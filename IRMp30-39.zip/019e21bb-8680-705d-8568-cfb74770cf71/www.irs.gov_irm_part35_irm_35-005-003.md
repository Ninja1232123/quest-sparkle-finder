---
url: "https://www.irs.gov/irm/part35/irm_35-005-003"
title: "35.5.3 Coordination of Settlements With Other Related Matters | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-005-003#main-content)

- 35.5.3 [Coordination of Settlements With Other Related Matters](https://www.irs.gov/irm/part35/irm_35-005-003#idm140380229763440)
  - 35.5.3.1 [Overview](https://www.irs.gov/irm/part35/irm_35-005-003#idm140380219264784)
  - 35.5.3.2 [Coordination of Settlements in Related Tax Court Cases with theAttorney General](https://www.irs.gov/irm/part35/irm_35-005-003#idm140380210567264)
  - 35.5.3.3 [Coordination of Tax Court and Refund Cases](https://www.irs.gov/irm/part35/irm_35-005-003#idm140380222563760)

    - 35.5.3.3.1 [Settlement Offers in Tax Court Cases](https://www.irs.gov/irm/part35/irm_35-005-003#idm140380220223760)
    - 35.5.3.3.2 [Settlement of the Tax Court Case With Dismissal of the Refund Suit](https://www.irs.gov/irm/part35/irm_35-005-003#idm140380212860624)
    - 35.5.3.3.3 [Settlement Offer to Settle Only the Refund Suit](https://www.irs.gov/irm/part35/irm_35-005-003#idm140380213128752)
    - 35.5.3.3.4 [Settlement Offers in Tax Court and Refund Cases](https://www.irs.gov/irm/part35/irm_35-005-003#idm140380249142224)

      - 35.5.3.3.4.1 [Offer Submitted to Field Counsel](https://www.irs.gov/irm/part35/irm_35-005-003#idm140380208270400)
      - 35.5.3.3.4.2 [Offer Submitted to DJ](https://www.irs.gov/irm/part35/irm_35-005-003#idm140380209828512)

  - 35.5.3.4 [Tax Court Cases Having Criminal Aspects](https://www.irs.gov/irm/part35/irm_35-005-003#idm140380222614128)
  - 35.5.3.5 [Coordination of Tax Court Cases and Collection Matters](https://www.irs.gov/irm/part35/irm_35-005-003#idm140380209810592)

    - 35.5.3.5.1 [Insolvency Cases](https://www.irs.gov/irm/part35/irm_35-005-003#idm140380227937392)

# Part 35. Tax Court Litigation

# Chapter 5. Settlement Procedures

# Section 3. Coordination of Settlements With Other Related Matters

* * *

## 35.5.3 Coordination of Settlements With Other Related Matters

**35.5.3.1** **(08-11-2004)**

### Overview

1. Anything signed or approved by or in the name of the Chief Counsel should be the position of the entire office and not merely the position of a particular division or part of the office. _See_ coordination principles at CCDM **31.1.4.2 Coordination within the Office of Chief Counsel.**


**35.5.3.2** **(08-11-2004)**

### Coordination of Settlements in Related Tax Court Cases with the Attorney General

1. The basic authority of the Attorney General to settle tax cases within the jurisdiction of the Department of Justice is contained in section 7122(a) and Executive Order No. 6166, dated June 10, 1933. _See_ C.B. X111–2, 449. Section 5 of that Order provides, in part, as follows:



|     |     |
| --- | --- |
|  | "As to any case referred to the Department of Justice for prosecution or defense in the Courts, the function of decision whether and in what manner to prosecute, or to defend, or to compromise, or to appeal, or to abandon prosecution or defense, now exercised by any agency or officer, is transferred to the Department of Justice." |

2. Cases docketed in the Tax Court that have not been referred to the Department of Justice are within the jurisdiction of the Chief Counsel, who is the Commissioner’s exclusive representative in the Tax Court pursuant to section 7452.

3. In order to ensure that the Attorney General’s settlement authority is properly exercised with the fullest knowledge of all pertinent matters concerning cases within their jurisdiction, it is essential that proposed settlements of Tax Court cases that are related to cases pending in DJ are carefully coordinated with the DJ attorney. Following coordination with DJ, settlements of related Tax Court cases will be finalized by the Chief Counsel.

4. Coordination between the Chief Counsel and the Attorney General occurs whenever there is a pending refund or collection suit with DJ, and the taxpayer’s offer of settlement to DJ includes not only disposition of the refund or collection suit but also disposition of a related Tax Court case or a related nondocketed case. In this instance, only after coordination with DJ has been completed will a final determination on the acceptance or rejection of the offer be made. Coordination with the Attorney General must also occur in instances in which an offer of settlement is made to the Service to dispose of not only the Tax Court and/or nondocketed cases but also a pending refund or collection suit.

5. All letters to DJ regarding settlement may be mailed directly by Field Counsel, except that the following must be submitted to the appropriate Associate office for review:



   - Letters recommending acceptance of offers covering years or parties not in suit (prepared for signature of the Chief Counsel or current delegate).

   - Letters recommending acceptance of offers which must be submitted to the Joint Committee on Taxation.

   - Letters recommending acceptance of offers concerning attorneys’ fees and costs under the Equal Access to Justice Act.


6. Notwithstanding the above, Field Counsel in their discretion may send any letter to the appropriate Associate office for review. Two information copies of any directly mailed letter should be sent by Field Counsel to the appropriate Associate office. _See_ Exhibit 35.11.1–1, Issues Requiring Associate Office Review.


**35.5.3.3** **(08-11-2004)**

### Coordination of Tax Court and Refund Cases

1. A settlement or concession in a Tax Court case may not be made in any instance in which there is also a refund suit in a related case pending in a district court, the Court of Federal Claims, a court of appeals, or the Supreme Court without prior coordination of the proposed settlement or concession through the appropriate Associate office and with DJ. Likewise, a proposed settlement or concession in a refund suit will be coordinated with the related Tax Court case prior to the Office of Chief Counsel’s recommendation to DJ on such proposal. The requirements set forth in this section are applicable both to situations in which the Attorney General must be consulted with respect to the settlement of the Tax Court case, and in situations in which the settlement of the Tax Court case is to be effectuated without a corresponding settlement of the refund suit.


**35.5.3.3.1** **(08-11-2004)**

#### Settlement Offers in Tax Court Cases

1. If the petitioner submits an offer to settle only the Tax Court case, such offer shall be processed in Field Counsel in the same manner as any other offer, except that before a final commitment is made by the Service on the acceptance of the offer it shall be coordinated with DJ. A rejection need not be coordinated.

2. If the offer is acceptable to Counsel, a letter to DJ should be prepared setting forth the issues involved in the petitioner’s case, the petitioner’s offer of settlement of such issues, and the reasons why the offer is viewed as being acceptable. The letter should in its caption reflect the name and the docket number of the refund case. The letter will inquire whether DJ has any objections to the proposed settlement of the Tax Court case. The letter to DJ should also explain why the settlement does not adversely affect the refund case.

3. For last-minute settlement offers received at or about the time of trial, a motion to continue the case should be filed with the suggestion that the court order a report on settlement at least 90 days in the future, so that there will be sufficient time to complete coordination with DJ.


**35.5.3.3.2** **(08-11-2004)**

#### Settlement of the Tax Court Case With Dismissal of the Refund Suit

1. If a counterclaim is pending in a related refund suit, or if any monetary value is to be assigned to the taxpayer’s willingness to dismiss the refund suit, the offer may not be accepted without prior coordination with DJ.

2. In some cases, the principal controversy is pending in the Tax Court and not in the district court or Court of Federal Claims, and if the petitioner can obtain an agreeable settlement in the Tax Court case, the taxpayer will dismiss the refund suit with prejudice. DJ has agreed that in a situation of this type the Chief Counsel may, without prior clearance from DJ, obtain an appropriate agreement from the taxpayer for dismissal of the refund suit, with prejudice, and send it to the Tax Division for filing with the district court or Court of Federal Claims, as appropriate. This procedure is applicable only if there is no counterclaim in the refund suit, and only if no monetary value is assigned to the dismissal of the refund suit in the settlement of the Tax Court case. Field Counsel, in settling the Tax Court case, with the provision for the dismissal of the refund suit, must be careful to determine that the settlement offer in the Tax Court case is acceptable on its own merits without regard to the dismissal of the refund suit, and that the concession of the refund suit plays no part in the acceptance on the merits of the offer in the Tax Court case. This provision is necessary and must be strictly followed by Field attorneys due to the statutory responsibility placed upon the Attorney General for the compromise of tax cases pending in the district court or Court of Federal Claims.

3. In effecting the settlement, Field Counsel will obtain from the attorney of record for the taxpayer in the district court or Federal Court of Claims a stipulation to dismiss with prejudice the refund suit. A stipulation for a dismissal of a district court case will be prepared for the signature of the appropriate trial attorney in the Tax Division, who has been assigned to the refund case; a stipulation for dismissal of a Court of Federal Claims case will also be prepared for the signature of the assigned DJ trial attorney. Simultaneously with the filing of the Tax Court stipulation, Field Counsel should forward a letter to DJ indicating the settlement of the Tax Court case, the willingness of the taxpayer to execute the dismissal of the refund suit, and the fact that no consideration was given to the dismissal of the refund suit in evaluating the settlement offer with respect to the Tax Court case. An original and six copies of the stipulation of dismissal of the refund suit should be forwarded with such letter.


**35.5.3.3.3** **(08-11-2004)**

#### Settlement Offer to Settle Only the Refund Suit

1. Generally, settlement offers in refund suits are processed in two different ways. Certain types of cases are classified Settlement Option Procedure. For a case so classified, DJ, upon receipt of an offer in compromise, will either accept it or reject it without first obtaining the recommendation of the Office of Chief Counsel. The Office of Chief Counsel will be notified if the offer is accepted on behalf of the Attorney General. For cases not classified as SOP cases, DJ will forward the taxpayer’s proposal of compromise of the refund suit to Field Counsel for its recommendation prior to either acceptance or rejection of the settlement proposal.

2. Normally, a refund suit is not classified as an SOP case if there is a related case pending in the Tax Court. If a refund suit is initially classified under SOP and at a later date, a petition is filed with the Tax Court which becomes a related case, Field Counsel should inform DJ of the related Tax Court case and that the refund suit has been reclassified as Standard.

3. Upon receipt of an offer to settle solely the refund suit in a case which is related to a Tax Court case, Field Counsel will prepare a letter to DJ containing its views as to the effect of the acceptance or rejection of the settlement offer in the refund suit on the Tax Court case. If the same issue or issues or the same general facts or factual pattern, are involved in the two cases, the letter should state whether the proposed settlement of the refund suit would have a substantial effect on the disposition of the Tax Court case, either by trial or settlement, and the basis for such views.

4. If the offer in the refund suit is accepted on behalf of the Attorney General, appropriate notification will be given to Field Counsel by DJ.


**35.5.3.3.4** **(08-11-2004)**

#### Settlement Offers in Tax Court and Refund Cases

1. Offers of settlement submitted by the taxpayer to settle both the refund suit and the Tax Court case are offers, which must be finally accepted or rejected by or on behalf of the Attorney General in the refund suit and the Chief Counsel in the Tax Court case. The petitioner or his/her representative, should be informed of these facts at the settlement conference. Even if the conference is attended by a DJ attorney, and the DJ attorney and Field Counsel attorney are in agreement, the taxpayer should not be led to believe that an offer has been accepted. The taxpayer may be informed, however, that the offer will or will not be recommended for acceptance by those attending the conference. Also coming within this category are offers to settle solely the Tax Court case and the simultaneous dismissal of the refund suit if there are counterclaims on behalf of the government in the refund suit, or if in the acceptance of the offer with respect to the Tax Court case monetary value or consideration for the acceptance is to be given to the dismissal of the refund suit. These offers may be submitted by the taxpayer either directly to DJ or to Counsel.

2. In the settlement of a Tax Court case requiring coordination with the Attorney General, it is essential to determine the extent to which a deficiency or overpayment will be stipulated in the Tax Court case. The letter to DJ recommending action on the offer should clarify or seek clarification on that point.

3. For offers submitted to settle both a Tax Court case and a related refund suit the following procedures should be followed:



1. If the Office of Chief Counsel recommends the acceptance of the offer, but DJ rejects the offer, DJ will be free to accept an offer in a more substantial amount without the resubmission of the new offer for Counsel’s views.

2. If Counsel recommends rejection of the offer, the letter, when feasible, should set forth the minimum offer, which Counsel believes should be recommended for acceptance in the overall settlement of the Tax Court case and the refund suit.

3. When feasible, a recomputation of the dollar results of the settlement proposal as it affects both cases should be forwarded with Counsel’s recommendation on the offer. The recommendation must not be unduly delayed to obtain such a recomputation, however.


**35.5.3.3.4.1** **(08-11-2004)**

##### Offer Submitted to Field Counsel

1. If an offer is received by Field Counsel to settle not only the Tax Court case but also the related district court or Court of Federal Claims case, Field Counsel will immediately send a copy of the settlement proposal to DJ.

2. As soon as possible, Field Counsel should forward a letter setting forth the views of the Office of Chief Counsel regarding the acceptability of the offer.

3. For primarily legal issue cases, cases involving a question of Service position, and as appropriate for primarily factual issue cases, the letter should analyze the issues in relation to the provisions of the Internal Revenue Code, regulations, revenue rulings, or other indicated Service position which may be involved, as well as decided cases, both supporting and against the position taken in the recommendation. In many instances, DJ does not have all of the facts necessary for an adequate appraisal of a settlement offer, particularly as to whether the offer is adequate for the Tax Court case or the factual relationship between the Tax Court and refund cases, so this letter should provide the necessary factual analysis.

4. The settlement authority possessed by Appeals pursuant to Rev. Proc. 87–24, 1987-1 C.B. 720, is not applicable to this type of offer.


**35.5.3.3.4.2** **(08-11-2004)**

##### Offer Submitted to DJ

1. When a taxpayer submits a settlement offer to DJ to settle not only the district court or Court of Federal Claims case but also the Tax Court case, such offer is referred to Field Counsel for a recommendation. The procedures as to offers submitted to Field Counsel are also applicable to these offers.

2. In cases where Field Counsel’s letter is submitted to the appropriate Associate office for review, unless otherwise directed, the letter must be received in the Associate office within 25 days after receipt of the offer from DJ. In cases where the letter recommending action on the offer is mailed directly by the field to DJ, the letter is due in DJ within 30 days after receipt of the offer from DJ. In many instances, the refund suit has been scheduled for trial, and the judge may not delay the trial to afford an extensive period of time for consideration of the offer. Thus, these offers should be given priority in their consideration. These time limitations are applicable to any recommendation which is to be made to DJ, whether the offer pertains solely to the refund suit or to both the Tax Court case and the refund suit.


**35.5.3.4** **(08-11-2004)**

### Tax Court Cases Having Criminal Aspects

1. Approval of the issuance of the statutory notice by the office then charged with the criminal matter recognizes that the civil case may be forced to a conclusion before the criminal case. In any such case, whether the statutory notice was issued by Appeals or an Area Director (SB/SE), the files related to the Tax Court matter should be retained by Counsel pending completion of the criminal aspects of the case or until the supervisor determines that forwarding the case to Appeals is appropriate. Generally, any settlement of the case must be in accord with the basis of the recommendation for prosecution to DJ. _See_ CCDM 38.3.1.8, which discusses the balancing of criminal and civil considerations.

2. It is the policy of the Service not to hold settlement conferences in Tax Court cases that have open criminal aspects, except at the request of or with the concurrence of DJ. (Note that the concurrence with DJ is necessary only if the criminal case has been referred; otherwise, concurrence is with the Criminal Investigation Division.) The factors to be given consideration may be different, depending upon whether the related criminal case is pending in Criminal Investigation, Counsel, or DJ offices. Also, the factors may be different when the related criminal case is open and when it is closed, as well as whether the taxpayer, or related taxpayer, was in fact indicted, convicted based upon a plea agreement, convicted after a trial, or was acquitted.

3. In this section, the term "related Tax Court and criminal cases" usually means that the criminal case involves the same taxpayer for the same or some of the same years that are pending in the Tax Court case. The term also includes a related taxpayer or different years of the same taxpayer if the facts, theory, or circumstances in the two cases are so intertwined that an action taken in one may materially affect the other. This is particularly applicable in net worth cases because of the effect of one year’s ending net worth on the next year’s beginning net worth.

4. The basic principle involved is that when a criminal tax case is under investigation or has been referred to DJ for prosecution, the Chief Counsel, or his delegate, should not, without a basic change in the facts or law, recommend criminal prosecution on the one hand while on the other hand admit or concede there is no civil fraud or fraud delinquency penalty. Nor should Field Counsel allow evidence to be prematurely discovered in a civil proceeding that would not be as readily available in a criminal case. In theory, there is a difference between the quantum of proof necessary to sustain the civil fraud or fraud delinquency penalty and to prove the criminal tax violation. As a practical matter, if there is sufficient evidence to recommend criminal prosecution, or DJ determines that there is sufficient evidence to warrant an indictment, there should be sufficient evidence to support the government’s burden on the civil fraud or fraud delinquency penalty. This latter factor should be borne in mind by the attorneys and supervisors in the consideration of any proposed concession of the fraud or fraud delinquency penalty in a Tax Court case for a year or years covered by the prosecution recommendation.

5. After a prosecution referral has been made to DJ in a criminal case, settlement negotiations in a related civil case will not ordinarily be conducted while the criminal aspects of the case remain open, except perhaps in fugitive situations or in response to a request by the attorney for the government as part of the sentencing process. In fugitive situations, however, negotiations should not be pursued without the advance concurrence of DJ. Any proposed settlement should be coordinated in advance with DJ. Any proposal for settlement should fully set forth all of the material facts.

6. When the criminal case has been closed by DJ following a conviction either by trial or plea, the following guidelines are applicable.



1. The ability of the government to sustain the civil fraud or fraud delinquency penalty will, of course, be determined on the basis of the available evidence existing at the time disposition of the Tax Court case is considered. Concession of the fraud or fraud delinquency penalty for prosecution years should be considered only if the necessary evidence is unavailable due to destruction of documents, death or unavailability of essential witnesses, or if there is substantial and material new evidence which for a justifiable reason was not available or considered in the criminal conviction. Furthermore, except in extraordinary circumstances, the concession of the fraud or fraud delinquency penalty under the above factors should be considered only for the years for which there was no guilty plea or conviction, or for which a nolo contendere plea was entered in the criminal case.

2. If the taxpayer is convicted upon a plea of guilty or after a trial on the counts of the indictment, the settlement of the Tax Court case must not be inconsistent with the theory of the counts in the indictment upon which the guilty plea or conviction was obtained in the criminal case. It is recognized that during the criminal trial the criminal figures may be reduced. If a settlement on an inconsistent basis is, in the view of Field Counsel, justified, it must first be coordinated with the Criminal Tax attorney and Area Counsel (CT) prior to any commitment being made thereon by Field Counsel. If the settlement reduces or concedes the fraud or delinquency penalty for a conviction year, the settlement must be approved by the Field Counsel responsible for the Tax Court case, after coordination with the Area Counsel (CT).


7. When the criminal aspects of a Tax Court case are pending investigation with Criminal Investigation or pending consideration with the delegated officials of Criminal Investigation, the following guidelines are applicable.



1. A settlement of a Tax Court case may not be effectuated until it has been determined whether or not criminal prosecution will be recommended or until it has been determined that a settlement of the Tax Court case will not prejudice the criminal prosecution of the taxpayer for the years under consideration by the administrative officials.

2. For such cases which are calendared for trial, Field Counsel should immediately contact the appropriate special agent or Criminal Tax attorney considering criminal prosecution. Every effort should be made to expedite the administrative investigation or consideration of the criminal aspects of the case so that a determination as to prosecution recommendation may be reached prior to the time when action must be taken in the Tax Court case.


8. For civil cases which are set for trial before the disposition of the criminal case, the taxpayer may in a stipulation of facts or trial preparation conference make a settlement proposal, which the Field attorney deems acceptable and not detrimental to the criminal case. While, in this instance, the attorney or the reviewer must not make any commitment with respect to such offer or negotiate settlement, Field Counsel may clarify the taxpayer’s offer and obtain all of the facts or bases upon which it is made for later consideration and coordination with the Area Counsel (CT).

9. Problems often develop in the civil case when the taxpayer is under indictment and has left the country. It is the general policy of DJ not to deal with fugitives from justice. This policy specifically applies to the settlement of the civil liability and, normally, if the taxpayer is a fugitive from justice, settlement proposals will not be entertained or considered. In appropriate instances, DJ may give clearance for settlement negotiations. This general policy of not dealing with fugitives from justice does not apply to the stipulation of facts or other trial preparation when the Tax Court has set the civil case for trial prior to the disposition of the criminal case. If it appears that a case in this category will be set for trial by the Tax Court and that an agreed motion for continuance cannot be obtained, the Field Counsel responsible for the Tax Court case, the Area Counsel (CT), and APJP, Branch 3 should be promptly notified.


**35.5.3.5** **(08-11-2004)**

### Coordination of Tax Court Cases and Collection Matters

1. A settlement or concession in a Tax Court case may not be made in any instance where there is a related general litigation case (including bankruptcy cases) pending in any court without prior coordination of the proposed settlement or concession in the appropriate Division or Associate office and with DJ. Likewise, a proposed settlement or concession in a related general litigation docketed case will not be made or recommended to DJ without prior coordination concerning the Tax Court case.

2. Field Counsel will coordinate, or cause to be coordinated, within their areas the tax litigation and general litigation activities of related cases. Action will not be taken or recommended in one case without prior coordination.


**35.5.3.5.1** **(08-11-2004)**

#### Insolvency Cases

1. _See_ CCDM 35.4.1.5.3 for a discussion on insolvency case coordination.

2. Normally, DJ is not much concerned with the amount of the settled tax liability, because the primary case within its jurisdiction relates to the allowance and collection in the insolvency proceeding of the taxes that are due. When offers to settle the Tax Court case are submitted to the Office of Chief Counsel, it should be ascertained whether DJ or the United States Attorney has at that time any interest in the determination of the amount of the correct tax liability. If so, before Field Counsel makes a final commitment on the offer, clearance should be obtained from DJ. In obtaining clearance, Field Counsel will prepare a proposed letter to DJ setting forth the tax liability involved in the Tax Court case and the proposed settlement. The letter will also inquire of DJ whether it has any objection to Counsel proceeding with the acceptance of the offer and the resulting disposition of the Tax Court case.

3. If an offer is received by an Associate office in a case within its jurisdiction having Tax Court aspects, the offer will be coordinated with Field Counsel with respect to the effect of the offer on the Tax Court case. Necessary coordination will be effected between the offices before disposition of the offer.

4. If the petitioner before the Tax Court dies during the pendency of the case, problems necessitating coordination may arise. With respect to the Tax Court case, this requires the naming of a successor petitioner or, if no successor is available, dismissal of the Tax Court case for failure to prosecute. Each case will have to be handled according to the particular facts or circumstances involved. The general provisions for coordination in insolvency cases are also applicable with respect to decedent estate cases. As in Tax Court cases having receivership aspects, it is always preferable that the merits of the case be determined in the Tax Court rather than in the probate court or other courts involved in the related aspects of the case.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-005-003#addtoany "Show all")

A2A