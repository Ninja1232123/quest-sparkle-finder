---
url: "https://www.irs.gov/irm/part33/irm_33-003-001"
title: "33.3.1 Legislation and Miscellaneous Matters | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part33/irm_33-003-001#main-content)

- 33.3.1 [Legislation and Miscellaneous Matters](https://www.irs.gov/irm/part33/irm_33-003-001#idm140352989591216)
  - 33.3.1.1 [Role of Office of Chief Counsel](https://www.irs.gov/irm/part33/irm_33-003-001#idm140352989590784)
  - 33.3.1.2 [Coordination of Proposed Legislation and Plans for Implementationof Legislation](https://www.irs.gov/irm/part33/irm_33-003-001#idm140352989577552)
  - 33.3.1.3 [Implementing New Legislation](https://www.irs.gov/irm/part33/irm_33-003-001#idm140352989568592)
  - 33.3.1.4 [Legislation Correspondence](https://www.irs.gov/irm/part33/irm_33-003-001#idm140352989562288)

# Part 33. Legal Advice

# Chapter 3. Other Legal Advice

# Section 1. Legislation and Miscellaneous Matters

* * *

## 33.3.1 Legislation and Miscellaneous Matters

**33.3.1.1** **(08-11-2004)**

### Role of Office of Chief Counsel

1. The Office of Chief Counsel may recommend, draft, or review proposed tax legislation. Primary responsibility for the recommendation and preparation, or review, of proposed legislation generally is assigned to the Associate Chief Counsel office that has jurisdiction over the subject matter of one or more provisions contained in the proposed legislation.


**33.3.1.2** **(08-11-2004)**

### Coordination of Proposed Legislation and Plans for Implementation of Legislation

1. The Office of Chief Counsel recommends and drafts proposed tax legislation in consultation with the affected Service organizations, the Office of Tax Policy, and the Department of Justice. The Associate Chief Counsel office that has jurisdiction over the subject matter of the proposed legislation generally is responsible for drafting the proposed legislative change. If two or more Associate Chief Counsel offices have subject matter jurisdiction over the provisions to be included in the proposed legislation, primary responsibility for drafting the proposed legislation is assigned to one Associate Chief Counsel office and that office is responsible for coordinating with the other Associate Chief Counsel office(s) or Division Counsel office(s), the Office of Tax Policy, the Department of Justice, and the affected Service organizations, as appropriate.

2. The Office of Chief Counsel will review or comment on legislative changes proposed by a Service field office, the Department of Treasury, other government agencies, or the Joint Committee on Taxation. Legislative proposals submitted to the Office of Chief Counsel for comment are directed to the Associate Chief Counsel office that has jurisdiction over the subject matter of the proposal. If the Associate Chief Counsel office that has jurisdiction over the subject matter is unknown or unascertainable, the legislative proposal is directed to the Legislative Counsel, Legal Processing Division (Procedure & Administration), which will determine the appropriate Associate Chief Counsel office and send the proposed legislation to that office. Where the subject matter of the legislative proposal implicates the jurisdiction of two or more Associate Chief Counsel offices, primary responsibility for the review of the proposed legislation is assigned to one Associate Chief Counsel office. The assigned Associate Chief Counsel office will coordinate the review of the proposed legislation with the other appropriate Associate Chief Counsel or Division Counsel offices and provide a timely response to the Department, committee, or office that requested review of their proposed legislation.


**33.3.1.3** **(08-11-2004)**

### Implementing New Legislation

1. The Office of Tax Administration Coordination (OTAC) coordinates the Service’s implementation of new tax legislation. OTAC contacts the Legislative Counsel, Legal Processing Division (P&A) when the enactment of tax legislation appears imminent or probable and OTAC intends to coordinate the implementation of the legislation. The Legislative Counsel will notify the appropriate Associate Chief Counsel and Division Counsel offices of OTAC’s plans to coordinate Service’s implementation of the legislation. The Legislative Counsel also will ask these offices for their input on what, if any, guidance is necessary for implementation of the legislation. The Legislative Counsel will input this information on OTAC’s legislative implementation database, soliciting further information from and apprising the Associate Chief Counsel and Division Counsel offices as necessary.

2. If guidance is necessary, the Associate Chief Counsel or Division Counsel office will create the appropriate assignment on TECHMIS. The due date for completing the assignment will be on or before the date that the Legislative Counsel, in consultation with the Associate Chief Counsel or Division Counsel office, provided to OTAC for completion of the action item. All guidance will be prepared, coordinated, and reviewed in accordance with applicable procedures. The Associate Chief Counsel or Division Counsel office responsible for preparing the guidance will notify the Legislative Counsel when the guidance has been issued and the case has been closed.


**33.3.1.4** **(08-11-2004)**

### Legislation – Correspondence

1. Congressional correspondence and telephone contacts, including contacts made by congressional staffers, concerning proposed legislation are controlled and processed under the procedures for congressional correspondence set forth in CCDM 33.3.5. For guidance in drafting replies to congressional correspondence relating to legislation, Office of Chief Counsel employees should consult the _Guide to Congressional Correspondence_ (IRS Document 11155), which is available on the Office of Legislative Affairs (Communications and Liaison) intranet site. Note, however, that this guidance may not be applicable to Office of Chief Counsel in all situations.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part33/irm_33-003-001#addtoany "Show all")

A2A