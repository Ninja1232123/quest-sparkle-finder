---
url: "https://www.irs.gov/irm/part34/irm_34-002-001"
title: "34.2.1 Jurisdiction of the Court Of Federal Claims | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part34/irm_34-002-001#main-content)

- 34.2.1  [Jurisdiction of the Court Of Federal Claims](https://www.irs.gov/irm/part34/irm_34-002-001#idm140477661851600)
  - 34.2.1.1  [Suits for a Refund of Tax/Counterclaims](https://www.irs.gov/irm/part34/irm_34-002-001#idm140477689408192)
  - 34.2.1.2  [Declaratory Judgments Relating to Status and Classification of Organizations under Section 501(c)(3)](https://www.irs.gov/irm/part34/irm_34-002-001#idm140477661573968)

# Part 34. Chief Counsel Directives Manual Litigation in District Court, Bankruptcy Court, Court of Federal Claims, and State Court

# Chapter 2. Jurisdiction of the Court of Federal Claims

# Section 1. Jurisdiction of the Court Of Federal Claims

* * *

## 34.2.1 Jurisdiction of the Court Of Federal Claims

#### Manual Transmittal

July 11, 2023

#### Purpose

(1) This transmits new CCDM 34.2.1, Litigation in District Court, Bankruptcy Court, Court of Federal Claims, and State Court; Jurisdiction of the Court of Federal Claims.

#### Background

CCDM Parts 34-35 are being updated to incorporate provisions of the centralized partnership audit regime enacted by the Bipartisan Budget Act of 2015 (BBA).

#### Material Changes

(1) A new subsection is added to section 34.2.1.1 to incorporate Bipartisan Budget Act of 2015 (BBA) provisions on the Court of Federal Claims jurisdiction over notices of final partnership adjustment..

#### Effect on Other Documents

This section supersedes CCDM 35.18.7.2 dated 5/10/2000.

#### Audience

Chief Counsel

#### Effective Date

(07-11-2023)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**34.2.1.1** **(07-11-2023)**

### Suits for a Refund of Tax/Counterclaims

1. Taxpayers may challenge the validity of the Service’s tax determination by paying the disputed tax and commencing a suit for a refund. Section 7422; 28 U.S.C. § 1491. In order to invoke the court’s jurisdiction, a taxpayer must first have filed an administrative claim for refund or credit which was denied or deemed denied under applicable regulations. Section 7422(a). _See_ CCDM 34.1.1.2 regarding counterclaims.

2. Under the Bipartisan Budget Act of 2015 (BBA), a partnership may within 90 days of the IRS mailing a notice of final partnership adjustment (FPA) file a petition in the Court of Federal Claims for a readjustment of the FPA. Section 6234(a). The Court of Federal Claims jurisdiction over the FPA depends on the partnership first depositing with the IRS an amount equal to the imputed underpayment, any penalties, any additions to tax, and any additional amounts listed in the FPA. Section 6234(b). Only the partnership representative entitled by section 6231 to receive notice of the FPA may petition for a redetermination of the FPA. Section 6223.

3. Under the Tax Equity and Fiscal Responsibility Act (TEFRA), a tax matters partner, or, if the tax matters partner fails to do so, certain other partners, may file a petition for readjustment of a partnership item. Section 6226. A tax matters partner or another partner may also petition the court if the Service denies any part of an administrative adjustment request. Section 6228.

4. A suit in the Court of Federal Claims must seek money damages.

5. Appeals from decisions of the Court of Federal Claims are to the Court of Appeals for the Federal Circuit.


**34.2.1.2** **(08-11-2004)**

### Declaratory Judgments Relating to Status and Classification of Organizations under Section 501(c)(3)

1. The Court of Federal Claims has jurisdiction to make a declaration with respect to the Service’s determination, or failure to make a timely determination, of an organization’s initial qualification or continuing qualification under section 501(c)(3) or with respect to its classification as a private foundation. Section 7428; 28 U.S.C. § 1507.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part34/irm_34-002-001#addtoany "Show all")

A2A