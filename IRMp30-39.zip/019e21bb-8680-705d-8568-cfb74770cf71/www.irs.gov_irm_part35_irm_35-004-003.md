---
url: "https://www.irs.gov/irm/part35/irm_35-004-003"
title: "35.4.3 Gathering Information from the Petitioner | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-004-003#main-content)

- 35.4.3 [Gathering Information from the Petitioner](https://www.irs.gov/irm/part35/irm_35-004-003#idm140270551559680)
  - 35.4.3.1 [Enforcement of Administrative Summonses](https://www.irs.gov/irm/part35/irm_35-004-003#idm140270527028720)
  - 35.4.3.2 [Informal Requests](https://www.irs.gov/irm/part35/irm_35-004-003#idm140270517065600)
  - 35.4.3.3 [Formal Discovery](https://www.irs.gov/irm/part35/irm_35-004-003#idm140270551542560)

    - 35.4.3.3.1 [General Procedures](https://www.irs.gov/irm/part35/irm_35-004-003#idm140270517184992)
    - 35.4.3.3.2 [InterrogatoriesT.C. Rule 71](https://www.irs.gov/irm/part35/irm_35-004-003#idm140270505289392)

      - 35.4.3.3.2.1 [Uses of Interrogatories](https://www.irs.gov/irm/part35/irm_35-004-003#idm140270513446144)
      - 35.4.3.3.2.2 [Service of Interrogatories](https://www.irs.gov/irm/part35/irm_35-004-003#idm140270509733920)
      - 35.4.3.3.2.3 [Answering Interrogatories](https://www.irs.gov/irm/part35/irm_35-004-003#idm140270524946976)

    - 35.4.3.3.3 [Production of Documents and Things T.C. Rule 72](https://www.irs.gov/irm/part35/irm_35-004-003#idm140270521912240)

      - 35.4.3.3.3.1 [Service of a Request for Production of Documents and Things](https://www.irs.gov/irm/part35/irm_35-004-003#idm140270513060000)
      - 35.4.3.3.3.2 [Responding to a Request for Production of Documents](https://www.irs.gov/irm/part35/irm_35-004-003#idm140270509303392)

  - 35.4.3.4 [Depositions](https://www.irs.gov/irm/part35/irm_35-004-003#idm140270526765552)
  - 35.4.3.5 [AdmissionsT.C. Rule 90](https://www.irs.gov/irm/part35/irm_35-004-003#idm140270508511776)

    - 35.4.3.5.1 [Drafting Requests for Admission](https://www.irs.gov/irm/part35/irm_35-004-003#idm140270511628688)
    - 35.4.3.5.2 [Filing and Service of Requests for Admission](https://www.irs.gov/irm/part35/irm_35-004-003#idm140270524676112)
    - 35.4.3.5.3 [Responses to Requests for Admission T.C. Rule 90(c)](https://www.irs.gov/irm/part35/irm_35-004-003#idm140270521141632)
    - 35.4.3.5.4 [Multiple Petitioners](https://www.irs.gov/irm/part35/irm_35-004-003#idm140270510826208)
    - 35.4.3.5.5 [Review of Petitioners Responses](https://www.irs.gov/irm/part35/irm_35-004-003#idm140270510823712)
    - 35.4.3.5.6 [Withdrawal and Modification of Admissions](https://www.irs.gov/irm/part35/irm_35-004-003#idm140270513821600)
    - 35.4.3.5.7 [Supplementation of Response](https://www.irs.gov/irm/part35/irm_35-004-003#idm140270536776176)

  - 35.4.3.6 [Enforcement Actions and Sanctions](https://www.irs.gov/irm/part35/irm_35-004-003#idm140270504810640)

    - 35.4.3.6.1 [Procedures](https://www.irs.gov/irm/part35/irm_35-004-003#idm140270504929648)
    - 35.4.3.6.2 [Drafting the Motion](https://www.irs.gov/irm/part35/irm_35-004-003#idm140270516547584)
    - 35.4.3.6.3 [Contempt of Court](https://www.irs.gov/irm/part35/irm_35-004-003#idm140270507494784)

  - 35.4.3.7 [Subpoenas](https://www.irs.gov/irm/part35/irm_35-004-003#idm140270502874608)
  - 35.4.3.8 [Discovery in Collection Due Process Cases](https://www.irs.gov/irm/part35/irm_35-004-003#idm140270505281936)

# Part 35. Tax Court Litigation

# Chapter 4. Pre-Trial Activities

# Section 3. Gathering Information from the Petitioner

* * *

## 35.4.3 Gathering Information from the Petitioner

#### Manual Transmittal

July 26, 2012

#### Purpose

(1) This transmits revised CCDM 35.4.3, Pre-Trial Activities; Gathering Information from the Petitioner.

#### Material Changes

(1) CCDM 35.4.3.8 was added to provide information about conducting discovery in Collection Due Process cases.

(2) Organizational references to APJP were updated to refer to the appropriate P&A practice group.

(3) Titles and hyperlinks were added to references throughout the section; references were updated as necessary.

#### Effect on Other Documents

CCDM 35.4.3 dated August 11, 2004 is superseded. This section also incorporates procedures contained in Chief Counsel Notice CC-2009-010.

#### Audience

Chief Counsel

#### Effective Date

(07-26-2012)

Deborah A. Butler

Associate Chief Counsel

(Procedure and Administration)

**35.4.3.1** **(08-11-2004)**

### Enforcement of Administrative Summonses

1. District courts have jurisdiction to enforce a Service administrative summons, whether the summons was issued prior to or after mailing of the notice of deficiency or notice of determination on which the Tax Court case is based. The Tax Court does not have jurisdiction to either enforce or not enforce an Service administrative summons. The Tax Court does have power to receive or exclude evidence developed through use of a summons.

2. The Tax Court will not exclude, on grounds related to the timing of the summons, evidence developed by use of a summons issued prior to the filing of Tax Court petition.

3. Only rarely (e.g., in the case of a Criminal Investigation summons) should the Service issue a summons in regard to a certain liability for a certain period after mailing of a notice of deficiency or a notice of determination for that liability and period, even less so after the filing of a Tax Court petition. It is not uncommon for a summons for a liability or a period not determined in a notice of deficiency or notice of determination to be issued after the notice is mailed. In either circumstance, the summons may seek or develop evidence relevant to the liability determined in the notice. If a Tax Court petition has been filed and the Field attorney desires to use any evidence developed as a result of a post-petition summons, the Tax Court may examine the circumstances under which the summons was issued. The court may exclude such evidence, unless the Service can show that the summons was issued legitimately, in good faith, for reasons independent of the Tax Court’s proceedings, and not in circumvention of the court’s discovery rules.


**35.4.3.2** **(08-11-2004)**

### Informal Requests

1. Discovery and requests for admissions may not be commenced by a party until after that party has made a meaningful, good faith attempt to attain the objectives of discovery through informal consultation or communication. T.C. Rules 70(a), 90(a); _Branerton Corp. v. Commissioner_, 61 T.C. 691 (1974). The Tax Court is insistent that the parties use informal efforts to obtain needed information for the preparation of the case for trial. The court expects the parties to discuss, deliberate, and exchange ideas, thoughts, and opinions on an informal basis before resorting to the methods specified in the rules. Short cuts to the use of formal discovery will not be tolerated.

2. Compliance with the "informal discovery" process begins with the Field attorney’s early and careful review of available Service files and the law applicable to the case. This review will help determine what additional facts and documents must be obtained, and whether additional legal research is necessary.

3. This review should be followed by a request to the petitioner or petitioner’s counsel to confer about the facts of the case, together with a request that the petitioner make available the additional facts and documents the Field attorney has determined are necessary. The extent of the request for information should be specific and be consistent with the complexity of the issue. This request may be made orally or in writing, but if it is made orally it should be confirmed in writing. This _Branerton_ letter should set a conference date, time, and place. Care should be taken to propose a date for the conference that will allow the petitioner reasonably sufficient time to organize the requested records and permit a meaningful informal conference prior to the initiation of formal discovery. This letter should be as complete as possible and convey a tone in accordance with the court’s informal discovery requirements, as it may later come before the court in support of the Service’s claim that it has satisfied the _Branerton_ requirements, or serve as an exhibit to a motion seeking enforcement of formal discovery. Especially in a _pro se_ case, the language employed must be as simple, nonlegalistic, clear, and concise as possible. Sample _Branerton_ letters are included in the Chief Counsel macros. These samples should be selected and adapted by the Field attorney to be most useful in the individual case.

4. Petitioner’s failure to supply facts and documents to Appeals does not excuse the Office of Chief Counsel from the _Branerton_ requirements. Similarly, a meeting between petitioner and Appeals also is not a substitute for the required conference between petitioner and respondent required by _Branerton_.

5. The _Branerton_ requirements are best achieved through in-person meetings between the petitioner or petitioner’s counsel and the Field attorney. In some circumstances, proper and adequate trial preparation can be achieved primarily or completely through telephone conferences and exchange of documents by mail. Trial preparation and the trial itself will proceed most smoothly if the Field attorney is acquainted with the petitioner and petitioner’s counsel.

6. If petitioner does not respond to the _Branerton_ letter or appear at the conference, a letter should be sent by certified mail, return receipt requested (or its equivalent), setting another conference and warning that respondent will use formal discovery in the event of continuing non-cooperation. If no response to this warning letter is received, formal discovery procedures and requests for admissions should be initiated promptly.

7. All discovery requests, formal and informal, for the tax accrual workpapers of a public accounting firm must be approved by Division Counsel prior to the initiation of any such request.


**35.4.3.3** **(08-11-2004)**

### Formal Discovery

1. In general terms, discovery and admissions may be used by respondent to achieve these purposes:



   - Commit the petitioner to a version of the facts

   - Commit the petitioner to a theory of the case

   - Learn of persons having knowledge of relevant facts

   - Obtain from a party statements that the party has obtained from other persons

   - Obtain documents and information leading to other documentary evidence

   - Obtain information leading to other potential witnesses


2. In general terms, discovery is used to find unknown facts, and admissions are used to establish uncontested matters as quickly as possible. The effective use of discovery and admissions will narrow the issues in the case and permit concentration on the true dispute, explore the areas for potential cross-examination at trial, avoid the dilution of cross-examination by eliminating areas where cross-examination will not be fruitful, eliminate the possibility of the petitioner changing testimony by virtue of an opening statement indicating the nature of cross-examination, serve as an impeachment tool, corroborate other witnesses, form a basis for a motion for summary judgment or for opposition to a motion for summary judgment, form a basis to answer a request for admission served upon respondent, provide summary information from the petitioner’s records, and often lead to a settlement of the case. Importantly, use of these techniques will allow the Field attorney time within which to verify, through investigatory agents, the truth of matter being stated by the petitioner, and time within which to obtain impeachment or rebuttal witnesses.

3. Formal discovery and requests for admissions are unnecessary if the petitioner is cooperating, in full, in informal consultation and exchange of facts and documents and stipulation. Even though the Tax Court rules deem matters admitted under the admissions procedure to be part of the record in the case, the court does not contemplate that any of the discovery or admissions rules will serve as a substitute for the stipulation process. If formal discovery and requests for admissions are to be used, though, they should be used as early and completely as possible. Early and complete use of discovery will allow the attorney to obtain as much information as possible with adequate time to properly use the information at trial.

4. Traditionally, the Office of Chief Counsel has limited the use of formal discovery and requests for admissions in "S" cases and _pro se_ cases, in order to avoid even the appearance of an attempt to obtain unfair advantage. While caution is always appropriate, these traditional approaches should not be taken as a _per se_ rule. The expansion of "S" case procedures to larger and more complex cases, and the increase in numbers and complexity of _pro se_ cases, mean that these tools may be appropriate in more cases. The overall goal of both the _Branerton_ rule and the court’s discovery rules is the just, speedy, and inexpensive determination of every case. The decision to use or not use formal discovery and requests for admissions in an individual case should be based on that goal. Since petitioners generally have control over the facts, they should not be allowed to gain an unfair advantage through non-cooperation.

5. It is not appropriate to invoke the discovery procedures for a retaliatory or other improper purpose. For example, a premature request for production of documents under T.C. Rule 72 cannot be justified on the ground that petitioner’s counsel has served a similarly premature discovery request on respondent. The appropriate response to petitioner’s premature discovery request is a response denying petitioner’s right to premature discovery and offering informal consultation or communication in accordance with T.C. Rule 70(a).


**35.4.3.3.1** **(07-26-2012)**

#### General Procedures

1. The Tax Court’s Rules provide for formal pretrial discovery through the use of written interrogatories, requests for production of documents or things, and depositions in certain circumstances. T.C. Rules 70, 71, 72, 74, 75 and 76. In addition, T.C. Rule 73 provides a specific method for examination by transferees. Although a request for admission under T.C. Rule 90 is technically not a discovery technique (it is not, for instance, included in Title VII of the court’s rules), it may incidentally result in discovery and is often commonly thought of as another discovery technique.

2. Under T.C. Rules 70 and 38, formal discovery may not be commenced, without leave of the court, until 30 days after a case is at issue (when the last pleading, usually an answer or a reply is filed). Under Rule 70, discovery, including depositions, must be completed, unless otherwise authorized by the court, not later than 45 days prior to the date set for call of the case from a trial calendar. The last day for filing motions to enforce discovery is the 45th day before the date set for the calendar call. Any filing after that date must be accompanied by a motion for leave to file out of time.

3. Tax Court Rule 101 provides that written interrogatories, requests for production of documents or things, depositions, and requests for admissions may be used in any sequence or simultaneously. Since requests for admission may seek to establish petitioner’s legal position by requesting responses calling for the application of law to fact, this type of request may be most effective if served prior to use of other discovery procedures. On the other hand, in some cases, it may be desirable to serve requests for admission simultaneously with other discovery requests such as interrogatories. See Exhibit 35.11.1–80, Respondent’s Interrogatories to Petitioner Used in Conjunction with Request for Admissions. For example, respondent’s request for admissions may request petitioner to admit certain facts which respondent believes to be true but which petitioner has not admitted in the pleadings. The written interrogatory served simultaneously may ask that, if petitioner does not admit each and every statement contained in respondent’s request for admissions, petitioner explain and specify in detail in what respect the statement not admitted is untrue and what petitioner contend the true facts are; it may also ask that petitioner state the nature and identity of any documentary evidence upon which petitioner will rely to show that such statement is untrue and the name, address, and telephone number of the person or persons having possession of such documentary evidence; and, further, it may ask the name, address, and telephone number of all persons having knowledge of the facts which petitioner contends to be true. Combining discovery and admissions procedures in this manner should be used with caution, however. Each request should be carefully worded so that enforcement is not foreclosed by the terms of the request, e.g., a petitioner who ignores an admission request would not be required to respond to an interrogatory asking, "If petitioner denies Request for Admission No. 1, provide the basis for petitioner’s denial."

4. In the Tax Court, a party may use formal discovery to obtain information that is relevant and not privileged. The relevancy standard is interpreted liberally, but discovery should not be used to determine facts that will be used to raise new issues or formulate new adjustments. Material that would aid the discovering party in understanding relevant material and material that would lead to the discovery of other admissible evidence, is discoverable. The Tax Court’s Rules do not bar discovery of material already known to the requesting party or previously examined by the requesting party. Discovery is not confined strictly to matters of fact, but may be used to require a party to give a contention of how the law applies to the facts of the case. See CCDM 35.4.6.3.3, Privileges.

5. While a party may not, through use of discovery and admissions, obtain privileged information, the Field attorney need not anticipate that the petitioner will claim any particular privilege. Unless a claim of privilege has been made with respect to a certain matter and shown to be valid prior to use of discovery or admissions in regard to that matter, the attorney may use discovery or admissions, leaving to petitioner or petitioner’s counsel the choice of whether any particular privilege will be claimed.

6. Under applicable Civil Justice Reform procedures, all uses of formal discovery, including interrogatories, and requests for admission and depositions, must be reviewed by a Chief Counsel attorney of GS-15 or Senior Executive Service rank, or an individual formally acting for such an official, to ensure that the discovery requests are not burdensome or oppressive. No attorney, not even a GS-15 or SES attorney, may be the "reviewer" of his or her own discovery requests. This independent review is designed to ensure that the discovery requests are warranted in light of all relevant litigation factors, including the amount in controversy, the importance of the issues at stake, and whether the documents can be obtained from another less burdensome source. Normally, the attorney’s immediate supervisor will be the reviewer of discovery requests for Civil Justice Reform purposes. Each Chief Counsel operating division may provide its own procedures for review in the event the attorney’s usual reviewer is unavailable. Unless those procedures provide otherwise, the issuing attorney and the reviewing attorney need not be from the same division or from the same post of duty. In every case, though, the reviewing attorney must be of GS-15 or Senior Executive Service rank (or in a formal acting capacity), and must be made familiar enough with the case and the relevant litigating factors that the reviewing attorney can make an appropriate independent review. The identity of the reviewer, the date of the review, and the reviewer’s concurrence in the use of discovery must be documented in the legal file.

7. Tax Court Rules 70(e) and 90(d) require that every discovery request and request for admissions be signed by at least one counsel of record (or by the _pro se_ petitioner). The signature of counsel or a petitioner constitutes a certification that the signer has read the request, and that, to the best of the signer’s knowledge, information, and belief formed after a reasonable inquiry, the request is appropriate, not used for an improper purpose, and not unreasonable or unduly burdensome or expensive. The court may impose sanctions for violations of these rules.

8. All discovery requests, formal and informal, for the tax accrual workpapers of a public accounting firm must be approved by Division Counsel prior to the initiation of any such request.

9. In order to assist attorneys in ensuring that the discovery rules and procedures have been properly complied with, a discovery checklist has been developed. See Exhibit 35.11.1–81, Discovery Checklist (Interrogatories, Production of Documents, Admissions Depositions, Motions to Compel).


**35.4.3.3.2** **(08-11-2004)**

#### Interrogatories—T.C. Rule 71

1. Interrogatories consist of written questions served upon another party to which the other party makes written answers. Interrogatories may not be served on someone who is not a party to the litigation. Interrogatories should be stated as concisely and clearly as possible. Each interrogatory should be framed as a single, definite question, which is separately numbered and which solicits specific information. Although an interrogatory may solicit information needed to fill out a document (such as a tax return), a request to fill out a document is not a single, definite question, and, thus, is not a proper interrogatory.


**35.4.3.3.2.1** **(08-11-2004)**

##### Uses of Interrogatories

1. In general, written interrogatories are used by respondent to discover information. An answer to an interrogatory becomes part of the evidentiary record in the case only when it is offered and received in evidence in accordance with the rules of evidence. T.C. Rule 70(d). As a practical matter, responses to interrogatories will not normally be admissible in evidence on behalf of the party making the response, although may be used by the adverse party as admissions of a party opponent or for impeachment.

2. Particular uses of interrogatories include:



   - To obtain the names and addresses of potential witnesses

   - To identify documents that have been withheld because of a claim of privilege

   - To identify documents that have been destroyed

   - To identify the petitioner’s position as to a legal issue by requiring the application of law to fact "contention interrogatories"

   - To obtain information that might not otherwise be available until expert witness reports are exchanged (T.C. Rule 71(d))


**35.4.3.3.2.2** **(07-26-2012)**

##### Service of Interrogatories

1. Service is effected by mailing or delivering a copy to the other party, to which should be attached a copy of the certificate of service.

2. Neither interrogatories nor answers to interrogatories are filed with the court unless enforcement or sanctions are sought. The attorney issuing the interrogatories should retain the original interrogatories and original certificate of service (without hole-punching) for use in connection with any necessary motion relating to the interrogatories. T.C. Rule 71(c). See Exhibit 35.11.1–82, Respondent’s Interrogatories to Petitioner.

3. The Rules do not specify a limit on the number of times written interrogatories may be served in a case, and do not specify the sequence of discovery devices. T.C. Rule 101. In a given case, if proper planning allows sufficient time, the attorney may choose to issue specific sets of interrogatories relating to separate issues, and may choose to simplify the initial set(s) of interrogatories by not including alternative or follow-up questions until petitioner’s responses are received. If unexpected responses are received, a new set of interrogatories may be served to elicit responses to additional questions. Although limits on frequency and sequence are not specified, interrogatories and other discovery devices are subject to general limits, and improper use may trigger a motion for a protective order under T.C. Rule 103(a).

4. Unless it is certain that respondent will not issue more than one set of interrogatories, each set of interrogatories should bear a heading including distinguishing language such as Respondent’s \[First, Second, Third, Etc.\] Set of Interrogatories \[Regarding the \_\_\_\_\_\_\_\_\_\_ Issue\]. Individual interrogatories should be numbered consecutively. If respondent serves more than one set of interrogatories, the second and each subsequent set should contain numbering beginning where the previous set ended.


**35.4.3.3.2.3** **(08-11-2004)**

##### Answering Interrogatories

1. The party receiving interrogatories must serve a copy of the answers (and objections, if any) on the propounding party within 30 days after service of the interrogatories (unless the court allows a shorter or longer time).

2. All answers to interrogatories should be made in good faith and as completely as the answering party’s information permits. The answering party may not give lack of information or knowledge as an answer or as a reason for failure to answer, unless the answering party has made reasonable inquiry and information known or readily obtainable by the answering party is insufficient to enable the answering party to answer the substance of the interrogatory.

3. For purposes of the interrogatory rules, a party is charged with knowledge of the party’s agents, and has a duty to inquire of the party’s attorney, accountants, partners, etc., in responding.

4. Where an answer to an interrogatory may be ascertained from business records and the burden of ascertaining the answer from the records is the same for either party, the responding party has the option to specify the records and produce them, rather than answer in narrative form.


**35.4.3.3.3** **(07-26-2012)**

#### Production of Documents and Things — T.C. Rule 72

1. Requests for production of documents and things are written requests served upon another party requiring the responding party to produce and permit the requesting party (or someone acting on the requesting party’s behalf) to:



   - Inspect and copy documents (as defined in T.C. Rule 72(a)) designated by the requesting party

   - Inspect, and copy, test, or sample any tangible thing in the responding party’s possession, custody, or control (see Exhibit 35.11.1–83, Respondent’s Request for Production of Documents)


2. Such a request also may be used to enter on land or other property in the possession or control of the responding party, for the purposes set out in T.C. Rule 72(a)(2). See Exhibit 35.11.1–84, Respondent’s Request to Petitioner for Permission for Entry, Inspection, Measuring, and Photographing Property and Objects and Operations Thereon. The request should specify a reasonable time, place, and manner of making the inspection and performing acts in relation to the request. The request should specify that computerized data compilations be provided in a usable format. While in most situations the cost of complying with routine discovery requests is an expected cost of litigation borne by the responding party, extraordinary costs of copying documents or translating data compilations into a usable form may be borne by the party making the request. If such expenditures are anticipated, the Field attorney should make arrangements for payment with the F&M Office Manager/Administrative Operations Specialist/Support Team Leader before any agreement is reached with the petitioner for respondent to bear the costs. The expense of copying voluminous records should be justified by their value in trial preparation.


**35.4.3.3.3.1** **(08-11-2004)**

##### Service of a Request for Production of Documents and Things

1. Service of a request for production of documents and things is effected by mailing or delivering a copy to the other party, accompanied by a copy of the certificate of service.

2. Neither the request nor the response is filed with the court unless enforcement or sanctions are sought. The attorney issuing the request should retain the original request and original certificate of service (without hole-punching) for use in connection with any necessary motion relating to the request. T.C. Rule 72(b).

3. The request must set forth and describe items to be inspected (and copied), either by individual item or category. The request should be drafted with the objective of identifying the documents or objects sought with as much particularity as possible. A description of the document or thing by association is permitted when more particular descriptions are not available.

4. The request must specify a reasonable time, place, and means of making the inspection or copying.

5. The Rules do not specify a limit on the number of times requests for production of documents and things may be served in a case, and do not specify the sequence of discovery devices. T.C. Rule 101. In a given case, if proper planning allows sufficient time, the attorney may choose to issue specific sets of requests relating to separate issues, and may choose to simplify the initial set(s) of requests to specific documents or objects known to exist which can be very specifically identified. If those documents or objects provide leads or references to other documents or objects, an additional request may then be served to inspect them. Although limits on frequency and sequence are not specified, requests for production of documents and things and other discovery devices are subject to general limits, and improper use may trigger a motion for a protective order under T.C. Rule 103(a). A protective order also may be sought if a request is too broad, ambiguous or otherwise unduly burdensome.


**35.4.3.3.3.2** **(08-11-2004)**

##### Responding to a Request for Production of Documents

1. The party receiving the request must serve a copy of its response (including any objections) on the propounding party within 30 days after service of the request (unless the court allows a shorter or longer time).

2. Except as provided by T.C. Rule 102 (relating to identity and location of certain persons, correcting responses that are not true, and duties imposed by the court or by agreement of the parties or by new requests), a party who has responded completely to a request for production of documents and things has no duty to supplement the responses to include later acquired information.


**35.4.3.4** **(07-26-2012)**

### Depositions

1. Depositions may be taken of a party or a non-party witness. In broad terms, the Tax Court’s rules provide for two types of depositions.

2. One type of deposition is a "discovery" deposition. Discovery depositions are governed by T.C. Rules 74, 75, and 76. Discovery depositions may be taken only in connection with a pending case, almost always before trial has commenced. For additional information see CCDM 35.4.4.5.1, Discovery Depositions.

3. The second type of deposition is a "deposition to perpetuate testimony." This type of deposition is governed by T.C. Rules 80 through 85. Depositions to perpetuate testimony may be taken prior to commencement of a case (T.C. Rule 82), prior to trial (T.C. Rule 81), or after trial (T.C. Rule 83). For additional information see CCDM 35.4.4.5.2, Depositions to Perpetuate Testimony.

4. For additional information on general procedures see CCDM 35.4.4.5.2.4, Procedures for Taking Depositions.


**35.4.3.5** **(08-11-2004)**

### Admissions—T.C. Rule 90

1. Requests for admission may be used by a party to require another party to admit or deny a statement of fact, an opinion of fact, the application of law to fact, or the authenticity or genuineness of a document. The admissions procedure has the beneficial effect of narrowing the issues and conserving needless time and effort to prove undisputed facts or documents at trial, and the admissions themselves may provide a basis for settlement.

2. The Tax Court’s Rules do not specify a limit on the number of times requests for admission may be served in a case, and do not specify the sequence of discovery devices. T.C. Rule 101. In a given case, if proper planning allows sufficient time, the attorney may choose to issue specific sets of requests relating to separate issues. Although limits on frequency and sequence are not specified, requests for admissions and other discovery devices are subject to general limits, and improper use may trigger a motion for a protective order under T.C. Rule 103(a).

3. If respondent has made detailed affirmative allegations in the answer but petitioner files an unsatisfactory reply containing merely general denials, the use of a request for admissions should be considered.

4. Both the request for admission and the response must be signed by counsel or the party. If not signed, the document may be stricken or disregarded, unless it is signed promptly after the omission is called to the party’s attention. T.C. Rule 90(d).


**35.4.3.5.1** **(07-26-2012)**

#### Drafting Requests for Admission

1. Each request should be should be stated separately and as concisely and clearly as possible, so that it may be admitted or denied without qualification. See Exhibit 35.11.1–85, Respondent’s Request for Admissions. Argumentative and vague statements should not be used in a request for admission. Generally, an attorney should avoid making a request for an admission where the requested fact, if admitted, would hamper the respondent’s own case.

2. If the Field attorney knows a fact to be true because it is stated in the administrative file or has come to the attorney’s attention by another reliable method, the attorney may request an admission, even though the attorney presently would not be able to prove the fact under the rules of evidence. Otherwise, the attorney should avoid requesting an admission of fact not definitely known to be true, whether or not the fact appears to be favorable to respondent’s position. Other discovery techniques should be used to clarify the matter. If evidence later establishes an admission to be erroneous, even where the respondent was the requesting party, a timely motion to modify or withdraw the admission should be made in order to clarify the record.

3. Generally, the Field attorney should not make a request for an admission where the requested fact, if admitted, would hamper the respondent’s own case. In general, the requesting party is not held bound by the facts recited in a request for admission since the admission, when made, is that of the responding, not requesting, party. Nevertheless, a petitioner may attempt to use T.C. Rule 91(f) to deem such fact established unless the respondent has some factual basis to ask the court to modify the admission. If evidence later establishes an admission to be erroneous, even where the respondent was the requesting party, a timely motion to modify or withdraw the admission should be made to avoid this result and to clarify the record.

4. If a request for admission asks the other party to admit the genuineness of a document or to make other admissions regarding a document (such as the contents of a document or a person’s handwriting or signature), the responding party must have access to any document described in the request. Although not required by Rule 90 in every case, better practice in almost all cases is to attach to the request a copy of every such document.


**35.4.3.5.2** **(07-26-2012)**

#### Filing and Service of Requests for Admission

1. Unlike interrogatories and requests for production of documents and things, the original of a request for admissions and an original certificate of service must be filed with the court when the request is served. A copy of the request, with a copy of the certificate of service, is mailed or delivered to the other party. T.C. Rule 90(b).

2. In cases involving joint petitioners, joined parties, intervenors, or consolidated cases, requests for admission may be served on fewer than all of the opposing parties. Since T.C. Rule 90 specifically provides only for serving the other party, it is not necessary to name and serve parties other than the one(s) from whom the requested admissions are sought. In the event the request is directed at fewer than all the opposing parties, the non-served parties will not necessarily be bound by another party’s admissions. Note, however, that the court’s standing pre-trial order will require service of all papers on every party if submitted after the Notice setting case for trial. If there is any question regarding service of papers in these situations, advice may be sought from the Associate Chief Counsel (P&A), Branches 6 or 7.

3. If the same request for admission is to be served on parties in related cases that are not consolidated, duplicate originals bearing original signatures must be filed in each docket. If a request for admission is to be served on only one party or several parties in group of consolidated cases, the request should bear the "consolidated" caption of the case and all the docket numbers in the group, but the opening paragraph should direct only the petitioner(s) in the relevant docket(s) to respond to the request, e.g., "Respondent, pursuant to T.C. Rule 90, requests that petitioner in Docket No. 12345–85, within 30 days ..., etc." Similarly, if a request for admission is to be served on only one petitioner in a joinder or intervenor case (i.e., multiple petitioners or an intervenor under one docket number), the request should bear the joint, official caption, but the opening paragraph should direct only the relevant petitioner to respond to the request, e.g., "Respondent, pursuant to T.C. Rule 90, requests that petitioner \[name\], within 30 days ..., etc." The original of such a request, together with an additional copy for each additional docket in a consolidated group, should be filed with the court. The extent to which an admission by one party in a group of cases or petitioners binds the other parties in the group is determined by the Federal Rules of Evidence.


**35.4.3.5.3** **(08-11-2004)**

#### Responses to Requests for Admission — T.C. Rule 90(c)

1. The party receiving a request for admission must serve a response within 30 days after service of the request, or within such shorter or longer time as the court may allow. T.C. Rule 90(c). If the responding party wants to extend the 30 day period, a motion to enlarge time must be filed before the 30 day period expires. While the motion may be an agreed motion, the self-executing nature of admissions means that the parties cannot simply agree to extend the time to answer without using a motion. If the party serving the requests wants to shorten the 30 day period, a motion is required.

2. The original of the response and proof of service are filed with the court. T.C. Rule 90(b). If the Field attorney receives a response from petitioner under circumstances indicating that the petitioner or petitioner’s counsel did not file an original with the court, the petitioner or petitioner’s counsel should be informally contacted, advised of the requirement of Tax Court Rule 90(b), and requested to file a duplicate original with the court.

3. Both the request for admission and the response become part of the record in the case in much the same manner as a matter which is admitted or agreed to by virtue of the petition and answer in the same case. T.C. Rule 90(f) states that matters admitted under Rule 90 are "conclusively established unless the Court on motion permits withdrawal or modification of the admission." Nevertheless, T.C. Rule 91(a)(2) requires the incorporating of the admissions into a stipulation of facts. If petitioner refuses to stipulate the admitted matters, a motion should be filed under Rule 91(f). The admissions, although filed with the court, will not by themselves raise new issues for determination by the court. If the admissions contain statements which raise a new issue or issues in the case, the pleadings must be amended to specifically raise such new issues.

4. With respect to each request, the response should do one of the following:



   - Specifically admit or deny it, in whole or in part

   - Assert that it cannot be truthfully admitted or denied and state the reasons why

   - State an objection, with detailed reasons for the objection


5. The response may not give "lack of information" as a reason for failure to admit or deny, unless a reasonable inquiry has been made and the information known or readily obtainable is insufficient to enable the answering party to admit or deny.

6. The answering party may not refuse to admit or deny a request on the ground of relevance, but may note the relevance objection as part of the response. If the admission sought by the request would be inadmissible for a reason other than relevance, the answering party may object to it on that ground without admitting or denying it.


**35.4.3.5.4** **(08-11-2004)**

#### Multiple Petitioners

1. A response by counsel for, and on behalf of, joint petitioners is sufficient to bind both petitioners. Likewise, a request which is admitted by one petitioner but without any response by the other is deemed admitted by both, since no response is the same as an admission. In such case, however, the nonresponding joint petitioner should be sent the type of letter described in CCDM 35.4.3.5.5(3).

2. Separate or conflicting responses might be received from each of two joint petitioners with irreconcilable differences in their admissions or denials. In such case, discovery devices such as follow-up interrogatories or a motion to review the sufficiency of the responses, should be considered to help resolve the differences. Another approach would be to go forward with proposed stipulations of facts believed to be true and, if necessary, file a motion for an order to show cause under T.C. Rule 91(f) if the motion will otherwise lie. This should put the burden upon the petitioners to show which answers should be adopted for purpose of the case. Conflicting answers, if left standing, would be unreliable since the denying petitioner would be free at trial to contravene the admission of the other petitioner. Therefore, it is imperative that the conflict be resolved prior to trial. Exceptions will occur, e.g., where respondent is merely a stakeholder. But, even there, we must make reasonable efforts to resolve the facts prior to trial.

3. In a group of consolidated cases, or one involving joinder of parties under T.C. Rule 61, an unqualified admission by respondent will be binding upon respondent with respect to all of the consolidated or joined parties even though the admission was sought by only one of the petitioners. However, it would not be binding upon a non-requesting party, and such other party would be free to show error in the admission.


**35.4.3.5.5** **(07-26-2012)**

#### Review of Petitioner’s Responses

1. If petitioner’s answer or objection to a request for admission seems insufficient, the attorney may move for the court to determine its sufficiency. T.C. Rule 90(e). See Exhibit 35.11.1–86, Motion to Review the Sufficiency of the Petitioner’s Objections to Respondent’s Requests for Admissions. Unless the court then determines that an objection is justified, it may order that an answer be filed. If the court determines that an answer does not comply with the admission rules, it may order either that the matter is admitted, or order that an amended answer be filed. The court, in the alternative, may withhold disposition of the motion until a later time which may be more appropriate for disposing of the question involved.

2. If petitioner unjustifiably fails to admit to the genuineness of any document or truth of any matter as requested in accordance with Rule 90, then, pursuant to Rule 90(g), a motion may be filed with the court for an order imposing such sanction on the petitioner or petitioner’s counsel as the court may find appropriate in the circumstances. ( _See_ T.C. Rule 104(c) and (d) for a list of specific sanctions). _See_ CCDM 35.4.3.6. Direct sanctions under Rule 90(g) in the absence of a preliminary motion to test the sufficiency of responses are rare and are reserved for unusual situations presenting a willful and deliberate failure to comply with the requirements of the court’s rules. Any such motion is required to be reviewed in the Associate Chief Counsel (P&A), Branches 36 or 7, prior to filing.

3. Under T.C. Rule 90(c), any request for admission that is not answered in a timely manner is deemed admitted. When petitioner fails to answer, it is often good practice to send a letter to petitioner or petitioner’s counsel stating that because no response was received within the 30 days allowed by the Rule, the facts are deemed admitted and respondent intends to use them as admissions at or before the trial. The letter can later be exhibited to the court, if necessary, either in support of a motion for sanctions or as a defense to an attempt to withdraw or modify the admissions. If it appears that the failure to respond may have been unintentional and due to good cause, petitioner may request that the Field attorney not object to a motion by petitioner to withdraw or modify the deemed admissions. Absent any prejudice to respondent, the Field attorney should ordinarily state no objection to such a motion.


**35.4.3.5.6** **(08-11-2004)**

#### Withdrawal and Modification of Admissions

1. Withdrawal or modification of matters admitted may be obtained only upon court order under T.C. Rule 90(f). Although the rule does not contain a time frame or a "due diligence" requirement, any necessary withdrawal or modification of an admission should be made at the earliest possible time.

2. Under the rule, the party opposing withdrawal or modification of an admission must show the court how the proposed withdrawal or modification will prejudice that party’s own case on the merits. For example, if respondent opposes a motion for withdrawal or modification filed by petitioner, a stronger opposing argument can be made in those instances where the admission has caused respondent to lose touch with potential witnesses or release them from subpoenas, or in those instances where respondent has considered and rejected taking affirmative action such as amending pleadings on the basis of the responses to a request for admissions. If respondent’s ability to try the case will be severely hampered, but the court, nevertheless, permits a withdrawal or modification by petitioner, a motion for continuance should be considered by the respondent if additional time for trial preparation is required.


**35.4.3.5.7** **(08-11-2004)**

#### Supplementation of Response

1. A party or counsel responding to a request for admission is obliged to amend the response in accordance with T.C. Rule 102(2) if it should be discovered that the original response was incorrect or has become incorrect by later arising facts. This duty to file a supplementary response exists irrespective of any order of the court or agreement of the parties and arises whether or not the other party files a motion seeking supplementation or correction. A specific request for a supplementation of a prior response may be filed by either party when it is believed that the opposing party has not reasonably amended the prior response. Requests for supplementation may be enforced through a motion to the court for an order requiring supplementation.

2. There is some tension between the binding effect of an admission and the requirement that a party supplement a response under T.C. Rule 102 when the incorrectness of the original response becomes known. The court, in adopting these two rules, did not intend the supplementation procedure to be used to completely revoke a prior admission or denial, but intended supplementation to be used to provide an expanded statement or modification of a portion of an established set of facts. A party or counsel wishing to be relieved of an entire admission should proceed by way of a motion under T.C. Rule 90(f).


**35.4.3.6** **(07-26-2012)**

### Enforcement Actions and Sanctions

1. In addition to specific enforcement actions and sanctions that are included as a part of specific rules, T.C. Rule 104 provides more detailed or additional sanctions directed at any failure to comply with the rules governing discovery and admissions. T.C. Rule 104(d) makes it clear that an evasive or incomplete answer or response is to be treated as a failure to answer or respond. In order to properly and successfully invoke the provisions of T.C. Rule 104, the rules in regard to instituting the deposition, interrogatory, or other process should have been precisely followed in the first instance, including informal attempts to obtain the information, as discussed in CCDM 35.4.3.2. In order to assist attorneys in ensuring that the discovery rules and procedures have been properly complied with, a discovery checklist has been developed. See Exhibit 35.11.1–81, Discovery Checklist (Interrogatories, Production of Documents, Admissions Depositions, Motions to Compel).


**35.4.3.6.1** **(07-26-2012)**

#### Procedures

1. Prior to moving for an order compelling compliance with an interrogatory, request for production of documents, etc., the Field attorney should make one final attempt to contact the petitioner or petitioner’s representative to determine the reason, if any, why there was no compliance. This communication is designed to determine if there is any reason to justify either not filing a motion compelling compliance, or to delay its filing, and is required to comply with the applicable provisions of Civil Justice Reform Executive Order.

2. Field reviewers have responsibility for review and clearance of motions to compel discovery that arise as a result of a petitioner’s complete failure to respond to informal and formal discovery. Other motions to compel may require review by the Associate office that has jurisdiction over the underlying substantive issue in the case. See Exhibit 35.11.1–1, Issues Requiring Associate Office Review. Situations where a petitioner is considered to have provided no response to discovery include not only situations where the taxpayer fails to respond to informal or formal discovery, but also situations where the responses make frivolous arguments concerning the legality of the Internal Revenue Code, the authority of the Service to enforce the Code or collect information, or similar arguments that have been repeatedly reviewed and rejected by the courts.

3. Motions to compel should be filed judiciously and only when the respondent can demonstrate that the information requested is needed for the government’s case or to rebut the petitioner’s case. Further, motions to compel should be filed only where the underlying discovery request satisfies the court-imposed obligation to consult and communicate, including the obligation to give petitioner enough time to respond to _Branerton_ requests.


**35.4.3.6.2** **(07-26-2012)**

#### Drafting the Motion

1. If relief under T.C. Rule 104 is appropriate, the Field attorney should file a motion with the court specifically alleging the actions taken in attempting informal discovery, pointing out the specific failures, and asking for an appropriate order under T.C. Rule 104 compelling full compliance. (See Exhibits 35.11.1–86 through 35.11.1–89). In an instance of an incomplete or evasive response, the motion should specifically detail the questions which were not answered or the request that received an inadequate response, indicate why the question or request is relevant, and specify with particularity how the answer or response was inadequate.

2. The court should be asked, in the same motion, to order also that certain specified sanctions shall apply in the event of a failure to comply with the order on compliance. The sanctions sought normally should be directed to the pleadings, issues, and matters in dispute, including dismissal of the case if appropriate, rather than for contempt. The sanction requested should be tailored to fit the particular situation. If the court does not include a provision for a show cause hearing or a self-executing sanction upon failure to comply with an enforcement order, a separate motion for sanctions will be necessary if petitioner fails to comply. See Exhibit 35.11.1–90, Motion to Impose Sanctions.

3. A motion to impose sanctions may seek the full amount of the deficiency and the fraud or fraud delinquency penalty where the petitioner has failed to respond to orders of the court requiring compliance to respondent’s discovery requests. It may also seek judgment for an increased deficiency or other matters upon which respondent bears the burden of proof. A petitioner’s unwarranted and unjustified conduct in flouting the discovery orders of the court can be considered to constitute a default under Rule 104(c)(3), authorizing the court to enter judgment against the disobedient party.


**35.4.3.6.3** **(07-26-2012)**

#### Contempt of Court

1. Although other sanctions are provided by the rules in regard to petitioners and petitioners’ counsel, the only sanction that can be applied to third parties under T.C. Rules 74(b) and 81(c) is that of contempt of court under T.C. Rules 104(a) and 104(c).

2. No request to hold the petitioner or counsel in contempt of court should be made without prior approval of the Sanctions Officer. While pursuant to applicable Civil Justice Reform procedures, attorneys are encouraged to seek sanctions against opposing parties for abusive practices, attorneys should normally first attempt to resolve with opposing counsel disputes that might warrant the filing of a sanctions motion. Motions or other correspondence involving ethical and contempt issues, including potential conflicts of interest issues, are not eligible for direct filing and should be submitted to the Sanctions Officer, through the Associate Chief Counsel (P&A), Branches 1 or 2, for review. The matter will be coordinated with the Associate Chief Counsel (GLS) if necessary, and the proposed correspondence or motion will be forwarded for final approval by the Associate Chief Counsel (P&A), who services as the Sanctions Officer.

3. When the court sanctions a party under T.C. Rule 104(c) by ordering the party to pay a sum to the Internal Revenue Service, the Field attorney should advise the court and the party ordered to make payment that a check, made payable to the U.S. Treasury, should be forwarded to the Field attorney. Upon receipt, the Field attorney will forward the check to the attorney’s Office Manager/Administrative Operations Specialist/Support Team Leader, with a memorandum briefly stating the nature of the payment for future transmittal to the appropriate fiscal office. Such payments will be treated as miscellaneous receipts and will be deposited into the general fund of the Treasury.


**35.4.3.7** **(07-26-2012)**

### Subpoenas

1. Most of the procedures for issuance, service, and use of subpoenas are found at CCDM 35.4.4.4, Subpoenas.

2. Where it is desired to ensure that the petitioner is available to testify (as in fraud cases or to satisfy the burden of production with respect to penalty issues), respondent will need to issue a subpoena to a petitioner. In those cases in which a subpoena is issued, respondent does not pay petitioner’s expenses.

3. The time for the issuance of necessary subpoenas will vary from case to case depending to a large extent upon the finalization of stipulations. Often, the issuance of a subpoena may expedite agreement on a stipulation.

4. It is preferable to introduce in evidence original documents, even though such documents are in the custody of or under the control of the petitioner. If not stipulated, it is necessary to subpoena such documents from the petitioner.


**35.4.3.8** **(07-26-2012)**

### Discovery in Collection Due Process Cases

1. Unless the taxpayer is raising only frivolous or groundless arguments, informal discovery should be conducted at a _Branerton_ conference. The taxpayer should be provided with a copy of the complete administrative record. In addition, request for admissions and all formal discovery procedures are available in a Collection Due Process case. If the taxpayer is only disputing determinations that are reviewed for abuse of discretion, the need for formal discovery (interrogatories or requests for admission) should generally be limited to cases in which there is a factual dispute over the contents of the administrative record (e.g., taxpayer asserts he submitted financial documentation that was not considered by Appeals) or the conduct of the administrative hearing (e.g., taxpayer disputes statement in notice of determination that he did not request a face-to-face conference, or did not request collection alternatives). See CCDM 35.3.23.8.3, Abuse of Discretion Issues, regarding the record rule.

2. For determinations subject to trial de novo, such as liability determination or section 6015(b) or (c) relief, the full range of formal discovery tools may be used.

3. All requests by the taxpayers to depose appeals officers or their managers should be opposed. Appeals officers and their managers are nonparty witnesses. Therefore, T.C. Rule 75(b) applies to their depositions. The rule states that depositions of nonparty witnesses without the consent of the parties are permitted only in extraordinary circumstances when the information sought is not available through other, less extraordinary means. Additionally, anything the taxpayer wishes to know about Appeals' determinations can be found in the administrative record. In addition, inquiry into the mental processes of the agency decision maker is not permissible, except for the limited purpose of determining if the decision was a result of bad faith. _Citizens to Preserve Overton Park v. Volpe_, 401 U.S. 402, 420 (1971). The taxpayer, however, must make a "strong showing of bad faith or improper behavior" before any such inquiry will be permitted. _Id_.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-004-003#addtoany "Show all")

A2A