---
url: "https://www.irs.gov/irm/part30/irm_30-009-001"
title: "30.9.1 Case File Management | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part30/irm_30-009-001#main-content)

- 30.9.1 [Case File Management](https://www.irs.gov/irm/part30/irm_30-009-001#idm140203666135504)
  - 30.9.1.1 [General Principles](https://www.irs.gov/irm/part30/irm_30-009-001#idm140203665987008)
  - 30.9.1.2 [Case History Sheets](https://www.irs.gov/irm/part30/irm_30-009-001#idm140203704369856)
  - 30.9.1.3 [Opening of Cases](https://www.irs.gov/irm/part30/irm_30-009-001#idm140203657681008)
  - 30.9.1.4 [Other Files](https://www.irs.gov/irm/part30/irm_30-009-001#idm140203675653248)

    - 30.9.1.4.1 [Administrative Files](https://www.irs.gov/irm/part30/irm_30-009-001#idm140203667852256)
    - 30.9.1.4.2 [Miscellaneous Law File](https://www.irs.gov/irm/part30/irm_30-009-001#idm140203662554256)
    - 30.9.1.4.3 [Special Litigation Project Files Dummy Files](https://www.irs.gov/irm/part30/irm_30-009-001#idm140203679428064)
    - 30.9.1.4.4 [Assistance Files](https://www.irs.gov/irm/part30/irm_30-009-001#idm140203704365136)

  - 30.9.1.5 [Closing the Legal File](https://www.irs.gov/irm/part30/irm_30-009-001#idm140203704361648)
  - 30.9.1.6 [File Retention and Exceptions (Freezes)](https://www.irs.gov/irm/part30/irm_30-009-001#idm140203667921584)
  - 30.9.1.7 [File Storage and Retrieval](https://www.irs.gov/irm/part30/irm_30-009-001#idm140203662595472)
  - 30.9.1.8 [File Destruction](https://www.irs.gov/irm/part30/irm_30-009-001#idm140203678457072)
  - 30.9.1.9 [Transfer of Permanent Records to NARA](https://www.irs.gov/irm/part30/irm_30-009-001#idm140203681788336)
  - 30.9.1.10 [File Removal by Terminated Employees](https://www.irs.gov/irm/part30/irm_30-009-001#idm140203661698560)

# Part 30. Administrative

# Chapter 9. File Management

# Section 1. Case File Management

* * *

## 30.9.1 Case File Management

**30.9.1.1** **(07-21-2005)**

### General Principles

1. Creating and maintaining legal files in cases assigned to a Counsel office improves the office's ability to ensure appropriate case management. The files also provide valuable background information when further developments occur in a case or with respect to an issue, such as the docketing of litigation in a case in which legal advice was previously issued.

2. The legal file should contain all key documents in the development of the work item, starting with the document that generated the assignment and continuing through the issuance of the final document closing the case. It should contain a copy of the opening and closing assignments on TECHMIS and TLCATS (if applicable) together with any assignment documents prepared by management. If the case was of any duration, it should contain a case history sheet documenting the development of the case.

3. The legal file need not contain every piece of paper created while a case was open. Intelligence and good judgment should be used in deciding whether a given piece of paper or document is a rightful part of the official file. Except where required by applicable record control schedules, rarely should multiple copies of the same piece of paper or document be placed in the legal file. The contents of legal files may be subject to disclosure to the public under disclosure statutes (e.g., Freedom of Information Act (FOIA) and section 6110), and may be subject to discovery or other compulsory legal process.


**30.9.1.2** **(07-21-2005)**

### Case History Sheets

1. Form 9718, Case History, Exhibit 30.9.1-1, provides a means for summarizing case development and listing research citations. It is used to provide a complete history of all significant actions in connection with the development of a case; avoid duplication of effort; determine research performed; and identify file memoranda.

2. Form 9718 is made a part of the case file on each request for a ruling. It may also be used in any other case assignment, or assistance assignment, if the supervisor deems it appropriate, particularly if the assignment may require substantial research or when a chronological record of case development is desirable. Doubtful cases should be resolved in favor of using the form.

3. Only an original of the form is prepared.

4. Each initiator, supervisor, and reviewer handling the case lists in chronological order the pertinent substantive and procedural actions taken. Items to be listed include special instructions (such as deadlines, target dates, and research sources), telephone and other contacts, coordination within or outside Chief Counsel, reports of significant matters within Chief Counsel, conferences, position meetings, file memoranda and review action. Entries should be clear, concise, and legible.

5. The form is fastened to the inside left of the folder if a case is jacketed. The form is clipped to non-jacketed work assignments.


**30.9.1.3** **(07-21-2005)**

### Opening of Cases

1. In general, Associate office case files are opened via one of three mechanisms:



1. Published guidance case files are opened and the TECHMIS assignments are made by the responsible Associate office.

2. Case files and assignments based on requests for legal advice, reviewed advice memoranda, coordinated issue papers (CIPs), Appeals settlement guidelines (ASGs), audit technique guides (ATGs), workplans for Notice cases, Tax Court briefs and documents submitted for Associate office review, all refund defense letters and refund settlement letters, and suit letters sent for review or set up as Associate office assignments are opened by the Technical Services Support Branch, CC:PA:LPD:TSS (TSS4510). TSS4510 is also responsible for the creation of appellate assignments and tracking for the national office. TSS4510 makes a primary assignment to an Associate office depending on the dominant issue in the assignment. When the assignment is made, a legal file is created. Associate offices are responsible for further assignment to branches and attorneys.



      ### Note:



      Different procedures exist for the handling of General Legal Services and Criminal Tax matters and are set forth in CCDM 30.9.2.8 and CCDM 30.9.2.7 below.

3. Technical Advice Memorandum and User Fee requests (PLRs, CAMs, CAPs) are routed through the Docket, Records and User Fee Branch CC:PA:LPD:DRU), which assigns User Fee cases to Associate offices and creates legal files. The DRU forwards TAMs for assignment to TSS4510. FOIA Requests are opened in the Disclosure and Litigation Support Branch (CC:PA:LPD:DLS)


2. Field office cases are opened and legal files created according to local procedures except for the following:



1. Tax Court cases are opened and legal files are created by the Docket, Records and User Fee Branch. The Branch forwards the legal file to the appropriate Field office.

2. Court of Federal Claims cases are opened and legal files are created by the Disclosure and Litigation Support Branch. The Branch forwards the files to the appropriate Field office.


**30.9.1.4** **(07-21-2005)**

### Other Files

1. In addition to legal files, there may be several other types of files associated with a case. The following subsections describe those files.


**30.9.1.4.1** **(07-21-2005)**

#### Administrative Files

1. The administrative file is the Commissioner's official file in the case or matter, and is not the file of the Office of Chief Counsel. Therefore, except as necessary to the handling of the case, no papers should be removed from or placed in this file by Counsel offices. In the preparation and trial of cases, it is generally necessary to remove from the administrative file original tax returns for reproduction or introduction into evidence.

2. The original returns and other documents must be replaced in the administrative file at the earliest practicable date, and no later than when the case is closed. In any case in which documents are removed from the administrative file for use in the Tax Court case, or for any other purpose, a list thereof should be made and placed in such file until the documents are returned, whereupon the list would be destroyed.


**30.9.1.4.2** **(07-21-2005)**

#### Miscellaneous Law File

1. If the legal file becomes bulky or there are documents associated with the case that are not part of the legal file, a miscellaneous law file may be made for the case. There may also be placed in the miscellaneous law file, at the discretion of the supervisor, the "filed" or "served" copy of documents, but not the "initialed " copy. In this instance, however, the initialed copy of such documents that are placed in the legal file must have written on the first page thereof the date filed or lodged with the court. Extra copies of all pleadings or other documents that will be needed on appeal from the Tax Court's decision should be placed in the miscellaneous law file, as well as extra copies of correspondence, memoranda, etc., that may actually be needed at a future date. As to the retention of extra copies of documents, the supervisor should bear in mind the duplicating equipment available and the feasibility of duplication of documents, should extra copies be needed at a later date. If deemed necessary or desirable, draft copies (properly identified and dated) may be retained in the miscellaneous law file and not in the legal file. All documents placed in either the legal or miscellaneous law file must be conformed copies. The miscellaneous law file will be kept with and serve as a supplement to the legal file. It should be orderly and, to the extent practicable, the papers should be in chronological order and fastened together.

2. Duplicated copies of respondent's exhibits or of petitioner's exhibits that are withdrawn from the court and are to be retained by the respondent are placed in the miscellaneous law file upon closing the case. If there is no miscellaneous law file, the retained exhibits, upon closing the case, may be placed in the legal file.

3. Other miscellaneous legal files may be created and associated with legal files regarding advice or guidance matters. These files should generally contain documents that are useful during the development of the work item but which are not appropriate for inclusion in the official legal file. An example would be copies of opinions considered in developing written advice. Such miscellaneous files will not retained as part of the official file.


**30.9.1.4.3** **(07-21-2005)**

#### Special Litigation Project Files — Dummy Files

1. Dummy files may exist in certain special litigation project cases. These projects were typically opened for tax shelter cases during the 1970s and 1980s. Some projects remain active at this date.

2. If the case involves more than one project issue or a combination of a single project issue and non-project issues, the field attorney assigned to the case will take the following steps with regard to each project issue after the case is deemed at issue.



1. Create a dummy record on CATS and a dummy file if the case is considered a "dirty" case involving more than one project issue or a combination of project and nonproject issues. Dummy records allow tracking of different issues or petitioners that are in different statuses. Dummy legal files should contain copies of all pleadings, the statutory notice, the return(s), RAR, supporting statement, and all materials related to the project issue. The file should be marked DUMMY FILE in bold letters on the outside of the file.

2. Forward the dummy legal file to the project attorney. The dummy legal file should have the address of the Field office, the operating division and the name and phone number of the Field attorney on the inside cover of the legal file.

3. If the case is sent to Appeals for settlement consideration, it should go through the local Appeals office with a legend on the transmittal reading as follows:


> THE FOLLOWING SHELTER ISSUE (name issue) IN THIS CASE IS PART OF A SHELTER PROJECT BEING CONTROLLED BY THE (name of) OFFICE. THE PROJECT ATTORNEY IS (name) WHO MAY BE REACHED AT (number) AND THE PROJECT APPEALS OFFICER IS (name) WHO MAY BE REACHED AT (number).

**30.9.1.4.4** **(07-21-2005)**

#### Assistance Files

1. A complete legal file necessarily includes documents relating to assistance with the case provided by all other offices. Thus, whenever an office requests assistance on a case assignment from another office, documentation of case developments by the office providing assistance must be incorporated into the legal file. To accomplish this purpose, any Counsel employees assigned to provide case assistance to another office should document case development in a temporary "assistance" file. Upon completion of the requested assistance, the assistance file should be forwarded to the office that requested the assistance for inclusion in the legal file as described below.

2. Whenever TSS4510 receives a request for assistance from one Associate office to another Associate office, TSS4510, or the receiving office, should set up an assistance file using a letter size, (brown) file folder. The folder should be set up in a manner similar to a legal file, i.e., the request and other documentation attached inside the folder on the right side, and the control sheet and case history sheet attached on the left. Attach a label to the upper left corner on the outside of the folder with the name of the case, the TL-CATS or TECHMIS control number (including WLI number), the type of assistance assignment and the assigned branch. Whenever a request for assistance is sent to another office, the transmittal memorandum should state:



> We request that a copy of documentation of significant activities during case development be returned to this office, along with the reply, for inclusion in the legal file.

3. An assistance file should be maintained in accordance with the file maintenance directions for a legal file.

4. The responding Associate office should forward the assistance file (with documentation, history sheet, and control sheet (showing closing) properly completed and attached to the requesting office). Forward the file with the response if possible, or promptly following the response when the need for a rapid response makes forwarding the assistance file at the same time impractical.

5. The assigned attorney in the requesting office may retain the assistance file with the legal file while the case is still open, but should integrate the contents of the assistance file into the legal file (removing any duplicate documents) before the legal file is closed. The assistance file jacket may then be relabeled and reused.


**30.9.1.5** **(07-21-2005)**

### Closing the Legal File

1. Assemble the Case File - The employee assigned to the case, or a member of the support staff, must ensure that all significant documentation relating to the case is fastened, in reverse chronological order of receipt (oldest at the bottom), to the inner right side of the file using a two hole fastener. For an example of typical case documentation see the discussion above. Merge any assistance case files into the legal file. Discard all duplicate copies of documents and readily available legal authorities (court opinions, revenue ruling, statutes, regulations, etc.) from the legal file and miscellaneous law file. The miscellaneous law file should be screened for any items that should be included in the legal file. Remaining material in the miscellaneous law file may be discarded or kept by the assigned attorney for later reference.

2. Control Sheet - Place a copy of the TL-CATS/TECHMIS Control Sheet for the case reflecting the closed status code (e.g., 900, 960, 980, 999) on top of the file documents. If a case is closed with a 900 status, an explanatory comment should be placed in the "status narrative line" on the TECHMIS Control Sheet. Support staff in each office have responsibility for creating the TECHMIS Control Sheet when the case is ready for closing.

3. Case Processing Form - A copy of a completed Case Processing Form will be placed on top of the TECHMIS Control Sheet. This form will be completed, signed, and dated by the employee assigned to the case.

4. Managerial Review - Submit the legal file to the reviewer when the legal file is ready for closing. The reviewer should verify that the file assembly procedures have been followed. In particular, the reviewer should review the completed TECHMIS Control Sheet and the Case Processing Form for accuracy and completeness. It is essential that the reviewer check the file classification code entered on the closing form to assure that the proper record retention schedule will be used for the file. Also, the reviewer should verify compliance with any public inspection requirements. The reviewer should sign and date the Case Processing Form if the legal file is ready for closing.

5. Transfer Legal File for closing and storage (Associate offices) - Transfer closed legal files to the Legal Processing Division for all cases.

6. Field offices follow local procedures regarding the storage location of closed files.

7. Each office must ensure that all legal files are closed in a timely fashion after the completion of the assignment. Legal files should not remain open more than two weeks after the assignment has been completed, absent unusual circumstances.


**30.9.1.6** **(07-21-2005)**

### File Retention and Exceptions (Freezes)

1. Files will be retained in accordance with the Chief Counsel Records Retention Schedules (see IRM 1.15.13 through IRM 1.15.15), which contain information on when to retire records and when to destroy or send files to the National Archives and Records Administration.

2. Records that are not covered in the Chief Counsel Records Retention Schedules will be retained in accordance with the National Archives and Records Administration General Records Schedules. See IRM 1.15.38 through IRM 1.15.61.

3. Regulations implementing the Federal Records Act and Federal Records Disposal Act provide for the suspension of records disposal under records disposition schedules when continued availability of the records is required to conduct Government operations because of special circumstances that alter their normal administrative, legal, or fiscal value. These circumstances include retaining the records for purposes of audit, court order, investigation, litigation, study, or any other administrative purpose that justifies the temporary extension of the retention period.

4. Office of Chief Counsel employees who are under an obligation to preserve documents required for a litigation, FOIA or privacy matter should notify the Service Records Officer in writing of the need to suspend disposal of records for purposes of the litigation, notwithstanding the fact that disposal may otherwise be authorized under approved records disposition schedules. The notice should be provided as soon as the need to preserve the records becomes known. Some common circumstances in which the notice should be provided are where there is a need to preserve the records; for the Government's affirmative case; to respond to opposing counsel's discovery; to respond to (or comply with) a subpoena, a "freeze" or "preservation " order from a Court or administrative forum of competent jurisdiction; or simply to preserve evidence potentially relevant to either party or a court in ongoing or imminent litigation. Documents that have not yet been sent to the Federal records center, should not be destroyed or forwarded until the litigation, FOIA or privacy matter has been concluded.

5. In the notice to the Records Officer the attorney should identify:



   - The name and nature of the litigation (including party names)

   - The records or types of records to be preserved (including record series where known)

   - The offices thought to possess the records

   - An estimate of how long the need to preserve might be in place

   - The name, office, and contact information for the person making the request to preserve

   - Other Service or Counsel offices or individuals who are centrally involved in the case


6. The notice should be provided to:



> IRS Records Officer
>
> 1111 Constitution Avenue, NW
>
> Washington, D.C. 20224
>
> Mail Stop A:RE:SC/CP-6 (10th Floor)

7. The notice is necessary to allow for the Records Management Office to advise the National Archives and Records Administration of the need to depart from otherwise mandatory disposal instructions contained in records disposition schedules. The Records Management Office will instruct potentially implicated Federal Records Centers to suspend disposal of temporary records in germane items under records disposition schedules. Moreover, the Records Management Office is often best positioned to alert potentially implicated offices of the need to preserve the records identified. Contact the Service Records Officer for further contact information or with any questions regarding the depth of information required. Legal questions concerning application of the Records Acts should be directed to the Associate Chief Counsel (General Legal Services).

8. Files that are subject to a freeze must be retained until the freeze is lifted. Closed legal case files, currently subject to a freeze, are retained at the Martinsburg Computing Center under the control of the Service records management staff.


**30.9.1.7** **(07-21-2005)**

### File Storage and Retrieval

1. Division Counsel and Associate offices are responsible for the following:



   - Maintaining active files (for information on files management, see IRM 1.15.7 Files Management)

   - Maintaining closed files prior to sending to the Federal Records Center, which includes the initial filing of closed files, retrieval of files for reference purposes and refiling

   - Establishing a system of accountability (charge-out) for files withdrawn from either the Division/Associate Chief Counsel files, or the Federal Records Center

   - Sending closed files to the Martinsburg Computing Center (closed legal case files) or Federal Records Center in accordance with the Office of Chief Counsel Records Control Schedules (see IRM 1.15.13 through IRM 1.15.15)

   - Disposing of records (see IRM 1.15.3) or transferring them to the National Archives and Records Administration (see IRM 1.15.4) in accordance with the Chief Counsel Records Control Schedules (see IRM 1.15.13 through IRM1.15.15)

   - Obtaining closed files from the Martinsburg Computing Center (closed legal case files) or Federal Records Center for reference purposes


2. For more information on storing closed files at Federal Records Centers, or retrieving them, see IRM 1.15.4, Retiring and Requesting Records.

3. Certain records require special handling to assure that confidentiality is maintained. For rules concerning storage of tax-related or classified records at Federal Records Centers or storage of criminal grand jury records, see IRM 1.15.4, Retiring and Requesting Records.


**30.9.1.8** **(07-21-2005)**

### File Destruction

1. For rules concerning file destruction see IRM 1.15.3 Disposing of Records.


**30.9.1.9** **(07-21-2005)**

### Transfer of Permanent Records to NARA

1. For rules concerning transfer of permanent records to the National Archives and Records Administration, see IRM 1.15.5 Relocating/Removing Records.


**30.9.1.10** **(07-21-2005)**

### File Removal by Terminated Employees

1. For rules concerning file removal by terminated employees, see IRM 1.15.5, Relocating/Removing Records.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part30/irm_30-009-001#addtoany "Show all")

A2A