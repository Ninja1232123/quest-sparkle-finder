---
url: "https://www.irs.gov/irm/part36/irm_36-002-005"
title: "36.2.5 Appeals of Tax Court Cases | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part36/irm_36-002-005#main-content)

- 36.2.5  [Appeals of Tax Court Cases](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946632875584)
  - 36.2.5.1  [Overview of Appeals of Tax Court Cases](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946632992016)
  - 36.2.5.2  [Tax Court Opinions and Decisions](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946632728192)
  - 36.2.5.3  [Finality of Tax Court Decisions and Mandamus](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946605975440)
    - 36.2.5.3.1  [Motion Not Timely After Appeal Filed or Decision Becomes Final](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946604548944)
    - 36.2.5.3.2  [Jurisdictional Questions](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946604546896)
    - 36.2.5.3.3  [Mandamus](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946605932784)
  - 36.2.5.4  [Interlocutory Appeals from Tax Court Orders](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946605930064)
    - 36.2.5.4.1  [Applicable Rules of Procedure](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946605927040)
    - 36.2.5.4.2  [Grounds for Interlocutory Appeal](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946605923584)
    - 36.2.5.4.3  [Interlocutory Appeal Procedure in General](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946633011888)
    - 36.2.5.4.4  [Interlocutory Commissioner Appeals](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946633006784)
    - 36.2.5.4.5  [Interlocutory Taxpayer Appeals](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946605995456)
    - 36.2.5.4.6  [Tax Court Certification Sua Sponte](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946605984512)
    - 36.2.5.4.7  [Stay of Tax Court Proceedings](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946605979632)
  - 36.2.5.5  [Entry of Appearance](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946606035120)
  - 36.2.5.6  [Notices of Appeal](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946606032496)
    - 36.2.5.6.1  [Multiple Docket Numbers](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946606028704)
    - 36.2.5.6.2  [Taxpayer Notices of Appeal](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946606024112)
    - 36.2.5.6.3  [Commissioner Notices of Appeal](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946606021872)
    - 36.2.5.6.4  [Time for Filing Notice of Appeal](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946606019456)
      - 36.2.5.6.4.1  [Cross-Appeals](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946606017520)
      - 36.2.5.6.4.2  [Protective Appeals](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946606015728)
      - 36.2.5.6.4.3  [Timely Mailing as Timely Filing](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946606013824)
      - 36.2.5.6.4.4  [Effect of Motion to Vacate or Revise Decision](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946606009456)
      - 36.2.5.6.4.5  [Effect of Motion for Litigation Costs](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946603046304)
      - 36.2.5.6.4.6  [Thirty-Day Period Before Decision Becomes Final Following Mandate or Remand](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946603043344)
      - 36.2.5.6.4.7  [Multiple Years](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946632991088)
  - 36.2.5.7  [Bankruptcy after Entry of Tax Court Decision or During Pendency of Appeal](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946632977216)
  - 36.2.5.8  [Venue on Appeal](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946632974912)
    - 36.2.5.8.1  [Stipulating to Venue](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946632959504)
    - 36.2.5.8.2  [Appeals to Improper Venue](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946632954592)
    - 36.2.5.8.3  [Transferee Cases](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946606085520)
  - 36.2.5.9  [Record on Appeal](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946606082960)
    - 36.2.5.9.1  [Docketing and Filing the Record on Appeal](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946606076704)
    - 36.2.5.9.2  [Printing the Record on Appeal](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946606071680)
    - 36.2.5.9.3  [Notice to Tax Court Not To Prepare Record on Appeal](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946606069792)
    - 36.2.5.9.4  [Trial Transcript](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946606065616)
    - 36.2.5.9.5  [Exhibits](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946606063408)
  - 36.2.5.10  [Refunds and Credits While Appeal is Pending](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946606059728)
  - 36.2.5.11  [Dismissal of Appeals in Tax Court Cases](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946606053072)
    - 36.2.5.11.1  [Dismissal in the Tax Court](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946606051376)
    - 36.2.5.11.2  [Dismissal in the Court of Appeals](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946606048592)
    - 36.2.5.11.3  [Dismissal of Taxpayer Appeals](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946606045296)
  - 36.2.5.12  [Cases Remanded to the Tax Court/Recomputations](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946606042464)
    - 36.2.5.12.1  [Actions Following Remand](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946606041248)
    - 36.2.5.12.2  [Transfer of Case to Area Counsel](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946601175360)
    - 36.2.5.12.3  [Settled Cases](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946601153488)
    - 36.2.5.12.4  [Effect of Transfer to Area Counsel](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946601151296)
    - 36.2.5.12.5  [Associate Chief Counsel Attorney Responsibilities](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946601146928)
      - 36.2.5.12.5.1  [Monitor Case Status](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946601142912)
      - 36.2.5.12.5.2  [Closing the Case to Area Counsel](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946601137280)
    - 36.2.5.12.6  [Computation on Remand](https://www.irs.gov/irm/part36/irm_36-002-005#idm139946601130672)

# Part 36. Appellate Litigation and Actions on Decision

# Chapter 2. Appeal/Certiorari Recommendations

# Section 5. Appeals of Tax Court Cases

* * *

## 36.2.5 Appeals of Tax Court Cases

#### Manual Transmittal

August 12, 2020

#### Purpose

(1) This transmits revised CCDM 36.2.5, Appeals of Tax Court Cases.

#### Background

CCDM 36.2.5 is being revised to address changes in law and procedures for appeals of Tax Court orders awarding attorney’s fees, orders disposing of fewer than all taxable years at issue, certain orders in small tax cases, and interlocutory appeals.

#### Material Changes

(1) CCDM 36.2.5.2 is revised for clarity and to reflect a change in the law (I.R.C. § 7430(f)) governing appeals of Tax Court orders awarding attorney’s fees.

(2) CCDM 36.2.5.3 is revised to reflect a change in the Tax Court Rules (specifically, T.C. Rule 171(d)) addressing removal of the small tax case designation.

(3) CCDM 36.2.5.4.5 is revised to require that a proposed notice of no objection to a taxpayer’s interlocutory appeal explain why the requirements for permitting such an appeal are met.

(4) CCDM 36.2.5.6.4.7 is revised to address changes in case law regarding the appropriate time to appeal Tax Court orders that dispose of one or more, but not all, years in a suit under one docket number.

(5) Minor editorial changes and clarifications have been made throughout the remainder of the section.

#### Effect on Other Documents

This section supersedes CCDM 36.2.5, dated February 8, 2017.

#### Audience

Chief Counsel

#### Effective Date

(08-12-2020)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**36.2.5.1** **(08-12-2020)**

### Overview of Appeals of Tax Court Cases

1. The provisions that follow are generally applicable to all appeals of Tax Court cases. Attorneys/paralegals should consult the more specific provisions of



   - CCDM 36.2.6.2.1 for taxpayer appeals

   - CCDM 36.2.6.2.2 for Commissioner appeals

   - CCDM 36.2.6.2.3 for protective appeals and cross-appeals

   - _CCDM 36.2.5.4_ for interlocutory appeals in Tax Court


2. Upon receipt of notification from the Associate Chief Counsel (Procedure and Administration (P&A)) that the taxpayer has filed a notice of appeal from the Tax Court's decision, the following action shall be taken:



1. If an appeal bond has been filed, the legal and miscellaneous law files shall be immediately forwarded by the Area Counsel attorney to the Department of Justice for handling in the court of appeals. No assessment should be made until the decision is final. _See_ _CCDM 36.2.5.3_, Finality of Tax Court Decisions and Mandamus, and CCDM 36.2.6.2.4, Assessment of Tax in Appealed Cases.

2. If an appeal bond was not filed, the legal and miscellaneous law files shall be immediately forwarded by the Area Counsel attorney to the Department of Justice for handling in the court of appeals. The administrative file should be immediately forwarded to Appeals for transmission to the appropriate Area Director's office for assessment of the deficiency in accord with instructions contained in the notification from the Associate Chief Counsel (P&A).

3. Prior to forwarding the files to the Department of Justice or to Appeals, the files will be prepared for closing by the Area Counsel office. _See_ CCDM 36.2.6.2.5, Closing Procedures Specific to Tax Court Appeals.

4. Upon the filing of a notice of appeal by either the taxpayer or the Commissioner, the Area Counsel office will be notified of the appeal in cases where the Area Counsel office recommended appeal. Upon receipt of such notification, the Area Counsel office will immediately forward to the Associate Chief Counsel (P&A) additional parts of the files, if any, remaining in the Area Counsel office, and will notify Appeals of the appeal. Area Counsel should retain the administrative file during the pendency of the appeal if not needed by Appeals.

5. When the administrative file is forwarded to Appeals for transmittal to the appropriate Area Director's office for the assessment of any deficiency, include the following under "Remarks" on Form 1734, Transmittal Memorandum, closing the administrative file to Appeals:



      > "The taxpayer has filed a notice of appeal from the Tax Court's decision in the above case. The administrative file is forwarded for transmittal to the Area Director for assessment of the deficiency (or deficiencies) with the request that the Area Director forward the administrative file to the Associate Area Counsel immediately after the assessment has been made. Attached are two copies of the notification of the appeal from the Associate Chief Counsel (P&A) dated. It is further requested that one copy of this notification be forwarded to the Area Director and that you forward to the Associate Chief Counsel (P&A) a copy of your closing memorandum to the Area Director so that the Associate Chief Counsel may be advised when the administrative file is forwarded to the Area Director. "

6. If an appeal from the Tax Court decision to a court of appeals is not taken within 90 days after the entry of the decision, the Area Counsel office closes the case and forwards the administrative file to the Chief, Appeals. Appeals will assess any redetermined deficiency, or credit any overpayment determined in the decision.


**36.2.5.2** **(08-12-2020)**

### Tax Court Opinions and Decisions

1. It is important to distinguish between Tax Court opinions and Tax Court decisions, as the terms are not interchangeable. Opinions are usually issued in advance of the decision or order disposing of the case, and parties may only take an appeal from that decision or order disposing of the case. _See_ T.C. Rule 190 and CCDM 35.9.1, Tax Court Opinions and Decisions.

2. An appeal should be sought only from orders that dispose of the entire matter, from decisions that specify the amount of a deficiency or lack thereof, or from orders that dismiss for lack of jurisdiction. But also see sections 6863(b)(3)(C) and 7481(c)(3) and (d) for other Tax Court orders that are reviewable "in the same manner as a decision of the Tax Court" ; and section 7482(a)(2); _CCDM 36.2.5.4_, Interlocutory Appeals from Tax Court Orders; and _CCDM 36.2.5.6.4.7_, Multiple Years, for other situations in which an appeal may be appropriate.

3. Section 7482(a)(1) confers upon the courts of appeals exclusive jurisdiction to review decisions of the Tax Court. _See also_ Fed. R. App. P. 13(a) and _CCDM 36.2.5.6.4_, Time for Filing Notice of Appeal.

4. There are exceptions to the rule that an amount of tax be in dispute for appellate review. For example, parties may also appeal awards of attorney’s fees ( _see_ section 7430(f)), orders compelling payment of witness fees, redeterminations of certain interest in transferee liability cases, certain prepetition orders ( _see_ T.C. Rule 82), and declaratory judgments.


**36.2.5.3** **(08-12-2020)**

### Finality of Tax Court Decisions and Mandamus

1. Section 7481 governs the finality of a Tax Court decision.

2. The decision of the Tax Court will become final 90 days from the date the decision is entered unless either party files a timely notice of appeal. The appeal period may be extended by a motion to vacate or revise the decision or by a motion for litigation costs. _See_ _CCDM 36.2.5.6.4_, Time for Filing Notice of Appeal.

3. **Finality of Tax Court decision when case is appealed** — Under section 7481:




| _If_ | _Then_ |
| --- | --- |
| the court of appeals affirms the Tax Court's decision or dismisses the appeal, and a petition for writ of certiorari is _not_ filed by either party within the 90-day period for filing the petition, | the Tax Court decision will become final upon the expiration of the certiorari period (90 days from the date the judgment of the court of appeals is entered). _See Note 1_. |
| the court of appeals affirms the Tax Court's decision or dismisses the appeal, and either party petitions for a writ of certiorari and the petition is denied, | the Tax Court decision becomes final upon the denial of the petition. _See Note 2_. |
| the petition for certiorari is granted and the Supreme Court affirms the Tax Court's decision (which has been affirmed by the court of appeals), | the Tax Court decision will become final 30 days from the date of the issuance of the mandate of the Supreme Court. |
| the petition for certiorari is granted and the Supreme Court modifies or reverses the Tax Court's decision (which has been affirmed by the court of appeals), | the Tax Court will be required to enter a new decision in accordance with the mandate of the Supreme Court. This new decision will become final upon the expiration of 30 days from the date it is entered, unless within such 30 days either party institutes proceedings to have the decision corrected to accord with the mandate. In the latter event, the decision will become final when it is corrected. |
| the court of appeals modifies or reverses the Tax Court's decision, | the Tax Court will be required to enter a new decision in accordance with the mandate of the court of appeals (unless the Supreme Court subsequently reverses the court of appeals). _See Note 3_. |
| the court of appeals modifies or reverses the Tax Court's decision, the certiorari period has expired and neither party has petitioned for a writ of certiorari, or if certiorari has been denied, | the Tax Court will then enter a new decision in accordance with the mandate of the court of appeals. This new decision will become final upon the expiration of 30 days from the date it is entered, unless within such 30 days either party institutes proceedings to have the decision corrected to accord with the mandate. In the latter event, the decision will become final when it is corrected. _See Note 4_. |
| the Supreme Court grants certiorari and affirms the Tax Court's decision (which was reversed or modified by the court of appeals), | the decision, as already entered, will become final 30 days after the issuance of the Supreme Court's mandate. |
| the Supreme Court affirms the court of appeals (which modified or reversed the Tax Court's decision) or itself modifies or reverses the Tax Court decision, | the Tax Court will be required to enter a new decision in accordance with the mandate of the court of appeals or in accordance with the mandate of Supreme Court, respectively. This new decision will become final upon the expiration of 30 days from the date it is entered, unless either party institutes proceedings to have the decision corrected to accord with the mandate. In the latter event, the decision will become final when it is corrected. |
| the court of appeals or the Supreme Court remands a case to the Tax Court for a rehearing, | the decision entered as a result of the rehearing will become final in the regular manner as if there had been no prior proceedings; i.e., after the expiration of the 90-day appeal period. _See Note 5_. |





> _Note 1._ A new 90-day period for petitioning certiorari begins upon the denial of a timely filed petition for rehearing in the court of appeals.





> _Note 2._ Under Supreme Court Rule 44, a taxpayer has 25 days in which to petition for a rehearing of an order denying a petition for writ of certiorari. Supreme Court Rule 44 provides that in the absence of a specific order by the Court or a stipulation by the parties, the mandate of the Supreme Court is not issued until after the expiration of 25 days from the date judgment is entered. Thus, when the court of appeals has affirmed a decision of the Tax Court and the Supreme Court has denied a petition for certiorari, the Tax Court's decision does not become final until 25 days after the date of such denial. _See R. Simpson & Co. v. Commissioner_, 321 U.S. 225 (1944).





> _Note 3._ Once the judgment of the court of appeals has been entered, either party has 90 days in which to file a petition for a writ of certiorari. For this reason, the entry of the new decision by the Tax Court should be delayed until the certiorari period has expired, or certiorari has been denied, or the Supreme Court has granted certiorari and issued its mandate.





> _Note 4._ The 30-day appeal period applies in the situation described here. _See_ _CCDM 36.2.5.6.4.6_, Thirty-Day Period Before Decision Becomes Final Following Mandate or Remand. _See also_ _CCDM 36.2.5.12_, Cases Remanded to the Tax Court/Recomputations.





> _Note 5._ The term "rehearing" encompasses any Tax Court proceeding beyond the mere entry of a new decision. Note, however, that if the case has been remanded for rehearing by the court of appeals, no trial or further proceedings should be instituted until after the certiorari period has expired. _See generally_ _CCDM 36.2.5.12_, Cases Remanded to the Tax Court/Recomputations.

4. _See_ CCDM 35.9.1.3.1, Finality of Tax Court Decision, regarding the Tax Court's jurisdiction after its decision becomes final.

5. **Tax Court Decisions in S Cases**. The Tax Court’s decision in a small tax case (S case) is nonreviewable and becomes final 90 days from the date the decision is entered. The Tax Court may remove the S case designation, on its own motion or on the motion of any party in the case, at any time before the commencement of trial. _See_ T.C. Rule 171(d) and CCDM 35.1.3.2, Small Tax Case Procedures. This raises a question as to whether an order of dismissal in an S case for lack of jurisdiction or any other reason entered prior to trial may be appealed if the Tax Court removes the S case designation. Motions to remove the S case designation for the purpose of pursuing an appeal must be coordinated with P&A and the Department of Justice.


**36.2.5.3.1** **(08-11-2004)**

#### Motion Not Timely After Appeal Filed or Decision Becomes Final

1. As a general rule, no motion pertaining to an opinion or decision of the Tax Court should be filed with that court after the decision has become final under the provisions of section 7481, or after a notice of appeal to a court of appeals has been filed by either party. Upon filing of a notice of appeal by either party, the Tax Court gives up its claim to jurisdiction of the case even though the appeal period has not expired.


**36.2.5.3.2** **(08-11-2004)**

#### Jurisdictional Questions

1. As a general rule, once the Tax Court's decision has become final, it may not take further action absent fraud on the court. _Lasky v. Commissioner_, 352 U.S. 1027 (1957). A party may raise a jurisdictional issue after a decision in the case has become final under section 7481. _See Brannon's of Shawnee, Inc. v. Commissioner_, 69 T.C. 999 (1978), and 71 T.C. 108 (1978).


**36.2.5.3.3** **(08-11-2004)**

#### Mandamus

1. Rule 21 of the Federal Rules of Appellate Procedure describes the procedures for obtaining extraordinary writs. (See the All Writs Act, 28 U.S.C. § 1651(a)). Pursuant to Fed. R. App. P. 14, Rule 21 applies to the review of a Tax Court decision. _See also_ CCDM 36.2.1.2.1, Federal Rules of Appellate Procedure.


**36.2.5.4** **(08-11-2004)**

### Interlocutory Appeals from Tax Court Orders

1. Generally, an interlocutory order is a ruling or an order of the court during the pendency of the litigation not otherwise appealable until after entry of decision.

2. Section 7482(a)(2) authorizes appeals from certain interlocutory orders of the Tax Court if application is made within 10 days after entry of the certified order. The court of appeals has discretion whether or not to grant the appeal.

3. Neither the application for nor the granting of an appeal stays proceedings in the Tax Court unless a stay is ordered by a judge of the Tax Court or the court of appeals.


**36.2.5.4.1** **(08-11-2004)**

#### Applicable Rules of Procedure

1. At present, there are no rules of appellate procedure specifically governing interlocutory appeals under section 7482(a)(2). T.C. Rule 193, Appeals From Interlocutory Orders, refers generally to Fed. R. App. P. 5. Accordingly, it is anticipated that the substantive and procedural requirements under 28 U.S.C. § 1292(b) (which governs interlocutory appeals from federal district courts and is identical in material respects to section 7482(a)(2)), and Rule 5 will, for the most part, carry over and be applied to Tax Court interlocutory appeals under Section 7482(a)(2). _See Kovens v. Commissioner_, 91 T.C. 74, 77 (1988).


**36.2.5.4.2** **(08-11-2004)**

#### Grounds for Interlocutory Appeal

1. To be appealable under section 7482(a)(2), the order must include a statement or certification that



1. A controlling question of law is present,

2. Substantial grounds for difference of opinion are present, and

3. An immediate appeal from the order may materially advance the ultimate termination of the litigation.


2. Failure to meet any one of the requirements in paragraph (1) is grounds for denial of certification. _See Gen. Signal Corp. v. Commissioner_, 104 T.C. 248 (1995), _aff'd_, 142 F.3d 546 (2d Cir. 1998); _Kovens v. Commissioner_, supra.


**36.2.5.4.3** **(08-11-2004)**

#### Interlocutory Appeal Procedure in General

1. The procedure for an interlocutory appeal can only be initiated after the Tax Court makes a ruling or issues an order. Unless the Tax Court issues the prescribed statement sua sponte ( _see_ _CCDM 36.2.5.4.6_, Tax Court Certification Sua Sponte) the party wishing to appeal must seek to have the Tax Court amend the order to include the prescribed statement of certification (or issue the ruling with the certification) by filing a motion for certification of question for appeal.

2. The appeal is assigned according to subject matter jurisdiction to the appropriate Associate Chief Counsel. Transmittals should indicate any prior or recommended coordination with the appropriate Associate Chief Counsel.

3. Some taxpayers may file an interlocutory notice of appeal from any ruling or order of the court that is neither a final decision nor a dismissal of the case for lack of jurisdiction. If an interlocutory notice of appeal is filed for purposes of delay, it may be appropriate to file a motion for an order directing the Clerk to retain the original record to enable the court to try the case and thereby preclude further delay. The attorney and his/her supervisor must consult with the Associate Chief Counsel (P&A) before taking any action on an interlocutory appeal.


**36.2.5.4.4** **(08-12-2020)**

#### Interlocutory Commissioner Appeals

1. In rare circumstances, and only when it is clearly in the Commissioner's interest to do so, will the Commissioner seek an interlocutory appeal. Authorization for a Commissioner interlocutory appeal must be obtained from the Solicitor General before the Commissioner can file a motion for certification of question for appeal in the Tax Court.

2. Since such appeals are rare, the attorney wishing to appeal from an interlocutory ruling or order must coordinate the appeal with Division Counsel, the Associate Chief Counsel with subject-matter jurisdiction over the issue involved, and the Associate Chief Counsel (P&A). The attorney should forward the recommendation to all three officials for review. The recommendation must contain:



   - A statement of facts

   - A statement of the controlling question of law

   - A statement of the reasons why a substantial basis exists for a difference of opinion on the question

   - A statement of the reasons why an immediate appeal may materially advance the termination of the litigation


3. The assigned Associate Chief Counsel attorney in the office with jurisdiction over the subject matter will review the recommendation and, if concurred in, prepare an appeal letter to the Department of Justice, Tax Division, Appellate Section. The appeal letter must be reviewed and approved by the Associate Chief Counsel with jurisdiction over the subject matter, and the Associate Chief Counsel (P&A), who reviews the letter for procedural concerns.

4. Upon receipt of the Solicitor General's authorization, the Associate Chief Counsel attorney in the office with jurisdiction over the subject matter will prepare for filing with the Tax Court the motion for certification of question for appeal. The motion must be reviewed by the Associate Chief Counsel (P&A) and Division Counsel before it is filed with the court. A copy of the motion will be forwarded to the DOJ Appellate Section.

5. The motion for certification of question for appeal should contain the same items required to be included in the recommendation, see above, _and_ a prayer that the Tax Court amend the subject ruling or order to include the certification of question for appeal. _See_ Exhibit 36.4.1–4, Motion for Certification of Question for Appeal.

6. If the taxpayer objects to the motion, the attorney will, after coordinating with the Associate Chief Counsel attorney in the office with jurisdiction over the subject matter and seeking appropriate leave from the court, file a response to the objection and argue the motion if it is calendared for hearing. The response must be reviewed and approved by the Associate Chief Counsel (P&A) before it is filed with the court.

7. After the Tax Court issues its order containing the prescribed statement, the Associate Chief Counsel attorney will notify the Appellate Section, which will prepare and file with the appropriate appellate court the petition for permission to appeal in compliance with Fed. R. App. P 5(b). The content of the petition will be drawn from the appeal letter, the Solicitor General's authorization, and the motion for certification of question for appeal.

8. The petition for permission to appeal must be filed with the clerk of the appropriate court of appeals within 10 days after entry of the Tax Court's certified interlocutory order. Timely filing has been held to be jurisdictional with respect to 28 U.S.C. § 1292(b) interlocutory appeals.

9. If the court of appeals allows the appeal, it will be treated as a Commissioner appeal from a decision of the Tax Court in accordance with existing CCDM procedures. _See_ CCDM 36.2.6.2.2, Commissioner Appeals — Adverse Opinion Review.


**36.2.5.4.5** **(08-12-2020)**

#### Interlocutory Taxpayer Appeals

1. If the taxpayer files a motion with the Tax Court for certification of a question for appeal under section 7482(a)(2), the court normally should issue a notice setting a time for response or objection.

2. Upon receipt of such a motion, the attorney will contact and send a copy of the motion to the Associate Chief Counsel (P&A). The Technical Services Support Branch will ensure that the motion is assigned to the proper Associate Chief Counsel.

3. As soon as possible after receipt of such a motion, the attorney will forward a proposed response or notice of objection for review and filing in the Tax Court, along with a copy of the motion and any other relevant materials. The response should address whether there is substantial ground for difference of opinion, and whether an immediate appeal from the order will materially advance the ultimate termination of the litigation. The attorney in the Associate office with subject matter jurisdiction must coordinate with the Associate Chief Counsel (P&A) and Division Counsel prior to forwarding any response or notice of objection to the Tax Court.

4. Our office will normally object to the taxpayer's motion on the ground that it fails to meet the criteria for interlocutory appeal. If the field office believes taxpayer's motion is not objectionable, a proposed notice of no objection should be forwarded to the Technical Services Support Branch. Because of the extraordinary nature of a certified interlocutory appeal, the field office’s proposed notice of no objection must be accompanied by a memorandum explaining why the requirements for an interlocutory appeal have been satisfied. The Technical Services Support Branch will assign the notice and memorandum to the Associate Chief Counsel office with jurisdiction over the subject matter for review and coordination. After coordination with the Associate Chief Counsel (P&A), the assigned Associate Chief Counsel attorney must also inform the Department of Justice that there is no objection to the taxpayer's motion. Our office may not acquiesce in the taxpayer’s motion unless the Department of Justice consents. Because that process requires the concurrence of the Solicitor General in the same manner as a Commissioner appeal, it may be necessary to request the Tax Court to grant an extension of time within which to file a response to the taxpayer’s motion.

5. If taxpayer's motion for certification of question for appeal is granted by the Tax Court, the taxpayer may, within 10 days of issuance of the Tax Court's order containing the prescribed statement, file a petition with the appropriate court of appeals for permission to appeal.

6. Rule 5 of the Federal Rules of Appellate Procedure provides that within seven days after service of the petition for permission to appeal, an adverse party may file an answer in opposition. The Department of Justice will prepare and file the answer. The answer in opposition advises the court of appeals whether it should permit an appeal to be taken from the certified order. Grounds for opposing the petition for permission to appeal are limited to:



   - The petition was not timely filed

   - Venue is improper

   - No controlling question of law is involved

   - There is no substantial ground for difference of opinion with respect to the question of law

   - An immediate appeal from the order will not materially advance the ultimate termination of the litigation


7. If the court of appeals allows the appeal, it will be defended under the procedures for a taxpayer appeal from a decision of the Tax Court. _See_ CCDM 36.2.6.2.1, Taxpayer Appeals.


**36.2.5.4.6** **(08-11-2004)**

#### Tax Court Certification Sua Sponte

1. The Tax Court may, on its own motion, enter an order containing a section 7482(a)(2)(A) statement. If taxpayer files a petition in the court of appeals for permission to appeal from such an order, the procedures of _CCDM 36.2.5.4.5_, Interlocutory Taxpayer Appeals, will apply.

2. If the respondent wishes to appeal from such an order, authorization must be secured from the Solicitor General for the Department of Justice to file a petition for permission to appeal with the court of appeals. _See_ _CCDM 36.2.5.4.4_, Interlocutory Commissioner Appeals. Since the petition must be filed within 10 days, the attorney must immediately notify the Associate Chief Counsel (P&A) upon service of such an order, so that coordination with the Department of Justice may be commenced and timely Solicitor General authorization for appeal be sought.


**36.2.5.4.7** **(08-11-2004)**

#### Stay of Tax Court Proceedings

1. Neither the application for nor the granting of an interlocutory appeal stays proceedings in the Tax Court unless the Tax Court or appeals court judge orders the stay. The attorney may apply to the Tax Court for a stay pending the interlocutory appeal without review by the Associate Chief Counsel (P&A). Informal coordination should be made with the responsible Associate office.

2. The attorney recommending that a stay order be sought from the appropriate court of appeals should advise the Associate Chief Counsel (P&A) of the reasons for the stay, for coordination with the Department of Justice in the preparation and filing of the motion for stay.


**36.2.5.5** **(08-11-2004)**

### Entry of Appearance

1. The Entry of Appearance form is normally filed by the Department of Justice. It is the responsibility of the Associate Chief Counsel attorney/paralegal to confirm with the Department of Justice that this form has been filed with the court.


**36.2.5.6** **(08-11-2004)**

### Notices of Appeal

1. Notices of appeal shall be filed with the Clerk of the Tax Court. Section 7483; Fed. R. App. P. 13(a). The courts of appeal have exclusive jurisdiction to review decisions of the Tax Court in the same manner and to the same extent as decisions of the district courts in civil actions tried without a jury. Section 7482(a).

2. Notices of appeal shall specify the party or parties taking the appeal; shall designate the decision appealed from; and shall name the court to which the appeal is taken. Fed. R. App. P. 3(c). While not required by Rule 3(c), a statement concerning venue should be included. _See_ Exhibit 36.4.1–5, Notices of Appeal — Tax Court, for a sample Commissioner notice of appeal.

3. The Clerk of the Tax Court serves a conformed copy of the Commissioner's notice of appeal on the taxpayer's first attorney of record, if the taxpayer is represented by more than one attorney. If the taxpayer was not represented by counsel in the Tax Court, service is made on the taxpayer. Service on behalf of the Government is accepted by the Docket, Records & User Fee Branch of the Associate Chief Counsel (P&A) and then forwarded to the Technical Services Support Branch in the Office of the Associate Chief Counsel (P&A).


**36.2.5.6.1** **(08-11-2004)**

#### Multiple Docket Numbers

1. If the appeal pertains to more than one docket number, a separate notice of appeal is generally filed with respect to each docket. In instances in which two or more dockets were consolidated for trial and opinion in the Tax Court, the appeal will pertain to the specific docket numbers in which the issues to be litigated on appeal are involved. See subsection (2), below, for consolidated appeals. The attorney should check for any necessary protective action with respect to docket numbers not directly involved in the appeal. _See_ CCDM 36.2.6.2.3, Protective Appeals and Cross-Appeals in Tax Court Cases.

2. If the appeal pertains to more than one docket number and these docket numbers were consolidated for trial and opinion in the Tax Court, a single notice of appeal pertaining to more than one docket number may be filed. (This procedure does not apply to the extent the appeal is not taken to the same circuit in all dockets or if, because of venue, an appeal is filed to the circuit in which venue lies and the circuit of preferred venue.) If the decisions for the docket numbers on appeal were not entered on the same day, note of this fact should be made in the notice of appeal. The single caption should list the taxpayers' name as shown in the decisions, and the docket numbers that are being appealed.

3. The filing of a single notice of appeal pertaining to more than one docket number does not constitute a joint or consolidated appeal under Fed. R. App. P. 3(b). The single notice merely informs the Clerk of the Tax Court and the appellate court that the cases are related and may be processed together.


**36.2.5.6.2** **(08-11-2004)**

#### Taxpayer Notices of Appeal

1. _See_ CCDM 36.2.6.2.1, Taxpayer Appeals, for particular provisions relating to taxpayer notices of appeal.


**36.2.5.6.3** **(08-11-2004)**

#### Commissioner Notices of Appeal

1. _See_ CCDM 36.2.6.2.2, Commissioner Appeals — Adverse Opinion Review, for particular provisions relating to Commissioner notices of appeal.


**36.2.5.6.4** **(08-11-2004)**

#### Time for Filing Notice of Appeal

1. Under Section 7483 and Fed. R. App. P. 13(a), a decision of the Tax Court may be reviewed by a court of appeals if a notice of appeal is filed with the Tax Court by either the Commissioner or the taxpayer within 90 days after the decision is entered. The exceptions and qualifications to the general rule are discussed below.


**36.2.5.6.4.1** **(08-11-2004)**

##### Cross-Appeals

1. Cross-appeals are discussed at CCDM 36.2.6.2.3, Protective Appeals and Cross-Appeals in Tax Court Cases. A cross-appeal may be filed within 120 days after the Tax Court decision has been entered.


**36.2.5.6.4.2** **(08-11-2004)**

##### Protective Appeals

1. Protective appeals are discussed at CCDM 36.2.6.2.3, Protective Appeals and Cross-Appeals in Tax Court Cases. It is Service position that both the protective appeal and the appeal of the adverse party in the other docket must be filed within the 90-day period after entry of the respective Tax Court decisions.


**36.2.5.6.4.3** **(08-11-2004)**

##### Timely Mailing as Timely Filing

1. Section 7502, which treats certain documents as timely filed (even though not received within the period prescribed by the Code) if they are timely mailed, applies to notices of appeal filed with the Tax Court. _See_ Treas. Reg. § 301.7502–1 for specific rules applicable thereto.

2. If the notice of appeal is timely mailed but improperly addressed and received by the Tax Court after expiration of the appeal period, it is not timely filed. _See_ section 7502(a)(2)(B).

3. Rule 4(a)(1) of the Federal Rules of Appellate Procedure does not apply to the Tax Court.


**36.2.5.6.4.4** **(05-02-2012)**

##### Effect of Motion to Vacate or Revise Decision

1. A timely filed motion to vacate or revise a Tax Court decision extends the 90-day appeal period.

2. Effect of motion to vacate or revise on the appeal period:




| _If_ | _Then_ |
| --- | --- |
| If the motion is denied, | a new 90-day appeal period begins to run from the date of denial of the motion. |
| If the motion is granted, | a new 90-day appeal period begins to run upon entry of the new or revised decision by the court. _See_ Fed. R. App. P. 13(a). |

3. A motion to vacate or revise a decision, with or without a new or further trial, is timely filed if it is filed within 30 days after the decision has been entered, unless the court otherwise permits. _See_ T.C. Rule 162.

4. Time period for filing motion to vacate or revise:




| _If_ | _Then_ |
| --- | --- |
| the motion to vacate or revise a decision is outside the 30-day period, | it is stamped _lodged_, rather than _filed_ by the court. A motion for leave to file out of time the motion to vacate or revise the decision should accompany the motion to revise or vacate the decision. |
| the motion for leave to file out of time is granted, | the motion to vacate or revise the decision will be _filed_. |
| the court denies a motion for leave to file out of time a motion to vacate or revise a decision, | the appeal period is not extended. |

5. Until a motion to vacate or revise a decision is filed with the court, either within the 30-day period after the entry of decision or upon the granting of a motion for leave to file out of time (which motion, itself, must be filed within the 90-day appeal period), the normal 90-day statutory period for filing an appeal is not extended.

6. The filing or denial of a motion to reconsider the denial of a motion to vacate or revise a decision will not suspend or start a new appeal period. Only the granting of the motion and entry of a new holding will have that effect.



### Note:



Some courts have held that these motions, filed toward the end of the normal appeal period, with the primary purpose of extending the time for filing an appeal, do not extend the appeal period even though granted by the lower court. _See Commissioner v. Realty Operators, Inc.,_ 118 F.2d 286 (5th Cir. 1941).


**36.2.5.6.4.5** **(05-02-2012)**

##### Effect of Motion for Litigation Costs

1. A timely motion filed by taxpayer asking for reasonable litigation and administrative costs (including attorneys' fees) after a Tax Court decision has been entered will usually extend the time for an appeal because the court will generally vacate the original decision in order to dispose of the motion and enter a new decision reflecting such disposition. _See_ T.C. Rules 231 and 232. See also CCDM 35.10.1, Awards of Litigation and Administration Costs and Fees. This is in contrast to Fed. R. Civ. P. 58(c)(1), which provides that the entry of judgment may not be delayed, nor the time for appeal extended, in order to tax costs or award fees, except as provided in Rule 58(c)(2).


**36.2.5.6.4.6** **(05-02-2012)**

##### Thirty-Day Period Before Decision Becomes Final Following Mandate or Remand

1. For purposes of determining the time when the decision becomes final after an appeal or review by the Supreme Court, there is a distinction between cases remanded for rehearing and cases remanded other than for rehearing, i.e., upon mandate of a court of appeals or the Supreme Court.

2. When a case is remanded for rehearing, this generally means that the Tax Court is required under the mandate of the court of appeals or the Supreme Court to hold a further trial in the case or to make further significant findings of fact without trial. _See_ _CCDM 36.2.5.12_, Cases Remanded to the Tax Court/Recomputations, for provisions regarding cases remanded to the Tax Court.

3. Application of 30-day period:




| _If_ | _Then_ |
| --- | --- |
| the final appellate action in the case modifies the Tax Court decision such that a new decision must be entered by the Tax Court without the need for any additional action in or by that court (i.e., the case is not remanded for rehearing), | the new Tax Court decision will become final upon the expiration of 30 days from the date entered. |
| either party institutes proceedings within the 30-day period to have the new Tax Court decision corrected to accord with the mandate, | the new decision will become final when it is corrected. _See_ section 7481(a)(3)(A) and (B). |
| a new decision is entered by the Tax Court after the case has been remanded _for rehearing_, | the new decision will become final in the regular manner, i.e., at the expiration of the 90-day appeal period, as if there had been no prior proceedings. _See_ section 7481. |


**36.2.5.6.4.7** **(08-12-2020)**

##### Multiple Years

1. The courts of appeals do not agree on the appropriate time to appeal Tax Court orders that dispose of one or more, but not all, years in a suit under one docket number. Because of the unsettled state of the law, when such an issue arises, the attorney should coordinate with P&A Branches 6 and 7 to determine how to preserve the Service’s right of appeal.

2. The United States Court of Appeals for the District of Columbia Circuit has held that a Tax Court order that disposes of one or more, but not all, years is appealable even though the Tax Court has not entered a decision with respect to claims for another year or years in that suit and even in the absence of an express determination by the Tax Court that there is no just reason for delay. _See Inverworld, Ltd. v. Commissioner_, 979 F.2d 868 (D.C. Cir. 1992). In a case appealable to this court, an immediate notice of appeal should be filed to preserve the Service’s right of appeal. _See_ CCDM 36.2.6.2.2.1.2, Preparation and Filing of Notice of Appeal, for further information regarding the circumstances and procedures for filing a notice of appeal.

3. The United States Courts of Appeals for the Third, Fifth, Seventh, and Ninth Circuits have held that an appeal of a Tax Court order that disposes of one or more, but not all, years is appealable only if the Tax Court expressly determines that there is no just reason for delaying such an appeal. _See N.Y. Football Giants, Inc. v. Commissioner_, 349 F.3d 102 (3rd Cir. 2003); _Nixon v. Commissioner_, 167 F.3d 920 (5th Cir. 1999); _Shepherd v. Commissioner_, 147 F.3d 633 (7th Cir. 1998); _Brookes v. Commissioner_, 163 F.3d 1124 (9th Cir. 1998); _see also Newstat v. Commissioner_, T.C. Memo. 2005-262. In a case appealable to one of these courts, if the Office of Chief Counsel recommends appeal, then the attorney should request that the Tax Court expressly determine that there is no just reason for delay of an appeal of that order. _See_ Fed. R. Civ. P. 54(b); T.C. Rule 1(b).

4. The United States Courts of Appeals for the Second, Fourth, and Sixth Circuits have held that an appeal of a Tax Court order that disposes of one or more, but not all, years is premature prior to the Tax Court’s disposal of the entire case. _See Estate of Yaeger v. Commissioner_, 801 F.2d 96 (2d Cir. 1986); _Christian v. Commissioner_, 8 F.3d 417 (4th Cir. 1993) (unpublished table decision); _Schrader v. Commissioner_, 916 F.2d 361 (6th Cir. 1990). In a case appealable to one of these courts or a court of appeals that has not ruled on this issue (currently, the United States Courts of Appeals for the First, Eighth, Tenth, and Eleventh Circuits), the attorney should coordinate with P&A Branches 6 and 7 to determine how to preserve the Service’s right of appeal.


**36.2.5.7** **(08-11-2004)**

### Bankruptcy after Entry of Tax Court Decision or During Pendency of Appeal

1. _See_ CCDM 34.3.1.1.2, Counsel’s Role in Bankruptcy Cases.


**36.2.5.8** **(02-08-2017)**

### Venue on Appeal

1. In the case of a taxpayer seeking redetermination of a tax liability, other than a corporation, a Tax Court decision may be reviewed by the court of appeals for the circuit of the taxpayer's legal residence, as of the date the petition for redetermination was filed with the Tax Court.

2. If the taxpayer is an estate, venue lies in the court of appeals for the circuit of the legal residence of the executor, executrix, or representative of the estate, as of the date the petition was filed with the Tax Court.

3. In the case of a TEFRA partnership or S corporation, venue lies in the court of appeals for the circuit where the principal place of business of the TEFRA entity was located at the time the petition was filed.

4. Corporate taxpayers.



1. In the case of a corporation seeking redetermination of a tax liability, the Tax Court decision may be reviewed by the court of appeals for the circuit in which is located the corporation's principal place of business or principal office or agency as of the date the petition was filed with the Tax Court.

2. If the corporation has no principal place of business or principal office or agency in the United States, the decision may be reviewed by the court of appeals for the circuit in which is located the Internal Revenue Office in which the tax return was filed.

3. If no return was filed, venue is then with the United States Court of Appeals for the District of Columbia Circuit (D.C. Circuit).


5. **Venue for Collection Due Process, Innocent Spouse, and Declaratory Decision Cases**.



1. For CDP petitions the case is appealable to the circuit of the petitioner’s legal residence (if the petitioner is an individual) or the petitioner’s principal place of business, office, or agency (if the petitioner is not an individual). _See_ section 7482(b)(1)(G).

2. For stand-alone innocent spouse petitions the case is appealable to the circuit of petitioner’s legal residence. _See_ section 7482(b)(1)(F).

3. Consult Branch 3 or 4 of Procedure and Administration if venue issues arise in CDP and innocent spouse cases where the petitions were filed before the effective date of sections (F) and (G), December 18, 2015.

4. _See_ section 7482(b)(1)(C) and (D) for venue concerning appeals under sections 7476 and 7428.


6. If for any reason none of the preceding rules apply, then the decision may be reviewed by the D.C. Circuit. See section 7482(b). Cases appealable to the D.C. Circuit under section 7482(b) include whistleblower cases under section 7623(b)(4) and disclosure cases under sections 6110(d)(3), (f)(3), (f)(4), or (h)(4).

7. Notwithstanding the general rules stated above, a decision of the Tax Court may be reviewed by any court of appeals designated by the Government and the taxpayer in a written stipulation, if a notice of appeal designating that circuit has been filed. See section 7482(b)(2).

8. If for any reason the taxpayer's legal residence is not established by the record before the Tax Court, this office generally states that it has no objection to review by the court of appeals for the circuit in which taxpayer's asserted residence is located if facts support that assertion. Thus, it is very important when writing or reviewing a brief to be filed in the Tax Court to ensure that the parties have stipulated venue and that an appropriate finding of fact has been requested.

9. _See_ CCDM 36.2.6.2.1, Taxpayer Appeals, for provisions particular to taxpayer appeals, and CCDM 36.2.6.2.2, Commissioner Appeals — Adverse Opinion Review, for provisions particular to Commissioner appeals.


**36.2.5.8.1** **(08-11-2004)**

#### Stipulating to Venue

1. If a taxpayer requests that the Government stipulate to a change in venue, the Department of Justice usually requests the views of the Chief Counsel. If there are sound reasons for entering into such a stipulation and there is no decision adverse to the Commissioner on the issue in the circuit where the taxpayer seeks to stipulate venue, and no decision favorable to the Commissioner in the court of proper venue, this office will generally state that there is no objection to the stipulation. _See_ Exhibit 36.4.1–6, Stipulation of Venue.

2. Some Tax Court cases involve multiple taxpayers whose appeals would be to different judicial circuits. To avoid the expense and inconvenience to both parties of presenting the same issue in different courts of appeal, the parties will ordinarily agree to stipulate venue in one circuit, unless one of the parties seeks a potential appellate conflict and a possible petition for certiorari with respect to the issue in question.

3. When the taxpayer sends a proposed stipulation of venue to the Office of Chief Counsel, the Chief Counsel will forward it to the Department of Justice with his recommendation. Although the Chief Counsel's office has authority to enter into stipulations of venue, it has, as a matter of practice, deferred to the Department of Justice, which will execute the venue documents on behalf of the Government. If, due to the late receipt of a request directly from the taxpayer for stipulation of venue, there is insufficient time to formally clear the matter with Justice, the attorney should advise the taxpayer's attorney to file an appeal both to the circuit of proper venue and to the circuit of preferred venue. After an examination of the law in both circuits, the attorney then makes a venue recommendation to the Department of Justice.


**36.2.5.8.2** **(08-11-2004)**

#### Appeals to Improper Venue

1. When a taxpayer appeals to an improper venue, the Service generally will recommend that the Department of Justice not object to transfer of the case to the appropriate venue when it is in the interest of justice to do so. _See Becker v. Commissioner_, 852 F.2d 524 (11th Cir. 1988)(It is in the interest of justice to transfer appeal to appropriate circuit when time for filing a new appeal has expired); _Dornbusch v. Commissioner_, 860 F.2d 611 (5th Cir. 1988)(transfer was appropriate remedy when pro se appellant in good faith filed an appeal to wrong circuit); _Alexander v. Commissioner_, 825 F.2d 499 (D.C. Cir. 1987)(appeal transferred to correct circuit when time for filing a new appeal had expired). If the taxpayer is making frivolous arguments contrary to well-established law, however, an objection should be raised in an effort to have the appeal dismissed. _See Dahlberg v. Commissioner_ (unpublished, per curiam order filed July 6, 1988, D.C. Cir.).


**36.2.5.8.3** **(08-11-2004)**

#### Transferee Cases

1. In a transferee case there may be some question as to which court of appeals is the court of proper venue. Normally, in transferee cases involving individuals who are the transferees or corporations that are the transferees, the rules for determining venue are those set out in paragraph (1) of _CCDM 36.2.5.8.1_, Stipulating to Venue. In cases where the Commissioner is the appellant, the attorney should file separate protective notices of appeal of the Tax Court's decision to the courts of appeal for the circuits applicable to each taxpayer involved.


**36.2.5.9** **(08-11-2004)**

### Record on Appeal

1. Pursuant to Fed. R. App. P. 10(a), the record on appeal is comprised of the original papers and exhibits filed in the Tax Court, the transcript of proceedings, if any, and a certified copy of the docket entries prepared by the Clerk of the Tax Court, unless only specific papers or exhibits are desired to be designated as the record on appeal. In general, lodged documents and memoranda and briefs are not part of the official record. These documents may, however, be transmitted to the court of appeals (see paragraph (3), below).

2. The Tax Court will transmit this complete record in all cases except those in which the record is extremely bulky or in other prohibitive circumstances. In those instances, the court will contact the parties for designations. Then, the assigned attorney in coordination with the Department of Justice will designate or counter designate those parts of the record on appeal deemed necessary to the Commissioner's case. This designation will be filed with the Tax Court and include the following salutation: To the Clerk of the United States Tax Court.

3. In some instances it is necessary or desirable to itemize each document included in the record on appeal. This type of designation is particularly applicable in instances in which there are necessary documents that were lodged but not filed and, therefore, are not a part of the official record that will be transmitted.

4. Rule 10(d) of the Federal Rules of Appellate Procedure provides that in lieu of the original papers and transcript provided for in Rule 10(a), the parties may prepare and sign an agreed statement showing how the issues presented by the appeal arose and were decided in the Tax Court and setting forth only so many of the facts averred and proved or sought to be proved as are essential to the issues presented. While the purpose of this optional procedure is to reduce costs that would otherwise be incurred in printing the appendix, it can be accomplished as well by filing a motion under Rule 30(f) to permit the case to be heard on the original papers, with such copies of the relevant parts of the record as the court may require. Also under Rule 30(b) the parties may decide to print less than the entire record.

5. If a taxpayer requests as part of the record on appeal documents and papers that are not a part of the official record of the case, the attorney should consider filing with the Tax Court a motion to exclude from the record on appeal such irrelevant documents and papers, if inclusion of the extraneous materials would be prejudicial. For example, occasionally a taxpayer will request documents or portions of the record in other cases that have not been made a part of the record. An exhibit that was offered in evidence but was rejected by the trial judge is not a part of the record in the case. The exhibit may be sent with the record to the reviewing court if a proffer of proof was made at the trial, however, or if the Tax Court upon motion of a party orders that it be sent with the record on appeal.


**36.2.5.9.1** **(08-11-2004)**

#### Docketing and Filing the Record on Appeal

1. The Clerk of the Tax Court will transmit a copy of the notice of appeal and of the docket entries to the clerk of the court of appeals named in the notice. Fed. R. App. P. 3(d). The clerk of the court of appeals will then enter the appeal upon the docket. Fed. R. App. P. 12(a).

2. Rule 11(b) of the Federal Rules of Appellate Procedure provides that when the record is complete for purposes of the appeal, the clerk of the lower court shall transmit it forthwith to the clerk of the court of appeals. The practice of the Tax Court, when an appeal is filed, is to advise the parties that the record is being assembled and that any action with respect to the record must be taken by the parties within 25 days after the date of the notice of appeal, and that the record will be transmitted to the court of appeals on the 30th day after the filing of the notice of appeal. The intent of the Tax Court is that the record reach the court of appeals within at least 40 days after the filing of the notice of appeal. The Tax Court has an informal understanding with the courts of appeal that these time limitations will satisfy the forthwith requirement of Rule 11(b).

3. In cross-appeals, or appeals by both parties in multiple dockets, in which the Tax Court established due date of the record as to each appeal would ordinarily be on a different date, the due date of the consolidated record is based upon the time limitations for the first notice of appeal. The Tax Court, however, issues a notice of transmittal date in respect of each subsequent appeal and transmits a supplement to the court of appeals containing subsequently filed papers.

4. Upon transmittal of the record to the court of appeals, the Tax Court forwards to the Chief Counsel, in duplicate, copies of the transmittal letter, docket entries, and index of the record. The Technical Services Support Branch in the Office of the Associate Chief Counsel (P&A) will immediately forward one copy of each to the Department of Justice and one copy of each to the Associate Chief Counsel attorney responsible for the appeal.


**36.2.5.9.2** **(08-11-2004)**

#### Printing the Record on Appeal

1. Matters pertaining to printing of the record on appeal are handled by the Department of Justice. Any inquiry pertaining to printing of the record should therefore be referred to the Department of Justice and the inquirer should be promptly advised of such referral.


**36.2.5.9.3** **(08-11-2004)**

#### Notice to Tax Court Not To Prepare Record on Appeal

1. In cases where the appeal period is about to expire and the Solicitor General has not yet authorized an appeal recommended by the Office of Chief Counsel, the Office of Chief Counsel will file a Notice of Appeal with the Tax Court pending the Solicitor General's decision. When the Department of Justice later formally notifies the Chief Counsel that the Solicitor General has declined to authorize further prosecution of an appeal, and it becomes definite that the appeal will not be further prosecuted, the Associate Chief Counsel attorney should immediately notify the Clerk of the Tax Court by letter of the Solicitor General's decision. This notification is provided so that the record on appeal can be retained in the court if it has not already been transmitted to the court of appeals.

2. The letter should be reviewed and signed in the name of the Chief Counsel by the attorney's reviewer or branch chief, and a copy should be placed in the attorney's open folder for the case. A sample letter is reproduced at Exhibit 36.4.1–7, Letter to Tax Court (Record on Appeal).

3. If the record on appeal has already been transmitted to the court of appeals, the Department of Justice usually has the case dismissed without further action by the Associate Chief Counsel attorney. Nevertheless, the attorney should call the Department of Justice to ascertain whether any further action is necessary on the part of the attorney to effectuate dismissal of the appeal.


**36.2.5.9.4** **(08-11-2004)**

#### Trial Transcript

1. The attorney must order the transcript of every case susceptible of appeal.

2. If the case is appealed, the attorney should forward the transcript, with the legal files, to the appropriate Associate Chief Counsel.


**36.2.5.9.5** **(08-11-2004)**

#### Exhibits

1. When a Tax Court decision is appealed, the clerk of the Tax Court sends the exhibits to the court of appeals.

2. A duplicate record of all exhibits must be assembled for the use of the attorney in the Department of Justice who will handle the case. The preferred practice is to have a copy of all of the exhibits offered by the parties in the miscellaneous law file when the respondent's original brief is mailed to the Chief Counsel.

3. It is the responsibility of the Area Counsel attorney to assure that a copy of all exhibits admitted or proffered in evidence are included in the legal or miscellaneous law file.

4. The original tax returns should not be a part of the record on appeal. At or before conclusion of the trial, the Area Counsel attorney should file a motion with the Tax Court requesting that copies of such returns be substituted and that the original returns be withdrawn.


**36.2.5.10** **(08-11-2004)**

### Refunds and Credits While Appeal is Pending

1. Section 6512(b)(1) authorizes the Service to refund or credit an overpayment that is not contested on appeal. Section 6213(a) gives the Tax Court jurisdiction to order this refund or credit.

2. Appeals can issue manual refunds or credits of undisputed overpayments when authorized by the Associate Area Counsel, Division Counsel or in some instances, by an Associate Chief Counsel.



1. Exhibit 36.4.1–8, Memorandum to Appeals (Authorizing Overpayment Refund/Credit), is a sample memorandum that may be used in authorizing Appeals to issue a refund or credit of these overpayments.

2. Although the litigation freeze code, W freeze code, will have to be removed from the taxpayer's account for the purpose of making the refund, it will be reinstated immediately after the manual refund has been issued. The W freeze will still be in effect on the tax module, so no additional refunds or credits will be inadvertently issued.

3. Any closing document or decision document should reflect that Appeals issued a refund or credit. For instance, if, after appeal, the case is remanded to the Tax Court, the stipulation portion of any new decision document must reflect that the refund or credit was issued while the appeal was pending. _See_ Exhibit 35.11.1–140, Overpayment From Application of EITC Plus Withholding. If the case is not remanded, closing instructions sent to Appeals should clearly indicate that the interim refund or credit was made.

4. For purposes of interest computations, the date of payment or credit will be determined according to the usual rules.


**36.2.5.11** **(08-11-2004)**

### Dismissal of Appeals in Tax Court Cases

1. In most, if not all, cases, the Department of Justice handles the dismissal of appeals.


**36.2.5.11.1** **(08-11-2004)**

#### Dismissal in the Tax Court

1. If the record on appeal has not been transmitted by the Tax Court to the court of appeals, the Tax Court will permit the appeal (either taxpayer, Commissioner, or cross-appeal) to be dismissed by stipulation of the parties or by a motion by the appellant. If the appellant files a motion to dismiss, the appeal will be dismissed whether or not the appellee agrees with the motion. If, however, the other party has also filed an appeal, the dismissal will not dispose of the other party's appeal.

2. When it is proposed to stipulate dismissal of a Commissioner appeal in the Tax Court prior to the expiration of the cross-appeal period available to the taxpayer, the stipulation must be expressly conditioned upon the taxpayer's relinquishment of all rights of cross-appeal.


**36.2.5.11.2** **(08-11-2004)**

#### Dismissal in the Court of Appeals

1. If the record on appeal has been transmitted by the Tax Court to the appropriate court of appeals, a joint motion of the parties for dismissal may be filed in the court of appeals.

2. Unagreed motions by the appellee to dismiss the appellant's appeal (e.g., upon the basis of lack of jurisdiction, improper or lack of prosecution) must be filed in the court of appeals whether or not the record has been transmitted to the appellate court. In some instances, the court of appeals will not pass upon the jurisdictional issue apart from consideration of the merits of the case.

3. Fees for the appellate court for docketing a taxpayer's appeal are collected by the Tax Court. There is no dismissal for failure to docket the appeal, as docketing is now automatic. Failure to pay the fees, however, can result in dismissal for lack of proper prosecution and no action is required by the Government.


**36.2.5.11.3** **(08-11-2004)**

#### Dismissal of Taxpayer Appeals

1. In cases where the taxpayer's notice of appeal was not timely filed or fails to state a claim upon which relief can be granted, the Associate Chief Counsel attorney/paralegal should recommend to the Department of Justice that a motion for dismissal be filed. This recommendation, along with the specific grounds for dismissal, should be incorporated in the letter that notifies the Department of Justice of the taxpayer's appeal.


**36.2.5.12** **(08-11-2004)**

### Cases Remanded to the Tax Court/Recomputations

1. When the appellate court reverses or modifies the Tax Court decision, in whole or in part, it usually remands the case to the Tax Court for appropriate action. The absence of the word "remand" from the appellate decision is not determinative. If the Tax Court decision has been modified in any way, the case will be returned to the Tax Court for entry of a new decision.


**36.2.5.12.1** **(08-11-2004)**

#### Actions Following Remand

1. In most instances, the appropriate action falls into two categories: remand for entry of a new decision; or remand for rehearing or further proceedings, which may or may not encompass a second trial followed by the entry of a new decision. For purposes of this discussion, the two categories are referred to as _remand for entry of new decision_ and _remand for rehearing_ (which will be followed by the entry of a new decision). _See_ _CCDM 36.2.5.6.4_, Time for Filing Notice of Appeal.


**36.2.5.12.2** **(05-02-2012)**

#### Transfer of Case to Area Counsel

1. When a case is remanded to the Tax Court, the Associate Chief Counsel attorney will transfer it to Area Counsel for further action in the Tax Court, with or without a rehearing.

2. Once the judgment of the court of appeals has been entered, either party may petition for a rehearing ( _see_ CCDM 36.2.1.2.2, Government’s Petition for Rehearing or Rehearing En Banc) or petition for a writ of certiorari ( _see_ CCDM 36.2.2.1, Petition for Certiorari Generally). Generally, a petition for a rehearing must be filed within 14 days and a petition for certiorari must be filed within 90 days of the court of appeals' judgment. For this reason, it is imperative that no trial or other proceedings be instituted in the Tax Court until the certiorari period has expired.

3. Transfer of remanded cases:




| _If_ | _Then_ | _Action Required_ |
| --- | --- | --- |
| the certiorari period has expired and neither party has filed a petition for certiorari, | the court of appeals' mandate will remain the final appellate action in the case. | Further action is required in the Tax Court so that a new decision can be entered in accord with the mandate. The Associate Chief Counsel will transfer the case to Area Counsel. |
| certiorari has been denied, | the court of appeals' mandate will remain the final appellate action in the case. | Further action is required in the Tax Court so that a new decision can be entered in accord with the mandate. The Associate Chief Counsel will transfer the case to Area Counsel. |
| certiorari has been petitioned and granted, |  | The transfer of the case to Area Counsel will await, and will be dependent upon, the Supreme Court's mandate. |
| the Supreme Court affirms the mandate of the court of appeals, | the Supreme Court's mandate will be the final appellate action in the case. | The case will be transferred to Area Counsel. |
| the Supreme Court reverses the court of appeals, | this final appellate action will not require further action in the Tax Court, since the Supreme Court will have affirmed the Tax Court's decision and a new decision will not have to be entered. | The case will not be transferred to Area Counsel. |
| the Tax Court's decision is affirmed by the court of appeals and subsequently reversed or modified by the Supreme Court, | the Supreme Court's mandate will be the final appellate action in the case and will require further action in the Tax Court in accord with the mandate. See Note 1. | The case will be transferred to Area Counsel. |





> _Note 1:_ If the Tax Court decision is modified by the Supreme Court, the Court will remand the case to the court of appeals so that the court of appeals can revise its opinion to accord with the mandate of the Supreme Court. The court of appeals will then remand the case to the Tax Court.





> _Note 2:_ The phrase "final appellate action" is used for purposes of simplicity and clarity. It is, of course, theoretically possible for a party to appeal again, once the Tax Court has entered a new decision in accord with the mandate of either the court of appeals or the Supreme Court. Also, upon the entry of judgment in either the court of appeals or the Supreme Court, a party may petition for a rehearing. _See_ CCDM 36.2.1.2.1, Federal Rules of Appellate Procedure, for the effect of the filing of such petition on the issuance of the mandate by the respective courts.


**36.2.5.12.3** **(08-11-2004)**

#### Settled Cases

1. _See_ CCDM 36.2.3.2.3, Cases Remanded to the Tax Court after Settlement.


**36.2.5.12.4** **(08-11-2004)**

#### Effect of Transfer to Area Counsel

1. When an appealed Tax Court case is transferred to the Area Counsel office from the Associate Chief Counsel office, jurisdiction over the case reverts to Area Counsel. The phrase sometimes used is that the case is closed by transfer to the appropriate Area Counsel office. Since a new decision must be entered in the Tax Court, with or without a rehearing, the case is not closed to the Appeals office by Form 9253. Form 9253, Appellate Court Closing Memorandum, is only to be used for closing cases in which the Tax Court's decision has become final. _See_ CCDM 36.2.4, Closing Appeal Cases, and CCDM 36.2.6.2.5, Closing Procedures Specific to Tax Court Appeals.

2. Once an appealed case is transferred to the Area Counsel attorney, that attorney is responsible for any further action required in the Tax Court. Upon the entry of a new decision by the Tax Court, the Area Counsel attorney is responsible for any required assessment and/or abatement activity. _See_ CCDM 36.2.6.2.4.5, Verification of Assessment in TEFRA Cases.


**36.2.5.12.5** **(08-11-2004)**

#### Associate Chief Counsel Attorney Responsibilities

1. Immediately upon receipt of a circuit court opinion that reverses or modifies the decision of the Tax Court, whether or not the opinion is adverse to the Commissioner, in whole or in part, the attorney should prepare a memorandum to Area Counsel to be sent with a copy of the opinion.

2. The memorandum advises Area Counsel of the reversal or modification on appeal and states whether the case has been remanded for entry of a new decision or for a "rehearing." It informs Area Counsel that the case will be transferred upon the expiration of the certiorari period.

3. _See_ Exhibits 36.4.1–9, Remand Memorandum (No Rehearing), and 36.4.1–11, Remand Memorandum (Rehearing), for sample memoranda that include required information when there is a remand with no rehearing, or a remand with a hearing, respectively.


**36.2.5.12.5.1** **(08-11-2004)**

##### Monitor Case Status

1. After transmitting the memorandum and a copy of the court of appeals' opinion, the attorney should closely monitor any further proceedings initiated by either party during the 90-day period following the date of the court of appeals' opinion. The attorney is responsible for preparing a second memorandum to Area Counsel and transmitting it, along with the legal and miscellaneous law files, upon the earliest of the following occurrences:



1. Upon the expiration of the certiorari period (90 days) if neither party has petitioned for a writ of certiorari;

2. Upon the denial of a petition for writ of certiorari (see second note to table at _CCDM 36.2.5.3_ for special provisions regarding this situation); or

3. Upon the issuance by the Supreme Court of its mandate, if the Supreme Court affirms the court of appeals.



      ### Note:



      If the Supreme Court reverses the court of appeals or modifies the court of appeals, see table at _CCDM 36.2.5.3_.


**36.2.5.12.5.2** **(08-11-2004)**

##### Closing the Case to Area Counsel

1. Upon the earliest of the occurrences in _CCDM 36.2.5.12.5.1_, the Associate Chief Counsel attorney will transfer the case to Area Counsel, thereby "closing" the case in the Associate Chief Counsel's office. Closing is accomplished by transmitting the legal and miscellaneous law files (returned by the Department of Justice) to Area Counsel, along with a transfer memorandum.

2. The attorney should follow the provisions of CCDM 36.2.4.1.1, Preparing Legal Files for Closing, in preparing the legal files for transmission.

3. The Associate Chief Counsel attorney should prepare a second transfer memorandum that notifies Area Counsel of the conclusion of the appellate proceedings and the transfer of the case to the field. If Area Counsel was not previously advised of the need to obtain an updated transcript and to request the local Appeals office to procure the necessary recomputation and statement of account in the first memorandum (i.e., if the case was remanded for "rehearing" ), the transfer memorandum should advise the field to do so at the conclusion of the Tax Court proceedings. See a sample memorandum reproduced at Exhibit 36.4.1–12, Transfer Memorandum (Rehearing).

4. If the Area Counsel was previously advised of these procedures in the first memorandum (i.e., the case was remanded for entry of a new decision), it is nevertheless beneficial to include a reminder of these procedures. See a sample memorandum reproduced at Exhibit 36.4.1–13, Transfer Memorandum (No Rehearing). The memorandum also advises the Area Counsel of the field's assessment responsibility once the Tax Court enters the new decision.

5. A copy of the memorandum should be sent to the Technical Services Support Branch of the Office Associate Chief Counsel (P&A).


**36.2.5.12.6** **(05-02-2012)**

#### Computation on Remand

1. For procedures for recomputation requests, _see_ CCDM 34.7.1.4.1, Recomputation of Tax Liability.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part36/irm_36-002-005#addtoany "Show all")

A2A