---
url: "https://www.irs.gov/irm/part32/irm_32-003-004"
title: "32.3.4 Closing Agreements Covering Specific Matters | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part32/irm_32-003-004#main-content)

- 32.3.4 [Closing Agreements Covering Specific Matters](https://www.irs.gov/irm/part32/irm_32-003-004#idm140333346992512)
  - 32.3.4.1 [Scope](https://www.irs.gov/irm/part32/irm_32-003-004#idm140333382007152)
  - 32.3.4.2 [Authority](https://www.irs.gov/irm/part32/irm_32-003-004#idm140333375944400)
  - 32.3.4.3 [Basis for Entering Into Closing Agreements](https://www.irs.gov/irm/part32/irm_32-003-004#idm140333382017024)
  - 32.3.4.4 [Processing Requests for Closing Agreements](https://www.irs.gov/irm/part32/irm_32-003-004#idm140333361606816)
  - 32.3.4.5 [Finality of Closing Agreements](https://www.irs.gov/irm/part32/irm_32-003-004#idm140333372243584)
  - 32.3.4.6 [Guidelines for Drafting Closing Agreements](https://www.irs.gov/irm/part32/irm_32-003-004#idm140333347000704)
  - 32.3.4.7 [Preparation of Closing Agreements](https://www.irs.gov/irm/part32/irm_32-003-004#idm140333382019296)
    - 32.3.4.7.1 [Single Closing Agreements](https://www.irs.gov/irm/part32/irm_32-003-004#idm140333373912352)
      - 32.3.4.7.1.1 [Single Closing Agreement Specific](https://www.irs.gov/irm/part32/irm_32-003-004#idm140333374562560)
    - 32.3.4.7.2 [Mass Closing Agreements](https://www.irs.gov/irm/part32/irm_32-003-004#idm140333349612592)
    - 32.3.4.7.3 [Instructions to Taxpayers for Execution of Agreements and for Returning Agreements to the Associate Office](https://www.irs.gov/irm/part32/irm_32-003-004#idm140333349608528)
    - 32.3.4.7.4 [Procedure after Closing Agreements Are Executed by Taxpayer](https://www.irs.gov/irm/part32/irm_32-003-004#idm140333368046512)
      - 32.3.4.7.4.1 [Special File](https://www.irs.gov/irm/part32/irm_32-003-004#idm140333374574480)
      - 32.3.4.7.4.2 [Signing and Disposition of Closing Agreements and Special Files](https://www.irs.gov/irm/part32/irm_32-003-004#idm140333351560720)
    - 32.3.4.7.5 [Setting Aside or Clarification of Closing Agreements](https://www.irs.gov/irm/part32/irm_32-003-004#idm140333379088368)
      - 32.3.4.7.5.1 [Procedure for Setting Aside Closing Agreement](https://www.irs.gov/irm/part32/irm_32-003-004#idm140333357722464)
  - Exhibit 32.3.4-1 [Transmittal Memorandum to Associate Chief Counsel](https://www.irs.gov/irm/part32/irm_32-003-004#idm140333354986432)
  - Exhibit 32.3.4-2 [Transmittal Letter to Taxpayer](https://www.irs.gov/irm/part32/irm_32-003-004#idm140333376709072)
  - Exhibit 32.3.4-3 [Transmittal Memorandum to District Director](https://www.irs.gov/irm/part32/irm_32-003-004#idm140333378508256)
  - Exhibit 32.3.4-4 [Assembly of the Special File](https://www.irs.gov/irm/part32/irm_32-003-004#idm140333378505824)

# Part 32. Published Guidance and Other Guidance to Taxpayers

# Chapter 3. Letter Rulings, Information Letters, and Closing Agreements

# Section 4. Closing Agreements Covering Specific Matters

* * *

## 32.3.4 Closing Agreements Covering Specific Matters

#### Manual Transmittal

October 11, 2017

#### Purpose

(1) This transmits revised CCDM 32.3.4, Letter Rulings, Information Letters, and Closing Agreements; Closing Agreements Covering Specific Matters.

#### Background

This material is being revised to implement TIGTA’s recommendation in Audit 2017 10-012 that Counsel adopt a policy that refunds of user fees be processed when a case is being closed.

#### Material Changes

(1) CCDM 32.3.4.7.4.2(5) was revised to clarify procedures for ensuring prompt consideration of refunds of user fees during the signing and disposition of closing agreements and special files.

#### Effect on Other Documents

CCDM 32.3.4, dated August 11, 2004, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(10-11-2017)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**32.3.4.1** **(08-11-2004)**

### Scope

1. The procedures set forth in this section are applicable only to closing agreements originating in the Office of Chief Counsel.

2. Closing agreements are not usually entered into with taxpayers where the issue presented involves excise taxes or when the letter ruling involves the status of a section 521 Farmers’ Cooperative.

3. For procedures applicable to closing agreements generally and for those originating in field offices see IRM 8.13.1, Appeals Closing Agreement Manual, Closing Agreements, and Rev. Proc. 68-16, 1968-1 C.B. 770.


**32.3.4.2** **(08-11-2004)**

### Authority

1. Pursuant to section 7121 and its regulations, the Commissioner may enter into and approve a written closing agreement with any person relating to the liability of that person in respect of any internal revenue tax for any taxable period ending prior or subsequent to the date of the agreement.

2. By Delegation Order No. 97, IRM 1.2.2.8.4 (as revised), the Commissioner authorized the Chief Counsel to enter into and approve a written closing agreement with any person relating to the internal revenue tax liability of such person (or of the person or estate for whom such person acts) in respect of any prospective transactions or completed transactions affecting returns to be filed. This authority may be redelegated to the Associate Chief Counsel and the Deputy Associate Chief Counsel for matters under their respective jurisdictions, and to the Assistant Chief Counsel for matters under their respective jurisdictions that do not involve precedent issues. The Order, however, provides that the authority delegated does not include the authority to set aside any closing agreement.

3. Closing agreements originating within the Office of Chief Counsel are normally approved and signed by the Associate Chief Counsel or Deputy Associate Chief Counsel, but are approved and signed by the Chief Counsel or the Commissioner, where appropriate (see Delegation Order 97 rev. 34). References to Associate Chief Counsel in this section include his or her Deputy Associate Chief Counsel, and when appropriate, the Assistant Chief Counsel.

4. Closing agreements originating within the Office of Chief Counsel may be based on letter rulings, covering prospective transactions or completed transactions affecting returns to be filed, that have been signed by the Commissioner, the Chief Counsel, or an Associate Chief Counsel and in which it is indicated that a closing agreement will be entered into based up on the holding in the letter ruling. In appropriate cases, closing agreements may also be entered into without an accompanying letter ruling.

5. The procedures in the annual revenue procedure for letter rulings, determination letters, and closing agreements should be followed in processing a request for a closing agreement that is entered into with or without an accompanying letter ruling. Both types of closing agreement applications require the payment of a user fee.


**32.3.4.3** **(08-11-2004)**

### Basis for Entering Into Closing Agreements

1. A taxpayer may be required to enter into a closing agreement as a condition to the issuance of a letter ruling in any case in which the interests of the Government will be served by having the case permanently and conclusively closed. Also, in appropriate cases, a taxpayer may be asked to enter into a closing agreement in which no letter ruling will be issued. A closing agreement may also be entered into upon request of a taxpayer that shows good and sufficient reasons for desiring a closing agreement and if it is determined that the Government will sustain no disadvantage through consummation of the agreement.

2. If, in a single case, closing agreements are requested on behalf of each of a number of taxpayers, such agreements are not entered into if the number of such taxpayers exceeds 25, in view of the prohibitive amount of work involved in the preparation and processing of such agreements. In a case where the issue and holding are identical as to all the taxpayers (for example, where the taxpayers are the common stockholders of a corporation and the corporation proposes to distribute preferred stock to them on a pro rata basis as a stock dividend) and the number of taxpayers is in excess of 25, a Mass Closing Agreement, described in CCDM 32.3.4.7.2 Mass Closing Agreements may be entered into with the taxpayer that is authorized by the others to represent the entire group.


**32.3.4.4** **(08-11-2004)**

### Processing Requests for Closing Agreements

1. The procedure for processing and disposing of a taxpayer’s request for a letter ruling accompanied by a request for a closing agreement is the same as that described in CCDM 32.3.2 Letter Rulings and this section.

2. If the proposed letter ruling is to be accompanied by a closing agreement, the letter ruling and closing agreement must be forwarded together for review. Language must be included in the letter ruling informing the taxpayer of the procedure for execution of the agreement and returning it to the appropriate Associate Chief Counsel or Division Counsel/Associate Chief Counsel (TEGE) for approval. See CCDM 32.3.4.7.3 Instructions to Taxpayers for Execution of Agreements and for Returning Agreements to the Associate Office. The letter ruling is normally prepared for the signature of the person who will approve and sign the closing agreement. See CCDM 32.3.4.2 Authority. If the proposed letter ruling is not in accordance with the taxpayer’s request, a closing agreement is not necessary and the adverse letter ruling is signed in accordance with established procedures. If the proposed letter ruling is in accordance with the taxpayer’s request but denies the request for a closing agreement, the letter ruling shall be signed at a level no lower than the Associate Chief Counsel.


**32.3.4.5** **(08-11-2004)**

### Finality of Closing Agreements

1. Closing agreements are final and conclusive and may not, in the absence of fraud, malfeasance, or misrepresentation of material fact, be reopened as to matter agreed upon or be modified by any officer, employee, or agent of the United States. Such agreements shall not be annulled, modified, set aside, or disregarded in any suit, action, or proceeding. A closing agreement with respect to a taxable period ending subsequent to the date of the agreement is subject to any change in, or modification of, the law enacted subsequent to the date of the agreement and made applicable to such taxable period, and each closing shall so recite. Because of the finality of these agreements, they must be carefully drafted. See also IRM 8.13.1.3 (3) and (4) and 8.13.1.6.1 pertaining to disagreements as to the interpretation of a closing agreement.


**32.3.4.6** **(08-11-2004)**

### Guidelines for Drafting Closing Agreements

1. Determined matters should be stated with such clarity as to lead reasonably to only one interpretation. Although the material in the file may adequately explain the intent of the agreement, the agreement itself will be the primary basis for future action.

2. Essentials must not be overlooked. For example, the agreement should state to whom the income pertains and property should be adequately identified. To avoid ambiguity in descriptive terms, it is usually preferable to use statutory terms where applicable.

3. The direct or indirect impact of the determination of a specific matter upon other years or related cases should be given careful consideration.


**32.3.4.7** **(08-11-2004)**

### Preparation of Closing Agreements

1. The following covers preparation of closing agreements.


**32.3.4.7.1** **(08-11-2004)**

#### Single Closing Agreements

01. The closing agreement is prepared by the initiator when the letter ruling is prepared. The specimen closing agreement shown in Form 906 should be followed in preparing agreements originating in the Office of Chief Counsel. Form 906 or a format that uses the language of that form should be used for the first page. See CCDM 32.3.4.7.1.1 Single Closing Agreement - Specific for language to use in a single closing agreement.

02. Closing agreements prepared in the Office of Chief Counsel usually consist of two or more pages. They may be prepared on letter-size paper; a standard Form 906 also may be used. The last page of this form cannot be used for closing agreements originating in the Office of Chief Counsel.

03. An original and eight identical copies of each page of the closing agreement should be prepared.

04. Where many taxpayers are involved in transactions of the same type (as, for example, corporate reorganizations), and the substance of the agreements is identical, a printed closing agreement may be used for all taxpayers in the same situation when the number of similar agreements justifies its use. The printed form, with blank spaces for insertion of the variable information such as name, address, and identifying number of taxpayer, dates of letters, etc., should be used for the original(s), and photocopies of the completed original for duplicate(s), triplicate(s), and all other copies. The procedure for mass closing agreements, CCDM 32.4.7.2 Mass Closing Agreements, is not applicable.

05. The original and all copies of each page other than page one will be identified in the upper left corner as follows:



    |     |
    | --- |
    | Form 906-Closing Agreement (name of taxpayer) |

06. Each additional page should be numbered at the bottom in the same style as shown, for example (Page 6 of 8).

07. In the upper right corner of the first page (Form 906 or photocopy) of the original, duplicate, and triplicate of the closing agreement, the following will be typed:



    |     |     |
    | --- | --- |
    | **On the** | **Type** |
    | Original | ORIGINAL |
    | Duplicate | DUPLICATE Taxpayer’s Copy |
    | Triplicate | TRIPLICATE Operating Division Copy |

08. The agreement should not contain erasures of significant matter.

09. The last page must contain more than the execution paragraph (the one that certifies that the parties have read and agreed to the terms of the document) and the date and signature lines. The last page should include at least a few lines of the text of the closing agreement.

10. In any case where closing agreements are requested by or on behalf of a number of taxpayers (less than 25) and the agreements will be identical except for the names and addresses of the taxpayers, the initiator prepares a closing agreement for only one of them, and the taxpayers or their representatives are requested to prepare similar agreements for the others.

11. In order to have legible copies of the letter ruling for the Special File, see CCDM 32.3.4.7.4.1 Special File, the initiator will, when forwarding the letter ruling for review and signature, attach to the upper right corner of the letter ruling the following note, which should be dated and signed: "After this letter ruling has been signed, please use the original and have three copies reproduced for each closing agreement in the Special File."


**32.3.4.7.1.1** **(08-11-2004)**

##### Single Closing Agreement – Specific

1. The opening paragraph of Form 906 states that the agreement is made between the taxpayer and the Commissioner of Internal Revenue. The taxpayer’s name, address, and identifying number (when known) are typed in the space provided. See paragraph 3 of CCDM 32.3.4.7.3 Instructions to Taxpayers for Execution of Agreements and for Returning Agreements to the Associate Office when the address of the taxpayer is unknown.

2. The content of the first WHEREAS paragraph depends on whether there is an accompanying letter ruling.



> **_Example 1:_** Where there is an accompanying letter ruling, the first WHEREAS paragraph should read substantially as follows:





> "WHEREAS, based on information submitted with the taxpayer’s request dated (date) (or such words as are suitable), and in the absence of other material circumstances as a part of the (enter either proposed or completed as the case may be) transaction, it has been determined for Federal (insert type of tax or taxes, as income or gift) tax purposes that under the circumstances stated in the Associate Chief Counsel’s letter to (addressee’s name and address), dated (leave space for date of ruling letter), a copy of which is attached hereto and made a part hereof, that: (insofar as is possible, the determinations in the agreement should be stated in the same language as the holdings or letter ruling paragraphs in the letter ruling)."





> **_Example 2:_** Where there is no letter ruling to be issued in connection with the closing agreement, the first WHEREAS paragraph should read substantially as follows:





> "WHEREAS, based on information submitted with the taxpayer’s request dated (date) (or such words as are suitable), and in the absence of other material circumstances as a part of the (enter either proposed or completed as the case may be) transaction, it has been determined for Federal (insert type of tax or taxes, as income or gift) that:"

3. The last WHEREAS paragraph should read substantially as follows: "WHEREAS, the determination(s) set forth above is (are) hereby agreed to by said taxpayer."

4. The following paragraph should be inserted in the closing agreement immediately following the last DETERMINATION paragraph:



|     |
| --- |
| "This agreement is final and conclusive except (1) the matter it relates to may be reopened in the event of fraud, malfeasance, or misrepresentation of material fact; (2) it is subject to the Internal Revenue Code sections that expressly provide that effect be given to their provisions (including any stated exception for section 7122) notwithstanding any other law or rule of law; and (3) if it relates to a tax period ending after the date of this agreement, it is subject to any law, enacted after the agreement date, that applies to that tax period." |

5. The execution paragraph is the last paragraph in the agreement and should read as follows:



|     |
| --- |
| "By signing, the above parties certify that they have read and agreed to the terms of this document." |

6. The date and signature lines follow the execution paragraph.

7. Certifications are typed on the reverse of the last page of the original only. See Form 906 for wording and format.


**32.3.4.7.2** **(08-11-2004)**

#### Mass Closing Agreements

1. The Mass Closing Agreement is the same in form as the specimen (Form 906) except for changes in the first paragraph and in the signature line. Form 906 will not be used as the first page of a Mass Closing Agreement.

2. The first paragraph should read as follows:



|     |
| --- |
| "THIS CLOSING AGREEMENT, made in triplicate, under and in pursuance of section 7121 of the Internal Revenue Code by and between (name and address of taxpayer signing the agreement for the group and taxpayer identifying number), on behalf of himself/herself and other shareholders of\_\_\_\_\_\_\_ corporation (or other appropriate words to identify the group) for whom he/she is authorized to act with respect to the specific matter involved at the time of execution hereof, as shown in the attached list which is made a part hereof, and the Commissioner of Internal Revenue" |

3. The signature line should read as follows:



|     |     |
| --- | --- |
|  | (Taxpayer) |
|  | (for himself/herself and on behalf of said other shareholders of\_\_\_\_\_\_\_corporation (or other appropriate words to identify the group) for whom he/she is authorized to act with respect to the specific matter involved at the time of execution hereof, as shown in the attached list which is made a part hereof). |





### Note:



The names and addresses of the taxpayers who are to authorize the principal taxpayer to execute the agreement on their behalf are ordinarily not known to the initiator. The taxpayer should be requested to prepare such a list in triplicate and attach it to the agreement when it is executed and returned for special approval.


**32.3.4.7.3** **(08-11-2004)**

#### Instructions to Taxpayers for Execution of Agreements and for Returning Agreements to the Associate Office

1. Where there is no letter ruling to be issued in connection with the closing agreement, a cover letter addressed to the taxpayer or representative is to be prepared to transmit the closing agreement.

2. A paragraph should be inserted in the cover letter or, where there is an accompanying letter ruling, in the letter ruling immediately following the ruling paragraphs, and should read substantially as follows: "We will, accordingly, approve a closing agreement with the taxpayer with respect to those issues affecting its tax liability on the basis set forth above. The necessary closing agreement for (name of taxpayer) has been prepared in triplicate and is enclosed. In pursuance of our practice with respect to such agreements, the agreement contains a stipulation to the effect that any change or modification of applicable statutes enacted subsequent to the date of this agreement and made applicable to the taxable period involved will render the agreement ineffective to the extent that it is dependent upon such statutes. "

3. Additional instructions as to the proper procedure for executing the closing agreement and returning it to the appropriate office for approval should be inserted under the following circumstances:



1. If the address used by the taxpayer in filing its Federal tax return is unknown to the initiator at the time of the preparation of the agreement, a space for that address is left in the first paragraph of the agreement and the taxpayer or representative is instructed to insert such address.

2. If agreements for several taxpayers will be identical, except for names and addresses of taxpayers, and an agreement has been prepared for only one of them, the taxpayer or representative should be requested to prepare, in triplicate, similar agreements for the other taxpayers in the group.


4. The taxpayer should be instructed to date and sign the original, duplicate, and triplicate of the closing agreement and to follow the procedures set forth below:



1. If a taxpayer is a corporation, the corporate name should be entered on the agreement, followed by the signature and title of an authorized officer, or officers, or by the signature of an authorized representative. Affixing of the corporate seal is not required. (While corporate resolutions authorizing execution of closing agreements are no longer required with such agreement, if they are submitted they must be reviewed to ascertain whether they are consistent with the action being taken.)

2. If an agreement is to be signed by a trustee on behalf of a trust or by an administrator or executor on behalf of an estate, there should be attached to the original of the agreement an attested copy of the letters testamentary, court order, or other instrument vesting such person with authority so to act, together with a recent affidavit to the effect that such authority remains in full force and effect.

3. If an agreement for a taxpayer is signed by an authorized representative for the taxpayer, there should be attached to the original of the agreement a properly executed power of attorney specifically authorizing the representative to enter into an agreement in the matter on behalf of the taxpayer.


5. If a "Mass Closing Agreement" is involved, the original, duplicate, and triplicate of the agreement will be dated and signed by the taxpayer designated to sign for the group. The taxpayer or representative should be requested to prepare and attach to each copy of the agreement a list setting forth the names and addresses of the taxpayers in the group on behalf of whom the designated taxpayer is executing the agreement. There should be attached to the original of the agreement properly executed powers of attorney for all of the taxpayers listed, authorizing the designated taxpayer to execute the agreement in their behalf.

6. Upon signing of the letter ruling and approval of the official file copy, Form 1937, of the closing agreement by the Associate Chief Counsel, the file is returned to the originating branch for insertion of proper dates in the closing agreement. The letter ruling with the unsigned closing agreement in triplicate is then mailed to the taxpayer. The section 6110 copies remain in the file.


**32.3.4.7.4** **(08-11-2004)**

#### Procedure after Closing Agreements Are Executed by Taxpayer

1. When a closing agreement has been executed, in triplicate, and returned for approval, it is directed to the initiator for examination to ensure that it is in proper order. The initiator should make no changes or additions to the agreement. If additions or corrections have been made by the taxpayer or authorized representative, the initiator should make sure that such additions or corrections have been initialed and dated by the taxpayer or authorized representative. If a new page has been substituted by the taxpayer or authorized representative, the taxpayer’s or authorized representative’s initials and date must appear at the bottom of that page. When satisfied that the closing agreement is in proper order, the initiator signs and dates on the reverse of the last page of the original as Receiving Officer.

2. The initiator prepares a Special File (see CCDM 32.3.3.2 Information Letters to be Available for Public Inspection) and a transmittal memorandum to the Associate Chief Counsel from the assigned reviewer. See Exhibit 32.3.4-1. The initiator also prepares a transmittal letter to the taxpayer, Exhibit 32.3.4-2, and a transmittal memorandum to the appropriate operating division, Exhibit 32.3.4-3, for the signature of the reviewer, to forward copies of the closing agreement after it has been approved by the Associate Chief Counsel.


**32.3.4.7.4.1** **(08-11-2004)**

##### Special File

1. The Special File is a temporary file for all papers relating to the closing agreement. A manila folder is used for this file. The outside of the folder is marked SPECIAL FILE and reflects the name of taxpayer, the number of closing agreements, and the symbols of the branch handling the case.

2. The file should contain the following:



> The powers of attorney, if any





> The original of taxpayer’s request for letter ruling, if any, and original request for closing agreement, together with all necessary supporting papers, such as subsequent related correspondence from the taxpayer, revenue agents’ and/or office reports, if any, and the like





> If case was forwarded to Chief Counsel, the official file copy, Form 1937, of transmittal memorandum





> Official file copies of the letter ruling, if any, and closing agreement





> Transmittal letter and memorandum (original and all copies) to taxpayer and appropriate operating division, respectively





> Three copies of letter ruling, if any, for each closing agreement in the file





> Closing agreements, executed in triplicate, with necessary documentary evidence, and all copies except the official file copy
>
> ### Note:
>
> In the case of a "Mass Closing Agreement" or any other agreement that is signed for a taxpayer by the taxpayer’s representative, the power of attorney authorizing the representative to sign should be attached to the original agreement





> Material for use by the operating divisions in the examination of the returns, including a copy of taxpayer&rsquos request for letter ruling, if any, and copy of the request for closing agreement and a copy of supporting papers, where appropriate. The necessary number of copies (in excess of one) of these documents will be reproduced





> Transmittal memorandum to the Associate Chief Counsel





> The deleted copy of the letter ruling and closing agreement and the section 6110 copies of the letter ruling and accompanying closing agreement referred to in the letter ruling

3. See Exhibit 32.3.4-4 for instructions for assembling the special file.


**32.3.4.7.4.2** **(10-11-2017)**

##### Signing and Disposition of Closing Agreements and Special Files

1. The initiator assembles the material in the Special File as explained in Exhibit 32.3.4-4, initials all Forms 1937 accompanying the Special File, and forwards it to the assigned reviewer, who reviews the agreement, signs and dates on the reverse of the last page of the original as Reviewing Officer, and forwards the Special File to the Associate Chief Counsel.

2. Each office is responsible for controlling closing agreements originating within its jurisdiction. After the closing agreement is controlled and the transmittal memorandum to the Associate Chief Counsel is signed, the Special File is forwarded to the person in the Associate Chief Counsel office who approved the letter ruling, if one was issued, for signing by the Associate Chief Counsel and dating of the original, duplicate, and triplicate of the closing agreement.

3. After signing, the closing agreement is returned with the Special File to the originating office. A copy is made of the original of the closing agreement, and the appropriate deletions are made following the guidelines in CCDM 37.1.2.2. The letter transmitting the duplicate closing agreement and the section 6110 copy of the letter ruling to the taxpayer and the memorandum transmitting the triplicate to the field are signed and dated. Also transmitted to the field with the triplicate of the closing agreement is a copy of each of the following: taxpayer’s request for letter ruling, if any, and request for closing agreement, related letter ruling, if any, and transmittal letter to taxpayer. The original of the closing agreement and a copy each of the related letter ruling, the transmittal letter to the taxpayer, and the transmittal memorandum to the field are retained in the originating office.

4. The Special File is made a part of the letter ruling case file.

5. The file is assembled and forwarded to the Docket, Records & User Fee Branch for processing in accordance with CCDM 37.1.2.2. In addition, if a refund of all or part of the user fee is due, the attorney must complete the User Fee Refund Request Form and submit it to the Legal Processing Division, Docket, Records and User Fee Section, for processing.


**32.3.4.7.5** **(08-11-2004)**

#### Setting Aside or Clarification of Closing Agreements

1. Agreements made under section 7121 may be set aside by the Commissioner upon a showing of fraud or malfeasance, or misrepresentation of a material fact. The Commissioner’s authority in this respect has not been delegated. See CCDM 32.3.4.2 Authority. Any such actions must be over the Commissioner’s signature.

2. In the event of litigation on the point, the burden of proof for setting aside a closing agreement has been held to be upon the party desiring to do so. _See Holmes & Janes, Inc. v. Commissioner_, 30 B.T.A. 74 (1934), and _Ingram v. Commissioner_, 32 B.T.A. 1063 (1935), _nonacq._, XIV-2 C.B. 34 (1935), _aff’d_, 87 F.2d 915 (3d Cir. 1937).

3. Setting aside of a closing agreement, even though deemed justified, is not mandatory. If it is in the best interests of the Government to refrain from setting aside the agreement, it may do so.


**32.3.4.7.5.1** **(08-11-2004)**

##### Procedure for Setting Aside Closing Agreement

1. Requests from field offices for consideration of setting aside of a closing agreement executed in the Office of the Chief Counsel should be submitted to the appropriate Associate Chief Counsel and be accompanied by a recommendation and the reasons therefor.

2. In considering the field request, Associate Chief Counsel will grant the taxpayer a conference only if it is deemed necessary and would be advantageous to the interests of the Government.

3. If it is determined that the closing agreement should not be set aside, a memorandum to that effect, setting forth the basis therefor, should be issued to the field office. The signature of the Associate Chief Counsel or Commissioner is required for this memorandum.

4. If it is determined that the closing agreement should be set aside, a letter notifying the taxpayer of the decision will be prepared for the Commissioner’s signature. It should be submitted to the Commissioner for approval, accompanied by an appropriate explanatory memorandum. See IRM 8.13.1.6.

5. A memorandum to the appropriate field office transmitting a copy of the letter to the taxpayer will be mailed at the same time the letter to the taxpayer is mailed.


**Exhibit 32.3.4-1**

### Transmittal Memorandum to Associate Chief Counsel

![This is an Image: 39012005.gif](https://www.irs.gov/pub/xml_bc/39012005.gif)

> Sample transmittal memorandum to Associate Chief Counsel

[Please click here for the text description of the image.](https://www.irs.gov/media/157671 "")

**Exhibit 32.3.4-2**

### Transmittal Letter to Taxpayer

![This is an Image: 39012006.gif](https://www.irs.gov/pub/xml_bc/39012006.gif)

> Sample transmittal letter to taxpayer

[Please click here for the text description of the image.](https://www.irs.gov/media/157676 "")

**Exhibit 32.3.4-3**

### Transmittal Memorandum to District Director

![This is an Image: 39012007.gif](https://www.irs.gov/pub/xml_bc/39012007.gif)

> Sample transmittal memorandum to District Director

[Please click here for the text description of the image.](https://www.irs.gov/media/157681 "")

**Exhibit 32.3.4-4**

### Assembly of the Special File

|     |
| --- |
| Assembly of the Special File |

The Special File should contain the following papers:

01. powers of attorney, if any; (See (g), below);

02. original of taxpayer’s request for letter ruling, if any, and original request for closing agreement, together with all necessary supporting papers, such as subsequent related correspondence from the taxpayer, revenue agents’ and/or office reports, if any, etc.;

03. if case was forwarded to Chief Counsel, official file copy, Form 1937, of transmittal memorandum;

04. official file copies of the letter ruling, if any, and closing agreement;

05. transmittal letter and memorandum (original and all copies) to taxpayer and appropriate district director, respectively;

06. three copies of letter ruling, if any, for each closing agreement in file;

07. closing agreements, executed in triplicate, with necessary documentary evidence; and all manifold copies except the yellow. In the case of a "Mass Closing Agreement" or any other agreement that is signed for a taxpayer by the taxpayer’s representative, the power of attorney authorizing the representative to sign should be attached to the original of agreement;

08. material for use by the operating divisions in the examination of the returns:



    1. copy of taxpayer’s request for letter ruling, if any, and copy of request for closing agreement; and

    2. copy of supporting papers, where appropriate. The necessary number of copies (in excess of one) of these documents will be reproduced;


09. transmittal memorandum to the Associate Chief Counsel; and

10. the redacted copy of the letter ruling and closing agreement, and the IRC 6110 copies of the letter ruling and accompanying closing agreement referred to in the letter ruling.


The papers listed above, will be attached in the Special File as follows:

1. items (a) through (d) are fastened to the folder in inverse order;

2. item (e)-original and all copies are paper-clipped to the inside of the front cover;

3. item (f)-all three copies are placed loose in the folder (these copies are for attachment to the original, duplicate and triplicate of the agreement);

4. item (g)-the closing agreements are placed loose in the folder;

5. item (h)-this material is also placed loose in the folder; and

6. item (i)-this transmittal memorandum is paper-clipped to the outside of the front cover.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part32/irm_32-003-004#addtoany "Show all")

A2A