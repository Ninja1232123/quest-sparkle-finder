---
url: "https://www.irs.gov/irm/part30/irm_30-005-002"
title: "30.5.2 Travel Guidelines | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part30/irm_30-005-002#main-content)

- 30.5.2 [Travel Guidelines](https://www.irs.gov/irm/part30/irm_30-005-002#idm140010895363120)
  - 30.5.2.1 [Guidelines for the Performance of Official Travel](https://www.irs.gov/irm/part30/irm_30-005-002#idm140010901714896)
  - 30.5.2.2 [Meetings, Conferences, and Training](https://www.irs.gov/irm/part30/irm_30-005-002#idm140010881136128)
  - 30.5.2.3 [Travel Authorization, Arrangements, and Reimbursement](https://www.irs.gov/irm/part30/irm_30-005-002#idm140010877371280)

    - 30.5.2.3.1 [Travel Authorization](https://www.irs.gov/irm/part30/irm_30-005-002#idm140010906984272)
    - 30.5.2.3.2 [Travel Charge Card](https://www.irs.gov/irm/part30/irm_30-005-002#idm140010885410576)

      - 30.5.2.3.2.1 [Misuse of Travel Charge Card](https://www.irs.gov/irm/part30/irm_30-005-002#idm140010899699520)

    - 30.5.2.3.3 [Travel Arrangements](https://www.irs.gov/irm/part30/irm_30-005-002#idm140010877136544)
    - 30.5.2.3.4 [Travel Expenses](https://www.irs.gov/irm/part30/irm_30-005-002#idm140010891389200)

      - 30.5.2.3.4.1 [Travel Advances](https://www.irs.gov/irm/part30/irm_30-005-002#idm140010882620976)
      - 30.5.2.3.4.2 [Reimbursement of Travel Expenses](https://www.irs.gov/irm/part30/irm_30-005-002#idm140010879552128)

        - 30.5.2.3.4.2.1 [Authorization of Actual Expense](https://www.irs.gov/irm/part30/irm_30-005-002#idm140010885079792)

  - 30.5.2.4 [Relocation At Government Expense](https://www.irs.gov/irm/part30/irm_30-005-002#idm140010888297264)
  - 30.5.2.5 [Foreign Travel](https://www.irs.gov/irm/part30/irm_30-005-002#idm140010886665728)
  - 30.5.2.6 [Promotional Items, Including Frequent Flyer Miles](https://www.irs.gov/irm/part30/irm_30-005-002#idm140010889055392)
  - 30.5.2.7 [Travel Gainsharing](https://www.irs.gov/irm/part30/irm_30-005-002#idm140010875007344)
  - Exhibit 30.5.2-1 [Counsel Travel Types and Codes](https://www.irs.gov/irm/part30/irm_30-005-002#idm140010874985904)

# Part 30. Administrative

# Chapter 5. Resources, Services, and Financial Management

# Section 2. Travel Guidelines

* * *

## 30.5.2 Travel Guidelines

#### Manual Transmittal

February 28, 2014

#### Purpose

(1) This transmits revised CCDM 30.5.2, Resources, Services, and Financial Management; Travel Guidelines.

#### Material Changes

(1) CCDM 30.5.2.3.2(1) was updated to correct an error in the current CFR reference; the correct reference is 41 CFR § 301-51.1

(2) IRM references were updated and hyperlinks added throughout the section.

#### Effect on Other Documents

CCDM 30.5.2 dated November 10, 2010 is superseded.

#### Audience

Chief Counsel

#### Effective Date

(02-28-2014)

Michael T. Cochis

Director, Planning and Management Division

**30.5.2.1** **(02-28-2014)**

### Guidelines for the Performance of Official Travel

1. Travel of employees on official business is governed by applicable laws and Government-wide rules and regulations and, except as otherwise provided below, the IRS travel policies. Procedures and guidelines for the performance of official travel are contained in the following:



   - The federal travel regulations (41 CFR Chapters 301-304), at [http://www.gsa.gov/](http://www.gsa.gov/)

   - Department of Treasury Directives, at [http://www.treas.gov/regs/](http://www.treas.gov/regs/)

   - IRM 1.32.1, Official IRS Local Travel Guide

   - IRM 1.32.11, Official IRS City-to-City Travel Guide

   - Relocation Guidelines and Procedures


2. This section establishes policy and procedures for the performance of official travel in the Office of Chief Counsel; it contains additional guidance, clarification and Counsel-specific information.

3. All Counsel travel is to be authorized for essential needs only and conducted in the most cost efficient manner. Supervisors must manage travel — not simply review vouchers for accuracy and entitlement.

4. The types of travel covered by these guidelines are listed in Exhibit 30.5.2-1 together with a short description of the travel category.


**30.5.2.2** **(02-04-2009)**

### Meetings, Conferences, and Training

1. Because the travel authority of the Office of Chief Counsel is derived from the Commissioner, the selection of locations and facilities for office meetings, conferences, and training sessions within the Office of Chief Counsel shall conform to IRM 1.32.1. Associate Chief Counsel or Division Counsel or their designees may approve an exception to the normal requirement regarding location and/or costs of the meeting, within their approved funding for travel.

2. The Office of Chief Counsel holds a large number of meetings, conferences, and training sessions across the country in the course of carrying out its legal programs. The following guidance is provided to ensure that sound business reasons are uniformly considered and applied when planning for these off site programs.



1. Meetings, conferences, and training sessions should be scheduled to minimize overnight travel and related cost (i.e., planned for a location requiring a minimum number of employees to travel/stay overnight).

2. All cost comparisons to identify the lowest cost city for the meeting location must include the headquarters city.

3. Whenever cost differences are negligible, the decision to use the headquarters city should prevail.

4. Perception must always be a consideration by managers and executives when planning off site meetings. Regardless of relative cost, availability, or other considerations, off site meetings should not be held in locations which might be considered resort locations.

5. Managers at all levels, should assure that training requiring travel is either essential to the employee's performance in their present assignment or is a planned investment necessary to an employee's development and career growth.

6. The Office of Chief Counsel retains the authority to determine meeting, conference, and training requirements and work directly with Procurement to use credit cards and purchase orders to secure outside facilities, contracts, and services as needed.


### Note:

This guidance should be followed except when the Deputy Chief Counsel (Operations or Technical), or their designee, grants an exception at least 30 days prior to obligating funds for the use of any private or commercial facility.

**30.5.2.3** **(02-15-2007)**

### Travel Authorization, Arrangements, and Reimbursement

1. This subsection provides procedures for travel authorization, arrangements, charges and reimbursement.


**30.5.2.3.1** **(11-10-2010)**

#### Travel Authorization

1. The IRS issues a General Travel Order (GTO), authorizing Counsel personnel, under proper direction, to perform official travel and to be reimbursed. This authorization covers travel within the United States and its possessions and travel to parts of Canada under certain conditions.

2. Counsel travelers must have a Travel Authorization submitted and approved within GovTrip prior to travel. This requirement allows funds for the travel to be committed within the IRS’s official accounting system. Employees may prepare the travel authorization within GovTrip, or manually complete Form 13635, Manual Travel Authorization. The latter can be used only for international travel.

3. All travel must be approved in advance by an Associate Chief Counsel or Division Counsel or their designees.

4. Written justification stating the necessity for the travel to be performed should be submitted to the approving official prior to input into GovTrip.

5. Transportation requests, or applications for advance of funds, will not be issued or processed prior to the receipt and approval of a completed travel authorization.



### Note:



Employees who use the Centrally Billed Account (CBA) to procure common carrier transportation tickets must submit their approved Travel Authorization to the CBA Coordinator or Designated Authorizer before SATO Travel will ticket the reservation.

6. In the event the authorized travel must be rescheduled or cancelled, it will be the responsibility of the traveler to notify the approving official of such changes. This notice of cancellation must also be entered into GovTrip.

7. Travel of employees for purposes of participating in or attending tax forums and continuing professional education programs, where reasonable expenses for travel, lodging, and meals are to be paid or reimbursed by any state, county, or municipal agency or by an organization which has been determined to be tax exempt under IRC § 501(c)(3), can be approved only by the following officials:



   - Chief Counsel

   - Deputy Chief Counsel (Operations)

   - Associate Chief Counsel (Finance and Management)


### Note:

See CCDM 30.4.3.2, Widely Attended Gatherings, and CCDM 30.4.8.6, Remuneration and Expenses.

**30.5.2.3.2** **(02-28-2014)**

#### Travel Charge Card

1. Pursuant to 41 CFR § 301-51.1, all frequent travelers are required to have individual Government contractor-issued travel charge cards. This regulation applies to all federal government travelers and will thus also apply to all Counsel frequent travelers.

2. All frequent Counsel travelers are required to use their individual Government contractor-issued travel charge cards to purchase common carrier transportation and other official travel expenses (absent specific exceptions outlined in paragraphs (3) and (5)).

3. The Office of Chief Counsel will follow the IRS rules on exemptions to the general rule on using the Government-contractor issued travel card for all travel expenses. Under those rules, the following groups of travelers are automatically exempted:



1. Infrequent travelers — employees who travel away from their post-of-duty less than twice a year

2. New employees — are exempt until they obtain a Government contractor-issued travel charge card. New employees who are identified by their managers to be frequent travelers are expected to obtain and use a travel charge card within 45 business days after their entrance on duty date.

3. Applicants interviewing for a job (also called invitational travelers)

4. Employees with suspended or canceled Government contractor-issued travel charge cards


4. All employees who do not fall into one of the categories outlined in paragraph (3) must obtain and use a Government contractor-issued travel card unless the employee obtains a specific exemption from the IRS Associate Chief Financial Officer for Internal Financial Management.



1. Any employee who wishes to apply for such an exemption must submit a request to the IRS CFO Policies and Procedures office, identifying the particular reason why the exemption is requested (e.g., religious objections to the use of any type of credit card).


5. Unless a specific exemption applies, Counsel travelers should not use their own funds or personal credit cards for travel expenses such as airfare or other common carrier transportation. However, there are certain other expenses where it is not necessary to use the government travel charge card:



   - Vendors who do not accept the card

   - Laundry/dry cleaning

   - Parking

   - Local transportation and taxis

   - Tips

   - Meals and incidental expenses that are less than $15.00

   - Certain relocation expenses, such as real estate transactions


**30.5.2.3.2.1** **(02-15-2007)**

##### Misuse of Travel Charge Card

1. The Government contractor-issued travel charge card may only be used for official business (meaning official Government travel-related expenses). It should not be used for personal travel or other personal expenses.

2. Personal use of a Government contractor-issued travel charge card may subject an employee to discipline, up to and including removal.

3. Employees must also take care to promptly pay all the amounts due on any Government contractor-issued travel charge card. Delinquencies in payment could result in serious discipline from management and/or suspension or cancellation of the card by the contractor.


**30.5.2.3.3** **(02-28-2014)**

#### Travel Arrangements

01. Counsel travelers must make all ticket reservations for official travel through RESX, the web-based self-booking travel reservation system, or the Scheduled Airline Travel Office (SATO), IRS’ nationwide travel management center. See IRM 1.32.11, Official IRS City-to-City Travel Guide.

02. Arrangements for travel which is within the following parameters should utilize the RESX system:



    - Official government business only

    - Air transportation service

    - Domestic destinations or an International single destination point

    - Government air fares

    - Coach-class service

    - Electronic tickets (e-tickets)

    - Individual government travel card transactions


03. Arrangements for travel consisting of one of the following elements should be made by contacting SATO:



    - Booking Amtrak reservations

    - Booking a restricted penalty fare

    - Booking a flight on Air Tran or another smaller exception carrier

    - Canceling a reservation after tickets have been issued

    - Changing a reservation after tickets have been issued

    - Combining official and personal travel

    - Traveling within the next 24 hours

    - Traveling with a disability and/or special need (e.g., two seats required, companion travel required, service dogs)

    - Traveling to multiple international cities

    - Using the Centrally Billed Account (CBA) for transportation charges (the employee does not have an Individually Billing Travel Account (IBA)


04. If an employee is exempt from the requirement to use a Government contractor-issued travel charge card, then the employee may use personal funds to purchase a common carrier transportation ticket (if the ticket costs $100 or less) or use a centrally billed account (Corporate Credit Card).

05. Counsel employees must follow the procedures in IRM 1.32.11.10.1, Arranging for Travel Services, regarding use of contract carriers between city pairs.

06. Travelers shall ordinarily use coach accommodations (lower than first class). Pursuant to Treasury Directive 74-13, first-class accommodations may be approved only by the Commissioner. Premium-class other than first-class accommodations may be approved only by the Commissioner or Deputy Commissioner. First-class accommodations may only be approved under the following conditions:



    1. No less than first class service is reasonably available

    2. When use of first-class is necessary to accommodate a disability or other special need (this may include a continuing approved authorization that must be included with any such voucher)

    3. When exceptional security circumstances require first-class travel

    4. When required because of agency mission


07. Premium-class other than first class accommodations may only be approved under the following conditions:



    1. No less than premium class service is available

    2. No space is available in coach-class accommodations in time to accomplish the mission, which is urgent and cannot be postponed

    3. When use of premium-class is necessary to accommodate a disability or other special need (this may include a continuing approved authorization that must be included with any such voucher)

    4. Security purposes or exceptional circumstances make the use of premium-class essential to the successful performance of the mission

    5. Coach-class accommodations on an approved foreign air carrier do not provide adequate sanitation or health standards

    6. The use results in an overall cost savings to the Government by avoiding additional subsistence costs, overtime, or lost productive time

    7. The transportation costs are paid in full through agency acceptance of payment from a non-Federal source (such acceptance is currently not authorized by Service policy)

    8. Where the origin and/or destination is Outside the Continental United States (OCONUS) and the scheduled flight time is in excess of 14 hours

    9. When required because of agency mission


08. Travelers may upgrade at their own expense ( _i.e._, by using frequent-flyer points to upgrade). Such upgrades do not require approval since no Government funds are used.

09. Travel by personally owned automobile (POA) can be allowed if it is advantageous to the Government (for example, the cost of round trip mileage being less than round trip air fare or several travelers traveling in one automobile being less than their combined round-trip air fare).



    1. If the employee wants to travel by automobile for personal convenience, and commercial travel would cost less, the traveler must claim the cost of the round trip fare plus any other transportation costs, not the actual cost of mileage by POA. The round trip mileage costs must be compared to the commercial cost on the travel voucher.

    2. The traveler is then reimbursed as if the travel had been performed by commercial means.

    3. Any travel time during working hours used in excess of the time needed to travel commercially must be charged to annual leave or leave without pay.


10. If a traveler has followed all procedures to obtain accommodations, and then the airline fails to provide service because of overbooking or cancellation of the reservation, the traveler is responsible for collecting the repayment and submitting it with their travel voucher as soon as possible.



    1. Government employees should not give up their seats voluntarily if doing so would impair the performance of their official duties, or result in a delay in returning to their post of duty during their official hours of duty or other cost to the Government.

    2. If an employee chooses to voluntarily give up his or her seat and the employee’s travel time is extended due to this, any regular work hours missed must be charged to annual leave or leave without pay.

    3. An employee who voluntary gives up his or her seat and complies with these restrictions may keep any compensation provided by the airline.


**30.5.2.3.4** **(02-15-2007)**

#### Travel Expenses

1. This subsection provides procedures for travel advances and the reimbursement of travel expenses.


**30.5.2.3.4.1** **(02-28-2014)**

##### Travel Advances

1. A traveler may request an advance of funds for per diem and miscellaneous expenses expected to be incurred during the planned travel.

2. The maximum travel advance that will be approved is the total cost of the estimated number of days of per diem and the local costs for transportation (i.e., to and from the airport or train station).

3. Travel advances are processed and approved through GovTrip. GovTrip is also used to approve travel and to reimburse travelers upon entry of their voucher expense information. Information about GovTrip can be found in:



   - IRM 1.32.1, Official IRS Local Travel Guide

   - IRM 1.32.11, Official IRS City-to-City Travel Guide

   - GovTrip Traveler's Toolkit


4. Travelers who have a Government contractor-issued travel charge card (see CCDM 30.5.2.3.2) may request automated teller machine (ATM) privileges.



1. ATM privileges can be granted if the traveler has a record of prompt payment of their travel expenses.

2. Requests for ATM privileges must be approved by the Associate Chief Counsel (F&M) or his/her designee.

3. ATM privileges are to be used in lieu of travel advances


**30.5.2.3.4.2** **(02-28-2014)**

##### Reimbursement of Travel Expenses

1. Travelers are required to enter their voucher expense information into GovTrip immediately following their return from travel status. Detailed information regarding how claims for reimbursement of expenses are to be filed may be found on that system or in IRM 1.32.1 and/or IRM 1.32.11 . Managers approve the expenses in GovTrip, and reimbursement is made via Electronic Fund Transfer (EFT) to the traveler’s bank account.

2. Travelers can be reimbursed for subway, bus, limousine, or taxi fares (including tips) to and from the airport or station and post of duty, residence, or hotel. These costs are not included in the per diem rate and are claimed separately on the travel voucher. In the interest of economy, subways, buses or limousines should be used in lieu of taxis wherever possible.

3. Travelers can be reimbursed for the use of privately owned automobiles (POA) from residence or post of duty to the airport or train station and return, in lieu of local transportation, if the cost of mileage and parking fees, if any, do not exceed the cost by commercial means. Current rates are provided at the Employee Resource Center (ERC) website.

4. Per diem is a rate of reimbursement established annually by GSA. Per diem is provided in lieu of a detailed submission of expenses covering meals, lodging, tips and other miscellaneous expenses. Information on the most current per diem rates can be found via the ERC website or [http://www.gsa.gov/](http://www.gsa.gov/).

5. Receipts are required to substantiate reimbursement only where those expenses exceed (75 for a specific expenditure. Receipts do not have to be submitted for non-lodging expenses that are less than $75.

6. See IRM 1.32.1, Official IRS Travel Guide, and IRM 1.32.11, Official IRS City-to-City Travel Guide, for full discussions of allowable expenses.


**30.5.2.3.4.2.1** **(02-28-2014)**

###### Authorization of Actual Expense

1. Actual expenses can be authorized when the actual and/or necessary subsistence expenses exceed the maximum per diem allowance by 10% or more and the traveler has no alternative but to incur hotel costs which absorb all or nearly all of the maximum per diem allowance.

2. The authority to approve actual expenses for travel, with the exception of foreign travel, is delegated to the Associates Chief Counsel and Division Counsels (see Delegation Order 1-5, Reimbursement for Actual Expenses, in IRM 1.2.40.6, Delegation of Authority for Organization, Finance and Management Activities). When the unusual circumstances of the travel assignment justify the decision, the Associates Chief Counsel and Division Counsels, or their designees, may:



1. Authorize or approve reimbursement for subsistence expenses on an actual expense basis

2. Authorize, in advance of performance of travel, appropriate per diem allowances in lieu of actual subsistence reimbursement for travel to high rate geographical areas


3. Travelers should submit requests for authorization of actual expenses prior to the planned travel through GovTrip or through the use of Form 13635.

4. Each Associate Chief Counsel and Division Counsel will be responsible for establishing appropriate procedures for approval of actual expenses within their organization.


**30.5.2.4** **(02-28-2014)**

### Relocation At Government Expense

1. The Associate Chief Counsel (F&M) is authorized to approve changes in post of duty (relocation) at Government expense. Information on relocation allowances is found in IRM 1.32.13,Relocation Services Program.

2. Counsel employees authorized to relocate should contact their administrative officers to initiate the appropriate paperwork and procedures.


**30.5.2.5** **(02-28-2014)**

### Foreign Travel

1. Advance approval of all travel outside the United States will be obtained from the Deputy Chief Counsel (Technical) or the Chief Counsel by the Associate Chief Counsel (International), prior to the issuance of Form 1321, Authorization for Official Travel.

2. Guidelines for official travel outside the continental United States including authorizations, computing reimbursement in accordance with per diem rates and regulations, and passport and immunization requirements, can be found at the following:



   - IRM 1.32.11.8.5, Foreign Travel

   - [Department of State](http://www.travel.state.gov/)

   - [General Services Administration](http://www.gsa.gov/)

   - [Department of Homeland Security](http://www.dhs.gov/index.shtm)

   - [Department of Defense](http://www.defense.gov/)


3. Any office contemplating official foreign travel by an employee under their jurisdiction should send the Associate Chief Counsel (International) a memorandum stating:



1. The purpose of the travel

2. The country or countries to be visited

3. The complete itinerary

4. Whether an official passport is required

5. An estimate of the travel expenses (transportation, per diem, and other)


### Note:

This memorandum should be received by the Associate Chief Counsel (International) in sufficient time (at least 20 work days) to allow for securing the necessary approvals and the processing of a passport application, if required.

4. Chief Counsel employees traveling to foreign countries on official business must obtain a valid United States official passport. A regular tourist passport is not appropriate for official travel.



1. The Department of State does not object to the use of an official passport for incidental personal travel by personnel going to or from an assignment abroad, provided the foreign governments concerned do not object to the use of the passport for unofficial travel. However, if the personal travel planned is extensive, the traveler must obtain a tourist passport.

2. A person may simultaneously possess both a valid tourist passport and a valid official passport. If an official passport is required, the office will pay for the expenses associated with obtaining one.

3. Questions regarding these procedures should be addressed to the office of Associate Chief Counsel (International).


**30.5.2.6** **(02-15-2007)**

### Promotional Items, Including Frequent Flyer Miles

1. Counsel employees may retain for personal use promotional items received during the course of an official business trip if such items are obtained under the same conditions as those offered to the general public at no additional cost to the Government.

2. These guidelines apply to any promotional items received by employees in the past or to be earned or received in the future.

3. Promotional benefits include free tickets and upgrades obtained through the redemption of accumulated frequent flier mileage points, hotel and car rental coupons, etc. Travelers are responsible for tracking their own points/benefits. Any costs associated with establishing a frequent flier account are personal expenses which are borne by the employee.

4. An employee cannot travel by non-contract carrier solely to earn more mileage points with that carrier, even if the non-contract carrier offers a matching fare.

5. As explained in CCDM 30.5.2.3.2, all frequent travelers must use the Government contractor-issue travel charge card. Therefore, a traveler should not charge an airline ticket or other expense, which should be charged to the Government card, to a personal credit card in order to take advantage of points and other benefits obtainable through the personal card.


**30.5.2.7** **(02-28-2014)**

### Travel Gainsharing

1. The Office of Chief Counsel has a Travel Gainsharing program which rewards employees who save government money through their own initiative. This is a voluntary program that operates under the guidelines below.

2. Counsel employees on official travel may receive cash awards of 50% of the combined savings from the following five categories:



   - Lodging costs that are less than the locality rate

   - Sharing a hotel room with one other government traveler (each traveler saves 1/2 of the single daily lodging rate times the number of days)

   - Staying with friends or family which results in zero lodging costs

   - Using frequent flyer miles accumulated from government or personal travel to purchase an airline ticket for official use

   - Traveling on his/her own time to/from official training programs or Division-wide meetings (with prior management approval) if the employee attends the entire program or meeting and reports to duty the day following the conclusion of the program or meeting


### Example:

One night’s lodging cost can be claimed if an employee goes to a training class ending at 5 p.m. on Thursday but the employee gets permission to travel home Thursday night and, therefore, incurs no additional lodging costs and reports to work on Friday morning instead of traveling home on Friday.

3. All Counsel employees on official travel status, either foreign or domestic, who save a minimum of $100 per fiscal year, are eligible for Travel Gainsharing awards of 50% of the savings.



### Example:



An employee who saves a combined total of $300 in lodging and airline tickets during the fiscal year will receive $150 at the end of the fiscal year. The employee will receive a SF 50 showing the award amount and the amount will be included on the employee’s Form W-2. Taxes and other applicable deductions will be withheld from the award amount.

4. Employees must comply with all travel requirements in IRM 1.32.14, Gainshairing Travel Savings Program, in order to qualify for the award.

5. Employees have the responsibility to track savings and submit Form 13631, Travel Savings Form – Office of Chief Counsel, with each travel voucher filed where savings have resulted. Once an employee’s aggregate savings reach or exceed $100, the employee should notify their manager that the $100 minimum savings has been reached and he/she is now eligible for a Travel Gainsharing Award which will be payable in total after the end of the current fiscal year.

6. Employees on travel during the last two weeks of the fiscal year should submit their forms within two weeks after the end of the fiscal year. Employees who do not submit completed forms timely will not receive awards for those periods.

7. The following exclusions apply:



1. Relocation travel is not covered under this program.

2. No Gainsharing awards will result from weekend travel to an alternate location.

3. Awards will not be made to individual employees on travel where lodging savings were the result of being prearranged by someone else or prepaid by contract with the hotel.

4. Hotel lodging costs must be paid with the government contractor issued travel card in order to qualify for inclusion under this program.

5. Lodging costs incurred on personal time such as leave will not be counted as savings under this program.


**Exhibit 30.5.2-1**

### Counsel Travel Types and Codes

| **_TYPE_** | **_DESCRIPTION_** | **_GovTrip CODE_** |
| --- | --- | --- |
| Case Related | All travel expenses related directly to specific cases. Special Trial Attorney travel is managed and approved by the Deputy Division Counsel (Large Business and International). | C |
| Training | All travel expenses to attend Counsel sponsored or individual training. | T |
| Meetings, Conferences and Speeches | All travel expenses related to attendance at or performance of responsibilities at meetings, conferences or speeches. | M |
| Long Term Taxable Travel | Travel of one year or longer duration which may result in Federal, state and local income tax liabilities. | L |
| Official Union Travel | Travel of employees on official union business. | U |
| General | Travel which is not otherwise defined. | G |
| Employee Relocation | Employee transfers that are authorized as "beneficial to the Government" . | \* |
| System Compatibility Testing | Travel which is authorized specifically to test information systems. | S |

\\* Manual vouchers only

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part30/irm_30-005-002#addtoany "Show all")

A2A