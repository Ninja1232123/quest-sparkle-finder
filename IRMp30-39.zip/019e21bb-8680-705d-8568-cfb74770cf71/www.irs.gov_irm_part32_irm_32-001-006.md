---
url: "https://www.irs.gov/irm/part32/irm_32-001-006"
title: "32.1.6 Review, Approval, and Publication of Regulations | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part32/irm_32-001-006#main-content)

- 32.1.6  [Review, Approval, and Publication of Regulations](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524209639616)
  - 32.1.6.1  [Coordination with Division Counsel and IRS Offices](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182871024)
  - 32.1.6.2  [Coordination with Associate Offices and Counsel for the National Taxpayer Advocate](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182707936)
  - 32.1.6.3  [Reconciliation Procedures](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182808672)
  - 32.1.6.4  [Review of Drafts](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182804976)
    - 32.1.6.4.1  [Review by Federal Register Liaison (FRL)](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182803360)
    - 32.1.6.4.2  [Review within the Associate Chief Counsel Offices](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182706368)
    - 32.1.6.4.3  [Review by OTP Attorney-Advisors](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182293968)
  - 32.1.6.5  [Briefings](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182291600)
  - 32.1.6.6  [Precirculation Draft](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182288912)
  - 32.1.6.7  ["Green" Circulation Draft](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524209762016)
    - 32.1.6.7.1  [Executive Summary](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524209757680)
    - 32.1.6.7.2  [Circulation Draft Routing and Distribution (Green Circulation)](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524209777184)
    - 32.1.6.7.3  [Special Note for TEGE Regulation Projects Regarding Circulation Drafts](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182700160)
    - 32.1.6.7.4  [Due Date for Review Responses](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182698160)
  - 32.1.6.8  [Pink Signature Package](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182696176)
    - 32.1.6.8.1  [Contents of Signature Package](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182689888)
    - 32.1.6.8.2  [Background Memorandum](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182860416)
    - 32.1.6.8.3  [Plain Language Summary](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182858304)
    - 32.1.6.8.4  [Clearance Chain for Signature Package](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182854080)
    - 32.1.6.8.5  [Informational Copy to Division Counsel and TIGTA](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182791280)
    - 32.1.6.8.6  [Special Instructions for Document Submission to Treasury](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182788528)
  - 32.1.6.9  [Administrative Procedure Following Treasury Approval](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182784832)
    - 32.1.6.9.1  [Schedule Hearing Room for NPRM](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182782448)
    - 32.1.6.9.2  [Advise by Email of Pending Publication of Regulation](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182779072)
  - 32.1.6.10  [Publication in the Federal Register](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182843840)
    - 32.1.6.10.1  [Filing and Publication](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182836672)
      - 32.1.6.10.1.1  [Immediate Filing and Emergency Publication](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182833712)
      - 32.1.6.10.1.2  [Obtaining Filing and Publication Dates and TD Number](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182829392)
    - 32.1.6.10.2  [After Obtaining Filing and Publication Dates](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182827520)
      - 32.1.6.10.2.1  [Prepare Filing Date Submissions to the Publications and Regulations Branch](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182821600)
      - 32.1.6.10.2.2  [Electronic Copy of Document](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182816032)
      - 32.1.6.10.2.3  [Form 14712, IRB Submission Memorandum and Record Forms](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524182810416)
      - 32.1.6.10.2.4  [Congressional Review Act Forms](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524178611264)
    - 32.1.6.10.3  [Notify Legislative Affairs on the Filing Date](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524178581488)
  - 32.1.6.11  [Post-Publication Administrative Duties](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524178577504)
    - 32.1.6.11.1  [Proofreading After Publication](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524178575712)
    - 32.1.6.11.2  [Filing Signed Congressional Review Act Submissions Acknowledgement of Receipt Forms](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524178570576)
  - Exhibit  32.1.6-1  [Sample Executive Summary](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524178566192)
  - Exhibit  32.1.6-2  [Sample Green Circulation Draft Routing Slip](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524178547408)
  - Exhibit  32.1.6-3  [Sample Pink Signature Package Routing Slip](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524178529056)
  - Exhibit  32.1.6-4  [Instructions for Processing Regulations](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524178527056)
  - Exhibit  32.1.6-5  [Congressional Review Act Form](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524178492624)
  - Exhibit  32.1.6-6  [Instructions for Completing Congressional Review Act Form](https://www.irs.gov/irm/part32/irm_32-001-006#idm140524178489392)

# Part 32. Published Guidance and Other Guidance to Taxpayers

# Chapter 1. Chief Counsel Regulation Handbook

# Section 6. Review, Approval, and Publication of Regulations

* * *

## 32.1.6 Review, Approval, and Publication of Regulations

#### Manual Transmittal

November 13, 2019

#### Purpose

(1) This transmits revised CCDM 32.1.6, Regulation Handbook, Review, Approval, and Publication of Regulations

#### Material Changes

(1) CCDM 32.1.6.7 is revised to state that the Office of Tax Analysis will be contacted before the green circulation and to require that the Office of Tax Analysis be included in the green circulation..

#### Effect on Other Documents

This section supersedes CCDM 32.1.6, dated August 2, 2018.

#### Audience

Chief Counsel

#### Effective Date

(11-13-2019)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**32.1.6.1** **(08-02-2018)**

### Coordination with Division Counsel and IRS Offices

1. The Office of Associate Chief Counsel is solely responsible for drafting and preparing published guidance. Division Counsel may assist the Associate Chief Counsel in developing published guidance. The drafting team should coordinate all projects with each Division Counsel office through their publication coordinator or designee. Each Division Counsel publication coordinator or designee is responsible for further coordination within its respective Operating Division. Any comments made by Division Counsel should be made by an employee with authority to speak on behalf of, and bind, the Division Counsel.

2. When work is initiated on a project, the drafting team should email each Division Counsel publication coordinator or designee within 30 days after the opening of the project on TECHMIS to alert the Division Counsel that the project has been opened. See CCDM 32.1.6.2 for additional email recipients. The email should contain:



   - Description of the issue to be addressed by the project

   - Taxpayers affected

   - Reasons for publication

   - Target publication date (and any other timing considerations)

   - Name and telephone number of drafting attorney


3. Each Division Counsel publication coordinator or designee must promptly respond as to whether their office wants to be involved in the development of the project. Alternatively, the Division Counsel publication coordinator or designee may indicate that their office does not need further information about the project.

4. The initial coordination does not preclude the Division Counsel publication coordinator or designee from reconsidering its choice at a later time, and requesting further involvement in (or no further information about) the project. Similarly, the Associate Chief Counsel office may later request a higher level of involvement by the Division Counsel office.

5. If a Division Counsel office requests involvement in the development of a project, the respective reviewer and Division Counsel publication coordinator or designee will determine the scope of the participation as soon as possible. This involvement will vary but, at a minimum:



   - Send the Division Counsel publication coordinator or designee all issues and policy memoranda and invite the Division Counsel publication coordinator or designee to attend any preliminary meetings to discuss the issues and policy memoranda (see CCDM 32.1.3.4, Issues Memorandum)

   - Invite the Division Counsel publication coordinator or designee to briefings of Treasury, Counsel, or IRS executives (see CCDM 32.1.6.5)

   - Send the Division Counsel publication coordinator or designee a copy of the green circulation draft (see CCDM 32.1.6.7)


**32.1.6.2** **(08-02-2018)**

### Coordination with Associate Offices and Counsel for the National Taxpayer Advocate

1. In addition to the coordination with Division Counsel and IRS Offices described in CCDM 32.1.6.1 above, when work is initiated on a project, the drafting team should email each Associate Office and the Counsel for the National Taxpayer Advocate within 30 days after the opening of the project on TECHMIS to alert those offices that the project has been opened. The email should contain the information and follow the procedures described in CCDM 32.1.6.1.


**32.1.6.3** **(08-11-2004)**

### Reconciliation Procedures

1. Absent extraordinary circumstances, reconciliation should begin by the drafting team requesting reconsideration and providing the reasons for its disagreement to the office/person that provided the advice or assistance. If that office/person adheres to its views after reconsideration, the drafting team must follow the advice or assistance or elevate the request for reconsideration to the next higher level.

2. A request for reconsideration of branch-level advice should be elevated to the Associate Chief Counsel of the office within which the branch is located, as applicable. A request for reconsideration at a higher level within the National Office should be made by the appropriate branch or the appropriate Associate Chief Counsel.

3. When coordination with another branch or office is completed, the drafting team should make a record for the legal file containing the name of the person with whom it coordinated, their office or branch symbols, and the date coordinated. This record should also reflect any unresolved disagreement. If the Associates are unable to reconcile their views, the matter should be elevated to the Deputy Chief Counsel or the Chief Counsel. The Associates will reconcile differing views and will ensure that the package that goes forward contains an analysis of all significant issues.


**32.1.6.4** **(08-02-2018)**

### Review of Drafts

1. During the development of the regulation, various individuals review drafts.


**32.1.6.4.1** **(09-20-2011)**

#### Review by Federal Register Liaison (FRL)

1. After the first working draft of the regulation is completed and has been approved by the branch reviewer, and prior to the Associate Chief Counsel review, the drafting team must provide a copy of the draft to the assigned FRL for review. The drafting team must also provide a copy to the FRL for review before circulating the draft regulation in green circulation and in signature package. The drafting team should not send the regulation forward in green circulation and in signature package until the regulation has been reviewed by the FRL and the FRL’s changes have been made to the regulation.


**32.1.6.4.2** **(09-20-2011)**

#### Review within the Associate Chief Counsel Offices

1. The branch reviewer or other designated reviewer initially reviews all regulation drafts. The Associate Chief Counsel or any other front office reviewers also review regulation drafts. Any reviewer may ask other Associate offices to review the draft and provide comments.

2. When the Associate Chief Counsel office or offices have completed their review of the regulation, the drafting attorney prepares the "Green" Circulation Draft. See CCDM 32.1.6.7.


**32.1.6.4.3** **(08-02-2018)**

#### Review by OTP Attorney-Advisors

1. Depending on the complexity and significance of the issues, the OTP attorneys may begin participation or review early in the drafting stage. If not already involved, during the period of Associate Chief Counsel front office review of regulation drafts, one or more OTP attorneys may review drafts.

2. Green circulation review generally occurs after consultation with Treasury.


**32.1.6.5** **(08-02-2018)**

### Briefings

1. Significant regulation projects may be briefed to the Chief Counsel or Deputy Chief Counsel, Associate Chief Counsel, the Commissioner/Deputy Commissioner (or other IRS executives), and to Treasury executives. Consult with the Associate front office to obtain any special procedures for these briefings. The drafting team should prepare a Conference Report after any briefings to memorialize the decisions reached. The conference report should be distributed to everyone who attended the briefing.

2. If a Division Counsel office has requested to be involved in the development of the project, invite the Division Counsel publication coordinator or designee to briefings of Counsel, Treasury, or IRS executives.


**32.1.6.6** **(08-11-2004)**

### Precirculation Draft

1. A precirculation draft is a preliminary draft that is circulated among members of the drafting team (including OTP attorneys, when appropriate) for review and comments. The drafting team may produce many precirculation drafts before the regulation is distributed outside the initiating Associate Chief Counsel office. Each precirculation draft should contain a draft identification block (see CCDM 32.1.4.3, Draft Identification Block) so that the members of the drafting team can easily distinguish the current from prior drafts.


**32.1.6.7** **(11-13-2019)**

### "Green" Circulation Draft

1. The "green" circulation draft is a draft approved for distribution outside the initiating Associate Chief Counsel office to other Counsel and IRS offices that have been involved in the project, or will be affected by it, for their review and comment. Circulation drafts are reviewed and approved by, or on behalf of, the initiating Associate Chief Counsel prior to circulation. The circulation draft is also reviewed by the FRL prior to circulation. The drafting team should not send the regulation forward in green circulation until the regulation has been reviewed by the FRL and the FRL’s changes have been made to the regulation. Generally, the OTP Attorney Advisor assigned to the regulation will ensure the Office of Tax Analysis has been made aware of the guidance before green circulation.

2. If the drafting team revised the document in response to comments to the circulation draft, the drafting attorney should send the revised draft and a compare version (showing all the changes that were made to the circulation draft) to the offices/persons who may be interested in the changes. If significant changes are made to the green circulation draft, it may be necessary to distribute a new circulation draft before preparing the signature package. If the drafting team did not make the suggested substantive changes, the drafting team should contact the office/person who suggested the change and attempt to resolve any differences utilizing the reconciliation procedures described in CCDM 32.1.6.3.


**32.1.6.7.1** **(08-02-2018)**

#### Executive Summary

1. The drafting team should prepare an Executive Summary for regulations. The Executive Summary generally should be no longer than a page. The Executive Summary may be in bullet format. The Executive Summary should not include the detail and background that more appropriately should be included in the Background Memorandum described in CCDM 32.1.6.8.2. The Executive Summary should include:



   - Description of the guidance,

   - Why/how guidance was initiated,

   - What taxpayers are impacted by the guidance,

   - Names of persons with whom the drafting attorney coordinated the guidance and the outcome of that coordination,

   - Other government agencies (e.g. Social Security Administration, Railroad Retirement Board, and Department of Labor) with whom the drafting attorney coordinated the guidance, and the outcome of that coordination,

   - Impact on pending litigation and coordination with Department of Justice, as appropriate,

   - Whether the guidance is controversial (either internally or externally), and

   - Critical dates, if any, for publication (For example, the date that a temporary regulation will expire, the deadline for filing season readiness, ABA meeting, end of the calendar year, etc. The target publication date is not a critical date.).


2. The Executive Summary should be sent together with the "green" circulation draft of regulations. The Executive Summary should be updated to reflect the results of coordination (including the names of the persons with whom the project was coordinated), and included in the orange folder containing the "pink" signature package.

3. The Executive Summary should be made part of the official file for the guidance project. Since it is a predecisional document that is used to obtain approval for publication, however, the Executive Summary generally may be withheld (or redacted) under the deliberative process privilege if the file is the subject of a FOIA or discovery request. See Exhibit 32.1.6-1, Sample Executive Summary.


**32.1.6.7.2** **(11-13-2019)**

#### Circulation Draft Routing and Distribution (Green Circulation)

1. Ordinarily, the drafting team should distribute the circulation draft via email with a brief message explaining that the attached draft regulation is being circulated for general comment and the due date for comments. Accommodate any executive who wants a paper copy of the circulation draft. Attach a Circulation Draft routing slip, printed on green paper, to any paper copy distributed.

2. Although the distribution list for the circulation draft will vary by regulation, the general distribution list includes:



   - Deputy Assistant Secretary (Regulatory Affairs)

   - Tax Legislative Counsel, Benefits Tax Counsel, or International Tax Counsel, as appropriate

   - Appropriate TLC Attorney/Accountant Advisor(s)

   - Office of Tax Analysis

   - Deputy Chief Counsel (Technical) or Deputy Chief Counsel (Operations), as appropriate

   - Other executives and key front office attorneys in Counsel and IRS (other than LM, SB, W&I and TE/GE) offices that will be or could be affected by the regulation project, including all Associate Chief Counsel and their publication coordinators or designees

   - Other executives and other key attorneys in Counsel and IRS offices that were involved in drafting the document

   - Division Counsel, their publication coordinators or designees, and any Operating Division executive designated by a Division Counsel

   - Any internal distribution within the initiating Associate Chief Counsel office

   - Federal Register Liaison

   - Chief, Appeals and key staff

   - National Taxpayer Advocate and Counsel to the National Taxpayer Advocate

   - Director, Tax Forms and Publications and Technical Advisor to the Director, Tax Forms and Publications

   - Director, National Public Liaison

   - Management and Program Analyst, Office of Privacy


3. The Office of Treasury Inspector General for Tax Administration (TIGTA) should be sent a separate email at Counsel.Office@tigta.treas.gov that contains only the green circulation email and the draft regulation. Do not send the executive summary to TIGTA.

4. Division Counsel offices review circulation drafts and generally handle all coordination with Operating Division offices. Occasionally, the drafting team should coordinate directly with the affected Operating Division.



> **_Example_ of a Green Circulation Draft Email Message:**
>
> **Subject:** Green Circulation Draft of Regulations for Comments and Executive Summary - \[Project Name\]
>
> **CASE-MIS Number:** REG-123456-11
>
> **Target Publication Date:**October 31, 2011
>
> **Please provide comments by:** September 20, 2011
>
> **Regulation Project Summary:**\[include a very brief summary, including any relevant background\]
>
> **Please send comments to:**Jane B. Attorney
>
> Office:
>
> Room:
>
> Phone:
>
> FAX:





### Note:



See Exhibit 32.1.6-2, Sample Green Circulation Draft Routing Slip (which is always printed on green paper, when used)


**32.1.6.7.3** **(08-02-2018)**

#### Special Note for TEGE Regulation Projects Regarding Circulation Drafts

1. For certain regulation projects originating within the Associate (Tax Exempt and Government Entities), the drafting team must submit a circulation draft to another federal agency, for example, the Department of Labor or the Pension Benefit Guaranty Corporation. The extent and timing of this coordination is determined by the nature of the project. The drafting team should discuss with the front office any questions about this process including whether it applies to a particular regulation project.


**32.1.6.7.4** **(08-11-2004)**

#### Due Date for Review Responses

1. Unless the initiating Associate Chief Counsel office requests comments by an earlier date, offices have 14 calendar days to review initial green circulation drafts and provide any comments (whether an ANPRM, NPRM, or a TD). Unless the initiating Associate Chief Counsel office requests comments by an earlier date, offices generally have 7 calendar days to review subsequent circulation drafts.


**32.1.6.8** **(08-02-2018)**

### Pink Signature Package

1. The signature package contains a group of documents, submitted to the Federal Register, through which the Chief Counsel, Commissioner (or Deputy Commissioner for Services and Enforcement), and Assistant Secretary for Tax Policy authorize publication of the ANPRM, NPRM, or TD in the Federal Register.

2. The drafting team should prepare a signature package once it is reasonably certain that all comments received from the green circulation draft have been considered and the regulation document will not change. The drafting team should not send the regulation forward in signature package until the regulation has been reviewed by the FRL and the FRL’s changes have been made to the regulation.

3. If a regulation is subject to significant time pressure (for example, when temporary regulations are about to sunset, see CCDM 32.1.1.2.3, Temporary Regulations), it may be necessary to distribute the green circulation draft and the signature package simultaneously.

4. Separate signature packages should be prepared for a temporary regulation and the cross-reference NPRM. The pink signature package routing slip for each signature package should reference the related temporary or cross-reference NPRM, as applicable.

5. The Associate office preparing and reviewing the signature package may have established its own review procedures for regulation projects. For example, the Associate office may wish to see background information not required in the formal signature package (such as comments received on the green circulation draft, and a compare version of the green circulation draft and the signature package draft). The drafting team should ensure that it complies with its Associate office’s procedures for signature packages.

6. The signature package delivered to the Commissioner’s office should include a "sign here" post-it note next to the signature space on the original print of the regulation.

7. The signature package moves through the Associate’s and Chief Counsel’s offices and the Commissioner’s office in a Chief Counsel Correspondence clearance folder. All of the documents in the signature package should be emailed to the appropriate office contemporaneously with delivery of the clearance folder.

8. The signature package should be delivered to Treasury electronically. For documents that are not TDs, a scanned image of the signature page containing the Deputy Commissioner’s signature should be added to the signature package when it is sent to Treasury. For TDs (including temporary regulations), the original signature page must be delivered to Treasury.


**32.1.6.8.1** **(08-02-2018)**

#### Contents of Signature Package

1. A signature package consists of:



   - The regulation signature package routing slip and clearance sheet, printed on pink paper (the pink sheet)

   - The Executive Summary (see CCDM 32.1.6.7.1)

   - A single-sided copy of the regulation for signature (remove the draft identification block from regulation before printing)

   - The Background Memorandum (if appropriate) (see CCDM 32.1.6.8.2)

   - The plain language summary (see CCDM 32.1.6.8.3)

   - A Regulatory Flexibility Act checklist (see CCDM 32.1.5.4.7.5.4.7, RFA Checklist)


2. The signature package moves through the Associate’s and Chief Counsel offices by paper copy and electronically by email. Any person who makes changes to the signature package documents provide the changes to the drafting attorney, and the drafting attorney is responsible for updating the signature package to reflect any changes made during the clearance process . See Exhibit 32.1.6-3, Sample Pink Signature Package Routing Slip.


**32.1.6.8.2** **(08-02-2018)**

#### Background Memorandum

1. The drafting team should consider including a short background memorandum . The background memorandum should discuss any cases affected by the regulation that are not discussed in the clearance sheet or preamble, any potential controversy that may arise from the regulation, any effective date concerns, and if there were any significant disagreements with the Operating Divisions or among Counsel offices during the drafting process. The background memorandum will be used by the executives to readily identify any issues that should be considered before clearing the regulation.


**32.1.6.8.3** **(08-02-2018)**

#### Plain Language Summary

1. The drafting team must prepare a plain language summary for each stage of a regulation project (ANPRM, NPRM, temporary regulation, final regulation).

2. The plain language summary explains, preferably in six sentences or less, the issue addressed by the regulation, but does not summarize the regulation. The target reader is someone who is not familiar with the tax law. Therefore, the drafting team should avoid references to Code sections and terms of art. The summary alerts the taxpayer to whether he or she is affected by the regulation, needs more information, or needs to consult a tax advisor. At the end of the plain language summary, add the reference number (the CASE-MIS ID number for an ANPRM or NPRM or the TD number for a TEMP or final regulation) and the date the regulation is published in the Federal Register.



### Example:



Integrated Auxiliary of a Church


While most tax-exempt organizations are required to file a report with the IRS, churches and some affiliated organizations are not required to meet this reporting requirement. These regulations explain the test that an affiliated organization must meet to be considered an integrated auxiliary of a church and thus exempt from the reporting requirement. REG-123456-11. Published \[insert publication date\].


**32.1.6.8.4** **(08-02-2018)**

#### Clearance Chain for Signature Package

1. After the drafting attorney assembles and proofreads the signature package, the drafting attorney and reviewer sign the pink sheet. Hand-carry the signature package to each Counsel or IRS office and to Treasury for TDs (including temporary regulations) in the clearance chain for signature. The clearance chain may vary by regulation and by Associate office but generally includes the following:



   - Drafting attorney

   - Branch reviewer

   - Front Office reviewer

   - Associate Chief Counsel

   - Chief Counsel

   - Deputy Chief Counsel (Technical) or Deputy Chief Counsel (Operations), as appropriate

   - Assistant to the Commissioner

   - Commissioner/Deputy Commissioner for Services and Enforcement

   - Treasury Attorney-Advisor

   - Tax Legislative Counsel, Benefits Tax Counsel, or International Tax Counsel, as appropriate

   - Assistant Secretary (Tax Policy)


2. After each office within Counsel and the IRS has signed the pink sheet, that office calls the Associate office to pick up the signature package and deliver the signature package to the next level of clearance. The Associate office, in its discretion, may contact the drafting attorney to pick up the signature package and move the package forward. The pink sheet should reflect the phone number of the Associate office to call for pick up. The pink sheet should also include the drafting attorney’s name and direct phone number. Generally, the OTP attorney moves the document through the process at Treasury.


**32.1.6.8.5** **(08-02-2018)**

#### Informational Copy to Division Counsel and TIGTA

1. If the Division Counsel office requested involvement in the development of the project, the drafting team should email an informational copy of the regulation document in the signature package and a compare version of the green circulation draft to the signature package draft to the Division Counsel publication coordinator or designee. Division Counsel, however, is not included on the formal clearance of the signature package (see CCDM 32.1.6.8.4) and may not comment further on the signature package. All comments from Division Counsel should be considered and resolved before the clearance process begins.

2. The drafting team should also provide TIGTA an informational copy of the regulation when the regulation is sent to Treasury in Signature Package.


**32.1.6.8.6** **(08-02-2018)**

#### Special Instructions for Document Submission to Treasury

1. After the Commissioner/Deputy Commissioner for Services and Enforcement has signed the regulation and it is returned to the drafting attorney, the signature package is submitted to Treasury. Before submitting the signature package to Treasury, the drafting attorney should photocopy the signature page and place the photocopy in the legal file. This documents that the Commissioner/Deputy Commissioner for Services and Enforcement signed the regulation.

2. Treasury clears regulations electronically, and the clearance package should be emailed to Treasury to begin the clearance process. Create an electronic pink sheet by typing in the information (symbols, surnames of drafter and reviewers, and dates) contained on the actual pink sheet. Only the signature page of a TD (including temporary regulations) needs to be delivered to Treasury in hard copy.

3. To ensure deliver of the signature page to Treasury, the drafting attorney can either provide the signature page to the Publications and Regulations Branch who will hand deliver the page to the Treasury Department Information Resource Center, Room 5037, Main Treasury Building, to be processed and sent to the appropriate Treasury attorney or hand-deliver the signature page to Room 5037 or the Treasury attorney working on the regulation.


**32.1.6.9** **(08-02-2018)**

### Administrative Procedure Following Treasury Approval

1. After the Assistant Secretary (Tax Policy) , which includes signing the signature page for TDs (including temporary regulations), the regulation must clear the General Counsel and the Executive Secretariat. After clearance, Treasury returns the signed regulation and an electronic pink sheet to the drafting attorney. The drafting attorney should put a printed copy the electronic pink sheet in the legal file. If Treasury only provides an email with the names of clearing officials and the date each official approved the regulations, the drafting attorney should print the email for the legal file. A copy of the electronic pink sheet and, if applicable, Treasury email will need to be provided to the FRL during the publication process.


**32.1.6.9.1** **(08-11-2004)**

#### Schedule Hearing Room for NPRM

1. After Treasury approves an NPRM and notice of public hearing, the drafting team should contact the Publications and Regulations Branch to have a specialist assigned to the regulation to schedule and coordinate the hearing. If Treasury may approve the regulation during a holiday week, the drafting team should contact the Publications and Regulations Branch several days before the expected approval date to allow the specialist sufficient time to schedule a hearing room.

2. The drafting team must add the comments due date, hearing date, and requests to speak and outline due date to the DATES caption of the preamble. Add the hearing location (room number) to the ADDRESS caption. Add the Regulation Specialist contact to the FOR FURTHER INFORMATION CONTACT caption.

3. The drafting attorney should inform the Publications and Regulations Branch Specialist if the Associate office anticipates that an unusually large number of people will request to speak at, or otherwise attend, the public hearing.


**32.1.6.9.2** **(08-02-2018)**

#### Advise by Email of Pending Publication of Regulation

1. Once the regulation has been approved by Treasury and the Publications and Regulations Branch has received a filing and publication date from the OFR, the drafting team should inform the following addressees by email of the pending publication of the regulation:



   - The Chief Counsel

   - Deputy Chief Counsel (Technical) or Deputy Chief Counsel (Operations),

   - All Special Counsel, Senior Counsel, and Senior Legal Counsel to the Chief Counsel

   - All Associate Chief Counsel and Deputy Associate Chief Counsel

   - All Division Counsel

   - The Assistant to the Commissioner

   - The Tax Legislative Counsel (or Benefits Tax Counsel or International Tax Counsel, as appropriate)

   - Any other Treasury representatives involved in the project

   - Any other recipients determined by the Associate office


**32.1.6.10** **(08-02-2018)**

### Publication in the Federal Register

1. The drafting attorney provides the FRL with the following:



1. A copy of the electronic pink sheet and any Treasury email. This may be provided electronically.

2. The original signed regulation.

3. An electronic copy of the regulation by email. The email should contain the CASE-MIS project ID.


### Note:

Remove all "hidden" codes that allow recipients to view prior changes to the document by following instructions in CCDM 32.1.6.11.2.3.

2. After the FRL proofs the regulation for any required changes the FRL



1. Inserts the name of the signing official(s), the date the regulation was approved, and, any modification to the title of any approving official (for example, by adding "Acting" ) on the signed original regulation document, and

2. Prepares a letter to the OFR certifying that the electronic copy contains a true copy of the document and asking for filing and publication of the regulation.


3. The FRL makes three copies of the regulation and delivers the regulation and related documents to the staff of the Publications and Regulations Branch . The FRL notifies (via email) the drafting attorney and the other FRLs of the date the regulation was sent to the OFR.

4. The Publications and Regulations Branch delivers the documents to the OFR where it is reviewed for compliance with Federal Register publication requirements. If there are minor errors, the FRL will make "pen and ink" changes. For more substantial changes, the OFR may request revised pages from the FRL, who will request the pages from the drafting attorney. The FLR will share all changes suggested by the OFR with the drafting attorney.


**32.1.6.10.1** **(08-11-2004)**

#### Filing and Publication

1. After the OFR reviews the regulation for compliance with its format and editorial requirements and resolves any problems with the FRL, the OFR assigns a filing date and publication date and notifies the FRL of those dates. Regulations are generally effective on the publication date, unless otherwise stated (see CCDM 32.1.5.7.4.5, Effective Date Paragraph). The OFR usually files the document at 8:45 a.m. within two working days after receipt, and publishes the document in the Federal Register the next working day after the filing date. For example, if the OFR receives a regulation by 2:00 p.m. Thursday, the OFR typically files the regulation at 8:45 a.m. on Monday and publishes it on Tuesday. Regulations submitted when the OFR has a backlog of regulations from the IRS or other agencies, may take longer to get reviewed, and filing and publication may be delayed.

2. When filed, the regulation is available to the public in the OFR reading room.


**32.1.6.10.1.1** **(08-02-2018)**

##### Immediate Filing and Emergency Publication

1. In extraordinary circumstances the IRS may request immediate filing at the OFR. A request for immediate filing is a request that the OFR review and file the regulation immediately, ahead of other regulations and documents that the IRS and other agencies already have pending at the OFR. Extraordinary circumstances warranting a request for immediate filing are limited to the public’s urgent need for guidance in the regulation. The IRS might request immediate filing when, for example, there is a need for guidance to have an immediate effective date. The Associate Chief Counsel (or Deputy) must approve a request for immediate filing. The drafting team must inform the FRL of the need and reason for immediate filing. The FRL prepares a letter to the OFR requesting immediate filing stating the reason for the request. This letter is made available for public inspection. The OFR decides whether to grant each request for immediate filing.

2. Immediate filing accelerates the filing date but not the publication date. The drafting team must make a separate request for emergency publication, if needed. Like immediate filing, extraordinary circumstances, based on the public’s urgent need, must justify any request for an expedited publication date. The OFR must obtain clearance from the Government Printing Office for emergency publication. There will be at least one full business day between an immediate filing date and the publication date, even if the publication date is accelerated.


**32.1.6.10.1.2** **(08-11-2004)**

##### Obtaining Filing and Publication Dates and TD Number

1. The FRL notifies the drafting attorney in advance of the filing and publication dates. If the regulation is a TD, the FRL also provides the drafting attorney with the TD number. The FRL provides any dates to be inserted in the regulation document.


**32.1.6.10.2** **(08-02-2018)**

#### After Obtaining Filing and Publication Dates

1. Once the FRL notifies the drafting attorney of the filing and publication dates, the drafting attorney must



1. Make any changes requested by the OFR or FRL,

2. Delete all instructions to insert dates that are contained in the document (such as _\[INSERT DATE 90 DAYS AFTER PUBLICATION OF THIS DOCUMENT IN THE FEDERAL REGISTER\]_) and type in the actual dates as provided by the OFR, and

3. Add the TD number (if applicable).


2. After making the above changes to the document, the drafting attorney must email the revised document to the FRL. See Exhibit 32.1.6-4, Instructions for Processing Regulations.


**32.1.6.10.2.1** **(08-02-2018)**

##### Prepare Filing Date Submissions to the Publications and Regulations Branch

1. By 8:45 a.m. on the filing date, the drafting attorney delivers the following documents to the Publications and Regulations Branch:



   - Electronic copy of the regulation by email. Remove hidden codes prior to delivery to the Publications and Regulations Branch (see CCDM 32.1.6.11.2.3)

   - Form 14712 (see CCDM 32.1.6.11.2.4)


2. By 11:00 a.m. on the filing date of TDs (including temporary regulations), the drafting attorney delivers to the Publications and Regulations Branch the completed and finalized Congressional Review Act (CRA) forms. The CRA form and attachments **must** be properly submitted for the regulation to be effective and it is the drafting attorney’s responsibility to ensure they are submitted to the Publications and Regulations Branch for forwarding to the Senate, House of Representatives, and GAO.See CCDM 32.1.6.11.2.5, Exhibit 32.1.6-5, Congressional Review Act Form, and Exhibit 32.1.6-6, Instructions For Completing The Congressional Review Act Form.

3. If a final regulation finalizes a temporary regulation due to expire (sunset) within five business days, the drafting team must alert the Publications and Regulations Branch to ensure that the final regulation receives special handling.


**32.1.6.10.2.2** **(08-02-2018)**

##### Electronic Copy of Document

1. The drafting attorney must email an electronic copy of the regulation to the Publications and Regulations Branch. The drafting attorney must remove all hidden codes to prevent readers from viewing prior changes to the document. The Publications and Regulations Branch emails the regulations to Media Relations and the Bulletin Unit (with Form 14712, Memorandum for Bulletin Unit Coordinator)

2. The Publications and Regulations Branch distributes copies of the regulation to:



   - National Taxpayer Advocate

   - Division Counsel (Wage and Investment)

   - Chief Counsel for Advocacy of the Small Business Administration,

   - Media Relations

   - Bulletin Unit

   - Federal Register Liaisons

   - FOIA Reading Room


**32.1.6.10.2.3** **(08-02-2018)**

##### Form 14712, IRB Submission Memorandum and Record Forms

1. The drafting attorney must complete Form 14712, Memorandum for Bulletin Unit Coordinator, for each document filed with the OFR, including ANPRMs. ANPRMs are published in the Internal Revenue Bulletin as Announcements.

2. The Publications and Regulations Branch electronically submits the forms and the regulation document to the Bulletin Unit, which coordinates publication of the document in the Internal Revenue Bulletin. In turn, the Bulletin Unit will provide the Publications and Regulations Branch with the Announcement number for ANPRMS and the IRB number and date for all regulations. The drafting team does not complete these sections of the forms. The Bulletin Unit will not publish the document(s) until they receive the properly completed forms. The drafting attorney should contact the Bulletin Unit (202-927-4374 or irb@irs.gov (**\*IRB**)) with any questions regarding completing these forms.

3. Retrieve Form 14712 and Form 12972 from IRS Publishing’s web site, or follow these steps:



1. Type http://publish.no.irs.gov/catlg.html,

2. Select "Catalog,"

3. Go to "View by Product Number,"

4. Go to "Select Product Type,"

5. Select "Form,"

6. Enter the form number beside "Enter product number (1040), "

7. Click on "Submit,"

8. Go to "Electronic Availability" , and

9. Click on "Current."


**32.1.6.10.2.4** **(11-13-2019)**

##### Congressional Review Act Forms

01. The Small Business Regulatory Enforcement Fairness Act of 1996 (SBREFA) added the Congressional Review Act (CRA) to chapter 8, title 5, United States Code (Congressional Review Act). The (CRA) provides that no final rule can become effective until the issuing agency submits a report containing certain information to the House of Representatives, the Senate, and the Comptroller General of the GAO. Specifically, the agency must submit the rule, a plain language summary, the cost-benefit analysis of the rule if one was required to be prepared, and other supporting documents. 5 U.S.C. § 801(a)(1).

02. The CRA notification requirements apply to any rule subject to the APA, which is any statement of general or particular applicability and future effect designed to implement, interpret, or prescribe law or policy and any statement describing the organization, procedure, or practice requirements of an agency. The CRA applies to temporary and final regulations (including removal of a temporary or final regulation) and does not apply to ANPRMs and NPRMs. The CRA also applies to any other rule meeting the above definition regardless of the form of published guidance used to announce the rule and regardless of whether the APA imposes a notice-and-comment requirement on the rule.

03. The IRS meets its Congressional Review Act notice requirement for regulations by submitting a Congressional Review Act form (CRA form), the regulation, and other attachments, to Congressional and GAO representatives. The drafting attorney must complete the CRA form and ensure it is delivered to the Publication and Regulations Branch. The forms should be sent to the "Congressional Review Acts" mailbox on outlook. The Publications and Regulations Branch arranges delivery of the completed CRA form, with attachments, to the House of Representatives, the Senate, and the Comptroller General of the GAO within one business day of receipt.

04. The drafting attorney must prepare the following and deliver them to the Publications and Regulations Branch before 11 a.m. on the regulation’s filing date:



    1. _Four CRA reports_ for President, United States Senate; Speaker, United States House of Representatives; General Counsel, GAO; and Publications and Regulations Branch files. Each report consists of the following documents in the order listed (from top to bottom):


        • The completed CRA form,


        • A copy of the concise summary, and


        • An unsigned copy of the final version of the regulation as submitted to the OFR.


        • For the GAO package only, if the rule is a major rule, a copy of the cost benefit analysis.



       ### Note:



       For the first three listed recipients of the CRA reports, type the recipient’s name and title in the upper right corner of the CRA form for that recipient.

    2. Five additional copies of the completed CRA form (without the concise summary or a copy of the rule). Type each recipient’s name and title in the upper right corner of each of these five CRA forms. These five recipients (courtesy copy recipients) receive only a copy of the CRA form, without the regulation or concise summary. These five CRA forms are for:


        • Chairman, Committee on Ways and Means


        • Ranking Minority Member, Committee on Ways and Means


        • Chairman, Committee on Finance


        • Ranking Minority Member, Committee on Finance


        • Chief of Staff, Joint Committee on Taxation


05. In the afternoon on the day of receipt (ordinarily by 2:00), the Publications and Regulations Branch



    1. Delivers the CRA reports for the Speaker, U.S House of Representatives and the President, U.S. Senate to the IRS Office of Legislative Affairs for hand-delivery to those Hill offices,

    2. Delivers the CRA report to the GAO, and

    3. Faxes the CRA forms to the courtesy copy recipients.


06. Each day, the Publications and Regulations Branch prepares an "Acknowledgement of Receipt" form (original and two copies), listing the documents being submitted under the CRA, for each of the following:



    - President, United States Senate

    - Speaker, U.S. House of Representatives


07. By 2:00 p.m. the Publications and Regulations Branch delivers the Acknowledgements of Receipt (original and one copy) and the listed CRA reports (Acknowledgement of Receipt packages) for the President, U.S. Senate, and the Speaker, U.S. House of Representatives, to the IRS Legislative Affairs office. Personnel in the IRS Legislative Affairs office deliver the CRA reports to those Congressional offices (usually within one business day) and get a representative of each of those Congressional offices to sign the Acknowledgement of Receipt forms. IRS Legislative Affairs returns the signed Acknowledgement of Receipt forms to the Publications and Regulations Branch box in the Office of IRS Legislative Affairs.

08. The Publications and Regulations Branch maintains records of all CRA submissions and signed Acknowledgement of Receipt forms, and follows up with the IRS Legislative Affairs office on any outstanding Acknowledgement of Receipt forms.

09. The Publications and Regulations Branch sends a CRA package to the General Counsel, GAO. The Publications and Regulations Branch faxes the CRA forms to the offices of the five courtesy copy recipients and verifies that each fax confirmation shows that the submission was properly transmitted in its entirety.

10. The Publications and Regulations Branch sends both signed Acknowledgement of Receipt forms (signed by the offices of the President, United States Senate, and the Speaker, U.S. House of Representatives), to the drafting attorney to retain in the regulation’s legal file. If an Acknowledgement of Receipt form lists more than one CRA report, the Publications and Regulations Branch sends the original signed form to the drafting attorney for the first listed document and a copy of the signed form to the drafting attorney for each other CRA report listed on the form. The Publications and Regulations Branch retains a copy of each signed Acknowledgement of Receipt form and a copy of each related CRA report.

11. The Publications and Regulations Branch also sends the Acknowledgement of Receipt form signed by the Office of the General Counsel, GAO to the drafting attorney for retention in the regulation’s legal file, and retains a copy together with the related CRA report, in the Publications and Regulations Branch files.

12. .In addition to the reporting requirement, the CRA also limits the effective date of any rule considered a "major rule." For major rules, the effective date cannot be earlier than 60 days after the rule is delivered to the House, Senate, and GAO. Under 5 U.S.C. § 804(2), a major rule is a rule identified by the administrator of the OMB Office of Information & Regulatory Affairs as resulting or likely to result in:



    1. An annual effect on the economy of $100 million or more;

    2. A major increase in costs or prices for consumers, individual industries, Federal, State or local government agencies, or geographic regions; or

    3. Significant adverse effects on competition, employment, investment, productivity, innovation or on the ability of United States-based enterprises to compete with foreign-based enterprises in domestic and export markets.


13. It is the responsibility of the drafting attorney to ensure that the Acknowledgment of Receipt forms are placed in the regulation's legal file. If the attorney does not receive the acknowledgments within 30 days of delivering the CRA form to the Publications and Regulations Branch, the attorney should follow up with the Publications and Regulations Branch to determine status of the forms and to verify the CRA reports were submitted. It is critical that the acknowledgments are retained in the event there is any question over whether the IRS complied with the CRA.

14. Generally, the analysis of whether an IRS/Treasury rule constitutes a major will rule will focus on the rule’s annual effect on the economy. Under this criterion, IRS/Treasury rules are rarely major rules because the effect of most IRS/Treasury rules is attributable to the underlying statute rather than to the regulation.



    1. The economic effect standard is the same under both the CRA and E.O. 12866, so a similar analysis applies in determining whether an action is a major rule due to annual effect on the economy for purposes of the CRA. See CCDM 32.1.5.4.7.5.3, Executive Order 12866. Any regulation that is determined to be economically significant under E.O. 12866 must be submitted to Congress as a major rule.


15. Additional information about the CRA is available at [http://www.gao.gov/legal/congressact/cra\_faq.html](http://www.gao.gov/legal/congressact/cra_faq.html). See Exhibit 32.1.6-5, Congressional Review Act Form and Exhibit 32.1.6-6, Instructions for Completing the Congressional Review Act Form


**32.1.6.10.3** **(08-11-2004)**

#### Notify Legislative Affairs on the Filing Date

1. On the date the regulation is filed at the OFR, the drafting attorney must email a copy of the regulation to Legislative Affairs of the Commissioner’s Office. The drafting attorney must include the following information in the text of the email:



   - CASE-MIS ID number (for example, REG-123456-02)

   - Project name / very brief description

   - TD number, if applicable

   - Filing date


**32.1.6.11** **(08-11-2004)**

### Post-Publication Administrative Duties

1. Once the regulation document is published in the Federal Register, the Publications and Regulations Branch enters the Federal Register filing and publication information in CASE-MIS.


**32.1.6.11.1** **(08-02-2018)**

#### Proofreading After Publication

1. Within seven days after publication, the Publications and Regulations Branch will provide the drafting attorney with a reprint of the regulation as it appears in the Federal Register. If the drafting attorney does not receive the reprint within 7-10 days, the drafting attorney should contact the Publications and Regulations Branch and ask for a copy.

2. The drafting attorney must compare the reprint to the copy of the regulation submitted to the OFR. Within seven days of receiving the reprint, the drafting attorney must



1. Identify and correct typographical errors, omissions, etc., in red pen or pencil. If there are no mistakes, note that, in red, at the top of the first page,

2. Identify the source of each error with an "I" for IRS or an "F" for Federal Register, and

3. Date and initial the corrected reprint and return to the Publications and Regulations Branch.


3. The Publications and Regulations Branch prepares a correction notice for the regulation if the error(s) alter the substance of the document or make the document difficult to understand. The correction notice is published in the Federal Register.


**32.1.6.11.2** **(08-02-2018)**

#### Filing Signed Congressional Review Act Submissions Acknowledgement of Receipt Forms

1. The drafting attorney must make sure he or she receives the following from the Publications and Regulations Branch to ensure compliance with the Congressional Review Act (CRA):



   - Signed Acknowledgement of Receipt form listing the regulation project from the office of the President of the Senate

   - Signed Acknowledgement of Receipt form listing the regulation project from the Office of the Speaker of the House of Representative

   - Signed Acknowledgement of Receipt form listing the regulation project from the Office of the General Counsel, GAO


2. The drafting attorney must contact the Publications and Regulations Branch if he or she does not receive the above documents within 30 days of delivering the CRA form to the Publications and Regulations Branch. The drafting attorney must file all three receipts in the legal file for the regulation project. See CCDM 32.1.6.11.2.5. It is critical that the acknowledgments are retained in the event there is any question over whether the IRS complied with the CRA.


**Exhibit 32.1.6-1**

### Sample Executive Summary

| **EXECUTIVE SUMMARY FOR PROPOSED REGULATIONS 301.6103(n)-I** |
| :-: |
| • | **Description of the guidance:** The proposed regulations clarify the IRS’s and Treasury’s historical view that redisclosures of returns and return information by contractors to agents or subcontractors are permissible, and that agents and subcontractors are subject to the civil and criminal penalties of sections 7431, 7213, and 7213A. The proposed regulations also clarify that section 61 03(n) applies to a variety of written contracts or agreements that are entered into to obtain property or services for purposes of tax administration, not just tax administration contracts awarded under the Federal Acquisition Regulations. |
| • | **Why/how guidance was initiated:** The proposed regulations were initiated, in large part, in response to the IRS’s collection contracting out initiative because of the perceived necessity to give contractors the ability to use agents or subcontractors to assist them in IRS collection activities. |
| • | **What taxpayers are impacted by the guidance:** The proposed regulations will affect any person who receives returns or return information in connection with a written contract or agreement for the acquisition of property or services for tax administration purposes. |
| • | **Names of persons with whom drafting attorney coordinated the guidance and the outcome of that coordination:** The proposed regulations were coordinated with David Barnes (CC:GLS:PCL) who provided general information about the types of contracts that the IRS enters into to obtain property or services for tax administration purposes. |
| • | **Impact on pending litigation and coordination with Department of Justice, as appropriate:** N/A |
| • | **Whether the guidance is controversial (either internally or externally):** No. The policy aspects of contracting out collection, however, are extremely controversial. |
| • | **Critical dates, if any, for publication:** None |

**Exhibit 32.1.6-2**

### Sample Green Circulation Draft Routing Slip

| **From:** | **Drafting attorney’s name** |
| --- | --- |
| **Sent:** | **Date** |
| **To:** | **\[Add persons directly involved with project\]** |
| **Cc:** | **\[Add Branch reviewer; Associate Chief Counsel reviewer; Treasury contact; TLC/ITC/BTC, as applicable; Service personnel who may be interested/affected by project not on the "to" line\]** |
| **Subject:** | **Project Name** |
| **Attachment:** | **Insert circulation draft and executive summary** |
|  | The attached document contains a draft \[add description of project, highlighting important issues or provisions\]. Also attached is an executive summary. Please review the document and provide us with any comments that you may have regarding \[insert type of guidance\] by **COB \[insert date 14 days from date of circulation\].** If your office does not have any comments, please send a negative response. |
|  | If you have any questions concerning this matter, please contact me. Thank you. |
|  | Drafting attorney’s name<br> Telephone number<br> Room number |

### Note:

For regulations — send a separate email to counsel.office@tigta.treas.gov attaching the circulation draft but without an executive summary. For other guidance — do not send either the circulation draft or the executive summary to TIGTA.

**Exhibit 32.1.6-3**

### Sample Pink Signature Package Routing Slip

![This is an Image: 38999020.gif](https://www.irs.gov/pub/xml_bc/38999020.gif)

> This is an example of how to prepare a Signature Package Routing Slip.

[Please click here for the text description of the image.](https://www.irs.gov/media/38999020.gif "")

**Exhibit 32.1.6-4**

### Instructions for Processing Regulations

| **INSTRUCTIONS FOR PROCESSING REGULATIONS** |
| :-: |
| Please follow these instructions carefully to ensure that your documents are ready (1) to be filed and published by the Federal Register, (2) distributed to the tax services, and (3) to upload on the Internet. |

|  |
| --- |
| **FEDERAL REGISTER AND DISTRIBUTION TO TAX SERVICES** |
| (1.) | Make changes, if any, to the document. |
| (2.) | Delete all instructions to insert dates that are contained in the document (e.g., \[INSERT DATE THAT IS 90 DAYS AFTER DATE OF PUBLICATION OF THIS DOCUMENT IN THE FEDERAL REGISTER\], \[INSERT DATE THAT THIS DOCUMENT IS FILED WITH THE FEDERAL REGISTER\]). Type in actual date(s) and print a new page. **CORRECT THE DATE(S) IN THE DOCUMENT BEFORE PRINTING AND PHOTOCOPYING THE REGULATION.** |
| (3.) | Print the document with changes. |
| (4.) | Place the cover sheet that gives the filing and publication dates on top of the document. |
| (5.) | On or before 8:45 a.m. on the filing date, email an electronic copy of **THE DOCUMENT IN MICROSOFT WORD** to the Publications and Regulations Branch (Main IRS/Room 5205). **THE WORD DOCUMENT MUST BE PURGED.** If you have any questions concerning the submission of the diskettes or copies, please contact the Publication and Regulations Branch at 622-7180. |
| (6.) | Complete Forms 12971 and 12972 for each document that is filed with the Federal Register. These forms are used to publish the document in the Internal Revenue Bulletin (IRB). Obtain electronic copies of Forms 12971 and 12972 by following the instructions listed below. Contact the IRS Bulletin Unit at 622-3869 (Rm 6129) or irb@irs.gov with any questions regarding how to complete these forms. The Bulletin Unit will _not_ publish the regulation in the IRB unless these forms are properly completed. |
| (7.) | **Take completed Forms 12971 and 12972 to the Publications and Regulations Branch, Main IRS, Room 5205, by 8:45 a.m. on the date the document(s) is filed with the Office of the Federal Register.** The Publications and Regulations Branch submits these forms and your document(s) to the Bulletin Unit. The Bulletin Unit coordinates publication of the document(s) in the Internal Revenue Bulletin. |
| RETRIEVE Form 12971 AND FORM 12972 FROM THE WEB SITE. Forms 12971 and 12972 may also be found on CC macros. |
| (8.) | On the filing date, send the filing date via email to Floyd L. Williams, Legislative Affairs, at the following email address: floyd.williams@irs.gov. |
|  |
| CONGRESSIONAL AND GAO NOTIFICATION REQUIREMENTS FOR<br> FINAL AND TEMPORARY REGULATIONS — SBREFA |
| Complete any remaining portion of the Congressional Review Act (CRA) form that were not completed when you included the CRA form in the signature package, prepare the required CRA packages and additional copies of the CRA form, and submit the CRA packages and CRA forms to the Regulations Unit on or before 11:00 a.m. on the date the regulation is filed in the Office of the Federal Register. |

**Exhibit 32.1.6-5**

### Congressional Review Act Form

![This is an Image: 38999001.gif](https://www.irs.gov/pub/xml_bc/38999001.gif)

> This is the first page of the Submission of Federal Rules Under the Congressional Review Act form.

[Please click here for the text description of the image.](https://www.irs.gov/media/38999001.gif "")

![This is an Image: 38999002.gif](https://www.irs.gov/pub/xml_bc/38999002.gif)

> This is page 2 of the Submission of Federal Rules Under the Congressional Review Act form.

[Please click here for the text description of the image.](https://www.irs.gov/media/38999002.gif "")

**Exhibit 32.1.6-6**

### Instructions for Completing Congressional Review Act Form

|  |
| --- |
| **INSTRUCTIONS FOR COMPLETING CONGRESSIONAL REVIEW ACT FORM** |
| Rev. 6-3-2003 |
| All CRA forms and packages are due to the Regulations Unit before 11:00 a.m. on the date the rule is issued (the date a TD is filed at the OFR). |
|  |
| **Instructions for Completing the 1st Page of the Congressional Review Act (CRA) Form:** |
| Select President of the Senate, Speaker of the House of Representatives, or GAO. Prepare a CRA form for each one. |
| 1\. Name of Department or Agency — Department of the Treasury |
| 2\. Subdivision or Office — Internal Revenue Service |
| 3\. Rule Title — State the Rule Title exactly as it appears on the rule. If the rule does not contain a title, the attorney should create a brief descriptive title. Do not include the RIN, TD number, Rev. Rul. or Rev. Proc. number, etc. in the title. |
|  | EXAMPLES:<br> <br>- TD: Substantiation of Incidental Expenses<br>  <br>- Revenue Ruling: Advance Reimbursements of Medical Expenses<br>  <br>- Revenue Procedure: Cost-of-Living Adjustments for 2011<br>  <br>- Notice: Liberty Zone Advance Refund Notice<br>  <br>- Announcement: Announcement and Report Concerning Advance Pricing Agreements<br>  <br>- Action on Decision: Action on Decision — Robert L. Beck v. Commissioner<br>  <br>- Appeals Settlement Guidelines: Appeals Settlement Guidelines —Construction/Real Estate — Per Diem Allowances for Temporary Technical Service Employees<br>  <br>- Coordinated Issue Paper: Coordinated Issue — Intermediary Transaction Tax Shelters<br>  <br>- Market Segment Specialization Paper: Audit Technique Guide — Farming — Specific Income Issues and Farm Cooperatives |
| 4\. Regulation Identification Number (RIN) or Other Unique Number (if applicable) |
|  | TDs: |
|  |  | Use the Regulation Identification Number (RIN) and the Treasury decision (TD) number. Place the TD number in parentheses following the RIN. If submitting multiple actions under one RIN, add information that identifies each action. |
|  | Other than TDs: |
|  |  | Use the agency’s unique identification number, such as the revenue ruling number, revenue procedure number AOD number, etc. Do not include the IRB citation.<br> If there is no agency unique identification number, leave blank. Do not use a CASE-MIS ID number or a Uniform Issue List (UIL) number. |
|  | EXAMPLES:<br> <br>- TD: RIN 1545-BBI9 (TD 9020)<br>  <br>- Revenue Ruling: Rev. Rul. 2010-80<br>  <br>- Revenue Procedure: Rev. Proc. 2010-70<br>  <br>- Notice: Notice 2010-73<br>  <br>- Announcement: Announcement 2010-40<br>  <br>- Action on Decision: AOD 2010-5<br>  <br>- Appeals Settlement Guidelines: Leave blank<br>  <br>- Coordinated Issue Paper: Leave blank<br>  <br>- Market Segment Specialization Papers: Leave blank |
| 5\. Major Rule — Indicate whether the rule is designated as a "major" or "non-major" rule pursuant to the CRA |
|  | A major rule is a rule that is likely to result in:<br> <br>1. An annual effect on the economy of $100,000,000 or more;<br>   <br>2. A major increase in costs or prices for consumers, individual industries, Federal, State, or local government agencies, or geographic regions; or<br>   <br>3. Significant adverse effects on competition, employment, investment, productivity, innovation, or on the ability of US-based enterprises to compete with foreign-based enterprises in domestic and export markets. |
|  |  | If the rule is a "major rule" , pursuant to 5 U.S.C 801, the effective date of the rule cannot be earlier than 60 days after the rule is delivered to the House, Senate and the GAO. |
|  | IRS rules are rarely major rules because the effect of most IRS rules is due to the underlying statute, rather than to the regulation. See CCDM 32.1.6.11.2.5(12). Consult the Chief, Regulations Unit, before responding that the document is a major rule. |
|  | A non-major rule is a rule that is not a major rule. Almost all IRS documents are non-major rules. |
| 6\. Final Rule — A final rule amends the Code of Federal Regulations (CFR). |
|  | TDs: |
|  |  | Answer "Final Rule." |
|  | Other than TDs: |
|  |  | Answer "Other."<br> Further, for non-regulation published guidance documents (for example, revenue rulings, revenue procedures, and notices), also type "IRB ONLY" in the space provided. |
| 7\. Public Comments — If the agency solicited public comments (for example, by publishing a prior ANPRM or NPRM, Notice, by holding a public hearing or meeting, by taking a survey, or by conducting an advisory committee hearing) respond "Yes." Otherwise, respond "No." |
| 8\. Priority of Regulation |
|  | TDs: |
|  |  | Indicate the priority to which the regulation was, or will be, assigned in the Semiannual Agenda (see below). Most IRS regulations are categorized as "Substantive, Nonsignificant." |
|  |  | A regulation is ECONOMICALLY SIGNIFICANT if is it expected to have an annual effect on the economy of $100,000,000 or more or will adversely affect in a material way the economy; a sector of the economy; productivity, competition; jobs; the environment, public health or safety; or State, local, or tribal governments or communities. This definition is similar, but not identical, to the definition of a major rule (above). |
|  |  | A regulation is SIGNIFICANT if it is not Economically Significant and (i) the agency considers the regulation significant, (ii) the regulation is a priority of the head of the agency, or (iii) the agency anticipates the regulation will be reviewed under Executive Order 12866. A significant regulation may be identified as a Major or Non-major rule. |
|  |  | A regulation is SUBSTANTIVE, NONSIGNIFICANT if it has substantive impacts but the magnitude of the impact is less than significant. These regulations are most likely not Economically Significant, will most likely not be reviewed under E.O. 12866, and are not, at present, a priority of the head of the agency. A Substantive, Nonsignificant regulation is always identified as a Non-major rule. |
|  |  | A regulation is ROUTINE AND FREQUENT if it is a specific case of a multiple recurring application of a regulatory program in the CFR and it does not alter the body of the regulation. (Note: If an individual regulation that normally falls into the Routine and Frequent category is submitted to OMB for review, the rulemaking should be classified as Economically Significant or Other Significant.) A Routine and Frequent regulation is always identified as a Non-major rule. |
|  |  | A regulation is INFORMATIONAL/ADMINISTRATIVE/OTHER if it is primarily informational or pertains to agency matters not central to accomplishing the agency's regulatory mandate but that the agency places in the Semiannual Agenda to inform the public of the activity. An Informational/Administrative/Other regulation is always identified as a Non-major rule. If the TD is categorized as "Routine and Frequent, or Informational/Administrative/Other" , do not complete the second page of the CRA form. |
|  | Other than TDs: |
|  |  | Leave blank. This question relates only to TDs. |
| 9\. Effective Date |
|  | TDs: |
|  |  | Enter the Effective Date as stated in the DATES caption in the preamble.<br> <br>### Note:<br>If the rule is a "major rule," pursuant to 5 U.S.C 801, the effective date of the rule cannot be earlier than 60 days after the rule is delivered to (and actually received by) the House, Senate and the GAO. |
|  | Other than TDs: |
|  |  | If the document contains an effective date or applicability date in the text, the Effective Date for the CRA form is the effective date or applicability date as stated in the document. If the rule contains multiple effective dates, enter the earliest effective date.<br> If the document does not contain an effective date or applicability date in the text, leave the Effective Date section on the CRA form blank (do not enter N/A; do not enter the publication or issuance date of the document).<br> Examples:<br> <br>1. A Revenue Procedure states that it is applicable to transactions entered into after December 31, 2010. The Effective Date for the CRA form is January 1, 2011.<br>   <br>2. A Notice provides guidance for computing certain amounts for a calendar quarter. The Effective Date for the CRA form is the first day of that calendar quarter.<br>   <br>3. A Revenue Ruling or Coordinated Issue Paper provides guidance to be applied on a retroactive (without stating a specific date) and a prospective basis. Leave the Effective Date section on the CRA form blank. Do not enter "N/A ." Do not enter the publication date or date of issuance. |
| 10\. Rule Concise Summary — Answer "attached." Prepare and attach a concise summary of the rule. |
| Submitted By — The Chief, Publications and Regulations Branch signs the form. |
|  | Enter that individual’s name and title as follows: |
|  |  | \[insert name\]<br> Chief, Publications and Regulations Branch |
|  | Following the signature, name, and title, type: |
|  |  | If you have any questions, please contact \[insert attorney’s name\] at \[insert attorney’s 10-digit phone number\]. |
|  |
| **Instructions for Completing the 2nd Page of the Congressional Review Act (CRA) Form** |
| ### Reminder:<br>For TDs only, if the TD is categorized as "Routine and Frequent" , or "Informational Administrative/Other" , (1st page, # 8) do not complete the second page of the CRA form. |
| A. If the final rule is a significant regulatory action or a major rule, the agency must prepare a cost and benefit analysis for OMB’s review. |
|  | TDs: |
|  |  | Answer "Yes" if the agency prepared an analysis of costs and benefits. If the rule is neither a significant regulatory action nor a major rule, answer "No." |
|  | Revenue Rulings, Revenue Procedures, Notices and Announcements: |
|  |  | If the rule is neither a significant regulatory action nor a major rule, answer "No." |
|  | Action on Decision: |
|  |  | Answer "N/A." |
|  | Coordinated Issue Papers: |
|  |  | Answer "N/A." |
|  | Market Segment Specialization Papers: |
|  |  | Answer "N/A." |
| B. TDs |
|  | If the final rule is subject to the Regulatory Flexibility Act, the agency must prepare a final regulatory flexibility analysis or certify that the rule will not have a significant economic impact on a substantial number of small entities.<br> If, by the final rule stage, the agency certifies that a regulatory flexibility analysis is not required, answer "Yes" to question B.1. and "N/A" to question B.2.<br> If, by the final rule state, the agency prepared a final regulatory flexibility analysis, answer "N/A" to question B.1. and "Yes" to question B.2.<br> If the final rule is not subject to the Regulatory Flexibility Act, answer "N/A" to both questions B.1. and B.2. |
|  | Other than TDs:<br> Answer "N/A" to both questions B.1 and B.2. |
| C. TDs: |
|  | If the final rule includes a mandate that will result in costs exceeding $100,000,000 in any one year, section 202 of the Unfunded Mandates Reform Act of 1995 (UMRA) requires agencies to prepare a "written statement." If the final rule is subject to the UMRA and the agency prepared a "written statement," answer "Yes" to question C. If the final rule is subject to the UMRA and agency did not prepare the "written statement," answer "No." If the final rule is not subject to UMRA, answer "N/A." Virtually all IRS regulations are not subject to UMRA. |
|  | Other than TDs:<br> Answer "N/A." |
| D. For all documents: Answer "N/A." |
| E. For TDs and other published guidance (revenue rulings, revenue procedures, notices): |
|  | If the rule contains a collection of information requirement subject to the Paperwork Reduction Act of 1995, answer "Yes." If it does not, answer "No." |
|  | For documents that are neither TDs nor other published guidance:<br> Answer "N/A." |
| F. TDs: |
|  | For each Executive Order (E.O.) answer "Yes" or "No" depending on whether the E.O. was discussed in the preamble (regardless of whether the E.O. applies or does not apply to the regulation). In the space provided, list all other statutes (for example, IRC section 7805) and other executive orders addressed in the preamble. The preamble to IRS regulations routinely address E.O. 12866 and 26 U.S.C. § 7805. |
|  | Other than TDs:<br> Answer "N/A" for each Executive Order. |
|  |
| **Preparation of CRA Packages and Additional Copies of the CRA Form:** |
| 1\. Assemble three packages, one each for (i) the President, United States Senate, (ii) the Speaker, U.S. House of Representatives, and (iii) the General Counsel, GAO. Each package contains the following documents in the order listed, from top to bottom:<br> <br>- Completed CRA form;<br>  <br>- Concise summary of the rule;<br>  <br>- A copy of the rule; and<br>  <br>- Any other attachment(s) (rarely will there will be any other attachment). |
| 2\. Make a copy of one of the packages for retention in the Regulations Unit. |
| 3\. Make five copies of one of completed CRA forms (preferably either the one for the President, U.S. Senate, or the one for the Speaker, U.S. House of Representatives). Type each of the following recipients. names and titles on the upper right corner of each of the five copies:<br> <br>- The Honorable Max Baucus, Chairman, Committee on Finance<br>  <br>- The Honorable Orin G. Hatch Ranking Minority Member, Committee on Finance<br>  <br>- The Honorable Dave Camp, Chairman, Committee on Ways and Means<br>  <br>- The Honorable Sander Levin, Ranking Minority Member, Committee on Ways and Means<br>  <br>- Mr. Thomas A. Barthold, Chief of Staff, Joint Committee on Taxation<br>  <br> These five recipients receive only a copy of the CRA form, without any attachments. |
|  |
| **Acknowledgment of Receipt Forms** |
| The Publication and Regulations Branch delivers to the drafting attorney Acknowledgement of Receipt forms from the Senate House of Representatives and GAO. If the drafting attorney does not receive the acknowledgment within 10 days from when the attorney delivered the CRA form to the Publications and Regulations Branch, the attorney must contact the Publications and Regulations Branch to obtain the acknowledgments. The drafting attorney must file all three acknowledgments in the legal file for the regulation project. It is critical that the acknowledgments are retained in the event that there is any question over whether the IRS complied with the CRA. |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part32/irm_32-001-006#addtoany "Show all")

A2A