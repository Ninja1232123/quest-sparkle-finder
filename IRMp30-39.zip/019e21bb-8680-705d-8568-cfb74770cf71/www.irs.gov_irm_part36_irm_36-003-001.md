---
url: "https://www.irs.gov/irm/part36/irm_36-003-001"
title: "36.3.1 Actions on Decision | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part36/irm_36-003-001#main-content)

- 36.3.1 [Actions on Decision](https://www.irs.gov/irm/part36/irm_36-003-001#idm139624315355712)
  - 36.3.1.1 [Actions on Decision](https://www.irs.gov/irm/part36/irm_36-003-001#idm139624334374064)
  - 36.3.1.2 [Standards Governing Issuance of AODs](https://www.irs.gov/irm/part36/irm_36-003-001#idm139624334459936)
  - 36.3.1.3 [Procedures for Determining Whether to Issue an AOD](https://www.irs.gov/irm/part36/irm_36-003-001#idm139624319570480)
  - 36.3.1.4 [Drafting an AOD](https://www.irs.gov/irm/part36/irm_36-003-001#idm139624314897360)
  - 36.3.1.5 [Format of AOD](https://www.irs.gov/irm/part36/irm_36-003-001#idm139624315428928)
  - 36.3.1.6 [Coordination of AODs](https://www.irs.gov/irm/part36/irm_36-003-001#idm139624319611232)
  - 36.3.1.7 [Approval and Issuance of AODs](https://www.irs.gov/irm/part36/irm_36-003-001#idm139624319411104)
  - 36.3.1.8 [Distribution and Publication of Approved AODs](https://www.irs.gov/irm/part36/irm_36-003-001#idm139624282890160)
  - 36.3.1.9 [Inquiries from the Public](https://www.irs.gov/irm/part36/irm_36-003-001#idm139624319412400)
  - 36.3.1.10 [Chief Counsel Notices to Announce Changes in Service Litigating Positions](https://www.irs.gov/irm/part36/irm_36-003-001#idm139624334350848)
  - 36.3.1.11 [Reconsideration of Actions](https://www.irs.gov/irm/part36/irm_36-003-001#idm139624334358032)

# Part 36. Appellate Litigation and Actions on Decision

# Chapter 3. Actions on Decision

# Section 1. Actions on Decision

* * *

## 36.3.1 Actions on Decision

#### Manual Transmittal

March 14, 2013

#### Purpose

(1) This transmits revised CCDM 36.3.1, Appellate Litigation and Actions on Decision; Actions on Decision.

#### Material Changes

(1) CCDM 36.3.1.1 was revised to clarify that actions on decision (AODs) are published in the Internal Revenue Bulletin to expeditiously alert Service personnel and the public to the Office’s current litigating position. It also clarifies that Counsel attorneys are required to follow the litigating positions announced in AODs in future litigation or dispute resolution.

(2) CCDM 36.3.1.2 was revised to clarify when an AOD can be issued, the factors that may be considered in determining whether an AOD should be issued, and alternatives to the issuance of an AOD that should be considered.

(3) CCDM 36.3.1.3 was revised to clarify the procedures for determining whether to issue an AOD.

(4) CCDM 36.3.1.4 was revised to clarify that, in those rare circumstances, when the office will continue to litigate the issue in the deciding circuit, the AOD must provide clear directions for resolving cases appealable to that circuit.

(5) CCDM 36.3.1.6 was revised to clarify that only one AOD is issued in a case and that when two or more Associate Chief Counsel offices have subject matter jurisdiction for the significant issues in a case, the offices must confer.

(6) CCDM 36.3.1.8 was revised to clarify the process for distributing and publishing AODs.

(7) Grammar, punctuation, and sentence structure were corrected throughout the section.

(8) Hyperlinks to CCDM references and IRS resources were added throughout the section.

#### Effect on Other Documents

CCDM 36.3.1 dated August 11, 2004 is superseded.

#### Audience

Chief Counsel

#### Effective Date

(03-14-2013)

Deborah A. Butler

Associate Chief Counsel

(Procedure & Administration)

**36.3.1.1** **(03-14-2013)**

### Actions on Decision

1. An action on decision (AOD) expeditiously alerts Service personnel and the public to the current litigating position of the Office of Chief Counsel. An AOD conveys the Office’s recommendation on whether the Service will follow a significant adverse opinion. Counsel attorneys are required to follow the litigating positions announced in AODs in future litigation or dispute resolution.

2. An AOD is issued by the Associate Chief Counsel office with subject matter jurisdiction over the substantive issues addressed by the AOD. AODs are published in the Internal Revenue Bulletin and also are available in the [Electronic Reading Room](http://www.irs.gov/uac/Electronic-Reading-Room) on the IRS webpage.


**36.3.1.2** **(03-14-2013)**

### Standards Governing Issuance of AODs

1. AODs are prepared when a court decides one or more significant issues adversely to the Government. An issue is decided adversely to the Government when the Service's legal position is adversely affected by the court’s opinion. An issue may be considered adverse for the purpose of determining whether an AOD should be issued even if neither the case nor the issue is appealable.

2. Although rare, an AOD can be prepared and can be issued when the court has sustained the Government’s determination as to the amount of the tax liability. Because the issues in the case may not be synonymous with the arguments or theories, and there may be numerous subsidiary questions of fact or law, the court may reject one or more of the Government's arguments or theories and nevertheless sustain the Government as to the amount of tax liability. Consequently, the Service cannot appeal the decision in these cases, but an AOD may be necessary to clarify the Service’s legal position in future litigation or dispute resolution.

3. An AOD may, on occasion, be issued on an issue not resolved by the court. This can arise in a case in which the Government in the pleadings or statutory notice of deficiency has taken alternative positions on the same taxable transaction and the court sustains the Government on one of the alternative positions.

4. Among the factors in determining whether an issue is significant and an AOD should be issued are:



01. Whether the opinion involves an issue under the Industry Issue Resolution program or a similar program

02. The number of cases and amount of revenue affected by the opinion

03. The impact of the opinion on regulations, revenue rulings, revenue procedures, and other technical pronouncements

04. Whether the opinion is inconsistent with legislative history or opinions in other courts

05. Whether the issue has been lost by the Government in two or more circuits

06. Whether the case is one of first impression

07. The likelihood of a future split in the circuits

08. Whether en banc review in the circuit was sought

09. Whether the opinion can be limited to its facts

10. Whether the opinion places an onerous administrative burden on the Service or taxpayers

11. Whether the opinion is based on Code sections, regulations or rulings that have been modified or revoked


5. An AOD generally is not prepared on issues decided favorably to the Government, on issues conceded by the Government, or on insignificant issues decided adversely to the Government. An AOD is not prepared for issues that are on appeal, or will be appealed, by the Government. The filing of the appeal by the Government provides notice of the Service's disagreement with the adverse opinion on the issues.

6. In general, an AOD is not issued with respect to a district court opinion, or a T.C. Memo or summary opinion issued by the Tax Court. Summary opinions are not appealable and are not precedential. T.C. Memo opinions are issued with respect to cases which are highly factual or involve issues that have been settled by the courts in prior opinions. T.C. Memos cases may be appealed, but, in general, they are not considered good candidates for an AOD.

7. Before issuing an AOD, attorneys should consider alternative courses of action, including, but not limited to, the possible issuance of published guidance or a Chief Counsel Notice. AODs also may be used in coordination with, or to supplement, other technical pronouncements.


**36.3.1.3** **(03-14-2013)**

### Procedures for Determining Whether to Issue an AOD

1. Upon receipt of an adverse opinion the Associate office attorney assigned to the case will perform an adverse opinion review. See CCDM 36.1.1.2.1, Definitions of Favorable Appeal and Adverse Decision, and CCDM 36.1.1.6, Responsibilities of Associate Chief Counsel Offices in Appeal Cases. When considering whether to recommend appeal of the adverse decision, the attorney also should consider whether to recommend the issuance of an AOD. See CCDM 36.2.1.1.3, Specific Recommendations, and CCDM 36.2.6.2.2, Commissioner Appeals — Adverse Opinion Review.



1. In Tax Court cases, the Fagan memo will state either that an AOD will be issued, will not be issued, or that the decision has been deferred. See Exhibit 36.4.1–10, "No Appeal" Memorandum. The Fagan memo is forwarded to Technical Services Support Branch, Office of the Associate Chief Counsel (P&A) retains a copy of the Fagan memo.

2. In refund cases and all other cases, the Associate office attorney should note in the legal file the preliminary determination concerning whether an AOD should be issued.

3. In circuit court cases, Tax Court appeals, refund litigation, disclosure and general litigation cases, a determination whether an AOD should be issued is made when the Department of Justice notifies the office assigned the case that the Government will not petition the Supreme Court for a writ of certiorari.


2. The field office may, if it chooses, provide an AOD recommendation by memorandum to the office assigned to consider appeal of the case.

3. An AOD will be prepared at the time the decision is final, or when the office determines that the decision cannot or will not be appealed.


**36.3.1.4** **(03-14-2013)**

### Drafting an AOD

1. An AOD should:



   - Be written concisely

   - Include only relevant facts

   - Include only facts taken from the court opinion or the public record of the case

   - Be a summary of the issue or opinion and the Service's litigation posture on the issue

   - Not contain summaries of the law or a complete analysis of the legal issues and facts of the case

   - Generally be no more than two pages


2. The recommendation in every AOD will be summarized as acquiescence, acquiescence in result only, or nonacquiescence.



1. Acquiescence means that the Service accepts the holding of the court in a case and that the Service will follow it in disposing of cases with the same controlling facts. It does not indicate approval or disapproval of the reasons assigned by the court for its conclusions.

2. Acquiescence in result only means that the Service accepts the holding of the court in a case and that the Service will follow it in disposing of cases with the same controlling facts. It also indicates disagreement or concern with some or all of the reasons assigned by the court for its conclusions.

3. Nonacquiescence signifies that, although the decision was not appealed or was not reviewed by the Supreme Court, the Service does not agree with the holding of the court and will not follow it nationwide in disposing of other cases. With respect to opinions of an appellate court, the Service generally will follow the holding n cases appealable to that circuit due to the binding nature of the opinion on lower courts even when the office concludes that the opinion is erroneous. The AOD may include a statement that the holding will not be followed in future cases in the circuit if the case can be distinguished on the facts. Any decision to not follow circuit court precedence in that circuit is a strategic decision, which can only made after consultation with the Department of Justice Tax Division.


3. Generally, the recommendation should be explained in the discussion portion of the AOD. An explanation should be included, for example, when the Service is seeking other cases with the same issues to establish a conflict among the circuits, or when the Service anticipates revoking or modifying a regulation or revenue ruling. When the Service is recommending nonacquiescence to a circuit court opinion, the discussion generally should include the following statement, articulating that Service personnel are expected to follow the circuit precedent, unless the case can be distinguished:



> "Although we disagree with the decision of the court, we recognize the precedential effect of the decision to cases appealable to the \_\_th Circuit, and therefore will follow it with respect to cases within that circuit, if the opinion cannot be meaningfully distinguished. We do not, however, acquiesce to the opinion and will continue to litigate our position in cases in other circuits."

4. In those very rare circumstances when the office determines that the issue will continue to be litigated in the deciding circuit or that the case does not establish controlling circuit precedent because its holding can be limited to its unique facts, the author should not include the statement set forth in paragraph (3). Instead, the AOD should provide clear directions to Service personnel for resolving cases appealable to that circuit. See, for example, United States v. Roxworthy, AOD 2007-4, IRB 2007-40 (Oct. 1, 2007) which provides, "The Service will continue to aggressively seek the enforcement of summonses, including those challenging unjustified assertions of work product in all appropriate cases, including those that would be appealable to the Sixth Circuit."


**36.3.1.5** **(03-14-2013)**

### Format of AOD

1. The format of an AOD is shown in Exhibit 36.4.1–26, Action on Decision.



1. Include the correct citation, including the case name under the Subject heading.

2. Include as part of the complete citation under the case name, any prior and subsequent history, but avoid unofficial citations.

3. Include the Tax Court docket number, if applicable, under the citation.

4. Do **not** date the AOD. See CCDM 36.3.1.7.


**36.3.1.6** **(03-14-2013)**

### Coordination of AODs

1. Only one AOD is issued in a case. The proposed AOD therefore must be fully coordinated with any other office that may have an interest in the issues adversely decided by the court.

2. If two or more Associate Chief Counsel offices have subject matter jurisdiction for the significant issues(s) in a case, those offices should confer and determine which office will issue the AOD. The offices may decide that the AOD will be signed and issued jointly by the offices affected.

3. The formal views of the Commissioner will be obtained on issues that affect the administrative operations of the Service.


**36.3.1.7** **(03-14-2013)**

### Approval and Issuance of AODs

1. The proposed AOD will be signed by the preparing attorney and initialed by all reviewers prior to its review by the Associate Chief Counsel, who signs on behalf of the Chief Counsel. See Exhibit 36.4.1–26, Action on Decision.

2. AODs generally are not issued in any case until litigation of the case is concluded or litigation of any cases with related issues is concluded.



1. To ensure related issues are identified, the attorney assigned to prepare the AOD should prepare a memorandum on related issues or cases. This memorandum should discuss such issues or cases and their relationship to the issues addressed by the AOD.

2. All of the circumstances of the case must be considered when determining if an issue is "related" . No all-encompassing definition is possible; the question must be resolved in each case by taking into account any possible prejudice to the Government's position if the AOD is approved prior to the conclusion of litigation in the related case. If any issue in a case is dependent for its resolution upon the same or similar legal or factual considerations as the issue for which the AOD is issued, the issues should be regarded as related. If there is reasonable doubt whether the issues are related, the matter generally should be resolved by treating the issues as being related.


3. The office may decide that issuance of an AOD is warranted, but may choose to defer issuance to a later date. A deferred AOD may be appropriate when the Service's position is unsettled, the office is contemplating published guidance on the issue, or the decision to issue the AOD must await other legal or policy determinations.

4. During the preparation or review of an AOD, consideration should be given, when appropriate, to whether there is a need for changes in the regulations or for new legislation. If an amendment to regulations is necessary for the purpose of clarifying the law or facilitating the administration of the issue involved as it may arise in future cases, or to accord with the court's decision if it is to be followed, the attorney should prepare a memorandum describing the changes needed along with the reasons for those changes. If the attorney believes that revision of the Internal Revenue Code is necessary, a similar memorandum should be prepared. These memoranda should be circulated along with the AOD.

5. If the holding of the court is contrary, in whole or in part, to a technical pronouncement such as a revenue ruling or procedure, consideration must be given to whether the technical pronouncement should be revoked or modified to accord with the court's opinion. If the recommendation is for acquiescence, the discussion portion should state in what manner the litigating position of the office, as stated in the technical pronouncement, is incorrect. An accompanying memorandum should be prepared by the Associate Chief Counsel office attorney, which discusses in greater detail than in the AOD the basis for the conclusion that the technical pronouncement should be modified or revoked.

6. After signature by the Associate Chief Counsel, the AOD will be forwarded to the Technical Services Support Branch (TSS), Legal Processing Division, Office of the Associate Chief Counsel (P&A) for processing and publication.


**36.3.1.8** **(03-14-2013)**

### Distribution and Publication of Approved AODs

1. Upon final approval of an AOD, TSS will coordinate publication of the AOD’s recommendation for acquiescence, nonacquiescence or acquiescence in result only in the Internal Revenue Bulletin.

2. The Publication and Regulations Branch, Legal Processing Division, will prepare a "Submission of Federal Rules Under the Congressional Review Act" form and forward it to the Congressional leadership for the Senate and House of Representatives.

3. Upon submission for Congressional review, the AOD will be date stamped. The date stamp affixed to the AOD will be the same date as the Internal Revenue Bulletin in which the recommendation is published and released simultaneously to the public via the [Freedom of Information Act portal](http://www.irs.gov/uac/IRS-Freedom-of-Information) on IRS.gov.


**36.3.1.9** **(03-14-2013)**

### Inquiries from the Public

1. Prior to publication, attorneys may not discuss the issuance or possible issuance of an AOD with taxpayers or the public.

2. After publication, the public may be informed of the AOD's position on such issues and that copies of such action are available in the Internal Revenue Bulletin.


**36.3.1.10** **(03-14-2013)**

### Chief Counsel Notices to Announce Changes in Service Litigating Positions

1. To ensure that all Counsel offices act uniformly in handling docketed and nondocketed cases, Associate Chief Counsel offices may announce changes in Service litigating positions in Chief Counsel Notices. These Notices will bear a uniform title, CHANGE IN LITIGATING POSITION, and a cancellation date as follows:



1. If the Notice announces a change in position that will be reflected in a form of guidance, the cancellation date should be " _upon issuance of published guidance._" The content of the Notice should state specifically the form of guidance that will be published and when it is anticipated it will be issued.

2. If the Notice announces a change in position that should be incorporated into the CCDM, the cancellation date should be " _upon incorporation in the CCDM_" .

3. If the Notice announces a change in position that is not appropriate for published guidance or incorporation in the CCDM, but is anticipated to be permanent, the cancellation date will be " _effective until further notice._"


2. Each Chief Counsel Notice will bear a Chief Counsel Uniform Issue List number to facilitate research of these documents. These Notices, like all Chief Counsel Notices, will be made available to the public through the [FOIA Electronic Reading Room](http://www.irs.gov/uac/Electronic-Reading-Room) .

3. The earliest possible coordination of changes in Service litigating positions is intended through Chief Counsel Notices, but the orderly preparation, scope and purpose of AODs and Litigation Guideline Memoranda (LGM) should continue.

4. Chief Counsel Notices are available in the IRS’s [FOIA Electronic Reading Room](http://www.irs.gov/uac/Electronic-Reading-Room) and through theCC Notices site. on the Chief Counsel intranet.


**36.3.1.11** **(03-14-2013)**

### Reconsideration of Actions

1. As a result of revisions in the technical or litigating position of the office, it is necessary from time to time to reconsider outstanding AODs and Chief Counsel Notices. Published actions for either acquiescence or nonacquiescence may be affected by new regulations or rulings, changes in existing regulations or rulings, subsequent court decisions, technical or litigation positions taken in letters to the Department of Justice, or other official memoranda. Attorneys, on their own initiative or at the direction of their supervisors, should consider and initiate any appropriate revisions of outstanding AODs or Notices whenever the need appears. The Department of Justice also may request revisions of published AODs or Notices in connection with cases involving similar issues that are being litigated by them. Such requested revisions should be processed as quickly as is practicable.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part36/irm_36-003-001#addtoany "Show all")

A2A