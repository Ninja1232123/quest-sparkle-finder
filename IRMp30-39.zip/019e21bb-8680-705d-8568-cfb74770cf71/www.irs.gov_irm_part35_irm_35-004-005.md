---
url: "https://www.irs.gov/irm/part35/irm_35-004-005"
title: "35.4.5 Evidence and Information from Abroad | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-004-005#main-content)

- 35.4.5 [Evidence and Information from Abroad](https://www.irs.gov/irm/part35/irm_35-004-005#idm140295815893856)
  - 35.4.5.1 [Introduction to Obtaining Information and Admissible Evidence from Abroad](https://www.irs.gov/irm/part35/irm_35-004-005#idm140295813618512)
  - 35.4.5.2 [Obtaining Evidence from Abroad Administratively](https://www.irs.gov/irm/part35/irm_35-004-005#idm140295802507728)

    - 35.4.5.2.1 [Formal Document Requests](https://www.irs.gov/irm/part35/irm_35-004-005#idm140295809097920)
    - 35.4.5.2.2 [Tax Attach](https://www.irs.gov/irm/part35/irm_35-004-005#idm140295803362512)
    - 35.4.5.2.3 [Tax Treaties](https://www.irs.gov/irm/part35/irm_35-004-005#idm140295822803728)
    - 35.4.5.2.4 [Tax Information Exchange Agreements](https://www.irs.gov/irm/part35/irm_35-004-005#idm140295813486880)

  - 35.4.5.3 [Obtaining Evidence From Abroad Judicially](https://www.irs.gov/irm/part35/irm_35-004-005#idm140295813518704)

    - 35.4.5.3.1 [Judicial Subpoenas](https://www.irs.gov/irm/part35/irm_35-004-005#idm140295824185312)
    - 35.4.5.3.2 [Letters Rogatory](https://www.irs.gov/irm/part35/irm_35-004-005#idm140295809710480)
    - 35.4.5.3.3 [Letters of Request under the Hague Evidence Convention](https://www.irs.gov/irm/part35/irm_35-004-005#idm140295822816336)
    - 35.4.5.3.4 [Discovery](https://www.irs.gov/irm/part35/irm_35-004-005#idm140295818878176)

  - 35.4.5.4 [Obtaining Testimony from Persons Outside the United States by Use of Depositions](https://www.irs.gov/irm/part35/irm_35-004-005#idm140295823727344)

    - 35.4.5.4.1 [Civil Cases](https://www.irs.gov/irm/part35/irm_35-004-005#idm140295817351664)

  - 35.4.5.5 [Authentication of Documents](https://www.irs.gov/irm/part35/irm_35-004-005#idm140295811263632)

    - 35.4.5.5.1 [Foreign Public Documents](https://www.irs.gov/irm/part35/irm_35-004-005#idm140295814774816)
    - 35.4.5.5.2 [Foreign Business Records](https://www.irs.gov/irm/part35/irm_35-004-005#idm140295816876304)

  - 35.4.5.6 [Proof of Foreign Law](https://www.irs.gov/irm/part35/irm_35-004-005#idm140295807935248)

    - 35.4.5.6.1 [Available Sources](https://www.irs.gov/irm/part35/irm_35-004-005#idm140295806899728)

  - 35.4.5.7 [Service of Documents Abroad](https://www.irs.gov/irm/part35/irm_35-004-005#idm140295806676880)
  - 35.4.5.8 [Requesting the Assistance of the Associate Chief Counsel (International) in Obtaining Foreign Information](https://www.irs.gov/irm/part35/irm_35-004-005#idm140295809096560)

    - 35.4.5.8.1 [Procedures for Requesting Foreign Information](https://www.irs.gov/irm/part35/irm_35-004-005#idm140295803295264)
    - 35.4.5.8.2 [Information to be Provided to the Associate Chief Counsel (International)](https://www.irs.gov/irm/part35/irm_35-004-005#idm140295822863856)

  - 35.4.5.9 [Translation of Foreign Language Documents](https://www.irs.gov/irm/part35/irm_35-004-005#idm140295813783520)
  - 35.4.5.10 [Cases Involving Competent Authority](https://www.irs.gov/irm/part35/irm_35-004-005#idm140295810656368)

# Part 35. Tax Court Litigation

# Chapter 4. Pre-Trial Activities

# Section 5. Evidence and Information from Abroad

* * *

## 35.4.5 Evidence and Information from Abroad

#### Manual Transmittal

January 18, 2013

#### Purpose

(1) This transmits revised CCDM 35.4.5, Pre-Trial Activities; Evidence and Information from Abroad.

#### Material Changes

(1) CCDM 35.4.5.9 was revised to provide more specific instructions for obtaining translation of foreign-language documents from the Office of the Deputy Commissioner, International (LB&I).

(2) Titles and hyperlinks were added to references throughout the section.

#### Effect on Other Documents

CCDM 35.4.5 dated December 21, 2010 is superseded.

#### Audience

Chief Counsel

#### Effective Date

(01-18-2013)

Deborah A. Butler

Associate Chief Counsel

(Procedure and Administration)

**35.4.5.1** **(12-21-2010)**

### Introduction to Obtaining Information and Admissible Evidence from Abroad

1. The globalization of economic transactions means evidence or information from foreign countries is frequently needed in connection with settlement negotiations or trial preparation. There are two keys to success in obtaining information and admissible evidence from abroad: start early and always work through the office of the Associate Chief Counsel (International), Branch 7. In many instances, it takes weeks, and sometimes months, to obtain the desired information. Because of the sensitivity of performing official governmental acts abroad, no Field attorney should attempt to obtain evidence or factual information from foreign countries no matter how routine, or interview a witness located in a foreign country, without first coordinating with the Associate Chief Counsel (International), Branch 7. That office, as appropriate, will coordinate with the Deputy Commissioner (International) (LB&I), who is the Competent Authority under all United States tax treaties through whom all tax treaty requests for exchange of information assistance must be made. The Field attorney should not, on her own, attempt to obtain such information even though it covers more or less routine matters. This applies even to Field Counsel offices in areas adjoining Canada or Mexico.

2. The Associate Chief Counsel (International), Branch 7 is also available to provide assistance to Field Counsel in resolving foreign law problems such as: how to secure documents from abroad in admissible form ( _see_ CCDM 35.4.5.3.2), procedures for foreign depositions ( _see_ CCDM 35.4.5.4), the use and limitations of subpoenas ( _see_ CCDM 35.4.5.3.1) and, requests for production of documents located abroad ( _see_ CCDM 35.4.5.2.1).

3. Make requests for information located abroad as soon as it appears that such information will be required even before the case appears on a trial calendar. Field attorneys should be aware that where a foreign government is to provide information, the Office of Chief Counsel depends entirely on that country’s cooperation. Accordingly, timely responses to requests that are not made well in advance of any scheduled trial cannot be guaranteed. If time constraints are severe, the Associate Chief Counsel (International), Branch 7 may be contacted by telephone to determine whether arrangements can be made to meet deadlines.

4. Field Counsel attorneys should provide the Associate Chief Counsel (International), Branch 7 with copies of all materials developed by them (briefs, memoranda, advisory opinions and reports of experts, responses to discovery, etc.) involving foreign law issues whether procedural or substantive. The Associate Chief Counsel (International), Branch 7 serves as a repository of information on foreign law, and the documents will help build a base of source material for dissemination to other Field Counsel offices desiring assistance.

5. When a subpoena or summons has been issued or a request made for production of documents which relate to evidence or factual information located abroad, advise the Associate Chief Counsel (International), Branch 7 of the success or failure of such measures.

6. The Director, Field Specialists, (LB&I) maintains centralized sources of economic data which may be useful in some cases, particularly section 482 cases involving foreign subsidiaries. The office has economists who may assist the Field attorney in certain types of cases. Requests for the assistance of an economist in the handling and processing of a case may be made by memorandum addressed to the Director, Field Specialists (LB&I). More information on the economist program can be found on the Economists webpage, under the LB&I/Field Specialists website.


**35.4.5.2** **(12-21-2010)**

### Obtaining Evidence from Abroad Administratively

1. In any situation in which information from abroad is required, the Deputy Commissioner (International) (LB&I) can provide valuable assistance. In addition to information which may already be in its files, or which may be obtained through exchange of information requests to tax treaty partners, the Deputy Commissioner (International) (LB&I) may obtain information through its Tax Attachés, formerly known as Revenue Service Representatives. _See_ CCDM 35.4.5.2.2.


**35.4.5.2.1** **(08-11-2004)**

#### Formal Document Requests

1. A Formal Document Request is another method of gathering information from abroad administratively. Section 982 provides that if a taxpayer fails to comply with a formal document request arising out of the examination of the tax treatment of any item within 90 days after the mailing of the request by the Secretary, then the taxpayer shall be prohibited from introducing into evidence in a civil proceeding in which the tax treatment of the examined item is in issue any foreign-based documentation covered by the request.

2. The term foreign-based documentation means any documentation held outside the United States which may be relevant or material to the tax treatment of the examined item. The term includes documents held by a foreign entity whether or not controlled by the taxpayer and includes but is not limited to books and records. Thus, section 982 may be used to request a domestic subsidiary to produce documents that are in the possession of its foreign parent.

3. The taxpayer may bring a proceeding to quash the request within 90 days of its mailing. The government may seek compliance in the proceeding to quash.


**35.4.5.2.2** **(12-21-2010)**

#### Tax Attaché

1. Each Tax Attaché is stationed in a particular country and is responsible for a geographical area consisting of several countries. The Tax Attaché and other Service personnel attached to the foreign post are frequently able to gather needed information. Further, the Tax Attaché can be a resource with regard to the types of information and records maintained by specific agencies or courts of the various countries and whether such records are publicly available or privately maintained. Because the Tax Attaché is working outside the territorial jurisdiction of the United States, the procedures which the Tax Attaché uses in exploring a particular matter depends upon formal and informal understandings with the government of the country in which the Tax Attaché is operating. The freedom which the Tax Attaché could exercise might depend upon factors such as whether an American citizen is being interviewed as opposed to a citizen from the country involved or a citizen of a third country, and on whether the government investigation has criminal aspects. Sometimes the agents of the foreign taxing authorities will assist, collaborate or accompany the Tax Attaché on the investigation. In other cases the scope of permissible action of the Tax Attaché may be severely limited.

2. Tax Attachés are currently stationed in Paris, France; Frankfurt, Germany; London, England; Beijing, China; and Plantation, Florida. For a current listing of Tax Attaché assignments and a list of countries covered, refer to the Overseas Posts website under the International tab of the LB&I homepage. The Deputy Commissioner (International) (LB&I) is the contact point for making treaty requests to Canada and France.

3. In some cases, the field attorney or cooperating revenue agent may travel to a foreign country, either alone or with a representative from the Deputy Commissioner (International) (LB&I), for the purpose of obtaining desired information directly. Such foreign investigation would be carried out only after coordination with the Deputy Commissioner (International) (LB&I) and the Associate Chief Counsel (International), Branch 7. This might be appropriate, for example, in a complicated case where extensive knowledge of the case is required in order to interview a witness successfully.


**35.4.5.2.3** **(12-21-2010)**

#### Tax Treaties

1. The United States has negotiated bilateral income tax treaties with many foreign countries. Each treaty is unique, although the subjects covered by treaties are similar. Often the tax treaty will specify the procedures necessary to obtain information and documents from that country. Where the treaty is specific regarding procedures for receipt of foreign documents and information, the treaty provisions must be followed. The United States Competent Authority has exclusive authority for making and receiving exchange of information and administrative assistance requests under all tax treaties. Information and documents obtained pursuant to a tax treaty are privileged and secret and may not be divulged except as specified in the treaty or by written consent of the foreign government. In cases where Field Counsel has documents or other evidence that was received from a foreign country in its files that it plans to provide to the taxpayer or witness, or file with court pleadings or introduce at trial, such actions should first be discussed with the Associate Chief Counsel (International), Branch 7, and coordinated as appropriate, with Deputy Commissioner (International) (LB&I).

2. For a list of current income tax and other tax treaties to which the United States is a party, see the Post Jurisdictions page under the LB&I/International website.


**35.4.5.2.4** **(12-21-2010)**

#### Tax Information Exchange Agreements

1. The United States also has negotiated agreements with numerous foreign countries governing the exchange of tax information. These are Tax Information Exchange Agreements (TIEA). The purpose of each TIEA is to assist each country to assure the accurate assessment and collection of taxes, to prevent fiscal fraud and evasion, and to develop improved information sources for tax matters. TIEAs are separate from tax treaties, but do not supplant an existing treaty. One principal difference between tax treaties and TIEAs is the latter’s legal status in the United States is that of an executive agreement that is authorized to be negotiated by the Secretary of Treasury by I.R.C. § 274(h)(6) and other Internal Revenue Code provisions, as opposed to a tax treaty that is ratified by the Senate. Another difference is that TIEAs are designed principally for the implementation of exchange of information programs between the TIEA signatories, whereas tax treaties include numerous articles designed to alleviate double taxation, as indicated in CCDM 35.4.5.2.3.

2. Insofar as information exchange and administrative assistance in civil and criminal tax matters are concerned, TIEAs and tax treaties generally operate in substantially the same manner. The United States Competent Authority in all TIEAs is the Deputy Commissioner (International) (LB&I). As with tax treaties, the authority and obligation to exchange information under a TIEA extends to information with respect to persons who are not residents or nationals of one of the contracting states. The officials of each country have a duty not to disclose information obtained under a TIEA other than to those involved in the country’s tax administration, and any information exchanged is subject to strict confidentiality and use provisions.

3. A TIEA generally provides for the exchange of tax information pursuant to specific requests, as well as routine and spontaneous exchanges of information, including information necessary or appropriate to carry out and enforce the tax laws of the United States and the beneficiary country (whether criminal or civil proceedings). TIEAs have more detailed provisions than tax treaties, in part because many of the jurisdictions that have signed TIEAs with the U.S. did not have comprehensive procedures in their local law for obtaining information in tax matters. TIEAs thus provide that the U.S. Competent Authority may specifically request that information shall be furnished in the form of depositions of witnesses and authenticated copies of unedited original documents (including books, papers, statements, records, accounts, and writings) in a form admissible into evidence in the Courts of the requesting country. The U.S. Competent Authority may also request information that may otherwise be subject to nondisclosure provisions of the local law of the beneficiary country such as provisions respecting bank secrecy and bearer shares.

4. Under a TIEA, the requested country may:



1. Examine any books, papers, records, or other tangible property which may be relevant or material to such inquiry

2. Question any person having knowledge or in possession, custody or control of information which may be relevant or material to such inquiry

3. Compel any person having knowledge or in possession, custody or control of information which may be relevant or material to such inquiry to appear at a stated time and place and testify under oath and produce books, papers, records, or other tangible property

4. Take such testimony of any individual under oath


**35.4.5.3** **(08-11-2004)**

### Obtaining Evidence From Abroad Judicially

1. This section discusses methods of obtaining evidence from abroad using judicial means.


**35.4.5.3.1** **(08-11-2004)**

#### Judicial Subpoenas

1. Most federal courts are authorized under 28 U.S.C. § 1783 to issue judicial subpoenas to a United States national or resident who is abroad. Such subpoenas may be issued during civil or criminal litigation and in connection with grand jury investigations. The Tax Court, however, is not among the federal courts authorized to issue subpoenas in such cases. Consequently, the Tax Court subpoena power is generally limited to the boundaries of the United States. See CCDM 35.4.3.7, Subpoenas. Under section 7456, the Tax Court may, upon motion and notice by the Secretary and a showing of good cause, order any foreign corporation, a foreign trust or estate, or a non-resident alien individual, who has filed a petition with the Tax Court, to produce books, records, etc., wherever situated, which are in the possession, custody or control of the petitioner, or of any person directly or indirectly under his control or having control over him or subject to the same common control.


**35.4.5.3.2** **(12-21-2010)**

#### Letters Rogatory

1. Letters rogatory are a formal written request by a court or judge to a court or judge in a foreign jurisdiction to summon and cause to be examined a specified witness within the jurisdiction and transmit his testimony for use in a pending action. Testimony of a witness in a foreign country can be obtained by letters rogatory. T.C. Rule 81(e). Obtaining information from abroad through letters rogatory can take a substantial amount of time.

2. The potential usefulness of letters rogatory also depends, to a large extent, on the foreign country involved and on the type of judicial assistance being requested. Although there is no limitation on the type of assistance in obtaining evidence which may be requested, the type of assistance which will be given is completely within the control of the foreign court involved. Thus, many countries will not honor requests which have been issued for pre-trial discovery purposes. Foreign courts might also refuse to cooperate because the request involves the enforcement of tax or fiscal matters, because bank secrecy laws are involved, or for other reasons relating to the policies of the foreign government. Similarly, most countries, including the United States, will not honor requests made by administrative bodies or from executive departments or agencies because such requests do not come from judicial authorities.

3. Use of letters rogatory frequently involves procedural difficulties. For example, if the court to receive the request is in a non-English speaking country it will be necessary to translate the request as well as any pertinent documents. Since the translations must be certified, this can be a time consuming process. Also, many countries require that letters rogatory be transmitted through the State Department and their own foreign ministry or foreign office rather than directly from court to court.

4. Notwithstanding the difficulties which may be encountered, the use of letters rogatory may provide the only possible means for obtaining evidence or for effecting service of process. Moreover, because each foreign country may have a different set of rules and priorities it may be possible to obtain assistance from the foreign court involved beyond that which might be expected. For examples see Exhibit 35.11.1–103, Obtaining Testimony of a Witness in a Foreign Country: Application for a Letter Rogatory, and Exhibit 35.11.1–104, Obtaining Testimony of a Witness in a Foreign Country: Letter Rogatory.


**35.4.5.3.3** **(12-21-2010)**

#### Letters of Request under the Hague Evidence Convention

1. The Convention on the Taking of Evidence Abroad in Civil or Commercial Matters, 23 U.S.T. 2555, T.I.A.S. No. 7444, July 27, 1970 \[1972\] (Hague Evidence Convention), is an international treaty designed to bridge the difference between the common law and civil law approaches to the taking of evidence in civil and commercial transnational disputes. Most common law countries will provide assistance under the Hague Evidence Convention in civil tax cases pending in a court within the United States. Many civil law countries, however, consider tax matters as "fiscal" matters that are not within the scope of the Convention. There are several foreign jurisdictions that have not signed the Hague Evidence Convention, but nonetheless have enacted laws that provide for similar assistance to a foreign applicant, e.g., the Bahamas Evidence (Proceedings in Other Jurisdictions) Act 2000 and the British Virgin Islands Evidence (Proceedings in Other Jurisdictions) Act (1991).

2. Branch 7 of the Associate Chief Counsel (International) provides assistance to Field Counsel offices in the preparation of requests under the Hague Evidence Convention as well as enabling statutes that provide for similar and often a broader scope of assistance. The form of the application to a court for letters requesting assistance under the Convention is similar to that of letters rogatory (Exhibit 35.11.1–103). Rather than requiring transmittal of the request through diplomatic channels, however, the Convention has a much more streamlined procedure for sending the letters of request directly to the Central Authority in the foreign jurisdiction, which is usually a designated official within the Ministry of Justice in the foreign country that will seek to enforce the request. The Central Authority for the United States is the Department of Justice, Office of Foreign Litigation.

3. Pursuant to Chapter I of the Hague Evidence Convention, a litigant may request the court where the action is pending to transmit a Letter of Request to the Central Authority in the foreign country where the evidence is located requesting such authority to obtain evidence or to perform some other judicial act. The Central Authority, selected by the foreign government, then transmits the request to the appropriate court or authority, which conducts the evidentiary proceeding. Upon request, the foreign court will conduct the evidentiary proceeding under the procedures designated by the requesting court, unless those procedures are incompatible with internal law of the requested state.


**35.4.5.3.4** **(08-11-2004)**

#### Discovery

1. It is possible to use Tax Court discovery, including depositions, to obtain information and evidence from abroad. In _Gerling International Insurance Company v. Commissioner_, 86 T.C. 468 (1986) _rev’d on other grounds_, 839 F.2d 131 (3d Cir. 1988), the Tax Court ordered the taxpayer, a domestic corporation, to make available to the Service the books and records of a Swiss corporation that reflected the premiums, losses, and expenses at issue, which the taxpayer claimed arose out of a reinsurance agreement it had with the Swiss corporation. The Tax Court rejected the taxpayer’s contention that it could not produce such records because it lacked control over the Swiss corporation, noting that as a Delaware corporation, the taxpayer was required to, and did, report the information sought by the Service to the insurance regulatory authorities of Delaware. Although the Tax Court in _Gerling_ ordered the taxpayer to produce the records, the court also stated that if the taxpayer failed to produce such records, then the taxpayer would be precluded from introducing the records, or any information derived from such records, into evidence.


**35.4.5.4** **(08-11-2004)**

### Obtaining Testimony from Persons Outside the United States by Use of Depositions

1. Testimony of a witness in a foreign country is usually taken by deposition upon written questions pursuant to letters rogatory or under the Hague Evidence Convention. Tax Court Rule 81(e)(2). Unlike a domestic deposition, if a foreign deposition is to be used, it _must_ be upon written questions, unless otherwise directed by the court for good cause shown. T.C. Rule 84(a). The time factors set forth in Tax Court rules for taking depositions of witnesses in this country do not apply to depositions in foreign countries. It is generally necessary to make preliminary arrangements with the witnesses for the taking of the deposition through the Department of State. In addition, after preliminary arrangements have been made, considerable time may be required for the various courts or officials to issue appropriate instructions for taking the deposition. The laws of the various foreign countries differ greatly as to the procedure to be followed for the taking of depositions. _See_ 22 C.F.R. Part 92 —Notarial and Related Services. Contact the Associate Chief Counsel (International), Branch 7 for assistance in arranging all foreign depositions.

2. Under the laws and treaties with many of the foreign countries, depositions may be taken upon written interrogatories before a consular official. However, there are other foreign countries in which, under their laws and in the absence of special treaty agreements, depositions may only be taken upon letters rogatory. Specific attention is called to the laws of Switzerland which prohibit inquiries relating to fiscal (tax) matters. Such restrictions on banking or similar matters are not unique to Switzerland. Current tax treaties (if any) between the United States and the foreign nation must always be carefully studied. In some instances, certain problems may be eliminated if the witness is willing to go to an adjoining country which permits depositions to be taken upon written questions before consular officials. Preliminary steps with respect to testimony of witnesses in foreign countries, whether by written questions or pursuant to letters rogatory, must be taken prior to issuance of the trial calendar unless all parties are in agreement as to a delay of the trial of the case.

3. Within the United States or a territory or insular possession subject to the dominion of the United States, depositions must be taken before an officer authorized to administer oaths by the laws of the United States or of the place where the examination is held, or before a person appointed by the court. A person so appointed has power to administer oaths and to take such testimony. (T.C. Rule 81(e)(1)).

4. In a foreign country, depositions may be taken on notice before a person authorized to administer oaths or affirmations in the place in which the examination is held, either by the law thereof or by the law of the United States; or before a person commissioned by the court, and a person so commissioned shall have the power, by virtue of the commission, to administer any necessary oath and take testimony; or pursuant to a letter rogatory or a letter of request issued in accordance with the provisions of the Hague Convention (T.C. Rule 81(e)(2)).

5. All arrangements necessary for taking the deposition shall be made by the party filing the application, or in the case of a stipulation, by such other persons as may be agreed upon by the parties. (Tax Court Rule 81(f)(1)). See CCDM 35.4.4.5, Depositions, for a discussion of depositions generally and CCDM 35.4.5.4.1 for depositions abroad.


**35.4.5.4.1** **(08-11-2004)**

#### Civil Cases

1. There are four methods of taking depositions abroad: by stipulation of the parties, on notice, by commission, and pursuant to a letter rogatory. Each method has drawbacks and benefits, depending on the country and circumstances involved. These include convenience to the parties, the type of litigation involved, the identity of the witness and where the deposition is to be taken. Location of the deposition may be the most important because judicial and quasi-judicial actions are severely restricted in many foreign countries.

2. **Deposition by Stipulation of the Parties**. The Tax Court Rules provide for the taking of deposition pursuant to a stipulation. In the Tax Court the use of a stipulation obviates the need for obtaining leave of court to take a deposition to perpetuate testimony. The deposition must conform in all other respects to the requirements of the Tax Court rules. T.C. Rules 81(d), 74(f).



1. From the standpoint of convenience to the litigants, this is usually the fastest method of taking testimony abroad. Since no participation by the foreign government is required, the parties can ensure that the testimony is taken in a manner acceptable to the United States court in which the matter is pending. Even if the method stipulated is not prohibited by the laws of the foreign country, stipulation will be useful only when the witness will testify voluntarily since the parties cannot compel the witness to appear. Another disadvantage is that perjury of the witness may not be punishable unless the examination is made before a person authorized to administer an oath by the laws of the United States. Under 18 U.S.C. § 1621 perjury committed before any person competent to administer oaths authorized by the laws of the United States is punishable, whether the perjury is committed within or without the United States.

2. The taking of a deposition may be considered by some countries to be an official governmental act or a judicial act. Such action may subject the United States to diplomatic or police action. Accordingly, no deposition should be planned or taken in a foreign country without first coordinating with the Associate Chief Counsel (International), Branch 7. Branch 7 will attempt to obtain permission for the deposition and will confirm appointments, arrange for space in the embassy for the deposition and arrange for an interpreter and someone authorized to administer an oath under United States law.


3. **Deposition on Notice**. Under this procedure, the party desiring to take a deposition serves a notice of the taking of the deposition upon the other party. The notice identifies the person before whom the deposition will be taken. Fed. R. Civ. P. 28(b)(1) provides for the taking of a deposition abroad on notice before a person authorized to administer oaths in the place in which the examination is held, either by the law thereof or by the law of the United States. T.C. Rule 81(e)(2) is to the same effect. Depositions on notice, like depositions by stipulation, do not require the intervention of either the United States or foreign courts. This procedure offers another simple and relatively fast method of obtaining testimony abroad for use in a United States court.



1. If the deposition on notice is to be taken before a person authorized to administer oaths under the laws of the foreign country, it will be necessary to make arrangements to have present at the deposition the witness, the foreign official authorized to administer oaths (usually a notary), a reporter or stenographer and, where necessary, an interpreter. Also, instructions must be given to the foreign official concerning the nature of his/her duties and the procedures to be followed. Information concerning the identity and mailing addresses of foreign officials who are authorized to administer oaths and conduct such proceedings is available from a variety of sources including the Martindale-Hubbell Law Directory and the ministry of justice in the foreign country. Additionally, the United States consulates and embassies abroad are authorized to furnish lists of foreign attorneys and notaries located within their district. These lists are maintained by the Department of State, Office of Consular Services.

2. In light of the procedural difficulties and expense usually involved in taking a deposition before a foreign official, it will usually be preferable to take the deposition before an official of the United States.


4. **Deposition by Commission**. A commission is an order issued by the court before which the action is pending, appointing an individual to take the deposition of witnesses who are beyond the jurisdiction of the court. Fed. R. Civ. P. 28(b)(2) provides that depositions may be taken abroad before a person commissioned by the court, and the person so commissioned shall have the power by virtue of his commission to administer any necessary oath and take testimony. To the same effect is T.C. Rule 81(e)(2). The commission may provide that the deposition be taken by oral examination, written interrogatories, or some variation of these methods. The commission procedure differs from the procedures described above primarily in that it requires the court to appoint the person before whom the testimony is to be taken. This may be crucial in countries where depositions on notice before consular officials are not permitted. Like the stipulation and notice procedures, an advantage of taking depositions under commission is that they will necessarily conform to the procedural requirements of the United States court. In addition, in some common-law countries compulsory process is made available to the service upon petitioning the foreign tribunal. In those countries which regard the taking of testimony as a sovereign function, however, the use of the commission is unavailable.

5. **Letters Rogatory**. Since many foreign countries place restrictions on the judicial and quasi-judicial actions which may be taken within their territory, these countries may not allow depositions by stipulation, notice or by commission. In this situation, it will generally be necessary to resort to the use of letters rogatory for foreign depositions. T.C. Rule 81(e)(2). _See_ CCDM 35.4.5.3.2.


**35.4.5.5** **(08-11-2004)**

### Authentication of Documents

1. This section discusses the means to authenticate foreign documents.


**35.4.5.5.1** **(08-11-2004)**

#### Foreign Public Documents

1. There are two methods of authenticating foreign public documents. One is the method set forth in the 1961 Hague Convention Abolishing the Requirement for Legalization of Foreign Public Documents. The second method must be used when documents are destined for or coming from a country which is not a party to the convention and is described in Fed. R. Evid. 902(3).

2. A foreign public document is one which was signed by an individual in their official capacity. Such documents include those from a judicial or other tribunal including the public prosecutor, clerk of court, or process server, administrative documents, notarial acts, or private documents bearing official certifications such as a certificate of registration on official authentication of a signature.

3. Hague Convention. The 1961 Hague Convention Abolishing the Requirement of Legalization for Foreign Public Documents simplifies the certification of documents originating in foreign countries to entitle them to recognition in the United States.



1. Documents intended for use in one or more of the countries party to the Convention will be certified by use of a standardize form called an apostile, which does not require authentication by the Department of State or subsequent legalization by the embassy or consulate of the country of intended use before it is entitled to recognition in that country. Rather, the completed apostile recognizes the document as certified in any of the other countries party to the Convention. Similarly, documents certified by apostile in one of those countries will be entitled to recognition by courts, authorities and private parties in the United States as matter of treaty right. United States consular officers in those countries will no longer issue their certifications for documents that have been certified with an apostile by the local authorities or that should be so certified so as to entitle them to recognition in the United States.

2. The benefits of the Convention apply only between the United States and the other countries party to it. Documents destined for or coming from other countries will continue to require authentication and legalization as before.


**35.4.5.5.2** **(08-11-2004)**

#### Foreign Business Records

1. One of the problems most frequently encountered in handling tax cases involving international aspects is the authentication of foreign business records. Frequently, it is usually easier to obtain copies of the records or excerpts from the records than it is to obtain such copies in admissible form. A typical reason involves the inability of the United States to compel the custodian of the records to provide authenticating testimony. Where authentication of business records is necessary, there are several possible approaches.



1. **Stipulation**. It may be possible to get the opposing party in any litigation to stipulate the authenticity of the records in question. Although obvious, this straight forward approach is sometimes overlooked; on a number of occasions attorneys have gone to inordinate lengths to prove the authenticity of documents by other means only to have opposing counsel readily agree to stipulate authenticity.

2. **Voluntary Testimony by the Record Custodian**. The custodian of the foreign business records may appear as a witness at trial in this country to give the necessary authenticating testimony. If the custodian is a United States citizen or resident, such appearance may be compelled by 28 U.S.C. §1783 if applicable to the particular court (not the Tax Court). If the custodian is a nonresident alien then the appearance would have to be voluntary.

3. **Deposition**. One obvious method of obtaining the necessary testimony is to use the deposition procedures available in Federal courts. See the discussion on use of depositions in CCDM 35.4.5.4.1 above.

4. **Foreign business records** (non-public records of a regularly conducted activity) such as bank records or corporate bookkeeping records, may be introduced into evidence in a United States civil or criminal proceeding without the testimony of a witness (live or by deposition) only if the records are self-authenticating and qualify under an exception to the "hearsay rule," a common law legal principle regarding the admissibility of statements. There are several provisions of U.S. law that provide for exceptions to the hearsay rule in the case of a record of regularly conducted activity. Specifically, 18 U.S.C. § 3505 (regarding criminal proceedings) as well as Rules 803(6) and 902(12) of the Federal Rules of Evidence (regarding civil proceedings) provide that a non-public record of a regularly conducted activity shall be self-authenticating and shall not be excluded from evidence by the hearsay rule if the record is accompanied by a "foreign certification." A foreign certification is a written declaration that is (i) made and signed in a foreign country; (ii) by the custodian of a foreign record of regularly conducted activity or another qualified person; and (iii) that, if falsely made, would subject the maker to criminal penalty under the laws of that country.


2. U.S. authorities may obtain a foreign certification for foreign business records through a treaty or TIEA request, a letter rogatory, or a letter of request. An example of the form that may be used by U.S. authorities for making a request for certification to foreign countries is at as follows:




| CERTIFICATION OF BUSINESS RECORDS |
| :-: |
| I, the undersigned, \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_, with the understanding that I am subject to criminal penalty under the laws of \[Country\] for an intentionally false declaration, declare that I am: employed by/associated with \_\_\_\_\_\_\_\_\_\_\_\_\_\_in the position of \_\_\_\_\_\_\_\_\_\_\_\_and by reason of my position am authorized and qualified to make this declaration. |
| I further declare that the documents attached hereto are original records or true copies of records that: |
| 1. were made at or near the time of the occurrence of the matters set forth therein, by (or from information transmitted by) a person with knowledge of those matters;<br>      <br>2. were kept in the course of regularly conducted business activity;<br>      <br>3. were made by the said business activity as a regular practice; and<br>      <br>4. if not original records, are duplicates of original records. The original or duplicates of these records are maintained in the country of \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_. |
|  | Date of execution: \_\_\_\_\_\_\_\_\_\_\_\_\_\_ |
|  | Place of execution: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |
|  | Signature: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |

3. **Commercial paper**. Under Fed. R. Evid. 902(9) commercial paper and related documents are considered self-authenticating to the extent provided by general commercial law. For all practical purposes general commercial law can be found by reference to the Uniform Commercial Code (U.C.C.). Federal commercial law will apply where federal commercial paper (e.g., Treasury notes) is involved. Pertinent U.C.C. provisions are sections 1–202, 3–307, 3–510, and 8–105. Fed. R. Evid. 902(9) may prove useful and should be considered whenever originals or copies of negotiable instruments, securities, bills of lading, and other commercial paper and related documents are needed as evidence and authenticating testimony is not readily obtainable.

4. **Affidavit**. In _United States v. Leal_, 509 F.2d 122 (9th Cir. 1975), the court admitted certain business records into evidence under the Federal Business Records Act, 28 U.S.C. § 1732 (1970), where the foundation was laid, over the objections of the defendant, by an affidavit of the custodian of the records. Although the method followed in the _Leal_ case would appear to provide an attractive alternative to the somewhat cumbersome process described in 18 U.S.C. § 3491, et seq., there are no cases outside of the Ninth Circuit in which such a procedure has been followed. The records in _Leal_ were hotel registration records required to be maintained by the laws of the Crown Colony of Hong Kong. The court found that many of the guarantees of trustworthiness underlying the official documents and business records exceptions to the hearsay rule were inherent in the documents. Fed. R. Evid. 803(24) was prescribed since _Leal_ was decided. This exception may be appropriate where documents in question are similar to those at issue in _Leal_. In _United States v. Miller_, 830 F.2d 1073, (9th Cir. Cal. 1987), the issue is whether the bank records here sought to be admitted under 18 U.S.C. § 3505 against the defendant bear the indicia of reliability. A statement made by the vice director of the bank certifies the authenticity and accuracy of the records and that they were kept in the ordinary course of business and prepared at or around the time the events occurred by a person familiar with those matters or on the basis of information given by such person. The court held that the records bear indicia of reliability, and that the admission of business records is a firmly rooted exception to the hearsay rule. _See also United States v. Bernard S._, 795 F.2d 749 (9th Cir. 1986). In _Karme v. Comm’r_, 73 T.C. 1163 (1980), _aff’d_, 673 F.2d 1062 (9th Cir. 1982), based on the particular facts of the case, the Tax Court held that records of a Netherlands Antilles Bank made available to an Internal Revenue Service special agent under the United States — Netherlands Income Tax Convention have circumstantial guarantees of trustworthiness and are admissible under the exception set forth in rule 803(24). _See also United States v. Nivica_, 887 F.2d 1110 (1st Cir. Mass. 1989) (based on testimony on chain of custody and the circumstances surrounding preparation of the records, the court held that the records were admissible); _United States v. Pelullo_, 964 F.2d 193 (3d Cir. Pa. 1992) (bank documents like other business records provide circumstantial guarantees of trustworthiness because the banks and their customers rely on their accuracy in the course of their business); _United States v. Wilson_, 249 F.3d 366 (5th Cir. Tex. 2001) (guarantees of trustworthiness of bank records extended to foreign bank records).

5. **Authentication by Testimony from Foreign Government Official**. If the foreign business records were obtained by operation of law by foreign officials, it may be possible to obtain the necessary authenticating testimony from a knowledgeable foreign official who is willing to testify in this country.

6. **Letters Rogatory**. If the authenticating witness declines to give his/her testimony or statement voluntarily, and if jurisdiction cannot be obtained by use of 28 U.S.C. § 1783, it may be possible to proceed by means of a of letter rogatory and have the requested court propound appropriate questions to the witness which will establish the authenticity of the business records. _See_ CCDM 35.4.5.3.2.


**35.4.5.6** **(08-11-2004)**

### Proof of Foreign Law

1. The court, in determining foreign law, may consider any relevant material or source, including testimony, whether or not submitted by a party or admissible under the Federal Rules or Evidence. The court’s determination shall be treated as a ruling on a question of law. T.C. Rule 146.

2. Tax Court Rule 146 requires a party who intends to raise an issue concerning the law of a foreign country give notice in the pleadings or other reasonable written notice. If not included in the pleadings, this notice typically can be accomplished by filing a document entitled Notice of Issue Concerning Foreign Law. The notice would recite that the government hereby notifies the court and the other party that it intends to request the court to consider the law of a particular foreign country, and cite the statute or case to be relied upon.

3. The court may consider any relevant material or source, whether or not the material or source was developed by a party to the lawsuit. This provision gives the court an added amount of flexibility in dealing with questions of foreign law. Often it is appropriate to have an affidavit prepared by a recognized expert in the foreign law in question or to present expert testimony. The court is also free to use its own resources to develop or amplify the material which has been presented by counsel.


**35.4.5.6.1** **(12-21-2010)**

#### Available Sources

1. Available sources of material on foreign law include local university and law libraries, as well as computerized legal research data bases such as LEXIS. The Library of Congress maintains the statutes of many countries and some case law and employs a staff of foreign law experts. The Martindale-Hubbell Law Directory, available online, contains a general discussion of the law of many countries. The Department of State, Office of Consular Services maintains lists of English speaking attorneys in different countries. In addition, foreign law experts may be identified by seeking the assistance of the Tax Attachés and through requests to treaty partners under the exchange of information provisions of the various tax conventions.

2. If difficulty is experienced in locating the foreign law or determining how it should be applied, then the Associate Chief Counsel (International), Branch 7 and the office of the Deputy Commissioner (International) (LB&I) may be contacted. They may provide assistance in locating the foreign law and source material as well as in identifying law experts in particular fields of law in particular countries. Field attorneys are requested to furnish copies of material developed by them involving foreign law issues so that this information may be passed on to other offices saving time and assuring that consistent positions are taken.

3. In addition to the sources mentioned above and the assistance which the Associate Chief Counsel (International) is able to provide, foreign law is subject to discovery under Tax Court Rules 70(b) and 146.


**35.4.5.7** **(08-11-2004)**

### Service of Documents Abroad

1. Questions often arise concerning the service of documents abroad. Where the documents in question are merely copies of notices etc., which are required to be served on the parties to a case, little difficulty is usually encountered. Generally all that is required is service by mail to the party’s counsel or, if appropriate, to the party directly. T.C. Rule 21(b).

2. The first consideration, of course, is whether, under the applicable laws and procedural rules, the document has any force and effect outside the United States. Except as provided in section 7456(b) a Tax Court subpoena can require attendance of witnesses and production of books and records from any place in the United States. Section 7456(b) allows the Tax Court to require the production of books and records by a foreign corporation, foreign trust or estate, or nonresident alien individual where that entity or person has filed a petition in the Court. _See also_ T.C. Rule 72(c).

3. **The Hague Service Convention**. The Convention on the Service Abroad of Judicial and Extrajudicial Documents in Civil or Commercial Matters (Hague Service Convention) prescribes rules that simplify and expedite the procedures for serving judicial and extrajudicial documents abroad. The Hague Service Convention applies only in civil or commercial cases where there is occasion to transmit a judicial or extrajudicial document for service abroad.



1. Under Article 2 of the Convention, each contracting state must designate a Central Authority to receive requests from other contracting states, and to serve, or have served, the documents contained in such requests. Pursuant to Article 6 the Hague Service Convention, the Central Authority of the state receiving a request, or its designated authority, must also complete a certificate indicating that the requested service of the document has been made, or setting forth the reasons why the request has been refused. The State Department is the U.S. Central Authority for purposes of receiving foreign service requests. In addition to the State Department, the Department of Justice and the U.S. Marshal or Deputy Marshal for the judicial district in which service is made are designated for purposes of completing the certificate of service.

2. All requests relating to service of judicial or extrajudicial documents abroad under the Hague Service Convention should be coordinated with the Associate Chief Counsel (International), Branch 7.


**35.4.5.8** **(08-11-2004)**

### Requesting the Assistance of the Associate Chief Counsel (International) in Obtaining Foreign Information

1. In cases where evidence or factual information including testimony and documents is needed from foreign countries in connection with settlement negotiations or trial preparation, a request should be made through the Associate Chief Counsel (International), Branch 7 as soon as possible after jurisdiction vests in the Office of Chief Counsel since it may take an extended period of time to secure the evidence or factual information desired. The Field attorney should be prepared to verify what types of administrative means have been attempted to secure the necessary information from domestic sources both during the examination and litigation stages of this case. Initial contact by the Field attorney to Associate Chief Counsel (International), Branch 7, may be by telephone or by memorandum.

2. Because of the sensitivity of performing official governmental acts abroad, no Field attorney should attempt to obtain evidence or factual information, no matter how routine, from foreign countries. All such attempts must be directed through the Associate Chief Counsel (International), Branch 7.


**35.4.5.8.1** **(12-21-2010)**

#### Procedures for Requesting Foreign Information

1. The request from Field Counsel for foreign evidence or factual information must be in memorandum form, addressed to the Deputy Commissioner (International) (LB&I) through the Associate Chief Counsel (International), Branch 7 setting forth the following matters:



   - The issue(s) involved, including the type of taxes in issue and the tax years

   - The nature of the evidence or factual information desired

   - All available information as to the names and addresses of the witnesses to be interviewed and the location and identification of the documentary material desired, together with all other information which may be of assistance to the Deputy Commissioner (International) (LB&I), in securing the evidence or factual information desired

   - The status of the case to which the desired evidence or factual information relates, with particular reference to whether the case has been or will probably be set for trial, including the date or anticipated date of trial


2. Every effort should be made to forward requests for information located abroad as soon as it appears that such information will be required even before the case appears on a trial calendar. Field attorneys should be aware that where a foreign government is to provide information, the Service depends entirely on that country’s cooperation. Accordingly, timely responses to requests that are not made well in advance of any scheduled trial cannot be guaranteed. If time constraints are severe, the Associate Chief Counsel (International), Branch 7 may be contacted by telephone to determine whether arrangements can be made to meet deadlines.


**35.4.5.8.2** **(08-11-2004)**

#### Information to be Provided to the Associate Chief Counsel (International)

1. The Associate Chief Counsel (International), Branch 7 serves as a repository of information on foreign law, both procedural and substantive, in order to maintain a base of source material for dissemination to Field Counsel desiring assistance.

2. Field Counsel should provide the Associate Chief Counsel (International), Branch 7, with copies of all materials developed by them (briefs, memoranda, advisory opinions and reports of experts, responses to discovery, etc.) involving foreign law issues (whether procedural or substantive).

3. When a summons or subpoena has been issued or a request made for production of documents which relate to evidence or factual information located abroad, the Associate Chief Counsel (International), Branch 7 should be told the success or failure of such measures.


**35.4.5.9** **(01-18-2013)**

### Translation of Foreign Language Documents

1. If respondent intends to offer into evidence a document that is in a foreign language, the document must be translated into English. The parties should work together to stipulate that the English translation of the document is an accurate and true translation. If the parties cannot stipulate that the English translation of the document is an accurate and true translation, see paragraph (7) below.

2. The Tax Treaty Division in the Large Business and International Division (LB&I) can provide the English translations written in the following languages:



   - French

   - German

   - Italian

   - Portuguese

   - Spanish


3. To obtain a translation from the Tax Treaty Division, submit a Request For Translation (Exhibit 35.11.1-234):



   - _By mail:_

      Internal Revenue Service

      Office of the Deputy Commissioner, International (LB&I)

      Attn: Office of Tax Treaty, SE:LM:IN:T:1

      1111 Constitution Avenue, NW

      Washington, DC 20224

   - _By fax:_

      (202) 435-5049


4. The Request For Translation form requires the following information:



   - Requestor’s name and contact information

   - Type of case

   - Date submitted

   - Return date desired

   - Type of translation requested

   - Explanatory background information of the document


5. With the Request For Translation form, provide a copy of the document to be translated. Nothing submitted will be returned. The copy is kept on file for six months and then destroyed.

6. Documents are only translated in ten page increments. If you submit a document longer than ten pages, it will be divided into increments consisting of ten pages. All sets of ten page increments after the first increment of ten pages will be placed in the back of the queue.

7. If the parties cannot stipulate that the English translation of the foreign language document is an accurate and true translation, or for languages other than French, German, Italian, Portuguese and Spanish, an outside translation organization must be contacted. The outside translator’s services must be contracted pursuant to IRC § 6103(n). See IRM 11.3.24, Disclosures to Contractors.


**35.4.5.10** **(12-21-2010)**

### Cases Involving Competent Authority

1. Competent authority procedures for resolving issues arising under an income tax treaty between the United States and a foreign country are described in Revenue Procedure 2002-52, 2002 I.R.B. 242, and amplified in Rev. Proc. 96-13, 1996-1 C.B. 616. Such issues involve the availability to the United States taxpayer of credits against foreign tax, reduced rates of foreign tax, and other benefits and safeguards provided under income tax treaties.

2. The United States has tax treaties with various countries which provide for consultation under certain circumstances between the competent authority of the United States and the competent authority of the treaty country. The Deputy Commissioner (International) (LB&I) acts as the United States competent authority under income tax treaties of the United States in administering the treaty operating provisions, and also in the interpretation or application of the treaties, but after the concurrence of the Associate Chief Counsel (International), in such interpretation or application.

3. In docketed cases, the Chief Counsel and his/her delegates are authorized to sign closing agreements under section 7121 giving effect to part or all of the competent authority determination. See Delegation Order 8-3, Closing Agreements Concerning Internal Revenue Tax Liability, supplemented by:



   - Delegation Order 4-24, Settlement Offers and Closing Agreements in CEP Cases Where Appeals has Effected a Settlement

   - Delegation Order 4-32, Closing Agreements Subject to Internal Revenue Service and Resolution Trust Corporation Inter-Agency Agreement

   - Delegation Order 4-25, Settlement Offers, Closing Agreements, and Settlement Agreements under Section 6224(c) in Cases with Technical Advisor (TA) Program Issues and Appeals Technical Guidance Program (Compliance Coordinated and Appeals Coordinated) Issues

   - Delegation Order 7-13, Authority of Examination, EP/EO and International Group Managers to Accept Classification Settlement Program (CSP) Offers and to Execute the Pro Forma Closing Agreements on CSP issues


### Note:

Under certain treaties it may be possible for a prior closing agreement to be set aside as part of the competent authority determination.

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-004-005#addtoany "Show all")

A2A