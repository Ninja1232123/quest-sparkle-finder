---
url: "https://www.irs.gov/irm/part35/irm_35-005-004"
title: "35.5.4 Settlement of Joint Committee Cases | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-005-004#main-content)

- 35.5.4 [Settlement of Joint Committee Cases](https://www.irs.gov/irm/part35/irm_35-005-004#idm140380203052656)
  - 35.5.4.1 [Introduction](https://www.irs.gov/irm/part35/irm_35-005-004#idm140380219247888)
  - 35.5.4.2 [Attorneys Responsibility](https://www.irs.gov/irm/part35/irm_35-005-004#idm140380227936192)
  - 35.5.4.3 [Method of Computation](https://www.irs.gov/irm/part35/irm_35-005-004#idm140380249077888)
  - 35.5.4.4 [Processing of the Cases](https://www.irs.gov/irm/part35/irm_35-005-004#idm140380213372928)
  - 35.5.4.5 [Preparation of the Report in Tax Court Cases](https://www.irs.gov/irm/part35/irm_35-005-004#idm140380227564080)
  - 35.5.4.6 [Inquiries from the Joint Committee](https://www.irs.gov/irm/part35/irm_35-005-004#idm140380210991936)
  - 35.5.4.7 [Coordination with DJ](https://www.irs.gov/irm/part35/irm_35-005-004#idm140380210998032)
  - 35.5.4.8 [Expedited Joint Committee Reports](https://www.irs.gov/irm/part35/irm_35-005-004#idm140380205681264)
  - 35.5.4.9 [Joint Committee on Taxation FOIA Requests](https://www.irs.gov/irm/part35/irm_35-005-004#idm140380215405808)

# Part 35. Tax Court Litigation

# Chapter 5. Settlement Procedures

# Section 4. Settlement of Joint Committee Cases

* * *

## 35.5.4 Settlement of Joint Committee Cases

#### Manual Transmittal

December 28, 2015

#### Purpose

(1) This transmits new CCDM 35.5.4.9, Joint Committee on Taxation – FOIA Requests.

#### Background

CCDM Parts 30–42 are being completely revised to provide current policy for the Office of Chief Counsel and to incorporate organizational and procedural changes implemented as a result of the reorganization of 2000.

#### Material Changes

(1) CCDM 35.5.4.9 is issued to provide instruction on how to treat Joint Committee on Taxation documents when responding to a Freedom of Information Act (FOIA) request.

#### Effect on Other Documents

New Section 35.5.4.9 cross references CCDM 34.9.1.3.

#### Audience

Chief Counsel

#### Effective Date

(12-28-2015)

Richard R. Goldman

Deputy Associate Chief Counsel

(Procedure & Administration)

**35.5.4.1** **(08-11-2004)**

### Introduction

1. Section 6405(a) provides that no refund or credit of any income, war profits, excess profits, estate, or gift tax, or any tax imposed with respect to public charities, private foundations, operators’ trust funds, pension plans, or real estate investment trusts under chapters 41, 42, 43, or 44 in excess of $2,000,000, shall be made until after the expiration of 30 days from the date upon which a report of such refund or credit is submitted to the Joint Committee on Taxation. The word "tax" includes penalties and interest previously assessed and paid as tax. The statute does not require the reporting of an overassessment which results in an abatement. The Joint Committee is concerned with learning whether the positions taken by the Service are consistent with congressional intent, and the reports required of the Service under section 6405(a) are a principal source of information.

2. Section 6405(b) provides that tentative refunds or credits under section 6411 may be made without making the report required by section 6405(a). A Joint Committee report is required when the correct amount of tax is determined, if the section 6405(b) refund or credit is in excess of $2,000,000. It should be noted that in determining the jurisdictional amount, a credit or refund tentatively allowed under section 6411 should be reduced by any agreed deficiency subsequently determined for that year. The final section 6405(b) amount is not combined with any section 6405(a) amount. Each is kept separate for determining the jurisdictional amount.

3. Section 6405(c) provides that if any refund or credit of income taxes is attributable to the taxpayer’s election under section 165(i) to deduct a disaster loss for the taxable year immediately preceding the taxable year in which the disaster occurred, the refund may be made prior to the submission of a report to the Joint Committee. _See_ Treas. Reg. § 301.6405–1.

4. With respect to a case in a district court, the Court of Federal Claims, the Tax Court, or on appeal to a court of appeals or the Supreme Court, a report must be made to the Joint Committee of any full or partial settlement or concession of issues before the court, which would result in refunds or credits in excess of $2,000,000, after reduction by the amount of offsets which might result should a determination of any remaining issues before the court be in favor of the government. Settlements or concessions made in the Tax Court should not be signed by Field Counsel until the 30-day period has expired. The Field attorney should advise the court and the petitioner that the settlement or concession will not be effective until respondent has considered the views of the Joint Committee.


**35.5.4.2** **(08-11-2004)**

### Attorney’s Responsibility

1. Before proposing any settlement or concession, in whatever form, in any of such cases, the attorney to whom a case is assigned, whether in the field or the Associate office, has the responsibility of ascertaining whether such settlement or concession would result in the case having to be first reported to the Joint Committee. Any partial settlement which could potentially result in a refund in excess of $2,000,000 should only be negotiated with the express understanding that it is subject to Joint Committee review if the disposition of the remaining issues by way of settlement or concession results in a net refund in excess of $2,000,000.

2. In cases pending in Field Counsel in which there is a substantial doubt as to whether the net overpayment resulting from the proposed settlement or concession would make it a Joint Committee case, Field Counsel should request a tentative computation from Appeals. In borderline cases, where there is a substantial doubt as to the interpretation of the guidelines to be applied in determining whether it is a Joint Committee case, Field Counsel should coordinate with APJP, Branch 1 before proceeding further with the settlement or concession.


**35.5.4.3** **(08-11-2004)**

### Method of Computation

1. To compute the aggregate net overpayment resulting from a settlement or concession is sufficient in amount to require review by the Joint Committee, you need to determine the net overpayment of tax, penalty and assessed interest for each year involved separately.

2. Then you add all the net overpayments thus determined for each year to determine the aggregate net overpayment for all the years involved.

3. The separate computations for the jurisdictional limits for sections 6405(a) and 6405(b) amounts may be illustrated as follows:



|     |     |     |     |
| --- | --- | --- | --- |
| _**Example 1:**_ If the 2000 tentative credit or refund was $1,200,000 and an examination of the return resulted in the determination of an overpayment of $1,400,000 in the same tax year, the case is not reportable to the Joint Committee because neither the section 6405(a) amount of $1,400,000 nor the section 6405(b) amount of $1,200,000 is in excess of $2,000,000. However, if either the section 6405(a) amount or section 6405(b) amount exceeds $ 2,000,000, review by the Joint Committee is required of the refund that exceeds $2,000,000. |
| _**Example 2:**_ In multiple-year cases, sections 6405(a) and 6405(b) amounts are computed separately. Assume the following: |
| **_Year_** | **_Net 6405(a) Refund_** | **_Net 6405(b) Refund_** | **_Net deficiency_** |
| 2000 | $700,000 |  |  |
| 2001 |  | $800,000 |  |
| 2002 |  |  | $2,400,000 |
| 2003 |  | $2,400,000 |  |
| 2004 | $3,600,000 |  |  |
| The aggregate section 6405(a) refund is $4,300,000 and the aggregate section 6405(b) refund is $3,200,000. The net deficiency of $2,400,000 should first be applied against the smaller aggregate refund, leaving a section 6405(b) amount of $800,000. Since this is less than $2,000,000, only the section 6405(a) refunds for 2000 and 2004 are reported. If the deficiency had been $3,600,000, the section 6405(b) refunds would have been completely offset and the remaining deficiency of $400,000 would have been applied against the aggregate section 6405(a) refund. Since the net section 6405(a) refund of $3,100,000 would have exceeded $2,000,000, both the 2000 refund and the 2004 refund would be reported. When a deficiency is determined in a nondocketed year, that deficiency is not applied against either the section 6405(a) or section 6405(b) refund. |

4. In making the above computations, amounts paid, accepted by the Service as a tax or penalty, and assessed are taken into account in computing an overpayment. The Joint Committee reviews only overassessments of paid tax. An overassessment of unpaid tax, which under the terms of the settlement or concession will be abated, is omitted from the computation. Also taken into account as part of the overpayment are overpayments of interest which have been assessed and paid. In determining the net overpayment for a specified year, or the aggregate net overpayments for several years, two or more different types of taxes are not combined. Thus, income, gift and estate taxes are considered separate taxes and each of the taxes under chapters 41, 42, 43 and 44 is considered a separate tax.

5. A refund or credit of an amount held as a cash bond is not required to be reported to the Joint Committee regardless of amount. This also applies to a refund or credit of an amount paid with a tentative return in excess of the tax liability shown in the final return. If the amount is in excess of $2,000,000 and is assessed, a report to the Joint Committee is required. _See_ CCDM 35.8.4.3.

6. Problems may arise in cases in which tentative refunds or credits in excess of $2,000,000 have been allowed prior to the issuance of the statutory notice. If the issues involved in the statutory notice are settled or conceded, in whole or in part, Joint Committee review of the adjustments will be required if the net refund still exceeds $2,000,000. _See_ CCDM 35.8.5.2; IRM 8.9.1.6.5.

7. If a refund or credit has been previously reviewed by the Joint Committee, whether in docketed or nondocketed status, and under the settlement an additional overpayment of less than $2,000,000 results from a later examination and determination, further review by the Joint Committee is not required.

8. If a report on a case has been made to the Joint Committee and the Joint Committee returns the case without approval, any subsequent proposed disposition of the case must be reported to the Joint Committee.

9. _See_ Exhibits 35.11.1–109 through 35.11.1–113 for guidance on how to determine whether cases are to be reported to the Joint Committee, methods for computing the relevant overpayment, and sample Joint Committee Reports and transmittal letters.


**35.5.4.4** **(08-11-2004)**

### Processing of the Cases

1. For Joint Committee reports encompassing years under Rev. Proc. 87–24, 1987-1 C.B. 720, the report will be prepared by the office which made the settlement.

2. In court of appeals and Supreme Court cases on appeal from the Tax Court, a district court or the Court of Federal Claims, which require a report to the Joint Committee, DJ prepares the report and transmits it directly to the Joint Committee.


**35.5.4.5** **(08-11-2004)**

### Preparation of the Report in Tax Court Cases

01. In Tax Court cases the report is prepared in letter format and signed by the appropriate Field Counsel. It is addressed to the Chairperson, Joint Committee on Taxation, Attention: Senior Refund Counsel, Room 3565, Internal Revenue Building, 1111 Constitution Ave., NW, Washington, DC 20224. A Joint Committee Report should be brief, concise, and sufficiently clear to permit the reader to understand the adjustments without further reference to another source, except that the report should contain a sentence or sentences indicating that counsel’s proposed disposition is more fully explained in the attached Counsel Settlement Memorandum, and action by appeals (if applicable) is explained in the attached Form 5103, Appeals Case Memo and audit statement.

02. The report should state that as required by section 6405, the following refunds or credits of income tax to \[name of taxpayer\], in Docket No. \[docket no.\] are reported before entry of stipulation. \[Set out the years for which net overpayments will exist plus the amounts of such overpayments and a total of the overpayments. If deficiencies also exist in other years in the case, this should be mentioned even though the deficiencies are not submitted for Joint Committee review. Applicable Counsel and Appeals explanations should be included. Avoid imprecise terminology and, when possible, use technical language from the Code and Regulations.\]

03. Overpayments proposed in other related cases do not enter into the computation. A deficiency determined in the case of one taxpayer is not to be offset against an overpayment determined in the case of another taxpayer, even though the changes resulted from the shifting of income or deductions from one taxpayer to the other.

04. If the settlement encompasses both years before and not before the Tax Court, the years before the Tax Court should be clearly stated. The primary basis of refunds or credits if resulting from carrybacks or carryovers should be set forth briefly and the primary cause of any overpayments. In tabular form, the attorney should set forth the taxable income and tax liability reported on returns and taxable income as finally determined prior to the allowance of any net operating loss deductions. Following that table, the attorney should show by year, type, and amount, any carrybacks or carryovers. If refunds or credits principally result from carrybacks and carryovers, net operating loss deductions should be listed first, followed by a listing of additional investment credits, additional foreign tax credits, and additional work incentive credits.

05. In the report to the Joint Committee, cover only years affecting a refund or credit. For example, if in the consideration of the years 2000 through 2003 a net operating loss for 2003 is carried back to, and fully absorbed in, 2000 and adjustments are made in 2001 and 2002 which do not relate to the cause of the refund or result in overassessment, the report should not cover the intervening years 2001 to 2002. Although the adjustments for these years are not covered, include in the report to the Joint Committee a tabulation of the deficiencies determined, and the net overpayment for jurisdictional purposes.

06. Taxpayer History. The next segment of the Joint Committee report should begin with the heading "Taxpayer History," which should include only relevant data such as type of business activity; principal products; and the number of subsidiaries or affiliates, if pertinent to understanding adjustments or causes of the overassessment. Unless otherwise stated, assume the accounting method is accrual. Give a concise narrative statement explaining the overassessments. For example, if an overassessment is due to a net operating loss, this should be stated — together with underlying causes, i.e., significant decrease in sales, significant increase in deductions, or unusual deduction items.

07. Prior Examination History. There need not be an extensive report of examination history, however, the report should contain:



    - The date of each Revenue Agent’s Report

    - The years covered by each Revenue Agent’s Report

    - The date of each Appeals Case Memo

    - The years covered by each Appeals Case Memo


08. Signature. The Joint Committee report should be prepared for the signature of the appropriate Field Counsel and should include the name and telephone number of the attorney preparing the letter.

09. Exhibit 35.11.1–112 is an example of a report to the Joint Committee.

10. After the report to the Joint Committee has been signed and forwarded, a brief letter should be sent to the petitioner merely stating that the case has been reported. Upon receipt and consideration of the views of the Joint Committee regarding the Office of Chief Counsel’s determination about whether to proceed with the proposed settlement, a brief letter should be sent advising the petitioner of this fact.


**35.5.4.6** **(08-11-2004)**

### Inquiries from the Joint Committee

1. Requests by a Joint Committee staff attorney for clarification of statements in Joint Committee reports and related questions which can be answered by the person identified in the report as the Chief Counsel contact may be resolved by telephone. If additional information is necessary, the Joint Committee may prepare an informal memorandum for response and appropriate action by the Office of Chief Counsel. Normally, this type of response does not involve a significant delay and will not require contact with the petitioner.

2. The Joint Committee sends all formal requests directly to the Chief Counsel, Attention: \[submitting office\]. If the Joint Committee expresses concern about the proposed settlement, the submitting office should coordinate with the appropriate Associate office.

3. Applicable area procedures will, of course, be followed in the handling of Joint Committee matters. Requests for a copy of a document need not be coordinated with the Field Counsel.

4. If the processing of the Joint Committee report may be delayed, the petitioner should be informed of the reasons for the delay and be advised of further developments. The time, method, and nature of the information provided to the petitioner are discretionary.


**35.5.4.7** **(08-11-2004)**

### Coordination with DJ

1. Under section 7122, the Attorney General has the authority to compromise any civil or criminal tax case which has been referred to DJ for prosecution or defense. Therefore, DJ must approve any settlement which encompasses a Tax Court case for one year and a pending refund suit for another year. If DJ obtains jurisdiction after the submission of a report to the Joint Committee by the Office of Chief Counsel, the Field Counsel will prepare a letter briefly explaining that the case is being withdrawn due to the change in jurisdiction (i.e. filing of refund suit after submission of report).

2. The coordination procedures to be followed when the settlement produces an overpayment that must be reported to the Joint Committee are the same as the coordination procedures that are followed when a report to the Joint Committee is not required.

3. To expedite the settlement process in refund Joint Committee cases, Counsel and DJ have agreed that DJ is authorized to submit to the Joint Committee a report as to each compromise or government concession involving a refund of tax, penalty, and interest paid in excess of $2,000,000 which the Office of Chief Counsel has affirmatively recommended or as to each compromise involving a refund of tax, penalty, and interest paid in excess of $2,000,000 in a case that has been classified Settlement Option Procedure (SOP).

4. If the Assistant Attorney General, Tax Division, is in favor of the proposed settlement, the Office of Review will transmit to the Joint Committee the memorandum in support of the settlement. On the same date, the Office of Review also will notify Field Counsel or the appropriate Associate office of the submission of the proposed settlement to the Joint Committee. Final action by DJ on the proposed settlement will be taken after receipt of the views of the Joint Committee.

5. Exhibit 35.11.1–113 is an example of the letter DJ will use in reporting the overpayments and transmitting the supporting memorandum to the Joint Committee.

6. It should also be noted that in accordance with present procedures, if DJ obtains a better settlement than what Counsel has recommended, the case will not be returned to Counsel for consideration.


**35.5.4.8** **(08-11-2004)**

### Expedited Joint Committee Reports

1. The Expedite Refund report (Exhibit 4.36.5–3) is similar to the regular report, with the following exceptions:



1. Write the words, "EXPEDITE REFUND" on the top of the report and Form 4081,and

2. Submit an extra copy of page one of the report.


2. This report will be used:



1. After the case is surveyed or at the completion of the examination,

2. When there is a net unpaid section 6405(a) refund in excess of $2,000,000.


**35.5.4.9** **(12-28-2015)**

### Joint Committee on Taxation – FOIA Requests

01. The Joint Committee on Taxation (Joint Committee or JCT) is authorized under IRC § 8021 to obtain and inspect information, including returns and return information pursuant to IRC § 6103(f), for the purpose of carrying out its general oversight responsibilities.

02. The Joint Committee is authorized under IRC § 8023 to secure directly from the IRS information for the purpose of making investigations, reports and studies relating to internal revenue taxation, including returns and return information, as to any action taken or proposed to be taken by the Service as a result of any audit of the return. _See_ IRC § 8023(a).

03. When the Joint Committee corresponds with the IRS under its general oversight authority, it generally includes a legend on the incoming correspondence that restricts the dissemination and use of both the inquiry and responsive records. The Joint Committee reserves the right to adjust the legend as needed, after coordination with the Service.



    ### Note:



    At this time, the legend reads, “This document is a record of the Joint Committee on Taxation (‘Joint Committee’) and is entrusted to the Department of the Treasury for your use only in handling this matter. Additionally, any documents created by the Department of the Treasury in connection with a response to this Joint Committee document, including (but not limited to) any replies to the Joint Committee, are records of the Joint Committee and shall be segregated from agency records and remain subject to the control of the Joint Committee. Accordingly, the aforementioned documents are not ‘agency records’ for purposes of the Freedom of Information Act. Absent explicit Joint Committee authorization, access to this document and any responsive documents shall be limited to Treasury personnel who need such access for the purposes of providing information or assistance to the Joint Committee.”

04. The incoming JCT document, as well as any documents created by the IRS in connection with a response to the JCT document, including (but not limited to) any replies to the Joint Committee, are records of the Joint Committee and shall be segregated from agency records and remain subject to the control of the Joint Committee. Accordingly, the aforementioned documents are not IRS agency records for purposes of the FOIA.

05. Whenever the Joint Committee’s inquiry letter includes the restrictive legend, the file that is created for the IRS’s reply, as well as any accompanying documents, may only be accessed by IRS personnel for the purpose of providing information to, or otherwise assisting, the Joint Committee. Copies of the inquiry letter and the IRS response are available through the Office of Legislative Affairs in the Communications and Correspondence Tracking System. Copies of records compiled by the IRS to respond to the Joint Committee inquiry are maintained in the office of the IRS component chiefly responsible for preparing the response.

06. Whenever the Joint Committee’s inquiry letter includes the restrictive legend, that letter remains a congressional record and is not an agency record of the IRS. In addition, any records created by the IRS in connection with the agency’s response to the Joint Committee’s inquiry, including (but not limited to) the IRS reply letter, are congressional records and are not IRS agency records. Such documents shall not be considered as responsive to a FOIA request directed to the IRS, and must not be released under the FOIA. Moreover, the IRS file(s) associated with providing records to the Joint Committee need not be searched for responsive records because the records that the files may contain are not agency records.

07. The legend is included as a matter of best practice. It identifies the document as a congressional record, not an IRS agency record. The legend is also an indication of the intent of the parties on how the records should be categorized. However, the absence of the legend is not legally determinative. If a JCT document fails to contain a legend, generally, IRS practice is to treat the JCT document and any IRS response thereto as a congressional record.



    ### Note:



    Consider consulting Chief Counsel (Procedure & Administration) on the treatment of JCT-origin documents that do not contain a legend.

08. A FOIA request received by an IRS Disclosure Office that seeks access to records involving the Joint Committee should be transferred to PGLD’s Office of Disclosure FOIA & Program Operations for processing. Disclosure personnel from the Office of Disclosure FOIA & Program Operations will consult with the Joint Committee, as well as any affected IRS function(s) and Chief Counsel (Procedure & Administration), before determining whether to release or withhold any IRS agency records that are the subject of a Joint Committee oversight inquiry.



    ### Note:



    CCDM 34.9.1.3, entitled, “Requests and Demands for Testimony, Responses to Interrogatories, and Production of Documents,” addresses how to respond to a discovery request that includes documents received from or created by the IRS in response to a congressional committee inquiry.

09. Depending upon the wording of the FOIA request, copies of records created and maintained by the IRS in the normal course of its operations that are subsequently provided to the Joint Committee in response to a general oversight inquiry may be IRS agency records subject to the provisions of the FOIA, or may be considered congressional records not subject to the FOIA.



    1. If the FOIA request specifically asks for records reviewed by the Joint Committee, the disclosure of any records or information, or even the acknowledgement that these records exist in the context of a Joint Committee inquiry, may confirm that the Joint Committee had exercised its general oversight responsibilities. These records are congressional records whether or not the Joint Committee inquiry letter bears a legend restricting dissemination of the records, the records are maintained in files specifically pertaining to the Joint Committee oversight inquiry and are segregated from IRS agency files, and/or the records are accessible only by IRS personnel involved in responding or providing assistance to the Joint Committee.



       ### Note:



       When a FOIA requester asks for “all requests by the Joint Committee for \[a particular matter\],” the IRS will respond that, to the extent such records exist, they are congressional records that are not subject to the FOIA.

    2. If the FOIA request seeks a file, such as an Examination file, which happens to contain records generated in the normal course of its operations that were subsequently furnished to the Joint Committee as part of its general oversight responsibilities, the records in the requested file are IRS agency records subject to the FOIA. Because neither the FOIA request acknowledgement nor the release of the records reveals the existence or the subject of a Joint Committee oversight inquiry, they remain IRS agency records. In the absence of any applicable FOIA exemption, the records in the file will be provided to the requester. For treatment of Joint Committee records in IRC §6405 refund or credit cases, see IRM 11.3.4.6 and IRM 4.36.3.



       ### Note:



       Any records revealing the existence or subject matter of a Joint Committee general oversight inquiry, such as a memorandum seeking or transmitting responsive records, must not be identified as part of IRS agency’s records in the FOIA response letter. Any notation or indication in the IRS agency records that were the subject of Joint Committee inquiry must be withheld as “not responsive” to the FOIA request.


10. In addition to its general oversight authority under IRC § 8023, the Joint Committee is also entitled to reports by the IRS under IRC § 6405 of the IRS’s proposed issuance of refunds or credits that meet the jurisdictional threshold. Section 6405 directs the IRS to delay the issuance of large refunds or credits for a thirty-day period after the report is submitted to the Joint Committee. Correspondence or other documentation reflecting the Joint Committee’s inquiries relating to the proposed credits or refunds will be maintained separately within the administrative file of the taxpayer to whom it pertains. Based upon past practice, Joint Committee correspondence in this context may not contain a legend. However, any documents or information received from the Joint Committee or prepared by the IRS in response to the Joint Committee’s inquiries regarding the proposed refund will not constitute IRS agency records subject to the FOIA. IRS practice is to treat these records as congressional records. Accordingly, the Joint Committee’s response to the IRS’s letter concerning the proposed refund, and any records created by the IRS as a result of, or in response to, the Joint Committee’s response, are not IRS agency records responsive to a FOIA request and must not be released under the FOIA. Moreover, the IRS file(s) associated with providing records to the Joint Committee need not be searched for responsive records because any records the files may contain are not IRS agency records.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-005-004#addtoany "Show all")

A2A