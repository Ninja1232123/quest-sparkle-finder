---
url: "https://www.irs.gov/irm/part35/irm_35-004-009"
title: "35.4.9 Significant Case Procedures, Pre-Trial Submissions and Alternative Dispute Resolution | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-004-009#main-content)

- 35.4.9 [Significant Case Procedures, Pre-Trial Submissions and Alternative Dispute Resolution](https://www.irs.gov/irm/part35/irm_35-004-009#idm140380249143712)
  - 35.4.9.1 [Significant Case Procedures](https://www.irs.gov/irm/part35/irm_35-004-009#idm140380249131600)
  - 35.4.9.2 [Pre-Trial Submissions to the Tax Court](https://www.irs.gov/irm/part35/irm_35-004-009#idm140380249112112)

    - 35.4.9.2.1 [Pretrial Memoranda/Statements of Facts and Issues](https://www.irs.gov/irm/part35/irm_35-004-009#idm140380249106224)
    - 35.4.9.2.2 [Status Reports](https://www.irs.gov/irm/part35/irm_35-004-009#idm140380249095920)
    - 35.4.9.2.3 [Pre-Trial Conferences](https://www.irs.gov/irm/part35/irm_35-004-009#idm140380249088672)
    - 35.4.9.2.4 [Pre-Trial Report ("10 Day Report") to the Presiding Judge](https://www.irs.gov/irm/part35/irm_35-004-009#idm140380249080128)

  - 35.4.9.3 [Alternative Dispute Resolution](https://www.irs.gov/irm/part35/irm_35-004-009#idm140380249076864)

# Part 35. Tax Court Litigation

# Chapter 4. Pre-Trial Activities

# Section 9. Significant Case Procedures, Pre-Trial Submissions and Alternative Dispute Resolution

* * *

## 35.4.9 Significant Case Procedures, Pre-Trial Submissions and Alternative Dispute Resolution

#### Manual Transmittal

June 17, 2013

#### Purpose

(1) This transmits revised CCDM 35.4.9, Pre−Trial Activities; Significant Case Procedures, Pre−Trial Submissions, and Alternative Dispute Resolution.

#### Material Changes

(1) CCDM 35.4.9.2 was revised to provide that:

- Questions about Standing Pre-Trial Orders or Standing Pretrial Notices should be directed to the Office of Associate Chief Counsel (Procedure and Administration) Branch 6 or Branch 7

- Any deviation in a Standing Pretrial Order or Notice that varies from the current format should immediately be brought to the attention of the P&A Special Counsel for Tax Practice and Procedure


(2) CCDM 35.4.9.2.1 was revised to provide that Pre-Trial memoranda in small tax cases must be received by the Tax Court at least seven calendar days before the first date of the trial.

#### Effect on Other Documents

CCDM 35.4.9, dated August 27, 2010, is superseded. This revision incorporated the procedures found in Chief Counsel Notice CC-2009-019.

#### Audience

Chief Counsel

#### Effective Date

(06-17-2013)

Kathryn A. Zuba

Deputy Associate Chief Counsel

(Procedure and Administration)

**35.4.9.1** **(08-11-2004)**

### Significant Case Procedures

1. Significant Case procedures are discussed in CCDM 31.2.1, Significant Case Program.


**35.4.9.2** **(06-17-2013)**

### Pre-Trial Submissions to the Tax Court

1. On February 10, 2003, the Tax Court adopted changes to the format of the Standing Pre-Trial Order, which is to be used commencing in the Fall 2003 trial sessions. The judge typically issues a pretrial order with respect to the action the parties must take in preparing the case for trial. See Exhibit 35.11.1−106, U.S. Tax Court Standing Pretrial Order, which is the standing pretrial order presently in use. Failure to comply with the pretrial order can result in the imposition of sanctions.

2. It is the responsibility of the attorney and the reviewer to make sure that the terms of the standing pretrial order are met. Substantial questions concerning the meaning of the standing pretrial order in a particular situation should be the subject of a conference call with petitioner’s counsel and the judge. Failure to meet the terms and conditions of the standing pretrial order may result in the exclusion of evidence or testimony. Do not wait until the calendar call to deal with such questions. Questions about Standing Pre-Trial Orders or Standing Pretrial Notices should be directed to the Office of Associate Chief Counsel (Procedure and Administration) (P&A) Branch 6 or Branch 7. Any deviation in a Standing Pretrial Order or Notice that varies from the current format should immediately be brought to the attention of the P&A Special Counsel for Tax Practice and Procedure.


**35.4.9.2.1** **(06-17-2013)**

#### Pretrial Memoranda/Statements of Facts and Issues

1. Pretrial memoranda are generally required by the terms of the court's pretrial order for all cases when no basis of settlement has been reached as of the date of the report. The purpose of the pretrial memorandum is to provide the court with information about the status of the case, the relative development of the facts and stipulation of facts, the prospective witnesses, issues in dispute and evidentiary questions that may arise. The pretrial memorandum is one of the first opportunities for trial advocacy in connection with a Tax Court case and care must be taken to ensure the pretrial memorandum is complete, accurate, fair and effective. In all cases, the administrative file should be carefully reviewed in connection with preparing the pretrial memorandum. The court may limit the case to those issues and witnesses identified in the pretrial memorandum. The form and content of the pretrial memorandum is specified in the standing pretrial order or other orders directly on point and should be followed. See an example of a pretrial memorandum at Exhibit 35.11.1−107, Pretrial Memorandum.



### Note:



Use the Chief Counsel macros to generate a pretrial memorandum in proper form.

2. Pretrial memoranda may be directly submitted to the Tax Court except for abatement of interest, collection due process answered cases involving novel or significant issues, or when the burden of proof or a _Shea_ issue (relating to a IRC § 66(b) determination regarding community property laws) is raised in the petition. See Exhibit 35.11.1−1, Issues Requiring Associate Office Review, for those issues requiring coordination. In addition, National Office review is required prior to filing when the pretrial memorandum seeks to distinguish a position set forth in published guidance.

3. The Standing Pre−Trial Notice for Small Tax Cases now requires pretrial memoranda to be filed in all small tax cases proceeding to trial, providing the court and the parties with timely and accurate case status information and a concise description of the issues and witnesses to be presented at trial, enhancing the efficient disposition of the cases. Pre-Trial memoranda in small tax cases must be received by the Tax Court at least seven calendar days before the first date of the trial.


**35.4.9.2.2** **(08-11-2004)**

#### Status Reports

1. Status reports are submitted to the Court where specifically ordered or where appropriate to the orderly processing of the case. Examples of matters for which status reports are required or appropriate include:



   - Responding to an order requesting a status report

   - Reporting on efforts to meet Court imposed deadlines for completion of discovery, preparation of stipulated decision documents, identifying witnesses, etc., especially where difficulties in meeting the deadlines are anticipated


2. Status reports may be joint or separate and are generally formal in form.

3. In the event action by the Court is required to deal with the status of the case, consider filing an appropriate motion in addition to the status report.


**35.4.9.2.3** **(08-11-2004)**

#### Pre-Trial Conferences

1. The judge or special trial judge to whom the case has been assigned for trial, will often conduct chambers conferences or telephone conference calls in which discovery schedules, stipulation difficulties, the parties’ position on the issues, and other pretrial issues are discussed. Occasionally the parties’ recollection of facts or issues agreed upon differs from that of the trial judge or each other. Since there is no transcript, there is often very little the field attorney can do to counter the judge’s or opposing counsel’s contrary memories. In these instances, the field attorney should consult with his or her reviewer as to the advisability of memorializing any agreements or lack of agreement for the record. Sound judgment is required in these instances. In general it is better practice to confirm in writing any agreements or concessions made by the parties in contacts where no transcript will be prepared.

2. If such a conference is held during trial sessions, and it is advisable to memorialize the agreements or lack of agreements, a Court reporter would normally be available for this purpose. The field attorney should request permission of the Court to go on the record at the earliest convenient time for purposes of stating the substance of the conference. The field attorney should state for the record the terms of any stipulations reached, as he or she understands them. In addition, the field attorney will state for the record, that, while other matters were discussed, no other agreements were reached. For example, "The parties have just concluded a chambers conference with the Court; we have agreed to stipulate that \[terms stipulated\], and will file a written stipulation to that effect by Friday, \[date\]. While other matters were discussed, no other agreements were reached."

3. Telephone conference calls have been widely used by the Court to conduct pretrial scheduling in lieu of formal status hearings. Since the opportunities for misunderstandings exist, field attorneys should consult with their reviewers in exercising judgment whether to follow up such conference calls with a letter to the petitioner’s representative, with a copy to the trial judge, confirming the agreements reached and acknowledging those areas in which agreements were not reached. In general it is better practice to confirm in writing any agreements or concessions made by the parties in contacts where no transcript will be prepared.


**35.4.9.2.4** **(08-11-2004)**

#### Pre-Trial Report ("10 Day Report" ) to the Presiding Judge

1. The ten-day Pre-Trial Report was discontinued for cases scheduled for trial commencing with the Fall 2003 Trial Term.


**35.4.9.3** **(08-11-2004)**

### Alternative Dispute Resolution

1. For alternative means to resolving disputes, see CCDM 35.5.5, Arbitration and Mediation.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-004-009#addtoany "Show all")

A2A