---
url: "https://www.irs.gov/irm/part35/irm_35-001-002"
title: "35.1.2 Tax Court Terms and Definitions | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-001-002#main-content)

- 35.1.2 [Tax Court Terms and Definitions](https://www.irs.gov/irm/part35/irm_35-001-002#idm140624445016432)
  - 35.1.2.1 [Common Terms](https://www.irs.gov/irm/part35/irm_35-001-002#idm140624413591296)

# Part 35. Tax Court Litigation

# Chapter 1. Tax Court Jurisdiction

# Section 2. Tax Court Terms and Definitions

* * *

## 35.1.2 Tax Court Terms and Definitions

**35.1.2.1** **(08-11-2004)**

### Common Terms

01. Certain terms are commonly used in connection with procedures established by the Tax Court. These terms are described below.

02. Divisions of the Court. Section 7444(c) provides that the chief judge may from time to time divide the Tax Court into divisions of one or more judges. _See_ T.C. Rule 3(a). Under this authority the court is divided into 19 divisions (assuming no vacancies) consisting of one judge for each division.

03. Reports and Decisions. Section 7459 provides for a report upon any proceeding and a decision thereon. The report of a division contains the findings of fact and opinion of the court in the case. These are generally referred to as published opinions, memorandum opinions, and summary opinions. The court may also render unpublished bench opinions or orders. In deficiency cases, the decision of the court sets forth the deficiency or overpayment determined pursuant to the court’s opinion. In declaratory judgment cases, the decision of the court sets forth the declaration of the court as to an administrative determination by the Commissioner. In section 7436 cases, the decision of the court sets forth the determination of the court as to the employment status and section 530 (Revenue Act of 1978) issues, as well as the proper amount of employment tax under that determination. _See_ CCDM 35.8.8.11 and Exhibits 35.11.1–149 through 35.11.1–151 for more information on section 7436 decisions. The date of the decision is the date it is entered on the court’s records rather than the date a judge executes an order or decision document.

04. Case and Proceeding. While the statute refers to a proceeding pending before the Tax Court, the term "case" is used in the Tax Court Rules and by the Office of Chief Counsel.

05. Trial and Hearing. A case is tried at a trial session. The term "hearing" is used with respect to some intermediary action in a case. Thus, there could be a hearing on a motion at either a motions session or at a trial session.

06. Trial and Hearing Notices. A Notice Setting Case for Trial is issued for each case or group of cases calendared for trial at a trial session. An order setting a case for hearing is issued for each motion or other interlocutory proceeding calendared for hearing at a trial or a motions session.

07. Sessions. The Tax Court conducts trial sessions (which may be regular, small, combined regular and small, or special) and motions sessions.

08. General Docket. All Tax Court cases at issue that have not been calendared for trial, assigned to a judge, or submitted for decision are considered to be on the general docket for the designated place of trial and are available for calendaring at a scheduled trial session at that location. A place of trial may be designated by either the petitioner or the respondent.

09. Calendars for Trial and Motions Sessions. Cases calendared by the court for trial at a designated trial session are listed upon a calendar for that session. A trial session’s calendar will also list cases in which motions are calendared for hearing at a trial session. Motions that are calendared for hearing in Washington, D.C., are listed by case upon a calendar for a specified Washington, D.C., motions session.

10. Unassigned Cases. Unassigned cases are those cases that are at issue (including cases in which there are pending motions for improved pleadings) that have not been assigned to a division of the court for disposition by trial or otherwise, and have not been calendared for trial. Unassigned cases are under the supervision and control of the chief judge of the Tax Court.

11. Assigned Cases. An assigned case is one called from a trial calendar at a trial session of the court which is submitted to, retained by, or taken under advisement by the division of the court conducting the session (i.e., the presiding judge) or one which is specifically assigned to a division of the court by the chief judge.

12. Submitted Cases. A submitted case is one that has been tried or fully stipulated and submitted to the court for opinion and decision.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-001-002#addtoany "Show all")

A2A