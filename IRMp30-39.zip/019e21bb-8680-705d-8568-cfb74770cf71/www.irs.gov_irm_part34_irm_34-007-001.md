---
url: "https://www.irs.gov/irm/part34/irm_34-007-001"
title: "34.7.1 Pre-Trial Procedures | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part34/irm_34-007-001#main-content)

- 34.7.1  [Pre-Trial Procedures](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716101161504)
  - 34.7.1.1  [Monitoring Litigation — Contact With and Assistance to the Department of Justice](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716129266528)
    - 34.7.1.1.1  [Informal Discussions and Modifications To Suit Or Defense Letters](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716129264880)
    - 34.7.1.1.2  [Document Requests](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716129259264)
    - 34.7.1.1.3  [Conferences](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716129305776)
    - 34.7.1.1.4  [Discovery Obligations to Preserve Evidence, Including Electronically Stored Information](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716129302896)
      - 34.7.1.1.4.1  [Roles and Responsibilities in Litigation Holds](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716129298448)
      - 34.7.1.1.4.2  [Determining Whether a Litigation Hold Is Necessary - Triggering Events](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716101068352)
      - 34.7.1.1.4.3  [Litigation Hold Procedures](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716101046208)
        - 34.7.1.1.4.3.1  [Litigation Hold Issuance - In General](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716101040128)
          - 34.7.1.1.4.3.1.1  [Litigation Hold Issuance - Timing of Issuance](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716101026512)
          - 34.7.1.1.4.3.1.2  [Litigation Hold Issuance - Scope and Timeframe of the Litigation Hold](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716101017376)
          - 34.7.1.1.4.3.1.3  [Litigation Hold Issuance - Identifying Custodians](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716101008192)
          - 34.7.1.1.4.3.1.4  [Litigation Hold Issuance - Identifying Sources of Evidence](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716100856832)
        - 34.7.1.1.4.3.2  [Litigation Hold Maintenance](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716100846784)
          - 34.7.1.1.4.3.2.1  [Litigation Hold Procedures for Separating Employees](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716100832528)
        - 34.7.1.1.4.3.3  [Collection of Potential Evidence](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716100824560)
        - 34.7.1.1.4.3.4  [Processing and Review of Potential Evidence](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716100798768)
        - 34.7.1.1.4.3.5  [Litigation Hold Release and EDR Termination](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716100788400)
  - 34.7.1.2  [Further Factual Development](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716100780384)
    - 34.7.1.2.1  [Supplemental Investigations — Definition & Scope](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716100779296)
    - 34.7.1.2.2  [When Supplemental Investigation Is Warranted](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716100776592)
    - 34.7.1.2.3  [Procedure for Supplemental Investigation](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716100773264)
      - 34.7.1.2.3.1  [Coordination with Area/Industry Director](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716100765376)
      - 34.7.1.2.3.2  [Request to Associate Chief Counsel (International) for Information Located Abroad](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716100762032)
  - 34.7.1.3  [Further Legal Development](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716100760480)
  - 34.7.1.4  [Requests for Miscellaneous Assistance](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716100757984)
    - 34.7.1.4.1  [Recomputation of Tax Liability](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716100753040)
    - 34.7.1.4.2  [Actuarial Reports](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716100744208)
    - 34.7.1.4.3  [Expert Reports Other Than Actuarial](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716100738144)
  - 34.7.1.5  [Supplemental Litigation Reports](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716100720800)
    - 34.7.1.5.1  [Mandatory Supplemental Litigation Reports](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716100716384)
      - 34.7.1.5.1.1  [Additional Factual Or Legal Development](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716100713392)
      - 34.7.1.5.1.2  [Amended Complaint](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716100709552)
  - 34.7.1.6  [Trial Assistance](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716100707088)
    - 34.7.1.6.1  [Assistance of Service Personnel at Trial](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716100703952)
    - 34.7.1.6.2  [Requests for Depositions or Testimony](https://www.irs.gov/irm/part34/irm_34-007-001#idm139716100694304)

# Part 34. Chief Counsel Directives Manual Litigation in District Court, Bankruptcy Court, Court of Federal Claims, and State Court

# Chapter 7. Pre-Trial Procedures

# Section 1. Pre-Trial Procedures

* * *

## 34.7.1 Pre-Trial Procedures

#### Manual Transmittal

August 03, 2022

#### Purpose

(1) CCDM 34.7.1 is revised to more accurately describe the roles of P&A personnel involved in eDiscovery processes and advise, and to update certain eDiscovery procedures to reflect new technology and processes.

#### Material Changes

(1) CCDM 34.7.1.1.4.3.2.1 is amended to clarify when to submit an electronic discovery request (EDR) for a custodian separating from the IRS.

(2) CCDM 34.7.1.1.4 is amended to include the concept of proportionality in the description of Chief Counsel’s discovery obligations.

(3) CCDM 34.7.1.1.4.1 and 34.7.1.1.4.3.4 are amended to more fully describe the role of CC:PA technology specialists in electronic discovery and clarify the roles of CC:PA Branches 6, 7 and 8 in providing advice on eDiscovery issues.

(4) CCDM 34.7.1.1.4.3.1.4 is amended to update the description of certain sources of electornically stored information (ESI) and to clarify that PA Branches 6 and 7 should be consulted with regards to handling certain sensitive types of evidence.

(5) CCDM 34.7.1.1.4.33 is amended to clarify that custodian self-collection remains an authorized means of collecting ESI.

#### Effect on Other Documents

CCDM 34.7.1.1.4.3.2.1, dated August 13, 2018, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(08-03-2022)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**34.7.1.1** **(08-11-2004)**

### Monitoring Litigation — Contact With and Assistance to the Department of Justice

1. Discussions between Field Counsel and the Department of Justice (DOJ) attorney assigned to a case referred to DOJ are necessary for Field Counsel to stay fully informed of the progress of a suit. These discussions can be useful in determining whether further factual development or an explanation of the Service’s legal position is needed.


**34.7.1.1.1** **(08-11-2004)**

#### Informal Discussions and Modifications To Suit Or Defense Letters

1. A Field Counsel attorney should not informally modify a position taken in a suit or defense letter, or a supplemental suit or defense letter, without the express approval of a supervisor. _See__CCDM 34.7.1.2_. When the DOJ attorney poses complex questions, ask the DOJ attorney to put the request in writing for formal consideration. If the suggested change involves a technical question that had previously been coordinated with an Associate Chief Counsel office, coordinate the modification as well.

2. When the DOJ attorney provides significant information, whether factual or legal, Field Counsel should note the information in a memorandum to the file. Memoranda are useful as aids to the attorney’s memory, they allow the attorney’s supervisor to keep abreast of developments in the case, and they provide a full record for any attorneys subsequently assigned to the case.

3. On occasion, informal modifications of a position taken in a suit, defense, or supplemental letter are necessary because of time constraints. In those cases, in addition to noting the modification in a memorandum to the file, send a confirming letter to the DOJ attorney. Confirming letters avoid misunderstandings because they allow the attorneys the opportunity to confirm that they agree on the exact nature of the modification.

4. The DOJ attorney may prepare the confirming letter, but Field Counsel must read it carefully to ensure that it reflects the agreement accurately.


**34.7.1.1.2** **(02-24-2016)**

#### Document Requests

1. In order to develop a suit for trial, the DOJ attorney may make informal requests for the assistance of Service personnel or for tax returns and other documents. _See__CCDM 34.7.1.2_. In evaluating requests from DOJ for additional returns, transcripts of account, etc., Field Counsel should always consider whether the material requested can be supplied under section 6103. It is the responsibility of Field Counsel to ensure that disclosure is proper.

2. Rather than processing such requests routinely, however, without thought to the time and expense involved, Field Counsel should consider whether the request for assistance is reasonable. Factors to consider in determining whether the request is reasonable are:



   - The time Service personnel must devote to providing the information

   - The expenses involved in gathering the information

   - The amount of tax involved in the suit

   - The precedential value of an opinion in the case

   - The impact on the case should the request not be fulfilled

   - Whether similar requests have been fulfilled in the past


3. Field Counsel should resolve doubts as to reasonableness in favor of complying with the request. If the attorney determines that the request is unreasonable, however, the attorney should confer with a supervisor. If the supervisor determines that the request is unreasonable, inform the DOJ attorney of that determination and try to modify the request to the satisfaction of both. If no satisfactory modification is reached, arrange a telephone conference with both attorneys and their reviewers.

4. After discussion about the appropriate scope of preservation of documents, if the assigned DOJ attorney requests that the Service implement a litigation hold (including a litigation hold for electronically stored information), the Chief Counsel attorney should follow the procedures in _CCDM 34.7.1.1.4_.


**34.7.1.1.3** **(08-11-2004)**

#### Conferences

1. The DOJ attorney may also ask Field Counsel to attend conferences with Government expert witnesses or with opposing counsel and their expert witnesses. Field Counsel should try to accommodate such requests. After attending a conference, Field Counsel should note in a memorandum to the file the names and identities of the participants attending the conference and the details of the discussion.


**34.7.1.1.4** **(08-03-2022)**

#### Discovery Obligations to Preserve Evidence, Including Electronically Stored Information

1. These procedures are designed to assist the Office of Chief Counsel (Counsel) in meeting its discovery obligations to search for, identify, preserve, and collect documents, tangible things, and electronically stored information (ESI) during litigation or in matters that are reasonably anticipated to be litigated. Timely issuance of litigation hold notices and appropriate management of litigation holds will help Counsel and the Service comply with the legal obligation to preserve relevant material.

2. The Federal Rules of Civil Procedure (FRCP), the Rules of the Court of Federal Claims, the Tax Court Rules, and case law permit a party to obtain discovery regarding any non-privileged matter that is relevant to a claim or defense and proportional to the needs of the case. These same authorities also impose obligations on the party that possesses discoverable evidence. This section sets out the specific procedures that Counsel should follow to fulfill obligations respecting discoverable evidence.

3. A litigant’s basic discovery obligations extend equally to ESI and non-ESI materials, such as paper documents and other tangible things. As a consequence, Counsel attorneys should take steps in all phases of discovery to address any and all forms of relevant information in an employee’s possession or under the employee’s control, whether the information exists in an electronic format or otherwise. See also CCDM 30.9.1.6, which describes the obligation to ensure that records subject to a retention schedule are not destroyed during the pendency of litigation.

4. The potential consequences of failing to preserve relevant evidence may be serious. Examples of potential consequences may include monetary sanctions, attorney fees and costs, the drawing of an adverse evidentiary inference against the Service concerning the material it failed to preserve, evidence or claim preclusion, and charges of contempt.

5. For a glossary of the terms used in this section and select legal references see Exhibit 34.12.1-38.


**34.7.1.1.4.1** **(08-03-2022)**

##### Roles and Responsibilities in Litigation Holds

1. The purpose of a litigation hold is to suspend the normal record retention rules and the disposition or processing of records to ensure such records are preserved for use in litigation. Counsel implements litigation holds by notifying employees who may have relevant evidence that they have an obligation to preserve that evidence during the course of litigation. Implementing a litigation hold helps the Service meet its discovery obligations and helps prevent relevant evidence from being inadvertently destroyed as a result of routine record retention policies. A litigation hold applies to all potentially relevant evidence, including documents, tangible things, and ESI, regardless of whether a privilege applies.

2. While litigation holds are implemented by multiple people within the Service and Counsel, the person responsible for determining whether to issue a litigation hold and for implementing such a hold under these procedures is the Counsel attorney responsible for the case (responsible attorney), in conjunction with the attorney’s manager. The responsible attorney is typically the field attorney to whom the case has been assigned or the attorney with the primary work load item (WLI) in the case. In a district court case or other court case, there is generally an attorney from the Department of Justice (DOJ), either with the Tax Division or the United States Attorney’s Office, assigned to the case as well as an attorney from Counsel who serves as the primary point of contact. For the purposes of these litigation hold procedures, the responsible attorney is the assigned Counsel attorney, not the DOJ attorney.

3. Custodians are those employees who create, manage, alter, edit, store, or otherwise possess relevant evidence in any format. Typically, custodians are revenue agents, revenue officers, economists, tax law specialists, and other employees who worked on a case prior to litigation. Custodians can also include Counsel employees. See _CCDM 34.7.1.1.4.3.1.3_ for additional information on how to identify custodians.

4. Branch 8 in the Office of the Associate Chief Counsel (Procedure and Administration) (PA Branch 8) is comprised of attorneys, technology specialists, and paralegals. The attorneys are primarily responsible for processing electronic discovery requests for assistance (EDRs) from the responsible attorney and, when requested by the responsible attorney and to the extent that the PA Branch 8 workload permits, providing the first level of document review for ESI. First level review assistance may not be available in all instances and will be assigned based on the priorities listed in _CCDM 34.7.1.1.4.3.3 (8)_ and workload capacity in the branch. The technology specialists are responsible for all technical aspects of electronic discovery, and training attorneys and paralegals on use of eDiscovery review tools. PA Branch 8 responsibilities include:



   - Conducting first level document review of ESI (e.g., review for deliberative or executive privilege, attorney-client privilege, work product privilege, and redactions required by section 6103, based upon instructions from the responsible attorney). See _CCDM 34.7.1.1.4.3.4 (3)-(4)_ for guidance on requesting assistance with first level review and on what terms review assistance will be provided;

   - Perfecting an EDR so that it can be processed efficiently;

   - Consulting with the responsible attorney regarding applicable case deadlines and the priority to be given an EDR relative to other EDRs;

   - Notifying the responsible attorney when the EDR has been initially processed and providing a timeframe for delivery of results;

   - Tracking EDRs and ensuring that collection is progressing;

   - Maintaining and updating the litigation hold custodian database;

   - Loading ESI into a review tool and delivering ESI to the responsible attorney;

   - Conducting de-duplication of ESI;

   - Returning the ESI to the responsible attorney for further review;

   - Assisting the responsible attorney with any technology issues prior to production; and

   - Notifying appropriate contacts in the Service’s office of Information Technology (IRS-IT) of the termination of a litigation hold.



     ### Note:



     PA Branch 8 is only responsible for ESI litigation hold procedures discussed in this section. If the responsible attorney has legal questions regarding any non-ESI litigation hold procedures or legal questions regarding ESI litigation holds, the responsible attorney should discuss those issues first with the attorney’s manager, and then with the Office of the Associate Chief Counsel (Procedure and Administration, Branches 6 and 7) (PA Branches 6 and 7).


5. IRS-IT performs the collection and initial processing of ESI. PA Branch 8 works directly with IRS-IT to ensure the responsible attorney can meet all discovery obligations.


**34.7.1.1.4.2** **(02-24-2016)**

##### Determining Whether a Litigation Hold Is Necessary - Triggering Events

01. When there is a reasonable expectation of litigation or where litigation has commenced, parties must take “reasonable steps” to preserve files and information that are “relevant to any party’s claim or defense.” In some cases, preservation by Counsel is accomplished when the responsible attorney receives the administrative file for the case. In other cases, however, the responsible attorney must take additional steps in order to preserve evidence not contained in the administrative file. If potentially relevant evidence exists outside the administrative file, the responsible attorney must consider whether to issue a litigation hold under these procedures in order to preserve that evidence.

02. Counsel does not issue a litigation hold under these procedures in every case in litigation, but Counsel attorneys must consider whether to issue a litigation hold in every case in which the Service has a reasonable expectation of litigation or where litigation has commenced. Litigation is commenced when a petition or complaint is filed with a court or other administrative tribunal, such as the Merit Systems Protection Board. The obligation to consider whether it is appropriate to issue a litigation hold applies to all cases involving the Service or the Commissioner as a party. The responsible attorney should also revisit the need to issue a litigation hold from time to time as the case develops and the claims and defenses in the case become clearer.

03. Generally, the obligation to search for and preserve relevant evidence attaches when it is reasonably anticipated that litigation will ensue. The responsible attorney should consider whether to issue a litigation hold notice as soon as litigation is reasonably anticipated. The determination of when litigation is reasonably anticipated should be based upon a good faith and reasonable evaluation of relevant facts and circumstances. Litigation may be reasonably anticipated, for example, when:



    - The taxpayer or taxpayer’s representative has affirmatively represented that the taxpayer will litigate and Counsel has determined that litigation is likely;

    - An issue in the case is designated for litigation at the administrative stage;

    - The taxpayer files a FOIA request for documents and the request causes Counsel to determine that litigation of a matter to which the documents pertain is likely; or

    - The Service has referred a case to Counsel requesting that Counsel initiate suit.


04. Prior to the commencement of litigation, the Service adheres to routine record retention policies. Barring situations where litigation is reasonably anticipated, there is no litigation hold in place. For example, a pending examination, collection case, or Freedom of Information Act (FOIA) request does not generally result in the issuance of a litigation hold. Issuing a litigation hold under these procedures should be considered, however, in matters pending at the administrative level when, based upon the facts and circumstances known at the time, the Service reasonably anticipates future litigation, as indicated above. See _CCDM 34.7.1.1.4.3.1.1_ for more information on the timing of when to issue a litigation hold notice.

05. In some cases in litigation, a litigation hold under these procedures may not be necessary. The responsible attorney should discuss the need for a litigation hold with the attorney’s manager. If the responsible attorney, with a manager’s approval, concludes that a litigation hold is not necessary, the responsible attorney should document the reasons for this decision in the legal file.

06. In district court cases, Court of Federal Claims cases, and other cases handled by DOJ, DOJ’s policy is to send a formal, written request to preserve relevant evidence. When the responsible attorney receives this request, the responsible attorney should promptly contact the assigned DOJ attorney in order to come to agreement regarding the scope of preservation and the steps needed to identify, preserve, and collect relevant evidence. This agreement should also cover whether the litigation hold procedures described in this subsection should be followed in the case, and, if so, the custodians to whom a litigation hold should be issued, the types of evidence requiring preservation, and the process that should be followed to ensure preservation. The agreement with DOJ on each of these matters should be documented and noted in the legal file and confirmed by incorporation into a letter sent to DOJ (typically, the defense letter). This letter should fully reflect the agreement reached, including the agreed upon custodian list.

07. Docketed FOIA cases are a subset of cases handled by DOJ. These cases may not require additional steps to preserve evidence if all evidence relevant to the FOIA request has already been preserved during the processing of the FOIA request at the administrative level. However, in considering the appropriate steps for preservation for the docketed FOIA case, the responsible attorney should consider the need to preserve certain documents other than those documents sought in the FOIA request, as, for example, where the government must defend the adequacy of its search. In all FOIA cases, the responsible attorney should discuss with the attorney’s reviewer and the DOJ attorney the necessity of a litigation hold under these procedures and document all preservation efforts in the legal file. When a litigation hold in a docketed FOIA case requires additional preservation beyond that done at the administrative level, the responsible attorney would typically issue litigation holds to disclosure specialists and any other custodians who may have been involved with the handling of the FOIA request.

08. Litigation holds will typically not be necessary in many Tax Court cases, such as “S” cases, Automated Underreporting (AUR) Program cases, Automated Substitute for Return cases, and routine collection, bankruptcy, and summons (except designated) cases. These cases often have few relevant records and little, if any, ESI. As a result, all the relevant evidence may be contained in the administrative file. Even if it appears that all relevant evidence is already in the responsible attorney’s possession, the responsible attorney should check with any possible custodians in these cases to ensure that custodians do not have any other potentially relevant evidence in their possession.

09. Matters handled by the Office of the Associate Chief Counsel (General Legal Services) (GLS) may require following the litigation hold procedures in this section. However, the responsible attorney, with the approval of the attorney’s manager, should determine whether unique circumstances apply in these cases to merit alternative treatment and to determine the appropriate level of preservation procedures to apply. All appropriate preservation efforts should be documented and noted in the legal file.

10. There may be other docketed Tax Court cases in which it may be appropriate to forego these litigation hold procedures. Generally, those cases would be instances when relevant evidence either does not exist or is not reasonably accessible. For example, if the responsible attorney concludes that discovery is unlikely because the litigated matter presents a pure legal issue, then a litigation hold is not necessary. In cases such as these, the responsible attorney must secure the manager’s approval to forego the litigation hold procedures and document the reason for the decision in the legal file.

11. If another federal agency contacts a Counsel attorney or the Service regarding a litigation hold for documents related to another agency’s case that involves non-tax administration issues, the attorney should contact PA Branches 6 and 7.

12. There may be additional circumstances outside of litigation in which these procedures could apply, such as with inquiries from Congress or other oversight bodies. In these cases, the responsible attorney should consult with the attorney’s manager to determine the extent to which these procedures apply and document the reason for the decision in the legal file.

13. See _CCDM 34.7.1.1.4.3.1.1_ for more information on the timing of when to issue a litigation hold notice once it is determined that it is appropriate to issue one.


**34.7.1.1.4.3** **(08-13-2018)**

##### Litigation Hold Procedures

1. Once the responsible attorney, with the approval of the attorney’s manager, has determined a litigation hold is necessary, the responsible attorney will undertake the following steps:



   - Issuance (_CCDM 34.7.1.1.4.3.1_)

   - Maintenance (_CCDM 34.7.1.1.4.3.2_)

   - Collection (_CCDM 34.7.1.1.4.3.3_)

   - Processing and Review(_CCDM 34.7.1.1.4.3.4_)

   - Release and EDR Termination (_CCDM 34.7.1.1.4.3.5_)


2. For a checklist of specific steps a responsible attorney should follow in issuing a litigation hold, see Exhibit 34.12.1-39.


**34.7.1.1.4.3.1** **(08-03-2022)**

###### Litigation Hold Issuance - In General

1. Once the responsible attorney, with the approval of the attorney’s manager, has determined that a litigation hold is necessary, the responsible attorney must notify custodians in writing of the responsibility to preserve relevant evidence. Custodians have the responsibility not to delete or alter documents, ESI, or other materials once they receive a litigation hold notice. See _CCDM 34.7.1.1.4.3.1.3_ for assistance in identifying potential custodians.

2. Attorneys must provide information for every litigation hold to Chief Counsel’s Litigation Hold Database intranet site. Because other IRS information technology systems, such email servers, rely on the Litigation Hold Database to verify current litigation holds and preserve ESI, potential evidence may be lost if litigation hold information is not entered in the Litigation Hold Database. See _CCDM 34.7.1.1.4.3.1.3 (8)_ for information on how to access the Litigation Hold Database intranet site to enter case and custodian information. Attorneys can find and view litigation holds that have been entered in the Litigation Hold Database using the Litigation Hold Database Query Form.

3. Responsible attorneys initiating holds and sending litigation hold reminders should use the litigation hold email message accessible via the links found on the Litigation Hold Database intranet site. See _CCDM 34.7.1.1.4.3.1.3 (8)_ for information on how to access this site. The email templates found on the Litigation Hold Database intranet site should be used in lieu of older templates found elsewhere.

4. Any litigation hold notice or reminder email should be marked as having **high importance.**

5. Attorneys must encrypt all litigation hold notice and reminder emails to IRS custodians, as they will generally contain taxpayer information and other confidential or privileged information that must be protected. See IRM 10.5.1.6.8 (6)-(7). The subject lines of such email messages should generally indicate that the email is a litigation hold, and may only reference the name of the case as follows:



   - In non-docketed cases (i.e., where the case has not yet been filed in a public docket), litigation hold notification emails to custodians should never contain the taxpayer name in the subject line. This is because the email header information, including the subject line, is not encrypted in IRS systems. As a substitute for return information, a file number may be used, or an abbreviation followed by asterisks (e.g., "M\*\*\*\*\*" ).

   - If the case has been publicly docketed, it is permissible, but not required, to use the docketed case caption in the email subject line.


6. Once a responsible attorney has sent a litigation hold notice email to a custodian, the responsible attorney should ensure that the custodian responds to the email and provides the requested information within seven business days. If a custodian does not respond within seven days, the responsible attorney should follow up with the custodian and, if necessary, the custodian’s manager or the Service Point of Contact. See _CCDM 34.7.1.1.4.3.1.3 (4)_ for additional information on the Service Point of Contact.


    The responsible attorney should work with the attorney’s manager and systems operators to ensure that relevant case-tracking systems (e.g., CASE-MIS and TL-CATS) are updated to document that the responsible attorney has taken reasonable and timely steps to identify and preserve evidence. This includes taking steps to establish appropriate “suspense date” tracking events and ensuring that the aspect code “EDISCV” is added to the case to assist in the tracking of cases involving a request for the preservation and collection of ESI. The responsible attorney and the attorney’s manager should also ensure that the information in these systems are updated throughout the litigation hold process.

7. Whether or not a litigation hold has been issued, the responsible attorney should consider discussing the potential need for exchange of discovery at the Branerton conference. In cases where a litigation hold has not already been issued, if the opposing party or counsel during the Branerton conference affirmatively signals a desire to obtain discovery of ESI or paper files, then the initial litigation hold procedures identified above should be reconsidered. In cases litigated by DOJ, the responsible attorney will have discussed the need for preservation of potential evidence with the assigned DOJ attorney in deciding whether to issue a litigation hold. See _CCDM 34.7.1.1.4.2 (6)_ respecting early consultation and agreement with DOJ.


**34.7.1.1.4.3.1.1** **(08-13-2018)**

###### Litigation Hold Issuance - Timing of Issuance

1. The responsible attorney should issue a litigation hold notice at the earliest possible opportunity and within 30 calendar days after the assignment of the case to the attorney or following the determination that litigation is reasonably anticipated. The timing of the initial litigation hold is inherently fact-specific and will depend on the type of matter and the circumstances affecting the timely preservation of evidence. If a litigation hold is not issued within 30 calendar days, an explanation of the delay in issuing the litigation hold should be included in the legal file and initialed by the manager. The responsible attorney should place copies of the litigation hold notices in the official legal file.

2. When suit is filed by the Government and a litigation hold is necessary, a litigation hold should generally be issued no later than 30 calendar days after the manager within Counsel with the authority to authorize suit issues an approval to proceed. In certain circumstances, it may be appropriate to issue a litigation hold at an earlier stage. See _CCDM 34.7.1.1.4.2 (2)_.

3. When suit is filed against the Commissioner or the Service and a litigation hold is necessary, the responsible attorney, absent unusual circumstances, should generally issue the litigation hold within 30 calendar days of being assigned a case. An example of unusual circumstances would include a case in which the Service failed to provide the administrative file to the responsible attorney within the 30-day time period. In cases handled by DOJ, it is expected that consultation with DOJ regarding the steps needed to identify, preserve, and collect relevant evidence will occur shortly after the case is assigned and, consequently, that the question of the need to issue a litigation hold will be resolved within the 30-day timeframe described above. See _CCDM 34.7.1.1.4.2 (6)_ for a description of the required consultation with DOJ.

4. In certain circumstances, a litigation hold may be necessary before litigation has commenced. The responsible attorney should speak with the attorney’s manager regarding whether a litigation hold should be issued prior to the commencement of litigation. The determination of whether to issue a litigation hold at an earlier phase depends on numerous factors, including, but not limited to, affirmative indications of a party’s intention to litigate, particular case claims and defenses, positions of the parties, evidence quality, evidence availability, or the potential to lose evidence due to retention policies. A litigation hold may be necessary prior to the issuance of the statutory notice of deficiency if, for example, opposing counsel in the case indicates at the examination or Appeals stage that the taxpayer will take the case to court and Counsel has determined that litigation is likely. See _CCDM 34.7.1.1.4.3_ for additional information on triggering events giving rise to reasonable anticipation of litigation.

5. The responsible attorney should always document in the legal file any discussions about whether to initiate a litigation hold and include information reflecting why the responsible attorney, with the approval of the attorney’s manager, did not issue the litigation hold at that time.


**34.7.1.1.4.3.1.2** **(08-13-2018)**

###### Litigation Hold Issuance - Scope and Timeframe of the Litigation Hold

1. Once the responsible attorney has determined that a litigation hold under these procedures is necessary, the responsible attorney should consider the scope of the litigation hold. The proper scope of the litigation hold is guided by general principles of reasonableness and proportionality based upon the totality of the circumstances. The responsible attorney should consider “the importance of the issues at stake in the action, the amount in controversy, the parties’ relative access to relevant information, the parties’ resources, the importance of the discovery in resolving the issues, and whether the burden or expense of the proposed discovery outweighs its likely benefit.” Fed. R. Civ. P. 26(b)(1).

2. A litigation hold could be for paper files and tangible evidence only, but it could also include ESI. Many cases in which a litigation hold under these procedures is necessary will likely include ESI. See _CCDM 34.7.1.1.4.3.1.4_ for a description of various types of ESI. The responsible attorney should direct custodians to IRM 1.15 or CCDM 30.9.2 for additional information on case file management.

3. The responsible attorney should also consider the relevant time period to which the litigation hold should apply. The litigation hold notice should clearly specify the timeframe in which relevant information was created. Rarely will the timeframe extend beyond the date litigation begins, which typically is when the petition or complaint is filed. In a very limited number of cases, however, a litigation hold obligation may extend to a point in time beyond the filing date. In these cases, the responsible attorney, with the approval of a manager, may include in the litigation hold relevant evidence created subsequent to the date the petition is filed in the Tax Court or a complaint is filed in another court. In DOJ cases, the responsible attorney should discuss with DOJ whether it is necessary to extend the relevant time period of the litigation hold beyond the date that the petition or complaint is filed. Examples of cases in which a litigation hold time period may extend beyond the commencement of litigation include:



   - Cases in which the taxpayer has other years in dispute which will likely lead to litigation over related issues;

   - Cases in which parties or entities related to the taxpayer have ongoing litigation;

   - Cases in which the Service is considering a referral to Criminal Investigation for related years or taxpayers;

   - Cases with related whistleblower claims; and

   - Cases involving employment disputes.


4. The responsible attorney may need to discuss the case with custodians before determining the scope and timeframe of the litigation hold.

5. When issuing litigation holds related to examinations of tax shelter promoters, contact PA Branches 6 or 7 for assistance with determining the scope of the litigation hold.


**34.7.1.1.4.3.1.3** **(08-13-2018)**

###### Litigation Hold Issuance - Identifying Custodians

01. In order to send the litigation hold notice, the responsible attorney must first identify potential custodians of relevant documentary and tangible evidence and ESI. In most cases, custodians are Counsel and Service employees (either current or former) who were involved in some aspect of the case before litigation commenced, such as a revenue agent or revenue officer.

02. For most docketed tax cases, the simplest way to identify custodians is to review the relevant case files and any documents filed by the taxpayer or opposing party. Revenue agents and revenue officers involved in a case will typically be able to identify other potential custodians. In some cases, the responsible attorney may need to do additional research to determine who was assigned to a case. Additionally, once the responsible attorney issues an initial litigation hold notice, custodians may suggest additional custodians to whom the litigation hold notice should be sent. The responsible attorney should discuss this search with the attorney’s manager to ensure the responsible attorney identifies all potential custodians. For custodians possessing significant relevant evidence, such as the lead agent or officer assigned to the case, the responsible attorney should consider also calling the custodian to reinforce the need to preserve evidence, especially if the custodian plans to leave the Service or change positions within the Service.

03. The duty to preserve extends to information in the possession, custody, or control of the parties and could potentially include information previously sent to the Federal Records Center or maintained by third parties, such as experts or contractors. Where a custodian is an outside contractor (e.g., economist, industry expert, etc.), the responsible attorney should promptly request that the contractor self-collect all relevant evidence, including ESI, and promptly produce it to the responsible attorney for preservation. When a custodian is an employee of another Federal agency (including other components of the Department of Treasury), the responsible attorney should not directly issue a litigation hold to such custodian, but should discuss and coordinate preservation requests with the other agency’s General Counsel’s office. In DOJ cases, the assigned DOJ attorneys will ordinarily coordinate with other agencies. Litigation holds issued to employees of other Federal agencies should not be entered into the Litigation Hold Database, but must be fully documented in the official legal file, including all communications with agency General Counsel offices.

04. Contact PA Branches 6 or 7 if assistance is required with IRC §6103 or other issues when issuing litigation holds to Counsel or Service custodians on behalf of other federal agencies or third parties.

05. Once the responsible attorney has identified potential custodians, the responsible attorney should determine which of the potential custodians from the Service will be the Service Point of Contact. The Service Point of Contact is the Service employee who is most familiar with the case and who, as a consequence, would likely have additional knowledge about other Service employees (both current and former) who may also possess relevant evidence. The responsible attorney will send the litigation hold notice to the Service Point of Contact and ask the Service Point of Contact to provide information about other, potential custodians. The Service Point of Contact litigation hold notification template is available at the Litigation Hold Database intranet site. Note that there may be a need for more than one Service Point of Contact as there could be different organizations and program offices involved in a particular case, each of which may involve an extensive number of employees.

06. If the custodian identified as the Service Point of Contact responds to the Service Point of Contact email indicating that he or she is not the appropriate Service Point of Contact, the responsible attorney should ask the custodian if there are other potential custodians who should be designated as the Service Point of Contact. If a Service Point of Contact is not identified, the responsible attorney should issue the litigation hold directly to Service employees who may possess relevant documentary and tangible evidence and ESI.

07. If a responsible attorney has insufficient information to determine whether a potential custodian should be issued a litigation hold, the responsible attorney should send the litigation hold notice email to that custodian and make a determination whether to include a custodian in the litigation hold based on the custodian’s response. Responsible attorneys, in conjunction with their managers, should use reasonable judgment in determining the breadth and scope of a litigation hold in light of the relevance of the information a particular custodian may possess or control. In making this determination, the responsible attorney should consider the likely scope of discovery in the case.



    ### Note:



    If a determination is made to exclude a potential custodian from the litigation hold after the initial litigation hold notice has been issued and the custodian has been entered into the Litigation Hold Database, contact PA Branch 8 at the Litigation Hold Mailbox to remove the custodian from the Litigation Hold Database.

08. To initiate the litigation hold process, the responsible attorney must enter the potential custodians’ information into the Litigation Hold Database (as described in subparagraph (9)) and send a litigation hold notice email to all potential custodians using the email templates found on the Litigation Hold Database intranet site. If additional custodians are subsequently identified, such custodians should immediately be sent litigation hold notice emails and entered into the Litigation Hold Database.

09. The responsible attorney must ensure that all custodian information is properly entered into the Litigation Hold Database intranet site. Custodian SEIDs must be verified using the Discovery Directory prior to entering custodian information into the Litigation Hold Database. SEIDs are alphanumeric strings, and all letters must be entered in upper-case. The responsible attorney should pay particular attention to employees with similar names, and confirm that the actual custodian’s SEID is entered, to prevent the erroneous inclusion in the database of an employee with a name similar to that of an actual custodian. For assistance in finding and verifying SEIDs, contact PA Branch 8. The Litigation Hold Database is used to track custodians, assist with collection, and prevent custodians’ email and other files from being deleted from network servers according to normal record retention schedules. Managers and attorneys may confirm that litigation holds have been correctly entered by using the Litigation Hold Database Query Form, which allows searches of the Litigation Hold Database using various filters.



    ### Note:



    Failure to properly enter each custodian’s correct information into the Litigation Hold Database could result in the loss of potential evidence and other adverse consequences.

10. To confirm whether a custodian is in the Litigation Hold Database, or which custodians are subject to litigation holds for a particular case, use the Litigation hold Database Query Form. Attorneys can query and view the contents of the Litigation Hold Database using the Litigation Hold Database Query Form. The query form permits searching and reporting by numerous criteria filters.

11. When DOJ requests that Counsel issue a litigation hold, often the DOJ attorney assigned to the case does not know who the appropriate custodians are. The responsible attorney should promptly confer with the DOJ attorney about the proper scope of the requested litigation hold to meet the preservation needs of the case, and make recommendations about who the appropriate custodians are and why. Once the responsible attorney and DOJ have agreed to a custodian list, the responsible attorney should document that list in both the legal file and in a letter to DOJ.

12. See _CCDM 34.7.1.1.4.3.2_ regarding litigation hold maintenance and what to do if a custodian notifies the responsible attorney that the custodian will be separating from the Service or Counsel, changing positions or organizations within the Service or Counsel, or if the attorney learns that a custodian may have lost or possibly destroyed relevant evidence.


**34.7.1.1.4.3.1.4** **(08-03-2022)**

###### Litigation Hold Issuance - Identifying Sources of Evidence

1. Documents and other tangible evidence are often found in files associated with a particular taxpayer or other party who has had some involvement in the matter that is in litigation (e.g., administrative files, legal files, personnel files, etc.). In tax cases, the administrative file should contain most, if not all, of the relevant evidence. The responsible attorney should always ask custodians if there might be any other evidence relevant to the litigation that is not in the responsible attorney’s possession, including files stored at an audit site.

2. ESI is data generated by custodians and maintained in a form accessible through use of an electronic device. The most common of these sources (also referred to as repositories) maintained by IRS-IT and used by custodians are network drives, email, SharePoint sites, OneDrive, and other network repositories. Some custodians may also store ESI on laptops, PCs, and removable media. Additionally, Service business units often maintain relevant ESI in database-type repositories such as Appeals Centralized Database System (ACDS), Audit Information Management System (AIMS), Issue Management System (IMS), Integrated Collection System (ICS), Integrated Data Retrieval System (IDRS), and Report Generation Software (RGS). Other repositories of ESI are listed in the definition of ESI in the Glossary.

3. Although much ESI within the Service and Counsel is maintained on servers managed by IRS-IT, some data is not backed up to servers and is maintained by the custodians. Working spreadsheets are one type of ESI that may be maintained either on servers or by custodians. Further, Examination teams may maintain computing equipment on the taxpayer's premises that is not managed by IRS-IT. In some cases, multiple versions of the same file may be located in more than one place. The responsible attorney should, through discussions with custodians, try to discern the various places where relevant ESI could be located.

4. The Federal Records Act requires Counsel and the Service to make and preserve records containing adequate and proper documentation of the organization, functions, policies, decisions, procedures, and essential transactions of the agency to protect the legal and financial rights of the Government and of persons directly affected by the agency’s activities. Such records may take a number of forms, and not all forms are listed here. The responsible attorney should ensure, through discussions with custodians, that all relevant records are identified, even if the type of record is not listed in this section.

5. If a custodian indicates that personal email or messaging accounts were used to conduct official business for the case, although this practice is prohibited, the responsible attorney should immediately direct the custodian to forward all relevant emails or messages to the custodian’s work email account to ensure those documents are preserved in the work email account. If the custodian used authorized personally-owned mobile devices to conduct official business related to the case (see IRM 10.8.26.2.2), the responsible attorney should contact PA Branch 8 immediately to determine whether additional steps are necessary to preserve that evidence.

6. If the responsible attorney learns that a custodian possesses sensitive evidence, including grand jury material, secret or top secret material, or Congressional records, or learns that a custodian who possesses evidence is also subject to an unrelated investigation by TIGTA, the responsible attorney should immediately contact PA Branches 6 and 7 for guidance on how best to handle discovery with respect to that evidence.

7. See _CCDM 34.7.1.1.4.3.2_ for additional information on what the responsible attorney should do if a custodian indicates an imminent reason to collect relevant evidence, such as a change in job or equipment malfunction.


**34.7.1.1.4.3.2** **(08-03-2022)**

###### Litigation Hold Maintenance

1. The responsible attorney maintains the litigation hold until a final decision has been reached in the matter, and no possibility remains that the preserved evidence will be needed for the case in the future. The responsible attorney must track and maintain all litigation hold notices and reminders, as well as all custodian responses. Responsible attorneys should periodically confirm the status of litigation holds in the Litigation Hold Database by using the Litigation Hold Database Query Form, which allows searches of the Litigation Hold Database using various filters.

2. Errors or updates to the Litigation Hold Database should be reported to PA Branch 8 at the Litigation Hold Mailbox. Litigating Divisions should establish a plan to regularly check their case litigation holds to ensure continued completeness and accuracy.

3. The responsible attorney should revisit the need for a litigation hold from time to time as the case develops and the claims and defenses in the case become clearer. Additionally, until a litigation hold is lifted, the responsible attorney must periodically send an email to custodians to remind them of their continuing obligation to preserve the material, even after ESI and other potential evidence have been collected or produced. This reminder notice should be sent, at a minimum, every six months after the initial notice email is sent. The Litigation Hold Database intranet site provides the template that must be used when sending litigation hold reminder notice emails.

4. To ensure the reminder notice has been received, the responsible attorney should direct the recipient of the notice to respond within seven business days acknowledging receipt of the email and providing a brief statement as to whether the ESI or other potential evidence remains preserved and unaltered and where the information is being stored. If the responsible attorney does not receive a response within seven days, the responsible attorney should follow up with the custodian and, if necessary, the custodian’s manager or the Service Point of Contact. In addition, the responsible attorney should keep an open line of communication with custodians by, for example, periodically calling them to ensure that ESI is preserved.

5. A “suspense date” reminder in TL-CATS should be created every six months establishing a new reminder date six months hence to ensure the responsible attorney is aware of the obligation to send this reminder notice every six months.

6. When custodians notify the responsible attorney that IT equipment failed (e.g., a hard drive malfunction) that contains ESI subject to the litigation hold, the responsible attorney should immediately notify PA Branch 8 by sending an email to TSS.assignments requesting preservation of any ESI that may have been lost or damaged as a result of the equipment failure.

7. If during the course of maintaining a litigation hold a responsible attorney learns that ESI may have been altered, destroyed, or otherwise compromised, the responsible attorney should immediately notify PA Branch 8 to coordinate an attempt to recover that ESI. See _CCDM 34.7.1.1.4.3.4_ for a discussion of the role of PA Branch 8 in litigation hold processing. Legal questions about potential spoliation and whether there is an obligation to notify the court or opposing party should be directed to PA Branches 6 and 7.

8. If a litigation hold case is transferred to another attorney for any reason, the responsible attorney should ensure that the new attorney understands and assumes the litigation hold responsibilities associated with the case. Updates to the identity of the responsible attorney should be reported to PA Branch 8 at the Litigation Hold Mailbox.

9. During the maintenance phase, the responsible attorney should be prepared for the potential need to collect, process, and produce relevant evidence. If the responsible attorney needs to have ESI collected, the responsible attorney should consider what evidence opposing counsel may request and whether the responsible attorney is capable of producing such evidence.



   - In DOJ cases, the DOJ attorney assigned the matter will have a conference with opposing counsel to create a discovery plan under FRCP Rule 26(f). The DOJ attorney may discuss at the conference various types of evidence, including ESI. It is imperative that the responsible attorney discuss with DOJ available evidence to prevent the DOJ attorney from making any inaccurate representations to the court about what records the Service possesses. It is also important for the responsible attorney and DOJ to agree on the list of anticipated custodians, file types, and preservation methods. When possible, secure agreement from the opposing counsel on these matters at the earliest opportunity.

   - In Tax Court, the responsible attorney should consider what evidence the attorney may need to produce as part of the informal discovery process under Branerton Corp. v. Commissioner, 61 T.C. 691 (1974), and the Tax Court Rules. Where a litigation hold under these procedures and exchange of ESI are called for, the responsible attorney should secure agreement from the petitioner or opposing counsel on the custodian list and search terms at the Branerton conference or other date mutually agreed upon by the responsible attorney and opposing counsel or petitioner. See _CCDM 34.7.1.1.4.3.1 (7)_ for guidance on how to address ESI related issues during the Branerton conference.


**34.7.1.1.4.3.2.1** **(08-03-2022)**

###### Litigation Hold Procedures for Separating Employees

1. Custodians may notify the responsible attorney that their data might need to be collected immediately—for example, when a custodian is separating from the Service or Counsel and potential evidence may be at risk of loss, as could occur if ESI is located in locations or repositories that may not be subject to continuing litigation holds such as laptop hard drives or removable media. If that occurs, the responsible attorney should promptly contact PA Branch 8 by sending a request for assistance to TSS.assignments. PA Branch 8 can advise on whether submission of an Electronic Discovery Request (“EDR”) is necessary under the circumstances. See _CCDM 34.7.1.1.4.3.3_ for more information on how to complete an EDR.

2. Separating custodians must provide information to their managers regarding the documents and ESI in their possession that are subject to litigation holds. The responsible attorney should talk with the separating custodian’s manager to ensure that all relevant evidence and IT equipment is properly preserved. Managers are required to complete Form 14757, Records Management Checklist for Separating Employees, to ensure Chief Counsel and IRS-IT are notified of custodians’ pending separation from IRS and to certify the preservation of all documents subject to litigation holds before separation. The responsible attorney should obtain a copy of the completed Form 14757 for any separating or separated employee. Additionally, although IRS-IT routinely checks Forms 14757 and the Litigation Hold Database to determine whether a separated employee is subject to litigation holds, the responsible attorney should also instruct the custodian and the custodian’s manager to leave a note prominently attached to the custodian’s laptop and other equipment that (1) states the laptop is subject to a litigation hold, and (2) provides contact information for the responsible attorney. The responsible attorney should also notify any departing custodians that they may be called to testify in the future with respect to matters involving litigation holds to which the custodians are subject. See IRM 1.15.5.9 for more information regarding the Separating Employee Clearance process and preservation of separating employees’ documents.

3. When custodians separate from the Service, the responsible attorney should ensure that, when applicable, new litigation hold notices are sent to any employee(s) assigned to continue work on any cases for which a litigation hold has been issued. In discussing maintenance of litigation holds with separating custodians’ managers, responsible attorneys should advise that all hard copy documents subject to a litigation hold be clearly labeled as such to inform successor custodians. Successor custodians must also be added to the Litigation Hold Database, as described at _CCDM 34.7.1.1.4.3.1.3 (8)_ .


**34.7.1.1.4.3.3** **(08-03-2022)**

###### Collection of Potential Evidence

01. After the responsible attorney has issued a litigation hold, the responsible attorney will determine if collection and processing of relevant evidence is necessary. In some cases, collection may never be necessary, especially in cases that settle or are dismissed prior to discovery. In other cases, only some of the potential evidence may need to be collected. As the responsible attorney (or the DOJ attorney) engages in discovery discussions, either through Fed. R. Civ. P. Rule 26 or Branerton conferences, the responsible attorney, with the approval of the attorney’s manager, may determine that it is necessary to collect, process, review, and produce to the opposing party or DOJ relevant evidence that is not in the responsible attorney’s possession. In that case, the responsible attorney should first collect all potentially relevant evidence contained in files or on paper that is not within the attorney’s possession.

02. The responsible attorney is often capable of coordinating the collection of paper files or other tangible materials from custodians by simply requesting that custodians send paper or scanned copies of the various items to the responsible attorney for discovery purposes. If the responsible attorney has questions about how to collect paper files or other tangible evidence, the responsible attorney should discuss any potential issues with the attorney’s manager. PA Branch 8 does not assist in the collection of non-ESI evidence.

03. In some cases, such as when the opposing party indicates it will accept images of original ESI without accompanying metadata and the volume of such ESI is limited, it may be acceptable for the responsible attorney to collect ESI images directly from the custodian in a manner similar to collection of paper files. The responsible attorney should consult with their manager as to whether custodian self-collection of ESI is an acceptable option in the particular matter.

04. In larger or more complex cases it can take several months for IRS-IT to collect ESI. The assigned attorney should begin the ESI collection process as soon as it is determined that ESI will be sought in discovery to ensure that there is sufficient time for review of the data prior to the time it must be produced.

05. To preserve metadata and original documents, custodians should preserve ESI in its native format. Native format is the format in which the ESI was originally created and stored (e.g., Microsoft Word or Excel; Outlook email).

06. If the collecting and processing of ESI is required, the attorney should complete an EDR to inform PA Branch 8 that collection is required. The EDR template is also available on the Litigation Hold Database intranet site. The attorney should submit the initial EDR to TSS.assignments.



    ### Note:



    The responsible attorney should confirm through the Discovery Directory the information needed to fill out this form, such as the SEID number, title, contact information, business unit, manager, and management level. The failure to include required information, especially the SEID, could delay the collection of ESI.

07. PA Branch 8 and IRS-IT need specific information to complete the collection process quickly and efficiently. If the responsible attorney cannot provide certain information to PA Branch 8, the collection process may be delayed. The responsible attorney should be prepared to give PA Branch 8 the following information at the time the responsible attorney starts the collection process:



    - A list of the custodians identified as being in possession or control of relevant evidence (see _CCDM 34.7.1.1.4.3.1.3_);

    - The identifying information (SEIDs) of the custodians as verified through the Discovery Directory (see _CCDM 34.7.1.1.4.3.1.3 (8)_);

    - The priority level of the case, with justification, such as court deadlines or the date a custodian will separate from employment (see _CCDM 34.7.1.1.4.3.3 (8)_);

    - A listing of any known ESI repositories used to store relevant evidence (see _CCDM 34.7.1.1.4.3.1.4_);

    - Copies of the complaint, petition, defense letter, or referral letter;

    - Copies of statutory notice of deficiency, notice of final partnership administrative adjustment, worker classification, notice of determination, or claim disallowance; and

    - Relevant search criteria (see _CCDM 34.7.1.1.4.3.2 (9)_).


08. After identifying all possible custodians, the responsible attorney should consider whether the role a custodian had in the matter warrants the collection of that custodian’s evidence. The litigation hold collection need only cover custodians, who are those individuals likely to have information that is relevant to any party’s claim or defense in the case. See Fed. R. Civ. P. Rule 26(b)(1). A collection need not cover every person who had contact with a case. For example, managers and executives who have only been advised on the status of a case by email and have not responded to the status email may not possess unique evidence relevant to the claims or defenses in the case.

09. The priority of requests for ESI communicated through EDRs is based upon an evaluation of various, objective factors. No one factor is entirely dispositive and the weighting of the factors can vary from case to case. The principal, pertinent factors to be weighed in resolving priority include:



    - Separation of an employee from the Service or Counsel when there is a risk that ESI in the separating custodian’s possession may not be preserved;

    - Imminent discovery requirements or other court-imposed deadlines;

    - Importance to tax administration of the case or issues within a case;

    - Significance of the amount in controversy;

    - Large volume of ESI;

    - ESI consisting of sensitive information, such as grand jury material (See _CCDM 34.7.1.1.4.3.1.4 (6)_) concerning sensitive evidence); and

    - Other circumstances that would require immediate collection or involve a protracted period for collection or processing.


10. If a dispute about the relative priority of EDRs occurs, PA Branch 8 will resolve the priority of EDRs by consulting with its management and the responsible attorneys involved. Disputes that cannot be resolved by PA Branch 8 will be elevated through the usual reconciliation process. See CCDM 31.1.4.6.

11. Once PA Branch 8 receives the EDR, PA Branch 8 assigns the EDR to a PA Branch 8 attorney or technology specialist (PA Branch 8 contact) who will coordinate with IRS-IT, which handles the collection of ESI. The PA Branch 8 contact will contact the responsible attorney promptly and no later than seven calendar days after the EDR submission to ask any necessary questions, to discuss whether the attorney wishes to have PA Branch 8 review the ESI once it is collected, and to discuss the appropriate level of priority. If a case is subsequently reassigned to a different Branch 8 attorney, the new PA Branch 8 contact will send an email to the responsible attorney within three calendar days noting the reassignment.

12. The PA Branch 8 contact will notify the responsible attorney when the EDR is submitted to IRS-IT. The PA Branch 8 contact will also provide an estimated time for completion, track the EDR, and give updates to the responsible attorney based upon information from IRS-IT.

13. During the course of litigation, events may occur that affect the priority of collection, such as a custodian’s imminent separation from employment, the custodian’s possession of grand jury information, changes in court-imposed deadlines, and any potential events that could lead to spoliation, such as upgrades to operating software on a custodian’s computer or the transfer of the custodian to another business unit of the Service. If events occur that could impact the priority of the responsible attorney’s case, the responsible attorney should contact the assigned PA Branch 8 contact who will address the matter with IRS-IT.

14. Collection can be accomplished remotely in the case of most desktops, laptops, and network servers, and in the case of removable media. Where remote collection and preservation is not possible, IRS-IT collects the data directly from the custodian and returns it once preservation is complete. Information on the mechanics of the preservation and collection process for user-created files is contained on the Litigation Hold Information Site.


**34.7.1.1.4.3.4** **(08-03-2022)**

###### Processing and Review of Potential Evidence

1. If the potential evidence relevant to a case does not involve ESI, processing of documents and other tangible evidence simply involves following normal discovery procedures to prevent production of certain evidence that is not relevant, is privileged, or contains third party return information as defined in IRC § 6103. Responsible attorneys should discuss with their managers the appropriate review needed before producing paper documents and other tangible evidence to the opposing party or to DOJ in discovery.

2. If collection of ESI by EDR is necessary, IRS-IT collects the ESI, processes it to remove encryption and prepares it for release to Counsel. PA Branch 8 technology specialists will further process the ESI and load it on a review tool. PA Branch 8 attorneys and technology specialists are available to assist in further culling the ESI by working with the responsible attorney to narrow search terms, employ computer-aided analytics and to advise how to remove nonresponsive ESI and otherwise efficiently review and analyze ESI. See _CCDM 34.7.1.1.4.3.2 (9)_ for additional information on the development of search criteria. PA Branch 8 will then provide responsive ESI, such as emails and attachments, for review by the responsible attorney. PA Branch 8 will recommend an appropriate review tool to the responsible attorney. Because of cost considerations, use of some tools may require Division Counsel approval.

3. The responsible attorney is wholly responsible for compliance with discovery obligations and the production of evidence in a Tax Court case or for providing the evidence to DOJ in litigating handled by DOJ. PA Branch 8 attorneys can assist, however, with document review by recommending review strategies and performing first-level review of potential evidence. Privileges, privacy, and disclosure issues, as well as any legal issues that arise during discovery, should be coordinated by the responsible attorney with PA Branches 6 and 7. The responsible attorney in a case may request assistance with first-level review from PA Branch 8 by sending a request for assistance to TSS.assignments.



### Note:



ESI obtained from a Service or Counsel executive must be reviewed by non-bargaining unit GS-15 attorneys unless otherwise determined. When reviewing ESI of non-executive Service or Counsel managers, litigation Divisions should employ procedures for review that preserve confidentiality of sensitive information such as personnel matters.

4. PA Branch 8, technology specialists and attorneys are available to assist with all ESI related discovery matters before the United States Tax Court, district court, and other courts. Based upon workload, this assistance may not be available in all instances. The following guidelines apply to PA Branch 8 assistance in ESI matters:



   - If the responsible attorney requests the services of PA Branch 8 for document review, the responsible attorney will be asked to provide enough information about the case to allow the PA Branch 8 attorney to perform a first-level review for relevance, preservation of privilege claims, and the protection of third party return information as defined in IRC § 6103. The responsible attorney may provide this information informally by telephone contact or through a presentation by the responsible attorney on the issues in the case relevant to the discovery request. The responsible attorney and manager will serve as the ultimate reviewer, after PA Branch 8’s first-level review.

   - First-level review by the assigned PA Branch 8 attorney should generally take place within 14 calendar days after receipt of the information from IRS-IT. In the case of large volumes of ESI, the PA Branch 8 attorney will coordinate a reasonable extension of time with the responsible attorney.

   - Once first-level review is complete, the results will be forwarded to the responsible attorney for further review and production. PA Branch 8 will be available to assist with any technological issues prior to production.


**34.7.1.1.4.3.5** **(08-13-2018)**

###### Litigation Hold Release and EDR Termination

1. Typically the legal requirement to preserve information terminates upon final case disposition, when a final, non-appealable decision or judgment is reached in existing litigation, or when the Service no longer reasonably anticipates litigation. In a Tax Court case, a decision is final when the parties file a stipulated decision entered by the court, when all appeals have been exhausted, or the period for filing an appeal has expired. See IRC § 7481. Similar principles of finality apply with respect to cases litigated in other courts. Until such time as a matter is final, all evidence should be preserved in a manner exempting it from the normal records retention requirements and policies. When a decision other than a stipulated decision is entered in the case, the responsible attorney should still wait until the appeal period has expired before lifting the litigation hold. In DOJ cases, the responsible attorney should not release a litigation hold without written confirmation from the DOJ attorney responsible for the litigation indicating that it is appropriate to do so. This written notification may take the form of email.

2. Once a litigation hold can be released, the responsible attorney should notify custodians that they no longer need to retain evidence for the case. If a litigation hold does not include ESI, the responsible attorney can simply notify custodians by email that they no longer need to retain documents and other tangible evidence related to the case. The Litigation Hold Release email template is located on the Litigation Hold Database intranet site. Normal records retention schedules and policies will resume and control any continued obligation to retain. The release of a litigation hold should not be construed as approval to destroy the evidence. Retention schedules and policies should be consulted prior to destruction.

3. The responsible attorney should send an email to the assigned PA Branch 8 contact to inform PA Branch 8 that the litigation hold can be marked inactive in the Litigation Hold Database and any pending EDR can be terminated. If there is no assigned PA Branch 8 contact, the email should be sent to the Litigation Hold Mailbox. The responsible attorney should notify PA Branch 8 via email within 21 calendar days of receiving notice of a final decision, judgment, or other notification that there is no further legal requirement to preserve the information. This email to PA Branch 8 should include a copy of the decision, judgment, or other document demonstrating final determination.

4. PA Branch 8 will change the litigation hold to inactive in the Litigation Hold Database. This will also remove automated exemptions from retention policy operation in IRS-IT systems. PA Branch 8 will also notify IRS-IT that any pending EDR collection or preservation processes may be terminated, unless the collection is potentially relevant to other pending or anticipated litigation.

5. Because PA Branch 8 regularly maintains the Litigation Hold Database, PA Branch 8 may contact responsible attorneys to determine if litigation holds should be terminated. Responsible attorneys should respond timely to PA Branch 8’s requests to review litigation holds and terminate any litigation holds that are no longer necessary.


**34.7.1.2** **(08-11-2004)**

### Further Factual Development

1. The duties of Field Counsel in handling a suit referred to DOJ do not end once the suit or defense letter is prepared. Field Counsel has a duty to assist DOJ attorneys in preparing a defense, which may include further development of the facts of the case.


**34.7.1.2.1** **(08-11-2004)**

#### Supplemental Investigations — Definition & Scope

1. In many instances, the materials available to Field Counsel at the time the suit or defense letter is prepared do not provide sufficient facts or enough detail to permit a proper analysis of a litigating position or litigation hazards. When Field Counsel believes that further development in the case is needed, he or she should initiate action to develop the facts and evaluate the legal analysis contained in the suit or defense letter.

2. When, in the light of subsequently determined facts, the legal analysis portion of the suit or defense letter is incomplete or must be reevaluated, Field Counsel should write a supplemental suit or defense letter.


**34.7.1.2.2** **(08-11-2004)**

#### When Supplemental Investigation Is Warranted

1. In preparing a suit or defense letter, Field Counsel will on occasion become aware that critical facts have not been ascertained while the case was pending administratively. The suit or defense letter should describe the factual development necessary and request that the DOJ attorney decide whether to develop the facts by way of discovery or supplemental investigation.

2. A supplemental investigation is a further investigation conducted by Service personnel, usually a revenue agent, to gather additional facts or more details with regard to one or more issues. Although a supplemental investigation is usually formally requested by a letter from the DOJ attorney, informal requests are sometimes made.

3. In addition, the DOJ attorney, upon receipt and review of the suit or defense letter, may determine that further factual development is needed and request a supplemental investigation.


**34.7.1.2.3** **(08-11-2004)**

#### Procedure for Supplemental Investigation

1. Approval from DOJ. Before any supplemental investigation is conducted, the Field Counsel attorney should have the express approval of the DOJ attorney.

2. Formal Requests. Make a request for a supplemental investigation by memorandum with the following sections.



1. Addressee. Normally the memorandum requesting a supplemental investigation is addressed to the Area/Industry Director for the Area/Industry in which the case arose. Field Counsel should be aware, however, that the information sought may be in another Area/Industry. If possible, indicate in the attention line of the memorandum the name of the revenue agent who will conduct the supplemental investigation.

2. Body. The amount and type of tax in the suit as well as the taxable periods should be stated at the beginning of the memorandum, preferably in the first paragraph. The scope of the supplemental investigation is spelled out in the memorandum. If, however, DOJ in its letter requesting the supplemental investigation describes the desired investigation in sufficient detail, the memorandum may merely refer to the DOJ letter and request compliance. In suits filed in district courts, where the plaintiff is represented by counsel, the memorandum should advise the revenue agent to approach the plaintiff only after prior arrangements have been made with the U.S. Attorney and only through the plaintiff’s counsel. The revenue agent may approach persons other than the plaintiff without prior notification to opposing counsel or the U.S. Attorney. In Court of Federal Claims cases, where the plaintiff is represented by counsel, the plaintiff should be approached only through the plaintiff’s counsel; as with district court cases, persons other than the plaintiff may be approached without prior contact with opposing counsel. Always provide the name and telephone number of the attorney initiating the request. Questions can then be directed by telephone to him or her without the need of written correspondence, which might delay the investigation.

3. Signature. The memorandum is usually prepared for the name of Area Counsel. Subject to local rules, attorneys who have been with Chief Counsel for one year or more are authorized to sign the memorandum in a byline.

4. Enclosures. Field Counsel should decide what parts of the administrative file should accompany the supplemental investigation request. Only the portion of the file necessary for the agent to complete the investigation should be sent. To maintain the integrity of the administrative file, Field Counsel may send copies of its contents in lieu of originals.


3. Telephone Requests. On rare occasions, it may be necessary to initiate a supplemental investigation by telephone call. Always confirm telephone requests with written memorandum.


**34.7.1.2.3.1** **(08-11-2004)**

##### Coordination with Area/Industry Director

1. Although a supplemental investigation entailing only a day or two of a revenue agent’s time requires no advance coordination or clearance with the Area/Industry Director, requests requiring a large number of interviews and significant time, expense, and documentation require clearance with the Area/Industry Director.

2. When Field Counsel receives an expansive request, he or she should first determine whether it is reasonable in light of the amount of money at risk in the suit and the need for the information. If the attorney determines that the request is reasonable, he or she should coordinate the request with the Area/Industry Director through the Area Counsel. In the event time does not permit written coordination, coordination may be by telephone. If Field Counsel determines that a supplemental investigation is unreasonable, the attorney should, before seeking clearance from the Area/Industry Director, contact the DOJ attorney and discuss modification of the request.


**34.7.1.2.3.2** **(08-11-2004)**

##### Request to Associate Chief Counsel (International) for Information Located Abroad

1. For procedures relating to obtaining information from abroad, see CCDM 34.6.3.7.


**34.7.1.3** **(08-11-2004)**

### Further Legal Development

1. Field Counsel may on occasion be unable to determine the legal position of the Service when the suit or defense letter is written or the letter’s legal discussion becomes obsolete due to subsequent factual or legal developments. For example, cases may have been decided subsequent to the writing of the suit or defense letter. Field Counsel should first coordinate technical issues with the appropriate Associate offices. Field Counsel then must reevaluate the position stated in the defense letter and write a supplemental defense letter.


**34.7.1.4** **(08-11-2004)**

### Requests for Miscellaneous Assistance

1. In developing a refund or collection case, Field Counsel may use a number of resources other than revenue agents for the following services:



   - Recomputations of tax liabilities

   - Expert opinions on matters of depreciation, depletion, valuation questions, etc.

   - Expert opinions from actuaries

   - Expert opinions from economists

   - Investigations to be conducted abroad. _See__CCDM 34.7.1.3_.


**34.7.1.4.1** **(08-11-2004)**

#### Recomputation of Tax Liability

1. Generally, Appeals offices can recompute the taxpayer’s tax liability pursuant to proposed settlements, finalized settlements, and adverse opinions or judgments. If, however, Appeals is unable to recompute the tax liability, Field Counsel can ask the Area Director from the area in which the case arose to do so.

2. Field Counsel should include the following items in a memorandum requesting a recomputation:



1. A subject line with the caption of all cases for which a computation is requested

2. The periods in suit, the type of tax involved, and the amount of any refund that the taxpayer is seeking

3. The issues and the disposition of each issue

4. A request that the recomputation show the amount of tax refundable and the allocable portion of the assessed interest and penalties that is refundable

5. The administrative files which include the revenue agent’s report with computation showing how the Service initially readjusted the plaintiff’s tax liability


3. Field Counsel should send the memorandum requesting a recomputation within three working days of the date the Field attorney receives the request from DOJ.

4. When Counsel receives recomputations from Appeals, he/she should verify that the recomputation is correct and should look for the following:



   - Inclusion of all the requested adjustments

   - In what years the Service owes the taxpayer any refunds

   - Assessed interest and additions to tax that are set out separately and apportioned correctly


5. Field Counsel should send DOJ three copies of each recomputation


**34.7.1.4.2** **(08-11-2004)**

#### Actuarial Reports

1. Field Counsel should send all requests for actuarial assistance, other than assistance for treatment of pension, profit sharing, stock bonus, annuity, and other benefit compensation plans to the Chief, General Actuarial Branch. The General Actuarial Branch provides assistance for the following:



   - Tax treatment of annuities

   - Tax treatment of life insurance

   - Tax treatment of accident and health plans and contracts

   - Valuation of life estates

   - Valuation of remainder interests

   - Valuation of contingent interests

   - Valuation of reversionary interests

   - Deductions for amounts paid or accrued on indebtedness by insurance companies


2. Field Counsel should send all requests for actuarial assistance for pensions, profit sharing, stock bonus, annuity, and other benefit compensation plans to the Chief, Pension Actuarial Branch.


**34.7.1.4.3** **(08-11-2004)**

#### Expert Reports Other Than Actuarial

1. Field Counsel may, while preparing a litigation report, realize that he or she might need an expert in the following areas:



   - Depreciation

   - Depletion

   - Valuation of art objects

   - Valuation questions arising in oil and gas, mining, timber, pulp and paper, industrial, public utilities, real estate, personal property, and other commercial fields


2. The Office of Appraisal Services can provide engineering and valuation experts in these areas. Field Counsel should promptly request the expert’s services but should not postpone completing the litigation report while waiting for an expert report from the Office of Appraisal Services. Field Counsel should state in the litigation report that he needs an expert opinion. Counsel should get the approval of the DOJ attorney before requesting an in house expert because the DOJ attorney may prefer to use an expert from the private sector.



1. The Office of Appraisal Services, as part of the Appeals Division, is composed of two sections, Financial/Engineering Services and Art Advisory Services. The Office of Appraisal Services can provide information for supplemental litigation reports, trial preparation, and its personnel can also testify as expert witnesses. If necessary, the office can assist the attorney in finding an outside expert.

2. Field Counsel should initially contact the Office of Appraisal Services for assistance by telephone and follow-up with a memorandum.


3. Field Counsel should request economists’ reports from the Field Specialists’ Office in Washington, DC. Economists may serve as expert witnesses or may identify and locate independent witnesses or consultants to provide expert testimony on economic matters.

4. Field Counsel should request an economist’s assistance as it is determined that such assistance is needed. Counsel should not ask for an economist for general statistical data, the identity of companies engaged in similar activities, or other information generally available in local libraries. An economist can help with:



   - Identification and evaluation of potential issues

   - Determination of the areas that should be explored

   - Recognition of the economic data needed to support the issues

   - Analysis, evaluation, and interpretation of the economic and statistical information in the file

   - Determination of whether an adjustment is based upon sound economic concepts, is reasonable in amount, and is consistent with recommendations made in similar situations.


5. Field Counsel should use the following guidelines while writing a memorandum requesting an expert and/or an economist:



1. Include the periods in suit, type of tax involved, and the amount the taxpayer is seeking to recover.

2. Generally include only the issue on which the expert report is being requested.

3. Describe the exact nature of the expert and the type of report needed. Enclose, if applicable, the letter from DOJ requesting assistance that contains a sufficient description of the desired expert and report.

4. State any deadlines for obtaining an expert and/or having the expert complete his/her report.

5. Send either a copy of the portion of the administrative file that contains facts appropriate to the report or a duplicate administrative file.


6. Field Counsel should review any report that the examination division or the Office of Appraisal Services prepared. If an expert has made an error, Counsel should informally contact the expert for clarification and, if necessary, correction. Counsel should resubmit the revised report to DOJ. If there are no errors in the report, Counsel should send it to DOJ, commenting on the report as necessary or appropriate. _See__CCDM 34.7.1.5_. The Field attorney does not have to repeat or summarize the findings contained in the report.


**34.7.1.5** **(08-11-2004)**

### Supplemental Litigation Reports

1. Field Counsel can write a supplemental litigation report completing or reevaluating the discussion in the initial litigation report. The supplemental letter modifies and/or affirms the recommendation of the litigation report in light of subsequent factual or legal developments. Field Counsel should always try to prepare a timely and complete litigation report. Occasionally, however, due to time limitations, unavailability of pertinent facts, or the nature of the legal issue involved, Field Counsel cannot include a definitive statement of facts, legal analysis, and recommendation in the litigation report. When this occurs, Field Counsel should write a supplemental litigation report.

2. Even if Field Counsel initially writes a complete litigation report, a supplemental litigation report may be used to discuss subsequent factual or legal developments. There is no general rule for the length or content of a supplemental litigation report. It should, however, include the case classification in the lower right hand corner of the first page. See CCDM 34.5.1.1.1 for a complete discussion of case classification.



1. If Field Counsel changes the classification of a case, he should explain why in the concluding paragraph.

2. If an issue is discussed in the supplemental litigation report which had been included in the initial litigation report, the prior discussion should be summarized but not repeated in the supplemental litigation report.

3. If never discussed, Field Counsel should thoroughly discuss the issue and reach a conclusion in the supplemental litigation report.


**34.7.1.5.1** **(08-11-2004)**

#### Mandatory Supplemental Litigation Reports

1. Supplemental litigation reports are required when:



1. There have been additional factual or legal developments; or

2. The taxpayer files an amended complaint.


**34.7.1.5.1.1** **(08-11-2004)**

##### Additional Factual Or Legal Development

1. During the pendency of a suit, Field Counsel may receive additional information requiring a reevaluation of the Service’s position on one or more of the issues in the litigation report. This may occur as a result of a supplemental investigation, report of an expert, or information that the DOJ attorney gives to the Field Counsel attorney. Field Counsel should monitor all information received about the suit and determine whether to reevaluate the position taken in the initial litigation report. If reevaluation of the position taken is necessary in light of new information, Counsel should prepare a supplemental letter whether or not the DOJ trial attorney requests one. Field Counsel may also become aware of changes in the law or Service position on an issue after preparation of the initial litigation report.

2. Field Counsel should prepare a supplemental litigation report whenever it is necessary to reevaluate the initial legal analysis in light of subsequent legal developments or changes in the Service’s position. The supplemental letter does not have to be extensive if the Field Counsel attorney can incorporate by reference and attach a document that includes a complete and well reasoned statement of the law or Service position. If this occurs, Field Counsel should evaluate the new material’s effect and make a definitive recommendation. The supplemental letter should also include the case classification and include an explanation of any changes in the case classification. See CCDM 34.5.1.1.1 for a complete discussion of case classification.


**34.7.1.5.1.2** **(08-11-2004)**

##### Amended Complaint

1. If the taxpayer files an amended complaint, Field Counsel should prepare a supplemental litigation report. If the taxpayer is merely seeking relief similar to the original complaint for other periods and there are no new issues, Field Counsel can prepare a brief supplemental letter.

2. If the taxpayer is seeking different relief or is raising a new issue, Field Counsel should discuss extensively the new matter as if it were the original litigation report.


**34.7.1.6** **(08-11-2004)**

### Trial Assistance

1. The DOJ trial attorney may request the following:



1. Assistance and testimony of a revenue agent at the trial; or

2. Special technical assistance, including charts and diagrams, hand writing analysis, laboratory analysis, or the translation of documents into English from a foreign language.


**34.7.1.6.1** **(08-11-2004)**

#### Assistance of Service Personnel at Trial

1. The DOJ trial attorney may request the assistance of Service personnel immediately prior to and during the trial. When the DOJ attorney makes this request, preferably in writing, the Field Counsel attorney should, if possible, contact by telephone the appropriate Area Director and follow with a confirming memorandum. Counsel should refer to _CCDM 34.7.1.2.1_, Supplemental Investigations, to determine when to comply with the request and how to write the memorandum. Field Counsel should give Service personnel as much advance notice as possible when DOJ needs their assistance.

2. Field Counsel should use the following guidelines in obtaining the assistance of service personnel.



1. Include the name of the case, type of tax involved, taxable periods involved, and a reference to DOJ’s request in the memorandum, and attach any written request from DOJ for assistance.

2. State if DOJ is requesting the assistance of a specific employee but request a substitute in the event the named employee is not available.

3. Clearly state in the memorandum that the employee will assist the DOJ trial attorney in trial preparation and/or at trial.

4. State in the memorandum the date and place where the employee will assist the DOJ attorney.

5. Specify in the memorandum whether the DOJ trial attorney will contact the employee or the employee is expected to contact the DOJ trial attorney.

6. Include the DOJ trial attorney and Field Counsel’s telephone number.

7. An attorney may not have to coordinate in advance a supplemental investigation entailing only a day or two of a revenue agent’s time. Prior to making a formal request, however, Field Counsel should coordinate with the affected Area Director extensive requests requiring a large number of interviews and an extraordinary amount of time, expense, and documentation. When Counsel receives such a request, he/she should determine whether it is reasonable given the amount of money in dispute and the actual need for information. If Field Counsel determines that the request is reasonable, he/he should contact the revenue agent who undertook the original investigation or his/her supervisor to ascertain if the agent or a substitute can comply with the request. Counsel should confirm by memorandum any agreement with the Area Director. If Counsel determines a supplemental investigation requested by DOJ is unreasonable, they should contact the DOJ trial attorney and seek to persuade him/her to modify the supplemental investigation request. This should be done prior to contacting the Examination Division.


**34.7.1.6.2** **(08-11-2004)**

#### Requests for Depositions or Testimony

1. The Chief Counsel is authorized to honor requests for the testimony of Service personnel without referring the request to the client if the request is for testimony on behalf of the Government; however, where the request for testimony, or depositions, although forwarded to the Office of Chief Counsel by DOJ, is for testimony on behalf of the taxpayer, the Area Director and appropriate disclosure personnel must authorize such testimony. Therefore, when Field Counsel receives such a request, they should first determine whether the requested testimony will be on behalf of the Government or the taxpayer. If necessary, they should initiate the request for authorization.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part34/irm_34-007-001#addtoany "Show all")

A2A