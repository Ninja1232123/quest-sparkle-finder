---
url: "https://www.irs.gov/irm/part30/irm_30-010-001"
title: "30.10.1 Correspondence Guidelines | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part30/irm_30-010-001#main-content)

- 30.10.1 [Correspondence Guidelines](https://www.irs.gov/irm/part30/irm_30-010-001#idm140019765682288)
  - 30.10.1.1 [Reserved](https://www.irs.gov/irm/part30/irm_30-010-001#idm140019765681856)

# Part 30. Administrative

# Chapter 10. 0 Standards for Correspondence

# Section 1. Correspondence Guidelines

* * *

## 30.10.1 Correspondence Guidelines

**30.10.1.1** **(07-15-2005)**

### Reserved

1. Reserved.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part30/irm_30-010-001#addtoany "Show all")

A2A