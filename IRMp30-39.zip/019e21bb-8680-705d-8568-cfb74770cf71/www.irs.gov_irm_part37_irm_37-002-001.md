---
url: "https://www.irs.gov/irm/part37/irm_37-002-001"
title: "37.2.1 Privacy Act of 1974 | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part37/irm_37-002-001#main-content)

- 37.2.1 [Privacy Act of 1974](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048794978752)
  - 37.2.1.1 [General](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048794986608)

    - 37.2.1.1.1 [Privacy Act Litigation](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048748325936)

  - 37.2.1.2 [Privacy Act Processing Requests for Notification and/orAccess](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048773103952)

    - 37.2.1.2.1 [Verification of Identity](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048795055424)
    - 37.2.1.2.2 [Content of Responses](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048794984112)

  - 37.2.1.3 [Privacy Act Amendment of Records](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048749703216)

    - 37.2.1.3.1 [Evaluation of Records](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048750223792)
    - 37.2.1.3.2 [Evaluation of Amendments](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048746536720)
    - 37.2.1.3.3 [Making the Amendment](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048765258144)
    - 37.2.1.3.4 [Notifying Prior Recipients](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048771729456)
    - 37.2.1.3.5 [Review of Refusal to Amend a Record](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048768518416)

      - 37.2.1.3.5.1 [Form of Requests for Review of Refusal to Amend Records](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048750364464)
      - 37.2.1.3.5.2 [Acting on Determinations](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048758134496)

    - 37.2.1.3.6 [Statement of Disagreement](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048755474480)

  - 37.2.1.4 [Accounting of Disclosures and Requests for Accounting of Disclosures](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048762845280)

    - 37.2.1.4.1 [Requests by Individuals for Accounting of Disclosures](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048773133840)

  - 37.2.1.5 [Agency Requirements under the Privacy Act](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048769114960)

    - 37.2.1.5.1 [Information Collection, Maintenance, and Dissemination](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048767823136)
    - 37.2.1.5.2 [Disclosure of Personnel Information](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048764046544)
    - 37.2.1.5.3 [Assuring Integrity of Systems of Records, Coordination](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048754967760)
    - 37.2.1.5.4 [Establishment or Alteration of Systems of Records](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048774551296)

  - 37.2.1.6 [Solicitation of Personal Information from Expert Witnesses](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048752084144)
  - Exhibit 37.2.1-1 [Sample Letter Advising Requester of Delay](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048773775904)
  - Exhibit 37.2.1-2 [Search Memorandum](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048760596960)
  - Exhibit 37.2.1-3 [Sample Letter Granting Access to Records](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048767343600)
  - Exhibit 37.2.1-4 [Sample Letter Denying Request for Access](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048752068448)
  - Exhibit 37.2.1-5 [Sample Acknowledgement of Request for Amendment](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048764385120)
  - Exhibit 37.2.1-6 [Sample Memorandum to System Manager](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048755484064)
  - Exhibit 37.2.1-7 [Sample Notification of Delay of Response to Review Refusal of Amendment](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048766846976)
  - Exhibit 37.2.1-8 [Notice to Expert Witnesses](https://www.irs.gov/irm/part37/irm_37-002-001#idm140048760721760)

# Part 37. Disclosure

# Chapter 2. Privacy Act of 1974; Freedom of Information Act

# Section 1. Privacy Act of 1974

* * *

## 37.2.1 Privacy Act of 1974

**37.2.1.1** **(08-11-2004)**

### General

1. The purpose of this section is to provide instructions and guidelines to the Office of Chief Counsel for implementing the Privacy Act of 1974 (Pub. L. 93-579), 5 U.S.C. § 552a.

2. The Privacy Act created certain restrictions on federal agency record keeping as well as affording individuals certain rights with respect to agency records pertaining to themselves.

3. To implement these individual rights with respect to records, the Privacy Act requires that each agency promulgate and publish rules in the Federal Register.



### Note:



The Treasury regulations implementing the Privacy Act are published at 31 C.F.R. § 1.20, et seq.

4. The instructions contained in this section are designed for the Office of Chief Counsel to carry out the requirements of the Privacy Act and the applicable Treasury regulations. Personnel performing duties described herein should familiarize themselves with the Act, the regulations, the OMB guidelines, and the Service’s published systems of records.

5. National Office Responsibilities. For purposes of this section, "national office" means the Associate and Division Counsel.



1. The basic responsibility for responding to Privacy Act requests for notification and access to records received in the national office of the Office of Chief Counsel has been assigned to the Disclosure & Litigation Support Branch.

2. The Assistant Chief Counsel (DPL) is responsible for administering requests for amendment of national office records, as well as providing assistance with respect to appeals from refusals to amend records maintained by the Office of Chief Counsel. Any questions concerning the administration of the Privacy Act should be referred to DPL.


6. Field Counsel Responsibilities. The field counsel have the authority to grant or deny a request for notification, access and/or amendment of records in systems of records maintained by their offices. The field counsel should designate an attorney within their offices to coordinate activities under the Privacy Act. The attorney designated to undertake such coordination shall hereinafter be referred to as the Privacy Coordinator. This title is used for the purposes of identification in this section only. The Privacy Coordinator should work closely with the Disclosure Officer for the jurisdiction in which he or she is located. The Area Counsel or Associate Area Counsel (or their delegates who will be no lower than a GS-15) will grant or deny all requests for notification, access, and/or amendment of records (as appropriate).

7. The Assistant Chief Counsel (DPL) handles legal matters arising under the Privacy Act and will coordinate all litigation with the Department of Justice. All documents and information concerning litigation arising under the Privacy Act should be forwarded to the Technical Services Support Branch, Room 5329.


**37.2.1.1.1** **(08-11-2004)**

#### Privacy Act Litigation

1. For specific procedures on receipt of Privacy Act litigation, follow the procedures in CCDM 37.2.2.2 through CCDM 37.2.2.4, and CCDM 37.2.2.6, applying to FOIA litigation substituting the Privacy Act where applicable.

2. Jurisdiction for defending Privacy Act claims falls to the Tax Division, Department of Justice. See CCDM 37.2.2.4.


**37.2.1.2** **(08-11-2004)**

### Privacy Act — Processing Requests for Notification and/or Access

01. The Privacy Act affords individuals certain rights with respect to records contained in the Service’s systems of records. Such rights, subject to various exemptions and restrictions, include: being notified in response to his or her request if any system of records named contains a record pertaining to him or her; obtaining access to such records; requesting amendment of such records; and securing an accounting of disclosures made of, or from, such records. This subsection provides guidance to Office of Chief Counsel personnel in handling requests from individuals for notification and/or access to systems of records.

02. Recipient of Requests. All Privacy Act requests for notification and/or access to systems of records addressed to the national office should be routed to the Chief, Disclosure & Litigation Support Branch. All Privacy Act requests for notification and/or access to systems of records addressed to field offices should be routed to the Privacy Coordinators.

03. Routine Requests. Personnel should continue to honor routine requests for information or data available under other procedures. Individuals shall not be required to submit Privacy Act requests for such data. An example of routine requests for information under another procedure would be an informal discovery request in the Tax Court.

04. Procedures. The Chief, Disclosure & Litigation Support Branch and Privacy Coordinators will establish a control system to ensure that Privacy Act requests are processed as set forth in paragraphs (5) through (9). Requests will be assigned to a paralegal specialist in the Disclosure & Litigation Support Branch and to an attorney or paralegal in the field counsel office. A case will be opened on CASE-MIS for all requests for notification or access to Office of Chief Counsel records.

05. Omission of Necessary Information. If a request for notification and/or access omits any information that is essential to processing the request, the requester will be advised within ten business days of the additional information that must be submitted before the request can be processed.

06. Records Located Elsewhere. If a request for notification and/or access is made for records that are not located within the jurisdiction of the receiving office, the request will be forwarded to the appropriate office for processing. The receiving office will acknowledge receipt of the incoming correspondence and advise the requester of the transfer to another office.

07. Time for Responding to Requests. A response will be provided to the requester within 30 days (excluding Saturdays, Sundays, and legal holidays) after receipt by the appropriate office of a request for notification and access.

08. Additional Time. If a request for notification and/or access cannot be answered within 30 days, the Chief, Disclosure & Litigation Support Branch or the Privacy Coordinator will advise the requester of the reasons for the delay and of the approximate time when the request can be honored. See Exhibit 37.2.1-1 for a sample delay letter.

09. Coordination with System Managers. The Chief, Disclosure & Litigation Support Branch or Privacy Coordinator will route a copy of the request within five business days to the Office of Chief Counsel official in possession of the records to which the request relates. See Exhibit 37.2.1-2 for a sample search memorandum. That official will take the necessary action to secure the records and promptly forward one set of copies of the records to the Chief, Disclosure & Litigation Support Branch or Privacy Coordinator (as appropriate) together with a disclosure recommendation.

10. Medical and Psychological Records. When an individual requests access to medical records (including psychological records), a DPL or field reviewer (as appropriate), in coordination with the Associate Chief Counsel (F&M), may determine that the release of the records may be made only to a physician designated in writing by the individual requesting access.


**37.2.1.2.1** **(08-11-2004)**

#### Verification of Identity

1. Manner of Verification. Personnel should verify the identity of the requester before processing the request.

2. If a request is made in person, the requester shall be asked to establish his or her identity by presenting either:



1. One document bearing a photograph (such as a passport or identification badge or, in most states, a driver’s license); or

2. Two items of identification that do not bear a photograph but do bear both the requester’s name and address and a signature.



      ### Note:



      The process used to identify the requester must be documented in the case file. There should be a short description, signed by the employee, of the documents reviewed to establish the requester’s identity.


3. Requests for notification and/or access received by mail should not be processed unless the requester has established his or her identity in the request. Identity can be established by a signature, address, and one other item of identification such as a photocopy of a driver’s license or other document bearing the individual’s signature.

4. An individual may also establish identity by providing a notarized statement or a statement made under penalty of perjury swearing or affirming to his or her identity and to the fact that he or she understands the penalties provided in 5 U.S.C. § 552a(i)(3) for requesting or obtaining access to records under false pretenses. See also 28 U.S.C. § 1746.

5. Additional Proof. Notwithstanding the requirements for identification discussed above, the Chief, Disclosure & Litigation Support Branch or Privacy Coordinators may require additional proof of an individual’s identity before action will be taken on any request if it is determined that it is necessary to do so to protect against unauthorized disclosure of information in a particular case. If additional proof of identity is requested, the employee shall document in the case file the reason the proffered proof of identity was deemed insufficient.

6. Parents, Guardians and Attorneys in Fact. The parent of any minor, the attorney in fact of any individual, or the legal guardian of any individual who has been declared by a court of competent jurisdiction to be incompetent due to physical or mental incapacity or age, must, in addition to the identification requirements discussed above, provide adequate proof of legal relationship before he or she may act on behalf of such minor or other individual.


**37.2.1.2.2** **(08-11-2004)**

#### Content of Responses

1. The Chief, Disclosure & Litigation Support Branch or field counsel (as appropriate) will advise the requester whether the system contains a record pertaining to the requester (unless the system is exempt); notify the requester of the time and place where inspection of the record can be made; or furnish a copy of the requested record to the requester, advising the requester of any copying charges. See IRM 11.3.5.7.1. No copying charges will be sought when the aggregate cost of copying is less than $10.00. If it is estimated that the total copying charges will amount to $250.00 or more, the individual making the request may be required to prepay the actual fees before copies will be furnished. See IRM 11.3.5.5.1.

2. Deletion of Third Party Tax Information. Privacy Coordinators or Disclosure & Litigation Support Branch personnel will review the information to ensure that, to the extent third party tax information is also contained within the system of records, it is disclosed only as authorized by section 6103.

3. Assertion of Applicable Exemptions. The Disclosure & Litigation Support Branch personnel or the Privacy Coordinator preparing the response should be knowledgeable about all applicable Privacy Act exemptions and assert those exemptions where it is in the interest of the Government to do so. The person preparing the response may withhold a record only if it is exempt under both the Privacy Act and the FOIA. 5 U.S.C. § 552a(t). Privacy Coordinators may obtain assistance from their local Disclosure Officer or the office of the Assistant Chief Counsel (DPL).

4. Qualified Exemption under Subsection (k)(2). Records from a system of records exempt from disclosure pursuant to subsection (k)(2) of the Privacy Act may nevertheless be provided to the requester if the Service agrees with the requester’s assertion that the requester has been denied a right, privilege, or benefit to which the requester would otherwise be entitled because of the maintenance of the material. In such cases, information that would reveal the identity of a confidential source shall be redacted before the records are disclosed. See 5 U.S.C. § 552a(k)(2).

5. Exemption of Confidential Source under Subsection (k)(5). If the record is from a system described in subsection (k)(5) of the Privacy Act, information that would reveal the identity of a confidential source shall be redacted before the record is disclosed. See 5 U.S.C. § 552a(k)(5).

6. Response Granting Request. See Exhibit 37.2.1-3 for a sample letter granting access to the system of records.

7. Response Denying Request. The denial will contain a statement of the reason(s) for not granting the request as made, specify the city in which the requested records (if any) are located, set forth the name, title, badge number, and telephone number of the responsible official, and advise the individual making the request of the right to file suit in accordance with 5 U.S.C. § 552a(g). See Exhibit 37.2.1-4 for a sample denial letter.

8. Treasury’s Privacy Act regulations permit Treasury agencies, when denying a request, to neither confirm nor deny the existence of the record but to advise the individual only that no record available to him/her pursuant to the Privacy Act has been identified. This type of response is an option, not a requirement. Even if this option is exercised, the individual should be advised of the right to file suit in accordance with 5 U.S.C. § 552a(g).



### Note:



If using this option, the city in which the records are located should not be listed in the denial.

9. Close the case file after inputting data into CASE-MIS.


**37.2.1.3** **(08-11-2004)**

### Privacy Act — Amendment of Records

1. Responsibility. Overall responsibility for processing requests to amend or correct Office of Chief Counsel records is placed with the Assistant Chief Counsel (DPL) (for records maintained in the national office) and the Privacy Coordinators (for records maintained in field counsel offices). Any necessary correction of records will be at the direction of the Assistant Chief Counsel (DPL) or the Area or Associate Area Counsel and will be undertaken by the Office of Chief Counsel employees normally responsible for maintenance of such records.

2. Authority to Respond to Requests to Amend. Responses will be prepared for the signature of the Assistant Chief Counsel (DPL) or the Area or Associate Area Counsel (as appropriate).

3. Time to Acknowledge. Initial requests to amend should be acknowledged by a DPL attorney or the Privacy Coordinator not later than ten business days from the date of receipt by the appropriate office of such request. See Exhibit 37.2.1-5.

4. Advice With Respect to Requests to Amend. DPL attorneys or Privacy Coordinators are available to discuss amendments with the individual and to offer advice on how to file requests for amendments, appeals, statements of disagreement, and information with respect to civil remedies.



### Note:



The Privacy Coordinator may seek legal advice and/or other assistance from the office of the Assistant Chief Counsel (DPL) with respect to any Privacy Act request that raises novel, complex, or sensitive issues.

5. Establish Administrative Amendment Case File. DPL attorneys or Privacy Coordinators should establish an amendment case file for all requests for amendment. The purpose of the file is to document all actions from the initial request for amendment through the final appeal. It should include a copy of the Privacy Act request for amendment and all correspondence and related material involving a particular record.

6. If the individual requests a review of a refusal to amend a record and the record is subsequently amended, or if the requested amendment is still denied, the amendment case file should be retained in accordance with approved record retention schedules.

7. The statute of limitations for bringing an action if the agency refuses to amend a record is two years. See 5 U.S.C. § 552a(g)(5). During this period, the case file may contain copies of the statements of disagreement and agency justification the original of which will be located with the record.


**37.2.1.3.1** **(08-11-2004)**

#### Evaluation of Records

01. Records Not Subject to Amendment. Certain requests to amend records pursuant to the Privacy Act are not properly subject to the amendment provisions of the Act. 5 U.S.C. § 552a(d)(2). The initial evaluation of any request should determine whether the record itself is subject to the amendment provisions of the Act, rather than whether the particular amendment requested is appropriate. Requests to amend records that cannot be processed on the basis of the following guidelines are to be returned to the requester with an appropriate explanation. A copy of the incoming letter and response will be maintained in an amendment case file.

02. Only records that are part of a system of records subject to the Act can be subject to the amendment provisions.

03. Records that are not retrieved by the name, identifying number, symbol, or other particular identifying information about an individual, or that do not pertain to a natural person, cannot be amended under the Act.

04. Records that pertain to or are retrieved by the identity of a corporation, estate, trust, or partnership cannot be amended under the Act. A sole proprietorship, however, is deemed to be an individual for purposes of the Act.

05. Individuals _may not_ use the amendment provisions of the Privacy Act to amend or correct any tax record. See I.R.C. § 7852(e). The determination of liability for taxes imposed by the Code, the collection of such taxes, and the payment (including credits or refunds of overpayments) of such taxes are governed by the provisions of the Code and by the procedural rules of the Service. These procedures are the exclusive means available to an individual to contest the amount of any liability for taxes or the payment or collection thereof.

06. Various systems of records have been determined to be exempt from some provisions of the Privacy Act and notices of these exemptions have been published in the Federal Register. Systems of records exempted in accordance with 5 U.S.C. § 552a(j)(2), (k)(2), (k)(4), (k)(5), and (k)(6) cannot be amended under the Act.

07. In addition, the following kinds of records have been determined by regulation to not be subject to amendment:



    - Transcripts or written statements made under oath

    - Transcripts of grand jury proceedings, judicial proceedings or quasi-judicial proceedings which form the official record of those proceedings

    - Pre-sentence reports that are the property of the courts but are maintained in agency files

    - Records compiled in reasonable anticipation of a civil action or proceeding


08. Form of Requests. If the request pertains to a record subject to the amendment provisions of the Act, the next step is to evaluate the adequacy of the request.



    1. All requests must be in writing and signed by the individual making the request.

    2. The request must pertain to that individual’s records, except that the parent of any minor, or the attorney in fact of any person, or the legal guardian of any individual who has been declared to be incompetent due to physical or mental incapacity or age by a court of competent jurisdiction, may act on behalf of the individual. A parent, attorney in fact, or legal guardian must submit adequate proof of legal relationship before being recognized to act on behalf of such individual.

    3. The request must include adequate proof of identity of the requester.



       > See CCDM 37.2.1.2.1. In evaluating the adequacy of identification supplied, consideration should be given to the possibility that an amendment that appears to be unfavorable or contrary to the best interests of the requester may be an indication that an improper attempt to amend the record is being made by a third party.

    4. The request should be clearly marked "Request for Amendment of Record" and should contain a statement that it is being made under provisions of the Privacy Act.

    5. The request must contain the name and address of the individual making the request. In addition, if a particular system of records employs an individual’s social security number as an essential means of accessing the system, the request must include that number.

    6. In case the record is maintained in the names of two or more individuals (e.g., husband and wife) the request must contain the names, addresses, social security numbers (if necessary for access) of each individual, but the signature and adequate identification for the requesting individual(s) only.

    7. The request must specify the name and location of the system of records (as published in the Notice of System of Records) in which the record is maintained, and the title and business address of the official designated in the access section of the Notice for that system.

    8. The request must specify the particular record in the system of records that the individual is seeking to amend. The request must clearly state the specific changes that the individual wishes to make in the record and a concise explanation of the reasons for the changes. If the individual wishes to correct or add any information, the request shall contain proposed specific language for the desired correction or addition.

    9. Requests to amend records that cannot be processed by the DPL attorney or Privacy Coordinator (as appropriate) will be returned to the requester with an explanation showing the additional items necessary to perfect the request. A record of the correspondence will be maintained in the case file.


09. Coordination with Record Owner. If the record is subject to the amendment provisions of the Act, the DPL attorney or Privacy Coordinator assigned to the amendment request should immediately contact the Office of Chief Counsel function whose records have been requested to be amended and obtain a copy of the record and a recommendation on whether the request to amend should be granted. See Exhibit 37.2.1-6.

10. Failure to Locate Record. If no action can be taken because the record cannot be located, does not exist, or has been destroyed, the requester will be advised accordingly. A record will be maintained of the steps taken to locate the record, of the response, and of the content of the proposed amendment.


**37.2.1.3.2** **(08-11-2004)**

#### Evaluation of Amendments

01. If the request pertains to a record subject to the amendment provisions of the Act, the request is adequate to permit processing, and the record has been located, it must be determined whether the proposed amendment should be made by considering paragraphs (2) through (9).

02. The portion of a record that is subject to correction because it is not accurate, relevant, timely, or complete is the factual information that pertains to the individual, such as his/her education, financial transactions, medical history, criminal history, or employment history, as opposed to subjective material that reflects opinion.

03. Care should be taken that any amendment does not trigger further action that could result in altering a tax matter, which is not subject to the amendment provisions of the Act.

04. Records may serve as a repository of information to be drawn upon for the purpose of making future determinations about an individual or they may merely serve to record past activities. The nature of the record will determine whether the existing information will be fully expunged from the record or will be annotated to reflect the amendment. Information that has already served as the basis for a Service action or determination may not be able to be fully expunged without distorting the historical experience that the record is intended to reflect. Care must be taken, however, that inaccurate, irrelevant, untimely, or incomplete existing information does not become the basis of a future determination.

05. If doubt exists as to whether the amendment should be made, the individual should, where appropriate, be asked to supply verifying data or documentary evidence.

06. Information that is not accurate is information that is not now and never has been correct. Such information should be corrected.

07. Information that is not relevant may or may not be correct, but is not necessary to accomplish a purpose of the Office of Chief Counsel. Such information should generally be completely expunged from the record.

08. Information that is not timely may have been correct when originally recorded but has become out of date. Such information need not be expunged since the addition of the current information would place the individual’s developing circumstances into proper perspective.

09. Information that is not complete is any information about which the individual raises no objection other than that he or she wishes to have additional information inserted in the record. This situation does not call for expunging or altering existing information. Generally, there would be no objection to an individual adding information to his or her record that is pertinent to information contained in the record.

10. If the proposed amendment has been accepted, the requester should be advised and provided with a courtesy copy of the corrected record if doing so is practical. Any difference between the correction actually made and the correction requested should be explained.

11. If it is determined that the requested amendment should not be made, the requester should be advised by the Assistant Chief Counsel (DPL) or the Area or Associate Area Counsel of the reasons for refusal and provided with a statement outlining the available administrative appeal rights. A complete file of all denials, including a copy of the request, a copy of the portion of the record involved (if practical), and a copy of the response will be maintained.


**37.2.1.3.3** **(08-11-2004)**

#### Making the Amendment

1. Notation of Amendment. Whenever records are amended, the record will be clearly marked "Information expunged, corrected, or added (whichever may be appropriate) Privacy Act Request" and the date.

2. Amending Paper Records. When paper records are involved, expunging the prior entry means to completely erase or otherwise render the information illegible. Corrections made without expunging the prior entry will consist of lining through the entry so as to make it apparent that it is no longer in effect without rendering it illegible. Information added to the file may consist of entries by pen and ink or by attaching additional sheets to the record.

3. Amending Non-paper Records. Records other than paper will be corrected by whatever means are ordinarily available for correcting erroneous entries or inserting additional information, so long as results comparable to 1 and 2 above are obtained.

4. Guidance. If difficulties are encountered in handling the physical aspect of carrying out an amendment due to the unusual nature of a record, guidance should be requested from the office of this Assistant Chief Counsel (DPL).


**37.2.1.3.4** **(08-11-2004)**

#### Notifying Prior Recipients

1. Requirements of the Act. Whenever a record is corrected at the request of an individual pursuant to the Privacy Act, each person or agency to whom that record has previously been disclosed must be notified of the exact nature of the correction to the extent that an accounting of disclosures was maintained.

2. Identifying Prior Recipients. In order to make this notification, it must be determined whether the specific portion of the record being corrected has been disclosed. Only those persons or agencies who received the specific portion of the corrected record need be notified of the correction.

3. Method of Notification. The system manager of the system of records that has been amended has the responsibility for notifying prior recipients. The usual manner of notification will be by providing the recipient with a photocopy of the amended record. In some circumstances it will be more practical to describe the correction made rather than send a photocopy, such as when the entire correction consists of deleting information.



### Note:



The system manager may seek assistance from the office of the Assistant Chief Counsel (DPL) in determining the system manager’s notification responsibilities.

4. Nature of Notification to Prior Recipients. If the corrections have been extensive and do not appear to be particularly relevant to the prior recipients’ interests, or if sufficient time has passed to suggest that the recipient may not be maintaining the records disclosed any longer, the nature of the corrections may be described to the recipient in sufficient detail to permit the recipient to determine if photocopies should be provided.


**37.2.1.3.5** **(08-11-2004)**

#### Review of Refusal to Amend a Record

1. A request for a review of a refusal to amend a record will be addressed or delivered to the Director, Office of Governmental Liaison & Disclosure (or delegate).

2. The Director, Office of Governmental Liaison & Disclosure (or delegate) will control the request for review of a refusal to amend records and refer to the Assistant Chief Counsel (DPL) that portion of the request for review of refusal to amend a record that pertains to an Office of Chief Counsel record.

3. Requests for review of a refusal to amend a record pertaining to systems of records under the jurisdiction of the Office of Chief Counsel will be determined by the Associate Chief Counsel (P&A).

4. A response to the request to review the refusal to amend an Office of Chief Counsel record will be prepared within 30 days of the receipt of the request to review. If the response cannot be completed within 30 days, the attorney assigned the case will so notify the individual within the 30 days and explain the reason for the delay and provide an approximate time when the response will be provided. See Exhibit 37.2.1-7.


**37.2.1.3.5.1** **(08-11-2004)**

##### Form of Requests for Review of Refusal to Amend Records

1. The DPL attorney will evaluate the adequacy of the request for review in accordance with the following standards:



1. The request shall be in writing, signed by the person to whom the record pertains (or duly authorized representative), and sent within 35 days of the date the individual was notified of an adverse determination.

2. The request must be clearly marked "Privacy Act Amendment Appeal" on the correspondence and the envelope.

3. The request must contain the name and address of the individual making the request. In addition, if a particular system of records employs an individual’s social security number as an essential means of accessing the system, the request must include that number. If the record is maintained in the name of two or more individuals, (e.g., husband and wife), the request should include the names, addresses, and social security numbers of all individuals.

4. The request must reasonably describe the records sought to be amended, including the title and business address of the official responsible for maintaining such system.

5. The request must include the date of the initial request for amendment of the record, and the date of the letter notifying the individual of the initial adverse determination.

6. The request must clearly state the specific changes the individual wishes to make in the record and a concise explanation of the reasons for the changes. If a copy of the initial request is attached, this requirement will be satisfied. If the individual wishes to correct or add any additional information, the request shall contain specific proposed language to make the desired correction or addition.


2. If the request substantially meets the regulatory requirements and is adequate to permit proper processing, discretion may be exercised in a particular instance to accept the request as filed.

3. If the request for review of a refusal to amend records is deficient, it will be returned to the requester with an appropriate explanation. A record will be maintained of the response. Resubmission of the request for review of the refusal to amend will be deemed timely if the original request for review of the refusal to amend was timely.

4. If the request for review of a refusal to amend is complete, and originated in the field, the DPL attorney will request that field counsel forward the file on the records not being amended and any other required materials.


**37.2.1.3.5.2** **(08-11-2004)**

##### Acting on Determinations

1. The Associate Chief Counsel (P&A) will make a determination to amend or not amend the record.

2. Reversal on Review. If the determination is to amend the record, the requester will be informed accordingly and the file will be returned to the appropriate system manager who will effect the actual amendment and inform any prior recipients of the record.

3. Affirming Initial Determinations. If the determination is not to amend the record in full or in part, the requester will be informed



   - Of the refusal and the reasons therefor

   - Of the right to file a concise statement of the requester’s reasons for disagreeing with the decision of the reviewing officer

   - Of the procedures for filing a statement of disagreement

   - That any such statement will be made available to anyone to whom the record is subsequently disclosed

   - That prior recipients of the disputed record will be provided a copy of any statement of dispute to the extent that an accounting of disclosures was maintained

   - Of the right to seek judicial review of the refusal to amend a record


**37.2.1.3.6** **(08-11-2004)**

#### Statement of Disagreement

1. Requirements of the Act. An individual who disagrees with a final determination not to amend a record subject to amendment under the Privacy Act may submit a concise statement for insertion in the record stating the reasons for disagreement with the refusal of the reviewing officer to amend the record. 5 U.S.C. § 552a (d)(3). A statement of disagreement should be addressed to the Director, Office of Governmental Liaison & Disclosure.

2. Assistant Chief Counsel (DPL) Responsibilities. The Director, Office of Governmental Liaison & Disclosure will forward the statement to the Assistant Chief Counsel (DPL), who will insert the statement in the individual’s record. Whenever physically possible, the contested entries in the record will be bracketed and the following notation placed on the record: See attached Statement of Disagreement.

3. Future Recipients. The Statement of Disagreement will be provided to all future recipients of that portion of the record to which it applies.

4. Prior Recipients. The system managers will ensure that prior recipients are notified of any Statement of Disagreement filed on the same basis as a correction.


**37.2.1.4** **(08-11-2004)**

### Accounting of Disclosures and Requests for Accounting of Disclosures

01. Section 552a(c) of the Privacy Act requires that agencies keep an accurate accounting of all disclosures to third parties except those made to Treasury employees in the course of their duties or those required to be made under the Freedom of Information Act (FOIA).

02. The accounting shall contain the date, nature, purpose, and recipient of disclosure.

03. Definitions. The following definitions are pertinent:



    - "Nature of Disclosure" means the method by which a disclosure is made and what was disclosed; e.g., by visual inspection of Form 1040, by computer printout, referral of audit administrative file, etc.

    - "Purpose of Disclosure" means the reason for which a disclosure was made

    - "Recipients of Disclosure" means the name and address of the person or agency to whom the disclosure was made


04. Responsible Individuals. Each employee of the Office of Chief Counsel who makes an accountable disclosure from a system of records will initiate a process by which the disclosure will be recorded. Under the procedures established by the Service, the personnel actually making a transfer of records to another agency will prepare the accounting. Therefore, any records, whether prepared by the Office of Chief Counsel or any other activity of the Service, that are physically transferred by the Office of Chief Counsel to another agency, will be accounted for by the pertinent office of Chief Counsel official when their office makes the transfer.

05. Section 6103. The record keeping requirements of the Privacy Act, to the extent certain disclosures require accounting under 5 U.S.C. § 552a(c), are superseded by section 6103(p)(3)(A). Disclosures made pursuant to any of the subsections listed in section 6103(p)(3)(A) do not require an accounting of disclosures.



    1. Accounting for disclosures made pursuant to subsections of section 6103 other than those listed in subparagraph 6103(p)(3)(A) is not limited to individual taxpayers, but is required for all types of returns and return information disclosed to third parties. See IRM 11.3.37.


06. Disclosures to the Department of Justice for Purposes of Tax Administration. Disclosures made to the Department of Justice (DJ) under section 6103(h)(3)(A) (referred cases) do not require an accounting. Section 6103(h)(3)(A) provides that the Service may, on its own initiative, make disclosures to DJ under section 6103(h)(2) by referring a tax case to DJ or when a taxpayer or third party initiates a suit against the IRS under subchapter B of Chapter 76 of the Code (e.g., under sections 7422, 7424, and 7428). Although section 6103 contains no definition of what constitutes a referral, the term has generally been construed as an institutional decision by the Service to request that DJ defend, prosecute, or take other affirmative action on a tax case on behalf of the Service, including search warrants, summons enforcement, writs of entry, etc.



    1. Exchanges of tax information with DJ, including disclosures made pursuant to requests from DJ (including U.S. Attorneys and Assistant U.S. Attorneys), in connection with a case that has been referred, are also considered disclosures under section 6103(h)(3)(A).



       ### Note:



       Disclosures to DJ pursuant to section _6103(h)(3)(B)_ (disclosures pursuant to written requests from the Attorney General, Deputy Attorney General, or an Assistant Attorney General) _do_ require an accounting. This includes instances in which DJ initiates tax investigations on its own and requests returns or return information from the Service.


07. Accounting for Disclosures of Returns and Return Information under Code Sections Other than Section 6103. Accounting requirements for disclosures of returns and return information made pursuant to sections of the Code other than section 6103 are unchanged by section 6103(p)(3). Therefore, Form 5466B need be prepared only for such disclosures pertaining to individuals.



    ### Example:



    Disclosures to the Joint Committee on Taxation of proposed refunds in excess of $2,000,000 under section 6405 require an accounting only for disclosures pertaining to individuals.

08. Method of Recording Disclosure on the IMF. IRM 11.3.37.3.1, Disclosure of Official Information, sets forth the general procedures for accounting for disclosures of returns and return information including codes to be used on Form 5466B.

09. Preparation of Additional Copy of Form 5466B. IRM 11.3.37.3.1 requires that Form 5466B be forwarded to the appropriate campus (national office sends Form 5466B to the Philadelphia Campus). For disclosures made by employees of the Office of Chief Counsel, an additional copy should be associated with the record from which the disclosure was made. Accordingly, Office of Chief Counsel personnel need to prepare two copies of Form 5466B.

10. Forwarding Form 5466B. Completed forms should be mailed on the last working day of the month to the appropriate campus.

11. Accounting Requirements for Disclosures of Nontax Information. Accounting requirements for disclosures of nontax information from systems of records need be made only for disclosures pertaining to individuals. Such accountings should not be sent to be incorporated on the IMF. One copy should be associated with the case file of the record disclosed and the original should be filed and maintained by the office making the disclosure. Form 5482, Accounting for Disclosures, may be used for this purpose if it is available; otherwise, Form 5466B may be used. The originals should be maintained alphabetically by name of individual. A separate file should be maintained for each calendar year in which disclosures are made so that the file may be destroyed after the sixth year. There is no need to prepare a separate Form 5482 for each source of records contained in the file actually disclosed. It is only necessary that an accounting be prepared for the system of records from which the disclosure is actually made.


**37.2.1.4.1** **(08-11-2004)**

#### Requests by Individuals for Accounting of Disclosures

1. Section 552a(c)(3) of the Privacy Act requires that an accounting of disclosures be made available to an individual upon request. Disclosures from exempt systems of records or disclosures in response to written requests from law enforcement officials as described in 5 U.S.C. § 552a(b)(7) need not be included in the accounting. Section 6103(p)(3) does not affect persons’ rights of access to accountings. Even though section 6103(p)(3) requires accountings for certain disclosures of returns and return information pertaining to non-individuals, access to those accountings under 5 U.S.C. § 552a(c)(3) is available only to individuals.

2. Treasury regulations provide that requests by individuals for accountings of disclosures must be in writing. Appropriate officials will establish the identity of the requester in accordance with instructions set forth in CCDM 37.2.1.2.1. See also IRM 11.3.18.8.1(3).

3. The Individual Master File (IMF) has been designated as the central recording medium for disclosures of returns and return information.



1. Because "Privacy Transcripts" generated by the IMF contain accountings of disclosures of non-Counsel records as well as Office of Chief Counsel records, requests for accountings of disclosures of returns and return information made to field counsel should be forwarded to the Disclosure Officer who services your geographic area.

2. Requests for accountings of disclosures of returns and return information made to a Division Counsel or Associate Chief Counsel should be forwarded to HQ Disclosure Office, Director, Governmental Liaison & Disclosure.


4. DPL attorneys or Privacy Coordinators (see CCDM 37.2.1.1) will analyze the request and prepare a letter to the requester in accordance with the following:



1. List the disclosures from the system(s) of records related to the subject of the inquiry. If no relevant disclosures were made, enter the word "none." Each entry should show the (1) date, nature, and purpose of disclosure; and (2) name and address of agency, activity, or person to whom disclosure was made.

2. Accountings of disclosures made pursuant to 5 U.S.C. § 552a(b)(7), of records from an exempt system(s), or of records that originated in an exempt system(s) of records, need not be provided to the individual.

3. The DPL attorney or Privacy Coordinator’s reviewer will sign the letter.

4. DPL attorneys or Privacy Coordinators will associate a copy of the letter with the case file from which the response was made.


**37.2.1.5** **(08-11-2004)**

### Agency Requirements under the Privacy Act

1. Section 552a(e)(8) of the Privacy Act requires that notices be sent to individuals whenever records pertaining to them are made available to another pursuant to compulsory legal process when the process becomes a matter of public record.

2. For purposes of administration of the Privacy Act, Treasury regulations provide that the notice will be sent within five days of making the records available or, with respect to a section 6103(i) court order or grand jury subpoena, within five days of the record becoming public. See 31 C.F.R. § 1.22(f).

3. The Service or Office of Chief Counsel official responding to compulsory legal process will be responsible for sending the notice required under 5 U.S.C. § 552a(e)(8). Personnel responding to such process must prepare an accounting of disclosures as provided in CCDM 37.2.1.4. The disclosure of tax records are accounted for under section 6103(p)(3).



1. In most cases, Service personnel will be preparing such accountings and sending the required notices because, generally, subpoenas are issued to those personnel.

2. Where Office of Chief Counsel personnel respond to such process, they will prepare the accountings and notice.


4. See CCDM 34.9.1.3 for treatment of situations when Office of Chief Counsel employees learn that a court order or court issued subpoena has been received requesting the disclosure of _tax_ records in non-tax litigation to which the Service or United States is not a party.

5. The following definitions are provided with respect to 5 U.S.C. § 552a(e)(8):



1. "Compulsory legal process" is an order of any court of record, a summons, or a subpoena (whether ad testificandum or duces tecum) issued by any authority legally empowered to issue such writs. It does _not_ include interrogatories, requests for admission and other discovery unless pursuant to a court order enforcing such discovery. It also does _not_ include legal process signed by a court clerk or opposing counsel; it is limited to process signed by a judge or magistrate, or a grand jury subpoena.

2. "Notice" means notice to the last known address of the individual.

3. This provision of the Privacy Act is applicable only to inquiries for which individuals are requested to provide information about themselves. It does not pertain to inquiries directed to third parties asking for information about someone else.

4. Individuals — The provision applies to taxpayers (including individuals in their entrepreneurial capacity) and to other persons to whom inquiries about themselves may be addressed, including Office of Chief Counsel employees.


6. The following sample language is offered as guidance with respect to the notice required under 5 U.S.C. § 552a(e)(8).



|     |
| --- |
| "This is to advise that records pertaining to you maintained in the Office of Chief Counsel have been made available to \[Name\] pursuant to compulsory legal process served on the Internal Revenue Service. This notice is sent to you in compliance with the Privacy Act of 1974, 5 U.S.C. § 552a(e)(8). This information pertains to \[provide a summary of the information provided\]." |


**37.2.1.5.1** **(08-11-2004)**

#### Information Collection, Maintenance, and Dissemination

1. Associate Chief Counsel, Division Counsel, and Area Counsel should instruct personnel under their supervision who are involved in the design, development, operation, or maintenance of any system of records, or in maintaining, collecting, using or disseminating any record, of the requirements set forth in the Treasury Department Regulations on Access to Records. See 31 C.F.R. § 1.28(a).

2. Solicitation of information from an individual about himself should be accompanied by a Privacy Act Notice conforming to 5 U.S.C. § 552a(e)(3). This includes information sought from Service and Office of Chief Counsel employees by the agency — as an employer — on personnel forms. If there is no Privacy Act Notice on the solicitation or any accompanying instructions, contact the Assistant Chief Counsel (DPL).

3. The "Umbrella" Notice for Solicitations of Information. Since many solicitations of information represent repeated contacts with the same individual pertaining to basically the same situation, the Service has adopted an umbrella approach in which the initial contact of a series will include a notice that the individual may retain and would be applicable to all future inquiries related to that situation. This approach spares the recipient from receiving repetitive and unnecessary identical notices and reduces the cost of complying with this requirement.

4. 1040 "Umbrella" Notice. The Service will include in the Form 1040/1040A/1040EZ packages a universal notice that applies to U.S. Individual Income Tax Returns, to declarations of estimated tax, to any other tax return required to be filed by individuals, to schedules, statements, or other documents related to the returns, and to subsequent inquiries necessary to complete, correct and process the returns of these taxpayers to determine the correct tax liability and to collect any unpaid tax, interest, or penalty.

5. Tax Cases. In view of the foregoing, it should not be necessary for Office of Chief Counsel personnel to furnish any additional notice to taxpayers with respect to tax cases handled by their offices.

6. For information on giving of notice by Office of Chief Counsel personnel regarding expert witnesses, see CCDM 37.2.1.6.

7. Office of Chief Counsel personnel should be aware that:



1. Individuals who have a pending collection activity will be provided with a notice upon first contact by the Campus or the collection personnel;

2. Taxpayers whose returns are selected for examination will be provided with notices on their first contact; and,

3. With respect to solicitations of information in criminal tax investigations and prosecutions, no notice will be provided because such systems of records are exempt from the notice requirements of 5 U.S.C. § 552a(e)(3).


**37.2.1.5.2** **(08-11-2004)**

#### Disclosure of Personnel Information

1. The Office of Personnel Management has determined that six data elements pertaining to Federal employees are generally available to the public. See 5 C.F.R. § 293.311(a). Information provided in accordance with 5 C.F.R. § 293.311 is required to be made available under the FOIA.

2. Where the context of the request means that furnishing the six items would reveal more than the authorized items of information and would constitute a clearly unwarranted invasion of privacy, the information will be withheld. These items of information are not furnished with respect to Series 1811 Criminal Investigators. See also 5 C.F.R. §293.311(b)(1); IRM 11.3.20.7.1.

3. All requests for income or employment verification should be routed through the employee’s personnel office for response.

4. Information to Other Federal Agencies. Service systems of records have a routine use for disclosure to a Federal agency in response to its request in connection with the hiring or retention of a former or current employee, or other benefit conferred by the requesting agency. Questions of this nature shall be responded to by the employee’s supervisor. An accounting is required for this type of disclosure.

5. Non-agency Employment Reference. When requests for information from personnel files on former or present employees are received from people or organizations other than Federal agencies, no information other than that described in 5 C.F.R. § 293.311 may be provided unless written consent is obtained from the individual to whom the record pertains. Disclosures made with the consent of the individual nevertheless require an accounting.


**37.2.1.5.3** **(08-11-2004)**

#### Assuring Integrity of Systems of Records, Coordination

1. While security measures are necessary with respect to tax information, the Privacy Act imposes security requirements with respect to all information pertaining to an individual. All Office of Chief Counsel executives are responsible for the integrity of systems of records under their control. 5 U.S.C. § 552a(e)(10).

2. All employees involved in the design, development, operation, or maintenance of any system of records are to be instructed with respect to the requirements of the Privacy Act. See 5 U.S.C. § 552(e)(9); 31 C.F.R. § 1.28(a). Associate Chief Counsel, Division Counsel, or Area Counsel, with the assistance of the Assistant Chief Counsel (DPL), as needed, should undertake such instruction of their personnel as is appropriate about the requirements of the Act.


**37.2.1.5.4** **(08-11-2004)**

#### Establishment or Alteration of Systems of Records

1. The Privacy Act requires that adequate advance notice to Congress, the Office of Management and Budget, and the public be given before the establishment or substantial alteration of any system of records. Publication of the notice invites comments on the proposed new system or substantial alteration of an existing system of records. 5 U.S.C. § 552a(o). Additionally, the Act requires publication in the Federal Register of any new or intended "routine use" 30 days before the final publication of such "routine use" to allow for comments. 5 U.S.C. § 552a(e)(4).

2. The creation of new methods of recordkeeping or changes to existing methods could create new systems of records covered by the Act or have an impact on existing systems. Therefore, before any new system is established or any existing system is substantially altered, including the addition of routine uses, the foregoing advance notice must be provided. Associate Chief Counsel, Division Counsel and Area Counsel should contact the Assistant Chief Counsel (DPL).


**37.2.1.6** **(08-11-2004)**

### Solicitation of Personal Information from Expert Witnesses

1. The following applies to all personnel of the Office of Chief Counsel who solicit personal information, including social security numbers, from those with whom we may, or do, contract with as expert witnesses.

2. Section 552a(e)(3) of the Privacy Act requires each agency that maintains records about an individual in a system of records to inform each individual whom it asks to supply information, on a form that it uses to collect the information or on a separate sheet or form that can be retained by the individual, of the authority for requesting the information; the principal purpose(s) for which the information will be used; the routine uses (external disclosures) of the information, and the effect(s), if any, on the individual of not providing all or part of the information.

3. Office of Chief Counsel personnel who solicit personal information, including social security numbers, from those with whom we may, or do, contract as expert witnesses shall provide the notice set forth in Exhibit 37.2.1-8 at the time the personal information is solicited.

4. If Office of Chief Counsel personnel perceive the need to provide a notice similar to that set forth in Exhibit 37.2.1-8 to individuals other than those with whom we may, or do, contract with as expert witnesses, or have questions about the notification obligations of the Privacy Act, they should coordinate with the Assistant Chief Counsel (DPL) before providing the notice.


**Exhibit 37.2.1-1** **(08-11-2004)**

### Sample Letter Advising Requester of Delay

|     |     |     |     |
| --- | --- | --- | --- |
| **OFFICE OF CHIEF COUNSEL**<br>**Internal Revenue Service**<br>**Washington, DC 20224** |
|  |  |  |  |
|  |  |  | QPAR-XXXXXX-YY |
|  |  |  |  |
| Mr. Robert Requester<br>1111 Roe Place<br>Washington, D.C. xxxxx |  |  |  |
|  |  |  |  |
| Dear Mr. Requester: |  |  |  |
|  |  |  |  |
| This is in reference to your Privacy Act request for access to records by letter dated \[month\] \[day\], \[year\]. We have not been able to respond to your request within the originally projected time period because of a delay in obtaining the requested records. We anticipate that a response will be mailed to you on or before \[month\] \[day\], \[year\]. |
|  |  | Sincerely, |  |
|  |  | \[Name\]<br>Associate Chief Counsel<br>(Procedure & Administration) |
|  |  |  |  |
|  | By: |  |  |
|  |  | \[Name\]<br>Chief, Disclosure & Litigation Support Branch<br>Telephone Number (202) 622-XXXX<br>Badge Number 50-XXXXX |

**Exhibit 37.2.1-2** **(08-11-2004)**

### Search Memorandum

|     |     |     |
| --- | --- | --- |
| **_To be prepared on standard Chief Counsel Memorandum form_** |
|  |  | QPAR- XXXXXX-YY |
|  |  |  |
| TO: ASSOCIATE CHIEF COUNSEL |
|  | \[insert appropriate function name here\]<br>\[insert office symbols here\] |  |
| FROM: Chief, Disclosure & Litigation Support Branch CC:PA:LPD:DLS |
| SUBJECT: Privacy Act Request of Robert Requester for Access |
| The attached Privacy Act (PA) request is for records which we believe to be within your function. An exemption \[has OR has not\] been asserted for this system of records in the Federal Register. |
| Please process this PA request as instructed in CCDM 37.2.1.2. Applicable PA exemptions should be asserted as set forth in CCDM 37.2.1.2.2. However, even where the documents are from an exempt system of records under the PA, they must still be evaluated for release under the Freedom of Information Act (FOIA). 5 U.S.C. § 552a(t). See also CCDM 30.11.3.4. Please provide us with one clean set of all responsive records and another complete set of responsive records with proposed redactions made with pink highlighter. Also provide written explanation of why each proposed redaction should be made. When considering a recommendation that the Service assert one or more discretionary FOIA exemptions as a basis for withholding (e.g., deliberative process, attorney-client, or attorney work product), please be cognizant of the agency’s discretionary disclosure standard as set forth in IRM 11.3.13.7.1, Disclosure of Official Information. Report the amount of time expended in searching for these records and the grade level of the individual who made the search. |
| Please respond within ten (10) business days of the date of this memorandum. You should also provide the name and telephone number of the person in your office who will be available to explain the scope of the search performed and the factual basis for the withholding of all or part of the records. This person should maintain accurate and detailed documentation of the search performed and be prepared, at some future date, to execute a declaration describing the search. |
| You may direct any questions you might have in responding to this request to \[employee\] at \[phone number\]. A Workload Item (WLI) has been opened to your office. You should charge any time spent on responding to this PA request to case number QPAR-XXXXXX-YY. |

**Exhibit 37.2.1-3** **(08-11-2004)**

### Sample Letter Granting Access to Records

|     |     |     |     |
| --- | --- | --- | --- |
| **OFFICE OF CHIEF COUNSEL**<br>**Internal Revenue Service**<br>**Washington, DC 20224** |
|  |  |  |  |
|  |  |  | QPAR-XXXXXX-YY |
|  |  |  |  |
| Mr. Robert Requester<br>1111 Roe Place<br>Washington, D.C. xxxxx |  |  |  |
|  |  |  |  |
| Dear Mr. Requester: |  |  |  |
|  |  |  |  |
| This is in response to your request pursuant to the Privacy Act of 1974, dated \[month\] \[day\], \[year\], for records contained in two systems of records. I am granting your request. Copies of the documents are enclosed. |
|  |  | Sincerely, |  |
|  |  | \[Name\]<br>Associate Chief Counsel<br>(Procedure & Administration) |
|  |  |  |  |
|  | By: |  |  |
|  |  | \[Name\]<br>Chief, Disclosure & Litigation Support Branch<br>Telephone Number (202) 622-XXXX<br>Badge Number 50-XXXXX |
| Enclosures: (# of pages) |  |  |  |

**Exhibit 37.2.1-4** **(08-11-2004)**

### Sample Letter Denying Request for Access

|     |     |     |     |
| --- | --- | --- | --- |
| **OFFICE OF CHIEF COUNSEL**<br>**Internal Revenue Service**<br>**Washington, DC 20224** |
|  |  |  |  |
|  |  |  | QPAR-XXXXXX-YY |
|  |  |  |  |
| Mr. Robert Requester<br>1111 Roe Place<br>Washington, D.C. xxxxx |  |  |  |
|  |  |  |  |
| Dear Mr. Requester: |  |  |  |
|  |  |  |  |
| This is in response to your request pursuant to the Privacy Act of 1974, dated \[month\] \[day\], \[year\], for records contained in two systems of records. |
| I am denying your request. The two systems from which you have requested records, system 90.005 (Chief Counsel General Litigation Case File) and system 90.009 (Chief Counsel Tax Litigation Case Files), are exempt systems of records pursuant to 5 U.S.C. § 552a(k)(2). These exemptions were promulgated by rule published at 31 C.F.R. app. B, & (b), _post_ § 1.36 (Internal Revenue Service) (7-1-1999). Additionally, the requested records were compiled in reasonable anticipation of civil litigation and are exempt from the access provisions of the Privacy Act pursuant to subsection (d)(5) of the Act. |
| If you desire judicial review of this decision, a complaint may be filed under 5 U.S.C. § 552a(g) in the United States District Court in the district in which you reside, or have your principal place of business, or in which the agency records are located or in the District of Columbia. The documents at issue are located in Washington, D.C. |
|  |  |  |  |
|  |  | Sincerely, |  |
|  |  | \[Name\]<br>Associate Chief Counsel<br>(Procedure & Administration) |
|  |  |  |  |
|  | By: |  |  |
|  |  | \[Name\]<br>Chief, Disclosure & Litigation Support Branch<br>Telephone Number (202) 622-XXXX<br>Badge Number 50-XXXXX |

**Exhibit 37.2.1-5** **(08-11-2004)**

### Sample Acknowledgement of Request for Amendment

|     |     |     |     |
| --- | --- | --- | --- |
| **OFFICE OF CHIEF COUNSEL**<br>**Internal Revenue Service**<br>**Washington, DC 20224** |
|  |  |  |  |
|  |  |  | DL-XXXXXX-YY |
|  |  |  |  |
| Mr. Robert Requester<br>1111 Roe Place<br>Washington, D.C. xxxxx |  |  |  |
|  |  |  |  |
| Dear Mr. Requester: |  |  |  |
|  |  |  |  |
| This is to acknowledge receipt of your Privacy Act request for amendment of records by letter dated \[month\] \[day\], \[year\]. |
| Your letter was received by the Office of the Assistant Chief Counsel (Disclosure & Privacy Law) on \[month\] \[day\], \[year\]. A response to your request should be forwarded to you on or before \[month\] \[day\], \[year\] \[30 business days after date of receipt\]. In the interim, should you have any questions concerning the status of the matter or wish to discuss it, please contact me. |
|  |  |  |  |
|  |  | Sincerely, |  |
|  |  | \[Name\]<br>Associate Chief Counsel<br>(Procedure & Administration) |
|  |  |  |  |
|  | By: |  |  |
|  |  | \[Name\]<br>Attorney<br>Assistant Chief Counsel<br>(Disclosure & Privacy Law)<br>Telephone Number (202) 622-XXXX<br>Badge Number 50-XXXXX |

**Exhibit 37.2.1-6** **(08-11-2004)**

### Sample Memorandum to System Manager

|     |     |     |
| --- | --- | --- |
| **_To be prepared on standard Chief Counsel Memorandum form_** |
|  |  | DL-XXXXXX-YY |
|  |  |  |
| TO: Associate Chief Counsel (Finance & Management) |
| FROM: Name, Chief, Branch X (Disclosure & Privacy Law) |
| SUBJECT: Request of Richard Roe for Amendment of Record under the Privacy Act |
| Attached is a copy of a request to amend a record in system of records 90.011, Attorney Recruiting Files, for which you are the system manager. Please forward a copy of the record requested to be amended and your recommendations on whether the request to amend should be granted. This system of records has not been exempted from the amendment provisions of the Privacy Act. If you need any assistance in responding to this request, contact \[name of attorney to whom case assigned\] at \[phone number\]. |
| Because we are required to promptly advise the requester of our determination, please respond to this memorandum by \[month\] \[day\]\[(15 business days)\]. |
| Attachment |

**Exhibit 37.2.1-7** **(08-11-2004)**

### Sample Notification of Delay of Response to Review Refusal of Amendment

|     |     |     |     |
| --- | --- | --- | --- |
| **OFFICE OF CHIEF COUNSEL**<br>**Internal Revenue Service**<br>**Washington, DC 20224** |
|  |  |  |  |
|  |  |  | DL-XXXXXX-YY |
|  |  |  |  |
| Mr. Robert Requester<br>1111 Roe Place<br>Washington, D.C. xxxxx |  |  |  |
|  |  |  |  |
| Dear Mr. Requester: |  |  |  |
|  |  |  |  |
| This is to inform you that we will not be able respond to your \[month\] \[day\], \[year\], Privacy Act request for a review of a refusal to amend certain records in the Office of Chief Counsel. \[state reason for delay.\] |
| Your letter was received by the Office of the Assistant Chief Counsel (Disclosure & Privacy Law) on \[month\] \[day\], \[year\]. A response to your request should be forwarded to you on or before \[month\] \[day\], \[year\]. In the interim, should you have any questions concerning the status of the matter or wish to discuss it, please contact me. |
|  |  |  |  |
|  |  | Sincerely, |  |
|  |  | \[Name\]<br>Chief Counsel |
|  |  |  |  |
|  | By: |  |  |
|  |  | \[Name\]<br>Attorney<br>Assistant Chief Counsel<br>(Disclosure & Privacy Law)<br>Telephone Number (202) 622-XXXX<br>Badge Number 50-XXXXX |

**Exhibit 37.2.1-8** **(08-11-2004)**

### Notice to Expert Witnesses

|     |
| --- |
| **Information Regarding Solicitation of Personal Information from Non-Employees Who May Be Paid Compensation** |
| This information is provided to you before you submit information to the Internal Revenue Service to be considered for a contract as an expert witness. The authority to collect the information is derived from 5 U.S.C. § 301, 26 U.S.C. §§ 7801, 7804 and 6109, and 31 U.S.C. § 7701(c). The information will be used principally to consider you for expert witness services, and, if selected, to process your contract to perform expert witness services and to ensure remuneration under that contract. You are not required to supply the information requested in the solicitation process. However, if you fail to provide the requested information, you could be rejected from consideration by the IRS for this contract. A false answer to any question in the written portion of the solicitation may be punishable under 18 U.S.C. § 1001. If false statements are discovered after the award of the contract, the contract may be terminated. |
| The Internal Revenue Code requires every person with respect to whom a return, statement, or other document is required to be made by another person to furnish his or her social security number to such other person (Section 6109 and the regulations pertaining thereto). If the amount of compensation paid to you by the Internal Revenue Service in any taxable year amounts to $600 or more, we are required to file an information return as to you. (Section 6041) Therefore, if the amount of compensation you will receive from us in a taxable year amounts to $600 or more, it is mandatory that you provide your social security number to us. If the amount of compensation received from us in a taxable year is less than $600, providing your social security number is voluntary. (Sections 6041A and 6050M). |
| We may disclose the information we have solicited from you for the purpose of litigating a tax proceeding in Federal court, including the Tax Court; to the Department of Justice for the purpose of litigating an action and seeking legal advice; to members of Congress for the purpose of answering congressional inquiries; to a Federal, State or local agency maintaining civil, criminal or other relevant law enforcement information or other pertinent information, such as current licenses, if necessary to obtain information relevant to any agency decision concerning the hiring or retention of an individual, issuance of a security clearance, the letting of a contract, or the issuance of a license, grant or other benefit; to a Federal agency, in response to its request, in connection with the hiring, retention of an employee, issuance of a security clearance, the reporting and investigation of an employee, the letting of a contract, or the issuance of a license, grant or other benefit by the requesting agency, to the extent that the information is relevant and necessary to the requesting agency’s decision on the matter. We may disclose information pertaining to an apparent violation of the law to the appropriate law enforcement authorities for investigation or possible prosecution, civil court action or regulatory order. |

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part37/irm_37-002-001#addtoany "Show all")

A2A