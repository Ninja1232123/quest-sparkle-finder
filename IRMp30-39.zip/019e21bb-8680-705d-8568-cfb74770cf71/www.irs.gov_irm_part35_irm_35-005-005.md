---
url: "https://www.irs.gov/irm/part35/irm_35-005-005"
title: "35.5.5 Arbitration and Mediation | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-005-005#main-content)

- 35.5.5 [Arbitration and Mediation](https://www.irs.gov/irm/part35/irm_35-005-005#idm139724104108048)
  - 35.5.5.1 [Voluntary Binding Arbitration](https://www.irs.gov/irm/part35/irm_35-005-005#idm139724104107616)
  - 35.5.5.2 [Arbitration Selection Guidelines](https://www.irs.gov/irm/part35/irm_35-005-005#idm139724104098688)
  - 35.5.5.3 [Arbitration Procedures](https://www.irs.gov/irm/part35/irm_35-005-005#idm139724104078192)
  - 35.5.5.4 [Mediation](https://www.irs.gov/irm/part35/irm_35-005-005#idm139724104035840)
  - 35.5.5.5 [Mediation Criteria](https://www.irs.gov/irm/part35/irm_35-005-005#idm139724104027872)
  - 35.5.5.6 [Mediation Process](https://www.irs.gov/irm/part35/irm_35-005-005#idm139724104022256)
  - 35.5.5.7 [Mediator Selection Guidelines](https://www.irs.gov/irm/part35/irm_35-005-005#idm139724104012208)
  - 35.5.5.8 [Agreement to Mediate](https://www.irs.gov/irm/part35/irm_35-005-005#idm139724103998624)

# Part 35. Tax Court Litigation

# Chapter 5. Settlement Procedures

# Section 5. Arbitration and Mediation

* * *

## 35.5.5 Arbitration and Mediation

**35.5.5.1** **(12-14-2010)**

### Voluntary Binding Arbitration

1. Under T.C. Rule 124, the parties may move that any factual issue in controversy be resolved through binding arbitration. The motion may be made before trial at any time after the case is at issue. Upon the filing of the motion, the chief judge will assign the case to a judge or special trial judge for disposition of the motion and supervision of any subsequent arbitration. The use of the procedure, in appropriate cases, can result in a more efficient use of judicial and Service resources and assist in reducing the Tax Court’s inventory. The Executive Order 12988 on Civil Justice Reform encourages the use of all alternative dispute resolution techniques (including binding arbitration where warranted) before utilizing any formal Court proceedings. Field attorneys are encouraged to contact the office of Associate Chief Counsel (Procedure & Administration) for guidance.

2. Cases involving factual issues such as valuation, reasonable compensation, or IRC § 482 should be evaluated for arbitration. Arbitration may be appropriate whether the case involves solely a factual issue or multiple issues where the factual issue can be severed. Arbitration is not appropriate for cases involving the substantiation of expenses under IRC §§ 162 and 274. Also, use of the arbitration procedure may not be appropriate; for example, if a settlement appears imminent, substantial resources have already been expended toward trial preparation, or a decision has been made that the Service must litigate the case because of its importance.

3. For more information on the use of arbitration to resolve disputes, Field attorneys may refer to the Administrative Dispute Resolution Act of 1996, 5 U.S.C. § 571 et seq., and Executive Order 12988 on Civil Justice Reform (effective on May 5, 1996), which encourages the use of all alternative dispute resolution techniques including binding arbitration where warranted before utilizing any formal court proceedings.


**35.5.5.2** **(08-11-2004)**

### Arbitration Selection Guidelines

1. _Binding Nature_. There must be a stipulation between the parties to be bound by the findings of the arbitrator in respect of the issues to be resolved.

2. _Selection and Payment of the Arbitrator_. The parties must stipulate to a procedure for jointly selecting the arbitrator with each party agreeing to pay one half of the arbitrator’s compensation, expenses and related fees and costs. The arbitrator’s qualifications and potential bias in favor of the taxpayer should be thoroughly explored prior to hiring. The arbitrator should agree to look solely to each party for one half of his or her compensation, expenses and related fees and costs.

3. _Limitations with Respect to the Arbitrator_. Some purposes of the stipulation are to focus the arbitrator on the prescribed task of finding facts based on a stipulated body of information; to preserve the integrity of the arbitrator’s work; and to control and minimize unnecessary contact with the court or the parties with the arbitrator after the arbitrator has been jointly hired and until the arbitrator has made or submitted findings of fact.



1. _Information to be considered_. The parties’ stipulation should precisely describe kind of information and any limitations related thereto that the arbitrator is permitted to consider. Field attorneys may consider placing a deadline in the stipulation for the providing of information to the arbitrator by both parties.

2. _Contacts with or by the arbitrator_. The stipulation should prohibit _ex parte_ contacts with the arbitrator. The stipulation should also specify the conditions under which the arbitrator may be contacted by the Service and the petitioner, as well as the conditions under which the arbitrator may contact the parties or the court for further guidance.

3. _Scope of arbitrator’s work_. The stipulation should normally also reflect that the arbitrator is not permitted to make any findings or provide reasoning that represents an interpretation of the law. The arbitrator is generally limited to the task of finding facts. Field attorneys may consider providing that the arbitrator must find a minimum value (e.g., the amount reported on the estate tax return) so that the arbitrator cannot select a value that would result in a refund to the taxpayer. Attorneys may also consider providing a maximum value for the arbitrator (e.g., the amount stated in the statutory notice).

4. _Legal guidance to arbitrator_. Any applicable legal guidance should be stipulated beforehand, or in extraordinary instances when some guidance has been overlooked or not contemplated beforehand, the parties may upon agreement stipulate to the provision of further legal guidance to the arbitrator and the manner in which it is to be communicated to the arbitrator. The stipulation may also indicate the tax treatment of the arbitrator’s findings or clarify any issues which may arise in calculating the deficiency resulting from the arbitrator’s fact-finding.


4. _General Supervisory Powers of the Court_. The parties must stipulate to the general supervisory powers of the court. The stipulation should note that the case will be assigned to a particular judge or special trial judge who will have continuing jurisdiction over the case. The court’s participation is in the nature of oversight.


**35.5.5.3** **(12-14-2010)**

### Arbitration Procedures

1. If the parties desire to submit a factual issue to arbitration, the attorney should first submit a request for the hiring of an arbitrator by memorandum to the Area Counsel (GLS). After the request has been approved, the Field attorney can then prepare a joint motion to resolve the issue or issues through voluntary binding arbitration. The motion is to be accompanied by a stipulation to be bound by the findings of the arbitrator. Field attorneys should coordinate with Procedure & Administration before seeking or agreeing to seek arbitration of any docketed Tax Court cases. Attorneys are to forward copies of all Tax Court orders pertaining to arbitration procedures to Procedure & Administration. These motions should be filed as soon as possible after the case is at issue. If the case has already been calendared, the motion should request a continuance from the trial session. For examples, see Exhibit 35.11.1-115, Joint Motion for Voluntary Binding Arbitration, Exhibit 35.11.1-116, Joint Motion for Stipulation to be Bound by Findings of Arbitrator, and Exhibit 35.11.1-117, Joint Motion to Continue for Settlement Purposes.

2. The arbitrator will be appointed by order of the court. The order may contain such directions to the arbitrator and to the parties as the judge or special trial judge considers to be appropriate.

3. The parties will report promptly to the court the findings made by the arbitrator and will attach to the report any written report or summary that the arbitrator may have prepared.

4. Field offices are encouraged to make greater use of the procedures under T.C. Rule 124 to resolve factual issues.


**35.5.5.4** **(12-14-2010)**

### Mediation

1. Mediation is a confidential process in which a neutral third party directs settlement discussions, but does not render judgment regarding any issue in dispute. A mediator holds meetings, defines issues, defuses emotions, and suggests possible ways to resolve a dispute. In contrast to arbitration, a mediator is not formally presented with evidence. Mediation is a nonbinding process. It should be the goal of the parties to reach an agreement with finality. The mediator will help the parties reach their own negotiated settlement.

2. Although there is no specific Tax Court rule describing the use of mediation, this type of procedure can be utilized by the parties to resolve Tax Court cases with the oversight of the court. General guidance on mediation may be gained from the procedures outlined in Rev. Proc. 2002–44, 2002 I.R.B. 10 and Notice 2001–67, 2001 I.R.B. 544, which announced the Large Business and International (LB&I) Fast Track Dispute Resolution Program. Field attorneys should coordinate with Procedure & Administration before seeking or agreeing to seek mediation of any docketed Tax Court cases.

3. The use of mediation, in appropriate cases, can result in a more efficient use of judicial and Service resources and assist in reducing the Tax Court’s inventory. Nevertheless, Counsel should not attempt to use mediation in lieu of established settlement procedures or when use of mediation would unduly delay discovery or trial. Instead, mediation should be utilized when other standard settlement procedures, such as Appeals consideration, have failed and when, in the opinion of the office, it is cost effective and otherwise appropriate.

4. Field attorneys should be aware that mediation must be effected within normal trial preparation time frames since efforts at mediation may not be considered good cause for a continuance. Thus, although the parties may advise the Tax Court in making any status report that settlement negotiations are proceeding in good faith and that the parties have entered into an agreement to mediate, such an agreement does not guarantee a continuance.


**35.5.5.5** **(08-11-2004)**

### Mediation Criteria

1. Fact-based cases lend themselves more readily to mediation. Accordingly, mediation is generally appropriate for cases involving factual issues. Mediation should generally not be used for any industry-wide issues, Appeals Coordinated Issues, or for cases or issues designated for litigation since the settlements of these issues have been circumscribed by other procedures. Except in extraordinary circumstances, mediation should not be available where it has already been made available to the taxpayer or tried once without success, _e.g._, at the Appeals level.

2. Mediation is not available for an issue for which the taxpayer has filed a request for Competent Authority assistance, or an issue for which the taxpayer intends to seek Competent Authority assistance. If a taxpayer enters into a settlement with the Office of Chief Counsel (including a settlement through the mediation process), and then requests Competent Authority assistance, the United States Competent Authority will endeavor only to obtain a correlative adjustment with the treaty country and will not take any actions that would otherwise amend the settlement.


**35.5.5.6** **(08-11-2004)**

### Mediation Process

1. The following description is a suggested framework. Field Counsel may find it necessary to adjust the process to suit their needs. The parties to the mediation process will be the taxpayer (and his or her representative) and Field Counsel. Each party should have someone with decision-making authority at the mediation or available by telephone. Participants in the mediation may include the taxpayer’s counsel or chief financial officer, the Field attorney in charge of the case and any other members of Field Counsel’s litigation team. In this regard, Field Counsel may want to have someone present who can prepare settlement computations. Counsel is encouraged to invite Appeals representatives to participate in the mediation process. It is advisable to have only one spokesperson for Field Counsel’s team. Other members of Field Counsel’s team may attend all sessions and participate, but not directly. Inasmuch as mediation is an informal process, breaks and sidebars can be taken at any time.

2. The mediation process generally will begin by each party presenting their respective views of the issues to the mediator. During each presentation, the mediator will ask questions of each side in order to clarify the facts. Following the opening presentation, the parties typically move to different conference rooms, and the mediator then meets separately with each party.

3. The mediator will help the parties reach their own negotiated settlement. To accomplish this goal, the mediator will act as a facilitator, assist in defining the issues, and promote settlement negotiations between the parties. The mediator will not have settlement authority in the mediation process and will not render a decision regarding any issue in dispute. The mediator should inform and discuss with the parties the rules and procedures pertaining to the mediation process.

4. The mediator’s tasks include encouraging each party to move toward a middle ground. At the end of the mediation session, the parties meet together in a joint session to take notes on their mutual understanding of any possible basis for settlement and of the issues submitted for mediation. Experience indicates that settlement is more likely if there is only one mediation session limited to one day; memorializing the settlement may, however, require additional time.

5. If the parties reach an agreement on all or some of the issues through the mediation process, Field Counsel will draft a stipulation of settled issues or a decision document for the parties’ signature and submission to the Tax Court. The stipulation of settled issues or decision documents should be prepared as part of the mediation process or very shortly thereafter in order to prevent later disagreements about the issues that were settled during the mediation. If the parties are not able to reach an agreement on an issue being mediated, the parties will prepare for trial as normal.


**35.5.5.7** **(08-11-2004)**

### Mediator Selection Guidelines

1. The taxpayer and Field Counsel should jointly select a mediator. If the parties cannot agree on a mediator, they may agree to a procedure to be used to select a mediator. In addition, the parties may seek the assistance of the Federal Mediation and Conciliation Service (telephone number (202) 606–5445) in selecting a mediator.

2. Consideration should be given to requesting a Special Trial Judge to serve as a mediator. The Tax Court has made judges available for this service.

3. A mediator must have no official, financial, or personal conflict of interest or past or present relationship with respect to the parties, unless such interest or relationship is fully disclosed in writing to the taxpayer and Field Counsel, and they agree that the mediator may serve. It is incumbent upon the Field attorney to thoroughly explore whether a conflict or other circumstance likely to affect impartiality exists with regard to all proposed mediators.

4. The mediator will be disqualified from representing the taxpayer in any pending or future action that involves the transactions or issues that are the particular subject matter of the mediation. This disqualification extends to representing any other parties involved in the transactions or issues that are the particular subject matter of the mediation. Moreover, the mediator’s firm will be disqualified from representing the taxpayer and any other parties involved in the mediation in any actions that involve both the same taxable year and the transactions or issues that are the particular subject matter of the mediation.

5. The mediator’s firm will not be disqualified from representing the taxpayer or any other parties in an action that involves the same transactions or issues that are the subject matter of the mediation, provided that such action relates to a different taxable year and the firm through screening procedures precludes the mediator from any form of participation in the matter and does not apportion to the mediator any part of the fee therefrom. While the mediator may not receive a direct allocation of the fee from the taxpayer in the matter for which the screening procedures are in effect, the mediator will not be prohibited from receiving a salary, partnership share or corporate distribution established by prior independent agreement. The mediator and his or her firm are not disqualified from representing the taxpayer in any matters unrelated to the transactions or issues that are the particular subject matter of the mediation.

6. The mediator should be an expert in the negotiated settlement process. Criteria for selecting a mediator may include completion of mediation training, previous mediation experience, a substantive knowledge of tax law, or knowledge of industry practices. Criteria may also include the projected travel costs, hourly fees and other expenses.

7. The hiring of a mediator and the commitment of funds and resources to finance the mediation process must be approved pursuant to normal rules and regulations for government procurement. Each party will usually agree to pay one-half of the mediator’s compensation, expenses and related fees and costs, and the mediator should agree to look solely to each party for one-half of his or her compensation, expenses and related fees and costs. A number of Appeals Officers have had sufficient training in mediation techniques to support an Appeals initiative on mediation in certain nondocketed cases. Consideration should be given to selection of an Appeals mediator, which might reduce costs for both parties and preserve limited Office of Chief Counsel budget resources for expert witnesses and other expenses if settlement is not reached and trial becomes necessary.


**35.5.5.8** **(12-14-2010)**

### Agreement to Mediate

1. If the parties desire to submit an issue to mediation, the Field attorney should submit a request for the hiring of a mediator by memorandum to the Area Counsel (GLS). After the request has been approved, the taxpayer and Field Counsel generally will enter into a written agreement to mediate.

2. The mediation agreement and any other documents regarding the mediation should be coordinated with Procedure & Administration prior to execution. It is advisable that the agreement be as concise as possible but include the following elements.



01. The agreement should specify the issue(s) to be mediated by the parties.

02. The agreement should provide how and when each party will present its case to the mediator; e.g., each party will prepare a short discussion summary, along with any pertinent exhibits, of the issues for consideration by the mediator, to be followed by oral discussions on a particular date.

03. The agreement might require each party to submit to the mediator and one another a list of participants expected to be present at the mediator session. It is strongly recommended that the taxpayer or an official with the authority to bind the taxpayer participate directly in the mediation sessions.

04. The agreement should contain an acknowledgment by the taxpayer that all participants in the mediation shall have access to all the taxpayer’s returns or return information pertaining to the issues being considered pursuant to IRC § 6103 and the regulations thereunder, particularly IRC §§ 6103(c), and 6103(n) and the regulations thereunder. (A waiver pursuant to section 6103 should also be obtained from the taxpayer).

05. The agreement should prohibit _ex parte_ contacts with the mediator outside the mediation session.

06. The agreement should state that the parties to the mediation acknowledge that under IRC § 7214(a)(8), Service employees are required to report information concerning violations of any revenue law to the Secretary of the Treasury.

07. If an Appeals mediator is selected, the written agreement to mediate shall include a statement confirming the employee’s proposed service as a mediator, that the mediator is a current employee of the Service and that any conflict resulting from that mediator’s continued status as a Service employee is known to and waived by the parties.

08. The agreement should state that mediation is a confidential process, and all participants will be subject to the confidentiality and disclosure provisions of the Internal Revenue Code, including IRC §§ 6103, 7213 and 7431. Additionally, any participants in the mediation process may not voluntarily, or through discovery or compulsory process, disclose any information regarding the mediation process, or disclose any communication made during the mediation process, including the settlement terms.

09. The agreement should provide that either party may withdraw from the mediation process at any time prior to reaching a settlement of the issues to be mediated by notifying the other party and the mediator in writing.

10. The agreement should provide that a settlement reached by the parties through mediation shall not serve as an estoppel in any other proceeding; and such settlement may not be considered in any factually unrelated proceeding and may not be used as precedent.

11. The agreement should include a schedule of dates on or before which each step in the mediation process should be completed. For example, the agreement should specify the date by which the parties should select a mediator, the date by which the parties should submit their discussion summaries to the mediator and each other, and the date by which the parties should submit their list of participants to the mediator and each other.


3. _See_ Exhibit 35.11.1–118 for a model agreement to mediate and Exhibit 35.11.1–119 for a model mediation participant’s list in CCDM 35.11.1.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-005-005#addtoany "Show all")

A2A