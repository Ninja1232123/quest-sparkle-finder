---
url: "https://www.irs.gov/irm/part30/irm_30-004-011"
title: "30.4.11 Pro Bono Activities | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part30/irm_30-004-011#main-content)

- 30.4.11 [Pro Bono Activities](https://www.irs.gov/irm/part30/irm_30-004-011#idm140614691995472)
  - 30.4.11.1 [Introduction](https://www.irs.gov/irm/part30/irm_30-004-011#idm140614709500816)
  - 30.4.11.2 [Office of Chief Counsel Pro Bono Legal and Volunteer Services Policy](https://www.irs.gov/irm/part30/irm_30-004-011#idm140614709498560)
  - 30.4.11.3 [Definition of Pro Bono Legal and Volunteer Services](https://www.irs.gov/irm/part30/irm_30-004-011#idm140614680462960)
  - 30.4.11.4 [Limitations of Pro Bono Legal and Volunteer Services](https://www.irs.gov/irm/part30/irm_30-004-011#idm140614710720480)
  - 30.4.11.5 [Approval and Other Procedures](https://www.irs.gov/irm/part30/irm_30-004-011#idm140614707023248)
  - 30.4.11.6 [Use of Official Position/Public Office/Agency Resources](https://www.irs.gov/irm/part30/irm_30-004-011#idm140614710714640)
  - 30.4.11.7 [Pro Bono and Volunteer Services Policy and Ethics Requirements](https://www.irs.gov/irm/part30/irm_30-004-011#idm140614710701760)
  - 30.4.11.8 [Voluntary Participation](https://www.irs.gov/irm/part30/irm_30-004-011#idm140614710700016)
  - Exhibit 30.4.11-1 [Sample Pro Bono Retainer Letter](https://www.irs.gov/irm/part30/irm_30-004-011#idm140614710695072)

# Part 30. Administrative

# Chapter 4. Personnel Administration, Training, and Equal Employment Opportunity

# Section 11. Pro Bono Activities

* * *

## 30.4.11 Pro Bono Activities

#### Manual Transmittal

July 26, 2018

#### Purpose

(1) This transmits new CCDM 30.4.11, Pro Bono Activities

#### Material Changes

(1) CCDM 30.4.11 is being issued to provide current policy regarding pro bono legal and volunteer services.

#### Effect on Other Documents

This section incorporates policy regarding pro bono legal and volunteer services.

#### Audience

Chief Counsel

#### Effective Date

(07-26-2018)

Ashton P. Trice

Deputy Associate Chief Counsel

(Procedure & Administration)

**30.4.11.1** **(07-26-2018)**

### Introduction

1. This section sets forth the Office of Chief Counsel policy regarding pro bono legal and volunteer services. Participation in pro bono legal and volunteer services will benefit attorneys by providing an opportunity to enhance their professional skills and increase their knowledge by engaging in practice that is outside of their day-to-day expertise. Participation in these activities will also help to fulfill the tremendous unmet need for pro bono legal services in our communities and enable attorneys to strengthen their communities by representing those in need of help and unable to afford it. Accordingly, attorneys are encouraged to participate in pro bono legal and volunteer services, and should work with their managers to receive the necessary approvals.


**30.4.11.2** **(07-26-2018)**

### Office of Chief Counsel Pro Bono Legal and Volunteer Services Policy

1. Pro bono legal work allows participants to assist individuals and strengthen communities and, at the same time, presents opportunities to enhance professional skills. It is the policy of the Office of Chief Counsel to facilitate voluntary participation in such activities by its attorneys.

2. This section describes the Office of Chief Counsel's policy on pro bono legal and volunteer services for persons employed within the Office. Employees seeking guidance on other outside employment activities should consult General Counsel Directive No. 6.


**30.4.11.3** **(07-26-2018)**

### Definition of Pro Bono Legal and Volunteer Services

1. Pro bono services include the uncompensated provision of legal services to the following:



1. persons of limited means or other disadvantaged persons;

2. charitable, religious, civic, community, governmental, health and educational organizations in matters that are designed primarily to address the needs of persons of limited means or other disadvantaged persons, or that further their organizational purpose;

3. individuals, groups or organizations seeking to secure or protect civil rights, civil liberties or public rights; or

4. activities for improving the law, the legal system, or the legal profession.


2. Volunteer Services include those services, other than the practice of law, provided without compensation to the following:



1. persons of limited means or other disadvantaged persons;

2. charitable, religious, civic, community, governmental, health and educational organizations in matters that are designed primarily to address the needs of persons of limited means or other disadvantaged persons or that further their organizational purpose;

3. individuals, groups or organizations seeking to secure or protect civil rights, civil liberties or public rights; or

4. activities for improving the law, the legal system, or the legal profession.


3. The examples provided above are illustrative only and are not intended as an exhaustive list of what may be considered pro bono and volunteer services. The definitions are modeled upon those provided in the Department of Justice Policy Statement on Pro Bono Legal and Volunteer Services, which in turn is based on Rule 6.1 of the ABA Model Rules of Professional Conduct.

4. Partisan political activities or compensated outside employment or other similar activities shall not be considered pro bono service under any circumstances.


**30.4.11.4** **(07-26-2018)**

### Limitations of Pro Bono Legal and Volunteer Services

1. The following statutes and regulations govern and limit the types of pro bono activities open to Chief Counsel Attorneys. The following descriptions are summaries only. The full text of these provisions should be consulted whenever questions arise.



1. 18 U.S.C § 205 prohibits Federal employees from engaging in certain activities in claims against and other matters affecting the United States, that would require the employee to act as an agent or attorney:


       1\. for prosecuting any claim against the United States or receiving any gratuity, or share of or interest in such claim, in consideration of assistance in the prosecution of such claim; or


       2\. for anyone else before the Government (including Federal courts) in connection with any covered matter in which the United States is a party or has a direct and substantial interest.

2. 5 C.F.R. part 2635, Standards of Ethical Conduct for Employees of the Executive Branch, specifies that it is inconsistent with the standards of conduct to engage in any outside employment or other outside activity which would:


       1\. require the recusal of the employee from significant aspects of the employee's official duties (5 C.F.R. 2635.802(b)); or


       2\. create an appearance that the employee’s official duties were performed in a biased or less than impartial manner (5 C.F.R. 2635.502); or


       3\. create an appearance of official sanction or endorsement (5 C.F.R. 2635.702(b)); or


       4\. would be prohibited by statute or agency supplemental regulation (5 C.F.R. 2635.802(a)).

3. 5 C.F.R. 3101 _et seq._ contains supplemental regulations for Treasury employees. In particular, 5 C.F.R. 3101.107 prohibits Legal Division attorneys from engaging in the outside practice of law that might require the attorney to take a position that is or might appear to be in conflict with the interests of the Department of the Treasury; or to interpret any statute, regulation or rule administered or issued by the Department.

4. Employees of the Legal Division are also subject to the rules on outside employment or activities applicable to employees of the bureaus or offices in which they serve, 5 C.F.R. 3101.107(a). Under the rules applicable to all IRS employees, attorneys may not:


       1\. perform legal services involving Federal, state or local tax matters;


       2\. appear on behalf of any taxpayer as a representative before any Federal, state or local government agency, in an action involving a tax matter unless consistent with 18 U.S.C. § 205 and with the written permission of the Deputy Chief Counsel (Operations);


       3\. engage in accounting, or the use, analysis, and interpretation of financial records when such activity involves tax matters;


       4\. engage in bookkeeping, the recording of transactions, or the record making phase of accounting, when such activity is directly related to a tax determination; and engage in the preparation of tax returns for compensation, gift or favor.

5. Federally Funded Programs. Treasury employees should be cognizant of the fact that their participation in cases or activities involving Federally funded programs may be inappropriate when the Department directly administers the funding for the specific program. Any questions concerning the appropriateness of participation in such a case or activity will be resolved on a case-by-case basis.


**30.4.11.5** **(07-26-2018)**

### Approval and Other Procedures

1. Consistent with Department of the Treasury General Counsel Directive No. 6, employees are permitted, when not on duty, to participate on a non-compensated basis, in the activities of civic, scout, religious, educational, fraternal, social, community, veterans and charitable organizations without prior approval. Employees are expected to consult with supervisors regarding activities that may cause an actual or apparent conflict of interest or if they become heavily involved (e.g., in a leadership position) in the volunteer activity and if that activity requires a significant time commitment.

2. Attorneys may engage in pro bono legal activities upon receipt of written permission from the Deputy Chief Counsel (Operations). Before engaging in any pro bono activities, attorneys must submit a completed Form 7995-A (Chief Counsel Outside Employment or Business Activity Request) to the attorney’s direct supervisor to receive permission to engage in pro bono legal activities. On line 13 (description of the Outside Employment or Business Activity) of Form 7995-A, the attorney seeking permission to engage in pro bono legal activities will include, at a minimum, the following information:



1. the name, address, and telephone number of the prospective client, or if the prospective client’s information is unknown, the name, address, and telephone number of the organization coordinating or facilitating the pro bono legal activity;

2. a description of the attorney’s anticipated duties;

3. the number of hours the attorney expects to work (per day, week, or month, as applicable);

4. the projected duration of the pro bono legal work;

5. any relationship of the proposed client to the attorney; and

6. any relationship of the proposed client, if a business entity, to the Internal Revenue Service, the Office of Chief Counsel or Treasury.


3. The attorney's direct supervisor will be responsible for recommending approval or disapproval of the pro bono legal work requested. The attorney's direct supervisor will perform a conflict of interest check before making an approval recommendation. Attorneys are prohibited from engaging in any outside activity which would conflict with the attorney's official duties. If the supervisor has any questions about the propriety of the request, the supervisor should contact the Ethics and General Government Law Branch. Reference materials a supervisor may consider when performing the conflict of interest check are available online at the GLS Ethics Link. If necessary, the attorney’s direct supervisor will elicit any additional information needed regarding avoiding conflicts of interest, or the appearance of conflicts of interest, from the attorney seeking approval to engage in the pro bono legal activity.

4. Authority to approve pro bono legal activities has been delegated to the Deputy Chief Counsel (Operations). The Form 7995-A should be submitted for the approval of each level of supervision between the attorney and the Associate Chief Counsel or Division Counsel. The Associate Chief Counsel or Division Counsel should then forward the recommended approval request to the Chief, Ethics and General Government Law Branch of GLS, who will prepare the recommendation for the Deputy Chief Counsel (Operations).

5. The attorney is responsible for avoiding conflicts of interest, or the appearance of conflicts of interest, in the pro bono activity. When there has been any change in circumstances that may be material to continuing approval of the activity, the attorney must submit a new request for approval. The attorney must also resubmit a request when the nature of the pro bono activity changes, or the attorney’s official duties or immediate supervisor changes. The attorney is responsible for reporting annually to the attorney’s immediate supervisor regarding any continued involvement in pro bono activities. The Form 7995-A should be used for this annual report. Unless there is a change in circumstances or in the nature of the pro bono activity, the annual report only needs approval through the Associate Chief Counsel or Division Counsel.

6. The attorney should prepare a retainer letter for each pro bono legal activity in which the attorney is engaged in client representation, making explicit to the client that the attorney is working as an individual and not in the capacity as a government lawyer. The attorney should consult with the appropriate State bar association in making a determination as to the content of the retainer letter. Some state bars, and some pro bono organizations that make referrals, require that a retainer letter be prepared when the attorney is representing a client in an individual capacity. See Exhibit 30.9.4.9-1, Sample Retainer Letter.

7. Information on requirements to practice pro bono may be obtained from State bar associations or administrative offices of the courts. In most states, attorneys may not undertake pro bono work unless they are licensed by that state. The District of Columbia bar is an exception to that general statement. Attorneys should check their state bar or licensing requirements to determine eligibility to engage in pro bono work prior to requesting approval to engage in pro bono activities in accordance with this policy statement.

8. The government is unable to provide malpractice insurance to attorneys taking pro bono cases. Prior to accepting a pro bono service, the attorney should determine whether the referring program or organization may provide malpractice insurance for the work. The immunities that may be granted to government attorneys in the performance of their official duties do not extend to pro bono work. Therefore, the Office of Chief Counsel strongly encourages attorneys to work with a legal service provider that carries malpractice insurance.

9. Due to conflict-of-interest issues, many pro bono opportunities available will be outside of the attorney’s expertise. Referring agencies frequently offer training seminars in the fields encountered in pro bono work.


**30.4.11.6** **(07-26-2018)**

### Use of Official Position/Public Office/Agency Resources

1. Attorneys who engage in pro bono or volunteer activities do so as private individuals. Attorneys are responsible for making it explicit to clients and other involved parties that they are not acting as representatives of the Office of Chief Counsel. Identification of an individual’s position in the Office of Chief Counsel or the Treasury Department is permissible only as long as it is merely incidental to the pro bono or volunteer service performed (e.g., information necessary to provide a mailing address or a telephone number may be revealed).

2. Pro bono or volunteer service should be performed outside of normal working hours. Occasions, such as court appearances, may call for pro bono or volunteer service during the business day. Employees must request to use annual leave or accumulated credit hours before engaging in pro bono or volunteer activities during their scheduled working hours. In considering these requests, supervisors should accommodate, when possible, the efforts of their employees to do pro bono or volunteer work, while paying due consideration to the effect of the employee’s absence on the operations of the office. A decision to grant or deny leave or use of credit hours may not be affected by the supervisor’s personal views regarding the substance of the pro bono or volunteer activity. Employees should remember, when resolving any scheduling conflicts, that their primary responsibility is to the Office of Chief Counsel.

3. Employees may not use official titles, business cards, office letterhead, fax coversheets, or anything else that identifies the employee as a member of the Office of Chief Counsel, or that could be reasonably construed to imply that the Office of Chief Counsel sanctions or endorses a personal activity. Additionally, employees may not use their public office for their own private gain, for the endorsement of any product, service or enterprise, or for the private gain of friends, relatives, or persons with whom the employees are affiliated in a nongovernmental capacity, including nonprofit organizations of which the employees are officers or members, and persons with whom the employees have or are seeking employment or business relations. 5 C.F.R. 2635.702.

4. Employees may not use information that they gain by reason of Federal employment and that they know or reasonably should know has not been made available to the general public for their own private interest or that of another, whether by advice or recommendation. 5 C.F.R. 2635.703.

5. Employees may only use Government property for those purposes authorized in accordance with law or regulation. 5 C.F.R. 2635.704. The following limited personal uses of Government office and research equipment and facilities are authorized in connection with approved pro bono work:



1. use of property that involves minimal time and expense (e.g., electricity, ink, small quantities of paper, and ordinary wear and tear);

2. occasional outgoing telephone/fax calls or calls that are charged to non-Government accounts (e.g., personal telephone credit cards);

3. use of word processing equipment; use of library, microfiche, and electronic databases when there is no extra cost to the office; and

4. use of internet services.


These limited personal uses are subject to the Office’s rules and policies regarding security, confidentiality, and other matters. This policy does not override statutes, rules, or regulations governing the use of specific types of government property, including telephone, e-mail, and internet services. See CC-2011-016, Chief Counsel Policy on Limited Personal Use of Government Technology Equipment/Resources. Employees may not use Office email systems to send communications to pro bono clients, opposing counsel, or third parties. Employees have no expectation of privacy in these communications which could compromise the confidentiality of such communications. Further, the use of Office email may create the appearance that the employee is misusing the employee’s official position for the benefit of pro bono clients or volunteer services. Employees wishing to use more than a small amount of office supplies must provide their own or pay for their cost. Any use of government resources for pro bono or volunteer purposes must not interfere with official business, and supervisors should be consulted if there is any question over whether such use is “minimal.” The policy may be revoked or limited at any time by any supervisor for any business reason. Employees with questions about the application of this section to any particular situation should consult their supervisor.

6. Work related to pro bono or volunteer activities may not be assigned to clerical or support staff. Asking clerical or support staff if they wish to participate in pro bono or volunteer activities may violate 5 C.F.R. 2635.702 and/or 2635.705.


**30.4.11.7** **(07-26-2018)**

### Pro Bono and Volunteer Services Policy and Ethics Requirements

1. The Associate Chief Counsel (General Legal Services) will serve as a general resource for ethics issues arising from pro bono and volunteer services activities.


**30.4.11.8** **(07-26-2018)**

### Voluntary Participation

1. This policy statement is intended to remove existing policy barriers which inhibit the performance of pro bono and volunteer service, and to serve as a guide for those who voluntarily wish to participate in these activities. It is not intended to require this participation, nor is this participation to be made a rating element of any employee.

2. This policy statement is intended only to encourage pro bono legal and volunteer activities and is not intended to create any right or benefit, substantive or procedural, enforceable at law by a party against the United States, its agencies, its officers, or any person. The United States, the Department of the Treasury and the Office of Chief Counsel will not be responsible in any manner or to any extent for any negligent or otherwise tortuous acts or omissions on the part of any employee while engaged in any pro bono or volunteer activity. The Office of Chief Counsel permits pro bono and volunteer activities by its employees, but it exercises no control over the services and activities of employees engaged in pro bono or volunteer activities, nor does it control the time or location of any pro bono or volunteer activity. Each employee is acting outside the scope of the employee’s Federal employment whenever the employee participates, supports, or joins in any pro bono or volunteer activity.

3. For further guidance contact the Associate Chief Counsel (P&A) Branches 1 or 2.


**Exhibit 30.4.11-1**

### Sample Pro Bono Retainer Letter

|     |     |     |
| --- | --- | --- |
| Retainer Agreement for Attorney Services |
| 1. | By this agreement,\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ ("Client" ) retains \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ ("Pro Bono Counsel" ) to advise, represent, appear and act for Client concerning the following matter:<br> \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_<br> The Pro Bono Counsel is acting in his/her individual capacity, and is not acting on behalf of the Internal Revenue Service, the IRS Office of Chief Counsel, or the Department of Treasury. |
| 2. | This case was referred to Pro Bono Counsel through \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_. The client understands that it is Pro Bono Counsel and not \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ that is representing him/her in this matter. The Client certifies that no other attorney is representing him/her in this matter and understands that the Pro Bono Counsel cannot and does not promise a successful outcome. |
| 3. | The Pro Bono Counsel agrees to undertake this representation on a pro bono basis, which means that the Pro Bono Counsel will not charge the Client for attorney or paralegal hours expended on this matter. Additionally, Pro Bono Counsel will not seek attorney’s fees in connection with this matter. |
| 4. | The Client agrees to cooperate fully with the Pro Bono Counsel and will promptly notify the Pro Bono Counsel of any of the following: |
|  | (A) | any changes in address, telephone number, or changes in the client’s situation which may impact Attorney’s representation; or |
|  | (B) | any plans to leave town which might interfere with court dates or appointments. |
| 5. | The Client agrees to assist the Pro Bono Counsel with this matter by: |
|  | (A) | providing complete information, including information that will assist the Pro Bono Counsel to investigate this matter; |
|  | (B) | maintaining regular contact with Pro Bono Counsel as is necessary for the conduct of his/her case; |
|  | (C) | attending and being on time for all appointments and court dates; |
|  | (D) | promptly notifying Pro Bono Counsel when other people contact Client about the case; and |
|  | (E) | helping to locate persons who may provide information about this case. |
| 6. | Pro Bono Counsel agrees to: |
|  | (A) | keep the Client informed about the status of his/her case; |
|  | (B) | keep all sensitive information provided by the client confidential unless authorized by the Client to disclose it (except that information may be shared with other attorneys who are working on the case or assisting with representation); |
|  | (C) | consult with the Client before making any significant decisions about the case; and |
|  | (D) | not settle the case without Client’s consent. |
| 7. | The Client agrees to assume responsibility for all expenses, which may include, but are not limited to, agency or court filing fees, costs of service of process and certified mail and any other administrative costs or litigation expenses. Attorney will discuss any significant costs with Client before incurring them. Client understands that Pro Bono Counsel does not charge a fee for his/her work on the case. |
| 8. | When Pro Bono Counsel closes Client’s file, all original documents that were furnished by Client shall be returned. Pro Bono Counsel will maintain the file for \_\_\_\_\_ years from the date of case closing, after which time it will be destroyed. |
| 9. | By agreeing to represent Client in the matter set forth above, Pro Bono Counsel does not agree to represent Client in any appeal, to collect any money judgement, or to enforce any order obtained in this matter. The parties may agree at a later time to extend representation to another matter. Any such extension will be the subject of a separate written agreement between the parties. |
| 10. | Client understands that Client may end this agreement at any time for any reason and agrees to notify Pro Bono Counsel in writing that he/she wishes to end this Agreement. |
| 11. | Client understands that Pro Bono Counsel reserves the right to withdraw from representing Client in certain limited circumstances. These circumstances include, but are not limited to, the following: |
|  | (A) | where insufficient legal grounds exist to continue a court or administrative action or appeal; |
|  | (B) | where Client fails to cooperate with the reasonable request of Pro Bono Counsel; |
|  | (C) | Where a conflict of interest is discovered or arises which makes it inappropriate for Pro Bono Counsel to continue representation; and |
|  | (D) | where client fails to meet the terms of this agreement. |
| 12. | Client has read this agreement in its entirety, or has had it read and explained to him/her in its entirety, before signing it. Client understands the terms of this agreement and agrees that it shall apply throughout the course of Pro Bono Counsel’s representation of him/her. |
| 13. | This writing represents the entire agreement between the parties and cannot be amended or modified except in writing signed by the parties. |
| \\_\\_\\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ | \\_\\_\\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |
| Client | Date |
|  |
| \\_\\_\\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ | \\_\\_\\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |
| Pro Bono Counsel | Date |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part30/irm_30-004-011#addtoany "Show all")

A2A