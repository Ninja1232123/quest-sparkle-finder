---
url: "https://www.irs.gov/irm/part35/irm_35-003-023"
title: "35.3.23 Motions in Collection Due Process Cases | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-003-023#main-content)

- 35.3.23 [Motions in Collection Due Process Cases](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270551546912)
  - 35.3.23.1 [Motions Generally](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270551683184)
  - 35.3.23.2 [Jurisdictional Issues Relevant to Motions](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270551576144)

    - 35.3.23.2.1 [Taxpayer Must Make Timely Request for Hearing](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270551482640)
    - 35.3.23.2.2 [Time for Filing for Judicial Review](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270551628736)

      - 35.3.23.2.2.1 [Determination Letter](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270551499824)

    - 35.3.23.2.3 [Innocent Spouse](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270524005536)
    - 35.3.23.2.4 [Nonjusticiable Claims](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270502579648)

  - 35.3.23.3 [Motion to Change Caption](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270523028016)
  - 35.3.23.4 [Motion to Dismiss on the Ground of Mootness](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270525517712)

    - 35.3.23.4.1 [Liability is Fully Paid](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270551561104)
    - 35.3.23.4.2 [Assessment Has Been Abated](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270551629664)

  - 35.3.23.5 [Motion to Dismiss for Lack of Jurisdiction](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270551613984)

    - 35.3.23.5.1 [Motion to Dismiss for Lack of Jurisdiction When a Taxpayer Petitions the Tax Court Based on the Assessment of a Restitution Order Pursuant to IRC 6201(a)(4)](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270551622400)

  - 35.3.23.6 [Motion to Dismiss for Failure to State a Claim Upon Which Relief Can be Granted](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270551484464)
  - 35.3.23.7 [Motion to Remand](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270551683984)

    - 35.3.23.7.1 [Remand Not Appropriate](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270525311648)
    - 35.3.23.7.2 [Remand Procedure](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270512303808)
    - 35.3.23.7.3 [Application of Ex Parte Rules to Remanded CDP Cases](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270511747088)

  - 35.3.23.8 [Motion for Summary Judgment](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270507996496)

    - 35.3.23.8.1 [General Grounds for Summary Judgment](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270528899600)
    - 35.3.23.8.2 [Liability Issues Under IRC 6330(c)(2)(B)](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270507819568)
    - 35.3.23.8.3 [Abuse of Discretion Issues](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270525442016)
    - 35.3.23.8.4 [Declaration](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270519756688)

  - 35.3.23.9 [IRC 6330(e)(2) Motions (Motions to Permit Levy)](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270524311792)

    - 35.3.23.9.1 [Underlying Tax Liability Not at Issue](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270511070688)
    - 35.3.23.9.2 [Good Cause](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270519543440)
    - 35.3.23.9.3 [Procedures for Filing IRC 6330(e)(2) Motion](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270526189520)

  - 35.3.23.10 [Petitions From Letters Denying Hearing Requests Under IRC 6330(g)](https://www.irs.gov/irm/part35/irm_35-003-023#idm140270519737424)

# Part 35. Tax Court Litigation

# Chapter 3. Motions

# Section 23. Motions in Collection Due Process Cases

* * *

## 35.3.23 Motions in Collection Due Process Cases

#### Manual Transmittal

February 08, 2017

#### Purpose

(1) This transmits revised CCDM 35.3.23, Motions in Collection Due Process Cases.

#### Material Changes

(1) CCDM 35.3.23.5.1, Motion to Dismiss for Lack of Jurisdiction When CDP Hearing Request Denied Under IRC 6330(g), is deleted.

(2) CCDM 35.3.23.5.2, Motion to Dismiss for Lack of Jurisdiction When a Taxpayer Petitions the Tax Court Based on the Assessment of a Restitution Order Pursuant to IRC § 6201(a)(4), is renumbered as 35.3.23.5.1.

(3) New CCDM section 35.3.23.10, Petitions From Letters Denying Requests Under IRC § 6330(g), is added.

#### Effect on Other Documents

CCDM 35.3.23, dated October 18, 2016, is superseded. This section incorporates the procedures described in Chief Counsel Notice CC-2016-008 into new section CCDM 35.3.23.10.

#### Audience

Chief Counsel

#### Effective Date

(02-08-2017)

Frederick W. Schindler

Deputy Associate Chief Counsel

(Procedure and Administration)

**35.3.23.1** **(07-25-2012)**

### Motions Generally

1. Many Collection Due Process (CDP) cases should be resolved by pretrial motion without trial, unless the taxpayer is properly contesting the underlying tax liability. It is therefore critical that appropriate motions be filed sufficiently in advance of the trial date.

2. It is important to file motions to permit levy under IRC 6330(e)(2) in cases involving taxpayers who raise solely frivolous and groundless issues and in other appropriate cases whenever possible. See CCDM 35.3.23.9.

3. The Tax Court frequently requests certified Form 4340, Certificate of Assessments and Payments, transcripts in cases seeking summary judgment and in cases seeking dismissal for failure to state a claim upon which relief may be granted. The best practice is to include certified Form 4340 transcripts for all relevant periods with all dispositive motions. The Form 4340 should be reviewed thoroughly, and any issues raised by entries on the Form 4340, or inconsistencies with other documents, should be explained in the motion.

4. When Appeals states in the notice of determination that all or a portion of the underlying tax liability will be abated, the trial attorney should ensure that the abatement is made and reflected on the transcript prior to filing a pre-trial motion. The attorney must ask Appeals to input this adjustment manually.


**35.3.23.2** **(07-25-2012)**

### Jurisdictional Issues Relevant to Motions

1. The following provides background on jurisdictional issues present in CDP cases that may be relevant to the ability to resolve CDP cases by pretrial motion.


**35.3.23.2.1** **(07-25-2012)**

#### Taxpayer Must Make Timely Request for Hearing

1. After a notice of intent to levy (the "final" notice) or notice of lien filing is issued, the taxpayer must make a written request for a CDP hearing within 30 days as specified in IRC §§ 6320 and 6330. Otherwise, the taxpayer is only entitled to an equivalent hearing (assuming the equivalent hearing request is timely under Treas. Reg. §§ 301.6320-1(i)(2) and 301.6330-1(i)(2), which is not subject to judicial review. IRC §§ 6320(a)(3)(B) and 6330(a)(3)(B). While CDP notices generally must be provided prior to levy, in some circumstances they may be provided after levy. IRC 6330(f).


**35.3.23.2.2** **(07-25-2012)**

#### Time for Filing for Judicial Review

1. Under IRC 6330(d)(1), a taxpayer has 30 days from the date of the notice of determination in which to appeal the determination to the Tax Court.


**35.3.23.2.2.1** **(07-25-2012)**

##### Determination Letter

1. The Tax Court does not have jurisdiction over the CDP case unless the taxpayer timely appeals from a valid notice of determination.

2. Prior to issuing the notice of determination:



1. Appeals must offer a hearing to the taxpayer, which depending on taxpayer’s preference and the issues raised, may be face-to-face or by telephone or correspondence.

2. The CDP hearing is required to be held by an impartial Appeals officer who has had no pre-CDP involvement with respect to the unpaid tax at issue.


3. The notice of determination is addressed to the taxpayer and gives a summary of the determination made by Appeals.

4. The attachment to the notice of determination includes:



1. Verification that the requirements of applicable law or administrative procedure have been met.

2. Consideration of the challenges that the taxpayer raises to the tax liability.

3. Consideration of the collection alternatives the taxpayer has proposed.

4. Determination of whether the proposed levy or the lien filing balances the need for efficient collection of taxes with the taxpayer’s legitimate concern that the levy or notice of lien filing is no more intrusive than necessary.


**35.3.23.2.3** **(07-25-2012)**

#### Innocent Spouse

1. A taxpayer may raise any appropriate spousal defense at a CDP hearing. IRC 6330(c)(2)(A)(i). Spousal defenses raised in a CDP hearing are governed by the provisions of IRC 6015 or IRC 66. A taxpayer may not, however, raise a spousal defense at a CDP hearing when the IRS has made a final determination as to the spousal defense in a final determination letter or statutory notice of deficiency. See Treas. Reg. §§ 301.6320-1(e)(3) Q&A E4, 301.6330-1(e)(3) Q&A E4.


**35.3.23.2.4** **(10-18-2016)**

#### Nonjusticiable Claims

1. The existence and amount of the underlying tax liability cannot be challenged at a CDP hearing if the taxpayer received a statutory notice of deficiency for the taxes in question or otherwise had an earlier opportunity to dispute the tax liability. IRC 6330(c)(2)(B). An opportunity to dispute a liability includes a prior opportunity for a conference with Appeals that was offered either before or after assessment of the liability. Treas. Reg. §§ 301.6320-1(e)(3) Q&A E2, 301.6330-1(e)(3) Q&A E2.

2. An issue may not be raised at the CDP hearing if the issue was raised and considered at a previous hearing under IRC 6320 or in any other previous administrative or judicial proceeding and the person seeking to raise the issue participated meaningfully in such hearing or proceeding. IRC 6330(c)(4).

3. In seeking Tax Court review of the notice of determination, the taxpayer can generally only request that the court consider an issue that was raised in the taxpayer’s CDP hearing. _Giamelli v. Commissioner_, 129 T.C. 107 (2007); Treas. Reg. §§ 301.6320-1(f)(2) Q&A F3, 301.6330-1(f)(2) Q&A F3. The Tax Court, however, can review whether the IRS complied with all applicable law and administrative procedures without regard to whether the taxpayer raised it at the CDP hearing. _Hoyle v. Commissioner_, 131 T.C. 187 (2008).

4. A taxpayer cannot challenge the amount of court-ordered restitution at a CDP hearing. The district court’s restitution order is final and cannot be challenged or modified during the CDP hearing. Section 6201(a)(4) prohibits collateral attacks on a restitution order in any subsequent legal or administrative proceeding under the Internal Revenue Code of which a CDP hearing is an example. The challenge to the amount of restitution is also prohibited under section 6330(c)(4), because the criminal tax case is considered a prior judicial hearing in which a taxpayer meaningfully participated. Thus, in cases where an assessment is made of the amount ordered as restitution, that amount may not be later challenged in the Tax Court. In addition, section 6213(b)(5) prohibits assessment of restitution to be subject to deficiency procedures. Any deficiency asserted as a result of a subsequent examination is, however, subject to challenge by the taxpayer.


**35.3.23.3** **(07-25-2012)**

### Motion to Change Caption

1. The Tax Court assigns docket numbers with an "L" suffix to regular CDP cases. The court assigns the "S L" suffix to small CDP cases. If a petition seeking review of a notice of determination is not marked with either an "L" or an "S L" and the notice of determination was not attached to the petition, the notice of determination should be attached to the answer. If the filing of the answer does not cause the Tax Court to add the suffix "L" or "S L" to the case docket number, a motion to change the caption should be filed. See Exhibit 35.11.1-221, Motion to Change Caption in Collection Due Process Case.


**35.3.23.4** **(07-25-2012)**

### Motion to Dismiss on the Ground of Mootness

1. A motion to dismiss on the ground of mootness is filed when there is no longer a case or controversy for the Tax Court to adjudicate. Two common scenarios are when the liability has been fully paid or the assessment has been abated.


**35.3.23.4.1** **(07-25-2012)**

#### Liability is Fully Paid

1. If, after the Appeals hearing, the tax, including all interest and penalty accruals, is fully paid and the assessment abated, generally the case should be dismissed as moot. There is no tax liability to collect, the NFTL will be or has been released, the proposed levy will be abandoned, and there is therefore no case or controversy for the Tax Court to adjudicate. The Tax Court’s jurisdiction under IRC 6330(d) is generally limited to reviewing whether the NFTL should remain filed or the proposed levy should proceed, and the Tax Court will dismiss as moot cases in which there is no unpaid tax liability upon which the lien or the proposed levy could be based. _Greene-Thapedi v. Commissioner_, 126 T.C. 1 (2006). The attorney must ensure that the NFTL is released prior to filing this motion. See Exhibit 35.11.1-222, Motion to Dismiss for Mootness in a Collection Due Process Case, for a sample motion. If only some of the tax years at issue are fully paid and the Tax Court retains jurisdiction with respect to one or more tax periods, the court can enter a decision addressing the unpaid years and declaring the paid years as moot.

2. The attorney should ensure that the underlying tax liability, including accruals, has been fully satisfied. The Form 4340 transcript may show a zero tax balance while there is still outstanding tax liability because it does not reflect unassessed interest accruals. The Service is not required to make a separate assessment of interest on an assessed underlying tax liability in order to collect that interest, and the Service usually allows interest to accrue unassessed until paid.

3. If the taxpayer is raising liability and requesting a refund, the CDP case is not the appropriate forum to resolve those issues because the Tax Court does not have refund jurisdiction in the CDP case and can only address the legality or appropriateness of the NFTL or proposed levy. _Greene-Thapedi, id_.

4. If the tax has been fully paid, a motion to dismiss for mootness is inappropriate if the notice of determination rejected interest abatement or spousal relief and the taxpayer would be entitled to a refund if interest abatement or spousal relief is granted. In those cases, the Tax Court has independent overpayment jurisdiction under IRC §§ 6404(h) and 6015(e). The case should proceed with only the interest abatement or spousal relief issues addressed.


**35.3.23.4.2** **(07-25-2012)**

#### Assessment Has Been Abated

1. A motion to dismiss for mootness is also appropriate if after the Appeals hearing the assessment has been abated because it is invalid (e.g., invalid notice of deficiency) or the Service has decided to forgo collection after a bankruptcy discharge. If the assessment has not yet been abated, a stipulated decision would be appropriate in these situations. See the sample Stipulated Decision at Exhibit 35.11.1-214, Notice of Determination Addressing Only Tax Liability or Collection Issues Not Sustained.

2. Not all bankruptcy discharge situations justify a motion to dismiss for mootness or a stipulated decision. If a taxpayer has received a bankruptcy discharge and the taxpayer’s tax liabilities are dischargeable, the taxpayer is no longer personally liable for the taxes and the Service is enjoined from collecting the liability from the taxpayer personally. The Service may collect a discharged liability from prebankruptcy assets if a NFTL was filed before the taxpayer’s bankruptcy. The Service may also collect a discharged liability from pension assets excluded from the bankruptcy estate, even if a NFTL is not on file prepetition. The federal tax lien, however, will only attach to the portion of the pension asset that existed as of the petition date. The lien is not limited to the value of the property as of the petition date. Once a tax lien attaches to property existing at the petition date, it attaches to any appreciation or diminution of that asset until the lien is enforced against that property.


**35.3.23.5** **(07-25-2012)**

### Motion to Dismiss for Lack of Jurisdiction

1. For sample motions to dismiss for lack of jurisdiction, see Exhibits 35.11.1-223 and 224, (no notice of determination for all or some taxes at issue), Exhibit 35.11.1-225 (no CDP notice), and Exhibit 35.11.1-226 (late-filed petition).

2. In order to establish the date on which a CDP lien or levy notice, or a notice of determination, was issued for purposes of a motion to dismiss for lack of jurisdiction, both a copy of the notice (if available) and a document proving mailing should be attached to the motion. Proof of mailing ACS notices generally requires a copy of the IRS certified mailing list, and for notices issued by field collection staff a stamped certified mail receipt ( [Postal Service Form 3800 PDF](http://about.usps.com/forms/ps3800.pdf)) or domestic return receipt (the "green card," Postal Service Form 3811). Certified mail lists for Letters 11 and other CDP levy notices issued by ACS can be located by contacting the appropriate CDP coordinator. The certified mail lists for Letters 3172 are all retained at the Centralized Lien Unit at the Cincinnati Campus. The certified mail lists for notices of determination are located at the Appeals Processing Section units in the Fresno and Memphis Campuses.

3. Relying on _Lunsford v. Commissioner_, 117 T.C. 159 (2001), the Tax Court will deny taxpayers’ motions to dismiss for lack of jurisdiction if the basis for the motion is that the taxpayers were not provided with a procedurally-valid CDP hearing. If a taxpayer wishes to withdraw a CDP petition, however, and have the case dismissed without prejudice, the attorney should file a Notice of No Objection indicating that if the case is dismissed, the Service will take any appropriate collection action as provided by law. Upon dismissal of the case, the attorney should make sure the case is immediately closed and returned to Collection to proceed with collection.


**35.3.23.5.1** **(02-08-2017)**

#### Motion to Dismiss for Lack of Jurisdiction When a Taxpayer Petitions the Tax Court Based on the Assessment of a Restitution Order Pursuant to IRC § 6201(a)(4)

1. The amount of restitution assessed may not be challenged in any proceeding authorized under the Internal Revenue Code. See IRC § 6201(a)(4)(C). Also, the assessment of criminal restitution is not subject to deficiency procedures. See IRC § 6213(b)(5). Therefore, the Tax Court does not have jurisdiction over a case that is filed to challenge the amount or existence of court-ordered restitution. The attorney should file a motion to dismiss such petitions for lack of jurisdiction. Nonetheless, if a taxpayer petitions the Tax Court based on a statutory notice of deficiency issued following an examination for the same tax years for which restitution is ordered or a CDP notice of determination for the same years, such petition is valid and the Tax Court will have jurisdiction over the entire deficiency without regard to the restitution ordered or the CDP determination.


**35.3.23.6** **(07-25-2012)**

### Motion to Dismiss for Failure to State a Claim Upon Which Relief Can be Granted

1. T.C. Rule 40 provides for the filing of a motion to dismiss for failure to state a claim upon which relief can be granted. These motions must be filed within 45 days after the date of service of the petition. If the motion is not filed within this 45-day period, then the attorney should consider a motion for judgment on the pleadings. The Tax Court’s review of these motions is limited to the pleadings and any documents attached thereto. T.C. Rule 333(a) and T.C. Rule 36(a). Examples of when a motion to dismiss for failure to state a claim should be filed include taxpayer makes only frivolous or groundless arguments, and taxpayer challenges only the existence or amount of the underlying liability and admits in the petition that he received the statutory notice of deficiency for the liability. When the taxpayer states a nonfrivolous claim that can be properly raised in the CDP case (such as he was denied the right to a record a face-to-face conference, or the hearing was not otherwise conducted properly), a motion for summary judgment should be filed instead of a motion to dismiss for failure to state a claim, even if frivolous arguments are also made. Responses to frivolous arguments can be found on the IRS website, [www.irs.gov](http://www.irs.gov/taxpros/article/0,,id=159853,00.html).

2. While Tax Court review of these motions is limited to the pleadings, the Tax Court sometimes requests Form 4340 transcripts be filed with motions to dismiss for failure to state a claim for background information. In view of the Tax Court’s requests for these transcripts, they should be submitted with each dispositive motion.


**35.3.23.7** **(03-26-2015)**

### Motion to Remand

1. When Appeals has abused its discretion or the taxpayer was not given a proper hearing, the Tax Court will remand the case to Appeals to hold a new hearing if a new hearing is necessary or will be productive. If the trial attorney determines that the Appeals officer’s exercise of discretion in conducting the hearing or making a determination on a nonliability issue can not be defended, and reconsideration of the case by Appeals is required because the error is not harmless, the trial attorney should file a Motion for Remand to require Appeals to hold a supplemental hearing (if necessary) and issue a Supplemental Notice of Determination (Letter 3978).

2. The Tax Court reviews underlying liability issues de novo and reviews nonliability issues for abuse of discretion. Review for abuse of discretion requires an adequate administrative record including clear findings by the Appeals officer on relevant issues so the court can determine whether the record supports the Appeals officer’s findings. See generally _Keller v. Commissioner_, 568 F.3d 710, 718 (9th Cir. 2009); _Murphy v. Commissioner_, 469 F.3d 27 (1st Cir. 2006), _aff’g_ 125 T.C. 301 (2005); _Robinette v. Commissioner_, 439 F.3d 455 (8th Cir. 2006), _rev’g_ 123 T.C. 85 (2004); Treas. Reg. §§ 301.6320-1(f)(2) Q&A F3 and F4, 301.6330-1(f)(2) Q&A F3 and F4. The court should not be making findings but instead should be reviewing the Appeals officer’s findings for abuse of discretion and should give deference to those findings.

3. Accordingly, instead of trying to defend an erroneous or insufficient notice of determination at trial, the trial attorney should consider asking the court to remand the case to Appeals for a supplemental determination if:



   - The Appeals officer failed to address a relevant issue.

   - The Appeals officer failed to make necessary findings of fact.

   - The Appeals officer failed to perform an analysis that is necessary in making the determination.

   - The administrative record contains no indication of the documents or evidence the Appeals officer considered in making the determination or the reasons for the determination.

   - The Appeals officer’s conduct of the hearing deprived the taxpayer of a procedural right granted by statute or regulation, such as the right to an impartial Appeals officer under IRC §§ 6320(b)(3) or 6330(b)(3).

   - The Appeals officer did not give the petitioner an adequate opportunity to present evidence or arguments in support of relevant issues raised during the CDP hearing process.


4. Specific examples of cases in which remand would be appropriate are:



   - Taxpayer denied receiving a notice of deficiency but the Appeals officer failed to address this issue.

   - Although taxpayer has a colorable argument for abatement of interest based on evidence that could show unreasonable delays by the IRS, the Appeals officer summarily rejected abatement without any explanation.

   - The Appeals officer rejected the taxpayer’s offer-in-compromise without consideration of relevant financial information that was provided by the taxpayer.

   - The Appeals officer’s findings are confusing or contradictory ( _e.g._, a low installment agreement amount is rejected as not adequate, while a higher amount is rejected because the taxpayer cannot afford it).

   - The Appeals officer closed the hearing and issued the notice of determination prior to the expiration of the agreed upon deadline for the taxpayer to submit financial documentation.


5. Inadequate findings or discussion in the notice of determination do not always require remand. There might be sufficient explanation in the Appeals officer’s case activity notes or letters to the taxpayer, or the Appeals officer may be able to clarify his findings in a declaration or through testimony. (Note, however, that Appeals officer testimony should be required only rarely.) See also CCDM 35.3.23.7.1(4) for cases involving harmless error.

6. If Appeals erroneously failed to consider an underlying liability issue, remand is not necessary to develop an administrative record because the issue will be reviewed de novo by the court. On the other hand, if the taxpayer is raising nonfrivolous issues, the case may be able to be resolved on remand without the necessity for trial. Unless the taxpayer’s arguments are frivolous or the liability issue can be easily resolved before the court, the trial attorney should consider remand for consideration of liability when it was not properly considered by Appeals.

7. Remand may also be appropriate in limited situations when there has been no abuse of discretion by Appeals, but there has been a change in circumstances that is material and affects the core issues in the case, which if known at the time of the CDP hearing would likely have altered Appeals’ determination. See Churchill v. Commissioner, T.C. Memo 2011-187. Remand based on changed circumstances should generally be limited to those cases in which the taxpayer fully cooperated during the CDP hearing and submitted all requested and available information within the taxpayer’s control (including filing all tax returns and submitting all financial information necessary for consideration of collection alternatives). If a taxpayer fails to provide available information requested by Appeals during the CDP hearing or fails to raise an issue during the CDP hearing, the taxpayer should be precluded from raising the issue(s) for the first time at trial. See Treas. Reg. §§ 301.6320-1(f)(2) Q&AF3 and 301.6330-1(f)(2) Q&A F3.

8. Informal consideration or reconsideration of an issue by Appeals while the case is pending in the Tax Court can lead to confusion as to whether and how the Tax Court should review the determination made as a result of the informal consideration or reconsideration, and should be avoided.

9. When the court remands a case to Appeals, the further hearing is a supplement to the taxpayer’s original IRC 6330 hearing. It is not a new hearing.


**35.3.23.7.1** **(03-26-2015)**

#### Remand Not Appropriate

1. In the absence of error by Appeals, the trial attorney should not agree to a remand to Appeals for the consideration or reconsideration of any issue, including a collection alternative, unless remand is appropriate for changed circumstances as specified in CCDM 35.3.23.7(7). For example, remand is not appropriate when a taxpayer wishes to submit a collection alternative during the Tax Court proceeding after having failed to take advantage of the opportunity to submit an alternative during the CDP hearing. This includes cases in which the taxpayer was not eligible for a collection alternative ( _e.g._, by filing required returns) during the CDP hearing after being given an opportunity to become eligible.

2. If remand is not appropriate, the trial attorney is not required to agree to have an issue considered by Collection, Examination, or other Service function to facilitate settlement of a case. However, there may be situations in which consideration by a Service function other than Appeals is the best practice for the fair treatment of taxpayers or to avoid undesirable legal precedent. For example,



   - There is a significant adverse change in taxpayer’s circumstances since the CDP hearing.

   - Taxpayer was unable to respond to Appeals during the CDP hearing due to illness or travel.

   - Taxpayer offers credible evidence affecting the amount of liability but Appeals did not consider liability because a liability challenge was precluded or if Appeals did consider liability the credible evidence was not discovered, through no fault of the taxpayer’s, until after the notice of determination was issued.


3. The trial attorney should notify the Appeals officer who made the determination that the issue is being considered by Collection, Examination, or other Service function. For cases involving collection alternatives being referred to Collection, the trial attorney is responsible for informing Collection of any deadlines imposed by the court on the Service’s consideration of the collection alternative, and for seeking any continuances necessary for adequate investigation and review. The attorney will not ask Collection to consider collection alternatives that are on their face clearly unprocessable or frivolous. The attorney will also not ask Collection to consider collection alternatives identical to those that have been rejected by Appeals, absent a subsequent change in the taxpayer’s circumstances.

4. The court should uphold a determination in cases in which the Appeals officer erred if the error does not affect the outcome of the case. As a consequence, any error should be evaluated to determine whether it is harmless. The harmless error rule is often applied when the taxpayer is only making frivolous or groundless arguments. For example, if the taxpayer was not permitted to record his conference under section 7521(a)(1), but relies on frivolous or groundless arguments, the Tax Court will not remand the case.

5. Some errors by Appeals on nonliability issues may not require reconsideration even if the error was not harmless, because the issue involves the application of law to uncontested facts. These issues may include whether the unpaid tax was discharged in bankruptcy, whether the statute of limitations has expired, or whether a notice of deficiency was properly issued. If an issue that was wrongly decided by Appeals does not require further fact-finding or a determination by Appeals, in appropriate cases the issue can be conceded.


**35.3.23.7.2** **(03-26-2015)**

#### Remand Procedure

1. A Motion for Remand should be filed as early as possible in the proceeding after the petition is answered. If the case is calendared, the Motion for Remand should be filed with a separate motion for continuance. If the case is not calendared, only a Motion for Remand should be filed. The Motion for Remand should explain the error in the determination or hearing that is to be remedied on remand. A sample motion is in Exhibit 35.11.1-213, Motion to Remand in a Collection Due Process Case.

2. Prior to filing a Motion for Remand, the trial attorney should consult with Appeals and advise the Appeals officer and his or her manager of the reasons for remand.

3. After receiving the court’s remand order, the trial attorney should promptly (generally, within three business days) send a remand memorandum and the case file directly to the Appeals Team Manager responsible for the supplemental hearing (ordinarily the manager responsible for the original hearing, but if the court ordered the supplemental hearing to be conducted by a different office, the manager of the office specified by the court). If the trial attorney does not have time to address all issues in the remand memorandum, the trial attorney should send a supplemental memorandum after sending the initial memorandum.

4. No later than three weeks before the deadline the court set for Appeals to hold the supplemental hearing, the trial attorney should contact Appeals to confirm that the hearing has been, or will be, timely held. If the hearing will not be timely held, the trial attorney should file with the court a motion for extension of time explaining the need for the extension. The motion for extension of time must be filed before the deadline set by the court for Appeals to hold the supplemental hearing.

5. After the case is remanded, the Appeals officer should not issue a standard notice of determination using Letter 3193. Instead, a Letter 3978, Supplemental Notice of Determination Concerning Collection Action(s) under IRC §§ 6320 and/or 6330, should be issued to the taxpayer. This supplemental notice should not have the standard language concerning the right to file a petition with the Tax Court to appeal the determination, as the case is already docketed with the court.

6. Following the issuance of the supplemental notice, a status report should be filed with the court attaching the supplemental determination.

7. If issuance of the supplemental notice makes it unnecessary for the court to review the Commissioner’s position taken before the determination was supplemented, the court will review only the supplemental notice and not prior determinations.


**35.3.23.7.3** **(07-25-2012)**

#### Application of Ex Parte Rules to Remanded CDP Cases

1. Care should be taken in remanded cases to ensure that the Appeals officer maintains the role of an independent officer. Therefore, Rev. Proc. 2012-18, 2012-10 I.R.B. 455 (providing rules limiting ex parte communications in nondocketed cases), should be followed in remanded cases.



1. The attorney working the docketed case should prepare a written memorandum addressed to the Office of Appeals explaining the reasons why the court remanded the case to Appeals, any special requirements in the order ( _e.g_., whether and to what extent a new conference should be held, or whether the case must be assigned to a different Appeals officer), and what issues the court has ordered Appeals to address on remand in its supplemental notice of determination. A copy of the memorandum must be provided to the taxpayer or the taxpayer’s representative. See sample memorandum in Exhibit 35.11.1-227, Remand Memorandum to Appeals in a Collection Due Process Case.

2. The remand memorandum is not a prohibited ex parte communication because it is furnished to the taxpayer or the taxpayer’s representative. A memorandum of this nature is also not a prohibited ex parte communication insofar as it only addresses matters that are ministerial, administrative, or procedural in nature because those types of communications are not prohibited ex parte communications. Rev. Proc. 2012-18, sections 2.03(2) and 2.03(10)(c)(i). The memorandum may also provide an explanation of the applicable law, but only if necessary for the Appeals officer to properly understand the Tax Court’s order or to be able to properly conduct the hearing on remand. If an explanation of the applicable law is included in the memorandum, it should be carefully tailored and should not opine on how the ultimate issues to be addressed by Appeals should be resolved.

3. The memorandum should not discuss the credibility of the taxpayer or the accuracy of the facts presented by the taxpayer. For example, the memorandum should not state that Counsel believes that the taxpayer did not testify truthfully at trial. Although the memorandum is not subject to the prohibitions on ex parte communications, the memorandum should address only procedural and legal matters and should not suggest any particular outcomes or attempt to influence the determinations of Appeals.

4. A request by an Appeals officer for legal advice in connection with the remanded CDP case may be handled by the attorney who is handling the docketed Tax Court case. Any legal advice should be carefully tailored to answer the legal questions posed by Appeals and should not opine on the ultimate issues to be addressed by Appeals in the Supplemental Notice of Determination. Requests for advice that raise novel collection issues should be coordinated with the Office of the Associate Chief Counsel (P&A), Branch 3 or 4. Also, neither the taxpayer nor his representative has a right to participate in any discussions between Appeals and Counsel with respect to the advice. In the course of such discussions, Counsel should also not address the credibility of the taxpayer or accuracy of the facts presented by the taxpayer.

5. The attorney who is handling the docketed case should review the supplemental notice of determination before it is issued to the taxpayer. This review is for the limited purpose of ensuring compliance with the Tax Court’s order. Any questions concerning these issues should be addressed to the Office of Associate Chief Counsel (P&A), Branch 3 or 4.


**35.3.23.8** **(07-25-2012)**

### Motion for Summary Judgment

1. A motion for summary judgment may be the most effective was to resolve a CDP case, when there is no genuine issue of material fact.

2. When appropriate, the trial attorney should consider filing a motion to permit levy under IRC 6330(e)(2) in connection with a motion for summary judgment. As discussed in CCDM 35.3.23.9, an IRC 6330(e)(2) motion should generally be filed in all cases involving taxpayers making frivolous or groundless arguments, or merely seeking to delay collection, and in all cases in which an IRC 6673(a)(1) penalty is sought. A summary judgment motion and an IRC 6330(e)(2) motion must be filed as separate motions and not joined together. T.C. Rule 54.

3. Also when appropriate, the trial attorney should consider requesting the court to impose an IRC 6673(a)(1) penalty in connection with a motion for summary judgment. The penalty can be requested as part of the summary judgment motion. IRC 6673(a)(1) authorizes the Tax Court to impose a penalty, not in excess of $25,000, on a taxpayer if the court finds that the taxpayer has instituted or maintained a CDP proceeding primarily for delay, or that the taxpayer’s position in the proceeding is frivolous or groundless. See CCDM 35.10.2.1, Penalties Claimed Under Section 6673. Ordinarily, this penalty is imposed on taxpayers who take frivolous positions, and should be requested when appropriate in motions or at trial.



1. When requesting the penalty, the trial attorney should advise the court about all prior communications with the taxpayer in which the Service warned the taxpayer about the possibility of the imposition of the IRC 6673 penalty if the taxpayer continued to pursue frivolous or groundless arguments. For example, upon assignment of a CDP case, Appeals issues a form letter containing standard warning language (Letter 3846) to taxpayers raising only frivolous claims. The Tax Court has, in some cases, declined to impose the IRC 6673 penalty when the taxpayer was not given a prior warning that the penalty may be imposed.

2. If an attorney wishes to ask for an IRC 6673(a)(1) penalty against a taxpayer, who instituted the proceeding primarily for delay but who is not making frivolous arguments, the attorney should be prepared to put forth substantial evidence to support the penalty.


**35.3.23.8.1** **(02-04-2014)**

#### General Grounds for Summary Judgment

1. If the taxpayer is only raising frivolous or groundless arguments, and there is no need to go beyond the pleadings, a motion to dismiss for failure to state a claim upon which relief can be granted should be filed within 45 days after service of the petition. If there is a need to go outside the pleadings, a motion for summary judgment should generally be filed.

2. A summary judgment motion should also be filed when the only issues raised by the taxpayer are precluded by IRC 6330(c)(2)(B) (preclusion of liability) or IRC 6330(c)(4) (preclusion due to prior proceedings), and there is no dispute as to material fact with respect to the facts supporting the preclusion.

3. A full or partial summary judgment motion should also be considered if the petitioner raises an issue, including liability, that petitioner cannot raise before the court because it was not raised in the administrative hearing.


**35.3.23.8.2** **(02-04-2014)**

#### Liability Issues Under IRC 6330(c)(2)(B)

1. Under IRC 6330(c)(2)(B), a taxpayer may challenge the existence or amount of the underlying tax liability in a CDP hearing under IRC §§ 6320 and 6330 if the taxpayer did not receive a statutory notice of deficiency for the tax liability or did not otherwise have an opportunity to dispute the tax liability. The term "underlying tax liability" means the total amount of tax (including interest and penalties) assessed for a particular tax period, including tax assessed under the deficiency procedures, tax reported on a tax return, or a combination of both. An opportunity to dispute a liability includes a prior opportunity for a conference with Appeals offered either before or after assessment of the liability. Treas. Reg. §§ 301.6320-1(e)(3) Q&A E2, 301.6330-1(e)(3) Q&A E2.

2. If the Service filed a proof of claim regarding an unpaid tax liability in a bankruptcy proceeding, the debtor could have filed an objection to the proof of claim. 11 U.S.C. § 502. If the bankruptcy court had jurisdiction to determine the liability, the taxpayer is precluded from challenging the underlying liability in a subsequent CDP hearing (without regard to whether the debtor or Trustee actually filed an objection to the proof of claim). The facts of a particular case should be examined to determine if the taxpayer had standing to object to the proof of claim and if the taxpayer had an actual opportunity to raise liability in the bankruptcy case. The IRC 6330(c)(2)(B) bar should not be asserted when the taxpayer is disputing a tax liability for which the Service did not file a proof of claim in a no-asset Chapter 7 case.

3. In cases in which a taxpayer is barred from challenging the existence or amount of the underlying liability pursuant to IRC 6330(c)(2)(B), but the taxpayer is raising a legitimate liability issue, processing of returns and audit reconsiderations should not be delayed just because a CDP Tax Court petition has been filed. The goal should always be to ensure that the correct amount of tax liability is being fairly collected even if consideration of liability is precluded under IRC 6330(c)(2)(B). On the other hand, the trial attorney should vigorously rely on IRC 6330(c)(2)(B) and seek summary judgment when the taxpayer is raising only frivolous or groundless issues or was uncooperative during the CDP hearing.

4. In cases in which a taxpayer is raising only frivolous or groundless challenges to the underlying liability, and it is questionable whether actual or constructive receipt of the deficiency notice can be proven, the trial attorney should consider not raising IRC 6330(c)(2)(B) because defeating the challenge on the merits may be easier than proving receipt.

5. A sample summary judgment motion covering cases in which IRC 6330(c)(2)(B) preclusion is at issue is in Exhibit 35.11.1-228, Motion for Summary Judgment in a CDP Case, Section 6330(c)(2)(B).


**35.3.23.8.3** **(07-25-2012)**

#### Abuse of Discretion Issues

1. Many cases involving nonfrivolous issues can also be decided through summary judgment when there are no genuine issues of material fact. This is especially the case when the only issues in the case are reviewable for abuse of discretion. In these cases, the Tax Court should resolve the case based on the administrative record and should be reviewing the Appeals officer’s findings for abuse of discretion rather than finding its own facts. All non-frivolous factual and legal issues raised by the taxpayer must specifically be addressed and resolved in the motion.



1. For example, if the taxpayer disputes the dollar amount that Appeals concluded must be paid under an offer in compromise, the motion must explain in detail the evidence Appeals relied upon and why the taxpayer’s proposed amount was rationally rejected. It is not sufficient to summarily state that the Appeals officer addressed all issues raised by the taxpayer and did not abuse his discretion. If the taxpayer denies receipt of a notice of deficiency, the motion must explain how the record evidence conclusively establishes receipt. Furthermore, all issues and problems raised by the transcripts or other record evidence must be addressed and explained (e.g., was a notice of deficiency properly issued? Did the Appeals officer make reasonable attempts to contact the taxpayer? Were payments properly applied?).

2. The court is unlikely to grant summary judgment in factually complex cases in which there exists any doubt or question as to the correctness of the Notice of Determination or whether the taxpayer was fairly dealt with by the Service. The court is also unlikely to grant summary judgment when factual issues are raised that cannot be decided as a matter of law ( _e.g._, taxpayer denies receipt of the notice of deficiency and the record evidence is insufficient to prove receipt).


2. In abuse of discretion cases, the fact that petitioner plans to introduce evidence at trial that was not presented to the Appeals officer should not preclude summary judgment because the court must confine its review to the administrative record. _Keller v. Commissioner_, 568 F.3d 710, 718 (9th Cir. 2009); _Murphy v. Commissioner_, 469 F.3d 27 (1st Cir. 2006); _Robinette v. Commissioner_, 439 F.3d 455 (8th Cir. 2006). The Tax Court does not follow _Keller_, _Murphy_, and _Robinette_, so in cases not appealable to the First, Eighth, or Ninth Circuit Court of Appeals, the Tax Court’s view is that its abuse of discretion review is not limited to the administrative record. _Robinette v. Commissioner_, 123 T.C. 85 (2004). The court, nonetheless, will exclude evidence not submitted to the Appeals officer because it is not relevant to whether Appeals abused its discretion. _See, e.g., Murphy v. Commissioner_, 125 T.C. 301 (2005). A sample motion for summary judgment, involving only claims subject to abuse of discretion review, is in Exhibit 35.11.1-229, Motion for Summary Judgment in a CDP Case, Abuse of Discretion Issues.

3. The court may hear evidence not in the administrative record when the taxpayer raises an issue as to how the administrative hearing was conducted. For example, the Tax Court may resolve issues of material fact with respect to whether the Appeals officer was impartial, refused to accept the submission of evidence, failed to consider issues raised by the taxpayer, or properly communicated to the taxpayer deadlines for the submission of evidence. These issues are generally treated as involving exceptions to the record rule. See generally _Robinette v. Commissioner_, 439 F.3d 455 (8th Cir. 2006); _Murphy v. Commissioner_, 469 F.3d 27, 31 (1st Cir. 2006). As a result, a summary judgment motion will not be successful if the taxpayer disputes facts concerning the conduct of the CDP hearing, unless the taxpayer offers no support for the alleged factual dispute or respondent can demonstrate that the taxpayer’s allegations are irrelevant or immaterial.


**35.3.23.8.4** **(07-25-2012)**

#### Declaration

1. A declaration from the Appeals officer making the determination should be filed with the summary judgment motion. The declaration should authenticate and attach the documents that support the motion for summary judgment, _i.e._, all documents which establish that no material facts are in dispute and the Commissioner is entitled to judgment as a matter of law. The entire administrative record does not need to be submitted to the court with a summary judgment motion and declaration; however, _all_ documents relied upon by the Appeals officer and relevant to the issues to be resolved pursuant to the motion should be included. See Exhibit 35.11.1-230, Declaration in Support of Motion for Summary Judgment in a CDP Case, for a sample declaration.

2. The documents that support a motion for summary judgment in a CDP case will vary depending upon the facts and issues in each case. IRC 6330(c)(3) requires that the notice of determination address the verification requirement, all issues raised by the taxpayer, and whether the collection action balances the need for efficient collection with the taxpayer’s concern that the collection action be no more intrusive than necessary. Examples of documents relevant to these issues that should generally be attached to the declaration of the Appeals officer in support of a motion for summary judgment are:



   - The CDP lien or levy notice. Copies of levy notices sent by the ACS are not retained by the IRS and so they will generally not be in the administrative record unless the Appeals officer can obtain a copy from the taxpayer. If Appeals cannot obtain a copy of the notice, the transcript relied upon to confirm the issuance of the notice should be attached.

   - The CDP hearing request.

   - The transcript of the taxpayer’s account that was reviewed by the Appeals officer ( _e.g._, TXMOD-A, Form 4340).

   - The statutory notice of deficiency and any supporting documents the Appeals officer relied upon to establish the notice of deficiency was sent to the taxpayer’s last known address, or was received by the taxpayer.

   - Correspondence between the taxpayer and the Appeals officer. This includes e-mail correspondence. Attorneys should secure copies of e-mail correspondence from Appeals if these are not already printed out and placed in the CDP file.

   - Copies of the taxpayer’s bankruptcy petition and schedules and order of discharge (when the impact of the bankruptcy on the tax due is raised as an issue).

   - A Form 656, Offer in Compromise, submitted by the taxpayer along with the taxpayer’s supporting financial documents.

   - Form 1040, Individual Income Tax Return, for the tax years at issue (if the taxpayer disputes the liability).

   - The history notes of the Appeals officer included in the Appeals case activity record.

   - The Appeals Transmittal and Case Memo, and the Notice of Determination with attachments.


3. A certified copy of an updated Form 4340 transcript should also be submitted with all summary judgment motions. Even though this transcript is prepared after the issuance of the notice of determination, submission of the Form 4340 is not a violation of the record rule because it generally contains the same information originally reviewed by the Appeals or settlement officer in making the CDP determination. Except as it may bear on the issue of mootness, the court should not consider transactions reflected on the Form 4340 that occurred after the CDP hearing because these transactions are not part of the administrative record subject to abuse of discretion review. Because the Form 4340 is self-authenticating, it does not need to be attached to the declaration. The Form 4340 should be reviewed thoroughly, and any issues raised by entries on the Form 4340, or inconsistencies with other documents, should be explained in the motion.

4. Among the documents that the Appeals officer may rely upon are the printouts from Integrated Collection System or ACS screens; documents pertaining to the evaluation of collection alternatives, such as financial statements; and documents that establish that an issue raised in the CDP proceeding was previously raised in an administrative or judicial proceeding in which the taxpayer participated meaningfully, for purposes of IRC 6330(c)(4).

5. Additionally, if any face-to-face or telephone conference between the Appeals officer and the taxpayer was recorded, a copy of the tape or a transcript of the recording, authenticated by the Appeals officer, should be submitted as part of the administrative record. If the taxpayer submits a transcript of the recorded conference, the Appeals officer should authenticate the taxpayer’s transcript only after comparing it to the tape recording made by the Appeals officer.

6. The declaration should set forth the Appeals officer’s job position, that the Appeals officer was assigned responsibility to handle the taxpayer’s hearing request, and that, pursuant to this assignment, the Appeals officer made the determination required under IRC 6330(c)(3). If any of the materials require interpretation ( _e.g._, transaction codes) or authentication, the declaration should include appropriate explanation.


**35.3.23.9** **(07-25-2012)**

### IRC 6330(e)(2) Motions (Motions to Permit Levy)

1. Unless one of the exceptions in IRC 6330(f) apply, or unless collection is in jeopardy, the levy action that is the subject of the CDP hearing is suspended while a CDP hearing and any subsequent court review are pending. IRC 6330(e)(1). Collection actions other than levy ( _e.g_., refund offsets, filing notices of federal tax lien) are not prohibited.

2. In CDP levy cases, the trial attorney should file a motion to permit levy pursuant to IRC 6330(e)(2), generally in conjunction with dispositive motions such as motions for summary judgment or to dismiss for failure to state a claim. See Exhibit 35.11.1-231, Motion to Permit Levy in a Collection Due Process Case. In general, a motion to permit levy should be considered in all CDP cases involving a taxpayer who raises solely frivolous or groundless arguments. Suspension of the Service’s levy authority in such cases serves no legitimate purpose. Even if the motion is not granted until the court enters its decision, it will have served a purpose because the Service will be able to levy immediately without having to wait for the expiration of the period for appeal and for any appellate litigation to conclude.

3. IRC 6330(e)(2) contains two criteria for obtaining relief from the suspension of levy. First, the underlying tax liability must not be at issue. Second, there must be a showing of "good cause."


**35.3.23.9.1** **(07-25-2012)**

#### Underlying Tax Liability Not at Issue

1. The underlying tax liability is not "at issue" merely because the taxpayer challenges it. Liability is not at issue, for example, if a taxpayer challenges underlying liability in the petition, but the court is precluded from considering that liability, pursuant to IRC 6330(c)(2)(B). Liability is also not at issue if the petition makes only frivolous arguments or general unsubstantiated allegations. Unless the challenge to liability is both allowed under IRC 6330(c)(2)(B) and bona fide, a motion to permit levy may be appropriate.

2. If the notice of determination contains multiple tax years and periods, but a taxpayer disputes only the tax liabilities (or interest or additions) for some of the periods, an IRC 6330(e)(2) motion may be brought with respect to the undisputed tax liabilities.


**35.3.23.9.2** **(07-25-2012)**

#### Good Cause

1. The primary focus of an IRC 6330(e)(2) motion should be the required showing of "good cause" not to suspend the levy during the pendency of the judicial review period. A showing of good cause may be made in any case in which a taxpayer is using the CDP provisions in a manner inconsistent with or inappropriate to their purpose. The purpose of the CDP statutes, IRC §§ 6320 and 6330, is to provide taxpayers with a forum to raise relevant issues with respect to a proposed levy or NFTL. IRC § 6330(c)(2)(A); H.R. Conf. Rep. No. 105-599, 105 Cong., 2d Sess., 263-267 (1998). An IRC 6330(e)(2) motion should be considered in all CDP levy cases which are not brought for this purpose, but are used solely as a forum for frivolous arguments or otherwise to delay collection action. Generally, good cause will be proven as part of the summary judgment or other dispositive motion filed with the motion to permit levy.

2. While good cause to permit levy during appeal will exist primarily in cases when a taxpayer raises solely frivolous or groundless issues, there may also be good cause for relief in other types of cases. For example, an IRC 6330(e)(2) motion may be appropriate in some cases involving the pyramiding of tax liabilities.


**35.3.23.9.3** **(07-25-2012)**

#### Procedures for Filing IRC 6330(e)(2) Motion

1. IRC 6330(e)(2) motions filed with the Tax Court should be captioned as "Respondent’s Motion to Permit Levy." The opening paragraph should state that respondent moves, pursuant to Tax Court Rule 50(a) and IRC 6330(e)(2), that the court remove the suspension of the levy under IRC 6330(e)(1) because the underlying liability is not at issue and respondent has shown good cause for the removal of the suspension of the levy. The body of the motion should set forth the background of the case and establish that the two criteria for relief from the stay have been met. The motion should conclude by requesting expedited handling by the court to minimize further unnecessary collection delays. See Exhibit 35.11.1-231, Motion to Permit Levy in a Collection Due Process Case.

2. The IRC 6330(e)(2) motion may be filed at any point at which the court retains jurisdiction over the case. Of course, the motion and the accompanying dispositive motion should be filed as early in the case as possible to minimize delays in resuming collection. When filed with a summary judgment or other dispositive motion, two separate motions must be filed, in accordance with T.C. Rule 54.

3. The trial attorney should, as a general rule, consider filing an IRC 6330(e)(2) motion in all cases involving taxpayers raising solely frivolous or groundless arguments in which we are filing summary judgment motions and/or seeking imposition of the IRC 6673(a)(1) penalty. While this motion may be made up to the time a final decision is entered, the attorney should file these motions as soon as possible in all applicable cases. In the absence of an order permitting levy, a litigious taxpayer may delay collection for a significant period by appealing the Tax Court’s decision to the court of appeals.

4. Generally, the Tax Division of the Department of Justice will not file an IRC 6330(e)(2) motion with a court of appeals because it is the trial attorney’s responsibility to file the motion in the first instance with the Tax Court. In some limited circumstances, however, it may be appropriate to file an IRC 6330(e)(2) motion for the first time in the court of appeals when there are new circumstances justifying seeking relief. For example, we may discover after a case has been appealed to a court of appeals that a taxpayer is dissipating assets or placing collection in jeopardy. Please contact the P&A attorney assigned to the case if there are grounds for requesting filing of an IRC 6330(e)(2) motion with a court of appeals.

5. Finally, since the purpose of an IRC 6330(e)(2) motion is to permit immediate levy, alert the Service before filing the motion, and immediately after the motion is granted, so that it will be prepared to proceed promptly with a levy. For cases which originate from the field, contact the group manager of the revenue officer who referred the case to Appeals. For cases that originate from ACS, contact the CDP coordinator for the state of taxpayer’s residence.


**35.3.23.10** **(02-08-2017)**

### Petitions From Letters Denying Hearing Requests Under IRC 6330(g)

1. IRC 6330(g) permits the Service to disregard any portion of a CDP hearing request that contains frivolous positions or reflects a desire to delay or impede the administration of Federal tax laws. Under section 6330(g), the Service may deny a CDP hearing if the taxpayer raises no legitimate issues.

2. The Tax Court and the Court of Appeals for the District of Columbia have held that the Tax Court has jurisdiction to review a petition filed from the denial of a hearing under IRC 6330(g). Thornberry v. Commissioner, 136 T.C. 356 (2011); Ryskamp v. Commissioner, 797 F.3d 1142 (D.C. Cir. 2015). Although counsel disagrees with these decisions, counsel will no longer contest the Tax Court’s jurisdiction to determine whether a hearing was properly denied under section 6330(g).

3. If the taxpayer petitions from the denial of a hearing under section 6330(g), and Counsel determines that the taxpayer has raised at least one legitimate issue and the CDP hearing request should not have been denied in its entirety, Counsel should file a motion to remand the case to Appeals to hold a hearing addressing the legitimate issues and to issue a Notice of Determination that should be submitted to the court.

4. If a CDP hearing was properly denied under section 6330(g), then Counsel should treat the disregard letter as the Notice of Determination and either (a) file a motion to dismiss for failure to state a claim, or (b) answer the case and then file a motion for summary judgment. Such motions should explain why the taxpayer’s arguments were frivolous so as to justify the denial of the hearing.

5. If the taxpayer is raising only frivolous and non-specific arguments, Counsel should also consider filing a motion to permit levy so that the Service can immediately levy after the Tax Court’s final decision. See IRC § 6330(e)(2) and CCDM 35.3.23.9.

6. Coordinate motions filed in cases described in this section with the Office of the Associate Chief Counsel (P&A), Branch 3 or 4.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-003-023#addtoany "Show all")

A2A