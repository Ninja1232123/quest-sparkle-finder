---
url: "https://www.irs.gov/irm/part32/irm_32-002-005"
title: "32.2.5 Coordination and Clearance | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part32/irm_32-002-005#main-content)

- 32.2.5 [Coordination and Clearance](https://www.irs.gov/irm/part32/irm_32-002-005#idm140236052117392)
  - 32.2.5.1 [Overview of Coordination Process](https://www.irs.gov/irm/part32/irm_32-002-005#idm140236052108704)
  - 32.2.5.2 [Coordination Within the National Office](https://www.irs.gov/irm/part32/irm_32-002-005#idm140236052097072)
  - 32.2.5.3 [Coordination with Division Counsel and with the Service](https://www.irs.gov/irm/part32/irm_32-002-005#idm140236052067248)
  - 32.2.5.4 [Coordination with Other Agencies or Organizations](https://www.irs.gov/irm/part32/irm_32-002-005#idm140236052049936)

    - 32.2.5.4.1 [Coordination Required on Social Security Matters](https://www.irs.gov/irm/part32/irm_32-002-005#idm140236052041296)
    - 32.2.5.4.2 [Coordination Required on Railroad Retirement Matters](https://www.irs.gov/irm/part32/irm_32-002-005#idm140236052035392)

# Part 32. Published Guidance and Other Guidance to Taxpayers

# Chapter 2. Chief Counsel Publication Handbook

# Section 5. Coordination and Clearance

* * *

## 32.2.5 Coordination and Clearance

#### Manual Transmittal

January 25, 2013

#### Purpose

(1) This transmits revised CCDM 32.2.5, Chief Counsel Publication Handbook; Coordination and Clearance.

#### Material Changes

(1) CCDM 32.2.5.1(6) was added to provide procedures on coordinating publications that contain an IRS toll-free number.

(2) CCDM references were hyperlinked.

#### Effect on Other Documents

CCDM 32.2.5 dated August 11, 2004, and Chief Counsel Notice CC-2004-004 are superseded.

#### Audience

Chief Counsel

#### Effective Date

(01-25-2013)

Deborah A. Butler

Associate Chief Counsel

(Procedure and Administration)

**32.2.5.1** **(01-25-2013)**

### Overview of Coordination Process

1. In order to achieve accuracy, uniformity, and consistency in documents issued by Chief Counsel, advice must often be solicited from other offices on issues crossing into their jurisdictional areas. Early recognition of the need to obtain advice from other offices is essential in order to permit a timely referral and allow sufficient time for a thorough and useful response.

2. Coordination should be done with any office that has expertise in the subject matter involved in the proposed publication or whose operational area may be affected by the position to be taken.

3. The drafting attorney may request coordination either before a draft of the proposed publication item is completed or the drafting attorney can send a draft to the coordinating office for that office’s input on the contents of the item. Prior to sending a draft to a coordinating office, the drafting attorney should have the branch reviewer complete the review of the draft or otherwise concur in the coordination.

4. Early coordination with the assigned Treasury attorney is strongly recommended, especially where the issues involved in the proposed publication item are complex or significant.

5. The drafting attorney should notify and provide an opportunity for early involvement in a proposed publication item to all Associate and Division Counsel offices and the Special Counsel to the National Taxpayer Advocate. _See_ CCDM 32.2.5.2(2) and 32.2.5.3(2).

6. If any proposed publication item is intended to communicate with taxpayers and contains an IRS toll-free number, the drafting attorney must coordinate the publication with the Office of Taxpayer Correspondence (OTC). The drafting attorney should either email the publication to the OTC or submit a request to the OTC website at http://win.web.irs.gov/TPC/TPC.htm. The OTC staff will review the publication item and promptly notify the drafting attorney if any problems or issues are identified.



### Note:



This requirement does not extend to work products that relate to a single or small group of taxpayers, such as TAMs or PLRs. In addition, only the office having primary responsibility for preparing a document is responsible for coordination with the OTC. Accordingly, Counsel attorneys that are reviewing documents created by the Service, such as IRM updates or IRS publications, are not responsible for forwarding these documents to the OTC.


**32.2.5.2** **(08-11-2004)**

### Coordination Within the National Office

1. When more than one branch or Associate office has concurrent jurisdiction over the subject matter of a proposed publication, coordination among those offices with related jurisdiction is appropriate. Coordination is particularly important when:



   - The other office or branch has not participated in the development of the proposed publication (or has participated in the development but has not previously approved the proposed publication), and

   - The other office or branch has participated in the development of a related letter ruling, technical advice, or other underlying document.


2. To facilitate coordination, when work is initiated on a project, the drafting attorney should email each Associate Office within 30 days after the opening of the project on TECHMIS to alert the Associate Offices that the project has been opened. The email should contain the information described in CCDM 32.2.5.3(2).

3. Coordination may be done either formally or informally, as appropriate, as long as the other branch or office has an opportunity to react to the proposed publication before it is circulated for comment.

4. An office that receives formal advice or assistance from another office must follow the advice or implement the assistance unless the receiving office requests reconsideration of the advice or assistance and the advice or assistance is changed through the reconciliation process discussed below. When there is doubt as to whether the advice is directive rather than suggestive, the receiving office should ask for clarification rather than proceed on what might be an erroneous assumption that the advice was merely a suggestion.

5. Absent extraordinary circumstances, reconciliation should begin by the receiving office requesting reconsideration and providing the reasons for its disagreement to the office that provided the advice or assistance. If that office adheres to its views after reconsideration, the receiving office must follow the advice or assistance or elevate the request for reconsideration to the next higher level.

6. A request for reconsideration of branch level advice should be elevated to the Associate Chief Counsel of the office within which the branch is located, as applicable. A request for reconsideration at a higher level within the national office should be made by the appropriate branch or the appropriate Associate Chief Counsel.

7. When coordination with another branch or office is completed, the preparer enters on page 1 of the BIN under "Coordinated with" the name of the person, symbols of the office or branch, and the date coordinated. Page 2 of the BIN must reflect any unresolved disagreement. If the Associates are unable to reconcile their views, the matter should be elevated to the Deputy Chief Counsel or the Chief Counsel. The Associates will reconcile differing views and will ensure that the package that goes forward contains an analysis of all significant issues.


**32.2.5.3** **(01-25-2013)**

### Coordination with Division Counsel and with the Service

1. The Associate Chief Counsel is responsible for drafting and preparing published guidance. Division Counsel may assist the Associate Chief Counsel in developing published guidance. The Associate office should coordinate all projects with each Division Counsel office through their Publication Coordinator or designee. Each Division Counsel Publication Coordinator or designee is responsible for further coordination within its respective Service Operating Division.

2. Within 30 days after the opening of the project on TECHMIS, the drafting attorney should email each Division Counsel Publication Coordinator or designee as soon as possible to alert the Division Counsel that the project has been opened. The email should contain:



   - Description of the issue to be addressed by the project

   - Taxpayers affected

   - Reasons for publication

   - Target publication date (and any other timing considerations)

   - Name and telephone number of drafting attorney


3. Within 15 business days (unless time is of the essence and the email from the drafting attorney requests feedback in a shorter time frame), the Publication Coordinator or designee will notify the drafting attorney by email whether that Division requests to be involved in the development of the proposed publication. If the Division does not request to be involved in the development of the proposed publication item, the Division will still have an opportunity to comment on the draft publication item when the item is circulated for comments. See CCDM 32.2.6.4, General Circulation.

4. A decision by the Publication Coordinator or designee not to be involved with the drafting of the publication item does not prevent the Publication Coordinator or designee from reconsidering at a later time, and requesting further involvement in developing those projects in which the Operating Division is interested. Similarly, the Associate office may later suggest a higher level of involvement by Division Counsel than was originally indicated.

5. If a Division Counsel office requests involvement in the development of a project, the respective reviewer and Division Counsel Publication Coordinator or designee will determine the scope of the participation as soon as possible. This involvement will vary but, at a minimum the drafting attorney should:



1. Send the Division Counsel Publication Coordinator or designee all issues and policy memoranda and invite the Division Counsel Publication Coordinator or designee to attend any preliminary meetings to discuss the issue and policy memoranda,

2. Invite the Division Counsel Publication Coordinator or designee to briefings of Treasury, Counsel, or IRS executives, and

3. Include the Division Counsel Publication Coordinator or designee in the distribution of the circulation draft.


6. Any comments made by Division Counsel should be made by an employee with authority to speak on behalf of, and bind, the Division Counsel. The drafting attorney must ensure that all comments made by an employee of Division Counsel represent the comments and views of the Division Counsel and not merely the views of the employee.


**32.2.5.4** **(08-11-2004)**

### Coordination with Other Agencies or Organizations

1. **Disclosure Prohibited** — Generally, the contents and status of proposed publications are confidential and can be disclosed to anyone outside of the Service only with the approval at the Associate Chief Counsel level or higher. This approval has been granted to permit clearance of proposed publications with certain agencies of the federal government, including the Social Security Administration (SSA) and the Railroad Retirement Board. See below.

2. **Coordination Permitted** — The Service may seek comments and suggestions from taxpayers or taxpayer groups with respect to proposed publications when justified by special circumstances. Thus, the drafting attorney may seek information from another agency or organization affected by a proposed publication. For example, it may be necessary to secure information regarding industry practices in a developing area or to determine whether a fact pattern still exists when updating a prior publication. In the process of this coordination, if it becomes necessary or desirable for a representative of another agency or organization to read a draft of the proposed publication, the drafting attorney must first secure approval at the Associate Chief Counsel level before permitting the representatives to read the draft. A brief description of this coordination must be included in the BIN on page 2 under the heading "COORDINATION. "

3. When coordination outside the Service is necessary, the drafting attorney must ensure that the persons to whom any information concerning the proposed publication is communicated understands that the proposed publication is a draft and has not been approved at higher levels of the Service and should be kept confidential.


**32.2.5.4.1** **(08-11-2004)**

#### Coordination Required on Social Security Matters

1. The Service is responsible for the Federal Insurance Contributions Act (FICA) tax and the Self-Employment Contributions Act (SECA) tax provisions of the Internal Revenue Code. The Social Security Administration (SSA) administers the social security and medicare coverage provisions under the Social Security Act. Any matters relating to liability for FICA or SECA taxes must be coordinated with SSA. The Division Counsel/Associate Chief Counsel (Tax Exempt and Government Entities) (TEGE) has responsibility for this coordination, which, for proposed publications, generally is conducted contemporaneously with circulation.

2. If a proposed publication involving social security taxes is prepared outside of TEGE, the drafting attorney should coordinate with TEGE early in the development of the publication to obtain their views on the social security tax aspects of the publication. TEGE will work with the drafting attorney to coordinate the proposed publication with SSA.

3. A proposed publication may proceed through review channels while awaiting a response from SSA if the drafting attorney and reviewer believe that the matter should be expedited and have agreement from TEGE to proceed. Final clearance by the Chief Counsel, however, cannot occur until SSA agrees with the proposed publication.


**32.2.5.4.2** **(08-11-2004)**

#### Coordination Required on Railroad Retirement Matters

1. The Service is responsible for the Railroad Retirement Tax Act provisions of the Internal Revenue Code. The Railroad Retirement Board (RRB) administers the retirement and benefit coverage provisions under the Railroad Retirement and Railroad Unemployment Insurance Acts. Any matters relating to liability for Railroad Retirement Tax Act taxes must be coordinated with the RRB. Division Counsel/Associate Chief Counsel (TEGE) has responsibility for this coordination, which, for proposed publications, is accomplished under procedures similar to those followed for coordination with SSA, above.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part32/irm_32-002-005#addtoany "Show all")

A2A