---
url: "https://www.irs.gov/irm/part30/irm_30-002-002"
title: "30.2.2 General Counsel Orders and Directives | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part30/irm_30-002-002#main-content)

- 30.2.2 [General Counsel Orders and Directives](https://www.irs.gov/irm/part30/irm_30-002-002#idm139987222067392)
  - 30.2.2.1 [General Counsel, Treasury Department](https://www.irs.gov/irm/part30/irm_30-002-002#idm139987242799680)
  - 30.2.2.2 [Legal Division Issuances](https://www.irs.gov/irm/part30/irm_30-002-002#idm139987231596656)
  - Exhibit 30.2.2-1 [Department Circular No. 519 re: Establishment of Legal Division](https://www.irs.gov/irm/part30/irm_30-002-002#idm139987231185840)
  - Exhibit 30.2.2-2 [Department Circular No. 595 re: Responsibility for Legal Work](https://www.irs.gov/irm/part30/irm_30-002-002#idm139987240894448)
  - Exhibit 30.2.2-3 [General Counsel Order No. 1, Organization and Functions of the Legal Division](https://www.irs.gov/irm/part30/irm_30-002-002#idm139987236198400)
  - Exhibit 30.2.2-4 [General Counsel Order No. 2, Delegation of Authority to Deputy General Counsel](https://www.irs.gov/irm/part30/irm_30-002-002#idm139987218532064)
  - Exhibit 30.2.2-5 [General Counsel Order No. 3, Delegation of Authority to Assistant General Counsel](https://www.irs.gov/irm/part30/irm_30-002-002#idm139987242992976)
  - Exhibit 30.2.2-6 [General Counsel Order No. 4, Delegation of Authority to Chief Counsel](https://www.irs.gov/irm/part30/irm_30-002-002#idm139987223191904)
  - Exhibit 30.2.2-7 [General Counsel Order No. 5, Delegation of Authority to Chief Counsel and Legal Counsel](https://www.irs.gov/irm/part30/irm_30-002-002#idm139987233358928)
  - Exhibit 30.2.2-8 [General Counsel Order No. 6, Delegation of Authority to Tax Legislative Counsel](https://www.irs.gov/irm/part30/irm_30-002-002#idm139987237027184)
  - Exhibit 30.2.2-9 [General Counsel Order No. 7, Delegation of Authority to International Tax Counsel](https://www.irs.gov/irm/part30/irm_30-002-002#idm139987241330560)
  - Exhibit 30.2.2-10 [General Counsel Order No. 8, Delegation of Authority to Benefits Tax Counsel](https://www.irs.gov/irm/part30/irm_30-002-002#idm139987240382048)
  - Exhibit 30.2.2-11 [General Counsel Order No. 9, Practice Before the IRS](https://www.irs.gov/irm/part30/irm_30-002-002#idm139987245998848)
  - Exhibit 30.2.2-12 [General Counsel Order No. 10, Procedures for Litigation](https://www.irs.gov/irm/part30/irm_30-002-002#idm139987246528912)
  - Exhibit 30.2.2-13 [General Counsel Directive No. 6, Outside Employment of Attorneys](https://www.irs.gov/irm/part30/irm_30-002-002#idm139987218462000)
  - Exhibit 30.2.2-14 [General Counsel Directive No. 16, Pro Bono Legal and Volunteer Service Policy Statement](https://www.irs.gov/irm/part30/irm_30-002-002#idm139987242154704)

# Part 30. Administrative

# Chapter 2. Chief Counsel Directives

# Section 2. General Counsel Orders and Directives

* * *

## 30.2.2 General Counsel Orders and Directives

#### Manual Transmittal

June 25, 2013

#### Purpose

(1) This transmits revised CCDM 30.2.2, Chief Counsel Directives; General Counsel Orders and Directives.

#### Material Changes

(1) References in CCDM 30.2.2.1 and CCDM 30.2.2.2 were updated and hyperlinks added.

(2) Exhibit 30.2.2–12, General Counsel Order No. 10, was replaced with the most recent revision of the Order.

(3) The following exhibits were converted to xml compatible formats to comply with the requirements of Section 508 of the Rehabilitation Act: 30.2.2-5, 6, 7 and 13 . The content of the exhibits was not changed.

(4) The tables in the following exhibits were reformatted to comply with the requirements of Section 508 of the Rehabilitation Act: 30.2.2-1, 2, 4, 8, 9, 10, and 11.

#### Effect on Other Documents

CCDM 30.2.2 dated August 24, 2007 is superseded.

#### Audience

Chief Counsel

#### Effective Date

(06-25-2013)

Michael T. Cochis

Director

Planning and Management Division

**30.2.2.1** **(06-25-2013)**

### General Counsel, Treasury Department

1. This section provides information on General Counsel Orders, Designations and Directives (Legal Division issuances) issued by the Treasury Department.

2. The source of the General Counsel’s authority, can be found, among other places, in:



   - 31 U.S.C. §§ 301(f) and 321(b)(2)

   - 26 U.S.C. § 7803(b)

   - [Treasury Order Nos. 101-05 and 107-01 through 107-07](http://www.treasury.gov/about/role-of-treasury/orders-directives/Pages/orders-numeric.aspx)


**30.2.2.2** **(06-25-2013)**

### Legal Division Issuances

1. In accordance with former General Counsel Order No. 58, there was established, and there continues to be, a series of General Counsel issuances made applicable to the Legal Division and known as Legal Division issuances. An issuance in this series takes one of the three following forms and is numbered consecutively in its category.



1. **_General Counsel Order_** — implements organizational changes and provides delegations of authority.

2. **_General Counsel Directive_** — provides policies, procedures, and standards to be followed in the Legal Division or segments thereof.

3. **_General Counsel Designation_** — designates a named person to a specified position, on an acting or permanent basis.


2. Legal Division issuances are numbered, preserved, and distributed by the Office of the General Counsel. They are then reissued in the Chief Counsel Directives Manual.

3. Exhibit 30.2.2–1 and Exhibit 30.2.2–2 contain historical Treasury Department circulars relating to the Legal Division.

4. The General Counsel Orders and Directives reproduced herein as exhibits are current as of the date of publication of this section.



1. Exhibit 30.2.2-3 through Exhibit 30.2.2-12 contain General Counsel Orders.

2. Exhibit 30.2.2-13 and Exhibit 30.2.2-14 contain General Counsel Directives.


5. Images of orders and directives with the signature of the General Counsel are maintained by the Department of the Treasury on the [General Counsel Orders and Directives](http://thegreen.treas.gov/offices/Pages/orders-dir.aspx) page.


**Exhibit 30.2.2-1**

### Department Circular No. 519 re: Establishment of Legal Division

| _OFFICE OF THE GENERAL COUNSEL FOR THE_<br>_DEPARTMENT OF THE TREASURY_ |
| :-: |
|  |

|  |  |
| :-: | :-: |
| 1934 <br>Department Circular No. 519 | TREASURY DEPARTMENT,<br>Washington,<br>June 20, 1934 |

|  |
| :-- |
| Office of the Secretary |
| The Revenue Act of 1934 created in the Department of the Treasury the Office of General Counsel for the Department of the Treasury. Accordingly, there is hereby established a division to be known as "Legal Division, Department of the Treasury" , to which is transferred all of the personnel, records, books, furniture and supplies connected with the legal activities of the Treasury Department, and such division is hereby placed under the direct supervision and control of the General Counsel. |
| The General Counsel is hereby authorized to perform all duties and functions incident to the administration of the legal activities of the Treasury Department, including the signing of letters and the approval in my stead of such documents as may come before him in the regular course of his administration of the Legal Division of the Treasury Department, and such other duties as may be assigned to him by me from time to time. |
| All matters relating to personnel in the Legal Division, including recommendations for new appointments, transfers, promotions, or other matters relating to changes in personnel and all matters relating to the purchase of books and supplies for the Legal Division shall be referred to the General Counsel for his approval before any action is taken thereon. |
|  | /s/ HENRY MORGENTHAU, Jr.<br>Secretary of the Treasury. |

**Exhibit 30.2.2-2**

### Department Circular No. 595 re: Responsibility for Legal Work

| _OFFICE OF THE SECRETARY OF THE TREASURY_ |
| :-: |
|  |

|  |  |
| :-: | :-: |
| 1938<br>Department Circular No. 595 | TREASURY DEPARTMENT,<br>Washington,<br>September 13, 1938 |

|  |
| :-- |
| The operating control of, and responsibility for, the legal work of the Office of the Comptroller of the Currency is hereby transferred to the General Counsel for the Department of the Treasury. Responsibility for decisions on all legal matters, including matters of general legal policy, as well as on any legal aspects of specific cases or instances, shall rest with the General Counsel or those he designates for this work. |
| The Secretary of the Treasury shall pass upon all changes in the legal staff and in their salaries, upon the recommendation of the General Counsel. The General Counsel will be responsible for the assignment of work to various members of the legal staff and for other matters mentioned in Department Circular No. 519, dated June 20, 1934. |
|  | /s/ HENRY MORGENTHAU, Jr.<br>Secretary of the Treasury. |

**Exhibit 30.2.2-3**

### General Counsel Order No. 1, Organization and Functions of the Legal Division

|  |
| --- |
| **DEPARTMENT OF THE TREASURY**<br>**GENERAL COUNSEL ORDER NO. 1**<br>**Organization and Functions of the Legal Division** |
| Under the authority vested in me as General Counsel of the Department of the Treasury, including the authorities of 31 U.S.C. sections 301(f) and 321(b) and Treasury Department Orders 101-05,107-04, and 107-07, and pursuant to my role as head of the Legal Division of the Department of the Treasury, I hereby define and prescribe the organization and functions of the Legal Division of the Department of the Treasury: |
|  | 1. | The Legal Division is headed by the General Counsel, who is by statute the chief law officer of the Department of the Treasury. The Legal Division comprises the attorneys providing legal services in offices and bureaus of the Department of the Treasury in accordance with the delegations made by this order. The General Counsel operates principally through the Deputy General Counsel, the Assistant General Counsels, the Assistant to the General Counsel (Legislation, Litigation, and Disclosure), the Counselor to the General Counsel, and the various Counsels listed herein. |
|  | 2. | The General Counsel provides legal advice to the Secretary of the Treasury, the Deputy Secretary, the Under Secretaries, the Assistant Secretaries, and the Treasurer of the United States on any legal matter that may arise within the Department. The General Counsel supervises the Legal Division and establishes the policies, procedures, and standards governing its functioning. |
|  | 3. | The Deputy General Counsel acts as General Counsel in the absence of the General Counsel, reviews all work prepared for the General Counsel, and supervises the day-to-day operation of the Legal Division. |
|  | 4. | All Assistant General Counsels (with the exception of the Assistant General Counsel who is the Chief Counsel of the Internal Revenue Service), the Assistant to the General Counsel (Legislation, Litigation, and Disclosure), the Counselor to the General Counsel, the Tax Legislative Counsel, the International Tax Counsel, and the Benefits Tax Counsel report to the General Counsel through the Deputy General Counsel. The Assistant General Counsel who is the Chief Counsel of the Internal Revenue Service reports to the General Counsel, except for those matters for which the Chief Counsel reports by statute exclusively to the Commissioner, Internal Revenue Service. Other Chief Counsels and the Legal Counsels report to an Assistant General Counsel as set forth in this Order. |
|  | 5. | The Assistant General Counsel who is the Chief Counsel of the Internal Revenue Service is by statute the chief law officer for the Internal Revenue Service and supervises and directs the legal staff advising the Internal Revenue Service. |
|  | 6. | The Assistant General Counsel (General Law and Ethics) provides legal advice to the Assistant Secretary (Management) and Chief Financial Officer, the Assistant Secretary (Public Affairs), and the Treasurer of the United States, and to the Departmental Offices generally with respect to ethics, procurement, personnel, labor relations, fiscal and other general law issues affecting the administration of the Department. The Assistant General Counsel (General Law and Ethics) supervises the Deputy Assistant General Counsel (General Law and Ethics); the Chief Counsel, United States Mint; the Chief Counsel, Bureau of Engraving and Printing; and the Chef Counsel, Alcohol and Tobacco Tax and Trade Bureau. |
|  | 7. | The Assistant General Counsel (Banking and Finance) provides legal advice to the Under Secretary (Domestic Finance), the Assistant Secretary (Financial Institutions), the Assistant Secretary (Financial Markets), the Assistant Secretary (Economic Policy), and the Fiscal Assistant Secretary. The Assistant General Counsel (Banking and Finance) supervises the Deputy Assistant General Counsel (Banking and Finance); the Chief Counsel, Bureau of the Public Debt; the Chief Counsel, Financial Management Service; the Legal Counsel, Community Development Financial Institutions Fund; and the Legal Counsel, Terrorism Risk Insurance Program. |
|  | 8. | The Assistant General Counsel (Enforcement and Intelligence) provides legal advice to the Under Secretary (Enforcement), the Assistant Secretary (Terrorist Financing), and the Assistant Secretary (Intelligence and Analysis). The Assistant General Counsel (Enforcement and Intelligence) supervises the Deputy Assistant General Counsel (Enforcement and Intelligence); the Chief Counsel, Financial Crimes Enforcement Network; the Chief Counsel, Office of Foreign Assets Control; and the Legal Counsel, Executive Office for Asset Forfeiture. |
|  | 9. | The Assistant General Counsel (International Affairs) provides legal advice to the Under Secretary (International Affairs) and the Assistant Secretary (International Affairs). The Assistant General Counsel (International Affairs) supervises the Deputy Assistant General Counsel (International Affairs). |
|  | 10. | The Assistant to the General Counsel (Legislation, Litigation, and Disclosure) provides legal advice to the Assistant Secretary (Legislative Affairs) and the Executive Secretary. The Assistant to the General Counsel (Legislation, Litigation, and Disclosure) oversees and coordinates the development and presentation of the Department's position in significant litigation at the trial and appellate level, other than litigation involving the Internal Revenue Service, the Office of the Comptroller of the Currency, the Office of Thrift Supervision, the Treasury Inspector General, or the Treasury Inspector General for Tax Administration. The Assistant to the General Counsel (Legislation, Litigation, and Disclosure) is responsible for the Department's disclosure of information under the Freedom of Information Act and similar authorities and supervises the Department's Office of Disclosure Services. The Assistant to the General Counsel (Legislation, Litigation, and Disclosure) also undertakes special assignments as requested by the General Counsel or Deputy General Counsel. The Assistant to the General Counsel (Legislation, Litigation, and Disclosure) supervises the Deputy Assistant to the General Counsel (Legislation, Litigation, and Disclosure). |
|  | 11. | The Counselor to the General Counsel assists the General Counsel and the Deputy General Counsel by coordinating issues of general interest within the Legal Division and undertakes special assignments as requested by the General Counsel or the Deputy General Counsel. |
|  | 12. | The Tax Legislative Counsel is the principal legal adviser to the Assistant Secretary (Tax Policy) with respect to domestic aspects of tax legislation and tax policy. |
|  | 13. | The International Tax Counsel is the principal legal adviser to the Assistant Secretary (Tax Policy) with respect to international aspects of tax legislation and tax policy. |
|  | 14. | The Benefits Tax Counsel is the principal legal adviser to the Assistant Secretary (Tax Policy) with respect to pension and benefits aspects of tax legislation and tax policy. |
|  | 15. | The Chief Counsel, Alcohol and Tobacco Tax and Trade Bureau, is the legal adviser to the Administrator, Alcohol and Tobacco Tax and Trade Bureau, and supervises and directs the legal staff advising the Alcohol and Tobacco Tax and Trade Bureau. This Chief Counsel reports to and is supervised by the Assistant General Counsel (General Law and Ethics). |
|  | 16. | The Chief Counsel, Financial Crimes Enforcement Network, is the legal adviser to the Director, Financial Crimes Enforcement Network, and supervises and directs the legal staff advising the Financial Crimes Enforcement Network. This Chief Counsel reports to and is supervised by the Assistant General Counsel (Enforcement and Intelligence). |
|  | 17. | The Chief Counsel, Financial Management Service, is the legal adviser to the Commissioner, Financial Management Service, and supervises and directs the legal staff advising the Financial Management Service. This Chief Counsel reports to and is supervised by the Assistant General Counsel (Banking and Finance). |
|  | 18. | The Chief Counsel, Bureau of the Public Debt, is the legal adviser to the Commissioner, Bureau of the Public Debt, and supervises and directs the legal staff advising the Bureau of the Public Debt. This Chief Counsel reports to and is supervised by the Assistant General Counsel (Banking and Finance). |
|  | 19. | The Chief Counsel, Office of Foreign Assets Control, is the legal adviser to the Director, Office of Foreign Assets Control, and supervises and directs the legal staff advising the Office of Foreign Assets Control. This Chief Counsel reports to and is supervised by the Assistant General Counsel (Enforcement and Intelligence). |
|  | 20. | The Chief Counsel, Bureau of Engraving and Printing, is the legal adviser to the Director, Bureau of Engraving and Printing, and supervises and directs the legal staff advising the Bureau of Engraving and Printing. This Chief Counsel reports to and is supervised by the Assistant General Counsel (General Law and Ethics). |
|  | 21. | The Chief Counsel, United States Mint, is the legal adviser to the Director, United States Mint, and supervises and directs the legal staff advising the United States Mint. This Chief Counsel reports to and is supervised by the Assistant General Counsel (General Law and Ethics). |
|  | 22. | The Legal Counsel, Executive Office for Asset Forfeiture, is the legal adviser to the Director, Executive Office for Asset Forfeiture, and supervises and directs the legal staff advising the Executive Office for Asset Forfeiture. This Legal Counsel reports to and is supervised by the Assistant General Counsel (Enforcement and Intelligence). |
|  | 23. | The Legal Counsel, Community Development Financial Institutions Fund, is the legal adviser to the Director, Community Development Financial Institutions Fund, and supervises and directs the legal staff advising the Community Development Financial Institutions Fund. This Legal Counsel reports to and is supervised by the Assistant General Counsel (Banking and Finance). |
|  | 24. | The Legal Counsel, Terrorism Risk Insurance Program, is the legal adviser to the Executive Director, Terrorism Risk Insurance Program, and supervises and directs the legal staff advising the Terrorism Risk Insurance Program. This Legal Counsel reports to and is supervised by the Assistant General Counsel (Banking and Finance). |
| A change in title of any official or office in the Departmental Offices or a bureau shall not affect the foregoing assignments unless the change includes a change of function. The General Counsel may reassign any function assigned herein. |
| General Counsel Order No. 1 of January 19, 2001, is hereby superseded. |
|  |
|  |  |  | _/s/_<br>Arnold I. Havens<br>General Counsel |
| DATE: August 17, 2004 |  |

**Exhibit 30.2.2-4**

### General Counsel Order No. 2, Delegation of Authority to Deputy General Counsel

| **DEPARTMENT OF THE TREASURY**<br>**GENERAL COUNSEL ORDER NO. 2**<br>**Delegation of Authority to the Deputy General Counsel** |
| :-: |
| Under the authority of 31 U.S.C. 301(f) and 321(b), and Treasury Department Order Nos. 101-05, 101–11, 107–02, 107–04, and 107–07, I hereby delegate to the Deputy General Counsel the following authority: |
|  | 1\. to supervise the day-to-day operations of the Legal Division. |
|  | 2\. to assign legal matters referred to the General Counsel to Assistant General Counsels, the Counselor to the General Counsel (hereafter counselor), or the Associate Deputy General Counsel. |
|  | 3\. To act on personnel actions respecting attorneys in the Legal Division that are referred to the General Counsel, except actions respecting Assistant General Counsels, Deputy Assistant General Counsels, the Counselor, the Deputy Counselor to the General Counsel, the Associate Deputy General Counsel, Chief Counsels, Deputy Chief Counsels, Legal Counsels, the Tax Legislative Counsel, the International Tax Counsel, or the Benefits Tax Counsel. |
|  | 4\. to represent the General Counsel in novel, significant, or disputed matters requiring contact with an agency outside the Department of the treasury or involving a matter in dispute between bureaus or offices of the Department. |
|  | 5\. To administer the oath of office required by 5 U.S.C. 3331 or any other oath required by law in connection with employment in the Federal service. |
|  | 6\. To sign her own name on all correspondence to Congressional committees, the Office of Management and Budget or otherwise pertaining to the treasury Department legislative program or its position on legislation, with the exception of recommendations to the Office of Management and Budget on enrolled bills, which are prepared for the signature of the General Counsel. |
|  | 7\. To exercise the authorities of the Deputy General Counsel prescribed in General Counsel Order No. 10, "Delegation of Authority and Procedures for Litigation." |
|  | 8\. To perform such other functions of the General Counsel as the General Counsel may from time to time direct. |
| General Counsel Order No. 2 of January 12, 1993, is hereby superseded. |
|  |  |  |
|  |  | _/s/_<br>Neal S. Wolin<br>General Counsel |
| DATE: January 19, 2001 |

**Exhibit 30.2.2-5**

### General Counsel Order No. 3, Delegation of Authority to Assistant General Counsel

|  |
| --- |
| **DEPARTMENT OF THE TREASURY**<br>**GENERAL COUNSEL ORDER NO. 3**<br>**Delegation of Authority to Assistant General Counsels,**<br>**the Counselor to the General Counsel,**<br>**and the Associate Deputy General Counsel** |
| Under the authority of 31 U.S.C. 301(t) and 321(b), and Treasury Department Orders Nos. 101-05, 101-11, 107-02, and 107-04: |
| 1\. I hereby delegate to Assistant General Counsels (other than the Assistant General Counsel who is Chief Counsel of the Internal Revenue Service), the Counselor to the General Counsel (hereafter Counselor), and the Associate Deputy General Counsel the authority to perform the following functions: |
|  | a. To provide advice to the Under Secretaries, Assistant Secretaries, and other officials and employees in the Departmental Offices and Treasury Bureaus to whom they are to provide legal assistance under General Counsel Order No. 1. |
|  | b. To exercise the authorities prescribed in General Counsel Order No. 10, "Delegations of Authority and Procedures for Litigation." |
|  | c. To administer the oath of office required by 5 U.S.C. 3331, or any other oath required by law in connection with employment in the Federal service. |
| 2\. In the performance of the foregoing responsibilities, Assistant General Counsels, the Counselor, and the Associate Deputy General Counsel shall be responsible for the preparation of all necessary documents in accordance with relevant General Counsel Directives, and shall refer to another Assistant General Counsel, the Counselor, or the Associate Deputy General Counsel, as appropriate, for guidance, action, or review, any legislation, regulation, litigation, matter of procedure, or any other matter within the responsibility of that other Assistant General Counsel, the Counselor, or the Associate Deputy General Counsel. |
| 3\. Assistant General Counsels and the Counselor shall supervise and evaluate the work of all personnel in their office and take necessary action in all personnel matters pertaining thereto, including the approval of the carry-over of annual leave under 5 U.S.C. 6304(d), and adverse actions and the separation of attorneys, in accordance with Departmental Offices and Legal Division directives. Assistant General Counsels and the Counselor are responsible for the maintenance by their legal staff of appropriate professional standards. |
| 4\. Unless directed otherwise by the General Counsel, Assistant General Counsel and the Counselor may redelegate in writing any of the authority delegated in this Order to any subordinate officer or employee and authorize further delegation of such authority. |
| 5\. Unless otherwise directed by the General Counsel, the Deputy Assistant General Counsel shall serve as Acting Assistant General Counsel in the absence of the Assistant General Counsel. |
| 6\. Except as otherwise directed by the General Counsel, the most senior among the Assistant General Counsels, the Counselor, or the Associate Deputy General Counsel shall serve as Acting Deputy General Counsel during the temporary absence of the Deputy General Counsel. |
| 7\. As necessary, Assistant General Counsels, the Counselor, the Associate Deputy General Counsel, and their staffs may be assigned work outside their area of responsibility. |
| General Counsel Order No. 3 of January 12, 1993, is hereby superseded. |
|  | /s/ <br>Neal S. Wolin<br>General Counsel |
| DATE: January 19, 2001 |

**Exhibit 30.2.2-6**

### General Counsel Order No. 4, Delegation of Authority to Chief Counsel

|  |
| --- |
| **DEPARTMENT OF THE TREASURY**<br>**GENERAL COUNSEL ORDER NO. 4**<br>**Delegation of Authority to the Assistant General Counsel —**<br>**Chief Counsel, Internal Revenue Service** |
| Under the authority of 31 U.S.C. 301(f), 26 U.S.C. 7803(b), and Treasury Department Order Nos. 101-5, 101-11, 107-02, 107-04, and 107-07, and the authority vested in me as General Counsel of the Department of the Treasury, I hereby delegate to the Chief Counsel for the Internal Revenue Service, subject to General Counsel Order No. 1, the authority set out below: |
| 1\. To be the legal adviser to the Commissioner of Internal Revenue and his/her officers and employees. In performing his/her assigned functions, the Chief Counsel shall consult with and assist the Commissioner of Internal Revenue with a view to furthering the policies and programs of the Treasury Department and the Internal Revenue Service. |
| 2\. To furnish such legal opinions as may be required in the preparation and review of rulings and memoranda of technical advice and the performance of other duties delegated to the Chief Counsel. |
| 3\. To prepare, review, or assist in the preparation of proposed legislation, treaties, regulations, and Executive Orders relating to laws affecting the Internal Revenue Service. |
| 4\. To represent the Commissioner of Internal Revenue in cases pending in the Tax Court of the United States as prescribed in section 7452 of the Internal Revenue Code of 1986, in such cases to decide whether and in what manner to defend, or to prosecute a claim, or to settle, or to abandon a claim or defense therein, subject to Commissioner Delegation Order No. 60; to acknowledge in the name of the Commissioner the receipt of Tax Court subpoenas served upon the Commissioner of Internal Revenue; to determine whether, and the extent to which, officers and employees of the Internal Revenue Service shall be permitted to disclose Internal Revenue records and information in response to a subpoena or other order of the Tax Court; to determine whether to acquiesce in the decisions of said Court; to file petitions for review of Tax Court decisions; and to enter into written stipulations of venue for review of Tax Court decisions by a United States Court of Appeals. |
| 5\. To determine what civil actions (including actions for the judicial enforcement of summonses) should be brought in the courts under the laws affecting the Internal Revenue Service and to prepare recommendations to the Department of Justice for the commencement of such actions. |
| 6\. To refer a matter to the Department of Justice in order to obtain advice prior to any referral to be made by the Commissioner pursuant to Treasury Order 150-35. |
| 7\. To determine how actions brought in the courts against the United States or officers or employees thereof should be conducted and to make recommendations to the Department of Justice with respect thereto. |
| 8\. To determine which court decisions (including court decisions of a criminal tax matter) should be appealed or further reviewed and to make recommendations to the Department of Justice with respect thereto, clearing recommendations on significant cases (as defined in General Counsel Order No. 10) with the General Counsel, and to otherwise exercise the authorities prescribed in General Counsel Order No. 10, "Delegations of Authority and Procedures for Litigation." |
| 9\. To cooperate with and, at the request of the Department of Justice or of United States Attorneys, to assist in conducting litigation in the courts, both civil and criminal, and in preparing briefs and arguments with respect thereto. |
| 10\. To accept or reject plans where the United States is a creditor or equity security holder, including municipal debt adjustment plans, reorganization plans, and railroad reorganization plans (11 U.S.C. sections 90 1 (a)and 1126(a)). This covers proceedings where the United States possesses solely an Internal Revenue Service claim (a Treasury claim), as well as proceedings in which there are other claims of the United States in addition to the claim of the Internal Revenue Service. A non-Treasury claim of the United States includes any department, agency, federally chartered corporation, or instrumentality of the United States. To the extent that an agreement cannot be reached between the Chief Counsel, Internal Revenue Service and the holder of a non-Treasury claim of the United States, the matter will be referred to General Counsel of the Treasury for resolution. |
| 11\. To review cases within the provisions of section 6405 of the Internal Revenue Code of 1986 and to prepare and sign the reports required by that section to be submitted to the Joint Committee on Taxation. |
| 12\. To perform the functions prescribed for the General Counsel by section 7122 of the Internal Revenue Code of 1986 with respect to compromise matters arising in the administration of the Internal Revenue laws (excluding matters arising under Internal Revenue Code provisions administered by the Bureau of Alcohol, Tobacco and Firearms). |
| 13\. To supervise and evaluate the work of all officers and employees who are performing the duties and functions delegated in this Order in the Office of the Chief Counsel, and to take the necessary action in all personnel matters pertaining thereto, including those for the appointment, classification, promotion, demotion, reassignment, transfer or separation of such officers and employees, with the exceptions of appointments above GS-15, and of promotions, demotions or separations to or from the Senior Executive Service and reassignment of SES members. |
| 14\. To be responsible for the establishment and maintenance of appropriate professional standards and for the professional competence, recruitment and evaluation of the work of the attorneys of his/her office. |
| 15\. Subject to the approval of the General Counsel, to establish in the Office of Chief Counsel such divisions and subdivisions as he/she may deem advisable to carry out the duties herein and elsewhere delegated by the General Counsel and to designate the titles and duties of officers and employees in the Office carrying out such duties, except that the approval of the General Counsel shall not be required to designate the titles of and duties of such officers and employees who are not members of the Senior Executive Service. |
| 16\. To redelegate any of the authority delegated in this Order to any officer or employee in the Office of the Chief Counsel, and to authorize further redelegation of such authority. With respect to cases in the U.S. Bankruptcy Court, to redelegate authority to refer matters and authorize the commencement of actions to the Commissioner of Internal Revenue, and to authorize further redelegation of such authority. |
| 17\. To administer the oath of office required by 5 U.S.C. 3331 or any other oath required by law in connection with employment in the Federal service, and to redelegate this authority to any officer or employee in the Chief Counsel, Internal Revenue Service. |
| 18\. To approve carry-over of annual leave in accordance with the requirements of 5 U.S.C. 6304( d), and to redelegate this authority to a Deputy Chief Counsel, Associate Chief Counsel, or Division Counsel. |
| 19\. To approve requests by attorneys under his/her jurisdiction to engage in outside employment, when authority to approve is conferred on Chief Counsel by General Counsel Directive No. 6, and the approval is consistent with any standards and criteria in the Standards of Ethical Conduct for Employees of the Executive Branch, 5 C.F.R. Part 2635; the Supplemental Standards of Ethical Conduct for Employees of the Department of the Treasury, 5 C.F.R. Chapter XXI; and any other applicable statutes and regulations. |
| 20\. To make determinations relating to the applicability of section 6103 of the Internal Revenue Code of 1986, including the determination that disclosure would seriously impair Federal tax administration, and to disclose and authorize disclosure of tax returns, tax return information and taxpayer return information pursuant to the provisions of section 6103 (excluding determinations relating to Subtitle E provisions administered by the Bureau of Alcohol, Tobacco and Firearms). |
| General Counsel Order No. 4 dated July 1, 1997 is hereby superseded. |
|  | /s/ <br>Neal S. Wolin<br>General Counsel |
| DATE: January 19, 2001 |

**Exhibit 30.2.2-7**

### General Counsel Order No. 5, Delegation of Authority to Chief Counsel and Legal Counsel

|  |
| --- |
| **DEPARTMENT OF THE TREASURY**<br>**GENERAL COUNSEL ORDER NO. 5**<br>**Delegation of Authority to Chief Counsel and Legal Counsel** |
| Under the authority of 31 U.S.C. 301(f) and 321(b), and Treasury Department Order Nos. 101-05, 101-11, 107-02, and 107-04: |
| 1. | Delegations |
| I hereby delegate to Chief Counsel (other than the Chief Counsel for the Internal Revenue Service) and Legal Counsel the following authority, subject to the review prescribed herein and in General Counsel Order No. 1: |
|  | a. | Legal Advice |
|  |  | (i) | To serve as the legal adviser to the head of the bureau or office for which he or she is designated Chief Counselor Legal Counsel, and to the officers and employees of that bureau or office. In fulfilling this function, the Chief Counselor Legal Counsel shall consult with and assist the head of the bureau or office and the officers and employees thereof with a view toward furthering the policies and programs of the Department of the Treasury. |
|  |  | (ii) | To furnish legal opinions and assist the head of the bureau or office and the officers and employees thereof in the preparation, review, and publication of rulings, memoranda of technical advice, interpretations, licenses, procedures and other authorizations as required, with respect to the laws enforced or administered by the bureau or office. |
|  |  | (iii) | To prepare, review, or assist in the preparation of proposed legislation, regulations, proclamations, and Executive Orders relating to the laws that affect, or are enforced or administered by, the bureau or office. |
|  |  | (iv) | To advise upon or conduct any administrative proceedings necessary in the administration of pertinent laws and regulations. |
|  | b. | Litigation |
|  |  | To direct and supervise the role of the bureau or office in litigation consistent with General Counsel Order No. 10, "Delegations of Authority and Procedures for Litigation," and such specific directions as the respective Assistant General Counsel may provide in specific cases or categories of cases. |
|  | c. | Personnel and Organization |
|  |  | (i) | To supervise and evaluate the work of all officers and employees in the office of the Chief or Legal Counsel and to take necessary action in all personnel matters pertaining thereto, including the approval of the carry-over of annual leave under 5 U.S.C. 6304(d), and adverse actions and the separation of attorneys, in accordance with applicable General Counsel directives, except that: |
|  |  |  | (I) | The appointment or promotion of attorneys through GS-15 shall be subject to the approval of the respective Assistant General Counsel. Assistant General Counsel may delegate such approval authority, in whole or in part, to subordinate Chief and Legal Counsel. Any such delegation shall be in writing and a copy thereof shall be provided to the Administrative Officer. Such authority may be redelegated only as provided in the delegation from the Assistant General Counsel.<br>For any position requiring formal approval by an Assistant General Counsel, the selection recommendation memorandum signed by the office with the vacancy shall be transmitted to that Assistant General Counsel. After approval, the Assistant General Counsel shall provide a copy of the memorandum to the General Counsel and the original to the Administrative Officer.<br>For attorney positions not requiring formal approval by an Assistant General Counsel, the Chief or Legal Counsel shall provide notification of each new hire to the General Counsel through the appropriate Assistant General Counsel. |
|  |  |  | (II) | The appointment or promotion to a GS-15 position that is a deputy to a Chief or Legal Counsel, and the appointment to any position in the Senior Executive Service, shall be subject to the approval of the General Counselor Deputy General Counsel. |
|  |  |  | (III) | The reassignment, transfer, or demotion of any attorney, and the reclassification of an attorney position, shall be subject to the approval of the respective Assistant General Counsel. Assistant General Counsel may delegate such approval authority, in whole or in part, to subordinate Chief and Legal Counsel. Any such delegation shall be in writing and a copy thereof shall be provided to the Administrative Officer. Such authority may be redelegated only as provided in the delegation from the Assistant General Counsel. |
|  |  | (ii) | To be responsible for the establishment and maintenance of appropriate professional standards and for the professional competence, recruitment, and evaluation of the work of the attorneys in his or her office. |
|  |  | (iii) | To administer the oath of office required by 5 U.S.C. 3331 or any other oath required by law in connection with employment in the Federal service. |
|  |  | (iv) | To act under the appropriate personnel directives in their respective bureau or office in conducting personnel actions with respect to employees other than attorneys. |
|  |  | (v) | Subject to approval of the respective Assistant General Counsel and the General Counsel, to designate the titles of officers and employees in the office of the Chief or Legal Counsel, and to establish in such office divisions, subdivisions, and regions as may be advisable. |
|  | d. | Appeals Concerning Practice Before the Bureau of Alcohol, Tobacco and Firearms |
|  |  | Only to the Chief Counsel for the Bureau of Alcohol, Tobacco and Firearms, to decide all appeals to the Secretary of the Treasury filed under any provision of Part 8 of Title 31, Code of Federal Regulations ("Practice before the Bureau of Alcohol, Tobacco and Firearms" ). |
|  | e. | Redelegations |
|  |  | Subject to the limitations herein and unless directed otherwise by the General Counselor the respective Assistant General Counsel, to redelegate in writing any of the authority delegated in this Order to any subordinate officer or employee and to authorize further delegation of such authority. |
| 2. | Acting Chief Counsel |
| Unless otherwise directed by the General Counsel, the Deputy Chief Counsel shall serve as Acting Chief Counsel in the absence of the Chief Counsel. |
| 3. | Temporary Assignments |
| As necessary, Chief Counsels, Legal Counsels, and their staffs may be assigned work outside their area of responsibility. |
| 4. | Recisions |
| General Counsel Order No. 6 of January 5, 1988, and General Counsel Order No. 7 of October 5, 1987, are hereby superseded. |
|  |  |  |  |  |
|  |  |  |  | /s/ <br> Neal S. Wolin<br> General Counsel |
| DATE: January 19, 2001 |

**Exhibit 30.2.2-8**

### General Counsel Order No. 6, Delegation of Authority to Tax Legislative Counsel

| **DEPARTMENT OF THE TREASURY**<br>**GENERAL COUNSEL ORDER NO. 6**<br>**Delegation of Authority to the Tax Legislative Counsel** |
| :-: |
| Under the authority of 31 U.S.C. 301(f) and 321(b), and Treasury Department Order Nos. 101-05 and 107–04, I hereby delegate to the Tax Legislative Counsel the authority to perform the following functions, subject to the review prescribed by General Counsel Order No. 1: |
|  | 1\. To provide legal advice to the Assistant Secretary (Tax Policy) and to his or her subordinates concerning domestic aspects of tax legislation and tax policy. |
|  | 2\. To supervise the legal activities of those attorneys and support personnel under him or her. |
|  | 3\. To recommend to the General Counsel personnel actions with respect to attorney and non-attorney personnel under his or her jurisdiction in accordance with the policies promulgated by the General Counsel. |
|  | 4\. To be responsible for the maintenance by his or her legal staff of appropriate professional standards. |
| General Counsel Order No. 8 of October 15, 1987, is hereby superseded. |
|  |  |  |
|  |  | _/s/_ |
|  |  | Neal S. Wolin<br>General Counsel |
| DATE: January 19, 2001 |

**Exhibit 30.2.2-9**

### General Counsel Order No. 7, Delegation of Authority to International Tax Counsel

| **DEPARTMENT OF THE TREASURY**<br>**GENERAL COUNSEL ORDER NO. 7**<br>**Delegation of Authority to the International Tax Counsel** |
| :-: |
| Under the authority of 31 U.S.C. 301(f) and 321(b), and Treasury Department Order Nos. 101-05 and 107–04, I hereby delegate to the International Tax Counsel the authority to perform the following functions, subject to the review prescribed by General Counsel Order No. 1: |
|  | 1\. To provide legal advice to the Assistant Secretary (Tax Policy) and to his or her subordinates concerning international aspects of tax legislation and tax policy, including with respect to international tax treaties. |
|  | 2\. To supervise the legal activities of those attorneys and support personnel under him or her. |
|  | 3\. To recommend to the General Counsel personnel actions with respect to attorney and non-attorney personnel under his or her jurisdiction in accordance with the policies promulgated by the General Counsel. |
|  | 4\. To be responsible for the maintenance by his or her legal staff of appropriate professional standards. |
| General Counsel Order No. 9 of October 15, 1987, is hereby superseded. |
|  |  |  |
|  |  | _/s/_ |
|  |  | Neal S. Wolin<br>General Counsel |
| DATE: January 19, 2001 |

**Exhibit 30.2.2-10**

### General Counsel Order No. 8, Delegation of Authority to Benefits Tax Counsel

|     |
| --- |
|  |

| **DEPARTMENT OF THE TREASURY**<br>**GENERAL COUNSEL ORDER NO. 8**<br>_Delegation of Authority to the Benefits Tax Counsel_ |
| :-: |
| Under the authority of 31 U.S.C. 301(f) and 321(b), and Treasury Department Order Nos. 101-05 and 107–04, I hereby delegate to the Benefits Tax Counsel the authority to perform the following functions, subject to the review prescribed by General Counsel Order No. 1: |
|  | 1\. To provide legal advice to the Assistant Secretary (Tax Policy) and to his or her subordinates concerning pension and benefits aspects of tax legislation and tax policy. |
|  | 2\. To supervise the legal activities of those attorneys and support personnel under him or her. |
|  | 3\. To recommend to the General Counsel personnel actions with respect to attorney and non-attorney personnel under his or her jurisdiction in accordance with the policies promulgated by the General Counsel. |
|  | 4\. To be responsible for the maintenance by his or her legal staff of appropriate professional standards. |
|  |
|  |  | _/s/_ |
|  |  | Neal S. Wolin<br>General Counsel |
| DATE: January 19, 2001 |

**Exhibit 30.2.2-11**

### General Counsel Order No. 9, Practice Before the IRS

| **DEPARTMENT OF THE TREASURY**<br>**GENERAL COUNSEL ORDER NO. 9**<br>**Practice Before the Internal Revenue Service**<br>**Delegation of Authority to the Chief Counsel of the Internal Revenue Service** |
| :-: |
| Under the authority of 31 U.S.C. 301(f), 321(b) and 330, Treasury Department Order Nos. 101-05 and 107–04, and the authority vested in me as General Counsel of the Treasury, I hereby delegate to the Assistant General Counsel who is the Chief Counsel for the Internal Revenue Service the authority to perform the following function: |
|  | To decide all appeals to the Secretary of the Treasury filed under any provision of Part 10 of Title 31, Code of Federal Regulations ("Practice before the Internal Revenue Service" , also known as Department circular 230). |
| The authority delegated by the Order may be redelegated. Any redelegation shall be in writing. |
| General Counsel Order No. 11 of March 12, 2000 is hereby superseded. |
|  |  |  |
|  |  | _/s/_ |
|  |  | Neal S. Wolin<br>General Counsel |
| DATE: January 19, 2001 |

**Exhibit 30.2.2-12**

### General Counsel Order No. 10, Procedures for Litigation

|  |
| --- |
| **DEPARTMENT THE TREASURY**<br>**GENERAL COUNSEL ORDER NO. 10**<br>**Delegations of Authority and Procedures for Litigation** |
| Under the authority granted to me as General Counsel of the Department of the Treasury by 31 U.S.C. 301(f) and 321(b), 26 U.S.C. 7803(b), and Treasury Department Order Nos. 101-05, 107-02 and 107-04 and pursuant to my role as head of the Legal Division of the Department of the Treasury, I hereby define and prescribe the authority and procedures for litigation in the Department of the Treasury: |
| 1\. The General Counsel is responsible for litigation related matters involving the Department the Treasury. Unless specifically prohibited by law, this order applies to all litigation affecting the Department of the Treasury. Every attorney in the Legal Division who is involved with litigation matters has a responsibility to work with clients, supervisors, and the Department of Justice when appropriate, to meet legal and ethical obligations regarding such litigation. |
| 2\. Any questions regarding these obligations should be referred quickly to supervisors, and the Justice Department when appropriate, to assure prompt resolution. Each Legal Division attorney involved with litigation matters also has a responsibility to actively and vigorously represent the Department, including involvement in discovery, in preparing and reviewing filings, in witness preparation, and, when appropriate, participation at trials. |
| 3\. Each Assistant General Counsel has principal responsibility, subject to the direction of the General Counsel and the Deputy General Counsel, for the supervision, day to day management, and general strategic direction for all litigation in his or her area of responsibility, including that related to the Freedom of Information Act. This includes case tracking; responding to requests for documents and testimony either through subpoena or Treasury's _Touhy_ regulations; preparation of litigation memoranda: review of pleadings and briefs; document review and production; and other necessary litigation duties. Each Assistant General Counsel may delegate these duties as appropriate. In addition, each Assistant General Counsel, except for the Chief Counsel for the Internal Revenue Service, is responsible for designating within his or area of responsibility a case/dispute or litigation matter as "significant" as defined below. |
| 4\. The Deputy General Counsel, Assistant General Counsels, Chief Counsels, Legal Counsels, these officials’ designees, and any other member of the Legal Division designated by the General Counsel, shall assist in the coordination of litigation matters to ensure that litigation obligations are met and that the Department is actively and vigorously represented. Among other things, this assistance shall include ensuring timely coordination of litigation matters with all Treasury clients with an interest in the litigation, with all Legal Division offices with an interest in the litigation, and with the Department of Justice when appropriate. This assistance also shall include ensuring that accurate information is maintained concerning the status of pending cases and deadlines associated therewith. If more than one Assistant General Counsel’s office has an interest in a particular case, and there is a disagreement as to which is primarily responsible, the Deputy General Counsel shall designate a lead office. |
| 5\. Authority to receive service of any subpoena, summons, or other judicial process directed to any component of the Department, or to an officer or employee of the Departmental Offices or any Treasury Department bureau in his or her official capacity in any litigation, is delegated to the Deputy General Counsel, Assistant General Counsels, Chief Counsels, and Legal Counsels within their respective areas of responsibility. This authority may be redelegated, in whole or in part, to any attorney under the supervision of these officials provided that any such redelegation shall be in writing. |
| 6\. All litigation documents mailed or directed to the Departmental Offices, shall be forwarded to the office of the Assistant General Counsel for General Law, Ethics and Regulation, who shall maintain records concerning the receipt those litigation documents, as appropriate. The Assistant General Counsel for General Law, Ethics and Regulation's office shall promptly forward litigation documents to an Assistant General Counsel, a Chief Counsel, a Legal Counsel, these officials' designees, or others, as appropriate. When a litigation document is forwarded to a Chief Counsel or Legal Counsel, a copy of the litigation document also will be forwarded to the supervising Assistant General Counsel. These officials should maintain their own records concerning the receipt of litigation documents regardless of whether the matter was referred by the Assistant General Counsel for General Law, Ethics and Regulation. |
| 7\. For purposes of this order, the terms "significant case" or "significant litigation" means any case or dispute, including matters that are not in formal litigation: |
|  | a. so designated by the General Counsel, Deputy General Counsel, or their designee; |
|  | b. involving the Department or an employee or official thereof with respect to which — |
|  |  | (1) a petition for writ of certiorari has been filed, or is being Contemplated by the Government; or |
|  |  | (2) a petition for rehearing or rehearing en banc has been filed, or is being contemplated, by the Government; or |
|  | c. that is deemed significant by an Assistant General Counsel, or his or her designee. A case may be significant if, for example, it has one or more of the following features: |
|  |  | (1) a significant legal or policy issue involving more than one office within the Treasury Department of having broad applicability to or significant impact on the Department; |
|  |  | (2) a policy issue that may attract significant public or media attention; |
|  |  | (3) an action against a senior official of the Department; |
|  |  | (4) sensitive policy or legal issues; |
|  |  | (5) a substantive or procedural challenge to a significant regulation issued or action taken by a Treasury office or bureau; |
|  |  | (6) the administration by the Department of a significant law; |
|  |  | (7) a petition for a rehearing or rehearing en bane that has been filed by a non-Governmental party; |
|  |  | (8) the Government's consideration of potential or actual amicus participation, intervention in litigation, or participation through filing a statement of interest; or |
|  |  | (9) a non-enforcement action in an amount in controversy in excess of $500,000. |
| 8\. Each Assistant General Counsel, except for the Chief Counsel for the Internal Revenue Service, shall ensure that the General Counsel, Deputy General Counsel and other appropriate Legal Division staff are promptly notified when a case is designated as significant and of each major ruling or event in significant cases. |
| 9\. All recommendations to the Solicitor General and to the Department of Justice concerning a petition for rehearing, rehearing en banc, or a writ of certiorari ( _i.e._, cases that are _per se_ significant) shall have the approval of the General Counsel or his designee. Such written recommendations shall be prepared for the signature of the General Counsel, except those involving the IRS may be prepared for the signature of the Chief Counsel for the Internal Revenue Service. |
| 10\. Other critical decisions regarding significant litigation, including any compromise or settlement, shall be approved by the General Counsel, the Deputy General Counsel, or their designee. Recommendations regarding these critical decisions shall be made in writing. |
| 11\. Documents and decisions concerning significant litigation that are not reserved to the General Counsel or the Deputy General Counsel shall be signed or made by the appropriate Assistant General Counsel, or their designees. Each Assistant General Counsel may delegate signature and decision-making authority concerning significant and other litigation matters to their respective Deputies and/or the Chief Counsel or Legal Counsel. |
| 12\. Documents and decisions, including any compromise or settlement up to $100,000, concerning litigation that is not designated as significant or otherwise reserved to the General Counsel or Deputy General Counsel may be signed or made by the appropriate Assistant General counsel or their designees. Before entering into a settlement, the Assistant General Counsel must obtain assurance that adequate funds are available to pay any monetary settlement. Each Assistant General Counsel shall establish procedures regarding the delegation of signature and decision-making authority concerning litigation to attorneys under their supervision. |
| General Counsel Directive No. 10 of January 19, 2001, is hereby superseded. |
| _/s/_<br>Robert F. Hoyt <br>General Counsel |
| DATE: 1-11-2009 |

**Exhibit 30.2.2-13**

### General Counsel Directive No. 6, Outside Employment of Attorneys

**DEPARTMENT OF THE TREASURY GENERAL COUNSEL DIRECTIVE NO. 6**

**Outside Employment of Attorneys**

1\. General Policy

(A) The policies and procedures applicable to outside employment activities by attorneys within the Legal Division set forth in 18 U.S.C. title 11, the Standards of Ethical Conduct (5 C.F.R. part 2635 subpart H) ("Standards" ), the Supplemental Standards of Ethical Conduct for Employees of the Department of the Treasury (5 C.F.R. part 3101) ("Supplemental Standards" ) and this Directive shall be strictly followed so that such activities do not interfere with our obligations as Treasury attorneys.

(B) Non-attorneys in the Legal Division shall follow the outside employment rules and procedures applicable to employees of the bureaus or offices in which they serve.

2\. General Principles

(A) The Standards and the Supplemental Standards prohibit outside employment activities that conflict with an employee's official duties because they are prohibited by statute or regulation, or would require the employee's disqualification from matters so central or critical to the performance of his official duties that the ability of the employee to perform the duties of his position would be materially impaired.

(B) Attorneys should be aware of the restrictions on representational activities against or before the Government set forth in 18 U.S.C. § 205, as well as those regarding the receipt or sharing of compensation for such activities in 18 U.S.C. § 203.

(C) Outside employment activities shall not be conducted during official time. Requests for annual leave, leave without pay, or use of accumulated credit hours (where available by office policy) for purposes of engaging in outside employment activities, like all such requests, must be scheduled and approved in advance and supervisors shall take into account the work needs of the office when considering such requests. Except as stated in subparagraph (D), below, outside employment activities shall not be conducted on Government premises nor involve the use of Government property and non-public information.

(D) Government property shall be used only for those purposes authorized in accordance with law or regulation. 5 C.F.R. § 2635.704. The following personal uses of Government office and library equipment and facilities are authorized in connection with permissible outside employment activities: (1) use of property that involves minimal time and expense ( _e.g._, electricity, ink, small quantities of paper, and ordinary wear and tear); and (2) limited, occasional outgoing telephone/fax calls to locations within the local dialing area, or that are charged to non-Government accounts.

(E) Outside teaching, speaking, and writing activities, with or without compensation, are outside employment activities for which advance approval is required if they relate to Treasury programs or operations. Employees should be aware of the restrictions on certain compensated outside speaking, teaching, and writing activities in the Standards, 5 C.F.R. § 2635.807.

(F) _Pro bono_ legal service is an outside employment activity for which advance approval is required.

(G) Attorneys are responsible for ensuring that their outside employment activities are consistent with applicable rules of professional responsibility or conduct.

3\. Prohibited Activities

(A) Attorneys in the Legal Division are covered by the rules in the Supplemental Standards applicable to employees of the bureaus or offices in which they serve.

(B) Except as set forth in section 5(A), below, an attorney in the Legal Division shall not engage in the outside practice of law that might require the attorney to:

(1) take a position that is or appears to be in conflict with the interests of the Department of the Treasury; or

(2) interpret any statute, regulation or rule administered or issued by the Department of the Treasury.

(C) Except as provided herein, no attorney in the Legal Division shall represent any other Treasury employee, with or without compensation, who is the subject of disciplinary or other personnel administration proceedings in connection with those proceedings. This prohibition does not extend to representation by an attorney in the Legal Division acting in his or her capacity as a union representative in a grievance procedure or a statutory appeals procedure, provided the represented employee is a Legal Division employee in the union representative's bargaining unit, and provided further that such representation does not otherwise create a conflict or apparent conflict of interest or would otherwise be incompatible with law or with the official duties of the representing employee.

(D) Nothing in this Directive shall prohibit an attorney in the Legal Division from acting without compensation as agent or attorney for, or otherwise representing any cooperative, voluntary, professional, recreational, or similar organization or group not established or operated for profit, if a majority of the organization's or group's members are current Government officers or employees, or their spouses or dependent children, provided that such representation is consistent with 18 U.S.C. § 205(d) and the attorney obtains prior written approval to engage in the activity.

(E) An attorney in the Legal Division may represent a person or organization as part of an approved _pro bono_ activity provided such representation is consistent with law, _e.g._, does not involve representation of another before any agency or court of the United States.

4\. Approval Procedures

(A) An attorney in the Legal Division who wishes to engage in outside employment shall request permission in writing prior to commencing the activity. The attorney shall submit the written request to the attorney's supervisor. The request shall provide, at a minimum, the following information:

(1) the name, address, and telephone number of the prospective outside employer, if appropriate;

(2) any relationship of the proposed employer to the attorney;

(3) any relationship of the proposed employer, if a business entity, to Treasury;

(4) a description of the attorney's anticipated duties;

(5) the number of hours the attorney expects to work (per day, week, or month, as applicable);

(6) the projected duration of the outside employment activity; and

(7) if the activity involves teaching, speaking, or writing for compensation, the nature and source of such compensation.

(B) The written request shall be decided as follows:

(1) for outside employment requests by Chief Counsel, Legal Counsel, or attorneys in the Office of the General Counsel, by the General Counselor Deputy General Counsel; and

(2) for outside employment requests by attorneys reporting to Chief Counselor Legal Counsel, by the appropriate Chief Counselor Legal Counsel, or Deputy Chief Counsel. The Chief Counsel of the Internal Revenue Service may delegate this authority to the Associate Chief Counselor Division Counsel level.

The determining official shall issue a written decision on the request. The determining official shall consult with bureau or office ethics counselor the Designated Agency Ethics Official if there are any questions about the propriety of the request.

C) The original written outside employment request and the determination shall be returned to the requesting attorney. The attorney's supervisor shall retain a copy of these documents, and a copy of both documents shall be sent to the attorney's servicing personnel office for inclusion in the attorney's official personnel folder (temporary side).

D) Chief Counsel and Legal Counsel may issue supplemental procedures and/or forms for approval of outside employment requests consistent with the requirements of this Directive. A copy of any such procedure or form shall be provided to the Designated Agency Ethics Official.

(E) Approval may be revoked at any time upon a determination that a change of circumstances renders the employment inconsistent with applicable law, regulation, or the principles set forth in this Directive.

5\. Activities Permitted Without Approval

The following types of activities do not require written approval:

(A) Providing legal services, or acting in a fiduciary capacity, for the attorney's parents, spouse, or child, or the estate of any such person, provided that such activities are consistent with applicable statutes ( _e.g._, 18 U.S.C. § 205(e), regulations, and rules of professional responsibility or conduct, and would not require the attorney's disqualification from matters so central or critical to the performance of his official duties that the ability of the attorney to perform the duties of his position would be materially impaired;

(B) Membership and services (including holding of office) in civic, scout, religious, educational, fraternal, social, community, veterans, and charitable organizations, including corporations, where such office or services do not entail the management of a business type activity such as the direct operation of a commercial-type clubhouse;

(C) Membership and services (including holding of office) in Federal employee organizations, credit unions, and Federal employee unions, as otherwise permitted by law;

(D) Services as a notary public;

(E) Sales to co-workers, friends, relatives, and neighbors not involving sales to, and solicitation of, the general public, provided that such sales are not solicited or transacted during duty hours or in space occupied by Treasury offices, and are otherwise permitted by law;

(F) Rental of personally owned real or personal property, provided that the attorney is not engaged in a commercial business venture;

(G) Minor services for friends, relatives, or neighbors; and

(H) Teaching, speaking, or writing that does not relate to Treasury programs or operations.

6\. _Pro Bono_ and Bar-Related Activities

Attorneys in the Legal Division are encouraged to participate in _pro bono_ service and activities of bar associations and other professional organizations. Each attorney shall obtain approval in accordance with this Directive before accepting a leadership position or undertaking substantive committee or _pro bono_ assignments that might require substantial commitments of time and energy or present the risk of an actual or apparent conflict of interest. Such activities are subject to the limitation in section 3(B) of this Directive. Attorneys should consult with the current Department of the Treasury Legal Division _Pro Bono_ Legal and Volunteer Service Policy Statement for additional considerations regarding _pro bono_ service.

7\. Effective Date, Duration and Cancellation

This revision is effective January 19, 2001. It remains in effect until superseded. All previous versions of General Counsel Directive No. 6 are superseded upon the effective date of this Directive. All previous delegations in conflict with the provisions herein are hereby superseded.

/s/

Neal S. Wolin

General Counsel

**Exhibit 30.2.2-14**

### General Counsel Directive No. 16, _Pro Bono_ Legal and Volunteer Service Policy Statement

|  |
| --- |
| **DEPARTMENT OF THE TREASURY _GENERAL_ COUNSEL DIRECTIVE NO. 16** |
| **_Pro Bono_ Legal and Volunteer Service Policy Statement** |
| **I. Introduction.** |
| _Pro bono_ legal work and other volunteer activities allow participants to assist individuals and strengthen communities, and at the same time present opportunities to enhance professional skills. Pursuant to Executive Order 12988 (February 5, 1996) and Executive Order 13254 (January 29, 2002), it is the policy of the Department of the Treasury Legal Division to facilitate voluntary participation in such activities by employees within the Legal Division. |
| Although Federal government attorneys face some constraints on the types of _pro bono_ legal and other volunteer activities they may perform, many of the former barriers to their participation in these activities have been removed. This policy statement is intended as a guide for those who wish to become involved in _pro bono_ service. The Legal Division’s goal is to increase _pro bono_ activity by eliminating uncertainty regarding the types of _pro bono_ legal and other volunteer activities in which attorneys may participate. |
| Attorneys should also consult the current Department of the Treasury General Counsel Directive No. 6 ("Outside Employment of Attorneys" ). |
| **II. Definitions.** |
|  | A. _Pro Bono_. _Pro bono_ service may include the uncompensated provision of legal services to the following: |
|  |  | 1\. persons of limited means or other disadvantaged persons; |
|  |  | 2\. charitable, religious, civic, community, governmental, health and educational organizations in matters which are designed primarily to address the needs of persons of limited means or other disadvantaged persons, or that further their organizational purpose; |
|  |  | 3\. individuals, groups or organizations seeking to secure or protect civil rights, civil liberties or public rights; or |
|  |  | 4\. activities for improving the law, the legal system, or the legal profession. |
|  | B. Volunteer Services. Volunteer services are non-legal activities performed without compensation, for the benefit of: |
|  |  | 1\. persons of limited means or other disadvantaged persons; or |
|  |  | 2\. charitable, religious, civic, community, governmental, health and educational organizations in matters which are designed primarily to address the needs of persons of limited means or other disadvantaged persons. |
|  | C. Illustrative definitions. The examples provided in sections A and B above are illustrative only, and are not intended as exhaustive lists of what may be considered _pro bono_ or volunteer service. The definitions are modeled upon those provided in the Department of Justice Policy Statement on _Pro Bono_ Legal and Volunteer Services which in turn is based on Rule 6.1 of the ABA Model Rules of Professional Conduct. Those sources may be consulted for further guidance on the appropriate activities which may be pursued as _pro bono_ or volunteer service. |
|  | D. Exclusions. Partisan political activities or compensated outside employment or other activities shall not be considered _pro bono_ service under any circumstances. |
| **III. Limitations.** |
| The following statutes and regulations govern and to some degree limit the types of _pro bono_ and volunteer activities open to Treasury Legal Division attorneys. The following descriptions are summaries only. The full text of these provisions should be consulted whenever questions arise. |
|  | A. 18 U.S.C. 205 prohibits Federal employees from engaging in certain activities in claims against and other matters affecting the United States, that would require the employee to act as an agent or attorney: |
|  |  | 1\. for prosecuting any claim against the United States or receiving any gratuity, or share of or interest in such claim, in consideration of assistance in the prosecution of such claim; or |
|  |  | 2\. for anyone else before the Government (including Federal courts) in connection with any covered matter in which the United States is a party or has a direct and substantial interest. |
|  | B. 5 C.F.R. 2635, Standards of Ethical Conduct for Employees of the Executive Branch, specifies that it is inconsistent with the standards of conduct to engage in any outside employment or other outside activity which would: |
|  |  | 1\. require the recusal of the employee from significant aspects of the employee’s official duties (5 C.F.R. 2635.802(b)); |
|  |  | 2\. create an appearance that the employee’s official duties were performed in a biased or less than impartial manner (5 C.F.R. 2635.502); |
|  |  | 3\. create an appearance of official sanction or endorsement (5 C.F.R. 2635.702(b)); or |
|  |  | 4\. would be prohibited by statute or agency supplemental regulation (5 C.F.R. 2635.802(a)). |
|  | C. 5 C.F.R. 3101 et seq. contains supplemental regulations for Treasury employees. |
|  |  | 1\. In particular, 5 C.F.R. 3101.107 prohibits Legal Division attorneys from engaging in the outside practice of law that might require the attorney: |
|  |  |  | a. to take a position that is or might appear to be in conflict with the interests of the Department of the Treasury; or |
|  |  |  | b. to interpret any statute, regulation or rule administered or issued by the Department. |
|  |  | 2\. Employees of the Legal Division are also subject to the rules on outside employment or activities applicable to employees of the bureaus or offices in which they serve, 5 C.F.R. 3101.107(a). IRS, OCC, and USCS currently have restrictions in the Treasury Supplement on outside employment. |
|  | D. Federally Funded Programs. Treasury employees should be cognizant of the fact that their participation in cases or activities involving Federally funded programs may be inappropriate where the Department directly administers the funding for the specific program. Any questions concerning the appropriateness of participation in such a case or activity will be resolved on a case-by-case basis. |
| **IV. Approval and Other Procedures.** |
|  | A. Approval for Non-Legal Volunteer Activities. General Counsel Directive No. 6 allows Legal Division attorneys when not on duty to participate on a non-compensated basis in the activities of civic, scout, religious, educational, fraternal, social, community, veterans and charitable organizations without prior approval. Attorneys are expected to consult with supervisors regarding activities that may cause an actual or apparent conflict of interest or if they become heavily involved ( _e.g._, in a leadership position) in the volunteer activity and if that activity requires a significant time commitment. |
|  | B. Approval/Conflicts Check for _Pro Bono_ Legal Activities. |
|  |  | 1\. Attorneys may engage in _pro bono_ legal activities upon receipt of written permission to do so from the appropriate Assistant General Counsel, Counselor to the General Counsel, Chief Counsel, Legal Counsel, or the Deputy General Counsel, or his or her respective designee. Attorneys’ direct supervisors will be responsible for consenting to the _pro bono_ legal work and for completing a conflict of interest check before approval is given. |
|  |  | 2\. Each request will include, as a minimum, the following information: |
|  |  |  | a. the name, address, and telephone number of the prospective client, if appropriate; |
|  |  |  | b. a description of the attorney’s anticipated duties; |
|  |  |  | c. the number of hours the attorney expects to work (per day, week, or month, as applicable); |
|  |  |  | d. the projected duration of the _pro bono_ legal work; |
|  |  |  | e. any relationship of the proposed client to the attorney; and |
|  |  |  | f. any relationship of the proposed client, if a business entity, to the Treasury. |
|  |  | 3\. Once an attorney has begun the _pro bono_ activity, he or she is responsible for avoiding conflicts of interest, or the appearance of conflicts of interest, in the _pro bono_ activity. Attorneys shall also be responsible for advising the official approving the outside employment or activity of any change in circumstances that may be material to continuing approval of the outside employment or activity. |
|  | C. Retainer Letter. The Department recommends that the attorney prepare a retainer letter for each _pro bono_ legal activity, making explicit to the client that the attorney is working as an individual, and not in his or her capacity as a government lawyer. The attorney should consult with the appropriate State bar association in making a determination as to whether or not a retainer letter is necessary. Some bars, and some _pro bono_ organizations that make referrals, require that a retainer letter be prepared when the attorney is representing a client in an individual capacity. |
|  | D. Bar Regulations. Information on requirements to practice _pro bono_ may be obtained from State bar associations or administrative offices of the courts. As of April 9, 2002, the following is a summary of rules applicable in the Washington, D.C. area: |
|  |  | 1\. D.C. |
|  |  |  | a. Attorneys not admitted to the District of Columbia Bar may practice in the District on a _pro bono_ basis under the supervision of a licensed D.C. Bar member, per D.C. Court of Appeals Rule 49(c). In these circumstances, it is necessary to file a Motion/Certificate of Practice _Pro Bono Publico_ with the Clerk of the court where the matter will occur. |
|  |  |  | b. The D.C. Bar licensing fee is waived for attorneys "engaged in the provision of legal services on a _pro bono_ basis solely or in combination with government service." |
|  |  | 2\. Virginia. Attorneys may not undertake _pro bono_ legal representation in the Commonwealth of Virginia unless they are licensed by the Virginia State Bar. They may, however, serve in an auxiliary function ( _e.g._, intake work) in a _pro bono_ context. |
|  |  | 3\. Maryland. Pursuant to Rule 15 of the Rules Governing Admission to the Bar of Maryland, a member of the Bar of another State who fulfills requirements set out in the Rule may practice under the auspices of an organized legal services program sponsored or approved by the Legal Aid Bureau. |
|  | E. Malpractice Insurance. The government is unable to provide malpractice insurance to attorneys taking _pro bono_ cases. Prior to accepting a _pro bono_ service, the attorney should determine whether the referring program or organization may provide malpractice insurance for the work. |
|  | F. Training. Due to conflict-of-interest issues, many of the _pro bono_ opportunities available to Treasury attorneys will be outside of the attorney’s area(s) of expertise. Referring agencies (for example, the D.C. Bar’s _pro bono_ division) frequently offer training seminars in fields often encountered in _pro bono_ work. |
| **V. Use of Official Position/Public Office/Agency Resources.** |
|  | A. In General. Treasury Legal Division attorneys who engage in _pro bono_ or volunteer activities do so as private individuals. The attorney is responsible for making it clear to clients and other involved parties that he or she is not acting as a representative of the Treasury Department. Identification of the individual’s position in the Treasury Department Legal Division is permissible only as long as it is merely incidental to the _pro bono_ activity performed ( _e.g._, information necessary to provide a mailing address or a telephone number may be revealed). |
|  | B. Hours of Work. _Pro bono_ or volunteer service should, to the greatest extent possible, be performed outside of normal working hours. However, occasions such as court appearances may call for _pro bono_ service-related work during the business day. Employees must request annual leave, leave without pay, or use of accumulated credit hours (if available within the organization where the attorney works) before engaging in _pro bono_ activities during their scheduled working hours. In considering such requests, supervisors should accommodate, where possible, the efforts of their employees to do _pro bono_ legal or volunteer work, also paying due consideration to the effect of the employee’s absence on the operations of the office. A decision to grant or deny leave or use of credit hours may not be affected by the supervisor’s personal views regarding the substance of the _pro bono_ activity. Employees should remember when resolving any scheduling conflicts that their primary responsibility is to the Treasury Department Legal Division. |
|  | C. Use of Official Position and Other Agency Resources. |
|  |  | 1\. Use of official titles, Treasury letterhead, business cards, etc. is prohibited. |
|  |  | 2\. Government property may be used only for those purposes authorized in accordance with law or regulation. 5 C.F.R. 2635.704 The following personal uses of Government office and library equipment and facilities are authorized in connection with approved _pro bono_ work: (1) use of property that involves minimal time and expense ( _e.g._, electricity, ink, small quantities of paper, and ordinary wear and tear); and (2) limited, occasional outgoing telephone/fax calls to locations within the local dialing area, or that are charged to non-Government accounts.<br>Employees wishing to use more than a small amount of office supplies must provide their own or pay for its cost. Employees should contact their ethics officer and supervisor if there is any question whether an intended use involves minimal expense or small amounts of office supplies. <br>This policy does not authorize the personal use of commercial electronic databases when there is an extra cost to the government; personal use is only allowed when the contract permits unlimited use. Research using the library’s books or microfiche is authorized, as it involves only negligible additional expense to the government. <br>Any such personal use must not interfere with official business, and supervisors should be consulted if there is any question over whether such use is "minimal" . The policy may be revoked or limited at any time by any supervisor for any business reason. Any employee who has questions about the application of this section to any particular situation should consult his or her supervisor. |
|  |  | 3\. Work related to volunteer service may not be assigned to clerical or support staff. Asking clerical or support staff if they wish to participate in volunteer activities may violate 5 C.F.R. 2635.705. |
| **VI. _Pro Bono_ Policy and Ethics Requirements.** |
| Senior Counsel for Ethics in the Office of the Assistant General Counsel (General Law and Ethics) will serve as a general resource for ethics issues arising from _pro bono_ and volunteer activities of Legal Division attorneys. Chief Counsel and Legal Counsel also may designate an attorney who deals with ethics issues on their staff to serve as a general resource for ethics issues arising from _pro bono_ and volunteer activities for their attorneys. |
| **VII. Voluntary Participation.** |
| This policy statement is intended to remove existing policy barriers which currently inhibit the performance of _pro bono_ service, and to serve as a guide for those who voluntarily wish to participate in _pro bono_ legal or volunteer service. It is not intended to require such participation, nor is such service to be made a rating element of any Treasury Department Legal Division employee. |
| **VIII. Disclaimer.** |
| This policy statement is intended only to encourage _pro bono_ legal and volunteer activities by Treasury Department Legal Division employees and is not intended to create any right or benefit, substantive or procedural, enforceable at law by a party against the United States, its agencies, its officers, or any person. |
| The United States and the Department of the Treasury will not be responsible in any manner or to any extent for any negligent or otherwise tortious acts or omissions on the part of any Treasury Department employee engaged in any _pro bono_ or volunteer activity. While the Treasury Department permits _pro bono_ and volunteer activities by its employees, it exercises no control over the services and activities of employees engaged in _pro bono_ or volunteer activities, nor does it control the time or location of any _pro bono_ or volunteer activity. Each employee is acting outside the scope of his or her employment whenever the employee participates, supports, or joins in any _pro bono_ or volunteer activity. |
| **IX. Effective Date, Duration and Cancellation.** |
| This policy statement is effective April 18, 2002. It is intended to be read in conjunction with General Counsel Directive No. 6, and not to supplant General Counsel Directive No. 6. It remains in effect until superseded. All previous delegations in conflict with the provisions herein are hereby superseded. |
| David D. Aufhauser <br>General Counsel |

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part30/irm_30-002-002#addtoany "Show all")

A2A