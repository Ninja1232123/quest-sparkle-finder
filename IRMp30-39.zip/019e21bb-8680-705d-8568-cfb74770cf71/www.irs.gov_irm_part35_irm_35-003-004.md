---
url: "https://www.irs.gov/irm/part35/irm_35-003-004"
title: "35.3.4 Motions Pertaining to Calendared Cases | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-003-004#main-content)

- 35.3.4 [Motions Pertaining to Calendared Cases](https://www.irs.gov/irm/part35/irm_35-003-004#idm140407497368048)
  - 35.3.4.1 [Motions Presented at Calendar Call](https://www.irs.gov/irm/part35/irm_35-003-004#idm140407497367616)
  - 35.3.4.2 [Continuances From Trial Date](https://www.irs.gov/irm/part35/irm_35-003-004#idm140407497362928)
  - 35.3.4.3 [Continuances for Settlement Purposes](https://www.irs.gov/irm/part35/irm_35-003-004#idm140407497313312)
  - 35.3.4.4 [Motion to Calendar for Trial](https://www.irs.gov/irm/part35/irm_35-003-004#idm140407497304944)
  - 35.3.4.5 [Motion for Default or Dismissal](https://www.irs.gov/irm/part35/irm_35-003-004#idm140407497269120)
  - 35.3.4.6 [Motion for Pretrial Conference](https://www.irs.gov/irm/part35/irm_35-003-004#idm140407497256432)
  - 35.3.4.7 [Motion to Compel Stipulation Under Tax Court Rule 91(f)](https://www.irs.gov/irm/part35/irm_35-003-004#idm140407497245216)

# Part 35. Tax Court Litigation

# Chapter 3. Motions

# Section 4. Motions Pertaining to Calendared Cases

* * *

## 35.3.4 Motions Pertaining to Calendared Cases

**35.3.4.1** **(08-11-2004)**

### Motions Presented at Calendar Call

1. After the parties have entered their appearances at calendar call, often preliminary motions are made by either party. Motions for continuance are sometimes argued at this time. When it is anticipated that petitioner’s representative will file a motion for continuance, and after consultation with the reviewer, the Field attorney is instructed to oppose the motion, the attorney in opposition to the motion should present the record of any prior continuances of the case along with all other arguments and material which support his/her argument. Motions which will require considerable time for their presentation and argument or which relate to the substance of the case should be mentioned to the court in a telephone conference or other joint communication so that in arranging the calendar the court may set them for hearing when it deems appropriate. Motions pertaining to the pleadings, jurisdiction, etc., which should have been made at an earlier time must be presented and disposed of when the case is called for trial.


**35.3.4.2** **(08-11-2004)**

### Continuances From Trial Date

1. Continuances of cases set for trial should be held to a minimum. _See_ Exhibits 35.11.1–50 and 35.11.1–51. The Field attorney and reviewer should manage the cases in inventory in such a manner that cases appearing upon calendars have been adequately prepared both legally and factually, complying with the procedures outlined in Rev. Proc. 87–24 for early development and disposition of the cases assigned by either settlement or trial. For those cases in which it is known at the time of the receipt of the calendar that it is unlikely that the case can be tried, an immediate motion for continuance, and hearing by telephone with the trial judge if agreeable to opposing counsel, should be considered. Time expended on calendared cases should not be dissipated through continuance unless the continuance is supported by good and sufficient reasons that arise between the time of the calendaring of the case and the time the case is set for trial. In responding to petitioner’s motion to continue, the Field attorney should employ judgment in determining whether the case is one which truly warrants a continuance. If not, a motion should be opposed on the merits and should not be predicated upon any broadly stated policy opposing continuances.

2. If the basis for the motion to continue is the fact that related cases are pending which may resolve the issue, such allegations should be specific. Will the parties accept the decision in the other case; is the Service looking for a split in these circuits for potential appeal, etc. If the parties will accept the other case as being dispositive, consideration should then be given as to which case will most effectively present the position of the respondent, and which forum is better. The fact that there is another case pending should not automatically be accepted as a basis for a continuance. If the basis for continuance is conflicting court appearances, consideration should be given to arranging for a specific trial time that can accommodate the petitioner’s schedule. Continuances based upon doctor’s certificates for the petitioner or witnesses should be closely examined to determine whether the petitioner or the witnesses are physically unable to appear in court and whether a deposition will be sufficient. In appropriate instances, the trial judge may be requested to call the petitioner’s or witnesses’ doctor to court to further explain the reasons for the doctor’s certificate or the court may be requested to order the petitioner or the witness to be examined by a physician designated by the court.

3. It is the general policy of the office to move cases expeditiously and to oppose petitioners’ unsupported motions for continuance from the trial session. The Field attorney should not advise the petitioner of his concurrence in the continuance without having first discussed the matter with the reviewer and establishing a firm position of the office.

4. If it is necessary for respondent to file a motion to continue a case from a trial calendar, an endorsement by petitioner’s counsel agreeing to the motion should be obtained when feasible. When it is not feasible to obtain an endorsement, but petitioner’s counsel has agreed with it or does not oppose its granting, this fact should be contained in the motion. If petitioner’s counsel will oppose the motion for continuance, the court should be advised of that fact when the motion is filed. Care should be exercised in not waiting any longer than necessary to move for a continuance after the trial notice has been issued. Under T.C. Rule 133 a motion for continuance filed 30 days or less before the trial calendar will ordinarily be deemed dilatory and will be denied unless the ground for continuance arose during the 30 days before trial or there was a good reason for not moving sooner.


**35.3.4.3** **(08-11-2004)**

### Continuances for Settlement Purposes

1. In any instance in which either party advises the court that a stipulation of settlement is being prepared or that a basis of settlement has been agreed upon but the settlement documents cannot be prepared in time to be filed by the conclusion of the trial session, the court will generally retain jurisdiction and set a date for the filing of stipulated decision documents. At least 90 days should be initially requested for filing the settlement documents. For cases which are to be submitted to the Joint Committee on Taxation, it is advisable to request the court to fix a six-month period, or more if necessary, rather than the 90-day period, for the filing of the settlement documents. Whenever any case is reported as settled and the basis of settlement is described to the court, the Field attorney and his reviewer should make sure that appropriate steps are taken to order a transcript of the proceedings.

2. The court must not be requested to continue a case for filing the settlement stipulation unless a basis of settlement has been reached by all parties and the only remaining action to be taken is the administrative processing of the case, such as making the necessary computations, preparing the settlement stipulation, or processing the case to the Joint Committee on Taxation. A case should not be continued merely for the purpose of permitting the parties to continue or to complete settlement negotiations.

3. Field Counsel has the sole responsibility of assuring that the settlement documents are received by the Tax Court on or before the date specified in the court’s order, or filing with the Tax Court not later than two weeks before the due date a Motion to Extend Time for Filing Decision Documents. The motion should set forth briefly the status of the settlement documents. The court should be requested in the motion to continue the case to a specific date, and the grounds should be stated in the request. If the delay in filing the settlement documents is due to inability to secure a transcript of account or other action within the control of the Service, such fact should be pointed out, the circumstances fully explained. A joint motion stating the status of settlement is preferable.


**35.3.4.4** **(08-11-2004)**

### Motion to Calendar for Trial

1. Since the Tax Court calendars cases for trial when they are at issue, taking into consideration the court’s travel schedule and courtroom availability, a motion to calendar a case for trial out of order must be for strong and compelling reasons. These types of motions are usually filed in situations in which the parties desire:



   - An early trial

   - That the case be set for a particular trial session, either proposed or announced by the court

   - A special trial session

   - To set for trial a noncalendared case which is related to a calendared case


### Note:

_See_ Exhibit 35.11.1–52. The caption of the motion in consolidated cases should list the various petitioners and their docket numbers in numerical order beginning with the earliest docket number. _See_ CCDM 35.3.9.5(4).

2. Motions to calendar cases for a special session are filed in cases that cannot be conveniently tried on a regularly scheduled Tax Court trial calendar due to the estimated extended trial time of the case. In such a case it is desirable to file a motion to calendar at a special setting at the earliest reasonable time. The court usually will not set a case for a special session unless the estimated trial time of the parties exceeds 20 hours and this estimate is supported by specific allegations in the motion.

3. Motions to calendar should always be filed when part of a group of related cases have been set for trial, but the remaining cases in the group have been omitted from the trial calendar. Such a motion should be filed as soon as possible after the issuance of the trial calendar and, when possible, it should be an agreed motion. A single motion to calendar and consolidate may be filed for the entire group of cases if appropriate in this situation. In addition, a motion to calendar and consolidate, or in the alternative to continue, may be filed if it is expected that the additional cases on the calendar may add significant trial time to the session. Motions of this type are to include every case in the proposed consolidated group as if it were an initial motion to consolidate, and include the consolidation form of caption and all docket numbers of the cases listed in numerical order beginning with the earliest case. Additional copies of the motion should be submitted for each additional docket number. Every motion to calendar cases for trial should set forth the grounds on which the motion should be granted. Also, the motion must specifically set forth a realistic estimated trial time. It is particularly important that the court be informed in the motion whether the addition of cases to the group already set will add any additional trial time to the group as a whole and, if so, the number of hours.

4. A motion to calendar should be considered for any case which was previously reported to the court as settled and for which decision documents have been ordered, but for some reason settlement efforts have stopped.


**35.3.4.5** **(08-11-2004)**

### Motion for Default or Dismissal

1. Tax Court Rule 123 provides that if any party has failed to plead or otherwise proceed as provided by the rules, or as required by the court, a motion would be proper to have a decision entered against the defaulting party. The court may take other action as provided in T.C. Rule 123.

2. When a case is called at the calendar call for assignment of the time and date of trial and there is no appearance on behalf of the petitioner, a motion in the form of a motion to dismiss for lack of prosecution should be made by the Field attorney, unless circumstances exist making such a motion inappropriate, for example, a disability preventing petitioner from appearing. Usually these are oral motions made at calendar call; however, if it is known or anticipated in advance of calendar call that the petitioner or petitioner’s attorney will not appear, a written motion to dismiss for lack of prosecution should be prepared. _See_ Exhibit 35.11.1–48.

3. The motion to dismiss for lack of prosecution should embody the following essential facts: first, that there is no appearance on behalf of the petitioner; second, if possible, that the respondent has informed petitioner of the consequences of nonappearance; and third, that all or some (as the case may be) of the material allegations of fact alleged in the petition have been denied in the answer. The motion should then request that the court dismiss the case for lack of prosecution and find in its order that there is a deficiency in tax (and penalties, if applicable) due from the petitioner for the taxable year(s) in the amounts shown in the statutory notice of deficiency or redetermined in a computation filed with the court at that time or later with a written motion. In nondeficiency cases, the court should be requested to sustain the determination of the Commissioner and enter a decision ordering the appropriate relief, such as a declaratory judgment in favor of the respondent or a decision sustaining the Commissioner’s determination made in a spousal relief, interest abatement, or collection due process case. In making this motion it is essential that the court have a correct copy of the statutory notice of deficiency or other determination letter, or recomputation of the deficiency or liability upon which the dismissal order is to be based.

4. In case in which respondent bears the burden of proof or burden of production, a motion for default judgment should be filed in lieu of a motion to dismiss for failure to properly prosecute. The motion should request that the allegations in the answer in support of respondent’s burden be deemed admitted and that judgment be entered in favor of respondent. _See Smith v. Commissioner_, 91 T.C. 1049 (1988). In a small tax case in which no answer has been filed, the motion for default judgment should contain affirmative allegations of fact on which respondent bears the burden of production, and attach any documentary evidence, such as a certified transcript of account, in support of such allegations. Guidance on the filing of motions for default judgment in cases on which respondent bears the burden of proof or production may be obtained from APJP, Branch 3.


**35.3.4.6** **(08-11-2004)**

### Motion for Pretrial Conference

1. A motion for pretrial conference under T.C. Rule 110 can be used for the purpose of narrowing issues, producing records, stipulating facts, simplifying the presentation of evidence or otherwise assisting the preparation for trial or possible disposition of the case, in whole or in part, without trial. Such a motion may be filed at any time, but normally will be filed only after the case is at issue and before commencement of trial. For form and content, _see_ Exhibit 35.11.1–53. This motion is rarely filed, but may be considered in unusual cases when assistance of the court to resolve an impasse in trial preparation may be necessary or desirable, and a scheduled trial calendar or motions session is available at which to conduct such a pretrial conference.

2. In most cases, other procedural devices obviate the need for formal pretrial conferences under Rule 110. These include Rule 91(f) motions to compel stipulation, discovery and sanctions motions, and the nonparty deposition procedures available under the court’s rules. In addition, the use of telephone conferences and informal requests at the calendar call for chambers conferences will often assist in resolving difficulties in trial presentation or in further settlement negotiations. The court, in its discretion, may on its own motion order a pretrial conference in an attempt to encourage the parties to settle the case or enter into a more comprehensive stipulation of facts.

3. Where a pretrial conference is requested for assistance of the court in stipulating facts or simplifying the presentation of evidence, it may be desirable in complex or important cases to issue a subpoena requiring the production of documents or records at the hearing, particularly from third parties from whom discovery is restricted. This, of course, cannot be issued until the court has ordered the hearing and specified the time and place. In such situations, the Field attorney must be prepared to explain why the normal discovery and third-party deposition rules were not sufficient to achieve the objectives of a subpoena issued in connection with a pretrial conference.

4. If the Field attorney wishes to obtain a formal record of all positions taken at the pretrial conference, it should be requested that the conference be conducted on the record. This is a matter for the discretion of the reviewer, since the presence of a reporter may affect the character of such a conference. In any event, it is important that rulings made and agreements reached during the pretrial conference should be formalized by a written stipulation, entry of a written order, or oral statements upon the record.

5. In lieu of formal pretrial conferences, many Tax Court judges conduct conference calls with the parties in order to resolve differences and promote stipulation. Of course, these calls are usually not on the record, but may result in encouraging settlement or proper preparation for trial without waiting until the trial judge arrives for the trial session. The Field attorney and reviewer are encouraged to consider this option as early as possible after the trial notice has been issued.


**35.3.4.7** **(08-11-2004)**

### Motion to Compel Stipulation Under Tax Court Rule 91(f)

1. When petitioner or counsel refuses to stipulate facts and evidence that should not be in dispute, a motion to show cause why proposed facts and evidence cannot be established should be considered. The T.C. Rule 91(f) motion cannot be filed before the trial notice has been issued (usually at least 5 months before the scheduled session in regular cases) nor less than 45 days before the date set for call of the case on a trial calendar. Motions should never be filed under this rule as an attempt to determine petitioner’s litigating position. If the petition is so vague or ambiguous that respondent cannot determine the issues contested, the discovery rules (T.C. Rules 70–75) should be utilized. Consideration should always be given to the use of requests for admission in lieu of the cumbersome procedures provided under T.C. Rule 91(f).

2. For a motion under T.C. Rule 91(f) to be used within the strict time limitations imposed, it is necessary that stipulation of fact conferences be held or sought early in the life of the case, particularly in cases that can be identified as probable trials.

3. The facts sought to be accepted must be based on competent evidence. The requirements of the rule concerning the setting forth of the facts sought to be accepted as evidence and listing of the source and location of such evidence should be fully met. All information of the type contained in the sample motion in Exhibit 35.11.1–54, which might impel the court to grant our motion in the event counsel for petitioner files an unsatisfactory response or no response at all, should be set forth.

4. The content of the stipulation sought by use of this motion should be carefully considered. The proposed stipulation filed with the motion to compel should be comprehensive and satisfy the requirements of Rule 91 as to form and content. The motion should request the court to issue an order designating the facts and evidence set forth in the proposed stipulation deemed established for purposes of the case.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-003-004#addtoany "Show all")

A2A