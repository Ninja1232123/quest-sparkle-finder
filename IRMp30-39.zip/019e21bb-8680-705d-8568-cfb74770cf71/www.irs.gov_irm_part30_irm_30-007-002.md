---
url: "https://www.irs.gov/irm/part30/irm_30-007-002"
title: "30.7.2 Research and Management Information | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part30/irm_30-007-002#main-content)

- 30.7.2 [Research and Management Information](https://www.irs.gov/irm/part30/irm_30-007-002#idm139658735724752)
  - 30.7.2.1 [Introduction to Research Services and Management Information](https://www.irs.gov/irm/part30/irm_30-007-002#idm139658743867616)
  - 30.7.2.2 [Electronic Research Services](https://www.irs.gov/irm/part30/irm_30-007-002#idm139658738287280)
  - 30.7.2.3 [Chief Counsel Quarterly (CCQ)](https://www.irs.gov/irm/part30/irm_30-007-002#idm139658741498768)
  - 30.7.2.4 [Surveys](https://www.irs.gov/irm/part30/irm_30-007-002#idm139658742673840)

# Part 30. Administrative

# Chapter 7. Management Systems

# Section 2. Research and Management Information

* * *

## 30.7.2 Research and Management Information

#### Manual Transmittal

November 30, 2012

#### Purpose

(1) This transmits revised CCDM 30.7.2, Management Systems; Research and Management Information.

#### Material Changes

(1) Material on electronic research services that had been contained in CCDM 30.7.2.2 and Exhibit 30.7.2-1 was relocated to CCDM 30.8.1.5 on November 9, 2012.

#### Effect on Other Documents

CCDM 30.7.2 dated May 15, 2012 is superseded.

#### Audience

Chief Counsel

#### Effective Date

(11-30-2012)

Michael T. Cochis

Director, Planning and Management Division

**30.7.2.1** **(11-30-2012)**

### Introduction to Research Services and Management Information

1. This section establishes policy and procedures for the Chief Counsel Quarterly report and the Survey Program.


**30.7.2.2** **(11-30-2012)**

### Electronic Research Services

1. For information on electronic research services see CCDM 30.8.1.5, Counsel Library Services; Electronic Research Services.


**30.7.2.3** **(05-15-2012)**

### Chief Counsel Quarterly (CCQ)

1. The Chief Counsel Quarterly(CCQ) is the Office of Chief Counsel’s time and workload compendium. The CCQ shows receipts, closures, and ending inventory by established categories of work called aliases for all organizational levels. The CCQ also provides time reporting information for executives, managers, attorneys, paralegals, and other professionals. The CCQ provides data in both numerical and graphical form and serves a variety of internal information needs of the Office including:



   - Workload management

   - Budget requests and justifications

   - Program and product costing and strategic planning

   - Program evaluation

   - Trends analyses

   - IRS Data Book and other annual workload reports

   - Staffing

   - Ad hoc requests


2. The CCQ is produced on a quarterly, fiscal year basis by the Planning and Management Division of the Associate Chief Counsel (Finance and Management). The CCQ is published on the Chief Counsel intranet no later than 45 days after the close of each quarter of the fiscal year.

3. Archived reports for recent past fiscal years are available on the intranet; older reports are available upon request from the Planning and Management Division.


**30.7.2.4** **(05-15-2012)**

### Surveys

1. The Associate Chief Counsel (Finance and Management), through the Planning and Management Division, coordinates and conducts customer and employee satisfaction surveys. The Survey Program helps to determine how well the Office meets or exceeds the reasonable expectations of its internal and external customers as well as its employees. Data gathered and analyzed by the program is used for a wide range of purposes, including evaluating programs and work products, assessing the effectiveness of information systems and administrative services, and acquiring a plethora of information about the workplace and employees.

2. [Executive Order 12862 PDF](http://www.archives.gov/federal-register/executive-orders/pdf/12862.pdf), Setting Customer Service Standards (September 11, 1993), required agencies to "survey customers to determine the kind and quality of services they want and their level of satisfaction with existing services." In response, the Assistance in Survey Coordination Program, now referred to as the Survey Program, was implemented that year. Key Survey Program responsibilities include:



   - Ensure effective coordination with the IRS and contractors as well as with other Federal Agencies for surveys that affect parties external to the Treasury Department

   - Develop and administer surveys to populations external and internal to Counsel

   - Gather data and analyze survey results

   - Prepare reports and presentations on survey data

   - Recommend improvements to existing Counsel management systems based on analysis

   - Provide a central reference point for Counsel survey information


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part30/irm_30-007-002#addtoany "Show all")

A2A