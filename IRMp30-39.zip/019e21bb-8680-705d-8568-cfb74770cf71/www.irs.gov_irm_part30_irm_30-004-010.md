---
url: "https://www.irs.gov/irm/part30/irm_30-004-010"
title: "30.4.10 Administrative Grievance Procedures | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part30/irm_30-004-010#main-content)

- 30.4.10  [Administrative Grievance Procedures](https://www.irs.gov/irm/part30/irm_30-004-010#id1)
  - 30.4.10.1  [Introduction](https://www.irs.gov/irm/part30/irm_30-004-010#id2)
  - 30.4.10.2  [Definitions](https://www.irs.gov/irm/part30/irm_30-004-010#id3)
  - 30.4.10.3  [Actions Not Covered](https://www.irs.gov/irm/part30/irm_30-004-010#id4)
  - 30.4.10.4  [General Instructions](https://www.irs.gov/irm/part30/irm_30-004-010#id5)
  - 30.4.10.5  [Informal Grievance](https://www.irs.gov/irm/part30/irm_30-004-010#id6)
    - 30.4.10.5.1  [Processing the Informal Grievance](https://www.irs.gov/irm/part30/irm_30-004-010#id8)
  - 30.4.10.6  [Formal Grievance](https://www.irs.gov/irm/part30/irm_30-004-010#id9)
    - 30.4.10.6.1  [Processing the Formal Grievance](https://www.irs.gov/irm/part30/irm_30-004-010#id11)
    - 30.4.10.6.2  [Fact-Finding](https://www.irs.gov/irm/part30/irm_30-004-010#id12)
    - 30.4.10.6.3  [Decision](https://www.irs.gov/irm/part30/irm_30-004-010#id13)
    - 30.4.10.6.4  [Time Limits](https://www.irs.gov/irm/part30/irm_30-004-010#id14)
    - 30.4.10.6.5  [Cancellation](https://www.irs.gov/irm/part30/irm_30-004-010#id15)

# Part 30. Chief Counsel Directives Manual Administrative

# Chapter 4. Personnel Administration, Training, and Equal Employment Opportunity

# Section 10. Administrative Grievance Procedures

* * *

## 30.4.10 Administrative Grievance Procedures

#### Manual Transmittal

December 05, 2025

#### Purpose

(1) This transmits reinstated CCDM 30.4.10, Administrative Grievance Procedures.

#### Material Changes

(1) CCDM Parts 30.4.10 have been reinstated to provide current administrative grievance policy for the Office of Chief Counsel.

#### Effect on Other Documents

None

#### Audience

Chief Counsel

#### Effective Date

(12-05-2025)

Edith M. Shine

Associate Chief Counsel

Finance and Management

**30.4.10.1** **(12-05-2025)**

### Introduction

1. This policy contains instructions for the timely and equitable consideration of employee grievances throughout the Office of Chief Counsel (Office). This process applies to all grievances not covered by a negotiated grievance procedure in an applicable collective bargaining agreement, subject only to exceptions that may be made by the Associate Chief Counsel, Finance & Management. This guidance is authorized by 5 CFR § 771.

2. In any human relationship, differences will inevitably arise, even under the most favorable conditions. A grievance system provides a means of resolving these differences. The primary objective of all parties using this grievance procedure should be problem-solving rather than establishing fault. To this end, aggrieved employees must utilize the informal procedure as set forth below. Only after informal means of resolving the grievance are exhausted may an employee resort to the formal procedure also set forth below.


**30.4.10.2** **(12-05-2025)**

### Definitions

1. The following definitions apply to the terms used in these procedures.



1. **Agency** is the Office of Chief Counsel, Internal Revenue Service.

2. **Days** means calendar days unless stated otherwise.

3. **Deciding****Official** is the management official designated to issue the formal decision on the grievance. The deciding official shall be at an administrative level higher than any official who could have adjusted or was involved in the grievance under the informal procedure.

4. **Fact-finding** means the process by which a fact-finder makes findings of facts, as requested by the deciding official, related to the matter being grieved. Fact-finding shall be conducted by a person or persons who have not been involved in the matter being grieved and who does not occupy a position that is directly subordinate organizationally to an official who has been involved in the grievance.

5. **Grievance** is a request by an employee for personal relief in a matter of concern or dissatisfaction which: (1) relates to the employment of the employee; (2) is subject to the control of agency management; and (3) does not involve a matter specifically excluded from the grievance procedure.

6. **Grievance File** means a separate, indexed file, identified by case number, which must be established for all grievances, containing all documents related to the grievance. This includes, but is not limited to: the original grievance, any statements of witnesses or summaries of statements (summaries of statements should be signed by the person(s) interviewed), records or copies thereof, report of findings, reasons for the determination made by the deciding official, and the final decision.

7. **Representative** is any person designated by an employee to assist, or to act for, that employee in the presentation of the grievance.

8. **Resolution Official** means the management official designated to issue the informal decision on the grievance. In most cases this will be the employee’s first line of supervision. However, in all cases, the informal grievance should be presented to an official who has the authority to grant an employee’s requested appropriate relief.


**30.4.10.3** **(12-05-2025)**

### Actions Not Covered

1. This policy applies to any matter of concern or dissatisfaction relating to the employment of an employee which is subject to the control of agency management, including any matter in which an employee alleges that coercion, reprisal, or retaliation has been practiced against him/her.

2. Actions Not Covered:



01. The content of published Treasury and Counsel regulations and policy;

02. A decision which is:



       > 1. appealable to the Merit Systems Protection Board
       >
       >        2. subject to final administrative review by the Office of Personnel Management or the Equal Employment Opportunity Commission under law or regulations of the Office or Commission; or
       >
       >        3. administrated by the General Accountability Office, the Office of Workers; Compensation Programs and/or any other Federal agency;

03. Non-selection for promotion from a group of properly ranked and certified candidates;

04. A preliminary warning or notice of a proposed action, which, if effected, would itself be covered under the grievance system;

05. A return of a career appointee from the Senior Executive Service to General Schedule or another pay system during the period of probation or for less than fully successful performance under; 5 USC § 3592

06. An action that terminates a temporary promotion and returns the employee to the position from which the employee was temporarily promoted, or reassigns or demotes the employee to a different position that is not at a lower grade or pay than the position from which the employee was temporarily promoted;

07. A reassignment of a Senior Executive Service appointee following the appointee's receipt of an unsatisfactory rating under 5 USC § 4314;

08. The termination under 5 CFR § 359 of an SES career appointee during probation for unsatisfactory performance;

09. An action taken in accordance with the terms of a formal agreement voluntarily entered into by an employee which (a) assigns the employee from one geographical location to another or returns an employee from an overseas assignment;

10. An action that terminates a temporary promotion at the completion of the project or specified period and returns the employee to the position from which promoted or to a different position of equivalent grade and pay in accordance with 5 CFR § 335.102(f)

11. The substance of the critical elements and performance standards of an employee's position which have been established in accordance with the requirements 5 USC Chapter 43 and 5 CFR § 430 (the application of the critical elements and performance standards is a grievable matter);

12. The granting of or failure to grant an employee performance award or the adoption of or failure to adopt an employee suggestion or invention under 5 USC § 4503-4505;

13. The granting of or failure to grant an award of the rank of meritorious or distinguished executive under 5 USC § 4507, which includes negative decisions as well as positive ones;

14. The receipt of or failure to receive a performance award under 5 USC § 5384 which includes negative decisions as well as positive ones;

15. The receipt or failure to receive a quality step increase under 5 USC § 5336 which includes negative decisions as well as positive ones;

16. A merit-based pay determination or a merit-based pay increase or the lack of a merit-based pay increase, or a decision on the granting of or failure to grant cash awards or honorary recognition under 5 USC Chapter 54, and 5 CFR § 451.

17. The termination under 5 CFR § 315, Subpart H of a competitive service probationary employee, or an excepted service employee in his or her trial period, for unsatisfactory performance;

18. An executive performance evaluation under 5 USC Chapter 43, Subchapter II (performance appraisal in the Senior Executive Service);

19. A separation action; however, this exclusion shall not apply to the termination of a competitive service employee in their probationary period for misconduct or of an excepted service employee in their trial period for misconduct or a supervisor or manager being returned to their non-supervisory or non-managerial position for failure to satisfactorily complete the probationary period as per 5 CFR § 315, Subpart I; and,

20. Separation of a non-preference eligible employee in the excepted service.


**30.4.10.4** **(12-05-2025)**

### General Instructions

1. The Office’s Labor and Employee Relations Division (LER) will provide counseling for employees and management officials on grievance procedures and assist employees and supervisors in determining the grievability of an issue.

2. An employee and their designated representative will be free from restraint, interference, coercion, discrimination or reprisal in presenting a grievance.

3. In presenting a grievance, each employee is entitled to be accompanied and represented by a representative of their own choosing. However, no employee may designate as their representative any employee if representation by that employee would create either a conflict of interest or position, would unduly interrupt the work of the office, or would give rise to unreasonable costs to the Government. Any question regarding the existence of a conflict of interest or position will be resolved by the Director of LER.

4. An employee shall be given a reasonable amount of official time to present the grievance if they are otherwise in an active-duty status in the Office. An employee’s representative, if they are an employee of Treasury, shall be given a reasonable amount of official time to present a grievance, but no official time will be provided for the representative to prepare for presenting the grievance. Supervisors also may limit the amount of official time for presentation of a grievance.

5. LER will maintain a grievance file containing all relevant documents which pertain to the grievance. The file will be opened at the outset of the formal grievance procedure.


**30.4.10.5** **(12-05-2025)**

### Informal Grievance

1. An employee must follow the informal grievance procedure before a grievance concerning the same matter will be accepted for processing under the formal grievance procedure.

2. An employee may present a grievance concerning a continuing practice or condition at any time. An employee shall present a grievance concerning a particular act or occurrence within fifteen (15) days of the date of that act or occurrence, or within fifteen (15) days of the date he/she became aware of that act or occurrence. If an employee wants to grieve over an act or occurrence that occurred more than 15 days in the past, they may attempt to explain why they did not file the grievance within fifteen (15) days after the act or occurrence which gave rise to the grievance. A grievance will not be accepted if it is determined that through normal diligence the employee could have learned of the act or occurrence within fifteen (15) days after it took place.

3. The grievance must be presented in writing.

4. The grievant must identify the issues involved in the grievance and the relief requested.

5. The grievant must present any and all evidence or information in their possession which will assist in resolving the grievance.

6. In no event does the filing of an informal or formal grievance absolve an employee from the responsibility of following their supervisor’s instructions, even though the instructions are the subject of or related to the grievance.


**30.4.10.5.1** **(12-05-2025)**

#### Processing the Informal Grievance

1. In every grievance, the employee will first inform the resolution official of their concern or dissatisfaction.

2. The resolution official and the employee will discuss the concern or dissatisfaction and attempt to reach a mutually satisfactory solution. However, when a grievance involves a matter not within the authority of the employee’s immediate supervisor to resolve, the supervisor shall direct the employee to the lowest level of management with the authority to resolve the grievance, and the grievance shall be presented to this official under the informal procedure. If the immediate supervisor has any questions concerning who has the authority to resolve the employee’s grievance, the supervisor should contact the Director of LER for advice.

3. A written response from the resolution official will be issued to the employee, regardless of whether the personal relief requested was granted or denied.

4. A written response will contain:



1. what the employee expressed as the cause of the dissatisfaction;

2. the relief requested;

3. what the resolution official perceives as the cause of the dissatisfaction and whether the relief sought should be granted;

4. whether the grievance is covered by this grievance procedure;

5. a statement to the effect that the written response constitutes completion of the informal procedure;

6. written response must be sent to the grievant via email or hand-delivered to the grievant. The grievant must acknowledge receipt of the written response in writing if the response is hand-delivered;

7. identification of the deciding official to whom the formal grievance is to be submitted (in most cases, the next level of management above the immediate supervisor or official who handled the informal grievance); and

8. the requirements of presenting a formal grievance.


5. If there is a question as to whether the matter may be grieved, it will be referred to the Director of LER for a final determination on grievability.

6. A copy of the written response should be forwarded to LER within two (2) days of issuance to the grievant.


**30.4.10.6** **(12-05-2025)**

### Formal Grievance

1. An employee is entitled to present a grievance under the formal procedure if: (1) the employee completed the informal procedure; and (2) presents the grievance within seven (7) days after receipt of the written response from the resolution official.

2. The grievance must:



1. be in writing;

2. contain sufficient detail to identify the specific issues which form the grievance;

3. identify the personal relief request by the employee; and

4. contain only issues which were raised at the informal level.


**30.4.10.6.1** **(12-05-2025)**

#### Processing the Formal Grievance

1. The employee will file the formal grievance with the deciding official specified in the written response to the informal grievance. The deciding official will review the grievance and make a determination on the following:



1. **Timeliness.** Failure to comply with the time limits established under this guidance may be grounds for rejection of a grievance. Untimely grievances will be rejected unless the employee submits acceptable justification for the delay, as determined by the deciding official.

2. **Grievance completeness.** The grievance must provide complete and specific information which will enable the deciding official to understand the employee’s grievance concerns, what the employee expects as a specific, personal remedy, and why the subject actions are being grieved. Failure by the employee to request proper personal relief or to furnish, upon request, additional sufficient detail to clearly identify the matter being grieved may be reason for denying a grievance.


**30.4.10.6.2** **(12-05-2025)**

#### Fact-Finding

1. The deciding official, at their discretion, may appoint a fact-finder prior to issuing a final decision. Fact-finding may be used when there is conflicting evidence causing a dispute over facts which, on their face, would be necessary to resolve a particular grievance, or when the deciding official believes that a fact-finder would assist them in reaching an equitable decision. Appointment of a fact-finder may be made at any time prior to the issuance of the decision.

2. The fact-finder will not be under the same chain of command either directly or indirectly, of the deciding official or of an official involved in the grievance. Moreover, the fact-finder will have broad discretion to use a variety of techniques designed to provide the fact-finder with all relevant facts and evidence.

3. The fact-finder will conduct an inquiry of a nature and scope appropriate to the issues involved in the grievance.

4. The fact-finder shall provide to LER all documents relating to the grievance, including the statements of witnesses and records or copies thereof. LER will be responsible for ensuring that documents relating to the grievance are enclosed in the grievance file. The fact-finder may not keep a copy of any documents relating to the fact-finding.

5. The fact-finder shall prepare a Report of Findings and submit it to the deciding official. The fact-finder will not make a determination or recommendation. The role of the fact-finder is to conduct an inquiry and collect the facts. The Report of Findings shall, at the very least, contain the following:



1. a brief statement of the issue(s) in dispute;

2. a description of the opposing and supporting points of view; and

3. a summary of the evidence and facts collecting during the fact-finding.


**30.4.10.6.3** **(12-05-2025)**

#### Decision

1. Whether through use of fact-finding or upon personal review of the grievance, the deciding official is responsible for making a final decision on the grievance that is supported by the facts.

2. The grievance decision should be issued within thirty (30) days after the deciding official first receives the grievance. In the event of the use of fact-finding, the deciding official may direct additional fact-finding be conducted if they determine that an initial report of fact-finding is insufficient or inadequate. In such cases, the grievant shall be informed of that determination, the type of additional inquiry that is to be made, and the approximate date the decision will be issued, normally within sixty (60) days after the deciding official first receives the grievance.

3. The decision shall consist of the following parts:



1. a brief statement of the issues, including a description of the matters that the grievant alleges to have been unfair and the personal relief requested;

2. a summary of findings for any relevant facts that were in dispute, if any;

3. a discussion of the applicable agency regulations or policy; and

4. a conclusion that specifically states what personal relief, if any, is to be granted.


4. The grievance decision shall be emailed or hand-delivered to the appropriate management official who was responsible for or took the action being grieved and to the grievant or the grievant’s representative, including a copy for the grievant. A copy shall also be included in the grievance file.


**30.4.10.6.4** **(12-05-2025)**

#### Time Limits

1. Each grievance shall be given full, impartial and prompt consideration and the decision on a grievance should normally be issued within ninety (90) days after initiation of the informal procedure.

2. Extension of time limit should be granted if there is mutual consent. Only the requirement to present a formal grievance no later than seven (7) days after receipt of the informal grievance written response from the resolution official is mandatory.

3. Failure to meet the time limits by the Office will not be grounds for a favorable resolution of the grievance.


**30.4.10.6.5** **(12-05-2025)**

#### Cancellation

1. The Office shall cancel a grievance:



1. at the employee’s request;

2. upon termination of the employee’s employment with the Office, unless the personal relief sought by the employee may be granted after termination of their employment;

3. upon the death of an employee unless the grievance involved a question or pay; or

4. for failure to prosecute if the employee does not furnish required information and duly proceed with the advancement of his or her grievance;

5. if it is determined to be non-grievable by the Director of LER; or

6. if it is untimely filed.


2. A copy of the notice of cancellation shall be included in the grievance file and provided to the grievant.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part30/irm_30-004-010#addtoany "Show all")

A2A