---
url: "https://www.irs.gov/irm/part38/irm_38-002-001"
title: "38.2.1 Administrative Cases | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part38/irm_38-002-001#main-content)

- 38.2.1 [Administrative Cases](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162872258752)
  - 38.2.1.1 [Noncomplex Cases](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162872264720)
  - 38.2.1.2 [Complex Cases](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162887097968)
  - 38.2.1.3 [Processing Administrative Cases](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162887085120)

    - 38.2.1.3.1 [Nonstatute Cases](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162872259968)
    - 38.2.1.3.2 [Statute Cases](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162858384544)
    - 38.2.1.3.3 [Cases Requiring Special Processing](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162852101920)

  - 38.2.1.4 [Taxpayer Conference Procedures](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162887194368)

    - 38.2.1.4.1 [General Authority](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162887098864)
    - 38.2.1.4.2 [Conference Opportunity](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162872292976)
    - 38.2.1.4.3 [Cases Where No Conference will be Held](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162887018368)
    - 38.2.1.4.4 [Conference Procedures in Sensitive Cases](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162887086464)
    - 38.2.1.4.5 [Prompt Scheduling of Conference](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162855933552)
    - 38.2.1.4.6 [Letter Offering a Conference](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162855945664)
    - 38.2.1.4.7 [Persons Recognized as Representatives of Taxpayers](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162864681840)
    - 38.2.1.4.8 [Persons Not Recognized as Taxpayer Representatives](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162864489936)
    - 38.2.1.4.9 [Taxpayer Witnesses](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162840137584)
    - 38.2.1.4.10 [Conference Attendees](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162851245360)
    - 38.2.1.4.11 [Documents Required from the Taxpayers Representatives](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162849084688)
    - 38.2.1.4.12 [Conference Preparation](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162857180448)
    - 38.2.1.4.13 [Joint Conference](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162860330608)
    - 38.2.1.4.14 [Conducting the Conference](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162887100208)
    - 38.2.1.4.15 [Conference Memorandum](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162861625104)

  - 38.2.1.5 [Supplemental Investigations](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162840150848)
  - 38.2.1.6 [Criminal Evaluation Memorandum](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162865470560)

    - 38.2.1.6.1 [Content and Style](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162842108320)

  - 38.2.1.7 [Plea Program Cases](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162840283824)
  - 38.2.1.8 [Release of Information](https://www.irs.gov/irm/part38/irm_38-002-001#idm140162861901440)

# Part 38. Criminal Tax

# Chapter 2. Review of Criminal Tax Cases

# Section 1. Administrative Cases

* * *

## 38.2.1 Administrative Cases

**38.2.1.1** **(08-11-2004)**

### Noncomplex Cases

1. Noncomplex cases are those in which the tax liability or unreported income is established by the specific items method of proof, the appropriate amount of yearly additional tax for criminal purposes is met for each year, and only minimal adjustments to Criminal Investigation’s recommended computations are required.

2. Noncomplex cases should be reviewed and evaluated within 45 days of receipt. See CCDM 38.2.1.3.

3. An invitation for a conference will be extended in accordance with CCDM 38.2.1.4.2. Normally, conferences should be scheduled and held within 20 days of receipt of the case to meet the 45-day processing requirement. Delays or extensions of the date of the conference for the convenience of the taxpayer or taxpayer’s representative beyond 20 days should be permitted only if the Criminal Tax attorney and the Special Agent in Charge (SAC) agree that a conference is necessary and will not extend the case completion date beyond the 45-day limit.

4. After reviewing the special agent’s report and exhibits, the Criminal Tax attorney prepares an evaluation memorandum for the SAC that discusses the legal issues and evaluates the prosecution potential of the case.


**38.2.1.2** **(08-11-2004)**

### Complex Cases

1. The existence of one or more of the following factors will preclude the classification of a case as noncomplex:



1. Cases established by an indirect method of proof, such as net worth, bank deposits, percentage mark-up, etc.

2. Cases involving tax shelters

3. Grand jury evaluations

4. Cases recommending a conspiracy charge under 18 U.S.C. § 371

5. Cases involving technically difficult questions regarding the taxability of unreported income or deductibility of expenses, e.g., cases involving IRC § 162(c) deductions, valuation problems, corporate diversions/constructive dividends, etc.

6. Cases involving problematic defenses or jury appeal problems, e.g., solicitation, condonation, voluntary disclosure, and dual prosecution, notwithstanding a determination that the evidence adequately rebuts the defense

7. Cases likely to generate significant local, regional, or national publicity because of the character of the taxpayer, e.g., prominent politicians or nationally known public figures

8. Church/First Amendment issues


2. Complex cases should be reviewed and evaluated within 60 days of receipt. The 60 days for completion of the Criminal Tax attorney’s review can be extended an additional 15 days upon the approval of the Area Counsel (CT). See CCDM 38.2.1.3.1, Nonstatute Cases.

3. An invitation for a conference will be extended in accordance with CCDM 38.2.1.4.2. Normally, conferences should be scheduled and held within 20 days of receipt of the case to meet the 60-day processing requirement. Delays or extensions of the date of the conference for the convenience of the taxpayer or taxpayer’s representative beyond 20 days should be permitted only if the Criminal Tax attorney and the SAC agree that a conference is necessary and will not extend the case completion date beyond the 60-day limit.

4. After reviewing the special agent’s report and exhibits, the Criminal Tax attorney prepares an evaluation memorandum for the SAC that discusses the legal issues and evaluates the prosecution potential of the case.


**38.2.1.3** **(08-11-2004)**

### Processing Administrative Cases

1. The following requirements apply to insure the timely processing of criminal tax cases.


**38.2.1.3.1** **(08-11-2004)**

#### Nonstatute Cases

1. Final action on the prosecution or prosecution-related question shall be taken within 60 days following receipt of the special agent’s report in cases that have no imminent statute of limitations expiration dates. Matters such as the offering of a conference and requesting a supplemental investigation essential to the case should be promptly considered upon receipt of the special agent’s report.


**38.2.1.3.2** **(08-11-2004)**

#### Statute Cases

1. When possible, the Criminal Tax attorney will complete his/her review and submit his/her evaluation of the prosecution and prosecution-related recommendation to the SAC not later than 300 days prior to the expiration of the earliest statute of limitations. For cases where direct referral to the US Attorney is authorized, Counsel will complete the review and submit the evaluation of the prosecution and prosecution-related recommendations to the SAC not later than 155 days prior to expiration of the earliest statute of limitations.

2. Cases with an imminent statute of limitations will first be reviewed from the standpoint of whether the loss of the violation(s) subject to the imminent statute of limitations would materially affect the case. A case may be materially affected by the expiration of the statute of limitations when it pertains to the major and/or critical tax year; e.g., a year with the highest criminal deficiency, a year essential to an indirect method of proof and/or a year impacting upon the standards of prosecutions.

3. Cases where inclusion of the violation(s) subject to the imminent statute of limitations is essential, must be expeditiously referred to the Tax Division or to the US Attorney. If the 210-day (or 65-day) period has expired, the criminal evaluation memorandum must discuss the circumstances warranting inclusion of the violation/year.

4. In the event inclusion of the violation(s) subject to the imminent statute of limitations is not essential to the case, the Criminal Tax attorney should recommend the year be eliminated and the exclusion should be discussed in the criminal evaluation memorandum.


**38.2.1.3.3** **(08-07-2008)**

#### Cases Requiring Special Processing

1. Cases involving the following sensitive individuals and/or issues should be forwarded to the Associate Chief Counsel (Criminal Tax) for review, evaluation, and preparation of the criminal evaluation memorandum:



01. Currently serving elected federal officials, (i.e., Members of Congress)

02. Current Article III judges, (i.e., United States District Court judges)

03. Current high-level Executive Branch officials, (i.e., Cabinet level officials)

04. Currently serving elected statewide officials, (i.e., Governor, Attorney General)

05. Current members of the highest court of a state

06. Currently serving mayors of municipalities having a population in excess of 250,000

07. Cases involving perjury, subornation of perjury, or a false declaration occurring during a United States Tax Court proceeding under 18 USC §§ 1621, 1622, and 1623

08. Tax shelter cases wherein one or more of the recommended charges is a conspiracy charge, _i.e._ 18 USC § 371, based on transactions between the recommended defendants and an IRS agent or controlled informant acting in an undercover capacity

09. Where the proposed target is an IRC § 501(c) or (d) organization

10. Publicly traded companies (defined as companies that have issued securities through an initial public offering and whose shares are traded on the open market)

11. Companies with annual gross revenues exceeding $10,000,000,000.00


2. _IRC § 7215 Cases_. The deterrent effect of an IRC § 7215 prosecution is based upon the potential criminal liability of an individual. In cases where both a corporation and an individual can be liable under IRC § 7215, the Criminal Tax attorney should recommend prosecution against the individual only. Expeditious processing of criminal withholding tax cases is essential to the effectiveness of the trust fund program.



### Note:



Cases involving IRC § 7215 are directly referred by Criminal Investigation to the US Attorney.

3. Whenever the subject of a criminal investigation involved an individual or entity within the purview of TEGE, the SAC should be informed that matter needs coordination with the Division Counsel/Associate Chief Counsel (TEGE). Once the SAC approves, the Criminal Tax attorney should handle the coordination with TEGE.


**38.2.1.4** **(08-11-2004)**

### Taxpayer Conference Procedures

1. Once a case is forwarded by Criminal Investigation to the Criminal Tax attorney for consideration, these taxpayer conference procedures are triggered. The conference should not be a pro forma exercise.

2. The purpose of the conference is to notify the taxpayer and/or representative of the special agent’s prosecution recommendation, explain criminal tax procedures, and provide the taxpayer an opportunity to supply information that may be relevant to the SAC’s ultimate determination of whether to refer the case to the Tax Division.

3. From the taxpayer’s standpoint, the conference provides an opportunity for the taxpayer to be heard by the Service. In this regard, additional evidence and defenses of a technical or policy nature may be presented.

4. _Plea bargaining, civil settlement negotiations, and/or compromise of tax liabilities will not be considered or discussed at the conference._


**38.2.1.4.1** **(08-11-2004)**

#### General Authority

1. Authority for holding conferences with taxpayers and/or their representatives is contained in 26 C.F.R. §§ 601.501-509. These regulations apply to all offices of the Service in all matters under the jurisdiction of the Service and apply to practice before the Service.

2. Taxpayer conferences in criminal tax cases are within the authority and are the responsibility of the SAC. The Criminal Tax attorney is an integral partner in the process and should take an active role in the coordinating, scheduling, and participating in these conferences.


**38.2.1.4.2** **(08-11-2004)**

#### Conference Opportunity

1. While a taxpayer conference is not a matter of right, an invitation for a conference will be extended unless it is concluded that offering a conference would serve no purpose.



1. For example, if alerting the taxpayer to the existence of the investigation may result in physical danger to a witness or flight on the part of the taxpayer, offering a conference would not be advised.

2. Counsel should consult with the investigating special agent regarding these issues prior to offering the conference.


2. Normally, only one conference will be afforded to each taxpayer in the case. If Criminal Investigation and Counsel personnel conclude a second conference would aid in resolving questionable issues, it should be granted, recognizing the need for expeditious processing and avoiding unnecessary delay.


**38.2.1.4.3** **(08-11-2004)**

#### Cases Where No Conference will be Held

1. When there is a grand jury investigation, or when the grand jury investigation results in a case evaluation, no taxpayer conference will be held unless requested by a US Attorney or Department of Justice (DOJ).

2. In IRC § 7215 cases, a conference will not be offered unless it can be scheduled in time to meet the 15-day processing requirement.


**38.2.1.4.4** **(08-11-2004)**

#### Conference Procedures in Sensitive Cases

1. The taxpayer conference procedures to be followed in sensitive cases are the same procedures to be followed in non-sensitive cases, _except_ that the conferences are coordinated between the attorney in the Headquarters Office of the Associate Chief Counsel (CT) and the Director of Field Operations.

2. Counsel’s review and evaluation of sensitive cases occurs in the Office of the Associate Chief Counsel (CT) and referral of sensitive cases for prosecution requires the written concurrence of the Director of Field Operations.


**38.2.1.4.5** **(08-11-2004)**

#### Prompt Scheduling of Conference

1. Within generally five workdays after assignment of a criminal case, the Criminal Tax attorney will coordinate with the SAC the issuance of a notification letter to the taxpayer or representative offering a conference at a location designated by the SAC. At the option of the SAC, the Criminal Tax attorney may prepare the letter for the SAC’s signature to the taxpayer or representative offering a conference at a location designated by the SAC.

2. The conference should be scheduled approximately two weeks from the date of the letter. Reasonable alternatives may be permitted for the convenience of both parties. The case may not stagnate, however, awaiting a convenient conference date. Delay of the conference beyond 30 days from the date of receipt of the case should be permitted only in unusual circumstances and only with the approval of the Area Counsel (Criminal Tax).


**38.2.1.4.6** **(08-11-2004)**

#### Letter Offering a Conference

1. The following table illustrates the requirements of a letter offering a conference.




| **If** | **Conference letter is sent to** | **Letter should contain** | **See** |
| :-- | :-- | :-- | :-- |
| A valid power of attorney has not been received | The taxpayer | 1\. The nature of the criminal recommendation from Criminal Investigation | Exhibit 38.3.1-7, Letter to Taxpayer Offering Conference |
| 2\. The opportunity for a conference |
| 3\. The proposed date, time, and location of the conference |
| 4\. That he/she may be represented at the conference, but that legal representation will not be provided by the Government. |
| 5\. The need for a Declaration of Representative and a Tax Information Authorization or Power of Attorney (Form 8821 or 2848) for all representatives coming unaccompanied by taxpayers. | See Exhibit 38.3.1-7 for documents required from the taxpayer’s representative. |
| A valid power of attorney authorizing disclosure of the tax information to the representative is on file. | The representative | The same information listed above, with the exception of item 5. | Exhibit 38.3.1-6, Letter to Attorney Offering Conference |

2. Evidence of settlement or attempted settlement of a disputed claim is inadmissible when offered as admission of liability or the amount of liability. Fed. R. Evid. 408. Therefore, the following sentence will be included in all conference letters:




| _"Please be advised that plea bargaining, civil settlement negotiations, and/or compromise of tax liabilities will not be considered or discussed at the conference under any circumstances. "_ |
| :-- |
|  |







### Note:



See Exhibit 38.3.1-6 and Exhibit 38.3.1-7 at http://publish.no.irs.gov/getpdf.cgi?catnum=39139.


**38.2.1.4.7** **(08-11-2004)**

#### Persons Recognized as Representatives of Taxpayers

1. Pursuant to Treasury Department Circular 230, Section 10.3, the persons described in paragraphs (2) through (6) may practice before the Service.

2. Any attorney who is not currently under suspension or disbarment from practice before the Internal Revenue Service may practice before the IRS by filing a written declaration that he or she is currently qualified as an attorney and is authorized to represent the party or parties on whose behalf he or she acts.

3. Any certified public accountant who is not currently under suspension or disbarment from practice before the IRS may practice before the IRS by filing a written declaration that he or she is currently qualified as a certified public accountant and is authorized to represent the party or parties on whose behave he or she acts.

4. Any individual enrolled as an agent pursuant to this part who is not currently under suspension or disbarment from practice before the IRS may practice before the IRS.

5. Any individual who is enrolled as an actuary by the Joint Board for the Enrollment of Actuaries pursuant to 29 U.S.C. § 1242 who is not currently under suspension or disbarment from practice before the IRS may practice before the IRS by filing a written declaration stating that he or she is currently qualified as an enrolled actuary and is authorized to represent the party or parties on whose behalf he or she acts. Practice as an enrolled actuary is limited to representation with respect to certain issues outlined in Section 10.3 of Circular 230.

6. Any individual qualifying under paragraph (d) of § 10.5 or § 10.7 of Circular 230 is eligible to practice before the IRS to the extent provided in those sections.


**38.2.1.4.8** **(08-11-2004)**

#### Persons Not Recognized as Taxpayer Representatives

1. No officer or employee of the United States in the executive, legislative, or judicial branch of the Government, or in any agency of the United States, including the District of Columbia, may practice before the IRS, except that such officer or employee may, subject to the conditions and requirements of these regulations and of 18 U.S.C. § 205, represent a member of his/her immediate family or any other person or estate for which he/she serves as guardian, executor, administrator, trustee, or other personal fiduciary.

2. No Member of Congress or Resident Commissioner (elected or serving) may practice before the IRS in connection with any matter for which he/she directly or indirectly receives, agrees to receive, or seeks any compensation. 18 U.S.C. § 205.

3. No officer or employee of any State, or subdivision thereof, whose duties require him/her to pass upon, investigate, or deal with tax matters of such State or subdivision, may practice before the IRS, if such State employment may disclose facts or information applicable to Federal tax matters.


**38.2.1.4.9** **(08-11-2004)**

#### Taxpayer Witnesses

1. The taxpayer may bring witnesses to the conferences. Should the taxpayer desire the witness to remain during the conference, during times when the taxpayer’s return information is to be discussed, the taxpayer’s consent must be obtained before any Service employee may disclose the taxpayer’s return information in the presence of the witness. The taxpayer may provide a written consent or expressly state his consent to the disclosure at the start of the conference. Service employees may not infer from the taxpayer bringing a witness that the taxpayer consents to the disclosure of his return information. Service employees should note in the case file the fact of the taxpayer’s oral consent. See IRM 11.3.3.2.1.


**38.2.1.4.10** **(08-11-2004)**

#### Conference Attendees

1. All conferences should be attended by the SAC (or ASAC upon designation by the SAC) and the Criminal Tax attorney assigned to the case. The Criminal Tax attorney will assist in the legal and technical discussion. An official note taker should be designated and that person can be the Criminal Tax attorney, the SAC or another Counsel or Criminal Investigation employee.

2. The attendance of investigating personnel at the conference is generally discouraged because the presence of investigating personnel may tend to inhibit the taxpayer and/or the taxpayer’s representative in a free discussion of all facets of the case. Nevertheless, with the approval of the SAC and the concurrence of the Criminal Tax attorney, the special agent and/or revenue agent may attend the conference if the agent’s presence is essential to having a meaningful conference.


**38.2.1.4.11** **(10-03-2007)**

#### Documents Required from the Taxpayer’s Representatives

1. Prior to, or at the beginning of the conference, the SAC must ascertain that the taxpayer’s representative(s) has filed a Declaration of Representative accompanied by either a Form 8821, Tax Information Authorization ( http://publish.no.irs.gov/getpdf.cgi?catnum=11596), or a Form 2848, Power of Attorney and Declaration of Representative ( http://publish.no.irs.gov/getpdf.cgi?catnum=11980).



1. The Tax Information Authorization, signed by the taxpayer, authorizes the taxpayer’s representative(s) to receive and inspect certain tax information.

2. The Power of Attorney not only authorizes the representative(s) to receive and inspect certain tax information, but also gives him/her the authority to perform certain specific acts on behalf of the taxpayer (such as execution of consents, waivers, etc.).


2. The printed forms provided by the Government (Forms 2848 and 8821) need not be used if a document containing the same information found in such forms is filed in lieu of the printed forms.

3. The SAC and the Criminal Tax attorney should be familiar with Circular 230; Forms 2848 and 8821 and the instructions; Subpart E of Part 601 of Title 26, Code of Federal Regulations. See IRC §§ 6103 and 7213 and 18 U.S.C. § 1905 addressing penalties for improper disclosure of information.


**38.2.1.4.12** **(08-11-2004)**

#### Conference Preparation

1. Before the conference the SAC and the Criminal Tax attorney will read the special agent’s report and become familiar with the exhibits, paying special attention to statements of the taxpayer and his/her representative, accountant, and/or return preparer made during the course of the investigation.

2. The Criminal Tax attorney will also examine the administrative file, including the revenue agent’s report, for notations of additional contacts with the taxpayer and for the origin of the investigation. The Criminal Tax attorney should pay particular attention to any prior statements of the taxpayer and any inconsistency in the evidence.

3. The SAC and the Criminal Tax attorney will have a preparatory discussion to determine the goals/objectives of the conference. They should also identify any factual questions for resolution.


**38.2.1.4.13** **(08-11-2004)**

#### Joint Conference

1. A joint conference is one involving two or more taxpayers against whom Criminal Investigation has recommended prosecution for the same scheme(s) or transaction(s) giving rise to the recommended offense. The taxpayers may or may not be represented by counsel and, if represented, may or may not be represented by the same attorneys.

2. Joint conferences in related criminal tax cases are not generally favored. If requested by the taxpayers (or their duly authorized representatives), a joint conference may be held where there is sufficient identity of facts and issues and the SAC and the Criminal Tax attorney conclude that a joint conference will not adversely impact the processing of the criminal case. The SAC is not required, however, to grant a request for a joint conference even in those cases wherein there would be no adverse impact.

3. When a joint conference is requested, both the request and the express permission of the taxpayers (or their representative(s)) authorizing the disclosure of tax return information to their proposed co-defendants and/or other third parties in attendance, should be obtained in writing. If the joint conference is held at the request of the authorized representatives of the taxpayers, the SAC should obtain in writing, prior to making any disclosures, the fact that the representatives are empowered to authorize the disclosure of tax return information to the other principals.

4. The written request for a joint conference and the taxpayer’s authorization for disclosure should be fully set forth in the conference memorandum.


**38.2.1.4.14** **(08-11-2004)**

#### Conducting the Conference

1. SAC’s Role. The SAC is charged with control of the conference and is responsible for its conduct throughout. The conference should be opened with the SAC’s statement covering the points listed in (a) through (h) below:



1. If the conference is attended by a representative and/or witnesses (with or without the taxpayer), verify that the appropriate documents have been executed.

2. Advise that the investigation has been completed and the case agent is recommending the case for prosecution on the specific charges and that the recommendation may be changed by the SAC. Emphasize that no formal charges have been made.

3. Advise as to the method of proof used in the recommended charges, such as, specific item, net worth, etc.

4. Advise the taxpayer of his/her constitutional right against self-incrimination.

5. Advise that under decisional law and Federal Rules of Evidence, Rule 801(d)(2)(C) and (D), admissions made by the taxpayer and/or representative and documents submitted may be used against the taxpayer in a criminal case. If the Power of Attorney limits the representative’s authority in regard to admissions, the SAC may terminate the conference. If the SAC does not terminate the conference, he/she should inform the representative that a conference under such circumstances severely limits communication and that the SAC and the Criminal Tax attorney will merely listen to whatever the representative wishes to say in regard to the client’s defense.

6. If the taxpayer is without legal representation, advise that he/she may have legal counsel of his/her choice at the conference and that the conference can normally be delayed for a brief period to enable the employment of counsel, but that counsel cannot be provided at Government expense.

7. Advise that the conference is purely voluntary and may be terminated by the taxpayer at any point.

8. Advise that the purpose of the conference is to provide an opportunity to submit evidence and offer any explanation or argument on behalf of the taxpayer as deemed appropriate and relevant to the case.


2. Vicarious Admissions. Rule 801(d)(2)(C) of the Federal Rules of Evidence provides that an admission of a party opponent is not hearsay. The statement is offered against a party and may be a statement by a person authorized by the party to make a statement concerning the subject. This is known as the vicarious admissions rule and operates to attribute to the taxpayer any statements made by the taxpayer’s representative during the course of a conference.



1. By Directive No. 86-58 (May 14, 1986), the Tax Division announced that it would not rely on the vicarious admissions rule to attribute to the taxpayer any statements made by the taxpayer’s representative at a conference before Tax Division attorneys, except for statements concerning the authentication of written instruments.

2. Criminal Investigation personnel and the Criminal Tax attorney will continue to rely on the vicarious admissions rule as provided by Rule 801(d)(2)(C) of the Federal Rules of Evidence.


3. Amount of Civil Tax Liability. The SAC may apprize the taxpayer and/or representative of the figures computed. The criminal figures may be disclosed with the caveat that the indictment figures may vary or the indictment may contain no actual amounts.

4. Discussion of Case. The SAC may, at his/her discretion, and after consideration of all aspects of the case, reveal and discuss facts or elements of the case so as to make the conference as meaningful as possible to both the taxpayer and the Government. Care must be exercised, however, to protect the identity of informants and other witnesses.

5. Recording of Conference. The SAC should discourage the recording of conferences by a taxpayer or his/her representative. If either the taxpayer or his/her representative insists upon recording the conference, the SAC must likewise record the conference, identifying those persons in attendance, the date, place, and time. The recording of the conference should be maintained in the criminal case file.

6. Review and Referral Procedures. The SAC should advise the taxpayer and/or representative of the review and referral procedures, as well as the anticipated time frame.

7. Communication of SAC’s Decision. The taxpayer and/or representative should be told that they will receive a letter notifying them of the SAC’s decision.


**38.2.1.4.15** **(08-11-2004)**

#### Conference Memorandum

1. Promptly after completion of the conference, a memorandum will be prepared by the Criminal Tax attorney assigned to the case. The memorandum should be as detailed as possible and cover everything that occurred or was discussed at the conference.

2. The memorandum will include:



1. Date and location of the conference

2. Names of the individuals in attendance

3. Facts representing the power of attorney and declaration filed

4. Any constitutional warnings given to the attending taxpayer

5. Any statements and representations of facts and law and by whom made

6. Any copies of written statements or documents submitted


3. The memorandum may contain comments regarding the demeanor of the taxpayer or witnesses who are present, but should not otherwise contain the Criminal Tax attorney’s opinions regarding the validity of evidence (except as discussed at the conference) or his/her views of the strengths or weaknesses of the case.

4. It will be signed by each of the Service representatives who were present. A copy of the conference memorandum should be sent to the Area Counsel (CT).

5. The conference memorandum, as well as the notes taken during the conference, should be included in the case file. In certain circumstances, these documents may be made available to the taxpayer at trial, or during civil negotiations.

6. The original and one copy of the memorandum are reserved for DOJ if prosecution is ultimately recommended, with additional copies for the Counsel file, and other files required by local instructions. See Exhibit 38.3.1-8 and Exhibit 38.3.1-9 at http://publish.no.irs.gov/getpdf.cgi?catnum=39139.


**38.2.1.5** **(08-11-2004)**

### Supplemental Investigations

1. After reviewing the special agent’s report and related exhibits, the Criminal Tax attorney may determine that additional evidence is needed to support various aspects of proof. Since some questions may be answered and others may surface at the taxpayer conference, it is normally preferable to delay a request for supplemental investigation until after such conference. Multiple supplemental requests should be avoided, if possible. Where feasible, the noted deficiencies in proof should be discussed orally with the special agent. The attorney should prepare a memorandum to Criminal Investigation detailing the supplemental information requested or document by a memorandum to the file the date and nature of the oral request. A copy of the written documentation should be forwarded to the Area Counsel (CT).

2. When a request for supplemental investigation has been made on a particular case, the attorney should remind Criminal Investigation that the 45-day or 60-day Counsel processing period is tolled from the date of the request until the requested response is received.


**38.2.1.6** **(08-11-2004)**

### Criminal Evaluation Memorandum

1. The criminal evaluation memorandum transmits the Criminal Tax attorney’s evaluation of the merits of the criminal prosecution to the SAC. The memorandum contains a thorough analysis of the case, an explanation of the recommended charges, a discussion of the evidence available to prove the recommended charges, a discussion of foreseeable problems and defenses whether raised by the taxpayer or his/her counsel or determined by analysis of the case file, and the Criminal Tax attorney’s concurrence or nonconcurrence with the prosecution recommendation. The discussion should be limited to the legal analysis and details of the particular case, and all documents submitted on behalf of the taxpayer are forwarded with the memorandum.

2. The criminal evaluation memorandum is more than mere paraphrasing of the special agent’s report. It is an independent critical analysis of the case, without undue reliance upon either the phraseology or conclusions found in the special agent’s report. See Exhibit 38.3.1-10 at http://publish.no.irs.gov/getpdf.cgi?catnum=39139.


**38.2.1.6.1** **(08-11-2004)**

#### Content and Style

01. Although the content and even the style of the memorandum must be tailored to the case, it should contain the information discussed in this subsection.

02. Criminal Subjects. This section contains the name, address, social security number and/or employer identification number of all recommended parties referred by Criminal Investigation. If there are related cases, the names of the related criminal subjects should also be provided.

03. Counsel’s Recommendation. This section contains Counsel’s recommendation as to the charge(s), year(s), number of count(s), venue, and statute of limitations. (If the statute of limitations is imminent, then the date should be **bolded**.) Counsel should state whether prosecution is or is not warranted. If prosecution is recommendation, whether the recommendation concurs with the Special Agent’s recommendation or differs from the Special Agent’s recommendation.

04. Executive Summary. In a nutshell, either in a short paragraph or using bullets, summarize the subject’s actions that give rise to the criminal prosecution recommendation, as well as relevant information important to the reader. For instance, include or note: the amount of tax dollars (including relevant conduct); harm to the government; the indirect method of proof; an expiring statute of limitations; investigative techniques; and, the technical tax issue(s).

05. Criminal Violations. Discuss the principal evidence available to establish the elements of the criminal offense(s). Subheadings should be used for each element of the proposed charge. Items of evidence should be set forth with bullets to separate and give the reader an idea of how many exhibits/how much evidence there is on a given element.

06. Discussion of the Law. Discuss any legal, procedural, and/or policy issues regarding:



    1. Venue

    2. Statute of limitations

    3. How the investigation originated (when and by whom the taxpayer was first contacted)

    4. Investigation techniques

    5. Aspects of personal history of significance to the case; age, marital status during the years at issue (especially in community property states), health (if a major problem is known), education, and criminal record


07. Tax Loss, Computations, Method of Proof and Technical Tax Issues. In this section the tax loss, computations and method of proof should be noted and discussed when warranted. When applicable, tax or tax-related issues or technical tax issues should be discussed.

08. Current Lifestyle. In this section, update information relative to each subject’s current lifestyle; job history; filing history; and audit history. If this information is relevant to the case and not readily available, then discuss this in the "Other Issues and Suggestions " section.

09. Defenses. Discuss defense contentions or reasonably probable defenses and available rebuttal evidence. When no defenses are foreseeable, so note.

10. Other Issues and Suggestions. Discuss problems/issues/concerns with the case.

11. Sentencing. In either a short paragraph or by using bullets, summarize sentencing, including the aggravating or mitigating offense related conduct.

12. Conclusion. In this section note whether the evidence relied upon to support the recommendation is sufficient to indicate guild beyond a reasonable doubt and whether there is a reasonable probability of conviction. In addition, note that Counsel is closing its file as of the date of this memorandum.

13. Signature of the Criminal Evaluation Memorandum. Signature authority for criminal evaluation memoranda rests with the Area Counsel (CT), unless delegated to the Criminal Tax attorney.

14. Distribution of the Criminal Evaluation Memorandum. The criminal evaluation memorandum is distributed as follows:



    1. The original criminal evaluation memorandum, along with the special agent’s report and exhibits to the SAC

    2. One copy of the criminal evaluation memorandum, along with a copy of the special agent’s report to the Area Counsel (CT)

    3. One copy of the criminal evaluation memorandum, along with a copy of the special agent’s report to the Associate Chief Counsel (CT)


**38.2.1.7** **(08-11-2004)**

### Plea Program Cases

1. The Expedited Plea Program, as set forth in Tax Division Directive 111, is designed to expedite the handling of criminal tax cases where the taxpayer, through his/her attorney, indicates during the course of an administrative investigation being conducted by Criminal Investigation, an interest in entering a guilty plea to some or all of the charges and years under investigation. The program is intended to dispose expeditiously of the entire criminal case. It is not intended to be utilized to limit the taxpayer’s exposure by curtailing or limiting the Service’s investigation. The following factors should be present:



1. The case involves an administrative investigation involving legal source income

2. It is available only to taxpayers who are represented by an attorney who must initiate plea discussions and/or negotiations

3. Criminal Investigation has not initiated the subject of plea discussions

4. The taxpayer has been informed that the Service has no authority to engage in plea negotiations and that only DOJ can engage in such negotiations

5. The taxpayer’s attorney has provided a written statement to Criminal Investigation confirming the taxpayer’s desire to engage immediately in plea negotiations with DOJ

6. The taxpayer has been informed that he/she will be required to plead to the most significant violation involved, consistent with the Tax Division’s Major Count Policy

7. The Service has taken precautions to insure that information furnished by the taxpayer, prior to formal plea discussions with DOJ, will not be foreclosed from future use under the restrictions of Fed.R.Crim.P.11(f), in the event that plea negotiations fail

8. The Service has sufficient evidence to constitute a referable matter to the Tax Division


2. Criminal Tax attorney Prereferral Assistance. After Criminal Investigation receives written conformation that the taxpayer wants to engage immediately in plea negotiations with DOJ, the Criminal Tax attorney will provide prereferral assistance, evaluating



1. Whether the evidence is sufficient to meet the requirements of Fed.R.Crim.P.11(b)(3) ( _i.e._, is there a factual basis to support the plea of guilty to each of the counts under investigation); and

2. Whether the charges under investigation adequately address the crime(s) committed by the taxpayer.


3. Review and Evaluation Procedures. The Criminal Tax attorney will review the special agent’s report and exhibits and provide an evaluation of the evidence consistent with the plea program procedures to the SAC via criminal evaluation memorandum.

4. Procedures for Non-Program Plea Agreements. The Criminal Tax attorney does not have authority to convert cases to the Expedited Plea Program that do not meet the previously discussed criteria; however, the situation may arise that while the case is being reviewed, the taxpayer and/or the taxpayer’s counsel, expresses a willingness to enter into plea negotiations with DOJ. If this occurs, the criminal evaluation memorandum should note the willingness of the taxpayer and/or taxpayer’s counsel to plead guilty to the major count established by the evidence.


**38.2.1.8** **(08-11-2004)**

### Release of Information

1. Because the IRS achieves the greatest deterrent effect through news coverage of criminal tax prosecutions, the Attorney General has approved the issuance by the Service of appropriate press releases. Excessive pretrial publicity constitutes a danger to an individual’s right to a fair trial, and thus it is essential that Service personnel avoid actions that might prejudice that right. Statutory prohibitions on the unauthorized disclosure of return and return information make it imperative that material contained in such news releases be limited to facts that are a matter of public record. _See_ IRC § 6103.

2. All release of information is subject to Service procedures and guidelines based on DOJ guidelines.

3. IRS personnel will not make public statements, news releases, or other public disclosures concerning a defendant, the evidence, or other aspects of a criminal matter anytime during the investigation and resulting prosecution, except upon approval by DOJ.

4. IRS personnel will neither encourage nor assist news media in televising or photographing a defendant or accused person being held or transported in federal custody, nor will they make photographs of the defendant available to the media.

5. Counsel is not authorized to make news releases.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part38/irm_38-002-001#addtoany "Show all")

A2A