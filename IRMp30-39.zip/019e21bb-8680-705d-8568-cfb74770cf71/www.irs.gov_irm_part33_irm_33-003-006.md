---
url: "https://www.irs.gov/irm/part33/irm_33-003-006"
title: "33.3.6 Designating a Case for Litigation | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part33/irm_33-003-006#main-content)

- 33.3.6 [Designating a Case for Litigation](https://www.irs.gov/irm/part33/irm_33-003-006#idm140483791838176)
  - 33.3.6.1 [Purpose and Effect of Designating a Case for Litigation](https://www.irs.gov/irm/part33/irm_33-003-006#idm140483791837744)
  - 33.3.6.2 [Procedures for Designating a Case for Litigation](https://www.irs.gov/irm/part33/irm_33-003-006#idm140483792030080)

    - 33.3.6.2.1 [Nondocketed Case under the Jurisdiction of an Operating Division](https://www.irs.gov/irm/part33/irm_33-003-006#idm140483792027024)
    - 33.3.6.2.2 [Docketed Case in Counsel Jurisdiction](https://www.irs.gov/irm/part33/irm_33-003-006#idm140483791974128)
    - 33.3.6.2.3 [Nondocketed Case under the Jurisdiction of Appeals](https://www.irs.gov/irm/part33/irm_33-003-006#idm140483791966816)

  - 33.3.6.3 [Background Development and Designation Recommendation Memorandum](https://www.irs.gov/irm/part33/irm_33-003-006#idm140483791954224)

    - 33.3.6.3.1 [Background Development](https://www.irs.gov/irm/part33/irm_33-003-006#idm140483791951184)
    - 33.3.6.3.2 [Designation Recommendation Memorandum](https://www.irs.gov/irm/part33/irm_33-003-006#idm140483791943408)

  - 33.3.6.4 [Release of Designation](https://www.irs.gov/irm/part33/irm_33-003-006#idm140483791929024)
  - 33.3.6.5 [Refund Litigation Cases](https://www.irs.gov/irm/part33/irm_33-003-006#idm140483791922736)
  - Exhibit 33.3.6-1 [Sample Template for Designation Recommendation Memorandum](https://www.irs.gov/irm/part33/irm_33-003-006#idm140483791918288)

# Part 33. Legal Advice

# Chapter 3. Other Legal Advice

# Section 6. Designating a Case for Litigation

* * *

## 33.3.6 Designating a Case for Litigation

**33.3.6.1** **(08-11-2004)**

### Purpose and Effect of Designating a Case for Litigation

1. Certain cases present recurring, significant legal issues affecting large numbers of taxpayers. When there is a critical need for enforcement activity with respect to such issues, cases are designated for litigation in the interest of sound tax administration to establish judicial precedent, conserve resources, or reduce litigation costs for the Service and taxpayers. For example, judicial precedent may provide guidance for the resolution of industry-wide, tax shelter or other issues, thereby serving early issue resolution and conserving Service and taxpayer resources.

2. When under the jurisdiction of the Service, the designated issue in a case will not be resolved without a full concession by the taxpayer.

3. In general, an issue will be designated when the case is under the jurisdiction of an Operating Division. If an issue in a case is designated, the taxpayer will not receive a 30-day letter with respect to remaining unresolved issues in the case. Rather, the taxpayer will be issued a statutory notice of deficiency. In general, the designation of an issue in a case will not preclude the settlement of the remaining issues after the case is docketed. Nor, in general, will designation preclude Appeals from settling the same issue in other cases within its jurisdiction. As part of the designation process, Counsel will consider whether the issue is one of first impression or otherwise involves unique or unusual circumstances. If the Chief Counsel believes circumstances surrounding the designated issue are such that settlement of the issue in other cases would be detrimental to the principles of sound tax administration, the Chief Counsel will confer with the Chief, Appeals. The Chief Counsel and the Chief, Appeals, will also confer as to the impact of the settlement of an issue on future settlements and a course of action with respect to the settlement of the issue that reflects the best interests of tax administration.


**33.3.6.2** **(08-11-2004)**

### Procedures for Designating a Case for Litigation

1. This subsection contains the procedures for designating for litigation cases under the jurisdiction of the Operating Divisions, Appeals, and Counsel.


**33.3.6.2.1** **(12-10-2010)**

#### Nondocketed Case under the Jurisdiction of an Operating Division

01. If a case is under the jurisdiction of an Operating Division, examination personnel with responsibility for the case will forward a written memorandum to the corresponding Area Counsel requesting that a case be considered for designation. In most circumstances, the focus of the designation will be one issue in the case. The initial request to the Area Counsel will be made by the examination personnel most knowledgeable about the facts of the issue and the case, and who are best able to provide the details necessary to reach a considered decision as to whether the case meets the requirements for designation.

02. Upon receipt of a written request that a case be considered for designation, the Area Counsel will ensure that the request is subject to a careful analysis by attorneys and managers appointed by the Area Counsel. A reasonable effort will be made to identify other cases presenting the proposed designated issue to allow for Service-wide strategic coordination. Operating Division and Area Counsel personnel will ensure that the issue being considered for designation meets the requirements for designation.

03. If the Area Counsel agrees that the case is appropriate for further consideration of designation, Operating Division personnel will notify the taxpayer of such consideration and the reasons for the proposal. The taxpayer will also be notified that its views on the proposed designation may be presented, in a meeting, to the Operating Division personnel and Area Counsel.

04. If the Operating Division personnel and Area Counsel believe that the case should be proposed for designation, the Associate Area Counsel with prime responsibility for the proposed designation will prepare the Designation Recommendation Memorandum (DRM). See CCDM 33.3.6.3.1. The Associate Area Counsel will informally coordinate with the Associate Chief Counsel with subject matter jurisdiction of the issue proposed for designation while preparing this memorandum. If it is intended that a different Associate Area Counsel office be responsible for the trial of the case, the preparation of the DRM will be coordinated with that trial office. If the Area Counsel concurs with the DRM, such concurrence will be reflected by a signature on the memorandum.

05. The Area Counsel will forward the DRM simultaneously to the Operating Division Executive, listed below, and the Division Counsel, who will have 30 days to review and concur on the proposal. Any written submissions by the taxpayer reflecting his/her views on the proposed designation will be forwarded with the DRM. Concurrence will be reflected by a signature on the memorandum. For purposes of advanced notice and coordination, the Area Counsel will also forward a copy of the DRM to the Associate Chief Counsel with subject matter jurisdiction of the issue proposed for designation.



    1. In LB&I, the Operating Division Executive is the Industry Director and, if the issue to be designated is an International issue, the Deputy Commissioner (International). If an LB&I taxpayer in one industry is under examination by another Industry Director, concurrence is required by both directors.

    2. In SB/SE, the Operating Division Executive is the Commissioner (SB/SE).

    3. In TEGE, the Operating Division Executive is the Commissioner (TEGE).


06. At the time the Area Counsel forwards the DRM to the Operating Division Executive and Division Counsel, the Operating Division will inform the taxpayer. The taxpayer will be provided with written notification that describes the issue proposed for designation and explains the reasons for the proposal. The taxpayer will also be notified that its views on the proposed designation may be presented, in writing and as a supplement to prior submissions, to the Operating Division Executive and the Division Counsel.

07. Following the signatures of the Operating Division Executive and the Division Counsel, the Division Counsel will forward the DRM, along with written submissions from the taxpayer, simultaneously to the Chief Counsel and the Associate Chief Counsel with subject matter jurisdiction of the issue proposed for designation. The Associate Chief Counsel will provide the Chief Counsel in writing comments on the DRM within 30 days of receipt of the DRM.

08. At the time the DRM is approved for forwarding to the Chief Counsel, the Operating Division will inform the taxpayer. The taxpayer will also be notified that its views on the proposed designation may be presented to the Chief Counsel.

09. If the Chief Counsel approves designating the case for litigation, the Division Counsel will notify the executives who concurred with the DRM and the Chief, Appeals. The Division Counsel will also notify the taxpayer in writing of the approval of the designation by the Chief Counsel.

10. Once the case is designated for litigation, the Operating Division will, as soon as possible, issue a statutory notice of deficiency to the taxpayer.

11. Once a designated case is docketed in the United States Tax Court, the trial counsel will seek the assignment of a judge and the calendaring of the case for trial. See T.C. Rule 132. As appropriate, trial counsel will seek the severance of the designated issue from the other issues set forth in the case. See T.C. Rule 141(b). In general, a Brannerton letter will be sent to the taxpayer within 30 days after the case is at issue. A first stipulation of facts should be proposed as early as possible after the case is at issue.


**33.3.6.2.2** **(08-11-2004)**

#### Docketed Case in Counsel Jurisdiction

1. Consideration may be given to designating a case that is docketed in the Tax Court. The procedures for initiating and approving the designation of a nondocketed case for litigation under the jurisdiction of the Operating Division, as set forth in CCDM 33.3.6.2.1, will be followed, with the addition of the procedures set forth below.

2. The trial counsel will initiate the request for designation, as provided in CCDM 33.3.6.2.1(1), in coordination with Operating Division personnel.

3. The trial counsel will notify the taxpayer, as provided in CCDM 33.3.6.2.1(3), of the consideration of the case for designation and the reasons for the proposal.

4. The trial counsel will inform the taxpayer in writing, as provided in CCDM 33.3.6.2.1(6), of the forwarding of the DRM to the Operating Division Executive and the Division Counsel. The written notification will advise the taxpayer that, if the case is designated, the trial counsel will seek the assignment of a judge and the calendaring of the case for trial. See T.C. Rule 132.

5. The trial counsel will inform the taxpayer of the forwarding of the DRM to the Chief Counsel requires provided in CCDM 33.3.6.2.1(8).


**33.3.6.2.3** **(08-11-2004)**

#### Nondocketed Case under the Jurisdiction of Appeals

01. As described in CCDM 33.3.6.1, an issue will generally be designated when a case is under the jurisdiction of an Operating Division. In certain instances, consideration may be given to designating a nondocketed case for litigation while the case is in Appeals jurisdiction. In general, a case is considered to be in Appeals jurisdiction after a protest is filed in response to a 30-day letter. The procedures for initiating and approving the designation of a nondocketed case for litigation under the jurisdiction of the Operating Division, as set forth in CCDM 33.3.6.2.1, will be followed, with the addition of the procedures set forth below.

02. While a request for designation is awaiting approval, Appeals may suspend settlement activity on the issue recommended for designation until a designation decision is made.

03. Appeals personnel will also receive a copy of the written memorandum requesting that the case be considered for designation as provided in CCDM 33.3.6.2.1(1).

04. The Chief, Appeals, will also ensure that the request is subject to a careful analysis, as provided in CCDM 33.3.6.2.1(2) by Appeals personnel.

05. If the Area Counsel and Chief, Appeals, agree that the case is appropriate for further consideration for designation, Appeals personnel will notify the taxpayer, as provided in CCDM 33.3.6.2.1(3) of such consideration. The taxpayer may present his/her views on the proposed designation to the Operating Division personnel, Chief, Appeals, and Area Counsel.

06. The Chief, Appeals, will concur in the DRM, as provided in CCDM 33.3.6.2.1(5), before the memorandum is forwarded to the Division Counsel and Operating Division Executive.

07. Appeals will provide the taxpayer, as provided in CCDM 33.3.6.2.1(6), with the written notification that the recommendation has been forwarded to the Operating Division Executive and Division Counsel. The taxpayer may present its views on the proposed designation, in writing as a supplement to prior submissions, to the Operating Division Executive, Chief, Appeals, and Division Counsel.

08. Appeals will inform the taxpayer of the forwarding of the DRM, as provided in CCDM 33.3.6.2.1(8), to the Chief Counsel.

09. Once the case is designated for litigation, Appeals will, as soon as possible, issue a statutory notice of deficiency for the designated issue and the other issues in the case.

10. After the case is docketed, the nondesignated issues may be referred to Appeals at the discretion of the Area Counsel.


**33.3.6.3** **(08-11-2004)**

### Background Development and Designation Recommendation Memorandum

1. This subsection sets out the procedures governing the responsibilities of Area Counsels prior to recommending a case for designation and the contents of a Designation Recommendation Memorandum.


**33.3.6.3.1** **(08-11-2004)**

#### Background Development

1. Before a case is recommended for designation, it is the responsibility of the recommending Area Counsel office to:



1. Articulate in a background memorandum the reasons why litigation is the most desirable method of resolving the issue proposed for designation. The background memorandum shall state the goal of the proposed litigation, the impact of both a favorable and an unfavorable opinion in the case, the potential impact of other issues in the case, the other methods of issue resolution that have been considered and why those methods are not appropriate, and an analysis of the substantive issue and any related issues (including penalties).

2. Ensure that the issue that is proposed for designation is factually developed to its fullest, including document production, and key taxpayer and third party witness interviews, when appropriate. The recommending office should also ensure that the Service has the resources to support the proposed litigation, including expert witness funds, and that the case, in its entirety, is appropriate for the issuance of a statutory notice of deficiency. Efforts should be made to discover the existence of facts that could adversely affect the desirability of designation, such as an agreement with the Service in an earlier year with the taxpayer contrary to the position now proposed.

3. Thoroughly research the issue to ensure that the litigating position of the Service is established, clear, and well-founded on statute and published positions. The recommending office shall ascertain the litigating position of the Service through coordination with its Area Counsel, Division Counsel, and the Associate Chief Counsel office with subject matter jurisdiction for the issue. Coordination with other Counsel offices may occur, as appropriate.


**33.3.6.3.2** **(08-11-2004)**

#### Designation Recommendation Memorandum

1. The Designation Recommendation Memorandum (DRM) will contain the information listed below and generally be in the form of Exhibit 33.3.6-1:



1. The issue to be designated, including the amount of the adjustment, approximate resulting deficiency and penalties, if applicable, with respect to the designated issue.

2. The tax years, total adjustments, total deficiencies, and total penalties involved in the case, as well as the number and identity of the other unresolved issues in the case.

3. A brief examination history of the taxpayer. This discussion should include the prior treatment or resolution of the issue proposed for designation, any rulings or adjustments previously made that are related to the litigation issue, and the possibility of carryforwards or carrybacks that would moot the trial of the case. This discussion should also state whether the statute of limitations is a potential problem and whether the taxpayer is in a position to withdraw a consent or refuse to execute a new one.

4. The purpose of the proposed designation. This discussion should explain why litigation is the preferred strategy for resolving the issued involved. Rejection, or coordinated use, of non-litigation strategies, such as regulations, rulings, or legislation, must also be explained.

5. A factual summary of the designated issue and any related issues (including penalties). This discussion should highlight significant favorable and unfavorable facts, state whether there are any areas of factual disagreement, explain the significance of the disagreement, and set forth any lack of availability of material evidence or witnesses. If expert testimony is required, this discussion should include the nature of the expert testimony, whether experts are available, and an approximation of costs to be incurred in procuring experts. Significant evidentiary issues should be discussed.

6. A legal analysis reflecting the litigating position of the Service. This discussion should contain an analysis of the law and how the law applies to the particular facts. Key advice memoranda should be attached.

7. A discussion of the litigating position of the taxpayer. This discussion should include comments regarding the law or facts advanced by the taxpayer in support of its position, and in opposition to the Service’s position, the time needed to prepare the case for trial and the estimated trial time. If the taxpayer made a written submission in response to the notification that designation was under consideration, a copy of that response should be attached.

8. A discussion of the anticipated taxpayer strategy. This discussion should include whether the taxpayer may choose to litigate in a refund setting, the likely appellate forum, and whether the taxpayer may invoke Competent Authority procedures. These possibilities should be considered as factors mitigating against designation and the discussion should explain why designation is nonetheless appropriate.

9. A recommendation on which Associate Area Counsel would have overall supervision of the trial of the case and the lead trial counsel.


**33.3.6.4** **(08-11-2004)**

### Release of Designation

1. Designation of a case for litigation should not be made in contemplation of a later release of the designation. The litigating position of the Service may change or new facts may come to light so that continuation of litigation no longer serves the purpose for which the designation was originally made. Under such circumstances, release of the designation may be considered.

2. Recommendations for release of designation may originate from the Operating Division, the Area Counsel, Division Counsel, Chief, Appeals, Associate Chief Counsel, or the Chief Counsel.

3. The decision to release or not release a designation will be made by the Chief Counsel or the Chief Counsel’s delegate.

4. If release of designation is approved, the taxpayer will be informed in writing by the Area Counsel responsible for the case.


**33.3.6.5** **(08-11-2004)**

### Refund Litigation Cases

1. If a case that has been designated for litigation proceeds to trial in a refund litigation status procedure, the case will be classified as "Standard" under the refund litigation procedures. See CCDM 34.5.1.1.1, Case Classification. The Area Counsel office responsible for the preparation of the refund defense letter will work with the Division Counsel and the Associate Chief Counsel with subject matter jurisdiction to articulate in the defense letter the goals of the designation. The Office of Chief Counsel will give full support to the Department of Justice’s litigation of a designated case, which may include devoting Counsel resources to trial preparation activities and trial.


**Exhibit 33.3.6-1**

### Sample Template for Designation Recommendation Memorandum

| _Sample Template_ |
| :-: |
|  | Office of Chief Counsel<br>Internal Revenue Service<br>memorandum<br>CC:LB&I |  |
| **date:** |  |
| **to:** | Division Counsel (Large Business and International) |
| **from:** | Associate Area Counsel, Large Business and International (LB&I) |
| **subject:** | Designation of Issue for Litigation<br>\[Taxpayer Name\]<br>Issue: \[summary description of issue\] |
|  | Pursuant to the provisions of CCDM 33.3.6, we recommend that an issue arising out of the examination of \[Taxpayer\] be designated for litigation. |
|  | **ISSUE:** |
|  | **ADJUSTMENTS AND DEFICIENCIES:** |
|  | **HISTORY OF PRIOR EXAMINATIONS:** |
|  | **PURPOSE OF DESIGNATION:** |
|  | **RELATED CASES:** |
|  | **SUMMARY OF FACTS:** |
|  | **LEGAL POSITION OF THE SERVICE:** |
|  | **TAXPAYER LEGAL POSITION, STRATEGY, AND DEFENSE:** |
|  | **TRIAL RESPONSIBILITY AND STRATEGY:** |

|     |     |     |
| --- | --- | --- |
| **RECOMMENDATION:** |  |
|  |  | \[Name\]<br>Associate Area Counsel<br>Large Business and International |
| CONCURRED IN BY: |  |  |
|  |  |  |
|  | Industry Director | Date: |
|  |  |  |
|  | Area Counsel | Date: |
|  |  |  |
|  | Division Counsel | Date: |
| APPROVED: |  |  |
|  | Chief Counsel | Date: |

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part33/irm_33-003-006#addtoany "Show all")

A2A