---
url: "https://www.irs.gov/irm/part35/irm_35-001-003"
title: "35.1.3 Tax Court Procedures | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-001-003#main-content)

- 35.1.3  [Tax Court Procedures](https://www.irs.gov/irm/part35/irm_35-001-003#idm140451720490864)
  - 35.1.3.1  [Form and Appearance of Documents](https://www.irs.gov/irm/part35/irm_35-001-003#idm140451691292928)
    - 35.1.3.1.1  [Caption, Date, and Signature](https://www.irs.gov/irm/part35/irm_35-001-003#idm140451691290384)
    - 35.1.3.1.2  [Clarity and Legibility](https://www.irs.gov/irm/part35/irm_35-001-003#idm140451692223760)
    - 35.1.3.1.3  [Size and Style](https://www.irs.gov/irm/part35/irm_35-001-003#idm140451692221584)
    - 35.1.3.1.4  [Binding and Covers](https://www.irs.gov/irm/part35/irm_35-001-003#idm140451692218592)
    - 35.1.3.1.5  [Citations](https://www.irs.gov/irm/part35/irm_35-001-003#idm140451692215552)
  - 35.1.3.2  [Service and Filing of Documents](https://www.irs.gov/irm/part35/irm_35-001-003#idm140451691456432)
    - 35.1.3.2.1  [Service of Documents by the Tax Court](https://www.irs.gov/irm/part35/irm_35-001-003#idm140451691454176)
    - 35.1.3.2.2  [Direct Service and Filing of Documents by Mail](https://www.irs.gov/irm/part35/irm_35-001-003#idm140451691441184)
    - 35.1.3.2.3  [Computation of Time](https://www.irs.gov/irm/part35/irm_35-001-003#idm140451691408016)
    - 35.1.3.2.4  [Court’s Notation on Served Documents](https://www.irs.gov/irm/part35/irm_35-001-003#idm140451720932704)
  - 35.1.3.3  [Small Tax Case Procedures](https://www.irs.gov/irm/part35/irm_35-001-003#idm140451720928864)
    - 35.1.3.3.1  [Small Tax Case Procedures for Collection Due Process Cases](https://www.irs.gov/irm/part35/irm_35-001-003#idm140451720917840)
  - 35.1.3.4  [Designation of Declaratory Judgment Cases; Cases under Sections 6015, 6110, 6330, 6404, and 7436](https://www.irs.gov/irm/part35/irm_35-001-003#idm140451720911472)

# Part 35. Chief Counsel Directives Manual Tax Court Litigation

# Chapter 1. Tax Court Jurisdiction

# Section 3. Tax Court Procedures

* * *

## 35.1.3 Tax Court Procedures

#### Manual Transmittal

July 31, 2023

#### Purpose

(1) This transmits revised CCDM 35.1.3, Tax Court Jurisdiction; Tax Court Procedures.

#### Background

On March 12, 2020, the Office of Chief Counsel issued CC Notce CC-2020-004, **Form and Appearance of Tax Court Documents**, announcing new and revised Chief Counsel guidelines regarding the form and appearance of all documents filed with the United States Tax Court, including the adoption of 14-point Times New Roman as the standard font for all such documents. CCDM 35.1.3 is revised to incorporate this guidance.

#### Material Changes

(1) CCDM 35.1.3.1 is a new section on the form and appearance of all documents filed with the United States Tax Court and directs attorneys to follow the requirements set out in Tax Court Rule 23 pertaining to such documents.

(2) Existing CCDM 35.1.3.1 is renumbered CCDM 35.1.3.2 and all subsequent sections are renumbered and updated accordingly.

#### Effect on Other Documents

CCDM 35.1.3 dated July 24, 2012, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(07-31-2023)

Richard G. Goldman

Deputy Associate Chief Counsel

(Procedure and Administration)

**35.1.3.1** **(07-31-2023)**

### Form and Appearance of Documents

1. T.C. Rule 23 prescribes specific requirements for the form and appearance of any document filed with the Tax Court. Attorneys must comply with these requirements in the preparation of any document to be filed with the court.

2. Pursuant to T.C. Rule 23(g), the Clerk of the Tax Court will not refuse to file any document solely because it fails to meet the requirements of T.C. Rule 23. However, attorneys should note that this provision does not bind judges of the court, and attorneys may not rely on this Rule to intentionally file documents that do not meet the requirements of T.C. Rule 23.


**35.1.3.1.1** **(07-31-2023)**

#### Caption, Date, and Signature

1. All documents filed with the Tax Court must have a caption meeting the requirements of T.C. Rule 32(a). T.C. Rule 23(a)(1). Examples of acceptable captions may be found in numerous exhibits in CCDM 35.11.1 and the Tax Litigation Guidebook available on the CC Intranet.

2. All documents filed with the Tax Court should include a title directly below the caption, in all capital letters, in boldface and/or underscored.

3. All documents filed with the Tax Court must contain a signature block that includes the name, in all capital letters, and title of the Chief Counsel, as follows:


    (NAME OF CHIEF COUNSEL)


    Chief Counsel


    Internal Revenue Service

4. All signatures on documents filed with the Tax Court, including on certificates of service included with filed documents, must include the date on which the signature is actually affixed to the document. T.C. Rule 23(a)(2), see _CCDM 35.1.3.2.2(4)_ . Signatures should not be post-dated to coincide with the date on which the document is served or filed, which the Clerk of the Tax Court will determine and separately note on the docket sheet for the case.


**35.1.3.1.2** **(07-31-2023)**

#### Clarity and Legibility

1. Attorneys must ensure that all documents filed with the Tax Court are clear and legible. T.C. Rule 23(c).

2. Documents and supporting attachments that have been photocopied, scanned, or otherwise reproduced should be reviewed prior to filing to ensure that they are clear and legible.


**35.1.3.1.3** **(07-31-2023)**

#### Size and Style

1. Documents filed with the Tax Court on paper should be produced using letter-size paper (8.5 by 11 inches) and documents filed with the Tax Court electronically should be transmitted in letter-size format, unless directed otherwise by the Tax Court. All documents should be filed with one-inch margins on all sides, unless necessary to accommodate letterhead or footnotes (but top and bottom margins should never be less than 3/4 inch). T.C. Rule 23(d).

2. Documents filed with the Tax Court must be produced using 14-point Times New Roman font, including all footnotes and quotations, unless directed otherwise by the Tax Court. To ensure that all documents filed on behalf of the Chief Counsel present a consistent form and appearance, proportional print fonts and/or point sizes other than 14-point Times New Roman may not be used on Tax Court documents. All documents must use double spacing throughout, except for footnotes, block quotations, captions, and signature blocks. T.C. Rule 23(d).


**35.1.3.1.4** **(07-31-2023)**

#### Binding and Covers

1. Paper documents filed with the Tax Court may only be bound using a removable fastener. T.C. Rule 23(e).

2. Paper document filed with the Tax Court should not include any separate cover or back. Cover sheets for briefs filed on paper should be printed on ordinary paper and fastened with the brief as its first page. _See_ CCDM 35.7.2.1.1.


**35.1.3.1.5** **(07-31-2023)**

#### Citations

1. Citations should follow the guidance in the "Bluepages" or equivalent section for non-academic legal documents in the current edition of _The Bluebook: A Uniform System of Citation,_ unless directed otherwise by the Tax Court.

2. In accordance with the Bluepages, attorneys may choose whether to underline or italicize case names in citations but must do one or the other consistently throughout any document filed with the Tax Course. _See_ T.C. Rule 23(f).


**35.1.3.2** **(07-24-2012)**

### Service and Filing of Documents

1. The petition and certain other documents are served by the Tax Court on the parties. Most documents, however, are served directly by the parties. See Exhibit 35.11.1–1, Issues Requiring Associate Office Review, for issues and/or documents which must be reviewed by an Associate office before being served or filed.


**35.1.3.2.1** **(07-31-2023)**

#### Service of Documents by the Tax Court

1. Certain documents are served by the Tax Court on the parties. Applicable procedures are described below.

2. **Petition**. Each petition filed with the Tax Court (including informal communications treated as imperfect petitions) receives a docket number, which is stamped on the original document and on all copies filed concurrently with the original. Thereafter, on each subsequent pleading or other document filed or lodged with the court, the docket number of the case must appear next to the caption. Effective January 1, 1962, docket numbers assigned to new cases filed with the court began with the number 101-62. The last two digits of the document number indicate the calendar year in which the petition was docketed with the court. Thus (with certain exceptions), the first petition filed each year is numbered 101-XX, with the last two digits (XX) reflecting the year in which the petition is filed.

3. **Other Documents Filed as Petitions**. Any doubt as to whether the initial document received by the court from a taxpayer is intended to be a petition is usually resolved by the court in favor of filing it as a petition, whether or not the document was accompanied by a filing fee or whether the required number of copies were received by the court.

4. **Required Copies**. The court will serve on the respondent a document filed as a petition even though the filing fee has not been paid. In general, the court will not serve upon the opposing party a motion, answer, or other document (other than a petition), unless the required copies are filed with the court. Generally, when filed in paper form, a signed original and one conformed copy are required to be filed with the court. Where filing is in more than one case (as a motion to consolidate, or in cases already consolidated), the number filed must include one additional copy for each docket number in excess of one. Copies of any attachments to the original must be attached to each copy to be served by the Clerk. _See_ T.C. Rule 23(b). See also the Tax Litigation Guidebook for the required number of copies of particular documents. The court, as a general rule, will not duplicate a document for service on the opposing party when sufficient copies have not been supplied to the court together with the original. This general rule is equally applicable to the respondent and to the petitioner.

5. **Amended Petition**. The Tax Court sometimes characterizes documents differently than they are titled by the parties. For example, the court will may add the word "Amended" before the preprinted word "Petition" on a form petition if a prior communication was treated as the "Petition" in the case. Any responsive pleading or other document filed by the respondent should conform to the caption on the document given by the Tax Court, not necessarily the one used by the petitioner. The [Tax Court’s web site](http://www.ustaxcourt.gov/) may be consulted to resolve questions concerning how the court characterized a particular document for filing.

6. **Inadequate Pleadings**. The court generally will take no independent action on the inadequacy of pleadings filed by the parties, except to issue an Order for Proper Petition and Filing Fee in the case of a timely but facially defective imperfect petition. If a document has been filed as a petition that respondent believes should not have been treated as a petition or is otherwise insufficient to confer jurisdiction on the court, it is the responsibility of the respondent to file an appropriate motion in order to get a ruling with respect to the perceived defect.

7. **Service by the Tax Court**. Petitions and any other documents to be served upon respondent through the Tax Court are served upon the Chief Counsel by the Clerk of the Court. T.C. Rule 21 also permits direct service on respondent of documents other than petitions.


**35.1.3.2.2** **(07-31-2023)**

#### Direct Service and Filing of Documents by Mail

01. Most documents are served by the parties directly. Applicable procedures are described below.

02. **Pre-filing Review**. See the Significant Issues List at Exhibit 35.11.1–1 , Issues Requiring Associate Office Review, for issues and/or documents which must be reviewed by an Associate office before being served or filed.

03. **Timeliness.** Every effort should be made to ensure that answers, motions, and other documents in paper form that are mailed directly to the Tax Court will be received by the court by the due date. If proof of timely mailing is not apparent on the face of the envelope transmitting the document or on the certificate of service, the Tax Court may reject and return a document received after the due date. The court may thereafter accept the document as timely if respondent can produce a copy of a receipt for certified mail that bears a timely United States postmark, a shipping document or receipt from respondent’s designated delivery service, or other proof of timely mailing with respect to those documents received after the due date. Establishing the timely mailing of a document is cumbersome and may be avoided if the document is received by the due date.

04. **Certificate of Service**. With respect to documents directly served, there is to be attached to each such document sent to the court a certificate of service, showing service on petitioners or their counsel. Use Form 9, Certificate of Service, at [Tax Court Rules, Appendix I](http://www.ustaxcourt.gov/rules/Appendix_I.pdf). Where copies of the document directly served are required to be filed with the court, a copy of the certificate of service should be attached to each copy. In all cases, the certificate must be dated and signed. The certificate of service for respondent must be executed by an attorney admitted to practice before the Tax Court. T.C. Rule 21(b). Under no circumstances may a certificate be signed by a secretary, law clerk, paralegal, or other person not admitted to practice before the court.

05. **Unadmitted Practitioner**. Where the petitioner’s attorney, CPA, or other representative is not admitted to practice before the Tax Court, service of papers must not be made on the unadmitted practitioner. Service will be made on petitioner, and the unadmitted practitioner should be notified by letter that the petitioner was served because the Tax Court does not recognize the individual as petitioner’s representative. If counsel who signs the petition is unadmitted at the time the petition is filed but is admitted prior to the filing of the answer, and enters an appearance in the case by the filing of an entry of appearance, service will be made on counsel. Otherwise, service will be made on petitioner.

06. **Manner of Service**. Respondent will utilize service by mail for most documents filed in paper form with the Tax Court. On occasion, service may be made by personal delivery. Service may be made by electronic means if the person served consented in writing, in which event service is complete upon transmission, but is not effective if the serving party learns that it did not reach the person to be served. **See** Tax Court Rule 21(b).

07. **Timely Service**. Documents will be served the same day they are mailed to the Tax Court.

08. **Accuracy of Certification**. The Field attorney will ensure that service is made on the date stated in the certificate of service.

09. **Improper Service**. If service is made on the wrong person(s), an incorrect address is used, or the served document is returned for any reason, a reasonable attempt should be made to re-serve the document with a cover letter to counsel or petitioner, indicating the circumstances surrounding the original service. An original document entitled "Amended Certificate of Service," which bears the caption of the case, describes the document in question, and shows that the document was re-served, should be prepared and filed with the court. The document to which the Amended Certificate of Service pertains may be attached to the document as an exhibit. The Amended Certificate of Service should itself be served on the opposing party, along with the document being re-served, and have a certificate of service attached to it.

10. **Transmittal to Tax Court**. Unless filed electronically, documents filed in paper form will be sent for filing with the Tax Court by direct overnight mail through the contract carrier (e.g., United Parcel Service or other). If there is any doubt as to whether a document will be received by the Tax Court on or before the due date, the Field attorney should work with the local support staff to ensure there is proof of timely mailing. Although the Tax Court will accept a UPS air bill as proof, the court cannot associate an air bill with an individual document mailed together with other papers in a transmittal package to the court. Thus, critical, time-sensitive documents for which respondent is relying on the timely-mailing rule to meet a court-imposed due date should be mailed individually. These overnight mail procedures are currently used for all transmittals to the Tax Court and for any other situations requiring that mail be expedited. Routine mail procedures will generally be used for transmittal of documents if circumstances do not require expedited handling.

11. **Contents of Mailing to Tax Court**. Two copies of a transmittal memorandum should be included in the envelope containing the paper documents to be directly filed with the Tax Court. The transmittal memorandum should be dated. The memorandum will reflect the UPS air bill receipt number, petitioner’s name(s), docket number(s), and the type of document(s) transmitted. The number of copies of documents to be provided to the court is stated in Exhibit 35.11.1–2, Direct Filing and Service of Documents. In the event the document served and/or directly filed pertains to more than one docket number such as for consolidated cases, an additional copy must be included for each additional docket number.

12. **Transmittal Memorandum**. The transmittal memorandum will generally be typed and must have correct spelling of petitioner’s name(s) and correct docket number(s). All documents transmitted in regard to a particular case should be listed consecutively on the form.

13. **Acceptance by Court**. A docket clerk at the Tax Court will check to see if all listed documents are, in fact, in the envelope. That clerk will then stamp one copy of the transmittal memorandum and return it to respondent’s Technical Services Support Branch (TSS) within P&A’s Legal Processing Division; one copy will be retained by the court. TSS will send the stamped copy to the Field Counsel office originating the transmission. The Tax Court’s docket clerk will note any omissions on the stamped copies of the transmittal memorandum. The stamped copy of the transmittal memorandum sent to the field should be compared against the retained copy of the memorandum to confirm that all documents listed on the transmittal were received by the court; both forms should be filed in the Field Counsel office with the retained documents evidencing timely mailing (e.g., UPS air bill).

14. **Monitoring Tax Court Receipt of Documents**. Field Counsel offices should maintain an accurate filing system for the transmittal memorandum. If the stamped copy of the transmittal memorandum is not received within 21 days after the mailing date to the Tax Court, the Field attorney should contact TSS to check the status. Each Field Counsel office should develop its own internal procedures to implement and facilitate direct filing.

15. **Discovery**. Interrogatories and requests for the production of documents and things and responses thereto will be sent directly by the Field attorney to petitioner or petitioner’s counsel, since these documents are not filed with the court.

16. **Direct Service on Respondent**. A response to a document filed by the petitioner generally should not be filed unless directed by the court. Nevertheless, if a document requiring a response is served directly on a Field attorney, the Field attorney should promptly commence preparation of the response and not wait for a notice of filing or other order directing a response from the court, since the court may set an imminent hearing date that gives insufficient time to prepare the response. Consideration should be given to requesting leave to file a response even if not ordered by the court. The response should be prepared early so that it can be sent to any appropriate Associate office in time for adequate review and timely filing.

17. Any motion or document that is not on the list of direct filed documents in Exhibit 35.11.1–2, Direct Filing and Service of Documents, must be sent to the Technical Services Support Branch (TSS.Assignments@irscounsel.treas.gov) with a copy to any Associate office attorney previously assigned for review prior to filing with the Tax Court. The Field attorney may transmit documents as e-mail attachments, which should also be directed to Technical Services Support Branch. The e-mail message should identify the case and document for review; specify the due date; indicate that the reviewer has approved the document; and mention any previous involvement by a member of an Associate office. The e-mail must not be designated" Private." Documents other than briefs requiring Associate office review generally are required to be submitted at least five business days prior to the due date to permit adequate review.

18. **Review by Associate Office if Significant Issue**. When a case involves a significant, sensitive, or unusual issue or a substantive issue that is on the list of issues for Associate coordination and review or when a case has been reported on the significant case report, the Field attorney should coordinate with the appropriate Associate office prior to filing any document with the Tax Court. This guideline applies to any document included in Exhibit 35.11.1–2, Direct Filing and Service of Documents, and to notices of objection or other response to motions filed by the petitioner.


**35.1.3.2.3** **(08-11-2004)**

#### Computation of Time

1. T.C. Rule 25 provides a method for computing time for an act, event, or default from which a designated period of time begins to run. The day of the act shall not be included, and the last day of the period so computed shall be included. If service is made by mail, then a period of time computed with respect to the service shall begin on the day after the date of mailing. Saturdays, Sundays, and all legal holidays shall be counted, with the following exceptions:



1. If the period prescribed is less than seven days, then intermediate Saturdays, Sundays, and all legal holidays in the District of Columbia shall be excluded in the computation

2. If any act is required to be taken or completed no later than a specified number of days _after_ a date certain, then the latest day of the period so specified shall not be included if it is a Saturday, Sunday, or legal holiday (i.e., in that case the day for timely completion of the act will fall on the next business day)

3. If any act is required to be taken or completed no later than a specified number of days _before_ a date certain, then the earliest day of the period so specified shall not be included if it is a Saturday, Sunday, or legal holiday (i.e., in that case the day for timely completion of the act will fall on the next _preceding_, or earlier, business day)

4. If a legal holiday falls on a Sunday, then Monday shall be considered a holiday; and, when a legal holiday falls on a Saturday, then Friday shall be considered a legal holiday. For example, generally all discovery must be completed no later than 45 days prior to the date set for call of the case from a trial calendar. When counting back in time from the trial calendar date, if the 45th day falls on a Saturday, Sunday, or legal holiday, the completion date for discovery would fall on the preceding Friday or other preceding business day. Moreover, if the 45th day falls on a Saturday and that Saturday happens to be a legal holiday, then the preceding Friday would automatically be considered a legal holiday for purposes of T.C. Rule 25. Under this scenario, the completion date for discovery would fall on the preceding Thursday or other preceding business day.


2. Pursuant to T.C. Rule 25(c), the Tax Court in its discretion may make longer or shorter any period provided by the Tax Court Rules. However, if the period is fixed by statute, the Tax Court cannot extend or shorten the period.


**35.1.3.2.4** **(08-11-2004)**

#### Court’s Notation on Served Documents

1. The Tax Court, on the first document served upon the respondent, will note thereon the postmark date as shown on the envelope in which the document was mailed to the court and the manner of mailing, i.e., regular, postmetered, registered, or certified mail. If the postmark date is illegible, it will be so noted. If a purported copy of the statutory notice is not attached to the original petition, the court will stamp the notation "Def. Notice NOT Attached to Orig."

2. It may be assumed that the original of the petition or motion is duly executed even though the served copy is not conformed. If the original petition is unsigned, the court will usually note that fact on the copy served on respondent. A petition executed by a representative admitted to the Tax Court will have stamped next to the representative’s name the notation "Admitted U.S. Tax Court." A petition that is executed by an unadmitted practitioner or other representative will have stamped on the served copy beside the conformed signature of such individual the notation "Not Admitted U.S. Tax Court." In addition, if the court does not recognize a practitioner who is admitted to the court as the petitioner’s representative (for example, because the attorney listed did not actually sign the document), the court will stamp the notation "Admitted, Not Recognized" on the service copy. Such notations are notifications to respondent that appropriate action should be taken to resolve any jurisdictional defects resulting from the signatures on the petition and to ensure that service of papers is made on the proper person.


**35.1.3.3** **(07-31-2023)**

### Small Tax Case Procedures

1. Title XVII of the Tax Court’s rules establishes special procedures to expedite the handling and disposition of Small Tax Cases (" S" cases) in accordance with section 7463. See T.C. Rules 170–174. The rules define the limits of "S" case jurisdiction and establish how "S" cases are handled by the Tax Court and by the parties.

2. Subject to petitioner’s election, a case may be an "S" case if it meets the dollar limitations under section 7463(a) and (f) and section 7436(c)(1) as to the amount of the deficiency in dispute. A petitioner may elect small tax case status in any case in which the amount of the deficiency placed in dispute (including any additions to tax, additional amounts and penalties) or claimed overpayment does not exceed $50,000 for any one taxable year in an income tax case; $50,000 in an estate tax case; $50,000 for any one calendar year in a gift tax case; $50,000 in employment taxes for each calendar quarter involved in a worker classification case under section 7436; $50,000 for any one taxable period or, if there is no taxable period, for any taxable event in the case of excise taxes under Code chapters 41, 42, 43, or 44 or under chapter 45 (windfall profit tax); claim for relief under section 6015(e) not in excess of $50,000; or an appeal under section 6330 in which the unpaid tax does not exceed $50,000. The deficiency is not added to any claimed overpayment in determining the jurisdictional amount. If the amount of the deficiency stated in the statutory notice exceeds $50,000 but the amount is reduced below $50,000 at the time the petition is filed (e.g., due to concessions by the parties), then the petitioner can elect to have the case designated an "S" case in the petition. T.C. Rules 171and 291(c).

3. A qualified petitioner who wishes to have a case handled under the "S" case procedure may so elect at the time of filing the petition or at any time prior to trial. T.C. Rules 171(c). Cases classified as "S" cases will be assigned the letter "S" after the docket number. The court occasionally does not honor a request for small tax case status if the deficiency notice or other determination letter is not attached to the petition. If petitioner in this situation elects small tax case status and the case otherwise qualifies, respondent should file a "Notice Regarding Small Tax Case Election" in which it is recited that petitioner elected small case status, and the case qualifies for such status. A copy of the relevant determination letter should be attached as an exhibit to the Notice. In no case may respondent elect small tax case status on behalf of a petitioner or on respondent’s own behalf.

4. The court, on its own motion or on the motion of a party, may enter an order directing that the "S" case designation be removed at any time prior to trial. In cases where the deficiency (including penalties and additions to tax) exceeds the statutory amount for a given year, respondent should move to remove the "S" case designation. If no order is entered prior to trial, the court shall be deemed to have concurred in petitioner’s election. _See_ T.C. Rule 171(d). After the beginning of a trial of an "S" case, but before the decision becomes final, the court may order that the proceedings be discontinued under section 7463 and that the case be tried as a regular case. Such an order under the Tax Court rules will be issued only if there are reasonable grounds for believing that the amount of the deficiency or the claimed overpayment in dispute will exceed $50,000, and the court finds that justice requires the discontinuance of the proceedings under section 7463, taking into consideration the convenience and expenses for both parties that would result from the order.

5. A decision entered in a case conducted under the small tax case procedure shall not be reviewed in any other court and shall not be treated as precedent for any other case. _See_ section 7463(b).


**35.1.3.3.1** **(07-24-2012)**

#### Small Tax Case Procedures for Collection Due Process Cases

1. Section 7463(a) provides that a case concerning a redetermination of a deficiency is eligible for small tax case treatment if the amount in dispute does not exceed $50,000 for any one taxable year or period. In contrast, section 7463(f)(2) provides that a CDP case under sections 6320 and 6330 may be conducted under "S case" procedures with respect to "a determination in which the unpaid tax does not exceed $50,000." Therefore, unlike the "for any one year" rule for deficiency cases, section 7463(f)(2) requires that the total unpaid tax, not just the amount of tax in dispute, for all tax periods at issue as of the date of the determination must not exceed $50,000 for a CDP case to qualify for small case status. In this context, the term "tax" includes all accrued and unassessed interest and penalties on the underlying tax liability, as well as all assessed interest and penalties. _Leahy v. Commissioner_, 129 T.C. 71 (2007); _Schwartz v. Commissioner_, 128 T.C. 6 (2007). _See_ sections 6601(e)(1) and 6665(a)(2). Amounts paid, credited, or assessed after the date of the determination should not be considered in determining eligibility.

2. When an attorney receives a CDP case with a small tax designation, the attorney must verify that the CDP case is actually eligible for the designation. If the attorney determines that the case is not eligible for the designation because the amount of the total unpaid tax, interest, and penalties, including all accruals, exceeded $50,000 as of the date of the determination, then the attorney should file a motion to remove the small tax designation as soon as possible. See Exhibit 35.11.1–172,, Motion to Remove Small Tax Case Designation in a Collection Due Process Case, for a sample motion.


**35.1.3.4** **(07-31-2023)**

### Designation of Declaratory Judgment Cases; Cases under Sections 6015, 6110, 6330, 6404, and 7436

1. The Tax Court identifies declaratory judgment cases by placing after the docket number a letter or descriptive designation of the category of declaratory judgment. A similar designation is used for certain other proceedings and for worker classification cases under section 7436.

2. The Tax Court uses the following identification terms or letters:



   - Section 6110 (Disclosure Actions) – D (with the prefix number next in order among all cases)

   - Section 6330 (Collection Due Process Cases) – L

   - Section 6404 (Interest Abatement Actions) – ABATEMENT

   - Section 7428 (Exempt Organization Cases) – X

   - Section 7436 (Worker Classification Cases) – EMPLOYMENT

   - Section 7476 (Employee Plan Cases) – R

   - Section 7478 (Governmental Obligation Actions) (Bonds) – B

   - Rule 82 (Application to Take Deposition Prior to Commencement of Case) – D (with a single digit prefix, e.g., 1–02"D" )


3. The Tax Court thus far has not specially designated declaratory judgment cases arising under section 6015, section 6234 (Oversheltered Return Actions) effective for partnership years ending after August 5, 1997, new section 7477 (Gift Tax Valuation Actions) effective for gifts made after August 5, 1997, or section 7479 (Estate Tax Installment Payment Actions) effective for estates of decedents dying after August 5, 1997.

4. In each such case the front outside cover of the legal file will contain the docket number followed by the appropriate term or letter designation.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-001-003#addtoany "Show all")

A2A