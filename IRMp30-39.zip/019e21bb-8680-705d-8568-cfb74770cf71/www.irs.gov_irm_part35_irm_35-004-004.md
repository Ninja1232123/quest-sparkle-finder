---
url: "https://www.irs.gov/irm/part35/irm_35-004-004"
title: "35.4.4 Gathering Information from Third Parties | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-004-004#main-content)

- 35.4.4  [Gathering Information from Third Parties](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149674112912)
  - 35.4.4.1  [Enforcement of Administrative Summonses](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641642496)
  - 35.4.4.2  [Informal Requests](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641704368)
    - 35.4.4.2.1  [Contacts Made During Litigation](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149670006976)
    - 35.4.4.2.2  [Procedures for Documenting Section 7602(c) Contacts by Counsel](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641579872)
    - 35.4.4.2.3  [Exception to Section 7602(c) Requirements When Notice Would Jeopardize Collection of Any Tax or May Involve Reprisal Against Any Person](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641701312)
  - 35.4.4.3  [Searching the Internet and Other Public Sources](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641220032)
    - 35.4.4.3.1  [Privacy and Disclosure Issues](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641292736)
    - 35.4.4.3.2  [Coordination of Other Than Read-Only Searches on a Publicly Available Website](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641301136)
  - 35.4.4.4  [Subpoenas](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149674111632)
    - 35.4.4.4.1  [Subpoenaed Witnesses](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641804128)
      - 35.4.4.4.1.1  [Timing and Approval](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641274784)
      - 35.4.4.4.1.2  [Documents in the Subpoena Package](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641838032)
      - 35.4.4.4.1.3  [Information Needed for the Subpoena Form](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641813184)
      - 35.4.4.4.1.4  [Copies of Subpoena](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641453760)
    - 35.4.4.4.2  [Service of Subpoena](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641858208)
    - 35.4.4.4.3  [Agreement to Appear](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641485056)
    - 35.4.4.4.4  [Subpoenas to Financial Institutions for Customer Records](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641602112)
      - 35.4.4.4.4.1  [Procedures for Issuing and Serving the Subpoena](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641599472)
    - 35.4.4.4.5  [Former Government Employees](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641724944)
    - 35.4.4.4.6  [Former Service Employees](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641722016)
    - 35.4.4.4.7  [Present or Former Employees of Congressional Committees](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641819072)
    - 35.4.4.4.8  [Witness in Prison](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641816544)
      - 35.4.4.4.8.1  [Writ of Habeas Corpus Ad Testificandum](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641406400)
    - 35.4.4.4.9  [Petitioner in Prison](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641295328)
      - 35.4.4.4.9.1  [Writ of Habeas Corpus Ad Testificandum](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641798768)
  - 35.4.4.5  [Depositions](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641638656)
    - 35.4.4.5.1  [Discovery Depositions](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641226688)
      - 35.4.4.5.1.1  [Consensual Depositions—T.C. Rule 74(b)](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641223008)
      - 35.4.4.5.1.2  [Non-Consensual Depositions—T.C. Rule 74(c)](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641287936)
      - 35.4.4.5.1.3  [Depositions of Expert Witnesses—T.C. Rule 74(b) and (c)](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149640474304)
    - 35.4.4.5.2  [Depositions to Perpetuate Testimony](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641409216)
      - 35.4.4.5.2.1  [Depositions Before Commencement of Case — T.C. Rule 82](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641808288)
      - 35.4.4.5.2.2  [Depositions Prior to Trial — T.C. Rule 81](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641284160)
      - 35.4.4.5.2.3  [Depositions After Commencement of Trial — T.C. Rule 83](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641325536)
      - 35.4.4.5.2.4  [Procedures for Taking Depositions](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641710672)
      - 35.4.4.5.2.5  [Expenses of Taking a Deposition](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641625744)
      - 35.4.4.5.2.6  [Execution and Return of the Deposition](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641622928)
      - 35.4.4.5.2.7  [Use of Deposition](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641472368)
      - 35.4.4.5.2.8  [Deposition Upon Written Questions](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149640463904)
      - 35.4.4.5.2.9  [Disadvantages of Depositions](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149640461600)
  - 35.4.4.6  [Witness Fees and Expenses](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641718928)
    - 35.4.4.6.1  [Specific Items of Claimed Fees and Expenses](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641714576)
    - 35.4.4.6.2  [Advance Payment of Witness Fees and Mileage](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149640455472)
    - 35.4.4.6.3  [Preparing the Witness Expense Voucher](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149640452896)
  - 35.4.4.7  [Use of Affidavits in "S" Cases](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641452288)
  - 35.4.4.8  [Expert Witnesses](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641446528)
    - 35.4.4.8.1  [Identifying the Expert Witness](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149642630640)
    - 35.4.4.8.2  [Contracting with, and Payment to, the "Outside" Expert](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641465120)
      - 35.4.4.8.2.1  [The Contracting Officer’s Technical Representative (COTR)](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641463392)
      - 35.4.4.8.2.2  [Field Attorney’s Role and Responsibilities](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641458704)
      - 35.4.4.8.2.3  [Procedures](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149641575424)
    - 35.4.4.8.3  [Uses of Experts Prior to Trial](https://www.irs.gov/irm/part35/irm_35-004-004#idm140149642746976)

# Part 35. Chief Counsel Directives Manual Tax Court Litigation

# Chapter 4. Pre-Trial Activities

# Section 4. Gathering Information from Third Parties

* * *

## 35.4.4 Gathering Information from Third Parties

#### Manual Transmittal

January 24, 2024

#### Purpose

(1) This transmits revised CCDM 35.4.4, Gathering Information from Third Parties.

#### Background

CCDM 35.4.4 is revised to reflect new requirements regarding third party contacts. Section 1206 of the Taxpayer First Act of 2019, Public Law 116-25 (133 Stat. 981), amended section 7602(c)(1) to provide that IRS officers or employees may not contact a third party with respect to the determination or collection of the tax liability of a taxpayer unless the taxpayer is first provided with advance notice that meets specified requirements. Specifically, the notice must identify the period, not to exceed one year, during which the IRS intends to make the contact, and unless otherwise specified by the Secretary of the Treasury, the IRS must provide the notice to the taxpayer no later than 45 days before the beginning of such period.

CCDM 35.4.4 is revised to clarify the requirements applicable to Chief Counsel attorneys for procuring expert witness services and to reflect the requirements for procuring expert witness services set forth in the Federal Acquisition Regulation.

#### Material Changes

(1) CCDM 35.4.4.2.2 is revised to reflect changes made by the Taxpayer First Act of 2019 to Internal Revenue Code section 7602(c) regarding notification of third-party contacts.

(2) CCDM 35.4.4.2.3 is revised to correct cross-references to the IRM.

(3) CCDM 35.4.4.5.1 is revised to update procedures and references to the Tax Court’s Rules of Practice and Procedure on discovery depositions.

(4) CCDM 35.4.4.8.1(6) is revised to provide that a Service specialist should only be called upon to serve as an expert witness if the field attorney is satisfied that the government can overcome allegations of bias.

(5) CCDM 35.4.4.8.1(7) is revised to make Chief Counsel expert witness procurement procedures consistent with and no more extensive than the requirements under the Federal Acquisition Regulation.

(6) CCDM 35.4.4.8.2.3(6) is revised to prevent the IRS from expending unnecessary resources tracking funds remaining on expert witness contracts.

#### Effect on Other Documents

CCDM 35.4.4, dated August 11, 2014, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(01-24-2024)

Richard G. Goldman

Deputy Associate Chief Counsel

(Procedure and Administration)

**35.4.4.1** **(08-11-2004)**

### Enforcement of Administrative Summonses

1. Under section 7602, the Service may issue administrative summonses to a third party in the course of an examination, a collection action, or a criminal investigation, to gather information and documents in regard to the taxpayer.

2. The interaction of an administrative summons and a Tax Court case is explained at CCDM 35.4.3.1.


**35.4.4.2** **(01-24-2024)**

### Informal Requests

1. The Tax Court’s Rules and interpretative case law on discovering information by informal means generally do not apply to discovery of third-party testimony and documents. See CCDM 35.4.3.2, _Informal Requests_, http://core.publish.no.irs.gov/irm/p35/pdf/irm35-004-003--2012-07-26.pdf. (An exception exists for a nonconsensual deposition of a third-party witness. In that case, Field Counsel must attempt informal communications before using T.C. Rule 74(c) procedures to take the deposition). The Tax Court’s rules and the case law do, however, provide useful guidelines. In every case in which a third party may have potentially relevant information, i.e., either documents or testimony, the Field attorney should contact the third party informally, either with or without the petitioner’s cooperation, before using depositions or “coercive” subpoenas.

2. See subparagraph 35.4.4.2.1 below regarding third-party contacts made during litigation, and compliance with the requirements of IRC 7602(c) for third-party contacts that do not relate to a matter being litigated.


**35.4.4.2.1** **(08-11-2014)**

#### Contacts Made During Litigation

1. Section 7602(c) provides that an IRS officer or employee may not contact any person other than the taxpayer with respect to the determination or collection of the taxpayer’s liability without providing advance notice that third-party contacts may be made. The statute does not give the taxpayer any right to prevent the contacts. Section 7602(c) also requires the Service to provide the taxpayer with a record of persons contacted upon the taxpayer’s request.

2. Section 7602(c) does not apply to third-party contacts made during litigation if the contact relates to a matter being litigated.

3. If the contact is made in connection with the determination or collection of a taxpayer’s liability and not with respect to a matter pending in litigation, then the requirements of the statute must be followed by Counsel employees unless another exception applies.

4. Contacts made with persons other than the taxpayer in order to avoid litigation or before a case is filed are considered section 7602(c) contacts.

5. The following are examples of section 7602(c) contacts that may be made by a Counsel employee:



   - To encourage voluntary compliance, a Counsel employee contacts a third party on whom a levy has been served.

   - A Counsel employee sends a last chance letter in a summons matter where the summoned party is not the taxpayer.


6. In the above examples, contacts are being made with respect to the determination or collection of the taxpayer’s liability during the administrative process. Therefore, section 7602(c) applies, and the Counsel employee must ensure that the notice and recordkeeping requirements of the statute are met.

7. Contacts made with other Service employees who are acting within the scope of their employment, or with Department of Justice attorneys in the course of litigation, do not constitute section 7602(c) contacts.


**35.4.4.2.2** **(01-24-2024)**

#### Procedures for Documenting Section 7602(c) Contacts by Counsel

1. The Taxpayer First Act of 2019 (TFA), Pub. L. 116-25 (July 1, 2019), revised IRC 7602(c)(1) to require the IRS to provide advance notice of the intent to contact third parties, specify in the notice the time period (not to exceed 1 year) in which contact will be made, and to send the notice no later than 45 days before the first contact with a third party. In most cases, the advance notice will have already been provided to the taxpayer by the time Counsel becomes involved in a case. However, prior to making any third-party contacts, Counsel must ensure that advance notice has been provided to the taxpayer, and that the time period specified in the notice has not expired. In the rare situation where the advance notice has not already been provided to the taxpayer, Counsel must give the advance notice. The Letter 3164, Third Party Contact, series must be used to satisfy the advance notice requirement of IRC 7602(c)(1), but must be tailored to the particular situation being handled by Counsel. It is anticipated, however, that Counsel will make few, if any, section 7602(c) contacts without the appropriate function employee being present or being a party to the contact.

2. The Service is required to make a record of all section 7602(c) contacts. IDRS has been adapted to store section 7602(c) contact information. Information regarding section 7602(c) contacts should be recorded on a Form 12175 and sent, within two working days of the contact, to the appropriate Third-Party Contact Coordinator.Third-Party Contact Coordinators are assigned to specific operating divisions, and may be located in field offices, service centers, and in the National Office. To locate the appropriate Third-Party Contact Coordinator, Counsel should refer to the list at the following website: https://portal.ds.irsnet.gov/sites/vl051/lists/thirdpartycontacts1/landingview.aspx.This website provides the names and telephone numbers of every coordinator for SB/SE, LB&I, W&I, and TEGE, as well as the locations served by each coordinator. For the Third-Party Contact Coordinator for Appeals, Counsel should refer to the program analyst listed on this website: http://appeals.web.irs.gov/tech\_services/disclosure/default.htm and should follow the procedures at IRM 8.1.6 for transmitting Forms 12175 by facsimile to Appeals Processing Services for entry into the third-party contact database.


**35.4.4.2.3** **(01-24-2024)**

#### Exception to Section 7602(c) Requirements When Notice Would Jeopardize Collection of Any Tax or May Involve Reprisal Against Any Person

1. Section 7602(c) does not apply if the Secretary determines for good cause shown that following its provisions would jeopardize collection of any tax or may involve reprisal against any person. This authority has been delegated to the Chief Counsel in Deleg. Order 25-12 (rev. 1), (formerly Deleg. Order 259), IRM 1.2.2.15.12. The Chief Counsel is authorized by this delegation order to redelegate this authority to subordinates of the Chief Counsel. On August 19, 1999, in CC Notice N(35)000-160(a), the Chief Counsel redelegated the authority “to determine for good cause shown that providing the taxpayer with general notice or notice of specific third-party contacts would jeopardize collection of any tax or may involve reprisal against any person” to all personnel in the Office of Chief Counsel required to make third-party contacts subject to the requirements of section 7602(c).

2. If it is determined that providing the taxpayer with prior notice or a record of a specific contact would jeopardize the collection of any tax, a Form 12175, Third-Party Contact Report Form, should nonetheless be completed timely and sent to the Third-Party Contact Coordinator once the jeopardy situation ceases to exist.

3. If it is determined that providing the taxpayer with advance notice or a record of a specific contact may involve reprisal against any person, then a Form 12175 should be sent to the Third-Party Contact Coordinator. The form should not contain any information that would identify the third party, and the word “Reprisal” should be written in where the third party’s name would otherwise go. The basis for making a reprisal determination should be documented in the case file.

4. Generally, a reprisal determination will be made on a case-by-case basis. However, if a taxpayer has been classified as a Potentially Dangerous Taxpayer (PDT), this serves as a basis for making a blanket reprisal determination only with respect to providing a record of specific contacts. In all other cases, the reprisal determination should be made based on facts known to the person making the contact. Sometime during the contact, the third party should be advised that a record of the contact will be provided to the taxpayer by the Service as required by law. Any concern that is raised by the third party regarding reprisal should be taken at face value. However, a general desire for confidentiality, without more, is insufficient to determine that the reprisal exception applies and the third party should be so advised.


**35.4.4.3** **(08-11-2004)**

### Searching the Internet and Other Public Sources

1. The Internet contains an enormous amount of information. With care, the Field attorney may use the Internet as a source of information.

2. Most businesses, groups, governmental entities, and nonprofit organizations, and even many individuals, have their own web pages on the Internet. In addition, information about those businesses, groups, governmental entities and nonprofit organizations, and individuals, may be found on the web pages of other persons, and in business directories and other documents found in libraries.

3. A web page may be located easily if the "URL" is known. URL stands for "Uniform Resource Locator" and it is a web page’s address. A URL often includes the name of the person or entity that sponsors the web page. URLs usually begin with "www" and usually end in one of these:



   - .com for commercial sites

   - .edu for U.S. higher education

   - .org for an organization

   - .mil for U.S. military

   - .gov for U.S. government

   - .net for Internet agencies

   - .state.XX.us for state government


4. Information may be found on the Internet by making searches through Library Internet Links, Search Engines, Portals, and Directories. Library Internet Links are located directly on the Chief Counsel Intranet home page. Searches may be made by a variety of methods, often depending on the searcher’s preferences. Some useful hints on searching are:



   - Be specific

   - Put the most important words first

   - Combine words into phrases whenever possible

   - Put phrases, such as "Internal Revenue Service," in quotes

   - Some search engines recognize AND, OR, NOT; others use + and - directly in front of a word

   - Use lower case letters unless referring to a connector or proper name


5. Internet searches should be made only as "read only" searches on publicly available websites. No attempt should be made to interact with a website. No search other than a "read only" search on a publicly available website may be made without prior coordination under CCDM 35.4.4.3.2.


**35.4.4.3.1** **(08-11-2004)**

#### Privacy and Disclosure Issues

1. Use of the Internet may give rise to questions under the Fourth Amendment or computer privacy laws, or under section 6103.

2. Some Internet sites have restricted access in whole or in part. These restrictions may give the website owner a reasonable expectation of privacy or other rights. In using the Internet, the Field attorney must not enter any restricted site or restricted portion of a site without appropriate authorization. _See_ CCDM 35.4.4.3.2, _Coordination of Other Than Read-Only Searches on Publicly Available Website_,http://core.publish.no.irs.gov/irm/p35/pdf/irm35-004-004--2004-08-11.pdf.

3. A Field attorney engaging in library or Internet searches must be sensitive to the restrictions of section 6103. _See_ CCDM 35.4.6.7, _Disclosure in Tax Court Cases,_ http://core.publish.no.irs.gov/irm/p35/pdf/irm35-004-006--2011-06-15.pdf. Because an Internet search regarding a Tax Court case will almost always involve use of the taxpayer’s name or other potentially identifying information, or other taxpayer information, use of the Internet raises disclosure issues. The Field attorney must keep in mind that a search on the Internet by definition goes outside Counsel’s and the Service’s own electronic systems.

4. Section 6103(k)(6) allows employees of the Service and Chief Counsel to make "investigative disclosures" under certain circumstances. In general terms, an Internet search would be permissible under section 6103(k)(6) if the same disclosure of information would have been a permissible investigative disclosure under more traditional circumstances (such as asking a question to a witness). Such a disclosure may be made under the statute only if it is "necessary" to make the disclosure in order to obtain information that is otherwise not reasonably available.

5. Generally, if the search can be performed successfully without using a taxpayer’s name and data, then the taxpayer’s name and data should not be used.

6. In making any library or Internet search, the Field attorney should be sensitive to the potential shortcomings of information appearing on web pages or other sources. Questions concerning this information include:



   - Credibility

   - Objectivity

   - Currency

   - Stability


7. In addition, the Field attorney must be sensitive to the fact that web sites operate at various levels of security.


**35.4.4.3.2** **(08-11-2004)**

#### Coordination of Other Than Read-Only Searches on a Publicly Available Website

1. \[Reserved\]


**35.4.4.4** **(08-11-2004)**

### Subpoenas

1. Tax Court Rule 147 prescribes the form of a subpoena and the method of issuing it. Upon request of a party, the court will send that party the original of the subpoena signed and sealed, but otherwise in blank. The party completes it before service. It is not necessary to return to the court the original or a copy of the served subpoena unless a record is to be made in court on failure of the witness to testify or otherwise comply. Subpoena forms may also be downloaded from the Tax Court’s web site at [www.ustaxcourt.gov](https://www.ustaxcourt.gov/).

2. Each Field Counsel should maintain a supply of Tax Court subpoenas which have been signed and sealed, usually by a deputy clerk. If additional blank subpoenas are needed, Field Counsel may download the forms from the Tax Court’s web site. Subpoenas issued for one session of the court, if not completed, should be retained by Field Counsel for use at succeeding sessions. Completed subpoenas should not be altered in any way.


**35.4.4.4.1** **(08-11-2004)**

#### Subpoenaed Witnesses

1. With only a few exceptions, all witnesses for the respondent should be subpoenaed. Ordinarily, the petitioner is not subpoenaed as a witness for the respondent, even though the attorney may desire to elicit information from petitioner either on direct or on cross-examination in support of the government’s position. However, it is proper to subpoena the petitioner when petitioner’s testimony is critical to respondent’s case or to require production of documentary material in petitioner’s possession or control when it is essential or desirable to have such documentary materials at the trial. Respondent also does not ordinarily subpoena witnesses from federal and state departments or agencies, unless the department or agency requests that a subpoena be issued. Respondent must not subpoena a witness who is to testify solely on behalf of the petitioner, even if requested to do so as an accommodation to petitioner.

2. Although a subpoena is used to compel attendance in court, subpoenas serve other purposes in connection with their function. For example, a witness who is an employee of an employer unconnected with the trial will use the subpoena to secure the employer’s approval of absence on trial day. In addition, the subpoena will make a non-petitioner witness eligible for a witness fee, use of common carriers, and lodging at the government rate, and expense reimbursements.


**35.4.4.4.1.1** **(08-11-2004)**

##### Timing and Approval

1. The time for the issuance of necessary subpoenas will vary from case to case depending to a large extent upon the finalization of stipulations. The issuance of subpoenas to essential witnesses, or for obtaining essential documents, should not be indefinitely delayed in the mere hope that facts to be established by such witnesses or documents will be stipulated. Often, the issuance of a subpoena may expedite agreement on a stipulation. To be effective in enforcing the attendance of the witness, a subpoena must be served on the witness a reasonable time in advance of its return date. A "reasonable time" will vary from witness to witness depending upon the location of the residence of the witness and the place of trial and, in the case of a subpoena duces tecum, the nature of the documents and records called for by the subpoena. A witness is entitled to sufficient notice to arrange personal affairs to enable attendance at the session of the court. If the subpoena calls for the production of documents and records, the witness is entitled to a reasonable time to gather records. A subpoena served after its return date is not enforceable.

2. The subpoenaing of the witness (and documents) must be approved by the Field attorney’s reviewer. Such approval will be indicated by initialing the initialed copy. Before approving the service of a subpoena, the reviewer should be reasonably satisfied that the subpoena is addressed to the proper witness and that it can be enforced. Prior to preparing the subpoena, the attorney should consult with the reviewer with respect to the witnesses to be called. This practice should be observed particularly where there is doubt that the reviewer will approve issuance of the subpoena.


**35.4.4.4.1.2** **(08-11-2004)**

##### Documents in the Subpoena Package

1. In addition to the subpoena form itself, the subpoena package includes the following items, all of which can be found in the Chief Counsel macros:



   - Memorandum to the appropriate Territory Manager, asking that an Service employee serve the subpoena

   - Form 2431, Subpoena Instructions and Questionnaire

   - Agreement to Appear

   - Letter to witness being subpoenaed and Form RC-Witness, Information Required of Subpoenaed Witnesses

   - Notice of Obligation of Witness Fees (Subpoena)

   - SF 1157, Claim for Witness Attendance Fees


2. Additional information on each of these items may be found in the Tax Litigation Guidebook at the F&M Intranet website.


**35.4.4.4.1.3** **(01-24-2024)**

##### Information Needed for the Subpoena Form

1. Caption of Case and Docket Number. The caption of the case should be the same as that given in the petition, or as changed by an order of the court. The docket number should be the docket number of the case of the petitioner whose name is stated in the caption. If the witness is to testify in consolidated or related cases, the subpoena should be issued in the name of the petitioner with the lowest docket number and, after his/her/its name, add the words "et al." or "et ux.," , etc., whichever is applicable. All of the docket numbers of all cases in the consolidated group should be listed in numerical order, as required by the court’s rules. Even if one docket is disposed of by settlement or otherwise, the subpoena will remain in force for all of the other cases.

2. Date and Place. The hour, the day of the month, and the month and year the witness is to appear should be stated. The complete address of the location where the Tax Court session will be held or the deposition is to be taken should be specified. Except in unusual circumstances, the time and date should be shown as the first day of the session of the court, as specified on the trial notice. It is generally inadvisable to subpoena a witness to appear on a later date when the actual trial is expected. Field attorneys must not subpoena witnesses, on behalf of the respondent, for the sole or principal purpose of testifying as the petitioner’s witness.

3. Records Subpoenaed. A subpoena can serve a discovery function, but it should sufficiently describe the records. A too broadly worded subpoena may not be enforced, because the relevance of the requested documents may be less evident. Each document or record required to be produced at the trial should be set forth separately and described adequately. The documents should be numbered consecutively. If the space provided on the subpoena form is inadequate, a sheet should be attached listing all of the documents, and the following words should be inserted in the appropriate space on the subpoena: "The documents or records listed on the attached sheet." There may be circumstances when the attorney reasonably believes that certain records or documents exist but is without information as to their particular details, or may wish to ensure that all documents relating to a specific transaction will be produced at the trial. In such a case, after listing specifically the pertinent documents and records of which the attorney is aware, it is appropriate to call for any other document or record pertaining to the transaction. If no documents or records are sought, and the subpoena is thus only for the appearance of the witness, the words "and to bring with you" should be crossed out.

4. Dating. This can be accomplished by typing out the original subpoena and making all copies by photocopy.

5. Attorney. In the space provided for the name of the attorney, type the name of the Field attorney and the Field attorney’s telephone number. Under this, cross out the word "(Petitioners)" following "Attorney for."

6. Return on Service. Tax Court Rule 147(b) provides that service of a subpoena may be made by any person who is not a party and is not less than 18 years of age. Typically, respondent’s subpoenas are served by a revenue agent or revenue officer. The person making the service must date, sign, and acknowledge the "Return on Service" before someone in the Service authorized to administer oaths (usually another revenue agent or revenue officer). The portion of the "Return on Service" as to the tendering to the witness of fees and mileage is not applicable to witnesses for the Service and should not be completed by the server. _See_ T.C. Rules 147(b) and 148.


**35.4.4.4.1.4** **(08-11-2004)**

##### Copies of Subpoena

1. The original and at least three copies of the subpoena will be necessary. The initialed copy will be placed in the legal file. One copy must be left with the witness, after the server has shown the original to the witness. Another copy must accompany the expense voucher so that the fees and expenses of the witness will be paid. When the original subpoena is returned by the server with the Return on Service completed, it should be kept with the other documents needed at trial, so that it will be available in the event it becomes necessary to ask the court to enforce compliance with the subpoena. After trial, the original should be filed in the legal file.

2. Generally, it is not necessary to send a copy of the subpoena to Division Counsel officials. However, in instances indicated below, a copy of the subpoena should be sent to Division Counsel at the time the original subpoena is sent to the Territory Manager for service:



   - When the case would appear to create considerable public interest because the petitioner is a prominent or notorious person

   - When the witness subpoenaed is so prominent or notorious that the appearance and testimony are likely to create considerable public interest

   - In any other instance where it appears that Division Counsel, or an Associate office will receive inquiries about the subpoena.


**35.4.4.4.2** **(08-11-2004)**

#### Service of Subpoena

1. Unless standing procedures exist between Field Counsel and an operating division in the vicinity in which the witness resides, the Field attorney or Associate Area Counsel should contact the Territory Manager for that vicinity informally to arrange a procedure for service of the subpoena. If more than one attorney group is responsible for trials on a specific calendar, the Associate Area Counsel for all those groups should work together to coordinate service of subpoenas, to reduce burden on client offices. When the subpoena has been properly authorized, the subpoena package completed, and the procedure for service agreed on, the package should be sent to the personal attention of the Territory Manager (or, in the Territory Manager’s discretion, to the attention of a Team Leader or other delegate), by a means best suited to avoid delay. A transmittal memorandum may cover any number of subpoenas, provided they are all within the same vicinity, because it is possible that one employee will be assigned to serve all of them. _See_ Exhibit 35.11.1–90. All subpoenas should be prepared and sent to the Territory Manager for service as far as possible in advance of the date the witness is required to appear.

2. The reverse of Form 2431, Subpoena Instructions and Questionnaire, sets out the general method of service and how it is to be accomplished. Any difficulties which may occur in the service of the subpoena should be anticipated as far in advance of the session of the court as practicable in order to allow sufficient time for the service and for the witness to obtain the documents called for. If the attorney has any information indicating possible difficulty in the service or possible attempts to avoid service, this information should be included in the memorandum to the Territory Manager. Any other special instructions Field Counsel wishes communicated to the agent or the witness should also be explained in the transmittal memorandum. Special instructions given the agent should be clear and specific so there is no misunderstanding as to what the agent is to do or avoid. If the Field attorney wants the serving agent to interview the witness, the transmittal memorandum should so state, and should be specific in the questions to be asked and the information to be obtained.

3. The Form 2431 sent to the Territory Manager will contain the name, address, and telephone number of the attorney to whom the case is assigned. In nearly every case, it is good practice to ask that the agent contact the attorney prior to service of a subpoena, and to again contact the attorney if the agent encounters any difficulty in serving the subpoena. If no prior contact is made, it is a good idea to request that the report returning the original served subpoena contain the name, address, and telephone number of the server.

4. At the time of serving the subpoena, the agent will also deliver a letter from Chief Counsel to the witness. A sample letter is contained in the Chief Counsel macros. _See_ Exhibit 35.11.1–91. This letter will note the Field attorney’s name and telephone number, explain the need for the appearance by the witness, and explain matters pertaining to witness fees and expenses. Additional information concerning travel (explained in the Tax Litigation Guidebook on the F&M Intranet website), may be included. The letter may be modified in other ways if there has been extensive contact between the Field attorney and the witness. If the witness is hostile to respondent, the letter may be modified to include additional information or exclude language applicable only to cooperative witnesses.


**35.4.4.4.3** **(08-11-2004)**

#### Agreement to Appear

1. In general, the Field attorney must consistently instruct every subpoenaed witness to comply strictly with the terms of the subpoena, including the time for appearance.

2. Many witnesses, although understanding their duties under the subpoena, wish to keep the interruptions to their personal affairs to a minimum, and ask Field attorneys to schedule their appearances at a specific time. Despite the seeming reasonableness of such requests, the Field attorney will pose risks to the case and to the attorney’s own stature in the eyes of the presiding judge if any such agreement is made without very careful planning and consideration. The time of the Tax Court judges is valuable, and most do not wish to spend it waiting for the arrival of a witness.

3. In a limited number of circumstances, with the concurrence of the Field attorney and the Field attorney’s reviewer, the witness may be relieved from the requirements to appear at calendar call and remain near the courtroom until the case is called. This arrangement is offered as a courtesy to cooperative witnesses. It will normally not be offered to a hostile witness. Appropriate circumstances for use of this arrangement include:



   - If the judge, on request, sets the case for trial, or schedules a witness to testify, at a time and date certain

   - If the witness lives or works a very short distance from the courtroom

   - If the attorney is certain that other witnesses are, or could be, available to testify for the entire time necessary for the witness to travel to court, and the flow of the trial will not be interrupted


4. In appropriate circumstances, if the witness agrees to appear in court immediately when notified by respondent, or at an agreed time, the witness may be excused from responding on the return date of the subpoena. The witness must be informed that, if there is no agreement to this appearance condition, the witness will be required to respond on the date specified in the subpoena and cannot depart without leave of the court. If such an agreement is made, it will be set out in an Agreement to Appear form, signed by the witness. _See_ Exhibit 35.11.1–92. If no agreement is being requested, the form subpoena instructions should be modified.

5. It is the responsibility of the attorney to notify all witnesses, after the court sets the specific trial date, of the date and hour they are to appear in court. In order to do this, the attorney must have the home, work, and any other telephone number of every witness.

6. When witnesses have been instructed not to appear in court until notified by the attorney, each witness should be notified by telephone immediately upon the continuance or settlement of the case. This may be confirmed by letter if desired, especially if the case is continued and the witness may be needed later. This notification will permit the witness to proceed with normal activities. The notification should be made not only to subpoenaed witnesses but to expert witnesses and personnel in other governmental departments and agencies who are assisting the attorney in the preparation and trial of the case.


**35.4.4.4.4** **(08-11-2004)**

#### Subpoenas to Financial Institutions for Customer Records

1. The Right to Financial Privacy Act of 1978, Pub L. No. 95–630, tit. XI, 92 Stat. 3697, codified at 12 U.S.C. §§ 3401 through 3422, imposes a number of restrictions on access by government authorities to customers’ records maintained by financial institutions. Of immediate application to Tax Court litigation are sections 1103, 1107, 1110, 1111 and 1115; 12 U.S.C. §§ 3403, 3407, 3410, 3411, 3415.

2. The Act applies only where the customer is a "third party," i.e., not a party to the Tax Court litigation, and only where the third-party customer is a "person" or authorized representative of a "person." As defined in section 1101(4) of the Act, "person" includes only an individual or a partnership of five or fewer individuals. It does not include a corporation or trust.


**35.4.4.4.4.1** **(08-11-2004)**

##### Procedures for Issuing and Serving the Subpoena

1. Section 1107 of the Right to Financial Privacy Act prescribes a very specific procedure which must be followed literally when a Tax Court subpoena is served upon a financial institution (as defined in section 1101(1)) to secure financial records of a customer who is not a party to the Tax Court litigation. _See_ 12 U.S.C. § 3413(e):



1. On or before the date the subpoena is served on the financial institution, a copy of it must either be served personally on the customer or mailed to the customer’s last known address. (If mailing is utilized, use of certified mail is recommended, though not literally required by the act).

2. The customer must be given the notice specified in section 1107, accompanied by a motion to quash and sworn statement. _See_ Exhibits 35.11.1–93 through 35.11.1–95.

3. The customer must be allowed either 14 days from the date of mailing or ten days from date of service to file a sworn statement and motion to quash with the Tax Court.

4. If the customer fails to move to quash within the specified time periods, or if the customer’s motion to quash is denied by the Tax Court, the Associate Area Counsel or other appropriate reviewer of the Office of Chief Counsel must furnish a signed certificate to the financial institution that the Office of Chief Counsel has complied with the provisions of section 1107 (and, if applicable, section 1110). _See_ Exhibits 35.11.1–96 and 35.11.1–97.


2. In any instance in which section 1107 is applicable, the subpoena should be served at least 30 days prior to its return date, to allow for the 14 day customer notification period and the time needed for the Tax Court to rule on any motion to quash.

3. In instances where financial records are subpoenaed pursuant to section 1107, the financial institution must be reimbursed for reasonable costs incurred in searching for, assembling, reproducing, or transporting the documents described in the subpoena. The schedule of such costs is published in 12 C.F.R. § 2193. In all other instances, a subpoenaed financial institution may be entitled only to fees, per diem, and mileage provided in 28 U.S.C. § 1821.


**35.4.4.4.5** **(08-11-2004)**

#### Former Government Employees

1. Since a former governmental employee is not subject to the direction and control of a governmental agency, it is necessary that subpoena be issued to the individual employee, if the individual’s testimony is essential to support the respondent’s position.

2. If the subject matter of the individual’s testimony will relate to information or documents which came to the individual’s attention with respect to official transactions in which the individual participated in the former governmental capacity, it is advisable to contact their former department or agency before a subpoena is issued. In this type of situation, a letter should be prepared for the Area Counsel’s signature to the individual’s former governmental department or agency, setting forth the issues involved and a brief statement of the nature of the prospective testimony relative to the official information or transactions. Inquiry should be made as to whether there is any objection to the disclosure of such official information or transactions. In addition, inquiry should be made as to whether any present employee of such department or agency is a qualified witness with respect to such matters and, if so, whether the services of a present employee would be made available for assistance in the preparation and trial of the case.

3. After receipt of an answer from such department or agency, it will be determined whether the former governmental employee will be subpoenaed or whether the evidence will be introduced through a present employee.


**35.4.4.4.6** **(08-11-2004)**

#### Former Service Employees

1. Since a former Service employee is not subject to the direction and control of the Service, it may be necessary that a subpoena be issued to the individual former employee, if the individual’s testimony is essential to support the respondent’s position. _See_ CCDM 35.4.4.4.1. Unless an agreement is reached to employ the former employee as an expert or to reemploy the former employee, all directives pertaining to third party subpoenaed witnesses will apply.

2. Before any decision to subpoena a former employee is made, the Field attorney should ascertain whether any present employee of the Service is a qualified witness with respect to the matters in dispute, and, if so, whether the services of a present employee may be made available for assistance in the preparation and trial of the case.


**35.4.4.4.7** **(01-24-2024)**

#### Present or Former Employees of Congressional Committees

1. Present or former employees of congressional committees generally may not testify with respect to any matter with which they became aware as a part of their official duties. Such witnesses should not be subpoenaed without approval of Division Counsel after coordination with P&A Branches 6 & 7.

2. If it is necessary or desirable to obtain, from a present or former employee of a congressional committee, testimony with respect to hearings before congressional committees, it may be necessary for the appropriate House of Congress to pass a resolution authorizing the present or former employee to testify. In this instance, after approval of Division Counsel, Field Counsel should make a request to the Associate Chief Counsel with jurisdiction over the subject matter of the litigation through the Technical Services Support Branch with a copy to P&A Branches 6 & 7, giving the name of the congressional committee, the name and present address of the employee or former employee of the committee, the position with the committee, the nature of the testimony to be obtained, and the reasons supporting the necessity for such testimony. Depending upon the importance of the issues at stake, the appropriate officials, upon receipt of the request from Field Counsel, will take appropriate action through legislative liaison channels to attempt to obtain the necessary resolution of the appropriate House of Congress.


**35.4.4.4.8** **(08-11-2004)**

#### Witness in Prison

1. A witness for the respondent who is in a federal or state prison is not subpoenaed, unless a subpoena is specifically requested by the appropriate federal or state official.

2. The trial or other disposition of a case should not be unduly delayed by reason of an essential witness being in prison, if arrangements can be made for the testimony at the trial. Where feasible, the witness should testify by deposition or through stipulated testimony in lieu of appearing at trial. _See_ CCDM 35.4.4.5.


**35.4.4.4.8.1** **(01-24-2024)**

##### Writ of Habeas Corpus Ad Testificandum

1. If an essential witness for the respondent is a prisoner in a federal or state prison or is under federal control, whose testimony cannot be stipulated and who cannot be deposed in lieu of appearing at trial, Field Counsel should prepare a Motion for Writ of Habeas Corpus Ad Testificandum and direct file it in the Tax Court. If there is any suggestion that prison officials or authorities may be reluctant to honor the writ, the Field attorney should contact P&A Branches 6 & 7 for guidance before filing the Motion for Writ of Habeas Corpus Ad Testificandum.

2. The Motion for Writ of Habeas Corpus Ad Testificandum should set forth the facts that the Tax Court case is set for trial at a stated time and place, the name and identification number of the prisoner, the name and location of the prison, the name and address of the warden, and any other information which might aid the court in securing the presence of the witness at trial. The motion should state specifically that the prisoner is an essential witness on behalf of the government. _See_ Exhibit 35.11.1–98. The information provided to the court should be as current as possible.

3. The Tax Court will assume responsibility for drafting and delivering any Writ of Habeas Corpus Ad Testificandum it issues, and for making arrangements with the U.S. Marshal’s office for transportation of the witness.

4. It is essential that any Motion for Writ of Habeas Corpus Ad Testificandum reach the court reasonably in advance of the trial date. Preferably, the motion should be filed at least four to six weeks before trial.


**35.4.4.4.9** **(08-11-2004)**

#### Petitioner in Prison

1. A petitioner who is in state or federal prison will not be subpoenaed by respondent.

2. If the petitioner is an essential witness for the respondent and is a prisoner in a federal or state prison or is under federal control, Field Counsel should consider use of a Motion for Writ of Habeas Corpus Ad Testificandum. _See_ CCDM 35.4.4.4.8.1.


**35.4.4.4.9.1** **(08-11-2004)**

##### Writ of Habeas Corpus Ad Testificandum

1. Usually, when the petitioner is in prison, the petitioner will not be an essential witness for respondent. Nevertheless, in the interest of moving the case to completion, when the case is placed on a calendar, the Field attorney should consider advising the petitioner by letter of the procedure for obtaining a Writ of Habeas Corpus Ad Testificandum. The letter should be written as early as possible after the case is set for trial, in order to give the petitioner and the Tax Court sufficient time to make the necessary arrangements. A sample letter to a petitioner advising of these procedures can be found in Exhibit 35.11.1–99.

2. Because cases of incarcerated petitioners tend to linger on the court’s docket for a long time, the Field attorney should keep a written record of all contacts made with the petitioner, especially those advising of the procedures for obtaining a Writ of Habeas Corpus Ad Testificandum or suggesting methods of proceeding that will not require petitioner’s actual appearance in the courtroom. All of these records will be useful in the event it later becomes appropriate to file a motion to dismiss for lack of prosecution and, if appropriate, a motion for a default judgment or to try those issues on which respondent has the burden of proof in the event it is necessary. As a general rule, the Tax Court will not dismiss a case on the ground that the petitioner has failed to prosecute the case unless it can be shown that less harsh alternatives to dismissal were considered by the Tax Court (e.g., depositions, continuing the case), and that petitioner did not attempt to take any of the necessary steps. In some instances, due to practical realities and as an accommodation to the court, respondent may consider filing a motion for a writ even when respondent does not require petitioner’s testimony as part of respondent’s case.

3. In the rare event a question as to the payment of costs of transporting the prisoner is actually presented as a result of respondent’s Motion for a Writ of Habeas Corpus Ad Testificandum, the Field attorney should refer the question to the F&M Office Manager/Administrative Operations Specialist/Support Team Leader.


**35.4.4.5** **(08-11-2004)**

### Depositions

1. Depositions almost always involve some costs for the respondent. T.C. Rule 81(g). Before consenting to the taking of any deposition or attempting to take a deposition without petitioner’s consent, the Field attorney should make arrangements for payment with the F&M Office Manager/Support Team Leader. Likewise, if a deposition is scheduled to occur over respondent’s objection, arrangements for payment of expenses should be made with F&M

2. Making arrangements for the taking of a deposition in accordance with the rules of the Tax Court consumes a considerable amount of time. Even more time is required to process an application for the taking of deposition on written questions. The Tax Court will not entertain an application to take a deposition which is filed too late to permit full opportunity for a party or a witness to object to the taking of such deposition and to be heard on the objection, or if the order will be entered too late to secure its timely delivery to the officer before whom such deposition is to be taken, or if the deposition will not be completed and reported on a timely basis.


**35.4.4.5.1** **(01-24-2024)**

#### Discovery Depositions

1. A party, nonparty, or expert witness may be deposed for discovery purposes upon the consent of all the parties under T.C. Rule 74(b). A party, nonparty, or expert witness may be deposed without the consent of all the parties under T.C. Rule 74(c).

2. Discovery depositions may be taken only in connection with a pending case. A transcript must be made of every deposition. The transcript of a discovery deposition (with any attached exhibits) is not filed directly with the court by the reporter. T.C. Rule 74(e)(1).

3. Unless the court orders otherwise for the convenience of the parties and witnesses and in the interest of justice, and subject to the provisions of the rules which apply more specifically, depositions may be taken in any sequence with written interrogatories, production of documents or things, examination by transferees, and requests for admission. The fact that a party is engaged in taking depositions shall not operate to delay the taking of depositions by any other party. Depositions and discovery procedures are not to be used in a manner or at a time which would delay or impede the progress of the case toward trial status or the trial of the case on the date for which it is noticed, unless the court orders otherwise. Unless the court orders otherwise under T.C. Rule 103, the frequency of use of depositions is not limited.


**35.4.4.5.1.1** **(01-24-2024)**

##### Consensual Depositions—T.C. Rule 74(b)

1. A discovery deposition upon consent of all parties requires a stipulation filed in duplicate with the court. T.C. Rule 74(b)(1).

2. A consent discovery deposition may be taken by oral examination or upon written questions, although the use of written questions is disfavored and is not to be used in the absence of a special reason. T.C. Rule 74(e)(2).

3. For the most part, the procedures for a consent discovery deposition are the same as in taking a deposition for presentation of evidence by stipulation pursuant to T.C. Rule 81, and most other aspects of a consent discovery deposition are governed by other provisions of T.C. Rule 81. **See**T.C. Rule 74(f).

4. Tax Court Rules 74(b) and (c) provide special rules for notice to, and objections by, nonparty witnesses.

5. A Rule 74 deposition must be taken within the time for completion of discovery under T.C. Rule 70(a)(2).


**35.4.4.5.1.2** **(01-24-2024)**

##### Non-Consensual Depositions—T.C. Rule 74(c)

1. A deposition of a party, nonparty witness, or expert witness without the consent of all parties is considered an “extraordinary method of discovery,” to be used only where discoverable testimony, documents, or things are unobtainable through informal communication or by deposition taken with consent of the parties. **See** T.C. Rule 74(c)(1)(B).

2. Most aspects of a non-consent discovery deposition are governed by provisions of T.C. Rule 81 as well as other applicable rules. _See_ T.C. Rule 74(f).

3. T.C. Rule 74(b) and (c) contain special rules for notice to, and objections by, other parties and the nonparty witness. Within 15 days after service of the notice of deposition, a party or a nonparty witness may object to the deposition. Any motions to compel under this rule are required to be reviewed in the same manner as other discovery enforcement motions requiring Associate Chief Counsel review.

4. Although a deposition under Rule 74(c) of a nonparty witness may be taken without leave of court, it may not be taken until after a notice of trial has been issued or after the case has been assigned to a judge or special trial judge. If neither has occurred, and a Rule 74(c) deposition is needed, a motion to assign the case to a judge or motion to calendar for trial should be filed and granted before notice of deposition is issued.

5. A Rule 74(c) deposition must be taken within the time for completion of discovery under T.C. Rule 70(a)(2).


**35.4.4.5.1.3** **(01-24-2024)**

##### Depositions of Expert Witnesses—T.C. Rule 74(b) and (c)

1. A deposition of an expert witness, to which all the parties consent, is governed by T.C. Rule 74(b). **See**CCDM 35.4.4.5.1.1. _See_ CCDM 35.4.4.5.1.1.

2. A deposition of an expert witness to which all parties do not consent is considered an extraordinary method of discovery, and may be taken only pursuant to an order of the Tax Court. T.C. Rule 74(c)(4).

3. A non-consensual deposition of an expert under T.C. Rule 74(c)(4)(A) is limited to:



   - The knowledge, skill, experience, training or education that qualifies the witness to testify as an expert

   - The opinion of the witness with respect to the issue in dispute

   - The facts or data that underlie that opinion

   - The analysis of the witness, showing how the witness proceeded from the facts or data to draw the conclusion that represents the opinion


4. A deposition under T.C. Rule 74(c)(4) may be taken only after a notice of trial has been issued or after a case has been assigned to a judge. If neither has occurred, and a Rule 74(c)(4) deposition is needed, a motion to assign the case to a judge or motion to calendar for trial should be filed. The deposition must be completed at least 45 days prior to the calendar call. T.C. Rules 70(a)(2).

5. The party wishing to depose an expert witness under T.C. Rule 74(c)(4) must file a written motion containing the information required by T.C. Rule 74(c)(4)(B). If the deposition is to be by written questions, the questions must be attached to the motion. If the deposition is to be video recorded, the procedures in T.C. Rule 81(j) apply. Any objection to the motion for order to depose an expert witness shall be filed within 15 days after service of the motion. A hearing on the motion will be held by the court only if it so directs. If the court approves the motion for order to depose an expert, the court will issue an order, which includes the name of the person to be examined, the time and place of the deposition, the officer before whom it is to be taken, and whether the deposition will be videotaped (if requested).

6. Tax Court Rule 74(d) contains provisions for the use of the deposition as the expert witness report required by T.C. Rule 143(g)(1). The actual taking of the expert’s deposition will not reduce the 30 day deadline imposed by T.C. Rule 143(g)(1), unless the court determines otherwise for good cause. T.C. Rule 74(d). A deposition of an expert may also be used in the manner set forth in T.C. Rule 81(i). T.C. Rule 74(f).

7. The Tax Court may, on its own motion and in the exercise of its discretion, order the taking of the deposition of an expert witness. In this situation, the court may also order the allocation of cost as it deems appropriate. T.C. Rule 74(c)(4)(C). If the court orders such an order allocating any expense to respondent, the Field attorney should contact the F&M Office Manager/Administrative Operations Specialist/Support Team Leader immediately and make arrangements for payment. In other cases, T.C. Rule 74(c)(4)(D) controls matters involving expenses of the deposition.


**35.4.4.5.2** **(08-11-2004)**

#### Depositions to Perpetuate Testimony

1. This section discusses depositions to perpetuate testimony.


**35.4.4.5.2.1** **(08-11-2004)**

##### Depositions Before Commencement of Case — T.C. Rule 82

1. For a discussion of depositions to perpetuate testimony prior to the filing of a petition in the Tax Court, _see_ CCDM 35.4.1.10, _Depositions Before Commencement of Case - T.C. Rule 82_, http://core.publish.no.irs.gov/irm/p35/pdf/irm35-004-001--2013-02-07.pdf.


**35.4.4.5.2.2** **(08-11-2004)**

##### Depositions Prior to Trial — T.C. Rule 81

1. A deposition to perpetuate testimony should be taken only where there is a "substantial risk" that the person, document, or thing involved will not be available at trial. As with discovery depositions, this type of deposition should relate only to testimony or document or thing which is not privileged and is material to a matter in controversy. A decision to take a deposition where the witness could be subpoenaed to appear at trial should only be made after a careful balancing of all factors such as the importance of the witness, desirability of having the judge view the witness’s demeanor, financial hardship, etc.

2. A party who desires to take a deposition to perpetuate testimony may file an application for an order of the court authorizing the taking of the deposition, containing the information required by T.C. Rule 81(b)(1). _See_ Tax Court Form 7. The application may be filed with the court at any time after the case is docketed, but must be filed at least 45 days prior to the trial date. The application and a conformed copy thereof, together with an additional conformed copy for each additional docket number involved, and a certification of service upon all other parties and persons to be deposed shall be filed with the Clerk of the Court. Such other parties or persons shall file their objections or other response, with the same number of copies and a certificate of service, within 15 days after service of the application. A hearing on the application will be held only if directed by the court. Unless the court determines otherwise for good cause shown, an application to take a deposition will not be regarded as sufficient ground for granting a continuance from a date or place of trial already. If the court approves the taking of a deposition, it will issue an appropriate order.

3. Under T.C. Rule 81(c), the applicant may name a corporation, partnership, association, or governmental agency as the deponent, but must designate with reasonable particularity the matters on which examination os requested. Any corporation, partnership, association, or agency, if named as a deponent, must designate one or more persons who consent to testify on its behalf, and may set forth, for each person designated, the matters on which such person will testify. The Field attorney, prior to applying for an order to take the deposition of an organization, should consider securing in advance the identity of a knowledgeable person within the organization and specify such person in the application. An organization’s designated witness is under a duty to testify as to matters "known or reasonably available" to the organization. In the event the designated witness lacks knowledge of the organization’s affairs, the Field attorney should seek an appropriate order directing compliance or imposing sanctions.

4. In lieu of a party applying to the court for an order allowing a deposition, the parties may agree to have a deposition taken without a court order. This is done by way of a stipulation containing the information required by T.C. Rule 81(d). The stipulation is to be filed with the court.

5. The stipulation to take a deposition to perpetuate testimony substitutes only for application and order. All other proceedings must conform to the court’s rules. Specifically, the parties by stipulation cannot change the court’s rules as to when such depositions are authorized, timing, signature, verification, and the duties of the officer taking the deposition.


**35.4.4.5.2.3** **(08-11-2004)**

##### Depositions After Commencement of Trial — T.C. Rule 83

1. Nothing in the Tax Court’s rules precludes the taking of a deposition after trial has commenced in a case, upon approval or direction of the court. The court may impose such conditions on the taking of the deposition as it may find appropriate. With respect to any aspect not provided specifically by the court, T.C. Rule 81 will govern, to the extent applicable.

2. If the deposition is to be taken after trial concludes, the Field attorney should ask the court to hold the record open and to allow sufficient time to take the deposition, receive and study the trial transcript, and, if necessary, introduce any additional evidence suggested by the deposition.


**35.4.4.5.2.4** **(08-11-2004)**

##### Procedures for Taking Depositions

1. All arrangements necessary for taking the deposition shall be made by the party filing the application, or in the case of a stipulation, by such other persons as may be agreed upon by the parties. T.C. Rule 81(f)(1). If respondent is responsible for the arrangements, the Field attorney must determine the contractual arrangements in effect for reporting depositions. The reporter under contract for reporting depositions is generally not the same reporter under contract for reporting Tax Court proceedings. If the reporter under contract for taking depositions is not an officer authorized to administer oaths in the state where the deposition is to be taken, arrangements must be made with such an officer in addition to the arrangements with the reporter to appear at the taking of the deposition. The officer before whom the deposition is taken should be fully informed as to the requirements of the Tax Court concerning the manner of taking and the return of depositions to the court. If a reporter is not under contract, special arrangements will have to be made for the employment of a reporter.

2. Attendance by the persons to be examined and production of documents in connection with the testimony may be compelled by the issuance of a subpoena. A subpoena should be served on all witnesses for the respondent, when the date, time, and place have been arranged, with sufficient time for the witness to arrange personal affairs so as to be present at the time set.

3. When attending the taking of a deposition, the Field attorney should act in the same manner as at trial with respect to questioning witnesses, making appropriate objections, cross-examining witnesses, and similar matters. Objections to questions and answers must be explicitly and briefly stated without any unnecessary comment, explanation, or argument. Objections to the competency of a witness, or the competency or relevancy of testimony, not made at the time of taking the deposition, may be pressed at trial, unless the ground for the objections is one which could have been obviated or removed if presented at the time of the taking of the deposition, such as objections to leading questions. Objections to errors and irregularities in the manner of taking the deposition, in the form of any question or answer, in the oath or in the conduct of the parties, and errors of any kind which might have been obviated, removed, or cured if promptly presented, will not be considered at the trial unless made at the taking of the deposition. _See_ T.C. Rule 85. Objections made at the taking of the deposition (including objections to materiality and relevancy) should be renewed at trial for record purposes.

4. At the deposition, the officer before whom the deposition is taken shall first put the witness on oath (or affirmation) and shall personally, or by someone acting under the officer’s direction and in the officer’s presence, record verbatim the questions asked, the answers given, the objections made, and all matters transpiring at the taking of the deposition which bear on the testimony involved. By stipulation of the parties or by order of the court, a deposition to perpetuate testimony may be recorded by videotape. If videotaped, the deposition need not be transcribed, unless one of the parties requests a transcript. T.C. Rule 81(j)(3). Examination and cross-examination of the witness, and the marking of exhibits, shall proceed as permitted at trial.

5. All objections made at the time of examination shall be noted by the officer in the deposition. Evidence objected to, unless privileged, shall be taken subject to the objections made. If an answer is improperly refused and as a result a further deposition is taken by the interrogating party, the objecting party or deponent may be required to pay all costs, charges, and expenses of that deposition to the same extent as is provided in T.C. Rule 81(g).

6. At the request of any party, any prospective witness, other than the person being deposed and other than a person acting in an expert or advisory capacity, shall be excluded from the room during the time in which a deposition is being taken. If such person remains in the room or within hearing of the examination after such a request, that person shall not thereafter be permitted to testify, except upon consent of the party who requested exclusion or by permission of the Court. T.C. Rule 81(f)(2). The Office of Chief Counsel interprets the language "a prospective witness at the deposition" to mean a person (not a party) whose deposition is scheduled to be taken on the same day or before the transcript of the deposition in question becomes available to the parties. Any more stringent safeguard against the disclosure of a prior witness’ testimony would have to be obtained by motion for a protective order by the court.


**35.4.4.5.2.5** **(08-11-2004)**

##### Expenses of Taking a Deposition

1. The party taking the deposition shall pay all the expenses, fees, and charges of the officer presiding at or recording the deposition and any expenses involved in providing a place for the deposition. The party taking the deposition also pays for any copy of the deposition to be filed with the court. Upon payment of reasonable charges, the officer taking the deposition will furnish a copy of the deposition to any party or the deponent. By stipulation between the parties or on order of the court, special provision may be made for any costs, charges, or expenses relating to a deposition. T.C. Rule 81(g)(1). The party taking the deposition is not obliged to pay for a copy for the opponent. A clear understanding should be reached with petitioner prior to any contemplated deposition as to who will pay the cost of copies of the deposition.

2. Specific sanctions are provided under T.C. Rule 81(g)(2) respecting payment of costs and expenses where a party fails to attend a deposition or failed to subpoena a deponent-witness who does not appear because of such failure. In this situation, the court may award the other party reasonable expenses incurred by the party and the party’s attorney in attending, including reasonable attorney’s fees. The other party must attend the deposition in the expectation that it will be taken, and such costs cannot be inflicted on the other side if a party seeking costs knew in advance that the deposition could not be taken.


**35.4.4.5.2.6** **(08-11-2004)**

##### Execution and Return of the Deposition

1. When the testimony is fully transcribed, the deposition will be presented to the witness for review and signature, in accordance with T.C. Rule 81(h)(1).

2. The deposition and exhibits are not filed with the court. Unless otherwise directed by the court, the party taking the deposition, or that party’s counsel, takes custody of the original deposition and exhibits. Any other party, on payment of reasonable charges, may obtain a copy of the deposition from the officer before whom the deposition is taken. T.C. Rule 81(h)(3).


**35.4.4.5.2.7** **(08-11-2004)**

##### Use of Deposition

1. At the trial or in any other proceeding in the case, any part or all of a deposition, so far as admissible under the rules of evidence applied as though the witness were then present and testifying, may be used against any party who was present or represented at the taking of the deposition or who had reasonable notice thereof, in accordance with either of the following provisions:



   - The deposition may be used by any party for the purpose of contradicting or impeaching the testimony of deponent as a witness

   - The deposition of a party may be used by an adverse party for any purpose


2. Under T.C. 81(i), the deposition may be used for any purpose if the court finds:



1. That the witness is dead

2. That the witness is at such distance from the place of trial that it is not practicable for the witness to attend unless it appears that the absence of the witness was procured by the party seeking to use the deposition

3. That the witness is unable to attend or testify because of age, illness, infirmity, or imprisonment

4. That the party offering the deposition has been unable to obtain attendance of the witness at the trial, as to make it desirable in the interest of justice, to allow the deposition to be used

5. That such exceptional circumstances exist, in regard to the absence of the witness at the trial, as to make it desirable in the interest of justice, to allow the deposition to be used


3. Testimony taken by deposition shall not be treated as evidence in a case until offered and received in evidence. T.C. Rule 143(c). Error in the transcript of a deposition may be corrected by agreement of the parties, or by the court on proof it deems satisfactory to show an error exists and the correction to be made, subject to the requirements of T.C. Rules 81(h)(1) and 85(e).

4. Objections made during the taking of the deposition, which the respondent desires to press at the trial, should be brought to the attention of the court for a ruling when the deposition is offered. It is necessary that the court rule on these objections in order that the record will clearly show whether or not the matter to which the objection is directed is or is not in evidence. If petitioner offers only the direct examination, it is incumbent upon respondent to offer the cross-examination if the cross-examination is needed in the record.

5. If only part of a deposition is offered in evidence by a party, an adverse party may require introduction of any other part which ought, in fairness, to be considered with the part introduced, and any party may introduce any other parts. T.C. Rule 81(i)(4).


**35.4.4.5.2.8** **(08-11-2004)**

##### Deposition Upon Written Questions

1. The procedures for taking depositions on written questions are set forth in T. C. Rule 84.

2. Tax Court Rule 84(a) itself indicates that depositions on written questions are not favored. The procedure for cross-examination is very difficult and time-consuming. A request to use this procedure generally should be resisted.


**35.4.4.5.2.9** **(08-11-2004)**

##### Disadvantages of Depositions

1. As a general rule, testimony taken by deposition is a less effective way of presenting the evidence than when the judge can personally hear and observe the witness.

2. Where the testimony of the witness is of vital importance to the respondent’s case, it should not be taken by deposition except in an emergency; for example, where the witness is sick or departing the country and is not expected to be able to attend the trial.

3. The Field attorney should determine that the rules clearly permit the taking of a deposition before consenting to such action. The fact that a deposition has been taken does not speak to its admissibility in evidence. An agreement with petitioner to take a deposition of petitioner’s witness should make clear that respondent does not agree to the admission of the deposition in evidence (unless, of course, such action is in fact intended by the parties).


**35.4.4.6** **(08-11-2004)**

### Witness Fees and Expenses

1. In federal courts, including the Tax Court, the payment to subpoenaed witnesses of witness fees, traveling expenses, and subsistence allowances is governed by statute. Section 7457; T.C. Rule 148. _See_ 28 U.S.C. § 1821.

2. The statutory fees apply to witnesses subpoenaed for trial, hearing, or deposition.

3. For information applicable in most circumstances, including procedures for claiming fees and allowances, _see_ the Subpoenaed Witnesses section of the F&M Administrative Handbook, Budget Section, on the F&M Intranet website.


**35.4.4.6.1** **(08-11-2004)**

#### Specific Items of Claimed Fees and Expenses

1. Problems may frequently arise as to whether a witness is entitled to be paid witness fees, subsistence, or other expenses under particular circumstances. Wherever possible, the attorney should anticipate such problems and request advice from the APJP, Branch 3 prior to the trial session. Where the problem does not arise until after the witness appears in court and Field Counsel is doubtful as to the amount that properly should be paid under the circumstances, a request for advice from APJP should be made before the voucher is processed. APJP will coordinate with the Associate Chief Counsel (GLS) as necessary in order to assist in reviewing decisions of the Comptroller General and any other applicable authority.

2. The cost of transporting books and records produced by the witness in response to a subpoena duces tecum issued by the respondent must be paid by the Government upon submission of an appropriate voucher.

3. Under section 7457, a petitioner who is subpoenaed to appear and testify solely as a witness for the respondent is entitled to receive witness fees from the respondent. Thus, the fact that such witness is a party-petitioner, or an officer of a corporate petitioner, should not operate to relieve the respondent of paying appropriate witness fees and expenses. If respondent’s liability for fees is questionable because the witness is primarily testifying on behalf of the petitioner, advice should be requested from APJP, Branch 3.

4. Witnesses who are prisoners in federal or state prisons are entitled to be paid attendance fees but not subsistence unless they personally bear such expenses. There is no statutory authority for payment of expenses of witnesses who are in custody.

5. If a witness is in such poor health that the witness cannot travel to court without a nurse or other health care attendant, testimony should usually be taken by deposition. If the witness must come to court, accompanied by a nurse or health care attendant, the payment of that person’s travel expenses becomes an issue. If, due to the nature of the issue in dispute, or otherwise, the nurse or health care attendant also must testify, then the expenses can be paid as for any other subpoenaed witness. If the nurse or health care attendant will not appear as a witness, actual travel and transportation expenses while accompanying the witness to and from the Tax Court trial would be payable under the statutory provisions of the Appropriation Act for necessary expenses of the Service. The voucher for such expenditures must be accompanied by a certification by Area Counsel or a delegate, that the personal appearance of the witness at the trial was essential in defense of the Commissioner’s determination and, due to physical condition, the witness required the nurse or health care attendant. F&M will coordinate payment of such vouchers.


**35.4.4.6.2** **(08-11-2004)**

#### Advance Payment of Witness Fees and Mileage

1. The usual procedure for witness expenses involves the witness submitting a claim for reimbursement after the expenses are incurred. For most witnesses, while this may present an inconvenience, it will not present a hardship.

2. Upon a proper showing of a real need for advance payment of fees and mileage, or where it is shown that a subpoenaed witness is unable to pay for transportation, the Associate Area Counsel should contact the F&M Area Manager to secure an advance.


**35.4.4.6.3** **(08-11-2004)**

#### Preparing the Witness Expense Voucher

1. The Field attorney or another employee from Field Counsel should be available at the trial session to give such assistance to the witness as is necessary for completion of the voucher covering the witness fees, mileage, and subsistence.

2. The attorney or employee should discuss the voucher with the witness and obtain any necessary information before the witness is excused from the trial.

3. Upon execution by the witness, the voucher (with a copy of the subpoena attached) should be given to the Office Manager/Administrative Operations Specialist/Support Team Leader for payment as expeditiously as feasible.


**35.4.4.7** **(01-24-2024)**

### Use of Affidavits in "S" Cases

1. Tax Court Rule 174(b) provides that trials of small tax cases (as defined in section 7463 and T.C. Rule 170) will be conducted as informally as possible consistent with orderly procedure, and that any evidence deemed by the court to have probative value shall be admissible.

2. Consistent with T.C. Rule 174(b), the court may accept affidavits in small tax cases. Generally, though, it is preferable for respondent to present live testimony even in small tax cases. At a minimum, if the Field attorney intends to present testimony by affidavit, the affidavit must reasonably comply with the requirements of Fed. R. Evid. 803(24) or 804(b)(5). In addition, if the Field attorney intends to present testimony by affidavit, reasonable notice should be given to the petitioner. This will afford petitioner an opportunity to subpoena the witness for cross-examination if petitioner so desires.

3. Prior to trial, the Field attorney should ask the petitioner if petitioner intends to present evidence by affidavit. If so, the Field attorney should contact the proposed affiant to discuss potential testimony, and, if appropriate, subpoena the witness. If petitioner refuses to reveal whether an affidavit will be used, the Field attorney should be prepared to object at trial to petitioner’s use of an affidavit.

4. Although the court may accept affidavits in lieu of live testimony in small tax cases, the court is not bound to believe the testimony contained in affidavits. If the Field attorney chooses to present testimony by affidavit, care should be taken to ensure that the affidavit testimony is complete, clear, logical, and consistent. If petitioner presents testimony by affidavit, the Field attorney should be prepared to refute the affidavit by presenting contrary evidence or by arguing the shortcomings of the affidavit.


**35.4.4.8** **(08-11-2004)**

### Expert Witnesses

1. Under Fed. R. Evid. 702, if scientific, technical, or other specialized knowledge would assist the court to understand the evidence or determine a fact in issue, a witness qualified as an "expert" by knowledge, skill, experience, training, or education, may testify by opinion or otherwise. Fed. R. Evid. 701 allows a non-expert witness to give opinion testimony only when the opinion is rationally based on the perception of witness and is helpful to a clear understanding of the non-expert’s testimony or determination of a fact in issue.

2. Certain types of issues generally are thought of to require or be conducive to the use of expert witnesses. Issues involving valuation of tangible or intangible assets, of services, or the working needs of a corporation (in an accumulated earnings case) are a but a few examples. Experts also might be used in cases in which the workings of a particular occupation or industry, not commonly known to lay persons, are at issue. Generally speaking, any time an expert’s specialized knowledge would be helpful to the judge in understanding the evidence and drawing inferences from the evidence, then an expert may be necessary or appropriate.

3. Time is of the essence in identifying the need for an expert witness. Consideration of the need for one or more additional expert witnesses is a process that continues even after an expert is engaged. In many cases, it is not enough for respondent to present expert witness evidence as part of respondent’s case-in-chief and then cross-examine petitioner’s expert(s). Instead, respondent must also present rebuttal evidence by way of an expert witness. Whether such rebuttal evidence may be presented through respondent’s case-in-chief expert(s), or must be presented through an additional one or more expert witnesses, depends on the circumstances of the individual case, on the qualifications of the case-in-chief expert(s) and, to some extent, on the strategy adopted by petitioner in petitioner’s use of an expert witness. An informed decision in this regard cannot be made without information concerning the identity, qualifications, and expected testimony of petitioner’s expert(s). Such information should be sought from petitioner on a continuing basis. Serious consideration should be given in all expert witness cases to use of interrogatories under T.C. Rule 71(d). _See_ CCDM 35.4.3.3.2.2, _Service of Interrogatories_, http://core.publish.no.irs.gov/irm/p35/pdf/irm35-004-003--2012-07-26.pdf.


**35.4.4.8.1** **(01-24-2024)**

#### Identifying the Expert Witness

1. Information on potential expert witnesses is available from a variety of sources in Chief Counsel and the Service. Chief Counsel’s library maintains information on expert witnesses who have been used by Chief Counsel attorneys in prior cases, and has access to other expert witness data bases. Division Counsel headquarters offices may have similar information available. Reported court opinions will contain information about issues and expert witnesses, plus the names of Chief Counsel attorneys who might be contacted for recommendations. Service specialists may, in some cases, serve as expert witnesses, and, in other cases, may make recommendations of "outside" experts. _See_ CCDM 35.4.2.2, _Use of IRS Personnel_, http://core.publish.no.irs.gov/irm/p35/pdf/irm35-004-002--2010-12-14.pdf.

2. Professional organizations, colleges and universities, appraisal and technical services companies, and individual experts often advertise in industry and legal publications. Also most of them maintain sites on the Internet, which might be searched for leads to an appropriate expert witness. _See_ CCDM 35.4.4.3.

3. Many factors, including cost, go into the final selection of a specific expert witness. The primary consideration is the degree to which a specific witness will be helpful to the Court in understanding and determining the matter at issue. The expert must be qualified to testify on the specific matters the court is considering. Because the Tax Court requires expert witnesses to submit written reports, the expert’s ability to express facts and opinions in writing as well as orally is very important. Other specific considerations for selection of a specific expert include:



   - Overall qualifications

   - Demeanor/professional appearance

   - Experience as a witness

   - Experience with specific matter at issue

   - Professional books/articles written

   - The degree to which the background work and actual writing of the expert witness report must and will be done personally by the proposed expert, and the degree to which such work may be delegated to the expert’s staff

   - Vulnerability to cross-examination: The following questions should be considered by the field attorney prior to the selection of the expert: (1) Are there any publications which may be inconsistent with present report? (2) Does the expert’s opinion change based on who is asking questions? (3) Is the expert’s knowledge current? (4) Will the expert be thoroughly prepared? (5) Has the expert testified previously in Tax Court or other administrative or judicial proceedings and taken a position not easily reconciled with the opinion required in this case? (6) Is the expert’s resume correct and complete? Verification might be necessary. (7) What is the quality of petitioner’s expert and does respondent’s candidate compare favorably to petitioner’s expert?


4. The ultimate role of the expert witness is to provide evidence to the court. In selecting an expert witness, the Field attorney should consider carefully whether the witness will be both able and willing to provide evidence that supports respondent’s theory of the case. It is never appropriate to dictate to a proposed expert the opinion the expert is expected to render. It is appropriate, however, to question a proposed expert in detail as to the approach the expert expects to use and the type of evidence on which the expert expects to rely, and to select or reject the expert based on the reasonableness of the answers. For example, if, in a valuation case, respondent’s theory is that the determined value is fully and appropriately supportable by a market value approach, it would be detrimental to the case to select an expert who rejects or downplays that approach in favor of another.

5. Whether the selected expert witness is an Service employee or not, the expert must be someone with whom the Field attorney can develop an appropriate and productive working relationship in which neither controls the work of the other. The expert also must be someone who will be able to keep commitments made to the Field attorney, and must be someone who will be able to work within the constraints of the Tax Court’s rules and government procurement law.

6. In many instances, particularly those involving especially complex or theoretical matters, it will be appropriate to procure the services an expert witness possessing a special knowledge or background who is not a Service employee. In some instances a Service specialist may qualify to act as an expert witness by satisfying all requirements for the assignment. However, the Field attorney must be satisfied that the government can overcome any allegations of bias against the Service specialist.

7. When hiring an “outside” expert witness the Office of Chief Counsel must abide by the regulations established in the Federal Acquisition Regulation (FAR). Typically, the Competition in Contracting Act (CICA) requires the federal government to use contracting methods which allow for full and open competition among interested parties. An exemption to CICA, however, allows federal agencies to make direct awards for expert witness services. This authority is codified at 41 U.S.C. § 253(c)(3) and 41 U.S.C. § 3304(a)(3). The expert witness exception to CICA is incorporated into the FAR at FAR 3.303-2.

8. Time is of the essence in identifying potential expert witnesses.


**35.4.4.8.2** **(08-11-2004)**

#### Contracting with, and Payment to, the "Outside" Expert

1. This section discusses contracting with and making payments to the "outside" expert witness, and roles and responsibilities, and provides procedures.


**35.4.4.8.2.1** **(08-11-2004)**

##### The Contracting Officer’s Technical Representative (COTR)

1. It is vitally important for any Field attorney who needs to retain the services of an outside expert to identify and work closely with the COTR. A COTR may be a paralegal assigned to a Counsel Field office, or a field F&M employee. Each attorney practice group has assigned to assist it at least one COTR, who is trained in expert witness procurement procedures. The COTR, in turn, receives legal advice and review from a General Legal Services attorney.

2. The COTR will assist the Field attorney in preparing the paperwork necessary to request expert witness services, in reviewing for accuracy the expert witness contract or purchase order, in ensuring that the expert does not begin providing services before the purchase order or contract has been awarded by the contracting officer, in reviewing invoices for accuracy and charges not covered by the contract or purchase order, in submitting supplemental requests or requests for modifications, and in deobligating funds once the expert’s work is concluded or the scope of the work is substantially reduced.


**35.4.4.8.2.2** **(08-11-2004)**

##### Field Attorney’s Role and Responsibilities

1. Although the COTR is qualified to render essential assistance in , contracting with, overseeing, and paying expert witnesses, the ultimate responsibility for all matters involving the expert rests with the Field attorney and the Field attorney’s reviewer.

2. Neither the Field attorney nor the COTR has authority to negotiate the price or terms and conditions under which an expert’s services will be rendered. Only a contracting officer or specialist may do that. The Field attorney must make this clear to every potential expert witness. The Service, by law, cannot pay for work commenced without an approved contract or purchase order (an "unauthorized procurement" ). Carelessness by the attorney or COTR could mean personal liability for the cost of any unauthorized work.


**35.4.4.8.2.3** **(01-24-2024)**

##### Procedures

1. An essential consideration in dealing with potential expert witnesses and expert witnesses arises from the disclosure restrictions of section 6103. In order for the potential expert to make a judgment as to whether the assignment is within the area of expertise and whether any potential conflicts of interest exist, the attorney will have to reveal certain information. Although the general outlines of the case may be disclosed on an initial contact with the expert, tax returns or tax return information should not be disclosed until the potential expert has signed a Certification of Non-Disclosure and an Agreement to Safeguard Confidential Tax Information.

2. The services of an outside expert can be procured under either a "purchase order," where the cost will be under $100,000, or a "contract," where the cost will be $100,000 or more. So far as the Field attorney is concerned, all procedures are the same under either arrangement. The primary difference, from the Field attorney’s perspective, is that approval of a "contract" by Contracts and Procurement takes a substantially longer period of time. Thus, under a contract, the date on which work will begin is later.

3. Once the attorney and reviewer have determined which expert(s) should be hired in a particular case, the request package should be prepared. It consists of several documents which are part of the "Requesting Services of an Expert Witness" set of Chief Counsel macros, plus Treasury Department Form 70.06, Justification for Other Than Full and Open Competition (JOFOC). Additional information regarding these documents may be found in the Tax Litigation Guidebook on the F&M page on the Chief Counsel intranet. These documents assume that the services of the expert will be procured by "sole source" procedures, since that is the method by which almost all expert witness services are procured for Tax Court cases.

4. The Field attorney and the COTR may divide the work of preparing the expert witness procurement documents in any way they deem suitable for a given case. In most instances the attorney will prepare the Statement of Work, the Informal Market Survey and the Explanation of Use of Non-Competitive Procedures since the preparation of those documents generally requires special knowledge of the case and trial strategy.

5. When the Field attorney and COTR complete the procurement documents, they will submit them to the Field attorney’s Area Counsel or the Area Counsel’s delegate for coordination with GLS and approval prior to transmittal to Contracts and Procurement. _See_ Exhibit 35.11.1–100.

6. The work of an expert witness for the respondent in a Tax Court case is divided into five general phases:



   - Phase I—Preliminary Evaluation

   - Phase II—Consultation with Field attorney and Preparation of Report

   - Phase III—Pre-Trial Support and Trial Preparation

   - Phase IV—Trial

   - Phase V—Post-Trial Litigation Support



     > Depending on the needs of the government in a particular case, the expert may be required to perform one phase, all five phases, or any number in between. Work in each phase is performed on an hourly basis, and billed separately. Travel expenses are authorized and billed separately. It is essential that the Field attorney and the expert accurately estimate the cost of each phase and necessary travel, because money authorized for one purpose may not automatically be used to cover other costs. Work on Phases I and II may begin when the contract or purchase order is approved. Work on additional phases may begin only when the COTR obtains authorization from Contracts and Procurement. Each phase is governed by its own "not to exceed" limit. Only the contracting officer may increase the limit, and each increase shall be through a written modification to the contract. Experts shall invoice the IRS as promptly as possible, in accordance with the requirements of the Expert’s contract with the Agency. Contracts with experts should require that billing occur not less than once per month during periods when the expert is actively performing work on the Service’s behalf. _See_ Exhibit 35.11.1–101.


7. After the expert’s work is concluded, the Field attorney and reviewer are responsible for evaluating the expert’s services and providing evaluation information to the COTR for transmittal to Contracts and Procurement.


**35.4.4.8.3** **(08-11-2004)**

#### Uses of Experts Prior to Trial

1. By definition, the expert witness has specialized or technical knowledge the Field attorney does not have, but must understand to most effectively represent respondent in the case. One of the things an expert can do is to "tutor" the Field attorney on the industry or area involved in the case, and background facts and theories. It is never, however, appropriate for the Field attorney to cede responsibility for the case, or its factual or strategic development, to the expert witness, or to allow the expert witness to undertake or complete tasks that are properly performed by the Field attorney. At the same time, it is never appropriate for the Field attorney to undertake or complete tasks that are properly performed by the expert witness, such as drafting of the expert witness report.

2. It is the responsibility of the Field attorney, throughout all phases of the expert witness engagement, to ensure that the expert’s work is in accordance with the respondent’s needs in the case, and in accordance with the understanding and expectations of the Field attorney regarding substance, timeliness, personal involvement of the expert, and quality of the expert’s work. The Field attorney should be in frequent and meaningful contact with the expert, particularly during the preparation of the expert witness report. Care should be taken, however, to ensure that the report is that of the expert and is not ghost-written or dictated by the Field attorney. The true authorship of the expert report is a common subject of cross-examination of the expert witness.

3. The expert can assist the Field attorney in developing the facts necessary for an appropriate decision by the Court. The expert can recommend matters for discovery, help identify other potential witnesses, and assist in review of the Stipulation of Facts. In particular, the expert should assist the Field attorney in making sure that every fact necessary to support the expert’s opinion is developed prior to trial.

4. It is also vital that the expert assist in evaluating and analyzing petitioner’s expert and petitioner’s expert’s report. Respondent’s expert should be asked to provide to the Field attorney possible questions and question areas for _voir dire_ and cross-examination. Areas for potential questioning of petitioner’s expert might include:



   - Qualifications

   - Bias

   - Errors in factual basis for opinion

   - Faulty methodology

   - Impeachment: (1) by petitioner’s expert’s own writing; (2) texts relied on or acknowledged as authoritative Fed. R. Evid. 803(18)


5. However, it is not proper for the expert to make the final decision on whether, when, or how specific questions should be asked at trial. Those matters are properly determined by the Field attorney, not the expert witness.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-004-004#addtoany "Show all")

A2A