---
url: "https://www.irs.gov/irm/part35/irm_35-004-002"
title: "35.4.2 Gathering Information from Government Sources | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-004-002#main-content)

- 35.4.2  [Gathering Information from Government Sources](https://www.irs.gov/irm/part35/irm_35-004-002#idm140149669770688)
  - 35.4.2.1  [Use of Administrative Files and Other Files and Records](https://www.irs.gov/irm/part35/irm_35-004-002#idm140149641643968)
  - 35.4.2.2  [Use of IRS Personnel](https://www.irs.gov/irm/part35/irm_35-004-002#idm140149642757296)
    - 35.4.2.2.1  [Former Employees](https://www.irs.gov/irm/part35/irm_35-004-002#idm140149642755264)
    - 35.4.2.2.2  [Use of Service Specialists](https://www.irs.gov/irm/part35/irm_35-004-002#idm140149642180896)
  - 35.4.2.3  [Information and Witnesses from Other Government Agencies](https://www.irs.gov/irm/part35/irm_35-004-002#idm140149640379632)
    - 35.4.2.3.1  [Technical and Expert Assistance](https://www.irs.gov/irm/part35/irm_35-004-002#idm140149640378032)
    - 35.4.2.3.2  [Use of Agency Files](https://www.irs.gov/irm/part35/irm_35-004-002#idm140149642735728)

# Part 35. Chief Counsel Directives Manual Tax Court Litigation

# Chapter 4. Pre-Trial Activities

# Section 2. Gathering Information from Government Sources

* * *

## 35.4.2 Gathering Information from Government Sources

#### Manual Transmittal

January 24, 2024

#### Purpose

(1) This transmits revised CCDM 35.4.2, Gathering Information from Government Sources.

#### Material Changes

(1) CCDM 35.4.2 is revised to update cross references within the CCDM and other intra-organizational references.

#### Effect on Other Documents

CCDM 35.4.2, dated December 14, 2010, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(01-24-2024)

Richard G. Goldman

Deputy Associate Chief Counsel

(Procedure and Administration)

**35.4.2.1** **(01-24-2024)**

### Use of Administrative Files and Other Files and Records

1. The Field attorney should make every reasonable effort to locate all Service and Chief Counsel files, documents, and other information related to the case. The primary source of information is the administrative file. Even when the administrative file does not include original tax returns, or a copy of the statutory notice of deficiency or other determination letter, or the originals or copies of other pertinent documents, it usually will contain leads as to the location of such documents. An administrative file also usually contains additional factual information in electronic format, including records of electronically filed tax returns. Service and Chief Counsel personnel who previously worked on the case or on other litigation, examination, collection, or criminal cases involving the same taxpayer may also be good sources of information. If their names are not apparent elsewhere in the file, they often can be found by referring to electronic records, including updated transcripts of account.

2. Returns and other files and records not found in the administrative file but needed to prepare the case for trial or settlement negotiations should be obtained at the earliest date possible. Files not in the possession of Chief Counsel or a Service functional division are generally stored by the Files Management Function at a Submission Processing Center or, in the case of older files, at a Federal Records Center. Procedures for accessing and retrieving such files are contained at IRM 3.5.61, Files Management and Services. The Field attorney may requisition this material directly from its custodian. Protecting statutory periods of limitations on original returns in the possession of the Field attorney is the responsibility of the Field attorney. Appropriate statute controls must be established and maintained. Original returns must be returned to the custodian as soon as possible after review and other use by the Field attorney. The Field attorney should consider use of copies or certified copies in lieu of original returns.

3. Criminal Investigation files and Division Counsel/Associate Chief Counsel (CT) files, including Special Agents’ Reports and exhibits, may contain information related to the Tax Court case. These files should be requisitioned in consultation with the Division Counsel/Associate Chief Counsel (CT) to ensure that access to the files will not violate Rule 6(e) of the Federal Rules of Criminal Procedure or any other court rule or order. If the deficiency notice was issued before the criminal tax file was closed, that file may contain information indicating unreported income not considered when the deficiency notice was issued. If such information exists, the attorney should consider amending the answer to seek an increased deficiency.

4. Returns filed by individuals and partnerships (Forms 1040, 1041, and 1065) are periodically destroyed by the Service as authorized by Congress. Corporation, estate, and gift tax returns are generally retained by the Service for a longer period of time. See Document 12990. If a particular return has been destroyed, and if proof with respect to the contents of such return is necessary in the case, it will be necessary to submit proof of its destruction, and to resort to the use of all available secondary evidence to establish the contents of the destroyed return. The contents of a destroyed return may be established by computerized information in the administrative file, explained and supplemented by Service personnel. Contents also might be established or corroborated by reference to returns filed with a state or other governmental authority, or by copies of federal or state returns which have been retained by the taxpayer or taxpayer’s accountant or other employee, together with proof of the amount of federal tax assessed based on the original tax return for such year.

5. Sometimes, it may be necessary to prove a lack of official records as shown by the official having custody of such records in a manner similar to that provided under Rules 803(8), 803(10), 902(1) and 902(4) of the Federal Rules of Evidence. These records or certifications are generally obtained from the Return and Income Verification Service Unit in the Document Retention Department of Post-Processing Operations at the servicing Submission Processing Center.


**35.4.2.2** **(01-24-2024)**

### Use of IRS Personnel

1. The Field attorney often needs, and should at least consider seeking, the assistance of the examining agent or other Service personnel who made the examination or investigation on which the Service’s determination is based. An agent who spent a significant amount of time with the case will have first hand knowledge of the file, and will be able to assist in organizing and understanding the facts. An agent also could assist in further investigating the facts to be relied upon, ascertaining the location and availability of witnesses, or verifying information supplied by the petitioner. These further investigations should be made at the earliest practicable time so that there will be no delay in completing trial preparation and stipulations. If an agent is assigned to assist, the attorney is responsible for ensuring that the agent’s time is conserved and spent as productively as possible, and for ensuring that the agent’s services are concluded expeditiously.

2. A request for assistance should specify the nature of the assistance needed, give the name of the taxpayer, and give the taxpayer’s address or addresses for the years involved as well as the taxpayer’s current address, if known. A request for assistance by the agent who made the examination or investigation on which the Service’s determination is based should be addressed to that employee’s immediate reviewer. If that agent is not available or if that agent’s particular skills are not needed for the specific assignment, a request for assistance, specifying the type of agent sought (other than a Special Agent), should be addressed to the Territory Manager of the Division (and Industry, if applicable) in which the case originated. Such a request for a Special Agent should be addressed to the Special Agent in Charge of the office in which prior investigative work was done. Any request for assistance also should include the name(s) of the agent(s) who have previously worked on the case, an estimate of the number of hours of assistance required, and the expected dates of beginning and completion of the assignment. It should also ask that the assigned agent contact the attorney by phone or in person as soon as possible.

3. The expenses incurred by agents or other Service employees assisting in the preparation and trial of Tax Court cases are not borne by the Office of Chief Counsel, but are borne by the agent’s or employee’s own operating division.


**35.4.2.2.1** **(08-11-2004)**

#### Former Employees

1. If the attorney determines that the services of the agent or employee who made the examination or investigation on which the determination is based are necessary, such as when extensive development of the facts was done by the revenue agent, and that person is no longer employed by the Service, that person’s services may still be engaged for trial preparation and/or trial.

2. The manner in which the Field attorney will engage that person’s services depends on the extent and type of services to be rendered.

3. If the former agent or employee will act strictly as a fact witness, compensation will be in accordance with that authorized by law for subpoenaed witnesses. See CCDM 35.4.4.6, Witness Fees and Expenses.

4. If the agent or employee is required to provide _bona fide_ expert assistance, his or her services may be procured on a sole source basis. See CCDM 35.4.4.8.3, Uses of Experts Prior to Trial. The Field attorney should consult with budget and procurement specialists in the Finance and Management Area office for information on the scale of pay available to the former employee for acting as an expert witness. During preliminary contacts with the former employee, the attorney should attempt to obtain an estimate of the fee and any other special conditions that may be imposed by the former employee. The former employee should not be induced into full cooperation by agreeing to pay expert witness fees if he or she is not a bona fide expert witness, but is instead a fact witness.

5. Should a determination be made that the use of sole source procurement procedures to obtain the expert services of the former employee under a nonpersonal services contract is appropriate, care should be taken to assure that the relationship between the Service and the former employee is an independent contractor relationship. The Field attorney should consult with budget and procurement specialists in the Finance and Management Area office and, where necessary, the Public Contracts and Technology Law Branch (GLS) to assure that the contract is structured to avoid the rendition of personal services. If the contract states that the former employee is an independent contractor, care should be taken to assure that the former employee’s behavior conforms with the standards applied in determining independent contractor status and those specified in the contract.

6. The length of the contract for the former employee’s services will be determined on the basis of the time required for pretrial preparation (such as reviewing reports and files, inspection of property, research, and travel), assisting at the trial and giving testimony, and post-trial review and report.

7. If the assistance of the former employee will be needed for an extended period of time, or if an employer-employee relationship is to be established (as opposed to an independent contractor relationship), the former employee would have to be redeployed on a temporary (temporary full-time, temporary part-time, or intermittent) basis. The salary of a reemployed annuitant is set by law, and employment of the annuitant would require either termination or suspension of annuity or deduction of annuity from pay, depending on the type of separation on which the annuitant’s retirement was based and other factors. The Field attorney should consult with budget and procurement specialists in the Finance and Management Area office for further information.


**35.4.2.2.2** **(01-24-2024)**

#### Use of Service Specialists

1. The Service has many different professional specialists who are available to assist the attorney in the preparation and trial of cases. These professional specialists include economists, engineers, forensics experts, actuaries, and specialists in various industries.

2. Depending on the nature of the issue in dispute and other factors, it may be appropriate to use one or more Service specialists as consultants or as expert witnesses prior to and at trial. See CCDM 35.4.4.8.1, Identifying the Expert Witness. Even if a decision is made that an outside expert should be employed, Service specialists can render valuable assistance to the attorney, and in many instances the work performed by these specialists will materially reduce the cost of outside experts, when employed.

3. Economists can assist in cases involving the determination of the value (or price) of tangible or intangible goods or services or identifying the substance of a transaction or activity. They often can develop innovative ways of combining data from varied sources or can use advanced analytical and statistical techniques to resolve an economic problem related to a tax issue. Additional information on Service economists can be found on the Large Business and International Division (LB&I) [Specialists website](https://irsgov.sharepoint.com/sites/LBI/SitePages/Specialists.aspx).

4. Engineering and valuation teams can assist in cases involving technical, engineering, and asset valuation issues. Additional information on Service engineering and valuation teams can be found on the LB&I [Specialists website](https://irsgov.sharepoint.com/sites/LBI/SitePages/Specialists.aspx).

5. Forensic expertise is provided by the Forensics Lab in Criminal Investigation's Office of Operations Policy and Support, headquartered in Chicago. The Forensics Lab provides services in document examination, ink/chemistry, polygraph, electronics, imaging, latent prints, trial illustration, and document input.

6. Actuarial expertise is provided in life insurance cases by actuaries in the Financial Services industry of the LB&I Division and in employee plan cases by actuaries in the Office of the Director, Employee Plans, of the TE/GE Division.

7. The Associate Chief Counsel (International) is available to provide assistance in resolving foreign law problems, such as methodology of securing documents from abroad in admissible form, procedural aspects of securing foreign depositions and the use of subpoenas, and requests for production of documents located abroad. See CCDM 35.4.5, Evidence and Information from Abroad.

8. Unless otherwise specified by the current procedures of the specialist’s operating division, a request for assistance should specify the nature of the assistance needed, give the name of the taxpayer, and give the taxpayer’s address or addresses for the years involved as well as the taxpayer’s current address, if known. Any request for assistance also should include the name(s) of any Service specialists who have previously worked on the case, an estimate of the number of hours of assistance required, and the expected dates of beginning and completion of the assignment. It should also ask that the assigned specialist contact the attorney by phone or in person as soon as possible.


**35.4.2.3** **(08-11-2004)**

### Information and Witnesses from Other Government Agencies

1. This subsection discusses obtaining information and witnesses from other Government agencies.


**35.4.2.3.1** **(01-24-2024)**

#### Technical and Expert Assistance

1. Many cases involve factual or technical issues that are commonly encountered by agencies of Federal, State, tribal, or local governments other than the Service. If so, the Field attorney should consider seeking assistance from those governmental entities. Audit Techniques Guides prepared by the Service’s Compliance functions often contain suggestions of the kinds of issues that are within the expertise of certain governmental entities and the types of assistance that may be available.

2. The following are examples of assistance provided by other federal agencies:

_Example 1._ The United States Army Corps of Engineers has on its staff engineers and real estate appraisers who may be made available to assist in the preparation and trial of cases. These services are in addition to, not in lieu of, requests for services of the Service’s engineering and valuation teams. Normally, requests to the Corps of Engineers should not be made unless there are no Service personnel available.

_Example 2._ The Bureau of Alcohol, Tobacco & Firearms and the Office of Treasurer of the United States provide ink analysis and questioned document examination services of the type provided by the Forensics Lab in Criminal Investigation's Office of Operations Policy and Support Division.

_Example 3._ On factual issues involving the purchase or redemption of United States bonds, assistance may be obtained from the Bureau of Public Debt. On issues involving United States currency, assistance may be obtained from the Bureau of Engraving and Printing.

3. If the attorney should find any document or notation in a file indicating that some information therein has been given a restricted, secret, top secret, etc., security classification by the Department of Defense, State Department, Department of Energy (for atomic or nuclear energy matters), or other governmental unit, extreme care should be exercised to avoid any unauthorized use or disclosure of such information. The attorney should ascertain first that the information was properly obtained, and that a record exists of an authorized release or declassification of the information. If the information has not been declassified, then a security clearance for the attorney and other persons having access to it is necessary. Also, security precautions in the storage of the information are required. Precise instructions should be obtained from the appropriate governmental unit as to what further use or disclosure may be made of the information. Normally, no further disclosure may be made until the information has been declassified. If any uncertainty exists with respect to the use or disclosure of such information, the matter should be referred to the Associate Chief Counsel (Procedure and Administration) (P&A).

4. The Field attorney may make preliminary searches of governmental information by viewing agency internet sites and publications. Preliminary informal contacts with the agencies, inquiring as to the availability of technical or expert assistance, and the agency’s preference as to methods for the Office of Chief Counsel to request such assistance, may be made by the Field attorney with the approval of the Field attorney’s reviewer. Formal requests for such assistance shall be made in writing and in accordance with the agency’s formal requirements.


**35.4.2.3.2** **(01-24-2024)**

#### Use of Agency Files

1. The preparation of the case for trial may require obtaining documents, such as government agency records or court records that are not contained in the files, or it may require the certification of documents, copies of which are in the attorney’s possession. Sometimes, it may be necessary to prove a lack of official records as shown by the official having custody of such records in a manner similar to that provided under Rules 803(8), 803(10), 902(1) and 902(4) of the Federal Rules of Evidence. Preliminary informal contacts with the agency or court, inquiring as to the availability of documents or certifications, and the agency’s or court’s preference as to methods for the Field attorney to obtain such documents or certifications, may be made by the Field attorney with the approval of the Field attorney’s reviewer. Formal requests for documents or certifications shall be made in writing and in accordance with the agency’s formal requirements.

2. Records of courts of the United States and the certification thereof generally are furnished without cost since they are for the use of the United States in the Tax Court trial, and other government agencies may likewise waive any usual fee. In instances in which a fee is to be charged for obtaining documentary or certification evidence, the Field attorney should receive supervisory approval before committing to pay the cost. Prior to giving this approval, the reviewer should request that the Office Manager/Administrative Operations Specialist/Support Team Leader obtain an approval number from the F&M Area Manager.

3. If, after approval to incur the cost, the attorney pays the fee from personal funds or by credit card, the attorney can be reimbursed in accordance with instructions contained in the Finance and Management Administrative Handbook. Generally, this requires submitting the receipt and a voucher (SF 1164), indicating the proper activity and sub-object class to be charged. Expenditures of this sort should not be claimed on a travel voucher.

4. If documents are borrowed from another governmental department or agency, the documents should be returned to the originating department or agency as soon as they have served their purpose, and in any event, not later than when the case is closed. The Field attorney should establish appropriate controls for documents obtained from other governmental departments or agencies.

5. A Field attorney requiring assistance in obtaining documents from a state or local or tribal government entity should consult with Government Liaison and Disclosure personnel in the Office of Commissioner (TE/GE). Coordination of such a consultation should be made with the Division Counsel (TE/GE) and Associate Chief Counsel (EEE) as appropriate.

6. A Field attorney who is unable to resolve a dispute with another federal agency or department involving the production of documents or testimony should refer the matter to the Associate Chief Counsel (P&A). Interagency disputes that are not settled by the disputing agencies ultimately may be referred to the Attorney General.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-004-002#addtoany "Show all")

A2A