---
url: "https://www.irs.gov/irm/part35/irm_35-003-002"
title: "35.3.2 Jurisdictional Defects | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-003-002#main-content)

- 35.3.2 [Jurisdictional Defects](https://www.irs.gov/irm/part35/irm_35-003-002#idm140265800379008)
  - 35.3.2.1 [Tax Court Subject Matter Jurisdiction](https://www.irs.gov/irm/part35/irm_35-003-002#idm140265805699456)
  - 35.3.2.2 [Appealable Determinations in Whistleblower Cases](https://www.irs.gov/irm/part35/irm_35-003-002#idm140265825925200)
  - 35.3.2.3 [Motions to Dismiss for Lack of Jurisdiction](https://www.irs.gov/irm/part35/irm_35-003-002#idm140265800450080)
  - 35.3.2.4 [Timeliness of Petition](https://www.irs.gov/irm/part35/irm_35-003-002#idm140265800432064)
  - 35.3.2.5 [Absence of Valid Statutory Notice](https://www.irs.gov/irm/part35/irm_35-003-002#idm140265815968928)
  - 35.3.2.6 [Jurisdiction Over Party Petitioners](https://www.irs.gov/irm/part35/irm_35-003-002#idm140265825801600)
  - 35.3.2.7 [Jurisdiction Over Each Year and Each Tax](https://www.irs.gov/irm/part35/irm_35-003-002#idm140265816492400)
  - 35.3.2.8 [No Valid Petition](https://www.irs.gov/irm/part35/irm_35-003-002#idm140265816149664)
  - 35.3.2.9 [Payment of Deficiency or Liability Before Issuance of the Statutory Notice](https://www.irs.gov/irm/part35/irm_35-003-002#idm140265813481920)

# Part 35. Tax Court Litigation

# Chapter 3. Motions

# Section 2. Jurisdictional Defects

* * *

## 35.3.2 Jurisdictional Defects

#### Manual Transmittal

August 12, 2019

#### Purpose

(1) This transmits revised CCDM 35.3.2, Motions, Jurisdictional Defects.

#### Material Changes

(1) CCDM 35.3.2.1(1) was revised to include whistleblower cases as a cause of action over which the Tax Court has jurisdiction.

(2) CCDM 35.3.2.2 was added to reflect that the Tax Court is the only court with jurisdiction to hear petitions regarding whistleblower award determinations. A whistleblower award determination includes awards under both 7623 (a) & (b), rejections, and denials and is construed broadly by the Tax Court. The Whistleblower Office may issue more than one determination with respect to any claim and any determination can be appealed within 30 days of the determination. Only whistleblower award determinations are appealable.

#### Effect on Other Documents

This section supersedes CCDM 35.3.2, dated July 27, 2018.

#### Audience

Chief Counsel

#### Effective Date

(08-12-2019)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure and Administration)

**35.3.2.1** **(08-12-2019)**

### Tax Court Subject Matter Jurisdiction

1. The Tax Court is a statutory court of limited jurisdiction, and strict compliance with all essential jurisdictional elements is necessary before the court is empowered to enter a legal decision in the case. Generally speaking, the Tax Court has jurisdiction to redetermine income, gift and estate tax liability, transferee liability with respect to these taxes, and certain excise taxes. The Tax Court also has jurisdiction over causes of action for declaratory judgments under sections 6110, 7428, 7476, 7477, and 7478; and certain other causes of action such as interest abatement, Whistleblower Office determinations, relief from joint and several liability, and collection due process proceedings. With minor exceptions, the jurisdiction of the court with respect to taxes extends only to those years and taxes in which a deficiency or liability was determined in the statutory notice of deficiency or liability and raised in a timely petition to the Tax Court. Jurisdictional questions may be raised by the court upon its own motion or by either party at any stage of the proceeding. Normally, all questions concerning jurisdiction should be resolved prior to the filing of the answer.

2. A jurisdictional motion is required where the petition attempts to take an appeal from something other than a statutory notice or other valid determination letter permitting Tax Court review; the petition is not filed within the statutory period; the petition attempts to take an appeal with respect to a year or a tax as to which no deficiency (or transferee liability) is determined; the petition is brought by an improper party or a nonexistent party; or, the petition is filed for redetermination of a deficiency or liability which has been paid before the mailing of the statutory notice. Special care should be taken to insure that a corporation, trust, or estate is still in existence and competent to sue. The foregoing jurisdictional items are not all inclusive, and the Field attorney should research the statutory and case law with respect to any case in which there is doubt as to the jurisdiction of the Tax Court.

3. A jurisdictional defect should be raised in a motion to dismiss for lack of jurisdiction as soon as the jurisdictional defect is discovered and any evidence needed to support such a motion is acquired. Field attorneys should avoid waiting to raise such defects in the answer, stipulation or motion under T.C. Rule 122 to ensure a prompt resolution of the case and to avoid unnecessary work for the Tax Court.

4. There is no jurisdictional defect in a petition when a petitioner seeks a determination of a section 6651(a)(2) (failure to pay) addition to tax when the Tax Court already has jurisdiction to redetermine the deficiency of the tax for the period upon which the section 6651(a)(2) addition to tax is based. _See_ _Estate of Hinz v. Commissioner_, T.C. Memo. 2000-6; _Estate of Nemerov v. Commissioner_, T.C. Memo. 1998-186. Motions to dismiss this claim on jurisdictional grounds should not be filed.

5. _See_ CCDM 35.3.8, _Motions in Declaratory Judgment Cases and Section 7436 Worker Classification Cases_, for guidance concerning motions in these types of cases.


**35.3.2.2** **(08-12-2019)**

### Appealable Determinations in Whistleblower Cases

1. Section 7623(b)(4) grants the Tax Court jurisdiction to review any whistleblower office determination regarding an award under paragraph (1), (2), or (3) of section 7623(b). This does not mean that jurisdiction is limited to when the conditions of section 7623(b)(4) have been satisfied. _See_ CCDM 35.1.1.17, _Review of Whistleblower Office Determinations_.

2. The Tax Court is the only court with jurisdiction over petitions regarding whistleblower award determinations. An award determination includes award rejections and denials. The name or label of the document does not control, nor does specific determination language.

3. The Tax Court’s jurisdiction is not limited to the amount of an award determination but includes any determination of award or denial of an award. Thus, for purposes of its jurisdiction, the Tax Court has held that an award determination under section 7623(a) is effectively a denial of an award claim under section 7623(b).

4. The Tax Court may not dismiss a case or relinquish its jurisdiction if the Whistleblower Office decides to reconsider a claim. If the Whistleblower Office issues a determination and the whistleblower petitions, the Tax Court will have jurisdiction, regardless of whether the Whistleblower Office decides to reopen or further consider the claim.

5. The Whistleblower Office may issue more than one determination with respect to any claim, and there is no specific format for a determination. The Tax Court has jurisdiction to review any award determination if timely petitioned, including subsequent determinations.

6. A petitioner has 30 days from the date of the Whistleblower Office’s determination to file a petition. The 30 day appeal period generally commences when the Whistleblower Office sends a final determination letter. In cases of an agreed award when there is no final determination letter, the Whistleblower Office’s final determination is made on the date that it issues an award check to petitioner. A whistleblower can choose to accept a preliminary award determination and agree to waive all administrative and judicial appeal rights, including the right to petition the Tax Court. The Tax Court has jurisdiction to determine the validity of petitioner’s waiver of the right to petition the Tax Court.


**35.3.2.3** **(09-21-2012)**

### Motions to Dismiss for Lack of Jurisdiction

1. If the document filed with the court as a petition is not properly within its jurisdiction, such as in instances in which a petition was not timely filed, the response should be a motion to dismiss for lack of jurisdiction. See Exhibits 35.11.1-34 through 35.11.1-40. When the petition is late, the Field attorney assigned the case should immediately obtain proof of mailing ( [U.S. Postal Service Form 3877 PDF](http://about.usps.com/forms/ps3877.pdf), Firm Mailing Book For Accountable Mail, or equivalent with legible United States postmark or an appropriate affidavit) from the office that issued the notice and attach the same to the jurisdictional motion. The motion should be filed with the court, if possible, before the answer due date.

2. Any motion based upon a jurisdictional defect must be a motion to dismiss for lack of jurisdiction and not a motion merely to strike the petition, in whole or in part. Likewise, a jurisdictional defect concerning a party must be raised in a jurisdictional motion, not merely a motion to change caption. The jurisdictional defect may extend to the entire case, or it may extend only to some taxes or some years or some persons which the petition attempts to bring before the Tax Court. Since the Tax Court must in its final order or decision cover all taxes for all years placed in controversy, and since the court may not enter a decision or final order with respect to any year, tax or person over which it does not legally acquire jurisdiction, a motion should be made to eliminate from the case all parts thereof over which the court does not acquire jurisdiction at the earliest time in which the jurisdictional defect appears in the case. When a jurisdictional motion is not intended to resolve the entire case, it is generally combined with an additional request such as a caption change or striking of certain allegations, signifying that the motion will result in only a partial disposition. Such a motion may be titled Motion to Dismiss for Lack of Jurisdiction and to Change Caption or Motion to Dismiss for Lack of Jurisdiction as to Taxable Year 2003 and to Strike.

3. In dismissing a case, in whole or in part, for lack of jurisdiction the court does not determine any tax or transferee liability. Thus, such motions should be filed regardless of whether the respondent has a statutory burden of proof as to the year, tax or person over which the petition attempts to place in controversy but over which the court lacks jurisdiction.

4. The petitioner has the burden of alleging and proving, when questioned, that the court has jurisdiction over all items or persons placed in controversy in the petition. At the same time, the moving party has the burden to establish a prima facie case for the relief requested in the motion. Thus, jurisdictional motions must be based upon facts and not upon failure to allege in the petition a jurisdictional fact known to the respondent. If the court has jurisdiction over all items or persons placed in controversy, and if such fact is known to the respondent although not alleged in the petition, the essential jurisdictional facts should be alleged in the answer so that jurisdiction will appear on the record. Thus, in the latter instances a jurisdictional motion would not be filed, but the missing jurisdictional elements in the pleadings would be cured by allegations in respondent’s answer. In the case of a timely, yet imperfect petition that the court has served on respondent without ordering it perfected, necessary jurisdictional facts such as the issuance of a valid notice of deficiency and the timely filing of the petition may be made in a motion for more definite statement with respect to the imperfect petition.


**35.3.2.4** **(09-21-2012)**

### Timeliness of Petition

01. In every case a computation must be made to determine the number of days between the mailing of the statutory notice of deficiency and the filing of the petition. The mailing date of the statutory notice is always the date certified or registered mail was sent to petitioner’s last-known address. The envelope in which the petition is mailed to the court bearing a postmark or postmeter mark after the prescribed date is conclusive as to the date of mailing, for purposes of section 7502, precluding the consideration of conflicting evidence as to date of mailing. Thus, in every such case, a motion to dismiss for lack of jurisdiction must be filed. Section 3463(a) of RRA 98 provides that the Service shall include on each notice of deficiency the date determined by the Secretary as the last day on which the taxpayer may file a petition with the Tax Court. Even if the date listed on the notice of deficiency for the last day to file is incorrect and allows more than the statutory 90 or 150 day period to timely file a petition, a petition mailed to the Tax Court on or before the date listed on the notice will nevertheless be deemed timely. If the notice of deficiency fails to list the last day on which the taxpayer may file a petition with the Tax Court and the petition is otherwise untimely, the Field attorney should contact the office of the Associate Chief Counsel (Procedure and Administration) concerning how to proceed with the case.

02. Section 7502(f) treats any private delivery service designated by the Service (Designated Delivery Service) as if it were the United States Postal Service for purposes of the timely mailing as timely filing provisions of section 7502. _See_ Rev. Proc. 97–17, Notice 97–26 and Notice 2001–62.

03. If a petition is untimely and the address on the petition differs from the address on the statutory notice of deficiency, a computer check should be made of the petitioner’s last known address and the Field attorney should attempt to obtain the petitioner’s most recently filed return as of the date that the notice of deficiency was issued. Ordinarily a jurisdictional motion should be filed if the petition is not filed within the 90–day period or the 150–day period. See Exhibits 35.11.1-41 and 35.11.1-42 for tables to compute 90- and 150- day periods. Common sense must be used in close cases. For example, if the petition was mailed from San Francisco, the postmark date is illegible, and it is filed with the Court one day late, common sense dictates that it was mailed timely. Any questionable calls should be brought to the attention of Procedure and Administration. Bear in mind that the filing due date of the petition may vary in some circumstances. The 90-day or 150-day period is extended if the last day falls on a Saturday, Sunday or any legal holiday in the District of Columbia, _see_ section 7503; and the time is suspended in some cases falling within section 7508. The petition served upon the respondent should normally bear the notation of the court as to the postmark date shown on the envelope in which the petition was mailed to the court, the lack of a postmark, private delivery service information, or the illegibility of the postmark or delivery service received date. If a postmark is made other than by a United States Post Office, e.g., by a private postal meter registered with the United States Postal Service, and the petition is received by the Tax Court within the time a letter ordinarily would have been received had it been mailed on the last day of the statutory period, no jurisdictional motion should be filed.

04. When the envelope in which the petition was mailed bears a private postmeter mark, section 7502 applies. Under the implementing regulation, Treas. Reg. § 301.7502–1(c)(1)(iii)(b), if the postmeter date is within the 90–day period and the petition was received no later than the ordinary delivery time for mail postmarked at the same place of origin by the United States Postal Service on the last day of the statutory period, the petition will be considered timely filed. If the petition is received later than the ordinary delivery time for documents so mailed and postmarked by the United States Postal Service, it will be considered timely only if petitioner can prove three things: first, that the petition was actually deposited in the mail before the last pickup from the mailbox on the 90th day; second, that the delay in receiving the petition was due to a delay in the transmission of the mail, and third, the cause of the delay. The jurisdictional issue should not be raised if the petitioner can demonstrate informally that the petition was timely mailed. See Exhibit 35.11.1-43, Letter to Petitioner Regarding Late Filed Petition. If a motion to dismiss is filed based on the receipt of the petition beyond the ordinary mailing time, and the petitioner’s response is fairly specific that the petition was mailed on or before the 90th day, the motion may be withdrawn or conceded. The petitioner has the burden of proof, but the Tax Court will not lightly dismiss a petition and thereby deprive the petitioner of the opportunity to litigate the deficiency in the Tax Court. The controlling regulation suggests that a petitioner can avoid the risk of an untimely filed petition by using certified or registered mail. As to registered mail, the date of registration is treated as the postmark date; as to certified mail, the mailer can obtain a postmarked receipt which is evidence of timely mailing and hence timely filing.

05. Every motion filed to dismiss upon the basis that the petition was not timely filed must make out a prima facie case on the untimeliness of the petition. The date the statutory notice of deficiency was mailed must be alleged in the motion. In addition, the filing date of the petition and facts which show that the case does not come within any of the statutory exceptions to the 90–day or 150–day period must be alleged. See Exhibit 35.11.1-34, Motions to Dismiss for Lack of Jurisdiction: Untimely Petition — Late U.S. Postmark. The motion should have attached a photocopy of the executed Application For Registration or Certification ( [U.S. Postal Service Form 3877 PDF](http://about.usps.com/forms/ps3877.pdf) or its equivalent) from the United States Post Office. This form sets forth the name and address of the sender of the documents, whether sent by registered or certified mail, the article number, the name and address of the addressee, the type of document mailed, the signature of the employee of the Postal Service receiving the document, and the post office stamp showing the date of the mailing and the post office in which mailed. This application is sometimes referred to as the "mailing list" of statutory notices. On occasion the Tax Court has, on its own, raised a question as to the sufficiency of the mailing list in proving the mailing date of the statutory notice when the mailing list did not set forth the type of document mailed. In some instances, in the absence of a description of the document on the mailing list, it may be necessary to obtain from the person in the office of the Area Director, Service Center, or Appeals, as applicable, who mailed the document an affidavit that the document set forth on the mailing list is in fact the statutory notice upon which the petition to the Tax Court is based. The names and addresses of other taxpayers on the mailing list must be redacted or blocked out to comply with disclosure restrictions. Only the United States postmark and the lines applicable to the petitioner should be exposed when making copies. If the United States postmark is placed on a typewritten or handwritten portion of the list, the postmark must remain readable and any words underneath cannot be eradicated. The minor information that might appear beneath the postmark will be insufficient to disclose anything subject to disclosure or Privacy Act restrictions.

06. If the U.S. postmark on the copy of the mailing list (submitted to the court as an attachment to the original of the motion) is not legible, or if there is no United States postmark on the list, it will be necessary to secure and attach to the motion an affidavit or declaration attesting to the date of mailing of the notice by the person who prepared the mailing list, or that person’s reviewer, or other custodian of the Service’s records of mailing. Where the mailing list or certified mail receipt ( [U.S. Postal Service Form 3877 PDF](http://about.usps.com/forms/ps3877.pdf) or its equivalent) is lost, destroyed, or otherwise unavailable, the Tax Court has held that the testimony of the 90-day clerk relative to the procedure for mailing the deficiency notice, while admissible, is not alone sufficient to prove that the notice was mailed. On the other hand, the presumption of official regularity and absence of direct evidence contradicting the government’s evidence of mailing was held sufficient by a district court. Any questions concerning this area may be directed to Procedure and Administration.

07. If the postmark date on the envelope containing the petition is illegible, or if there is no postmark, and there is a substantial question of fact as to whether the petition was timely mailed, a jurisdictional motion may be filed requiring the petitioner to sustain his or her burden as to the timely mailing of the petition. Such a motion is not required if the petitioner’s position is documented as to the circumstances surrounding the mailing and such evidence is a satisfactory explanation of the circumstances. See Exhibit 35.11.1-36, Motions to Dismiss for Lack of Jurisdiction: Untimely Petition — Illegible Postmark/ Postmeter.

08. A question occasionally arises as to whether the petitioner is entitled to 90- or 150-days after the mailing of the statutory notice within which to file a petition with the Tax Court. The taxpayer may claim to have been a nonresident or out of the country at the time of the issuance of the notice and, therefore, entitled to 150 days. In instances of this type, the Field attorney should research the statutory and case law before filing a jurisdictional motion, since there is not always a bright line test to determine the applicability of the 150-day rule.

09. In the event further litigation over a jurisdictional issue becomes necessary, the Field attorney will need to present direct testimony or prepare several affidavits in support of the Service’s position. At a minimum, the Field attorney should have an affidavit from the preparer of the notice of deficiency or another knowledgeable person about the issuance of the particular notice. As needed, depending on the complexity of the particular factual situation, direct testimony or an affidavit from the Service Center Witness Coordinator should explain the particular processing of address information. Additionally, if a taxpayer questions the efficacy of the Postal Service’s proper handling of the notice of deficiency, direct testimony or an affidavit from a postal representative may be needed.

10. Cases challenging the processing periods contained in Rev. Proc. 2001–18, 2001–08 I.R.B. 708, should be defended utilizing the existing case law, which generally gives the Service a reasonable processing time to input change of address information. Therefore, extreme care must be exercised in the development of cases questioning the efficacy of the Service’s processing of tax returns. Whenever possible, direct testimony or an affidavit from a knowledgeable Service Center employee should be utilized so that the courts are aware of the lengths the Service must go to in processing the millions of returns received each year. Inasmuch as the Service may now update a taxpayer’s address based on a change of address request filed with the Postal Service, the Service’s procedures for updating addresses based on return information should rarely be at issue in cases before the court.


**35.3.2.5** **(07-27-2018)**

### Absence of Valid Statutory Notice

1. Petitions to the Tax Court in deficiency cases challenging the proposed assessment of income, estate, gift, and certain excise tax may be predicated only upon the issuance of a valid statutory notice of deficiency.

2. A petition in a deficiency case that is filed before the Service issues a notice of deficiency does not confer jurisdiction on the Tax Court. The Tax Court does not acquire jurisdiction upon the issuance of a 30-day letter, notice of rejection of a claim for refund, or other similar notices with respect to the taxpayer’s tax liability. If a notice of deficiency has not been issued because the tax year is still under examination, the petition is premature.

3. If the petition is premature, attorneys should move to dismiss the case for lack of jurisdiction. In this instance, the motion should make out a prima facie case that the petition is based upon a 30-day letter, notice of rejection of a claim for refund, or other similar notice, or not based on any communication from the Service at all. In premature petition cases, Field Counsel will generally receive a Form 15022, IRS Certification - Income/Gift/Estate Tax Statutory Notice of Deficiency NOT Issued from Appeals Account and Processing Support (APS). _See_ CCDM 35.2.1.1.6, Premature Petitions. If Field Counsel does not receive a Form 15022, Field Counsel must conduct a search to verify that a notice of deficiency or other determination letter that would confer jurisdiction on the Tax Court has not been issued to the taxpayer for the tax/period at issue. The jurisdictional motion should state that a search was conducted and no notice of deficiency or any other determination letter that may form the basis of a petition to the court was found. Form 15022 may be relied on in place of attorneys conducting a search, but it is not to be attached as an exhibit to the jurisdictional motion.

4. The IRC section 6503(a) suspension of the periods of limitations on assessment and collection does not apply if the Service did not issue a notice of deficiency. As a result, Field Counsel will be available to assist Examination personnel in ensuring that timely assessments are made in these cases. _See_ CCDM 35.2.1.1.6, Premature Petitions.


**35.3.2.6** **(09-21-2012)**

### Jurisdiction Over Party Petitioners

1. The court must have jurisdiction over the party or parties who are filing the petition from the statutory notice. If one or all of the listed parties are not the party or parties to whom the statutory notice was issued, a jurisdictional motion should be filed unless it is clear from the petition that the "substitute party" has legal authority to file a petition for or on behalf of the party to whom the statutory notice was issued. See Exhibit 35.11.1-37, Motions to Dismiss for Lack of Jurisdiction: No Statutory Notice. In that event, a motion to correct caption may be required.

2. In the research of the statutory and case law, it may be necessary not only to examine federal statutes but also state statutes and federal and state court decisions on the legal authority of the purported petitioner to prosecute an action in the Tax Court. Most frequently this question arises in statutory notices issued to dissolved corporations, merged corporations, discharged executors, sham trusts, etc. The question also arises under state or foreign law as to the authority of former officers and stockholders of dissolved corporations or discharged executors to bring the action in the Tax Court. Questions may also arise under state or foreign law with respect to statutory notices to unincorporated associations; in cases in which the notice was issued jointly and severally to a husband and wife and the petition is executed only by one of the parties even though the name of the other party is set forth in the caption and body of the petition; or in cases in which the statutory notice is issued to two or more persons and the petition is executed by only one of such persons and the term petitioner is used rather than petitioners in the caption and body of the petition. In these instances, the entire petition must be examined to determine whether the petition is intended to include all parties to whom the statutory notice was issued. For petitions based upon a statutory notice issued to two or more persons, it is important that it be determined if all of such persons are in fact proper party petitioners so that immediate assessment may be made against any person who did not in fact petition from the statutory notice. If the petitioning spouse, who intends to file a joint petition, fails to clarify his or her intention by filing an amended petition promptly, then a motion to dismiss the nonpetitioning spouse should be filed. Prior to filing such a motion to dismiss, consideration should be given to informally contacting the petitioner to see if the omission was inadvertent.

3. If petitioner’s counsel executes and timely files a petition on behalf of the petitioner, but at the time of filing was not admitted to practice before the Tax Court, a motion to dismiss for lack of jurisdiction on the ground that suit was instituted by a third party should only be filed if there is a question that the attorney is acting on behalf of the petitioners. Petitioner’s counsel should be notified in writing that he or she must take the steps necessary, under T.C. Rule 200, to be admitted to practice before the court and file an entry of appearance after becoming admitted. Otherwise, he or she cannot be recognized by the court or respondent as petitioner’s counsel of record and a motion may then be required to cure the pending jurisdictional defect.

4. As to whether the Tax Court has jurisdiction over a petitioner-corporation to which a deficiency notice was issued as a possessor of cash, see CCDM 35.2.1.1.4.1(1), Possessor of Cash.


**35.3.2.7** **(09-21-2012)**

### Jurisdiction Over Each Year and Each Tax

1. The Tax Court does not acquire jurisdiction over a year or a tax in which the statutory notice determined an overpayment, an overassessment, no deficiency in tax, or when the deficiency determined in the notice was assessed and paid prior to its issuance. If the petitioner attempts to place in controversy a year or a tax in which the statutory notice did not determine a deficiency (or liability in transferee cases), a jurisdictional motion with respect to this part of the case should be filed. See Exhibit 35.11.1-38, Motions to Dismiss for Lack of Jurisdiction: No Statutory Notice For Year Put In Issue. There is an exception with respect to years involved in carryover or carryback issues. Facts with respect to other years not before the court may sometimes have to be resolved to determine the tax effect for the year before the court. _See_ section 6214(b). Once the court acquires jurisdiction over a year or a tax, it has jurisdiction to redetermine the deficiency contested by the petitioner, any overpayment of tax for a year over which the court has acquired jurisdiction, and any section 6651(a)(2) (failure to pay) addition to tax regarding the tax period at issue. _See_ sections 6214(a), 6512(b).


**35.3.2.8** **(09-21-2012)**

### No Valid Petition

1. For the court to acquire jurisdiction, a valid petition must be timely filed. Since the court will frequently treat as a petition any document purporting to be a petition, only in rare, extraordinary cases should a motion to dismiss be filed on the ground that the petition does not constitute a valid petition. Typically, the problem arises in pro se cases or cases in which the petition is filed by attorneys unfamiliar with the rules of the Tax Court. In general, for the court to acquire jurisdiction, the document as a whole must express a present intent of the petitioner to file a petition from a statutory notice. The assignment by the court of a docket number to a document and service of that document on the respondent filed as a petition is a factual determination by the court that such document qualifies as a petition. Before any motion is filed which challenges the factual determination made by the court in this regard, the Field attorney should consult with the office of the Associate Chief Counsel (Procedure and Administration). See Exhibit 35.11.1-1, Issues Requiring Associate Office Review.


**35.3.2.9** **(08-11-2004)**

### Payment of Deficiency or Liability Before Issuance of the Statutory Notice

1. If, upon examination of the transcript of account, it appears that the deficiency or liability determined in the statutory notice was paid prior to the mailing of the statutory notice, a motion to dismiss the case for lack of jurisdiction should be filed. Cash bonds, however, and payments due to tax withheld or estimated tax payments are not considered as a payment, in whole or in part, of the determined deficiency or liability for this purpose since a statutory deficiency or liability is determined without regard to cash bonds, tax withheld or estimated tax payments. The motion must set forth fully the facts upon which it is based, and there must be attached thereto a copy of the transcript of account showing the assessment and/or payment of the deficiency or liability before the mailing of the notice.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-003-002#addtoany "Show all")

A2A