---
url: "https://www.irs.gov/irm/part34/irm_34-006-003"
title: "34.6.3 Summons Enforcement Actions | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part34/irm_34-006-003#main-content)

- 34.6.3  [Summons Enforcement Actions](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477661150096)
  - 34.6.3.1  [Summons Provisions](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477661542336)
  - 34.6.3.2  [Nature of Proceedings](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477661671536)
  - 34.6.3.3  [General Procedures for Seeking Enforcement of the Summons](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477661153504)
    - 34.6.3.3.1  [Referrals Directly to United States Attorney](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477661906048)
      - 34.6.3.3.1.1  [Procedures for Direct Referrals to U.S. Attorney](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477661107248)
    - 34.6.3.3.2  [Referrals through the Office of the Associate Chief Counsel (Procedure & Administration)](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477661322192)
      - 34.6.3.3.2.1  [Procedures for Referrals](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477689207904)
    - 34.6.3.3.3  [Referrals Directly to the Tax Division](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477661243648)
    - 34.6.3.3.4  [Adverse Recommendations from Magistrate in Summons Enforcement Cases](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477661719280)
    - 34.6.3.3.5  [Closing of Summons Cases](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477661809024)
  - 34.6.3.4  [General Procedures for Defending a Petition to Quash or Motion to Enjoin](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477661598272)
    - 34.6.3.4.1  [First Amendment as a Defense to a Summons or an Injunction Request in the Context of an IRC §6700 and/or §6701 Investigation](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477662485280)
      - 34.6.3.4.1.1  [The First Amendment as a Defense to Summonses](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477661811408)
      - 34.6.3.4.1.2  [The First Amendment as a Defense to Injunction Requests](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477661185184)
      - 34.6.3.4.1.3  [Preparing for a First Amendment Defense to Summons Enforcement or Injunction Request](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477661903552)
  - 34.6.3.5  [John Doe Summonses](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477661146320)
  - 34.6.3.6  [Special Summons Action](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477661820720)
    - 34.6.3.6.1  [Pre-Issuance Review of Summonses Issued for Tax Accrual or Other Audit Workpapers](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477661819920)
      - 34.6.3.6.1.1  [Procedures for Requesting Audit or Tax Accrual Workpapers](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477661816112)
      - 34.6.3.6.1.2  [Issuance of Summonses](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477689410768)
      - 34.6.3.6.1.3  [Enforcement of Summonses](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477661897264)
    - 34.6.3.6.2  [Summonses Issued to Obtain Computer Software and Documentation](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477661275424)
    - 34.6.3.6.3  [Actions to Obtain Approval for Dispensing with the Notice Requirements](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477661544144)
    - 34.6.3.6.4  [Criminal Investigation Summonses — Protest Procedures](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477661734384)
    - 34.6.3.6.5  [Summonses Issued During Collateral Investigations](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477661261408)
    - 34.6.3.6.6  [Tax Treaty and TIEA Summonses](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477661259792)
    - 34.6.3.6.7  [Administrative Requests for Grants of Statutory Use Immunity](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477661265136)
  - 34.6.3.7  [Issuance of Summons for Books and Records Abroad](https://www.irs.gov/irm/part34/irm_34-006-003#idm140477661857136)

# Part 34. Chief Counsel Directives Manual Litigation in District Court, Bankruptcy Court, Court of Federal Claims, and State Court

# Chapter 6. Suits Brought by the United States

# Section 3. Summons Enforcement Actions

* * *

## 34.6.3 Summons Enforcement Actions

#### Manual Transmittal

July 05, 2023

#### Purpose

(1) This transmits revised CCDM 34.6.3, Summons Enforcement Actions.

#### Material Changes

(1) CCDM 34.6.3.4(5) is revised to provide that, instead of referring all requests to defend petitions to quash a summons to the Tax Division, employees should refer requests to defend petitions to quash a summons to the appropriate U.S. Attorney or the Tax Division, depending on the underlying summons and/or defenses raised.

#### Effect on Other Documents

CCDM 34.6.3, dated June 8, 2022, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(07-05-2023)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**34.6.3.1** **(06-08-2022)**

### Summons Provisions

1. The statutory authority for issuing a summons is contained in IRC 7602. Under this provision, a summons may be issued for the purpose of ascertaining the correctness of any return, making a return where none has been made, determining the liability of any person for, or with respect to, any internal revenue tax, or collecting any such liability. _See_ section 7602(a). A summons may also be served for the purpose of inquiring into any offense in connection with the administration or enforcement of the internal revenue laws. _See_ IRC 7602(b).



1. No summons may be issued and the Secretary may not begin any action under section 7604 to enforce any summons with respect to a person if a DOJ referral, as defined in section 7602(d)(2), is in effect with respect to such person. This is the so-called "bright line test" under which a summons can be enforced as long as the enforcement petition is filed before a DOJ referral is made. That is, litigation of summons proceedings pending at the time of a referral may continue. No summons may be issued after a referral, however, and no petition to enforce may be brought after a referral has been made. Each taxable period and, in the case of excise taxes, each taxable event, is to be treated separately for referral purposes.


2. Other sections relating to the issuance and enforcement of summonses are:



   - IRC 7603 (service of summons)

   - IRC 7604 (proceedings to obtain enforcement of a summons)

   - IRC 7605(a) (time and place for examination)

   - IRC 6503(j) (suspension of statute of limitations in the case of designated summonses and related summonses)

   - IRC 7609 (special procedures for third-party summonses)

   - IRC 7610 (payment of fees and costs to witnesses)

   - IRC 7612 (special procedures for computer software)

   - IRC 7622 (authority to administer oaths)

   - IRC 7525 (confidentiality privilege for taxpayer communications)


3. The Right to Financial Privacy Act of 1978, codified at 12 U.S.C. §§ 3401 et seq. (RTFPA), contains provisions that control federal access to and use of financial records in the custody of financial institutions.



1. Section 3413(c), 12 U.S.C provides: "Nothing in this chapter prohibits the disclosure of financial records in accordance with procedures authorized by Title 26." The effect of this exception is that the RTFPA will not apply to requests for financial records by the Service. It is the Service’s position that this exemption applies not only when the Service issues a summons pursuant to IRC 7602 and IRC 7609; it also applies to the inspection of books and records pursuant to IRC 6333, and the examination of books and records and the taking of testimony without the issuance of a summons pursuant to IRC 7602. An example of the latter situation is obtaining records based on the presentation of credentials citing IRC 7602 authority. In _Neece v. Internal Revenue Service_, 922 F.2d 573 (10th Cir. 1990), the Tenth Circuit held that a bank’s voluntary disclosure of a customer’s financial records to the Internal Revenue Service, without prior notice to the customer, violated the RTFPA. The court determined that the voluntary disclosure of information pursuant to IRC 7602 did not constitute a procedure so as to fall within 12 U.S.C. § 3413(c). Accordingly, in situations where venue would lie in the Tenth Circuit, offices may employ third-party, John Doe, and collection summonses, and IRC 6333 demands to Exhibit books and records, but should refrain from other information-gathering procedures with respect to financial institutions.

2. IRC 7609(j), added by The IRS Restructuring and Reform Act of 1998 (RRA 98), specifically provides that the provisions of IRC 7609 regarding summonses do not limit the Service’s ability to obtain information, through formal and informal procedures, other than by summons, authorized by IRC §§ 7601 and 7602. This provision clarifies that, contrary to _Neece_, the voluntary disclosure of information is a procedure under IRC 7602.


4. Disclosure of returns or return information is governed by IRC 6103, Treasury regulations promulgated thereunder, and IRC §§ 7213 and 7431 and 18 U.S.C. § 1905. No commitments should be made to taxpayers or third parties guaranteeing a greater degree of confidentiality or limitation of use than is provided by existing law and regulations.

5. RRA 98 substantially amended I.R.C. § 7609. Under the amended version of IRC 7609, the procedures for third-party summonses are made inapplicable to criminal investigation summonses except those served on third-party record-keepers as defined in IRC 7603. Summonses for establishing liability for the Trust Fund Recovery Penalty are no longer potentially classifiable as collection summonses exempt from the third-party summons procedures. Summonses may be served by mail on third-party record-keepers (as defined in IRC 7603).

6. **Review of Proposed Summonses**. Occasionally, revenue agents, EP/EO specialists, and revenue officers may need assistance in the preparation of a summons or advice in connection with whether a summons can be used, to whom it should be directed, etc. It is likely Field Counsel will receive requests for advice and assistance.



1. Certain summonses are required to be reviewed by Field Counsel prior to issuance. Specifically, these are: summonses proposed to be issued where the records are outside the United States, which are coordinated with Procedure & Administration; John Doe summonses issued pursuant to IRC 7609(f); summonses issued to obtain audit, tax, or tax accrual workpapers; summonses that seek computer software packages; and designated summonses under IRC 6503(j). Summonses served on investors in abusive tax shelters must be reviewed by Field Counsel prior to service. A memorandum to file must be prepared by the Field Counsel and maintained in both the revenue agent’s administrative file and Field Counsel’s legal file.

2. For procedures regarding the review of summonses issued under IRC 6038A (Information With Respect to Certain Foreign-Owned Corporations), contact Division Counsel.

3. The issuance of a designated summons must be preceded by review by the Division Commissioner and the Division Counsel. It must also be reviewed and approved by Procedure & Administration. Approval by the Area Counsel is not required for any subsequent related summons that Field Counsel may approve for issuance.

4. Summonses issued to promoters of abusive tax shelters during a promoter investigation must be pre-reviewed and approved by Division Counsel or Deputy Division Counsel; then sent to DOJ for pre-issuance review. Some operating divisions may also require pre-review by Procedure & Administration for these summonses.


**34.6.3.2** **(02-01-2011)**

### Nature of Proceedings

1. The judicial device for enforcing the administrative summons is provided by IRC §§ 7402(b) and 7604. IRC 7604(a) provides that the jurisdiction to compel compliance with a summons is in the United States District Court for the district in which the person summoned resides or is found. Subsection (b) provides for a body attachment procedure, which "was intended only to cover persons who were summoned and wholly made default or contumaciously refused to comply" and is not to be used where there was a refusal based upon a claim of privilege. _Reisman v. Caplin_, 375 U.S. 440 (1964).

2. A proceeding brought under IRC 7604 is summary in nature. In petitioning the district court for an order to enforce the summons, the United States is seeking the assistance of the district court in requiring the person summoned to provide the requested information to the Service.

3. If the summons is issued to a third party, however, any person entitled to notice under IRC 7609(a) has the right to bring a proceeding to quash the summons. That person also has the right to intervene in any action to enforce a third-party summons brought by the Government under IRC 7604. IRC 7609(b). If the court orders the summons enforced, disobedience of such an order is punishable through a contempt citation issued by the court. Special attention should be given to assure that, where applicable, the issuing agent obtained prior supervisory authorization. See Delegation Order No. 25–1, _Summonses, Oaths, Certifications, and Related Functions_, http://publish.no.irs.gov/getpdf.cgi?catnum=39624.


**34.6.3.3** **(02-01-2011)**

### General Procedures for Seeking Enforcement of the Summons

1. When there is a neglect or refusal on the part of the person summoned to respond to the summons, or the person entitled to notice under IRC 7609(a) has exercised his/her right to bring a proceeding to quash the summons, the Area Director will consider whether to seek judicial enforcement. Generally, when a summons is served, the office should be prepared to see the matter to a final and successful conclusion.



1. When determining whether to seek enforcement of a third-party summons, Field Counsel should verify that notice was given to the person who is identified in the description of the records contained in the summons and the appearance date must be at least 23 days after the date notice is given. IRC 7609(d)(1).

2. In the case of non-third-party summonses, Field Counsel should check to assure that the response date is at least ten (full) days from the time the summons was served. IRC 7605(a).

3. If after consideration of all of the circumstances, the Area Director deems it advisable to proceed with enforcement, the matter is referred to Field Counsel for consideration and determination of what legal action should be taken. The referral memorandum transmits the original of the summons, together with a memorandum prepared by the issuing agent, specialist, or officer outlining the facts. The Internal Revenue Manual contains instructions as to what the report should contain and the number of copies.

4. Unless specifically provided otherwise below, final action should be taken within six workdays after receipt of a request for civil enforcement of a summons.


2. A file under the name of the taxpayer is opened immediately upon receipt of the request for civil enforcement. It is categorized as a Summons Case. Where summonses have been issued to multiple witnesses, a file should be opened in the name of the taxpayer for each summons enforcement request, and the subject line of the legal file should be cross referenced to the name of the witness against whom the summons enforcement action is requested.

3. After the request for enforcement has been reviewed by Field Counsel and he/she believes that the summons is legally enforceable, a letter should be prepared referring the matter to the appropriate U.S. Attorney or the Tax Division. See_CCDM 34.6.3.3.1_ and _CCDM 34.6.3.3.2_ to determine whether a request for enforcement should go directly to the U.S. Attorney or DOJ or should be routed through the Office of the Associate Chief Counsel (Procedure & Administration).

4. If for some reason the summons is legally defective, this can often be corrected by reissuing and serving an amended summons, and, if compliance is still not forthcoming, the matter may then be referred for enforcement. The procedures set out in the Internal Revenue Manual will be followed by the Area Director’s office in the event Field Counsel contemplates disapproving a request for civil enforcement of a summons. For procedures to be followed when Field Counsel contemplates disapproving a request for enforcement of a summons in a Criminal Investigation case, see _CCDM 34.6.3.6.4_, below.

5. In the absence of unusual circumstances, Field Counsel will take final action within six workdays from the receipt of a summons case. Where emergency action is required, telephonic referral may be used with a formal written referral transmitted as soon as circumstances will permit.

6. Field Counsel should stay abreast of a case once it is referred and advise Procedure & Administration of any situation that arises which could have a bearing on a summons case referred to DOJ. Field Counsel should similarly advise the U.S. Attorney in cases that were directly referred to the U.S. Attorney.


**34.6.3.3.1** **(02-01-2011)**

#### Referrals Directly to United States Attorney

1. Requests for enforcement of summonses (except those specifically required to be forwarded to the Office of the Associate Chief Counsel (Procedure & Administration) or to the Tax Division) will be forwarded directly to the U.S. Attorney.

2. Requests for civil enforcement of summonses may also be sent directly to the U.S. Attorney where a summons has been issued to a financial institution and neither the financial institution nor noticee has raised any defense to enforcement, and where any defenses raised are merely procedural and not substantive (e.g., defective service, failure to give notice, etc.). Frivolous constitutional defenses are not considered substantive and may be referred directly to the U.S. Attorney. In cases where there is doubt as to whether the defense is frivolous, the request for enforcement should be sent to the Tax Division. Defenses of the frivolous nature contemplated by this paragraph include but are not limited to:



   - The tax laws are unconstitutional because the Sixteenth Amendment was not properly ratified.

   - The Federal Reserve System is unconstitutional and, therefore, so is the Internal Revenue Code to the extent that it taxes income represented by notes or checks that do not contain or are not redeemable in gold or silver.

   - The Internal Revenue Code violates the First, Fourth, Fifth, and Thirteenth Amendments by enslavement of person.

   - The requirement that one file an income tax return violates a person’s Fifth Amendment right against self-incrimination.

   - Sections 7201-7212 are unconstitutional in that they make no provision for the protection of a taxpayer’s constitutional right against self-incrimination;

   - The summons is not valid because it was issued by an agent, not a judge; or because it was served by an agent, not a United States Marshal;

   - Sections 7201-7212 are unconstitutional because a summons constitutes an unreasonable search and seizure in violation of the Fourth Amendment; and

   - Compliance with a summons that seeks records of a third party violates the taxpayer’s Fifth Amendment right against self-incrimination.


3. With respect to examination or collection summonses referred directly to the U.S. Attorney, where enforcement is sought under IRC 7604(b), U.S. Attorneys are instructed that the approval of the Tax Division is required. U.S. Attorneys do not have to obtain prior authorization from the Tax Division to institute summons enforcement proceedings with respect to summonses issued by Examination and Collection, except where individual taxpayers or others have refused to produce records and have invoked the privilege against self-incrimination under the Fifth Amendment of the Constitution.


**34.6.3.3.1.1** **(02-01-2011)**

##### Procedures for Direct Referrals to U.S. Attorney

01. If a request for enforcement of a summons is received and may be forwarded directly to the U.S. Attorney, the following procedures should be followed.

02. If it is deemed appropriate, a letter, presenting a further opportunity for voluntary compliance, may be sent by Field Counsel to the person summoned. The letter should inform the recipient that if the summons is not complied with within TEN WORKDAYS after the date of the letter, a recommendation to judicially enforce the summons will be made. This letter should be mailed within TWO DAYS of receipt of the request. This procedure should not be used where the person entitled to notice under IRC 7609 has brought a proceeding to quash a third-party summons. The copies should be distributed as follows:



    - Original to the person summoned

    - 1cc - Area Director, location, Attn: appropriate division chief or section

    - 1cc - Legal file- initialed copy

    - Any other required copies


03. Arrangements should be made with the appropriate territory in the area director’s office to advise Field Counsel within THREE WORKDAYS after the date set in the letter for appearance if the person summoned has not complied with the summons. Arrangements can be made to provide that it is to be assumed that the summons has been complied with if notice to the contrary is not received.

04. If the summons is still not complied with, the recommendation for summons enforcement should be prepared by Field Counsel within SIX WORKDAYS after receipt of notification of noncompliance.

05. If a letter is not sent to the person summoned, or if the person summoned does not comply with the letter and civil enforcement is to be recommended, a letter setting forth law and facts is prepared by Field Counsel to the U.S. Attorney, together with proposed pleadings (with exhibits attached) to be used by the U.S. Attorney. All pleadings should be prepared for the signature of the U.S. Attorney. There are no objections to the use of acceptable pattern pleadings. The Tax Division considers the preferable caption in these proceedings to be United States v. \[person summoned\]. The U.S. Attorneys may nonetheless prefer to continue with captions customarily used in their districts. An Internal Revenue Officer is not to be named in the caption. The following distribution is made of the letter or memorandum:



    - Original – U.S. Attorney

    - 1cc – initialed copy

    - 1cc –Tax Division, Department of Justice, Attn: Civil Trial Section (with a copy of all attachments) (transmittal letter should NOT be used to forward this copy)

    - 2cc – Area Director (originating office)

    - 1cc – Area Counsel

    - Copies as required by Area Counsel

    - Copy to Field Counsel servicing the territory where a collateral summons is to be enforced


06. The pleadings prepared for use by the United States Attorney include a petition (Exhibit 34.12.1-21, _Petition_, http://publish.no.irs.gov/getpdf.cgi?catnum=29689), a declaration of Revenue Agent or Officer, (Exhibit 34.12.1-22, _Declaration_, http://publish.no.irs.gov/getpdf.cgi?catnum=29689), and an order to show cause (Exhibit 34.12-1-23, Order,http://publish.no.irs.gov/getpdf.cgi?catnum=29689).

07. The pleadings should be distributed as follows:



    - Original – U.S. Attorney (with copies if requested by the U.S. Attorney)

    - 1cc – Tax Division, Department of Justice, Attn: Civil Trial Section (to be stapled to the copy of the letter or memorandum to the U.S. Attorney)

    - 1cc – Initialed copy

    - Copies as required by Area instructions


08. The original Commissioner’s summons should be attached to the petition as an exhibit and a copy should be attached to the copies of the petition. The original declaration of the Revenue Officer or Internal Revenue Agent should be attached to the petition as an exhibit and a copy attached to copies of the petition.

09. All summons enforcement letters should bring to the U.S. Attorney’s attention all related summons enforcement cases.

10. If civil enforcement action is not to be taken to enforce compliance with the summons, a memorandum will be prepared from Field Counsel to the Area Director, for the attention of the appropriate Territory Manager, returning the files and stating reasons why enforcement is not appropriate. For procedures to be followed when Field Counsel contemplates disapproving a request for enforcement of a summons in a Criminal Investigation case, see _CCDM 34.6.3.6.4_, below.


**34.6.3.3.2** **(02-01-2011)**

#### Referrals through the Office of the Associate Chief Counsel (Procedure & Administration)

1. Requests for civil enforcement of summonses issued by Small Business / Self-Employed (SB/SE), Large Business & International (LB&I), Tax Exempt And Government Entities (TEGE) or Criminal Investigation (CI) will require reference through the Office of the Associate Chief Counsel (Procedure & Administration), if Field Counsel approves the request for enforcement in the following situations:



1. Suits to enforce summonses relating to the tax liability of a church. Suits to enforce summonses issued to or seeking records (except bank records) pertaining to the tax liability of a minister or person claiming to be a minister, in coordination with TEGE Division Counsel, to consider whether the restrictions of IRC 7611 apply and, if so, are met.

2. Suits to enforce or defense letters for summonses issued to obtain tax accrual workpapers or other audit workpapers, as defined in IRM 4.10.20.2, _Audit Workpapers, Tax Accrual Workpapers, and Tax Reconciliation Workpapers Defined_,http://publish.no.irs.gov/getpdf.cgi?catnum=38775, regardless of whether the summonses are served on the taxpayer, the taxpayer’s accountant, the independent auditor, or any other person. These suit or defense letters also require approval by the Deputy Chief Counsel (Operations) or the Associate Chief Counsel (Procedure & Administration), as described in _CCDM 34.6.3.6.1.3_.

3. Requests for service of John Doe summonses pursuant to IRC 7609(f).

4. All suit authorization, defense and settlement letters involving designated and related summonses under IRC 6503(j). Suit recommendations with regard to enforcement of or defense of motions to quash designated and related summonses are to be prepared by Field Counsel and transmitted to Procedure & Administration as well as to DOJ for simultaneous review.

5. Requests involving significant, novel, or important issues may, at the discretion of Field Counsel, be forwarded to the Office of the Associate Chief Counsel (Procedure & Administration) for review. These should include summons cases involving significant, novel, or important interpretations of IRC 7609.

6. Suits to enforce summonses for records located outside the United States. _See_ _CCDM 34.6.3.7_.

7. Suits to enforce summonses for computer tax software packages and documentation. _See_ _CCDM 34.6.3.2_.

8. All suit authorization, defense and settlement letters involving summonses to produce records or information that may be relevant to ascertaining the correctness of Forms 8300, Reports of Cash Payments Over $10,000 Received in a Trade or Business, or to determine compliance with the reporting requirements of IRC 6050I. This includes summons enforcement against any trade or business for incomplete Forms 8300, as well as summonses against trades or businesses that the Service has reason to believe are not filing Forms 8300 or are filing false Forms.

9. All suit authorization, defense, and settlement letters involving a claim of the tax advice privilege under IRC 7525.


2. Except as provided above with respect to designated and related summonses, after review and approval by Procedure & Administration, all approved summons enforcement requests will be forwarded to the Tax Division. Those disapproved will be returned to the originating Field Counsel office. The Tax Division will prepare and file the necessary pleadings. Enforcement applications will usually take the form of orders to show cause why the summons should not be complied with.


**34.6.3.3.2.1** **(02-01-2011)**

##### Procedures for Referrals

1. If a Summons Enforcement recommendation must be referred through Procedure & Administration the following procedures should be followed:

2. If civil enforcement is to be recommended, a letter, containing adequate discussion of all relevant law and facts and addressed to the Department of Justice, Attn: Civil Trial Section, \_\_\_Region, is prepared and signed on behalf of the Chief Counsel by Field Counsel or his/her delegate. The proposed letter should be sent to Procedure & Administration by form transmittal. Distribution is as follows:



   - Original – Department of Justice

   - 1 cc – initialed copy

   - 2 cc – Associate Chief Counsel (Procedure & Administration)

   - 1 cc – Area Director (originating office with address)

   - 1 cc – Area Counsel

   - Copies as required by area instructions



     ### Note:



     Include mailing addresses for any copy to administrative distributees.


3. If the Criminal Division of DOJ or the Criminal Section of the Tax Division is known to have a related case or an interest in the taxpayer or witness, the letter should point out this fact and recommend coordination.

4. If the summons is issued by a Special Agent, it should be specified in the letter whether a joint investigation is in progress. If only a Special Agent is assigned to the investigation, the circumstances surrounding this fact should be described. If a pen register has been used in the investigation prior to issuance of the summons, this fact should be highlighted.

5. Proposed pleadings (Petition and Order) will not be prepared by Field Counsel. The original and one copy of the Commissioner’s summons should accompany the letter to DOJ.

6. All summons enforcement letters should bring to DOJ’s attention all related summons enforcement cases.

7. A copy of the investigative report and any other pertinent files should be forwarded with the proposed letter for the use of Procedure & Administration. These materials should be properly assembled with a properly filled out enclosure tag that includes the Chief Counsel file number, court caption, and taxpayer’s name.


**34.6.3.3.3** **(02-01-2011)**

#### Referrals Directly to the Tax Division

1. Requests for civil enforcement of summonses issued by the Criminal Investigation Division (except those specifically required to be forwarded to Procedure & Administration (see _CCDM 34.6.3.3.2_, above), or allowed to be forwarded directly to the U.S. Attorney (see _CCDM 34.6.3.3.1_, above)), should be sent to the Tax Division. Requests for civil enforcement of summonses issued by SB/SE, LB&I, TEGE and Criminal Investigation where the summons was issued to a financial institution, and where substantive defenses other than procedural defenses have been raised (see _CCDM 34.6.3.3.2_ above), shall also be sent to the Tax Division.

2. DOJ requires that all summons enforcement actions against attorneys be referred to the Tax Division and approved by the Assistant Attorney General regardless of the type of information being sought in the summons. This includes summonses issued to attorneys for purposes of obtaining client-related information or summonses issued to attorneys for obtaining information regarding the attorneys’ own tax liabilities. The same policy applies where a summons has been served on an attorney and the taxpayer files a Petition to Quash.

3. If a request for enforcement of a summons may be referred directly to the Tax Division, the following procedures may be followed. A letter, containing adequate discussion of all relevant law and facts, is sent to DOJ, Attn: Civil Trial Section, \_\_\_Region, and is signed on behalf of the Chief Counsel by the Area Counsel or his/her delegate, with distribution as follows:



   - Original – Department of Justice

   - 1cc – initialed copy

   - 1cc – Procedure & Administration (also enclose copy of the summons and request for enforcement)

   - 1cc – Area Counsel

   - Copies as required by area instructions



     ### Note:



     Include mailing addresses for any copy to administrative distributees.


4. Instructions in _CCDM 34.6.3.3.2 (3)-(7)_ above should be followed.


**34.6.3.3.4** **(08-11-2004)**

#### Adverse Recommendations from Magistrate in Summons Enforcement Cases

1. A district court judge may designate a magistrate to conduct hearings (including evidentiary hearings) and submit to a judge of the court proposed findings of fact, conclusions of law, and recommendations for disposition. 28 U.S.C. § 636. It is beyond the magistrate’s enumerated powers to render a final decision. But, pursuant to the 1979 Magistrate Act, 28 U.S.C. § 636(c), a magistrate, upon consent of the parties, may conduct hearings and render final decisions.

2. Whenever a proposed recommendation rendered by a magistrate is adverse to the position asserted by the Government, a request may be received from DOJ for the Chief Counsel’s views as to the advisability of filing objections to the findings of fact and conclusions of law.

3. Frequently, an adverse recommendation will be brought to Field Counsel’s attention locally by the court, the Area Director, or the U.S. Attorney. In many instances, Field Counsel may have knowledge of the adverse decision because of prior work in connection with the case.

4. After learning of an adverse recommendation, Field Counsel will immediately consider the matter and prepare a letter on Area Counsel stationery addressed to the U.S. Attorney or Assistant Attorney General, Tax Division, as appropriate.

5. This letter will contain a legal analysis and a recommendation as to the advisability of filing and prosecuting an objection from the magistrate’s recommendation, giving due effect to the facts and law applicable to the case.

6. It is important that Field Counsel consider the record in reaching a conclusion as to the position the office should adopt, i.e., is the Government’s position set out clearly and supported by competent testimony and documentary evidence?

7. The letter will recommend for or against making an objection and will be signed on behalf of the Chief Counsel at the field level.

8. **Time Limitations**. Generally, a party has ten days from being served with a copy of the magistrate’s findings and recommendation to file and serve written objections. 28 U.S.C. § 636. When objections are filed within the 10-day period, "… A judge of the court shall make a _de novo_ determination of those portions of the report or specified proposed findings or recommendations to which objection is made." (28 U.S.C. § 636(b)(1).) Field Counsel should take necessary precautions to ensure that the date for filing objections is observed. If necessary, the U.S. Attorney should be contacted for purposes of seeking an extension of time for filing the notice of objection. Such action should be cleared by telephone with the Tax Division, as appropriate.

9. In the event no objections are filed, the court remains under a duty to review the magistrate’s proposals because those proposals are not self-operative. The nature of that review will vary with the circumstances, and the court has the discretion to determine the extent to which it will review the matter. At least a minimal review is necessary because only a court order can put the proposal into effect. _Webb v. California_, 468 F. Supp. 825 (E.D. Cal. 1979).


**34.6.3.3.5** **(02-01-2011)**

#### Closing of Summons Cases

1. An enforcement of a summons case should be closed under the following conditions:



1. Counsel is advised that the witness has complied with the summons as a result of Field Counsel’s letter or, in the case of certain summonses, agreed to in advance by the Service, if notification of noncompliance is not received within (NUMBER TO BE SET BY FIELD COUNSEL) workdays of the date set for appearance of the witness summoned.

2. The summons is returned to the originating office without Field Counsel taking any action to enforce compliance therewith and any protest procedure is over.

3. Counsel is advised that the witness has complied with the summons as a result of a letter from the U.S. Attorney.

4. Counsel is advised that the witness has complied with the summons as a result of a court order.

5. The district court has denied enforcement and the Field Counsel’s file is forwarded to the Office of the Associate Chief Counsel (Procedure & Administration) for opening of an appeal file.

6. The petition is withdrawn.

7. For pre-referral cases, the advice has been given.


**34.6.3.4** **(07-05-2023)**

### General Procedures for Defending a Petition to Quash or Motion to Enjoin

1. When a person entitled to notice under IRC 7609(a) has exercised his/her right to bring a proceeding to quash a summons, the Service officer receiving a petition to quash should notify Field Counsel by telephone that same day. The recommendation of the Area Director’s office should be referred to Field Counsel within six work days. The referral memorandum should include the original of the summons and a copy of the petition to quash (together with any documents supporting the petition).

2. A file under the name of the taxpayer should be opened immediately upon notification that a petition to quash has been received. It is categorized as a Summons Case. Where summonses have been issued to multiple witnesses, a file should be opened in the name of the taxpayer for each petition to quash, and the Subject line of the legal file should be cross referenced to the name of the witness.

3. After reviewing the summons and the petition to quash, Field Counsel should prepare a letter referring the matter to the appropriate U.S. Attorney or the Tax Division. Field Counsel should verify that notice was given the noticee within three days of the day on which service of the summons was made, but not less than 23 days before the appearance date. Field Counsel should also verify that the petition to quash was timely filed within 20 days of the giving of notice.



1. Usually the Service may rely upon a court order denying a petition to quash to compel compliance even though the summoned party was not made a party to the action. If Field Counsel reasonably anticipates that the summoned party will resist the summons, Field Counsel should request that the summoned party be joined and seek enforcement against it.

2. If a summons should prove partially defective, defense and enforcement should still be sought as to the remaining valid portions.

3. In the case of a Criminal Investigation summons, if Field Counsel determines that it should not be defended, an informal conference with the Special Agent in Charge should be arranged as quickly as possible. If no agreement can be reached, the procedures in _CCDM 34.6.3.6.4_ will be followed.


4. In the absence of unusual circumstances Field Counsel should take final action within six workdays from the receipt of the referral from the Area Director’s office. Where emergency action is required, telephonic referral may be utilized with formal written referral submitted as soon as circumstances will permit.

5. **Routing of Referrals**. Defense letters involving petitions to quash must be referred to the appropriate U.S. Attorney or the Tax Division, either directly by Field Counsel, or through Procedure & Administration, depending on the underlying summons and/or defenses raised. See CCDM 34.6.3.3.1 and CCDM 34.6.3.3.2 to determine whether a request to defend a petition to quash should go directly to the U.S. Attorney or the Tax Division or should be routed through the Office of the Associate Chief Counsel (Procedure & Administration). See also the **Justice Manual**, §§ 6-5.200 (“Summons Litigation–Allocation of Responsibility”) and 6-5.210 (“Summons Litigation–Exceptions to Direct Referrals”). The **Justice Manual** is available online at [http://www.justice.gov/jm/justice-manual](http://www.justice.gov/jm/justice-manual).



1. Letters routed through Procedure & Administration should have the same distribution as set forth above in _CCDM 34.6.3.3.2(3)a_. Paragraphs (2) through (7) are also to be followed to the extent applicable.

2. Letters sent directly to DOJ should follow the procedures set forth in _CCDM 34.6.3.3.3_.


6. **Motion to Enjoin**. IRC 7609 provides the sole means for a taxpayer to prevent a witness from complying with a third-party summons. A taxpayer may not, however, prevent the Service from seeking enforcement.



1. Procedure & Administration, is to be notified immediately whenever any action to enjoin the enforcement of an Internal Revenue summons is brought. It can be anticipated that there may continue to be actions in state and Federal courts seeking to restrain a summoned witness from testifying or producing records before an Internal Revenue official.

2. If an action to enjoin the witness is filed in ANY court and neither the United States nor any Internal Revenue official is named, ordinarily the Government should not become involved in any manner in that action.

3. If a suit is brought in the United States district court and the United States or an Internal Revenue official is named, the Government will oppose that suit by moving to dismiss immediately on the authority of _Reisman v. Caplin_, 375 U.S. 440 (1964).

4. If a suit is brought in a state court to enjoin an Internal Revenue official, then action will be taken to remove the action to the United States district court under 28 U.S.C. § 1442, and to dismiss on the authority of _Reisman v. Caplin_.

5. Whenever an action is filed to enjoin either the Service or a summoned witness, the Internal Revenue official who issued the summons should be advised immediately so that a determination can be made whether to judicially enforce the summons. If the Service decides to seek enforcement, the recommendation should be processed promptly so as to ensure an early determination on the enforcement of the summons.


7. For procedures regarding an adverse decision by a magistrate on a petition to quash, see _CCDM 34.6.3.3.4_.


**34.6.3.4.1** **(08-11-2014)**

#### First Amendment as a Defense to a Summons or an Injunction Request in the Context of an IRC §6700 and/or §6701 Investigation

1. The First Amendment is sometimes raised as a defense (1) to compliance with summonses and (2) in investigations and requests for injunctive relief for violations of sections 6700 and 6701. Not all speech is protected speech. Two types of unprotected speech are implicated in this context: false commercial speech and speech that aids or abets unlawful conduct.

2. When government action is challenged on First Amendment grounds, the permissibility of the action will depend on whether the communication or expressive conduct is protected speech. Speech penalized under sections 6700 and 6701 is not protected speech. Because speech and conduct penalized by these sections is not eligible for First Amendment protection, the speech and conduct can be enjoined under sections 7402, 7407, or 7408. Section 6700 generally penalizes persons who organize or participate in selling a plan or entity, and who state that investing in the plan or entity will confer a tax benefit, while knowing or having reason to know that the statement is false or fraudulent as to a material matter. Its purpose is to penalize persons who promote abusive tax shelters. Section 6701 generally penalizes persons who aid or assist in preparing a return or other document (or portion thereof), while knowing or having reason to believe the document will be used in connection with a material matter arising under the tax laws, and while knowing that if the document is so used, it will result in the understatement of another person’s tax liability. Speech that violates these provisions can be false speech made in a commercial context and/or speech that aids or abets unlawful actions. Nevertheless, abusive tax shelter promoters and others who disseminate false tax information will at times raise the First Amendment as a defense to summons enforcement or to the government’s request for injunctive relief.

3. In circumstances in which a First Amendment privilege may be raised, field Counsel may be asked to assist the client with several matters, which include (1) describing the basic principle underlying the privileges of free speech and association, (2) distinguishing between speech that is and is not protected by the First Amendment, (3) evaluating the evidence to defend against a claim of First Amendment privilege, and (4) drafting the summons or injunction request. _IRM 34.6.3.4.1(4)_below describes categories of speech not protected by the First Amendment.

4. The First Amendment to the United States Constitution prohibits the government from “abridging the freedom of speech.” Accordingly, the First Amendment protects a person’s right to express and explore ideas and to associate with others to do so. The privilege includes the right to utter, print, distribute, receive, read, inquire about, contemplate, and teach ideas, regardless of the medium in which the ideas are expressed. The law does, however, distinguish between protected speech and unprotected speech. In the tax context, protected speech includes statements and discussions about the tax laws, whether true or not, including frivolous constitutional arguments. A person or group is free to profess and discuss virtually any erroneous, frivolous argument about the tax laws or their application, even if the discussions perpetuate false ideas and information about the tax laws. These types of protected speech do not, without more, violate any law. However, false commercial speech, speech that aids or abets unlawful conduct, and speech that incites imminent lawlessness are categories of speech not protected by the First Amendment. Thus, whether false speech about the tax laws is or is not protected depends on the context in which it occurs.



1. False Commercial Speech. When false speech, such as false opinions about the tax laws, occurs in a commercial context or in connection with a commercial interest, it becomes unprotected false commercial speech. Central Hudson Gas & Elec. Corp. v. Public Service Commission of New York, 447 U.S. 557, 563-64 (1980). Commercial speech, whether truthful or false, is speech that proposes a commercial transaction and is related solely to the economic interests of the speaker and its audience. Among the factors used to determine whether speech is commercial include whether: (1) the speech is an advertisement; (2) the speech refers to a specific product or service; and (3) the speaker has an economic motivation for the speech. Section 6700 penalizes anyone who, in organizing or selling a “plan” or “arrangement,” makes a statement about the tax benefits from participating in the plan or arrangement knowing, or having reason to know, that the statement is materially false or fraudulent. When the statement is made in the course of “selling” the plan or arrangement, the statement is false speech made in a commercial context. The same is true for “organizing” a plan or arrangement with the intent to make money from that effort. The First Amendment will not be a valid defense to summons enforcement or a proposed injunction in these commercial contexts.

2. Speech That Aids or Abets Unlawful Conduct. The First Amendment does not protect speech that aids or abets illegal conduct, such as tax evasion. Village of Hoffman Estates v. Flipside, Hoffman Estates, Inc., 455 U.S. 489, 496 (1982). Organizing or selling a false or fraudulent tax scheme in violation of section 6700 can also be speech that aids or abets unlawful actions. For example, a promoter may not legitimately claim First Amendment protection for speech promoting abusive tax shelters and arrangements in a way that purposely helps taxpayers violate section 7201 (tax evasion) or a similar provision. Speech made in a context that subjects it to penalty under section 6701 can also be speech that aids or abets illegal conduct.

3. Inciting Imminent Lawlessness. Another form of unprotected speech is that which incites others to imminently violate the law. Brandenburg v. Ohio, 395 U.S. 444, 447-49 (1969). The First Amendment does not confer the right to persuade others to violate the law. The imminence requirement may limit the government’s ability to assert this exception in promoter injunction cases. Nevertheless, a person can incite another to violate the internal revenue laws, and incitement as an exception to First Amendment protection may be available and should be considered in appropriate cases. For example, advising a taxpayer personally, or at a seminar, on how to prepare fraudulent tax forms presents a stronger case for this exception than one in which the advice is not one-on-one and is not likely to be acted on imminently.

4. Protected and Unprotected Speech Together. Many utterances include both protected and unprotected speech. Cloaking unprotected speech in protected speech will not prevent the government from regulating it, Ohralik v. Ohio State Bar Ass'n, 436 U.S. 447, 455-56 (1978), as either false commercial speech or speech contributing to illegal conduct or both, as long as the protected and unprotected speech are not “inextricably entwined.” United States v. Schiff, 379 F.3d 621, 627-29 (9th Cir. 2004).


**34.6.3.4.1.1** **(08-11-2014)**

##### The First Amendment as a Defense to Summonses

1. Summons enforcement is likely to be the point at which a promoter first raises the First Amendment as a defense. The Service must anticipate and prepare for a First Amendment defense prior to issuing a summons. The summons should be narrowly tailored to exclude information about protected speech, and/or the government must develop evidence that the speech to which the summoned information relates is unprotected speech, such as false commercial speech. For example, a promoter raises the First Amendment privilege to defend against enforcement of a third-party summons issued to an Internet payment service for information about online sales of a book. The Service must provide evidence to show that the affected speech was made in the context of promoting an abusive tax scheme, thereby removing the speech from First Amendment protection. The Service can demonstrate this with evidence showing (1) there is a likely suspicion the promoter is engaged in conduct subject to penalty under section 6700, and (2) the summons is limited to gathering information reasonably related to confirming that suspicion. The suspicion of conduct subject to section 6700 will come from evidence of an actual plan, arrangement, or other similar services being promoted or sold that claim false tax benefits.


**34.6.3.4.1.2** **(08-11-2014)**

##### The First Amendment as a Defense to Injunction Requests

1. Conduct that violates section 6700 or 6701 may be the basis for an injunction. In considering whether to impose an injunction, which is a prior restraint on speech, courts closely scrutinize the facts to determine if the speech or conduct to be enjoined is First Amendment-protected. The government must establish that the First Amendment does not bar an injunction. If the facts show a person is engaging in activity that violates section 6700 or 6701, then the activity is not protected speech and may be enjoined. Thus, the Service must obtain reliable evidence of the prohibited promotion, including the specifics of the promoter’s speech and conduct and any commercial element.

2. Cases to enjoin promoters of frivolous tax arguments are likely to involve both protected and unprotected speech. In some cases, the purportedly protected speech is an attempt to cloak false commercial speech with the appearance of being protected political speech. In these instances, the government will need to show a reviewing court that the purportedly protected speech is actually a ruse.

3. A proposed injunction must be carefully written to avoid unduly impacting protected speech when both types of speech are present. This may result in an injunction limited to the promotion of abusive tax schemes, while allowing the promoter to continue engaging in protected speech that stops short of promoting violations of the tax laws. For examples of properly drafted injunctions that did not infringe upon First Amendment rights because they focused on false commercial speech or the promotion of an illegal activity or transaction, see United States v. Buttorff, 761 F.2d 1056 (5th Cir. 1985), and United States v. Estate Preservation Servs., 202 F.3d 1093 (9th Cir. 2000).


**34.6.3.4.1.3** **(08-11-2014)**

##### Preparing for a First Amendment Defense to Summons Enforcement or Injunction Request

1. Before issuing a summons or referring a request for injunction, the Service should have credible information that can be presented as evidence that the subject of the contemplated summons or injunction may be promoting abusive tax schemes or is assisting others to violate the tax laws. The following is a non-exclusive list of potential evidence:



1. Evidence showing, or supporting a reasonable belief, that the materials to be summoned explain specifically how to evade tax that is in fact legally owed (i.e., a plan or arrangement for tax avoidance).

2. Evidence that the promoter describes or provides to customers forms (including tax returns) or statements (e.g., would-be revocations of citizenship or Social Security numbers) for filing with the Service or third parties. Usually a promoter will advise customers on how to complete and file the documents in a way that will understate liability, frustrate collection, or cause an erroneous refund.

3. Evidence that the promoter advises on how to hide or disguise ownership of money or other assets or how to remove assets from the United States.

4. Evidence that the promoter encourages or assists taxpayers to obstruct tax administration (e.g., through make-work FOIA requests, frivolous lawsuits, or spurious liens on the property of Service personnel).


2. There should be sufficient facts to demonstrate to a court, for purposes of summons enforcement or injunctive relief, that the promoter’s activities go beyond merely advocating an incorrect position. Field Counsel should assist in drafting summonses to ensure that they are tailored to request only the records and other information relating to the speech or conduct determined to be unprotected. These cases are to be reviewed in the Procedure & Administration Division of the National Office.


**34.6.3.5** **(02-01-2011)**

### John Doe Summonses

1. Under IRC 7609(f), prior court approval is required before service of a summons that does not identify the person with respect to whose liability the summons is to be issued (a "John Doe" ). Prior to making a determination with regard to the service of a John Doe summons, consideration should be given to the use of a dual-purpose summons. _See Tiffany Fine Arts, Inc. v. United States_, 469 U.S. 310 (1985). A dual purpose summons is a summons served with the dual purpose of investigating liabilities of a taxpayer and of unnamed parties. Such a summons does not need to meet the requirements of a John Doe summons if the information sought may be relevant to the legitimate investigation of the identified taxpayer. Delegation Order 25-1, _Summonses, Oaths, Certifications, and Related Functions_, http://publish.no.irs.gov/getpdf.cgi?catnum=39624, describes the persons delegated the authority to issue a John Doe summons.

2. If an office forwards a request for pre-issuance approval of a John Doe summons, Field Counsel reviews the request to determine if the summons relates to the investigation of a particular person or ascertainable group or class of persons, if there is a reasonable basis for believing that such person or group may have failed to comply with any provision of the internal revenue laws, and if the information sought to be obtained is not readily available from other sources.

3. If approved, Field Counsel will prepare a letter containing the law and facts justifying court approval. The letter should be addressed to the DOJ, Attention: Civil Trial Section, Chief, \_\_\_Region, and be signed on behalf of the Chief Counsel by the Field Counsel or his/her delegate with distribution as outlined in _CCDM 34.6.3.3.2_ above.


**34.6.3.6** **(08-11-2004)**

### Special Summons Action

1. This subsection describe summons actions requiring special handling.


**34.6.3.6.1** **(02-01-2011)**

#### Pre-Issuance Review of Summonses Issued for Tax Accrual or Other Audit Workpapers

1. Field Counsel and Procedure & Administration will provide pre-issuance review of any informal document requests (IDR) or summonses that seek tax accrual or other audit workpapers. This will ensure that the procedures of IRM 4.10.20, Requesting Audit, Tax Accrual, or Tax Reconciliation Workpapers, are followed. These procedures do not apply to Criminal Investigation summonses.

2. Tax accrual workpapers and audit workpapers are defined in IRM 4.10.20.2, Audit Workpapers, Tax Accrual Workpapers, and Tax Reconciliation Workpapers Defined.

3. In general, audit or tax accrual workpapers will be requested only in unusual circumstances. This standard, described in IRM 4.10.20.3.1, Unusual Circumstances Standard, applies to all requests for tax accrual workpapers that do not involve a listed transaction as defined in Treas. Reg. § 1.6011-4, to any request for tax accrual workpapers involving a listed transaction for returns filed on or before February 28, 2000, and to requests for any audit workpapers other than tax accrual workpapers.

4. In 2002, the Service modified its historical policy of restraint in requesting tax accrual workpapers. In general, the modified policy applies to returns filed by taxpayers claiming benefits from listed transactions. Announcement 2002-63, 2002-2 C.B. 72. A listed transaction is defined in Treas. Reg. § 1.6011-4, and subsection (b)(2) defines listed transactions to include substantially similar transactions. The Service’s policies governing requests for tax accrual workpapers in listed transaction circumstances vary according to when the tax return was filed, as described in IRM 4.10.20.3.2.2, Returns filed after February 28, 2000, but before July 1, 2002, and IRM 4.10.20.3.2.3, Returns filed on or after July 1, 2002.


**34.6.3.6.1.1** **(02-01-2011)**

##### Procedures for Requesting Audit or Tax Accrual Workpapers

1. **Information Document Requests (IDRs)**. Upon determining that a request for audit or tax accrual workpapers should be made, an examiner will prepare an IDR for the workpapers. The examiner should work with Field Counsel in preparing the IDR. The Office of the Associate Chief Counsel (Procedure & Administration) is also available to provide assistance to Field Counsel on IDRs. Coordination with Counsel will be treated as a high priority matter by Counsel so as not to delay the examination.



1. For a request under the unusual circumstances standard (see IRM 4.10.20.3.1, _Unusual Circumstances Standard_, http://publish.no.irs.gov/getpdf.cgi?catnum=38775, Unusual Circumstances Standard), any National Office Counsel review through the Office of the Associate Chief Counsel (Procedure & Administration) will, in general, be completed no later than fourteen days after coordination with P&A is initiated.

2. For a request involving a listed transaction, any National Office Counsel review through P&A will, in general, be completed no later than seven days after coordination with P&A occurs. Sample IDR language for requests involving listed transactions is available to the examiner at the Office of Tax Shelter Analysis (OTSA) Website http://lmsb.irs.gov/hq/pftg/otsa/index.asp.


2. Any IDR for audit or tax accrual workpapers should request that, in the event a taxpayer or third party does not produce a document requested by the IDR, the taxpayer or third party should provide the examiner with a description of the document being withheld, including the number of pages contained in the document, and the specific reason why the document is not being provided in response to the IDR. If a document is not produced based on a claim of privilege, the taxpayer or third party should provide the examiner with a detailed privilege log. However, if the taxpayer or a third party served with an IDR fails to provide (or unreasonably delays providing) the requested description of documents being withheld or the requested detailed privilege log for any privilege being claimed, the examiner should promptly issue an appropriate summons, as described in _CCDM 34.6.3.6.1.2_, Issuance of Summonses, requesting all withheld workpapers.

3. **Review or Approval**. Before an IDR for these workpapers is issued, review or approval must occur.



1. _Requests under the Unusual Circumstances Standard_. In LB&I cases, approval to issue an IDR under the unusual circumstances standard must be obtained from the Director Field Specialists, LB&I. In SB/SE cases, approval for such requests must be obtained from the Area Compliance Director, with the concurrence of the Director of Compliance Policy, SB/SE. In TEGE cases, approval for such requests must be obtained from the Director, EO Examinations; the Director, EP Examinations; or the Director, Government Entities.

2. _Requests Involving Listed Transactions_. The Team Manager in LB&I cases, Group Manager in SB/SE cases, or \[TBA\] in TEGE cases, must review any IDR requesting tax accrual workpapers involving listed transactions.


**34.6.3.6.1.2** **(02-01-2011)**

##### Issuance of Summonses

1. If a taxpayer or third party does not produce audit or tax accrual workpapers in response to an IDR, the examiner must determine whether to issue a summons. The standards and procedures will differ depending upon whether the request for workpapers was made under the unusual circumstances standard (see IRM 4.10.20.3.1, _Unusual Circumstances Standard_, IRM 4.10.20.3.1) or involved a listed transaction.

2. **Audit or Tax Accrual Workpapers under the Unusual Circumstances Standard**.



1. In cases not involving listed transactions, the examiner should make the decision whether to issue a summons based on all the facts and circumstances surrounding the case. If the examiner decides to issue a summons to secure audit or tax accrual workpapers under the unusual circumstances standard, the examiner should ensure that the burden of compliance with the summons will not be unreasonably onerous. The summons should provide a specific and unambiguous description of the records demanded so that the summoned party can reasonably be expected to identify the exact records sought. The summons should also identify the particular taxpayer for which the documents are sought, the period covered, and the nature of the documents. Unless the examiner determines that all of the workpapers are material and relevant, the summons should identify and request only those documents relating to the specific matters under consideration. Finally, the summons should specify whether it seeks audit or tax accrual workpapers, or both.

2. Approval. In LB&I cases, prior approval for the issuance of summonses for audit or tax accrual workpapers must be obtained from the Director, Field Specialists, LB&I. In SB/SE cases, prior approval for the issuance of such summonses must be obtained from the Area Compliance Director, with the concurrence of the Director of Compliance Policy, SB/SE. In TEGE cases, approval for such requests must be obtained from the Director, EO Examinations; the Director, EP Examinations; or the Director, Government Entities.

3. Prior to issuance, a summons for audit or tax accrual workpapers will be submitted to Field Counsel for review and comment, accompanied by a statement of applicable facts and circumstances. Field Counsel will coordinate review of the proposed summons with the Associate Chief Counsel (Procedure and Administration) and through the appropriate Division Counsel. Coordination with Counsel will be treated as a high priority matter by Counsel so as not to delay the examination. National Office Counsel review of the summons will, in general, be completed no later than fourteen days after coordination with P&A occurs.

4. Counsel will review the summons to ensure that the summons is appropriately drafted and meets all legal requirements. The summons should be directed to the taxpayer, the taxpayer’s accountant, the independent auditor, or all three, based on a determination as to the location of the workpapers.


3. **Tax Accrual Workpapers Involving Listed Transactions**. In cases involving listed transactions, the examiner must prepare a summons for workpapers that are not produced in response to an IDR.



1. When the examiner prepares a summons for the workpapers, a statement of the facts and circumstances should also be prepared. The records sought must be described with reasonable certainty. The requirement of reasonable certainty will be satisfied if the description of the records is specific and unambiguous and the summoned party can reasonably be expected to identify the exact records sought. The summons must identify the particular taxpayer for which the documents are sought, the period the documents cover, and the nature of the documents.

2. Executive Review. In LB&I cases, pre-issuance review of summonses for tax accrual workpapers must be obtained from the Director Field Specialists, LB&I. In SB/SE cases, pre-issuance review of such summonses must be obtained from the Area Compliance Director, with the concurrence of the Director of Compliance Policy, SB/SE. In TEGE cases, pre-issuance review of summonses for tax accrual workpapers must be obtained from the Director, EO Examinations; the Director, EP Examinations; or the Director, Government Entities.

3. The examiner will work with Field Counsel to prepare the summons. Field Counsel will coordinate review of the summons through the appropriate Division Counsel and the Associate Chief Counsel (Procedure & Administration). Coordination with Counsel will be treated as a high priority matter by Counsel so as not to delay the examination. Any National Office Counsel review of the summons will, in general, be completed no later than seven days after coordination with P&A is initiated.

4. Counsel will review the summons to ensure that the summons is appropriately drafted and meets all legal requirements. The summons should be directed to the taxpayer, the taxpayer’s accountant, the independent auditor, or all three, based on a determination as to the location of the tax accrual workpapers.


**34.6.3.6.1.3** **(02-01-2011)**

##### Enforcement of Summonses

1. If the summoned party does not comply with the summons, the examiner will refer the matter to Counsel for enforcement of the summons: following consultation with the Director Field Specialists, LB&I, for LB&I cases; for SB/SE cases, following consultation with the Area Compliance Director, with the concurrence of the Director of Compliance Policy, SB/SE; or for TEGE cases, following consultation with the Director, EO Examinations, the Director, EP Examinations, or the Director, Government Entities.



1. For summonses involving listed transactions and requests for tax accrual workpapers, the summons enforcement letter will be approved by the Deputy Chief Counsel (Operations) after coordination with, and pre-review by, the responsible Division Counsel and the Associate Chief Counsel (Procedure & Administration).

2. For all other summonses seeking tax accrual or other audit workpapers, any summons enforcement letter must be coordinated with, and pre-reviewed by, the responsible Division Counsel and the Associate Chief Counsel (Procedure & Administration).


**34.6.3.6.2** **(02-01-2011)**

#### Summonses Issued to Obtain Computer Software and Documentation

1. In order to effectively audit returns and to examine tax credits when taxpayers use software programs, the Service may summon the following data (in addition to other potential information): an executable copy of the software; the source code, including data-based descriptions, record layouts, and descriptions of physical file formats; and the underlying manuals and documentation to the software and to the source code.

2. IRC 7612 prohibits the issuance of a summons for computer source code unless certain conditions enumerated in that section are satisfied, and requires that the Service take certain precautions whenever it comes into possession of any computer software or related materials.

3. Requests for this information should be made as early in the audit as possible and as soon as the agents determine they will need to examine this information.

4. Any such proposed summons must be submitted to the appropriate Field Counsel for pre-issuance review. Field Counsel may seek assistance from the Chief, Branch 3 (Collection, Bankruptcy & Summonses) in drafting the summons.

5. **Enforcement**. In the event that the Service requests civil enforcement of any summons issued pursuant to this procedure, the appropriate Field Counsel office will review the request and, if enforcement is appropriate, the Field Counsel office will prepare a letter to the Tax Division requesting and authorizing a suit for enforcement of the summons. The Field Counsel office will forward the enforcement letter to Procedure & Administration for review prior to transmission to the Tax Division.

6. **Proceeding to Quash**. If the Service must defend against a proceeding to quash a summons issued pursuant to this procedure, the defense letter will be prepared by the appropriate field office, and then forwarded to Procedure & Administration for review prior to transmission to the Tax Division.


**34.6.3.6.3** **(08-11-2004)**

#### Actions to Obtain Approval for Dispensing with the Notice Requirements

1. In general when a summons is issued to a third party, the Service is required to issue a notice to the taxpayer or other person who is identified in the description of records sought. IRC 7609(g) provides a limited exception where the Service can dispense with the giving of notice. To dispense with notice under IRC 7609(a) and (b), the United States district court for the district within which the person summoned resides or is found must enter an order, on the basis of the facts and circumstances alleged, that there is reasonable cause to believe the giving of notice may lead to attempts to conceal, destroy, or alter records relevant to the examination, to prevent the communication of information from other persons through intimidation, bribery, or collusion, or to flee to avoid prosecution, testifying, or production of records. IRC 7609(g). The determination by the court will be _ex parte_ and solely upon petition and supporting affidavits.

2. If the Area Director’s office requests that Field Counsel obtain a court order to allow the notice requirements to be dispensed with, Field Counsel will review the request to determine if the facts and circumstances indicate that the required showing can be made. If approved, Field Counsel will prepare a letter to the U.S. Attorney containing the law and sufficient facts justifying court approval. The distribution of the letter should be as specified in _CCDM 34.6.3.3.1_.


**34.6.3.6.4** **(02-01-2011)**

#### Criminal Investigation Summonses — Protest Procedures

1. If the Field Counsel contemplates disapproving a request for civil enforcement of any summons issued by Criminal Investigation, an informal conference may be arranged between the Special Agent in Charge and Field Counsel for the purpose of clarifying the available evidence or for discussing the merits of the proposed legal action.

2. If Field Counsel still disapproves or no agreement is reached, a memorandum will be transmitted to the Special Agent in Charge setting forth the reasons for concluding that legal action should not be instituted. A copy should also be sent to the Director, Field Operations.

3. Upon receipt of Field Counsel’s memorandum, the Special Agent in Charge may choose to prepare a report setting forth his or her views. The Special Agent in Charge’s memorandum will be forwarded to the Director, Field Operations within ten working days of reviewing Field Counsel’s memorandum. A copy of the memorandum will be forwarded to Field Counsel.

4. Within 30 days of receipt of the memorandum, the Director, Field Operations, may inform Field Counsel in writing of his or her disagreement. A copy of the Special Agent in Charge’s report should be forwarded with the Director, Field Operations’ memorandum.

5. In the event of disagreement between the Director, Field Operations, and Field Counsel, the Director, Field Operations may refer the matter to the Chief, Criminal Investigation. If the Chief agrees with the Director, he or she should discuss the matter with the Area Counsel in an attempt to resolve the differences. If they do not reach an agreement, the Chief may submit a memorandum report to the Associate Chief Counsel (Procedure & Administration) requesting that the Office of Chief Counsel consider the case. One copy of the memorandum report will be forwarded to Area Counsel and one copy will be forwarded to the Special Agent in Charge. The Associate Chief Counsel (Procedure & Administration) will make the final decision.


**34.6.3.6.5** **(08-11-2004)**

#### Summonses Issued During Collateral Investigations

1. The Field Counsel office servicing the Area Director where requests for a collateral investigation originate will process all requests for summons enforcement. A copy of the summons enforcement request will be sent to the Field Counsel in the jurisdiction where the summons enforcement action is to be instituted. That Field Counsel will coordinate the matter to the extent necessary. Thus, when the Area Director, Area 1, sends a collateral request for summons issuance to the Area Director, Area 2, the Field Counsel for Area 1 will process the summons enforcement request. At the time the Field Counsel office for Area 1, forwards a request for summons enforcement, it will forward a copy of the summons enforcement request to the Field Counsel in Area 2 who will provide any necessary coordination with the U.S. Attorney’s Office in Area 2.


**34.6.3.6.6** **(02-01-2011)**

#### Tax Treaty and TIEA Summonses

1. Summonses may be issued pursuant to exchange of information requests from tax treaty partners of the United States even if the United States has no tax interest and no claim for U.S. taxes are potentially due and owing. _United States v. Burbank & Company, Ltd._, 525 F. 2d 9 (2d Cir. 1975), _rev’g in part and aff’g in part_, 74-2 U.S.T.C. ¶ 9779 (S.D.N.Y. 1974), _cert. denied_, 425 U.S. 934 (1976). In order to be enforced, these tax treaty summonses need to comply with the good faith requirements of _United States v. Powell_, 379 U.S. 48 (1964), and other statutory requirements for summonses such as the notice requirements for third-party record-keeper summonses in IRC 7609(a). _United States v. Stuart_, 489 U.S. 353 (1989), citing _Powell_, 379 U.S. at 57-58. Summonses may also be issued pursuant to exchange of information requests from countries with which the United States has entered into a tax information exchange agreement (TIEA). _Zarate Barquero v. United States_, 18 F.3d 1311 (5th Cir. 1994). In view of the complexity of the questions involved, it is believed that tax treaty and TIEA summonses will require special treatment. Therefore, Branch 7, Office of the Associate Chief Counsel (International), in conjunction with Procedure & Administration, has worked out special procedures for the processing of exchange of information requests, and when necessary to secure the requested information through issuance and service of summonses by agents in field offices.

2. **Preparation**. Upon receiving a request from a treaty or TIEA partner (foreign country), the Deputy Commissioner (International) (LB&I) or his/her delegate will make a determination as to whether the request falls within the exchange of information provisions of the tax treaty or tax information exchange agreement with that country.



1. If the request is determined to be proper under the terms of that treaty or TIEA, the concerned Tax Attaché, or a program analyst of the Exchange of Information Team (in the Office of Deputy Commissioner (International) (LB&I)), will initially request the appropriate Area Director’s office to attempt to secure the information requested without the use of an administrative summons.

2. If, however, the person refuses to voluntarily supply the information requested, the Tax Attaché or the Exchange of Information Team prepares a summons. The proposed summons shall be reviewed by Branch 7, Associate Chief Counsel (International), before it is served. If the summons is approved for issuance by Branch 7, Associate Chief Counsel (International), a memorandum will be sent to the Tax Attaché or the Exchange of Information Team, as the case may be, notifying them of this fact, and indicating any changes that should be made to the summons. The summons, along with a copy of the review memorandum, will be sent by the Tax Attaché or the Exchange of Information Team to the appropriate Area Director’s office for service on the summoned party.

3. The Office of Associate Chief Counsel (International) may from time to time determine that certain types of routine treaty summonses will not require review by Branch 7. Upon doing so, it will advise the Office of Deputy Commissioner (International) (LB&I) describing the type of summonses affected, and it will specify instructions regarding the processing of such cases in the event of a petition to quash or enforcement proceeding.


3. **Enforcement**. If after issuance, it becomes necessary to seek judicial enforcement of a tax treaty or TIEA summons, the letter to the Tax Division, requesting and authorizing a suit to enforce the summons, will be prepared by the Field Counsel office for the area in which the summons was served. The Field Counsel office will forward the enforcement letter to Branch 7, Associate Chief Counsel (International), which will review the letter and coordinate the case as necessary with Procedure & Administration, prior to transmission to the Tax Division.

4. **Proceeding to Quash**. If a party brings a proceeding to quash a tax treaty or TIEA summons, the defense letter will be prepared by the Field Counsel’s office for the area in which the summons was served. The defense letter will be forwarded to Branch 7, Office of the Associate Chief Counsel (International), for review, and coordination as necessary with Procedure & Administration, prior to transmission to the Tax Division.

5. Field Counsel shall obtain such statements or declarations from area offices needed in connection with enforcement or quash proceedings. All matters concerning the incoming request from the treaty or TIEA country shall be coordinated with Branch 7, Associate Chief Counsel (International), and that office will advise the Office of Deputy Commissioner (International) (LB&I) in the preparation of any documents that may be requested of that office in conjunction with such proceedings.


**34.6.3.6.7** **(02-01-2011)**

#### Administrative Requests for Grants of Statutory Use Immunity

1. The procedures for processing requests for grants of statutory use immunity under 18 U.S.C. 6001 §§ _et seq._ are set forth in IRM 9.6.1.3. Field Counsel attorneys should familiarize themselves with these procedures for handling act of production immunity requests. Under these procedures, Field Counsel is directly involved in the drafting of the summons and in the agency proceeding and review of the documents produced pursuant to the limited grant of immunity. Enforcement letters relating to witnesses who fail to comply with act of production immunity orders are to be forwarded to Procedure & Administration for review. These letters will be coordinated with the Criminal Tax Division.


**34.6.3.7** **(02-01-2011)**

### Issuance of Summons for Books and Records Abroad

1. **Background**. Summonses may be issued to persons or entities in the United States who have control over books and records located abroad. Examples of "control" of records abroad would include interlocking board of directors, corporate officers holding positions with each corporation, or direct or indirect ownership. _See United States v. Toyota Motor Corporation_, 569 F. Supp. 1158 (C.D. Cal. 1983) (enforcement of summons provisions not barred by principles of international law); _In re Grand Jury Proceedings Bank of Nova Scotia_, 740 F.2d 817 (11th Cir. 1984), _cert. denied_, 469 U.S. 1106 (1985) (Grand Jury subpoena to a branch of a foreign bank for records located in foreign countries is enforceable, even if disclosure of bank records is a criminal offense under the laws of those countries); _United States v. Vetco_, 644 F.2d 1324 (9th Cir. 1981), _cert. denied_, 454 U.S. 1098 (1981) (Service was successful in obtaining enforcement of and sanctions for noncompliance with a summons for corporate records held in a Swiss subsidiary). The summoned party may allege that compliance with the summons will violate the law of the country where the books and records are located. In that case, the court will balance the competing interests of the two countries. _Restatement (Third) of the Foreign Relations Law of the United States_, 442(1)(c).

2. **Summons Preparation**. Any such proposed summonses will be submitted by the Service to the appropriate Field Counsel office for pre-issuance review as described in _CCDM 34.6.3.1_ above. The Field Counsel office, within two days of the receipt of the request, will consult with Procedure & Administration by telephone, and fax a copy of the proposed summons and any accompanying documents to that office if necessary. Procedure & Administration will coordinate with Branch 1 of the Office of the Associate Chief Counsel (International), complete its review as quickly as possible, and advise the Field Counsel office on the feasibility of issuance and enforcement of the proposed summons. The Field Counsel office, in turn, will provide the requesting office with its views on the proposed summons.

3. In the past, foreign banks have taken the position that records may not be released without the taxpayer’s consent. Such consent may be provided by the taxpayer executing a consent directive authorizing the bank to produce the records on his behalf. While a summons issued under IRC 7602 may not be used to compel the taxpayer to execute a consent directive, the desired result may be effected by issuing a summons to the taxpayer requesting production of the records sought in the bank summons. While not in his possession, the taxpayer has custody and control of the records and can be ordered to comply with the summons by either producing the books and records himself, or by signing a consent directive authorizing the bank to produce the records on his behalf.

4. **Enforcement**. In the event that the Service requests civil enforcement of any summons issued pursuant to this procedure, the appropriate Field Counsel office will review the request and if enforcement is appropriate, the Field Counsel office will prepare a letter to the Tax Division requesting and authorizing a suit for enforcement of the summons. The Field Counsel office will forward the enforcement letter to Procedure & Administration which will review the letter and coordinate the case as necessary with International, Branch 1, prior to transmission to the Tax Division.

5. **Proceeding to Quash**. If the Service must defend against a proceeding to quash a summons issued pursuant to this procedure, the defense letter will be prepared by the appropriate Field Counsel office, and then forwarded to Procedure & Administration which will, in turn, review the letter and coordinate the case as necessary with International prior to transmission to the Tax Division.

6. The above provisions do not apply to summonses for foreign documents within the scope of IRC 6038A, Information with Respect to Certain Foreign-Owned Corporations, nor does it apply to formal document requests within the scope of IRC 982, Admissibility of Documentation Maintained in Foreign Countries. The Office of the Associate Chief Counsel (International) will continue to handle those matters.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part34/irm_34-006-003#addtoany "Show all")

A2A