---
url: "https://www.irs.gov/irm/part32/irm_32-002-007"
title: "32.2.7 Formal Clearance of Publication Items | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part32/irm_32-002-007#main-content)

- 32.2.7 [Formal Clearance of Publication Items](https://www.irs.gov/irm/part32/irm_32-002-007#idm140236052035392)
  - 32.2.7.1 [General Information about the Clearance Process](https://www.irs.gov/irm/part32/irm_32-002-007#idm140236052074032)
  - 32.2.7.2 [Assembly of the Clearance Package](https://www.irs.gov/irm/part32/irm_32-002-007#idm140236020800496)

    - 32.2.7.2.1 [Dissenting Opinions](https://www.irs.gov/irm/part32/irm_32-002-007#idm140236012089536)
    - 32.2.7.2.2 [Companion Cases](https://www.irs.gov/irm/part32/irm_32-002-007#idm140236023274448)
    - 32.2.7.2.3 [Concurrent Publication and Issuance](https://www.irs.gov/irm/part32/irm_32-002-007#idm140236012031280)
    - 32.2.7.2.4 [Reversal of Position](https://www.irs.gov/irm/part32/irm_32-002-007#idm140236019340816)

  - 32.2.7.3 [Chain of Clearance](https://www.irs.gov/irm/part32/irm_32-002-007#idm140236018757888)
  - 32.2.7.4 [Record of Clearance on BIN](https://www.irs.gov/irm/part32/irm_32-002-007#idm140236009069920)
  - 32.2.7.5 [Associate Chief Counsel Clearance](https://www.irs.gov/irm/part32/irm_32-002-007#idm140236051946000)
  - 32.2.7.6 [Chief Counsel Clearance](https://www.irs.gov/irm/part32/irm_32-002-007#idm140236017259792)
  - 32.2.7.7 [Commissioner Clearance](https://www.irs.gov/irm/part32/irm_32-002-007#idm140236018430080)
  - 32.2.7.8 [Clearance by Treasury](https://www.irs.gov/irm/part32/irm_32-002-007#idm140236005920752)
  - Exhibit 32.2.7-1 [Checklist for Preparing a Proposed Publication for Formal Review](https://www.irs.gov/irm/part32/irm_32-002-007#idm140236020662976)

# Part 32. Published Guidance and Other Guidance to Taxpayers

# Chapter 2. Chief Counsel Publication Handbook

# Section 7. Formal Clearance of Publication Items

* * *

## 32.2.7 Formal Clearance of Publication Items

#### Manual Transmittal

October 21, 2011

#### Purpose

(1) This transmits revised CCDM 32.2.7, Chief Counsel Publication Handbook; Formal Clearance of Publication Items.

#### Background

CCDM 32.2.7., Formal Clearance of Publication Items is being revised to remove references to the expedited published guidance program and to reflect current office structure.

#### Material Changes

(1) CCDM 32.2.7.3(2) was removed because these problems are now obsolete.

(2) CCDM 32.2.7.2 and Exhibit 32.2.7-1 were revised to reflect that items for publication are circulated for review in electronic form.

(3) Obsolete titles and office names were removed from CCDM 32.2.7.5 and CCDM 32.2.7.8.

(4) Exhibit 32.2.7-1 was made compliant with Section 508 of the Rehabilitation Act.

(5) References were updated and hyperlinked.

#### Effect on Other Documents

CCDM 32.2.7 dated August 11, 2004 is superseded.

#### Audience

Chief Counsel

#### Effective Date

(10-21-2011)

Deborah A. Butler

Associate Chief Counsel

(Procedure & Administration)

**32.2.7.1** **(08-11-2004)**

### General Information about the Clearance Process

1. The rules contained in this subsection apply to all Division Counsel/Associate Chief Counsel offices. Differences in organizational structure, however, may require additional levels of clearance that do not apply to all offices.


**32.2.7.2** **(10-21-2011)**

### Assembly of the Clearance Package

1. When preparing a proposed publication for formal clearance, the drafting attorney and the assigned reviewer are responsible for ensuring that the appropriate forms have been completed and the necessary components of a publication are present; making sure that the spelling, grammar, punctuation, pagination, photocopying, and assembly of the clearance package are accurate; that the legal research, research statement, cross-references, and citations are accurate and current; and ensuring that the proposed publication reflects the changes recommended during circulation.

2. See Exhibit 32.2.7-1 for a check list to assist in the preparation of a proposed publication for formal clearance. Proposed publication items are assembled using Document 6712, Office of Chief Counsel Executive Correspondence (Orange Folder).

3. Clearance packages are assembled top-to-bottom for each level of clearance, as follows:



   - A routing or transmittal slip (transmittal document), addressed to the Associate Chief Counsel (on the cover of the orange folder)

   - Updated Executive Summary (inside orange folder on left hand side) (see CCDM 32.2.6.5, Executive Summary)

   - BIN (inside orange folder on right hand side)

   - Proposed publication (behind BIN)


4. Additional material may be attached to the proposed publication item. The attachments, however, should be limited to that likely to be particularly helpful to reviewers. The material should be listed on the last page of the BIN as attachments. List each item separately rather than as a group of attachments with a term such as "court opinions" or "legislative history." There must be attached a copy of any material that is essential to a clear understanding of the proposed publication such as:



   - Legal Memo;

   - Any publication affected by the new publication or that is an important part of the rationale;

   - Any court opinion (pertinent portions only, e.g., front page and relevant portion of facts, rationale, and holding) that is an important part of the rationale or that is the subject of the proposed publication, or that relate to a significant contrary argument. If the message of the publication is that the Service will or will not follow the opinion of the court in that case, include any relevant Action on Decision (AOD);

   - Any tax form that is germane to an understanding of the proposed publication;

   - Any news item or law review article that caused the project to be established;

   - Any proposed publication that is cited as authority in the new publication and BIN, if it is necessary to a clear understanding of the proposed publication. When a proposed publication is referred to in the BIN, it must be identified by name and CASE-MIS number. Write at the bottom of the first page of this attached item: "As of (date) when forwarded for or when cleared at (clearance level)" ;

   - Any nontax statute essential to an understanding of the proposed publication unless the statute is quoted or paraphrased in the publication;

   - Any coordination memorandum;

   - Any "suspend" or "comment" memorandum from Treasury;

   - Pertinent memoranda from Treasury, or other memoranda from the Commissioner, Chief Counsel, or Associate Chief Counsel, or Division Counsel;

   - Coordination memoranda containing unresolved substantive comments; or

   - Any other information deemed useful to a reviewer.


5. When requested, include behind a background tab, a "red-lined strike-out" copy comparing the clearance version of the item with the circulation version showing where additions and deletions have been made as a result of comments received on circulation. In addition, when requested, include copies of the comments received on circulation.

6. When appropriate, also include a "red-lined strike-out" copy comparing the current version of the proposed publication item to the existing publication that the proposed item is revising.

7. To facilitate moving the publication package, include a draft transmittal document to the Chief Counsel and the Deputy Chief Counsel (Operations) or Deputy Chief Counsel (Technical), as appropriate, from the Associate Chief Counsel. See CCDM 32.2.7.6(2) for the content of this transmittal document.

8. When the orange folder is delivered to the reviewer, send the reviewer an email containing electronic copies of the clearance package documents in the orange folder. The email should contain the proposed publication item, the BIN, the legal memo (if there is one), the executive summary, and the draft transmittal document to the Chief Counsel. Any person who makes changes to the electronic copies of the proposed publication item or the BIN should email the changes to the drafting attorney or provide the drafting attorney with a marked-up paper copy reflecting the changes. The marked-up copy reflecting the changes should be returned to the drafting attorney to ensure that the drafting attorney is aware of the changes to the clearance package documents. The drafting attorney should keep all changes made to the proposed publication item or the BIN in the background file and should reflect on the marked-up copy the name of the person making the changes and the date of the change.


**32.2.7.2.1** **(08-11-2004)**

#### Dissenting Opinions

1. Neither the drafting attorney nor any reviewer is required to approve a proposed publication with which the person disagrees. If the drafting attorney or reviewer disagrees with the proposed publication, the dissenting person should place an asterisk beside the person’s name on page 1 of the BIN leading to a footnote stating, "Do not agree. See dissent of (insert date)" and place a dissenting memorandum in the clearance package.

2. Dissenting memoranda are not to be prepared indiscriminately because of minor changes in language or composition. A dissenting memorandum should not be prepared when the position of the Service has been clearly established by revenue rulings or by acquiescence in or other agreements to follow court opinions if nothing has occurred to cast doubt on the validity of that position. Dissenting memoranda may be prepared with regard to:



   - A position not previously established by publication or otherwise, if reasonable persons may disagree

   - An established position, if subsequent events can reasonably be understood to undermine that position


3. Because contra arguments must be noted in the BIN, any memorandum dissenting from a position in a proposed publication, whether written in connection with it by the drafting attorney or assigned reviewer, must initially be included in the clearance package. The Associate Chief Counsel will decide whether to retain the dissenting memorandum as part of the clearance package to be sent forward to higher levels of clearance. Whether or not the dissenting memorandum is retained, the asterisk and footnote described in CCDM 32.2.7.2.1(1) may not be deleted without the concurrence of the author of the dissenting memorandum.


**32.2.7.2.2** **(08-11-2004)**

#### Companion Cases

1. The text of a proposed publication may refer to another proposed publication that is in process if the two are to be published simultaneously. In these cases, the written reference in the proposed publication item to the companion publication is to "Rev. Rul. \[insert number\] page , this Bulletin." Companion proposed publications generally are submitted together for all levels of clearance.


**32.2.7.2.3** **(10-21-2011)**

#### Concurrent Publication and Issuance

1. A proposed publication may be based on a pending letter ruling request or technical advice. See CCDM 32.3.2, Letter Rulings, and CCDM 33.2.1, Issuing Technical Advice Memorandum and Technical Expedited Advice Memoranda. In these cases, the drafting attorney of the proposed publication must make certain that when the revenue ruling or revenue procedure has been assigned a number in the IRB, notice of the imminent publication of the matter is given to the appropriate person in the branch in which the letter ruling request or technical advice is pending, together with a copy of the revenue ruling or revenue procedure submitted by the branch to the Bulletin Unit for publication. The copy should be noted to show the number assigned and the number and date of the IRB in which it will be published.



### Note:



Generally, the publication will originate in the branch to which the underlying letter ruling request or technical advice is assigned.

2. Generally, issuance of the underlying letter ruling or technical advice is not delayed pending publication of the item in the IRB or an early drop. In rare circumstances, however, it may be advisable to delay the issuance of the letter ruling or technical advice until after the publication item is available to the public or to consider not ruling on the letter ruling request. These circumstances could include situations where the issuance of the letter ruling or technical advice prior to publication would give a competitive advantage to a taxpayer or the pending publication will reverse a published position. If the Associate office determines that the letter ruling or technical advice should be delayed, then care must be taken to ensure that the publication is published in the IRB or released using the early drop procedures prior to issuing the letter ruling or technical advice.


**32.2.7.2.4** **(08-11-2004)**

#### Reversal of Position

1. The BIN must state whether the proposed revenue ruling or revenue procedure is consistent with any underlying document such as a letter ruling or a technical advice. See CCDM 32.2.4.2.1.4, Consistency with Underlying Document. If the position stated in the underlying document is being reversed or changed in the proposed revenue ruling or revenue procedure, the BIN should include a statement concerning whether the taxpayer or appropriate Service official will be advised of the change and, if not, the reason for not doing so should be specified.

2. When in the clearance of a proposed revenue ruling or proposed revenue procedure it appears that a holding in the underlying document will not be followed, the branch that issued the underlying document, if different from the branch originating the proposed publication, should be given appropriate and timely notification when the issue is settled by publication to allow that branch to take appropriate action. Appropriate action could include:



1. Informing the recipient of the letter ruling or technical advice that the holding is being reconsidered and that further reliance on the letter or memorandum is not justified,

2. Waiting to inform the recipient of the underlying document of the reconsideration until a final decision to accept the position of the proposed publication has been made, or

3. Suspending action on similar requests pending the final approval of the position in the proposed publication.


3. The decision whether to suspend action on similar requests or to notify the recipient of the underlying letter ruling or technical advice that the issue is being reconsidered is made by the Associate Chief Counsel after discussion with the chief of the branch or a representative of that office.

4. If a holding or position in the underlying communication is reversed or changed by a revenue ruling or revenue procedure based on it, the addressee of the communication is notified of the change concurrently with publication of the revenue ruling or revenue procedure.


**32.2.7.3** **(10-21-2011)**

### Chain of Clearance

1. All proposed publications are cleared by the Associate Chief Counsel. Proposed publications (except "ministerial publications" ) are also referred to the Chief Counsel, the Commissioner, and Treasury for clearance. See CCDM 32.2.8.5, Ministerial Publication Procedures, "Waiver of Clearance" , for further information on ministerial publication items.


**32.2.7.4** **(08-11-2004)**

### Record of Clearance on BIN

1. The BIN is the sole clearance document for proposed publication items. At each level of clearance during the formal clearance of a proposed publication, the approving office will sign the appropriate line on page 1 of the BIN. Signatures (or other documentation of approval as discussed in CCDM 32.2.7.7 and CCDM 32.2.7.8) must be obtained before submitting the publication item to the next level of clearance. The dates to be shown for each approval are the "date submitted" and the "date cleared."


**32.2.7.5** **(10-21-2011)**

### Associate Chief Counsel Clearance

1. After the general circulation comment period has closed, the drafting attorney makes any necessary revisions as discussed in CCDM 32.2.5, Coordination and Clearance. After the assigned reviewer approves the revised publication item and the assembled package for formal clearance, the clearance package is submitted to the assigned reviewer in the Associate office. After the reviewer in the Associate office approves, the proposed publication is submitted to the Associate Chief Counsel for approval.


**32.2.7.6** **(08-11-2004)**

### Chief Counsel Clearance

1. After approval by the Associate Chief Counsel, the Associate Office submits the publication to the Chief Counsel or delegate for approval.

2. A transmittal document is used to forward the clearance package to the Chief Counsel for approval. The transmittal document addressed to the Chief Counsel explains that the publication has been coordinated with Treasury and the Service (if applicable), approved by the Associate Chief Counsel, and is being submitted for approval of the Chief Counsel. The transmittal document also provides the name and telephone number of the contact person to be notified when the Chief Counsel has taken action on the matter.

3. The Chief Counsel (including the Deputy Chief Counsels) may request a briefing or may make changes to the proposed publication item. If the Chief Counsel (or Deputy Chief Counsels) changes the proposed publication item but does not make the changes to an electronic version, the drafting attorney must retrieve the clearance package and make the changes. The drafting attorney MUST prepare a compare version to show the changes requested by the Chief Counsel (or Deputy Chief Counsels). The drafting attorney should use the options available in Microsoft Word (e.g., the "track changes" feature with changes in the text instead of the balloons to the side of the text) to produce a compare version (red-lined, strike-out) showing the changes. The drafting attorney MUST print the compare version using a color printer so that the red-lined changes are clearly detectable. This will assist the Chief Counsel (or Deputy Chief Counsels) to more quickly approve the package. The Associate offices will determine whether they will review the clearance package with the color compare version prior to resubmitting the package to the Chief Counsel.

4. The drafting attorney should provide the Assistant to the Commissioner and the assigned Treasury attorney with a courtesy copy via email when the clearance package goes to the Chief Counsel. Inform both parties in the email that the clearance package has moved to the Chief Counsel’s office.


**32.2.7.7** **(08-11-2004)**

### Commissioner Clearance

1. Although the Chief Counsel has the authority to approve a proposed publication for the Commissioner, it is customary to obtain separate approval from the Assistant to the Commissioner on behalf of the Commissioner. To submit a proposed publication for approval of the Commissioner, the drafting attorney can either attach the publication, related BIN, and Executive Summary to an email addressed to the Assistant to the Commissioner or provide the clearance package (with or without attachments), including the Executive Summary, to the Assistant to the Commissioner. The email, or the transmittal with the package, should inform the Assistant to the Commissioner of the offices within the Service that have cleared the publication and of the existence of any issues in the publication that might impact tax administration. The Assistant to the Commissioner will signal approval or disapproval of the publication either by return email to the individual who emailed the publication or by signing the BIN in the appropriate place. If approval is made by email, the email is to be printed out and attached to the BIN. A separate copy is also retained in the background file for the publication item.


**32.2.7.8** **(10-21-2011)**

### Clearance by Treasury

1. After receiving the approval of the Chief Counsel and the Commissioner, the Associate office sends the proposed publication to the appropriate office in Treasury. Generally, this is accomplished by emailing the documents to the assigned Treasury attorney.

2. Treasury responds by memorandum to the Associate Chief Counsel. This memorandum will state whether Treasury approves, approves with changes, recommends suspension, or has other comments.

3. No proposed publication is to be closed or published based on a telephone call from Treasury. Attorneys in Treasury, however, may call the drafting attorney or reviewer to discuss the proposed publication.

4. Treasury generally does not have a need for taxpayer specific information in order to review a proposed publication item. If Treasury personnel request taxpayer specific information, such as the administrative file (the Commissioner’s official file) from a particular taxpayer’s case (or excerpts from the file), the drafting attorney should discuss with the Treasury official the scope of the request and the extent to which taxpayer specific information can be redacted. The drafting attorney should consider coordinating with branch 6 or 7 of Procedure and Administration if there are any questions about the need to redact information from the file. For more information see CCDM 30.9.1.4.1, Administrative Files. Next, the drafting attorney of the publication must secure written approval of the Associate Chief Counsel to grant the request. Upon approval of the request, a copy of the administrative file (or excerpts therefrom) is transmitted to Treasury by memorandum prepared for the signature of the Associate Chief Counsel.

5. If the proposed publication is the subject of either (i) an approval memorandum with minor changes, (ii) a comment memorandum, or (iii) a suspend memorandum, as described below, the drafting attorney and reviewer should, at the direction of the Associate Chief Counsel, first review the memorandum and evaluate whether it agrees with the memorandum. After review, the branch consults with the Associate Chief Counsel. If the conclusion is to disagree with some or all of the points made in the memorandum, Treasury will be contacted as directed by the Associate Chief Counsel to see whether reconciliation can be reached.

6. A comment memorandum from Treasury states that the proposed publication reaches the correct result but requests that a significant revision in rationale, scope, or factual description be made. A suspend memorandum requests that the proposed publication not be issued at all, or at least should not be issued reaching the proposed result. Both of these memoranda can result in revisions so substantial that the proposed publication must go through the entire clearance process again.

7. If reconciliation is made with Treasury, and changes are made to the proposed publication, the Associate Chief Counsel must approve the revised publication item. The Associate Chief Counsel will determine whether the changes are important, substantive changes. If so, the Chief Counsel must also approve the revised publication item. If the Associate Chief Counsel determines that the publication item should be sent back to the Chief Counsel to be cleared again, the drafting attorney should prepare a color compare version of the publication item highlighting the important, substantive changes. See CCDM 32.2.7.6 for instructions for preparing a color compare version.

8. Treasury must furnish a formal approval memorandum before a project may be forwarded to Media Relations or the Bulletin Unit for early release or publication, respectively. In extraordinary circumstances, however, a publication may be forwarded to Media Relations for early release if the Tax Legislative Counsel, Benefits Tax Counsel, International Tax Counsel, or higher-level Treasury official sends an email approving the publication and expressly authorizing its early release. In those circumstances, Treasury must furnish a formal approval memorandum as soon thereafter as possible. The approval email and memorandum are included with the BIN and copies are retained in the background file for the publication item.


**Exhibit 32.2.7-1**

### Checklist for Preparing a Proposed Publication for Formal Review

| FORMAL REVIEW CHECKLIST |
| :-: |
| \_\_ | The CASE-MIS number is correct. |
| \_\_ | The Initiator and Branch Reviewer information is entered in the Records of Clearance on the BIN. CCDM 32.2.4.2(2) |
| \_\_ | All applicable coordination entries on the BIN are complete and correct. CCDM 32.2.5.2(7) |
| \_\_ | The Research Statement is updated and complete. CCDM 32.2.4.2.1.10 |
| \_\_ | The sequence of captioned items in the BIN is correct. CCDM 32.2.4.2.1 |
| \_\_ | The final publication package is assembled in proper order in an orange folder. CCDM 32.2.7.2(3) |
| \_\_ | Additional relevant materials attached at the end of the BIN are provided in the correct sequence and in good quality copy. CCDM 32.2.7.2(4) |
| \_\_ | Red-lined, strike-out copies are attached if requested. CCDM 32.2.7.2(5)-(6) |
| \_\_ | A draft transmittal to the Chief Counsel is included. CCDM 32.2.7.2(7) |
| \_\_ | An email containing the draft publication, the BIN, the legal memo (if there is one) and the draft transmittal to the Chief Counsel is sent to the reviewer. CCDM 32.2.7.2(8) |
| \_\_ | The BIN is signed and dated. CCDM 32.2.6.2 |
| \_\_ | The current draft date appears on page one of the publication. CCDM 32.2.3.3.2 |
| \_\_ | The number of copies is correct. |
| \_\_ | The early drop procedure has been followed where applicable. CCDM 32.2.8.4.2 |
| \_\_ | The Congressional review of rules procedures have been followed. CCDM 32.2.8.2 |

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part32/irm_32-002-007#addtoany "Show all")

A2A