---
url: "https://www.irs.gov/irm/part30/irm_30-004-005"
title: "30.4.5 Labor and Employee Relations | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part30/irm_30-004-005#main-content)

- 30.4.5 [Labor and Employee Relations](https://www.irs.gov/irm/part30/irm_30-004-005#idm140128546312304)
  - 30.4.5.1 [Labor and Employee Relations in the Office of Chief Counsel](https://www.irs.gov/irm/part30/irm_30-004-005#idm140128546318416)
  - 30.4.5.2 [Employee Conduct and Ethics](https://www.irs.gov/irm/part30/irm_30-004-005#idm140128576407200)

# Part 30. Administrative

# Chapter 4. Personnel Administration, Training, and Equal Employment Opportunity

# Section 5. Labor and Employee Relations

* * *

## 30.4.5 Labor and Employee Relations

**30.4.5.1** **(05-22-2006)**

### Labor and Employee Relations in the Office of Chief Counsel

1. This section provides information on employee conduct and ethics, disciplinary actions and adverse actions, agency grievance procedures, the collective bargaining agreement with NTEU, suits against Chief Counsel employees, and personal injury claims.


**30.4.5.2** **(05-22-2006)**

### Employee Conduct and Ethics

1. Reserved.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part30/irm_30-004-005#addtoany "Show all")

A2A