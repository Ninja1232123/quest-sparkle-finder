---
url: "https://www.irs.gov/irm/part35/irm_35-007-001"
title: "35.7.1 Filing Tax Court Briefs | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-007-001#main-content)

- 35.7.1 [Filing Tax Court Briefs](https://www.irs.gov/irm/part35/irm_35-007-001#idm140487056352992)
  - 35.7.1.1 [Regular Tax Cases](https://www.irs.gov/irm/part35/irm_35-007-001#idm140487056421744)
  - 35.7.1.2 [Small Tax Cases](https://www.irs.gov/irm/part35/irm_35-007-001#idm140487056419552)
  - 35.7.1.3 [Types of Briefs](https://www.irs.gov/irm/part35/irm_35-007-001#idm140487093646848)
    - 35.7.1.3.1 [Formal Briefs](https://www.irs.gov/irm/part35/irm_35-007-001#idm140487093645152)
      - 35.7.1.3.1.1 [Seriatim Briefs](https://www.irs.gov/irm/part35/irm_35-007-001#idm140487093642928)
      - 35.7.1.3.1.2 [Simultaneous Briefs](https://www.irs.gov/irm/part35/irm_35-007-001#idm140487093639504)
      - 35.7.1.3.1.3 [Surreply Briefs](https://www.irs.gov/irm/part35/irm_35-007-001#idm140487093570048)
    - 35.7.1.3.2 [Informal Briefs](https://www.irs.gov/irm/part35/irm_35-007-001#idm140487093567232)
    - 35.7.1.3.3 [Stand-Alone Proposed Findings of Fact](https://www.irs.gov/irm/part35/irm_35-007-001#idm140487093563120)
    - 35.7.1.3.4 [Memorandum Briefs](https://www.irs.gov/irm/part35/irm_35-007-001#idm140487093560720)
    - 35.7.1.3.5 [Answering Brief](https://www.irs.gov/irm/part35/irm_35-007-001#idm140487056347376)
      - 35.7.1.3.5.1 [Form and Contents](https://www.irs.gov/irm/part35/irm_35-007-001#idm140487056336992)
      - 35.7.1.3.5.2 [Discretionary Review](https://www.irs.gov/irm/part35/irm_35-007-001#idm140487056329696)
    - 35.7.1.3.6 [Supplementing Briefs](https://www.irs.gov/irm/part35/irm_35-007-001#idm140487056372832)
      - 35.7.1.3.6.1 [Necessity for Filing](https://www.irs.gov/irm/part35/irm_35-007-001#idm140487056368096)
      - 35.7.1.3.6.2 [Formal Type](https://www.irs.gov/irm/part35/irm_35-007-001#idm140487056364000)

# Part 35. Tax Court Litigation

# Chapter 7. Tax Court Briefs

# Section 1. Filing Tax Court Briefs

* * *

## 35.7.1 Filing Tax Court Briefs

#### Manual Transmittal

July 18, 2018

#### Purpose

(1) This transmits new CCDM 35.7.1, Tax Court Briefs, Filing Tax Court Briefs.

#### Background

CCDM 35.7.1 contains instructions for filing Tax Court briefs in S and regular Tax Court cases. CCDM 35.7.1.3.1 discusses the appropriate headings for formal briefs filed with the United States Tax Court.

#### Material Changes

(1) Section 35.7.1.3.1 is updated to reflect that when the Tax Court orders simultaneous original briefs, the proper heading for respondent’s simultaneous answering brief filed in response to petitioner’s simultaneous original brief is “Answering Brief for Respondent,” rather than “Reply Brief for Respondent.”

(2) The content of the original CCDM 35.7.1.3.1 is divided into CCDM 35.7.1.3.1.1, CCDM 35.7.1.3.1.2, and CCDM 35.7.1.3.1.3 to clarify the appropriate headings for seriatim briefs, simultaneous briefs, and surreply briefs, respectively.

(3) CCDM 35.7.1.3.5, 35.7.1.3.5.1, and 35.7.1.3.5.2 are revised to reflect that the proper heading for a brief in response to petitioner’s opening seriatim or simultaneous brief is an answering brief.

(4) CCDM 35.7.1.3.6 is revised to set forth new procedures for supplementing briefs after briefing has closed.

#### Effect on Other Documents

This section supersedes CCDM 35.7.1, dated 08-11-2004. This section incorporates Chief Counsel Notice 2018-009, Headings for Tax Court Briefs, dated July 10, 2018.

#### Audience

Chief Counsel

#### Effective Date

(07-18-2018)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**35.7.1.1** **(07-18-2018)**

### Regular Tax Cases

1. The general rule is that, except in cases processed under the Small Tax Case procedures, a brief is filed in each case submitted to the Tax Court. In some instances in which a case is tried and processed under regular procedures, the judge may specifically state that briefs are not desired. In these limited instances, the Field attorney should consider the issues, evidence, and other circumstances relating to the importance of the case and decide whether permission to file briefs should nevertheless be requested. If it is concluded not to request permission to file a brief, consideration should be given to either requesting permission to make an oral argument or to file a memorandum of authorities.


**35.7.1.2** **(08-11-2004)**

### Small Tax Cases

1. The filing of a brief, a memorandum brief, or a memorandum of authorities may be very important in an "S" case if the court has earlier denied respondent’s motion to remove small tax case designation. If the Tax Court declines permission to file briefs in any regular case and in any "S" case that the court refused to process under the regular procedure, and Field Counsel believes that briefs are necessary, Field Counsel should notify Division Counsel, who will determine whether additional action needs to be taken in the case.


**35.7.1.3** **(07-18-2018)**

### Types of Briefs

1. The Tax Court’s rules should be followed exactly in the preparation of briefs. _See_ T.C. Rule 151.


**35.7.1.3.1** **(07-18-2018)**

#### Formal Briefs

1. The Tax Court’s Rules provide for either seriatim (one after another) or simultaneous briefs. If seriatim (non-simultaneous) briefs are ordered, one party (usually the petitioner) files its “Opening Brief” first, the opposing party thereafter responds to the opening brief with an “Answering Brief,” and the first party thereafter responds to the answering brief with a “Reply Brief.”


**35.7.1.3.1.1** **(07-18-2018)**

##### Seriatim Briefs

1. When the court orders respondent’s brief to be filed first, respondent’s brief shall contain the heading, “Opening Brief for Respondent.”

2. When, under the order of the court, the petitioner files its seriatim opening brief first, then the respondent’s responding brief shall contain the heading, “Answering Brief for Respondent,” after which the petitioner will file a reply brief.

3. Respondent’s reply brief to petitioner’s answering brief shall contain the heading “Reply Brief for Respondent.”


**35.7.1.3.1.2** **(07-18-2018)**

##### Simultaneous Briefs

1. When simultaneous briefs are being filed by the parties, respondent’s brief shall contain the heading, “Opening Brief for Respondent.”

2. When the court orders simultaneous original briefs and respondent files a simultaneous answering brief to petitioner’s original brief, respondent’s brief shall contain the heading, “Answering Brief for Respondent.”



### Note:



A simultaneous responding brief should never be titled “Reply Brief for Respondent.” “Reply Briefs” are only filed when the court orders seriatim briefs. See Tax Court Rule 151(b)(1) & (2).


**35.7.1.3.1.3** **(07-18-2018)**

##### Surreply Briefs

1. Additionally, for both seriatim briefs and simultaneous briefs, a Surreply Brief may be filed, with permission of the court, when a party desires to respond to a reply brief (if seriatim briefs were filed), or to an answering brief (if simultaneous briefs were filed). Such a brief shall contain the heading, “Surreply Brief for Respondent.” The proposed Surreply Brief should be lodged together with the filing of a “Motion for Leave to File Surreply Brief” that states the reasons why the court should accept a surreply brief and whether there is any objection to the filing of the surreply brief.


**35.7.1.3.2** **(07-18-2018)**

#### Informal Briefs

1. If the court specifically indicates that a formal brief is not desired, a Memorandum of Authorities may be filed, with permission of the court. This document will rarely be ordered in regular cases and, in such cases, should be reviewed in the appropriate Associate offices if it involves issues that must be submitted to such offices for review. _See_ CCDM 35.7.3.2.

2. A memorandum of authorities should contain a brief recitation of the issues, respondent’s position, reference to the pertinent Code and Regulation sections, and a general discussion of the applicable law.

3. The memorandum of authorities should incorporate the facts established at the trial. The extent of discussion of the facts in a memorandum prepared prior to trial and submitted at trial will depend upon the nature of the case and the stipulation of facts.


**35.7.1.3.3** **(07-18-2018)**

#### Stand-Alone Proposed Findings of Fact

1. In some instances the court may request the parties to file proposed findings of fact as a stand-alone document. This document is headed, "Respondent’s Proposed Findings of Fact." It is rarely used, and when requested by the judge, it is preferable to include, in addition to the proposed findings of fact, the ultimate facts desired by the respondent and a Memorandum of Authorities on the issues involved.


**35.7.1.3.4** **(07-18-2018)**

#### Memorandum Briefs

1. A memorandum brief is headed Memorandum Brief for Respondent. It is used primarily in connection with motions and, in some instances, for cases tried under the "S" case procedures. A memorandum brief may be used as an accompaniment to, and in support of, a motion by respondent when it is necessary to enlarge upon the grounds for granting the motion beyond those set forth in the motion. It also may be used in opposition to a petitioner’s motion when it is advisable to inform the court in writing of the respondent’s position, either prior to the argument on a petitioner’s motion or at a hearing. Upon the completion of an oral argument on a motion, the court sometimes requests a memorandum brief on the legal points involved. The use of this type of brief in tried cases is unusual except for cases coming under the "S" case procedures.

2. The form of a memorandum brief depends upon the number of legal points discussed, its length, and the purpose for which it is prepared. If only a single legal issue is involved, the Contents page may be omitted. If few cases are cited, the Citations page may also be omitted. The Questions Presented page is generally omitted unless a number of issues are argued. The section for Respondent’s Request for Findings of Fact is omitted, and the pertinent facts are summarized in the beginning of the Argument on each issue. The Points Relied upon section is also usually omitted. The Preliminary Statement section is omitted, but the opening paragraphs of the brief should contain statements as to how the issues arose before the court and the reasons for filing the brief. A Conclusion is included as in a regular brief. There are no definite rules for its preparation. Before preparing a memorandum brief in a tried case, the attorney should discuss the matter with the reviewer in order to reach an understanding about the form and content of the brief.


**35.7.1.3.5** **(07-18-2018)**

#### Answering Brief

1. In the opinion of a number of the judges of the Tax Court, an answering brief considerably strengthens a party’s case. This factor should be borne in mind in the preparation of the brief. Because the answering brief addresses the arguments and contentions made by petitioner, the court is not left with any uncertainty as to the position of the respondent on any new phases of the case. No assumption can therefore be made by the court as to the abandonment by the respondent of any point in the case. Furthermore, if an argument is not fully and completely made in the original brief, such argument can, and should, be strengthened in the answering brief.

2. An answering brief will be filed by the respondent in virtually all cases. The attorney cannot assume that merely because respondent’s requested findings and arguments are contrary to or incompatible with petitioner’s requested findings and arguments, respondent’s original brief has answered the petitioner’s brief. The inconsistencies between petitioner’s and respondent’s requested findings and arguments should be specifically handled in the answering brief. The answering brief should also make clear to the court that respondent is not abandoning or conceding any issues. This can be done in two ways: by addressing each issue in the answering brief or by including a disclaimer. The disclaimer should state, for example, that failure to address issues covered in the opening brief does not constitute a concession or abandonment of those issues, that the answering brief is confined to matters not previously discussed or requiring clarification, and that the opening brief adequately covers the relevant factual and legal arguments for the issues not discussed.

3. While the general rule is that answering briefs should be filed in all cases in which simultaneous original briefs are filed by the parties, there are instances in which an answering brief is not necessary. These exceptions will be rare, and any doubt should be resolved by Field Counsel in favor of filing an answering brief. No specific guidelines can be laid down that will be applicable in all cases. An answering brief certainly should be filed in instances in which the parties are not in accord in their requested findings of fact. In this instance the court should be advised as to those requested findings of the petitioner with which we are in accord and as to those requested findings with which we are not in accord. The reasons for the disagreement should be stated. An answering brief should also be filed in instances in which petitioner’s arguments are based upon points, facts, statutory provisions, or case law that have not been fully and completely covered in respondent’s original brief. This is a troublesome area, and while respondent’s original brief may have included to some extent an argument dealt with more fully in petitioner’s brief, it is often necessary, or at least desirable, to enlarge upon such arguments, without unnecessary duplication, in an answering brief. It should never be assumed that petitioner’s argument is facetious or lacks substance; such factors should be respectfully and in a proper manner pointed out to the court in an answering brief. Furthermore, it must be kept in mind that some judges of the court specifically require the filing by the parties of answering briefs; these requirements must be strictly complied with in all instances. There are other judges who do not specifically request the parties to file an answering brief. Judges may, however, give consideration to the failure of one party or the other to respond to the opponent’s requested findings of fact and arguments in an answering brief.

4. In some cases, an answering brief may not be necessary due to the nature and contents of petitioner’s brief and the requested findings and arguments of respondent’s original brief. A decision not to file an answering brief should be made by the Field attorney in consultation with the reviewer. After such a determination, Field Counsel will prepare, within the due date for filing an answering brief, a document entitled, "Notice of Intent Not to File Answering Brief." _See_ Exhibit 35.11.1–121. If the original brief was filed directly with the court by Field Counsel, the Notice of Intent Not to File Answering Brief should be signed by Field Counsel and filed directly with the court. If the original brief was reviewed by an Associate office, the notice of intent, together with the legal file containing copies of the transcript and the parties’ original briefs, should be sent to that Associate office for review.


**35.7.1.3.5.1** **(07-18-2018)**

##### Form and Contents

1. No definite rules apply for the preparation of an answering brief, as each case must be briefed in accordance with the issues involved, the disagreement between the parties on the requested findings of fact, and argument on the legal points. The answering brief should not duplicate the matter contained in the original brief. In cases where there is a wide area of disagreement between the parties on both the findings of fact and the legal consequences to be drawn from the facts, the headings would be as follows:



1. Contents and Citations. In accordance with T.C. Rule 151(e)(1), all briefs should contain contents and citations pages. _See_ CCDM 35.7.2.1.2 and CCDM 35.7.2.1.3.

2. Preliminary Statement. This should be a short and concise statement of the nature of the document. Reference should be made to the original brief, and the due date of the answering brief given.

3. Respondent’s Objections to Petitioner’s Proposed Findings of Fact. The contents under this heading of the answering brief should be in the form and substance required by T. C. Rule 151(e)(3). When deemed necessary, a request for alternative findings of fact may also be included.

4. Argument. Petitioner’s legal argument should be answered.

5. Conclusion and Execution. _See_ CCDM 35.7.2.1.9 and CCDM 35.7.2.1.10.


**35.7.1.3.5.2** **(07-18-2018)**

##### Discretionary Review

1. In some cases, upon review of an opening brief by an Associate office, the Associate office may determine that the answering brief should be sent in for review prior to filing with the court. Conversely, there will be instances where it is determined by an Associate office that an answering brief need not be sent in for review prior to filing. In either event, the initialed copy of every opening brief reviewed in an Associate office will specifically designate one of the options referred to on being returned to Field Counsel. If the designated preference is that the answering brief need not be sent in, the procedures of CCDM 35.7.3.3, relating to directly filed briefs, will apply to the answering brief.

2. If the designated preference on the initialed copy of respondent’s opening brief is to send in the answering brief, the Field reviewer has the discretion to forward a copy of petitioner’s opening brief to the appropriate Associate office with a memorandum stating the reasons why the Field reviewer believes it is unnecessary that respondent’s answering brief be reviewed by the Associate office prior to filing in the Tax Court. If the Field reviewer elects to do so, Field Counsel’s memorandum and copy of petitioner’s opening brief should be sent to the Associate office within five days of its receipt in Field Counsel. Following that election by Field Counsel, the Associate office will have five days from the receipt of Field Counsel’s memorandum to notify Field Counsel that it wants to review respondent’s answering brief before filing. If the Associate office subsequently agrees that direct filing should be permitted, it will so notify Field Counsel within five days and the provisions of CCDM 35.7.3.3 will apply to the answering brief.

3. An Associate office may designate as its preference that a copy of petitioner’s brief be sent in with a memo. That option will generally be checked when the Associate office is uncertain whether it would prefer to review the answering brief before filing. If the designated preference on the initialed copy of respondent’s opening brief is to send in a copy of petitioner’s original brief with memo, Field Counsel shall, within 5 days of receiving the original brief, submit a copy thereof to the Associate office accompanied by a memorandum stating reasons why respondent’s answering brief need not be reviewed in the Associate office prior to filing. The Associate office will have five days from the receipt of Field Counsel’s memorandum to notify Field Counsel that it wants to review the answering brief. If the Associate office agrees that direct filing should be permitted, it will so notify Field Counsel within five days and the provisions of CCDM 35.7.3.3 will apply.

4. Following receipt of the petitioner’s opening brief, situations will occur in which Field Counsel believes it appropriate to have the Associate office review respondent’s answering brief before filing with the Tax Court. This may occur when the designated preference of the Associate office is to not send in a copy of the answering brief. Similarly, it may occur when the designated preference is to send in a copy of petitioner’s opening brief with a memo. It may also occur when the Associate office did not review respondent’s opening brief. _See_ CCDM 35.7.3.3. Accordingly, in any case in which Field Counsel determines that Associate office review prior to filing the answering brief is advisable, Field Counsel need not submit a copy of petitioner’s opening brief even if the Associate office has designated its preference on the initialed copy of respondent’s opening brief to send it in with a memo. In that event, the provisions of CCDM 35.7.3.2 apply and respondent’s answering brief should be received for review not later than seven calendar days prior to the due date.

5. The designation of a preference with respect to respondent’s answering brief is made prior to receipt of the petitioner’s simultaneously filed original brief. Accordingly, the foregoing provisions of this section do not apply if the question to be decided is whether to file any answering brief. .


**35.7.1.3.6** **(07-18-2018)**

#### Supplementing Briefs

1. A brief may be supplemented in several ways. One method is the filing of a formal document in the nature of a responsive brief, which is filed after respondent has filed the briefs permitted by the rules or an order of the court. This document must be accompanied by a motion for leave to file. A more common method of supplementing a brief is the filing of a Notice that simply calls the court’s attention to a recent decision on point or distinguishes a case or cases relied upon in a reply brief, answering brief, surreply brief, or supplemental brief filed with the court. The Tax Court has several forms for such a Notice that may be selected through eAccess for electronic filing: (1) Notice of Judicial Ruling; (2) Notice of Relevant Judicial Decisions; and (3) Notice of Supplemental Authority. The e-filed Notice form of supplementing a brief replaces the former procedure of sending a letter addressed to the trial judge, with a copy to petitioner or opposing counsel, informally advising the court of a recent judicial development. The Notice form of supplementing a brief may not be used if its purpose is to make extensive legal arguments or answer in detail a new argument raised by the petitioner in an answering or reply brief. The Notice does not require a motion for leave to file. Formal supplemental briefs or Notices supplementing a brief are reviewed in the appropriate Associate office to the same extent as any other brief.


**35.7.1.3.6.1** **(07-18-2018)**

##### Necessity for Filing

1. If after the submission of respondent’s answering brief or respondent’s reply brief a case is decided that is particularly applicable to the issue or issues involved, a proposed Notice of Judicial Ruling should be promptly prepared by Field Counsel, calling attention to such case. Also, if petitioner, after filing a brief, has filed a paper with the court calling attention to a recently decided case and such case is believed distinguishable, a proposed Notice of Supplemental Authority should be promptly prepared by the Field attorney **briefly** distinguishing the recent case relied upon by the petitioner. If the case cannot be satisfactorily distinguished, the matter should be promptly referred to the appropriate Associate office with a memorandum setting forth the views of Field Counsel. Upon receipt of the views of Field Counsel, further consideration will be given the matter by the Associate office, which will reach a decision on the action to be taken in the case.

2. A brief must be supplemented as soon as possible after the occasion arises necessitating its filing. If any of the issues addressed require review by the Associate office, Field Counsel will forward the supplemental brief or Notice to the appropriate Associate office for review.


**35.7.1.3.6.2** **(07-18-2018)**

##### Formal Type

1. The formal type of supplemental brief rarely will be used. When used, it will have the heading “Supplemental Brief for Respondent” and will be in memorandum form, without all of the formalities of a regular brief. It will contain the necessary headings to indicate to the court the reasons for its filing and to divide the points or items to which the argument contained therein is applicable. The exact format to be used will depend upon the particular circumstances of the case. If any of the issues addressed require review by the Associate office, Field Counsel will forward a formal supplemental brief to the appropriate Associate office, together with a motion for leave to file, setting forth the reasons for the filing of the supplemental brief. The brief will be lodged with the court together with an electronically filed motion for leave.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-007-001#addtoany "Show all")

A2A