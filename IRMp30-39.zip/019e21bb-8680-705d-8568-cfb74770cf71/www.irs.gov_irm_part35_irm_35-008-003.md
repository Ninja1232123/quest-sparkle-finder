---
url: "https://www.irs.gov/irm/part35/irm_35-008-003"
title: "35.8.3 Overpayments | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-008-003#main-content)

- 35.8.3 [Overpayments](https://www.irs.gov/irm/part35/irm_35-008-003#idm140689593287328)
  - 35.8.3.1 [In General](https://www.irs.gov/irm/part35/irm_35-008-003#idm140689589479088)
  - 35.8.3.2 [Tax Payment Dates](https://www.irs.gov/irm/part35/irm_35-008-003#idm140689600928464)
  - 35.8.3.3 [Filing Date of Tax Return](https://www.irs.gov/irm/part35/irm_35-008-003#idm140689588725472)
  - 35.8.3.4 [Agreements Extending Assessment Period](https://www.irs.gov/irm/part35/irm_35-008-003#idm140689591979232)
  - 35.8.3.5 [Claims for Refund](https://www.irs.gov/irm/part35/irm_35-008-003#idm140689605525872)
  - 35.8.3.6 [Overpayment Resulting From Jeopardy Payments](https://www.irs.gov/irm/part35/irm_35-008-003#idm140689605620912)
  - 35.8.3.7 [Overpayments and Deficiencies Resulting From Application of EarnedIncome Tax Credit](https://www.irs.gov/irm/part35/irm_35-008-003#idm140689602821840)
  - 35.8.3.8 [Overpayment Resulting From Undisputed Refund Pending Appeal Pursuantto RRA 3464](https://www.irs.gov/irm/part35/irm_35-008-003#idm140689591787056)

# Part 35. Tax Court Litigation

# Chapter 8. Decisions, Orders of Dismissal, and Other Final Judgments

# Section 3. Overpayments

* * *

## 35.8.3 Overpayments

**35.8.3.1** **(08-11-2004)**

### In General

1. An overpayment should not be determined in a Rule 155 computation or in a settlement stipulation or decision document unless the amount thereof can be legally credited or refunded to the taxpayer. The facts of the case must bring the overpayment within the provisions of section 6512(b).

2. In some instances a statutory notice of deficiency will be issued after the three-year limitation period where no agreement to extend the period has been executed, or after the period to which the statutory period is extended by agreement has expired. These situations primarily involve cases where no statutory return was filed, or where fraud or an understatement of gross income in excess of 25% is the basis for issuing the statutory notice. Generally, if no claim for refund specifying the ground which gives rise to the overpayment has been timely filed, an overpayment for the year involved will be barred under the provisions of sections 6511 and 6512(b).

3. The Rule 155 computation or the settlement stipulation, as the case may be, must reflect every fact necessary for the court to legally determine the overpayment, and the decision must determine such overpayment and find the facts required by statute to support the overpayment. In addition to the mathematical computation, the Rule 155 computation or the stipulation must set forth the following:



1. The section or sections of the appropriate Internal Revenue Code or Revenue Act upon which the overpayment is based;

2. The filing date of the return, if a statutory return was filed;

3. Whether a claim for refund has been filed and, if so, the filing date;

4. Whether an agreement or agreements have been executed extending the statutory period for assessment and, if so, the date or dates of such agreements, and the date to which the last agreement extended the period for assessment;

5. The date of the mailing of the statutory notice; and

6. The date or dates of each payment and amounts thereof.


**35.8.3.2** **(08-11-2004)**

### Tax Payment Dates

1. Under sections 6513 and 6151(c) any amounts withheld, paid as estimated income tax, or otherwise paid prior to the return due date, are deemed to have been paid on the last day prescribed for filing the return. The statutory date of payment is to be used for such amounts. When the statutory date is used in these situations, it should be indicated in the stipulation or Rule 155 computation that the date is the statutory payment date. _See_ Exhibit 35.11.1–130. The terms estimated tax payment or tax withheld should never be used in designating a payment of tax. Either the statutory date or the actual date of payment must be given for each payment listed in the document. Payments of tax and penalty cannot be combined in a stipulation or in a Rule 155 computation, and the dates of the payments of tax and penalty must be separately shown.

2. Generally, the overpayment results from the last tax paid since there is no overpayment in tax or penalty until the full liability therefor has been paid. In cases involving previous allowances for credits or refunds, the attorney must first determine out of which payment such refunds or credits were made. The attorney will then determine the date or dates of payment from which the proposed overpayment is to come, and whether such overpayment is barred by any provision of the internal revenue laws. If the overpayment comes out of tax paid on two or more dates, the stipulation or Rule 155 computation must set forth the basis supporting the portion of the overpayment for each of the dates on which the tax was paid. The court’s decision must also specify the date or dates the tax or penalty was paid, and the portion of the overpayment for each such date. Overpayments arising from tax paid after the mailing of the statutory notice need not be broken down in the decision into specific dates paid.


**35.8.3.3** **(08-11-2004)**

### Filing Date of Tax Return

1. The tax return, which in most cases is one of the essential factors supporting an overpayment, must be a return which satisfies all of the statutory requirements. If a statutory return has not been filed and the overpayment is otherwise allowable under the provisions of the Internal Revenue laws, the Rule 155 computation or the settlement stipulation should show no return filed.

2. Normally, the statutory filing date of a return is shown in the stipulation or Rule 155 computation since no record is made of the date of timely filed returns unless filed pursuant to a granted extension. _See_ section 6513(a). When the statutory filing date is used, it should be indicated that the designated date is the statutory date. Particular care should be exercised in drafting the Rule 155 and settlement documents in cases in which a return was filed after the statutory date but within the period as extended by the Area Director. _See_ Exhibit 35.11.1–129.

3. In overpayment cases involving a petitioner that is the successor of merged corporations, the return and related documents, such as waiver agreements and claims, must be with respect to the returns of the separate corporations prior to the merger, _i.e._, the corporation which actually paid the tax resulting in the overpayment. This also applies when an overpayment may legally be made to a petitioner who is not the taxpayer who paid the original tax.


**35.8.3.4** **(08-11-2004)**

### Agreements Extending Assessment Period

1. If the taxpayer and the Service, pursuant to the provisions of section 6501(c)(4), have entered into an agreement in writing to extend the statutory period for assessment, such agreement must be indicated in the stipulation or Rule 155 computation. The waiver agreement must be valid, _i.e._, it must be properly executed by the taxpayer and by or on behalf of the Service within the statutory period. If a valid agreement or agreements have been entered into by the parties, the date or dates of such agreements and the period to which the last agreement extended the time for assessment must be shown in the stipulation or Rule 155 computation. If an agreement has not been executed by the parties, or if the agreement forwarded to the Commissioner or a delegate is not a valid agreement, the document must show no agreements executed. _See_ examples of overpayment stipulation exhibits at Exhibit 35.11.1–129 through 35.11.1–137.


**35.8.3.5** **(08-11-2004)**

### Claims for Refund

1. If a claim for refund has been filed which, in whole or in part, supports the overpayment, such fact must be set forth in the stipulation or Rule 155 computation even though the decision is not to be based upon the claim under the applicable provisions of the internal revenue laws. If a valid claim has not been filed, or if the claim filed does not support, in whole or in part, the overpayment, then the stipulation or Rule 155 documents should show no claim filed. The attorney must examine the claim and determine whether it is valid; that is, was it executed as required by statute; was it timely filed; and does it cover the issue or issues which form the basis for the overpayment? Even though valid when filed, such claim will not support the overpayment if one of the conditions specified in subparagraphs (i), (ii) and (iii) of section 6512(b)(3)(C) is not satisfied. Thus, claims should be ignored that: are invalid; relate to an issue or issues not resulting in the overpayment; or are not supported by the applicable provisions of the internal revenue laws. A claim for refund may be made by the taxpayer on the prescribed claim form. In appropriate instances, the tax return may also be considered the taxpayer’s claim for an overpayment. If the basis for the overpayment, in whole or in part, is a claim filed for a net operating loss carryback or carryforward, an overpayment cannot be allowed by the Tax Court unless the carryback or carryforward loss is raised as an issue in the pleadings or as stipulated by the parties.

2. The overpayment must be based on payments made after the mailing of the notice of deficiency, or upon the fact that a valid claim could have been filed on the date of the mailing of the statutory notice, or upon facts which come within the provisions of section 6512(b)(3)(C). Also subparagraphs (B) and (C) of the section are to be construed as basing the overpayment on a valid claim if a valid claim supporting the overpayment was filed prior to the issuance of the statutory notice. If no valid claim has been filed but a valid claim could have been filed on the date of the mailing of the statutory notice, the overpayment should be based on section 6512(b)(3)(B). The stipulation or Rule 155 documents, as well as the court’s decision, should specify the various portions of the total overpayment which are allowable under different subsections of the applicable statute, and set forth the applicable statutory provisions supporting each portion. For example, a portion of the overpayment may be allowable under subsection (b)(3)(A), another portion may be allowable under subsection (b)(3)(C), and the remaining portion of the overpayment allowable under subsection (b)(3)(B) of section 6512. In this situation, the documents filed with the Tax Court as well as the administrative computations must precisely show the dollars and cents which are to be refunded or credited under the various provisions of the statute. This specificity is required in order to confirm that the Tax Court has jurisdiction to determine the overpayment pursuant to section 6512.


**35.8.3.6** **(08-11-2004)**

### Overpayment Resulting From Jeopardy Payments

1. If an overpayment of tax and penalty results from payment, in whole or in part, of a jeopardy assessment, the stipulation or Rule 155 proposed decision will provide for, and the decision should determine, the overpayment of tax or penalty. The stipulation or Rule 155 decision should indicate the payments of tax or penalty which were overpayments of jeopardy assessments (both settlement and Rule 155). Any unpaid portion of the jeopardy assessment will be handled in the administrative part of the computation and adjusted administratively, and need not be considered in drafting the settlement or Rule 155 documents for the court. _See_ Exhibit 35.11.1–132.


**35.8.3.7** **(08-11-2004)**

### Overpayments and Deficiencies Resulting From Application of Earned Income Tax Credit

1. Overview of the Credit: The earned income credit pursuant to section 32 provides, in general, for a refundable tax credit for eligible individuals. The credit is based on "earned income," such as wages, salaries and other employee compensation, as well as earnings from self-employment. The credit amount is determined by multiplying an individual’s earned income by a credit percentage. The credit is subject to a possible phase-out as adjusted gross income increases. Different credit and phase-out percentages apply, depending on whether the individual has no qualifying children, one qualifying child, or more than one qualifying child.

2. Application of the Credit: The earned income credit is a refundable credit that is treated as a payment of tax, not as a reduction in the assessed tax liability. It is "refunded" to the eligible individual to the extent it exceeds the tax liability. Disposition of cases in Tax Court involving an individual’s entitlement to the credit can require the preparation of settlement and decision documents that reflect an overpayment to the individual. The overpayment derives from the credit, which is treated as an "amount paid" as of the due date of the subject return.

3. Calculation of Deficiencies Involving the Earned Income Credit: Earned income credits claimed by the taxpayer that are disallowed are subject to deficiency proceedings. Section 6211(b)(4). The deficiency is arrived at by comparing the sum of the correct amount of tax imposed and the correct earned income credit with the sum of the tax shown on the return plus the credit shown. For deficiency purposes, the earned income credit is treated as a negative tax. The credit must be considered even if it is a negative number. The statutory requirement can be summarized by the following formula:



1. Tax shown less EIC shown tax on return

2. Correct tax less correct EIC tax imposed

3. Tax imposed less tax on return deficiency


4. It is important that decision documents involving the EITC are properly prepared and its components properly labeled so that administrative accounting for the EITC is correctly reflected to the extent it does not involve real remittances of revenue to the government. _See_ Exhibits 35.11.1–138 and 35.11.1–139.


**35.8.3.8** **(08-11-2004)**

### Overpayment Resulting From Undisputed Refund Pending Appeal Pursuant to RRA § 3464

1. Section 3464 of the Internal Revenue Service Restructuring and Reform Act of 1998 (RRA), Pub. L. No. 105–206, 112 Stat. 685 (1998), amended section 6512(b)(1) of the Code to authorize the Service to refund or credit an overpayment determined by the Tax Court that is not contested on appeal. RRA § 3464 also amended section 6213(a) of the Code to give the Tax Court jurisdiction to order this refund or credit. Any decision document should reflect that a refund or credit was made pursuant to RRA § 3464. For instance, if, after appeal, the case is remanded to the Tax Court, the stipulation portion of any new decision document must reflect that the refund or credit was issued while the appeal was pending. _See_ Exhibit 35.11.1–140.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-008-003#addtoany "Show all")

A2A