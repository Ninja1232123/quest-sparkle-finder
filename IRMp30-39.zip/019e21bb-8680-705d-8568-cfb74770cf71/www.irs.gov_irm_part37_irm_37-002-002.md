---
url: "https://www.irs.gov/irm/part37/irm_37-002-002"
title: "37.2.2 Freedom of Information Act (FOIA) Litigation | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part37/irm_37-002-002#main-content)

- 37.2.2 [Freedom of Information Act (FOIA) Litigation](https://www.irs.gov/irm/part37/irm_37-002-002#idm139788293027056)
  - 37.2.2.1 [General](https://www.irs.gov/irm/part37/irm_37-002-002#idm139788308713216)
  - 37.2.2.2 [Procedures upon Receipt of Complaint](https://www.irs.gov/irm/part37/irm_37-002-002#idm139788308711808)
  - 37.2.2.3 [Defense Letter](https://www.irs.gov/irm/part37/irm_37-002-002#idm139788293725776)
  - 37.2.2.4 [Coordination](https://www.irs.gov/irm/part37/irm_37-002-002#idm139788292987648)
  - 37.2.2.5 [Vaughn Index](https://www.irs.gov/irm/part37/irm_37-002-002#idm139788307918800)
  - 37.2.2.6 [Closing the Case](https://www.irs.gov/irm/part37/irm_37-002-002#idm139788307913168)

# Part 37. Disclosure

# Chapter 2. Privacy Act of 1974; Freedom of Information Act

# Section 2. Freedom of Information Act (FOIA) Litigation

* * *

## 37.2.2 Freedom of Information Act (FOIA) Litigation

#### Manual Transmittal

August 09, 2018

#### Purpose

(1) This transmits revised CCDM 37.2.2, Disclosure, Freedom of Information Act (FOIA) Litigation.

#### Background

CCDM 37.2.2 is revised to provide current policy and procedures relating to the coordination of litigation arising under the Freedom of Information Act (FOIA).

#### Material Changes

(1) CCDM 37.2.2.1 is revised to define and provide guidance related to partial FOIA complaints, specifically, that assigned non-P&A attorneys will retain primary responsibility for such cases but the FOIA counts should be coordinated with P&A Branches 6 and 7.

(2) CCDM 37.2.2.2(3) is revised to instruct attorneys to contact the Disclosure Office regarding FOIA requests in cases where either no search was conducted or there are questions regarding the adequacy of the search.

(3) CCDM 37.2.2.3(1) is revised to state that P&A Branch 6 and 7 attorneys will provide language addressing FOIA counts for defense letters in response to partial FOIA complaints.

(4) CCDM 37.2.2.3(2) is revised to provide current practices regarding the required elements of defense letters.

(5) CCDM 37.2.2.3(7) is revised to clarify the requirements of an appropriate declaration in the context of FOIA litigation.

(6) CCDM 37.2.2.5 is revised to clarify that a _Vaughn_ Index may only be required by court order.

(7) Organizational titles and references are updated and minor typographical errors are corrected throughout the section.

#### Effect on Other Documents

CCDM 37.2.2, dated 08-11-2004, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(08-09-2018)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**37.2.2.1** **(08-09-2018)**

### General

1. The Associate Chief Counsel (P&A) is responsible for coordinating all aspects of litigation arising under the FOIA, 5 U.S.C. § 552. For procedures concerning administrative processing of FOIA requests, see CCDM 30.11.1.

2. Any complaint alleging jurisdiction in part under the FOIA and in part under other statutes or theories falling under the aegis of another Office of Chief Counsel function (a partial FOIA complaint) is to be coordinated with the Associate Chief Counsel (P&A). See CCDM 37.1.2.9. For partial FOIA complaints, the assigned non-P&A attorney will retain primary responsibility for the case, but should not address the FOIA components independently. Instead, those components will be addressed by the P&A attorney assigned to the case, as set forth below.


**37.2.2.2** **(08-09-2018)**

### Procedures upon Receipt of Complaint

1. Upon receipt by any component of the Office of Chief Counsel of a copy of a complaint that alleges jurisdiction under the FOIA, the complaint will be sent to the Technical Services Support Branch (email to TSS.Assignments@irscounsel.treas.gov) for case opening and assignments to a P&A attorney. In the event of a short deadline for response to a complaint, the complaint should also be emailed to the Branch Chiefs of P&A Branches 6 and 7.



1. For partial FOIA complaints, the attorney with primary responsibility for the case should also email a copy of the complaint to the Branch Chiefs of P&A Branches 6 and 7 within five business days of receipt for response coordination.


2. The P&A attorney assigned to the case should first ascertain the date of service of process on the United States Attorney’s office in the district in which the action is filed in order to calculate the due date for the answer and should confirm that date with the Department of Justice Tax Division attorney assigned to the case.

3. The attorney should ascertain whether the lawsuit is based upon the agency’s failure to respond to an initial request or based upon a complete or partial denial of a FOIA appeal. The attorney should obtain the appeal file and review the administrative record as it pertains to the issues raised in the complaint, including any procedural issues (e.g., fee waiver, reasonable description of records, adequacy of search). If no search for responsive records was conducted or if there are questions regarding the adequacy of the search, the attorney should contact the Disclosure Office responsible for the FOIA request. The attorney should also review any withheld records, or portions thereof, and the reasons for the withholdings. If there is no appeal file or if the appeal file is incomplete, the attorney should obtain a copy of the initial request file from the Disclosure Office responsible for the FOIA request that is the subject of the complaint.

4. Suit based on failure to timely respond. If the lawsuit is based on the agency’s failure to timely respond to a FOIA request or appeal, the attorney should immediately obtain a copy of the request or appeal file and review the administrative record.



1. Generally, if the request or appeal is still being processed, the office having jurisdiction over the request or appeal should conclude the processing as expeditiously as possible. If an adequate search for responsive records has not been conducted, the attorney should ensure that such a search is promptly carried out. Once a response is issued, copies of the response and any withheld records should be obtained. The determination whether to continue the agency’s administrative processing of the request or appeal or to process them through the Tax Division will be made by the P&A attorney in consultation with Tax Division counsel.


5. Additionally, it may appear from the FOIA request or the complaint, or both, that the records are sought in connection with a substantive tax matter, such as an examination, collection activity, criminal investigation, or ongoing litigation. In such cases, it may be helpful or necessary to a proper defense of the FOIA lawsuit to obtain from the Disclosure personnel who processed the request and/or appeal, and/or from the agency personnel handling the substantive tax matter, pertinent background information relating to the FOIA request.

6. As the FOIA litigation proceeds, the P&A attorney should stay up to date on the status of the underlying tax matter. Factors such as the closing of a civil examination, docketing of a case in the Tax Court, or referral of a case for criminal prosecution, may have an impact on the choice of defenses to the FOIA lawsuit.


**37.2.2.3** **(08-09-2018)**

### Defense Letter

1. The P&A attorney assigned to the case will prepare a defense letter to assist the Tax Division in defending the Service.



1. For partial FOIA complaints, P&A Branches 6 and 7 will provide language addressing the FOIA counts for insertion into a defense letter prepared by the attorney with primary responsibility for the case.


2. The contents of a defense letter are described below:



1. Background. The background discussion shall cover the events leading up to the commencement of the litigation including all actions taken on a FOIA request submitted by the plaintiff. The background discussion shall, when relevant, also describe the plaintiff’s substantive tax case to the extent it pertains to the lawsuit. If the records are voluminous or multiple FOIA exemptions are being asserted, a short index may be included in the letter.

2. Affirmative Defenses. The recommended affirmative defenses in the defense letter shall be briefly stated and shall include dismissal of any individual defendants on the ground that the FOIA authorizes suit only against the agency.

3. Legal Analysis. The legal analysis section of the defense letter shall discuss the applicable law in depth and relate it to the facts of the case. Case law relating to the recommended defenses shall be cited and discussed, especially opinions of the district court or court of appeals for the judicial district and circuit in which the litigation has been brought. Unfavorable controlling precedent shall be brought to the Tax Division’s attention in the letter.



      ### Note:



      After the search is conducted and the records are reviewed, declarations supporting the factual basis of the Government’s motion for summary judgement or other dispositive motion will be provided to the Tax Division.


3. Sometimes the circumstances of the case or time constraints may not permit a complete defense letter to be finished in sufficient time to be of use to the Tax Division in filing an answer to the complaint. In such situations, the attorney shall prepare an initial defense letter setting forth all background information gathered up to that point and recommended affirmative defenses.



1. If the attorney cannot presently determine what exemptions to the FOIA the Service shall assert, he or she should recommend that 5 U.S.C. § 552(b) be asserted as an affirmative defense.

2. The attorney should also determine if 5 U.S.C. § 552(c) excludes any of the records at issue from the provisions of the FOIA and, if appropriate, provide information to support an argument based on the subsection.

3. The initial defense letter should conclude with a statement that a full discussion of the law supporting the recommended defenses and any necessary declarations will be furnished later.


4. If an initial defense letter is provided in lieu of a complete defense letter, the attorney should promptly prepare a final defense letter setting forth any additional background information, a legal analysis of the issues, and executed declarations to support a dispositive motion, if appropriate.

5. In the course of preparing the defense letter, the attorney should analyze the records that have been withheld to evaluate the arguments supporting denial of the records. To the extent that an exemption has been misapplied, the attorney should bring the record to the attention of a reviewer to determine if release, in whole or in part, is appropriate.

6. In conjunction with preparing the defense letter, the attorney shall prepare declarations to support the exemption claims and other defenses as appropriate.

7. Declarations should include the facts necessary to support the Government’s motion for summary judgement or other dispositive motion, **e.g.**, details regarding the processing of the FOIA request and the search for records. Declarations are to be written for the signature of, or with input from, those with firsthand knowledge of the facts.

8. Declarations should be detailed and non-conclusory and avoid the use of inadmissible hearsay. When appropriate, the attorney will incorporate input and suggestions from the Tax Division attorney assigned to the case. The attorney’s reviewer will review the declarations before forwarding them to the declarants for signature.

9. Once executed, declarations are to be returned to the P&A attorney. The P&A attorney will then forward the declarations to the Tax Division.


**37.2.2.4** **(08-09-2018)**

### Coordination

1. After the P&A attorney has provided the Tax Division with the defense letter, declarations necessary to support a motion for summary judgment or other dispositive motion, and, if necessary, copies of the records at issue in a format suitable for in camera submission, the attorney is responsible for furnishing any additional assistance requested by the Tax Division. This responsibility may include obtaining additional declarations, furnishing or updating background information, enlarging upon a defense, preparing a court-ordered _Vaughn_ index, answering interrogatories or other discovery, assessing a settlement proposal, or assessing a request for attorney fees and court costs.

2. Coordination with the Tax Division should continue through any post-judgment filings, such as a motion to alter or amend the judgment under Fed. R. Civ. P. 59(e) or a motion for relief from the judgment under Fed. R. Civ. P. 60. For all "significant litigation" within the meaning of Department of Treasury General Counsel Order No. 10 (January 19, 2001), the reporting requirements of that order should be followed.


**37.2.2.5** **(08-09-2018)**

### _Vaughn_ Index

1. The attorney may be required by court order to prepare a _Vaughn_ Index (see _Vaughn v. Rosen_, 484 F.2d 820 (D.C. Cir. 1973)) of the records being withheld. Generally, the _Vaughn_ Index will entail a document by document description of the records, along with an enumeration of the FOIA exemptions claimed for each record, and a detailed justification for the exemptions.

2. The index should be detailed, nonconclusory, and avoid the use of inadmissible hearsay. For any record for which it has been determined that there are no segregable portions that may be released, such that the record is being withheld in its entirety, the _Vaughn_ index should include a statement that nonexempt material in the record could not reasonably be segregated from exempt material and the justification for that determination.


**37.2.2.6** **(08-09-2018)**

### Closing the Case

1. After court decision or other conclusion (voluntary dismissal, settlement, etc.) and expiration of the appeal period, the attorney should complete the case closing documentation, submit the case file for closing, and ensure the case is closed on CASE-MIS.

2. If an appeal is filed, a new work load item should be opened under the appropriate appeal category and the work load item for the district court should be closed. For appellate litigation, see CCDM Part 36.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part37/irm_37-002-002#addtoany "Show all")

A2A