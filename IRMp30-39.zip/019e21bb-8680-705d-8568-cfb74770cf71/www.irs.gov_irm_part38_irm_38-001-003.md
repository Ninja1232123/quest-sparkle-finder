---
url: "https://www.irs.gov/irm/part38/irm_38-001-003"
title: "38.1.3 Forfeitures | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part38/irm_38-001-003#main-content)

- 38.1.3 [Forfeitures](https://www.irs.gov/irm/part38/irm_38-001-003#idm140162887186896)
  - 38.1.3.1 [IRS Forfeiture Jurisdiction](https://www.irs.gov/irm/part38/irm_38-001-003#idm140162887186480)
  - 38.1.3.2 [Investigation and Seizure](https://www.irs.gov/irm/part38/irm_38-001-003#idm140162887000016)
  - 38.1.3.3 [Administrative Forfeitures](https://www.irs.gov/irm/part38/irm_38-001-003#idm140162887192864)

    - 38.1.3.3.1 [Monetary Limits](https://www.irs.gov/irm/part38/irm_38-001-003#idm140162887025520)
    - 38.1.3.3.2 [Counsel Review of Proposed Forfeiture](https://www.irs.gov/irm/part38/irm_38-001-003#idm140162887020432)

      - 38.1.3.3.2.1 [Memorandum of Law and Fact](https://www.irs.gov/irm/part38/irm_38-001-003#idm140162887016704)

    - 38.1.3.3.3 [Inquiries Regarding Forfeiture](https://www.irs.gov/irm/part38/irm_38-001-003#idm140162887112224)
    - 38.1.3.3.4 [Appraisals of Seized Property](https://www.irs.gov/irm/part38/irm_38-001-003#idm140162887107424)
    - 38.1.3.3.5 [Authorizations, Timing, and Review Procedures for Title 26 Forfeitures](https://www.irs.gov/irm/part38/irm_38-001-003#idm140162887103072)
    - 38.1.3.3.6 [Deficient Cases](https://www.irs.gov/irm/part38/irm_38-001-003#idm140162887094592)

  - 38.1.3.4 [Judicial Forfeitures](https://www.irs.gov/irm/part38/irm_38-001-003#idm140162887086416)

    - 38.1.3.4.1 [Circumstances Requiring Judicial Forfeiture](https://www.irs.gov/irm/part38/irm_38-001-003#idm140162887079072)
    - 38.1.3.4.2 [Claims](https://www.irs.gov/irm/part38/irm_38-001-003#idm140162887067728)
    - 38.1.3.4.3 [Documents Prepared For Proposed Title 18 and 31 Forfeitures](https://www.irs.gov/irm/part38/irm_38-001-003#idm140162887059872)
    - 38.1.3.4.4 [Documents Prepared For Proposed Title 26 Forfeitures](https://www.irs.gov/irm/part38/irm_38-001-003#idm140162872300704)
    - 38.1.3.4.5 [Other Documents Prepared by Counsel Attorneys](https://www.irs.gov/irm/part38/irm_38-001-003#idm140162872294912)

  - 38.1.3.5 [Petitions for Remission or Mitigation of Forfeiture](https://www.irs.gov/irm/part38/irm_38-001-003#idm140162872289968)
  - 38.1.3.6 [Offers in Compromise](https://www.irs.gov/irm/part38/irm_38-001-003#idm140162872265216)
  - 38.1.3.7 [Forfeiture Suspended](https://www.irs.gov/irm/part38/irm_38-001-003#idm140162872261264)
  - 38.1.3.8 [Miscellaneous Matters](https://www.irs.gov/irm/part38/irm_38-001-003#idm140162872254800)

# Part 38. Criminal Tax

# Chapter 1. Assistance to Criminal Investigation During Investigatory Stage

# Section 3. Forfeitures

* * *

## 38.1.3 Forfeitures

**38.1.3.1** **(08-11-2004)**

### IRS Forfeiture Jurisdiction

1. The IRS has jurisdiction to forfeit property under Titles 18, 26, and 31.

2. Section 981(a)(1)(A) of Title 18 authorizes forfeitures of real and personal property involved in a transaction or attempted transaction in violation of 18 U.S.C. §§ 1956, 1957 and 1960, or property traceable to such property. _See_ 18 U.S.C. §§ 1956 and 1957 and the Memorandum of Understanding (MOU), dated August 1990 defining Service jurisdiction.

3. IRS-CI has jurisdiction under 18 U.S.C. § 981(a)(1)(C) to forfeit proceeds derived from specified unlawful activities. In order to exercise this jurisdiction, the proceeds forfeiture must be incidental to a legitimate money laundering investigation. Use of forfeiture authority under section 981(a)(1)(C) is limited to situations in money laundering investigations where no reasonable forfeiture alternative is available, that is, proof required to forfeit under section 981(a)(1)(C) is lacking. These situations typically arise when the subject property cannot be traced to a specific financial transaction.

4. Sections 7301 and 7302 of the Internal Revenue Code (Code Forfeitures) authorize seizure and forfeiture of property used or intended to be used in violation of any of the internal revenue laws. All proposed forfeitures under IRC §§ 7301 or 7302 that do not relate solely to violations of IRC § 6050I or wagering excise tax violations (i.e., violations not relating to violations under IRC §§ 4401, 4411, 4412) require authorization from the Associate Chief Counsel (CT) prior to recommending forfeiture. The Associate Chief Counsel (CT) must review and approve any proposed seizure of real property for Code forfeiture. The field will handle all other forfeitures matters and may make the referral directly to the US Attorney (if judicial).

5. Section 5317(c) of Title 31 forfeitures are predicated on violations of the Bank Secrecy Act. See 31 U.S.C. §§ 5313(a), 5316, and 5324(a). Prior to enactment of the USA Patriot Act of 2001 (October 26, 2001), Pub. L. 107-56, 18 U.S.C. § 981(a)(1)(A) listed 31 U.S.C. §§ 5313(a) and 5324(a) as the only Title 31 violations subject to forfeiture. Section 372 of the Patriot Act removed those sections from Title 18 and inserted the sections in their entirety into 31 U.S.C. § 5317(c).

6. The burden of proof to seize forfeitable property is probable cause. The burden of proof to forfeit is preponderance of the evidence. The Criminal Tax attorney should ensure the available evidence is sufficient to sustain both the seizure and forfeiture.

7. Criminal Investigation’s authority to seize property subject to forfeiture is pursuant to Delegation Order No. 158 for Titles 18 and 31, and Delegation Order No. 157 for Title 26.


**38.1.3.2** **(10-03-2007)**

### Investigation and Seizure

1. Requests for advice pertaining to the sufficiency of evidence to justify searches and seizures, and for assistance in preparing affidavits for search warrants, arrest in rem warrants, and/or seizure warrants should be handled in the same manner presently afforded the handling of requests for pre-referral advice. See CCDM 38.1.1.1, http://publish.no.irs.gov/getpdf.cgi?catnum=39133.

2. Although not required by Rule C(3) of the Supplemental Rules for Certain Admiralty and Maritime Claims, it is Department of Justice (DOJ) policy that, absent exigent circumstances, the complaint and affidavit for warrant be taken before a magistrate for a judicial finding of probable cause.

3. Once the property has been seized, all relevant documents and exhibits generated by the investigation and seizure will be forwarded by Criminal Investigation to Counsel for review to determine whether the available evidence is sufficient to sustain the forfeiture. The documents and exhibits should include but are not limited to:



1. Form 4008, Seized Property Report, used to report seizures of all property regardless of whether the property is subject to administrative or judicial forfeiture, http://publish.no.irs.gov/getpdf.cgi?catnum=41259

2. Form 181, Property Inventory Record, used to inventory the seizure of vehicles, and other conveyances, http://publish.no.irs.gov/getpdf.cgi?catnum=16556

3. Form 226-A, Appraisement List (Seized Property), used to provide an appraisal of the value of property seized from one owner in one location when, in the opinion of the special agent, the value of the property is less than the applicable range, http://publish.no.irs.gov/getpdf.cgi?catnum=16584

4. Special agent’s memorandum of activity

5. Copy of affidavit for seizure (search) warrant

6. Copy of seizure (search) warrant and return


4. After seizing the property as set forth above, it may be administratively or judicially forfeited, depending on the facts and circumstances.


**38.1.3.3** **(08-11-2004)**

### Administrative Forfeitures

1. Personal property may be administratively forfeited based on authority in Title 18, 26, or 31. The following subsections set out the monetary limits on forfeitures under each of these titles, the contents of the memorandum to the SAC analyzing the proposed forfeiture, and other procedures regarding administrative forfeitures.


**38.1.3.3.1** **(08-11-2004)**

#### Monetary Limits

1. Personal property valued at $500,000 or less may be administratively forfeited (provided no claim is filed) based on Title 18 or Title 31 authority. Personal property constituting monetary instruments, as defined in 31 U.S.C. § 5312(a)(3), can be administratively forfeited without regard to value.

2. Personal property valued at $100,000 or less may be administratively forfeited pursuant to Title 26 authority, provided no claim and cost bond is filed.


**38.1.3.3.2** **(08-11-2004)**

#### Counsel Review of Proposed Forfeiture

1. Counsel’s role is to determine whether the evidence is legally sufficient to sustain the forfeiture and provide Criminal Investigation policy and procedural guidance.


**38.1.3.3.2.1** **(08-11-2004)**

##### Memorandum of Law and Fact

1. Counsel should provide a law and fact memorandum to the SAC, Criminal Investigation, within 30 days after receipt of a complete package from Criminal Investigation, unless legal action is required earlier. The purpose of the memorandum is to provide a complete legal analysis and recommendation regarding the proposed forfeiture. See Exhibit 38.3.1-4 and Exhibit 38.3.1-5 at http://publish.no.irs.gov/getpdf.cgi?catnum=39139.

2. The memorandum should discuss the facts of the seizure and should include a description of the nature and value of the property seized, a description of the place(s) of seizure, the legal basis for the seizure and forfeiture, the sufficiency of the evidence needed to sustain the forfeiture, and any applicable Constitutional issues (e.g., due process claims, excessive fines). A copy of this memorandum with attachments should be sent to the Associate Chief Counsel (CT).

3. The memorandum should advise the SAC that written notice is required to be provided to each person believed to have an interest in the seized property not more than 60 days after seizure or after the identity of an interested party has been determined. Notice is statutorily required for Titles 18 and 31. _See_ 18 U.S.C. § 983(a). Further, the SAC must place an advertisement in a newspaper of general circulation in the geographic area where the seizure was made once per week for three consecutive weeks. The advertisement must describe the seized property and state when, where, why, and from whom it was seized. It should also advise that a claim for the property must be made within 30 days of the last advertisement or 30 days of the first advertisement for Title 26 forfeitures. A copy of the advertisement should be enclosed with each letter.

4. Since these forfeitures are traditionally civil proceedings, it is the SAC’s responsibility to advise Counsel whether criminal prosecution has been recommended or is contemplated in related cases. The memorandum should discuss how the proposed forfeiture may affect criminal prosecution of such cases with a view towards advising whether the forfeiture proceedings should be stayed.

5. The memorandum should request that the SAC notify Counsel if a claim (and cost bond for Title 26 forfeitures), a petition for remission or mitigation of forfeiture, or an offer in compromise is received.

6. The memorandum should also advise the SAC whether to execute a Declaration of Forfeiture 30 days after the date the advertisement is last published (or first published for Title 26 forfeitures) to perfect the forfeiture.


**38.1.3.3.3** **(08-11-2004)**

#### Inquiries Regarding Forfeiture

1. Occasionally, the Criminal Tax attorney may receive a written inquiry submitted by, or on behalf of, the individual from whom the property was seized and/or owned. The attorney should forward the inquiry to Criminal Investigation for appropriate response. Criminal Investigation should inform the individual of the applicable forfeiture regulations at 19 U.S.C. § 1602 _et seq._, or 26 C.F.R. Part 403.


**38.1.3.3.4** **(08-11-2004)**

#### Appraisals of Seized Property

1. The Criminal Tax attorney should receive the appraisal information as part of the file and should insure the appraised value of the property seized allows the Service to administratively forfeit the property. For Title 26 forfeitures only, IRC § 7325(1) requires the Service obtain an appraisal by three sworn appraisers who reside within the geographic area served by the local IRS office where the seizure was made.


**38.1.3.3.5** **(08-11-2004)**

#### Authorizations, Timing, and Review Procedures for Title 26 Forfeitures

1. In any case of a proposed forfeiture under IRC § 7301 or IRC § 7302 of nonwagering related property that does not solely concern the filing of IRS Form 8300 regarding the receipt of more than $10,000 cash by a trade or business (i.e., violations not relating to wagering excise tax violations under IRC §§ 4401, 4411, 4412), authorization must be obtained from the Associate Chief Counsel (CT) prior to recommending forfeiture.

2. In cases requiring approval by the Associate Chief Counsel (CT), a copy of the proposed law and fact memorandum and supporting material, as appropriate, should be sent to the Associate Chief Counsel (CT) in a timely manner to ensure the final law and fact memorandum is provided to the SAC within the 30 day time frame, unless legal action is required earlier.

3. The Associate Chief Counsel (CT), with the assistance of Headquarters attorneys, will complete review the proposed memorandum within three work days of receipt.

4. If the Associate Chief Counsel (CT) approves the proposed forfeiture action, the submitting Criminal Tax attorney will be notified of this decision in writing and authorized to send the memorandum to the SAC. A copy of this notification and authorization will be sent by fax or other electronic means to the respective Area Counsel (CT). The law and fact memorandum should then be signed by the Criminal Tax attorney or Area Counsel (CT), as appropriate.

5. If the Associate Chief Counsel (CT) does not agree with the proposed forfeiture action, the respective Area Counsel (CT) will be notified of the decision.


**38.1.3.3.6** **(08-11-2004)**

#### Deficient Cases

1. If a review of the evidence indicates a deficiency in the case, the Criminal Tax attorney should attempt to remedy it by contacting Criminal Investigation to obtain additional evidence or information to meet the burden of proof.

2. If the Criminal Tax attorney determines the case is not subject to cure, the law and fact memorandum to the SAC should outline the problems and recommend the seized property be returned when no longer needed as evidence. In such cases, a waiver or indemnity agreement between the Service and the owner of the seized property may be appropriate.

3. Where property, such as books, records, and papers, will not be forfeited, such property should be retained for evidentiary purposes only.

4. Where property, such as drugs or contraband, has been seized by Criminal Investigation during the course of a raid, such property should be turned over to the appropriate federal agency for disposition. With respect to illegal firearms, refer to current policy on disposition of seized firearms.

5. Attention should be given to potential search and seizure defects and self-incrimination assertions because the Fourth and Fifth Amendments may be applicable to forfeitures. Note an illegal seizure may not result in the inability of the Government to forfeit the property if the Government can independently establish probable cause for forfeiture.


**38.1.3.4** **(08-11-2004)**

### Judicial Forfeitures

1. This subsection describes the authority for judicial forfeitures under Titles 18, 26, and 31, the circumstances when judicial forfeiture is required, and the procedures for Counsel review of proposed forfeitures under these titles.

2. Counsel is the referral authority for judicial forfeitures brought under IRC §§ 7301 and 7302. _See_ IRC § 7401 and 26 C.F.R. § 403.26(b). All Code forfeitures, other than those relating to IRC § 6050I violations or wagering excise tax violations under IRC §§ 4401, 4411, or 4412, may be referred only with approval of the Associate Chief Counsel (CT). Recommendations for these forfeitures also must be reviewed and authorized by the Civil Section of the Tax Division. The Tax Division has not delegated this authority to the US Attorneys.

3. Code forfeitures relating to IRC §§ 6050I violations or wagering excise tax violations under IRC §§ 4401, 4411, or 4412 may be referred by the Area Counsel (CT), or if a delegation is in place, by the Criminal Tax attorney. The referral will be to the US Attorney for the judicial district in which the seizure was made.


**38.1.3.4.1** **(08-11-2004)**

#### Circumstances Requiring Judicial Forfeiture

1. Judicial forfeiture is required in the following circumstances:



1. When the aggregate value of the seized property exceeds the monetary limits for administrative forfeitures ($500,000 for forfeitures based on Title 18 or 31 forfeiture authority or $100,000 for forfeitures based on Title 26 forfeiture authority)

2. When a person with an interest in the property files a timely and adequate claim (and cost bond for Title 26 forfeitures) with Criminal Investigation

3. When the forfeiture involves real property and real property interests _See_ 18 U.S.C. § 985



      ### Note:



      The Internal Revenue Code does not preclude real property forfeitures, but the regulations only address forfeitures of personal property. Therefore, any proposed seizure must be reviewed and approved by the Associate Chief Counsel (CT).

4. When grand jury information is essential to the forfeiture decision and such information is subject to the restrictions of Fed. R. Crim. P. 6(e), but the particular jurisdiction will not allow grand jury information to be used civilly as authorized by 18 U.S.C. § 3322(a)


**38.1.3.4.2** **(08-11-2004)**

#### Claims

1. Any person claiming an interest in seized property may file a claim (and cost bond for Title 26 forfeitures) with Criminal Investigation for the field office in which the property was seized. Claims must be filed within 30 days of the last publication or 35 days from the date the notice was mailed. For Title 26 forfeitures, a claim and cost bond must be filed within 30 days of the first publication of notice in order to be timely, IRC § 7325. The bond should be made payable to the United States in the sum of $2,500.

2. A timely filed claim ends the administrative forfeiture process and requires judicial adjudication.

3. For Title 26 claims, a party in interest may claim indigence and seek exception from the requirement to post the bond. Such claimant should be given a Form 9365, which requires provision of financial information, to test the claim of indigence. The SAC may grant or deny such a claim. If granted, the claim is forwarded to the Civil Section of the Tax Division. If denied, the claimant is notified that if satisfactory bond is not received by the end of the now restarted period of 30 days, the administrative forfeiture process will be perfected.

4. Once the Criminal Tax attorney receives a copy of the claim, the attorney should evaluate and process the case as a judicial forfeiture matter. Such processing involves the determination of whether a referral should be made to the Tax Division or US Attorney, as appropriate.


**38.1.3.4.3** **(08-11-2004)**

#### Documents Prepared For Proposed Title 18 and 31 Forfeitures

1. The Criminal Tax attorney shall submit a law and fact memorandum to the SAC in the field office with jurisdiction over the proposed forfeiture within 30 days of receipt, unless there is an earlier date by which legal action is required. If Counsel previously wrote a law and fact memorandum with regard to an administrative basis for the proposed forfeiture, and neither the facts nor Counsel’s views have changed, the prior law and fact memorandum may be resubmitted with a transmittal memorandum indicating that it represents Counsel’s views with regard to the propriety and advisability of judicial forfeiture. Copies of these documents, with attachments, will be sent to the Associate Chief Counsel (CT).

2. The law and fact memorandum should discuss the facts of the seizure (including a description of the nature and value of the property seized and the place(s) of seizure), the legal basis for the seizure and forfeiture, the sufficiency of the evidence needed to sustain the forfeiture, and any applicable Constitutional issues (e.g., due process claims, excessive fines, etc.).

3. The SAC, after considering Counsel’s advice, will refer the matter to the U.S. Attorney or, if deemed appropriate, take other action to return the seized property, or transfer it to another law enforcement agency. If requested, Counsel will prepare documents, such as a referral letter, to carry out the SAC’s decision.


**38.1.3.4.4** **(08-11-2004)**

#### Documents Prepared For Proposed Title 26 Forfeitures

1. The Criminal Tax attorney shall prepare a transmittal letter to the Tax Division for Code forfeitures other than those relating to IRC § 6050I violations or wagering exercise tax violations under IRC §§ 4401, 4411, or 4412. The letter should address the same discussion points as the above referenced law and fact memorandum and be forwarded to the Associate Chief Counsel (CT) for review and approval. Such approval will be sought in accordance with the procedures set out above. Once approved by the Associate Chief Counsel (CT), the Criminal Tax attorney shall mail the signed forfeiture package to the Tax Division. Forfeitures relating to IRC § 6050I violations, and wagering excise tax violations under IRC §§ 4401, 4411, or 4412, may be referred by the Area Counsel (CT) or delegate to the U.S. Attorney for the judicial district in which the seizure was made. A copy of the letter with attachments should be sent to the Associate Chief Counsel (CT) and to the SAC, Criminal Investigation.


**38.1.3.4.5** **(08-11-2004)**

#### Other Documents Prepared by Counsel Attorneys

1. In some judicial districts, the US Attorney may request that Counsel prepare forfeiture pleadings, including complaints, motions, and other pleadings. The Criminal Tax attorney should ascertain the expectation of the requesting US Attorney.

2. The Criminal Tax attorney may prepare a formal complaint, request for warrant to seize property, and a notice that the property has been seized for forfeiture. These documents are to be prepared in accordance with the Supplemental Rules for Certain Admiralty and Maritime Claims.


**38.1.3.5** **(08-11-2004)**

### Petitions for Remission or Mitigation of Forfeiture

1. Pursuant to 19 U.S.C. § 1618 for Titles 18 and 31, and IRC § 7327 and 26 C.F.R. § 403.35, et seq., for Title 26, any person claiming an interest in property seized by the Service subject to administrative forfeiture, may petition for remission or mitigation of the forfeiture of such property. Consideration and submission of petitions are governed by the Customs laws and regulations. The regulations describe in detail the necessary form, content, and timeliness of such petitions.

2. The Chief, Criminal Investigation and Director, Operations Policy and Support, Criminal Investigation, have been delegated the authority to allow or deny petitions for remission or mitigation of administrative forfeitures and to make the necessary notification to the petitioner or to authorize the SAC to notify the petitioner of the action taken on the petition.

3. In any case where judicial action will be necessary to perfect forfeiture, the petition for remission or mitigation must be forwarded to the US Attorney. 19 C.F.R. § 171.24(a).

4. The Associate Chief Counsel (CT) is the Chief Counsel executive responsible for advising the Chief, Criminal Investigation, or Director, Operations Policy and Support, Criminal Investigation, whether to allow or deny petitions for remission or mitigation and offers in compromise in administrative forfeiture cases. In judicial forfeitures, Counsel and Criminal Investigation should coordinate advice to the US Attorney, as appropriate.

5. The Criminal Tax attorney handling the initial forfeiture matter shall, within 15 days of receipt of the petition, transmit the petition or offer to the Associate Chief Counsel (CT) for action along with copies of the following material:




|  | (i) The underlying law and fact memorandum reflecting the original recommendation regarding forfeiture; |
| :-- | :-- |
|  | (ii) A copy of the search warrant or seizure warrant, if any; and |
|  | (iii) Any other documents and materials reflecting facts developed or conclusions reached in the investigation (pre- and post-seizure) that are pertinent to the forfeiture or to the sufficiency of the petition or offer. |



The Counsel attorney’s transmittal should comment on any matter the attorney deems pertinent to the resolution of the petition or offer.

6. The Associate Chief Counsel (CT), with the assistance of Headquarters attorneys, will prepare a law and fact memorandum to the Chief, Criminal Investigation recommending resolution of the petition or offer. Barring situations where the matter must be coordinated with the field or another division, the Associate Chief Counsel’s (CT) law and fact memorandum to the Chief, or Director, Operations Policy and Support, should be forwarded to Criminal Investigation within 30 days of receipt of the complete package from the field.

7. The Associate Chief Counsel (CT), with the assistance of Headquarters attorneys, will prepare any additional correspondence required, such as a memorandum for the signature of the Chief, Criminal Investigation, or Director, Operations Policy and Support, Criminal Investigation, advising the SAC of the action taken on the petition and the proposed letter to petitioner for the SAC’s signature. The letter should inform the petitioner that his/her petition has been granted or denied.


**38.1.3.6** **(08-11-2004)**

### Offers in Compromise

1. Offers in compromise are handled in the same manner as petitions for remission or mitigation of forfeiture. Refer to IRC § 7122 and the corresponding regulations for guidance on offers in compromise.


**38.1.3.7** **(08-11-2004)**

### Forfeiture Suspended

1. Where a petition or offer is submitted before the seized property has been sold or destroyed, proceedings to dispose of the property are suspended until the petition has been granted or denied or the offer accepted or rejected. _See_ 26 C.F.R. § 403.41.

2. Where a petition has been filed before the administrative forfeiture has been perfected, action to complete the perfecting process, including declaration of forfeiture if no timely claim (and cost bond in Title 26 forfeitures) is filed, will be pursued prior to action on the petition or offer. If the decision is made to return the property prior to perfection of forfeiture, this will be done pursuant to the SAC’s post-seizure quick release authority. Where a petition or offer is submitted pending judicial forfeiture, it will be forwarded to the US Attorney for appropriate action.


**38.1.3.8** **(10-03-2007)**

### Miscellaneous Matters

1. Seized Instruments. In the event a portion of the seized property consists of checks or other instruments such as money orders, bonds, cashier’s checks, or airline tickets, the Criminal Tax attorney should request Criminal Investigation have the drawee bank certify them. In a judicial forfeiture, the Criminal Tax attorney should also recommend to DOJ that the order of forfeiture be worded so that the checks are endorsed in the Government’s favor.

2. Department of Justice Policies. The Service follows DOJ’s aggregation rule when computing the value of seized property for purposes of determining whether the judicial forfeiture requirement is triggered: judicial forfeiture must be initiated if the property seizure has a common factual basis, legal authority, and common owner, and this aggregation exceeds the $500,000 (Title 18 forfeitures) or $100,000 (Title 26 forfeitures) threshold. Personal property constituting monetary instruments, as defined in 31 U.S.C. § 5312(a)(3), can be administratively forfeited without regard to value. Additionally, the policy requires judicial forfeiture of otherwise administratively forfeitable property seized in connection with property required to be judicially forfeited (e.g., furniture seized along with a house or office) in a consolidated proceeding.

3. Temporary Restraining Orders. Occasionally personal property, such as forfeitable funds located in accounts in financial institutions, is not presently seizable because evidence is still being developed to establish the probable cause necessary to obtain a seizure warrant, or because seizure authorization has not yet been obtained from the Department of the Treasury. To prevent such property from being moved, a temporary restraining order (TRO) pursuant to 18 U.S.C. § 983(j), may be utilized. _See also_ Fed. R. Civ. P. 65(b).



1. A TRO will freeze access to the property for a period of up to ten days, at which point the Government must show cause for the seizure at a hearing. The parties can extend the ten day period prior to the hearing.

2. TROs can be granted without notice to the account holder and without a hearing, if a clear showing is made by affidavit that immediate and irreparable injury, loss, or damage will result to the Government before a hearing can be granted, and if the Government attorney certifies in writing the efforts, if any, made to give notice, and the reasons for not giving notice.

3. Counsel’s assistance may be requested in preparing such affidavits.


4. Use of Grand Jury Information. In cases where the use of confidential grand jury information is anticipated (e.g., to support seizure of property subject to forfeiture or to sustain a judicial forfeiture), coordination with the US Attorney’s Office is required.

5. Disclosure Considerations. Access to and disclosure of return or return information is subject to limitations contained in IRC § 6103. Therefore, the Criminal Tax attorney must be alert to such issues, and should consult with Branches 6 and 7 in the office of the Associate Chief Counsel (Procedure & Administration).

6. Sealed Affidavits. Occasionally, Criminal Tax attorneys will be required to make recommendations concerning forfeiture matters in situations where a court has sealed the affidavit. The Criminal Tax attorney should discuss the forfeiture matter with the affiant and/or special agent assigned the case to determine the basis of the forfeiture action and should review Counsel files to see whether there is a related or associated matter that might provide insight into the forfeiture in question. The attorney’s recommendation should discuss the information relied upon in arriving at his/her recommendation.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part38/irm_38-001-003#addtoany "Show all")

A2A