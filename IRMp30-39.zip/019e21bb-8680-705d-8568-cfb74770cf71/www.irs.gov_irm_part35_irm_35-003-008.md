---
url: "https://www.irs.gov/irm/part35/irm_35-003-008"
title: "35.3.8 Motions in Declaratory Judgment Cases and Section 7436 Worker Classification Cases | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-003-008#main-content)

- 35.3.8 [Motions in Declaratory Judgment Cases and Section 7436 Worker ClassificationCases](https://www.irs.gov/irm/part35/irm_35-003-008#idm140407472355280)
  - 35.3.8.1 [Motions in EP Declaratory Judgment Cases](https://www.irs.gov/irm/part35/irm_35-003-008#idm140407497367136)
  - 35.3.8.2 [Motions in EO Declaratory Judgment Cases](https://www.irs.gov/irm/part35/irm_35-003-008#idm140407472787248)
  - 35.3.8.3 [Motions in Government Obligation Declaratory Judgment Cases](https://www.irs.gov/irm/part35/irm_35-003-008#idm140407462994048)
  - 35.3.8.4 [Motions in Worker Classification Cases under Section 7436](https://www.irs.gov/irm/part35/irm_35-003-008#idm140407463288352)

# Part 35. Tax Court Litigation

# Chapter 3. Motions

# Section 8. Motions in Declaratory Judgment Cases and Section 7436 Worker ClassificationCases

* * *

## 35.3.8 Motions in Declaratory Judgment Cases and Section 7436 Worker Classification Cases

**35.3.8.1** **(08-11-2004)**

### Motions in EP Declaratory Judgment Cases

1. Tax Court Rule 213 allows 45 days from the date of service of the petition within which to file a motion with respect to petition. As in all cases, however, jurisdictional motions may be made at any time. Before considering jurisdictional motions in these cases, the following statutory elements under section 7476 should be considered.

2. Section 7476 requires that an applicant must exhaust its administrative remedies by taking all reasonable steps to obtain a determination. These steps include (1) the filing of a substantially complete appropriate form; (2) timely submitting all additional information requested by the Service, and (3) taking all administrative appeals available within the Service. Treas. Reg. § 601.201(o)(10); Rev. Proc. 83–36, 1983–1 C.B. 763, modified by Rev. Proc. 88–8, 1988–1 C.B. 628.

3. A petitioner is not deemed to have exhausted its administrative remedies merely because the Service has failed to make a determination before the 270th day following the request for such determination. The 270-day period of section 7476(b)(3) is a minimum period, enabling respondent to consider ruling requests without judicial interference. The Tax Court has held that in revocation cases, the 270-day period begins when the organization protests the Service’s proposed adverse ruling. If a delay is caused by petitioner’s unresponsiveness or if the administrative procedure is still actively in process, the petitioner may not have exhausted its administrative remedies. The exhaustion requirement promotes the completeness of the administrative record. _See Halliburton v. Commissioner_, 98 T.C. 88 (1992).

4. A petitioner who sues as an interested party must have exhausted administrative remedies by filing a comment with the Service during the administrative process. If the petitioner fails to file such a comment because petitioner never received the required notice of application, the court will deem the requirement met. Where a comment was filed, the petitioner may raise only those issues contained in the comment. _See_ Treas. Reg. § 601.201(o)(5) regarding the administrative remedies of interested parties.

5. A motion to dismiss for lack of jurisdiction and to strike for failure to exhaust administrative remedies is in order if the petitioner seeks to raise a new basis for qualified status in its petition.

6. Other Motions in EP Declaratory Judgment Cases. Pursuant to T.C. Rule 215(a), a joinder of parties is permitted in section 7476 declaratory judgment actions brought by interested parties pursuant to T.C. Rule 211(c)(4). The employer should always be joined as an indispensable party. _See_ Exhibit 35.11.1–66, Motion for Joinder of Additional Parties. Consolidation under T.C. Rule 141 permits the court to order a joint hearing of any common questions of law or fact; orders of this kind may be made by the court if they tend to prevent unnecessary costs, delays, or duplication. The consideration of whether to move to consolidate separate actions brought under section 7476 will have to be made on a case by case basis; however, the court will not ordinarily consolidate a deficiency case with a declaratory judgment case. When the same questions of law are raised in a declaratory judgment action and a deficiency action, consideration may be given to filing a motion to stay one action pending the outcome of the other, or to stipulating to be bound to the outcome of one or the other case or issue in the case.

7. Pursuant to section 7476(b)(4), the Field attorney should make sure that the plan and/or amendments discussed in the petition have been put into effect prior to the date of the petition; otherwise, the attorney should move to dismiss the case or strike the applicable portions of the petition for lack of jurisdiction. _Arthur Sack, Pension Paperwork, Inc. v. Commissioner_, 82 T.C. 741 (1984).

8. The following are some of the jurisdictional defects which should be raised by motion. Jurisdiction motions are appropriate at any time. However, in practice where possible they should be made within 45 days after service of the petition.



1. Untimely petition. Declaratory judgment actions pursuant to section 7476(a)(5) require that the pleading be filed before the ninety-first day after the day after the notice is mailed. _See Flight Attendants Against UAL Offset v. Commissioner_, 165 F.3d 572 (7th Cir. 1999). If the petition is not timely filed, a motion to dismiss for lack of jurisdiction should be filed.

2. No determination. If no determination has been made regarding the qualification or classification of the plan, and the petition is filed within 270 days after the request for determination, a motion to dismiss for lack of jurisdiction is proper. _See_ section 7476(b)(3).

3. Actual controversy. If there is no bona fide controversy between the Service and the petitioner over the Commissioner’s determination, or lack thereof, with respect to the initial or continuing qualification of a retirement plan, then a motion to dismiss for lack of jurisdiction should be filed. An actual controversy exists within the meaning of section 7476(a) in a revocation case if at least one consequential notice of deficiency has been or is being issued to the related trust, sponsoring employer, or plan participant for a year in which the plan is not qualified.

4. Exhaustion of administrative remedies. The Tax Court does not have jurisdiction unless the petitioner has exhausted its administrative remedies. _See_ section 7476(b)(3). The requirements for exhausting administrative remedies (listed in Treas. Reg. § 601.201(n)(7)) are (i) the filing of a substantially completed application form; (ii) the timely submission of all additional information requested by the Service; and (iii) the exhaustion of all administrative appeals within the Service.

5. If 270 days have elapsed from the date the application for a determination was filed, and all reasonable steps have been take to secure a determination in a timely manner (including allowing the Service a reasonable time to act upon the appeal or request, as the case may be), but the Service has failed to issue a final letter, the organization is deemed under section 7476(b)(3) to have exhausted its administrative remedies.

6. Proper petitioner. A petition may be filed only by the parties identified in section 7476(b)(1). The Field attorney should move to dismiss a petition filed by any other party. A section 7476 declaratory judgment action may be petitioned by an interested party. Interested parties are defined in Treas. Reg. §1.7476–1(b). A motion to dismiss for lack of jurisdiction should be made if an interested party petitioner does not satisfy the appropriate regulatory criteria. _See Flynn v. Commissioner_, 269 F.3d 1064 (D.C. Cir. 2001).

7. New basis for qualification. The petitioner may not raise issues for the first time in the petition. The petitioner has not exhausted its administrative remedies with regard to such issues and the court lacks jurisdiction over them.


**35.3.8.2** **(08-11-2004)**

### Motions in EO Declaratory Judgment Cases

1. The following are some of the jurisdictional defects which should be raised by motion in litigating declaratory judgment cases under section 7428. Although jurisdictional motions may be filed at any time, if possible such motions should be filed within 45 days after service of the petition.



1. Untimely Petition. If the petition is not filed before the 91st day after the mailing of the final adverse determination letter, a motion to dismiss for lack of jurisdiction should be filed.

2. No Determination. If no determination has been made regarding the qualification or classification of the organization and the petition is filed within 270 days after the request for the determination, a motion to dismiss for lack of jurisdiction is proper.

3. Actual Controversy. If there is no bona fide controversy between the Service and the petitioner over the Commissioner’s determination, or lack therof, with respect to the initial or continuing qualification or classification of an organization as an organization described in section 501(c)(3) or section 170(c)(2); a private foundation under section 509(a); or a private operating foundation under section 4942(j)(3), then a motion to dismiss for lack of jurisdiction should be filed. _See, however, Friends of the Society of Servants of God v. Commissioner_, 75 T.C. 209 (1980).


2. Exhaustion of Administrative Remedies. The Tax Court does not have jurisdiction unless the petitioner has exhausted its administrative remedies. The requirements for exhausting administrative remedies listed in Rev. Proc. 84–46, 1984–1 C.B. 541, and Treas. Reg. § 601.201(n)(7) are:



1. The filing of a substantially completed application form;

2. The timely submission of all additional information requested by the Service;

3. Exhaustion of all administrative appeals within the Service;

4. Appeal of a proposed adverse ruling to the Exempt Organizations Conference and Review Staff in Associate office jurisdiction cases.


3. If 270 days have elapsed from the date the organization filed a substantially completed application form and the organization has taken in a timely manner all reasonable steps to secure a ruling or determination (including allowing the Service a reasonable time to act upon the appeal or request for consideration, as the case may be), but the Service has failed to issue a notice of final determination, the organization is deemed under section 7428(b)(2) to have exhausted its administrative remedies.

4. Proper Petitioner. A petition may be filed only by the organization whose qualification or classification is at issue. The Field attorney should move to dismiss a petition filed by any other party.

5. New basis for exemption. The petitioner may not raise issues for the first time in the petition. The petitioner has not exhausted its administrative remedies with regard to such issues and the court lacks jurisdiction over them.

6. For an example of a jurisdictional motion in an EO declaratory judgment case, _see_ Exhibit 35.11.1–67.

7. Other papers in EO declaratory judgment cases:



1. Motion to Strike Facts Outside the Record — CCDM 35.2.2.9(4); CCDM 35.2.2.9.2(8).

2. Motion to Extend Time to Stipulate to Administrative Record — CCDM 35.2.2.9(8); Exhibit 35.11.1–68.

3. Notice of Filing of the Administrative Record and Commissioner’s Certificate as to the Genuineness of the Entire Administrative Record — CCDM 35.2.2.9(9); CCDM 35.2.2.9.2(12); Exhibit 35.11.1–28.

4. T.C. Rule 212 statement on time for submission — _See_ CCDM 35.2.2.9.2(7).

5. Letter regarding stipulation to administrative record — _See_ CCDM 35.2.2.9.2(11).

6. Stipulation as to the Administrative Record — _See_ CCDM 35.2.2.9.2(12); Exhibit 35.11.1–27.

7. Motion to Submit the Case on the Record (T.C. Rule 122 Motion) — _See_ CCDM 35.2.2.9.2(13); Exhibit 35.11.1–58.

8. Motion for Order to Show Cause why Case Should Not be Submitted on the Administrative Record — _See_ CCDM 35.2.2.9.2(14); Exhibit 35.11.1–69.


**35.3.8.3** **(08-11-2004)**

### Motions in Government Obligation Declaratory Judgment Cases

1. See the discussion in CCDM 35.2.2.9.3 for various pleadings and motions that may be filed in government obligation declaratory judgment cases.


**35.3.8.4** **(08-11-2004)**

### Motions in Worker Classification Cases under Section 7436

1. Before considering jurisdictional motions in litigating worker classification cases under section 7436, the following statutory elements should be considered. See CCDM 35.2.1.1.15.4 for material on initial review of such cases.

2. Section 7436(a) provides the Tax Court with jurisdiction to review only the three employment tax determinations listed in the statute-worker classification, section 530 treatment, and proper amount of employment tax. Note that the proper amount of employment tax includes additions to tax, additional amounts, and penalties that relate to the employment tax. See CCDM 35.1.1.18.4 for more discussion. The procedures set forth in section 7436 do not apply to worker classification issues not arising under Subtitle C, such as the classification of individuals for purposes of pension plan coverage or the proper treatment of individual income tax deductions. Nor is Tax Court review available when there is no controversy with respect to the classification of workers, such as where the taxpayer itself treated the workers as employees by filing Forms W-2 (Wage and Tax Statements). Additionally, since section 7436(a) only confers jurisdiction upon the Tax Court to review determinations that are made by the Service as part of an examination, other Service determinations of worker classification (including those that are made in the context of private letter rulings, technical advice memoranda, or Forms SS-8, Determination of Employee Work Status for Purposes of Federal Employment Taxes and Income Tax Withholding) that are not made as part of an examination are not subject to review by the Tax Court under section 7436(a).

3. Because the notice of determination of worker classification constitutes the Service’s determination described in section 7436(a), the notice of determination of worker classification is a jurisdictional prerequisite for seeking Tax Court review of the Service’s determinations regarding worker classification, section 530 treatment, and the proper amount of employment tax under those determinations. Tax Court proceedings seeking review of these determinations may not be commenced prior to the time the Service sends the notice of determination of worker classification by certified or registered mail.

4. Section 7436(b)(2) provides that a taxpayer’s petition for review must be filed with the Tax Court before the 91st day after the Service mails its notice of determination of worker classification by certified or registered mail. On the first page of the notice of determination of worker classification, the Service will specify the last date by which the taxpayer may timely file a petition in the Tax Court.

5. A taxpayer who does not file a Tax Court petition within the allotted time retains the right to seek judicial review of the Service’s determinations by paying the tax and filing a claim for refund, as required by section 7422. If the claim for refund is denied, or if after six months the Service has not responded to the claim for refund, the taxpayer may file a refund suit in a district court or the Court of Federal Claims.

6. Section 7436(b)(1) provides that a pleading seeking Tax Court review of the Service’s determinations may be filed only by the person for whom the services are performed. Thus, a worker may not be a petitioner under section 7436. _See also_ CCDM 35.1.1.18.4.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-003-008#addtoany "Show all")

A2A