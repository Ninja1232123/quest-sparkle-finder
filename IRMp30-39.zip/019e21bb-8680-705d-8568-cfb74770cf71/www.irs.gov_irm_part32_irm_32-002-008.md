---
url: "https://www.irs.gov/irm/part32/irm_32-002-008"
title: "32.2.8 Publication | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part32/irm_32-002-008#main-content)

- 32.2.8 [Publication](https://www.irs.gov/irm/part32/irm_32-002-008#idm140236010288496)
  - 32.2.8.1 [Submission to the Bulletin Unit](https://www.irs.gov/irm/part32/irm_32-002-008#idm140236051945360)
  - 32.2.8.2 [Congressional Review of Rules](https://www.irs.gov/irm/part32/irm_32-002-008#idm140236018130000)
  - 32.2.8.3 [Processing Material](https://www.irs.gov/irm/part32/irm_32-002-008#idm140236027471088)
  - 32.2.8.4 [Early Release of a Publication](https://www.irs.gov/irm/part32/irm_32-002-008#idm140236052119728)

    - 32.2.8.4.1 [News Releases](https://www.irs.gov/irm/part32/irm_32-002-008#idm140236023666656)
    - 32.2.8.4.2 ["Drop" or "Early Drop" of a Publication](https://www.irs.gov/irm/part32/irm_32-002-008#idm140236052080384)

  - 32.2.8.5 [Ministerial Publication Procedures, "Waiver of Clearance "](https://www.irs.gov/irm/part32/irm_32-002-008#idm140236011781856)
  - 32.2.8.6 [Processing Public Comments](https://www.irs.gov/irm/part32/irm_32-002-008#idm140236018721072)
  - 32.2.8.7 [Mass Obsoleting of Revenue Rulings/Procedures](https://www.irs.gov/irm/part32/irm_32-002-008#idm140236010001936)
  - Exhibit 32.2.8-1 [Submission of Federal Rules under the Congressional Review Act](https://www.irs.gov/irm/part32/irm_32-002-008#idm140236010484176)
  - Exhibit 32.2.8-2 [Instructions for Completing Congressional Review Act Form](https://www.irs.gov/irm/part32/irm_32-002-008#idm140236030372416)
  - Exhibit 32.2.8-3 [Procedures for Release of Guidance to the News Media (Drops)](https://www.irs.gov/irm/part32/irm_32-002-008#idm140236020800496)
  - Exhibit 32.2.8-4 [Format for Request for Early Release of a Publication](https://www.irs.gov/irm/part32/irm_32-002-008#idm140236018262480)
  - Exhibit 32.2.8-5 [Pattern Revenue Ruling Obsoleting Multiple Revenue Rulings](https://www.irs.gov/irm/part32/irm_32-002-008#idm140236013860016)

# Part 32. Published Guidance and Other Guidance to Taxpayers

# Chapter 2. Chief Counsel Publication Handbook

# Section 8. Publication

* * *

## 32.2.8 Publication

#### Manual Transmittal

April 14, 2017

#### Purpose

(1) This transmits revised CCDM 32.2.8, Chief Counsel Publication Handbook; Publication.

#### Background

This material is being revised to implement recommendations made by the Government Accountability Office for improvement of the regulatory guidance process.

#### Material Changes

(1) CCDM 32.2.8.2 was revised to clarify procedures for ensuring congressional review of revenue rulings, revenue procedures, notices, and announcements where required by the Small Business Regulatory Enforcement Fairness Act of 1996 (SBREFA).

#### Effect on Other Documents

CCDM 32.2.8, dated September 23, 2011, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(04-14-2017)

Kathryn A. Zuba

Acting Associate Chief Counsel

(Procedure & Administration)

**32.2.8.1** **(09-23-2011)**

### Submission to the Bulletin Unit

01. When all clearances have been obtained, the proposed publication item is ready for publishing in the IRB.

02. The submission to the Bulletin Unit includes the following:



    - The signed Form 12971 or macro

    - Two copies of the proposed publication

    - A completed Form 12972 or macro

    - Any cross-reference sheets (see Exhibit 32.2.3-8, Format for Typed Draft Cross-Reference Sheet)

    - An electronic copy of the proposed publication


03. Prior to submitting the package to the Bulletin Unit for publication, the drafting attorney will prepare the report to GAO and Congress. See CCDM 32.2.8.2.

04. The drafting attorney is also responsible for removing all "hidden" codes from the word processing files of the document submitted to the Bulletin Unit to prevent readers from viewing prior changes to the document.

05. Instructions for removing hidden codes.



    1. Microsoft Word documents: Pull up the approved version of the document, which reflects all changes to the document.

    2. On the eWord Toolbar: Select **Purge**.

    3. When the Purged Data Report message window appears, click **OK.**

       The purged document will be displayed and stored in the same directory as the original file. The purged document’s filename will be the same as the original file with "(checked)" added. For example, RR-XXXXXX-XX (checked).doc.


06. After removing any hidden codes, the drafting attorney prepares the package for submission to the Bulletin Unit. The copies of the publication submitted to the Bulletin Unit must not contain the control (CASE-MIS) number, the draft date, or printer’s footnotes. When using the eWord Chief Counsel MACROs, the control number and draft date will be deleted from the final version of the publication item when the drafting attorney submits the publication item to Counsel’s content management system (Documentum).

07. Instructions for removing control number and draft date. Once the publication item is ready to be submitted to the Bulletin Unit, the drafting attorney should:



    1. Select the **Submit** button on the eWord toolbar.

    2. Documentum will delete the first line of the document, including the CASE-MIS number and draft date, from the document and rename the file using the CASE-MIS number.

    3. The drafting attorney should print this document and provide the printed document to the Bulletin Unit.

    4. Additionally, Documentum will create an XML file containing the publication item and send the drafting attorney an email, shortly after submission, advising the drafting attorney how that file can be retrieved.

    5. The XML file can be provided electronically to the Bulletin Unit (All documents printed in the IRB are converted to XML prior to publication. If Counsel does not provide an XML file, the Bulletin Unit must transcribe the file. Thus, sending the XML file electronically will save the Bulletin Unit processing time).

    6. Questions on this process may be forwarded to the Macro development team at Macro.Inbox@irscounsel.treas.gov


08. The assigned reviewer in the Associate Office is responsible for ensuring that the final proposed publication reflects the changes recommended at the various levels of review and that the submission package is complete (including the index and highlight entries on Form 12972). Once the assigned reviewer approves, the reviewer will sign Form 12971. If the index or highlight entries on Form 12972 are not completed, the Bulletin Unit will return the form to the drafting attorney to complete those sections of the form.

09. The Associate office forwards the submission package to the Bulletin Unit (Room 6516).

10. Manuscripts for the IRB must be prepared using Microsoft Word, the standard word processing application for all of the Office of Chief Counsel. The Bulletin Unit is authorized to return any manuscript to the drafting attorney if the material does not meet the standards of acceptability for submission to the printer.

11. When the Associate office forwards the submission package to the Bulletin Unit (or to Media Relations for an early drop, see CCDM 32.2.8.4.2), the Associate office should inform the following addresses by email of the pending publication:



    - The Chief Counsel

    - The Deputy Chief Counsel

    - All Special Counsel, Senior Counsel, and Senior Legal Counsel to the Chief Counsel

    - All Associate Chief Counsel and Deputy Associate Chief Counsel (using "&NO-ALL ACC and DACC" in the "To:" field)

    - The Tax Legislative Counsel (or Benefits Tax Counsel or International Tax Counsel, as appropriate)

    - Any other Treasury representatives involved in the project

    - Any other recipients determined by the Associate office


**32.2.8.2** **(04-14-2017)**

### Congressional Review of Rules

01. The Small Business Regulatory Enforcement Fairness Act of 1996 (SBREFA) added chapter 8 to title 5, United States Code (Congressional Review Act). The Congressional Review Act (CRA) provides that no final rule can become effective until the issuing agency submits a report containing certain information to the House of Representatives, the Senate, and the Comptroller General of the GAO.

02. The Service meets its Congressional Review Act notice requirement by submitting a Submission of Federal Rules Under the Congressional Review Act Form (see Exhibit 32.2.8-1 for a sample CRA form and Exhibit 32.2.8-2 for instructions for completing the CRA form), the rule, and other attachments, to Congressional and GAO representatives. The drafting attorney must complete the CRA form. The Publications and Regulations Branch arranges delivery of CRA forms, with attachments, to the House of Representatives, the Senate, and the Comptroller General of the GAO within one business day of receipt.



    ### Note:



    No publication should be delivered for publication until a completed report is prepared and approved.

03. A rule is defined by SBREFA as the whole or a part of an agency statement of general or particular applicability and future effect designed to implement, interpret, or prescribe law or policy or describing the organization, procedure, or practice requirements of an agency. SBREFA provides specifically that the following are not rules for purposes of the congressional review procedures:



    - Any rule of particular applicability

    - Any rule relating to agency management or personnel

    - Any rule of agency organization, procedure, or practice that does not substantially affect the rights or obligations of nonagency parties.


04. Revenue rulings, revenue procedures, notices, and announcements that are rules under the SBREFA must be submitted for congressional review before they can become effective. Whether a revenue ruling, revenue procedure, notice, or announcement is considered a rule subject to reporting is determined on a case-by-case basis. Ministerial revenue rulings and revenue procedures; notices and announcements relating to error corrections, personnel matters, or proposed rules; and press releases generally will not be considered rules under SBREFA.

05. The determination that a revenue ruling, revenue procedure, notice, or announcement is or is not a rule under the SBREFA must be documented in the legal file.

06. The drafting attorney must prepare the following and deliver them to the Publications and Regulations Branch (CC:PA:LPD:PR), room 5203, before 11 a.m. on the earliest of the date that the rule is released to the tax services, published in the IRB, or otherwise made available to the public. Four CRA reports, each report consisting of the following documents in the order listed (from top to bottom):



    - The completed CRA form

    - A copy of a concise summary of the rule

    - An unsigned copy of the final version of the rule

    - For the GAO package only, if the rule is a major rule, a copy of the cost benefit analysis


07. These four CRA reports are for:



    - President, United States Senate

    - Speaker, United States House of Representatives

    - General Counsel, GAO

    - Publications and Regulations Branch files


08. For the first three listed recipients of the CRA reports, type the recipient’s name and title in the upper right corner of the CRA form for that recipient.

09. Five additional copies of the completed CRA form (without the concise summary or a copy of the rule). Type each recipient’s name and title in the upper right corner of each of these five CRA forms. These five recipients (courtesy copy recipients) receive only a copy of the CRA form, without the rule or concise summary. These five CRA forms are for:



    - Chairman, Committee on Ways and Means

    - Ranking Minority Member, Committee on Ways and Means

    - Chairman, Committee on Finance

    - Ranking Minority Member, Committee on Finance

    - Chief of Staff, Joint Committee on Taxation


10. Each day, the Publications and Regulations Branch prepares an "Acknowledgment of Receipt" form (original and two copies), listing the documents being submitted under the CRA, for each of the following: (1) President, United States Senate, and (2) Speaker, U.S. House of Representatives. By 2:00 p.m. the Publications and Regulations Branch delivers the Acknowledgments of Receipt (original and one copy) and the listed CRA reports (Acknowledgment of Receipt packages) for the President, U.S. Senate, and the Speaker, U.S. House of Representatives, to the IRS Legislative Affairs office. Personnel in the IRS Legislative Affairs office deliver the CRA reports to those Congressional offices (usually within one business day) and get a representative of each of those Congressional offices to sign the Acknowledgment of Receipt forms. IRS Legislative Affairs returns the signed Acknowledgment of Receipt forms to the Publications and Regulations Branch box in the Office of IRS Legislative Affairs.

11. The Publications and Regulations Branch maintains records of all CRA submissions and signed Acknowledgment of Receipt forms, and follows up with the IRS Legislative Affairs office on any outstanding Acknowledgment of Receipt forms.

12. The Publications and Regulations Branch sends a CRA package to the General Counsel, GAO.

13. The Publications and Regulations Branch faxes the CRA forms to the offices of the five courtesy copy recipients and verifies that each fax confirmation shows that the submission was properly transmitted in its entirety.

14. The Publications and Regulations Branch sends both signed Acknowledgment of Receipt forms (signed by the offices of the President, United States Senate, and the Speaker, U.S. House of Representatives), to the drafting attorney to retain in the publication’s background file. If an Acknowledgment of Receipt form lists more than one CRA report, the Publications and Regulations Branch sends the original signed form to the drafting attorney for the first listed document and a copy of the signed form to the drafting attorney for each other CRA report listed on the form. The Publications and Regulations Branch retains a copy of each signed Acknowledgment of Receipt form and a copy of each related CRA report. The Publications and Regulations Branch also sends the Acknowledgement of Receipt form signed by the Office of the General Counsel, GAO to the drafting attorney for retention in the publication’s background file, and retains a copy together with the related CRA report, in the Publications and Regulations Branch files.

15. It is the responsibility of the drafting attorney to ensure that the Acknowledgment of Receipt forms are placed in the regulation’s legal file. If the attorney does not receive the acknowledgments within 10 days of delivering the CRA form to the Publications and Regulations Branch, the attorney should follow up with the Publications and Regulations Branch to determine status of the forms and to verify the CRA reports were submitted. It is critical that the acknowledgments are retained in the event there is any question over whether the IRS complied with the CRA.

16. Additional information about the CRA is available at [http://www.gao.gov/legal/congressact/congress.html](http://www.gao.gov/legal/congressact/congress.html). For a copy of the CRA Form, see Exhibit 32.2.8-1.


**32.2.8.3** **(09-23-2011)**

### Processing Material

1. The Bulletin Unit prepares the proposed publication for printing. When appropriate, the Bulletin Unit may ask the Associate office to do a proof check of the manuscript and the IRB highlights before it goes to the printer.

2. Publication timetable. There is a normal period of approximately 3 weeks between the time a publication is received by the Bulletin Unit and its publication in the IRB. In extraordinary circumstances, it is possible for a publication to be published in less time than the normal 3 week time period.


**32.2.8.4** **(09-23-2011)**

### Early Release of a Publication

1. In almost all cases it is desirable to release a publication prior to publishing in the IRB. Accordingly, the proposed publication should be prepublished (that is, made public by or in a news release or by way of an "early drop" before it is published in the IRB). If Media Relations or higher level official feels that a news release is unnecessary, an advance copy of a publication may be provided to the commercial tax services through the Media Relations office with a notation as to which IRB it will appear in. This latter procedure is commonly referred to as a "drop" or "early drop" . See CCDM 32.2.8.4.2. In certain instances, the release of a publication through commercial tax services is not feasible, for example, when a legal effective date is tied to the date of the publication or when publication will affect market conditions. A decision to not release a publication in advance of appearing in the IRB must be approved by an Associate Chief Counsel.


**32.2.8.4.1** **(08-11-2004)**

#### News Releases

1. Most news releases involving issues within the jurisdiction of the Associate Chief Counsel are used to release to the public a publication and contain no more than a plain-language statement of the information being published and a reference to the IRB in which the publication will appear. The drafting attorney should contact the Media Relations office at least one week before the anticipated release of the publication and work with that office in the preparation of the news release.

2. See Exhibit 32.2.3-7, Format for Typed Draft of Proposed News Release, for a sample news release.

3. A news release may be appropriate if the publication:



   - Has a broad target audience

   - Has high popular interest

   - Will be a controversial media issue

   - Will require a significant education or compliance effort


**32.2.8.4.2** **(09-23-2011)**

#### "Drop" or "Early Drop" of a Publication

1. This procedure provides advance copies of the publication to the commercial tax services through the Media Relations office (see Exhibit 32.2.8-3)

2. After all approvals to publish have been secured, the drafting attorney prepares a form, Request for Advance Release of IRB Item to the News Media (see Exhibit 32.2.8-4).

3. The drafting attorney emails an electronic version of the publication to Media Relations. It is very important that the drafting attorney purge the electronic version of the publication of any hidden codes before submitting the proposed publication to Media Relations. See CCDM 32.2.8.1(5) for instructions on how to remove hidden codes from the electronic version submitted to Media Relations. In addition, the electronic version and the copies of the publication to be dropped must _not_ contain the control number, the draft date, or printer’s footnotes. See CCDM 32.2.8.1(7) for instructions on how to remove the control number and draft date if using the eWord Chief Counsel MACROs. The copies _must_, however, contain the publication number.

4. The electronic version of the publication should be emailed to Media Relations and the form should be delivered to the office listed in Exhibit 32.2.8-3. Media Relations disseminates at 10 AM and 2 PM and needs the materials at least 90 minutes before release. Because of processing issues, releases after 2 PM are burdensome for both the Service and the media and are done in only rare, emergency situations.


**32.2.8.5** **(08-11-2004)**

### Ministerial Publication Procedures, "Waiver of Clearance "

1. General — Certain proposed publications involving only ministerial matters (such as, applicable federal interest rates and monthly bond factor amounts) may be published without referral to the Chief Counsel, Commissioner, and, in most cases, without referral to Treasury. The branch should consult the Techmis IRS/Treasury Business Plan Appendix-Ministerial Rulings report to determine whether, and to what extent, approval may be waived for a publication item.

2. After the review and approval of a proposed ministerial publication by the Associate Chief Counsel, the branch will prepare the publication package for submission to the Bulletin Unit for publication.


**32.2.8.6** **(08-11-2004)**

### Processing Public Comments

1. On occasion, the public is offered the opportunity to provide comments on proposed publications, usually proposed revenue rulings or proposed revenue procedures. The drafting attorney will consider any comments received during the development of the proposed publication.

2. When a request for comments is solicited (for example, in a notice or announcement) interested persons should be given the following information on how to submit comments:




|  |
| --- |
| Mail | Internal Revenue Service<br>CC:PA:LPD:RU (Notice 200x-xx), Room 5203<br>P.O. Box 7604<br>Ben Franklin Station<br>Washington, DC 20044 |
| Hand Delivery<br>8:00 a.m. — 4:00 p.m. | CC:PA:LPD:RU (Notice 200x-xx)<br>Courier’s Desk<br>Internal Revenue Service<br>1111 Constitution Avenue, NW<br>Washington, DC 20224 |
| Email | Notice.Comments@irscounsel.treas.gov |





### Note:



Commenters should be instructed to include the identification number of the publication in both the body of the comment and on the email subject line.

3. When considering public comments, steps should be taken to identify the source and content of the comments in materials that are reviewed, when appropriate. For example, it may be appropriate to make an entry in the BIN to reflect public comments that are considered in the development of the project.


**32.2.8.7** **(08-11-2004)**

### Mass Obsoleting of Revenue Rulings/Procedures

1. The Service has a continuing program to review its publications in order to identify and publish lists of those publications that, although not specifically revoked or superseded, are no longer determinative because:



1. The applicable statutory provisions or regulations have been changed or repealed

2. The ruling position is specifically covered by statute, regulation, or subsequent published position

3. The facts set forth no longer exist or are not sufficiently described to permit clear application of the current statute and regulations


2. Exhibit 32.2.8-5 provides a pattern for use in obsoleting these publications.


**Exhibit 32.2.8-1**

### Submission of Federal Rules under the Congressional Review Act

![This is an Image: 39009003.gif](https://www.irs.gov/pub/xml_bc/39009003.gif)

> This is the first page of the Submission of Federal Rules under the Congressional Review Act form.

[Please click here for the text description of the image.](https://www.irs.gov/media/157641 "")

![This is an Image: 39009004.gif](https://www.irs.gov/pub/xml_bc/39009004.gif)

> This is page 2 of the Submission of Federal Rules under the Congressional Review Act form.

[Please click here for the text description of the image.](https://www.irs.gov/media/157646 "")

**Exhibit 32.2.8-2**

### Instructions for Completing Congressional Review Act Form

|  |
| --- |
| **INSTRUCTIONS FOR COMPLETING CONGRESSIONAL REVIEW ACT FORM** |
| Rev. 6-3-2003 |
| All CRA forms and packages are due to the Regulations Unit before 11:00 a.m. on the date the rule is issued (the date a TD is filed at the OFR). |
|  |
| **Instructions for Completing the 1st Page of the Congressional Review Act (CRA) Form:** |
| Select President of the Senate, Speaker of the House of Representatives, or GAO. Prepare a CRA form for each one. |
| 1\. Name of Department or Agency — Department of the Treasury |
| 2\. Subdivision or Office — Internal Revenue Service |
| 3\. Rule Title — State the Rule Title exactly as it appears on the rule. If the rule does not contain a title, the attorney should create a brief descriptive title. Do not include the RIN, TD number, Rev. Rul. or Rev. Proc. number, etc. in the title. |
|  | EXAMPLES:<br>- TD: Substantiation of Incidental Expenses<br>  <br>- Revenue Ruling: Advance Reimbursements of Medical Expenses<br>  <br>- Revenue Procedure: Cost-of-Living Adjustments for 2011<br>  <br>- Notice: Liberty Zone Advance Refund Notice<br>  <br>- Announcement: Announcement and Report Concerning Advance Pricing Agreements<br>  <br>- Action on Decision: Action on Decision — Robert L. Beck v. Commissioner<br>  <br>- Appeals Settlement Guidelines: Appeals Settlement Guidelines —Construction/Real Estate — Per Diem Allowances for Temporary Technical Service Employees<br>  <br>- Coordinated Issue Paper: Coordinated Issue — Intermediary Transaction Tax Shelters<br>  <br>- Market Segment Specialization Paper: Audit Technique Guide — Farming — Specific Income Issues and Farm Cooperatives |
| 4\. Regulation Identification Number (RIN) or Other Unique Number (if applicable) |
|  | TDs: |
|  |  | Use the Regulation Identification Number (RIN) and the Treasury decision (TD) number. Place the TD number in parentheses following the RIN. If submitting multiple actions under one RIN, add information that identifies each action. |
|  | Other than TDs: |
|  |  | Use the agency’s unique identification number, such as the revenue ruling number, revenue procedure number AOD number, etc. Do not include the IRB citation.<br>If there is no agency unique identification number, leave blank. Do not use a CASE-MIS ID number or a Uniform Issue List (UIL) number. |
|  | EXAMPLES:<br>- TD: RIN 1545-BBI9 (TD 9020)<br>  <br>- Revenue Ruling: Rev. Rul. 2010-80<br>  <br>- Revenue Procedure: Rev. Proc. 2010-70<br>  <br>- Notice: Notice 2010-73<br>  <br>- Announcement: Announcement 2010-40<br>  <br>- Action on Decision: AOD 2010-5<br>  <br>- Appeals Settlement Guidelines: Leave blank<br>  <br>- Coordinated Issue Paper: Leave blank<br>  <br>- Market Segment Specialization Papers: Leave blank |
| 5\. Major Rule — Indicate whether the rule is designated as a "major" or "non-major" rule pursuant to the CRA |
|  | A major rule is a rule that is likely to result in:<br>1. An annual effect on the economy of $100,000,000 or more;<br>   <br>2. A major increase in costs or prices for consumers, individual industries, Federal, State, or local government agencies, or geographic regions; or<br>   <br>3. Significant adverse effects on competition, employment, investment, productivity, innovation, or on the ability of US-based enterprises to compete with foreign-based enterprises in domestic and export markets. |
|  |  | If the rule is a "major rule" , pursuant to 5 U.S.C 801, the effective date of the rule cannot be earlier than 60 days after the rule is delivered to the House, Senate and the GAO. |
|  | IRS rules are rarely major rules because the effect of most IRS rules is due to the underlying statute, rather than to the regulation. See CCDM 32.1.6.11.2.5(12), Congressional Review Act Forms. Consult the Chief, Regulations Unit, before responding that the document is a major rule. |
|  | A non-major rule is a rule that is not a major rule. Almost all IRS documents are non-major rules. |
| 6\. Final Rule — A final rule amends the Code of Federal Regulations (CFR). |
|  | TDs: |
|  |  | Answer "Final Rule." |
|  | Other than TDs: |
|  |  | Answer "Other." <br>Further, for non-regulation published guidance documents (for example, revenue rulings, revenue procedures, and notices), also type "IRB ONLY" in the space provided. |
| 7\. Public Comments — If the agency solicited public comments (for example, by publishing a prior ANPRM or NPRM, Notice, by holding a public hearing or meeting, by taking a survey, or by conducting an advisory committee hearing) respond "Yes." Otherwise, respond "No." |
| 8\. Priority of Regulation |
|  | TDs: |
|  |  | Indicate the priority to which the regulation was, or will be, assigned in the Semiannual Agenda (see below). Most IRS regulations are categorized as "Substantive, Nonsignificant." |
|  |  | A regulation is ECONOMICALLY SIGNIFICANT if is it expected to have an annual effect on the economy of $100,000,000 or more or will adversely affect in a material way the economy; a sector of the economy; productivity, competition; jobs; the environment, public health or safety; or State, local, or tribal governments or communities. This definition is similar, but not identical, to the definition of a major rule (above). |
|  |  | A regulation is SIGNIFICANT if it is not Economically Significant and (i) the agency considers the regulation significant, (ii) the regulation is a priority of the head of the agency, or (iii) the agency anticipates the regulation will be reviewed under Executive Order 12866. A significant regulation may be identified as a Major or Non-major rule. |
|  |  | A regulation is SUBSTANTIVE, NONSIGNIFICANT if it has substantive impacts but the magnitude of the impact is less than significant. These regulations are most likely not Economically Significant, will most likely not be reviewed under E.O. 12866, and are not, at present, a priority of the head of the agency. A Substantive, Nonsignificant regulation is always identified as a Non-major rule. |
|  |  | A regulation is ROUTINE AND FREQUENT if it is a specific case of a multiple recurring application of a regulatory program in the CFR and it does not alter the body of the regulation. (Note: If an individual regulation that normally falls into the Routine and Frequent category is submitted to OMB for review, the rulemaking should be classified as Economically Significant or Other Significant.) A Routine and Frequent regulation is always identified as a Non-major rule. |
|  |  | A regulation is INFORMATIONAL/ADMINISTRATIVE/OTHER if it is primarily informational or pertains to agency matters not central to accomplishing the agency's regulatory mandate but that the agency places in the Semiannual Agenda to inform the public of the activity. An Informational/Administrative/Other regulation is always identified as a Non-major rule. If the TD is categorized as "Routine and Frequent, or Informational/Administrative/Other" , do not complete the second page of the CRA form. |
|  | Other than TDs: |
|  |  | Leave blank. This question relates only to TDs. |
| 9\. Effective Date |
|  | TDs: |
|  |  | Enter the Effective Date as stated in the DATES caption in the preamble. <br>### Note:<br>If the rule is a "major rule," pursuant to 5 U.S.C 801, the effective date of the rule cannot be earlier than 60 days after the rule is delivered to (and actually received by) the House, Senate and the GAO. |
|  | Other than TDs: |
|  |  | If the document contains an effective date or applicability date in the text, the Effective Date for the CRA form is the effective date or applicability date as stated in the document. If the rule contains multiple effective dates, enter the earliest effective date.<br>If the document does not contain an effective date or applicability date in the text, leave the Effective Date section on the CRA form blank (do not enter N/A; do not enter the publication or issuance date of the document).<br>Examples:<br>1. A Revenue Procedure states that it is applicable to transactions entered into after December 31, 2010. The Effective Date for the CRA form is January 1, 2011.<br>   <br>2. A Notice provides guidance for computing certain amounts for a calendar quarter. The Effective Date for the CRA form is the first day of that calendar quarter.<br>   <br>3. A Revenue Ruling or Coordinated Issue Paper provides guidance to be applied on a retroactive (without stating a specific date) and a prospective basis. Leave the Effective Date section on the CRA form blank. Do not enter "N/A ." Do not enter the publication date or date of issuance. |
| 10\. Rule Concise Summary — Answer "attached." Prepare and attach a concise summary of the rule. |
| Submitted By — The Chief, Publications and Regulations Branch signs the form. |
|  | Enter that individual’s name and title as follows: |
|  |  | \[insert name\]<br>Chief, Publications and Regulations Branch |
|  | Following the signature, name, and title, type: |
|  |  | If you have any questions, please contact \[insert attorney’s name\] at \[insert attorney’s 10-digit phone number\]. |
|  |
| **Instructions for Completing the 2nd Page of the Congressional Review Act (CRA) Form** |
| ### Reminder:<br>For TDs only, if the TD is categorized as "Routine and Frequent" , or "Informational Administrative/Other" , (1st page, # 8) do not complete the second page of the CRA form. |
| A. If the final rule is a significant regulatory action or a major rule, the agency must prepare a cost and benefit analysis for OMB’s review. |
|  | TDs: |
|  |  | Answer "Yes" if the agency prepared an analysis of costs and benefits. If the rule is neither a significant regulatory action nor a major rule, answer "No." |
|  | Revenue Rulings, Revenue Procedures, Notices and Announcements: |
|  |  | If the rule is neither a significant regulatory action nor a major rule, answer "No." |
|  | Action on Decision: |
|  |  | Answer "N/A." |
|  | Coordinated Issue Papers: |
|  |  | Answer "N/A." |
|  | Market Segment Specialization Papers: |
|  |  | Answer "N/A." |
| B. TDs |
|  | If the final rule is subject to the Regulatory Flexibility Act, the agency must prepare a final regulatory flexibility analysis or certify that the rule will not have a significant economic impact on a substantial number of small entities.<br>If, by the final rule stage, the agency certifies that a regulatory flexibility analysis is not required, answer "Yes" to question B.1. and "N/A" to question B.2.<br>If, by the final rule state, the agency prepared a final regulatory flexibility analysis, answer "N/A" to question B.1. and "Yes" to question B.2.<br>If the final rule is not subject to the Regulatory Flexibility Act, answer "N/A" to both questions B.1. and B.2. |
|  | Other than TDs:<br> Answer "N/A" to both questions B.1 and B.2. |
| C. TDs: |
|  | If the final rule includes a mandate that will result in costs exceeding $100,000,000 in any one year, section 202 of the Unfunded Mandates Reform Act of 1995 (UMRA) requires agencies to prepare a "written statement." If the final rule is subject to the UMRA and the agency prepared a "written statement," answer "Yes" to question C. If the final rule is subject to the UMRA and agency did not prepare the "written statement," answer "No." If the final rule is not subject to UMRA, answer "N/A." Virtually all IRS regulations are not subject to UMRA. |
|  | Other than TDs: <br> Answer "N/A." |
| D. For all documents: Answer "N/A." |
| E. For TDs and other published guidance (revenue rulings, revenue procedures, notices): |
|  | If the rule contains a collection of information requirement subject to the Paperwork Reduction Act of 1995, answer "Yes." If it does not, answer "No." |
|  | For documents that are neither TDs nor other published guidance:<br> Answer "N/A." |
| F. TDs: |
|  | For each Executive Order (E.O.) answer "Yes" or "No" § depending on whether the E.O. was discussed in the preamble (regardless of whether the E.O. applies or does not apply to the regulation). In the space provided, list all other statutes (for example, IRC § 7805) and other executive orders addressed in the preamble. The preamble to IRS regulations routinely address E.O. 12866 and 26 U.S.C. § 7805. |
|  | Other than TDs: <br> Answer "N/A" for each Executive Order. |
|  |
| **Preparation of CRA Packages and Additional Copies of the CRA Form:** |
| 1\. Assemble three packages, one each for (i) the President, United States Senate, (ii) the Speaker, U.S. House of Representatives, and (iii) the General Counsel, GAO. Each package contains the following documents in the order listed, from top to bottom:<br>- Completed CRA form;<br>  <br>- Concise summary of the rule;<br>  <br>- A copy of the rule; and<br>  <br>- Any other attachment(s) (rarely will there will be any other attachment). |
| 2\. Make a copy of one of the packages for retention in the Regulations Unit. |
| 3\. Make five copies of one of completed CRA forms (preferably either the one for the President, U.S. Senate, or the one for the Speaker, U.S. House of Representatives). Type each of the following recipients. names and titles on the upper right corner of each of the five copies:<br>- The Honorable Max Baucus, Chairman, Committee on Finance<br>  <br>- The Honorable Orin G. Hatch Ranking Minority Member, Committee on Finance<br>  <br>- The Honorable Dave Camp, Chairman, Committee on Ways and Means<br>  <br>- The Honorable Sander Levin, Ranking Minority Member, Committee on Ways and Means<br>  <br>- Mr. Thomas A. Barthold, Chief of Staff, Joint Committee on Taxation<br>  <br>These five recipients receive only a copy of the CRA form, without any attachments. |
|  |
| **Acknowledgment of Receipt Forms** |
| The Publication and Regulations Branch delivers to the drafting attorney Acknowledgement of Receipt forms from the Senate House of Representatives and GAO. If the drafting attorney does not receive the acknowledgment within 10 days from when the attorney delivered the CRA form to the Publications and Regulations Branch, the attorney must contact the Publications and Regulations Branch to obtain the acknowledgments. The drafting attorney must file all three acknowledgments in the legal file for the regulation project. It is critical that the acknowledgments are retained in the event that there is any question over whether the IRS complied with the CRA. |

**Exhibit 32.2.8-3**

### Procedures for Release of Guidance to the News Media (Drops)

| **RELEASE OF GUIDANCE TO THE NEWS MEDIA** |
| :-: |
| ("DROPS" ) |

> ADVANCE COORDINATION

- **Please alert Media Relations at least one week before anticipated release if the guidance affects a broad target audience, would be of high popular interest, covers a controversial issue, or requires significant education or compliance effort.**

- Note on the Request sheet if either a Treasury or IRS release is in process.


> SCHEDULE

- Media Relations issues guidance at 10 AM and 2 PM; because of processing issues, releases after 2 PM are burdensome for both IRS and the media and are done only in cases of real urgency.

- Media Relations needs IRB Advance materials at least 90 mins. before release.

- Media Relations needs Regs and Fed. Register notices by 1:30 PM. There is no point in sending electronic files after the day regs are filed, as the tax services will have obtained the text from the Register and printed it.


> ELECTRONIC FILE FORMAT

- Remove Draft Date and Case Number from the document.

- MS Word is the preferred format.

- The preferred spacing format is single-spaced.


> SUMMARY DESCRIPTION

- One or two "plain English" sentences on the subject of the drop.

- Not a "cut & paste" of the document’s first paragraph or its conclusion.

- Include key terms and/or their "popular" names.


> COUNSEL CONTACTS

- Direct Phone # should be included (not Branch or general office line) for:

• Person responsible for file/disk/paper materials

• Attorney (and a backup) authorized to speak w/ media (someone must be available the day

materials are released and the next business day)


> DELIVERY TO MEDIA RELATIONS

- **E-mailing the electronic file is preferred — call 622-4000 to coordinate.**


**Exhibit 32.2.8-4**

### Format for Request for Early Release of a Publication

| REQUEST FOR <br>ADVANCE RELEASE OF IRB ITEM TO THE NEWS MEDIA |
| :-: |
| RELEASE DATE: \_\_ TIME: 10 AM \_ 2 PM \_ |
| (materials must be to Media Relations at least 90 mins. in advance) |
| RELATED NEWS RELEASE? Treasury Dept. \_ IRS \_ |
| INTERNAL REVENUE BULLETIN ITEM(s): |
|  | Rev. Rul. \_ | Rev. Proc. \_ | Notice \_ | Ann. \_ | #: 2011-\_ |
|  | Rev. Rul. \_ | Rev. Proc. \_ | Notice \_ | Ann. \_ | #: 2011-\_ |
| WILL BE IN IRB 2009-\_ | DATED: \_\_, 2011 |
| SUMMARY DESCRIPTION OF SUBJECT (1 or 2 "plain English" sentences using key terms and/or "popular" names — not a "cut & paste" of the document’s 1st paragraph or conclusion): |
| CONTACTS (must be available the day of release and the following day): |
|  | Electronic file / paper copies: \_\_\_ |
|  | Direct phone #: \_\_\_ |
|  | Attorney for interviews: \_\_\_ |
|  | Direct phone #: \_\_\_ |
|  | Backup for interviews: \_\_\_ |
|  | Direct phone #: \_\_\_ |
|  | TREASURY (OTP) ATTORNEY: \_\_\_ |
| **E-mail file to a Media Relations Specialist – call 622-4000 for name(s) of Media Specialist who will handle it.** |
|  |
| **Chief Counsel Approval** |
| The attached guidance, |
|  | Announcement<br>Notice<br>Revenue Procedure<br>Revenue Ruling | \_\_<br>\_\_<br>\_\_<br>\_\_ |
| has been cleared for release to the public. |
|  |  |
| Chief Counsel | Date |

**Exhibit 32.2.8-5**

### Pattern Revenue Ruling Obsoleting Multiple Revenue Rulings

|  |
| --- |
| Draft Date: MM/DD/YY | CASE-MIS Number: RR-xxxxx-xx |

Part I

Section 7805.--Rules and Regulations

26 C.F.R. 301.7805-1: Rules and regulations.

Rev. Rul.

The Internal Revenue Service is continuing its program of reviewing revenue rulings published in the Internal Revenue Bulletin to identify and publish lists of those rulings that, although not specifically revoked or superseded, are no longer considered determinative because: (1) the applicable statutory provisions or regulations have been changed or repealed; (2) the ruling position is specifically covered by a statute, regulation, or subsequent published position; or (3) the facts set forth no longer exist or are not sufficiently described to permit clear application of the current statute and regulations.

This revenue ruling publishes a list of rulings dealing with \[insert subject matter\].

The listed revenue rulings have been identified under the Service's review program as no longer being determinative.

Accordingly, the revenue rulings listed below are hereby declared obsolete.

|  |
| --- |
|  | Rev. Rul. No. | C.B. Citation |
|  |

The Service will continue to review other revenue rulings relating to \[insert subject matter\] to identify those that, for the reasons stated above, are inapplicable to future transactions. Therefore, failure to include any particular revenue ruling in the above list should not be construed as an indication that the revenue ruling necessarily is determinative with respect to future transactions.

DRAFTING INFORMATION

The principalauthorofthisrevenuerulingis\_\_of the Office of Associate Chief Counsel (\_\_). For further information regarding this ruling contact \_\_on (202) \_(not a toll-free call.)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part32/irm_32-002-008#addtoany "Show all")

A2A