---
url: "https://www.irs.gov/irm/part33/irm_33-003-003"
title: "33.3.3 Appeals Settlement Guidelines | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part33/irm_33-003-003#main-content)

- 33.3.3 [Appeals Settlement Guidelines](https://www.irs.gov/irm/part33/irm_33-003-003#idm140352942339312)
  - 33.3.3.1 [Purpose and Organization of Appeals Settlement Guidelines](https://www.irs.gov/irm/part33/irm_33-003-003#idm140352953453856)
  - 33.3.3.2 [Procedures for Review of ASGs by Counsel](https://www.irs.gov/irm/part33/irm_33-003-003#idm140352962596016)

    - 33.3.3.2.1 [Coordination with the Associate Chief Counsel (Procedure & Administration)](https://www.irs.gov/irm/part33/irm_33-003-003#idm140352963082592)
    - 33.3.3.2.2 [Counsel Response to Appeals](https://www.irs.gov/irm/part33/irm_33-003-003#idm140352968880320)

  - Exhibit 33.3.3-1 [Appeals Settlement Guidelines Check Sheet](https://www.irs.gov/irm/part33/irm_33-003-003#idm140352948270464)

# Part 33. Legal Advice

# Chapter 3. Other Legal Advice

# Section 3. Appeals Settlement Guidelines

* * *

## 33.3.3 Appeals Settlement Guidelines

**33.3.3.1** **(11-04-2010)**

### Purpose and Organization of Appeals Settlement Guidelines

1. Appeals Settlement Guidelines (ASGs) are guidelines written by Appeals and reviewed by the Office of Chief Counsel to assist Appeals in coordinating issues of broad impact or importance to ensure resolution on a consistent basis nationwide. In general, Appeals develops settlement guidelines when an issue is coordinated by the Examination function. Deputy Area Counsels (Industry Program) work with the Examination function to develop Coordinated Issue Papers (CIP), and the Office of Chief Counsel reviews these papers. Settlement guidelines build on the core of a CIP by adding guidelines governing the settlement of issues, including addressing the hazards of litigation.

2. An ASG is generally organized into two sections: a law and analysis section and settlement guidelines section. The ASG in its entirety must be reviewed by the Office of Chief Counsel for legal accuracy. Since ASGs are available to the public, subject to certain exemptions under the Freedom of Information Act (FOIA), the settlement guidelines section must also be reviewed by the Office of the Associate Chief Counsel (Procedure & Administration) to ensure that only privileged material is subject to redaction.


**33.3.3.2** **(11-04-2010)**

### Procedures for Review of ASGs by Counsel

1. **Overview**. The Office of Appeals will submit all Appeals Settlement Guidelines (ASGs) to Division Counsel (Large Business and International) (LB&I). The underlying CIP should accompany the proposed ASG when it is submitted by Appeals. Division Counsel (LB&I) will, in turn, forward the ASGs to the Technical Services Support Branch for assignment. To the extent possible, Division Counsel (LB&I) will indicate the appropriate Associate office for assignment. The Associate office has 90 days to review the ASG once received by the Technical Services Support Branch. The Technical Services Support Branch will assign the ASG to an Associate office and simultaneously open a request for assistance from the Office of the Associate Chief Counsel (Procedure & Administration). The prime branch is responsible for ensuring that all issues in the ASG are properly coordinated with the Associate office having jurisdiction over the relevant issue. In addition, the prime branch is responsible for ensuring a disclosure review by the Associate Chief Counsel (Procedure & Administration). These coordination efforts must be completed within the time allowed for review and the prime branch will issue one response that contains all Counsel comments on the proposed ASG. The Technical Services Support Branch will run a report of the pending ASG assignments weekly. Copies of this report will be furnished to each Associate Chief Counsel, Division Counsel (LB&I), and Appeals.

2. **Initial Contact with Appeals**. Within seven calendar days, the prime attorney should contact the Appeals drafter of the ASG to inform the drafter that the ASG is under review.

3. **Review of Prior File**. The prime attorney should verify whether an earlier draft of the proposed ASG has been reviewed by the Office of Chief Counsel. If not submitted with the revised ASG, the prime attorney should obtain and review the file containing the prior draft and Counsel’s comments.

4. **Need for Assistance Requests**. If the prime attorney identifies issues that are outside the prime Associate office’s jurisdiction, an assistance request should be prepared within seven calendar days of assignment.



1. The prime attorney will send an assistance request, along with the TECHMIS screen showing the assistance WLI, to each Associate’s office providing assistance. All relevant background material ( _e.g._, underlying CIP, prior draft, copy of prior Counsel comments, etc.) will be attached to each assistance request. It is the responsibility of the attorney to ensure that the WLI assistance information is entered into TECHMIS.

2. The assistance request must state the date by which the prime attorney needs the response in order to respond within 90 days. Generally, the office providing assistance should have no less than 45 calendar days to respond. The review and input from other Associate offices must be completed prior to the disclosure review. See CCDM 33.3.3.2.1.

3. It is the prime attorney’s responsibility to follow up on all requests for assistance to make sure the response is received in time to be incorporated into Counsel’s response. Late outstanding assistance requests should be promptly elevated to the assigned reviewer.


5. **Scope of review**. The prime attorney will review the issues within the prime Associate office’s jurisdiction and perform any necessary research to determine the technical accuracy of the ASG. Issues will be elevated, as necessary. Review of the ASG should include coordination with the appropriate LB&I Deputy Area Counsel (Industry Program) or other field counsel. The prime attorney and, if appropriate, any attorney providing technical assistance to the prime attorney, will call the ASG drafter to discuss substantive, format, disclosure, or other concerns during Counsel’s review of the ASG. The prime attorney will coordinate these Appeals contacts with the appropriate LB&I Deputy Area Counsel (Industry Program) or other Field Counsel.



1. Issues that are not addressed in an underlying CIP are not to be added. The ASG is an Appeals work product; major revisions or rewriting are to be avoided. However, if Counsel believes a rewrite is needed, the matter should be elevated in Appeals. If it is determined that the ASG requires redrafting, the ASG will be returned to Appeals with a memorandum outlining the problems that need to be addressed. No disclosure review will be necessary in these circumstances.

2. The prime attorney’s review will encompass not only technical matters, but will also include a review of the extent to which the ASG will be made available for public inspection ( _i.e._, that the information contained in the "Settlement Guidelines" section is properly exempt under the FOIA and that the information contained in the other sections may properly be disclosed). The attorney should answer the questions provided on the ASG check sheet to expedite the disclosure review. See Exhibit 33.3.3-1.


**33.3.3.2.1** **(11-04-2010)**

#### Coordination with the Associate Chief Counsel (Procedure & Administration)

1. A disclosure review must be completed within the 90-day time frame for responding to Appeals. When the prime attorney determines that the ASG is ready to be issued as submitted by Appeals, or with only minor changes, but generally no later than 14 days before Counsel’s response date, the prime attorney will send a copy of the ASG (with any pen-and-ink minor changes), along with the supplementary materials in support of its preliminary disclosure review to the Associate Chief Counsel (Procedure & Administration).

2. In general, material that will be redacted prior to public release should be confined to the "Settlement Guidelines" section of the ASG. Material that may be protected would include evaluation of the hazards of litigation and settlement criteria and ranges. Guidelines that conclude that no cases should be settled or that cases should be settled simply on the basis of the Appeals officer’s own evaluation of the facts and circumstances would, however, not be redacted.

3. Based upon the supplementary materials provided by the prime attorney, the P&A attorney will confirm that:



   - Any taxpayer-specific facts included within the ASG are contained in the judicial opinion (or other public record documentation accompanying the ASG).

   - None of the material proposed for redaction is included in other Service documents that are available to the public ( _e.g._, IRM, ASGs, CIPs, CCAs, etc.).

   - The material proposed for inclusion in the "Guidelines" section of the ASG appropriately falls within one or more FOIA exemptions.

   - No material contained in the discussion or background section should be withheld under one of the FOIA exemptions.


4. The P&A attorney will complete the disclosure review and provide written assistance back to the prime attorney generally no later than seven calendar days before Counsel’s response date. This memorandum will either set forth any disclosure concerns with the proposed ASG or indicate clearance of the ASG.


**33.3.3.2.2** **(11-04-2010)**

#### Counsel Response to Appeals

1. Once the prime attorney has completed work on the prime Associate office’s issues, has received all assistances, including the disclosure review, one response for Counsel will be prepared. Counsel’s response will address all issues in the proposed ASG. The response should acknowledge the conversations with the Appeals drafter on substantive comments.

2. Counsel’s response to Appeals, which will also address the disclosure review, must be reviewed by a reviewer with signature authority to sign for the assigned office.

3. The ASG file should be organized and submitted for closing, and all TECHMIS assignments, including all WLIs, should be closed.

4. The response should be sent to the Chief, Appeals, with a copy to Division Counsel (LB&I).


**Exhibit 33.3.3-1**

### Appeals Settlement Guidelines Check Sheet

| **APPEALS SETTLEMENT GUIDELINES CHECK SHEET** |
| :-: |
| After technical review of the proposed **Appeals Settlement Guideline** is complete, the prime attorney assigned should complete this Check Sheet and furnish it to Associate Chief Counsel (Procedure & Administration) for a disclosure review: |
|  | (a) If there are any taxpayer-specific facts contained in the ASG, are all of the facts drawn directly from the judicial opinion of the case (or other portions of the public court record of the case), and not from internal IRS files? |
|  | \_ | There are no taxpayer-specific facts in the ASG. |
|  | \_ | All of the taxpayer-specific facts are drawn from the judicial opinion (or other portions of the public court record) in the case; they are attached. |
|  | (b) Is any material identified for nondisclosure under the Guidelines portion of the ASG reflected in (a) prior published ASGs; (b) CIPs, (c) Industry Specialization Papers, or (d) other publicly available IRS or Counsel documents on this issue? Please provide copies of these relevant public materials. |
|  | \_ | None of the material identified for nondisclosure is reflected in any published IRS or Counsel documents; they are attached. |
|  | (c) Is any material identified for nondisclosure a straightforward discussion of the law, and not in the nature of guidelines governing the settlement of issues? (In other words, is the material of the type that would be disclosed in Chief Counsel Advice or is the material of the type that would be considered privileged and placed under the Heading, "Case Development, Hazards, and Other Considerations" ?) |
|  | \_ | None of the material identified for nondisclosure is the type of straightforward discussion of the law (including contrary legal arguments) that are to be disclosed in Chief Counsel Advice. |
|  | \_ | The material to be redacted is of the type that would be privileged in Chief Counsel Advice. |
|  | (d) For any material that is believed to be properly a law enforcement guideline that should not be disclosed to the public, provide an articulation as to the nature of the harm to the IRS should the material be disclosed. |
| Attorney Initials & Date: \_ |
| Manager Initials & Date:\_ |

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part33/irm_33-003-003#addtoany "Show all")

A2A