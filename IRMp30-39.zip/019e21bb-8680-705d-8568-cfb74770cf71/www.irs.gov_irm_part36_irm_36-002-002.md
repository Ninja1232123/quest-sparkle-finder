---
url: "https://www.irs.gov/irm/part36/irm_36-002-002"
title: "36.2.2 Petition for Writ of Certiorari | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part36/irm_36-002-002#main-content)

- 36.2.2 [Petition for Writ of Certiorari](https://www.irs.gov/irm/part36/irm_36-002-002#idm140076797285120)
  - 36.2.2.1 [Petition for Certiorari Generally](https://www.irs.gov/irm/part36/irm_36-002-002#idm140076797353248)
  - 36.2.2.2 [Supreme Court Rules - Time for Filing Petition](https://www.irs.gov/irm/part36/irm_36-002-002#idm140076812161696)
  - 36.2.2.3 [Taxpayer's Petition for Writ of Certiorari](https://www.irs.gov/irm/part36/irm_36-002-002#idm140076812205104)

    - 36.2.2.3.1 [Associate Chief Counsel Attorney Assignments - Taxpayer Petition](https://www.irs.gov/irm/part36/irm_36-002-002#idm140076797386896)
    - 36.2.2.3.2 [Documents and Files - Taxpayer Petition](https://www.irs.gov/irm/part36/irm_36-002-002#idm140076775128800)
    - 36.2.2.3.3 [Coordination - Taxpayer Petition](https://www.irs.gov/irm/part36/irm_36-002-002#idm140076771709600)
    - 36.2.2.3.4 [Review Taxpayer's Petition](https://www.irs.gov/irm/part36/irm_36-002-002#idm140076797288976)
    - 36.2.2.3.5 [Information Memorandum - Taxpayer Petition](https://www.irs.gov/irm/part36/irm_36-002-002#idm140076812193520)
    - 36.2.2.3.6 [Opposition](https://www.irs.gov/irm/part36/irm_36-002-002#idm140076797288592)
    - 36.2.2.3.7 [Acquiescence](https://www.irs.gov/irm/part36/irm_36-002-002#idm140076765571424)
    - 36.2.2.3.8 [Denial of Taxpayer's Petition for Writ of Certiorari](https://www.irs.gov/irm/part36/irm_36-002-002#idm140076812146000)

  - 36.2.2.4 [Government's Petition for Writ of Certiorari](https://www.irs.gov/irm/part36/irm_36-002-002#idm140076797337744)
  - 36.2.2.5 [Associate Chief Counsel Attorney Responsibilities in Certiorari Cases](https://www.irs.gov/irm/part36/irm_36-002-002#idm140076797329472)

    - 36.2.2.5.1 [Initial Responsibilities - Certiorari Cases](https://www.irs.gov/irm/part36/irm_36-002-002#idm140076797284064)

      - 36.2.2.5.1.1 [Documents and Files](https://www.irs.gov/irm/part36/irm_36-002-002#idm140076797378928)
      - 36.2.2.5.1.2 [Coordination within Chief Counsel](https://www.irs.gov/irm/part36/irm_36-002-002#idm140076812081776)
      - 36.2.2.5.1.3 [Information Memorandum - Certiorari Cases](https://www.irs.gov/irm/part36/irm_36-002-002#idm140076812277408)
      - 36.2.2.5.1.4 [Letter to Department of Justice - Certiorari Recommendation](https://www.irs.gov/irm/part36/irm_36-002-002#idm140076797315968)
      - 36.2.2.5.1.5 [Action Documents](https://www.irs.gov/irm/part36/irm_36-002-002#idm140076770744096)
      - 36.2.2.5.1.6 [Letter Recommending No Certiorari](https://www.irs.gov/irm/part36/irm_36-002-002#idm140076774171744)

# Part 36. Appellate Litigation and Actions on Decision

# Chapter 2. Appeal/Certiorari Recommendations

# Section 2. Petition for Writ of Certiorari

* * *

## 36.2.2 Petition for Writ of Certiorari

#### Manual Transmittal

March 27, 2012

#### Purpose

(1) This transmits revised CCDM 36.2.2, Appeal/Certiorari Recommendations; Petition for Writ of Certiorari.

#### Material Changes

(1) CCDM 36.2.2.5.1.3 was updated to provide for email transmission of Information Memorandums.

(2) CCDM 36.2.2.5.1.5 was updated to provide for email transmission of Action Memorandums.

(3) References were corrected in CCDM 36.2.2.2, CCDM 36.2.2.3.3 and CCDM 36.2.2.5.1.2. Hyperlinks were added to references throughout the section.

#### Effect on Other Documents

CCDM 36.2.2 dated August 11, 2004 is superseded.

#### Audience

Chief Counsel

#### Effective Date

(03-27-2012)

Deborah A. Butler

Associate Chief Counsel

(Procedure & Administration)

**36.2.2.1** **(08-11-2004)**

### Petition for Certiorari Generally

1. Once the court of appeals has concluded its consideration of a case, either party may file a petition for writ of certiorari with the Supreme Court. _See_ 28 U.S.C. § 1254. The writ is discretionary with the Supreme Court, and only a small percentage of petitions are granted.

2. Upon receipt of a petition for writ of certiorari filed by the litigant or receipt of a request from the Department of Justice for the Service's recommendations concerning certiorari review of an unfavorable court of appeals decision, it is the responsibility of the affected Associate Chief Counsel to forward the Chief Counsel's recommendation to the Department of Justice and provide all necessary assistance.

3. Because the matter must be coordinated and approved by both the Chief Counsel and the General Counsel, Department of Treasury (General Counsel), before a letter recommending certiorari may be sent, attorneys must be mindful of the time limitations on processing a certiorari recommendation. See CCDM 36.2.2.5 for specific responsibilities of Associate Chief Counsel attorneys when it is considered probable that certiorari will be recommended.


**36.2.2.2** **(03-27-2012)**

### Supreme Court Rules - Time for Filing Petition

1. Rule 13 of the Rules of the Supreme Court provides that, unless otherwise provided by law, a petition for a writ of certiorari to review a judgment in any case, civil or criminal, entered by a state court of last resort or a United States court of appeals, is timely when it is filed within 90 days after entry of the judgment. For good cause, a Justice may extend the time to file a petition for a writ of certiorari for a period not exceeding 60 days.

2. It is the policy of the Solicitor General's Office only to seek an extension of time when there is a substantial probability that certiorari will be sought by the Government. Thus, generally this extension provision does not lengthen the time in which the office must act. See CCDM 36.2.1.2.1, Federal Rules of Appellate Procedure, for the distinction between judgments and mandates in the courts of appeal.

3. If a timely petition for rehearing is filed with the court of appeals and denied, a new 90-day certiorari period begins to run from the date of the denial. _See_ Sup. Ct. R. Rule 13(3).


**36.2.2.3** **(08-11-2004)**

### Taxpayer's Petition for Writ of Certiorari

1. When a taxpayer files a petition for writ of certiorari, the Government must decide whether to oppose or acquiesce in the petition. The procedures for recommendations for certiorari and recommendations against certiorari vary dramatically. Thus, it is important to determine the probability of requesting certiorari or agreeing to a taxpayer's petition for certiorari.

2. The Department of Justice generally does not forward copies of taxpayers' petitions for writ of certiorari to the Chief Counsel nor notify the Chief Counsel that a petition has been filed. The Solicitor General waives a response to a majority of petitions and files a routine opposition to most of the rest. If an Associate's office wants to be notified in a particular case if the taxpayer files a petition for certiorari, so that the office may consider whether to acquiesce or provide comments in the event an opposition is filed, it should notify the Appellate Section of the Tax Division soon after the favorable court of appeals opinion is issued.

3. The Appellate Section must provide its recommendation on the taxpayer's petition to the Solicitor General within 15 days after service. In most cases, however, it will convey its recommendation informally within a day or two after it receives a copy of the petition. In the few instances in which a formal recommendation is appropriate, the Appellate Section generally will seek the views of Chief Counsel. If the recommendation of the Appellate Section conflicts with the Chief Counsel's, the Appellate Section will send copies of its recommendation to Chief Counsel at the same time it forwards its recommendation to the Assistant Attorney General. Time and circumstances permitting, the Assistant Attorney General will withhold final action on the Tax Division's recommendation in order to reconcile differences. A conference may be held to discuss the recommendations. The Solicitor General has final authority over how to respond to the petition for certiorari. The office of the General Counsel of the Department of the Treasury should be invited to any meeting with the office of the Solicitor General regarding any recommendation in favor of or in opposition to a petition for writ of certiorari.


**36.2.2.3.1** **(08-11-2004)**

#### Associate Chief Counsel Attorney Assignments - Taxpayer Petition

1. When the attorney is assigned a taxpayer petition for writ of certiorari, the attorney must decide whether to recommend opposition, acquiescence, or offer comments to the Department of Justice. The recommendation will be in the form of a draft letter to the Department of Justice.

2. An information memorandum must be prepared in certain cases and an action memorandum is required in all cases where acquiescence is recommended. These documents are discussed below, following the preliminary steps that should be taken by the attorney.


**36.2.2.3.2** **(08-11-2004)**

#### Documents and Files - Taxpayer Petition

1. The attorney should ensure that all documents and files required to make an informed decision regarding certiorari have been obtained. Letters recommending acquiescence in the taxpayer's petition, when referred for additional review, should be accompanied by such files or other memoranda as may be helpful to their consideration. At a minimum, the accompanying materials should include the court of appeals' opinion and the appellate court briefs filed by the Government.


**36.2.2.3.3** **(03-27-2012)**

#### Coordination - Taxpayer Petition

1. It may be necessary or appropriate to coordinate further action on the taxpayer's petition with other offices within the Office of Chief Counsel or with other branches within the responsible Associate's office. The Associate Chief Counsel attorney should consult the provisions of CCDM 36.1.1.6, Responsibilities of Associate Chief Counsel Offices in Appeal Cases, for instructions regarding coordination.


**36.2.2.3.4** **(08-11-2004)**

#### Review Taxpayer's Petition

1. In reviewing the taxpayer's petition, the attorney should consider:



1. Whether the holding of the court of appeals favorable to the Government still represents Service position on the issues;

2. Whether the court's opinion, although favorable to the Government, is inconsistent with the arguments made in our briefs and, if so, whether we can accept the reasons given by the court for its holding despite this inconsistency;

3. Whether there are matters that should be brought to the attention of the Department of Justice, such as a lack of timeliness in filing the petition or the existence of subsequent rulings, regulations, or legislation that may have a bearing on the issue;

4. Whether the issues raised in the petition have been adequately answered in the Government's briefs and, if not, whether the defects are of sufficient importance to justify comment;

5. Whether there is a genuine intercircuit conflict or whether cases alleged to be in conflict may be distinguished;

6. Whether the issues are of administrative importance; and

7. Whether the issues are ripe for Supreme Court review in view of the pendency of other cases.


2. In some instances, allegations of conflict must be handled delicately so as to preserve a possible basis for a Government petition in a subsequent case if desired. Consideration of many of these matters can begin when the attorney handling the case receives a copy of the favorable court of appeals opinion, so that in the event the taxpayer files a petition for writ of certiorari, the question of whether to recommend opposition to or acquiescence in the petition will have been largely resolved.


**36.2.2.3.5** **(08-11-2004)**

#### Information Memorandum - Taxpayer Petition

1. In all cases where the Department of Justice has requested the recommendation of the Chief Counsel and in any case where the attorney, in consultation with the attorney's reviewer(s), believes serious consideration should be given to Supreme Court review, the attorney should prepare an information memorandum. This is the same memorandum that is used to inform officials in the Office of the Chief Counsel and others that certiorari recommendation is being considered. The memorandum is discussed at CCDM 36.2.2.5.1.3.


**36.2.2.3.6** **(08-11-2004)**

#### Opposition

1. If the attorney recommends opposition, the attorney should prepare a draft letter to the Assistant Attorney General, Tax Division, conveying that recommendation. The letter should concisely explain why opposition is appropriate, e.g., the absence of a conflict or of administrative importance, factors making the particular case a poor vehicle.

2. The attorney should forward the draft letter to the reviewer within two work days after receipt of the taxpayer's petition. The draft should be accompanied by the taxpayer's petition, a copy of the court of appeals opinion (if not already an addendum to the petition), and the Government's appellate briefs, if available.

3. Review by the Chief Counsel, Deputy Chief Counsel, or Associate Chief Counsel is not necessary. All certiorari matters, including routine opposition, should be brought to the attention of the Associate Chief Counsel.


**36.2.2.3.7** **(08-11-2004)**

#### Acquiescence

1. The criteria for acquiescence are the same as for a recommendation for a Government petition for writ of certiorari. See CCDM 36.2.2.5.1.4, Letter to Department of Justice - Certiorari Recommendation.

2. If the attorney recommends acquiescence in the taxpayer's petition, a draft letter to the Department of Justice and an action memorandum must be prepared expeditiously. The attorney should submit the letter and memorandum to the reviewer within two work days after receipt of the taxpayer's petition. The reviewer should forward the letter and memorandum to the Chief Counsel, through the Associate Chief Counsel. The letter and action memorandum will be distributed in accordance with the provisions of CCDM 36.2.2.5.1.5, Action Documents.


**36.2.2.3.8** **(08-11-2004)**

#### Denial of Taxpayer's Petition for Writ of Certiorari

1. If the Supreme Court denies a petition for writ of certiorari, the taxpayer has 25 days within which to petition for a rehearing on the denial. The case should not be closed until this 25-day period has expired. See CCDM 36.2.5.3, Finality of Tax Court Decisions and Mandamus, for the finality of a Tax Court decision in this situation.

2. During this 25-day period, the attorney should have the files prepared for closing. Immediately upon the expiration of the 25-day period, if a petition for rehearing is not filed, or if filed, is denied by the Supreme Court, the Associate Chief Counsel attorney should take the appropriate closing action, depending upon whether the case has been remanded or involves a bonded taxpayer appeal. Remember that in bonded appeal cases involving tax deficiencies, assessment has not occurred and the period of limitations on assessment begins to run again when the decision becomes final. _See_ section 7485. Accordingly, attorneys should promptly close the case so that assessment can occur. Appeal bonds in Tax Court cases are more fully discussed at CCDM 36.2.6.2.1.2, Appeal Bond.

3. The Associate Chief Counsel attorney should informally check with the Department of Justice as to whether a petition for rehearing was filed and, if not, close the case immediately upon the expiration of the 25-day period.


**36.2.2.4** **(08-11-2004)**

### Government's Petition for Writ of Certiorari

1. Adverse opinions of the court of appeals are transmitted by letter from the Appellate Section, Tax Division, Department of Justice. These are picked up daily, logged in, and forwarded to the appropriate Associate's office by the Technical Services Support Branch of the Office of the Associate Chief Counsel (P&A).

2. When the opinion of the court of appeals is adverse to the Government, the Government must decide whether or not to file a petition for writ of certiorari. The Office of Chief Counsel will make a recommendation to the Department of Justice in the form of a letter to the Assistant Attorney General, Tax Division.

3. The Appellate Section of the Tax Division will review the Chief Counsel's recommendation and will prepare its own recommendation to the Assistant Attorney General (Tax Division). If the recommendations are in agreement, the Appellate Section drafts a memorandum for the Assistant Attorney General to the Solicitor General.

4. The Appellate Section's recommendation may conflict with the Chief Counsel's recommendation. In such a case, the Appellate Section will send Chief Counsel copies of its draft recommendation at the same time or shortly before the recommendation is forwarded to the Assistant Attorney General. Time and circumstances permitting, the Assistant Attorney General will withhold final action on the Tax Division's draft recommendation in order to reconcile the differences. A conference may be held to discuss the recommendations.

5. The Solicitor General will make the final determination as to whether to file a petition for writ of certiorari. The office of the General Counsel of the Department of the Treasury should be invited to any meeting with the office of the Solicitor General regarding any recommendation in favor of or in opposition to a petition for writ of certiorari. If the Solicitor General determines that a writ of certiorari should be filed, the Department of Justice will file the petition with the Supreme Court.


**36.2.2.5** **(08-11-2004)**

### Associate Chief Counsel Attorney Responsibilities in Certiorari Cases

1. This subsection describes the responsibilities of the Associate Chief Counsel Attorney in Certiorari cases.


**36.2.2.5.1** **(08-11-2004)**

#### Initial Responsibilities - Certiorari Cases

1. If the adverse appellate court opinion reverses or modifies a Tax Court decision, the attorney should consult CCDM 36.2.5.12, Cases Remanded to the Tax Court/Recomputations, for cases remanded to the Tax Court. For example, if the Tax Court's decision was favorable to the Government and the taxpayer prevailed on appeal in the court of appeals, the case will usually be remanded to the Tax Court for entry of a new decision in accord with the mandate of the court of appeals. Any action on remand, however, must await the expiration of the certiorari period or, if certiorari is petitioned and granted, the conclusion of proceedings in the Supreme Court. Nevertheless, Area Counsel should be advised of the remand by the Associate Chief Counsel attorney.


**36.2.2.5.1.1** **(08-11-2004)**

##### Documents and Files

1. As in the case of taxpayer petitions, the attorney should obtain all documents and files required to make an informed decision regarding certiorari, including the recommendation of the Appellate Section, if available.


**36.2.2.5.1.2** **(03-27-2012)**

##### Coordination within Chief Counsel

1. If the issues lost on appeal are within the jurisdiction of other offices within the Office of Chief Counsel or with other branches within the responsible Associate's office, further action should be coordinated with that office or branch. See CCDM 36.1.1.6, Responsibilities of Associate Chief Counsel Offices in Appeal Cases, for instructions regarding coordination.


**36.2.2.5.1.3** **(03-27-2012)**

##### Information Memorandum - Certiorari Cases

1. If it is reasonably probable that an affirmative recommendation for certiorari will be made, the Associate Chief Counsel office will prepare an information memorandum summarily describing the adverse court opinion, Service position, and the administrative significance or other reason for potentially recommending filing a petition for certiorari. The memorandum concludes with a statement that an affirmative recommendation for certiorari is being considered. A copy of the opinion should be attached.

2. The purpose of the information memorandum is to provide early notification to Chief Counsel officials, the Commissioner's office, and the General Counsel's office that the Associate Chief Counsel is strongly considering recommending filing a petition for certiorari. The Associate Chief Counsel attorney should prepare the information memorandum sufficiently early to allow adequate time to react to the potential recommendation.

3. The Associate Chief Counsel transmits the information memorandum via email. The information memorandum may either be embedded in the email or attached to it. A copy of the adverse appellate court opinion should be attached. The email and memorandum should highlight the due dates for action. The email should be sent to the following:



   - Chief Counsel

   - General Counsel

   - Both Deputy Chief Counsel

   - Associate Chief Counsel and Division Counsel

   - Commissioner

   - Deputy Commissioner for Services and Enforcement and Assistant Deputy Commissioner for Services and Enforcement

   - Chief of Staff to the Commissioner and Deputy Chief of Staff

   - The Counselor to the General Counsel, Treasury

   - The Office of Tax Policy at Treasury, as appropriate

   - Other Commissioner’s staff who may have been involved in the issue or are generally involved in litigation matters


4. Circulation to these parties permits them to provide input, including consideration of the impact the recommendation might have on the availability of Supreme Court review in their cases. The email should highlight the critical dates for recommending certiorari. A sample information memorandum email for certiorari cases appears in Exhibit 36.4.1–2..

5. Should a decision be made to not seek certiorari after an information memorandum has been circulated, the originator of the information memorandum should prepare a short memorandum explaining the reasons for not seeking certiorari that may be transmitted via email by the Associate Chief Counsel to the above parties.


**36.2.2.5.1.4** **(08-11-2004)**

##### Letter to Department of Justice - Certiorari Recommendation

1. The Associate Chief Counsel is responsible for preparing the letter and ultimately signs the letter, to the Assistant Attorney General, Tax Division, Department of Justice, recommending for or against the filing of a petition for writ of certiorari. The Associate should take into consideration the views and comments generated by the Information Memorandum or provided by Division Counsel and should coordinate the draft letter with those parties that made substantive comments. Coordination is particularly important when the letter recommends certiorari.

2. A letter recommending a petition for certiorari must be sent to the Department of Justice no later than 30 days after the court of appeals' opinion or order is filed or after receipt of the request from the Department of Justice. Since any letter recommending a petition for certiorari must be reviewed and approved by various offices within the Office of Chief Counsel and by the Chief Counsel and General Counsel, Treasury, it is imperative that such letters be prepared expeditiously.

3. Considerations in recommending certiorari.



1. For certiorari, as for other appellate purposes, controversy in tax cases is defined in terms of a decision against the Government and not a mere refusal to accept the Government's legal theory. See CCDM 36.2.1.1, Preparation of Appeal Letters. The letter to the Department of Justice should set forth very persuasive reasons why review by certiorari should be sought.

2. Review by certiorari is generally recommended when there is a clear conflict among the circuits on the legal issue and this should be clearly stated in the letter.

3. In the absence of an intercircuit conflict, Supreme Court review may nevertheless be recommended when the issue is one of exceptional administrative importance requiring prompt resolution.

4. The administrative importance of the issue should be stated explicitly, and the conflict, if any, should be explained.

5. The nationwide jurisdiction of the Federal Circuit is one factor in considering a recommendation for certiorari. A loss in this circuit may mean that the Government will not litigate another case with the issue.


4. The letter to the Department of Justice recommending certiorari should include the following statement: _The General Counsel concurs with this recommendation._


**36.2.2.5.1.5** **(03-27-2012)**

##### Action Documents

1. After the information memorandum is circulated and assuming the Office initially has decided that a recommendation for a petition for certiorari is appropriate, the process works as follows:



1. The attorney should prepare a signature package for review and approval by the Chief Counsel, which package shall include an Action Memorandum. The Action Memorandum should briefly describe the adverse court opinion, Service position, and the administrative significance or other reason for potentially recommending filing a petition for certiorari.

2. The package is first sent to the Associate Chief Counsel who will forward it to the Chief Counsel through the responsible Deputy Chief Counsel. Since the General Counsel, Treasury must approve the petition for certiorari, this package serves two purposes. It allows the Chief Counsel to review and approve the draft recommendation to the Department of Justice. It also transmits this recommendation to Treasury for consideration and approval.

3. The Chief Counsel will sign the Action Memorandum to the General Counsel, Treasury, and the Associate Chief Counsel will transmit the Action Memorandum to the General Counsel via email.

4. Once approval by the General Counsel is received, the Associate Chief Counsel can sign the letter and deliver it to the Department of Justice.


2. The responsible Associate will forward the following documents to the Chief Counsel for review and concurrence:



   - Transmittal document transmitting the package to the Chief Counsel

   - Draft undated letter to the Department of Justice recommending certiorari

   - Draft Action Memorandum from the Chief Counsel to the General Counsel (Exhibit 36.4.1–3).

   - Copies of the relevant opinion and other attachments, if any


3. Once the Chief Counsel has approved the draft letter and signed the Action Memorandum, the package will be returned to the appropriate Associate Chief Counsel for handling. The Associate will transmit scanned copies of the following documents to the General Counsel, Treasury, via email:



   - Action Memorandum to the General Counsel signed by the Chief Counsel

   - Copy of the draft letter to the Department of Justice

   - Copy of the opinion and other attachments


### Note:

The email should highlight the critical dates when action is required. The signed Action Memorandum should be scanned and attached to the email. (Exhibit 36.4.1-2).

4. The General Counsel, Treasury, will be responsible for clearance of the matter with the appropriate Treasury officials. Once the General Counsel informs the Associate office that Treasury concurs in the recommendation, the Associate will sign the letter and forward the package to the Department of Justice. Copies of the letter will also be forwarded to any of the Associates or Division Counsel who were involved in developing the letter.


**36.2.2.5.1.6** **(08-11-2004)**

##### Letter Recommending No Certiorari

1. When attorneys do not recommend certiorari, they should exercise common sense in deciding the scope and content of the letter.



1. When the issues lost are not primarily factual, the letter should discuss the adverse holding in relation to the Service positions sufficiently to provide a basis for informed judgment. If the issues are primarily factual, an extensive discussion generally is not required.

2. If it is clear that certiorari is not appropriate, no information memorandum is prepared and no formal coordination is required.

3. Attorneys should exercise caution so as not to make statements that could adversely affect future recommendations in similar cases or might prematurely commit the Service on controversial or unresolved positions.

4. Generally, attorneys should avoid phrases such as "no administrative importance." Instead, use phrases such as "in the absence of a conflict, the issue currently lacks sufficient administrative importance to warrant a petition for writ of certiorari."

5. A recommendation not to apply for writ of certiorari does not, itself, indicate an acceptance of the court of appeal's opinion.


2. When the Associate Chief Counsel attorney and branch reviewer recommend against certiorari or the Associate Chief Counsel decides against certiorari, an action memorandum is _not_ prepared and the recommendation does not have to be formally reported to the Chief Counsel. Should, however, the responsible Associate Chief Counsel decide to recommend certiorari, the above certiorari procedures will be followed.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part36/irm_36-002-002#addtoany "Show all")

A2A