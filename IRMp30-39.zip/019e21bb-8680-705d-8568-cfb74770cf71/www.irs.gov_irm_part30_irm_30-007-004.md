---
url: "https://www.irs.gov/irm/part30/irm_30-007-004"
title: "30.7.4 Programs and Special Topics | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part30/irm_30-007-004#main-content)

- 30.7.4 [Programs and Special Topics](https://www.irs.gov/irm/part30/irm_30-007-004#idm140203704318880)
  - 30.7.4.1 [Programs and Special Topics](https://www.irs.gov/irm/part30/irm_30-007-004#idm140203704374848)
  - 30.7.4.2 [The Employee Suggestion Program](https://www.irs.gov/irm/part30/irm_30-007-004#idm140203704402928)

    - 30.7.4.2.1 [Submission of Suggestions](https://www.irs.gov/irm/part30/irm_30-007-004#idm140203704336528)

      - 30.7.4.2.1.1 [Criteria for the ESP](https://www.irs.gov/irm/part30/irm_30-007-004#idm140203704417360)
      - 30.7.4.2.1.2 [Components of the Suggestion](https://www.irs.gov/irm/part30/irm_30-007-004#idm140203704338816)

    - 30.7.4.2.2 [Evaluation of Suggestions](https://www.irs.gov/irm/part30/irm_30-007-004#idm140203678482976)
    - 30.7.4.2.3 [Suggestions Adopted by the Office of Chief Counsel](https://www.irs.gov/irm/part30/irm_30-007-004#idm140203674069152)
    - 30.7.4.2.4 [Reconsideration of Suggestions](https://www.irs.gov/irm/part30/irm_30-007-004#idm140203671278544)

# Part 30. Administrative

# Chapter 7. Management Systems

# Section 4. Programs and Special Topics

* * *

## 30.7.4 Programs and Special Topics

#### Manual Transmittal

January 07, 2014

#### Purpose

(1) This transmits revised CCDM 30.7.4, Management Systems; Programs and Special Topics.

#### Material Changes

(1) CCDM 30.7.4.2.1.1 was revised to emphasize that all three components of a suggestion must be present, add examples of suggestions that would be excluded from consideration because they call attention to routine maintenance or repair work, and clarify that proposals pertaining to other agencies are outside the IRS' mission.

#### Effect on Other Documents

CCDM 30.7.4, dated May 01, 2013, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(01-07-2014)

Michael T. Cochis

Director, Planning and Management Division

**30.7.4.1** **(10-02-2007)**

### Programs and Special Topics

1. This section covers a range of subjects, including the Employee Suggestion Program.


**30.7.4.2** **(10-02-2007)**

### The Employee Suggestion Program

1. The Employee Suggestion Program provides employees with the opportunity to submit constructive proposals that identify and describe a specific need for improvement, and propose a solution.

2. The suggestion must directly contribute to the economy, efficiency or effectiveness of government operations.

3. An employee who submits a suggestion will receive a prompt, objective and fair evaluation of the proposal, and may receive an award if the suggestion is adopted.


**30.7.4.2.1** **(05-01-2013)**

#### Submission of Suggestions

1. The Office of Chief Counsel participates in the Employee Suggestion Program (ESP) overseen by the IRS Human Capital Office. Employees submit suggestions through an online system that is available at Employee Suggestion Program homepage.



1. If an employee does not have access to the ESP system, he/she may submit a suggestion by completing and signing Form 13380, I Suggest . . ..

2. If an employee submits a suggestion by using Form 13380, the signed form must be given to an Administrative Officer or Finance and Management (F&M) Office Manager, who will input the information into the ESP system. Where possible, the Form 13380 from the employee should be electronically scanned and loaded into the ESP system as an attachment.


2. Various user guides and handbooks are available on the ESP website for assistance in developing suggestions and submitting them through the online system. Prior to submitting a suggestion, employees are encouraged to search the ESP system for similar suggestions via the _"Search"_ screen.

3. Chief Counsel employees are not limited to submitting suggestions related to Chief Counsel operations. Suggestions may address any procedures or systems within IRS.

4. Two or more employees may jointly submit a suggestion; any award granted would be shared equally.


**30.7.4.2.1.1** **(01-07-2014)**

##### Criteria for the ESP

1. In order to be considered an acceptable suggestion, the suggestion must be constructive, _i.e._, it must contribute to the economy, efficiency or effectiveness of Chief Counsel or IRS operations.

2. The suggestion **must** include the following three elements:



1. A statement of the problem or a description of the current situation,

2. The proposed solution to the problem, and

3. An explanation of the possible benefits of the suggestion


### Caution:

Suggestions that are not constructive or do not contain these three elements will not be considered for adoption.

3. The following types of suggestions are specifically **excluded from consideration** under the Employee Suggestion Program:



   - Duplicates of a suggestion already under consideration, or one that was considered within the preceding two years

   - Suggestions where the potential benefit(s) would not offset the cost of implementation

   - Suggestions to correct typographical errors in printed or published products

   - Suggestions that call attention to routine maintenance or repair work, _e.g._, software fixes and upgrades that a part of the normal course of business

   - Suggestions to improve working conditions, _e.g._, air conditioning, decorations, furniture

   - Suggestions for routine or normal safety practices

   - Suggestions for employee services and benefits, _e.g._, vending machines, cafeteria services, parking facilities, holidays

   - Complaints, grievances or other proposals that do not include a specific means for improving operations in the Office of Chief Counsel or the Service

   - Suggestions that are clearly within the employee’s job responsibilities, unless they are so superior and/or meritorious that they warrant special consideration

   - Proposals that are outside the IRS' mission, _e.g._, suggestions pertaining to operations in other Federal agencies or bureaus


**30.7.4.2.1.2** **(05-01-2013)**

##### Components of the Suggestion

1. **Statement of the Problem**. The suggestion must contain specific details identifying the item, procedure or program that is the subject of the proposal; the problem that results from the current situation; and the impact the problem has on IRS/Chief Counsel operations, employees or the public.

2. **Proposed Solution**. The suggestion must fully describe how the suggestion would address the problem, where the suggestion would be used, what procedures or internal directives would need to be changed, etc.

3. **Possible Benefits**. The suggestion must describe the benefits that would result from implementation of the change, including either or both of the following types:



   - _Tangible Benefits_ — Improvements that can be identified entirely in terms of a dollar amount, _e.g._, labor, travel, training, supplies

   - _Intangible Benefits_ — Improvements that cannot be expressed solely in monetary terms, _e.g._, quality, morale, decreased employee turnover, reduction of taxpayer burden


4. Although the submitting employee is not required to prepare a cost benefit analysis, suggestions should include sufficient information for such an analysis to be completed during the review.



### Example:





– Time currently being used versus time potentially saved

– The grades and number of employees affected

– Volumes involved

– Frequency of work performed

– Expenditures required for implementation, such as training, equipment, etc.

5. The required fields in the _"I Suggest"_ screen on the ESP system must be completed. Additional information that supports the suggestion can be loaded by following the _" add attachments"_ instructions.



### Caution:



The ESP system is not a secure system and should not contain taxpayer data, nor disclose information subject to the Privacy Act.

6. Some of the fields in the _"I Suggest"_ screen will be automatically completed when the employee accesses the system. Changes to this employee information can be made via the _" Edit Profile"_ screen.



### Note:



If employees who have submitted suggestions leave the Office of Chief Counsel or the IRS before the evaluation process is completed, they should provide the ESP Program Manager with a forwarding address.


**30.7.4.2.2** **(05-01-2013)**

#### Evaluation of Suggestions

1. The Office of Chief Counsel’s ESP Program Manager in the Planning and Finance Division (CC:FM:PM) will review submitted suggestions for completeness and adherence to the criteria in CCDM 30.7.4.2.1.1.



1. Incomplete suggestions will be returned to the submitter for additional information. If the suggestions are not completed and returned to the ESP Program Manager within 30 days the suggestion will be closed.

2. Suggestions that do not meet the ESP criteria will be declined.


2. Suggestions under consideration may be evaluated by one or more of the following:



   - Chief Counsel and IRS ESP Program Managers

   - ESP Suggestion Coordinators in Chief Counsel and IRS

   - Subject matter experts in applicable program area(s)


3. Suggestions are identified by the number assigned in the ESP system; those submitted by Chief Counsel employees begin with "88" . The identification number also contains a fiscal year code.

4. The process of evaluation consists of:



1. Identifying and analyzing the costs, benefits, advantages and disadvantages of a suggestion

2. Determining whether a suggestion’s implementation is feasible, considering time, resources, policy, regulations, and law

3. Recommending whether a suggestion should be implemented (" adopted" )

4. Determining whether an award should be recommended


5. The resources located on the ESP website under the "Evaluators" tab, including requisite suggestion processing timeframes, should be used in the evaluation process.

6. The results of the analysis and review will be documented on Form 2665, Suggestion Evaluation. The form can be accessed through either the ESP system or the IRS Forms Catalog. The evaluator will upload both the Form 2665 and supporting documentation to the ESP system.

7. After the final review, suggestions will be forwarded to the appropriate Approving Official with a draft decision letter. (Templates for decision letters are available on the ESP website.) "Approving Officials" are managers with the authority to decide whether the suggestion will be implemented/adopted in whole or in part, and, if implemented, whether an award will be given.

8. A decision letter signed by the Approving Official will be sent to the employee (or employees in the case of a group suggestion) stating whether the suggestion will be adopted. A copy of the letter will be uploaded to the ESP system and the suggestion will be closed.


**30.7.4.2.3** **(05-01-2013)**

#### Suggestions Adopted by the Office of Chief Counsel

1. If the Approving Official is in the Office of Chief Counsel, the suggestion evaluator will prepare a cover memorandum recommending adoption, and summarizing the principal benefits and costs described on the Form 2665. The package will contain all of the following:



   - Description of actions necessary for implementation, _e.g._, changes to processes, procedural guidance, system modifications, purchases

   - The completed Form 2665

   - A draft decision letter

   - A completed Form 9127, Recommendation for Recognition


2. Due to the nature of the suggestion, implementation may require the concurrence of several organizations. In this case the Approving Official with the primary program interest will be responsible for obtaining the concurrence(s) required to implement the suggestion.

3. After the Approving Official makes the decision to implement the suggestion in whole or in part, or to disapprove its implementation, the complete package will be forwarded to Chief Counsel's ESP Program Manager (CC:FM:PM).

4. Approved Forms 9127 will be forwarded by the ESP Program Manager to the IRS Human Capital Office for funds certification. All suggestion awards are paid from the fund maintained by the ESP Servicewide Program Office.

5. The Approving Official will take the necessary action(s) to implement the suggestion.


**30.7.4.2.4** **(05-01-2013)**

#### Reconsideration of Suggestions

1. An incomplete suggestion that has been returned to an employee may be resubmitted within 30 days with the necessary information added.

2. After a suggestion has been evaluated and the decision was made to either adopt or not adopt the suggestion, a request for reconsideration must be submitted within two years of the date of the final decision letter. A request for reconsideration may be submitted by employees or their manager if:



   - They have information showing that the suggestion was not properly evaluated

   - They can provide new data or facts that would materially affect the evaluation decision

   - They can show that an award amount, if paid, was not properly derived, _i.e._, they want the estimated tangible savings used to calculate the award amount re-evaluated to determine if the actual savings exceed the projected amount


3. Chief Counsel employees should submit their request for reconsideration through the online system. If an employee can not access the ESP system, a written request for reconsideration may be given to an Administrative Officer or F&M Office Manager, who will submit the request via the ESP system. The ESP Program Manager will forward requests that meet the criteria above to the appropriate Chief Counsel or IRS organization for reconsideration.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part30/irm_30-007-004#addtoany "Show all")

A2A