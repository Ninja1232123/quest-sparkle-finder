---
url: "https://www.irs.gov/irm/part32/irm_32-001-003"
title: "32.1.3 Substantive Development of a Regulation Project | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part32/irm_32-001-003#main-content)

- 32.1.3 [Substantive Development of a Regulation Project](https://www.irs.gov/irm/part32/irm_32-001-003#idm139733168628048)
  - 32.1.3.1 [Introduction](https://www.irs.gov/irm/part32/irm_32-001-003#idm139733167963296)
  - 32.1.3.2 [The Drafting Team](https://www.irs.gov/irm/part32/irm_32-001-003#idm139733167960512)
  - 32.1.3.3 [Issue Identification](https://www.irs.gov/irm/part32/irm_32-001-003#idm139733167958560)
  - 32.1.3.4 [Issues Memorandum](https://www.irs.gov/irm/part32/irm_32-001-003#idm139733167951088)
  - 32.1.3.5 [Impact on Electronic Filing](https://www.irs.gov/irm/part32/irm_32-001-003#idm139733167948352)

# Part 32. Published Guidance and Other Guidance to Taxpayers

# Chapter 1. Chief Counsel Regulation Handbook

# Section 3. Substantive Development of a Regulation Project

* * *

## 32.1.3 Substantive Development of a Regulation Project

#### Manual Transmittal

August 01, 2018

#### Purpose

(1) This transmits revised CCDM 32.1.3, Regulation Handbook, Substantive Development of a Regulation Project.

#### Background

CCDM 32.1.3, Substantive Development of a Regulation, Project is being revised to clarify that public comments include public hearing documents.

#### Material Changes

(1) This section revises procedures for developing the issues to be covered in a regulation project formerly contained in Part 30, and in memoranda, guides, and other Chief Counsel documents.

#### Effect on Other Documents

This section supersedes CCDM 32.1.3, dated April 11, 2004.

#### Audience

Chief Counsel

#### Effective Date

(08-01-2018)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**32.1.3.1** **(08-01-2018)**

### Introduction

1. The Chief Counsel, the Associate Chief Counsel, or Treasury typically assigns a completion date to each regulation project. Upon assignment to a project, the drafting team should prepare a time line setting interim goal dates designed to ensure that the project meets its set completion date. The time line should include deadlines for required administrative procedures; the preparation of an issues memorandum and drafts of the guidance; front office briefings and, to the extent necessary, briefings with the Chief Counsel (or a Deputy Chief Counsel) and Treasury personnel. _See_ CCDM 32.1.2.6.2 for a discussion of Milestones.


**32.1.3.2** **(08-11-2004)**

### The Drafting Team

1. Once the decision has been made to issue guidance on an issue, the Associate assigns the project to a drafting team consisting, at a minimum, of a branch attorney and reviewer. The drafting team is responsible for complying with the requirements for processing and publishing a regulation and the requirements imposed by Federal administrative law.


**32.1.3.3** **(08-01-2018)**

### Issue Identification

1. The drafting team must check LEXIS or Westlaw to determine if any other regulations are affected by the regulation project so that the other regulations can be changed if necessary and to determine if any form of other published guidance needs to be changed because of the regulation project.

2. The drafting team should conduct thorough research. When developing the substantive issues in a regulation project, the drafting team should consult the following sources:



   - Statutes, including newly enacted provisions and related provisions

   - Legislative history, particularly House Ways and Means and Senate Finance Committees, and Conference Reports

   - General explanation of a particular tax act prepared by the staff of the Joint Committee on Taxation (Blue Book)

   - Case law, including briefs

   - Published guidance and background files, and other IRS documents (including PLRs, TAMs, and GCMs)

   - Law review articles and articles in other periodicals

   - IRS and Treasury personnel

   - Public comments received on an NPRM, including at any public hearing or public meetings

   - Taxpayer and practitioner questions and inquiries


3. The drafting team should be aware of any effective date issues. Section 7805(b) of the Code contains rules regarding the authority of the Treasury and the IRS to issue retroactive regulations. The statutory effective date must also be considered when issuing regulations on a newly enacted statutory provision.


**32.1.3.4** **(08-01-2018)**

### Issues Memorandum

1. In some cases, the drafting team may need to prepare a formal issues memorandum to assist the Chief Counsel, the Associate Chief Counsel, or Treasury in making the necessary technical and policy decisions. The memorandum should identify the significant issues raised in the project and should include an analysis and recommended resolution. The drafting team should present alternative and opposing positions in the issues memorandum.

2. The issues memorandum may serve as the basis for meetings to discuss the issues and may be used during higher level briefings as well. The issues memorandum may be abbreviated for use in informal meetings, but may require more detail for higher level briefings.


**32.1.3.5** **(08-11-2004)**

### Impact on Electronic Filing

1. Eliminating electronic filing impediments is an important consideration in evaluating any regulation. Regulations should avoid, to the extent possible, prescribing new paper submissions of statements or forms to be filed with tax returns.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part32/irm_32-001-003#addtoany "Show all")

A2A