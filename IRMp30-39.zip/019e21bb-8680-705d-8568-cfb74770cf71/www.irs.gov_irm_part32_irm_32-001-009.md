---
url: "https://www.irs.gov/irm/part32/irm_32-001-009"
title: "32.1.9 Closing a Regulation Project | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part32/irm_32-001-009#main-content)

- 32.1.9 [Closing a Regulation Project](https://www.irs.gov/irm/part32/irm_32-001-009#idm139733168639104)
  - 32.1.9.1 [Criteria for Closing a Regulation Project](https://www.irs.gov/irm/part32/irm_32-001-009#idm139733167425920)
  - 32.1.9.2 [Final Regulation Published](https://www.irs.gov/irm/part32/irm_32-001-009#idm139733167433792)
  - 32.1.9.3 [NPRM Published But Will Not be Finalized](https://www.irs.gov/irm/part32/irm_32-001-009#idm139733167430016)
  - 32.1.9.4 [No Regulation Published](https://www.irs.gov/irm/part32/irm_32-001-009#idm139733168665488)
  - 32.1.9.5 [Closed Regulation File Assembly](https://www.irs.gov/irm/part32/irm_32-001-009#idm139733152373088)
  - Exhibit 32.1.9-1 [Sample Withdrawal of Notice of Proposed Rulemaking](https://www.irs.gov/irm/part32/irm_32-001-009#idm139733167384288)
  - Exhibit 32.1.9-2 [Sample Closing Memorandum by Nonpublication](https://www.irs.gov/irm/part32/irm_32-001-009#idm139733167381232)
  - Exhibit 32.1.9-3 [Form 9506, TD File Closing: Information Sheet and Assembly Checklist](https://www.irs.gov/irm/part32/irm_32-001-009#idm139733167379312)

# Part 32. Published Guidance and Other Guidance to Taxpayers

# Chapter 1. Chief Counsel Regulation Handbook

# Section 9. Closing a Regulation Project

* * *

## 32.1.9 Closing a Regulation Project

#### Manual Transmittal

August 01, 2018

#### Purpose

(1) This transmits revised CCDM 32.1.9, Regulation Handbook, Closing a Regulation Project.

#### Background

CCDM 32.1.9, Closing a Regulation Project, is being updated to reflect current practices.

#### Material Changes

(1) CCDM 32.1.9.2 is updated to reflect new closing classification codes.

#### Effect on Other Documents

This section supersedes CCDM 32.1.9, dated August 11, 2004.

#### Audience

Chief Counsel

#### Effective Date

(08-01-2018)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**32.1.9.1** **(08-01-2018)**

### Criteria for Closing a Regulation Project

1. A regulation project can be closed only after



1. The IRS withdraws an NPRM or publishes it as a final regulation,

2. In the case of a temporary regulations with a cross-referencing NPRM, the IRS removes the temporary regulations and withdraws the NPRM or published it as a final regulation, or

3. The IRS decides not to publish a regulation.


**32.1.9.2** **(08-01-2018)**

### Final Regulation Published

1. After a final regulation is published, the drafting attorney should use Form 9506, Treasury Decision File Closing Information Sheet and Assembly Checklist, to assemble and organize the folder(s) of the legal file. The drafting attorney should use a two-hole punch to put holes in the top of each paper or document and put the papers and documents in the folders using file fasteners. The drafting attorney should send the legal file to the Communications, Records, and User Fee Unit (CC:PA:LPD:DRU) in room 5336 as soon as possible after publication of the final regulation.

2. After a final regulation is published, the drafting attorney should ensure that the final regulation is closed on CASE-MIS using status code 951 (closed – publication) and classification code W (Regulations, revenue ruling, revenue procedure, IRB notice & announcement **(non-ministerial)**). The Publications and Regulations Branch enters the Federal Register filing and publication information on CASE-MIS.


**32.1.9.3** **(08-01-2018)**

### NPRM Published But Will Not be Finalized

1. If the IRS will not publish an NPRM as a final regulation, the NPRM should be withdrawn before closing the regulation project. To withdraw a regulation, a withdrawal of notice of proposed rulemaking must be signed by the Commissioner, approved by Treasury, and published in the Federal Register. Once the NPRM is withdrawn, the drafting attorney should assemble the legal file and forward it to the Communications, Records, and User Fee Unit (CC:PA:LPD:DRU). The drafting attorney should ensure that the regulation project is closed on CASE-MIS using status code 960 (closed – withdrawn).

2. Occasionally, the IRS decides not to publish an NPRM as a final regulation and does not issue a withdrawal of notice of proposed rulemaking. In that situation, the regulation project remains open in CASE-MIS with status code 745 (NPRM published) and classification code W (Regulations, revenue ruling, revenue procedure, IRB notice & announcement **(non-ministerial)**). _See_ Exhibit 32.1.9-1, Sample Withdrawal of Notice of Proposed Rulemaking.


**32.1.9.4** **(08-01-2018)**

### No Regulation Published

1. If the IRS will not publish a regulation, prepare a closing memorandum for the signature of the Associate Chief Counsel stating the reason the project is being closed. Include the closing memorandum in the legal file. Send the legal file to the Communications, Records, and User Fee Unit (CC:PA:LPD:DRU) for storage. Files closed by nonpublication will be retained in accordance with the records control schedule set forth in Document 12990, Records and Information Management Records Control Schedules. Close the regulation project on CASE-MIS using status code 952 (closed – non-publication) and classification code W (Regulations, revenue ruling, revenue procedure, IRB notice & announcement **(non-ministerial)**).

2. An open regulation project may be closed by nonpublication for any of the following reasons:



1. The matter involves an issue specifically addressed by another open regulation project,

2. The issue is answered by statute, treaty, or regulations, or will be answered by pending legislation; answered by publications or court opinions previously published in the IRB; involves a determination of fact rather than an interpretation of law; or is of insufficient importance or interest to warrant publication.

3. The matter is recommended for nonpublication by an Associate Chief Counsel, a Division Counsel, the Chief Counsel, the Commissioner, or by a Treasury official.


3. If an open regulation project is identified as an appropriate subject for nonpublication, a nonpublication memorandum is prepared by the drafting attorney for the signature of the Associate Chief Counsel. After the memorandum is approved by the Associate Chief Counsel, the original is included in the case file.

4. The body of the nonpublication memorandum must contain the following in separate paragraphs:



   - Introduction: A statement that the project is under consideration; a description of the regulation project; the date of issuance of any relevant document; and

   - Background or Reason for Nonpublication: A discussion of the developments or events that led to a conclusion that the regulation should be closed by nonpublication. The memorandum should contain sufficient information for the Associate Chief Counsel to determine whether the regulation should be closed without reviewing the file.

   - Action: A direct statement that the project is being closed and no further consideration will be given to its publication.


5. See Exhibit 32.1.9-2, Sample Closing Memorandum by Nonpublication.


**32.1.9.5** **(08-01-2018)**

### Closed Regulation File Assembly

1. Follow the procedures on Form 9506, Treasury Decision File Closing Information Sheet and Assembly Checklist, for assembling the contents of the legal file. See Exhibit 32.1.9-3, Form 9506, TD File Closing: Information Sheet And Assembly Checklist.

2. See CCDM 32.1.2(2) for a list of documents that should be included in the legal file.


**Exhibit 32.1.9-1**

### Sample Withdrawal of Notice of Proposed Rulemaking

![This is an Image: 39004900.gif](https://www.irs.gov/pub/xml_bc/39004900.gif)

> This is a sample withdrawal of notice of proposed rulemaking.

[Please click here for the text description of the image.](https://www.irs.gov/media/157551 "")

![This is an Image: 39004901.gif](https://www.irs.gov/pub/xml_bc/39004901.gif)

> This is page 2 of a sample withdrawal of notice of proposed rulemaking.

[Please click here for the text description of the image.](https://www.irs.gov/media/157556 "")

**Exhibit 32.1.9-2**

### Sample Closing Memorandum by Nonpublication

![This is an Image: 39004902.gif](https://www.irs.gov/pub/xml_bc/39004902.gif)

> This is a sample closing memorandum by nonpublication

[Please click here for the text description of the image.](https://www.irs.gov/media/157561 "")

**Exhibit 32.1.9-3**

### Form 9506, TD File Closing: Information Sheet and Assembly Checklist

![This is an Image: 39004001.gif](https://www.irs.gov/pub/xml_bc/39004001.gif)

> This is a Form 9506, TD File Closing: Information Sheet and Assembly Checklist

[Please click here for the text description of the image.](https://www.irs.gov/media/157566 "")

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part32/irm_32-001-009#addtoany "Show all")

A2A