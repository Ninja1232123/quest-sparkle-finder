---
url: "https://www.irs.gov/irm/part35/irm_35-003-001"
title: "35.3.1 Motions Practice | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-003-001#main-content)

- 35.3.1 [Motions Practice](https://www.irs.gov/irm/part35/irm_35-003-001#idm140344673072768)
  - 35.3.1.1 [Scope](https://www.irs.gov/irm/part35/irm_35-003-001#idm140344673064960)
  - 35.3.1.2 [Tax Courts Rules on Pleadings and Motions](https://www.irs.gov/irm/part35/irm_35-003-001#idm140344678957536)
  - 35.3.1.3 [Effect of Tax Court Rule 33(b) Upon Tax Court Pleadings](https://www.irs.gov/irm/part35/irm_35-003-001#idm140344673120880)
  - 35.3.1.4 [Direct Service and Filing by Mail of Motions](https://www.irs.gov/irm/part35/irm_35-003-001#idm140344673167712)
  - 35.3.1.5 [Motions Session](https://www.irs.gov/irm/part35/irm_35-003-001#idm140344677232432)
  - 35.3.1.6 [Respondents Attorney at Motions Session](https://www.irs.gov/irm/part35/irm_35-003-001#idm140344673027856)
  - 35.3.1.7 [Information and Files for Use of Motions Attorneys](https://www.irs.gov/irm/part35/irm_35-003-001#idm140344673149344)
  - 35.3.1.8 [Timely Submission of Information to Associate Chief Counsel (P&A), Branch 6 or 7](https://www.irs.gov/irm/part35/irm_35-003-001#idm140344673010624)
  - 35.3.1.9 [General Procedures for Petitioners Motions](https://www.irs.gov/irm/part35/irm_35-003-001#idm140344673122656)
  - 35.3.1.10 [Petitioners Motions in Cases Having Criminal Aspects](https://www.irs.gov/irm/part35/irm_35-003-001#idm140344673059984)
  - 35.3.1.11 [Agreed Motions](https://www.irs.gov/irm/part35/irm_35-003-001#idm140344673163920)
  - 35.3.1.12 [Burden of Proof Upon Respondent and Jurisdictional Motions](https://www.irs.gov/irm/part35/irm_35-003-001#idm140344673145024)
  - 35.3.1.13 [Petitioners Motions to Dismiss](https://www.irs.gov/irm/part35/irm_35-003-001#idm140344673052544)
  - 35.3.1.14 [Motions to Shift the Burden of Proof](https://www.irs.gov/irm/part35/irm_35-003-001#idm140344673049776)
  - 35.3.1.15 [More Than One Motion Pending in Same or Related Case](https://www.irs.gov/irm/part35/irm_35-003-001#idm140344673136432)
  - 35.3.1.16 [Continuance of Hearings at Motions Sessions](https://www.irs.gov/irm/part35/irm_35-003-001#idm140344673134880)
  - 35.3.1.17 [Form of Motions](https://www.irs.gov/irm/part35/irm_35-003-001#idm140344678951824)
    - 35.3.1.17.1 [Form and Appearance of Motion](https://www.irs.gov/irm/part35/irm_35-003-001#idm140344673108112)
    - 35.3.1.17.2 [Title of Motion](https://www.irs.gov/irm/part35/irm_35-003-001#idm140344673015344)
    - 35.3.1.17.3 [Introductory Paragraph](https://www.irs.gov/irm/part35/irm_35-003-001#idm140344673013456)
    - 35.3.1.17.4 [Grounds in Support of the Motion](https://www.irs.gov/irm/part35/irm_35-003-001#idm140344672992816)
    - 35.3.1.17.5 [Prayer of Motion](https://www.irs.gov/irm/part35/irm_35-003-001#idm140344673152608)

# Part 35. Tax Court Litigation

# Chapter 3. Motions

# Section 1. Motions Practice

* * *

## 35.3.1 Motions Practice

#### Manual Transmittal

May 03, 2019

#### Purpose

(1) This transmits revised CCDM 35.3.1, Motions; Motions Practice.

#### Material Changes

(1) This section is being revised to further conform Part 35 to the realignment addressed in Chief Counsel Notice 2007-012.

#### Effect on Other Documents

This section supersedes CCDM 35.3.1, dated August 11, 2004.

#### Audience

Chief Counsel

#### Effective Date

(05-03-2019)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**35.3.1.1** **(05-03-2019)**

### Scope

1. Motions practice is an important aspect in the handling of Tax Court litigation. Proper action by way of motions may not only expedite the handling and disposition of cases, improve pleadings and narrow the issues, eliminate the necessity of proof of certain facts, and facilitate trial matters, but may be essential in determining whether or not the Tax Court has jurisdiction of the case. This is not to say, however, that a motion should be filed for every defect in the petitioner’s pleading. Motions should only be filed in situations in which there is a substantial basis therefor and a desired objective in the handling of the case to be achieved. The Field attorney should recognize promptly any situation in which a motion should be filed and take action at the earliest possible date. The reviewer, however, should examine whether a motion should be filed and whether the proposed motion is the type which will accomplish the desired results. When in doubt, the reviewer should consult with the Associate Chief Counsel (P&A), Branch 6 or 7.

2. Variation in Rulings. The views and actions of the Tax Court on motions vary to a considerable extent, dependent upon which judge holds a particular motions session. Since the court may take various actions with respect to similar motions, the granting or denying of one type of motion is not necessarily an indication of the court’s action on a similar motion which is filed at a later date if heard by a different judge. Thus, Field Counsel should not be guided in total by the granting or denying by the court of a motion in a particular case in determining whether a motion should be filed under similar circumstances in a different case. To the extent feasible, Associate offices will keep Field Counsel advised of the principal actions of the court with respect to certain types of motions.

3. Joinder of Motions. Under T.C. Rule 54, there is a general prohibition on joinder of motions requesting more than one type of action by the court. That rule provides a specific exception for motions to strike and for a more definite statement and for the review of a jeopardy assessment and the review of a jeopardy levy under certain circumstances. Over the years the court has developed a number of additional informal exceptions to the rule. If the Field attorney and reviewer believe motions should be joined which are not included in the list of acceptable motions below, they should consult with Associate Chief Counsel (P&A), Branch 6 or 7 before submitting any such document to the court. Presently acceptable joinders include:



   - Motion for More Definite Statement and to Strike

   - Motion to Calendar and Consolidate

   - Motion to Calendar and Consolidate or, in the Alternative, to Continue

   - Motion to Consolidate Cases and to Sever Issues for Trial

   - Motion to Compel Responses to Interrogatories and, in the Alternative, to Impose Sanctions

   - Motion to Compel Production of Documents and, in the Alternative, to Impose Sanctions

   - Motion to Compel Responses to Interrogatories and Production of Documents

   - Motion to Compel Responses to Interrogatories, Production of Documents and, in the Alternative, to Impose Sanctions

   - Motion for Review of Jeopardy Assessment and for Review of Jeopardy Levy

   - Motion to Dismiss for Lack of Jurisdiction and to Change Caption

   - Motion to Dismiss for Lack of Jurisdiction and to Strike

   - Motion for Summary Judgment and to Impose Sanctions


**35.3.1.2** **(05-03-2019)**

### Tax Court’s Rules on Pleadings and Motions

1. Each Field attorney and each reviewer must be thoroughly familiar with the Tax Court’s rules on pleadings and motions and with the court’s interpretations of its rules.

2. Motions with respect to the petition must generally be filed within 45 days after service of the petition upon respondent, and answers must generally be filed within 60 days after such service. Other time periods apply in disclosure actions and small tax cases. The time for filing is variable under section 7503 and T.C. Rule 25 where the expiration date falls on a Saturday, Sunday, a legal holiday in the District of Columbia, or day appointed as a holiday by the President or Congress. The date of service of the petition is the date the petition is delivered to the Docket and Records Section, and can be confirmed by checking the Tax Court’s web site at www.ustaxcourt.gov.  The date of service will be reflected on the received date stamped by the Docket and Records Section. These due dates are important in maintaining the office control of the case to see that motions and answers are timely filed. These dates do not necessarily represent the amount of time the Field attorney should use to prepare an appropriate motion or answer. The Field attorney should prepare an answer or motion as soon as possible after receipt of the case and the administrative file and submit such motion or answer to the reviewer with the utmost dispatch.

3. Although a jurisdictional motion may be filed at any time by either party, if the petition does not confer jurisdiction on the court as to either the party or parties involved or as to the tax or taxes involved, a jurisdictional motion should be filed prior to the filing of an answer. If circumstances warrant, a jurisdictional defect can be raised in the answer. For example, lack of jurisdiction as to a claim for attorney’s fee should be raised in the answer. The unified partnership/S corporation audit and litigation procedures (TEFRA) often generate jurisdictional issues which may be raised in the answer rather than by motion. Such matters should generally be coordinated with Associate Chief Counsel (P&A), Branch 6 or 7. _See_ Exhibit 35.11.1–1, Issues Requiring Associate Office Review. If a jurisdictional motion is filed prior to the answer due date, the Field attorney should wait for disposition of the motion before filing the answer. _See_ T.C. Rule 25(c). An answer submitted prior to such time may be rejected for filing by the court.

4. A motion to dismiss for failure to state a claim upon which relief can be granted is to be filed within 45 days after service of the petition. A motion to strike the petition in part is also to be filed within this period. The timely filing of such motions when appropriate is essential to determine what allegations of the petition are to be answered and such motions can narrow the issues for trial. Only in rare cases should a motion for more definite statement in the petition be filed. Instead, the Tax Court generally expects the parties to use discovery to narrow the issues. Coordination with Associate Chief Counsel (P&A), Branch 6 or 7 should be undertaken in case of questions concerning the propriety of filing motions with respect to the petition.

5. If a motion to concerning jurisdiction or the sufficiency of the petition is filed, T.C. Rule 25 provides that the time for the respondent to answer the petition begins to run from the date the Tax Court serves the order disposing of the motion, unless the court directs otherwise. The filing of a jurisdictional motion not only suspends the time to answer, but also stays the period for filing other motions directed at the pleadings. In appropriate cases, motions to sever under T.C. Rules 61 or 62 should be filed where there has been misjoinder of proper parties within the 45-day period described in T.C. Rule 36(a).

6. T.C. Rule 50(a) provides for notice to the court concerning whether a party opponent objects to a moving party’s motion. The court presumes objection to certain motions, e.g., motions to compel discovery, but the requirement of Rule 50(a) should nevertheless be followed for every motion filed by respondent. The Tax Court will strictly enforce the provisions of Rule 50(a) in motions to extend time within which to answer, motions for leave to file answers out of time, and motions for leave to file amendments to answer, and may return unfiled any such motions that do not contain a statement regarding petitioner’s position with respect to the motion. In every motion filed with the Tax Court, the Field attorney shall:



1. Reasonably attempt to contact a party opponent or opposing counsel by telephone (or if time permits by mail) to learn whether an objection exists to the granting of the proposed motion; and

2. State in the motion the fact of objection, if known, as well as the fact of no objection; or

3. State the fact of attempted but unsuccessful contact and the lack of knowledge whether the opposing party objects, if applicable, as the final allegation in the motion.


**35.3.1.3** **(08-11-2004)**

### Effect of Tax Court Rule 33(b) Upon Tax Court Pleadings

1. CCDM 35.2.2.1.1 for a discussion of an attorney’s obligations under T.C. Rule 33(b).


**35.3.1.4** **(08-11-2004)**

### Direct Service and Filing by Mail of Motions

1. CCDM 35.1.3.2 for a detailed description of direct service and filing by mail in general and _see_ Exhibit 35.11.1–1 for issues and motions which must be reviewed by an Associate office before being served or filed.


**35.3.1.5** **(08-11-2004)**

### Motions Session

1. All motions sessions of the court are held in Washington, D.C. The court issues orders calendaring cases for hearing in all cases which are to be included on the motions calendar. With the exception of holiday seasons or special events, the court sits every Wednesday for motions sessions.

2. Joint or agreed motions and sometimes _ex parte_ motions are often acted upon by the court without being calendared for hearing at a motions session unless the court determines that it desires oral arguments thereon. Motions in calendared cases should normally be filed sufficiently in advance of the trial date to permit the court to act prior to the trial session.

3. From time to time the Tax Court calendars for a motions session a case for purposes of a pretrial conference, or for a report as to whether it is to be tried or settled and, if the latter, on the status of the settlement negotiations.


**35.3.1.6** **(05-03-2019)**

### Respondent’s Attorney at Motions Session

1. The respondent is generally represented at the motions sessions in Washington, D.C. by attorneys of Associate Chief Counsel (P&A), Branch 6 or 7, attorneys of Associate Chief Counsel (P&A), Branch 3 or 4 for collection due process cases, and occasionally other Associate office attorneys for specialized motions. A particular motion may justify the Field attorney coming to Washington to argue the motion. This would depend upon a number of factors such as the complicated nature of the argument, the familiarity with all facets of the case needed to present the argument, the amount of tax involved in the case, the distance from Washington, D.C. to the Field Counsel office at which the attorney is stationed, etc. Field Counsel should advise Associate Chief Counsel (P&A), Branch 6 or 7 of any case in which Field Counsel has been authorized by Area Counsel to assume responsibility for presenting the argument at the motions session. Associate Chief Counsel (P&A), Branch 6 or 7 may coordinate such cases with the Field Counsel if necessary. Motions in cases assigned to Field attorneys whose post of duty is in the Washington, D.C. area are generally argued by those attorneys. Field attorneys arguing motions at a Washington, D.C. motions calendar should contact Associate Chief Counsel (P&A), Branch 6 or 7 or other Associate office in appropriate cases to coordinate their proposed argument with the general position of the office on the matter involved.

2. If it is concluded that respondent should be represented at the hearing on the motion by the Field attorney and it becomes necessary to request a change of the date of the hearing in Washington, D.C. to permit the Field attorney’s attendance, petitioner’s counsel should be advised of our motion for a continuance of the hearing date. Also, if it is necessary for Associate Chief Counsel (P&A), Branch 6 or 7 to request a change in the hearing date, Field Counsel will be advised so that it can advise the petitioner’s attorney.

3. In those instances in which it is concluded that the respondent should be represented by a Field attorney, the Field attorney should discuss with Associate Chief Counsel (P&A), Branch 6 or 7, prior to the hearing, the position proposed to be taken on the matter to be heard. This course of action will not be required in all cases, but the Field attorney should allow time prior to the hearing for any discussion with Associate Chief Counsel (P&A), Branch 6 or 7 which may be necessary. The Field attorney should point out any special problems in connection with the hearing on a motion or a T.C. Rule 155 computation at the time the Field attorney sets forth his views on the desirability of the respondent being represented at the hearing by the Field attorney.


**35.3.1.7** **(05-03-2019)**

### Information and Files for Use of Motions Attorneys

1. Field Counsel should recognize the necessity for furnishing complete information at the earliest practicable date with respect to matters which are to be argued at a motions session in Washington, D.C. It is essential that motions attorneys have sufficient time in which to examine all memoranda, data and files, whether it be respondent’s or petitioner’s, submitted by Field Counsel prior to presenting the respondent’s contentions on the motion involved. Only rarely in motions which actually go to hearing is the full position of the respondent set forth in the motion. The legal file should be forwarded together with so much of the administrative file as may be needed by Associate Chief Counsel (P&A), Branch 6 or 7 in the particular case. In circumstances where the legal file must be retained for trial, a complete substitute legal file should be forwarded. In many instances, the court makes inquiries beyond the immediate scope of the motion about the case which will have an indirect effect upon the court’s action. The Field attorney should identify, when forwarding files, the Associate office attorney with whom the Field attorney previously coordinated.

2. In view of the short time frames in handling matters on the motions calendar, when Associate Chief Counsel (P&A), Branch 6 or 7 requests that the legal file or other background information be sent by express mail or by expedited courier service, the material should be sent in accordance with that request. If there is a reason why the Field attorney does not think sending all of the files is necessary, the Field attorney should contact the motion sessions supervisor.

3. If some action has occurred between the time of the filing of the motion and the date of the hearing, the motions attorney should be contacted and informed of the development by the Field attorney. Prior to the hearing, it is the responsibility of the motions attorney to contact the Field attorney to learn of any developments in regard to the motion. It is also the responsibility of the motions attorney to become familiar with legal issues in the case and the factual problems in the case in order to more appropriately answer the questions of the court and to rebut the allegations of petitioner’s counsel. The Field attorney should inform the motions attorney of any facts involving the case or petitioner’s counsel with which the motions attorney should be familiar before appearing on the motion.


**35.3.1.8** **(05-03-2019)**

### Timely Submission of Information to Associate Chief Counsel (P&A), Branch 6 or 7

1. For respondent’s motions, the files should be forwarded to Associate Chief Counsel (P&A), Branch 6 or 7 at the time the motion is calendared for hearing at a Washington, D.C. motions session. The court’s order will be followed by a CATS message requesting transmission of the files to Washington. Thereafter, if there are any changes which would affect the respondent’s contentions or the motion itself, or any documents directly served by petitioner, this information should be promptly sent to the motions attorney. With respect to respondent’s motions not directly filed, the requested material and data in support of the argument on the motion will also be needed in the review of the motion by Associate Chief Counsel (P&A), Branch 6 or 7.

2. With respect to petitioner’s motion, the notice of objection or no objection must be forwarded to the court in ample time to be received prior to the date set by the court for filing an objection to petitioner’s motion and a copy of said notice should be forwarded to Associate Chief Counsel (P&A), Branch 6 or 7. If an objection is called for, then the Field attorney’s views must be received in Associate Chief Counsel (P&A), Branch 6 or 7 at least eight days prior to the date set for the hearing on petitioner’s motion.

3. Substantive tax law issues are sometimes raised by motions, usually in motions for summary judgment or judgment on the pleadings. If, in such a case, the substantive tax law issue requires review by an appropriate Associate office and the court orders the filing of briefs or memoranda of law, these should be reviewed by the appropriate Associate office before being filed with the court and should be received not later than ten calendar days prior to the due date. The Field attorney’s transmittal memorandum should note that the brief or legal memorandum submitted involves significant substantive tax law issues and is in support of respondent’s motion or in opposition to petitioner’s motion.


**35.3.1.9** **(05-03-2019)**

### General Procedures for Petitioner’s Motions

1. With respect to petitioner’s motions which are granted or denied ex parte prior to service by the court, no action is required by Field Counsel unless it is desired to modify the order of the court thereon. For petitioner’s motions not acted upon by the court _ex parte_, the procedures hereinafter set forth are applicable. Motions by petitioner should be opposed only if there are good grounds to do so and not for retaliatory purposes. If appropriate, a memorandum of law in support of a Notice of Objection may be filed. Otherwise, a notification should be filed with the court to the effect that respondent has no objection to the granting of the motion. _See_ Exhibit 35.11.1–32.

2. In considering petitioner’s motions, careful consideration should be given to the purpose of the motion and its justification. This is particularly important in petitioner’s motions with respect to answers or responses to interrogatories. If the answer is inadequate and cannot be defended, an amended answer or response curing the defect should be filed. If an amended answer is to be filed, it should be filed with the court on or prior to the due date set by the court in its notice or order for the respondent to respond to petitioner’s motion. Unless the court’s notice of filing or order permits the filing of an amended answer in lieu of a response to petitioner’s motion, a motion for leave to file the amended answer should be filed if the time for amendment without leave of court has expired. A pro forma response to petitioner’s motion asking the court to deny the motion on the ground that respondent has amended the answer and cured the defect should also be filed.

3. If Field Counsel concludes that a motion should be opposed, or that only certain portions of the motion should be opposed, it may file directly with the court a Notice of Objection containing the reasons for respondent’s opposition. _See_ Exhibit 35.11.1–33. When faced with an unusual or sensitive issue, good judgment requires coordination with the appropriate Associate office before finalizing respondent’s position in court. Coordination in this manner will allow the Field attorney and reviewer to ascertain whether the Service has adopted a position on the issue and, if not, to discuss the issue and alternatives for its resolution so that a uniform position can be applied. Since materials may be forwarded to the Associate offices by overnight mail or by fax, there is no reason why unusual or sensitive issues should not be coordinated. Notices of objection with respect to TEFRA procedural issues should be coordinated with Associate Chief Counsel (P&A), Branch 6 or 7 by telephone, and when time permits, should be forwarded to Associate Chief Counsel (P&A), Branch 6 or 7 for prereview. If a Notice of Objection is forwarded to an Associate office for review, the legal file should be transmitted so as to be received not later than 5 working days before a response date or not later than ten working days prior to a motions session hearing. In appropriate circumstances, the Notice of Objection should be accompanied by the supporting memorandum of points and authorities.

4. In some instances after the oral argument at the motions session, the court requests memorandum briefs on the positions of the parties. The files will generally be returned to Field Counsel for preparation of any such memorandum. In appropriate instances, a post-hearing memorandum may be prepared in Associate Chief Counsel (P&A), Branch 6 or 7 or other Associate office with prior involvement in the case or issue presented.

5. In cases where petitioner’s or respondent’s motions are filed and argued at trial, a copy of respondent’s motion or respondent’s notice of objection and any memorandum in support thereof will be sent to Associate Chief Counsel (P&A), Branch 6 or 7 if the motion or positions presented are ones which Field Counsel believes should be called to the attention of the Associate offices.


**35.3.1.10** **(08-11-2004)**

### Petitioners’ Motions in Cases Having Criminal Aspects

1. _See_ CCDM 35.2.1.1.5.1, CCDM 35.2.2.5, CCDM 35.4.1.5.1, CCDM 35.4.6.4, and CCDM 35.5.3.4 for a discussion of coordination procedures for cases with criminal aspects.

2. _See_ CCDM 35.3.13.12 for a discussion regarding motions to stay civil proceeding.


**35.3.1.11** **(05-03-2019)**

### Agreed Motions

1. It is preferable that motions in which there is no basic disagreement between the parties be joint motions, ex parte motions endorsed No Objection by the opposing party, or motions which contain the statement that the opposite party has no objection. The Field attorney will contact the opposing party and attempt to obtain a statement concerning petitioner’s position on the granting of such motion. If the Field attorney is unable to contact the opposing party, this should be noted in the motion. _See_ CCDM 35.3.1.2(6) for specific instructions. Likewise, if the Field attorney becomes aware that petitioner will file a motion, the Field attorney should make inquiries as to the type and purpose of the motion and determine whether respondent would be in basic opposition thereto. Oftentimes the filing of many motions by the parties can be avoided by an agreement on the course of action to be followed or by the filing of amended pleadings to cure any defect which is apparent.

2. Joint motions or motions endorsed No Objection are processed like other motions and may be directly filed with the court. TEFRA procedural motions generally must be reviewed by Associate Chief Counsel (P&A), Branch 6 or 7 before filing. _See_ Exhibit 35.11.1–1, Tax Court Documents Requiring Associate Office Review. After the execution of the motion on behalf of the Chief Counsel, it is our general practice that the executed document be retained in the possession of respondent’s counsel until it is filed with the court. The petitioner or petitioner’s attorney should, of course, be given a conformed copy of the original document, if requested.

3. Extreme care should be exercised in endorsement or the agreement of no objection to petitioner’s motion, not only as to the relief requested but also to the petitioner’s statements as to the basis of the motion. This is particularly important with respect to motions for continuances from trial sessions on the basis of a pending case in litigation which may affect the instant case, or representations concerning the settlement posture of the case. In this instance, rarely if ever should a mere No Objection endorsement or an agreement of no objection be made. Instead, a Notice of No Objection stating the precise matters on which respondent has no objection, such as the continuance of trial only but not necessarily the grounds therefor recited in petitioner’s motion, should be filed.


**35.3.1.12** **(05-03-2019)**

### Burden of Proof Upon Respondent and Jurisdictional Motions

1. Except for jurisdictional motions, care must be exercised in the filing of a motion to dismiss a case in its entirety in which there is an issue upon which the respondent has a statutory burden of proof or burden of production. This is particularly applicable to all motions with respect to misjoinder of parties and to dismiss the case in its entirety for failure properly to prosecute or for lack of prosecution. These cases usually involve fraud, transferee liability, claim for increased deficiency, the corporate accumulated earnings tax issue, and penalties under section 7491(c).

2. In jurisdictional motions the court does not determine a deficiency or liability whereas in motions to dismiss for failure to state a claim or for lack of prosecution the court determines in its order of dismissal the amount of tax or penalty due from the petitioner, and the case may not be further litigated. With the adoption of T.C. Rule 123(a), which provides for default judgments without a limitation to issues on which the moving party does not bear the burden of proof, the Tax Court provided a procedure for the summary disposal of such cases.

3. A default judgment is available where a party has failed to plead or otherwise proceed as required by the Tax Court rules or by court order. The failure of a petitioner to respond to correspondence alone is not sufficient grounds for a default.

4. The effect of a default judgment is to deem admitted all well-pleaded affirmative allegations in the answer. However, a mere general allegation that the petitioner is liable for the fraud penalty is not sufficient to satisfy the burden of proof. Accordingly, a default judgment should only be sought when the allegations in the answer are sufficiently detailed to support a finding of fraud, or any other issue on which the respondent bears the burden of proof.

5. Other mechanisms may serve to bring expedited resolution to cases which a petitioner has abandoned, but contain issues on which the respondent bears the burden of proof or burden of production. These include deemed admissions under T.C. Rules 37(c) or 90(c), and deemed stipulations under T.C. Rule 91(f).

6. Associate Chief Counsel (P&A), Branch 6 or 7 should be consulted prior to filing any motion for default when the respondent bears the burden of proof or burden of production. _See_ Exhibit 35.11.1–1, Tax Court Documents Requiring Associate Office Review.


**35.3.1.13** **(08-11-2004)**

### Petitioners’ Motions to Dismiss

1. One of the grounds upon which a petitioner may rely for a motion to dismiss for lack of jurisdiction is that a valid statutory notice of deficiency was not issued by the Service. If the petitioner is successful in the motion and the time for issuing a valid statutory notice has expired in the absence of fraud or other statutory exception, the respondent may not be able to issue a new statutory notice. If in a late-filed petition the statutory notice was sent to the wrong address and a defense of actual notice or other defense is not available, a notice of no objection should be filed. If the statute of limitations is still open, this procedure would not preclude issuance of another statutory notice to the correct address.

2. Pro se petitioners sometimes send to the court letters received from the Service which indicate that they have satisfied the Service that there is no deficiency or that the deficiency is in a lesser amount. The court will usually treat such correspondence as petitioner’s motion for entry of decision and order a response from respondent. In most cases, respondent will have no objection to the entry of a no deficiency decision, and a Notice of No Objection should be filed (even if the court’s order suggests that no response need be filed if there is no objection). In the case of an overpayment resulting from the Service’s no change letter, a stipulated decision document will be required from the parties; in that event, a response to the court’s order should state the need for an overpayment decision and be accompanied by the stipulated decision, if possible, or state when such a decision may be expected.


**35.3.1.14** **(05-03-2019)**

### Motions to Shift the Burden of Proof

1. Petitioners occasionally file Motions to Shift the Burden of Proof. The purpose of this section is to outline the response that should be filed to such a motion. _See_ CCDM 35.2.2.3.8 and CCDM 35.4.1.6 for a general discussion of burden of proof.

2. The general rule is that the Service’s deficiency determination is presumed to be correct, and that the petitioner has the burden of proving it to be wrong. T.C. Rule 142(a). A Tax Court case is a proceeding de novo, in which a petitioner’s tax liability for the year(s) in issue can be redetermined; even issues that were not previously examined by the Service may be subject to the Tax Court’s scrutiny, assuming they are timely raised. Therefore, the Tax Court will not, as a general rule, examine the evidence used or the propriety of the Service’s motives or administrative policies or procedures in making the determination of the deficiency. There is a limited exception to the rule that the deficiency determination making process is not to be scrutinized. In unreported income cases, courts have held that the presumption of correctness will not arise when a petitioner shows that the Service’s determination of deficiency is arbitrary and excessive, i.e., without factual foundation or lacking in rational basis. In cases where a petitioner seeks to apply this exception, the petitioner has the burden of producing some reasonable evidence which demonstrates the arbitrary nature of the notice. Once the petitioner produces evidence of the arbitrariness of the Service’s determination, the court will determine whether the Service’s assertion of unreported income is supported by evidence linking the petitioner to an income producing activity. The Service must demonstrate the link to the income producing activity to ensure that he is entitled to the benefit of the presumption of correctness.

3. A variation of the unreported income theory is based on _Portillo v. Commissioner_, 932 F.2d 1128 (5th Cir. 1991). In _Portillo_, the Fifth Circuit held that a notice of deficiency based on the matching of a Form 1099 with the petitioner’s return, with no other information, was arbitrary and lacked a factual foundation. The Fifth Circuit denied the government the benefit of the presumption of correctness, and held that the Service had not met its burden to link the taxpayer to the unreported income reported by the Form 1099. Based on _Portillo_, a number of petitioners have filed motions to shift the burden of proof to the Service. These motions have been filed shortly after the petition or the answer has been filed. They have also been filed in cases where income has been reconstructed on the basis of Bureau of Labor Statistics statistics, the Consumer Price Index, or some combination of information returns, CPI and BLS. Where a motion of this sort is received before a case has been calendared, it may be resisted on the grounds that it is premature, if the time period for discovery has not commenced. T.C. Rule 70(a)(2). The motion may also be resisted on the grounds that the Service’s determination is not arbitrary and suffices to link the petitioner to an income producing activity. At trial, if the petitioner persists in claiming that the statutory notice lacks a factual foundation, respondent must be prepared to produce evidence linking the petitioner to the income producing activity referred to in the statutory notice.

4. For proceedings pending on and after July 30, 1996, section 6201(d) applies. That section, which was added to the Code by section 602 of the Taxpayer Bill of Rights 2 (TBOR2), Pub. L. 104–168, 110 Stat. at 1452, 1463, provides that in any court proceeding, where the taxpayer asserts a reasonable dispute with an item reported on an information return, and the taxpayer has fully cooperated with the Service, the Service has the burden of producing reasonable and probative information concerning such deficiency in addition to such information return. Section 6201. Full cooperation is defined by the statute as a requirement that the taxpayer provide the Service with access to and inspection of all witnesses, information, and documents within his or her control, as reasonably requested by the Service. A taxpayer should also assist the Service by providing leads so that the Service can contact third parties, where necessary. Although the statute does not define what kind of dispute with an information item is reasonable, the Service takes the position that a reasonable dispute goes to the receipt of the income, the timing of the receipt of income, the accuracy of the reported amount, or the taxability of the item to the taxpayer. Disputes based on tax protester type arguments are not reasonable for purposes of this section. The information the Service presents in support of an information item under this section must be reasonable and probative, although, for purposes of defending the motion to shift the burden of proof, it need not be admissible under the Federal Rules of Evidence. In the usual case, the respondent will want to present the business records of the third party who reported the item. Provided that these records are reliable, section 6201(d) should be satisfied by such information.

5. Another form of the motion to shift the burden of proof is based on section 7522, which requires that a notice of deficiency describe the basis for, and the amounts of, the adjustments made in that notice. An inadequate description does not invalidate the notice. An item which is not well explained in the notice of deficiency should be the subject of further allegations in the Service’s answer. _See_ CCDM 35.2.2.4.1. A motion to shift the burden of proof may be filed on the grounds that respondent has raised a new matter within the meaning of T.C. Rule 142(a) if the notice of deficiency failed to adequately describe the deficiency determination. The Tax Court in _Shea v. Commissioner_, 112 T.C. 183 (1999), interpreted the new matter doctrine in connection with section 7522, which requires the Commissioner to issue a notice of deficiency which contains a description of the basis for the Commissioner’s deficiency determination. The Tax Court held that where (1) a notice of deficiency fails to describe the basis on which the Commissioner relies to support the deficiency determination and (2) that determination requires the presentation of evidence that is different from that which would be necessary to resolve the determinations that were described in the notice of deficiency, the Service will bear the burden of proof as to the new matter. Both parts of the _Shea_ test must be met for the court to shift the burden of proof. All motions to shift the burden of proof regarding a new matter should be coordinated with Associate Chief Counsel (P&A), Branch 6 or 7.

6. Petitioners may also seek to shift the burden of proof to respondent pursuant to section 7491. It is respondent’s position that petitioners may only properly seek to shift the burden of proof pursuant to section 7491 after evidence has been presented at trial. _See_ CCDM 35.2.2.3.8 and CCDM 35.4.1.6.1 for a more detailed discussion on shifting the burden of proof pursuant to section 7491.

7. Responding to Summary Judgment Motions. When a taxpayer has filed a motion for partial summary judgment contending that the Service should have the burden of proof by operation of section 7491, Field attorneys should follow the procedures for responding to summary judgment motions outlined in CCDM 35.3.5.3. The conditions required for the Service to bear the burden of proof generally require factual determinations that, if disputed, may not be resolved by summary judgment. In addition, motions for summary judgment based on section 7491(a) should be opposed on the basis that they are premature because a determination that the Service has the burden can only be made after the introduction of credible evidence at trial. A motion for summary judgment or partial summary judgment concerning a substantive issue is premised on the ground that there are no genuine issues of material fact; accordingly, the burden of proof should be irrelevant in consideration of such a motion. Questions involving whether a sufficient factual predicate has been met for a summary judgment motion should be resolved in coordination with the Associate office with subject matter jurisdiction over the issue presented in the motion. Procedural issues concerning the burden of proof should be coordinated with Associate Chief Counsel (P&A), Branch 6 or 7.

8. Responding to motions regarding the burden of proof. When a taxpayer has filed a motion with respect to the burden of proof based on section 7491, Field attorneys should look to CCDM 35.2.2.3.8 and CCDM 35.4.1.2.2 for guidance. If the motion is based on section 7491(a), it may be resisted on the basis that it is premature, as outlined above. Motions on burden of proof under section 7491(b) may also be opposed as premature on the basis that a factual determination is required regarding whether the determination is based solely on BLS or CPI statistics.

9. Associate Chief Counsel (P&A) Coordination and Review. All documents raising a burden of proof issue, including motions regarding the burden of proof, motions for summary judgment on the burden of proof issue and trial memoranda that assert the burden of proof is on the Service by operation of section 7491 should be coordinated with Associate Chief Counsel (P&A), Branch 6 or 7. Additionally, all documents responding to taxpayer claims concerning the burden of proof and cases in which the allocation of the burden of proof remains at issue at trial should be coordinated with Associate Chief Counsel (P&A), Branch 6 or 7. When the allocation of the burden of proof is unresolved at trial, the issue should be briefed and reviewed by Associate Chief Counsel (P&A), Branch 6 or 7. CCDM 35.7.3 and Exhibit 35.11.1–1, Tax Court Documents Requiring Associate Office Review.


**35.3.1.15** **(08-11-2004)**

### More Than One Motion Pending in Same or Related Case

1. If the petitioner files a motion and it is concluded that a cross-motion should be filed on behalf of the respondent, such action should promptly be taken upon receipt of the petitioner’s motion by Field Counsel. This also applies to a motion in a related case. In these situations the motions of the parties usually deal with the same subject matter and should be heard by the court at the same time. Thus, the cross-motion of respondent (or motion in related case) should specifically request that it be set for hearing on the same date that petitioner’s motion is set for hearing. The filing of such motions will not, within itself, satisfy the requirement for making a response to the petitioner’s motion, and the response should set forth the fact that in addition to objecting to petitioner’s motion, the respondent is filing a motion with respect to the same or related case which should be heard at the same time as petitioner’s motion.


**35.3.1.16** **(05-03-2019)**

### Continuance of Hearings at Motions Sessions

1. Problems frequently arise when the respondent requests a continuance on a hearing of the motion at a motions session without a prior agreement of the opposite party. This is particularly true in situations in which respondent files a continuance motion just prior to the hearing date and there is not sufficient time for the court to act upon the motion and serve it upon petitioner’s counsel prior to the hearing date, since the petitioner’s counsel may be on the way to Washington, D.C. for the hearing. The court will be particularly critical of oral motions for continuance made at a calendar to which petitioner or petitioner’s counsel has traveled for the hearing. Respondent’s motions for continuance of hearings at the motions session must be kept to an absolute minimum, and such motions must only be filed under extraordinary circumstances. When they are justified, the motions should be filed in sufficient time for the court to act upon them and, if granted, to serve a copy of granted motions upon petitioners, or their counsel, several days in advance of the hearing date. If possible, a telephone conference should be scheduled with the petitioner’s counsel and the motions judge in order to avoid any inconvenience to the parties when a continuance may be sought at the last minute. Appropriate notification of the filing of such a motion or the scheduling of a conference call to request a continuance should be timely made to Associate Chief Counsel (P&A), Branch 6 or 7.

2. Where respondent has filed a jurisdictional motion and the petitioner desires a settlement conference prior to the hearing on respondent’s motion, it may create a hardship on petitioner if the case is dismissed for lack of jurisdiction prior to settlement negotiations. If the case was not considered by Appeals in nondocketed status, an agreed motion may be filed with the court requesting a continuance of the hearing on respondent’s motion. The file should immediately be forwarded to Appeals for settlement purposes in accordance with Rev. Proc. 2016-22 or superseding Revenue Procedure. If Appeals settles the matter, respondent will proceed to request that the case be dismissed and the settlement will proceed as if it were a nondocketed case. In this instance, the continuance of the hearing should not generally be extended for a period longer than 60 days. This will ordinarily give the petitioner sufficient time within which to negotiate a settlement of the case. The reason for this procedure is that after the case is dismissed for lack of jurisdiction, the tax and penalty must be assessed in accordance with the statutory notice, and Appeals would lose jurisdiction to hold settlement negotiations except under the claim for refund procedures. If the case had been considered by Appeals in nondocketed status, respondent may oppose a continuance on the basis that settlement negotiations have previously been undertaken and were unsuccessful.


**35.3.1.17** **(05-03-2019)**

### Form of Motions

1. The exhibits at CCDM 35.11 illustrate various types of motions. A motion to consolidate two or more cases must include the official caption of each case and its docket number enumerated from the lowest to the highest. If a subsequent motion relates to all petitioners in a group of cases which have been consolidated, the style of the motion must include the official caption for the lowest docket number of the group together with the words et al. and the docket numbers of each case in the group enumerated from the lowest to the highest. Whenever a motion pertains to more than one docketed case, an additional copy should be forwarded for each additional docket number as required under T.C. Rule 23(b).

2. A motion must state in precise and clear language the type of motion being filed, the action or relief desired, and the basis upon which the court is requested to grant the motion. Do not ordinarily join separate independent requests for relief in one motion. _See_ CCDM 35.3.1.1(3) and T.C. Rule 54. In certain types of motions, the court issues orders to show cause prior to final action on the motion. Only rarely, should the motion request the court to issue a show cause order instead of the ultimate action desired by the respondent. For example, orders to show cause are appropriate under T.C. Rule 91(f) and in declaratory judgment actions not requiring a trial, where petitioner refuses to submit the case on the administrative record as required under T.C. Rule 217. Guidance on when a show cause motion may be appropriate to resolve jurisdictional issues or achieve submission of the case to the court for decision may be obtained from Associate Chief Counsel (P&A), Branch 6 or 7.


**35.3.1.17.1** **(08-11-2004)**

#### Form and Appearance of Motion

1. See the Tax Litigation Guidebook on the F&M Intranet website, T.C. Rule 23(d) for information concerning proper form and appearance of motions.


**35.3.1.17.2** **(08-11-2004)**

#### Title of Motion

1. The motion should contain a heading or title indicating the type of motion being filed, such as Motion to Dismiss for Lack of Jurisdiction. The title of the motion must be clear and concise as to the type of motion being filed and be consistent with relief of action requested of the court.


**35.3.1.17.3** **(08-11-2004)**

#### Introductory Paragraph

1. The introductory paragraph in the body of the motion is the moving part of the motion and should set forth in clear and concise language the action for relief requested and, in appropriate instances, the ultimate basis for the relief requested. This may be illustrated as follows:



|     |
| --- |
| THE RESPONDENT MOVES that this case be dismissed for lack of jurisdiction upon the ground that the petition was not filed within the time prescribed by the applicable provisions of the Internal Revenue Code. |


**35.3.1.17.4** **(08-11-2004)**

#### Grounds in Support of the Motion

1. Following the introductory paragraph, the body of the motion sets forth the specific grounds urged in support of the prayer of the motion. This will include the facts and authorities justifying the court granting the motion. Normally, an argument, in its technical sense, should not be included in the motion proper. Also, lengthy citations of case authority should not normally be included in the motion. If it is desirable to submit to the court a written argument in support of the motion or an analysis of the case or other authorities in support thereof, such should be done by a separate Memorandum in Support of Motion which is filed simultaneously with the motion.

2. The introduction to the grounds in support of the motion will be in words as follows: IN SUPPORT THEREOF, the respondent respectfully shows: Following this introduction will be set forth in separate paragraphs for each statement of fact or for each authority the grounds supporting the motion. These separate paragraphs will be numbered 1., 2., 3., etc. The paragraphs should be arranged in logical sequence to lead to the conclusion that the motion should be granted, and the contents thereof should present a sufficient basis for the action or relief requested. There should be a statement pursuant to T.C. Rule 50(a) that petitioner is or is not opposed to the granting of the motion in every motion filed with the court. _See_ CCDM 35.3.1.2(6).


**35.3.1.17.5** **(08-11-2004)**

#### Prayer of Motion

1. The last paragraph of the motion contains a prayer requesting the court to grant the specific action or relief sought. The prayer should be in accord with the title and introductory paragraph of the motion. In most cases a prayer such as WHEREFORE, respondent requests \[the parties request\] that this motion be granted is sufficient. In some cases, the prayer should set forth the specific relief or action sought. This is particularly true in motions in which there are alternative requests. In this instance the prayer must set forth both the principal request and the alternative request.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-003-001#addtoany "Show all")

A2A