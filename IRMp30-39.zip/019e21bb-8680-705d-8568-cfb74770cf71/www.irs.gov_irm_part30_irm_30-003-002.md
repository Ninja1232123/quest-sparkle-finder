---
url: "https://www.irs.gov/irm/part30/irm_30-003-002"
title: "30.3.2 Delegations of Authority and Designations | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part30/irm_30-003-002#main-content)

- 30.3.2  [Delegations of Authority and Designations](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415794771168)
  - 30.3.2.1  [Delegations of Authority to and Functions of Deputies Chief Counsel, Counsel to the National Taxpayer Advocate, Special Counsels and National Counsel](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415793875296)
    - 30.3.2.1.1  [Deputies Chief Counsel](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415764271376)
      - 30.3.2.1.1.1  [Deputy Chief Counsel (Operations)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415795393216)
      - 30.3.2.1.1.2  [Deputy Chief Counsel (Technical)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415794900544)
    - 30.3.2.1.2  [Division Counsel/Associate Chief Counsel (National Taxpayer Advocate Program)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415766583984)
    - 30.3.2.1.3  [Special Counsels and National Counsel](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415794122928)
  - 30.3.2.2  [Delegations of Authority to Associates Chief Counsel and Division Counsel Generally](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415794822864)
    - 30.3.2.2.1  [Delegations of Authority to Both Associates Chief Counsel and Division Counsel](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415764277440)
      - 30.3.2.2.1.1  [Personnel Actions](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415793936656)
      - 30.3.2.2.1.2  [Other Personnel Matters](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415794147264)
      - 30.3.2.2.1.3  [Travel, Relocation, and Related Matters](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415793887440)
      - 30.3.2.2.1.4  [Signature Authority](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415794871376)
      - 30.3.2.2.1.5  [General Duties and Workload](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415794810992)
    - 30.3.2.2.2  [Delegations of Authority to Associates Chief Counsel](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415793953760)
      - 30.3.2.2.2.1  [Delegations of Authority to, and Common Functions of, Associates Chief Counsel with Technical Responsibilities](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415794128544)
    - 30.3.2.2.3  [Delegations of Authority to, and Common Functions of, Division Counsel](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415794582576)
    - 30.3.2.2.4  [Mixed Functions](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415766580272)
    - 30.3.2.2.5  [Deputies Associate Chief Counsel](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415794137440)
    - 30.3.2.2.6  [Redelegation](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415764307744)
  - 30.3.2.3  [Associate Chief Counsel Functional Statements, including Delegations of Authority to Specific Associates Chief Counsel](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415764217552)
    - 30.3.2.3.1  [Associate Chief Counsel (Corporate)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415793921200)
      - 30.3.2.3.1.1  [Subject Matter Responsibility and Functions](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415794901968)
    - 30.3.2.3.2  [Associate Chief Counsel (Finance & Management)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763692816)
      - 30.3.2.3.2.1  [Subject Matter Responsibility](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763462976)
      - 30.3.2.3.2.2  [Functions of the Office of the Associate Chief Counsel (F&M)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763458928)
      - 30.3.2.3.2.3  [Field Support Function](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415765701056)
    - 30.3.2.3.3  [Associate Chief Counsel (Financial Institutions & Products)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415764205808)
      - 30.3.2.3.3.1  [Subject Matter Responsibility and Functions](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763656096)
    - 30.3.2.3.4  [Associate Chief Counsel (General Legal Services)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763420736)
      - 30.3.2.3.4.1  [Area Counsel (General Legal Services)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415793636704)
      - 30.3.2.3.4.2  [Claims, Labor & Personnel Law](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763552384)
      - 30.3.2.3.4.3  [Ethics & General Government Law](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763438672)
      - 30.3.2.3.4.4  [Public Contracts and Technology Law](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763689360)
    - 30.3.2.3.5  [Associate Chief Counsel (Income Tax Accounting)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763831952)
      - 30.3.2.3.5.1  [Subject Matter Responsibility and Functions](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415793525712)
    - 30.3.2.3.6  [Associate Chief Counsel (International)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415793598832)
      - 30.3.2.3.6.1  [Subject Matter Responsibility and Functions](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415764022576)
      - 30.3.2.3.6.2  [Deputies Associate Chief Counsel and Director (APA Program)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763793488)
    - 30.3.2.3.7  [Associate Chief Counsel (Passthroughs & Special Industries)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415766629024)
      - 30.3.2.3.7.1  [Subject Matter Responsibility and Functions](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763861216)
    - 30.3.2.3.8  [Associate Chief Counsel (Procedure & Administration)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763645024)
      - 30.3.2.3.8.1  [Subject Matter Responsibility and Functions](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763724848)
      - 30.3.2.3.8.2  [Deputies Associate Chief Counsel](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763857264)
    - 30.3.2.3.9  [Associate Chief Counsel (Criminal Tax)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763828752)
    - 30.3.2.3.10  [Associate Chief Counsel (Tax Exempt and Government Entities)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763827232)
  - 30.3.2.4  [Division Counsel Functional Statements, including Delegations of Authority to Specific Division Counsel](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763824848)
    - 30.3.2.4.1  [Division Counsel/Associate Chief Counsel (Criminal Tax)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763512144)
      - 30.3.2.4.1.1  [Subject Matter Responsibility and Functions](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415757505488)
      - 30.3.2.4.1.2  [Deputy Division Counsel/Deputy Associate Chief Counsel (Criminal Tax)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415766625616)
      - 30.3.2.4.1.3  [Senior Level Counsel](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415766621072)
      - 30.3.2.4.1.4  [Special Counsel](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415757478160)
      - 30.3.2.4.1.5  [Assistant Chief Counsel (Criminal Tax)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415757474624)
      - 30.3.2.4.1.6  [Area Counsel and Deputy Area Counsel (Criminal Tax)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415757572848)
    - 30.3.2.4.2  [Division Counsel (Large & Midsize Business)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415764009296)
      - 30.3.2.4.2.1  [Subject Matter Responsibility and Functions](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415764005216)
      - 30.3.2.4.2.2  [Area Counsel (Large & Mid-Size Business)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415764088896)
      - 30.3.2.4.2.3  [Associate Area Counsel (Large & Mid-Size Business)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415764080256)
    - 30.3.2.4.3  [Division Counsel (Small Business/Self-Employed)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415757516800)
      - 30.3.2.4.3.1  [Subject Matter Responsibility and Functions](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415757510912)
      - 30.3.2.4.3.2  [Assistant Division Counsel (Small Business/Self-Employed)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763539584)
      - 30.3.2.4.3.3  [Area Counsel (Small Business/Self-Employed)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763535456)
      - 30.3.2.4.3.4  [Associate Area Counsel (Small Business/Self-Employed)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763569232)
    - 30.3.2.4.4  [Division Counsel (Strategic Litigation)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763567360)
      - 30.3.2.4.4.1  [Subject Matter Responsibility and Functions](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763562592)
      - 30.3.2.4.4.2  [Deputy Division Counsels (Strategic Litigation)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415793648720)
      - 30.3.2.4.4.3  [Strategic Litigation Counsels (Strategic Litigation)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415793643936)
    - 30.3.2.4.5  [Division Counsel/Associate Chief Counsel (Tax Exempt & Government Entities)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763403424)
      - 30.3.2.4.5.1  [Functions of the Division Counsel/Associate Chief Counsel (TEGE)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763394720)
      - 30.3.2.4.5.2  [Deputies Division Counsel/Deputies Associate Chief Counsel (Tax Exempt & Government Entities)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763877392)
      - 30.3.2.4.5.3  [Deputy Division Counsel/Deputy Associate Chief Counsel (Employee Benefits)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763870544)
      - 30.3.2.4.5.4  [Deputy Division Counsel/Deputy Associate Chief Counsel (Exempt Organizations/Employment Tax/Government Entities)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763819152)
      - 30.3.2.4.5.5  [Deputy Division Counsel/Deputy Associate Chief Counsel (Field Service)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763812928)
        - 30.3.2.4.5.5.1  [Area Counsel (TEGE)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763804944)
          - 30.3.2.4.5.5.1.1  [Functions of the Area Counsels](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763983168)
    - 30.3.2.4.6  [Division Counsel (Wage & Investment) (W&I)](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415766614544)
      - 30.3.2.4.6.1  [Subject Matter Responsibility and Functions](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415766610880)
  - 30.3.2.5  [Delegations of Authority to Chief Counsel Managers and Chief Counsel Employees](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415766599088)
    - 30.3.2.5.1  [Jeopardy or Reprisal Exceptions Pertaining to Third Party Contacts](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415766468240)
  - 30.3.2.6  [Savings](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415766464944)
  - 30.3.2.7  [Direct Delegations from the Commissioner](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415766459984)
  - 30.3.2.8  [Delegations of Authority to the Commissioner and Other IRS Officials](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415766454992)
    - 30.3.2.8.1  [Certain Bankruptcy Matters](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415766453312)
    - 30.3.2.8.2  [Deciding Appeals to the Secretary of the Treasury in Director of Practice Cases](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415764237648)
  - 30.3.2.9  [Field Management Matrix](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415764236064)
    - 30.3.2.9.1  [Managing Counsel](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415764232224)
    - 30.3.2.9.2  [Area Teams](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415764227600)
    - 30.3.2.9.3  [Field Leadership Team](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415764220480)
  - Exhibit  30.3.2-1  [Chief Counsel Organization Chart](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763499072)
  - Exhibit  30.3.2-2  [Division Counsel/Associate Chief Counsel (National Taxpayer Advocate Program) Organization Chart](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763495552)
  - Exhibit  30.3.2-3  [Associate Chief Counsel (Corporate) Organization Chart](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763493184)
  - Exhibit  30.3.2-4  [Associate Chief Counsel (FM) Organization Chart](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763490880)
  - Exhibit  30.3.2-5  [Associate Chief Counsel (FIP) Organization Chart](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763484976)
  - Exhibit  30.3.2-6  [Associate Chief Counsel (GLS) Organization Chart](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763482240)
  - Exhibit  30.3.2-7  [Associate Chief Counsel (ITA) Organization Chart](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763479664)
  - Exhibit  30.3.2-8  [Associate Chief Counsel (International) Organization Chart](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415763477216)
  - Exhibit  30.3.2-9  [Associate Chief Counsel (PSI) Organization Chart](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415765962528)
  - Exhibit  30.3.2-10  [Associate Chief Counsel (PA) Organization Chart](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415765959552)
  - Exhibit  30.3.2-11  [Division Counsel/Associate Chief Counsel (CT) Organization Chart](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415765955280)
  - Exhibit  30.3.2-12  [Division Counsel (LMSB) Organization Chart](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415765952160)
  - Exhibit  30.3.2-13  [Division Counsel (SBSE) Organization Chart](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415765948384)
  - Exhibit  30.3.2-14  [Division Counsel (Strategic Litigation) Organization Chart](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415765944128)
  - Exhibit  30.3.2-15  [Division Counsel/Associate Chief Counsel (TEGE) Organization Chart](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415765942208)
  - Exhibit  30.3.2-16  [Division Counsel (WI) Organization Chart](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415765938928)
  - Exhibit  30.3.2-17  [Commissioner Delegation Orders which Delegate Authority to Chief Counsel](https://www.irs.gov/irm/part30/irm_30-003-002#idm140415765936032)

# Part 30. Chief Counsel Directives Manual Administrative

# Chapter 3. Organizations, Functions, Designations, and Delegations of Authority

# Section 2. Delegations of Authority and Designations

* * *

## 30.3.2 Delegations of Authority and Designations

#### Manual Transmittal

February 07, 2025

#### Purpose

(1) This transmits revised CCDM 30.3.2, Delegations of Authority and Designations.

#### Background

CCDM 30.3.2 is being revised to incorporate references to the new Division Counsel (Strategic Litigation) organization.

CCDM 30.3.2 is being revised to reflect the current organizational structure of the Office of the Associate Chief Counsel (Procedure & Administration).

#### Material Changes

(1) CCDM 30.3.2.8.1, Certain Bankruptcy Matters, was clarified and expanded to include additional bankruptcy matters that may be directly referred to the Department of Justice.

(2) CCDM 30.3.2.8.1(1) was amended to add motions based on debts in excess of the eligibility limits for a Chapter 13 debtor; responses to objections to claims that are based on valuation of the property securing the claim or on the fact that the claim that has been superseded by a subsequent claim; and matters involving agreed cash collateral or adequate protection.

#### Effect on Other Documents

CCDM 30.3.2.8.1, dated November 18, 2011, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(02-07-2025)

Paul T. Butler

Associate Chief Counsel

(Procedure and Administration)

**30.3.2.1** **(07-21-2005)**

### Delegations of Authority to and Functions of Deputies Chief Counsel, Counsel to the National Taxpayer Advocate, Special Counsels and National Counsel

1. This section sets forth the authority delegated to and the functions of the Deputies Chief Counsel, the Counsel to the National Taxpayer Advocate, Special Counsels, and the National Counsel, as depicted on the organizational chart in Exhibit 30.3.2-1.


**30.3.2.1.1** **(10-11-2017)**

#### Deputies Chief Counsel

1. Except for those functions or duties which by law must be performed by the Chief Counsel only, all authority delegated to the Chief Counsel is redelegated to the Deputies Chief Counsel for matters and persons under their jurisdiction, subject to the Chief Counsel's continuing supervision, control, and review as required, which includes, but is not limited to, the following:



1. As assigned, to perform the functions of the Chief Counsel in the absence of the Chief Counsel

2. To represent the Chief Counsel in the development of policies governing the Office of Chief Counsel

3. To direct, supervise, and evaluate the work of the Division Counsel and Associates Chief Counsel

4. To sign pocket commissions in his or her own name and issue them to employees under his or her supervision, as necessary

5. To perform such additional duties as may, from time to time, be assigned by the Chief Counsel


2. The Deputy Chief Counsel (Technical) serves as the principal deputy to the Chief Counsel. The Deputy Chief Counsel (Technical) acts as the Chief Counsel when the office of Chief Counsel is vacant, and, when so acting, may perform all the functions or duties of the Chief Counsel, including any functions or duties that by law must be performed by the Chief Counsel personally. See CCDM 30.3.1.7, Acting Chief Counsel under the Vacancies Reform Act and Other Matters of Succession.

3. The provisions of CCDM 30.3.2.1.1.1 and CCDM 30.3.2.1.1.2 describe the areas of focus of the two Deputies. Notwithstanding these assignments of areas of focus, each Deputy Chief Counsel may, as he or she deems appropriate, participate in and direct any activities that are subject to the overall supervision of the Chief Counsel.


**30.3.2.1.1.1** **(11-13-2023)**

##### Deputy Chief Counsel (Operations)

1. The Deputy Chief Counsel (Operations) supervises the Division Counsel (Large & Mid-Size Business), the Division Counsel (Small Business/Self Employed), the Division Counsel (Strategic Litigation), the Division Counsel (Wage & Investment), the Division Counsel/Associate Chief Counsel (Criminal Tax), the Division Counsel/Associate Chief Counsel (National Taxpayer Advocate Program), the Associate Chief Counsel (Finance and Management), the Associate Chief Counsel (General Legal Services), and the Associate Chief Counsel (Procedure & Administration).

2. The Deputy Chief Counsel (Operations) maintains jurisdiction over issues arising in litigation nationwide and has primary responsibility for matters involving management of the Office of Chief Counsel. The Deputy Chief Counsel (Operations) performs any additional duties assigned by the Chief Counsel.

3. The Deputy Chief Counsel (Operations) is chiefly responsible for the following additional activities:



1. To serve as liaison to the staffs of the General Counsel and the Commissioner as to matters identified in the previous paragraph

2. To plan, direct, and coordinate the administrative and management policies and programs of the Office

3. To participate in the formulation of tax litigation policy


**30.3.2.1.1.2** **(11-19-2009)**

##### Deputy Chief Counsel (Technical)

1. The Deputy Chief Counsel (Technical) supervises the Associate Chief Counsel (Corporate), the Associate Chief Counsel (Financial Institutions & Products), the Associate Chief Counsel (Income Tax Accounting), the Associate Chief Counsel (International), the Associate Chief Counsel (Passthroughs & Special Industries), and the Division Counsel/Associate Chief Counsel (Tax Exempt and Government Entities).

2. The Deputy Chief Counsel (Technical) maintains jurisdiction over legal issues arising in published guidance, letter rulings, technical advice, and other processes where the National Office has historically played a primary role. The Deputy Chief Counsel (Technical) performs any additional duties assigned by the Chief Counsel.

3. The Deputy Chief Counsel (Technical) is chiefly responsible for the following additional activities:



1. To serve as liaison to the staffs of the General Counsel and the Commissioner as to matters identified in the previous paragraph

2. To participate in the interpretation and development of internal revenue laws


**30.3.2.1.2** **(10-29-2020)**

#### Division Counsel/Associate Chief Counsel (National Taxpayer Advocate Program)

1. The Division Counsel/Associate Chief Counsel (National Taxpayer Advocate Program) (CC:NTA) reports to, and is supervised by, the Deputy Chief Counsel (Operations). CC:NTA provides legal advice and support directly to the National Taxpayer Advocate (NTA) and headquarters employees of the Office of the Taxpayer Advocate (commonly referred to as the Taxpayer Advocate Service (TAS)) to assist TAS in fulfilling its mission and responsibilities as set forth in the Internal Revenue Code (IRC) As CC:NTA does not have a field component the Office of the Division Counsel (Small Business/Self-Employed) assists in providing legal advice and support to TAS field offices, as depicted on the organizational chart in Exhibit 30.3.2-2. CC:NTA is also responsible for coordinating all legal and advisory services to TAS field offices, including reconciling any differences between the Office of Division Counsel (Small Business/Self-Employed) and TAS field offices.

2. CC:NTA is responsible for matters that require interpretation of the provisions of IRC §§ 7803(a)(3) and (c), 7811, and 7526, matters that raise questions regarding any authority delegated to the NTA and TAS, and any other issue that relates specifically to the NTA or the TAS organization.

3. Functions within CC:NTA include:



1. Providing legal support to TAS, including to the NTA, the Deputy NTA, and the headquarters staff of program managers who coordinate budget, personnel, communications, and equal employment opportunity issues, as well as a staff that works on significant and/or complex taxpayer cases.

2. Providing legal support to TAS with respect to legal issues involving: the scope of the statutory or delegated authorities; the formulation and completion of the NTA's Reports to Congress, Taxpayer Assistance Orders; and Taxpayer Advocate Directives.

3. Ensuring that the Office of Chief Counsel provides optimal legal support to the NTA in fulfilling the objectives of the relevant IRC provisions as they relate to that office.

4. Serving as a central point of contact for all questions and issues relating to the role of the Office in providing legal support to the NTA, including the review of incoming requests for assistance from the NTA, identification, and prioritization of legal issues, and coordinating a response.

5. Advising the Chief Counsel on short and long range legal support needs of the NTA as related to NTA program objectives, including developments or issues requiring the direct intervention of the Chief Counsel or Deputies Chief Counsel.

6. Advising the NTA of legislative proposals or Counsel legal advice or published guidance with potential impact on the NTA program.

7. Where permitted, coordinating the participation of the Office in the development of reports and studies involving the NTA program for Treasury, Congress, and oversight bodies and overseeing compilation of data necessary for such participation.

8. Identifying for the NTA areas where guidance or legislation would be beneficial to taxpayers or tax administration.

9. Supervising a staff of attorneys and clerical support personnel; assigning and reviewing work; and proposing and effecting disciplinary action where appropriate.


**30.3.2.1.3** **(10-28-2008)**

#### Special Counsels and National Counsel

1. The National Counsel, Special Counsels and other senior advisors serve on the immediate staff of the Chief Counsel to provide advice and guidance regarding the formulation of policy; the management of the legal programs of the Office; the preparation and review of proposed legislation; or technical and legal issues of interest to the Chief Counsel or the IRS. The Special Counsels and National Counsel report to, and are supervised by, the Chief Counsel.


**30.3.2.2** **(07-21-2005)**

### Delegations of Authority to Associates Chief Counsel and Division Counsel Generally

1. This sub-section sets forth authority delegated to all Associates Chief Counsel and Division Counsel. Functional statements and delegations of authority specific to each Associate Chief Counsel and Division Counsel are set forth in CCDM 30.3.2.3 and CCDM 30.3.2.5.


**30.3.2.2.1** **(07-21-2005)**

#### Delegations of Authority to Both Associates Chief Counsel and Division Counsel

1. This sub-section sets forth delegations of authority common to both Associates Chief Counsel and Division Counsel.


**30.3.2.2.1.1** **(11-13-2023)**

##### Personnel Actions

1. Each Associate Chief Counsel and Division Counsel is delegated the authority to supervise and evaluate the work of all officers and employees who are performing duties and functions under his or her jurisdiction and supervision, and to take or recommend (as appropriate under Office policy and procedures) the necessary action in all personnel matters pertaining thereto, including those for the appointment, classification, promotion, demotion, reassignment, transfer or separation of such officers and employees, including to recommend personnel actions respecting personnel in the function, to approve annual performance appraisal ratings of outstanding or equivalent, and to take necessary disciplinary or adverse action with respect to employees in the function.

2. This authority excludes appointments above GS-15, promotions, demotions, or separations to or from the Senior Executive Service (SES), and reassignment of SES members and is otherwise subject to the following exceptions and conditions.



1. The discharge of attorney personnel for conduct violations of the standards described in CCDM 39.1.1.2.2.1, Standards Applicable to All Office of Chief Counsel Employees, requires the prior approval of the Deputy Chief Counsel (Operations) or the Associate Chief Counsel (Finance & Management).

2. Concurrence is required for a nondischarge action on a GS-15 employee by the Deputy Chief Counsel (Operations) or the Associate Chief Counsel (F&M).

3. All disciplinary or adverse action shall be taken only after consulting and receiving guidance from the Office of Associate Chief Counsel (F&M), Labor and Employee Relations Division.

4. A copy of documents effecting disciplinary or adverse actions against employees at GS-14 and below that do not require prior approval or concurrence must be provided to the Associate Chief Counsel (F&M).


3. The authority to effect any disciplinary or adverse actions granted herein to Associates Chief Counsel and Division Counsel is also delegated to Deputies Associate Chief Counsel in the Offices of Associate Chief Counsel (Procedure & Administration) and (Employee Benefits, Exempt Organizations, and Employment Taxes) for actions proposed by subordinates to them.

4. The authority to effect disciplinary actions, but not adverse actions, may be redelegated. First-line supervisors may propose disciplinary or adverse actions.


**30.3.2.2.1.2** **(07-21-2005)**

##### Other Personnel Matters

1. Each Associate Chief Counsel and Division Counsel is authorized to perform the following duties and functions:



1. To administer the oath of office or any other oath required by law in connection with employment in the Federal service.

2. Except when doing so would change the basic rate of pay, to prescribe the official hours of duty for his or her function and, when necessitated by operating requirements, to establish an administrative workweek of five 8-hour days other than Monday through Friday for individual employees or groups of employees whose services are required on Saturday or Sunday or both, and to establish tours of duty for educational purposes. The exercise of authority to change tours of duty for employees must be in compliance with statute, regulation, and any applicable Treasury Department policy. _See_ 5 U.S.C. § 6101.

3. To approve leave (including approval of the correction of administrative errors and determination that a period of sickness or injury interfered with the use of scheduled annual leave), charge absence without leave for unauthorized absences, authorize brief absences from duty without charge to leave or loss of pay, for individual employees under their supervision and control in accordance with applicable statutes, executive orders, regulations and policies.

4. To order or approve the performance of overtime duty for all employees under his or her supervision for which compensatory time off shall be provided for incumbents of exempt positions under the Fair Labor Standards and for which overtime pay shall be provided for incumbents of nonexempt positions under the Fair Labor Standards (provided funds are available for such duty). Non-exempt employees may also elect to receive compensatory time off for overtime worked.

5. To order or approve the performance of work on holidays for all employees under his or her supervision provided funds are available for such duty.

6. To sign in their own names pocket commissions to be issued to attorneys under his or her supervision.


**30.3.2.2.1.3** **(11-13-2023)**

##### Travel, Relocation, and Related Matters

1. Each Associate Chief Counsel and Division Counsel is delegated the following authorities with respect to travel being performed by employees under his or her supervision and control under the General Travel Order:



1. To direct official travel and approve advances and travel vouchers for reimbursement of expenses, including non-workday travel, under the Federal Travel Regulation and Treasury and Service travel and relocation guidance, which is redelegated through Division Counsel and Associates Chief Counsel to the supervisory level for official domestic travel. No employee of the Office of Chief Counsel may approve his or her own travel or his or her own travel voucher or otherwise approve the use of travel authorities as applied to him or her.

2. To authorize reimbursement for subsistence on an actual expense basis under circumstances and conditions permitted by the Federal Travel Regulation and Service travel and relocation guidance, which is redelegated to Deputies Associate Chief Counsel and Area Counsel;

3. To authorize or approve the use of cash to procure emergency passenger transportation services, which may be redelegated in writing to Deputies Associates Chief Counsel and Area Counsel.

4. To authorize travel and transportation payment for emergency purposes under the Federal Travel Regulation and Service travel and relocation guidance, which is redelegated to Area Counsel.


2. The authority delegated to Division Counsel and Associates Chief Counsel under Delegation Order 1-22 , Authority to Authorize Travel Not at Government Expense (IRM 1.2.2.2.19), is also delegated to Deputies Associate Chief Counsel and Area Counsel. Delegates should assure that Counsel participants comply with the Office's public speaking directives.

3. The authority to authorize the attendance of employees at meetings of scientific or professional societies; municipal, state, federal, or international organizations; Congress; and law enforcement or other groups; and to authorize or approve attendance of employees at meetings held by employee groups, organizations, or associations is delegated to Division Counsel and Associates Chief Counsel. This authority may be redelegated in writing no lower than to Deputies Associate Chief Counsel and Area Counsel.

4. The authority to direct official travel and approve travel vouchers for an expert or consultant who is paid on a daily when actually-employed basis and an individual serving without pay or at $1 per year under 5 U.S.C. § 5703, under the circumstances and conditions described in the Federal Travel Regulation and Service travel and relocation guidance is delegated to Associates Chief Counsel and Division Counsel. This authority may be redelegated in writing to Area Counsel.

5. The authority to approve travel vouchers of Associates Chief Counsel and Division Counsel is delegated to the Associate Chief Counsel (Finance and Management). This authority may not be redelegated. The travel vouchers of the Associate Chief Counsel (F&M) will be approved at the Deputy Chief Counsel (Operations) level.


**30.3.2.2.1.4** **(11-13-2023)**

##### Signature Authority

1. Each Associate Chief Counsel is authorized to sign on behalf of the Chief Counsel by use of the "by-line" or in his or her own name as Associate Chief Counsel correspondence and other papers pertaining to the functions of his or her office and which are considered in the course of his or her official duties.

2. This authority is redelegated to Deputies Associate Chief Counsel in the Office of Associate Chief Counsel (Procedure & Administration) and Division Counsel/Associate Chief Counsel (Tax Exempt & Government Entities). This authority may be redelegated by the Associate Chief Counsel (General Legal Services) to an Area Counsel under his or her supervision.

3. The following officers and employees and other persons are authorized to sign on behalf of the Chief Counsel by use of the "by-line," or to sign in their own names or that of the Associate Chief Counsel, as provided in CCDM correspondence guidance and to the extent otherwise authorized in writing by an Associate Chief Counsel or an Area Counsel with authority to so sign:



   - Deputies Associate Chief Counsel

   - Branch Chiefs

   - Assistant Branch Chiefs

   - Executive Assistants

   - Senior Technical Reviewers

   - Senior Technician Reviewers

   - Special Litigation Assistants

   - Special Litigation Attorneys

   - Special Counsel

   - Technical Assistants

   - Senior Counsel


4. Each Division Counsel is authorized to sign on behalf of the Chief Counsel by use of the by-line as provided in CCDM correspondence guidance or in their own names (whichever is appropriate), correspondence, memoranda, pleadings, and motions filed with the U.S. Tax Court, and other papers pertaining to the functions of their positions and considered in the course of their official duties.



1. This authority may be redelegated to the docket attorney level.

2. Except as specifically and expressly limited, the authority vested in the Division Counsel to sign in their own names may be redelegated to the docket attorney level. Area Counsel offices are to use Area Counsel stationery in order to clarify the authority and appearance of the Area Counsel in dealing with the public. As a national organization, Strategic Litigation groups are to use Division Counsel (Strategic Litigation) stationery. The use of by-lines should correspond to the letterhead.


5. Except through the use of the by-line, correspondence and other papers are not to be signed by anyone other than the Chief Counsel except in specific situations where he/she authorizes the use of his/her signature.

6. See CCDM 30.10.1, Correspondence Guidelines, for specific instructions regarding documents which can or cannot be signed by use of the by-line.


**30.3.2.2.1.5** **(11-13-2023)**

##### General Duties and Workload

1. Each Associate Chief Counsel and Division Counsel is authorized to perform the following duties and functions:



1. To serve as the principal liaison officer for the Chief Counsel with congressional committees, the Department of the Treasury, the Commissioner's Office, the Department of Justice, and other departments and agencies of the Government on matters or cases within his or her delegated jurisdiction.

2. To coordinate the work of his or her function with the other functions of the Office and the Service and to dispose of all matters under his or her jurisdiction, referring to the Chief Counsel, a Deputy Chief Counsel, or other appropriate official of the Office of Chief Counsel such matters as in his or her discretion seem proper, or as directed.

3. To supervise, assign work, review the work product, and appraise the performances of the personnel of the function, wherever located.

4. To plan, direct, and supervise the operations of their respective function.

5. To establish, subject to the approval of the Chief Counsel and the General Counsel, branches, sections or other units or offices within the function, and to recommend further necessary changes in the organizational structure of the function or of the Office to the Chief Counsel, with reference to changes in the organizational structure of the Service or other components of the Office.

6. To make recommendations with respect to the number of employees necessary for the performance of the work under their jurisdiction.

7. To prepare and maintain records and reports with respect to the work of the function.

8. To designate an acting official of the function (or of a subordinate function), during the temporary absence of an incumbent. The authority to designate an acting official for a position held by an official in the Senior Executive Service may only be delegated to officials reporting directly to the official holding the position or to his or her Deputy.


2. Each Associate Chief Counsel and Division Counsel is also authorized to perform all needful activities to effectively manage its organization and personnel under its supervision, including:



1. Developing and executing policies, procedures, and directives designed to manage the budget process of all aspects of office operations;

2. Developing and monitoring performance measures and program goals for: the provision of legal services, litigation, and published guidance, and the implementation, compliance, and outreach initiatives within his/her jurisdiction;

3. Implementing and evaluating operational policies and procedures designed to improve the delivery of legal services;

4. Ensuring that performance and program goals, strategy, and organizational policies are clearly communicated to employees; and

5. Identifying emerging issues in the topical areas and litigation matters within its jurisdiction to improve delivery of legal services.


3. Associates Chief Counsel and Division Counsel shall perform such additional duties as may, from time to time, be assigned by the Chief Counsel or Deputies Chief Counsel, and may redelegate as necessary any of his or her authority, except as may be otherwise limited by statute, regulation, or superior delegation.


**30.3.2.2.2** **(07-21-2005)**

#### Delegations of Authority to Associates Chief Counsel

1. Each Associate Chief Counsel is authorized to perform the following duties and functions:



1. To serve as chief legal advisor to the Chief Counsel and all Service functions on legal subject matters within his or her jurisdiction

2. To serve as coordinator with Division Counsel on all administrative, policy, and technical matters pertaining to areas within his or her responsibility


**30.3.2.2.2.1** **(06-07-2012)**

##### Delegations of Authority to, and Common Functions of, Associates Chief Counsel with Technical Responsibilities

1. Each Associate Chief Counsel with technical responsibilities is delegated the following authorities:



01. To plan, direct, and coordinate the policies and programs with respect to legislation, regulations, interpretation of rulings and opinions pertaining to the laws administered by the Service for which the Associate has subject matter jurisdiction.

02. For matters under his or her subject matter jurisdiction, to determine whether an action on decision should be prepared and to prepare such document for the signature of the Chief Counsel, after considering any memorandum from Division Counsel recommending an action on decision.

03. For matters under his or her subject matter jurisdiction, to review decisions, make recommendations for appeal, write settlement letters, and write letters recommending appeal for signature by the Chief Counsel, after considering and describing in the transmittal to the Chief Counsel any memorandum of Division Counsel making recommendation on such matters.

04. For matters under his or her jurisdiction, to review prior to filing documents prepared by Division Counsel listed below:



       > • Standard defense letters in refund cases (and settlement option procedure defense letters in Court of Federal Claims matters)
       >
       > • Briefs and summary judgment motions, where such documents involve issues requiring pre-review as set forth in this manual or other Chief Counsel guidance
       >
       > • Filings containing issues designated as novel or significant by this manual or other Chief Counsel guidance and, therefore, requiring pre-review

05. To represent the Service at motions sessions before the U.S. Tax Court, except in those cases where Division Counsel sends attorneys to argue their motions.

06. For matters under his or her subject matter jurisdiction, to prepare or review motions for reconsideration of Tax Court opinions for the approval of the Chief Counsel.

07. For matters under his or her subject matter jurisdiction, to prepare action memorandums on whether to seek certiorari, including the preparation of letters recommending certiorari for signature by the Chief Counsel and approval by the General Counsel.

08. For matters under their jurisdiction, to enter into and approve a written agreement with any person relating to the internal revenue tax liability of such person (or of the person or estate for whom he/she acts): (1) in respect to any prospective or completed transactions if the request to the Chief Counsel for determination or ruling was made before any affected returns have been filed; and (2) for a taxable period or periods ended prior to the date of agreement and related specific items affecting other taxable periods.



       ### Note:



       These same authorities are delegated to the Deputies Associate Chief Counsel for cases under their respective jurisdictions. The authority listed as 1 may be redelegated by an Associate Chief Counsel to subordinate Assistants Chief Counsel for cases that do not involve precedent issues. See Delegation Order 8-3, Closing Agreements Concerning Internal Revenue Tax Liability (IRM 1.2.47.4).

09. To prescribe the extent, if any, to which any technical advice memorandum or other legal guidance issued under his/her jurisdiction shall be applied without retroactive effect. The same authority is delegated to the Deputies Associate Chief Counsel. See Delegation Order 30-1 , Application of Rulings without Retroactive Effect (IRM 1.2.53.2).

10. To approve for the Chief Counsel announcements pertaining to civil litigation policy as it pertains to tax litigation matters under his/her jurisdiction.


**30.3.2.2.3** **(11-13-2023)**

#### Delegations of Authority to, and Common Functions of, Division Counsel

1. Each Division Counsel is authorized to perform the following duties and functions:



1. To plan, direct, handle, process, and litigate cases pending in the U.S. Tax Court involving taxpayers or matters under his or her jurisdiction, and to determine the Service's litigating position in such cases and also in suits for refund brought in the U.S. District Courts and the U.S. Court of Federal Claims, and to review closing agreements which require the approval of the Commissioner in such cases or suits.



      ### Note:



      To the extent that a regulation or ruling does not provide clear guidance on the position to be taken in litigation, or the position of the Service is not clear from existing case law or the unambiguous language of the Code, Division Counsel must seek advice from the Associate Chief Counsel with subject matter jurisdiction over the involved issue concerning the position of the Service.

2. To assign and detail attorneys from his or her function to handle and conduct the hearings and trials of cases in the U.S. Tax Court, and to arrange for the reassignment and detail of attorneys in other offices for the trials of U.S. Tax Court cases where the circumstances warrant such action.

3. To prepare pleadings, motions, briefs, settlement documents, notices of appeal, and any other material prepared in connection with U.S. Tax Court litigation, coordinating such action, where required under Office procedure or where desirable, with the appropriate Associate Chief Counsel (such as in the case of briefs or summary judgments motions pertaining to issues requiring review under issues lists published in the CCDM or pertaining to novel or significant issues).

4. Where necessary or desirable, to recommend one of the following to an Associate Chief Counsel with subject matter jurisdiction:


       • Whether and what action on decision should be taken


       • A position on appeal, or on an offer of compromise or settlement pending appeal


       • Whether certiorari should be sought

5. To provide legal advice relating to case development to their respective client, coordinating with Associate Chief Counsel with subject matter jurisdiction over the issue to the extent that a regulation or ruling does not provide clear guidance on the position to be taken in litigation, or the position of the Service is not clear from existing case law or the unambiguous language of the Code.

6. To approve in writing the making of jeopardy and termination assessments and levies made less than 30 days after notice and demand for payment, who may redelegate this authority no lower than a front-line manager (e.g., Associate Area Counsel, Strategic Litigation Counsel, etc.). The approval of jeopardy and termination assessments and jeopardy levies must be based upon an independent finding by the appropriate approving official that at least one jeopardy condition exists in accordance with Treas. Reg. § 301.6851-1(a).


2. Each Division Counsel is also authorized to perform the following duties and functions:



1. To participate to the appropriate extent in the emergency planning of the Service in areas where they maintain offices, and to delegate such authority to personnel under their jurisdiction as may be appropriate for emergency planning. (Copies of agreements or delegation orders should be furnished to the Chief Counsel.)

2. To transfer attorney positions from one Area office to another within their Division, but only with the concurrence of the Associate Chief Counsel (Finance & Management) where that action is expected to have a budgetary impact.

3. To assign and reassign, with ERB approval, personnel at grade GS-15 and below within their functions. Personnel may be simultaneously reassigned (exchange of positions) as long as the nature of the duties and the levels of responsibility are essentially the same and the Deputy Chief Counsel (Operations) has approved the reassignments in writing.


**30.3.2.2.4** **(07-21-2005)**

#### Mixed Functions

1. Division Counsel who are also Associate Chief Counsel may exercise the authorities granted to Associates Chief Counsel with respect to their technical and non-field operations.

2. Associates Chief Counsel who have field functions may exercise authorities granted to Division Counsel, as applicable to their field operations.


**30.3.2.2.5** **(07-21-2005)**

#### Deputies Associate Chief Counsel

1. Except as specified otherwise, a Deputy Associate Chief Counsel can perform all the functions of the Associate Chief Counsel to which such Deputy Associate is assigned.


**30.3.2.2.6** **(11-13-2023)**

#### Redelegation

1. Except as otherwise expressly provided, and except where inconsistent with statute, regulation, or superior delegation, the authorities delegated herein may be redelegated.

2. Except as otherwise expressly provided, or where inconsistent with statute, regulation, or superior delegation, or as restricted by the Associate Chief Counsel (Procedure and Administration), the authorities generally and specifically granted to the Associate Chief Counsel (Procedure & Administration) are presumed to be redelegated to Deputies Associate Chief Counsel for subject matter under their jurisdiction and personnel under their supervision.


**30.3.2.3** **(07-21-2005)**

### Associate Chief Counsel Functional Statements, including Delegations of Authority to Specific Associates Chief Counsel

1. This subsection outlines the responsibilities and functions of each Associate Chief Counsel.


**30.3.2.3.1** **(07-21-2005)**

#### Associate Chief Counsel (Corporate)

1. The Corporate legal function is headed by an Associate Chief Counsel (Corporate), who reports to, and who is supervised by, the Deputy Chief Counsel (Technical). A Deputy Associate Chief Counsel reports to, and is supervised by, the Associate Chief Counsel (Corporate). The Associate Chief Counsel (Corporate), together with his or her Deputy, supervises six branches, technical and planning staff, and administrative staff, as depicted on the organizational chart in Exhibit 30.3.2-3. With the exception of the front office staff, employees are assigned to six branches.

2. The Associate Chief Counsel (Corporate) is responsible for providing legal support and guidance to the Commissioner, the Operating Divisions, Division Counsel, other components of the Service and Chief Counsel's Office, Treasury, other government agencies and the public on all legal matters within its jurisdiction.


**30.3.2.3.1.1** **(07-21-2005)**

##### Subject Matter Responsibility and Functions

1. The Associate Chief Counsel (Corporate) is responsible for tax matters involving corporate organizations, reorganizations, liquidations, redemptions, spin offs, transfers to controlled corporations, distributions, to shareholders, debt vs. equity determinations, bankruptcies, and consolidated return issues affecting affiliated groups of corporations to the Service, the Office of Chief Counsel, the Department of the Treasury, and, where appropriate or required, to other government agencies and the public.

2. The Associate Chief Counsel (Corporate) performs the following functions:



01. Furnishes, upon request, information, advice, and assistance in the development and drafting of internal revenue legislation and committee reports thereon; initiates recommendations and coordinates with Legislative Affairs in providing advice and assistance on legislative matters; prepares, upon request, memoranda or reports to the Associate General Counsel (Legislation, Litigation, and Regulation) setting forth the views of the Office of Chief Counsel on proposed or pending legislation.

02. Works with Treasury officials with respect to, and directs the drafting and development of, regulations and Treasury Decisions, assesses public comments and conducts public hearings on proposed regulations, and manages the movement of regulations through the review process within the Service and the Department of the Treasury.

03. Prepares revenue rulings, revenue procedures, announcements, notices, and news releases to be published for the guidance of taxpayers and Service personnel.

04. Assists the Operating Divisions in setting strategic goals, policy and procedure by providing input in the areas within the Associate's jurisdiction and working with Division Counsel and other Counsel offices to ensure the correct application of law.

05. Coordinates the Service's position in litigation with Division Counsel, the Service, and Department of Justice in areas within the Associate's jurisdiction in order to ensure the Operating Divisions are taking consistent and appropriate technical positions in litigation. Makes appeal and settlement recommendations and prepares other documents setting forth the Service's position in such cases.

06. Coordinates the resolution of cases and other matters where the subject matter is within the jurisdiction of the Associate's office. Works with the Service, Operating Divisions, Division Counsel, Taxpayer Advocate, and other components of the Service, as appropriate.

07. Provides administrative and technical support to Division Counsel and other Associates Chief Counsel in the handling and processing of litigation pending in the U.S. Tax Court and other federal courts. Reviews and coordinates pleadings, motions, briefs, settlement documents, notices of appeal, and any other material prepared in connection with U.S. Tax Court litigation. Processes or coordinates, as appropriate, petitions and complaints, briefs, actions on decision, and other matters with Division Counsel and other Associates.

08. Works with Division Counsel in: advising Department of Justice as to the facts and legal positions of the Service in matters within the jurisdiction of the Associate's office; preparing recommendations concerning defense, offers in compromise, settlement, appeal, or certiorari; and coordinating other matters with the Department as required.

09. Develops policy, procedure, directives, Chief Counsel Notices, Litigation Guideline Memorandums and CCDM provisions to provide uniform application of the provisions within the Associate's jurisdiction to the Office of Chief Counsel. Provides support and guidance in connection with the development of IRM provisions.

10. Issues technical advice or other legal advice or determinations responding to questions raised by Service personnel.

11. Issues letter rulings and general technical information letters in response to requests from taxpayers.

12. Reviews booklets, training materials, Audit Technique Guides, Coordinated Issue Papers, Appeals Settlement Guidelines, forms, publications and instructions to ensure technical accuracy, and upon request, assists in their preparation.


**30.3.2.3.2** **(08-09-2006)**

#### Associate Chief Counsel (Finance & Management)

1. The Finance and Management function is headed by the Associate Chief Counsel (Finance & Management), who reports to the Deputy Chief Counsel (Operations). A Deputy Associate Chief Counsel (F&M) reports to the Associate Chief Counsel (F&M). As depicted on the organizational chart in Exhibit 30.3.2-4, the Associate Chief Counsel (F&M), together with his or her Deputy, supervises five major functional areas and four Area Managers that manage field operations support in offices nationwide.


**30.3.2.3.2.1** **(08-09-2006)**

##### Subject Matter Responsibility

1. The mission of the Office of the Associate Chief Counsel (F&M) is to perform all Counsel-wide finance and management activities and manage all field Counsel employees who are not attorneys, paralegals, or technical advisors. The office's responsibilities include the primary functions of Human Resources, Labor and Employee Relations, Strategic Planning, Financial Management, Library Services, and Equal Employment Opportunity.

2. Information Services are provided by a Service component dedicated to servicing the Office of Chief Counsel pursuant to a memorandum of understanding between the office and the Modernization and Information Technology Services organization.

3. The Associate Chief Counsel (F&M) is responsible for all administrative functions and personnel across the country.


**30.3.2.3.2.2** **(06-07-2012)**

##### Functions of the Office of the Associate Chief Counsel (F&M)

1. The functions of the Associate Chief Counsel (F&M) include:



01. To direct, supervise, and evaluate the work of the heads of Counsel-wide finance and management activities: Human Resources, Strategic Planning, Finance, Labor and Employee Relations, Business Systems, Library services, and field support operations.

02. To be responsible for the general administration and management of the Office of Chief Counsel nationally, and to prepare and issue appropriate orders, instructions, and directives pertaining to management and administrative matters for guidance and planning of the Office.

03. To serve as the Financial Plan Manager for the Office of Chief Counsel, and to plan, direct and coordinate the financial management and administrative policies and programs of the Office, including all personnel-fiscal and budgetary operations.

04. To direct the management of the field non-legal support operations, including all administrative and clerical personnel who provide support to field functions; to supervise and manage, and delegate the authority to supervise and manage (both to supervisors within the Office of the Associate Chief Counsel (F&M) and other Counsel supervisors) all field Counsel employees who are not attorneys, paralegals, or technical advisors; and to perform, and to delegate the authority to perform all of the administrative functions necessary for the support operation of the field offices.

05. To serve as the project manager for Counsel's national automation initiative, the Counsel Automated Systems Environment (CASE-MIS), and to be responsible for the viability and continued progress of the Counsel information systems program, which is administered by the IRS Chief Information Officer's (CIO) organization. This is accomplished through continuing oversight of the ClO's formulation and execution of Counsel's budget for CASE-MIS. The Chief Counsel Executive Steering Committee (CC ESC) ensures the ClO is provided overall program priorities for the CASE-MIS initiative in concert with Counsel's business requirements. The Associate Chief Counsel (F&M) signs-off on the annual program letter which is used as a basis for the budget spending plan development process; receives advance notice of any proposed reductions or redirection of funds; and provides comments and recommendations to the ClO relative to the impact of such changes on Chief Counsel's ability to carry out effective legal support to the Service.

06. To manage Counsel's business systems and strategic planning processes, and organizational studies and analyses; to assist in or provide the formulation of executive performance goals and organizational measures; management consulting services on organizational performance issues; and the continued viability of management information systems for workload staffing and time-reporting.

07. To direct the management of the Chief Counsel Library, a highly specialized tax law library system, which provides Chief Counsel and IRS staff with support in all substantive areas of the mission of the Service as it pertains to tax law.

08. To direct the management of a full range of human resource functions. Serves as a member of the Executive Resource Boards (i.e., national and local) and chairs the Executive Resource Board when the Deputy Chief Counsel is unable to participate. Establishes implements and evaluates policies and programs to ensure that all required human resources services, training, and workforce communications are provided throughout the Office. Deals with a wide variety of labor and employee relations matters, and is authorized to approve a variety of personnel issues including settlements in grievance/adverse action cases.

09. To administer the Equal Employment Opportunity Program and to approve, on behalf of the Deputy Chief Counsel (Operations), the appointment of Equal Employment Opportunity representatives.

10. To approve or disapprove all requests for waivers of overpayment of pay and allowances up to $5000.

11. To authorize or approve the allowance and payment from Government funds of expenses related to relocation of employees, and related advance of funds, in accordance with guidance from the Chief Financial Officer. This delegation does not include the authority to agree to the payment of moving expenses by an office other than the gaining office in transfers between the Service and another agency, department, bureau of the Department of the Treasury, etc. This delegation does not include the authority to approve a period of service of less than two years, or to accept separation, without penalty, from service before the end of one year of service, with respect to employees serving outside the coterminous United States under circumstances requiring two years of service. This authority may not be redelegated.

12. To negotiate basic agreements, with labor organizations holding exclusive recognition for any unit of employees within the Office, subject to final approval by the Chief Counsel, and, in his or her discretion, to authorize negotiation by other Office of Chief Counsel officials on local issues.

13. To approve in advance requests to speak, publish, or teach made by Associates Chief Counsel and Division Counsel, including the authority to approve travel, travel vouchers, and travel not at Government expense (to the extent permitted by Delegation Order 1-22), where appropriate, in connection with the approval of such requests; and, in connection with the foregoing requests, to act as the agency designee for purposes of making written determinations that the agency interest in having the official participate in a widely attended gathering outweighs the concern that acceptance of a gift of free attendance to such an event may or may appear to improperly influence the official in the performance of his official duties.



       ### Note:



       The authority to approve in advance requests to speak, publish, or teach (and related travel and widely attended gathering requests) made by the Associate Chief Counsel (F&M) rests in the Deputy Chief Counsel (Operations), or, should that officer be unavailable or the office vacant, in the Chief Counsel.


**30.3.2.3.2.3** **(07-21-2005)**

##### Field Support Function

1. The field support function is divided into four geographical areas with 10 to 14 posts of duty per area. In addition to managing program and clerical support in the field, the Area Managers are responsible for providing cross-functional, administrative duties that consist of coordinating and monitoring budgets, initiating and tracking personnel actions, and dealing with various facilities issues.


**30.3.2.3.3** **(06-11-2008)**

#### Associate Chief Counsel (Financial Institutions & Products)

1. The Financial Institutions and Products legal function is headed by the Associate Chief Counsel (Financial Institutions & Products), who reports to, and who is supervised by, the Deputy Chief Counsel (Technical). A Deputy Associate Chief Counsel reports to, and is supervised by the Associate Chief Counsel (FIP). The Associate Chief Counsel (FIP), together with his or her Deputy, supervises technical and planning staff, administrative staff, and six branches, as depicted on the organizational chart in Exhibit 30.3.2-5. With the exception of the front office staff, employees are assigned to the following branches:



1. Litigation and Controversy

2. General Jurisdiction

3. General Jurisdiction

4. Insurance

5. Tax-Exempt Bonds

6. New Financial Products


2. The Associate Chief Counsel (FIP) is responsible for providing legal support and guidance to the Commissioner, the Operating Divisions, Division Counsel, other components of the Service and Chief Counsel's Office, Treasury, other government agencies, and the public on all legal matters within its jurisdiction.


**30.3.2.3.3.1** **(06-11-2008)**

##### Subject Matter Responsibility and Functions

1. The Associate Chief Counsel (FIP) is responsible for tax matters involving the taxation of:



   - Life insurance companies, property and casualty insurance companies, and the various products issued by those companies, such as life insurance contracts, health insurance contracts, property and casualty contracts, and annuities

   - Commercial banks, thrift institutions, regulated investment companies, and real estate investment trusts

   - A wide range of financial products, including equity and debt securities, discount and premium obligations, options, forwards, futures, notional principal contracts, and other financial derivatives

   - Asset securitization, such as real estate mortgage investment conduits and financial asset securitization investment trusts

   - Financial strategies, such as hedging, constructive sales, and straddles

   - Tax exempt bonds


2. The Associate Chief Counsel (FIP) performs the following functions:



01. Prepares legislative proposals, regulations, revenue rulings and procedures, actions on decisions, other items of public guidance and advisory opinions on matters of law within the jurisdiction of the Associate's office. Coordinates these matters with other components of the Service, Chief Counsel's office and Treasury, as necessary.

02. Assists the Operating Divisions in setting strategic goals, policy and procedure by providing input in the areas within the Associate's jurisdiction and working with Division Counsel and other Counsel offices to ensure the correct application of law.

03. Coordinates the Service's position in litigation with Division Counsel, the Service, and Department of Justice in areas within the Associate's jurisdiction in order to ensure the Operating Divisions are taking consistent and appropriate technical positions in litigation. Makes appeal and settlement recommendations and prepares other documents setting forth the Service's position in such cases.

04. Coordinates with other agencies with respect to issues of coordinated jurisdiction, e.g., the Securities and Exchange Commission (SEC) with respect to tax exempt bonds.

05. Coordinates the resolution of cases and other matters where the subject matter is within the jurisdiction of the Associate's office. Works with the Service, Operating Divisions, Division Counsel, Taxpayer Advocate, and other components of the Service, as appropriate.

06. Provides administrative and technical support to Division Counsel and other Associate Chief Counsel in the handling and processing of litigation pending in the U.S. Tax Court and other federal courts. Reviews and coordinates pleadings, motions, briefs, settlement documents, notices of appeal, and any other material prepared in connection with U.S. Tax Court litigation. Processes or coordinates, as appropriate, petitions and complaints, briefs, actions on decision, and other matters with Division Counsel and other Associates.

07. Advises Department of Justice as to the facts and legal positions of the Service in matters within the jurisdiction of the Associate's office; prepares recommendations concerning defense, settlement, appeal, or certiorari; and coordinates other matters with the Department as required.

08. Develops policy, procedure, directives, Chief Counsel Notices, Litigation Guideline Memorandums, and CCDM provisions to provide uniform application of the provisions within the Associate's jurisdiction to the Office of Chief Counsel. Provides support and guidance in connection with the development of IRM provisions.

09. Issues Technical Advice or other legal advice responding to questions raised by Service personnel.

10. Issues letter rulings and general technical information letters in response to requests from taxpayers.

11. Reviews booklets, training materials, Audit Technique Guides, Coordinated Issue Papers, Appeals Settlement Guidelines, forms, publications and instructions to ensure technical accuracy, and upon request, assists in their preparation.


**30.3.2.3.4** **(07-21-2005)**

#### Associate Chief Counsel (General Legal Services)

1. The General Legal Services function is headed by the Associate Chief Counsel (General Legal Services), who reports to, and who is supervised by, the Deputy Chief Counsel (Operations). Two Deputy Associate Chief Counsel report to, and are supervised by, the Associate Chief Counsel (GLS). The Associate Chief Counsel (GLS), together with his Deputies, supervises six Area Counsel, who head the offices at the locations depicted on the organizational chart in Exhibit 30.3.2-6. The Associate Chief Counsel (GLS), together with his Deputies, also supervises three Branch Chiefs located at headquarters in Washington, D.C., who have subject matter concentrations in: Claims, Labor and Personnel Law (CLP); Ethics and General Government Law (EGG); and Public Contracts and Technology Law (PCTL).

2. The Associate Chief Counsel (GLS) plans, directs, coordinates, and maintains jurisdiction over the policies and programs of the Office of Chief Counsel (Office) with respect to a broad range of principally nontax legal work for the agency, including the following:



1. Legal advice and determinations (and related litigation support to Department of Justice) on subject matters set forth in the descriptions of the branches below.

2. Litigation in proceedings on unfair labor practice, arbitration, adverse action, discrimination, agency grievance, and other employee appeals, labor, and personnel litigation (such as that before the Merit Systems Protection Board (MSPB), the Federal Labor Relations Authority (FLRA), and Equal Employment Opportunity Commission (EEOC)), as well as travel claims, bid protests, contract claims, and other government contract proceedings before the General Accounting Office (GAO), the General Services Administration Board of Contract Appeals (GSBCA), Department of Labor (DOL), Small Business Administration (SBA), and other government contract forums.

3. Legal advice and assistance with respect to negotiation and collective bargaining in various forums and before neutrals concerning the matters just identified above.


3. The Associate Chief Counsel (GLS) has the following specific responsibilities, among others:



01. To represent the Service and the Office at administrative hearings involving personnel, discrimination, labor-management relations, and the procurement of goods and services.

02. To provide legal advice concerning the administration of the Office's and Service's labor relations programs, and to act as a representative in third-party proceedings under those programs.

03. To review and coordinate pleadings, briefs, settlement documents, notices of appeal, and any other material prepared in connection with cases in the U. S. Tax Court related to conflict of interest or ethical matters, and, where necessary, to detail and assign attorneys from the function to participate in or handle such hearings.

04. To provide representation to the Service and the Office in all formal and informal proceedings related to nontax legal issues and cases under his jurisdiction.

05. To assist Department of Justice by preparing and approving recommendations regarding the litigating position with respect to cases within the jurisdiction of the function; advising and participating regarding cases within the jurisdiction of the function, including defense, prosecution, and settlements; and recommending what court decisions within the jurisdiction of the function should be appealed to higher courts, including recommendations with respect to certiorari to the U. S. Supreme Court, referring to the Chief Counsel or the General Counsel such decisions as he/she may be directed or as deems proper in his/her discretion, with recommendations thereon.

06. To perform the duties of the Deputy Ethics Official (DEO) pursuant to 31 C. F. R. § 0.105 as to employees of the Service and the Office (except as to the Commissioner, Chief Counsel, and any other official appointed by the President and confirmed by the U.S. Senate), including financial disclosure statement duties for the Service and the Office under TD 61-01 (July 24, 1992), and the duty to interpret the Standards of Ethical Conduct for Employees of the Executive Branch, Supplemental Standards of Ethical Conduct for Employees of the Department of the Treasury Supplement, Department of the Treasury Employee Rules of Conduct, and Service conduct provisions.

07. To supervise, coordinate, and perform the legal work of the Office on matters relating to conflicts of interest or ethical considerations involving former employees of the Service and the Office, and practitioners, including the propriety of representations before the Service and the U. S. Tax Court.

08. To review and prepare for hearing the enrollee and practitioner cases referred by the Director, Office of Professional Responsibility or Executive Director of the Joint Board for Enrollment of Actuaries and to represent those officials before the administrative law judges and agency appellate authority.

09. To render advisory opinions concerning delegation orders of the Department of the Treasury, Service, or other Government agencies which impact on the Service.

10. To operate the Service's and the Office's administrative claims program and to supervise a Claims Manager that passes upon and recommends settlement or disposition of administrative claims filed against the Service and the Office under the FTCA and where otherwise appropriate.


4. The Deputies Associate Chief Counsel (General Legal Services) perform those functions the Associate Chief Counsel (GLS) is authorized to perform that arise out of, relate to, or concern the respective activities or functions assigned to each deputy by the Associate Chief Counsel (GLS), subject to the continuing supervision, control, and review of the Associate Chief Counsel (GLS). In general, one of the deputies will focus on the oversight of litigation occurring in the area offices. This deputy will have primary responsibility for the formulation and application of a uniform litigation policy concerning EEO, labor, and personnel matters. The other deputy will act for the Associate Chief Counsel (GLS) in the absence of the Associate and will focus on non-labor matters in area offices, as well as claims, ethics, procurement, and general government matters.


**30.3.2.3.4.1** **(07-21-2005)**

##### Area Counsel (General Legal Services)

1. There is an Area Counsel for each of the geographic offices of the Associate Chief Counsel (GLS), as depicted in Exhibit 30.3.2-6. Area Counsel have the following responsibilities, among others, in their geographic areas:



1. With respect to litigation, litigation support, and litigation-related activity, to litigate and arbitrate labor and personnel cases arising in their geographic areas in appropriate forums (such as before the MSPB, FLRA, and EEOC) or before neutrals.

2. For cases filed or to be filed in their geographic areas, to review and prepare for hearing the enrollee and disbarment cases referred by the Director, Office of Professional Responsibility and the Executive Director of the Joint Board for the Enrollment of Actuaries and to represent those officials before the administrative law judges, providing litigation support to Department of Justice for appealed cases where the position of those officials was substantially sustained in the administrative adjudication and by the agency.

3. To provide litigation support to Department of Justice in suits filed under the FTCA in their geographic area, where no administrative claim has been filed, and to refer to the Branch Chief (CLP) such suits where such claim has been filed.

4. To provide litigation support to Department of Justice with respect to, or to litigate (where appropriate), suits filed under Title VII of the Civil Rights Act, suits employing the theory of _Bivens v. Six Unknown Defendants of the FBI_ ( _Bivens_), State court criminal complaints, and other miscellaneous nontax suits filed in their geographic area - in all such matters coordinating significant cases for review as appropriate under Office procedures for the coordination of significant cases and cases involving ethics and professionalism.

5. To provide legal advice to agency employees and components in their geographic area with respect to general government matters involving: property management, Federal travel, delegations of authority, the Federal Advisory Committee Act, fiscal law, the Records Acts, and such other matters as may be from time to time prescribed by the Associate Chief Counsel (GLS). Area Counsel will provide legal advice on labor, personnel, and discrimination matters only as related to cases in litigation or concerning which litigation is imminent.

6. To provide advice on general government matters on local issues arising with agency employees and components in their geographic area, notifying the Branch Chief (EGG) of sensitive cases, and referring to the Branch Chief (EGG) those precedential questions or that will have an unusual or nationwide impact.


**30.3.2.3.4.2** **(07-21-2005)**

##### Claims, Labor & Personnel Law

1. The Branch Chief (CLP) has the following responsibilities:



1. With respect to litigation, litigation support, and litigation-related activity, to provide legal advice and program coordination support to Area Counsel for labor, personnel, and discrimination cases in litigation and arbitration before relevant forums (such as the MSPB, FLRA, and EEOC) or before neutrals.

2. To provide litigation support to Department of Justice with respect to, or to litigate (where appropriate), suits filed under Title VII of the Civil Rights Act, suits employing a _Bivens_ theory, State court criminal complaints, and other miscellaneous nontax suits in cases not otherwise covered by Area Counsel.

3. To provide litigation support to Department of Justice in suits filed under the FTCA in cases not covered by Area Counsel, including cases in which administrative claims have been filed and the Claims Manager has referred the case to the Branch Chief (CLP) for assistance.

4. To handle direct litigation arising from subject matters under its jurisdiction as assigned by the Associate Chief Counsel (GLS).

5. With respect to legal advice, to provide legal advice on labor-management relations, personnel, and discrimination matters, including matters, proposals, and referrals under the Office's professionalism program (originally CC Notice N(30)487-1), and to provide program coordination to Area Counsel in all of these matters.

6. To provide legal advice concerning administrative claims and suits filed under the Federal Torts Claims Act (FTCA), the Federal Claims Collection Act (FCCA), the Debt Collection Act (DCA), and the Military and Civilian Employees' Claims Act (MCECA), and representation of agency employees in damage and other suits for acts taken in their official capacity (including officials and employees under investigation by State and local authorities for official acts), including individual administrative claims referred directly by Claims Manager to the Branch Chief (CLP) for legal assistance, as well as program coordination to Area Counsel in these matters.

7. To provide legal advice and assistance with respect to, and (where appropriate) to represent the Service and the Office in arbitration, negotiation, and collective bargaining on labor and personnel issues and agreements of National scope.


**30.3.2.3.4.3** **(06-07-2012)**

##### Ethics & General Government Law

1. The Branch Chief (EGG) has the following responsibilities, among others:



01. With respect to litigation, litigation support, and litigation-related activity, to review and coordinate pleadings, briefs, settlement documents, notices of appeal, and any other material prepared in connection with cases in the U. S. Tax Court related to conflict of interest or ethical matters.

02. To provide litigation support to Department of Justice on appealed cases arising under [Treasury Department Circular No. 230](http://www.irs.gov/pub/irs-pdf/pcir230.pdf) not otherwise covered by Area Counsel.

03. To provide litigation support to Department of Justice on all general government and legal management matters not otherwise covered by Area Counsel.

04. To handle direct litigation arising from subject matters under its jurisdiction as assigned by the Associate Chief Counsel (General Legal Services).

05. With respect to legal advice, to act as the program coordinator and primary advisor to the DEO.

06. To act as the program coordinator for matters arising from the Office of Professional Responsibility and Joint Board for the Enrollment Actuaries.

07. To provide legal advice and ethics advisory opinions on all ethics matters, wherever such matters arise or such advice is needed or required, including advice on matters as to the propriety of acts involving the Service and Office employees under 18 U.S.C. Pt. I, Ch. 11; the Ethics in Government Act; and Government-wide, Treasury, Service, Office, and professional standards and rules of conduct or behavior.

08. To supervise, coordinate, and perform the legal work of the Office on matters relating to conflicts of interest or ethical considerations involving former employees of the Service and the Office, and practitioners, including the propriety of representations before the Service and the U.S. Tax Court.

09. To provide formal ethics training and briefings, wherever needed.

10. To provide legal oversight of the filing, review, and action on financial statements of Service and Office employees who are required to file such statements under Title I of the Ethics in Government Act of 1978 (Pub. L. No. 95- 521) (as amended).

11. To perform ethics reporting of any type.

12. To provide legal advice on all general government and legal management matters not otherwise covered by Area Counsel, including Federal agency housekeeping matters, such as those matters arising under or concerning fiscal and budgetary statutes and regulations; travel statutes and regulations; property management statutes and regulations; the Federal Advisory Committee Act (FACA); delegations of authority; intellectual property; and the Records Acts.

13. The Branch Chief (EGG) is responsible for ethics matters of any type, whether litigation, litigation support, or advice, and wherever the case is filed or the matter arises (including matters and cases arising with the Divisions).


**30.3.2.3.4.4** **(07-21-2005)**

##### Public Contracts and Technology Law

1. The Branch Chief (PCTL) has the following responsibilities, among others:



1. With respect to litigation, litigation support, and litigation- related activity, to represent the Service, the Office, and (as requested) the Department in travel claims, bid protests, contract claims, and other government contract proceedings before the GAO, the GSBCA, DOL, SBA, and other government contract forums.

2. To provide litigation support to Department of Justice on all cases that concern the procurement of goods or services.

3. With respect to legal advice, to provide legal advice on public contract formation and administration and all public contract matters, including the review of solicitations and contracts, the review of competitive range and other significant pre-award decisions, informant and indemnity agreements, agreements made to effectuate criminal investigation undercover operations, contracting out, interagency agreements for the acquisition of goods and services, computer security, and technology law matters arising under statutes, regulations, and policies bearing on the use and management of technology in the Federal Government.

4. To represent the Service and the Office, where appropriate, in interagency matters and on interagency councils bearing on the formulation of Government procurement and information technology policy.

5. To provide primary legal advice on grants and cooperative agreements, agreements respecting the FedState program, and agreements implementing public-private partnerships.

6. The Branch Chief (PCTL) is responsible for procurement matters of any type, whether litigation, litigation support, or advice, and wherever the case is filed or the matter arises (including matters and cases arising with the Divisions).


**30.3.2.3.5** **(06-11-2008)**

#### Associate Chief Counsel (Income Tax Accounting)

1. The Income Tax and Accounting legal function is headed by the Associate Chief Counsel (Income Tax Accounting), who reports to, and who is supervised by, the Deputy Chief Counsel (Technical). A Deputy Associate Chief Counsel reports to, and is supervised by, the Associate Chief Counsel (ITA). The Associate Chief Counsel (ITA), together with his or her Deputy, supervises administrative staff and eight branches, as depicted on the organizational chart in Exhibit 30.3.2-7. With the exception of the front office staff, employees are assigned to eight branches.

2. The Associate Chief Counsel (ITA) is responsible for providing legal support and guidance to the Commissioner, the Operating Divisions, Division Counsel, other components of the Service and Chief Counsel's Office, Treasury, other government agencies and the public on all legal matters within its jurisdiction.


**30.3.2.3.5.1** **(06-11-2008)**

##### Subject Matter Responsibility and Functions

1. The Associate Chief Counsel (ITA) is responsible for tax matters involving recognition and timing of income and deductions; certain credits; sales and exchanges; capital gains and losses; accounting methods and periods; depreciation and other cost recovery issues; installment sales; long-term contracts; inventories and alternative minimum tax and to provide legal advice, and litigation support services to the Service, the Office of Chief Counsel, the Department of the Treasury, and, where appropriate or required, to other government agencies and the public.

2. The Associate Chief Counsel (ITA) performs the following functions:



01. Prepares legislative proposals, regulations, revenue rulings and procedures, other items of public guidance, actions on decision and advisory opinions on matters of law within the jurisdiction of the Associate Chief Counsel's office. Coordinates these matters with other components of the Service, Chief Counsel's Office and Treasury, as necessary.

02. Assists the Operating Divisions in setting strategic goals, policy and procedure by providing input in the areas within the Associate Chief Counsel's jurisdiction and working with Division Counsel and other Counsel offices to ensure the correct application of law.

03. Coordinates the position of the Service in litigation with the Operating Division Counsel, and Department of Justice in areas within the Associate Chief Counsel's jurisdiction in order to ensure the Operating Divisions are taking consistent and appropriate technical positions in litigation. Recommends appeal and settlement of Tax Court and refund cases and prepares other documents setting forth the Service's position in such cases.

04. Coordinates the resolution of cases and other matters where the subject matter is within the jurisdiction of the Associate Chief Counsel's office. Works with the Service, Operating Divisions, Division Counsel, Taxpayer Advocate and other components of the Service, as appropriate.

05. Provides administrative and technical support to Division Counsel and other Associate Chief Counsel in the handling and processing of litigation pending in the U.S. Tax Court and other federal courts. Reviews and coordinates pleadings, motions, briefs, settlement documents, notices of appeal, and any other material prepared in connection with U.S. Tax Court litigation. Processes or coordinates, as appropriate, petitions and complaints, briefs, actions on decision, and other matters with Division Counsel and other Associates.

06. Advises Department of Justice as to the facts and legal positions of the Service in matters within the jurisdiction of the Associate Chief Counsel's office; prepares recommendations concerning defense, settlement, appeal, or certiorari; and coordinates other matters with the Department as required.

07. Develops policy, procedure, directives, Chief Counsel Notices, Litigation Guideline Memoranda, and CCDM provisions to provide uniform application of the provisions within the Associate's jurisdiction to the Office of Chief Counsel. Provides support and guidance in connection with the development of IRM provisions.

08. Issues Technical Advice and other legal advice or determinations responding to questions raised by Service personnel.

09. Issues letter rulings and general technical information letters in response to requests from taxpayers.

10. Reviews booklets, training materials, Audit Technique Guides, Coordinated Issue Papers, Appeals Settlement Guidelines, forms, publications and instructions to ensure technical accuracy, and upon request, assists in their preparation.


**30.3.2.3.6** **(07-21-2005)**

#### Associate Chief Counsel (International)

1. The International legal function is headed by an Associate Chief Counsel (International), who reports to, and who is supervised by, the Deputy Chief Counsel (Technical). The Deputy Associate Chief Counsel (Strategic International Programs), the Deputy Associate Chief Counsel (International - Technical), the Deputy Associate Chief Counsel (International Field Service and Litigation), and the Director (Advance Pricing Agreement (APA) Program) report to, and are supervised by, the Associate Chief Counsel (International). The Associate Chief Counsel (International), together with his or her Deputies and the Director (APA Program), supervise six technical branches, another four branches in the APA Program, and administrative staff, as depicted on the organizational chart in Exhibit 30.3.2-8. With the exception of the front office staff (Special Counsel and technical and administrative staff), employees are assigned to six branches and the four branches of the APA Program.

2. The Associate Chief Counsel (International) is responsible for providing legal support and guidance to the Commissioner, the Operating Divisions, Division Counsel, other components of the Service and Chief Counsel's Office, Treasury, other government agencies and the public on all legal matters within its jurisdiction.


**30.3.2.3.6.1** **(07-21-2005)**

##### Subject Matter Responsibility and Functions

1. The Associate Chief Counsel (International) is responsible for all tax matters that involve the international provisions of the United States revenue laws, all bilateral and multilateral tax treaties and agreements to which the United States is a party, and all foreign revenue laws that pertain to or affect tax matters in the United States, and that arise as a result of the activities of non-United States persons or entities inside the United States and the activities of United States or United States-related persons or entities outside the United States, including in United States possessions.

2. The Associate Chief Counsel (International) performs the following functions:



01. Prepares legislative proposals, regulations, revenue rulings and procedures, actions on decisions, other items of public guidance and legal advice within the jurisdiction of the Associate's office. Coordinates these matters with other components of the Service, Chief Counsel's Office, Treasury, other government agencies, and international organizations, as necessary.

02. Assists the Operating Divisions in setting strategic goals, policy, and procedure by providing input in the areas within the Associate's jurisdiction and working with the Division Counsel and other counsel offices to ensure the correct application of law. Formulates and coordinates goals and strategies for the effective and comprehensive strategic management of international issues through all phases of the tax administration process in conjunction with the Director International, the Division Counsel (LMSB), and the Division Counsel (SB/SE). Works closely with international specialists assigned to the Division Counsel and located in various field offices across the country to provide legal advice to the Operating Divisions.

03. Coordinates the Service's position in litigation with the Division Counsel, the Service, and Department of Justice in areas within the Associate's jurisdiction in order to ensure the Operating Divisions are taking consistent and appropriate technical positions in litigation. Makes appeal and settlement recommendations and prepares other documents setting forth the Service's position in such cases.

04. Works with the Service, Operating Divisions, Division Counsel, Taxpayer Advocate, and other components of the Service, as appropriate, to ensure consistent and appropriate resolution of cases and other matters where the subject matter is within the jurisdiction of the Associate's office.

05. Provides administrative and technical support to the Division Counsel and other Associate Chief Counsel in the handling and processing of litigation pending in the U.S. Tax Court and other federal courts. Reviews and coordinates pleadings, motions, briefs, settlement documents, notices of appeal, and any other material prepared in connection with litigation, as appropriate. Coordinates, as appropriate, petitions and complaints, briefs, actions on decision, and other matters with the Division Counsel and other Associates.

06. Develops policy, procedure, directives, Chief Counsel Notices, Litigation Guideline Memorandums, and CCDM provisions to provide uniform application of the provisions within the Associate's jurisdiction to the Office of Chief Counsel. Provides support and guidance in connection with the development of IRM provisions.

07. Issues Technical Advice, and other legal advice responding to questions raised by Service personnel.

08. Issues letter rulings and general technical information letters in response to requests from taxpayers.

09. Reviews booklets, training materials, Audit Technique Guides, Coordinated Issue Papers, Appeals Settlement Guidelines, forms, publications and instructions to ensure technical accuracy, and upon request, assists in their preparation.

10. Conducts the negotiation and execution of all Advance Pricing Agreements. See CCDM 32.4.1, Advance Pricing Agreements.

11. Serves as a member of the International Council with the LMSB Director for International and Treasury's International Tax Counsel, a three-office partnership designed to formulate and coordinate goals and strategies for the development and advancement of sound tax policy and administration in the international arena.

12. Plans, directs, and coordinates the Office of Chief Counsel's participation in all multinational fora, such as the Organization for Economic Cooperation and Development, the Group of Four, and the Pacific Association of Tax Administrators.

13. Represents the Office of Chief Counsel and assists Treasury and other government agencies in tax treaty negotiations and in negotiations with respect to other international agreements.

14. Provides legal advice and assistance to the United States Competent Authority on all matters of treaty interpretation and implementation, including both substantive legal issues as well as all procedural issues arising out of treaty-based processes, such as information exchange and cross-border information gathering and collection processes. In addition, provides assistance to Area Counsel, Division Counsel, and Operating Division personnel with respect to such matters.


**30.3.2.3.6.2** **(12-18-2006)**

##### Deputies Associate Chief Counsel and Director (APA Program)

1. Functions of the Deputies Associate Chief Counsel (International) and Director (Advance Pricing Agreement Program). The Deputies Associate Chief Counsel (International) (Deputy or Deputies) and Director (APA) report to and are supervised by the Associate. The Deputies perform those functions the Associate is authorized to perform that arise out of, relate to, or concern the respective activities or functions administered by each Deputy, subject to the continuing supervision, control, and review of the Associate. Each Deputy may act for the Associate, or one another, as directed by the Associate. The Director (APA) performs those functions the Associate is authorized to perform that arise out of, relate to, or concern the APA Program.

2. In general, the Deputy Associate Chief Counsel (Strategic International Programs) focuses on strategic planning within the Office of Chief Counsel; develops strategic relationships with the Operating Divisions, including the relationship of the Associate Chief Counsel (International) with international specialists assigned to the Division Counsel at field offices across the country; plans, directs, and coordinates the Office of Chief Counsel's participation in all multinational fora; assists Treasury in planning, directing, and coordinating the negotiation of treaties and other international agreements; oversees the tax shelter program of the Associate Chief Counsel (International) and plans, directs, and coordinates international training for the Office of Chief Counsel.

3. In general, the Deputy Associate Chief Counsel (International - Technical) focuses on the public guidance program; helps ensure accurate, consistent, and uniform legal analysis in all the Office's legal products; and coordinates these matters with other components of the Service, Chief Counsel's Office, Treasury, other government agencies, and international organizations, as necessary.



1. The Deputy Associate Chief Counsel (International - Technical) is delegated the authority to sign closing agreements pertaining to elections under IRC § 953(d).


4. In general, the Deputy Associate Chief Counsel (International Field Service and Litigation) focuses on formulating and coordinating the Service's position in litigation with the Division Counsel, the Service, and Department of Justice in order to ensure that consistent and appropriate technical positions are taken; coordinates appeal and settlement recommendations and prepares other documents setting forth the Service's position in such cases; coordinates letter rulings in response to requests from taxpayers; and coordinates technical advice memoranda and other legal advice responding to questions raised by Service personnel.



1. The Deputy Associate Chief Counsel (International Field Service and Litigation) is delegated the authority to sign closing agreements described in Treas. Reg. §1.1503-2(g)(2)(iv)(B)(2)(i).


5. In general, the Director (APA) is responsible for the APA Program. See CCDM 32.4.1, Advance Pricing Agreements.



1. The Director (APA) is delegated the authority to sign Advance Pricing Agreements and Recommend ed United States Negotiating Positions.


**30.3.2.3.7** **(06-11-2008)**

#### Associate Chief Counsel (Passthroughs & Special Industries)

1. The Passthroughs and Special Industries legal function is headed by the Associate Chief Counsel (Passthroughs & Special Industries), who reports to, and who is supervised by, the Deputy Chief Counsel (Technical). A Deputy Associate Chief Counsel reports to, and is supervised by, the Associate Chief Counsel (PSI). The Associate Chief Counsel (PSI), together with his or her Deputy, supervises seven branches, technical and planning staff, and administrative staff, as depicted on the organizational chart in Exhibit 30.3.2-9. With the exception of the front office staff, employees are assigned to the following branches:



1. Passthroughs

2. Passthroughs

3. Tax Shelters

4. Estate and Gift

5. Incentive Provisions

6. Energy and Natural Resources

7. Excise Tax


2. The Associate Chief Counsel (PSI) is responsible for providing legal support and guidance to the Commissioner, the Operating Divisions, Division Counsel, other components of the Service and Chief Counsel's Office, Treasury, other government agencies and the public on all legal matters within its jurisdiction.


**30.3.2.3.7.1** **(06-11-2008)**

##### Subject Matter Responsibility and Functions

1. The Associate Chief Counsel (PSI) is responsible for tax matters involving income taxes of "S" corporations, partnerships (including limited liability companies), estates and trusts; estate, gift, generation-skipping transfer, and certain excise taxes; depletion; general business tax credits; cooperative housing corporations; farmers' and other cooperatives; the low-income housing credit; research and experimental expenditures; domestic production deductions; and certain homeowners associations, to the Service, the Office of Chief Counsel, the Department of the Treasury, and, where appropriate or required, to other government agencies and the public.

2. The Associate Chief Counsel (PSI) performs the following functions:



01. Prepares legislative proposals, regulations, revenue rulings and procedures, actions on decisions, other items of public guidance and advisory opinions on matters of law within the jurisdiction of the Associate's office. Coordinates these matters with other components of the Service, Chief Counsel's Office and Treasury, as necessary.

02. Assists the Operating Divisions in setting strategic goals, policy, and procedure by providing input in the areas within the Associate's jurisdiction and working with Division Counsel and other Counsel offices to ensure the correct application of law.

03. Coordinates the Service's position in litigation with Division Counsel, the Service and Department of Justice in areas within the Associate's jurisdiction in order to ensure the Operating Divisions are taking consistent and appropriate technical positions in litigation. Makes appeal and settlement recommendations and prepares other documents setting forth the Service's position in such cases.

04. Coordinates the resolution of cases and other matters where the subject matter is within the jurisdiction of the Associate's office. Works with the Service, Operating Divisions, Division Counsel, Taxpayer Advocate, and other components of the Service, as appropriate.

05. Provides administrative and technical support to Division Counsel and other Associate Chief Counsel in the handling and processing of litigation pending in the U.S. Tax Court and other federal courts. Reviews and coordinates pleadings, motions, briefs, settlement documents, notices of appeal, and any other material prepared in connection with U.S. Tax Court litigation. Processes or coordinates, as appropriate, petitions and complaints, briefs, actions on decision, and other matters with Division Counsel and other Associates.

06. In coordination with Division Counsel, advises Department of Justice as to the facts and legal positions of the Service in matters within the jurisdiction of the Associate's office; prepares recommendations concerning defense, settlement, appeal, or certiorari; and coordinates other matters with the Department as required.

07. Develops policy, procedure, directives, Chief Counsel Notices, Litigation Guideline Memoranda, and CCDM provisions to provide uniform application of the provisions within the Associate's jurisdiction to the Office of Chief Counsel. Provides support and guidance in connection with the development of IRM provisions.

08. Issues Technical advice or other legal advice or determinations responding to questions raised by Service personnel and Division Counsel.

09. Issues letter rulings and general technical information letters in response to requests from taxpayers.

10. Reviews booklets, training materials, Audit Technique Guides, Coordinated Issue Papers, Appeals Settlement Guidelines, forms, publications and instructions to ensure technical accuracy, and upon request, assists in their preparation.


**30.3.2.3.8** **(11-13-2023)**

#### Associate Chief Counsel (Procedure & Administration)

1. The Procedure and Administration legal function is headed by the Associate Chief Counsel (P& A), who reports to, and who is supervised by, the Deputy Chief Counsel (Operations). Three Deputies Associate Chief Counsel report to, and are supervised by, the Associate Chief Counsel (P&A). The Associate Chief Counsel (P&A), together with his or her Deputies, supervises legal branches, and administrative and support personnel, as depicted on the organizational chart in Exhibit 30.3.2-10. With the exception of the front office staff (Senior Level Counsel, Special Counsel, and administrative staff), employees are assigned to the legal branches.

2. The Associate Chief Counsel (P&A) is responsible for providing legal support and guidance to the Commissioner, the Operating Divisions, Division Counsel, other components of the Service and Chief Counsel's Office, Treasury, other government agencies and the public on all legal matters within its jurisdiction.


**30.3.2.3.8.1** **(11-13-2023)**

##### Subject Matter Responsibility and Functions

1. The Associate Chief Counsel (P&A) is responsible for matters falling under Subtitle F of the Internal Revenue Code, related off Code provisions and various provisions of Titles 5, 11 and 28 of the United States Code. The subject matter jurisdiction of the Associate Chief Counsel (P&A) includes matters under the Administrative Procedure Act, the Bankruptcy Code, the Freedom of Information Act, the Privacy Act, the Right to Financial Privacy Act, the McCarron-Ferguson Act and the Miller Act; judicial process under Chapter 76 and 78; sanctions; judicial ethical, procedural, and evidentiary rules; arbitration; meditation and assertions of privileges; the time, place and manner and procedures prescribed for reporting and paying taxes; assessing and collecting taxes (including interest and penalties); abating, crediting or refunding overassessments or overpayments of tax; filing information returns; summons matters; and matters under the disclosure provisions of IRC §§ 6103, 6104, 6108, 6110, 4424, 7213, 7213A, 7431, 7513 and 7852(e), and Treas. Reg. § 301.9100-1. The Associate Chief Counsel (P&A) is responsible for the uniform application and interpretation of these provisions within the Service. The Associate Chief Counsel (P&A) also serves as the liaison officer of the Chief Counsel with the U.S. Tax Court and the U.S. Court of Federal Claims. The Associate Chief Counsel (P&A) serves as the sanctions officer for the Office of Chief Counsel.

2. The Associate Chief Counsel (P&A) performs the following functions:



01. Prepares legislative proposals, regulations, revenue rulings and procedures, letter rulings, actions on decisions, other items of public guidance and advisory opinions on matters of law within its jurisdiction. Coordinates these matters with other components of the Service, Chief Counsel's office and Treasury as necessary.

02. Assists the Operating Divisions in setting strategic goals, policy, and procedure by providing input in the areas within the Associate's jurisdiction and working with the Operating Division Counsel and other Counsel offices to ensure the correct application of law.

03. Coordinates the Service's position in litigation with the Operating Division Counsel, the Service, and the Department of Justice in areas within the Associate's jurisdiction in order to ensure the Operating Divisions are taking consistent and appropriate technical positions in litigation. Makes appeal and settlement recommendations and prepares other documents setting forth the Service's position in such cases.

04. Coordinates the resolution of cases and other matters where the subject matter is within the jurisdiction of the Associate's office. Works with the Service, Operating Divisions, Operating Division Counsel, Taxpayer Advocate, and other components of the Service as appropriate.

05. Provides administrative and technical support to the Operating Division Counsel and other Associates Chief Counsel in the handling and processing of litigation pending in the U.S. Tax Court and other federal courts. Reviews and coordinates pleadings, motions, briefs, settlement documents, notices of appeal, and any other material prepared in connection with U.S. Tax Court litigation. Processes or coordinates, as appropriate, petitions and complaints, briefs, actions on decision, and other matters with the Operating Division Counsel and other Associates Chief Counsel.

06. Assists in the authorization or sanction of counterclaims, third party complaints, or the commencement of collection suits with respect to refund suits pending in the district courts, the U.S. Court of Federal Claims and in performance of necessary legal services on behalf of the Service as directed in connection with taxpayer suits for refund of taxes, EXCEPT alcohol, tobacco, and firearms taxes.

07. Coordinates with the Department of Justice the defense of any case where an employee's refusal to testify or produce Service records results in, or may result in, an order to show cause as to why that employee should not be held in contempt of court, or an actual order of contempt. Prepares such documents setting forth the Service’s position in such cases.

08. Advises the Department of Justice as to the facts and legal positions of the Service in matters within his/her jurisdiction; prepares recommendations concerning defense, settlement, appeal, or certiorari; and coordinates other matters with the Department as required.

09. Develops policy, procedure, directives, Chief Counsel Notices, and CCDM provisions to provide uniform application of the provisions within the Associate's jurisdiction to the Office of Chief Counsel. Provides support and guidance in connection with the development of IRM provisions.

10. Issues Technical Advice and other legal advice or determinations responding to questions raised by Service personnel.

11. Approves on behalf of the Chief Counsel actions to be taken with respect to U.S. Tax Court subpoenas and disclosure of information in U.S. Tax Court litigation.

12. As provided by Executive Order 12778, serves as sanctions officer for the Office of Chief Counsel who reviews motions for sanctions filed by litigation attorneys within the meaning of the Executive Order, or against such litigation attorneys, the United States, its agencies, or its officers. Such review may be redelegated to the Deputies Associate Chief Counsel, Branch Chiefs, Senior Technician Reviewers and Special Counsel within the Associate Office.

13. Serves as the liaison officer of the Chief Counsel with the U.S. Tax Court and the U.S. Court of Federal Claims.

14. Serves as the Commissioner's delegate for assertion of claims of executive privilege involving internal or interagency records or information that are predecisional and deliberative in matters before the U.S. Tax Court, U.S. Court of Federal Claims and other federal courts, as appropriate.

15. Coordinates, as appropriate, with other executives and managers in their handling and processing of actions to restrain disclosure under I.R.C § 6110 in the U.S. Tax Court, including the determination of the Service’s litigating position in such cases.

16. Accepts and acknowledges service of process directed to the Service or its employees acting in their official capacity.

17. Prepares opinions as to whether there is a sufficient showing of fraud, malfeasance, or misrepresentation to warrant reopening closing agreements.


3. Additionally, the Associate Chief Counsel (P&A) is responsible for the management of administrative support functions that serve the entire Office of Chief Counsel.



1. The Publications and Regulations section performs a wide variety of duties with respect to regulations and other documents filed with the Federal Register, including reviewing and editing regulations; assigning Regulatory Identification Numbers; coordinating codification of regulations in the Code of Federal Regulations; submitting regulations to the Small Business Administration; coordinating Paperwork Reduction Act submissions; ensuring that all final and temporary regulations comply with the Congressional Review Act; scheduling and coordinating public hearings; drafting, correcting and filing documents with the Federal Register; preparing the Service's portions of the semi-annual Unified Agenda of Regulations; retrieving, distributing and filing public comments; processing FOIA requests for public comments and public hearing information; and preparing many regulations and regulatory law related special projects for the Office of Chief Counsel.

2. The Disclosure Support section processes for public release all written determinations prepared by the Office of Chief Counsel that are subject to the provisions of I.R.C. § 6110, and processes all Office of Chief Counsel FOIA requests. The DS section also provides paralegal assistance on special projects for the office of Chief Counsel.

3. The Litigation Technology section supports electronic discovery for the Office of Chief Counsel. All eDiscovery information and resources can be found on the Chief Counsel Litigation Technology Page and CCDM 34.7.1.


**30.3.2.3.8.2** **(11-13-2023)**

##### Deputies Associate Chief Counsel

1. The Deputies Associate Chief Counsel report to and are supervised by the Associate. The Deputies perform those functions the Associate is authorized to perform that arise out of, relate to, or concern the respective activities or functions administered by each Deputy, subject to the continuing supervision, control, and review of the Associate. Each Deputy may act for the Associate, or one another, as directed by the Associate.

2. In general, one Deputy Associate Chief Counsel supervises P&A Branches 1 & 2, which have subject matter responsibility for matters under the Administrative Procedure Act, and matters under the Internal Revenue Code relating to the time, place, manner, and procedures prescribed for reporting and paying taxes; interest and penalties; the filing and furnishing of information returns; the filing of income tax returns and estate and gift tax returns; periods of limitations; and sanctions and judicial ethical issues, among other issues. The specific provisions within the jurisdiction of P&A Branches 1 and 2 are set out in the Office of Chief Counsel’s Code and Subject Matter Directory. This Deputy supervises the Publications and Regulations section described in CCDM 30.3.2.3.8.1(3).

3. In general, one Deputy Associate Chief Counsel supervises P&A Branches 3, 4 & 5, which have subject matter responsibility for matters relating to the assessment and collection of taxes (including liens and levies); alternative dispute resolution; abatements, credits, and refunds; protection of the interests of the Service as a creditor in bankruptcy and insolvency matters; the interpretation of laws relating to search and seizure issues, writs of entry, mandamus; the whistleblower program; the Bankruptcy Code and the Federal Rules of Bankruptcy Procedure, the Anti-Injunction Act, the McCarron-Ferguson Act, and the Miller Act. The specific provisions within the jurisdiction of P&A Branches 3, 4, and 5 are set out in the Office of Chief Counsel's Code and Subject Matter Directory.

4. In general, one Deputy Associate Chief Counsel supervises P&A Branches 6 & 7, which have subject matter responsibility for all disclosure provisions, including I.R.C. §§ 6103, 6104, 6108, 6110, 4424, 7213, 7213A, 7431, 7513 and 7852(e), Treas. Reg. § 301.9000-1, the FOIA, the Right to Financial Privacy Act, and the Privacy Act of 1974. P&A Branches 6 and 7 also have subject matter responsibility for judicial doctrines; judicial procedural, and evidentiary rules; assertions of privilege; mitigation; partnership audit procedures – both under the Tax Equity and Fiscal Responsibility Act and the Bipartisan Budget Act of 201; summonses; Tax Court rules; and combat zone and disaster relief. The specific provisions within the jurisdiction of P&A Branches 6 and 7 are set out in the Office of Chief Counsel's Code and Subject Matter Directory. This Deputy also supervises the Disclosure Support described in CCDM 30.3.2.3.8.1(3).

5. The Chief Counsel's authority to receive service of subpoenas or summonses in other than U.S. Tax Court matters is delegated, through the Associate Chief Counsel (P&A), to the Deputy Associate Chief Counsel (P&A) with responsibility over Branches 6 & 7. This includes the authority to receive service of any subpoena, summons, or other judicial process directed to any officer or employee of the Department of the Treasury in his or her official capacity in any litigation (other than the U.S. Tax Court).



1. Under the authority of the Deputy Associate Chief Counsel (P&A) with responsibility over P&A Branches 6 & 7, the Branch Chiefs and Senior Technician Reviewers in P&A Branches 6 & 7 are authorized to receive service of any subpoena, summons, or other judicial process directed to an officer or employee of the Department of the Treasury in his or her official capacity in any litigation (other than the U.S. Tax Court).

2. This authority may be redelegated by the Deputy Associate Chief Counsel (P&A) with responsibility over P&A Branches 6 & 7 to other attorneys in P&A Branches 6 & 7.

3. If a Deputy U.S. Marshall or other process server attempts to serve process on any person not delegated authority to receive process server to one of the persons having authority to receive service.


**30.3.2.3.9** **(07-21-2005)**

#### Associate Chief Counsel (Criminal Tax)

1. This statement may be found grouped with Division Counsel statements at CCDM 30.3.2.4.1.


**30.3.2.3.10** **(07-21-2005)**

#### Associate Chief Counsel (Tax Exempt and Government Entities)

1. This statement may be found grouped with Division Counsel statements at CCDM 30.3.2.4.4.


**30.3.2.4** **(07-21-2005)**

### Division Counsel Functional Statements, including Delegations of Authority to Specific Division Counsel

1. This subsection describes the responsibilities, functions, and authority of each Division Counsel.


**30.3.2.4.1** **(06-07-2012)**

#### Division Counsel/Associate Chief Counsel (Criminal Tax)

1. The Criminal Tax legal function is headed by the Division Counsel/Associate Chief Counsel (Criminal Tax), who reports to and is supervised by the Deputy Chief Counsel (Operations). As depicted on the organizational chart in Exhibit 30.3.2-11, the Division Counsel/Associate Chief Counsel (CT) directly supervises a Deputy Division Counsel/Deputy Associate Chief Counsel (CT), and, through this official supervises:



   - An Assistant Chief Counsel (Criminal Tax)

   - A Senior Level Counsel

   - Special Counsel (one of whom is stationed at National Headquarters and one of whom is stationed in Glynco, Georgia at the Federal Law Enforcement Training Center (FLETC))

   - Attorneys assigned to the Office of Division Counsel/Associate Chief Counsel in Washington, DC

   - Area Counsel (Criminal Tax) and Deputy Area Counsel (Criminal Tax), who in turn supervise numerous division attorneys, including Senior Counsel in each area


2. The Area Counsel (Criminal Tax) generally maintain their offices in the same cities as the Directors, Field Operation, Criminal Investigation. The Division Counsel/Associate Chief Counsel (CT), his or her Deputy, and the Assistant Chief Counsel (Criminal Tax) maintain their offices at the National Headquarters in Washington, DC.

3. The Division Counsel/Associate Chief Counsel (CT) is responsible for providing impartial, top quality legal service to, and on behalf of, the Service and the Office with respect to Criminal Tax (CT) matters and to provide all necessary legal support to the Chief Counsel and the Department of Treasury on matters of CT policy.


**30.3.2.4.1.1** **(07-21-2005)**

##### Subject Matter Responsibility and Functions

1. The Division Counsel/Associate Chief Counsel (CT) is responsible for the overall administration of the CT legal program and effective supervision, management and performance of legal services in support of Criminal Investigation (CI) at the national and field levels. The Division Counsel/Associate Chief Counsel (CT) is responsible for planning, directing, and coordinating the policies and programs with respect to the management and direction of all CT legal work within the Chief Counsel's office, including substantive criminal matters (tax, currency, and money laundering crimes), criminal procedure and investigative matters (administrative and grand jury investigations, undercover operations, electronic surveillance, search warrants and forfeitures), providing advice on the referral of cases to Department of Justice for prosecution or commencement of judicial forfeitures, and providing appellate recommendations to Department of Justice.

2. The Division Counsel/Associate Chief Counsel (CT) performs the following functions:



01. Plans, directs and coordinates the legal work of the CT function.

02. Provides input to the Chief Counsel, Chief, Criminal Investigation and other senior executives within CI on matters of CT policy.

03. Reviews high profile/sensitive cases centralized in the National Headquarters.

04. Plans and implements actions, including periodic meetings, necessary to create and maintain strong communications within the CT function and between CT, CI and other functions.

05. Issues advice, direction, and guidance in the appropriate form, including but not limited to legal advice memorandum; informal and formal technical advice; Legal Guidance Memorandum; IRM provisions; Chief Counsel Notices and Directive Manual provisions; and various other publications and handbooks on various issues such as money laundering, tax crimes, electronic surveillance, sentencing, and search warrants.

06. Reviews CI requests for use of special investigation techniques, including but not limited to proposed Grants of Immunity under 18 U.S.C. § 6001, et seq.; initial requests, deviations and extensions of Group I undercover operations as a member of the Undercover Advisory Committee; highly sensitive search warrants centralized in the National Headquarters; and non-consensual electronic surveillance.

07. Reviews requests for Code judicial forfeitures pursuant to IRC § 7301, et seq. and makes recommendations on forfeiture petitions for remission or mitigation or offers in compromise.

08. Responds to inquiries including, but not limited to, those from Congress; other governmental agencies; professional organizations and the public as well as FOIA requests.

09. Prepares Chief Counsel Advice for disclosure under IRC § 6110.

10. Coordinates between Department of Justice, other Chief Counsel/IRS functions and other Government agencies.

11. Disseminates Department of Justice declines.

12. In consultation with the Chief Counsel and the General Counsel, makes appellate and certiorari recommendations to Department of Justice.

13. Designs, coordinates, and conducts CT training, including Basic, Advanced, Symposium, and specialized schools.

14. Provides full time senior attorney(s) as instructors at the Federal Law Enforcement Training Center (FLETC) in Glynco, Georgia.

15. Provides a Counsel liaison to multi-governmental agency task forces.

16. Implements and evaluates operational policies and procedures designed to improve the delivery of legal services.

17. Identifies and communicates emerging and significant issues.

18. Performs such other functions as may be prescribed from time to time by the Chief Counsel.


**30.3.2.4.1.2** **(07-21-2005)**

##### Deputy Division Counsel/Deputy Associate Chief Counsel (Criminal Tax)

1. The Deputy Division Counsel/Deputy Associate Chief Counsel (Criminal Tax) assists the Division Counsel/Associate Chief Counsel (CT) in the overall administration of the CT legal program and in the supervision, management, and performance of legal services in support of Criminal Investigation at the national and field levels. The Deputy DC/ACC (CT) performs those functions the Division Counsel/Associate Chief Counsel (CT) is authorized to perform that arise out of, relate to, or concern the respective activities or functions administered by the Deputy, subject to the continuing supervision, control, and review of the Division Counsel/Associate Chief Counsel (CT).

2. Upon delegation by the Division Counsel/Associate Chief Counsel (CT), the Deputy Division Counsel/Deputy Associate Chief Counsel (Criminal Tax) may supervise any or all staff not otherwise under the supervisory jurisdiction of the Deputy Division Counsel/Deputy Associate Chief Counsel (CT). Unless prescribed otherwise by the DC/ACC (CT), the Deputy may act for or represent the Division Counsel/Associate Chief Counsel (CT) in the development of policies governing the office and serves as Acting Division Counsel/Associate Chief Counsel (CT) in the absence of the Division Counsel/Associate Chief Counsel (CT). The Deputy will perform such additional duties as may, from time to time, be assigned by the Division Counsel/Associate Chief Counsel (CT).

3. The Deputy Division Counsel/Associate Chief Counsel (CT) also works with the Division Counsel/Associate Chief Counsel (CT) in overseeing the planning, direction, review, and coordination the policies and programs with respect to the management and direction of all CT legal work centralized at the National Headquarters, including substantive criminal matters (e.g., tax, currency, and money laundering crimes), criminal procedure and investigative matters (e.g., administrative and grand jury investigations, undercover operations, electronic surveillance, search warrants and forfeitures), providing advice on the referral of cases to Department of Justice for prosecution or commencement of judicial forfeitures, and providing appellate recommendations to Department of Justice.


**30.3.2.4.1.3** **(06-07-2012)**

##### Senior Level Counsel

1. The Senior Level Counsel (CT) assists the Division Counsel/Associate Chief Counsel (CT) in formulating policies and programs for the operation of the Office. In addition, the Senior Level Counsel (CT) performs assignments of the highest complexity and broadest impact.

2. The Senior Level Counsel (CT) personally represents the Division Counsel/Associate Chief Counsel (CT) at top-level IRS/Treasury and DOJ meetings, and coordinates highly complex and significant special projects in Criminal Tax matters. The Senior Level Counsel (CT) serves as the program manager for sensitive and semi-sensitive cases to ensure consistent and correct legal interpretation of criminal tax issues. The Senior Level Counsel (CT) serves as primary liaison to Division and Associate Chief Counsel offices in the coordination and direction of activities to support IRS needs and objectives.


**30.3.2.4.1.4** **(07-21-2005)**

##### Special Counsel

1. Special Counsel perform the following functions:



1. When assigned to National Headquarters, to serve as legal and technical consultants on the most difficult, important and complex matters arising in connection with the work of the Division, as well as less complex matters assigned at the discretion of the Division Counsel/Associate Chief Counsel (CT) or his or her Deputy. Special Counsel assist and represent the Division Counsel/Associate Chief Counsel (CT) at Chief Counsel, Internal Revenue, and Treasury conferences where policy is developed and determined.

2. When assigned to FLETC, to serve as the primary legal instructor and Chief Counsel representative on Criminal Investigation's teaching cadre at FLETC. The Special Counsel in this capacity exercise overall program and policy responsibility for the substantive criminal tax teaching provided at FLETC.


**30.3.2.4.1.5** **(07-21-2005)**

##### Assistant Chief Counsel (Criminal Tax)

1. The Assistant Chief Counsel (Criminal Tax) assists the Division Counsel/Associate Chief Counsel (CT) in coordinating and directing all administrative activities of the Criminal Tax organizational component of the Office of Chief Counsel. The Assistant Chief Counsel assists the Division Counsel and Deputy Division Counsel in the overall supervision, management, and performance of legal services in support of Criminal Investigation at the national and field levels. The Assistant Chief Counsel is delegated authority and responsibility to perform as an Assistant Chief Counsel, including authority to sign finally on all matters over which the Division Counsel/Associate Chief Counsel (CT) has authority.

2. The Assistant Chief Counsel (CT) duties and responsibilities include:



01. Acts for the Division Counsel/Associate Chief Counsel (CT) in the absence of the Division Counsel and Deputy Division Counsel. When acting in such capacity, the Assistant assumes complete responsibility for the activities of the Office of the Division Counsel/Associate Chief Counsel (CT).

02. Collaborates closely with the Division Counsel regarding any administrative issues under the jurisdiction of Criminal Tax. Specifically, the Assistant plans, directs, and coordinates the administrative and management policies and programs of the office, serving as liaison to the budgetary, information technology, and management committees of the Chief Counsel and the Commissioner.

03. Assists the Deputy Division Counsel/Associate Chief Counsel (CT) in the management and supervision of the Area Counsel (Criminal Tax). The Assistant conducts Area visitations, works with the Area Counsel relative to staffing issues and workload issues in their Areas, and other duties and responsibilities assigned by the Division Counsel/Associate Chief Counsel (CT) and his or her Deputy.

04. Serves as the appraising official of the Special Counsel assigned to the FLETC and the approving official of the docket attorney assigned to the FLETC. The Assistant works with the Special Counsel and Criminal Investigation personnel relative to the oversight of this program.

05. Supervises the attorneys in the Office of Division Counsel/Associate Chief Counsel in positions below GS-15. This responsibility includes, but is not limited to, assigning work, reviewing work products, and appraising the annual performance of the attorneys.

06. Serves as the appraising official of the Executive Assistant and the Management Analyst and the approving official of the Administrative Officer.

07. Develops and executes policies, procedures, and directives designed to manage the budgetary process for all aspects of the Criminal Tax function.

08. Develops, implements, and evaluates operational policies and procedures designed to improve the delivery of legal services.

09. Develops, implements and evaluates modernization policies and procedures for the Criminal Tax function.

10. Performs such other functions and duties as may be prescribed from time to time by the Division Counsel/Associate Chief Counsel (CT) and the Deputy Division Counsel/Associate Chief Counsel (CT).


**30.3.2.4.1.6** **(06-07-2012)**

##### Area Counsel and Deputy Area Counsel (Criminal Tax)

1. Each Area Counsel (Criminal Tax) and Deputy Area Counsel (Criminal Tax) is responsible for the administration of the CT program at the area and district level. Each Area Counsel (CT) supervises a Deputy Area Counsel (CT), Senior Counsel and division attorneys within an assigned geographic area. Each Area Counsel (CT) reports to and is supervised by the Division Counsel/Associate Chief Counsel (CT) through the Deputy Division Counsel/Deputy Associate Chief Counsel (Criminal Tax). Each Deputy Area Counsel (CT) reports to and is supervised by the Area Counsel (CT). Each Deputy Area Counsel (CT) serves to assist the Area Counsel (CT) in the mission and is responsible for the effective supervision, management, and performance of legal services in support of the CI within an assigned geographic function.

2. Each Area Counsel and Deputy Area Counsel (CT) is responsible for implementing the policies and programs formulated by the Service and the Office of Chief Counsel with respect to the criminal tax function; advising and counseling the Area Manager for Service Criminal Investigation and his/her subordinates in all legal aspects of the criminal tax function, including substantive criminal matters (e.g., tax, currency and money laundering crimes), criminal procedure and investigative matters (e.g., administrative and grand jury investigations, undercover operations, electronic surveillance, search warrants and forfeitures), the referral of cases to Department of Justice for grand jury investigation, criminal prosecution, and the commencement of forfeitures; and coordinating with other functions within the Service and the Office of Chief Counsel on all matters involving criminal tax.

3. To accomplish the mission, each Area Counsel (CT) with the assistance of Deputy Area Counsel (CT):



01. Plans, directs, and coordinates the legal work of the Criminal Tax function in the assigned geographic area.

02. Plans and implements actions, including periodic meetings, necessary to create and maintain strong communications within the assigned area and between other areas and the Office of Division Counsel/Associate Chief Counsel Associate.

03. Provides formal and informal legal advice and assistance in matters requiring the approval of the CI Area Manager.

04. Informs division attorneys and the CI Area Manager of developments in substantive and procedural matters.

05. Coordinates and participates in training of Counsel and CI personnel.

06. Periodically meets with the CI Area Manager to ensure that necessary legal services are being provided and to discuss areas for improvement.

07. Alerts the Division Counsel/Associate Chief Counsel (CT) to sensitive or unique matters in the area.

08. Makes recommendations to the Division Counsel/Associate Chief Counsel (CT) on emerging issues.

09. Supports the Division Counsel/Associate Chief Counsel (CT) in the design, coordination and conducting of criminal tax schools.

10. Supports the Division Counsel/Associate Chief Counsel (CT) in the preparation and updating of manual provisions, training materials, technical updates and other publications.

11. Coordinates between Department of Justice, other Chief Counsel and Service functions and other Government agencies.

12. Performs such other functions as may be prescribed from time to time by the Division Counsel/Associate Chief Counsel (CT).


4. Each Area Counsel (CT) with the assistance of Deputy Area Counsel (CT) also performs the following and other necessary managerial and supervisory duties:



01. Supervises the Senior Counsel and division attorneys assigned to the Criminal Tax function in the Area and local offices.

02. Assigns, reassigns, and transfers Area Counsel (CT) and Division Counsel (CT) personnel under his or her jurisdiction among any of the Area's subordinate offices, as necessary.

03. Prepares evaluations and appraises the performance of subordinate personnel, taking personnel actions as necessary for those under his/her supervision.

04. Assigns and reviews work products, establishes work assignment priorities, monitors workload balances, and transfers work among docket attorneys to ensure a proper workload balance.

05. Ensures performance and program goals, strategy, and organizational policies are clearly communicated to employees.

06. Approves travel and travel vouchers and manages other assigned budgetary functions for the area.

07. Prepares and maintains records and reports with respect to the work of the CT function in the area.

08. Designates an Acting Area Counsel (CT) or other manager for the function for the temporary absence of the incumbent.

09. Redelegates his/her authority as necessary, except where such redelegation is expressly restricted or otherwise restricted by law, regulation, or policy.

10. Signs on behalf of the Chief Counsel by the use of the by-line or in his/her own name (whichever is appropriate) correspondence and other papers pertaining to the functions of Counsel and which are considered in the course of the official duties of the Area Counsel (CT).



       ### Note:



       Except through the use of the by-line, correspondence and other papers are not to be signed in the name of the Chief Counsel by anyone other than the Chief Counsel except in specific situations where he/she authorizes the use of his/her signature.


**30.3.2.4.2** **(07-21-2005)**

#### Division Counsel (Large & Midsize Business)

1. The Large and Mid-Size Business legal function is headed by the Division Counsel (LMSB) who reports to, and who is supervised by, the Deputy Chief Counsel (Operations). A Deputy Division Counsel (LMSB) reports to, and is supervised by, the Division Counsel (LMSB). The Division Counsel (LMSB), together with his or her Deputy, supervise: five Area Counsel who are responsible for the work in various industry segments in the field (and who, in turn, supervise Associate Area Counsel and five Senior Legal Counsel), as well as an Executive Assistant who provides the budget, administrative and personnel support for the entire Division; Senior Legal Counsels for Pre-filing & Technical Guidance, Research and Planning, Tax Shelters, and International; and staff attorneys and administrative support personnel — all as depicted on the organizational chart in Exhibit 30.3.2-12.

2. The Division Counsel (LMSB) serves as the principal legal advisor to the LMSB Commissioner. The Division Counsel (LMSB) works closely with the LMSB Commissioner to formulate and execute policies, strategic goals, procedures, operating priorities and programs. The Division Counsel (LMSB) serves as the principal legal advisor to the Commissioner, Internal Revenue Service, other operating divisions, Chief Counsel, Appeals, and other senior Service and Treasury officials on the legal issues confronting LMSB taxpayers. The Division Counsel (LMSB) is responsible for the effective management and oversight of the delivery of legal services by approximately three hundred headquarter and field managers, attorneys, and paralegals located in forty-two posts of duty.


**30.3.2.4.2.1** **(11-13-2023)**

##### Subject Matter Responsibility and Functions

1. The Division Counsel (LMSB) has primary responsibility for providing legal services in cases involving the taxpayer base served by the LMSB Commissioner. Specifically, the Division Counsel (LMSB) has primary responsibility for providing litigation services and legal advice on matters involving subchapter C corporations, subchapter "S" corporations, and partnerships with assets greater than $10 million.

2. The Division Counsel (LMSB) performs the following functions with respect to the litigation of tax cases involving LMSB taxpayers:



1. Represents the Commissioner in the litigation of cases pending in the U.S. Tax Court.

2. Prepares enforcement, defense, and settlement letters in summons enforcement and refund litigation cases, and leading the coordination of these Department of Justice cases with other Counsel functions.

3. Makes recommendations of acquiescence and nonacquiescence in adverse decisions in litigation, providing on-going services to Department of Justice and coordinating with Associate Chief Counsels on recommendations to the Chief Counsel and Department of Justice regarding appeals of adverse decisions, rehearing and rehearing en banc, the filing of amicus curiae briefs, petitions for writ of certiorari to the U.S. Supreme Court, and any other appropriate judicial action pertaining to matters under the jurisdiction of LMSB.


3. The Division Counsel (LMSB) performs the following functions with respect to rendering legal advice, coordination activities, and providing litigation and other support on matters or issues involving LMSB taxpayers:



1. Provides pre-filing and post-filing legal advice to LMSB examination teams, either in the audit of returns or in the consideration of claims for refund.

2. Coordinates input from the LMSB Commissioner with the Deputy Chief Counsel (Technical), Associate Chief Counsels and Treasury officials with respect to the need for and the administrability of published guidance, including regulations, notices, revenue rulings, revenue procedures, actions on decision and other items of published guidance.

3. Coordinates key issues and cases with the Chief Counsel, Deputies Chief Counsel, Associate Chief Counsels, and other members of the Chief Counsel organization.

4. Oversees the Industry Counsel and International Field Counsel Programs, which are the counterparts to the Industry Technical Advisor and International Technical Advisor Programs in LMSB Pre-Filing and Technical Guidance.

5. Works in concert with the LMSB Office of Tax Shelter Analysis to identify and address abusive tax avoidance transactions.

6. Supports the Division Counsel (SB/SE) in bankruptcy matters.

7. Provides legal advice on Advance Pricing Agreements, Pre-filing Agreements and other closing agreements.

8. Provides internal and external training on issues.

9. Conducts public outreach to taxpayer organizations.


**30.3.2.4.2.2** **(11-13-2023)**

##### Area Counsel (Large & Mid-Size Business)

1. The Division Counsel (LMSB) field executive staff is composed of five Area Counsel who report to, and are supervised by, the Division Counsel. Each Area Counsel is collocated with one of the five Industry Directors for the LMSB Commissioner, and serves as the principal legal advisor to their respective Industry Director on the legal issues confronting LMSB taxpayers in the industries with which they are aligned. Each Area Counsel also has a geographic area of responsibility. Geographically, the Area Counsel serves as the legal advisor to other LMSB Industry Directors with operations or personnel within the geographic area; and oversee and coordinate the delivery of legal services by their attorneys and paralegals located in the posts of duty within their respective geographic area. The five Area Counsel are:



1. The Area Counsel for Financial Services (Area 1), who serves as the principal legal advisor to, and is collocated with, the Industry Director, Financial Services.

2. The Area Counsel for Heavy Manufacturing and Transportation (Area 2), who serves as the principal legal advisor to, and is collocated with, the Industry Director, Heavy Manufacturing and Transportation.

3. The Area Counsel for Retailers, Food, Pharmaceuticals and Health Care (Area 3), who serves as the principal legal advisor to, and is collocated with, the Industry Director, Retailers, Food, Pharmaceuticals and Health Care.

4. The Area Counsel for Natural Resources (Area 4), who serves as the principal legal advisor to, and is collocated with, the Industry Director, Natural Resources.

5. The Area Counsel for Communications, Technology and Media, (Area 5) who serves as the principal legal advisor to, and is collocated with, the Industry Director, Communications, Technology and Media.


2. Area Counsel supervise and are responsible for the effective management and oversight of the field operations and personnel within their Areas. An Associate Area Counsel (Industry Programs), and several Associate Area Counsels responsible for general practice groups report to, and are supervised by, their respective Area Counsel. In addition, to insure close coordination with Division Counsel headquarters, LMSB Commissioner headquarters, Associate Chief Counsel offices, and other counsel staff, each Area Counsel also has a Senior Legal Counsel assigned to the Division Counsel headquarters in Washington, D.C.

3. In their industry-based function, the Area Counsel work closely with the Industry Directors to formulate and execute policies, strategies, operating priorities and programs for the particular industries on a nationwide basis; and oversee and coordinate the delivery of legal services on industry issues to Industry Director personnel nationwide. The Area Counsel exercise ongoing responsibility for the budget, administrative and personnel actions, processes and procedures for the Area.

4. Each Area Counsel designates an Associate Area Counsel to coordinate the International Field Counsel Program within the area and to serve as primary liaison with the Senior Legal Counsel (International) and the International Technical Advisor Program within Pre-filing and Technical Guidance. The Area Counsel will, as directed by the Division Counsel, or as they deem appropriate, designate other persons under their supervision to serve as coordinators and primary liaison in support of other client strategic initiatives and programs.


**30.3.2.4.2.3** **(11-13-2023)**

##### Associate Area Counsel (Large & Mid-Size Business)

1. Associate Area Counsel (Industry Programs) provide primary support to the Area Counsel and Industry Director staff with respect to industry specific pre-filing, filing, and post- filing activities. They also serve as an actor for the Area Counsel in his or her absence or unavailability. They oversee all Industry Counsel, who serve as the primary Chief Counsel liaison with the Pre-filing and Technical Guidance Industry Technical Advisors aligned with their area's respective industries.

2. Associate Area Counsel responsible for the general practice groups provide primary support to the Area Counsel and local LMSB Industry Director staff with operations or personnel within the geographic area with respect to a variety of pre-filing, filing and post-filing activities. They also manage the litigation of Tax Court cases other than those assigned to Special Trial Attorneys, and have the primary responsibility for preparing enforcement, defense and settlement letters in summons enforcement and refund litigation. They are responsible for insuring appropriate coordination of advice and significant issues within the Area and the Division.


**30.3.2.4.3** **(10-28-2008)**

#### Division Counsel (Small Business/Self-Employed)

1. The Small Business/Self Employed legal function is headed by the Division Counsel (SB/SE), who reports to, and who is supervised by, the Deputy Chief Counsel (Operations). Two Deputies Division Counsel report to, and are supervised by, the Division Counsel (SB/SE). The Division Counsel (SB/SE), together with his or her Deputies, supervise four Assistant Division Counsel and nine Area Counsel (who are responsible for the work in the field and who, in turn, supervise Associate Area Counsel), as well as technical, planning, and administrative staff, as depicted on the organizational chart in Exhibit 30.3.2-13.

2. The Division Counsel (SB/SE) is the principal legal advisor to the Division Commissioner, SB/SE. The Division Counsel (SB/SE) is also the principal legal advisor to the field components of the Wage & Investment Division, the Taxpayer Advocate Service, and the SB/SE function of the Appeals Division. The Division Counsel (SB/SE) oversees all docketed and non-docketed tax litigation matters involving taxpayers within the jurisdiction of the Division Commissioner, SB/SE.

3. The Division Counsel (SB/SE) also oversees, in coordination with the Division Counsel, Wage & Investment, all docketed and non-docketed tax litigation matters involving taxpayers within the jurisdiction of the Division Commissioner, Wage & Investment. Tax litigation matters may include pre-filing, filing, and post-filing tax issues.

4. The Division Counsel (SB/SE), is responsible for providing legal advice and opinions, upon request, to the Division Commissioner, SB/SE, or to other functions of the Service having jurisdiction over collection matters, in any matter relating to the collection of taxes. The Division Counsel (SB/SE) is also responsible for handling legal work relating to collection actions, including bankruptcies. The Division Counsel (SB/SE) oversees a headquarters office consisting of a deputy, program managers, and a staff of attorneys.


**30.3.2.4.3.1** **(11-13-2023)**

##### Subject Matter Responsibility and Functions

1. The Division Counsel (SB/SE) has primary responsibility for providing advice on legal issues relating to individuals who file Schedules C, E, F, or Forms 2106, and corporations, "S" corporations and partnerships with assets less than $10 million. The Division Counsel (SB/SE) also has responsibility, in coordination with the Division Counsel (W&I), for providing advice on legal issues relating to individuals classified as Wage & Investment taxpayers. The Division Counsel (SB/SE) has responsibility for all docketed Tax Court litigation involving SB/SE and W&I taxpayers. The Division Counsel (SB/SE) has responsibility over all collection matters involving taxpayers regardless of their taxpayer classification within the Service.

2. The Division Counsel (SB/SE) performs the following functions with respect to tax litigation matters involving:



1. Docketed Cases. To process and handle cases docketed in the Tax Court involving SB/SE or W&I taxpayers.

2. Statutory Notices. To perform the duties and functions relating to the consideration and review, prior to issuance, of proposed statutory notices of deficiency and statutory notices of claim disallowance prepared by SB/SE or W&I

3. Subpoenas. To approve on behalf of the Chief Counsel actions to be taken with respect to Tax Court subpoenas and disclosure of information in Tax Court litigation within the jurisdiction of the division.

4. Adverse Decisions. To make recommendations to the Chief Counsel respecting adverse Tax Court decisions within the jurisdiction of the division.

5. Cases in the Tax Court. To dispose of Tax Court cases within the jurisdiction of the division by trial, settlement, or dispositive motion.

6. Refund Matters. To authorize or sanction counterclaims, third-party complaints, or the commencement of collection suits with respect to refunds suits of taxpayers within the jurisdiction of SB/SE or W&I pending in the district courts or the Court of Federal Claims and to perform necessary legal services on behalf of the Service as directed in connection with taxpayer suits for refund of taxes.


3. The Division Counsel (SB/SE) performs the following functions with respect to general litigation matters involving:



01. Legal Advice and Opinions. Upon request, to furnish collection advice and opinions to SB/SE personnel or other functions of the Service responsible for collection matters in any matter (court and noncourt).

02. Actions. To advise SB/SE Field personnel, handle the legal work, and assist US Attorneys in cases involving:




       |  |
       | --- |
       | • Federal and state receiverships or other insolvencies |
       | • Assignments for the benefit of creditors |
       | • Corporate dissolutions |
       | • Administration of estates and decedents or incompetents |
       | • Civil enforcement of summonses |
       | • Tax liens, mortgage foreclosures, and actions to quiet title |
       | • Injunctions to restrain the assessment or collection of taxes |
       | • Actions seeking the return of property seized by levy |
       | • Actions for the perpetuation of testimony |
       | • Actions by taxpayers for review of jeopardy assessment or jeopardy levy procedures |
       | • Civil remedies against tax return preparers, including the handling of refund suits, brought by tax return preparers on their own behalf |
       | • Actions including refund suits relating to civil penalties for frivolous returns, and the filing of false statements with respect to withholding |
       | • Actions relating to civil penalties for aiding and abetting understatements of tax liabilities and the filing of false statements with respect to withholding |
       | • Motions to quash formal document requests |

03. Bankruptcy Matters. To handle legal work pertaining to the collection and protection of tax claims and liens of the United States in proceedings under the bankruptcy law.

04. Bankruptcy Plans. To accept or reject plans where the United States is a creditor or equity security holder, including municipal debt adjustment plans, reorganization plans, and railroad reorganization plans (11 U.S.C. §§ 901(a) and 1126(a)). This covers proceedings where the United States possesses solely an IRS claim (a Treasury claim), as well as proceedings in which there are other claims of the United States in addition to the claim of the IRS. A non-Treasury claim of the United States includes any department, agency, federally chartered corporation, or instrumentality of the United States. To the extent that an agreement cannot be reached between the Chief Counsel, IRS, and the holder of a non-Treasury claim of the United States, the matter will be referred to the General Counsel of the Treasury for resolution.

05. Suits. To determine what civil actions shall be brought by the Government in connection with the collection with the collection of internal revenue taxes and to authorize or sanction commencement of such actions.

06. Offers-in-Compromise. To review and dispose of offers-in-compromise.

07. Leases, Bonds, and Escrow Agreements. To handle legal matters arising within the regions with respect to leases, bonds, escrow agreements, and other similar matters relating to the collection of taxes.

08. Appeals. To make recommendations to the Chief Counsel respecting appeals of court decisions in general litigation matters.

09. Disclosure of Information. To assist, when called upon, Service field personnel in matters involving the disclosure of information. The Associate Chief Counsel (P&A), Branches 6 and 7, however, retains primary responsibility for disclosure matters.

10. Jeopardy and Termination Assessments and Jeopardy Levies. To approve in writing the making of jeopardy and termination assessments and jeopardy levies. This authority may be redelegated no lower than Associate Area Counsel.

11. Summons Matters. To review, upon request, proposed summonses, and to recommend enforcement or defense in summons litigation matters, involving SB/SE & W&I taxpayers.

12. Writs of Entry. To review, upon request, proposed writs of entry, and to recommend the filing of motions to obtain writs of entry in collection matters.

13. Writs Ne Exeat. To review, upon request, and to recommend the filing of writs ne exeat in collection matters.


**30.3.2.4.3.2** **(11-13-2023)**

##### Assistant Division Counsel (Small Business/Self-Employed)

1. The **Assistant Division Counsel (Abusive Tax Avoidance Transactions)** reports directly to the Division Counsel and Deputy Division Counsel (SB/SE) and is responsible for formulating, implementing, and executing a comprehensive plan for addressing abusive tax avoidance transactions (ATAT), which includes examination, assessment, and collection matters. The Assistant Division Counsel (Abusive Tax Avoidance Transactions) provides guidance to and serves as the principal legal advisor and contact point on ATAT matters with Division field attorneys, other components of the Office of Chief Counsel, the SB/SE Operating Division, Treasury, and the Department of Justice. The Assistant Division Counsel (Abusive Tax Avoidance Transactions) is the line supervisor of attorneys assigned to the headquarters ATAT function, and has functional responsibility for oversight of ATAT matters throughout the Division.

2. The **Assistant Division Counsel (General Litigation)** reports directly to the Division Counsel and Deputy Division Counsel (SB/SE) and is responsible for formulating, implementing, and executing a comprehensive plan for supporting the SB/SE Operating Division and Chief Counsel goals in General Litigation (GL) matters (which includes collection matters). The Assistant Division Counsel (General Litigation) provides guidance to and serves as the principal legal advisor and contact point on such matters with Division field attorneys, other components of the Office of Chief Counsel, the SB/SE Operating Division, Treasury, and the Department of Justice. The Assistant Division Counsel (General Litigation) is the line supervisor of attorneys assigned to the headquarters GL function, and has functional responsibility for oversight of GL matters throughout the Division.

3. The **Assistant Division Counsel (Prefiling)** reports directly to the Division Counsel and Deputy Division Counsel (SB/SE) and is responsible for providing guidance on pre-filing and filing matters. The Assistant Division Counsel (Prefiling) serves as the principal legal advisor and contact point on pre-filing and filing matters with Division field attorneys, other components of the Office of Chief Counsel, the SB/SE Operating Division, Treasury, and the Department of Justice. The Assistant Division Counsel (Prefiling) serves as principal legal advisor to the SB/SE Communications Division, contact point on electronic filing/electronic compliance and taxpayer identification number issues, and a principal contact point on employment tax issues. The Assistant Division Counsel (Prefiling) assists that Office in the formulation of policies and programs, and performs special assignments of a case or project nature.

4. The **Assistant Division Counsel (Tax Litigation)** reports directly to the Division Counsel and Deputy Division Counsel (SB/SE) and is responsible for formulating, implementing, and executing a comprehensive national tax litigation program in all substantive tax, non-abusive tax avoidance transaction (ATAT) areas. The Assistant Division Counsel (Tax Litigation) is responsible for ensuring that SB/SE attorneys consistently apply law and policy in tax litigation matters, including nondocketed cases, and cases docketed in the U.S. Tax Court, U.S. District Courts, and the Court of Federal Claims. The Assistant Division Counsel (Tax Litigation) provides guidance to and serves as the principal legal advisor and contact point on non-ATAT tax litigation matters with Division field attorneys, other components of the Office of Chief Counsel, the SB/SE Operating Division, Treasury, and the Department of Justice. The Assistant Division Counsel (Tax Litigation) is the line supervisor of any attorneys assigned to the headquarters Tax Litigation function, and has functional responsibility for oversight of Tax Litigation matters throughout the Division. The Assistant Division Counsel (Tax Litigation) serves as principal legal advisor to the Examination function in the SB/SE Operating Division on procedural issues involving tax litigation matters. In addition, the Assistant Division Counsel (Tax Litigation) serves as principal legal advisor and contact point on anti-money laundering (AML) issues and for the National Fraud Program.


**30.3.2.4.3.3** **(10-28-2008)**

##### Area Counsel (Small Business/Self-Employed)

1. There are nine Area Counsel within the office of Division Counsel (SB/SE) who report to the Division Counsel. Each Area Counsel has a deputy and a staff of Associate Area Counsel who act as first-line managers of SB/SE attorneys and paralegals. Each Area Counsel is assigned a geographic area to coincide with one or more SB/SE compliance areas of the Service:



   - Area 1, Manhattan

   - Area 2, Philadelphia

   - Area 3, Jacksonville

   - Area 4, Chicago

   - Area 5, Denver

   - Area 6, Dallas

   - Area 7, San Francisco

   - Area 8, Los Angeles

   - Area 9, Kansas City


2. The Area Counsel are the principal legal advisors to one or more SB/SE Area Compliance Directors. The Area Counsel are also the principal legal advisors to various other Field executives within the Customer Accounts Service (CAS) and Taxpayer Education and Communication (TEC) offices of the Division Commissioner, SB/SE, and to other designated Field executives and managers within the components of the Wage & Investment Division, the Taxpayer Advocate Service, and the SB/SE function of the Appeals Division, within their geographic areas.

3. The Area Counsel share the subject matter responsibility of the Division Counsel (SB/SE) for matters within their geographical area. The Area Counsel oversee all docketed and non-docketed tax litigation matters involving SB/SE and W&I taxpayers within their jurisdiction. The Area Counsel are responsible for providing legal advice and opinions, upon request, to personnel of the Division Commissioner, SB/SE, and to other functions of the Service having jurisdiction over collection matters, in any matter relating to the collection of taxes within their geographical areas. The Area Counsel are also responsible for handling legal work relating to collection actions, including bankruptcies, within their geographical areas.


**30.3.2.4.3.4** **(07-21-2005)**

##### Associate Area Counsel (Small Business/Self-Employed)

1. The Associate Area Counsel (SB/SE) are the first-line managers of SB/SE attorneys and paralegals. The Associate Area Counsel report to the Area Counsel responsible for their geographic area. The locations of the Associate Area Counsel are depicted on the organizational chart in Exhibit 30.3.2-13.


**30.3.2.4.4** **(11-13-2023)**

#### Division Counsel (Strategic Litigation)

1. The Strategic Litigation (SL) legal function is headed by the Division Counsel (SL) who reports to, and who is supervised by, the Deputy Chief Counsel (Operations). Two Deputy Division Counsels (SL) report to, and are supervised by, the Division Counsel (SL). The Division Counsel (SL), together with their Deputies, supervise: twelve Strategic Litigation Counsels who are responsible for the most significant and complex litigation in the U.S. Tax Court including cases considered “Significant” under the Chief Counsel Significant Case Coordination Program (and who, in turn, supervise Special Trial Attorneys and Paralegals), Senior Level Counsels, Senior Level Special Trial Attorneys, Special Counsels, Staff Attorneys, and Administrative Support Staff — all as depicted on the organizational chart in _Exhibit 30.3.2-14_.

2. The Division Counsel (SL) serves as the principal legal advisor to the Commissioner, Internal Revenue Service, other operating divisions, Chief Counsel, Appeals, and other senior Service and Treasury officials on strategic litigation matters and oversees the cases under the responsibility of the Division Counsel (SL). The Division Counsel (SL) works closely with the Commissioner, Internal Revenue Service, other operating divisions, Chief Counsel, Appeals, and other senior Service and Treasury officials to formulate and execute policies, strategic goals, procedures, operating priorities, and programs. The Division Counsel is a national organization and is responsible for the effective management and oversight of the delivery of litigation services by employees in various field offices across the country.


**30.3.2.4.4.1** **(11-13-2023)**

##### Subject Matter Responsibility and Functions

1. The Division Counsel (SL) has primary responsibility for providing litigation services in cases considered “Significant” under the Chief Counsel Significant Case Coordination Program. The Division Counsel (SL) also provides legal advice and services to the Internal Revenue Service on its most significant non-docketed cases. In addition, the Division Counsel (SL) assists the Department of Justice in handling civil litigation of the Services’ most significant cases in U.S. District Court.

2. The Division Counsel (SL) performs the following functions with respect to the litigation of significant cases:



1. Represents the Commissioner in the litigation of significant cases pending in the U.S. Tax Court.

2. Prepares enforcement, defense, and settlement letters in significant summons enforcement and refund litigation cases and leads the coordination of these Department of Justice cases with other Counsel functions.

3. Makes recommendations of acquiescence and non-acquiescence in adverse decisions in significant case litigation, providing on-going services to Department of Justice and coordinating with Associate Chief Counsels on recommendations to the Chief Counsel and Department of Justice regarding appeals of adverse decisions, rehearing and rehearing en banc, the filing of amicus curiae briefs, petitions for writ of certiorari to the U.S. Supreme Court, and any other appropriate judicial action pertaining to matters under the jurisdiction of SL.

4. Manages the Significant Case Program, which allows for coordination of significant cases approaching litigation, and docketed in the U.S. Tax Court and other federal courts.

5. Manages the Strategic Litigation Program, which includes a nationwide staff of Special Trial Attorneys and Paralegals, and which provides the primary support for the litigation of significant cases in the U.S. Tax Court.


3. The Division Counsel (SL) performs the following functions with respect to rendering legal advice, coordination activities, and providing litigation and other support on matters or issues:



1. Provides pre-filing and post-filing legal advice to examination teams, either in the audit of significant and complex returns or in the consideration of significant and complex claims for refund.

2. Coordinates input from the Commissioner with the Deputy Chief Counsel (Technical), Associate Chief Counsels and Treasury officials with respect to the need for and the administrability of published guidance, including regulations, notices, revenue rulings, revenue procedures, actions on decision and other items of published guidance.

3. Coordinates key issues and cases with the Chief Counsel, Deputies Chief Counsel, Associate Chief Counsels, and other members of the Chief Counsel organization.

4. Provides internal and external training on issues.

5. Conducts public outreach to taxpayer organizations.


**30.3.2.4.4.2** **(11-13-2023)**

##### Deputy Division Counsels (Strategic Litigation)

1. The Division Counsel (SL) field executive staff is composed of two Deputy Division Counsels who report to and are supervised by the Division Counsel (SL). The Deputy Division Counsels serve as the primary advisors on SL matters, assist in formulating policies and programs, and oversee the cases under the responsibility of the Division Counsel (SL).

2. Deputy Division Counsels supervise and are responsible for the effective management and oversight of the field operations and personnel within their respective teams. Several Strategic Litigation Counsels responsible for groups of Special Trial Attorneys and Paralegals report to, and are supervised by, their respective Deputy Division Counsel. In addition, Deputy Division Counsels supervise and are responsible for Senior Level Special Trial Attorneys who lead trial teams litigating the most significant cases before the U.S. Tax Court. To ensure close coordination with Division Counsel (SL) headquarters, LB&I, SB/SE, and TEGE Commissioner headquarters, Associate Chief Counsel offices, and other counsel staff, Deputy Division Counsels are assisted by Senior Level Counsels assigned to the Division Counsel (SL) headquarters.

3. The Deputy Division Counsels exercise ongoing responsibility for the budget, administrative and personnel actions, processes, and procedures for their respective teams.

4. The Deputy Division Counsels will, as directed by the Division Counsel (SL), or as they deem appropriate, designate other persons under their supervision to serve as coordinators and primary liaisons in support of other client strategic initiatives and programs.


**30.3.2.4.4.3** **(11-13-2023)**

##### Strategic Litigation Counsels (Strategic Litigation)

1. Strategic Litigation Counsels provide primary support to the Deputy Division Counsels and may serve as an actor for the Deputy Division Counsel in their absence or unavailability.

2. Strategic Litigation Counsels provide primary support to the Deputy Division Counsels on SL matters. They serve as the principal advisor to the Deputy Division Counsels on SL matters assigned to SL personnel within their assigned groups and serve as a consultant to other front-line managers on litigation matters. The Strategic Litigation Counsels conduct the primary management of the Significant Case Program, which allows for coordination of significant cases approaching litigation, and docketed in the U.S. Tax Court and other Federal courts. They oversee and supervise all Special Trial Attorneys and Paralegals, who handle the most complex and significant U.S. Tax Court cases.

3. Strategic Litigation Counsels may serve as a consultant to other front-line managers with respect to a variety of pre-filing, filing and post-filing activities. In addition, they have the primary responsibility for preparing enforcement, defense and settlement letters in significant summons enforcement and refund litigation. They also are responsible for insuring appropriate coordination of advice and significant issues within their respective Teams and Division Counsel (SL).


**30.3.2.4.5** **(11-19-2009)**

#### Division Counsel/Associate Chief Counsel (Tax Exempt & Government Entities)

1. . The Office of Division Counsel/Associate Chief Counsel (Tax Exempt & Government Entities) is one of only two offices that combines the strategic, technical, and litigation functions into a single integrated office. This combined role results in two basic parts of the office structure: Headquarters and Area Counsel, as depicted on the organizational chart in Exhibit 30.3.2-14. The Tax Exempt & Government Entities legal function is headed by the Division Counsel/Associate Chief Counsel (TEGE), who reports to, and who is supervised by, the Deputy Chief Counsel (Technical).



1. The office is headquartered in Washington, D.C.; it maintains eight branches in headquarters and Area Counsel offices in Long Island, Baltimore, Chicago, Dallas, Denver, and Los Angeles.

2. The Headquarters component includes the Division Counsel/Associate Chief Counsel and Deputies Division Counsel/Deputies Associate Chief Counsel as well as others involved in strategic planning, technical, litigation, and administrative activities.

3. The office is responsible for providing impartial legal service to the TEGE Operating Division, other Service Operating Divisions, other Service and Counsel offices, Treasury, other government agencies, and the public.


2. **Subject Matter Responsibility**. In strategic partnership with the Service, the Division Counsel/Associate Chief Counsel (TEGE) is responsible for planning, directing, and coordinating the policies and programs with respect to issues pertaining to the uniform interpretation and application of federal tax laws involving:



1. Employment taxes and taxes on self-employment income

2. Income tax and other tax aspects of executive compensation, exempt organizations, employee benefits, and health and welfare programs (other than those within the jurisdiction of the Commissioner, TEGE Operating Division), including employer-provided medical plans, nonqualified deferred compensation plans, and fringe benefits

3. Indian tribal governments

4. Federal, state, and local governments

5. Tax exempt bonds, in field activity


3. The office represents the Service in litigation in the U.S. Tax Court and serves as the chief legal advisor to the Chief Counsel and all Service functions with respect to legislation, regulations, and other guidance, rulings, and advisory opinions, and litigation within the jurisdiction of the Division Counsel/Associate Chief Counsel (TEGE).


**30.3.2.4.5.1** **(06-07-2012)**

##### Functions of the Division Counsel/Associate Chief Counsel (TEGE)

01. Assists the Operating Division (Tax Exempt/Government Entities) (OD (TEGE)) in setting the business unit strategy and goals that enhance compliance with the tax laws.

02. Develops and executes policies and procedures designed to assist the OD (TEGE) in executing the Customer Education and Outreach, Rulings and Agreements, and Examination programs for Employee Plans (EP) and Exempt Organizations (EO) and similar programs relating to government entities, Indian tribal governments, and tax exempt bonds.

03. Assists other Service Operating Divisions in setting the strategy and goals relating to other topics within the jurisdiction of the Division Counsel/Associate Chief Counsel (TEGE), e.g., employment tax.

04. Serves as the legal advisor to the Commissioner, TEGE Operating Division, and other Service Operating Divisions, by preparing or reviewing regulations, legislation, rulings, legal memoranda, and other responses to technical matters within the jurisdiction of the Division Counsel/Associate Chief Counsel (TEGE).

05. Provides interpretations of laws and procedures by providing pre-transactional rulings to specific requesters and issuing technical advice and technical assistance to Service personnel regarding topics within its jurisdiction (except those within the jurisdiction of the TEGE Operating Division).

06. Coordinates with the Department of Labor with respect to issues relating to employee benefit plans, in particular, cases involving prohibited transactions and qualification cases raising the exclusive benefit requirements of IRC § 401(a)(2) and with respect to certain issues relating to health and welfare benefit plans.

07. Coordinates with other agencies with respect to issues of coordinated jurisdiction, for example:



    - The Department of Labor and Pension Benefit Guaranty Corporation (PBGC) with respect to employee benefit plans

    - Health and Human Services (HHS) with respect to employer-provided group health coverage

    - The Railroad Retirement Board with respect to railroad retirement issues

    - The Social Security Administration (SSA) with respect to employment tax matters

    - The state attorneys general with respect to charitable regulation


08. Renders legal advice and assistance to the Service, Appeals offices, and Campus offices concerning applications for determination of exemption qualification, compliance activities, cases involving the examination of returns, or the consideration of claims for refund with respect to areas under the jurisdiction of the Division Counsel/Associate Chief Counsel (TEGE).

09. Renders legal advice and assistance to the Service, Appeals offices, and Campus offices concerning the disclosure of information with respect to TEGE taxpayers and issues within the jurisdiction of the Division Counsel/Associate Chief Counsel (TEGE).

10. Renders legal advice and assistance to the Service and Appeals offices concerning the review and disposition of offers-in-compromise when the offer is premised on doubt as to liability or promotion of effective tax administration and when either the offer was submitted by a TEGE taxpayer or the underlying liability issue is within the jurisdiction of the Division Counsel/Associate Chief Counsel (TEGE).

11. Approves for the Chief Counsel announcements pertaining to civil litigation policy as it pertains to the duties and functions of the Office of the Division Counsel/Associate Chief Counsel (TEGE).

12. Considers cases within the jurisdiction of the Division Counsel/Associate Chief Counsel (TEGE) (when requested by the Counsel Criminal Tax office) where the Service requests review of decisions declining recommendations for grand jury investigation and assists in preparing each case for a final decision of the grand jury investigation in question.

13. Handles and processes cases docketed in the U.S. Tax Court, including the determination of the Service's litigating position in such cases, as well as in suits for refund and for declaratory judgment, and reviews closing agreements that require the approval of the Commissioner in such cases or suits with respect to the Division Counsel/Associate Chief Counsel (TEGE) areas of responsibility.

14. Prepares, reviews, and coordinates pleadings, motions, briefs, settlement documents, notices of appeal, and other material prepared in connection with U.S. Tax Court litigation with respect to areas under his/her responsibility.

15. Approves the defense or settlement of cases pending in the Tax Court, including the preparation and approval of Chief Counsel decisions.

16. Handles and conducts hearings and trials of cases in the Tax Court where circumstances warrant.

17. Advises the Department of Justice (DOJ) as to the facts and law:



    1. Prepares recommendations concerning defense, settlement, concession, appeal, or certiorari

    2. Furnishes advice and assistance in pending litigation including suits for declaratory judgment for exempt organizations arising under IRC § 7428 in the U.S. District Court for the District of Columbia and the Court of Federal Claims

    3. Authorizes or sanctions counterclaims, third party complaints, or the commencement of collections suits in the district courts, bankruptcy courts, or the U.S. Court of Federal Claims pertaining to matters under his/her jurisdiction


18. Provides advice and review to the TEGE Operating Division, handles the legal work in conjunction with other Counsel divisions, and assists U.S. Attorneys in cases involving the following when these cases involve matters within the jurisdiction of the Division Counsel/Associate Chief Counsel (TEGE).



    - Enforcement of a summons

    - Injunctions to restrain the assessment or collection of taxes

    - Recovery of erroneous refunds

    - Actions for the perpetuation of testimony

    - Motions to quash formal document requests

    - Actions by taxpayers for review of jeopardy assessment procedures

    - Civil remedies against tax return preparers pertaining to matters under his/her jurisdiction

    - Civil actions including refund suits relating to civil penalties for aiding and abetting understatements of tax liabilities, the filing of frivolous returns, and the filing of false statements with respect to withholding

    - Federal and state receiverships or other insolvencies

    - Assignments for the benefit of creditors

    - Corporate dissolutions

    - Administration of estates and decedents or incompetents

    - Tax liens

    - Actions seeking the return of property seized by levy


19. Approves in writing the making of jeopardy and termination assessments and levies made less than 30 days after notice and demand for payment. This authority may be redelegated no lower than the Area Counsel (TEGE).

20. Approves for the Chief Counsel recommendations of acquiescence and nonacquiescence in adverse decisions in tax litigation; prepares actions on decision in adverse decisions, where appropriate; approves for the Chief Counsel recommendations to Department of Justice regarding appeals from adverse decisions and regarding certiorari to the U.S. Supreme Court pertaining to matters under his/her jurisdiction.

21. Performs all other necessary litigation coordination within the Division Counsel/Associate Chief Counsel (TEGE) area of responsibility.

22. Processes nondocketed cases submitted for pre-litigation review by the Service with respect to matters under the office's jurisdiction.

23. Provides review and advice to the TEGE Operating Division concerning audits of churches under IRC § 7611.

24. Coordinates matters involving the discretion of the Secretary of the Treasury to intervene in actions brought by parties other than the United States under § 502 of the Employment Retirement Income Security Act of 1974 (ERISA), except those matters in which the Secretary of the Treasury or Secretary of Labor is named as a direct party defendant.

25. Coordinates large case petitions, Tax Court briefs, defense letter preparation, appeal recommendations, actions on decisions, and other appropriate matters with other Division Counsel or other Associate Chief Counsel as necessary.

26. Performs the duties and functions relating to the consideration and review, prior to issuance, of proposed and final statutory notices of deficiency and statutory notices of claim disallowance and notices of adverse determinations prepared by the Service.

27. Coordinates with Congressional committees, the Department of the Treasury, the Commissioner’s office, DOJ, and other departments and agencies on matters within his/her jurisdiction.

28. Performs the duties and functions relating to the concurrence in the elimination of the ad valorem fraud penalty in a case not docketed in the U.S. Tax Court.

29. Performs the duties and functions relating to the concurrence as to action proposed by the Appeals Division in any case in which a recommendation for criminal prosecution is pending.

30. Approves on behalf of the Chief Counsel actions to be taken with respect to U.S. Tax Court subpoenas and disclosure of information in U.S. Tax Court litigation conducted under his/her jurisdiction.

31. Disposes of Tax Court cases under the jurisdiction of the Division Counsel/Associate Chief Counsel (TEGE), referring, with recommendations, to the Chief Counsel such Tax Court cases which seem proper or as may be directed.

32. Exercises exclusive jurisdiction over any case docketed in the Tax Court:



    1. If the sole issue or primary issue is a TEGE issue and the notice of deficiency, liability, or other determination was issued by the Appeals Division after Appeals' consideration of all petitioned issues;

    2. If the notice of deficiency, liability, or final adverse determination letter was issued by the TEGE Operating Division and is based upon a TEGE ruling or TEGE technical advice in that case involving a qualification of an employee plan or tax exemption and/or foundation status of an organization (but only to the extent the case involves such issue); or,

    3. If the case was docketed under IRC §§ 7428, 7476, or 7478, except as provided in paragraph 3 of Delegation Order 8-1, Appeals Functions. Settlement of Cases Docketed in the United States Tax Court (IRM 1.2.47.2. Jurisdiction vests with Counsel at the time such cases are docketed with the court. _See_ 26 CFR § 301.6020-1, 26 CFR § 301.6201-1, 26 CFR § 301.7701-9; [Treasury Department Order No. 150-10](http://www.treasury.gov/about/role-of-treasury/orders-directives/Pages/to150-10.aspx); [General Counsel Order No. 4](http://intranet.treas.gov/General_Counsel/orders-dir/order4_1-19-01.pdf); and Delegation Order 8-1.


33. Exercises jurisdiction over all docketed Tax Court cases if the notice of deficiency, liability, or other determination was issued by the TEGE Operating Division or if the notice of deficiency, liability, or other determination was issued by another Service Operating Division and the sole issue or primary issue is a TEGE issue. Extends the settlement period or accepts jurisdiction of docketed Tax Court cases referred to the Appeals Division for settlement.

34. Determines what civil actions should be brought for recovery of erroneous refunds pertaining to matters under the jurisdiction of the Division Counsel/Associate Chief Counsel (TEGE) and authorizes the commencement of erroneous refund collection suits. Authorizes or sanctions counterclaims or third-party complaints with respect to refund suits pending in the district courts or the U.S. Court of Federal Claims if those suits involve matters under the jurisdiction of the Division Counsel/Associate Chief Counsel (TEGE) and performs necessary legal services on behalf of the Service as directed in connection with taxpayer suits for refund of taxes.

35. Partners with other Division Counsel to request that Department of Justice commence any proceeding to enjoin promoters of abusive tax shelters, as authorized under IRC § 7408, and to advise and consult with DOJ concerning the defense, settlement, concession, or appeal of such cases.

36. Partners with other Division Counsel to develop procedures and guidelines with the Commissioner's office for the assertion of civil penalties against promoters of abusive tax shelter under IRC § 6700.

37. Partners with other Division Counsel to develop procedures with the Commissioner's office and DOJ for handling refund suits for the recovery of civil penalties by promoters under IRC § 6703.


**30.3.2.4.5.2** **(06-11-2008)**

##### Deputies Division Counsel/Deputies Associate Chief Counsel (Tax Exempt & Government Entities)

1. There are three Deputy Division Counsel/Deputy Associate Chief Counsel (Tax Exempt & Government Entities):



   - Deputy Division Counsel/Deputy Associate Chief Counsel (Employee Benefits) (EB)

   - Deputy Division Counsel/Deputy Associate Chief Counsel (Exempt Organizations, Employment Tax and Government Entities) (EOEG)

   - Deputy Division Counsel/Deputy Associate Chief Counsel (Field Service) (FS)


2. The deputies report to and are supervised by the Division Counsel/Associate Chief Counsel (TEGE). The deputies perform those functions the Division Counsel/Associate Chief Counsel (TEGE) is authorized to perform that arise out of, relate to, or concern the respective activities or functions administered by the deputies, subject to the continuing supervision, control, and review of the Division Counsel/Associate Chief Counsel (TEGE).

3. The following are the functions of the Deputies Division Counsel/Deputies Associate Chief Counsel (TEGE):



1. Upon delegation by the Division Counsel/Associate Chief Counsel (TEGE), any deputy may supervise all or any Special Counsel, Technical Assistants, and staff not otherwise directly supervised by the DC/ACC (TEGE).

2. As prescribed by the DC/ACC (TEGE), the deputies may serve as Acting Division Counsel/Associate Chief Counsel (TEGE) in the absence of the DC/ACC (TEGE) and may act for or represent the DC/ACC (TEGE) in the development of policies governing the office.

3. The deputies will perform such additional duties as may, from time to time, be assigned by the DC/ACC (TEGE).


**30.3.2.4.5.3** **(06-11-2008)**

##### Deputy Division Counsel/Deputy Associate Chief Counsel (Employee Benefits)

1. The Deputy Division Counsel/Deputy Associate Chief Counsel (Employee Benefits) (EB) is made up of four branches covering employee benefits issues including qualified plans, executive compensation, and health and welfare. The office is responsible for providing impartial legal service to the TEGE Operating Division, other Service Operating Divisions, other Service and Counsel offices, other governmental agencies, and the public.

2. **Subject Matter Responsibilities**. The Deputy Division Counsel/Deputy Associate Chief Counsel (EB) is responsible for:



1. Planning, directing, supervising technical subject experts, and coordinating operational policies and programs with respect to legislation, regulations, and other guidance

2. Interpretations of rulings and opinions to assure the uniform interpretation and application of federal tax laws involving income tax and other tax aspects of executive compensation, employee benefits programs ( including employer-provided medical plans), and nonqualified deferred compensation plans.


3. The functions of the Deputy Division Counsel/Deputy Associate Chief Counsel (EB) are described above in CCDM 30.3.2.4.4.2.


**30.3.2.4.5.4** **(08-02-2011)**

##### Deputy Division Counsel/Deputy Associate Chief Counsel (Exempt Organizations/Employment Tax/Government Entities)

1. The Deputy Division Counsel/Deputy Associate Chief Counsel (Exempt Organizations/Employment Tax/Government Entities) (EOEG) is made up of three branches covering exempt organizations, employment tax, and government entities issues. The office is responsible for providing impartial legal service to the TEGE Operating Division, other Service Operating Divisions, other Service and Counsel offices, other governmental agencies, and the public.

2. **Subject Matter Responsibilities**. The Deputy Division Counsel/Deputy Associate Chief Counsel (EOEG) is responsible for:



1. Planning, directing, supervising technical subject experts, and coordinating operational policies and programs with respect to legislation, regulations and other guidance.

2. Interpretations of rulings and opinions to assure the uniform interpretation and application of federal tax laws involving employment taxes and taxes on self-employment income, exempt organizations (other than those within the jurisdiction of the Commissioner, TEGE Division), fringe benefits, Indian tribal governments, and federal, state, and local governments.


3. The functions of the Deputy Division Counsel/Deputy Associate Chief Counsel (EOEG) are described above in CCDM 30.3.2.4.4.2.


**30.3.2.4.5.5** **(06-11-2008)**

##### Deputy Division Counsel/Deputy Associate Chief Counsel (Field Service)

1. The Deputy Division Counsel/Deputy Associate Chief Counsel (Field Service) is made up of six Area Counsels in six geographic areas covering employee benefits, exempt organizations, employment tax, tax exempt bonds, and government entities issues arising in field offices. The office is responsible for providing impartial legal service to the TEGE Operating Division, other Service Operating Divisions, other Service and Counsel offices, other governmental agencies, and the public. The six geographic Area Counsels are:



   - Northeast Area

   - Mid-Atlantic Area

   - Great Lakes Area

   - Gulf Coast Area

   - Pacific Coast Area

   - Mountain States Area


2. **Subject Matter Responsibilities.** The Deputy Division Counsel/Deputy Associate Chief Counsel (Field Service) is responsible for planning, directing, supervising, and coordinating the operational policies and programs for the delivery of legal advice, legal representation in litigation, and support involving:



   - Employment taxes and taxes on self-employment income

   - Income tax and other tax aspects of executive compensation, employee benefits programs, and exempt organizations, including employer-provided medical plans, nonqualified deferred compensation plans, and fringe benefits

   - Indian tribal governments

   - Tax exempt bonds

   - Federal, state, and local governments


3. The functions of the Deputy Division Counsel/Deputy Associate Chief Counsel (Field Service) are described above in CCDM 30.3.2.4.4.2.


**30.3.2.4.5.5.1** **(06-11-2008)**

###### Area Counsel (TEGE)

1. Area Counsel offices are designed as groups of versatile specialized staff providing legal service to the TEGE Operating Division. Based on an analysis of the geographic source of workload and the key functional location of client activities, the Deputy Division Counsel/Deputy Associate Chief Counsel (Field Service) serves the TEGE Division field function from six key cities. The office is responsible for providing impartial legal service to the TEGE Operating Division, other Service Operating Divisions, other Service and Counsel offices, other governmental agencies, and the public. There are six Counsel areas, with an Area Counsel and a Deputy Area Counsel for each area:



   - Northeast (Long Island)

   - Mid-Atlantic (Baltimore)

   - Great Lakes (Chicago)

   - Gulf Coast (Dallas)

   - Mountain States (Denver)

   - Pacific Coast (Los Angeles with a POD in Thousand Oaks)


2. **Subject Matter Responsibilities**. The Area Counsels are responsible for planning, directing, supervising, and coordinating the operational policies and programs for the delivery of legal advice, legal representation in litigation, and support to the TEGE Operating Division, other Service Operating Divisions, other Service and Counsel offices, other government agencies, and the public in the topics within his/her geographic jurisdiction concerning the application of federal tax laws involving:



1. Employment taxes and taxes on self-employment income

2. Income tax and other tax aspects of executive compensation, employee benefits programs, and exempt organizations, including employer-provided medical plans, nonqualified deferred compensation plans, and fringe benefits

3. Indian tribal governments

4. Federal, state, and local governments


**30.3.2.4.5.5.1.1** **(06-07-2012)**

###### Functions of the Area Counsels

01. Serves as legal advisor to the following:



    - The National Director, Employee Plans (EP) Examination, Baltimore

    - The National Director, Exempt Organizations (EO) Examination, Dallas

    - Employee Plans (EP) Area Managers

    - Exempt Organizations (EO) Area Managers

    - The TEGE field office managers on Government Entity matters

    - Other TEGE employees involved in outreach, compliance, examination, and enforcement activities


02. Litigates cases in the U.S. Tax Court, including:



    1. Declaratory judgment cases under IRC §§ 7428, 7476, and 7478

    2. Cases arising under IRC § 7436

    3. Deficiency cases arising from an examination conducted by the TEGE Operating Division

    4. Deficiency cases arising from an examination conducted by another Service Operating Division if the sole issue or primary issue is a TEGE issue

    5. Approves the defense or settlement of cases pending in the Tax Court


03. Prepares and files pleadings, motions, briefs, and settlement documents in Tax Court litigation.

04. Handles and processes litigation in the U.S. Tax Court, including the determination of the Service's litigating position in such cases.

05. Reviews closing agreements.

06. Prepares defense letters in suits including declaratory judgment suits filed by exempt organizations under IRC § 7428 in the U.S. District Court for the District of Columbia or in the Court of Federal Claims and suits for refund of employment taxes under IRC § 7422 and provides advice and support to Department of Justice in that litigation.

07. Partners with other Division Counsel/Associate Chief Counsel (TEGE) executives and managers in the preparation of legal advice to Department of Justice as to the facts and law including:



    1. Recommendations concerning defense, settlement, concession, appeal, or certiorari

    2. Other advice and assistance including suits for declaratory judgment for exempt organizations arising under IRC § 7428 in the U.S. District Court for the District of Columbia and the Court of Federal Claims

    3. The authorization or sanctioning of counterclaims, third party complaints, or the commencement of collection suits in the district courts, bankruptcy courts, or the U.S. Court of Federal Claims pertaining to matters under his/her jurisdiction


08. Prepares recommendations of acquiescence and nonacquiescence in adverse decisions in tax litigation and prepares recommendations to the Division Counsel/Associate Chief Counsel (TEGE) regarding appeals of litigated cases.

09. Coordinates large case petitions, Tax Court briefs, and other appropriate matters with the Division Counsel/Associate Chief Counsel (TEGE) and with other Division Counsel as necessary.

10. Assists the Division Counsel/Associate Chief Counsel (TEGE) in considering cases within his/her jurisdiction (when requested by the Counsel Criminal Tax office) where the Service requests review of decisions declining recommendations for grand jury investigation and assists in preparing each case for final decisions of the grand jury investigation in question.

11. Performs all other necessary litigation coordination in his/her area of responsibility.

12. Provides advice to the Division Counsel/Associate Chief Counsel (TEGE) concerning audits of churches under IRC § 7611.

13. Supervises the pre-issuance review of notices in nondocketed cases submitted for pre-litigation review by the Operating Division TEGE client.

14. Performs the duties and functions relating to:



    - The consideration and review, prior to issuance, of proposed and final statutory notices of deficiency and statutory notices of claim disallowance and notices of adverse determinations prepared by the Service

    - The concurrence in the elimination of the ad valorem fraud penalty in a case not docketed in the U.S. Tax Court

    - The concurrence as to action proposed by the Appeals Division in any case in which a recommendation for criminal prosecution is pending


15. Supervises and coordinates the rendering of legal advice and assistance to Service offices, Appeals offices, and Campus offices concerning applications for determination of exemption qualification, compliance activities, cases involving the examination of returns, or the consideration of claims for refund with respect to areas under his/her jurisdiction.

16. Renders legal advice and assistance to the Service, Appeals offices, and Campus offices concerning the disclosure of information with respect to TEGE taxpayers and issues within the jurisdiction of the Division Counsel/Associate Chief Counsel(TEGE).

17. Renders legal advice and assistance to the Service and Appeals offices concerning the review and disposition of offers-in-compromise when the offer is premised on doubt as to liability or promotion of effective tax administration and when either the offer was submitted by a TEGE taxpayer or the underlying liability issue is within the jurisdiction of the Division Counsel/Associate Chief Counsel (TEGE).

18. Directs and ensures coordination with the Department of Labor with respect to issues relating to employee benefit plans, in particular, cases involving prohibited transactions and qualification cases raising the exclusive benefit requirements of IRC § 401(a)(2).

19. Provides advice and review to the TEGE Operating Division, handles the legal work in conjunction with other Counsel divisions, and assists US Attorneys in cases involving the following when these cases involve matters within the jurisdiction of the Division Counsel/Associate Chief Counsel (TEGE):



    - Enforcement of a summons

    - Injunctions to restrain the assessment or collection of taxes

    - Actions by taxpayers for review of jeopardy assessment procedures

    - Civil remedies against tax return preparers pertaining to matters under his/her jurisdiction

    - Civil actions including refund suits relating to civil penalties for aiding and abetting understatements of tax liabilities, the filing of frivolous returns, and the filing of false statements with respect to withholding

    - Federal and state receiverships or other insolvencies

    - Assignments for the benefit of creditors

    - Corporate dissolutions

    - Administration of estates and decedents or incompetents

    - Tax liens

    - Actions seeking the return of property seized by levy


20. Approves in writing the making of jeopardy and termination assessments and levies made less than 30 days after notice and demand for payment. This authority may not be redelegated.

21. Approves on behalf of the Chief Counsel actions to be taken with respect to U.S. Tax Court subpoenas and disclosure of information in U.S. Tax Court litigation conducted under his/her jurisdiction.

22. Exercises exclusive jurisdiction over any case docketed in the Tax Court if:



    1. The sole issue or primary issue is a TEGE issue and if the notice of deficiency, liability, or other determination was issued by the Appeals Division after Appeals' consideration of all petitioned issues

    2. The notice of deficiency, liability, or final adverse determination letter was issued by the TEGE Operating Division and is based upon a ruling or technical advice in that case involving a qualification of an employee plan or tax exemption and/or foundation status of an organization (but only to the extent the case involves such issue)

    3. The case was docketed under IRC §§ 7428, 7476, or 7478, except as provided in paragraph 3 of Delegation Order 8-1 (IRM 1.2.47.2). Jurisdiction vests with Counsel at the time such cases are docketed with the court. See 26 CFR § 301.6020-1, 26 CFR § 301.6201-1, 26 CFR § 301.7701-9; [Treasury Department Order No. 150-10;](http://www.treasury.gov/about/role-of-treasury/orders-directives/Pages/to150-10.aspx) [General Counsel Order No. 4](http://intranet.treas.gov/General_Counsel/orders-dir/order4_1-19-01.pdf); and Delegation Order 8-1


23. Exercises jurisdiction over all docketed Tax Court cases if the notice of deficiency, liability, or other determination was issued by the TEGE Operating Division; or, if the notice of deficiency, liability, or other determination was issued by another Service Operating Division and if the sole issue or primary issue is a TEGE issue. Extends the settlement period or accepts jurisdiction of docketed Tax Court cases referred to the Appeals Division for settlement.

24. Disposes of Tax Court cases under the jurisdiction of the Division Counsel/Associate Chief Counsel (TEGE), referring, with recommendations, to the Chief Counsel cases which seem proper or as may be directed.

25. Determines what civil actions should be brought for recovery of erroneous refunds pertaining to matters under the jurisdiction of the Division Counsel/Associate Chief Counsel (TEGE) and authorizes the commencement of erroneous refund collection suits. Authorizes or sanctions counterclaims or third-party complaints with respect to refund suits pending in the district courts or the U.S. Court of Federal Claims if those suits involve matters under the jurisdiction of the Division Counsel/Associate Chief Counsel (TEGE) and performs necessary legal services on behalf of the Service as directed in connection with taxpayer suits for refund of taxes.

26. Partners with other Division Counsel to:



    - Request that Department of Justice commence any proceeding to enjoin promoters of abusive tax shelters, as authorized under IRC § 7408, and to advise and consult with the Department of Justice concerning the defense, settlement, concession, or appeal of such cases

    - Develop procedures and guidelines with the Commissioner's office for the assertion of civil penalties against promoters of abusive tax shelter under IRC § 6700

    - Develop procedures with the Commissioner's office and the Department of Justice for handling refund suits for the recovery of civil penalties by promoters under IRC § 6703


**30.3.2.4.6** **(07-21-2005)**

#### Division Counsel (Wage & Investment) (W&I)

1. The Wage and Investment legal function is headed by a Division Counsel (Wage & Investment), who reports to, and who is supervised by, the Deputy Chief Counsel (Operations). As depicted on the organizational chart in Exhibit 30.3.2-15, the Division Counsel (W&I) supervises a Senior Legal Counsel and a small staff of attorneys or other legal personnel.

2. The Division Counsel (W&I) partners with the Office of Division Counsel (Small Business/Self-Employed) to provide full service to both SB/SE and W&I functions and their taxpayers and other customers, providing W&I program direction and feedback for the annual performance evaluations of SB/SE Area Counsel based on delivery of service related to W&I cases and taxpayers. The Division Counsel (W&I) does not have dedicated attorneys and other legal staff to litigate cases with respect to W&I taxpayers or the collection of taxes.


**30.3.2.4.6.1** **(07-21-2005)**

##### Subject Matter Responsibility and Functions

1. The Division Counsel (W&I) serves as senior legal advisor and expert consultant to the Commissioner of Internal Revenue, Commissioner (W&I), other Division Commissioners, the Chief Counsel, and other top ranking Service and Treasury officials on the legal issues, regulations, and needs relevant to serving all wage earning or investing taxpayers who do not file Schedules C, E, F and/or Form 2106, representing these officials on sensitive and controversial legal matters related to these areas.

2. The Division Counsel (W&I) performs the following functions with respect to tax litigation matters:



1. Works closely with the Commissioner and Deputy Commissioner (W&I), in formulating short and long range program policies, strategies, and objectives for the Division to implement overall Service strategy and vision. Participates as an executive member of Commissioner (W&I) Planning Council. Participates in the design and development of integrated policies, programs, systems, and strategies that effectively provide superior customer service and ensure fairness and equity in enforcement of the Division's delivery of service and accountability to taxpayers.

2. Sets Division Counsel (W&I) business unit strategy and goals in alignment with overall organizational and research strategy. Establishes performance targets and business unit goals.

3. Provides program direction to the Division Counsel (SB/SE) relative to tax litigation and other legal services associated with W&I cases and taxpayers. Provides feedback to the Division Counsel (SB/SE) for the annual performance evaluations of SB/SE Area Counsel, based on continuing assessments of delivery of service related to W&I cases and taxpayers.

4. Allocates Division Counsel (W&I) resources as required and manages operating unit budget process and investment process.

5. Coordinates strategy and positions with appropriate officials throughout the W&I Division, other Division Counsel offices, and Associate Chief Counsel offices. Coordinates questions concerning litigation and/or settlement of issues and cases of W&I taxpayers.

6. Directs and oversees the overall management of the Division Counsel (W&I) staff. In this regard, provides continuing coordination, control, and direction of Division Counsel (W&I) operations to assure that Chief Counsel objectives, policies, procedures, and programs are implemented fully and effectively, including the development of programs and their evaluation in terms of effectiveness, efficiency, comprehensiveness, and timeliness.

7. Assures that Division Counsel (W&I) staff operates as an effective team, and that all functions are handled equitably and in a manner that is responsive to the needs of all programs that Division Counsel (W&I) supports. Assures sound position management policy and takes positive steps in support of all merit system principles.

8. Assures the full range of personnel activities are properly and timely addressed as necessary (i.e., recruitment, training, performance evaluation, disciplinary or adverse action, and management reporting), and performs all needful activities to effectively manage the organization and personnel within the Division Counsel (W&I) organization.


**30.3.2.5** **(07-21-2005)**

### Delegations of Authority to Chief Counsel Managers and Chief Counsel Employees

1. The authority to respond through appropriate channels to congressional inquiries directed at, or most germane to, their offices as directed by the Legislative Unit.

2. The authority to perform other duties as assigned from time to time by their superiors.


**30.3.2.5.1** **(11-19-2009)**

#### Jeopardy or Reprisal Exceptions Pertaining to Third Party Contacts

1. The authority to determine whether the jeopardy or reprisal exceptions apply has been delegated to all non-Chief Counsel employees who might make IRC § 7602(c) contacts and to the Chief Counsel by Delegation Order 25-12, Third Party Contact Jeopardy or Reprisal Determination (IRM 1.2.52.13).

2. The authority to determine for good cause shown that providing the taxpayer with general notice or notice of specific third party contacts would jeopardize collection of any tax or may involve reprisal against any person is delegated to all personnel in the Office of Chief Counsel required to make third party contacts subject to the requirements of IRC § 7602(c).


**30.3.2.6** **(06-07-2012)**

### Savings

1. Where not inconsistent with this chapter, other provisions of this manual (including Notices and Orders), or other instruction of the Chief Counsel, any authority heretofore delegated by the Chief Counsel to Chief Counsel subordinates that is not delegated under this chapter or other provision of this manual is delegated as was set forth in the following (which may be found at CCDM Notices and Orders):



   - CC Order O-30-2000-001 (May 31, 2000)

   - CC Orders O-30-2000-002 through 0-30-2000-007 (July 2, 2000)

   - CC Order O-30-2000-009 (October 8, 2000)

   - CC Order O-30-2000-012 through 0-30-2000-014 (October 8, 2000)

   - CC Order O-30-2000-017 (November 19, 2000)

   - CC Order O-30-2001-001 (March 12, 2001)

   - Notice CC-2001-032 (June 19, 2001)


**30.3.2.7** **(11-19-2009)**

### Direct Delegations from the Commissioner

1. Direct delegations of authority from the Commissioner to the Chief Counsel, Division Counsel, Associates Chief Counsel and Deputies Associate Chief Counsel can be found by subject matter in IRM 1.2.2, Delegations of Authority (in some cases these are further implemented by this CCDM section). Use caution when consulting IRM 1.2.2. While the section has been updated several times since the 1998 reorganization, the purpose of many of the updates was to add new organizational titles brought about by the Service's modernization. The delegations sometimes refer to, or are based upon, obsolete or changed provisions of law, regulation, or policy. At the time of this CCDM section's publication, all Commissioner Delegation Orders were under review for comprehensive revisions and renumbering. Delegation Orders that have been approved but not yet published in the IRM can be found at [http://www.irs.gov/foia/content/0,,id=132725,00.html](https://www.irs.gov/irm/part30/.http://www.irs.gov/foia/content/0,,id=132725,00.html).

2. Listed in _Exhibit 30.3.2-16_ are Commissioner Delegation Orders that name the Chief Counsel or other officials in the Office as delegates, or that have historically been regarded as making delegations to the Chief Counsel or other officials in the Office, sometimes even where primary comparable authority is delegated through the General Counsel.

3. That exhibit does not include delegations of authority to non-Counsel personnel that predicate the exercise of authority upon the review, advice, consultation, concurrence, or approval of the Chief Counsel or his subordinates, or that require the exercise of that authority to be based on the positions taken by the Chief Counsel or his or her subordinates.


**30.3.2.8** **(07-21-2005)**

### Delegations of Authority to the Commissioner and Other IRS Officials

1. This section delegates authority from the Chief Counsel to the Commissioner of Internal Revenue and other officials.


**30.3.2.8.1** **(02-07-2025)**

#### Certain Bankruptcy Matters

1. The Commissioner of the Internal Revenue is delegated the authority to directly refer matters to and authorize commencement of actions by the Department of Justice in the U.S. Bankruptcy Courts on the matters listed below in cases where the Service has filed a proof of claim for less than $1 million or has not filed a proof of claim:



1. Motions to dismiss or convert cases, except those involving organizations that claim an exemption from taxation under IRC § 501.

2. Motions on behalf of the Service based on debts in excess of the eligibility limits for a chapter 13 debtor.

3. Motions on behalf of the Service and objections to plans based on the debtor’s failure to file a tax return and responses to the debtor’s objections to estimated claims filed by the Service in cases where the debtor failed to file a tax return.

4. Responses to objections to Service claims that are based on the debtor’s claimed payment of tax, or claims that the debtor filed a return.

5. Responses to objections to Service claims that are based on valuation of the property securing the claim.

6. Responses to objections to Service claims that are based on the fact that the claim that has been superseded by a subsequent claim.

7. Motions for the debtor’s failure to make timely payments under a confirmed plan or accrual of post-confirmation liabilities.

8. Agreed cash collateral or adequate protection hearings, including stipulations or agreements for the use of the collateral.

9. Responses to the debtor’s motion to determine dischargeability of a tax, except when:


       i. the denial of discharge is premised on Bankruptcy Code section 523(a)(1)(C) concerning a liability for which the debtor made a fraudulent return or willfully attempted in any manner to evade or defeat such tax; or


       ii. the denial of discharge under Bankruptcy Code section 523(a)(1)(B) concerning a tax for which the debtor filed a return, or a document that purports to be a return, after the due date (including extensions).


2. See [General Counsel Order No. 4](http://intranet.treas.gov/General_Counsel/orders-dir/order4_1-19-01.pdf) , Delegation of Authority to the Assistant General Counsel —- Chief Counsel, Internal Revenue Service, [General Counsel Order No. 5](http://intranet.treas.gov/General_Counsel/orders-dir/order5_1-19-01.pdf), Delegation of Authority to Chief Counsel and Legal Counsel, and Delegation Order 25–9, Authority to Refer Matters to and Authorize Commencement of Actions by the Department of Justice in Certain Bankruptcy Matters.


**30.3.2.8.2** **(07-21-2005)**

#### Deciding Appeals to the Secretary of the Treasury in Director of Practice Cases

1. \[Reserved\]


**30.3.2.9** **(12-21-2010)**

### Field Management Matrix

1. The Field Management Matrix is an integrated management structure that balances geographic and functional needs at all levels, but does not change the existing Divisional lines of authority or supervisory chains of command. The Field Management Matrix focuses on office-wide issues of teamwork, resource allocation, and skill development. The matrix structure requires the selected managers to assume additional duties to support cross-Divisional coordination and communication.

2. The Field Management Matrix operates in three tiers:



   - Managing Counsel

   - Area Teams

   - Field Leadership Team


**30.3.2.9.1** **(12-21-2010)**

#### Managing Counsel

1. Managing Counsel are appointed in each of the 48 posts of duty to address issues that have an office-wide impact, such as the following:



   - Office functions

   - Office closings

   - Recruitment

   - Training

   - Local bar and taxpayer community contacts


2. Managing Counsel are appointed by the Chief Counsel following recommendation from the Area Teams and Field Leadership Team. Managing Counsel appointments are reviewed by the Area Team and Field Leadership Team every three years. Recommended changes, if any, are forwarded to the Chief Counsel for decision.


**30.3.2.9.2** **(07-27-2017)**

#### Area Teams

1. Area Teams interact with Managing Counsel, assume a leadership role that transcends existing Division management roles, ensure collaboration and cooperation across Divisions, maintain high levels of Service-wide client satisfaction, and foster an effective relationship with the National Treasury Employees Union (NTEU). The teams are comprised of appointed representatives from each business unit, within the following geographic areas:



   - Northeast — CT, MA, ME, NH, NY, RI, VT

   - Central — DC, DE, KY, MD, MI, NJ, OH, PA, WV

   - Southeast — AL, AR, FL, GA, MS, NC, SC, TN, VA

   - Midwest — IA, IL, IN, KS, MN, MO, ND, NE, SD, WI

   - Southwest — AZ, CO, LA, MT, NM, NV, OK, TX, UT, WY

   - West — AK, CA, HI, ID, OR, WA


2. Each Area Team has a **Team Leader** selected by the Chief Counsel from among the SES Area Counsel on the team, following recommendations from the Field Leadership Team. Team Leader appointments are reviewed every three years by the Field Leadership Team. Recommended changes, if any, are forwarded to the Chief Counsel for decision.

3. Team Leaders hold periodic conference calls, not less than quarterly, during which team members are provided with field leadership information and discuss issues of interest to the team.


**30.3.2.9.3** **(12-21-2010)**

#### Field Leadership Team

1. The Field Leadership Team has an enhanced role in policy decisions for the Office of Chief Counsel. The Field Leadership Team is led by the Deputy Chief Counsel (Operations) and consists of the following positions:



   - Division Counsel (Small Business/Self Employed)

   - Division Counsel (Large Business & International)

   - Division Counsel (Strategic Litigation)

   - Division Counsel/Associate Chief Counsel (Criminal Tax)

   - Division Counsel/Associate Chief Counsel (Tax Exempt and Government Entities)

   - Associate Chief Counsel (Finance and Management)

   - Associate Chief Counsel (General Legal Services)

   - Six Area Team Leaders


2. The Field Leadership Team holds monthly conference calls to consider issues of importance to the functioning of field offices, deciding on courses of action for addressing those issues.


**Exhibit 30.3.2-1**

### Chief Counsel Organization Chart

![This is an Image: 29599001.gif](https://www.irs.gov/pub/xml_bc/29599001.gif)

> Pictured is the organization chart for the Chief Counsel, shown reporting to the General Counsel of the Treasury, with a dotted line linking this organization to the Commissioner of Internal Revenue. Under the Chief Counsel are: Deputy Chief Counsel (Technical)Deputy Chief Counsel (Operations)Executive CounselCounselor to the CommissionerReporting to the Deputy Chief Counsel (Operations) are: Associate Chief Counsel (Finance and Management)Division Counsel (Wage and Investment)Division Counsel/Associate Chief Counsel (Criminal Tax)Associate Chief Counsel (General Legal Services)Division Counsel/Associate Chief Counsel (National Taxpayer Advocate Program)Division Counsel (Small Business/Self-Employed)Division Counsel (Tax Exempt and Government Entities)Associate Chief Counsel (Procedure and Administration)Division Counsel (Strategic Litigation)Division Counsel (Large Business and International)Reporting to the Deputy Chief Counsel (Technical) are: Associate Chief Counsel (Corporate)Associate Chief Counsel (Passthroughs and Special Industries)Associate Chief Counsel (Income Tax and Accounting)Associate Chief Counsel (Financial Institutions and Products)Associate Chief Counsel (International)Division Counsel/Associate Chief Counsel (Employee Benefits, Exempt Organizations, and Employment Taxes)The Equal Employment Opportunity program is depicted, with a dotted line linking this organization to both the Chief Counsel and the Associate Chief Counsel (Finance and Management).

[Please click here for the text description of the image.](https://www.irs.gov/media/157176 "")

**Exhibit 30.3.2-2**

### Division Counsel/Associate Chief Counsel (National Taxpayer Advocate Program) Organization Chart

![This is an Image: 29599002.gif](https://www.irs.gov/pub/xml_bc/29599002.gif)

> Pictured is the organization chart for the Division Counsel/Associate Chief Counsel (National Taxpayer Advocate), shown reporting to the Chief Counsel through the Deputy Chief Counsel (Technical) and the Deputy Chief Counsel (Operations). Also shown is a dotted line linking this organization to the National Taxpayer Advocate.

[Please click here for the text description of the image.](https://www.irs.gov/media/157181 "")

**Exhibit 30.3.2-3**

### Associate Chief Counsel (Corporate) Organization Chart

![This is an Image: 29599003.gif](https://www.irs.gov/pub/xml_bc/29599003.gif)

> Pictured is the organization chart for the Associate Chief Counsel (Corporate), shown reporting to the Chief Counsel through the Deputy Chief Counsel (Technical) and the Deputy Chief Counsel (Operations).Reporting to the Associate Chief Counsel (Corporate) are: Deputy Associate Chief Counsel (Corporate)Technical and Planning staffAdministrative staffSix branches

[Please click here for the text description of the image.](https://www.irs.gov/media/157186 "")

**Exhibit 30.3.2-4**

### Associate Chief Counsel (FM) Organization Chart

![This is an Image: 29599004.gif](https://www.irs.gov/pub/xml_bc/29599004.gif)

> Pictured is the organization chart for the Associate Chief Counsel (Finance and Management), shown reporting to the Chief Counsel through the Deputy Chief Counsel (Operations).1. Reporting to the Associate Chief Counsel (F&M) are: Deputy Associate Chief Counsel (F&M)Executive AssistantEqual Employment Opportunity, with a dotted line linking this organization to the Chief CounselLabor and Employee Relations DivisionLibrary DivisionHuman Resources DivisionPlanning and Management DivisionFinancial Management DivisionBusiness Systems ManagerFour Area Offices2. Reporting to the Library Division are: Digest BranchResearch Services BranchTechnical Services Branch3. Reporting to the Human Resources Division are: Executive Resources BoardStaffing, Classification, and Benefits BranchAttorney Recruiting and Retention ProgramPayroll and Processing BranchTraining and Communications Branch4. Reporting to the Planning and Management Division are: Management Analytics BranchSystems Coordination Branch5. Reporting to the Area Manager in Manhattan are Support Services offices in: BostonBuffaloCincinnatiClevelandDetroitHartford, CTLong Island, NYManhattanNewarkPhiladelphiaPittsburgh6. Reporting to the Area Manager in Atlanta are Support Services offices in: AtlantaBaltimoreBirminghamFt. LauderdaleGreensboroIndianapolisJacksonvilleLouisvilleMiamiNashvilleNew OrleansRichmondWashington, DC7. Reporting to the Area Manager in Dallas are Support Services offices in: AustinChicagoDallasDenverHoustonKansas CityMilwaukeeOklahoma CityOmahaSalt Lake CitySt. LouisSt. Paul8. Reporting to the Area Manager in San Francisco are Support Services offices in: HonoluluLaguna Niguel, CALas VegasLos AngelesPhoenixPortland, ORSacramentoSan DiegoSan FranciscoSan JoseSeattleThousand Oaks, CA

[Please click here for the text description of the image.](https://www.irs.gov/media/157191 "")

**Exhibit 30.3.2-5**

### Associate Chief Counsel (FIP) Organization Chart

![This is an Image: 29599016.gif](https://www.irs.gov/pub/xml_bc/29599016.gif)

> Pictured is the organization chart for the Associate Chief Counsel (Financial Institutions and Products), shown reporting to the Chief Counsel through the Deputy Chief Counsel (Technical).Reporting to the Associate Chief Counsel (Financial Institutions and Products) are: Deputy Associate Chief Counsel (Financial Institutions and Products) Technical and Planning StaffAdministrative StaffLitigation & Controversy Branch 1 (CC:FIP:B01)General Jurisdiction Branch 2 (CC:FIP:B02)General Jurisdiction Branch 3 (CC:FIP:B03)Insurance Branch 4 (CC:FIP:B04)Tax-Exempt Bonds Branch 5 (CC:FIP:B05)New Financial Products Branch 6 (CC:FIP:B06)

[Please click here for the text description of the image.](https://www.irs.gov/media/157196 "")

**Exhibit 30.3.2-6**

### Associate Chief Counsel (GLS) Organization Chart

![This is an Image: 29599006.gif](https://www.irs.gov/pub/xml_bc/29599006.gif)

> Pictured is the organization chart for the Associate Chief Counsel (General Legal Services), shown reporting to the Chief Counsel through the Deputy Chief Counsel (Technical) and the Deputy Chief Counsel (Operations). Reporting to the Associate Chief Counsel (General Legal Services) are: Two Deputy Associate Chief Counsel (General Legal Services)Public Contracts and Technology Law BranchClaims, Labor and Personnel Law BranchEthics and General Government Law BranchSix Area Counsels, located in Atlanta, Chicago, Dallas, Manhattan, San Francisco and Washington, DC.Reporting to the Area Counsel in San Francisco is the Los Angeles post of duty.

[Please click here for the text description of the image.](https://www.irs.gov/media/157201 "")

**Exhibit 30.3.2-7**

### Associate Chief Counsel (ITA) Organization Chart

![This is an Image: 29599018.gif](https://www.irs.gov/pub/xml_bc/29599018.gif)

> Pictured is the organization chart for the Associate Chief Counsel (Income Tax and Accounting), shown reporting to the Chief Counsel through the Deputy Chief Counsel (Technical).Reporting to the Associate Chief Counsel (Income Tax and Accounting) are: Deputy Associate Chief Counsel (Income Tax and Accounting)Administrative staffEight branches designated as: CC:ITA:B01, CC:ITA:B02, CC:ITA:B03, CC:ITA:B04, CC:ITA:B05, CC:ITA:B06, CC:ITA:B07, and CC:ITA:B08

[Please click here for the text description of the image.](https://www.irs.gov/media/157206 "")

**Exhibit 30.3.2-8**

### Associate Chief Counsel (International) Organization Chart

![This is an Image: 29599008.gif](https://www.irs.gov/pub/xml_bc/29599008.gif)

> Pictured is the organization chart for the Associate Chief Counsel (International), shown reporting to the Chief Counsel through the Deputy Chief Counsel (Technical) and the Deputy Chief Counsel (Operations).1. Reporting to the Associate Chief Counsel (International) are: Deputy Associate Chief Counsel (Strategic International Programs) Deputy Associate Chief Counsel (International Technical)Deputy Associate Chief Counsel (International Field Service and Litigation) Technical SupportAdministrative officeSpecial CounselsAdvance Pricing Agreement programSix branches2. Reporting to the Advance Pricing Agreement Program are four Branches.

[Please click here for the text description of the image.](https://www.irs.gov/media/157211 "")

**Exhibit 30.3.2-9**

### Associate Chief Counsel (PSI) Organization Chart

![This is an Image: 29599019.gif](https://www.irs.gov/pub/xml_bc/29599019.gif)

> Pictured is the organization chart for the Associate Chief Counsel (Passthroughs and Special Industries), shown reporting to the Chief Counsel through the Deputy Chief Counsel (Technical).Reporting to the Associate Chief Counsel (Passthroughs and Special Industries) are: Deputy Associate Chief Counsel (Passthroughs and Special Industries) Technical and Planning StaffAdministrative StaffPassthroughs Branch 1 (CC:PSI:B01)Passthroughs Branch 2 (CC:PSI:B02)Tax Shelters Branch 3 (CC:PSI:B03)Estate & Gift Tax Branch 4 (CC:PSI:B04)Incentive Provisions Branch 5 (CC:PSI:B05)Energy & Natural Resources Branch 6 (CC:PSI:B06)Excise Tax Branch 7 (CC:PSI:B07)

[Please click here for the text description of the image.](https://www.irs.gov/media/157216 "")

**Exhibit 30.3.2-10**

### Associate Chief Counsel (PA) Organization Chart

![This is an Image: 29599010.gif](https://www.irs.gov/pub/xml_bc/29599010.gif)

> Pictured is the organization chart for the Associate Chief Counsel (Procedure and Administration), shown reporting to the Chief Counsel through the Deputy Chief Counsel (Technical) and the Deputy Chief Counsel (Operations). 1. Reporting to the Associate Chief Counsel (P&A) are:Deputy Associate Chief Counsel (P&A)Assistant Chief Counsel (Administrative Provisions and Judicial Practice) Assistant Chief Counsel (Collection, Bankruptcy and Summonses)Assistant Chief Counsel (Disclosure and Privacy Law)Legal Processing Division2. Reporting to the Assistant Chief Counsel (APJP) are three Branches.3. Reporting to the Assistant Chief Counsel (CBS) are three Branches.4. Reporting to the Assistant Chief Counsel (DPL) are two Branches.5. Reporting to the Legal Processing Division are: Docket and Records SectionTechnical Services SectionPost Litigation UnitComm, Records and User Fee UnitDisclosure UnitRegulations UnitLegislative Unit

[Please click here for the text description of the image.](https://www.irs.gov/media/157221 "")

**Exhibit 30.3.2-11**

### Division Counsel/Associate Chief Counsel (CT) Organization Chart

![This is an Image: 29599011.gif](https://www.irs.gov/pub/xml_bc/29599011.gif)

> Pictured is the organization chart for the Division Counsel/Associate Chief Counsel (Criminal Tax), shown reporting to the Chief Counsel through the Deputy Chief Counsel (Technical) and the Deputy Chief Counsel (Operations). Also shown is a dotted line linking this organization to the Chief, Criminal Investigations.1. Reporting to the Division Counsel/Associate Chief Counsel (CT) are:Deputy Division Counsel/Deputy Associate Chief Counsel (CT)Senior Level CounselAssistant Chief Counsel National OfficeSpecial Counsels in Washington DC and Glynco, GASix Area Counsels2. Under Area Counsel 1 in Philadelphia are six posts of duty:BostonBuffaloHartfordLong IslandManhattanNewark3. Under Area Counsel 2 in Baltimore are six posts of duty:CincinnatiClevelandDetroitGreensboroLouisvilleRichmond4. Under Area Counsel 3 in Atlanta are four posts of duty:Ft. LauderdaleJacksonvilleMiamiNew Orleans5. Under Area Counsel 4 in Chicago are three posts of duty:IndianapolisSt. LouisSt. Paul6. Under Area Counsel 5 in Dallas are five posts of duty:AustinDenverHoustonLas VegasPhoenix7. Under Area Counsel 6 in Laguna Niguel are five posts of duty:Los AngelesSeattleSan DiegoSan FranciscoPortland

[Please click here for the text description of the image.](https://www.irs.gov/media/157226 "")

**Exhibit 30.3.2-12**

### Division Counsel (LMSB) Organization Chart

![This is an Image: 29599012.gif](https://www.irs.gov/pub/xml_bc/29599012.gif)

> Pictured is the organization chart for the Division Counsel (Large and Mid-Size Business), shown reporting to the Chief Counsel through the Deputy Chief Counsel (Technical) and the Deputy Chief Counsel (Operations). Also shown is a dotted line linking this organization to the Division Commissioner (LMSB).1. Reporting to the Division Counsel (LMSB) are:Deputy Division Counsel (Large and Mid-Size Business)Executive AssistantSenior Legal Counsel (Pre-filing and Technical Guidance)Senior Legal Counsel (Corporate Tax Shelters)Senior Legal Counsel (Research and Planning)Senior Legal Counsel (International)Five Area Counsels2. Reporting to the Area Counsel (Financial Services), located in Manhattan, are 11 Associate Area Counsel offices in six posts of duty:ManhattanLong IslandWashington, DCBostonHartford, CTBuffalo3. Reporting to the Area Counsel (Heavy Manufacturing and Transportation), located in Iselin, NJ, are 15 Associate Area Counsel offices in eight posts of duty:CincinnatiPhiladelphiaWashington, DCClevelandPittsburghDetroitNewarkRichmond4. Reporting to the Area Counsel (Retailers, Food, Pharmaceuticals, and Healthcare), located in Downers Grove, IL, are 15 Associate Area Counsel offices in 12 posts of duty:ChicagoAtlantaKansas CityWashington, DCGreensboroMilwaukeeJacksonvilleNashvilleMiamiFt. LauderdaleSt. PaulSt. Louis5. Reporting to the Area Counsel (Natural Resources and Construction), located in Houston, are 10 Associate Area Counsel offices in seven posts of duty:DallasWashington, DCOklahoma CityDenverHoustonAustinPhoenix6. Reporting to the Area Counsel (Communications, Technology and Media), located in Oakland, CA, are 15 Associate Area Counsel offices in eight posts of duty:San JoseLos AngelesPortland, ORSan DiegoSan FranciscoSeattleWashington DCLaguna Niguel

[Please click here for the text description of the image.](https://www.irs.gov/media/157231 "")

**Exhibit 30.3.2-13**

### Division Counsel (SBSE) Organization Chart

![This is an Image: 29599013.gif](https://www.irs.gov/pub/xml_bc/29599013.gif)

> Pictured is the organization chart for the Division Counsel (Small business/Self-Employed), shown reporting to the Chief Counsel through the Deputy Chief Counsel (Technical) and the Deputy Chief Counsel (Operations). Also shown is a dotted line linking this organization to the Division Counsel/Associate Chief Counsel (National Taxpayer Advocate), the Division Commissioner (SBSE), and the Division Counsel (Wage and Investment).1. Reporting to the Division Counsel (SBSE) are:Two Deputy Division Counsel (SBSE)Special CounselAssistant Division Counsel (General Litigation)Director HQ. OperationsAssistant Division Counsel (International)Assistant Division Counsel (Prefiling)Assistant Division Counsel (Tax Litigation)Administrative and Operations Staff supportNine Area Counsels and their Deputy Area Counsels2. Reporting to the Area Counsel located in Manhattan, are 11 Associate Area Counsel offices in six posts of duty:BostonBuffaloHartfordLong IslandManhattanNewark3. Reporting to the Area Counsel located in Philadelphia, are 10 Associate Area Counsel offices in six posts of duty:BaltimoreGreensboroPhiladelphiaPittsburghRichmondWashington, DC4. Reporting to the Area Counsel located in Jacksonville, are nine Associate Area Counsel offices in six posts of duty:AtlantaBirminghamFt. LauderdaleJacksonvilleMiamiNashville5. Reporting to the Area Counsel located in Chicago, are nine Associate Area Counsel offices in six posts of duty: ChicagoCincinnatiClevelandDetroitIndianapolisMilwaukee6. Reporting to the Area Counsel located in Denver, are seven Associate Area Counsel offices in four posts of duty: DenverLas VegasPhoenixSalt Lake City7. Reporting to the Area Counsel located in Dallas, are eight Associate Area Counsel offices in four posts of duty: AustinDallasHoustonNew Orleans8. Reporting to the Area Counsel located in San Francisco, are 10 Associate Area Counsel offices in six posts of duty: HonoluluPortland, ORSacramentoSan FranciscoSan JoseSeattle9. Reporting to the Area Counsel located in Los Angeles, are eleven Associate Area Counsel offices in four posts of duty: Los AngelesLaguna NiguelSan DiegoThousand Oaks10. Reporting to the Area Counsel located in Kansas City, are six Associate Area Counsel offices in six posts of duty: Kansas CityLouisvilleOklahoma CityOmahaSt. LouisSt. Paul

[Please click here for the text description of the image.](https://www.irs.gov/media/157236 "")

**Exhibit 30.3.2-14**

### Division Counsel (Strategic Litigation) Organization Chart

![This is an Image: 29599015.gif](https://www.irs.gov/pub/xml_bc/29599015.gif)

> Place holder, will add information from the Org chart

[Please click here for the text description of the image.](https://www.irs.gov/media/157246 "")

**Exhibit 30.3.2-15**

### Division Counsel/Associate Chief Counsel (TEGE) Organization Chart

![This is an Image: 29599017.gif](https://www.irs.gov/pub/xml_bc/29599017.gif)

> Pictured is the organization chart for the Division Counsel/Associate Chief Counsel (Tax Exempt and Government Entities), shown reporting to the Chief Counsel through the Deputy Chief Counsel (Technical). Also shown is a dotted line linking this organization to the Division Commissioner (TEGE). 1. Reporting to the Division Counsel/Associate Chief Counsel (TEGE) are: Three Deputy Division Counsel/Deputy Associate Chief CounselsTechnical and Planning staffAdministrative staff2. Reporting to the Deputy Division Counsel/Deputy Associate Chief Counsel (Employee Benefits) are four branches: Qualified Plans 1 (CC:TEGE:EB:QP1)Qualified Plans 2 (CC:TEGE:EB:QP2)Executive Compensation (CC:TEGE:EB:EC)Health and Welfare (CC:TEGE:EB:HW)3. Reporting to the Deputy Division Counsel/Deputy Associate Chief Counsel (Exempt Organizations/Employment Tax/Government Entities) are three branches: Exempt Organizations (CC:TEGE:EOEG:EO)Employment Tax 1 (CC:TEGE:EOEG:ET1)Employment Tax 2 (CC:TEGE:EOEG:ET2)4. Reporting to the Deputy Division Counsel/Deputy Associate Chief Counsel (Field Service) are six Area Counsels: Northeast (CC:TEGE:FS:NELI)Mid-Atlantic (CC:TEGE:FS:MABAL)Great Lakes (CC:TEGE:FS:GLCHI)Gulf Coast (CC:TEGE:FS:GCDAL)Mountain Area (CC:TEGE:FS:MSDEN)Pacific Coast (CC:TEGE:FS:PCLA), with a subordinate post of duty in Thousand Oaks, CA

[Please click here for the text description of the image.](https://www.irs.gov/media/157241 "")

**Exhibit 30.3.2-16**

### Division Counsel (WI) Organization Chart

![This is an Image: 29599015.gif](https://www.irs.gov/pub/xml_bc/29599015.gif)

> Pictured is the organization chart for the Division Counsel (Wage and Investment), shown reporting to the Chief Counsel through the Deputy Chief Counsel (Technical) and the Deputy Chief Counsel (Operations). Also shown is a dotted line linking this organization to the Division Commissioner (Wage and Investment).In addition, the organization chart for the Division Counsel (Small Business/Self-Employed) is pictured. This organization chart is described in Exhibit 30.3.2–13.

[Please click here for the text description of the image.](https://www.irs.gov/media/157246 "")

**Exhibit 30.3.2-17**

### Commissioner Delegation Orders which Delegate Authority to Chief Counsel

Listed below by subject matter are Commissioner Delegation Orders that name the Chief Counsel or other officials in the Office as delegates. The current D.O. number (and former D.O. number where applicable) are shown as well as the IRM section where the delegation order can be viewed. Delegation Orders that have been approved but not yet published in the IRM can be found at [http://www.irs.gov/foia/content/0,,id=132725,00.html](https://www.irs.gov/irm/part30/.http://www.irs.gov/foia/content/0,,id=132725,00.html).

| **Current Del. Order No.** | **Former Del. Order No.** | **Title of Commissioner Delegation Order** |
| --- | --- | --- |
| **_Organization, Finance and Management –_**IRM 1.2.40 |
| 1–3 | 19 (Rev. 17) | Payment to Employees for Relocation Expenses |
| 1–4 | 23 (Rev. 15) | Settlement of Tort Claims, Claims under the Small Claims Act, and Claims Made by an Employee of the Internal Revenue Service for Damage to or Loss of Personal Property Incident to Service |
| 1–5 | 25 (Rev. 20) | Reimbursement for Actual Expenses |
| 1–7 | 47 (Rev. 18) | To Authorize Attendance at Meetings at Government Expense |
| 1–8 | 48 (Rev. 15) | Foreign Travel |
| 1–10 | 74 (Rev. 5) | Travel of Personnel Detailed to the Internal Revenue Service |
| 1–15 | 110 (Rev. 9) | Waiving Claims Against Current or Former Employees for Erroneous Payments |
| 1–16 | 111 (Rev. 13) | Agency Collection Action |
| 1–22 | 189 (Rev. 6) | Authority to Authorize Travel Not at Government Expense |
| 1–30 | 95 (Rev. 14) | Approval of Travel Advances, Travel and Transportation Services, and Travel Vouchers |
| 1–31 |  | Authorization and Approval of Tour Renewal Agreement Travel |
| 1–32 |  | Emergency Transportation and Storage of Privately Owned Vehicles |
| 1–33 |  | Travel for Emergency Purposes |
| 1–35 (Rev. 1) |  | Authority to Approve Use of Non-Contract Air Carriers |
| 1–36 |  | Authority to Direct Official Travel by an Individual Employed Intermittently in the Government |
| 1–40 | 192 (Rev. 6) and<br> 243 (Rev. 1) | Approval of Non-Emergency and Emergency Common Carrier Purchases over $100 |
| 1–54 | 208 (Rev. 6) | Delegation of Authority in the Performance of Commercial Activities |
| **_The Examining Process –_**IRM 1.2.43 |
| 4–1 | 8 (Rev. 11) | Agreements as to Liability for Personal Holding Company Tax |
| 4–2 | 14 (Rev. 5) | Extension of Time for Filing Statement of Grounds |
| 4–5 | 35 (Rev. 15) | Agreements Treated as Determinations |
| 4–10 | 93 (Rev. 10) | Aggregations |
| 4–11 | 107 (Rev. 8) | Authority to Determine that Certain "Savings Institutions" Do Not Intend to Avoid Taxes by Paying Dividends or Interest for Periods Representing More than 12 Months |
| 4–15 | 136 (Rev. 6) | Authority to Sign Agreements Under Revenue Procedure 74-6 With Respect to Exercise by Trustee of Administrative and Investment Powers |
| 4–18 | 154 (Rev. 10) | Reports of Refunds and Credits to the Joint Committee on Taxation |
| **_The Rulings and Agreements Process –_**IRM 1.2.46 |
| 7–2 | 113 (Rev. 14) | Authority to Issue Exempt Organization Determination Letters |
| 7–4 | 139 (Rev. 7) | Authority to Extend the Correction Period and the Allowable Distribution Period Relating to Private Foundation Matters |
| **_The Appeals Process –_**IRM 1.2.47 |
| 8–1 | 60 (Rev. 7) | Appeals Functions. Settlement of Cases Docketed in the United States Tax Court |
| 8–3 | 97 (Rev. 34) | Closing Agreements Concerning Internal Revenue Tax Liability |
| 8–4 | 171 (Rev. 2) | Authority of Appeals Under 26 CFR 301.6511 and 26 CFR 301.6532 |
| 8–7 | 160 (Rev. 6) | Authority of Appeals in Termination Assessments of Income Tax and Jeopardy Assessments |
| 8–8 | 66 (Rev. 15) | Authority of Appeals in Protested and Tax Court Cases |
| **_Communications, Liaison and Disclosure Activities –_**IRM 1.2.49 |
| 11–1 | 89 (Rev. 10) | Administrative Control of Documents and Material |
| 11–2 | 156 (Rev. 17) | Authority to Permit Disclosure of Tax Information and to Permit Testimony or the Production of Documents |
| 11–4 | 165 (Rev. 8) | Responses to Administrative Appeals Filed Pursuant to the Freedom of Information Act (5 U.S.C. § 552) |
| **_Special Topic Activities –_**IRM 1.2.52 |
| 25–1 | 4 (Rev. 23) | Summonses, Oaths, Certifications, and Related Functions |
| 25–2 | 42 (Rev. 28) | Authority to Execute Agreements to Extend the Period of Limitations on Assessment or Collection and to Accept Form 900, _Tax Collection Waiver_ |
| 25–12 (Rev. 1) | 259 | Third Party Contact Jeopardy or Reprisal Determination |
| **_Chief Counsel Activities –_**IRM 1.2.53 |
| 30–1 (Rev. 2) | 30-1 (Rev. 1), 30-1, and 96 (Rev. 13) | Application of Rulings Without Retroactive Effect |
| 30–2 | 155 (Rev. 4) | Recommendation Letters to the Department of Justice Concerning Settlement Offers Covering Persons or Periods Not in Suit |
| 30–3 | 183 (Rev. 8) | Extension of Time for Making Certain Elections |
| 30–4 | 220 (Rev. 3) | Claims of Executive Privilege in Federal Courts |
| 30–5 | 190 (Rev. 4) | Transfer of Technical Functions to the Office of Chief Counsel |
| 30–6 | 231 (Rev. 4) | Abate Interest on Erroneous Refunds |
| _Status Indeterminate_ |
|  | 246 | Continuation of Authority under Existing Delegations and Conferral of Authority on Deputy Regional Counsel |
| _Revocations_ |
|  | 69 (Rev. 7) | ### Note:<br>**Revoked**.<br> Formerly "Designating Employees Who May Certify That Commercial Long-Distance Calls Were Necessary in the Interest of the Government" |

### Note:

The following delegation orders made delegations to Chief Counsel officials during the period when Chief Counsel had shared supervisory jurisdiction over Appeals and when the Commissioner reserved certain personnel authorities over technical personnel in the Office of Chief Counsel following the 1982 reorganization. As applied to Chief Counsel, these orders are no longer effective, but the Office now delegates comparable authority through the CCDM for personnel under its jurisdiction.

- D.O. 1–21, Authorization to Grant Case by Case Exemptions to the Financial Conflict of Interest Provision in 18 U.S.C. Subsection 208(a) , at IRM 1.2.40 (formerly D.O. 188 (Rev. 5))

- D.O. 1–2, Designation of Acting Supervisory Officials, at IRM 1.2.40 (formerly D.O. 12 (Rev. 14))

- D.O. 6–2, Authority to Administer Oaths Required by Law in Connection with Employment in the Federal Service, at IRM 1.2.45 (formerly D.O. 27 (Rev. 14))

- D.O. 6–11, Tours of Duty, at IRM 1.2.45 (formerly D.O. 39 (Rev. 19))

- D.O. 6–12, Absence and Charges to Leave, at IRM 1.2.45 (formerly D.O. 104 (Rev. 14))

- D.O. 6–4, Authorization to Engage in Outside Employment, Business, and Other Activities, at IRM 1.2.45 (formerly D.O. 105 (Rev. 10))

- D.O. 6–13, Certification of Time and Attendance, at IRM 1.2.45 (formerly D.O. 105 (Rev. 10))


See [Treas. Order Nos. 107-04 and 107-07](http://www.treasury.gov/about/role-of-treasury/orders-directives/Pages/default.aspx) (as to personnel and personnel-related authorities); IRC § 7803(b)(4); and [General Counsel Order Nos. 1, 4 and 10](http://intranet.treas.gov/General_Counsel/orders-dir/).

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part30/irm_30-003-002#addtoany "Show all")

A2A