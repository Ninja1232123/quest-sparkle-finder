---
url: "https://www.irs.gov/irm/part39/irm_39-003-001"
title: "39.3.1 Claims, Suits, and Related Matters | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part39/irm_39-003-001#main-content)

- 39.3.1  [Claims, Suits, and Related Matters](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912169318128)
  - 39.3.1.1  [Federal Tort Claims Act](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912169027264)
    - 39.3.1.1.1  [Action upon Receipt of Administrative Claims for Damages](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912169023024)
    - 39.3.1.1.2  [GLS Action upon Receipt of Claim](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912169017264)
    - 39.3.1.1.3  [Information Gathering](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912169115120)
    - 39.3.1.1.4  [Research on the Claim](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912169109680)
    - 39.3.1.1.5  [Recommendation Regarding Disposition of a Claim](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912169107216)
    - 39.3.1.1.6  [Referrals to the Department of Justice](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912169363536)
    - 39.3.1.1.7  [Letter to the Claimant Regarding Disposition of the Claim](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912169359312)
    - 39.3.1.1.8  [Preparation of Voucher](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912169355424)
    - 39.3.1.1.9  [Actions upon Claimant’s Request for Reconsideration](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912169350896)
    - 39.3.1.1.10  [Final Closing of Administrative Claim](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912169347824)
    - 39.3.1.1.11  [Litigation under the Federal Tort Claims Act](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912169346112)
  - 39.3.1.2  [Small Claims Act](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912169012544)
  - 39.3.1.3  [Suits for the Recovery of Monetary Damages Where the Federal Tort Claims Act Does Not Serve as the Sole Jurisdictional Basis](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912169007168)
    - 39.3.1.3.1  [Procedures to Maintain Confidentiality of Information and to Avoid Conflict of Interest](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912169000080)
    - 39.3.1.3.2  [Coordination with DOJ and Representation of Government Employees](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912168996048)
      - 39.3.1.3.2.1  [Defendants Other than Employees Sued in Their Individual Capacities](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912168987424)
    - 39.3.1.3.3  [Coordination within the Office of Chief Counsel](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912168984896)
    - 39.3.1.3.4  [Payment of Judgments](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912168979632)
  - 39.3.1.4  [Removal of Actions Brought in State Court](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912168976368)
    - 39.3.1.4.1  [Suits Cognizable Under the Federal Tort Claims Act](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912168974560)
    - 39.3.1.4.2  [Bivens-Type Suits](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912168971872)
    - 39.3.1.4.3  [Suits Charging Violations of State Criminal Laws](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912168969136)
    - 39.3.1.4.4  [General Procedures for Removal Actions](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912168964880)
  - 39.3.1.5  [Military Personnel and Civilian Employees’ Claims Act of 1964](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912168959088)
  - 39.3.1.6  [Legal Advice Regarding Federal Claims Collection Act As Amended](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912168950912)
  - 39.3.1.7  [Legal Memoranda Prepared on Questions Involving Potential Litigation](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912168946768)
  - 39.3.1.8  [Requests for Government Representation of Non-Government Defendants](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912168945008)
    - 39.3.1.8.1  [General Instructions](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912168941632)
    - 39.3.1.8.2  [Instructions to Attorneys](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912168931872)
  - Exhibit  39.3.1-1  [Letter of Eligibility to be Represented by Government Counsel](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912168924688)
  - Exhibit  39.3.1-2  [Letter to Non-Government Defendant](https://www.irs.gov/irm/part39/irm_39-003-001#idm139912168911216)

# Part 39. Chief Counsel Directives Manual General Legal Services

# Chapter 3. Claims and Suits

# Section 1. Claims, Suits, and Related Matters

* * *

## 39.3.1 Claims, Suits, and Related Matters

#### Manual Transmittal

April 11, 2022

#### Purpose

(1) This transmits revised CCDM 39.3.1 Claims and Suits; Claims, Suits, and Related Matters.

#### Background

This section is being revised to provide current policy and procedure concerning Claims, Suits, and Related Matters handled by the Office of Chief Counsel.

#### Material Changes

(1) CCDM 39.3.1.1 was revised to clarify referral procedures for claims filed under 26 U.S.C. § 7433. In addition, related subsections (39.1.1.1.1 - 39.3.1.1.11) were revised to reflect current procedures for processing claims filed under the Federal Tort Claims Act.

(2) CCDM 39.3.1.3.1 was revised to clarify procedures pertaining to disqualification decisions.

(3) Citations to relevant Delegation Orders, United States Code sections, and IRM sections were updated throughout.

(4) Minor typographical errors were corrected and editorial changes made throughout.

(5) Organizational titles and references were updated throughout.

(6) Exhibits 39.3.1-1 and 39.3.1-2 were revised to reflect current policy with respect to communicating with parties sued for damages in their individual capacities.

#### Effect on Other Documents

This section supersedes CCDM 39.3.1, dated June 3, 2009.

#### Audience

Chief Counsel

#### Effective Date

(04-11-2022)

Mark Kaizen

Associate Chief Counsel

(General Legal Services)

**39.3.1.1** **(04-11-2022)**

### Federal Tort Claims Act

1. This section concerns those situations where an administrative claim or suit has been filed for property damages and/or personal injury against the United States under circumstances where the Federal Tort Claims Act (FTCA), 28 U.S.C. §§ 2671-2680, is the exclusive mode of relief.

2. The legal aspects of these claims are the responsibility of the Associate Chief Counsel (GLS), Claims, Labor & Personnel Law (CLP) Branch. However, from time to time, Area Counsel (GLS) will be requested to obtain information or perform other legal services in some of these cases.

3. Claims filed under 26 U.S.C. § 7433 (Civil Damages for Certain Unauthorized Collection Activity) are sometimes filed on FTCA claims forms. Section 7433 claims are not handled by GLS and should be referred to the IRS Collection Advisory Group in accordance with Publication 4235.


**39.3.1.1.1** **(08-11-2004)**

#### Action upon Receipt of Administrative Claims for Damages

1. FTCA administrative claims filed with the Agency in any office are to be forwarded to the Claims Manager, CLP, under the procedures set forth in IRM 1.14.7.2.9. The Claims Manager has been delegated settlement authority up to $25,000 in relation to such claims under the FTCA. Upon receipt of such a claim, the Claims Manager determines whether a legal opinion is required to obtain a recommendation for the disposition of the claim.

2. Claims which do not need a legal opinion are claims that satisfy all of the criteria below. The Claims Manager prepares a memorandum recommending payment for such claims and forwards the memorandum to the Chief, CLP, for legal review.



1. The claim is for property damage and/or minor personal injury only.

2. There is no legal question regarding scope of employment or liability.

3. The appropriate amount of damages is subject to certainty.


3. Claims that do not satisfy the above criteria require a legal opinion which sets forth a recommendation regarding the claim. Such a claim is forwarded to the Chief, CLP. The claim is then assigned to an attorney or paralegal for preparation of the law and fact memorandum.

4. Any additional information received by the Claims Manager pursuant to an assigned claim will be associated with that claim.


**39.3.1.1.2** **(04-11-2022)**

#### GLS Action upon Receipt of Claim

1. The claim and all accompanying materials must be examined to determine if a properly executed and completed claim has been filed. The claim must contain the following required information:



   - A written explanation of the claim with enough detail to allow the agency to investigate the allegation(s).

   - A stated sum certain (total dollar amount being sought).

   - The signature of the claimant or an authorized representative.


2. The claim must be filed within the two year statute of limitations commencing on the occurrence of the alleged wrongful act or event.


**39.3.1.1.3** **(08-11-2004)**

#### Information Gathering

1. If information which has not been supplied is necessary to adjudicate the claim, GLS should prepare a letter requesting that such information be expeditiously submitted. If the requested information has not been received within a reasonable length of time, a second letter should follow. Such letters should be sent by certified mail, return receipt requested.

2. Evidence and information regarding proof of damages must be supplied in accordance with the provisions of 28 C.F.R. § 14.4.

3. The following documentation is necessary for property claims:



   - Standard Form 91, Motor Vehicle Accident Report (where applicable)

   - Standard Form 92-A, Report of Accident Other Than Motor Vehicle (where applicable)

   - Statements and relevant documents bearing on the employee’s scope of employment if other than a motor vehicle accident


4. If the claim is for personal injury and/or property damage, then in addition to the appropriate forms set forth above, a formal investigation by TIGTA may be requested by the assigned attorney or paralegal through the Claims Manager. The employee involved in the underlying FTCA claim may also be contacted directly for additional information.


**39.3.1.1.4** **(08-11-2004)**

#### Research on the Claim

1. Once the claim has been perfected, the facts and the legal issues raised by those facts must be analyzed by the assigned attorney or paralegal or, as appropriate, by the Claims Manager.

2. In determining whether the United States is liable under the FTCA, an examination of the laws of the state where the act occurred is typically required. State law examination includes the statutes and court decisions as to the issues of negligence and scope of employment.


**39.3.1.1.5** **(08-11-2004)**

#### Recommendation Regarding Disposition of a Claim

1. For claims which require a legal opinion (see _CCDM 39.3.1.1.1(3)_), a law and fact memorandum is prepared by the assigned attorney or paralegal, reviewed by the Chief, CLP for legal sufficiency and sent to the Claims Manager recommending an impartial disposition of the claim. This memorandum should give a concise analysis of:



   - All pertinent facts surrounding the case

   - The legal issues presented by the facts

   - The relevant law of the state involved and any relevant federal statutory provisions

   - Conclusions and recommendations on the claim


2. For claims which do not require a legal opinion (see _CCDM 39.3.1.1.1(2)_), the Claims Manager prepares a memorandum regarding payment of the claim. Claims are subject to legal review. Memoranda regarding such claims prepared by the Claims Manager must be approved by the Chief, CLP.


**39.3.1.1.6** **(04-11-2022)**

#### Referrals to the Department of Justice

1. Any proposed award, compromise, or settlement of an administrative claim in excess of $25,000 requires prior written approval of the Attorney General or designee. See 28 U.S.C § 2672. In addition, any administrative claim, which in the opinion of the agency involves a new precedent or a new point of law, a question of policy, a question of whether the United States is or may be entitled to indemnity or contribution, or which may control the disposition of a related claim, requires prior consultation with the Department of Justice (DOJ) as indicated above. Any proposed award, compromise, or settlement requiring approval or consultation with the DOJ under the provisions of 28 C.F.R. §14.6 must be reviewed by the Treasury General Counsel’s Office prior to referral to the Attorney General, and notification of the proposed award, compromise, or settlement should be provided to the Deputy Chief Counsel (Operations).

2. If the claim requires the referral to, approval of or consultation with the Attorney General, a memorandum of law and fact will be prepared by the assigned attorney or paralegal and submitted to the Claims Manager for written approval. Additionally, a letter transmitting the matter to the Treasury General Counsel’s Office will be prepared for the signature of the Associate Chief Counsel, GLS. If the claim is approved by the Treasury General Counsel’s Office the matter will be transmitted to the Assistant Attorney General, Civil Division, DOJ, by the General Counsel of the Treasury Department.


**39.3.1.1.7** **(08-11-2004)**

#### Letter to the Claimant Regarding Disposition of the Claim

1. A letter to the claimant is prepared and signed by the Claims Manager. The letter is addressed to the claimant or authorized representative and, if the claim is allowed in full, the letter is sent by regular mail. All letters will briefly identify the circumstances out of which the claim arose and the amount claimed. They will also incorporate the proposed action set forth in the legal memorandum.

2. If the claimant is offered an amount that is smaller than that claimed, then a general statement of why such an amount is offered may be set forth. If a lesser amount is offered or if the claim is totally denied, then a paragraph must be inserted in the letter which informs the claimant of the right to file suit within the six-month statutory time limitation and such letter must be sent by certified mail, return receipt requested. An example of such a notice is as follows: "In the event you are dissatisfied with this action, you may file suit in an appropriate United States District Court no later than six months after the date of mailing of this notification." 28 U.S.C. § 2401(b).


**39.3.1.1.8** **(04-11-2022)**

#### Preparation of Voucher

1. In those cases in which a claim is being allowed in full or an offer of settlement is being made, the Claims Manager will prepare a Voucher For Payment Under the Federal Tort Claims Act. Payment will be made upon receipt of the signed voucher.

2. The voucher will be made payable to the claimant unless the claimant is represented by counsel. If the claimant is represented by counsel, the voucher shall designate both the claimant and counsel and be mailed to the address of counsel.

3. In those cases concerning property damage in which there is a deductible, the deductible will be paid only to the claimant upon receipt of a claim for the deductible. The insurance carrier will only be paid the non-deductible portion of the claim unless the insured states in writing that he or she authorizes the insurer to file a claim for the deductible on his or her behalf.

4. Upon receipt of a signed voucher in the amount of $2,500.00 or less, the Claims Manager will forward the voucher to the IRS CFO, Administrative Financial Management/Accounts Payable and Miscellaneous Programs, Beckley Finance Center, for payment.

5. When the amount of the award is more than $2,500.00, the Claims Manager will forward the signed voucher to the Judgment Fund Section, Bureau of Fiscal Services, for payment.


**39.3.1.1.9** **(08-11-2004)**

#### Actions upon Claimant’s Request for Reconsideration

1. If a claimant submits a claim for reconsideration under the provisions set forth in 28 C.F.R. § 14.9(b), prior to initiating suit or the expiration of the six-month period for filing suit, the claim is forwarded by the Claims Manager to the Chief, CLP. The claim is examined to see if additional facts or evidence warrant further consideration.

2. A formal memorandum on the claim will be prepared by the assigned attorney or paralegal only if, in consultation with the Chief, CLP, it is determined new or intervening evidence has been submitted which will alter the original recommendation.


**39.3.1.1.10** **(08-11-2004)**

#### Final Closing of Administrative Claim

1. Once the Claims Manager takes final action on an administrative claim, the case is closed.


**39.3.1.1.11** **(04-11-2022)**

#### Litigation under the Federal Tort Claims Act

1. Suits brought under the FTCA will generally be referred to the Associate Chief Counsel (GLS) for coordination with DOJ and for preparation of a litigation report. FTCA suits where no administrative claim was filed may be referred to the appropriate Area Counsel’s Office

2. When the suit is brought against the United States and/or its employees in a state court, immediate action will be initiated by the assigned attorney or paralegal to have the appropriate U.S. Attorney remove the suit to federal district court. See CCDM 39.3.1.4. In suits in which an individual employee is named as a defendant, the U.S. Attorney may request that the employee involved request and obtain representation by the United States. If a representation request is required, the assigned GLS attorney will contact the named Government employee to obtain the documentation necessary for the representation request. Issues regarding attorney/client privilege and representation requests are addressed below in _Section 39.3.1.3.1_ and _39.3.1.3.2IRM 39.3.1.3.2_.

3. Where the named employee is the Commissioner or the Chief Counsel, a representation request will generally not be required. However, where the assigned GLS office believes that one is necessary, the decision to initiate any such request should be raised and coordinated in advance with the Associate Chief Counsel (GLS).

4. After all available factual information pertaining to the suit in question has been obtained, a litigation report will be prepared in CLP Branch/Associate Area Counsel, Associate Chief Counsel (GLS), and will be submitted to the official designated in the DOJ letter to receive the report.


**39.3.1.2** **(04-11-2022)**

### Small Claims Act

1. The Small Claims Act, 31 U.S.C. § 3723, allows the heads of federal agencies (or their designees) to adjust and settle claims of $1,000 of less for damage to or loss of privately owned property caused by the negligence of an officer or employee of the Government acting within the scope of his or her employment, that would otherwise be barred under the Federal Tort Claims. Claims filed under the Small Claims Act are administered under the same processes that apply for claims filed under the Federal Tort Claims Act. See _CCDM 39.3.1.1_.

2. The legal aspects of these claims are the responsibility of the Associate Chief Counsel (GLS), CLP. However, from time to time, Area Counsel (GLS) will be requested to obtain information or perform other legal services in some of these cases.

3. The Claims Manager prepares and signs a letter to the claimant notifying him or her of the disposition of the claim and of the fact that there are no appeal rights under the Small Claims Act.

4. Pursuant to Delegation Order 1-4 (Rev. 1) IRM 1.2.2.2.4, the Claims Manager does not have the authority under the Small Claims Act to consider, ascertain, adjust, or determine claims for bank charges as provided in Policy Statement 5-39 (IRM 1.2.1.6.11). See Policy Statement 5-39, IRM 1.2.2.2.4(5)-(15), IRM 21.5.7.4.4.4, and Form 8546 for such delegations of authority and claim submission instructions.


**39.3.1.3** **(06-03-2009)**

### Suits for the Recovery of Monetary Damages Where the Federal Tort Claims Act Does Not Serve as the Sole Jurisdictional Basis

1. The Associate Chief Counsel (GLS) has been delegated the responsibility for coordinating with DOJ the defense of civil actions for monetary damages brought against the United States, the Agency itself, and/or individually named employees for alleged actions taken by employees in the performance of their official duties. For instance, such suits may be brought for alleged violations of constitutional rights, i.e., _Bivens_-type actions and alleged violations of civil rights protected by statute. In some of these cases, the plaintiff will seek monetary damages as well as injunctive or other relief concerning a real or imagined tax problem. If the principal issue in such cases is damages under the FTCA or against an employee in an individual capacity, the Associate Chief Counsel (GLS) will handle the matter and coordinate the case as appropriate, e.g., with the Office of the Associate Chief Counsel, Procedure & Administration (P&A) in significant cases or those involving novel issues, or with the appropriate Associate/Division Counsel office in other cases. See _CCDM 39.3.1.3.3_.

2. Area Counsel has been delegated the authority to prepare litigation reports to coordinate this type of case with DOJ except in cases where the plaintiff has filed an administrative claim under the Federal Tort Claims Act. In that situation, the attorney or paralegal assigned to the administrative FTCA claim will provide DOJ with litigation support. CLP may provide litigation support to DOJ in the following situations:



1. The actions complained of occurred in more than one Area Counsel geographical region or the employees named as defendants have posts of duty in more than one Area Counsel geographical region.

2. An Area Counsel office is disqualified because of a potential conflict of interest.


3. Once a decision has been made to request representation from DOJ, the proper Division of DOJ should be notified. The GLS attorney should advise the trial attorney assigned to the case of the suit and inform the Assistant U.S. Attorney that representation for the employee or former employee has been or will be requested by the Agency. Issues regarding attorney/client privilege are addressed below in _Section 39.3.1.3.1_ and _39.3.1.3.2_.


**39.3.1.3.1** **(08-11-2004)**

#### Procedures to Maintain Confidentiality of Information and to Avoid Conflict of Interest

1. The attorney-client relationship between employee-defendants and Chief Counsel attorneys assigned to these types of cases will be governed by the Attorney General’s Representation Guidelines set forth in 28 C.F.R. §§ 50.15 and 50.16.

2. Because both CLP and the Area Counsel offices also handle personnel actions, there may be times when it would be appropriate for an office to disqualify itself from either a personnel matter or a civil litigation matter in which the employee is named as a defendant. Any cases presenting such potential conflicts should be elevated to the Associate Chief Counsel (GLS) through the Chief, CLP, for a determination as to whether the case should be reassigned or other next steps, as appropriate.

3. Isolation of Files and Information. When the Branch or Area Counsel Offices have been involved in providing or determining whether representation should be provided in a civil action against an employee and a personnel action arises involving the same employee out of the same facts and circumstances, then all possible efforts (including the isolation of files) must be taken to ensure that materials and information relating to the civil action are not available to other GLS attorneys involved in the personnel action. GLS attorneys will share pertinent portions of the case files with attorneys in other Chief Counsel functions as necessary when litigation involves issues within the jurisdiction of those functions.


**39.3.1.3.2** **(06-03-2009)**

#### Coordination with DOJ and Representation of Government Employees

1. Defense of actions involving claims against the United States before federal and state courts will, in most instances, be undertaken by DOJ.

2. Upon receipt of a complaint, GLS should confirm that DOJ is aware of the complaint.

3. If an individual employee receives a request for a waiver of service of summons, the GLS attorney assigned to the case should contact DOJ to discuss whether the waiver should be signed.

4. If, after being informed of the role of the Office of Chief Counsel attorney in the case and the attorney’s relationship with the employee-defendant, the employee elects to request representation by Government counsel, the GLS attorney shall send the employee a Letter of Eligibility to be Represented by Government Counsel (_See Exhibit 39.3.1-1_) and a Form DOJ-399, Acknowledgment of Conditions of Department Representation.

5. A copy of the signed Letter of Eligibility and the original of the Form DOJ-399 will be sent to DOJ with a letter containing a summary of available factual information, GLS’s findings as to whether the employee was acting within the scope of his or her employment, and GLS’s recommendation for or against providing representation.

6. Information obtained by the GLS attorney concerning the complaint shall be covered by the attorney/client privilege whether or not representation is terminated or the office recommends that DOJ not represent the employee.

7. The GLS attorney should explain to the employee that any representation afforded to employees in these cases is based upon the fact that since Agency employees are involved the Agency has an interest in the outcome of the litigation, but if protecting the interest of an individual conflicts with the obligation of protecting the interest of the Agency, it will be necessary for the attorney to disqualify himself/herself.

8. GLS will furnish DOJ a litigation report for the defense of the Government’s or employee-defendant’s conduct.

9. The GLS attorney will render whatever assistance is necessary by promptly securing further documentation as requested by DOJ. The attorney will stay in regular contact with the DOJ concerning updates in the status of the case, including requesting to receive copies of pleadings and correspondence, and must obtain a status report on the case from DOJ every 60 days. Matters concerning representation of federal employees by private counsel at federal expense are controlled by 28 C.F.R. § 50.16.


**39.3.1.3.2.1** **(06-03-2009)**

##### Defendants Other than Employees Sued in Their Individual Capacities

1. As previously noted, plaintiffs in this type of litigation often name the United States, the Treasury Department, the Service, the Secretary of the Treasury, or the Commissioner in their official capacity as the defendant or as one of many defendants.

2. Where the litigating DOJ attorney agrees that the suit is against the employees in their official capacities only, neither scope of employment facts nor requests for representation are necessary with respect to any of these defendants. Every effort should be made to avoid having the Secretary or the Commissioner execute an affidavit.


**39.3.1.3.3** **(06-03-2009)**

#### Coordination within the Office of Chief Counsel

1. In various cases a plaintiff will seek monetary damages under I.R.C. § 7433 or injunctive or other relief concerning a real or imagined tax problem in addition to seeking damages under the FTCA or from individual employees. The jurisdiction of the Associate Chief Counsel (GLS) and Associate Chief Counsel (P&A) overlap in these cases. If the principal issue in such cases is damages under the FTCA or from individual employees, the Associate Chief Counsel (GLS) will handle the matter and coordinate with the Associate Chief Counsel (P&A). On the other hand, if the principal issue in such cases is injunctive or other relief concerning a tax problem, the matter will be handled by the appropriate Associate Area Counsel (SBSE) and coordinated with the Associate Chief Counsel (GLS). The determination as to what the principal issue is in these cases must be made on a case-by-case basis. These suits will be fully coordinated among the appropriate offices. In other FTCA and _Bivens_ claims cases where there is a novel issue or the matter is deemed significant for other reasons, the Associate Chief Counsel (GLS) will coordinate with the appropriate Chief Counsel office.

2. If disclosure of tax information is involved, the GLS attorney assigned to the case is responsible for ensuring that appropriate coordination takes place with the Associate Chief Counsel (P&A). Further, Section 7431 cases often contain Privacy Act (5 U.S.C. § 552a) counts that require coordination with P&A.


**39.3.1.3.4** **(08-11-2004)**

#### Payment of Judgments

1. The Federal Tort Claims Act contains specific authorization for the payment of judgments. _See_ 28 U.S.C. § 2414, 2672.

2. I.R.C. § 7423 authorizes reimbursement of an employee for damages and costs recovered against the employee for acts done in the due performance of the employee’s official duty. Although reimbursement is discretionary, and the issue rarely arises, the Commissioner has authorized reimbursement of a judgement rendered against an employee who was acting within the scope of the employee’s official duties.


**39.3.1.4** **(08-11-2004)**

### Removal of Actions Brought in State Court

1. In exercising its delegated authority, GLS will encounter several types of cases in which the removal of a proceeding from a state court to a federal district court is necessary or desirable. This section describes the procedures for use in the following types of cases.


**39.3.1.4.1** **(08-11-2004)**

#### Suits Cognizable Under the Federal Tort Claims Act

1. The type of case most frequently encountered involves employees who are sued individually in state court for damages, usually arising from automobile accidents, where the employee was acting within the scope of employment. Since such a case is cognizable under the FTCA and the exclusive remedy is against the United States, the assigned GLS attorney or paralegal shall prepare a letter to the appropriate U.S. Attorney requesting removal to a federal district court and substitution of the United States as the defendant.

2. In instances where the plaintiff has not exhausted his administrative remedies, the assigned GLS attorney or paralegal has the responsibility for assisting the DOJ in arranging for dismissal of the case upon removal.


**39.3.1.4.2** **(08-11-2004)**

#### Bivens-Type Suits

1. Suits for damages brought in state courts against federal employees or the United States and its agencies where the employee named as the defendant was acting within the scope of his authority, commonly called _Bivens_-type suits, may be removed to a federal district court pursuant to 28 U.S.C. §1442. The assigned attorney or paralegal shall request that the U.S. Attorney obtain such removal.


**39.3.1.4.3** **(08-11-2004)**

#### Suits Charging Violations of State Criminal Laws

1. Suits brought in a state court charging a federal employee with a state criminal violation as a result of acts taken under color of office may, under appropriate circumstances, be removed to federal district court pursuant to 28 U.S.C. §1442.

2. The removal of these actions is an extremely sensitive area and caution should be exercised in recommending such removals to DOJ. Before making a recommendation for the removal of a case of this type, the GLS attorney should thoroughly research the law in this area and closely analyze the facts to be sure that the matter falls within decided opinions and the interest of the Government will be protected by such action.

3. In determining whether such a recommendation to DOJ should be made, the attorney must be cognizant of the time limits prescribed in 28 U.S.C. §1455(b) for filing a petition for removal of a criminal prosecution.

4. In non-routine cases, GLS attorneys shall consult with the Associate Chief Counsel (GLS) or either Deputy Associate Chief Counsel (GLS) prior to recommending the removal of such a case.


**39.3.1.4.4** **(08-11-2004)**

#### General Procedures for Removal Actions

1. The removal of a case should be coordinated by the assigned attorney or paralegal directly with the appropriate Office of the U.S. Attorney.

2. In all removal cases where an employee is individually named as a defendant, the GLS attorney should assist that employee in making a request for representation as required by DOJ. See _CCDM 39.3.1.3.2_.

3. The attorney should be cognizant of the time limits prescribed for removal of the particular type of action as prescribed by:



   - 28 U.S.C. § 1446 for Bivens-type actions

   - 28 U.S.C. § 2679(d) for actions under the FTCA

   - 28 U.S.C. § 1455 for criminal prosecutions


4. The attorney or paralegal assigned to the matter is responsible for promptly furnishing DOJ and/or the U.S. Attorney with all available data upon which a removal action can be based.

5. Once the petition or certification has been properly filed in the appropriate federal court, the matter should generally be removed without further action on the part of the DOJ and/or the U.S. Attorney. There is no requirement for a hearing.


**39.3.1.5** **(06-03-2009)**

### Military Personnel and Civilian Employees’ Claims Act of 1964

1. The Military Personnel and Civilian Employees’ Claims Act of 1964 (MPCECA), 31 U.S.C. § 3721, authorizes the heads of federal agencies, or their designees, to settle and pay the claim of an officer or employee of the agency for damage to, or loss of, personal property incident to the service of the officer or employee. Treasury regulations implementing this Act may be found at TD P 32-13. Commissioner Delegation Order 1-4 (formerly D.O. 23 (Rev. 15) IRM 1.2.2.2.4, has delegated to the Claims Manager, CLP, the authority to settle and pay employees’ personal property claims.

2. The Associate Chief Counsel (GLS), CLP, performs the legal work of the office relating to the MPCECA. The Claims Manager handles MPCECA claims but may request legal advice on a claim, and if so, the GLS attorney will prepare a memorandum which will include:



1. The facts surrounding the claim and legal issues upon which the claim was originally referred;

2. The legal issues upon which the claim was presented along with any additional issues;

3. The essential facts upon which approval or disapproval of the claim may turn;

4. The law as provided for by relevant statutory and regulatory provisions; and

5. The conclusions and recommendations regarding the claim.


3. Legal review of claims over $500 is required. The GLS attorney reviewing the claim should complete section 12 of the form found at TD P 32-13.1.

4. The Claims Manager will prepare a letter to the claimant either approving the claim in full or in part, or, if disapproving it, briefly setting forth the reasons why it has been disapproved.

5. If a claimant whose claim is denied in whole or in part appeals the Claims Manager’s decision, the Deputy Associate Chief Counsel (GLS) will review the claim. The attorney who reviewed the initial claim will prepare a memorandum for the Deputy’s signature and recommended action, as well as a memorandum outlining the relevant facts and law.

6. The claimant will be notified of the outcome of the appeal by letter under the signature of the Deputy Associate Chief Counsel (GLS).


**39.3.1.6** **(08-11-2004)**

### Legal Advice Regarding Federal Claims Collection Act As Amended

1. The Federal Claims Collection Act, as amended, 31 U.S.C. §§ 3701, 3711, et seq., provides for the collection, compromise, termination, suspension, and referral to DOJ of non-tax and non-interagency debts owed to the United States.

2. Commissioner Delegation Order No. 1-16 (formerly DO-111, Rev. 13), IRM 1.2.2.2.14, provides authorization to various IRS functions, including the Claims Manager, GLS, to collect claims and to compromise, terminate, or suspend claims collection activity, and requires the advice of Counsel when the claims reach certain dollar thresholds.

3. The Associate Chief Counsel (GLS) has been delegated the responsibility to supervise, coordinate, and perform the legal work of the office for claims or suits brought under the Federal Claims Collection Act, as amended. Area Counsel and the CLP Branch provide the legal advice and litigation support in such matters as provided in Delegation Order 1-16.

4. Advice on claims collection matters should conform with Title 31 C.F.R. Part 900 which provides guidance on claims collection matters including compromise, suspension, and termination of claims collection as well as referral of claims collection matters to DOJ.


**39.3.1.7** **(08-11-2004)**

### Legal Memoranda Prepared on Questions Involving Potential Litigation

1. All GLS attorneys shall open their legal opinions on subjects where litigation can reasonably be anticipated with a statement that the advice and recommendations contained therein are provided in anticipation of litigation.


**39.3.1.8** **(04-11-2022)**

### Requests for Government Representation of Non-Government Defendants

1. DOJ will, under some circumstances, provide representation to non-Government defendants. Representation has been provided to spouses of Agency employees named as defendants in damage suits against employees arising from the performance of their duties. Informants and other non-Government defendants have been afforded representation where it has been shown that they acted under the direction and control of the Agency. Absent compelling circumstances, DOJ will not provide representation to independent contractors or others who do business with the Service.

2. This section does not apply to former employees sued for actions undertaken while they were IRS employees. Such persons are treated as employees for representation purposes.

3. Situations in which DOJ provides representation to non-Government defendants are rare, and any such cases should be coordinated with the Deputy Associate Chief Counsel, Labor and Employment (GLS) and the Chief, CLP as appropriate.


**39.3.1.8.1** **(08-11-2004)**

#### General Instructions

1. A non-Government defendant served with process who desires representation by Government counsel should immediately contact GLS.

2. The attorney who receives notification of the suit from the non-Government defendant and a request for Government representation will immediately advise the non-Government defendant of the information contained in paragraphs (3) through (8).

3. Whether legal representation will be afforded to a non-Government defendant is a discretionary matter to be determined by DOJ.

4. The Government is also the client of the attorney who is providing representation to the non-Government defendant sued individually, thereby creating a potential conflict of interest. Whenever the interest of the defendant diverges from that of the United States, as when the defendant confides information to the attorney which tends to show that the defendant has committed a crime, representation of the defendant by Government counsel will cease. In such event, subject to the limitations specifically set forth below, confidential communications concerning the subject matter of the suit in the possession of the Government attorney will not be told or given to anyone without the written permission of the non-Government defendant.

5. Confidential communications given to the GLS attorney during the representation process which relate to the case will be protected by the attorney/client privilege in the same manner that such communications to a private sector attorney would be protected.

6. If DOJ furnishes the non-Government defendant representation, the assigned GLS attorney may furnish factual material, legal defenses, recommendations, and assistance to DOJ as requested.

7. GLS attorneys cannot provide legal assistance to non-Government defendants with respect to an investigation for criminal activity related to the litigation.

8. Legal assistance provided by the assigned GLS attorney will be stopped if:



1. The non-Government defendant fails to faithfully provide all the information he/she has regarding the case.

2. A determination is made that the defendant’s actions for which he is being sued were criminal.

3. The non-Government defendant becomes the target of a criminal investigation.

4. The non-Government defendant is indicted as a result of the actions for which he is being sued.

5. It is determined that the interest of the non-Government defendant does not coincide with the interest of the United States.


9. If, after having the conditions above explained, a non-Government defendant wishes to request representation by Government attorneys, he shall sign the letter sent to him informing him of his possible eligibility to be represented by Government counsel.


**39.3.1.8.2** **(06-03-2009)**

#### Instructions to Attorneys

1. Once a non-Government defendant has been sued and has requested representation, the attorney assigned to the case will immediately send the non-Government defendant a copy of this section and a letter informing the defendant of his possible eligibility to be represented by Government counsel. _See Exhibit 39.3.1-2._

2. All communications concerning the complaint that are obtained by the attorney assigned to the case will be treated as confidential as previously explained in this section.

3. The GLS attorney assigned to the case shall prepare a complete account of the facts surrounding the incident, including:



1. The terms of the Agency’s contract with the non-Government defendant, if appropriate

2. A statement detailing the involvement and supervisory actions of Agency employees in regard to the activities complained of

3. Factors indicating the projected benefit for the administration of the internal revenue laws should representation be afforded to the non-Government defendant, and factors indicating any prospect of actual harm to the Government if legal representation is not afforded to the non-Government defendant


4. The request for representation will be transmitted to DOJ, accompanied by a complete exposition of the facts, together with GLS’s analysis of the Government’s interest in providing the requested representation.

5. Representation requests should be submitted to the appropriate Division at DOJ. If a request for representation is denied, GLS may request a meeting with the DOJ Representation Committee to present the office’s position.


**Exhibit 39.3.1-1**

### Letter of Eligibility to be Represented by Government Counsel

| My name is \_\_\_\_\_\_\_, and I am an attorney with the IRS Office of Chief Counsel, General Legal Services (GLS). I am reaching out to you because my office has been informed that you have been sued in your individual capacity in the above-entitled action. I am writing to provide you with additional information about what this means, and the role my office will play in assisting you throughout the government representation process.<br> First, it is an unfortunate aspect of federal service that employees sometimes get sued in their individual capacities. Our office receives a number of these types of cases each year. In virtually all of these cases, the IRS employees are dismissed from the lawsuits without ever going to trial because the employees were found to have been acting within the scope of their official duties. Government employees who are found to have been acting within the scope of their official duties are generally entitled to qualified immunity, which means that they cannot be held personally liable for damages.<br> The ultimate determination as to whether your alleged activities were within the scope of your official duties will be made by the Department of Justice, based in part on the IRS’s recommendation. To that end, if you elect to request Government representation, I will be in touch with you to discuss your involvement in the activities at issue in this lawsuit. The information you provide will be reviewed and provided to the Department of Justice (DOJ), and DOJ will independently assess your right to Government representation. DOJ approves representation for actions taken within the scope of employment and when it is in the interest of the United States to do so. Please note, it is understood to be important for the morale of the federal work force for employees to know that their employer will stand behind them when they are acting in good faith; accordingly, representation of employees performing their duties to the best of their abilities is generally understood to be in the United States’ interest.<br> I have enclosed an Acknowledgement of Conditions of Department Representation Form (Form DOJ-399), along with a letter requesting representation. If you would like to be represented by Government counsel, please sign and return both the letter and the Form DOJ-399 to me at \_\_\_\_\_ (address or email address) by \_\_\_\_ (date). If there is anything in these materials that is unclear to you, please feel free to reach out to me at \_\_\_\_\_\_, and I would be happy to discuss with you, as well as further explain the representation process. As soon as I receive a final determination from the Department of Justice, I will be in touch with you to discuss next steps, and of course, if you have any questions in the meantime, please don't hesitate to reach out.<br> Thank you, and I look forward to working with you. |
| --- |
| Sincerely, |
| --: |
| Request: I hereby request representation by Government counsel in the above-captioned case. |
| --- |
| Date:<br> Signature: |
| --- |
|  |

**Exhibit 39.3.1-2**

### Letter to Non-Government Defendant

|     |
| --- |
| My name is \_\_\_\_\_, and I am an attorney with the IRS Office of Chief Counsel, General Legal Services (GLS). I am reaching out to you because my office has been informed that you have been sued in your individual capacity for damages in the above-entitled action. Because this matter appears to have arisen as a result of \[your performance of a contractual undertaking with the Internal Revenue Service or specify other reason, as appropriate\], you may be eligible to be represented by a Government attorney. I am writing to provide you with additional information about what this means, and the role my office will play in assisting you throughout the government representation process.<br> I have enclosed a copy of our office’s general policies with respect to requests for representation for non-Government defendants \[enclose text of CCDM 39.3.1.8 - 39.3.1.8.3\]. Please read these provisions carefully and let me know if you have any questions or would like to discuss. If, after reading these provisions, you would like to request Government representation, you may do so by signing and dating the acknowledgment below.<br> If you decide to request representation, the Internal Revenue Service will investigate the matter and make a recommendation to the Department of Justice (DOJ), and DOJ will independently determine whether you are entitled to Government representation. While that determination is pending, you may wish to consult with your own private counsel and to take any steps that may be necessary to protect your interests in this matter, particularly if your answer or response to the complaint in this case is soon due to be filed. You should also understand that, if an adverse money judgment is entered against you, you will be personally responsible for the payment of that judgment.<br> If you desire to be represented by Government counsel, please sign this letter and return it to this office. If there is anything in this letter that is unclear to you, please contact me at \_\_\_\_\_\_\_\_\_\_, and I would be happy to discuss with you. |
| Sincerely, |
| **Acknowledgment:**<br> I have received a copy of the IRS Office of Chief Counsel’s policy with respect to Requests for Government Representation of Non-Government Defendants, I have read it, and I understand the conditions stated therein concerning my being represented by Government attorneys in the above-entitled action. I accept those conditions and I want to be represented by Government counsel, including Department of Justice attorneys, in this case. I understand that the Government has not yet decided whether such legal representation will be provided to me and that the Government is in no way committed to providing such legal representation unless and until the Department of Justice notifies me in writing that such legal representation will be provided. In making this request, I am aware that I have the option of hiring a private attorney at my own expense to represent me in this case. |
| Date:<br> Signature: |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part39/irm_39-003-001#addtoany "Show all")

A2A