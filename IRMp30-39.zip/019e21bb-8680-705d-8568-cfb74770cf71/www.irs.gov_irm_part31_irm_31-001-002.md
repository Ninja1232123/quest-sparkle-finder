---
url: "https://www.irs.gov/irm/part31/irm_31-001-002"
title: "31.1.2 Dealing with Taxpayers and Practitioners | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part31/irm_31-001-002#main-content)

- 31.1.2 [Dealing with Taxpayers and Practitioners](https://www.irs.gov/irm/part31/irm_31-001-002#idm140019720274512)
  - 31.1.2.1 [Representation of Taxpayers before the IRS and CC Office](https://www.irs.gov/irm/part31/irm_31-001-002#idm140019721600512)
  - 31.1.2.2 [Power of Attorney or Tax Information Authorization](https://www.irs.gov/irm/part31/irm_31-001-002#idm140019736490912)
  - 31.1.2.3 [Authorized Representatives](https://www.irs.gov/irm/part31/irm_31-001-002#idm140019721080768)
  - 31.1.2.4 [Conferences](https://www.irs.gov/irm/part31/irm_31-001-002#idm140019737850912)

    - 31.1.2.4.1 [Requests for Conferences](https://www.irs.gov/irm/part31/irm_31-001-002#idm140019730100304)
    - 31.1.2.4.2 [Conflict of Interest](https://www.irs.gov/irm/part31/irm_31-001-002#idm140019724712528)
    - 31.1.2.4.3 [Report of Conference](https://www.irs.gov/irm/part31/irm_31-001-002#idm140019743348800)

  - 31.1.2.5 [Outreach Efforts, Speeches, and Teaching](https://www.irs.gov/irm/part31/irm_31-001-002#idm140019722433104)
  - 31.1.2.6 [Contacts by the Media](https://www.irs.gov/irm/part31/irm_31-001-002#idm140019736485808)

    - 31.1.2.6.1 [Criminal and Civil Matters](https://www.irs.gov/irm/part31/irm_31-001-002#idm140019729817392)
    - 31.1.2.6.2 [Matters within the Jurisdiction of the Department of Justice](https://www.irs.gov/irm/part31/irm_31-001-002#idm140019735245296)
    - 31.1.2.6.3 [Procedures](https://www.irs.gov/irm/part31/irm_31-001-002#idm140019718774352)

  - Exhibit 31.1.2-1 [Excerpt from ABA Model Rules of Professional Conduct](https://www.irs.gov/irm/part31/irm_31-001-002#idm140019736807680)

# Part 31.Guiding Principles

# Chapter 1. Guiding Principles

# Section 2. Dealing with Taxpayers and Practitioners

* * *

## 31.1.2 Dealing with Taxpayers and Practitioners

**31.1.2.1** **(08-11-2004)**

### Representation of Taxpayers before the IRS and CC Office

1. The Statement of Procedural Rules 26 CFR 601.501–509 and Treasury Department Circular 230, 31 CFR, Subtitle A, Part 10, contain rules governing the recognition of attorneys, certified public accountants, enrolled agents and other persons representing clients before the Internal Revenue Service.


**31.1.2.2** **(08-11-2004)**

### Power of Attorney or Tax Information Authorization

1. Attorneys should assure themselves that any person claiming to represent a taxpayer has the authority to represent the taxpayer or that the taxpayer has authorized the disclosure of tax information to that person. Procedures for determining the validity of a power or attorney or other authorization to disclose tax information are contained in CCDM 32.3.2.8.3, which provides the procedures for letter rulings.


**31.1.2.3** **(08-11-2004)**

### Authorized Representatives

1. A request for a letter ruling, determination letter, or closing agreement by or for a taxpayer must be signed by the taxpayer or the authorized representative. A taxpayer’s representative who signs the request or appears before the Service in connection with the request must be one of the following:



1. An attorney who is a member in good standing of the bar of the highest court of any State, possession, territory, Commonwealth, or the District of Columbia, and who files with the Service a written declaration of current qualification as an attorney and authorization to represent the principal;

2. A certified public accountant who is duly qualified to practice in any State, possession, territory, Commonwealth, or the District of Columbia, and who files with the Service a written declaration of current qualification as a certified public accountant and authorization to represent the principal;

3. A person other than an attorney or certified public accountant, enrolled to practice before the Service, and who files with the Service a written declaration of current enrollment including enrollment card number and an authorization to represent the principal; or

4. An enrolled actuary who files with the Service a written declaration of current qualification as an actuary and authorization to represent the principal.


2. The above requirements do not apply to an individual representing a full-time employer or to a bona fide officer, administrator, trustee, etc., representing a corporation, trust, estate, association, or organized group.

3. An unenrolled preparer of a return (other than an attorney or certified public accountant referred to above) who is not a full-time employee or a bona fide officer, administrator, trustee, etc., may not represent a taxpayer with respect to a request for a letter ruling, determination letter, or closing agreement.

4. Any authorized representative, whether or not enrolled to practice, must also comply with the conference and practice requirements of the Statement of Procedural Rules and Circular 230.


**31.1.2.4** **(08-11-2004)**

### Conferences

1. The following procedures govern requests from outside organizations for conferences with Associate Chief Counsel offices.

2. Representatives of Associate Chief Counsel offices may meet on an ad hoc basis with representatives of outside organizations, such as professional organizations and industry and trade associations, to discuss matters of broad general interest under the Associate Chief Counsel’s jurisdiction. Such discussions usually concern, but are not limited to, matters involving proposed or revised ruling positions, procedures, or proposed changes in taxpayer publications.

3. Associate Chief Counsel, or their designees, arrange for and conduct such meetings on matters within their own jurisdiction.

4. Generally, the Deputy Chief Counsel (Technical) or Deputy Chief Counsel (Operations), as appropriate, arranges for and conducts such meetings on matters that involve jurisdiction of more than one Associate.


**31.1.2.4.1** **(08-11-2004)**

#### Requests for Conferences

1. A request for a conference may be made orally or in writing by a representative of an outside organization. Such conferences are granted only after clearance with the appropriate Associate Chief Counsel or with the appropriate Deputy Chief Counsel on matters that involve more than one Associate Chief Counsel office.

2. After a decision is made on the request for a conference, the Associate Chief Counsel advises the outside organization of the decision and, if a conference is to be granted, of the date and place for the conference. Representatives of appropriate Government offices may be invited to attend the conference.

3. Associate Chief Counsel may seek a conference with an outside organization on their own initiative. In such case they may, in their discretion, clear it with the appropriate Deputy Chief Counsel. The Associate Chief Counsel then advises the outside organization of the Service’s desire for a conference and the subject(s) to be discussed.


**31.1.2.4.2** **(08-11-2004)**

#### Conflict of Interest

1. Ordinarily, conferences with outside organizations are held only on matters of broad general interest that justify the attention of representatives of both the Service and the outside organization. In some instances, one or more of the organization’s representatives to the conference may have cases in which an issue to be decided is involved in the subject of the conference. The outside organization is requested to submit in writing the names of the organization’s representatives who will attend the conference, and to state whether any of those representatives have a pending tax case involving the issue or issues that are the subject of the conference.

2. A conference may not be granted on a subject a narrow interest or if it is determined that the particular representative of the outside organization has a case involving the issue. If doubt exists as to the propriety of holding a conference or allowing a particular representative to attend, the Associate Chief Counsel should refer the matter to the appropriate Deputy Chief Counsel.


**31.1.2.4.3** **(08-11-2004)**

#### Report of Conference

1. The Chairperson of the outside organization usually designates a representative to prepare a report on the conference. A draft of the report is sent to the appropriate Associate Chief Counsel for review and clearance.

2. The Associate Chief Counsel has the draft report reviewed and, if necessary, modified so that it correctly reflects what was discussed and the conclusions, if any, agreed upon. In order to verify the substance of what was discussed as stated in the draft report, notes are taken during the conference by a designated Service representative.

3. Persons attending the conference are identified by name and title in the introductory portion of the report. The report should not attribute specific remarks or statements to individuals unless essential to proper reporting of the conference.

4. When the Associate Chief Counsel is satisfied that the draft report is in order, a photocopy is made for Counsel’s files and the draft report is returned to the Chairperson of the outside organization, with a request that copies of the final report be furnished to the appropriate Associate.

5. In all instances when the conference is held at the request of a Deputy Chief Counsel, or in those instances when it is known that the outside organization requesting the conference will not prepare a report, the Associate office arranges for preparation of a report on the conference. The report identifies those in attendance, sets forth what was discussed, and includes the conclusions or sense of the meeting. If requested, a copy of the approved report may be forwarded to the Chairperson of the outside organization.

6. Each conference report prepared by the Service will contain a caveat that statements made in the report are not to be construed in any way as establishing official Service position on any issue. Such a caveat will also be added to each draft report prepared by an outside organization.


**31.1.2.5** **(08-11-2004)**

### Outreach Efforts, Speeches, and Teaching

1. The Chief Counsel’s participation in outreach programs is designed to benefit taxpayers and other stakeholders, including practitioners. This work includes, for example, speeches, panel presentations, focus groups, and training programs for a variety of audiences concerning any topic within the responsibility of the Division Counsel or the Associate Chief Counsel office. Often, these activities will be done in a team with Service personnel or with representatives from other agencies or organizations. The procedures for requesting permission to give speeches or participate in panel discussions can be found in CCDM 30.5.5.


**31.1.2.6** **(08-11-2004)**

### Contacts by the Media

1. This section provides instructions for responding to inquiries received from the members of the media in order to ensure that taxpayers are properly informed of Internal Revenue Service matters without taxpayer’s rights being prejudiced.


**31.1.2.6.1** **(08-11-2004)**

#### Criminal and Civil Matters

1. Publicity on criminal matters is covered by IRM 9.3.2. The local Criminal Investigation (CI) Public Information Officer will work with the local U.S. Attorney in accordance with the IRM for publicity on local cases. For cases of national scope or involving national media, National Media Relations coordinates publicity with CI Communication and Education Headquarters.


**31.1.2.6.2** **(08-11-2004)**

#### Matters within the Jurisdiction of the Department of Justice

1. Publicity of civil cases generally falls to the Department of Justice or the local U.S. Attorney. In some cases the Service may decide to proactively publicize civil cases or issues. Such publicity will be decided on a case by case basis and should be coordinated through National Media Relations for matters with national scope or for national media or through a local Media Relations specialist for local matters with local media. Any decision by the Service to publicize a matter in litigation should be brought to the attention of the Associate Chief Counsel or Division Counsel, as appropriate.


**31.1.2.6.3** **(08-11-2004)**

#### Procedures

1. News articles or stories based upon incorrect or insufficient information can be detrimental to the voluntary self-assessment upon which our revenue system depends. Accordingly, all press releases by or on behalf of the Service are released to members of the press through Media Relations of the Internal Revenue Service. All inquires and requests for comments by the media must also be coordinated through Media Relations. Media Relations will be able to assist the Chief Counsel employee in negotiating the terms and conditions of the interview. Media Relations will also be available to listen in on any phone conversation with a member of the media. All inquiries from the press including inquiries on recently published regulations must be coordinated with Media Relations. The Communications Handbook at IRM 1.19 explains the functions of Media Relations.

2. Generally, Chief Counsel employees and officials will not participate in press conferences. Under certain circumstances Media Relations may request a Chief Counsel employee or official to be present at a press conference to offer assistance to Media Relations. Under those circumstances, the Chief Counsel employee or official should request the approval of the appropriate Deputy Chief Counsel before participating in any press conference or discussion with the press. When field personnel are requested by the local Media Relations office to offer assistance at a press conference, such personnel should consult channels, for approval and advice. The comments should be limited to matters which are in the public record (such as the pleadings, court orders, etc.). Attorney comments should be in keeping with the principles contained in the Model Rules of Professional Conduct. Comments should not violate the disclosure provisions of section 6103. Attorneys should never discuss litigating strategies or the names of proposed witnesses, or comment on the taxpayer’s tactics or chances of success.


**Exhibit 31.1.2-1** **(08-11-2004)**

### Excerpt from ABA Model Rules of Professional Conduct

![This is an Image: 2964801a.gif](https://www.irs.gov/pub/xml_bc/2964801a.gif)

There is currently no description available for this image. For help with this image, please call the IRS.gov Helpdesk at 1-800-876-1715.

[Please click here for the text description of the image.](https://www.irs.gov/media/157321 "")

![This is an Image: 2964801b.gif](https://www.irs.gov/pub/xml_bc/2964801b.gif)

There is currently no description available for this image. For help with this image, please call the IRS.gov Helpdesk at 1-800-876-1715.

[Please click here for the text description of the image.](https://www.irs.gov/media/157326 "")

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part31/irm_31-001-002#addtoany "Show all")

A2A