---
url: "https://www.irs.gov/irm/part35/irm_35-009-003"
title: "35.9.3 Closing Procedures | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-009-003#main-content)

- 35.9.3 [Closing Procedures](https://www.irs.gov/irm/part35/irm_35-009-003#idm140265829559440)
  - 35.9.3.1 [Duties of Field Counsel](https://www.irs.gov/irm/part35/irm_35-009-003#idm140265812766592)
  - 35.9.3.2 [Closing Case Files](https://www.irs.gov/irm/part35/irm_35-009-003#idm140265811304704)
  - 35.9.3.3 [Closing Tax Court Cases Ready Reference](https://www.irs.gov/irm/part35/irm_35-009-003#idm140265804266640)
  - 35.9.3.4 [Withdrawal of Exhibits](https://www.irs.gov/irm/part35/irm_35-009-003#idm140265800373376)
  - 35.9.3.5 [Closing TEFRA Cases](https://www.irs.gov/irm/part35/irm_35-009-003#idm140265823556608)
    - 35.9.3.5.1 [Annotating the TEFRA Case File](https://www.irs.gov/irm/part35/irm_35-009-003#idm140265804266320)
    - 35.9.3.5.2 [Assessing TEFRA Cases](https://www.irs.gov/irm/part35/irm_35-009-003#idm140265800405568)
      - 35.9.3.5.2.1 [Tacking](https://www.irs.gov/irm/part35/irm_35-009-003#idm140265805481904)
  - 35.9.3.6 [Closing Collection Due Process Cases](https://www.irs.gov/irm/part35/irm_35-009-003#idm140265815858656)
  - 35.9.3.7 [Closing Whistleblower Cases](https://www.irs.gov/irm/part35/irm_35-009-003#idm140265805314688)

# Part 35. Tax Court Litigation

# Chapter 9. Post Opinion Activities

# Section 3. Closing Procedures

* * *

## 35.9.3 Closing Procedures

#### Manual Transmittal

August 12, 2019

#### Purpose

(1) This transmits revised CCDM 35.9.3, Post Opinion Activities; Closing Procedures.

#### Material Changes

(1) CCDM 35.9.3 is being revised by adding new subsection CCDM 35.9.3.7, Closing Whistleblower Cases, to provide case closing instructions specific to whistleblower cases.

#### Effect on Other Documents

CCDM 35.9.3 dated June 22, 2015, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(08-12-2019)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**35.9.3.1** **(08-11-2004)**

### Duties of Field Counsel

1. Field Counsel will close "S" and regular cases, whether tried, settled, defaulted, or dismissed after the decision becomes final. Under current closing procedures, Field Counsel is to retain and close the legal file(s) unless an appeal is filed or a special need exists for permanent storage in the appropriate Associate office. If files are forwarded to the appropriate Associate office for appeal consideration, but no appeal is filed, the files are returned to the Field Counsel for closing and storage.

2. Files closed by Field Counsel should normally be retained for one year and then forwarded to a Federal Records Center for storage. During the year that such files are retained, each file should be readily retrievable if it is needed by any attorney working on related or similar cases. Upon forwarding files to a Federal Records Center, the relevant FRC data ( _e.g._, record group number, accession number, FRC box number, and the FRC location number) should be recorded and retained to assist in the event retrieval from the records center is necessary. Local procedures should determine what FRC data is necessary for rapid file retrieval.


**35.9.3.2** **(04-27-2012)**

### Closing Case Files

1. For a discussion of file closing, see CCDM 30.9.1.5 , Closing the Legal File, and the Tax Litigation Guidebook, located on the Intranet website.


**35.9.3.3** **(08-11-2004)**

### Closing Tax Court Cases — Ready Reference

1. **"S" Cases Tried, Defaulted or Dismissed**. Upon receipt of a correct Tax Court decision for the respondent, the legal, miscellaneous law, and administrative files should be closed by Field Counsel immediately upon the expiration of 90 days following the entry of decision.



1. Upon receipt of a correct decision entered pursuant to T.C. Rule 155, the legal, miscellaneous law, and administrative files may be closed immediately if petitioner has signed a waiver of restrictions on assessment. Otherwise, the files should be closed 100 days following the entry of decision. The additional ten-day waiting period beyond the appeal period of 90 days from the date of the entry of decision provides time for the Field Counsel to be notified of an appeal.


2. **Settled Cases: "S" and Regular**. Upon receipt of the Tax Court’s entered decision, the legal, miscellaneous law, and administrative files should be closed within seven days by Field Counsel, if petitioner has signed a waiver of restrictions on assessment. Otherwise, the files should be closed ten days after the expiration of the 90-day appeal period.

3. **Regular Cases Tried, Defaulted, or Dismissed — Decision for Respondent**. Upon receipt of a correct Tax Court decision for the respondent, the legal, miscellaneous law, and administrative files should be closed by Field Counsel ten days after expiration of the 90-day appeal period if Field Counsel has not been notified that a notice of appeal has been filed by the petitioner. See CCDM 36.2.4, Closing Appeal Cases.



1. In all appealed cases, the Field attorney should keep a "dummy" file consisting of copies of the petition, the answer, the opinion, and the decision, as well as any other significant documents in the file.

2. Upon notification that a notice of appeal has been filed by the petitioner and that no appeal bond has been filed, the legal and miscellaneous law files should immediately be sent to the appropriate Associate office, or directly to the Department of Justice (DOJ), if requested. The administrative file should be forwarded to Appeals with a memorandum notifying that office of the petitioner’s appeal and requesting immediate action for the making of any necessary assessments.

3. Upon notification that a notice of appeal and an approved appeal bond have been filed by the petitioner, the legal and miscellaneous law files should immediately be sent to the appropriate Associate office, or directly to DOJ, if requested. Field Counsel should notify Appeals that a bonded appeal has been filed by the petitioner, but should retain the administrative file since no assessment may be made until the decision on appeal has become final, except for amounts not covered by the bond. Upon notification from an Associate office that the decision on appeal has become final, the administrative file should immediately be forwarded to Appeals for any necessary assessments.


4. **Regular Cases Tried, Defaulted, or Dismissed — Decision for Petitioner or Decision under T.C. Rule 155**. If no appeal or action on decision is recommended, after receipt of a correct decision either for the petitioner or pursuant to T.C. Rule 155 in a case in which no action on decision or appeal recommendation is required, the legal, miscellaneous law, and administrative files should be closed by Field Counsel ten days after the expiration of the appeal period if the field has not been notified that a notice of appeal has been filed. See CCDM 36.2.4, Closing Appeal Cases.



1. Upon notification that a notice of appeal has been filed by the petitioner and that no appeal bond has been filed, the legal and miscellaneous law files should immediately be sent to the appropriate Associate office, or directly to DOJ, if requested. The administrative file should be forwarded to Appeals with a memorandum notifying that office of the petitioner’s appeal and requesting immediate action for the making of any necessary assessments.

2. Upon notification that a notice of appeal and an approved appeal bond has been filed by the petitioner, the legal and miscellaneous law files should immediately be sent to the appropriate Associate office, or directly to DOJ, if requested. Field Counsel should notify Appeals that a bonded appeal has been filed by the petitioner, but should retain the administrative file since no assessment may be made until the decision on appeal has become final, except for amounts not covered by the bond. Upon notification from an Associate office that the decision on appeal has become final, the administrative file should immediately be forwarded to Appeals for any necessary assessments.


5. **Action on Decision or Appeal Recommendation Required**. If an action on decision or appeal recommendation is required, the legal and miscellaneous law files should immediately be sent to the appropriate Associate office with the action on decision or appeal recommendation. The administrative file should be retained by Field Counsel. The appropriate Associate office will retain the legal and miscellaneous files until the expiration of the appeal period, and will notify Field Counsel whether or not a notice of appeal has been filed by either party. See CCDM 36.2.6.2.2.1.3, Notification to the Field. In the case of a decision adverse to the Service, if a claim for litigation costs is made, the legal file may be retained by Field Counsel when necessary for the proceedings under T.C. Rules 231 and 232.



1. Upon notification that no notice of appeal has been filed either by the petitioner or the respondent, the administrative file should be forwarded to Appeals for any necessary assessments. The legal and miscellaneous law files will be retained and closed by an appropriate Associate office ten days after the expiration of the appeal period. The Associate office may, in lieu of closing a case directly, return the legal and miscellaneous files to the Field Counsel office for closing.

2. Upon notification that a notice of appeal has been filed by the petitioner without posting an appeal bond, any remaining material for association with the legal or miscellaneous law files should immediately be forwarded to the appropriate Associate office, or directly to DOJ, if requested. The administrative file should be forwarded to Appeals for any necessary assessments.

3. If Field Counsel is notified either that the petitioner has filed a notice of appeal and has posted an appeal bond approved by the Tax Court, or that the government has filed a notice of appeal, any remaining material for association with the legal or miscellaneous law files should immediately be forwarded to the appropriate Associate office, or directly to DOJ, if requested. Field Counsel should notify Appeals by memorandum that an appeal has been filed, but should retain the administrative file since no assessment can be made until the decision on appeal is final, except for amounts not covered by the bond. Upon notification received that the decision on appeal has become final, the administrative file should be forwarded to Appeals for any necessary assessments. The legal and miscellaneous law files will be retained and closed by an appropriate Associate office immediately after the decision on appeal has become final. See CCDM 36.2.5.12.5.1, Monitor Case Status. The Associate office may, in lieu of closing a case directly, return the legal and miscellaneous files to the Field Counsel office for closing.

4. If a decision of the Tax Court is reversed or modified by a court of appeals or by the Supreme Court, and the case is remanded to the Tax Court for appropriate action, the legal and miscellaneous law files will be forwarded to Field Counsel upon expiration of the period for initiating further appellate proceedings or upon denial of, or order of the Supreme Court upon, a petition for a rehearing. Cases which are remanded are thereafter closed by Field Counsel in accordance with the normal procedures outlined above.


**35.9.3.4** **(08-11-2004)**

### Withdrawal of Exhibits

1. After a decision becomes final, Field Counsel may request that the Tax Court return certain exhibits, including original documents. If the decision is not yet final, Field Counsel must file a motion requesting the withdrawal of the exhibits.

2. Exhibits may not be withdrawn from the Tax Court except for photocopying or under the court’s order until the decision becomes final. Exhibits are withdrawn upon the closing of the case. The Field attorney and reviewer should determine which exhibits, if any, should be withdrawn. In general, the Field attorney should request withdrawal of original documents, including returns.

3. T.C. Rule 12(a) provides, in substance, that the Clerk of the Court shall not permit any exhibit to be withdrawn from the court except as ordered by a judge or as the Clerk may find necessary in furnishing photocopies until the decision of the court becomes final. Upon the decision of the court becoming final, the Clerk disposes of the exhibits in accord with T.C. Rule 143(d)(2). After the decision is final, the Field attorney may write a letter to the court requesting the return of the exhibits and explaining the circumstances for requesting the withdrawal.

4. Since exhibits in other than settled cases may not be withdrawn in the usual procedure prior to the date the decision becomes final, a motion is necessary to withdraw exhibits prior to the expiration of the appeal period. Thus, in a tried case in which neither party will appeal the court’s decision, a motion must be filed with the court for the withdrawal of the exhibits when such exhibits are needed for related cases prior to the expiration of the appeal period. In this instance photocopies or certified copies may be obtained and oftentimes will suffice. If it is necessary to permanently withdraw such exhibits, the motion should set forth the fact that the case will not be appealed and the reasons for the necessity of permanently withdrawing the exhibits at that time. Whenever possible, such motion should be endorsed "No Objection" by the petitioner.


**35.9.3.5** **(08-11-2004)**

### Closing TEFRA Cases

1. Special attention should be paid to closing Tax Equity and Fiscal Responsibility Act of 1982 (TEFRA) cases for the following reasons. First, the statute of limitations for assessment in TEFRA cases is different than in other cases. Second, settled TEFRA cases should be closed quickly to give Appeals time to recompute tax attributable to the partners. Third, each settled TEFRA case file must be annotated to alert case processors as to the proper period in which to assess the tax against the partners.

2. Closing TEFRA Cases in Seven Days. Unlike settled deficiency cases which normally contain waivers of restrictions on assessment, cases settled under T.C. Rule 248 do not contain a waiver paragraph permitting immediate assessment of the deficiency. Neither the petitioner nor the Tax Matters Partner is generally authorized to execute waivers for all partners. The tax cannot be assessed against the parties, who include all nonpetitioning and nonintervening partners with an interest in the outcome, until the decision becomes final 90 days after the decision is entered. Notwithstanding, all settled TEFRA cases should be closed in the same seven day period in which settled statutory notice cases are closed. The reason for closing TEFRA cases within seven days is that, unlike deficiency cases where the amount of the deficiency is set forth in the decision, assessment in TEFRA cases must be preceded by complex recomputations of tax attributable to partnership items for each affected partner. Closing the case within seven days will enable Appeals and Exam to get a head start on the complex task of recomputing the tax attributable to the partnership level adjustments in the TEFRA decision for the individual partners.


**35.9.3.5.1** **(04-27-2012)**

#### Annotating the TEFRA Case File

1. Since no assessment can be made until the appeal period expires, the following should be added on the closing transmittal in TEFRA cases:



> "This is a settled TEFRA partnership case. Please advise the appropriate Service Center that assessment of any resulting deficiencies and the issuance of any notices of deficiencies for penalties should not be made until after \[date\]."

2. The blank should be filled in with the appeal expiration date. If an appeal with an adequate appeal bond is subsequently filed, a follow up memorandum to this effect should be immediately forwarded to the Service Center advising that assessment should be delayed pending the decision becoming final.


**35.9.3.5.2** **(06-22-2015)**

#### Assessing TEFRA Cases

1. Once the decision of the Tax Court in a TEFRA case becomes final, the Service has one year in which to assess the tax (plus any additional time obtained through "tacking" ). _See_ section 6229(d). The decision of the Tax Court will become final 90 days after entry of the decision if neither party files a notice of appeal during that period. _See_ section 7481 for the determination of when a Tax Court decision becomes final.

2. Although, as to tax years on appeal, the statute of limitations on assessment is suspended until the appellate court proceedings are concluded and the Tax Court decision becomes final and for one year thereafter in TEFRA cases, it is the position of the Service to have the deficiency assessed at the earliest opportunity.

3. Generally, the disallowance of partnership losses or increased partnership income, and any related penalties, can be directly assessed against the partners. Tax attributable to purely computational affected items can also be directly assessed. Affected items that require non-computational partner-level determinations, however, must be assessed using deficiency procedures. The Service may not know with certainty whether a court will agree with its determination that partner-level determinations, and thus a notice of deficiency, are required or not required. If the Service issues a notice of deficiency, the period of limitations is tolled only if partner-level determinations are in fact required to make the assessment.

4. If a partner has a reported loss (or decreased gain) from selling a partnership interest or selling an asset distributed by the partnership, Field Counsel should determine whether the Service must issue a notice of deficiency to assess a deficiency attributable to this affected item. Field Counsel must coordinate this determination with Procedure & Administration branches 6 or 7. If it is determined that significant hazards exist on the assessment procedure to be used, and the deficiency amount is significant, the following protective procedure may be followed.



1. The Service will issue a notice of deficiency with respect to the asset or interest sold by the partner and any penalties relating to the sold asset or interest within eight months of the decision in the partnership-level proceeding becoming final.

2. After the 90 day period has expired for the taxpayer to petition the notice of deficiency to the Tax Court, the Service will assess the entire deficiency, including any penalties, reflecting both the outcome of the partnership-level proceeding as well as what was included in the affected item notice of deficiency. This assessment should be made regardless of whether taxpayer files a petition with the Tax Court to challenge the determinations in the notice of deficiency.


       1\. If the taxpayer files a petition in response to the notice of deficiency and then moves to enjoin the assessment of the tax, Counsel attorneys should agree to abate the portion of the assessment related to the sold asset or interest provided the court agrees the loss (or decreased gain) reported on the taxpayer’s return is subject to the deficiency procedures.


       2\. If the taxpayer also moves to enjoin penalties, Counsel attorneys should argue that the penalties are directly assessable and should not be enjoined.

3. In all circumstances, however, the entire assessment of tax and penalties should be made within one year of the conclusion of the partnership-level proceeding.


**35.9.3.5.2.1** **(08-11-2004)**

##### Tacking

1. Tacking refers to the additional period of time provided by the unexpired portion of the three-year limitation period at the time the Final Partnership Administrative Adjustment is issued. This period may be tacked onto the one-year period for assessment following the finality of the Tax Court’s decision.


**35.9.3.6** **(04-27-2012)**

### Closing Collection Due Process Cases

1. Section 6330(e)(1) provides generally for a suspension of the collection statute of limitations for the period during which Collection Due Process (CDP) hearings, and appeals therein, are pending. This section states "In no event shall any such period expire before the 90th day after the day on which there is a final determination in such hearing." It is therefore important for attorneys to monitor the status of all pending Tax Court CDP lien and levy cases to determine when such cases become final, because that is when the collection statute of limitations resumes running. In addition, in CDP levy cases, once a decision favorable to the Service is final, the Service may issue levies.

2. It is, therefore, imperative to get final CDP cases returned to Collection as soon as possible. A case is returned to Collection when the CDP case is closed by the Office of Appeals Processing Service (APS) and the Transaction Code (TC) 520 (freeze code) is reversed by Appeals by the entry of a TC 521.

3. Under the current Appeals procedures, a pending Tax Court case will be closed and the freeze code reversed once APS receives from Chief Counsel the CDP administrative file and a copy of the Tax Court decision and any opinion. See paragraph (5) below if the Tax Court decision was appealed. The file should be sent (to the address on the orange sheet at the front of the file) with a Form 1734, Transmittal Memorandum, requesting that the CDP case be closed in Appeals, and stating the date the Tax Court decision became final so Appeals knows what date to input for the TC 521. **The date the Tax Court decision is final is the date the section 6330(e)(1) suspension of the collection statute of limitations and the levy prohibition ends.**

4. When pursuant to these procedures the administrative file and associated documents are returned to Appeals, it is important to also clearly communicate any additional actions required pursuant to the final CDP case.



1. _Alternative resolution_ — When field counsel has worked with Appeals on a remand or worked with Collection to review new information, which results in an alternative resolution during the Tax Court case (e.g., installment agreement, offer-in-compromise, CNC determination), field counsel should also provide copies of the documents (e.g., payment agreement, Form 53) that will be needed to process the alternative resolution.

2. _Liability determination_ — If the final Tax Court decision determines the taxpayer’s liability in an amount less than the assessment subject to the CDP hearing, the field counsel attorney should include specific instructions in the Form 1734 to Appeals to make the necessary abatement to tax and any related penalties and interest. If the Tax Court CDP case was consolidated with a later-commenced deficiency case involving the same tax and period as the CDP case, the final Tax Court decision determines a deficiency, and the deficiency has not been assessed because the taxpayer posted an adequate bond on appeal, then the transmittal Form 1734 should include a request to Appeals to make the deficiency assessment.

3. _Costs or Sanctions_ — If the final Tax Court decision awards costs or sanctions to the government, the field counsel attorney should include specific instructions in the Form 1734 to Appeals to make an assessment of the costs or sanctions.



      ### Note:



      If the court of appeals or Supreme Court awards costs or sanctions to the government, a later request for assessment will be submitted by the Disclosure and Litigation Support Branch when the case is closed by Procedure and Administration.


5. If the Tax Court decision was appealed, Appeals should also be provided with a copy of the court of appeals final judgment or order and any opinion. For additional procedures for closing CDP cases that were appealed to a court of appeals, see CCDM 36.2.6.2.5, Closing Procedures Specific to Tax Court Appeals.


**35.9.3.7** **(08-12-2019)**

### Closing Whistleblower Cases

1. Special attention should be paid to closing whistleblower cases for the following reasons. First, there are procedures specific to whistleblower cases that do not apply in other Tax Court cases. Second, there are heightened security concerns concerning disclosures of a whistleblower identity. Third, administrative claim files in whistleblower cases must be routed back to the IRS Whistleblower Office, not the IRS Office of Appeals. When closing a Tax Court whistleblower case, Field attorneys need to follow these instructions, to the extent they differ from the general instructions for closing Tax Court cases.

2. It is the responsibility of Field Counsel to close the legal and whistleblower administrative claim files once the decision of the Tax Court in a whistleblower case becomes final. _See_ section 7481 for the determination of when a Tax Court decision becomes final.

3. Field Counsel must prepare a letter to the whistleblower-petitioner informing the petitioner that, consistent with any protective order entered in the case, they must either return or certify destruction of all section 6103 information disclosed during the Tax Court case. This letter must be included in the legal file before it is closed. _See_ CCDM 35.4.6.5.2, _Protective Orders, Whistleblower Proceedings_.

4. The IRS Whistleblower Office’s administrative claim file must be returned to the IRS Whistleblower Office when the Tax Court decision becomes final. It is essential that Field Counsel safeguards the administrative claim file during litigation and transfers the administrative claim file back to the IRS Whistleblower Office when the Tax Court decision becomes final.

5. The IRS Whistleblower Office will not process the payment of an award until all appeals of the Whistleblower Office’s determination are final. _See_ Treas. Reg. § 301.7623-4(d)(1). In cases petitioned to the Tax Court, the IRS Whistleblower Office depends on Field Counsel to confirm when the Tax Court case is final.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-009-003#addtoany "Show all")

A2A