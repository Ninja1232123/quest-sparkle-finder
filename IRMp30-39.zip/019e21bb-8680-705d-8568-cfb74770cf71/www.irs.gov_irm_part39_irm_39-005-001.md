---
url: "https://www.irs.gov/irm/part39/irm_39-005-001"
title: "39.5.1 Public Contracts, Technology Law, and Related Matters | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part39/irm_39-005-001#main-content)

- 39.5.1  [Public Contracts, Technology Law, and Related Matters](https://www.irs.gov/irm/part39/irm_39-005-001#idm139912169318000)
  - 39.5.1.1  [Contracting](https://www.irs.gov/irm/part39/irm_39-005-001#idm139912169362720)
  - 39.5.1.2  [Agreements](https://www.irs.gov/irm/part39/irm_39-005-001#idm139912169351424)
  - 39.5.1.3  [Technology Matters](https://www.irs.gov/irm/part39/irm_39-005-001#idm139912169344560)
  - 39.5.1.4  [Litigation](https://www.irs.gov/irm/part39/irm_39-005-001#idm139912169175104)
    - 39.5.1.4.1  [Protests](https://www.irs.gov/irm/part39/irm_39-005-001#idm139912169173104)
    - 39.5.1.4.2  [Contract Disputes](https://www.irs.gov/irm/part39/irm_39-005-001#idm139912169154112)
    - 39.5.1.4.3  [Contract Appeals](https://www.irs.gov/irm/part39/irm_39-005-001#idm139912169149536)
    - 39.5.1.4.4  [Support to Department of Justice](https://www.irs.gov/irm/part39/irm_39-005-001#idm139912169137184)
    - 39.5.1.4.5  [Significant Case Coordination](https://www.irs.gov/irm/part39/irm_39-005-001#idm139912169134592)

# Part 39. Chief Counsel Directives Manual General Legal Services

# Chapter 5. Public Contracts and Technology Law

# Section 1. Public Contracts, Technology Law, and Related Matters

* * *

## 39.5.1 Public Contracts, Technology Law, and Related Matters

#### Manual Transmittal

April 08, 2022

#### Purpose

(1) This transmits revised CCDM 39.5.1 Public Contracts and Technology Law; Public Contracts, Technology Law, and Related Matters.

#### Background

This section is being revised to provide current policy and procedure concerning Public Contracts, Technology Law, and Related Matters within the Office of Chief Counsel.

#### Material Changes

(1) CCDM 39.5.1 and related subsections were revised to expand and update the list of statutes, regulations, and policies that govern public contracts, as well as to reflect current procedures for handling matters related to Contracting.

(2) CCDM 39.5.1.1(4), Performance, was deleted. As a result of this deletion, CCDM 39.5.1.1(5) has now been moved to 39.5.1.1(4).

(3) CCDM 39.5.1.1(5) (now 39.5.1.1(4)) has been renamed Software Licenses.

(4) CCDM 39.5.1.2 and related subsections were revised to reflect current procedures for handling matters related to Agreements.

(5) CCDM 39.5.1.3 and related subsections were revised to reflect current procedures for handling matters related to Technology, including changing the subsection heading of CCDM 39.5.1.3(2) from Computer Security to Computer Security/Cybersecurity.

(6) CCDM 39.5.1.4.1 was revised to add CCDM 39.5.1.4.1(4) (Agency Protests) and CCDM 39.5.1.4.1(5) (GAO Protests).

(7) CCDM 39.5.1.4.3 was revised to clarify the rules governing proceedings before the Civilian Board of Contract Appeals.

(8) CCDM 39.5.1.4.3(1) was deleted. As a result of this deletion, subsection headings and numberings in 39.5.1.4.3 have changed throughout.

(9) CCDM 39.5.1.4.5 was added to describe case-coordination expectations for significant cases falling within PCTL’s subject matter areas.

(10) CCDM 39.1.5.5 was deleted.

(11) Citations to the IRM and other relevant authorities were updated throughout.

(12) Minor typographical errors were corrected and editorial changes made throughout.

#### Effect on Other Documents

This section supersedes CCDM 39.5.1, dated June 16, 2009.

#### Audience

Chief Counsel

#### Effective Date

(04-08-2022)

Mark Kaizen

Associate Chief Counsel

General Legal Services

**39.5.1.1** **(04-08-2022)**

### Contracting

1. The GLS attorneys in the Public Contracts and Technology Law Branch (PCTL) are responsible for providing legal support to the Service’s contracting offices, requiring activities, the facilities management offices, fiscal offices, and other National and field or area office elements, upon request, on all legal matters pertaining to the formation and administration of contracts entered into by the Service. This support covers the full range of problems encountered by the various Service elements in all phases of purchasing supplies and services. In addition, PCTL attorneys provide this same support to Office of Treasury Procurement Services and the Bureau of Engraving and Printing for its Information Technology acquisitions. Legal guidance is furnished regarding statutes, regulations, and policies that govern public contracts to include:



   - The Competition in Contracting Act (CICA)

   - The Federal Acquisition Streamlining Act of 1994 (FASA)

   - The Procurement Integrity Act (PIA)

   - The Buy American Act (BAA)

   - The Trade Agreement Act (TAA)

   - The Federal Acquisition Regulation (FAR)

   - Department of Treasury Acquisition Regulations (DTAR)

   - Department of the Treasury Acquisition Procedures (DTAP)

   - The Internal Revenue Acquisition Procedures (IRSAP)

   - The Small Business Act


2. **Formation**. PCTL attorneys provide legal assistance by reviewing acquisition plans, solicitations, requests for proposals, and contract awards. The dollar value threshold requiring legal review is set forth in Internal Revenue Service Acquisition Procedures (IRSAP), Procedures, Guidance and Instructions (PGI) 1004.71. PCTL attorneys also assist in drafting special clauses and contract language, interpreting, and applying numerous statutory, regulatory, policy and funding requirements, and advising on matters concerning organizational conflicts of interest, contractor responsibility and performance metrics.

3. **Administration**. PCTL attorneys provide legal assistance by reviewing contract modifications and task orders as required by the dollar value threshold as set forth in IRSAP PGI 1004.71 and as requested. PCTL attorneys work with contracting personnel to identify and resolve performance and payment problems prior to litigation, and, depending upon the forum, provide either direct or indirect support of any litigation that arises during the course of contract administration.

4. **Software Licenses**. PCTL attorneys provide legal advice pertaining to software licensing issues as they relate to procurement, to include assistance in negotiating terms in vendor provided commercial user agreements. In rendering such advice, PCTL attorneys ensure that all protectable rights and interests acquired by the Service through contract and licenses to intellectual property are fully preserved and protected.


**39.5.1.2** **(04-08-2022)**

### Agreements

1. PCTL attorneys ensure agreements submitted for review comply with general contractual standards. Upon request, PCTL attorneys provide legal assistance in drafting special clauses and agreement language and in interpreting and applying the numerous statutory, regulatory, policy, and funding requirements relating to Government agreements between Counsel and/or the Service and other parties.

2. **Memoranda of Understanding**. PCTL attorneys review Memoranda of Understanding (MOU) to ensure that program objectives, as well as the rights and obligations of the parties, are clearly stated.

3. **Cooperative Agreements and Grants**. PCTL attorneys review proposed transfers of financial assistance from the Service to a State or local government, or other recipient, to determine that the appropriate type of legal instrument is used in accordance with the Federal Grant and Cooperative Agreement Act of 1977, that there is statutory authority for the transfer of such financial assistance, and that the agreement comports with all provisions of that underlying authority.

4. **Interagency Agreements**. PCTL attorneys’ review of interagency agreements includes consideration of whether the services provided by one Federal agency to another raise reimbursement issues under the Economy Act, 31 U.S.C. §§ 1535, 1536, or other statutory authority. Treasury specific requirements related to interagency agreements are at DTAP Subpart 1017.5. Additionally, where the agreement requires that the Service reimburse another Federal agency, PCTL attorneys will consider whether the agreement requires review by the Service’s Office of Procurement and execution by a Contracting Officer. The dollar value threshold requiring legal review is set forth in IRSAP 1017.5.


**39.5.1.3** **(04-08-2022)**

### Technology Matters

1. The Branch Chief, PCTL, coordinates the rendering of legal advice pertaining to technology-related matters including emerging electronic commerce issues and the adoption and redesign of electronic-based processes. PCTL attorneys furnish legal support for technology matters including furnishing legal guidance regarding program authority and the review and drafting of related contracts, licenses, MOUs, and non-disclosure agreements that relate to technology matters. Legal products that pertain to electronic processes and data are reviewed for both legal sufficiency and compliance with all applicable legal requirements, such as electronic and information technology accessibility requirements imposed by Section 508 of the Rehabilitation Act of 1973, as amended by the Workforce Investment Act of 1998 and the Federal Technology Transfer Act of 1986.

2. **Computer Security/Cybersecurity**. PCTL attorneys perform the legal work associated with information security-related matters including the application of computer security standards, risk management, encryption, public key infrastructure initiatives, and non-disclosure agreements and other issues related to contractor personnel access to, and use of, IRS IT systems. Legal guidance is furnished regarding statutes, regulations, and policies that bear on the use and management of information technology in the federal government, to include:



   - E-Government Act of 2002

   - Federal Information Security Management Act of 2014

   - OMB IT and computer security policy guidance

   - Treasury Security Manual, TD P 15-71

   - Treasury Information Technology Security Program, TD P 85-01

   - Internal Revenue Manual (IRM) Part 10, Security, Privacy and Assurance

   - Computer Fraud and Abuse Act

   - Economic Espionage Act of 1996

   - Uniform Trade Secrets Act

   - Defend Trade Secrets Act of 2016

   - Electronic signature alternatives as provided for by the Government Paperwork Elimination Act and the Electronic Signatures in Global and National Commerce Act (to the extent government activities and requirements relate to business, commercial, or consumer transactions)

   - Federal Information Technology Acquisition Reform Act (FITARA)


**39.5.1.4** **(08-11-2004)**

### Litigation

1. PCTL attorneys represent the Service in bid protests before the Government Accountability Office (GAO) and in appeals before the Civilian Board of Contract Appeals (CBCA). Additionally, PCTL attorneys provide litigation support to the Department of Justice before Federal District Courts, the United States Court of Federal Claims, and appellate courts.


**39.5.1.4.1** **(04-08-2022)**

#### Protests

1. Contracting officers consider and respond to, or resolve, all protests, whether submitted before or after award and whether filed directly with the Service, the GAO, or the U.S. Court of Federal Claims.

2. **PCTL Attorney Support**. PCTL attorneys provide advice, assistance, and direct and indirect litigation support in protests depending upon the forum.

3. **Protest Policies and Procedures**. The policies and procedures for processing agency and GAO protests where PCTL provides direct support are found in:



   - FAR Part 33

   - DTAR Part 1033.1

   - IRSAP 1033.1

   - GAO Bid Protest Regulations in 4 C.F.R. Part 21


4. **Agency Protests**



1. Agency protests are filed directly with the contracting officer. The PCTL Branch Chief is notified of all agency protests by the Procurement Policy Office so an attorney can be assigned to advise the contracting officer.

2. The assigned attorney will arrange for a meeting with the contracting officer as soon as possible to discuss the merits of the protest and explain the steps required to respond to the protest.

3. The assigned attorney will determine whether a stay or performance pending resolution of the protest is required and will review for legal sufficiency any justification prepared for overriding the stay.

4. The assigned attorney will assist the contracting officer in preparing the contracting officer’s final decision, which should normally be issued within 35 days after the protest is filed.


5. **GAO Protests**



1. GAO notifies Procurement’s Policy Office of all protests received, and the Policy Office in turn notifies the PCTL Branch Chief so an attorney can be assigned to represent the agency.

2. The assigned attorney will immediately file a Notice of Appearance on GAO’s EPDS docketing system.

3. As soon as possible the assigned attorney will arrange for a meeting with the contracting officer, and if determined to be appropriate, members of the technical evaluation team, to discuss the merits of the protest and explain the steps required to respond to the protest. At this time, the attorney should ascertain whether a stay of the award is required so the contracting officer can issue a stop work order if needed.

4. Not later than 25 days after protest filing, the assigned attorney must file the Agency Report Index showing what documents will be provided with the Agency Report and identifying any documents requested by the protester that will not be provided, with an explanation why providing such documents is not required.

5. Not later than 30 days after protest filing, the assigned attorney will file the Agency Report to include a legal memorandum addressing each protest ground, the contracting officer’s statement of facts, and all documents previously identified in the Agency Index.

6. The protestor must file a response to the Agency Report within 10 days or the protest will be dismissed. If, in its response, the protestor raises additional protest grounds, the assigned attorney must file a supplemental Agency Report within whatever time frame GAO dictates.

7. If it is determined that one or more protest grounds have merit and there is no viable defense, in lieu of filing an Agency Report, a notice of corrective action can be filed which will normally result in GAO dismissing the protest as moot. The notice of corrective action must be filed before the Agency Report is due because otherwise the Agency will be responsible for paying the protestor attorney’s fees incurred in pursuing the protest.

8. GAO decisions are almost always decided solely on the basis of the submitted record. In the rare case where GAO determines a hearing is necessary, it will be held at the GAO headquarters in Washington D.C. GAO has no set procedures for holding a hearing. It will normally conduct a prehearing conference to decide what issues will be addressed at the hearing, to identify the witnesses it wants to hear, and to settle procedural questions. After the hearing, all parties will be allowed to file written comments on the hearing.

9. In the event GAO does hold a hearing, the parties will be expected to obtain a court reporter and provide GAO a copy of the transcript. The PCTL attorney should coordinate with the protestor’s counsel as to which party will be responsible for retaining the court reporter, and then coordinate with the Procurement Officer for them to either issue a contract for court reporter services or arrange to pay the court reporter obtained by the protestor for any needed transcripts.


**39.5.1.4.2** **(06-16-2009)**

#### Contract Disputes

1. The Contract Disputes Act of 1978 (CDA), 41 U.S.C. §§ 601-613, establishes procedures and requirements for asserting and resolving claims by or against contractors arising under or relating to a contract subject to the CDA. In addition, the CDA provides for the payment of interest on contractor claims, for the certification of contractor claims in excess of $100,000, and for a civil penalty for contractor claims that are fraudulent or based on a misrepresentation of fact.

2. **PCTL Attorney Support**. PCTL attorneys provide advice, assistance, and support in formulating the contracting officer’s final decision on matters arising under or relating to a contract dispute.

3. **Dispute Policies and Procedures**. The policies and procedures for processing agency disputes are found in FAR Part 33.


**39.5.1.4.3** **(04-08-2022)**

#### Contract Appeals

1. **PCTL Attorney Support**. PCTL attorneys provide advice, assistance, and direct and indirect litigation support in appeals.

2. **Appeal Policies and Procedures**. The policies and procedures for processing appeals are found in:



   - FAR Part 33

   - DTAP Subpart 1033.2

   - CBCA Rules

   - The Federal Rules of Civil Procedure


3. The Civilian Board of Contract Appeals (CBCA) serves as the authorized representative of the Secretary to hear, consider, and determine appeals filed under IRS contracts, 41 U.S.C. § 607 and 48 C.F.R. Chapter 10. The CBCA has authority with respect to disputes arising under or relating to IRS contracts. The rules of the board govern the procedures to be followed.



1. The CBCA provides the PCTL Branch Chief a notice of docketing whenever a notice of appeal of an IRS contracting officer’s decision is filed. The Branch Chief in turn assigns a PCTL attorney to represent the Agency.

2. The assigned attorney will immediately file a notice of appearance and then arrange a meeting with the contracting officer to discuss the merits of the case and explain the steps required to address the appeal.

3. In Contract appeals, as in all cases handled by the office, the assigned PCTL attorney is responsible for ensuring that appropriate measures are in place to ensure the preservation of any necessary paper and electronic information and evidence. Although the form of the notification may differ from case to case, a litigation hold should be issued in each appeal, in accordance with internal Chief Counsel and GLS policies regarding ligation holds.

4. The PCTL attorney will prepare the case for hearing including determining the facts, identifying and interviewing prospective witnesses, and identifying and gathering necessary documents. The PCTL attorney will use discovery to facilitate preparation of the case, to include, where appropriate, interrogatories, requests for production of documents, requests for admissions, and depositions.

5. In the event a hearing or deposition is held, the PCTL attorney must coordinate with the contracting officer to ensure arrangements are made to purchase any transcripts produced.


4. **The U.S. Court of Federal Claims**. In accordance with 41 U.S.C. § 609, in lieu of appealing the decision of the contracting officer to an agency board, a contractor may bring an action directly on the claim in the United States Court of Federal Claims. PCTL provides indirect support to the Department of Justice, as set forth in _CCDM 39.5.1.4.4_ for any appeals filed in the Court of Federal Claims.


**39.5.1.4.4** **(04-08-2022)**

#### Support to Department of Justice

1. PCTL attorneys provide litigation support to DOJ before Federal District Courts, the United States Court of Federal Claims, and appellate courts. Such support, which may include drafting interrogatories, pleadings, briefs, and other papers, generally includes answering interrogatories on behalf of the agency for the Department of Justice. In addition to protests and contract appeals, PCTL attorneys provide support to DOJ in matters arising under the False Claims Act, 31 U.S.C. § 3729.


**39.5.1.4.5** **(04-08-2022)**

#### Significant Case Coordination

1. The Associate Chief Counsel (GLS) must be kept informed of significant issues and cases handled by the PCTL Branch. Attorneys shall promptly bring significant cases to the attention of the Deputy Associate Chief Counsel (GLS) and/or the Chief, PCTL Branch.

2. The Associate Chief Counsel (GLS) must be promptly notified of any appeal to the Court of Appeals or higher that needs the approval of the Chief Counsel or designee.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part39/irm_39-005-001#addtoany "Show all")

A2A