---
url: "https://www.irs.gov/irm/part35/irm_35-011-001"
title: "35.11.1 Litigation Exhibits | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-011-001#main-content)

- 35.11.1  [Litigation Exhibits](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415794641568)
  - 35.11.1.1  [Supplementary Material](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415794841072)
  - Exhibit  35.11.1-1  [Issues Requiring Associate Office Review](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415794641184)
  - Exhibit  35.11.1-2  [Untitled](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415763593504)
  - Exhibit  35.11.1-3  [Transfer of Cases and Coordination of Issues with Division Counsel/Associate Chief Counsel (TE/GE)](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415764206752)
  - Exhibit  35.11.1-4  [Jeopardy Assessment Cases — Notice of Jeopardy Assessment (Termination)](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415763682864)
  - Exhibit  35.11.1-5  [Jeopardy Assessment Cases — Notice of Partial Abatement of Jeopardy Assessment](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415764098496)
  - Exhibit  35.11.1-6  [Jeopardy Assessment Cases — Notice of Abatement of Jeopardy Assessment](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415757591280)
  - Exhibit  35.11.1-7  [Munro Stipulation for Deficiency Cases](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415763511056)
  - Exhibit  35.11.1-8  [Motion for Leave to File an Amendment to Answer — Munro — Increased Deficiency and Increased Penalties](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415763433312)
  - Exhibit  35.11.1-9  [Answer — Petitioner's Burden of Proof: Complete Admissions and Denials](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415757475168)
  - Exhibit  35.11.1-10  [Answer — Petitioner's Burden of Proof: Qualified Admissions and Denials](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415757575248)
  - Exhibit  35.11.1-11  [Answer — Petitioner's Burden of Proof: Unnumbered and/or Unlettered Paragraphs](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415763852064)
  - Exhibit  35.11.1-12  [Answer — Affirmative Allegations: Statute of Limitations — Fraud as Defense](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415798477712)
  - Exhibit  35.11.1-13  [Answer — Affirmative Allegations: Statute of Limitations — 25% Omission as Defense](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415798474736)
  - Exhibit  35.11.1-14  [Answer – Affirmative Allegations: Statute of Limitations — Delinquency as Defense](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415763784352)
  - Exhibit  35.11.1-15  [Answer — Affirmative Allegations: Statute of Limitations — Waivers or Consents as Defense](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415764087312)
  - Exhibit  35.11.1-16  [Answer — Affirmative Allegations: Statute of Limitations — Waivers or Forms 872A as Defense](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415764081456)
  - Exhibit  35.11.1-17  [Answer — Collateral Estoppel — General](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415757563424)
  - Exhibit  35.11.1-18  [Answer — Affirmative Allegations: Fraud — Bank Deposit Method](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415763544320)
  - Exhibit  35.11.1-19  [Answer — Affirmative Allegations: Fraud — Net Worth Method](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415763883536)
  - Exhibit  35.11.1-20  [Answer — Affirmative Allegations: Fraud — Specific Items Method](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415763810208)
  - Exhibit  35.11.1-21  [Answer — Affirmative Allegations: Fraud — Alternative Negligence and Delinquency Penalties](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415763985824)
  - Exhibit  35.11.1-22  [Answer — Affirmative Allegations: Fraud — Collateral Estoppel as to Tax Year](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415763975632)
  - Exhibit  35.11.1-23  [Answer — Affirmative Allegations: Transferee Liability](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415764195008)
  - Exhibit  35.11.1-24  [Answer — Accumulated Earnings Tax: Inadequate Section 534(c) Statement](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415764181904)
  - Exhibit  35.11.1-25  [Answer — Accumulated Earnings Tax Answer: Petitioner Failed to Submit Section 534(c) Statement](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415766607408)
  - Exhibit  35.11.1-26  [Answer — Accumulated Earnings Tax Answer: Section 534 Letter Sent But No Response](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415766600032)
  - Exhibit  35.11.1-27  [Declaratory Judgment Case: Employee Plans (Stipulated Administrative Record)](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415766456592)
  - Exhibit  35.11.1-28  [Declaratory Judgment Case: Employee Plans (Administrative Record Submitted Unagreed)](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765955632)
  - Exhibit  35.11.1-29  [Notice of Filing of Petition and Right to Intervene](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765937232)
  - Exhibit  35.11.1-30  [Notice of Filing of Petition and Right to Intervene (Deceased Nonpetitioning Spouse)](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415764629040)
  - Exhibit  35.11.1-31  [Designation of Place of Trial](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415764907984)
  - Exhibit  35.11.1-32  [Notice of No Objection](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415764845648)
  - Exhibit  35.11.1-33  [Notice of Objection](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415764840416)
  - Exhibit  35.11.1-34  [Motions to Dismiss for Lack of Jurisdiction: Untimely Petition — Late U.S. Postmark](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415764832224)
  - Exhibit  35.11.1-35  [Motions to Dismiss for Lack of Jurisdiction: Untimely Petition — Private Postmeter](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415764822160)
  - Exhibit  35.11.1-36  [Motions to Dismiss for Lack of Jurisdiction: Untimely Petition — Illegible Postmark/ Postmeter](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415764810304)
  - Exhibit  35.11.1-37  [Motions to Dismiss for Lack of Jurisdiction: No Statutory Notice](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415764798544)
  - Exhibit  35.11.1-38  [Motions to Dismiss for Lack of Jurisdiction: No Statutory Notice For Year Put In Issue](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415764790256)
  - Exhibit  35.11.1-39  [Motions to Dismiss for Lack of Jurisdiction: Unauthorized Representative of Deceased Person](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415764781856)
  - Exhibit  35.11.1-40  [Motions to Dismiss for Lack of Jurisdiction: Violation of Bankruptcy Code Stay Provision](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415764771008)
  - Exhibit  35.11.1-41  [Table of Ninety Calendar Days](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415764761664)
  - Exhibit  35.11.1-42  [Table of 150 Calendar Days](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415764758000)
  - Exhibit  35.11.1-43  [Letter to Petitioner Regarding Late Filed Petition](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415764755488)
  - Exhibit  35.11.1-44  [Motions Addressed to the Petition: Failure to State Claim — No IRC § 6673 Penalty Requested](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415764740224)
  - Exhibit  35.11.1-45  [Motions Addressed to the Petition: Failure to State Claim — Claim for Penalties Under IRC § 6673](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415764722288)
  - Exhibit  35.11.1-46  [Motions Addressed to the Petition: Motion to Strike](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415764669136)
  - Exhibit  35.11.1-47  [Motions Addressed to the Petition: Motion for a More Definite Statement or to Strike](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765692304)
  - Exhibit  35.11.1-48  [Tax Court Rule 37(c) Motion](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765678432)
  - Exhibit  35.11.1-49  [Motion to Dismiss for Lack of Prosecution (Generally)](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765668544)
  - Exhibit  35.11.1-50  [Motion to Dismiss for Lack of Prosecution: Nordstrom Procedure — Joint Petitioners](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765659488)
  - Exhibit  35.11.1-51  [Motion for Continuance of Trial (Example 1)](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765647568)
  - Exhibit  35.11.1-52  [Motion for Continuance of Trial (Example 2)](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765638544)
  - Exhibit  35.11.1-53  [Motion to Calendar and Consolidate or In the Alternative to Continue](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765629712)
  - Exhibit  35.11.1-54  [Motion for Pretrial Conference](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765597824)
  - Exhibit  35.11.1-55  [Tax Court Rule 91(f) Motion](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765586928)
  - Exhibit  35.11.1-56  [Motion for Partial Summary Judgment](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765564016)
  - Exhibit  35.11.1-57  [Motion for Summary Judgment and Supporting Affidavit](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765554704)
  - Exhibit  35.11.1-58  [Motion for Protective Order in Opposition to Petitioner's Motion for Partial Summary Judgment](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765535088)
  - Exhibit  35.11.1-59  [Joint Motion to Submit Case Under Rule 122](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765471248)
  - Exhibit  35.11.1-60  [Motion for Entry of Decision](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765462800)
  - Exhibit  35.11.1-61  [Motion to Vacate Decision](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765452176)
  - Exhibit  35.11.1-62  [TEFRA Partnership: Motion to Dismiss for Lack of Jurisdiction Pursuant to IRC § 6226 (b)(1)](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765443104)
  - Exhibit  35.11.1-63  [TEFRA Partnership: Motion to Dismiss for Lack of Jurisdiction Pursuant to IRC § 6226 (b)(2), (b)(4)](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765429504)
  - Exhibit  35.11.1-64  [TEFRA Partnership: Motion to Dismiss for Lack of Jurisdiction — TEFRA Items Only](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765416112)
  - Exhibit  35.11.1-65  [TEFRA Partnership: Motion to Dismiss for Lack of Jurisdiction and to Strike — TEFRA and Non-TEFRA Items](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765404960)
  - Exhibit  35.11.1-66  [TEFRA Partnership: Motion to Dismiss for Lack of Jurisdiction and to Strike With Respect to Additions to Tax](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765393600)
  - Exhibit  35.11.1-67  [Declaratory Judgment Case: Motion for Joinder of Additional Parties](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765380544)
  - Exhibit  35.11.1-68  [Declaratory Judgment Case: Motion to Dismiss for Lack of Jurisdiction](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765370928)
  - Exhibit  35.11.1-69  [Declaratory Judgment Case: Motion to Extend Time Within Which to Stipulate as to Administrative Record](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765349120)
  - Exhibit  35.11.1-70  [Declaratory Judgment Case: Motion for Order to Show Cause Why Case Should Not Be Submitted on Administrative Record as Provided in T.C. Rule 217](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765340080)
  - Exhibit  35.11.1-71  [Notice of Proceeding Under Bankruptcy Code](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765304448)
  - Exhibit  35.11.1-72  [Motion to Consolidate for Trial, Briefing and Opinion](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765298416)
  - Exhibit  35.11.1-73  [Motion to Change Place of Trial](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765288688)
  - Exhibit  35.11.1-74  [Motion to Correct Transcript (Joint)](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765278208)
  - Exhibit  35.11.1-75  [Motion to Change Caption — (Nonjurisdictional)](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765269344)
  - Exhibit  35.11.1-76  [Motion to Substitution of Party and to Change Caption](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765230992)
  - Exhibit  35.11.1-77  [Sample Letter To Attorneys in Conflict Situations Involving Planning, Promoting or Operating a Tax Shelter](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765220752)
  - Exhibit  35.11.1-78  [Sample Letter To Attorneys in Conflict Situations Involving Multiple Representation; IRC § 6015 at Issue](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415765186256)
  - Exhibit  35.11.1-79  [Conflict of Interest Situations Where Petitioner’s Attorney Is a Potential Witness](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415762298624)
  - Exhibit  35.11.1-80  [Discovery Checklist (Interrogatories, Production of Documents, Admissions Depositions, Motions to Compel)](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415762275280)
  - Exhibit  35.11.1-81  [Respondent's Interrogatories to Petitioner](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415762269472)
  - Exhibit  35.11.1-82  [Respondent's Request for Production of Documents](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415762256928)
  - Exhibit  35.11.1-83  [Respondent's Request to Petitioner for Permission for Entry, Inspection, Measuring, and Photographing Property/Objects/Operations Thereon](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415762248240)
  - Exhibit  35.11.1-84  [Respondent's Request for Admissions](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415762238944)
  - Exhibit  35.11.1-85  [Motion to Review Sufficiency of Petitioner's Objections to Respondent's Requests for Admissions](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415762231120)
  - Exhibit  35.11.1-86  [Motion to Compel Responses to Respondent's Interrogatories](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415762220544)
  - Exhibit  35.11.1-87  [Motion to Compel Production of Documents](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415762208736)
  - Exhibit  35.11.1-88  [Motion to Compel Entry, Inspection, Etc.](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415762196208)
  - Exhibit  35.11.1-89  [Motion to Impose Sanctions](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415762180912)
  - Exhibit  35.11.1-90  [Transmittal Memorandum to Manager for Service of Subpoena](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415762169440)
  - Exhibit  35.11.1-91  [Letter Explaining Witness' Appearance](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415762145712)
  - Exhibit  35.11.1-92  [Witness Agreement to Appear](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415762127456)
  - Exhibit  35.11.1-93  [Letter to Third Party Customer in Regard to Subpoena on Financial Institution](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415762108768)
  - Exhibit  35.11.1-94  [Enclosure: Form Motion to Quash Subpoena Served on Financial Institution](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415762078000)
  - Exhibit  35.11.1-95  [Enclosure: Form Affidavit of Third Party Customer](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415762038192)
  - Exhibit  35.11.1-96  [Letters to Financial Institution: Right to Financial Privacy Act — Motion to Quash Denied](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415762015056)
  - Exhibit  35.11.1-97  [Letters to Financial Institution: Right to Financial Privacy Act — No Motion to Quash Filed](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761997904)
  - Exhibit  35.11.1-98  [Motion For Writ of Habeas Corpus Ad Testificandum](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761980848)
  - Exhibit  35.11.1-99  [Sample letter to Witness in Prison](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761971520)
  - Exhibit  35.11.1-100  [Expert Witness Procurement Flow Chart](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761956928)
  - Exhibit  35.11.1-101  [Expert Witness Procurement — Billing and Related Processes](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761919936)
  - Exhibit  35.11.1-102  [Obtaining Testimony of a Witness in a Foreign Country: Application for a Letter Rogatory](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761917840)
  - Exhibit  35.11.1-103  [Obtaining Testimony of a Witness in a Foreign Country: Letter Rogatory](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761908896)
  - Exhibit  35.11.1-104  [Motion for Protective Order](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761855504)
  - Exhibit  35.11.1-105  [U.S. Tax Court Standing Pretrial Order](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761843856)
  - Exhibit  35.11.1-106  [Pretrial Memorandum](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761810544)
  - Exhibit  35.11.1-107  [Letter Enclosing Settlement Documents](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761753616)
  - Exhibit  35.11.1-108  [Letter to Tax Court Judge Reporting Status of Settled Cases](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761707072)
  - Exhibit  35.11.1-109  [Cases Involving a Complete Settlement or Concession Requiring a Report to Joint Committee](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761685920)
  - Exhibit  35.11.1-110  [Cases Involving a Complete Settlement Note Requiring Review by Joint Committee](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761636704)
  - Exhibit  35.11.1-111  [Method of Computing the Aggregate Minimum Net Overpayment](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761579136)
  - Exhibit  35.11.1-112  [Joint Committee Report](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761527680)
  - Exhibit  35.11.1-113  [Letter to the Joint Committee](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761459968)
  - Exhibit  35.11.1-114  [Joint Motion for Voluntary Binding Arbitration](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761433616)
  - Exhibit  35.11.1-115  [Joint Motion for Stipulation to be Bound by Findings of Arbitrator](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761428112)
  - Exhibit  35.11.1-116  [Joint Motion to Continue for Settlement Purposes](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761407440)
  - Exhibit  35.11.1-117  [Model Agreement to Mediate](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761403872)
  - Exhibit  35.11.1-118  [Model Mediation Participants List](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761357600)
  - Exhibit  35.11.1-119  [Motion for Substitution of Exhibits](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761348688)
  - Exhibit  35.11.1-120  [Motion to Withdraw Exhibit for Purposes of Copying](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761338288)
  - Exhibit  35.11.1-121  [Notice of Intent Not to File Answering Brief](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761330080)
  - Exhibit  35.11.1-122  [Example of Brief Cover Sheet](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761325056)
  - Exhibit  35.11.1-123  [Joint Motion to Correct Record on Appeal](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761288352)
  - Exhibit  35.11.1-124  [Tabular Form of Decision: Several Years](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761273760)
  - Exhibit  35.11.1-125  [Tabular Form of Decision: Multiple Petitioners](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761240864)
  - Exhibit  35.11.1-126  [Paragraph Form of Decision: Tax and Penalty](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761186592)
  - Exhibit  35.11.1-127  [Claim For Increased Deficiency](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761166736)
  - Exhibit  35.11.1-128  [Deficiency in Income Tax (Simple Stipulated Decision)](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761148480)
  - Exhibit  35.11.1-129  [Overpayment Based on Claim: Return Filed Within Period as Extended](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761125120)
  - Exhibit  35.11.1-130  [Overpayment Based on Claim: Different Years and Different Bases for Overpayment](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761078224)
  - Exhibit  35.11.1-131  [Overpayment Based on Claim: Same Year and Different Bases of Overpayment](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415761008672)
  - Exhibit  35.11.1-132  [Overpayment Based on Claim: Jeopardy Assessment — Tax and Penalty](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760968688)
  - Exhibit  35.11.1-133  [Overpayment Based on Claim: Gift Tax](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760921024)
  - Exhibit  35.11.1-134  [Overpayment Based on Claim: Estate Tax](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760898928)
  - Exhibit  35.11.1-135  [Overpayment Due to Credit for State Inheritance Taxes: Refund Suit or Claim](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760865920)
  - Exhibit  35.11.1-136  [Overpayment by Transferee](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760828496)
  - Exhibit  35.11.1-137  [Overpayment from Estimated Tax Payments or Tax Withheld: Return as a Claim — Deficiency and Overpayment for Same Year](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760773584)
  - Exhibit  35.11.1-138  [Overpayment Resulting From Application of Earned Income Tax Credit: Previous Assessment](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760718768)
  - Exhibit  35.11.1-139  [Overpayment From Application of EITC Plus Withholding](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760690752)
  - Exhibit  35.11.1-140  [Undisputed Overpayment Refunded Pending Appeal Under RRA § 3463 (lRC §§ 651 2(b)(1), 6213(a))](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760656224)
  - Exhibit  35.11.1-141  [Interim Assessments: No Deficiency to Be Assessed or to Be Paid](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760617152)
  - Exhibit  35.11.1-142  [Interim Assessments: Deficiency to Be Assessed or to Be Paid](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760601744)
  - Exhibit  35.11.1-143  [Interim Payment: Deficiency to Be Assessed](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760568736)
  - Exhibit  35.11.1-144  [Advance Payment: Fully Paid — Unassessed Payment](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760541184)
  - Exhibit  35.11.1-145  [Unassessed Payments](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760524336)
  - Exhibit  35.11.1-146  [Jeopardy Assessments: Paragraph Form of Decision](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760492320)
  - Exhibit  35.11.1-147  [Jeopardy Assessments: Tabular Form of Decision](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760472304)
  - Exhibit  35.11.1-148  [Jeopardy Assessments: Additional Deficiency to Be Assessed](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760445248)
  - Exhibit  35.11.1-149  [Jeopardy Assessments: Partial Payment — Excessive Assessment (Paragraph Form)](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760411696)
  - Exhibit  35.11.1-150  [Jeopardy Assessments: Partial Payment — Excessive Assessment (Tabular Form)](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760394192)
  - Exhibit  35.11.1-151  [Prior Unpaid Assessments](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760364768)
  - Exhibit  35.11.1-152  [Duplication of Liability Due From Transferor and/or Several Transferees](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760342208)
  - Exhibit  35.11.1-153  [No Transferee Liability: By Reason of Payment](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760321232)
  - Exhibit  35.11.1-154  [No Transferee Liability: Transferee of a Transferee](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760302464)
  - Exhibit  35.11.1-155  [Unlimited Transferee Liability: Single Tax — One Year](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760284800)
  - Exhibit  35.11.1-156  [Unlimited Transferee Liability: Single Tax for Several Years](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760268736)
  - Exhibit  35.11.1-157  [Unlimited Transferee Liability: Tax and Penalty — One Year](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760252640)
  - Exhibit  35.11.1-158  [Unlimited Transferee Liability: Taxes and Penalties — Several Years](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760236480)
  - Exhibit  35.11.1-159  [Limited Transferee Liability: One Tax and Single Transfer of Assets](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760210064)
  - Exhibit  35.11.1-160  [Limited Transferee Liability: Several Taxes, Penalties and Transfers of Assets](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760194048)
  - Exhibit  35.11.1-161  [Limited Transferee Liability: Deficiency and Unpaid Tax for One or More Years — Single Transfer of Assets](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760167520)
  - Exhibit  35.11.1-162  [Net Operating Losses: Tentative Net Operating Loss Not in Issue](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760151184)
  - Exhibit  35.11.1-163  [Net Operating Losses: Excessive Tentative Net Operating Loss Placed in Issue](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760126368)
  - Exhibit  35.11.1-164  [Net Operating Losses: Deficiency Prior to Net Operating Loss Carryback; Overpayment After Net Operating Loss Carryback](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760093120)
  - Exhibit  35.11.1-165  [Net Operating Losses: Overpayment Due Solely to Net Operating Loss Carryback — No Deficiency Prior to Carryback](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760052736)
  - Exhibit  35.11.1-166  [Net Operating Losses: Deficiency Both Before and After Net Operating Loss Carryback — No Carryback Claim Filed](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415760008944)
  - Exhibit  35.11.1-167  [Net Operating Losses: Overpayment Before and After Allowance for Net Operating Loss Carryback](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415759969392)
  - Exhibit  35.11.1-168  [Net Operating Losses: Deficiency Before and Overpayment After Net Operating Loss Carryback (Notice Sent under 6-Year Period of IRC § 6501(e) and Overpayment Based on Carryback Claim)](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415759924048)
  - Exhibit  35.11.1-169  [Motion to Stay Proceedings: Deficiency in Estate Tax (Extended Payment under IRC § 6161) — Stipulation](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415759877120)
  - Exhibit  35.11.1-170  [Motion to Stay Proceedings: Deficiency in Estate Tax (Extended Payment Under IRC § 6161) — Motion](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415759868368)
  - Exhibit  35.11.1-171  [Motion to Remove Small Tax Case Designation in a Collection Due Process Case](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415759856928)
  - Exhibit  35.11.1-172  [Failure to Pay Addition to Tax for Returns Prepared Under IRC § 6020(b)](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415759838832)
  - Exhibit  35.11.1-173  [Innocent Spouse Decision Documents: IRC § 6015(e)(1)(A) Cases — Denial IRC § 6015(e)](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415759791104)
  - Exhibit  35.11.1-174  [Innocent Spouse Decision Documents: IRC § 6015(e)(1)(A) Cases — Relief Granted in Full, No Overpayment](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415759727424)
  - Exhibit  35.11.1-175  [Innocent Spouse Decision Documents: IRC § 6015(e)(1)(A) Cases — Relief Granted in Full, Overpayment](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415759662368)
  - Exhibit  35.11.1-176  [Innocent Spouse Decision Documents: IRC § 6015(e)(1)(A) Cases — Partial Relief Granted, No Overpayment](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415759502032)
  - Exhibit  35.11.1-177  [Innocent Spouse — Decision Documents in Deficiency Cases Involving IRC § 6015 — Relief Denied in Full](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415759498208)
  - Exhibit  35.11.1-178  [Innocent Spouse — Decision Documents in Deficiency Cases Involving IRC § 6015 — Relief Granted in Full, No Overpayment](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415759436672)
  - Exhibit  35.11.1-179  [Innocent Spouse Decision Documents: IRC § 6015(e)(1)(A) Cases — Relief Granted in Part, No Overpayment — Joint Petitioners](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415759342112)
  - Exhibit  35.11.1-180  [Innocent Spouse Decision Documents: IRC § 6015(e)(1)(A) Cases — Relief Granted in Part, No Overpayment — One Petitioner](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415759251376)
  - Exhibit  35.11.1-181  [Employment Tax: Decision Document in Settled IRC § 7436 Case — IRC § 530 in Favor of Petitioner](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415759169008)
  - Exhibit  35.11.1-182  [Employment Tax: Decision Document in Settled IRC § 7436 Case — Employment Status Decision in Favor of Petitioner](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415759131392)
  - Exhibit  35.11.1-183  [Employment Tax: Decision Document in Settled IRC § 7436 Case — Decision in Favor of Respondent](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415759094224)
  - Exhibit  35.11.1-184  [Declaratory Judgement Cases: Retirement Plans](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415759007504)
  - Exhibit  35.11.1-185  [Declaratory Judgement Cases: Exempt Organizations](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758992288)
  - Exhibit  35.11.1-186  [TEFRA: Rule 248(a) Decision per Settlement — Tabular Format — TEFRA Partnership](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758962848)
  - Exhibit  35.11.1-187  [TEFRA Partnership: Rule 248(b) Motion for Entry of Decision, Certificate and Decision — Tax Matters Partner is a Participating Partner](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758898624)
  - Exhibit  35.11.1-188  [TEFRA Partnership: Rule 248(b) Motion for Entry of Decision, Certificate and Decision — Tax Matters Partner is not a Participating Partner](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758843472)
  - Exhibit  35.11.1-189  [TEFRA Partnership: Rule 248(b) Motion for Entry of Decision, Certificate and Decision — Cash Out-of-Pocket Settlements](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758791184)
  - Exhibit  35.11.1-190  [TEFRA Partnership: Rule 248(b) Cash Out-of-pocket Settlements — Sample Letter to TMP and Partners](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758776880)
  - Exhibit  35.11.1-191  [TEFRA Partnership: Notice Of Objection To Motion To Participate Out Of Time](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758755312)
  - Exhibit  35.11.1-192  [TEFRA Partnership: Motion to Appoint a Tax Matters Partner](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758742368)
  - Exhibit  35.11.1-193  [TEFRA Partnership: Penalty Only Affected Item — Decision Document](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758725584)
  - Exhibit  35.11.1-194  [Compromise by the Attorney General](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758706496)
  - Exhibit  35.11.1-195  [Adjudication by Another Court Having Concurrent Jurisdiction with Tax Court: Another Court Disposed of All Issues Pending in Tax Court](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758691856)
  - Exhibit  35.11.1-196  [Adjudication by Another Court Having Concurrent Jurisdiction with Tax Court: All Issues Before Tax Court Not Disposed of by Another Court](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758670416)
  - Exhibit  35.11.1-197  [Rule 155 Computation: Computation Face Sheet](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758642656)
  - Exhibit  35.11.1-198  [Rule 155 Computation: Proposed Decision](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758594608)
  - Exhibit  35.11.1-199  [Rule 155 Computation: Computation Statement — Tabular Form, Deficiency, Tax, Penalty, Husband and Wife, Joint and Several Liability, Separate Docket Numbers](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758545968)
  - Exhibit  35.11.1-200  [Rule 155 Computation: Computation Statement — Narrative Form, Deficiency, Tax, Penalty, Interim Assessment, Jeopardy Assessment, Overpayment](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758515680)
  - Exhibit  35.11.1-201  [Rule 155 Computation: Computation Statement — Overpayment of Tax and Penalty, Jeopardy Assessment](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758418544)
  - Exhibit  35.11.1-202  [Rule 155 Computation: Computation Statement — Transferee Liability, Computation for Transferor and/or Several Transferees Covering Duplication of Liability in Cases Before Court](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758360128)
  - Exhibit  35.11.1-203  [Rule 155 Computation: Computation Statement — Carryback, Overpayment](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758339760)
  - Exhibit  35.11.1-204  [Rule 155 Computation: Computation Statement — Estate Tax, State Estate Tax](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758280496)
  - Exhibit  35.11.1-205  [Rule 155 Computation: Computation Statement — Short Form, No Change in Amount of Deficiency/Computation from that Shown in Statutory Notice — No Overpayment Involved](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758259840)
  - Exhibit  35.11.1-206  [Rule 155 Computation: Computation Statement — Portion of Overpayment Barred Notice sent under 6-year period of IRC 6501(e)](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758236352)
  - Exhibit  35.11.1-207  [Award Data Sheet](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758193056)
  - Exhibit  35.11.1-208  [Payment Memorandum with Offset](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758153024)
  - Exhibit  35.11.1-209  [Payment Memorandum without Offset](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758125760)
  - Exhibit  35.11.1-210  [Collection Due Process Case: Stipulation of Facts Attaching Administrative Record](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758106368)
  - Exhibit  35.11.1-211  [Motion to Remand in a Collection Due Process Case](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758080752)
  - Exhibit  35.11.1-212  [Notice of Determination Addressing Only Tax Liability or Collection Issues Not Sustained](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758068240)
  - Exhibit  35.11.1-213  [Notice of Determination Addressing Only Tax Liability or Collection Issues Sustained in Full](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758032256)
  - Exhibit  35.11.1-214  [Notice of Determination Addressing Only Tax Liability or Collection Issues Sustained in Full if Collection Alternative Agreed to Outside CDP Case](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415758001456)
  - Exhibit  35.11.1-215  [Notice of Determination – Underlying Tax Properly at Issue and No Abuse of Discretion](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415757968752)
  - Exhibit  35.11.1-216  [Notice of Determination – Underlying Tax Not at Issue, but Adjusted and No Abuse of Discretion](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415757908208)
  - Exhibit  35.11.1-217  [Notice of Determination Addressing CDP Issues and Interest Abatement of No Abuse of Discretion in Denial of Abatement of Interest](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415757848512)
  - Exhibit  35.11.1-218  [Notice of Determination Addressing CDP Issues and Innocent Spouse Relief](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415757792800)
  - Exhibit  35.11.1-219  [Motion to Change Caption in Collection Due Process Case](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415757661776)
  - Exhibit  35.11.1-220  [Motion to Dismiss for Mootness in a Collection Due Process Case](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415757653152)
  - Exhibit  35.11.1-221  [Motion to Dismiss for Lack of Jurisdiction in a CDP Case, No CDP Notice of Determination (and No Notice of Deficiency or Other Determination Issued)](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415757641152)
  - Exhibit  35.11.1-222  [Motion to Dismiss for Lack of Jurisdiction in a CDP Case](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415757622032)
  - Exhibit  35.11.1-223  [Motion to Dismiss for Lack of Jurisdiction in a CDP Case, Invalid Notice of Determination](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415756938640)
  - Exhibit  35.11.1-224  [Motion to Dismiss for Lack of Jurisdiction in a CDP Case, Late-Filed Petition](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415756918304)
  - Exhibit  35.11.1-225  [Remand Memorandum to Appeals in a Collection Due Process Case](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415756908704)
  - Exhibit  35.11.1-226  [Motion for Summary Judgment in a CDP Case, IRC 6330(c)(2)(B)](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415756869136)
  - Exhibit  35.11.1-227  [Motion for Summary Judgment in a CDP Case, Abuse of Discretion Issues](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415756845168)
  - Exhibit  35.11.1-228  [Declaration in Support of Motion for Summary Judgment in a CDP Case](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415756821440)
  - Exhibit  35.11.1-229  [Motion to Permit Levy in a Collection Due Process Case](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415756784048)
  - Exhibit  35.11.1-230  [Motion in Limine in Collection Due Process Case](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415756767760)
  - Exhibit  35.11.1-231  [Answer — Affirmative Allegations: Civil Fraud Penalty — Collateral Estoppel of Certain Issues After a Criminal Conviction under IRC 7206(1)](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415756744928)
  - Exhibit  35.11.1-232  [Request For Translation](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415756727904)
  - Exhibit  35.11.1-233  [Sample Letter Accepting a Valid Qualified Offer](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415756686064)
  - Exhibit  35.11.1-234  [Sample Letter Rejecting a Valid Qualified Offer](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415756666352)
  - Exhibit  35.11.1-235  [Sample Letter Accepting an Offer that is Not a Qualified Offer because it Was Not Timely Made](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415756659360)
  - Exhibit  35.11.1-236  [Sample Letter Rejecting an Offer that is Not a Qualified Offer Because it Includes Interest](https://www.irs.gov/irm/part35/irm_35-011-001#idm140415756636288)

# Part 35. Chief Counsel Directives Manual Tax Court Litigation

# Chapter 11. Litigation Exhibits

# Section 1. Litigation Exhibits

* * *

## 35.11.1 Litigation Exhibits

#### Manual Transmittal

February 10, 2025

#### Purpose

(1) This transmits revised Exhibit CCDM 35.11.1, Litigation Exhibits.

#### Background

CCDM 35.11.1-30, Notice of Filing of Petition and Right to Intervene (Deceased Nonpetitioning Spouse), is revised to provide two updated templates of notices that may be filed with the Tax Court regarding notice of filing of a petition for relief from joint and several liability pursuant to I.R.C. § 6015 and the right of the nonpetitioning spouse to intervene when the nonpetitioning spouse is deceased.

#### Material Changes

(1) CCDM 35.11.1-30 is revised to provide templates of two notices to be filed with the Tax Court when the nonpetitioning spouse of a petitioner seeking relief from joint and several liability under I.R.C. § 6015 is deceased. The templates reflect the two approaches that respondent may take with respect to the heirs: (1) respondent provides notice to the court of the deceased nonpetitioning spouse’s heirs, and the court serves notice of the petition and right to intervene on the heirs; (2) respondent provides notice to the court of respondent’s compliance with the notice requirements of T.C. Rule 325(a) and**Fain v. Commissioner**, 129 T.C. 89 (2007) and provides notice of the petition and the right to intervene directly to the deceased nonpetitioning spouse’s heirs.

#### Effect on Other Documents

CCDM 35.11.1-30, dated February 28, 2014, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(02-10-2025)

Paul T. Butler

Associate Chief Counsel

(Procedure & Administration)

**35.11.1.1** **(08-02-2023)**

### Supplementary Material

1. This section provides sample motions, letters, memorandums, and other documents used in Counsel’s litigation practice as described in CCDM Parts 34 through 36. These exhibits have been consolidated into a single chapter for ease of use.


**Exhibit 35.11.1-1**

### Issues Requiring Associate Office Review

Certain issues listed below by respective Associate office require National Office review. An issue on the Associate office review list must be coordinated regardless of the stage of the case in which the issue arises ( _e.g._, whether in examination or in litigation). Coordination on these issues should be commenced at the earliest opportunity and well before litigation, if possible.

### Note:

With respect to “S” cases it is recognized that coordination might take place later than normally expected with regular cases, typically after they are returned from Appeals.

Advice issued to the client, briefs and motions filed with the Tax Court, and suit and defense letters sent to the Department of Justice must reflect positions consistent with Service legal positions and policies and uphold the office’s reputation for the highest quality of written product. In order to ensure these attributes, documents involving novel or significant issues contained on the Associate office review list will be reviewed in Associate offices before issuance or filing of the document. The Associate Chief Counsel and Division Counsel will consult regarding the prompt removal of any pre-review requirement once the Service’s position has become sufficiently established that pre-review is no longer necessary.

The issues list set forth below contains both generic and specific significant issues. Any issue included on either list must be coordinated with the affected Associate offices. Although some Associate offices may not have a specific issue list, coordination of generic significant issues with those offices is required and should be done at the earliest opportunity. Also refer to the Significant Case Program coordination procedures at CCDM 31.2.1.1 for additional guidance for additional items that may need to be coordinated with Division Counsel.

There are issues that do not require Associate office review. An issue not described in the generic or specific significant issues list is presumed not to require Associate office review. Court documents that contain no issues requiring Associate office review and that are not of a nature that requires Associate office review may be filed directly without Associate office review. Defense and suit letters that do not contain issues on this list may be sent to the Department of Justice without Associate office review regardless of their classification as Standard or S.O.P. See CCDM 34.8.1, Settlement Procedures Overview.

Even though a case does not contain any of the issues described below, novel, unusual, or unique questions may be presented. The Division Counsel office is expected to communicate informally with the appropriate Associate office when these issues arise. In some cases, the Associate office will want to review certain documents before they are filed or issued. It is the responsibility of the attorney and the reviewer in the Division Counsel office to identify those issues that warrant review by an Associate office and to forward the document for both pre-review and review according to current procedures. For those briefs, motions, and letters that are directly filed or sent to the Department of Justice by the Division Counsel office, it is the responsibility of the Division Counsel reviewer to ensure that they are correct factually and legally and of the highest quality. In addition, attorneys and reviewers in Division Counsel are still required to perform any necessary substantive issue coordination among Division Counsel offices pursuant to existing issue coordination procedures.

When an issue is identified as significant and requires coordination, it is the responsibility of the Division Counsel office to seek and the Associate offices to provide timely advice. All such requests, and any advice provided, should generally be in writing. Generally, the Division Counsel and Associate office attorneys will come to an agreement with respect to the timing of the advice that will be given, and if an agreement cannot be reached, then the issue should be elevated through the respective management chains. In exigent situations, such as an expiring statute of limitations or court deadline, the Division Counsel and Associate office attorneys should discuss the urgency for the advice, and the advice should be provided by the Associate office in sufficient time to take the appropriate action before the exigent event. If the advice is not timely sought by the Division Counsel office, or is not timely provided by the Associate office, the Division Counsel office may proceed with the proposed position subject to modifying or changing the position, as appropriate, to reflect the correct legal position after the advice request has been fully considered and coordinated. Before doing so, however, the Division Counsel office must notify the appropriate Associate office and their Division Counsel of their intent to do so. The attorney in the Associate office who receives such notice must promptly notify his or her Associate Chief Counsel of the Division Counsel office’s intent. The failure to timely seek or provide advice when circumstances would have permitted timely coordination is a performance issue that should occur only in rare circumstances. It should be addressed at the management level. This will typically require a post-filing review of the circumstances leading to the event and a discussion between the relevant Division Counsel and Associate Chief Counsel as to how to prevent a reoccurrence.

### Note:

The below list of issues, code sections, and documents requiring Associate office review is also contained in Exhibit 31.1.1-1.

**I. Generic Significant Issues that Require Associate Office Review with the Affected Associate Office**

An issue will be significant such that it requires relevant Associate office review regardless of the underlying code section or subject matter if it involves any of the following:

01. The validity of a regulation, temporary regulation, revenue ruling, revenue procedure, or other published guidance item (coordination with P&A also required).

02. An issue of importance to tax administration, such as:


     a. An issue of first impression;


     b. An interpretation of a statute or regulation when there have been no prior judicial opinions addressing the interpretation, including the Inflation Reduction Act, Pub. L. No. 117-169; and the Tax Cuts and Jobs Act, Pub. L. No. 115-97;


     c. An issue affecting large numbers of taxpayers or an industry; or


     d. An issue falling within an operating division’s major strategic goal.

03. An issue likely to attract congressional or public attention on a national level.

04. An issue where the Government attempts to distinguish a regulation, proposed regulation, temporary regulation, revenue ruling, or revenue procedure.

05. A position that is inconsistent with a proposed Treasury regulation.

06. A change in litigation position as identified in a Chief Counsel Notice.

07. An argument contrary to Chief Counsel advice.

08. Any statute or statutory amendment that has been enacted within the year preceding the filing date of the document or the due date of the letter to the Department of Justice.

09. Nonfrivolous constitutional challenges to statutes, regulations, published guidance or Service administrative practices or any nonfrivolous assertion of the application of the Religious Freedom Restoration Act. Examples of frivolous constitutional issues that need not be reviewed are contained in The Truth About Frivolous Tax Arguments that can be found at https://www.irs.gov/privacy-disclosure/the-truth-about-frivolous-tax-arguments-introduction.

10. Issues appearing on the current Priority Guidance Plan (PGP) of pending published guidance projects. The current PGP can be found at https://www.irs.gov/uac/priority-guidance-plan.

11. An issue considered for designation for litigation under CCDM 33.3.6, which is subject to the separate procedures under that section that control the coordination between the Division Counsel and Associate offices.

12. An issue that will not be referred to Appeals under Rev. Proc. 2016-22, 2016-15 I.R.B. 577, sec 3.03, for a technical tax reason, as opposed to a strategic or tactical reason involving the preparation and trial of the case, if the issue is otherwise considered significant.

13. Matters to be submitted to the Justice Department Office of Legal Counsel.


**II. Other Specific Issues Requiring Review by an Associate Office**

In addition to the foregoing issues, the following specific issues require review by an Associate office:

CNTA

1. Section 7803(a)(3) (execution of duties in accord with taxpayer rights).

2. Section 7803(c) (Office of the Taxpayer Advocate).

3. Section 7811, including the authority to issue a Taxpayer Assistance Order and the tolling of the statute of limitations.


Corporate

01. Section 267(f) (deferral of loss resulting from corporate related-party sales or exchanges).

02. Section 269 (acquisitions made to evade or avoid income tax).

03. Stock basis shifting transactions (for example, situations in which the seller shifts basis to a small number of remaining shares after a stock redemption or section 304 transaction).

04. Section 331/332/Granite Trust transaction, specifically situations in which 80% shareholder sells part of stockholdings to a related or accommodation party then engages in a section 331 liquidation.

05. Section 351 (formation of a corporation) with repatriation transaction.

06. Section 355 (spin off transactions), specifically:


     a. The device factor relating to nature and use of assets as described in Notice 2015-59;


     b. The weighing of significant device factors (other than pro rata distributions) with business purpose;


     c. Planned sales of stock after the transaction;


     d. Retention of Controlled corporation stock by the Distributing corporation after the transaction;


     e. Distribution of the stock of a Controlled corporation in a transaction potentially subject to section 355, and, as part of the same plan, the Distributing corporation or the Controlled corporation liquidates into or merges with the parent corporation or another related corporation (i.e., **drop-spin-liquidate** and **drop-spin-merge**);


     f. Delayed payments of debt or distributions to shareholders related to a spin off (i.e., delay in **boot purge** in a D/355);


     g. Spinoff transactions that are structured to allow the distributing group to claim losses on distribution but still qualify under section 355; or


     h. Distributing corporation debt to be retired with Controlled corporation securities.

07. Transactions that do not qualify under section 332 or section 355 but are intended to be tax-free reorganizations in reliance on §1.368-2(k) (e.g., corporate subsidiary elects to be a disregarded entity, distributes an appreciated asset to its parent, then elects to be taxed as a corporation or converts back into a corporation in the same state or in a different state).

08. Section 385 (debt v. equity) especially related party intercompany debt created or utilized as part of a larger structured transaction.

09. Section 482, specifically situations in which the parties involved are domestic.

10. Situations in which a subsidiary corporation, either directly or indirectly, owns stock of its parent (i.e., "hook" stock).

11. Situations in which an issuing corporation issues stock to its 100 percent shareholder that tracks the economic performance of a lower-tier entity (i.e., "tracking" stock), including any transactions in which the holder of the tracking stock claims an ordinary worthless stock loss under section 165(g)(3).

12. Intercompany debt transactions that inflate basis when debt is moved outside the consolidated group.

13. Situations relating to transactions involving Special Purpose Acquisition Companies (SPACs), including formation, acquisitions, capital raising, and wind-ups.

14. Situations in which a taxpayer uses nonqualified preferred stock (NQPS) as defined in section 351(g) to obtain benefits to which it otherwise would not be entitled.

15. A rescission of any or all of a corporate transaction pursuant to Rev. Rul. 80-58, 1980-1 C.B. 181.

16. Transactions under CC:CORP’s jurisdiction in which statutory economic substance and judicial doctrines (including economic substance, substance over form, and other common law doctrines) might be asserted.


Income Tax and Accounting

01. Section 36B refundable credit for coverage under a qualified health plan, limited to coordination when a case with an issue of first impression is nearing trial, including review of pretrial memorandums, motions for summary judgment, draft stipulations of facts, and briefs.

02. Section 61(a)(12), limited to issues involving whether a discharge or forgiveness of a liability is one for which the taxpayer did not receive a previously untaxed accession to wealth (for example, the taxpayer did not receive loan proceeds or the liability was under a guaranty, indemnity or similar agreement).

03. Section 108(a)(1)(B), limited to whether an interest in a retirement plan is an asset for purposes of applying the insolvency exclusion.

04. Section 162 limited to deductibility of a payment of a shareholder’s expenses in the context of a corporate reorganization or buyout and unreasonable compensation in the context of mergers or buyouts or golden parachute payments.

05. Section 163, limited to deductibility of mortgage interest following a foreclosure or short sale of the underlying property.

06. Section 170 charitable contribution deductions involving quid pro quo issues for contributions to churches or religious organizations.

07. Section 274(a), except where the issue is whether an activity constitutes entertainment, amusement, or recreation, or where the issue is the deductibility of country club dues; section 274(d), except where the substantiation issue is strictly factual; section 274(e); section 274(g); section 274(k); section 274 (l); section 274(m); and section 274(n).

08. Section 460, limited to issues involving (1) completion year in the case of a contract for the construction and sale of a home in a development, or (2) whether a real estate developer that constructs infrastructure and amenities, but not homes, qualifies for the home construction contract exemption.

09. Section 1400Z-2, regarding special rules for capital gains invested in Opportunity Zones.

10. Section 5000A requirements to maintain minimum essential coverage, where the shared responsibility payment is raised as an issue and not merely a computational adjustment, including the issue of whether it is an excise tax or penalty for purposes of bankruptcy priority, and decisions in deficiency cases that require below-the-line language due to an adjustment to the shared responsibility payment and involve an overpayment in tax.

11. Section 6055 reporting of health insurance coverage.

12. Issues involving digital assets, including virtual currency, digital currency, crypto-assets, and cryptocurrency, not addressed by Notice 2014-21 or other public guidance, involving novel issues or issues likely to attract national attention, unless the issue only involves substantiation.


International

01. Issues arising under international provisions of the Tax Cuts and Jobs Act (TCJA) and international issues arising under the Inflation Reduction Act of 2022 (IRA 22).

02. International aspects of the corporate alternative minimum tax (sections 55, 56A, and 59).

03. Issues arising under U.S. income tax treaties, estate and gift tax treaties, or other international agreements (including IGAs and TIEAs), and sections 894, 898 and 7852(d).

04. Issues arising under section 482 (transfer pricing) and related portions of section 6662(e).

05. Issues arising under section 367 or section 721(c) (other than routine issues).

06. Characterization and non-routine sourcing of income under Subchapter N.

07. U.S. nexus and related rules including trade or business, ECI and branch profits tax, and FIRPTA (sections 864, 872-875, 882-884, 897, 1445 and 1446) (other than ancillary computational issues or routine compliance issues).

08. Issues involving foreign governments (sections 892, 893, and 895).

09. Matters involving international shipping and air transport (sections 883, 887 and related international agreements (equivalent exemptions)).

10. Availability of and limitations on foreign tax credits (other than ancillary computational issues).

11. Non-routine matters involving controlled foreign corporations or their U.S. shareholders (sections 951-965) or PFICs or their U.S. shareholders (sections 1291-1298).

12. Foreign currency issues (other than translation issues) arising under sections 985-989.

13. Chapters 3 and 4 withholding on foreign persons and accounts (sections 871, 881, and 1441-1474).

14. Issues involving U.S. territories.

15. Non-routine issues involving the residence or expatriation of individuals (sections 877, 877A, and 7701(b)).

16. Issues involving the expatriation of corporations (section 7874) (other than ancillary computational issues).

17. International information gathering issues arising with respect to summonses issued pursuant to a tax treaty or other international agreement, quashes or enforcement of formal document requests (section 982), and enforcement of requests for foreign documents under section 6038A(e).

18. Contact with individuals physically located in a foreign jurisdiction, including requests for documents, interviews, depositions, or participation in formal or informal proceedings.

19. Non-routine issues involving dual consolidated losses (section 1503(d)).

20. Issues involving cross border debt equity (section 385).

21. Non-routine issues involving foreign trusts and foreign gifts (subchapter J and sections 6048, 6039F, and 6677).

22. Issues involving insurance excise tax (section 4371).

23. Economic substance and common law doctrines relating to international matters.


Passthroughs and Special Industries

01. A tax shelter that is a listed transaction within the description in Treas. Reg. §1.6011-4(b)(2). Issues concerning reportable transaction, partnership arguments and judicial doctrines. In the case of syndicated conservation easement transactions described in Notice 2017-10, 2017-4 I.R.B. 544, issues involving section 170 do not require Associate office review unless such transaction involves a novel, unusual, or unique question under section 170.

02. Valuation of interests in closely-held entities such as partnerships, S-corporations and LLCs.

03. Chapter 49 and sections 9008 and 9010 of the Affordable Care Act.

04. Sections 513, 543 and 613 regarding rents and royalties paid for oil and gas interests or whether payments to tax-exempt organizations constitute rent or royalties.

05. Sections 2501, and 2512, and Treas. Reg. § 25.6019-4 – the treatment of pecuniary (defined value) transfer clauses for gift tax purposes.

06. Sections 4001 through 4907 -excise taxes in chapters 31, 32, 33, 35, 36 subchapters B and D, 38, and 40.

07. Sections 6415, 6416, 6426, and 6427 – certain excise tax refunds and credits.

08. Treas. Reg. § 1.701-2 – Partnership Anti-Abuse Rule.

09. Estate and gift tax treatment of split-dollar life insurance agreements.

10. The treatment of taxes for valuation purposes, i.e., tax-affecting.

11. Section 199A except where the only issue is whether there is a trade or business under section 162.

12. The recharacterization of long term capital gains as short term capital gains under section 1061 with respect to certain partnership interests granted in connection with the performance of services.

13. Disguised fee for services under section 707(a)(2)(A).

14. Basis adjustments under sections 734(b), 743(b), or 732 resulting from a transfer of a partnership interest in a non-recognition transaction or distribution of partnership property involving related parties under section 267 and 707(b).


Procedure and Administration

01. The applicability of the Administrative Procedure Act.

02. Section 7421 (Anti-Injunction Act) – where a suit does not facially seek to enjoin a tax assessment or collection but a defense letter recommends asserting the AIA on the ground that that is the suit’s purpose in substance; or where a suit seeks to enjoin the exam process, such as the issuance of a summons.

03. Challenges to the jurisdictional nature of a statutory deadline or claims that a deadline is subject to equitable tolling.

04. The untimely filing of a petition in a CDP case (except when raised in answers, Rule 37(c) motions, and stipulated decisions sustaining the determination by Appeals).

05. Bankruptcy issues under 11 U.S.C § 523(a)(1)(B)(i) involving a Form 1040 filed after the due date.

06. Any suit letter recommending that the Government:


     a. Join with other creditors to commence an involuntary bankruptcy case against an individual, partnership, or corporation; or


     b. File an objection to confirmation under 11 U.S.C. § 1129(d) on the ground that the principal purpose of the plan is tax avoidance.

07. Injunction, mandamus, or declaratory judgment sought by the Government. Preparer/promoter injunction referrals and injunctions to prevent pyramiding, however, do not require Associate office review unless the case involves a novel substantive issue.

08. Novel privilege issues involving informants, including confidentiality, disclosure, third-party contacts, and the government informant’s privilege.

09. Sanctions officer issues, including misconduct on the part of Service employees or Division Counsel or opposing counsel, disqualification of counsel, recusal or disqualification of judges, referrals to the Office of Professional Responsibility, section 6673(a)(2) penalty against counsel for unreasonable or vexatious multiplication of proceedings in Tax Court or other ethical issues in litigation.

10. Any constitutional or conscience-based objections to the use of a Social Security Number (SSN) or Taxpayer Identification Number (TIN).

11. Novel issues related to same-sex marriage.

12. Protective orders:


     a. Any motion for protective order to be filed under T.C. Rule 103 and/or section 7461, except a routine protective order filed during whistleblower litigation, regardless of whether petitioner consents or opposes;


     b. Any proposed statement of agreement, consent, or "no objection" to the granting of a petitioner’s motion for protective order under T.C. Rule 103 and/or section 7461 (see CCDM 35.4.6.5); or


     c. Any motion for protective order with a covered entity as defined by 45 CFR § 160.103 of the HIPAA regulations, regardless of forum.

13. Disclosure issues - production of congressional materials in discovery and deliberative process privilege claims for records over 25 years old.

14. "Clawback" agreements and inadvertent production claims:


     a. Any proposed court order under Fed. R. Evid. 502(d) or non-waiver agreement under Fed. R. Evid. 502(e) that purports to protect from waiver any privilege other than the attorney-client privilege or the work product doctrine, or to modify the IRS’s obligation under section 6103; and


     b. Any demand for return of documents produced to the IRS in discovery on the ground that it was inadvertently produced privileged material pursuant to Fed. R. Civ. P. 26(b)(5) or any other rule or order of Court, where Chief Counsel is considering refusing to acquiesce in the demand.

15. Alternative dispute resolution – requests or agreements to seek arbitration or mediation in any docketed Tax Court cases.

16. Section 6015 – the effect on the allocation of a deficiency under section 6015(c) due to the tax benefits rule of section 6015(d)(3)(B); res judicata and meaningful participation under section 6015(g)(2); claims solely for relief from unpaid interest or penalties; untimely Tax Court petition (stand-alone cases); jurisdiction in the Federal district courts; and cases in which the trial attorney and manager believe that the evidence does not warrant following the Service’s determination to grant relief.

17. Section 6050W – requirement to file information returns for payment card and third party network payments on Form 1099-K, including penalties for failure to file and for filing incorrect returns.

18. Section 6109 – the issuance or use of individual taxpayer identification numbers (ITINs) after the effective date of section 203 of the PATH Act of 2015.

19. Sections 6221 through 6241 –


     a. The interpretation of or validity of an action taken under the centralized partnership audit regime enacted by the Bipartisan Budget Act of 2015 (sec. 1101 of the BBA).


     b. TEFRA: Foreign withholding under chapters 3 and 4.

20. Section 6306 – contracting for collection services.

21. Section 6330 and 6320 collection due process – briefs, motions, and other Tax Court documents raising novel or significant issues. Issues that are considered novel or significant include (but are not limited to):


     a. Challenges to the admission of evidence based on the administrative record rule;


     b. Whether challenges concerning validity of assessment, periods of limitation, or the application of payments and credits are liability issues under section 6330(c)(2)(B);


     c. Issues involving whether a notice of determination was issued in violation of the bankruptcy automatic stay; and


     d. Issues involving whether the untimely filing of a request for CDP hearing in Appeals or petition in Tax Court in response to a notice of determination is subject to equitable tolling.

22. Section 6332(d)(2) – penalty for failure to honor levy.

23. Section 6404(g) – Tax Court jurisdiction over interest suspension (Corbalis issue).

24. Sections 6601 and 6611 issues involving restricted interest; section 6621 issues involving the appropriate interest rate to be used; section 6621(d)(interest netting); Tax Court motions to redetermine interest; suits for additional overpayment interest filed in the Court of Federal Claims or District Court.

25. Section 6751(b) – issues concerning the timing of written supervisory approval of penalties where supervisory approval would not be timely under existing Tax Court precedent that is being challenged; and any other supervisory approval issue either not directly addressed by Tax Court precedent or on which Tax Court precedent is being challenged, (Graev/Chai/Clay issues).

26. Closing agreements (section 7121) involving novel or significant issues, such as:


     1\. Section 482 transfer pricing issues;


     2\. New partnership audit and adjustment provisions in Bipartisan Budget Act of 2015;


     3\. Delegation order challenges;


     4\. Consent to publicize a closing agreement.

27. Section 7345 – revocation or denial of passport.

28. Section 7430 – issues relating to section 7430; answers to petitions including requests for costs; any purported qualified offer; motions for costs; responses or briefs filed in opposition to taxpayers’ motions for costs; settlements of section 7430 claims regardless of whether authority for approval is required. For more specific coordination requirements in section 7430 matters, see CCDM 35.10.1.

29. Section 7602 – limited to designated summonses, John Doe summonses, summonses to third parties for foreign-based records (so-called Bank of Nova Scotia summonses), LB&I promoter summonses, summonses for audit or tax accrual workpapers, cases where section 7612, the Right to Financial Privacy Act or Health Insurance Portability and Accountability Act has been argued in a suit to enforce or quash summons, cases where the government advocates assertion of the tax shelter exception of section 7525(b).

30. Section 7623 whistleblower matters (including briefs, motions, and other Tax Court filings) involving novel or significant issues or any disclosure regarding the existense or identity of a whistleblower. Issues that are considered novel and significant include: non-routine privilege and taint issues, motions to compel information protected by section 6103, post-decision enforcement of protective orders, any arguments requiring an interpretation of the statute, and any arguments requiring an interpretation or application of the regulations.

31. Section 7701(o) – the application of the codified economic substance doctrine under section 7701(o) in novel cases.


Employment Taxes

01. Issues regarding scope of Additional Medicare Tax under FICA, RRTA, or SECA including decisions that contain language referencing the AdMT.

02. Section 107 – exclusion for parsonage or parsonage allowances.

03. Section 1402(a)(13) – whether any partner of a federal tax partnership (including state law LPs, LLCs, LLPs, etc.) is a limited partner for purposes of the exclusion from self-employment tax under section 1402(a)(13).

04. Sections 3131 – 3133 – issues involving leave credits for qualified sick and family leave wages under sections 3131 through 3133 of the Code or the FFCRA.

05. Issues involving credits allowed to self-employed individuals for qualified leave equivalent amounts as provided by the uncodified sections 7002 and 7004 of FFCRA or the uncodified sections 9642 and 9643 of ARP.

06. Section 3134 - issues involving the employee retention credit under section 3134 of the Code or section 2301 of the CARES Act.

07. Section 3231(e) – definition of "compensation" under RRTA.

08. Section 3401(d)(1) – issues regarding identification of employer in control of the payments of the wages.

09. Section 3504 – issues involving application of Treas. Reg. § 31.3504-2.

10. Section 3511 – determination of liability if a Certified Professional Employer Organization is involved.

11. Section 7705 – issues regarding CPEO certification, suspension or revocation.

12. Section 6432—issues involving the COBRA premium tax credit under the American Rescue Plan Act of 2021.

13. Issues involving the deferral of the employer portion of social security tax under section 2302 of the CARES Act.


Employee Plans/Qualified Plans/Executives & Nonqualified Deferred Compensation/IRAs

01. Section 72(t) – exceptions to the 10% additional tax.

02. Sections 401 through 418 – qualification issues for employee benefit plans involving diversion or misuse of plan assets, egregious failures relating to coverage, nondiscrimination, or benefit limitations, and deductions issues for employee benefit plans involving non-cash contributions.

03. Section 402/408 – failure to roll over within 60 days.

04. Section 409(l)(3) and 409(p) – issues involving preferred stock or synthetic equity.

05. Section 409A – issues involving nonqualified deferred compensation plans.

06. Section 414(e) – definition of a church plan.

07. Section 420 – transfer of excess pension assets to retiree health accounts.

08. Section 457A – issues involving nonqualified deferred compensation plans of nonqualified entities.

09. Section 457(b) - eligible deferred compensation plans.

10. Section 457(f) – ineligible deferred compensation.

11. Section 4971 – pension underfunding taxes in bankruptcy cases.

12. Section 4975 – issues involving prohibited transactions, including transaction involving qualified plans and individual retirement arrangements (IRAs).

13. Section 4980 - tax on reversions from a qualified pension plan when there is a transfer of 401(h) account assets (retiree medical account in the defined benefit plan) upon termination of a pension plan.

14. Section 4985 – excise tax on stock compensation on insiders of inverting corporations.


Health and Welfare Plans

01. Section 45R – employee health insurance expenses of small employer.

02. Section 51 – Work Opportunity Credit and controlled group rules under section 52.

03. Section 79 – issues involving group term life insurance plans utilizing cash value life insurance policies.

04. Section 501(c)(9) – voluntary employees’ beneficiary associations (VEBAs), but only issues involving multiple employer plans.

05. Section 512(a)(3)(E) – unrelated business taxable income (UBTI) for voluntary employees’ beneficiary associations (VEBAs).

06. Section 4976 – excise tax on welfare benefit funds providing a disqualified benefit.

07. Section 4980B – excise tax for failure to satisfy continuation coverage requirements of group health plans.

08. Section 4980D – excise tax for failure to meet certain group health plan requirements.

09. Section 4980H – shared responsibility payment for employers regarding health coverage.

10. Section 6056 – certain employers required to report on health insurance coverage.


Government Entities

1. Issues regarding identification of taxpayers as federal, state or local governments or Indian Tribal Governments.


Tax Exempt Organizations

01. Section 501(c)(3) – issues involving internet churches or schools.

02. Section 501(c)(3) – issues involving health maintenance organizations.

03. 501(c)(3) and 501(c)(4)—issues involving an accountable care organization’s initial or ongoing qualification as an organization described in section 501(c)(3) or 501(c)(4).

04. Sections 501(c)(3) and 511-514 – issues involving joint ventures or partnerships.

05. Sections 501(m) and 511-514 – issues involving commercial type insurance.

06. Section 501(r) – additional requirements for certain hospitals.

07. Section 509(a)(3) – issues involving whether supporting organizations satisfy the relationship test.

08. Section 512 – issues involving unrelated business taxable income (UBTI) and voluntary employee beneficiary associations (VEBAs).

09. Section 529A – Qualified ABLE Programs.

10. Section 4958 – excess benefit transaction issues involving indirect transactions, the rebuttable presumption, the interaction with the requirements for exemption, and interaction with section 4967 (taxes on prohibited benefits).

11. Section 4966—issues involving sponsoring organizations, donor-advised funds, and whether a distribution from a donor-advised fund is a taxable distribution.

12. Section 4967—whether a distribution results in one or more persons receiving a more than incidental benefit.


**Exhibit 35.11.1-2**

### Untitled

Former Exhibit 35.11.1-2, Direct Filing and Service of Documents, was combined with Exhibit 35.11.1-1 per Chief Counsel Notice CC-2014-005. Although Exhibit 35.11.1-2 was deleted, the exhibit number was retained so that all the exhibits that follow would not be re-numbered.

**Exhibit 35.11.1-3**

### Transfer of Cases and Coordination of Issues with Division Counsel/Associate Chief Counsel (TE/GE)

**TE/GE HAS JURISDICTION OVER TE/GE TAXPAYERS REGARDLESS OF THE ISSUES INVOLVED AND OVER TE/GE ISSUES REGARDLESS OF THE TAXPAYER INVOLVED**

This exhibit identifies the more common TE/GE issues and shows when SBSE and LB&I managers must transfer a case to TE/GE or coordinate with TE/GE in the assignment or handling of these issues.

(1) **IS THE TAXPAYER A TE/GE TAXPAYER?**

General rule: Regardless of the issues, if a case involves an employee plan (EP); exempt organization (EO); tax exempt bond (TEB); federal, state, local government (FSLG), or Indian tribal government (ITG) taxpayer, call the Area Counsel (TE/GE) office and transfer the case.

### Exception:

If a TE/GE taxpayer is in bankruptcy or is the subject of collection activity, do not transfer the case. Call the Area Counsel (TE/GE) office to coordinate case assignment or technical support.

(2) **IS THE TAXPAYER AN LB&I, SBSE, OR WI TAXPAYER WITH ONE OR MORE TE/GE ISSUES?**

General rule for sole issue: Transfer case to TE/GE if the sole issue is a TE/GE issue. The more common issues are shown below.

General rule for mixed issues: Call to coordinate if there are multiple issues with mixed non-TE/GE and TE/GE issues.

**_Exceptions:_**

1. _Employment Tax cases_: See WHETHER TO TRANSFER, COORDINATE OR SEEK TECHNICAL SUPPORT ON EMPLOYMENT TAX CASES.

2. _Earned Income Tax Credit (EITC) and Individual Retirement Account (IRA) regular cases_: Do not transfer. Call the Area Counsel (TE/GE) office to coordinate or for technical support.

3. _EITC and IRA "S" cases_: Do not transfer. There is no coordination requirement. The Area Counsel (TE/GE) office is available to provide technical support.


(3) **TE/GE ISSUES**

|  |
| --- |
| The following identifies the more common TE/GE issues and shows when SBSE and LB&I managers must transfer a case to TE/GE or coordinate with TE/GE on the assignment or handling of these issues. Consult the Code and Subject Matter Directory for a more complete list. If you have any questions on whether an issue is a TE/GE issue, call the Area Counsel (TE/GE) office to discuss. |
|  | a. Exempt Organizations |
|  |  | - Sections 501–509, 6033 EO exemptions and requirements<br>  <br>- §§ 511–514 UBIT<br>  <br>- §§ 527, 4911,4912,4955 political activities and lobbying<br>  <br>- § 529 qualified state tuition plans<br>  <br>- § 530 education IRAs<br>  <br>- §§ 4940–4948 private foundation excise taxes<br>  <br>- § 4958 intermediate sanctions<br>  <br>- § 6104 EO/EP disclosure<br>  <br>- § 7428 EO declaratory judgments<br>  <br>- § 7611 church audits<br>  <br>- § 277 certain coops<br>  <br>- Chapters 95 and 96 Presidential election campaign fund |
|  | b. Employee Plans |
|  |  | - Sections 401–418 qualification of employee benefit plans<br>  <br>- Funding<br>  <br>- Taxation of employer and employee contributions<br>  <br>- Taxation of distributions<br>  <br>- § 72(p) plan loans<br>  <br>- § 72(t) early plan distributions<br>  <br>- §§ 219, 408 SEPs, SIMPLEs<br>  <br>- § 457 plans for state and local governments and tax-exempt entities<br>  <br>- § 1042 sale of stock to ESOP or certain co-ops<br>  <br>- §§ 4971–4981A EP excise taxes<br>  <br>- § 7476 EP declaratory judgments |
|  | c. Executive Compensation |
|  |  | - Section 83 annuities and property transferred in connection with performance of services<br>  <br>- § 162 million dollar cap<br>  <br>- §§ 280G & 4999 golden parachutes<br>  <br>- §§ 421– 424 certain stock options<br>  <br>- § 451 nonqualified deferred compensation |
|  | d. Health & Welfare |
|  |  | - Section 79 group term life insurance<br>  <br>- §§ 104–105 (except § 104(a)(2)) compensation for injuries and sickness, accident and health plans<br>  <br>- §125 cafeteria plans<br>  <br>- §§ 419/419A funded welfare benefit plans<br>  <br>- § 501(c)(9) VEBAs<br>  <br>- § 4980B COBRA<br>  <br>- Chapter 98 HIPAA<br>  <br>- Chapter 99 coal industry health benefits |
|  | e. Tax Exempt Bonds |
|  |  | - Sections 103 & 141–150<br>  <br>- Tax-exempt bond issues can also arise under §§ 22, 25, 265(b), 1016(a)(6), 1394, 1397E, 1400A, 7871(c)<br>  <br>- § 7478 bond declaratory judgments |
|  | f. Employment Taxes |
|  |  | - Section 7436 worker classification/§ 530 cases. See below for whether to transfer, coordinate or seek technical support on other employment tax and fringe benefit issues (including § 132, § 119; and accountable plan issues) |

4) **WHETHER TO TRANSFER, COORDINATE OR SEEK TECHNICAL SUPPORT ON EMPLOYMENT TAX CASES**

|  |
| --- |
| a. Cases To Transfer To TE/GE |
|  | 1\. Section 7436 worker classification/§ 530 cases docketed in Tax Court |
|  |  | - Also includes procedural questions relating to Notice of Determination |
|  | 2\. Refund cases (including erroneous refund cases) involving only employment tax issues designated for coordination below |
| b. Call TE/GE To Coordinate |
|  | 1\. Worker classification - all docketed and nondocketed cases except docketed § 7436 cases |
|  |  | - Includes worker status; § 530; applicable tax rates; corporate officers; statutory employees<br>  <br>- Also includes individual cases in which deductions or liability for SECA (self-employment tax) turn on worker classification |
|  | 2\. Employee leasing/three party wage payment issues — docketed and nondocketed cases |
|  |  | - Includes which entity is employer; which entity must report, withhold, and deposit; payroll agents<br>  <br>- Excludes § 6672 cases (see below) |
|  | 3\. Wage issues — docketed and nondocketed cases |
|  |  | - Includes fringe benefits (such as §§132 and 119); accountable plan issues; back pay; deferred, stock-based, other executive compensation (§§83, 3121(v)) |
|  | 4\. Employment issues (§3121(b)) – docketed and nondocketed cases |
|  |  | - Excepted services, such as students, fishing crews, student nurses, certain government employment |
|  | 5\. Railroad retirement tax issues-docketed and nondocketed cases |
|  | 6\. Tips |
|  |  | - All aspects, including liability, reporting, initiatives and compliance projects |
|  | 7\. Military benefits - docketed and nondocketed cases |
|  | 8\. Parsonage allowances-docketed and nondocketed cases |
|  | 9\. Public Official status/fees |
|  | 10\. Limited liability company/partnership issues — docketed and nondocketed cases |
|  |  | - Applicability of SECA or FICA<br>  <br>- Which party is liable |
|  | 11\. Self-employment Tax (SECA) issues |
|  |  | - Status as independent contractor or employee<br>  <br>- Definition of self-employment income |
| c. Call TE/GE If Novel Issue Or If Technical Assistance Is Needed |
|  | 1\. SECA issues |
|  |  | - Reporting or computational issues |
|  | 2\. FICA, FUTA, RRTA reporting and deposits |
|  |  | - Includes applicable penalties<br>  <br>- Does not include issues concerning whether taxes apply (see above) |
|  | 3\. Section 6672 trust fund recovery penalty and § 3505 |
|  |  | - SBSE has primary jurisdiction |

**Exhibit 35.11.1-4**

### Jeopardy Assessment Cases — Notice of Jeopardy Assessment (Termination)

| **NOTICE OF JEOPARDY ASSESSMENT** |
| :-: |
| RESPONDENT NOTIFIES the Court, pursuant to the provisions of I.R.C. § 6861, that subsequent to issuance of the statutory notice of deficiency dated \[date\], upon which notice the above entitled case is based, jeopardy assessments of the deficiencies involved herein were made against petitioner on \[date\], for the years and in the respective amounts as follows: |
|  |
| Year | Income Tax | Additions to the Tax<br>I.R.C. § 6663(b) | Interest | Total |
| 2000 | $10,000.00 | $1,000.00 | $500.00 | $11,500.00 |
| 2001 | $20,000.00 | $2,000.00 | $1,000.00 | $23,000.00 |
|  |  |  |  |  |
|  | $30,000.00 | $3,000.00 | $1,500.00 | $34,500.00 |
|  |

\\_\\_\\_\_

### Note:

This form may also be used to give the Tax Court notice of section 6851 termination assessments.

**Exhibit 35.11.1-5**

### Jeopardy Assessment Cases — Notice of Partial Abatement of Jeopardy Assessment

| **NOTICE OF PARTIAL ABATEMENT OF JEOPARDY ASSESSMENT** |
| :-: |
| RESPONDENT NOTIFIES the Court, pursuant to the provisions of I.R.C. § 6861, that partial abatements of the amounts jeopardy assessed against petitioner on \[date\], which date was prior to the mailing of the statutory notice of deficiency on \[date 2\], upon which notice the above-entitled case is based, were allowed on \[date 3\], for the years and in the respective amounts as follows: |
|  | 2000 | 2001 |
| Income Tax: |
|  | Jeopardy Assessed<br> Abated<br> Balance Assessed | $5,000.00<br> $1,000.00<br> $4,000.00 | $10,000.00<br> $2,000.00<br> $8,000.00 |
| Interest: |
|  | Jeopardy Assessed<br> Abated<br> Balance Assessed | $600.00<br> $150.00<br> $450.00 | $600.00<br> $150.00<br> $450.00 |
|  |

\\_\\_\\_\_

### Note:

This form may also be used to give the Tax Court notice of section 6851 termination assessments

**Exhibit 35.11.1-6**

### Jeopardy Assessment Cases — Notice of Abatement of Jeopardy Assessment

| **NOTICE OF ABATEMENT OF JEOPARDY ASSESSMENT** |
| :-: |
| RESPONDENT NOTIFIES the Court, pursuant to the provisions of I.R.C. § 6861, that the jeopardy assessments made against petitioner on \[date\], which assessments were made subsequent to the mailing of the statutory notice of deficiency on \[date 2\], upon which notice the above-entitled case is based, and notice of which has previously been filed with the Court, were abated in full on \[date 3\], for the years and in the respective amounts as follows: |
|  | Tax Year Ended June 30, 2000 | Tax Year Ended June 30, 2001 |
| Income Tax: |
|  | Jeopardy Assessed<br> Abated<br> Balance Assessed | $5,000.00<br> $5,000.00<br> None | $10,000.00<br> $10,000.00<br> None |
| Interest: |
|  | Jeopardy Assessed<br> Abated<br> Balance Assessed | $ 600.00<br> $ 600.00<br> None | $ 600.00<br> $ 600.00<br> None |
|  |

\\_\\_\\_

### Note:

This form may also be used to give the Tax Court notice of section 6851 termination assessments.

**Exhibit 35.11.1-7**

### Munro Stipulation for Deficiency Cases

|  |
| --- |
| **STIPULATION** |
| It is hereby stipulated: |
| 1\. Petitioner(s) reported certain items on the \[year\] income tax return related to the investment in \[partnership name\] |
| 2\. \[Partnership name\] is a partnership which is subject to the unified partnership audit and litigation procedures set forth In I.R.C. §§ 6221 _et seq_. (TEFRA partnership procedures) . |
| 3\. For purposes of computing the deficiency \[or overpayment\] in this case, petitioner's partnership items relating to \[partnership name\] have been treated as if they were correctly reported on petitioner's income tax returns for the \[taxable year(s)\] and they have not been adjusted as part of this docketed proceeding. |
| 4\. The tax treatment of petitioner's partnership items relating to \[partnership name\] will be resolved in a separate partnership proceeding conducted in accordance with the TEFRA partnership procedures. |
| 5\. The adjustments necessary to apply the results of the TEFRA partnership proceeding described in subparagraph 4 to petitioner, shall be treated as computational adjustments under I.R.C. § 6231(a) (6) and assessed, credited or refunded accordingly. |
| 6\. To the extent that the computation of petitioner's tax liability which properly reflects the tax treatment of the partnership items relating to \[partnership name\], as determined in the TEFRA partnership proceeding described in subparagraph 4, would also result in a change in petitioner's tax liability attributable to nonpartnership items, as previously determined in this docketed proceeding, such change may be treated as a computational adjustment under I.R.C. § 6231(a) (6) and assessed, credited or refunded accordingly. |
| 7\. Petitioner waives any restrictions on assessment or overpayment imposed by I.R.C. §§ 6501, 6511 or 6512, with respect to any assessment, credit or refund described in subparagraph 6, provided such assessment, credit or refund is made within the time period provided for computational adjustments under I.R.C. § 6231 (a) (6) . |

**Exhibit 35.11.1-8**

### Motion for Leave to File an Amendment to Answer — Munro — Increased Deficiency and Increased Penalties

|  |
| --- |
| **MOTION FOR LEAVE TO FILE AMENDMENT TO ANSWER** |

RESPONDENT MOVES, pursuant to Rule 41(a) of the Tax Court's Rules of Practice and Procedure, for leave to file an amendment to answer to seek an increased deficiency and increased additions to tax under the provisions of I.R.C. § 6214(a).

IN SUPPORT THEREOF, respondent respectfully states:

1\. The petition in this case was filed with the Court on \[date\].

2\. The answer to that petition was filed on \[date\].

3\. During the \[year\] taxable year, the year at issue in the instant case, petitioner was a partner in \[name of partnership\], and reported items attributable to \[name of partnership\] on the Federal income tax return (Form 1040) for that year.

4\. \[Name of partnership\] is a TEFRA partnership for the \[year\] taxable year. Accordingly. the tax treatment of the partnership items attributable to \[name of partnership\] for the \[year\] taxable year must be determined at the partnership level pursuant to I.R.C. §§ 6221-6234.

5\. A notice of final partnership administrative adjustment was mailed to the tax matters partner of \[name of partnership\] with respect to the \[year\] taxable year on \[date\]. A petition for readjustment of partnership items was filed in this Court in response to that notice and assigned docket number \[docket no.\].

6\. The notice of deficiency that forms the basis for the instant case was prepared by assuming that petitioner correctly reported his distributive share of partnership items attributable to \[name of partnership\] on the \[year\] Federal income tax return.

7\. In Munro v. Commissioner, 92 T.C. 71 (1989), this Court held that the partnership items (whether income, loss, deduction or credits) included on a taxpayer's return should be completely ignored in determining whether a deficiency exists that is attributable to nonpartnership items. Moreover, the Court ruled that the Service may not assume the correctness of its proposed adjustments to partnership items for computational purposes in determining a deficiency, and taxpayers may not offset net partnership losses against their taxable income for purposes of deficiency proceedings.

8\. The deficiency and additions to tax in the instant case have been recomputed in accordance with the _Munro_ opinion. As a result of this recomputation, it has been determined that the correct amount of the deficiency should be $ \[amount\] rather than $ \[amount\] and the correct amount of the addition to tax under I.R.C. § 6662(b) (1) should be $ \[amount\] rather than $ \[amount\].

9\. Respondent is lodging an amendment to answer concurrently herewith that seeks an increased deficiency in the amount of $ \[amount\] and an increase in the addition to tax under I.R.C. § 6662(b) (1) in the amount of $ \[amount\], claim for which is being made under the provisions of I.R.C. § 6214(a).

10\. The increased deficiency and increased additions to tax referred to in paragraph 9, above, are solely attributable to the recomputation that was required in order to comply with this Court's opinion in Munro. Accordingly, petitioner will not suffer any undue prejudice as a result of the amendment to answer, since no new theories or issues are being raised and no additional evidence will have to be introduced; the increases in question are purely computational.

11\. This matter has been discussed with petitioner's counsel, who has indicated that he objects to the granting of this motion.

WHEREFORE, respondent respectfully requests that this motion be granted, and that the amendment to answer, which is being lodged concurrently herewith, be filed.

\\_\\_\\_\_

\\_\\_\\_\_

### Note:

The above motion must be forwarded to Procedure and Administration for review prior to being filed with the court.

**Exhibit 35.11.1-9**

### Answer — Petitioner's Burden of Proof: Complete Admissions and Denials

| **ANSWER** |
| :-: |
| RESPONDENT, in answer to the petition filed in the above entitled case, admits and denies as follows: |
| I., 2., and 3. Admits. |
| 4\. and 5. Denies. |
| 6\. Denies each and every allegation of the petition not herein before specifically admitted, qualified or denied. |
| WHEREFORE, it is prayed that respondent's determination, as set forth in the notice of deficiency, be in all respects approved. |

**Exhibit 35.11.1-10**

### Answer — Petitioner's Burden of Proof: Qualified Admissions and Denials

| **ANSWER** |
| :-: |
| RESPONDENT, in answer to the petition filed in the above entitled case, admits, denies and alleges as follows: |
| 1\. Admits, but alleges that petitioner resides at \[correct address\] not \[address as written by petitioner\]. |
| 2\. Admits. |
| 3\. Denies, except admits that respondent determined a deficiency in income tax for the tax year \[year\] in the amount of $ \[amount\], all of which is in dispute. |
| 4\. (a) through (g), inclusive. Denies. |
| 5\. (a) Admits.<br> (b) Denies, except admits that petitioner received $ \[amount\] from his employer, \[name\].<br> (c) Admits, except denies the second sentence for lack of sufficient information.<br> (d) Denies, but alleges that petitioner's employer, \[name\], paid such $ \[amount} as additional compensation to petitioner on \[date\].<br> (e) Denies, except admits the third and fourth sentences.<br> (f) and (g) Denies. |\
| 6\. First unnumbered and unlettered paragraph following paragraph 5 (g), denies, except admits the second sentence. |\
| 7\. Denies generally each and every allegation of the petition not hereinbefore specifically admitted, qualified or denied. |\
| WHEREFORE, it is prayed that respondent's determination, as set forth in the notice of deficiency, be in all respects approved. |\
\
**Exhibit 35.11.1-11**\
\
### Answer — Petitioner's Burden of Proof: Unnumbered and/or Unlettered Paragraphs\
\
| **ANSWER** |\
| :-: |\
| RESPONDENT, in answer to the petition filed in the above entitled case, admits, denies and alleges as follows: |\
| 1\. First unnumbered paragraph on page 1, admits. |\
| 2\. Second unnumbered paragraph on page 1, admits, except denies that the notice of deficiency was arbitrarily and capriciously issued. |\
| 3\. Third unnumbered paragraph beginning on page 1, admits, except alleges the amount in dispute is $ \[amount\] and not $ \[amount in petition\]. |\
| 4\. First through third unnumbered paragraphs beginning on page 2, admits. |\
| 5\. Fourth unnumbered paragraph beginning on page 2, denies. |\
| 6\. First unnumbered paragraph beginning on page 3, admits. |\
| 7\. Second unnumbered paragraph beginning on page 3, first two sentences, admits. |\
| 8\. Third sentence of the second unnumbered paragraph beginning on page 3, denies, but alleges the revenue agent used an indirect method of computing cost of sales in the absence of adequate records. |\
| 9\. Denies generally each and every allegation of the petition not hereinbefore specifically admitted, qualified or denied. |\
| WHEREFORE, it is prayed that respondent's determination, as set forth in the notice of deficiency, be in all respects approved. |\
\
**Exhibit 35.11.1-12**\
\
### Answer — Affirmative Allegations: Statute of Limitations — Fraud as Defense\
\
8\. FURTHER ANSWERING the petition, and as a defense that the statute of limitations does not bar the assessment and collection of deficiencies in income taxes due from petitioners for the taxable years \[year(s)\], respondent alleges:\
\
(a) The income taxes due from petitioners for the taxable years \[year(s)\], may be assessed, or a proceeding in Court for the collection of such tax may be begun without assessment, at any time under the provisions of I.R.C. § 6501(c) (1), since petitioners filed false or fraudulent income tax returns for said years with intent to evade tax, as is more fully set forth by the facts alleged in paragraph 7 above, which facts are incorporated herein by reference and relied upon by the respondent as a defense to any issue involving the statute of limitations.\
\
**Exhibit 35.11.1-13**\
\
### Answer — Affirmative Allegations: Statute of Limitations — 25% Omission as Defense\
\
8\. FURTHER ANSWERING the petition with respect to the tax year \[year\], the income taxes due from petitioners are not barred from assessment and collection by the statute of limitations and may be timely assessed pursuant to the provisions of I.R.C. § 6501(e) (1) (A), in support of which respondent alleges as follows:\
\
(a) Petitioners' income tax return for the taxable year \[year\] was filed on \[date\].\
\
(b) The amount of gross income stated in the income tax return filed by petitioners for the taxable year \[date\] and one half of the amount of gross income incorporated by reference from the \[name\] partnership consists of a total of $ \[amount\] reported as follows:\
\
|  |\
| --- |\
|  | Gross Receipts — Partnership (1/2) | $ \[amount\] |\
|  | Gross Receipts — Schedule C | $ \[amount\] |\
|  | Wages | $ \[amount\] |\
|  | Interest Income | $ \[amount\] |\
|  | Gross Income Reported | $ \[amount\] |\
\
(c) During the taxable year \[year\], petitioners received additional income of $ \[amount\] as determined by use of the net worth method, as set forth in attached Exhibit A, which is incorporated herein by reference and made a part hereof. This amount of additional income was not included in the gross income stated in the return filed by petitioners for this year, and there was not disclosed on the return or in a statement attached thereto the fact that such amount was received during said year.\
\
(d) Petitioners during the taxable year \[year\], did not borrow or receive from nontaxable sources any funds, or other assets, not properly taken into account by the respondent which would cause or account for the additional income as set forth in paragraph 8(c) above.\
\
(e) The additional income of $ \[amount\] which petitioners received was properly includable in gross income for the taxable year \[year\].\
\
(f) The $ \[amount\] of gross income which petitioners received and which was omitted from the income tax return filed by petitioners for the taxable year \[year\] is in excess of 25 percent of the gross income reported in said return.\
\
(g) The statutory notice of deficiency setting forth the respondent's determination of petitioners' deficiency for the taxable year \[year\] was timely sent to petitioners by certified mail on \[date\], which date was prior to the expiration of the six-year period for assessment applicable under I.R.C. § 6501 (e) (1) (A).\
\
WHEREFORE, it is prayed that the assessment and collection of the deficiency for the taxable year \[year\], as set forth in the statutory notice, is not barred by the statute of limitations.\
\
**Exhibit 35.11.1-14**\
\
### Answer – Affirmative Allegations: Statute of Limitations — Delinquency as Defense\
\
8\. FURTHER ANSWERING the petition with respect to the tax years \[date(s)\], the income taxes due from petitioners are not barred from assessment and collection by the statute of limitations and may be timely assessed pursuant to the provisions of I.R.C. § 6501(a), in support of which respondent alleges as follows:\
\
(a) Petitioners' income tax return for the taxable year \[year\] was due to be filed on or before April 15, \[year\].\
\
(b) Petitioners' income tax return for the taxable year \[year\] was due to be filed on or before April 15, \[year\].\
\
(c) Examination of petitioners' \[year\] return, filed \[date\], was begun in \[month, year\].\
\
(d) Respondent, when the examination began, had no record of any filing of income tax returns by petitioners for the taxable years \[year(s)\]\
\
(e) Copies of petitioners' \[year(s)\] income tax returns, dated \[date(s)\], respectively, were accepted for filing on \[date\].\
\
(f) The statutory notice of deficiency setting forth respondent's determination of petitioners' income tax deficiencies for the taxable years \[year(s)\] was timely sent to petitioners by certified mail on \[date\], which date was prior to the expiration of the three-year period for assessment applicable under I.R.C. § 6501(a).\
\
WHEREFORE, it is prayed that the assessment and collection of the deficiencies for the taxable years \[year(s)\], as set forth in the statutory notice, are not barred by the statute of limitations.\
\
**Exhibit 35.11.1-15**\
\
### Answer — Affirmative Allegations: Statute of Limitations — Waivers or Consents as Defense\
\
8\. FURTHER ANSWERING the petition and as a defense that the statute of limitations does not bar assessment and collection of an income tax deficiency for the taxable year \[date\], which deficiency may be timely assessed under the provisions of I.R.C. § 6501(c) (4), respondent alleges as follows:\
\
(a) Petitioner's income tax return for the taxable year \[year\] ,was filed on \[date\].\
\
(b) Prior to the expiration of the time prescribed by section 6501(a) for the assessment of income tax due from petitioner for the taxable year \[year\], petitioner and the respondent on \[date\], timely executed an agreement in writing pursuant to the provisions of section I.R.C. § 6501(c) (4) extending the period for the assessment of tax due for said year to \[date\].\
\
(c) The statutory notice of deficiency setting forth respondent's determination of petitioner's income tax liability for the taxable year \[year\], was timely sent to petitioner by certified mail on \[date\], which date was prior to the expiration of the period for assessment as duly and timely extended under the agreement in writing executed by both petitioner and the respondent.\
\
WHEREFORE, it is prayed:\
\
(1) That the relief sought in the petition be denied;\
\
(2) That the deficiency in income tax for the taxable year \[year\], as set forth in the statutory notice, be in all respects approved; and\
\
(3) That the Court determine that the assessment and collection of the deficiency in income tax for the taxable year \[date\], as set forth in the statutory notice, are not barred by the statute of limitations.\
\
**Exhibit 35.11.1-16**\
\
### Answer — Affirmative Allegations: Statute of Limitations — Waivers or Forms 872A as Defense\
\
8\. FURTHER ANSWERING the petition, and as a defense to the assignment of error that the statute of limitations bars the assessment and collection of the deficiencies in income taxes due from petitioners for the years 2000 through 2003, respondent alleges:\
\
a. Petitioners' income tax returns for the taxable years 2000 through 2003 were filed on April IS, 2001, August 4, 2002, June 19, 2003, and July 3, 2004, respectively.\
\
b. Prior to the expiration of the time prescribed by I.R.C. § 6501(a) for the assessment of income tax due from petitioners for each of the taxable years 2000 through 2003, petitioners and respondent timely executed agreements in writing pursuant to the provisions of section 6501(c) (4) as follows:\
\
|  |\
| --- |\
|  | Date Executed by: |  |\
| Year | Form No. | Title | Respondent | Petitioners | Statute Extended To |\
| 2000 | 872 | Consent Fixing Period of Assessment | 2/14/03 | 2/21/03 | 6/30/04 |\
| 2001 | 872 | Consent To Extend Time To Assess Tax | 1/24/04 | 3/11/04 | 12/31/07 |\
| 2001 | 872-A | Special Consent To Extend Time To Assess Tax | 5/7/06 | 7/20/06 | N/A |\
| 2002 | 872 | Consent To Extend | 7/18/04 | 7/22/04 | 12/3/06 |\
\
Copies of these agreements are attached hereto marked Exhibits A, B, C, D, E, F, G, and H, respectively,\
\
c. The agreements titled Special Consents to Extend Time in Which to Assess Tax, which are described in subparagraph b, provide that amount of federal income tax due on any return made by petitioners for the taxable year covered by the agreement may be assessed on or before the 90th day after: (a) the Internal Revenue Service office considering the case receives Form 872-T, Notice of Termination of Special Consent to Extend the Time to Assess Tax, from petitioners; or (b) the Internal Revenue Service mails Form 872-T to petitioners; or (c) the Internal Revenue Service mails a notice of deficiency for the taxable year covered by the agreement. Each agreement further provides that if a notice of deficiency is sent to petitioners, the time for assessing the tax for the period(s) stated in the notice of deficiency will end 60 days after the period during which the making of an assessment was prohibited.\
\
d. The Internal Revenue Service has not received a Form 872-T from petitioners and has not mailed a Form 872-T to petitioners.\
\
e. The statutory notice of deficiency setting forth the respondent's determination of petitioners' income tax liabilities for the taxable years 2000 through 2003, upon which notice the above-entitled case is based, was sent to petitioners by certified mail on \[date\], which date was prior to the expiration of the time for assessment for each of the taxable years 2000 through 2003, as duly and timely extended under the agreements in writing executed by both petitioners and respondent.\
\
WHEREFORE, it is prayed:\
\
(1) That the relief sought in the petition be denied;\
\
(2) That the deficiencies in income tax for the taxable years 2000 through 2003, as set forth in the statutory notice, be in all respects approved; and\
\
(3) That the Court determine that the assessment and collection of the deficiencies in income taxes for the years 2000 through 2003, as set forth in the statutory notice, are not barred by the statute of limitations.\
\
**Exhibit 35.11.1-17**\
\
### Answer — Collateral Estoppel — General\
\
8\. FURTHER ANSWERING the petition in respect to respondent's determination that the petitioner \[insert description as to the fraud committed by petitioner\], respondent affirmatively relies upon the doctrine of collateral estoppel, and alleges:\
\
a. Petitioner is the same person who was the defendant in a criminal case of the United States v. \[petitioner's name\], No. \[case no.\], in the United States District Court for the District of \[location\].\
\
b. Respondent is a party in privity with the United States of America, the prosecuting party in the aforesaid criminal case in which petitioner was a defendant.\
\
c. \[Insert facts as to on what counts petitioner was indicted.\] A copy of the indictment is attached as Exhibit A.\
\
d. \[Insert facts as to what the indictment charged.\]\
\
e. On \[date\], the United States District Court for the District of \[location\], following a trial by jury, entered a judgment of guilty as to each count. This judgment has become final.\
\
f. An issue in the instant Tax Court case is whether taxpayer received any income in excess of his salary in the year \[year\].\
\
g. The fact that taxpayer received income illegally (combined with his failure to report such income) is evidence that a part of his underpayment of the tax was due to fraud.\
\
h. The issue of receiving illegal income was presented and adjudicated adversely to petitioner in the District Court case.\
\
i. The prior criminal conviction of petitioner is conclusive and binding upon petitioner, and by reason thereof the petitioner is estopped in this case, under the doctrine of collateral estoppel, to deny that he received additional income in \[year\] and that the income was received as a result of his fraudulent actions against the United States.\
\
WHEREFORE, it is prayed:\
\
1\. That the relief sought in the petition be denied\
\
2\. That the deficiency in income tax for the taxable year \[year\] as set forth in the statutory notice of deficiency be in all respects approved\
\
3\. That the addition to tax for the taxable year \[year\] under the provisions of I.R.C. § 6663(a) as set forth in the statutory notice of deficiency be in all respects approved and\
\
4\. That the Court determine that petitioner is estopped, under the doctrine of collateral estoppel, to deny that he received income in excess of his reported salary in the year \[year\] and that such income was received as the result of petitioner's illegal activity.\
\
**Exhibit 35.11.1-18**\
\
### Answer — Affirmative Allegations: Fraud — Bank Deposit Method\
\
|  |\
| --- |\
| 8\. FURTHER ANSWERING the petition and in support of the determination that a part of the underpayments of tax required to be shown on petitioners' income tax returns for the taxable years \[year(s)\] is due to fraud, respondent alleges: |\
| (a) Petitioner (husband) is a \[occupation\] |\
| (b) Petitioner (wife) is a \[occupation\]. |\
| (c) During the taxable years \[year(s)\] petitioners received unreported taxable income from the business activities of petitioner (wife). |\
| (d) Petitioners failed to maintain, or to submit for examination by the respondent, complete and adequate books and accounts of their income producing activities for each of the taxable years \[year(s)\], as required by the applicable provisions of the Internal Revenue Code and the regulations promulgated thereunder. |\
| (e) Respondent has determined petitioners' correct adjusted gross income for the taxable years \[year(s)\] on the basis of the bank deposits method. |\
| (f) During the taxable years \[year(s)\], petitioners maintained personal checking account # \[account number\] in the \[name of bank\] and made deposits in such account in the total amounts of $ \[amounts\], respectively, during such taxable years. |\
| (g) During the taxable years \[year(s)\], petitioners maintained checking account # \[account 2\] titled \[name of account\] in the \[name of bank\], and made deposits in such account in the total amounts of $ \[amounts\], respectively, during such taxable years. |\
| (h) During the taxable years \[year(s)\] petitioners total deposits into their bank accounts were as follows: |\
| Account # \[account 1\]<br> Account # \[account 2\]<br> Total bank deposits | \[year 1\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[total 1\] | \[year 2\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[total 2\] |\
| (i) During the taxable years \[year(s)\] petitioners' reduction in total deposits in their bank accounts for amounts attributable to nontaxable sources was as follows: |\
| IRS refund \[date\]<br> Automobile deposit refunded<br> Debit memos<br> Withdrawals — Credit Union<br> Refund — FICA Overpayment<br> Loans<br> Checks cashed<br> Transfers<br> Reductions for nontaxable sources | \[year 1\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\] | \[year 2\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\] |\
| (j) During the taxable years \[year(s)\] petitioners' net taxable deposits into their bank accounts were as follows: |\
| Total bank deposits<br> Less: reduction for nontaxable sources<br> Net taxable deposits | \[year 1\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\] | \[year 2\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\] |\
| (k) The copies of petitioners' returns for the taxable years \[year(s)\] reflect that petitioners reported the following income items: |\
| Wages: Net of income tax<br> FICA withholding<br> Schedule C gross receipts<br> Partnership income<br> Interest income<br> As reported | \[year 1\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\] | \[year 2\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\] |\
| (l) The unreported adjusted gross income of petitioners for the taxable years \[year(s)\] as summarized from the allegations contained in subparagraphs (h) through (k) of this paragraph are as follows: |\
| Total bank deposits<br> Less: reductions for nontaxable sources<br> Net taxable deposits<br> Less: amount reported<br> Unreported adjusted gross income | \[year 1\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\] | \[year 2\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\] |\
| (m) Petitioners during the taxable year \[year(s)\] did not receive any nontaxable or excludable income, receipts, cash, or other assets other than the specific items and amounts thereof described in paragraphs 7(h) through 7(l)above. |\
| (n) Petitioners during the taxable years \[year(s)\] did not receive any gifts, inheritances, legacies, or devises. |\
| (o) Petitioners' failure to maintain complete and accurate records of their income-producing activities and their failure to produce complete and accurate records to respondent in connection with the examination of petitioner's income tax returns for the taxable years \[year(s)\] was fraudulent with intent to evade tax. |\
| (p) Petitioners fraudulently and with intent to evade tax made false and misleading statements to respondent's agents during the examination of petitioners' income tax returns for the years \[year(s)\]. |\
| (q) Petitioner (wife), in holding herself out to the public as providing tax return preparation and financial accounting services, was fully aware of the requirement to file federal income tax returns on time. |\
| (r) Petitioners fraudulently and with intent to evade tax failed to timely file their federal income tax returns for the taxable years \[year(s)\]. |\
| (s) Petitioners fraudulently and with intent to evade tax, omitted from their income tax returns for the taxable years \[year(s)\] amounts of income as follows: |\
| Unreported income | \[year 1\]<br> $ \[amount\] | \[year 2\]<br> $ \[amount\] |\
| (t) Petitioners fraudulently and with intent to evade tax, understated their income tax liability on their \[year(s)\] returns as follows: |\
| Corrected tax liability<br> Add: self-employment tax<br> Total corrected liability<br> Less: tax shown on return or as previously adjusted<br> Understatement of tax | \[year 1\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\] | \[year 2\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\] |\
| (u) A part of the underpayment of tax required to be shown on petitioners' returns for each of the taxable years \[year(s)\] is due to fraud. |\
| WHEREFORE, it is prayed: |\
| (1) That the relief sought in the petition be denied; |\
| (2) That the deficiencies in income tax for the taxable years \[year(s)J, as set forth in the statutory notice, be in all respects approved; |\
| (3) That the additions to tax for the taxable years \[year(s)\] under the provisions of I.R.C. § 6663(a), as set forth in the statutory notice, be in all respects approved. |\
\
**Exhibit 35.11.1-19**\
\
### Answer — Affirmative Allegations: Fraud — Net Worth Method\
\
8\. FURTHER ANSWERING THE PETITION, and in support of the determination that the underpayment of tax required to be shown on each of petitioners' income tax returns for the taxable years \[year(s)\], is due to fraud, respondent alleges:\
\
(a) \[Name\], hereinafter referred to as petitioner, was a \[occupation/position\] herein. in \[company\] in each of the years at issue\
\
(b) In \[year\] petitioner's father, \[name\], relinquished control of \[company\] to his sons with petitioner becoming President.\
\
(c) The business activity of \[company\] was that of \[specify\].\
\
(d) Petitioner diverted \[specify\] from the inventory of \[company\] for the purposes of making illegal unrecorded cash sales of \[specify\] for his personal benefit in each of the years \[year(s)\]\
\
(e) Petitioner caused substantial cash sums generated from his illegal sales to be deposited to the business bank account of \[company\] during the years at issue herein and directed the accountant of \[company\] to credit the purchases account in an attempt to cover up his diversion and illegal sale of \[specify\]\
\
(f) Petitioner maintained no sales invoices or other records relating to his illegal sales of \[specify\] during the years at issue herein.\
\
(g) Petitioner, as an officer, had primary responsibility and control over the accounting and bookkeeping functions of \[company\] during the years at issue herein.\
\
(h) Petitioner, as an officer had primary responsibility and control over the maintenance and inventory of all \[specify\] of \[company\] during the years at issue herein.\
\
(i) Petitioner personally kept the proceeds of his illegal \[specify\] sales and did not cause to be recorded on the books and records of \[company\] any of such sales, during the years at issue herein.\
\
(j) Petitioners' income tax returns for their \[year(s)\] taxable years were prepared by \[name\], Certified Public Accountant, \[city, state\].\
\
(k) \[Name\] prepared said returns on the basis of information provided by petitioner.\
\
(l) \[Name\], in accordance with his business practice, asked petitioner upon completion of the \[year(s)\] tax returns if all of his and his wife's income had been reported therein, to which petitioner answered it was fully recorded.\
\
(m) Petitioner failed to maintain, or to submit for examination by respondent, complete and adequate books of account and records of his income producing activities for each of the taxable years \[year(s)\], as required by the applicable provisions of the Internal Revenue Code, and respective regulations promulgated thereunder.\
\
(n) That the amount of petitioner's gross taxable income, deductions and other items required to be shown on their income tax returns for each of the taxable years \[year(s)\] cannot be determined from the books and records which petitioner maintained and submitted for examination by respondent, as is shown by the following facts:\
\
1\. Agents of respondent, during the calendar year \[year\] and subsequently during the course of their investigations, requested petitioner to submit to them for inspection and examination all the books and records maintained by him with respect to his \[year(s)\] taxable years for use in respondent's agents' examination and verification of petitioner's taxable income for each of said years.\
\
2\. Petitioner in response to such request, failed to submit the requested books of account and records, which were maintained by petitioner.\
\
3\. Petitioner maintained no records or invoices which reflected his illegal sales of \[specify\] during the years at issue herein.\
\
4\. Respondent's agents determined in their examination that petitioner had purchased assets during \[year(s)\] with funds that exceeded in total amount the income reflected on petitioners' income tax returns for the \[year(s)\] taxable years.\
\
5\. Petitioner, although aware of the recordkeeping requirements willfully failed to maintain adequate books and other records of account with respect to his income during the years at issue.\
\
(o) Respondent has determined petitioner's correct taxable income for the taxable years \[date\] through \[date\] on the basis of the net worth method.\
\
(p) There is attached hereto as Exhibits A through C, which are incorporated herein by reference and made a part hereof, a net worth statement of the assets and liabilities of petitioners on \[year(s)\]. Petitioners did in fact, on the date specified on Exhibits A through C have the specific items of assets and liabilities in the various amounts set forth therein.\
\
(q) Petitioners had no nontaxable sources of funds or excludable receipts which require adjustments in computing their correct taxable income for the taxable years \[year(s)\], except as already noted in Exhibits A through C of this Answer.\
\
(r) Petitioners had no cash on hand other than the amount indicated in Exhibit B to this Answer on \[date\].\
\
(s) Petitioners maintained no checking accounts or savings accounts during the periods \[date\] through \[date\] other than those indicated in Exhibit B to this Answer.\
\
(t) There is attached hereto as Exhibits D through H, which are incorporated herein by reference and made a part hereof, statements of various expenditures, deductible and nondeductible, income taxes paid and gifts made, and computation of depreciation allowable, applicable to the calculation of adjusted gross income of petitioners during the years \[year\] through \[year 2\], inclusive. Petitioners did in fact make expenditures, deductible and nondeductible, and make the gifts and income tax payments indicated on Exhibits D through H during the years \[year\] through \[year 2\] .\
\
(u) In \[year\], petitioner received $ \[amount\] in dividends which he failed to report on his \[year\] income tax return. Through petitioner's failure to report such dividend income he fraudulently understated his taxable income in that year with the intent to evade the payment of taxes on such income.\
\
(v) Petitioner received interest income in \[year(s)\] in the amounts of $ \[amounts\], respectively, which he failed to report as interest income on his income tax returns for each respective year. Through petitioner's failure to report such interest he fraudulently understated his taxable income in each respective year with the intent to evade the payment of taxes on such income in each respective year.\
\
(w) In \[year\] petitioner sold his common stock holdings in \[company\] in which he had a realizable gain of $ \[amount\] which he failed to report on his \[year\] income tax return. Through petitioner's failure to report the gain on the sale of his stock he fraudulently understated his taxable income in that year with the intent to evade the payment of taxes on such income in that year.\
\
(x) Petitioner received income in the form of Director's fees in each of the years \[year(s)\] in the amounts of $ \[amounts\] , respectively, which he failed to report in each year's respective income tax return. Through petitioner's failure to report such income from Director's fees he fraudulently understated his taxable income in each respective year with the intent to evade the payment of taxes on such income in each respective year.\
\
(y) In \[year\] petitioner recognized gain on the maturity of an endowment policy with \[company\] in the amount of $ \[amounts\] which he failed to include in his \[year\] income tax return. Through petitioner's failure to include the gain on the endowment policy he fraudulently understated his taxable income in that year with the intent to evade the payment of taxes on such income.\
\
(z) The net worth of petitioner during \[year(s)\] increased by $ \[amounts\], respectively.\
\
(aa) Petitioner fraudulently understated his taxable income during his \[year(s)\] taxable years in the amounts of $ \[amounts\], respectively, with the intent to evade the payment of taxes on such income in each respective year.\
\
(ab) Petitioner's correct income tax liability for \[year\] is $ \[amount\] , the tax liability reported on petitioner's \[year\] income tax return was $ \[amount\], and thus the understatement of tax liability for \[year\] was $ \[amount\].\
\
(ac) - (ae) \[specify each year as shown in (ab) above\]\
\
(af) Petitioner's failure to maintain complete and adequate records of his income producing activities, and illegal \[specify\] sales, and his failure to produce complete and accurate records for respondent in connection with the examination of his income tax returns for the taxable years \[year(s)\] was fraudulent with the intent to evade tax.\
\
(ag) Petitioner's extensive use of cash and his purchase and use of cashiers checks, in excess of $ \[amount\], during the years at issue herein was fraudulent with the intent to evade tax on his true taxable income.\
\
(ah) That petitioner willfully failed to report income tax liability of $ \[amounts\] in \[year(s)\], respectively, with the intent to evade the payment of such tax in each respective year.\
\
(ai) Petitioner made misleading statements to agents of respondent during their investigations relative to his business investments and illegal cost of sales of \[specify\].\
\
(aj) A part of the underpayment of tax required to be shown on petitioner's income tax returns for his \[year(s)\] taxable years is due to fraud.\
\
WHEREFORE, it is prayed:\
\
(1) That the relief sought in the petition be denied;\
\
(2) That the deficiencies in income taxes for the taxable years \[year(s)\] as set forth in the statutory notice, be in all respects approved; and\
\
(3) That the addition to the tax for each of the taxable years \[year(s)\], under the provisions of I.R.C. § 6663(a), as set forth in the statutory notice, be in all respects approved.\
\
**Exhibit 35.11.1-20**\
\
### Answer — Affirmative Allegations: Fraud — Specific Items Method\
\
8\. FURTHER ANSWERING the petition, and in support of the determination that a part of the underpayments of tax required to be shown on petitioners' income tax returns for the taxable years \[year(s)\] are due to fraud, the respondent alleges:\
\
(a) During each of the taxable years \[year(s)\], petitioners were engaged in the business of \[specify\].\
\
(b) Petitioners' principal place of business at which their books and records were maintained is located at \[city, state\]; said books and records were maintained, and their income tax returns were filed for the years here involved, on the cash method of accounting.\
\
(c) During the taxable years \[year(s)\], petitioners sold \[specify\] in the amount of $ \[amounts\], respectively, which were not reported on their income tax returns for said years.\
\
(d) Petitioners \[names\] fraudulently and with intent to evade taxes for the taxable years \[year{s)\], filed false income tax returns for said years that omitted the gain from the sale of \[specify\] as follows:\
\
(1) Petitioners' return for \[year\] only included part of the sales of \[specify\] made by petitioners to \[company\], in \[date\], resulting in an omission of $ \[amount\] of gain.\
\
(2) - (7) \[specify each instance as shown in (1) above\]\
\
(e) Respondent's determination of the omission of the specific items is corroborated by the fact that petitioners sent two documents captioned Amended United States Individual Income Tax Returns for the years \[year\] and \[year 2\] to the Internal Revenue Service Center in \[city, state\] including all the omitted specific items for those years. These amended returns were received at the Internal Revenue Service Center on \[date\]. Said documents were not sent to the Internal Revenue Service Center until the Criminal Investigation Division of the Internal Revenue Service had contacted petitioners regarding their \[year(s)\] Federal income tax returns.\
\
(f) When confronted at two interviews with Revenue Agent \[name\] on \[date(s)\], regarding the large decrease in \[specify\] sales in \[year\] compared to \[year 2\] without a corresponding decrease in the size of his \[specify\], petitioner \[name\] advised the agent that \[specify\]. In \[year\], petitioners sold \[specify\] to \[company\] which was not included on their \[year\] income tax return.\
\
(g) Petitioners \[names\] fraudulent omission of specific items of income on their income tax returns filed for \[year(s)\] is a part of a three year pattern of intent to evade taxes.\
\
(h) Petitioners understated their taxable income on their income tax returns for the taxable years \[year(s)\], in the amounts of $ \[amounts\], respectively.\
\
(i) Petitioners understated their income tax liabilities on their income tax returns for the taxable years \[year(s)\] in the amounts of $ \[amounts\], respectively.\
\
(j) Petitioners' failure to produce records or other information as to such sales to respondent in connection with the examination of their income tax returns for the taxable years \[year(s)\], was fraudulent with intent to evade tax.\
\
(k) Petitioners fraudulently, and with intent to evade tax, omitted from their income tax returns for the taxable years \[year(s)\], the gain from sales of \[specify\] in the amounts of $ \[amounts\], respectively.\
\
(1) A part of each deficiency in income tax for taxable years \[year(s)\], is due to fraud with intent to evade taxes.\
\
WHEREFORE, it is prayed:\
\
(1) That the relief sought in the petition be denied;\
\
(2) That the deficiencies in income taxes for the taxable years \[year(s)\], as set forth in the statutory notice, be in all respects approved; and\
\
(3) That the additions to the tax pursuant to I.R.C. § 6663(b) for the taxable years \[year(s)\], as set forth in the statutory notice be in all respects approved.\
\
**Exhibit 35.11.1-21**\
\
### Answer — Affirmative Allegations: Fraud — Alternative Negligence and Delinquency Penalties\
\
8\. FURTHER ANSWERING the petition in the alternative to paragraph 7, and in support of respondent's claim for a 25-percent addition to the income tax under the provisions of I.R.C. § 6651(a), and a 20-percent penalty under the provisions of I.R.C. § 6662(a) from petitioners, respondent alleges:\
\
(a) In the statutory notice of deficiency dated \[date\], upon which notice this case is based, respondent determined that petitioners were liable for the addition to tax for fraud under I.R.C. § 6663(a). Facts supporting this determination are more fully set forth in the allegations in paragraph 7 above, which facts are incorporated herein by reference and relied upon for the alternative position that the delinquency and accuracy related penalties are applicable.\
\
(b) The income tax return of petitioners for the taxable year \[year\] was due to be filed on or before April 15, \[year\].\
\
(c) The income tax return of petitioners for the taxable year \[year\] was due to be filed on or before April 15, \[year\].\
\
(d) The income tax return of petitioners for the taxable year \[year\] was filed on \[date\], which date is more than \[specify number of\] months or fractions thereof after the due date for such return and with respect to which due date no extension of time was sought from, nor granted by, respondent.\
\
(e) The income tax returns of petitioner for the taxable years \[year(s)\] were filed on \[date\], which date is more than \[specify number of\] months or fractions thereof after the respective due dates for such returns and with respect to which due dates no extensions of time were sought from, nor granted by, respondent.\
\
(f) If the Court determines that petitioners are not liable for the addition to tax for fraud, they are liable for the addition to tax provided by I.R.C. § 6651 for failure to timely file, without reasonable cause, their tax returns for the taxable years \[year(s)\].\
\
(g) If the Court determines that petitioners are not liable for the addition to tax for fraud, they are liable for the addition to tax provided by I.R.C. § 6653(a) since at least a part of the underpayment of the tax for each of the years \[year(s)\] is due to negligence or intentional disregard of rules and regulations.\
\
WHEREFORE, it is prayed:\
\
(1) That the relief sought in the petition be denied;\
\
(2) That the deficiencies in income tax for the taxable years \[year(s)\], as set forth in the statutory notice, be in all respects approved;\
\
(3) That the additions to the tax for the taxable years \[year(s)\], under the provisions of I.R.C. § 6663(a), as set forth in the statutory notice, be in all respects approved;\
\
(4) That the Court determine that the assessment and collection of the deficiencies in income taxes for the taxable years \[year(s)\], as set forth in the statutory notice, are not barred by the statute of limitations;\
\
(5) That, in the alternative to the addition to tax under I.R.C. § 6663(a), the Court determine that there is due a 25-percent addition to the tax under the provisions of I.R.C. § 6651, claim for which is hereby made pursuant to the provisions of I.R.C. § 6214(a); and\
\
(6) That, in the alternative to the addition to tax under I.R.C. § 6663(a), the Court determine that there is due a 5-percent addition to the tax under the provisions of I.R.C. § 6653(a) (1), claim for which is hereby made pursuant to the provisions of I.R.C. § 6214(a).\
\
**Exhibit 35.11.1-22**\
\
### Answer — Affirmative Allegations: Fraud — Collateral Estoppel as to Tax Year\
\
8\. FURTHER ANSWERING the petition, and in support of the determination that a part of the underpayment of tax required to be shown on petitioner's income tax return for the taxable year \[year\] is due to fraud, respondent affirmatively relies upon the doctrine of collateral estoppel (estoppel by judgment), and alleges:\
\
(a) \[Name\], petitioner herein, is the same person who was the defendant in the criminal case of United States of America v. \[name\] \[court, Docket No.\]. The judgment entered in that case became final on \[date\].\
\
(b) Respondent herein is a party in privity with the United States of America, the prosecuting party in the aforesaid criminal case in which petitioner herein was the defendant.\
\
(c) The indictment filed on \[date\], in said criminal case set forth the following charge against the defendant, petitioner herein:\
\
THE GRAND JURY CHARGES:\
\
> That on or about \[date\], in the \[court\], \[name\], a resident of \[city\], did willfully and knowingly attempt to evade and defeat a large part of the income tax due and owing by him to the United States of America for the calendar year \[year\] by preparing and causing to be prepared, by signing and causing to be signed, and by mailing and causing to be mailed, in the \[city\] a false and fraudulent income tax return, which was filed with the Internal Revenue Service, wherein he stated that his taxable income for said calendar year was the sum of $ \[amount\] and that the amount of tax due and owing thereon was the sum of $ \[amount\], whereas, as he then and there well knew, his taxable income for the said calendar year was the sum of $ \[amount\], upon which said taxable income he owed the United States of America income tax of $ \[amount\] i in violation of Section 7201, Internal Revenue Code; Section 7201, Title 26, United States Code.\
\
(d) Petitioner on \[date\], entered a plea of guilty to the charge set forth against him in said indictment.\
\
(e) On \[date\], the United States District Court entered its judgment pursuant to said plea, a certified copy of which is attached hereto as Exhibit A.\
\
(f) Among the issues of fact determined in the aforesaid criminal case was whether \[name\], the defendant therein, and petitioner herein, did in fact willfully file a false and fraudulent income tax return for the taxable year \[year\] with intent to evade and defeat income tax, and whether he did in fact by such means understate a part of the income tax due and owing by him to the United States of America for said year.\
\
(g) One of the issues in the instant case is whether the addition to the tax imposed by I.R.C. § 6663(a) should be imposed against petitioner for the taxable year \[year\].\
\
(h) Said issue in the instant case is the same as the issue which was presented and determined adversely to petitioner in the aforesaid criminal case to the extent that both the imposition of the addition to the tax against petitioner for the taxable year \[year\], under I.R.C. § 6663(a), and said judgment of conviction of petitioner for violation of I.R.C. § 7201, are each dependent upon findings that petitioner for said year did in fact file a false and fraudulent income tax return and that by reason of such fraud there is for said year an underpayment of income tax.\
\
(i) The prior criminal conviction of petitioner under I.R.C. § 7201, for the taxable year \[year\] is conclusive and binding on petitioner, and by reason thereof petitioner is estopped in the instant case, under the doctrine of collateral estoppel (estoppel by judgment), from denying herein that he willfully filed a false and fraudulent income tax return for the taxable year \[year\] with intent to evade and defeat a part of the income due and owing by him for said year, and that due to such fraud there is for said year an underpayment of tax within the meaning of I.R.C. § 6663 (a).\
\
(j) By reason of such prior criminal conviction, petitioner is estopped in the instant case, under the doctrine of collateral estoppel (estoppel by judgment), from denying that a part of the underpayment of income tax for the year \[date\] is due to fraud, and that, therefore, petitioner is liable for the addition to the tax imposed by I.R.C. § 6663(a), as determined by respondent in the statutory notice, upon which notice the instant case is based.\
\
WHEREFORE, it is prayed that the Court determine that for the taxable year \[year\] petitioner is estopped under the doctrine of collateral estoppel (estoppel by judgment) from denying his liability for the addition to the tax imposed by I.R.C. § 6663 (a).\
\
**Exhibit 35.11.1-23**\
\
### Answer — Affirmative Allegations: Transferee Liability\
\
8\. FURTHER ANSWERING the petition, and in support of the determination that petitioners' \[petitioner A\] and \[petitioner B\] are liable as transferees at law and in equity of \[name of entity\], transferor, for the deficiency in corporate income tax due from said transferor for the taxable year \[year\], plus interest thereon as provided by law, respondent alleges:\
\
(a) \[Name of entity\], hereinafter referred to as the transferor, was incorporated under the laws of the State of \[state\] and had as its principal place of business \[address\].\
\
(b) On \[date\], the transferor adopted a plan of complete liquidation.\
\
(c) That pursuant to the plan of liquidation the transferor was dissolved on or about \[date\].\
\
(d) That on or about \[date\], the transferor transferred to petitioners assets with fair market values as follows:\
\
\[set forth assets\]\
\
(e) Said transfers, as set forth in paragraph 7(d) above, were made to petitioners without any consideration other than the surrender of their shares of the capital stock of the transferor.\
\
(f) By reason of the transfer of assets by the transferor to petitioners, the transferor was rendered and is, insolvent without assets with which to pay the deficiency in corporate income tax in the amount of $ \[amount\] , plus interest thereon as provided by law due, for its taxable year \[year\].\
\
(g) The fair market value of the assets transferred to petitioners upon dissolution of the transferor was in excess of the deficiency in corporate income tax due from the transferor, plus interest thereon as provided by law.\
\
(h) Petitioners executed and delivered to respondent an instrument in writing with respect to the transferor which provides as follows:\
\
> Transferee Agreement: In consideration of the Commissioner of Internal Revenue not issuing a notice of deficiency to and making an assessment against the above-named transferor, the undersigned, as transferee of assets received from the above-named transferor, assumes and agrees to pay the amounts of any and all Federal income or profits taxes finally determined or adjudged as due and payable by such transferor for the tax years ended \[date\], to the extent of the liability at law or in equity as transferee within the meaning of section 6901 of the Internal Revenue Code and corresponding provisions of internal revenue laws.\
\
> FURTHER: The undersigned transferees agree, in the absence of prior written consent of the Commissioner of Internal Revenue, not to sell, transfer, or assign without adequate consideration, all or any substantial portion of its assets; and\
\
> FURTHER: The undersigned, if a corporation, has, by resolution of its board of directors, been authorized to enter into this agreement and there is attached a copy of the minutes of its board of directors evidencing the authorization and that the terms of this agreement have been included in its corporate minutes.\
\
(i) Respondent has not issued to the transferor a statutory notice of deficiency for the taxable year ended \[date\], and has in every other respect duly performed all the terms and conditions of said agreement on his part to be performed.\
\
(j) Under said agreement petitioners assumed and agreed to pay any deficiency in income tax for the \[year\] taxable year, together with interest thereon as provided by law, as may be determined to be due from the transferor.\
\
(k) On \[date\], respondent sent to each petitioner, by certified mail, a notice of liability in which it was determined that there was a deficiency in income tax due from the transferor for the taxable year \[year\] in the amount of $ \[amount\].\
\
(l) No part of the deficiency in corporate income tax due from the transferor, together with interest thereon as provided by law, has been paid.\
\
(m) By reason of the transfer of assets to petitioners and their receipt by petitioners, petitioners became, and are, each transferee of assets within the meaning of section 6901, 28 U.S.C. § 3301 et seq. (the Federal Debt Collection Procedure Act), and \[appropriate state fraudulent transfer act, if any\] and, as such, are liable for the deficiency in income tax due from the transferor for the taxable year \[year\], plus interest thereon as provided by law.\
\
WHEREFORE, it is prayed:\
\
(1) The relief sought in the petition be denied.\
\
(2) That the deficiency in income tax for the taxable year \[year\], due from transferor as set forth in the statutory notice of liability be in all respects approved; and\
\
(3) That petitioner be held liable as transferees at law and in equity of the transferor for the deficiency in income tax for the taxable year \[year\], due from the said transferor, as set forth in the statutory notice of liability, plus interest thereon as provided by law.\
\
**Exhibit 35.11.1-24**\
\
### Answer — Accumulated Earnings Tax: Inadequate Section 534(c) Statement\
\
8\. FURTHER ANSWERING the petition, and in support of the determination that for the taxable year 2000 the petitioner is liable for the accumulated earnings tax imposed by I.R.C. § 531 and without, by virtue of these allegations, making any admission or concession in regard to the burden of proof, which respondent contends is in all respects upon the petitioner, the respondent alleges as follows:\
\
(a) The respondent, pursuant to section 534(b), sent by certified mail on February 6, 2003, a notification informing the petitioner that a proposed statutory notice of deficiency included an amount with respect to the accumulated earnings tax imposed by section 531 for the taxable year 2000. A copy of said notification is attached hereto as Exhibit A.\
\
(b) The petitioner, pursuant to section 534(c) timely submitted on April 9, 2003, a statement of the grounds upon which it relies to establish that all or a part of its earnings and profits for the taxable year 2000 have not been permitted to accumulate beyond the reasonable needs of its business. In said statement, petitioner listed the following alleged grounds:\
\
(1) Normal working capital needs.\
\
(2) Additional working capital needs.\
\
(3) Expansion, diversification and modernization programs.\
\
(4) Reserve for payment of Federal income and accumulated earnings deficiencies.\
\
(5) Reserve for contingent liabilities for product defects. A copy of said statement is attached hereto as Exhibit B.\
\
(c) The statement submitted by the petitioner does not comply with the requirements of section 534(c) for the reasons that the grounds set forth therein are either irrelevant or insufficient to justify petitioner's accumulation of earnings and profits, in that:\
\
\[(1) - (5), (6), . . . . .\] \[Insert specific factual information here to rebut each alleged grounds for accumulation.\]\
\
(d) In the alternative, however, the Court should determine whether any or all of the petitioner's grounds are clear, definitive and relevant. For the reasons set forth in subparagraph (c) of this paragraph the statement of the petitioner does not comply with section 534(c) since the grounds set forth are not supported by facts sufficient to show the basis of designated grounds\
\
(e) In the further alternative, if the Court should determine that the statement submitted by petitioner complies with the requirements of section 534(c), respondent alleges that the petitioner did not retain any of its earnings, nor would it have been justified in retaining any of its earnings, for any of the alleged grounds set forth in said statement, in that:\
\
(1) The petitioner, in the beginning of the year at issue, had already accumulated in prior years \[insert amount\] .\
\
(2) The petitioner had not formulated any specific plans with regard to expansion, modernization and diversification.\
\
(3) The petitioner had submitted no information from which computations could be made as to the costs of expansion or the needs for reserves.\
\
(4) If petitioner had distributed its accumulated earnings for 1970, its primary stockholders' income tax would have been increased by $ \[insert amount\].\
\
WHEREFORE, it is prayed:\
\
(1) That the relief sought in the petition be denied;\
\
(2) That the Court determine that the statement submitted by the petitioner, pursuant to section 534(c) does not comply with the requirements of said section and, as a result thereof, the burden of proof as to the reasonable needs of the business is on the petitioner pursuant to the provisions of section 534(a) (1);\
\
(3) That the Court determine that the earnings and profits of the petitioner were permitted to accumulate beyond the reasonable needs of the business; and\
\
(4) That the deficiency determined by the respondent be in all respects approved.\
\
**Exhibit 35.11.1-25**\
\
### Answer — Accumulated Earnings Tax Answer: Petitioner Failed to Submit Section 534(c) Statement\
\
8\. FURTHER ANSWERING the petition, and in support of the determination that for the taxable year 1975 the petitioner is liable for the accumulated earnings tax imposed by I.R.C. § 531, and without, by virtue of these allegations, making an admission or concession in regard to the burden of proof, which respondent contends is in all respects upon the petitioner, the respondent alleges as follows:\
\
(a) The respondent, pursuant to section 534(b), sent by certified mail on March 9, 2000, a notification informing the petitioner that a proposed statutory notice of deficiency included an amount with respect to the accumulated earnings tax imposed by section 531 for the taxable year 1996. A copy of said notification is attached hereto as Exhibit A.\
\
(b) The petitioner never submitted, pursuant to section 534(c), a statement of the grounds upon which it relies to establish that all or part of its earnings and profits for the taxable year 1996 have not been permitted to accumulate beyond the reasonable needs of its business.\
\
(c) The allegations of subparagraphs (a) through (c) of paragraph 5 of the petition are vague, irrelevant, and insufficient to justify petitioner's accumulation of earnings and profits and sufficient grounds are not set forth therein which are supported by facts or data which can be verified by respondent.\
\
(d) The petitioner has not alleged any facts, nor do any facts exist, which would have justified it in retaining any of its earnings for any of the alleged grounds set forth in subparagraphs (a) through (c) of paragraph 5 of the petition.\
\
(e) The petitioner has accumulated sufficient earnings and profits from periods prior to 1996 to more than cover any reasonable needs of the business during 1996 and petitioner was therefore not entitled to an accumulated earnings tax credit under section 535(c).\
\
WHEREFORE, it is prayed:\
\
(1) That the relief sought in the petition be denied;\
\
(2) That the Court determine that the burden of proof as to the reasonable needs of business is on the petitioner pursuant to the provisions of section 534(a) (1) since no statement was submitted by the petitioner pursuant to section 534(c);\
\
(3) That the Court determine that the earnings and profits of the petitioner were permitted to accumulate beyond the reasonable needs of the business; and\
\
(4) That the deficiency determined by the respondent be in all respects approved.\
\
**Exhibit 35.11.1-26**\
\
### Answer — Accumulated Earnings Tax Answer: Section 534 Letter Sent But No Response\
\
8\. FURTHER ANSWERING the petition, and in support of the determination that for its fiscal taxable year ended March 31, 2000, the petitioner is liable for the accumulated earnings tax imposed by section 531 of the Internal Revenue Code of 1954, the respondent alleges as follows:\
\
(a) During its fiscal year ended March 31, 2000, petitioner was engaged in \[insert type of business\].\
\
(b) For its fiscal year ended March 31, 2000, petitioner's gross receipts or sales derived from its principal business activities were as follows: \[insert specific facts\]\
\
(c) \[Insert specific facts describing petitioners' business enterprise\].\
\
(d) On March 31, 2000, the petitioner's current assets, current liabilities, and net working capital were as follows: \[insert specific facts\]\
\
(e) Petitioner's business activities are such that its operating cycle is \[virtually instantaneous\]. \[Insert appropriate facts about petitioner's business operating cycle.\]\
\
(f) Petitioner has demonstrated a stable accounts receivable balance over the years with virtually no allowance for bad debts. Its receivables are converted into cash within 30 days.\
\
(g) Petitioner does not fit within the concept of an operating cycle as that term has been defined by the courts and as determined by use of the Bardahl formula.\
\
(h) Even assuming the petitioner's business activities fit within and can be defined by the Bardahl formula, its operating cycle is de minimis. Application of the Bardahl formula to the business enterprise of petitioner results in an inventory cycle, accounts receivable cycle and resulting operating cycle as follows: \[insert specific facts\]\
\
(i) Petitioner's operating expenses including investment related expenses but less depreciation for its fiscal year ended March 31, 2000, was in the amount of $ \[insert amount\].\
\
(j) Under the Bardahl formula the petitioner's total operating expenses for an operating cycle would be as follows: \[insert specific facts\]\
\
(k) The petitioner has excess net working capital over its working capital needs at March 31, 2000, in an amount of not less than $ \[insert amount\].\
\
(l) The corporate minutes of petitioner during the time period involved herein do not contain any mention of plans for expansion, diversification or other activity for which its excess working capital would be needed, \[note exceptions as appropriate\].\
\
\[(m) — (p), (q), (r), . . . \] \[Insert other relevant facts about petitioner's business activities, assets and liabilities, etc.\]\
\
(s) The petitioner permitted its earnings and profits to accumulate beyond the reasonable needs of its business for its fiscal taxable year ended March 31, 2000.\
\
(t) At all times relevant hereto, petitioner had no definite or specific plans for the utilization of its excess working capital through expansion or modernization of its facilities or diversification of its business activities.\
\
(u) If the petitioner had distributed its excess working capital during the year at issue, its shareholders' income tax liabilities would have been substantially increased.\
\
(v) The petitioner was formed or availed of during its fiscal year ended March 31, 2000, for the purpose of avoiding income tax with respect to its shareholders by permitting earnings and profits to accumulate beyond the reasonable needs of the business rather than being distributed.\
\
WHEREFORE, it is prayed:\
\
(1) That the relief sought in the petition be denied;\
\
(2) That the Court determine that the earnings and profits of petitioner were permitted to accumulate beyond the reasonable needs of its business;\
\
(3) That the deficiency determined by the respondent be in all respects approved; and\
\
(4) That the addition to the tax as determined by respondent under section 6653(a) be in all respects approved.\
\
**Exhibit 35.11.1-27**\
\
### Declaratory Judgment Case: Employee Plans (Stipulated Administrative Record)\
\
|  |\
| --- |\
| **UNITED STATES TAX COURT** |\
|  |\
| \[NAME OF COMPANY\], | )<br> ) |  |\
| Petitioner, | )<br> ) |  |\
| v. |  | )<br> ) | Docket No. \[docket no.\] R |\
| COMMISSIONER OF INTERNAL REVENUE, | )<br> ) |  |\
| Respondent. | ) |  |\
|  |\
| **ADMINISTRATIVE RECORD** |\
|  |\
|  | \[NAME\]<br> Chief Counsel |\
| OF COUNSEL:<br> \[Signature Block\] |\
\
|  |\
| --- |\
| **UNITED STATES TAX COURT** |\
|  |\
| \[NAME OF COMPANY\], | )<br> ) |  |\
| Petitioner, | )<br> ) |  |\
| v. |  | )<br> ) | Docket No. \[docket no.\] R |\
| COMMISSIONER OF INTERNAL REVENUE, | )<br> ) |  |\
| Respondent. | ) |  |\
| **STIPULATION AS TO THE ADMINISTRATIVE RECORD** |\
| THE PARTIES hereby stipulate that the exhibits attached constitute the entire administrative record in the above captioned case; that said exhibits are genuine; and are described and marked hereafter: |\
|  |\
| EXHIBIT NO. | DESCRIPTION |\
| 1-J | \[Briefly describe exhibit including name, form no., date and number of pages; examples below\]. |\
| 2-J | Application for Determination for Defined Benefit Plan (Form 5300) \[date\]. (\[#\] pages) |\
| 3-J | Corrected Page 1 of Application for Determination for Defined Benefit Plan (Form 5300) \[date\]. (\[#\] pages) |\
|  |\
| _\[Use signature format used for other stipulations\]._ |\
\
**Exhibit 35.11.1-28**\
\
### Declaratory Judgment Case: Employee Plans (Administrative Record Submitted Unagreed)\
\
| **NOTICE OF FILING AND SUBMISSION OF ADMINISTRATIVE RECORD** |\
| :-: |\
| Pursuant to Rule 217(b) (1) of the Tax Court's Rules of Practice and Procedure, respondent hereby files with the Court the administrative record appropriately certified as to its genuineness. The administrative record contains those items listed in the index to the administrative record annexed hereto. |\
\
| **COMMISSIONER'S CERTIFICATE AS TO THE GENUINENESS OF THE ENTIRE ADMINISTRATIVE RECORD** |\
| :-: |\
| I, \[Name of person executing certificate\], hereby certify that the documents annexed hereto are the true and genuine documents constituting the administrative record regarding the request for determination as to the qualification of an amendment to the pension plan of the \[name of pension plan\] and participating employers to wit: |\
\
| **INDEX TO ADMINISTRATIVE RECORD** |\
| :-: |\
| Exhibit | Description |\
| 1-R | \[Briefly describe exhibit including name, form no., date and number of pages; examples below\] . |\
| 2-R | Cover letter submitted with Short Form Application for Determination \[date\]. (1 page) |\
| 3-R | Short Form Application for Determination for Amendment of Employee Benefit Plan. (5 pages) |\
\
**Exhibit 35.11.1-29**\
\
### Notice of Filing of Petition and Right to Intervene\
\
|  |\
| --- |\
| **UNITED STATES TAX COURT** |\
|  |\
| JANE DOE, | )<br> ) |  |\
| Petitioner, | )<br> ) |  |\
| v. |  | )<br> ) | Docket No. XXXX-XX |\
| COMMISSIONER OF INTERNAL REVENUE, | )<br> ) |  |\
| Respondent. | ) |  |\
|  |\
| **NOTICE OF FILING OF PETITION AND RIGHT TO INTERVENE** |\
\
RESPONDENT, pursuant to T.C. Rule 325(a) and King v. Commissioner, 115 T.C. 118 (2000), hereby provides Notice of the filing of a petition raising relief from joint and several liability on a joint return by the above-named petitioner, and right to intervene, to petitioner's \[former\] spouse, John Doe, the other individual filing joint returns with petitioner for the years in issue, as follows:\
\
1\. On , petitioner Jane Doe filed a petition with the United States Tax Court for determination of relief from joint and several liability on joint returns for tax years I, 2, and 3.\
\
2\. John Doe, petitioner's \[former\] spouse, filed joint returns with petitioner for the years in issue.\
\
3\. Under T.C. Rule 325(b), John Doe has a right to intervene in this matter regarding petitioner's entitlement to relief from joint and several liability. John Doe may exercise that right by filing a notice of intervention with the Tax Court no later than 60 days after service of this Notice and attaching a copy of this Notice to any notice of intervention filed with the Tax Court.\
\
|  |\
| --- |\
| Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ |  | \[NAME OF CHIEF COUNSEL\]<br> Chief Counsel<br> Internal Revenue Service |\
|  |\
|  | By: | \_\_ |\
|  |  | Attorney<br> T.C. Bar No.<br> \[Address\]<br> \[Phone number\] |\
| OF COUNSEL:<br> \[NAME OF DIVISION COUNSEL\]<br> Division Counsel<br> (Small Business/Self-Employed)<br> AREA COUNSEL'S NAME<br> Area Counsel<br> (Small Business/Self-Employed:Area Z) |  |  |\
| \\_\\_\\_\_\_\_ |\
\
| **CERTIFICATE OF SERVICE** |\
| :-: |\
| This is to certify that a copy of the foregoing NOTICE OF FILING OF PETITION AND RIGHT TO INTERVENE was served on petitioner by mailing the same on \_in a postage paid wrapper addressed as follows: |\
| Jane Doe<br> Street Address<br> City, State Zipcode |\
| Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ | \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_<br> AREA COUNSEL ATTORNEY'S NAME<br> Senior Attorney<br> (Small Business/Self-Employed)<br> Tax Court Bar No. YYYYY |\
| \\_\\_\\_\_\_\_ |\
\
| **CERTIFICATE OF SERVICE** |\
| :-: |\
| This is to certify that a copy of the foregoing NOTICE OF FILING OF PETITION AND RIGHT TO INTERVENE was served on John Doe, nonpetitioning spouse, by mailing the same on \_in a postage paid wrapper addressed as follows: |\
| John Doe<br> Street Address<br> City, State Zipcode |\
| Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ | \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_<br> AREA COUNSEL ATTORNEY'S NAME<br> Senior Attorney<br> (Small Business/Self-Employed)<br> Tax Court Bar No. YYYYY |\
| \\_\\_\\_\_\_\_ |\
\
|  |\
| :-: |\
| **\[USE APPROPRIATE LETTERHEAD\]**<br>**CC:SBSE:X:XXX:X**<br>**ABCoe** |\
|  |\
| John Doe<br> Street Address<br> City, State Zipcode |\
|  | Re: | Jane Doe v. Commissioner<br> Docket No.\_\_\_\_\_\_\_\_\_\_\_ |\
|  |\
| Dear Mr. Doe: |\
| Attached to this letter is a Notice of Filing of Petition and Right to Intervene in the above-referenced matter. Jane Doe has filed a petition with the United States Tax Court, alleging, in part, that she should be relieved of joint tax liabilities for the years 1, 2, and 3, for which you and she filed joint federal income tax returns. The Tax Court Rules afford you the right to intervene in this matter. If you wish to exercise that right, please follow the instructions in the attached notice. If you have any questions concerning this matter, please direct them to the undersigned at the above address or telephone number. |\
|  | Sincerely, |\
|  | Associate Area Counsel's Name<br> Associate Area Counsel |\
|  |\
| By: | \_\_ |\
|  | Attorney's Name<br> Attorney<br> T.C. Bar No. YYYYY |\
|  |\
| Enclosures:<br> Notice of Filing of Petition and Right to Intervene<br> Copy of T.C. Rule 325 |\
\
**Exhibit 35.11.1-30**\
\
### Notice of Filing of Petition and Right to Intervene (Deceased Nonpetitioning Spouse)\
\
Template 1: Respondent Provides Notice to Court of Deceased Nonpetitioning Spouse’s Heirs.\
\
Use this template when asking the court to provide notice of the right to intervene to heirs or heirs at law.\
\
|  |\
| --- |\
| **UNITED STATES TAX COURT** |\
|  |\
| \[PETITIONER\], | )<br> ) |  |\
| Petitioner, | )<br> ) |  |\
| v. |  | )<br> ) | Docket No. XXXX-XX |\
| COMMISSIONER OF INTERNAL REVENUE, | )<br> ) | Filed Electronically |\
| Respondent. | ) |  |\
|  |\
| **NOTICE OF FILING OF PETITION AND RIGHT TO INTERVENE** |\
| RESPONDENT hereby provides notice to the Court of respondent’s efforts to comply with T.C. Rule 325(a), requiring respondent to serve notice on the nonpetitioning spouse of the filing of a petition by a spouse seeking action for determination of relief from joint and several liability on a joint return pursuant to I.R.C. § 6015. Respondent advises the Court as follows:<br> <br>1. Respondent is unable to provide notice of the filing of a claim for relief from joint and several liability in the above-captioned case to \[Decedent\], with whom petitioner filed a joint income tax return for the tax year\[s\] before the Court, because \[Decedent\] is deceased. This notice is required by T.C. Rule 325(a); see also King v. Commissioner, 115 T.C. 118 (2000). \[Decedent\], deceased (Decedent), died on **\[MONTH DAY, YEAR\]**, in **\[CITY, STATE\]**. A copy of Decedent’s death certificate is attached as Exhibit A.<br>   <br>2. Petitioner advised respondent that no representative or fiduciary is currently authorized to act on behalf of Decedent’s estate. Petitioner further advised respondent that Decedent left **\[a/no\]** will but because the estate is de minimis, the **\[will/estate\]** has not been and will not be submitted to a court for probate. Thus, there is no duly authorized representative available to act on behalf of Decedent’s estate.<br>   <br>3. Further, in accordance with **Fain v. Commissioner**, 129 T.C. 89 (2007), respondent provides the following information, insofar as ascertainable, regarding Decedent’s heirs.<br>   <br>**\[Scenario: Will available; heirs named with addresses.\]**<br>   <br>4. Decedent’s will named the following heir\[s\]: **\[NAME AND FULL ADDRESS OF EACH HEIR\]**.<br>   <br>**\[Go to Signature Block.\]**<br>   <br>**\[Scenario: No will. Heirs at law; petitioner provided addresses.\]**<br>   <br>   <br>   <br>   <br>    4) Petitioner advised respondent that Decedent’s only heirs at law are **\[NAME OF EACH HEIR AT LAW\]**. Petitioner further advised respondent **\[FOR EACH HEIR AT LAW: NAME OF HEIR AT LAW\]** resides at **\[STREET ADDRESS, CITY, STATE, ZIP CODE\]**.<br>   <br>**\[Go to Signature Block.\]**<br>   <br>**\[Scenario: No will. Heirs at law; no addresses provided respondent unable to identify addresses.\]**<br>   <br>   <br>   <br>   <br>    4) Petitioner advised respondent that Decedent’s only heirs at law are \[**NAME OF EACH HEIR AT LAW\].** Petitioner further advised respondent that petitioner was not able to provide the current address of **\[NAME OF EACH HEIR AT LAW\].** In addition, respondent has not been able to identify the current address of **\[NAME OF EACH HEIR AT LAW\]. \[SET FORTH THE ATTEMPTS RESPONDENT MADE TO IDENTIFY CURRENT ADDRESSES FOR EACH HEIR AT LAW.\]** |\
\
|  |\
| --- |\
|  |  | \[NAME OF CHIEF COUNSEL\]<br> Chief Counsel<br> Internal Revenue Service |\
|  |\
| Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ |  | \\_\\_\\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |\
|  |  | \[NAME OF ATTORNEY\]<br> \[TITLE\]<br> (Small Business/Self-Employed)<br> Tax Court Bar No. \[NUMBER\]<br> \[STREET ADDRESS\]<br> \[CITY, STATE ZIP CODE\]<br> Telephone: \[NUMBER\]<br> \[EMAIL ADDRESS\] |\
| OF COUNSEL:<br> \[NAME OF DIVISION COUNSEL\]<br> Division Counsel<br> (Small Business/Self-Employed)<br> \[NAME OF AREA COUNSEL\]<br> Area Counsel<br> (Small Business/Self-Employed:Area \[X\])<br> \[NAME OF ASSOCIATE AREA COUNSEL\]<br> Associate Area Counsel<br> (Small Business/Self-Employed) |  |  |\
| \\_\\_\\_\_\_\_ |\
\
**\[Certificate of Service to Petitioner Unless Petitioner Accepts Electronic Service\]**\
\
|  |\
| :-: |\
| **CERTIFICATE OF SERVICE** |\
| This is to certify that a copy of the foregoing NOTICE OF FILING OF PETITION AND RIGHT TO INTERVENE was served on petitioner by mailing the same on **\[MONTH DAY, YEAR\]** in a postage paid envelope addressed as follows: |\
| \[PETITIONER\]<br> \[STREET ADDRESS\]<br> \[CITY, STATE ZIP CODE\] |\
| Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ | \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_<br> \[NAME OF ATTORNEY\]<br> \[TITLE\]<br> (Small Business/Self-Employed)<br> Tax Court Bar No. \[NUMBER\] |\
\
**Template 2: Respondent Provides Notice to Court of Compliance with T.C. Rule 325(a) and Fain v. Commissioner, 129 T.C. 89 (2007)**\
\
**Use this template when respondent provides notice of the right to intervene to the heirs or heirs at law.**\
\
|     |\
| --- |\
|  |\
| **UNITED STATES TAX COURT** |\
|  |\
\
|     |     |     |\
| --- | --- | --- |\
| \[PETITIONER\] | )<br> ) |  |\
| Petitioner, | )<br> ) | Docket No. \[XXXX-XX\] |\
| v. | )<br> ) |  |\
| COMMISSIONER OF INTERNAL REVENUE | )<br> ) | Filed Electronically |\
| Respondent. | )<br> ) |  |\
\
**NOTICE OF FILING OF PETITION AND RIGHT TO INTERVENE**\
\
RESPONDENT hereby provides notice to the Court of respondent’s compliance with T.C. Rule 325(a), requiring respondent to serve notice on the nonpetitioning spouse of the filing of a petition by a spouse seeking action for determination of relief from joint and several liability on a joint return pursuant to Code section 6015. Although respondent was unable to serve such notice on the nonpetitioning spouse, respondent hereby serves notice on the nonpetitioning spouse’s heir\[s\] pursuant to Fain v. Commissioner, 129 T.C. 89 (2007).\
\
1. Respondent is unable to provide notice of the filing of a claim for relief from joint and several liability in the above-captioned case to \[Decedent\], with whom petitioner filed a joint income tax return for the tax year\[s\] before the Court, because \[Decedent\] is deceased. This notice is required by T.C. Rule 325(a); , 115 T.C. 118 (2000). \[Decedent\], deceased (Decedent), died on **\[MONTH DAY, YEAR\]**, in**\[CITY, STATE\]**. A copy of Decedent’s death certificate is attached as Exhibit A.\
\
2. Instead, respondent provides notice of the filing of a petition claiming relief from joint and several liability on a joint return by the above-named petitioner, and of the right to intervene, to Decedent’s **\[heir\[s\]/heir\[s\] at law\]**. Such notice to Decedent’s **\[heir\[s\]/\[heir\[s\] at law\]** is required pursuant to Fain v. Commissioner, 129 T.C. 89 (2007).\
\
3. On **\[DATE\]**, petitioner filed a petition with the United States Tax Court for determination of relief from joint and several liability on the joint return pursuant to I.R.C. section 6015 for the tax year **\[YEAR\]**.\
\
4. Decedent filed a joint return with petitioner for the year in issue.\
\
5. Petitioner advised respondent that no representative or fiduciary is currently authorized to act on behalf of Decedent’s estate. Petitioner further advised respondent that Decedent left **\[a/no\]** will but because the estate is de minimis, the**\[will/estate\]** has not been and will not be submitted to a court for probate. Thus, there is no duly authorized representative available to act on behalf of Decedent’s estate.\
\
**\[Scenario: Will available; heirs named with addresses.\]**\
\
6. Decedent’s will named the following heir\[s\]: **\[NAME AND FULL ADDRESS OF EACH HEIR\]**.\
\
**\[Go to Paragraph 8.\]**\
\
**\[Scenario: No will. Heirs at law; respondent identified probable addresses.\]**\
\
7. Consequently, in accordance with Fain v. Commissioner, respondent provides the following information, insofar as ascertainable, regarding Decedent’s heirs at law. Decedent’s only heirs at law are **\[NAME OF EACH HEIR AT LAW\]**. Petitioner advised respondent that **\[he/she\]** believed **\[NAME OF EACH HEIR AT LAW\]** was in **\[STATE FOR EACH HEIR AT LAW\]**. Petitioner further advised respondent that **\[he/she\]** does not have the current address for **\[NAME OF EACH HEIR AT LAW FOR WHOM PETITIONER DID NOT PROVIDE AN ADDRESS\]**. Thus, respondent sets forth probable addresses found in public records (Accurint) for Decedent’s heirs at law in the attached certificates of service.\
\
8. Under T.C. Rule 325(b) and Fain v. Commissioner, Decedent’s heirs have a right to intervene in this matter regarding petitioner’s entitlement to relief from joint and several liability. Decedent’s heirs may exercise that right by filing a notice of intervention with the Tax Court no later than 60 days after service of this Notice and attaching a copy of this Notice to any notice of intervention filed with the Tax Court.\
\
\
\
|     |     |\
| --- | --- |\
|  | \[NAME OF CHIEF COUNSEL\]<br> CHIEF COUNSEL<br> Internal Revenue Service |\
| Date: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ | \\_\\_\\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |\
|  | \[NAME OF ATTORNEY\]<br> \[TITLE\]<br> (Small Business/Self-Employed)<br> Tax Court Bar No. \[NUMBER\]<br> \[STREET ADDRESS\]<br> \[CITY, STATE ZIP CODE\]<br> Telephone: \[NUMBER\]<br> \[EMAIL ADDRESS\] |\
| OF COUNSEL:<br> \[NAME OF DIVISION COUNSEL\]<br> Division Counsel<br> (Small Business/Self-Employed)<br> \[NAME OF AREA COUNSEL\]<br> Area Counsel<br> (Small Business/Self-Employed: Area \[X\])<br> \[NAME OF ASSOCIATE AREA COUNSEL\]<br> Associate Area Counsel<br> (Small Business/Self-Employed) |  |\
\
\
**\[Certificate of Service to Petitioner Unless Petitioner Accepts Electronic Service\]**\
\
**CERTIFICATE OF SERVICE**\
\
This is to certify that a copy of the foregoing **\[NOTICE OF FILING OF PETITION AND RIGHT TO INTERVENE\]** was served on petitioner by mailing the same on **\[MONTH DAY, YEAR\]** in a postage paid envelope addressed as follows:\
\
|     |\
| --- |\
| \[PETITIONER\]<br> \[STREET ADDRESS\]<br> \[CITY, STATE ZIP CODE\] |\
\
|     |     |\
| --- | --- |\
| Date: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ | \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |\
|  | \[NAME OF ATTORNEY\]<br> \[TITLE\]<br> (Small Business/Self-Employed)<br> Tax Court Bar No. \[NUMBER\] |\
\
**\[Certificate of Service to Each Heir/Heir at Law\]**\
\
**CERTIFICATE OF SERVICE**\
\
This is to certify that a copy of the foregoing NOTICE OF FILING OF PETITION AND RIGHT TO INTERVENE was served on heir/heir at law **\[NAME OF HEIR/HEIR AT LAW\]** by mailing the same on **\[MONTH DAY, YEAR\]** in a postage paid envelope addressed as follows:\
\
|     |\
| --- |\
| \[NAME OF HEIR/HEIR AT LAW\]<br> \[STREET ADDRESS\]<br> \[CITY, STATE ZIP CODE\] |\
\
|     |     |\
| --- | --- |\
| Date: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ | \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |\
|  | \[NAME OF ATTORNEY\]<br> \[TITLE\]<br> (Small Business/Self-Employed)<br> Tax Court Bar No. \[NUMBER\] |\
\
**Exhibit 35.11.1-31**\
\
### Designation of Place of Trial\
\
|  |\
| --- |\
| **UNITED STATES TAX COURT** |\
|  |\
| JANE DOE, | )<br> ) |  |\
| Petitioner, | )<br> ) |  |\
| v. |  | )<br> ) | Docket No. XXXX-XX |\
| COMMISSIONER OF INTERNAL REVENUE, | )<br> ) |  |\
| Respondent. | ) |  |\
| **DESIGNATION OF PLACE OF TRIAL** |\
| Respondent hereby designates \[city and state\] as the place of trial of this case. |\
\
|  |\
| --- |\
| Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ |  | \[NAME OF CHIEF COUNSEL\]<br> Chief Counsel<br> Internal Revenue Service |\
|  |\
|  | By: | \_\_ |\
|  |  | Attorney<br> T.C. Bar No.<br> \[Address\]<br> \[Phone number\] |\
| OF COUNSEL:<br> \[NAME OF DIVISION COUNSEL\]<br> Division Counsel<br> (Small Business/Self-Employed)<br> \[AREA COUNSEL'S NAME\]<br> Area Counsel<br> (Small Business/Self-Employed:Area Z) |  |  |\
| \\_\\_\\_\_\_\_ |\
\
|  |\
| :-: |\
| **CERTIFICATE OF SERVICE** |\
| This is to certify that a copy of the foregoing paper was served on petitioner by mailing the same on \_in a postage paid wrapper addressed as follows: |\
| Jane Doe<br> Street Address<br> City, State Zipcode |\
| Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ | \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_<br> AREA COUNSEL ATTORNEY'S NAME<br> Senior Attorney<br> (Small Business/Self-Employed)<br> Tax Court Bar No. YYYYY |\
\
**Exhibit 35.11.1-32**\
\
### Notice of No Objection\
\
| **NOTICE OF NO OBJECTION** |\
| :-: |\
| RESPONDENT HEREBY NOTIFIES the Court that he has no objection to the granting of the petitioner's motion to change the place of trial of the above-entitled case from \[original location\] to \[new location\]. |\
\
**Exhibit 35.11.1-33**\
\
### Notice of Objection\
\
| **NOTICE OF OBJECTION** |\
| :-: |\
| RESPONDENT OBJECTS to the granting of petitioner's motion to continue the trial of the above-entitled case from the \[date\] trial session at \[place of trial\]. |\
| IN SUPPORT THEREOF, respondent respectfully states: |\
| 1\. The above-entitled case has been at issue since \[date\]. |\
| 2\. Petitioner has obtained \[number of previous continuances already granted\] continuances from previous trial sessions over the objections of respondent. |\
| 3\. Efforts to effect settlement of the case were undertaken without success prior to the \[number\] previous trial sessions at which the case was calendared for trial. Respondent believes that a further continuance will not enhance the possibility of settlement of said case. |\
| 4\. Petitioner has not set forth in the motion any valid ground for further continuance of said case. |\
| WHEREFORE, it is prayed that petitioner’s motion be denied. |\
\
**Exhibit 35.11.1-34**\
\
### Motions to Dismiss for Lack of Jurisdiction: Untimely Petition — Late U.S. Postmark\
\
|  |\
| :-: |\
| **MOTION TO DISMISS FOR LACK OF JURISDICTION** |\
\
RESPONDENT MOVES that the above-entitled case be dismissed for lack of jurisdiction upon the ground that the petition was not filed within the time prescribed by I.R.C. §§ 6213(a) or 7502.\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. The statutory notice of deficiency dated \[date\] upon which notice the above-entitled case is based, was sent to petitioner at the last known address, \[address used in notice of deficiency\], by certified mail on \[date of notice of deficiency\], as shown by the postmark date stamped on the executed Application for Registration or Certification, United States Postal Service Form 3877, a copy \[or certified mail list on file in the office of (name of office and location), a duly authenticated copy\] of which is attached hereto as Exhibit A.\
\
2\. The 90-day period for timely filing the petition with this Court from said notice of deficiency expired on \[day of week and date on which 90th day expired\], which date was not a legal holiday in the District of Columbia.\
\
3\. The petition was filed with the Tax Court on \[date on which petition was filed\], which date is \[number of days after date of mailing the notice\] days after the mailing of the notice of deficiency.\
\
4\. The copy of the petition served upon respondent bears a notation that the date of the United States postmark stamped on the cover in which the petition was mailed by \[type of mail\] mail, to the Tax Court is \[date\], which date is \[number of days after date of mailing notice\] days after the mailing of the notice of deficiency.\
\
5\. The petition was not filed with the Court within the time prescribed by I.R.C. §§ 6213(a) or 7502.\
\
WHEREFORE, it is prayed that this motion be granted.\
\
**Exhibit 35.11.1-35**\
\
### Motions to Dismiss for Lack of Jurisdiction: Untimely Petition — Private Postmeter\
\
|  |\
| :-: |\
| **MOTION TO DISMISS FOR LACK OF JURISDICTION** |\
| RESPONDENT MOVES that the above-entitled case be dismissed for lack of jurisdiction upon the ground that the petition was not filed within the time prescribed by I.R.C. §§ 6213(a) or 7502. |\
| IN SUPPORT THEREOF, respondent respectfully states: |\
| 1\. The statutory notice of deficiency dated \[date\] upon which notice the above-entitled case is based, was sent to petitioner at the last known address, \[address used in notice of deficiency\], by certified mail on \[date of notice of deficiency\], as shown by the postmark date stamped on the executed Application for Registration or Certification, United States Postal Service Form 3877, a copy \[or certified mail list on file in the office of (name of office and location), a duly authenticated copy\] of which is attached hereto as Exhibit A. |\
| 2\. The 90-day period for timely filing the petition with this Court from said notice of deficiency expired on \[day of week and date on which 90th day expired\], which date was not a legal holiday in the District of Columbia. |\
| 3\. The petition was filed with the Tax Court on \[date on which petition was filed\], which date is \[number of days after date of mailing the notice\] days after the mailing of the notice of deficiency. |\
| 4\. The copy of the petition served upon the respondent bears a notation that the date stamped by postal meter on the cover in which the petition was mailed, by \[type of mail\] mail, to the Tax Court is \[date\]. |\
| 5\. The United States Postal Service has advised respondent that an envelope, which was properly addressed to the Tax Court, mailed by \[type of mail\] from the \[city\] area and bearing a United States postmark with a date of \[date on which 90th day expired\], would have ordinarily been received on \[normal delivery date\] at the Tax Court. |\
| 6\. Since the petition in this case was not delivered to the Tax Court until \[date on which petition was filed\], the petition was not timely filed within the time prescribed by I.R.C. §§ 6213(a), 7502(b), and Treas. Reg. § 301.7502-1(c) (1) (iii) (b). |\
| WHEREFORE, it is prayed that this motion be granted. |\
\
**Exhibit 35.11.1-36**\
\
### Motions to Dismiss for Lack of Jurisdiction: Untimely Petition — Illegible Postmark/ Postmeter\
\
|  |\
| :-: |\
| **MOTION TO DISMISS FOR LACK OF JURISDICTION** |\
| RESPONDENT MOVES that the above-entitled case be dismissed for lack of jurisdiction upon the ground that the petition was not filed within the time prescribed by I.R.C. §§ 6213(a) or 7502. |\
| IN SUPPORT THEREOF, respondent respectfully states: |\
| 1\. The statutory notice of deficiency dated \[date\] upon which notice the above-entitled case is based, was sent to petitioner at the last known address, \[address used in notice of deficiency\], by certified mail on \[date of notice of deficiency\], as shown by the date stamped \[by postal meter\] on the executed Application for Registration or Certification, United States Postal Service Form 3877, a copy or certified mail list on file in the office of \[name of office and location\], a duly authenticated copy of which is attached hereto as Exhibit A. |\
| 2\. The 90-day period for timely filing the petition with this Court from said notice of deficiency expired on \[day of week and date on which 90th day expired\], which date was not a legal holiday in the District of Columbia. |\
| 3\. The petition was filed with the Tax Court on \[date on which petition was filed\], which date is \[number of days after date of mailing the notice\] days after the mailing of the notice of deficiency. |\
| 4\. The copy of the petition served upon the respondent bears a notation that the date of the \[postmark or postmeter\] stamped on the cover in which the petition was mailed, by \[type of mail\] mail, to the Tax Court is illegible. |\
| 5\. The United States Postal Service has advised the respondent that an envelope, which was properly addressed to the Tax Court, mailed by \[type of mail\] from the \[city\] area and bearing a United States postmark with a date \[date on which the 90th day expired\], would have ordinarily been received on \[normal delivery date\] at the Tax Court. |\
| 6\. The petition was not filed with the Court within the time prescribed by I.R.C. §§ 6213 (a) or 7502. |\
| WHEREFORE, it is prayed that this motion be granted. |\
\
**Exhibit 35.11.1-37**\
\
### Motions to Dismiss for Lack of Jurisdiction: No Statutory Notice\
\
| **MOTION TO DISMISS FOR LACK OF JURISDICTION** |\
| :-: |\
| RESPONDENT MOVES that this case be dismissed for lack of jurisdiction upon the ground that no statutory notice of deficiency has been sent to the petitioner. |\
| IN SUPPORT THEREOF, respondent respectfully states: |\
| 1\. The petitioner seeks a redetermination of an alleged deficiency in income tax for taxable year \[year raised in petition\]. The alleged notice of deficiency dated \[date of purported notice\], is in fact \[description of actual document presented by petitioner\] . |\
| 2\. Despite a diligent search, respondent has been unable to locate a notice of deficiency issued to petitioner for the year(s) in issue. |\
| OR |\
| 2\. No statutory notice of deficiency authorized by I.R.C. § 6212, and required by I.R.C. § 6213(a) to form the basis for an appeal to this Court has been sent to the petitioner with respect to the taxable year \[years raised in petition\]. |\
| WHEREFORE, it is prayed that this motion be granted. |\
\
**Exhibit 35.11.1-38**\
\
### Motions to Dismiss for Lack of Jurisdiction: No Statutory Notice For Year Put In Issue\
\
| **MOTION TO DISMISS FOR LACK OF JURISDICTION**<br>**AND TO STRIKE AS TO THE TAXABLE YEAR \[Year\]** |\
| :-: |\
| RESPONDENT MOVES that this easel insofar as it relates to the taxable year \[year not put in issue by notice\] I be dismissed for lack of jurisdiction upon the ground that no deficiency in tax has been determined for said year. |\
| RESPONDENT FURTHER MOVES that \[paragraph or subparagraph in which this year is referred to\] of the petition in which reference is made to the taxable year \[year not put in issue by notice\] be stricken. |\
| IN SUPPORT THEREOF, respondent respectfully states: |\
| 1\. Respondent determined in the statutory notice of deficiency dated \[date of notice\] I upon which notice this case is based I that there are due from the petitioner deficiencies in income taxes for the taxable years \[years in issue by notice\] . |\
| 2\. No notice of deficiency authorized by I.R.C. §§ 6211 and 6212 has been sent to petitioner with respect to the taxable year \[year not put in issue by notice\] I which would give this Court jurisdiction over petitioner's tax liability for said year. |\
| WHEREFORE, it is prayed that this motion be granted. |\
\
**Exhibit 35.11.1-39**\
\
### Motions to Dismiss for Lack of Jurisdiction: Unauthorized Representative of Deceased Person\
\
|  |\
| :-: |\
| **MOTION TO DISMISS FOR LACK OF JURISDICTION**<br>**AS TO ESTATE OF (NAME) DECEASED, AND TO CHANGE CAPTION** |\
| RESPONDENT MOVES that the above-entitled case, insofar as it purports to be an appeal by or on behalf of the Estate of \[name of decedent\], Deceased, be dismissed for lack of jurisdictioni and that the caption be changed to read, \[name of surviving spouse\], Petitioner. |\
| IN SUPPORT THEREOF, respondent respectfully states: |\
| 1\. A joint statutory notice of deficiency dated \[date\], upon which notice the above-entitled case is based, was sent to the Estate of \[name of decedent\], Deceased and \[name of surviving spouse\] in which it was determined that they are jointly and severally liable for \[describe type of deficiency & additions to tax plus years involved\] inasmuch as the decedent and \[name of surviving spouse\], as husband and wife, jointly filed a Federal income tax return for said year. |\
| 2\. The 90-day period for timely filing a petition with this Court from said notice of deficiency expired on \[day of week & date on which 90-day period expired\], which date was not a legal holiday in the District of Columbia. |\
| 3\. A petition captioned in the name of Estate of \[name of decedent\], Deceased, and \[name of surviving spouse\], was timely filed with the Court by \[name of surviving spouse or counsel\] . Said petition was not executed by or on behalf of a fiduciary or personal representative duly appointed by a court of competent jurisdiction and legally entitled to institute a case on behalf of the Estate of \[name\], Deceased. It does not appear that petitioner \[name of surviving spouse\] is duly qualified as either a fiduciary or personal representative of the decedent. |\
| 4\. Since the petition has not been timely filed by a fiduciary or personal representative legally entitled to institute a case on behalf of the decedent or his estate, this Court does not have jurisdiction over the decedent or his estate. |\
| WHEREFORE, it is prayed that this motion be granted. |\
\
**Exhibit 35.11.1-40**\
\
### Motions to Dismiss for Lack of Jurisdiction: Violation of Bankruptcy Code Stay Provision\
\
| **MOTION TO DISMISS FOR LACK OF JURISDICTION**<br>**AS TO THE PETITIONER \[NAME\] AND TO CHANGE CAPTION** |\
| :-: |\
| RESPONDENT MOVES that the above-entitled case be dismissed for lack of jurisdiction as to the petitioner \[name\] upon the ground that the petition was filed in violation of the automatic stay provisions of 11 U.S.C. § 362(a) (8) and that the caption be changed by striking therefrom the name of \[name\]. |\
| IN SUPPORT THEREOF, respondent respectfully states: |\
| 1\. On \[date of bankruptcy petition\], petitioner, \[name\], filed a petition with the United States Bankruptcy Court for \[name of district\] under 11 U.S.C. Chapter \[number\]. A copy of the Bankruptcy Court's Notice of First Meeting of Creditors and of automatic stay is annexed hereto as Exhibit A. |\
| 2\. As a result of the filing of \[name of petitioner's\] bankruptcy petition, \[name of petitioner\] is precluded from commencing an action in this Court due to the automatic stay provisions of 11 U.S.C. § 362(a) (8). |\
| 3\. On \[date petition was filed in Tax Court\], petitioner \[name\] filed a joint petition with \[name of other petitioner\] with this Court. |\
| 4\. Since 11 U.S.C. § 362(a) (8) automatically stayed the commencement of this action by petitioner \[name\] in this Court, this Court does not have jurisdiction over petitioner \[name\] |\
| WHEREFORE, it is prayed that this motion be granted. |\
\
**Exhibit 35.11.1-41**\
\
### Table of Ninety Calendar Days\
\
![This is an Image: 30026084.gif](https://www.irs.gov/pub/xml_bc/30026084.gif)\
\
> This table is used to determine whether petitions are filed within 90 days after the notice of deficiency is mailed. All the dates in the year are arrayed in columns. Find the date of mailing and read across to the right, skipping one column. (If February 29 falls within the ninety days, subtract one day from the ending date found in the table.) Do not count Saturday, Sunday, or a legal holiday in the District of Columbia as the last day.\
\
[Please click here for the text description of the image.](https://www.irs.gov/media/157721 "")\
\
![This is an Image: 30026900.gif](https://www.irs.gov/pub/xml_bc/30026900.gif)\
\
> This is a continuation of the table used to determine whether petitions are filed within 90 days after the notice of deficiency is mailed.\
\
[Please click here for the text description of the image.](https://www.irs.gov/media/157726 "")\
\
**Exhibit 35.11.1-42**\
\
### Table of 150 Calendar Days\
\
![This is an Image: 30026085.gif](https://www.irs.gov/pub/xml_bc/30026085.gif)\
\
> This table is used to determine whether petitions are filed within 150 days after the notice of deficiency is mailed to a person outside the United States. All the dates in the year are arrayed in columns. Find the date of mailing and read across to the right, skipping two columns. (If February 29 falls within the ninety days, subtract one day from the ending date found in the table.) Do not count Saturday, Sunday, or a legal holiday in the District of Columbia as the last day.\
\
[Please click here for the text description of the image.](https://www.irs.gov/media/157731 "")\
\
**Exhibit 35.11.1-43**\
\
### Letter to Petitioner Regarding Late Filed Petition\
\
| \[Letterhead\] |\
| :-: |\
| \[Name and address of<br> petitioner or petitioner’s counsel\] |\
| Re: \[Petitioner\] v. Commissioner<br> Docket No. \[docket no.\] |\
| Dear \[name of petitioner or petitioner’s counsel\]: |\
| I am the attorney responsible for handling your recently filed case in the United States Tax Court. The preliminary question raised is whether your petition was timely filed. If your petition was not timely filed, the Court has no choice but to dismiss it. If the petition is dismissed, you will be required to fully pay the tax, file a claim for refund with the Internal Revenue Service, and, if the refund claim is disallowed, contest the issues in the district court or the Court of Federal Claims. |\
| The problem arises because the Tax Court has indicated that your petition was postmeter marked on \[date\], a few days before the expiration of the 90-day filing period, but that the petition was received by the Court later than the ordinary delivery time for documents so mailed and postmarked by the U.S. Postal Service. However, if you will send me a letter stating that the petition was actually deposited in the mail before the last pickup from the mailbox on or before the 90th day and showing the time, place and circumstances of the mailing, I will rely on your representation and not raise the jurisdictional issue to the Court. For your convenience, I am enclosing a return self addressed envelope for this purpose. |\
| It is important that you respond immediately. \[If a joint petition is involved, petitioners should be instructed that both should sign the letter.\] After this preliminary procedural matter is resolved, you will have an opportunity to resolve your case on an informal basis with our Appeals office. That office will contact you and arrange a conference at a mutually convenient time. \[Use of this paragraph would depend upon the circumstances of the case.\] |\
| If you should have any questions, please feel free to write or call me at \[telephone number\]. |\
|  | Sincerely, |\
\
**Exhibit 35.11.1-44**\
\
### Motions Addressed to the Petition: Failure to State Claim — No IRC § 6673 Penalty Requested\
\
|  |\
| :-: |\
| **MOTION TO DISMISS FOR FAILURE TO STATE A CLAIM**<br>**UPON WHICH RELIEF CAN BE GRANTED** |\
\
RESPONDENT MOVES, pursuant to Rule 40 of the Court's Rules of Practice and Procedure, that this Court dismiss the above entitled case for failure to state a claim upon which relief can be granted; and find in its order that there is due from the petitioner deficiencies in income taxes and additions to the taxes under I.R.C. § 6662 for the years and in the amounts set forth in the statutory notice of deficiency dated \[date\], upon which notice the above-entitled case is based.\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. On \[date\], petitioner filed a petition with this Court and alleged a disagreement with the notice of deficiency, in which respondent disallowed a war tax credit taken by the petitioner on his income tax returns filed for the taxable years \[year (s)\].\
\
2\. Petitioner's basis for claiming the above credit as stated in the petition is that petitioner is, upon religious grounds, opposed to the use of tax money for military purposes. In addition, petitioner claims a constitutional right to freedom of religious practice and therefore a right to have approximately \[amount\] percent of the income taxes refunded as a tax credit.\
\
3\. This Court and other federal courts have repeatedly held that a taxpayer may not refuse to comply with the federal tax laws based upon the taxpayer's disagreement, no matter how sincere, with the policies of the Federal Government. Greenberg v. Commissioner, 73 T.C. 806 (1980); Graves v. Commissioner, 579 F.2d 392 (6th Cir. 1978), aff'g T.C. Memo. 1976-353. In addition, this Court has repeatedly held in similar cases that the taxpayer's right to freedom of religion under the First Amendment to the Constitution was not violated by the requirement that the taxpayer pay income taxes even though part of his tax dollar went towards armaments. Muste v. Commissioner, 35 T.C. 13 (1961); Palmer v. Commissioner, T.C. Memo. 1981-604. Further, there is no provision in the Internal Revenue Code for the petitioner's claimed credit.\
\
4\. In similar cases where respondent has sought to dismiss an action because the petitioners have failed to state a claim upon which relief can be granted, this Court has approved the assertion of an addition to tax under I.R.C. § 6662 where the petitioners have not alleged in the petition specific facts to support their position that no addition to tax is warranted except their objection on moral, religious, or frivolous constitutional grounds to paying federal income taxes. Greenberg v. Commissioner, 73 T.C. 806 (1980); Wright v. Commissioner, T.C. Memo. 1981-65; Evans v. Commissioner, T.C. Memo. 1981-580.\
\
5\. The petition filed in this case does not allege any justiciable error with respect to the respondent's determinations in the notice of deficiency, and no justiciable facts in support of such error are extant therein as required by T.C. Rule 34 (b) (4) and ( 5) .\
\
6\. Accordingly, petitioners have failed to state a claim upon which relief can be granted.\
\
WHEREFORE, it is prayed that this motion be granted.\
\
**Exhibit 35.11.1-45**\
\
### Motions Addressed to the Petition: Failure to State Claim — Claim for Penalties Under IRC § 6673\
\
| **MOTION TO DISMISS FOR FAILURE TO STATE A CLAIM UPON WHICH**<br>**RELIEF CAN BE GRANTED AND TO IMPOSE A PENALTY UNDER I.R.C. § 6673** |\
| :-: |\
| RESPONDENT MOVES, pursuant to Rule 40 of the Rules of Practice and Procedure'of the United States Tax Court, that the above-entitled case be dismissed for failure to state a claim upon which relief can be granted, and that the Court find in its order that there is due from the petitioner, the following deficiencies and additions to the taxes, as set forth in the statutory notice of deficiency which was dated \[date\]: |\
|  | Year<br> \[date\]<br> \[date\]<br> \[date\]<br> \[date\]<br> Totals | Deficiency<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\] | § 6651 (a) (1)<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\] | § 6651 (a) (2)<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\] | § 6654<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\] |\
| RESPONDENT FURTHER MOVES that the Court award penalties to the United States in an appropriate amount, pursuant to I.R.C. § 6673, based upon the fact that petitioner has instituted these proceedings primarily for the purpose of delay and/or petitioner's position in the present case is frivolous or groundless. |\
| IN SUPPORT THEREOF, respondent respectfully states: |\
| 1\. Respondent, in the notice of deficiency issued to petitioner on \[date\], a copy of which is attached hereto as Exhibit B, determined deficiencies and additions to the taxes for the taxable years \[year\] through \[year 2\], as set forth above, based upon: |\
| \[Briefly set forth basis for deficiency determination(s)\]. |\
| 2\. On \[date\], petitioner filed a purported petition with the United States Tax Court. On \[date\], the United States Tax Court ordered that an amended petition be filed by \[date\], because such purported petition did not comply with the rules of the Tax Court as to the form and content of a proper petition. |\
| 3\. On \[date\], petitioner filed an amended petition with the United States Tax Court. Said petition, a copy of which is attached hereto as Exhibit A, is not in conformance with T.C. Rule 34 (b). |\
| 4\. T.C. Rule 34(b) provides, in pertinent part, that the petition in a deficiency action shall contain "clear and concise assignments of each and every error which the petitioner alleges to have been committed by the Commissioner in the determination of the deficiency or liability. . . . Any issue not raised in the assignment of errors shall be deemed to be conceded." |\
| 5\. Petitioner's assignment of errors, upon which this case is based, in part alleges: |\
| \[Briefly set forth petitioner's contentions\]. |\
| 6\. Petitioner makes no factual claims of error in his petition, but argues only law and legal conclusions therein. |\
| 7\. No justiciable error has been alleged in the petition with respect to the Commissioner's determination of the deficiencies and additions to the taxes, and no facts in support of any such error are apparent therein. The absence in the petition of specific justiciable allegations of error and of supporting facts permits this Court to grant respondent's motion under T.C. Rule 123(b). Dwight v. Commissioner, T.C. Memo. 1981- 609; Klein v.Commissioner, 45 T.C. 308 (1965); Goldsmith v. Commissioner, 31 T.C. 56 (1958). |\
| 8\. The document filed in this case is not a proper petition, but rather is a statement making frivolous constitutional arguments with no factual basis. Petitioner's positions are totally without merit. This Court and other Federal Courts have repeatedly upheld the validity of the Federal income tax laws against Sixteenth Amendment challenges. United States v. Stillhammer, 706 F.2d 1072 (10th Cir. 1983); Hayward v. Day, 619 F.2d 716 (8th Cir. 1980); Adams v. Commissioner, 82 T.C. 403 (1984). |\
| 9\. The document filed as the petition does not comply with the Rules of the Tax Court as to the form and content of the petition and fails to state a claim upon which relief can be granted. |\
| 10\. Petitioner has instituted these proceedings primarily for the purpose of delay and/or petitioner's position in the present case is frivolous or groundless. Such an action falls within the bounds of I.R.C. § 6673, Penalties Assessable for Instituting Proceedings Before the Tax Court Primarily for Delay. |\
| WHEREFORE, it is prayed that this motion be granted and that this Court award damages in an appropriate amount pursuant to section 6673. |\
\
**Exhibit 35.11.1-46**\
\
### Motions Addressed to the Petition: Motion to Strike\
\
| **MOTION TO STRIKE** |\
| :-: |\
| RESPONDENT MOVES, pursuant to the provisions of Rule 52 of the Court's Rules of Practice and Procedure, that this Court strike from the petition the assignments of error in subparagraphs and the purported allegations of fact in subparagraphs of the petition. |\
| IN SUPPORT THEREOF, respondent respectfully states: |\
| 1\. On \[date\], petitioner filed a timely petition with this Court in which petitioner put in issue the deficiencies and additions to the tax determined by the respondent in the notice of deficiency sent to the petitioner by certified mail on \[date\]. |\
| 2\. The assignments of error in subparagraphs are immaterial, frivolous and nonjusticiable. See Wright v. Commissioner, T.C. Memo. 1981-65, n.5. |\
| 3\. The allegations of fact in subparagraphs are frivolous, immaterial and nonjusticiable and do not comply with Rule 34(b) (5) of this Court's Rules of Practice and Procedure. |\
| WHEREFORE, respondent prays that this motion be granted. |\
\
\\_\\_\\_\_\_\_\
\
### Note:\
\
A motion of this type should be filed only if a substantial basis therefore can be demonstrated. Irrelevant allegations in the petition which do not affect the determination of the tax, for example, may be met satisfactorily by simple denials in the answer.\
\
**Exhibit 35.11.1-47**\
\
### Motions Addressed to the Petition: Motion for a More Definite Statement or to Strike\
\
|  |\
| :-: |\
| **MOTION FOR MORE DEFINITE STATEMENT OR TO STRIKE** |\
\
RESPONDENT MOVES, pursuant to the provisions of Rule 51(a) of the Court's Rules of Practice and Procedure, that the Court enter an order requiring the petitioner to file a more definite statement of the alleged errors of the respondent and the facts upon which petitioner relies to sustain the alleged errors of respondent.\
\
RESPONDENT FURTHER MOVES, pursuant to the provisions of Rule 51(b) of the Court's Rules of Practice and Procedure, that upon failure of the petitioner to amend the petition in accordance with such order, the Court strike from the petition the allegations of error in subparagraphs \[#\] through \[#\], of paragraph \[#\] of the petition and the purported allegations of facts in subparagraphs \[#\] through \[#\] of paragraph \[#\] of the petition.\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. In the statutory notice of deficiency dated \[date\], upon which notice the above-entitled case is based, the respondent determined that there are deficiencies due from the petitioner in income taxes and additions to tax under I.R.C. § 6662 for the years and the amounts set forth in said notice of deficiency.\
\
2\. The determination of the respondent is based on his decision that the petitioner is not entitled to claimed employee business expenses in the amounts of $ \[amounts\] for taxable years \[year(s)\], respectively; claimed itemized deductions in the amounts of $ \[amounts\] for taxable years \[year(s)\], respectively; claimed exemptions for alleged dependents in the amounts of $ \[amounts\] for taxable years \[year(s)\], respectively; and that the underpayment of income taxes for taxable years \[year(s)\] was due to the petitioner's negligent or intentional disregard of rules and regulations.\
\
3\. In the petition filed with this Court on \[date\], the petitioner makes no allegations of justiciable error as to the adjustments to taxable income made by the respondent or as to the determination that the underpayment of income taxes was due to the petitioner's negligent or intentional disregard of rules and regulations, except in regard to the disallowance of the claimed exemptions. Subparagraphs \[#\] through \[#\] of paragraph \[#\] and subparagraphs \[#\] through \[#\] of paragraph \[#\] of the petition contain irrelevant, immaterial, and frivolous allegations of error.\
\
4\. Subparagraphs \[#\] through \[#\] of paragraph \[#\] of \[#\] the petition contain irrelevant, immaterial, and frivolous allegations of facts and do not contain clear and concise statements of facts as required by Rule 34(b) (5) of the Court's Rules of Practice and Procedure.\
\
WHEREFORE, respondent prays:\
\
That the Court enter an order requiring the petitioner to file an amended petition containing a more definite statement as to each and every justiciable error which the petitioner is relying on in petitioner's attempt to prove that the respondent's determination of deficiencies and additions to tax was incorrect and containing clear and concise statements of facts on which petitioner bases a more definite statement of justiciable errors;\
\
That upon failure of the petitioner to comply with such order of the Court, that the Court strike from the petition subparagraphs \[#\] through \[#\] of paragraph \[#\] and subparagraphs \[#\] through \[#\] of paragraph \[#\] of the petition.\
\
**Exhibit 35.11.1-48**\
\
### Tax Court Rule 37(c) Motion\
\
|  |\
| :-: |\
| **MOTION FOR ENTRY OF ORDER THAT UNDENIED ALLEGATIONS**<br>**IN ANSWER BE DEEMED ADMITTED** |\
\
RESPONDENT MOVES , pursuant to the provisions of Rule 37(c) of the Court's Rules of Practice and Procedure, that the Court enter an order in the above-entitled case that the undenied allegations of fact set forth in paragraph(s) of the answer be deemed to be admitted.\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. Respondent on \[date\], timely filed an answer setting forth the material allegations of fact relied upon to sustain the issue(s), in respect of which the burden of proof is placed upon respondent by \[statute or Rule 142(a)\] A copy of the answer was served on petitioner by respondent on \[date\].\
\
2\. Although required to do so under the provisions of T.C. Rule 37, petitioner filed no reply. The time within which to file such reply expired on \[date\].\
\
3\. The material allegations of fact set forth in the paragraphs of respondent's answer listed above stand undenied.\
\
4\. In the absence of the filing of the required reply, the case may not be deemed at issue under the provisions of T.C. Rule 38 until the entry of an order under T.C. Rule 37(c), as is herein requested.\
\
5\. The period within which to file a motion with respect to a reply will not expire until \[date\], and this motion is filed within the time permitted by T.C. Rule 37(c).\
\
WHEREFORE, it is prayed that this motion be granted.\
\
**Exhibit 35.11.1-49**\
\
### Motion to Dismiss for Lack of Prosecution (Generally)\
\
| **MOTION TO DISMISS FOR LACK OF PROSECUTION** |\
| :-: |\
| RESPONDENT MOVES that the Court dismiss the above-entitled case for lack of prosecution and find in its order that there is due from petitioner a deficiency in income tax for the taxable year \[year\] in the amount of $ \[amount\], as set forth in the statutory notice of deficiency dated \[date\], upon which notice the above-entitled case is based. |\
| IN SUPPORT THEREOF, respondent respectfully states: |\
| 1\. This case was regularly called for trial at the Trial Session of this Court on \[date\], at \[city, state\]. Counsel for respondent appeared and announced ready for trial. No appearance was made by or on behalf of petitioner. |\
| 2\. All the material allegations of fact set forth in the petition in support of the assignments of error have been denied by respondent in his answer. No issues have been raised upon which the burden of proof is upon respondent, and respondent has not conceded any error assigned in the petition. |\
| 3\. No evidence has been adduced in support of the assignments of error raised in the petition. |\
| 4\. A copy of the notice of deficiency upon which this case is based is annexed to respondent's answer as Exhibit A. |\
| WHEREFORE, it is prayed that this motion be granted. |\
\
**Exhibit 35.11.1-50**\
\
### Motion to Dismiss for Lack of Prosecution: Nordstrom Procedure — Joint Petitioners\
\
|  |\
| :-: |\
| **MOTION TO DISMISS FOR LACK OF PROSECUTION** |\
\
RESPONDENT MOVES that this case, insofar as it purports to be an appeal by or on behalf of \[name\], deceased, be dismissed for lack of prosecution, and that the Court find in its order that there is due from petitioner \[name\], deceased, a deficiency in income tax for the taxable year \[year\] in the amount of $ \[amount\] and an addition to the tax for the taxable year \[year\], under the provisions of I.R.C. § 6651, in the amount of $ \[amount\], as reduced from the deficiency in the amount of $ \[amount\], and an addition to the tax in the amount of $ \[amount\], as set forth in the statutory notice of deficiency dated \[date\], upon which the above-entitled case is based.\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. Respondent has been advised that petitioner \[name\], deceased, died on \[date\], at \[location, city, state\], which date is subsequent to the filing of the petition in this case. A copy of petitioner's death certificate is attached as Exhibit A.\
\
2\. Respondent has been advised that no representative or fiduciary is currently authorized to act on behalf of the estate of \[name\], deceased.\
\
3\. Respondent has been advised that petitioner \[name\], deceased, left a will naming the surviving spouse, \[name\], as executrix, but because the estate is de minimis the will has and will not be submitted to the Surrogate's Court for probate. Thus, there is no duly authorized representative available to act on behalf of the estate.\
\
4\. At present, the only ascertainable heirs at law of the decedent are the surviving spouse, \[name\] and the surviving issue, \[name\], who resides at \[full street address, city, state\], and \[name\], \[full street address, city, state\].\
\
5\. No issues have been raised upon which the burden of proof is upon respondent. However, respondent has conceded a portion of the disallowance initially set forth in the statutory notice of deficiency. Attached hereto, as Exhibit A, is a computation setting forth the basis of the proposed deficiency.\
\
6\. No evidence has been adduced in support of the assignments of error raised in the petition with the exception of the items previously allowed.\
\
7\. A stipulation of settlement, reflecting the agreement between respondent and petitioner \[name\] is submitted herewith for filing.\
\
8\. Neither the surviving spouse or surviving issue object to the granting of the motion to dismiss as to petitioner \[name\].\
\
WHEREFORE, it is prayed that this motion be granted.\
\
**Exhibit 35.11.1-51**\
\
### Motion for Continuance of Trial (Example 1)\
\
| **MOTION TO CONTINUE GENERALLY** |\
| :-: |\
| RESPONDENT MOVES, pursuant to the provisions of Rule 133 of the Tax Court's Rules of Practice and Procedure, that the Court remove the above-entitled case from the Trial Session of the Court scheduled to commence at \[location\], on \[date\], and to restore the case to the general trial docket. |\
| IN SUPPORT THEREOF, respondent states: |\
| 1\. On \[date\], petitioners filed an imperfect petition with this Court, and this court entered, on \[order date\], an Order for Proper Petition and Filing Fee requiring that a petition proper as to form and content be filed and that the appropriate filing fee be paid on or before \[date\]. |\
| 2\. Respondent has informed petitioners that he did not receive notice that the said petition had been perfected, and, accordingly, the case was not referred to the Appeals Division for possible settlement prior to the case being set for trial in \[location\]. |\
| 3\. Petitioners have informed respondent's counsel that they would like to pursue settlement of this matter and wish the opportunity to do so administratively. They are appearing pro se. |\
| 4\. Respondent believes that the case is susceptible of settlement by the Appeals Division. |\
| 5\. Petitioners have no objection to this motion. |\
| WHEREFORE, it is prayed that this motion be granted. |\
\
**Exhibit 35.11.1-52**\
\
### Motion for Continuance of Trial (Example 2)\
\
|  |\
| :-: |\
| **MOTION FOR CONTINUANCE** |\
\
RESPONDENT MOVES , pursuant to the provisions of Rule 133 of the Tax Court's Rules of Practice and Procedure, that this case be continued from the calendar of the Court commencing \[date\], in \[city, state\], and restored to the Court's general trial docket.\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. The petition in this case was filed \[date filed\] / the case was at issue on or after \[date\]. The tax year involved in this case is \[year\].\
\
2\. Petitioner \[name\] is the subject of a criminal referral to the Department of Justice. The matter referred involves the same issues as those that are pending in this case. The criminal matters are expected to be completed by \[estimated completion date\].\
\
3\. The potential exercise by petitioner \[name\] of his Fifth Amendment rights in connection with this case will prevent the respondent from adequately presenting its case.\
\
4\. The trial of this case during the \[calendar date\] session of this Court would be premature and may present legal problems and issues that could be avoided if the parties had the opportunity to develop fully their cases.\
\
5\. The granting of this motion will conserve the Court's time and will avoid undue hindrance in the resolution of this case.\
\
6\. Petitioners' counsel objects to the granting of this motion.\
\
WHEREFORE, it is prayed that this motion be granted.\
\
**Exhibit 35.11.1-53**\
\
### Motion to Calendar and Consolidate or In the Alternative to Continue\
\
|  |\
| :-: |\
| **MOTION TO CALENDAR AND CONSOLIDATE**<br>**OR IN THE ALTERNATIVE TO CONTINUE** |\
\
RESPONDENT MOVES that the Court calendar Docket No. \[docket no.\] for trial at the Trial Session of the Court scheduled to commence at \[city, state\] on \[date\]. This case is related to Docket No. \[docket 2 no.\] presently scheduled for trial at that trial session.\
\
RESPONDENT FURTHER MOVES that if the motion to calendar be granted, the cases at Docket Nos. \[docket no.\] and \[docket 2 no.\] be consolidated for trial, briefing and opinion.\
\
RESPONDENT FURTHER MOVES that if the motion to calendar be denied, the case at Docket No. \[docket 2 no.\], presently scheduled for trial, be continued generally and the related cases in any event be consolidated for future trial, briefing and opinion.\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. The case at Docket No. \[docket 2 no.\] is presently scheduled for trial at \[city, state\] on \[date\].\
\
2\. Petitioners in the case at Docket No. \[docket no.\] are the same as the petitioners in the case at Docket No. \[docket 2 no.\]\
\
3\. \[Insert a brief description as to what the cases involve.\]\
\
4\. Consolidation of the trial of these cases will conserve the time of the Court and of the parties.\
\
5\. Respondent estimates that only three additional trial hours will be necessary if Docket No. \[docket no.\] is added to the trial calendar.\
\
6\. If the motion to calendar Docket No. \[docket no.\] is denied, the Court should continue the case at Docket No. \[docket 2 no.\] from the present trial session in order that both cases may be tried together, thereby conserving the time of the Court and preventing the duplication of witnesses, evidence, briefs, etc.\
\
WHEREFORE, it is prayed:\
\
(1) That the Court grant the motion to calendar Docket No. \[docket no.\]; and\
\
(2) That the above-entitled cases be consolidated for trial, briefing and opinion; or\
\
(3) In the alternative, if the Court denies the motion to calendar Docket No. \[docket no.\], that the Court continue Docket No. \[docket 2 no.\] generally and consolidate such cases for purposes of trial, briefing and opinion.\
\
**Exhibit 35.11.1-54**\
\
### Motion for Pretrial Conference\
\
|  |\
| :-: |\
| **MOTION FOR PRETRIAL CONFERENCE** |\
\
RESPONDENT MOVES, pursuant to provisions of Rule 110 of the Tax Court's Rules of Practice and Procedure that the Court schedule an informal pretrial conference at the United States Tax Court in Washington, D.C., on \[date\], in lieu of or in addition to its scheduled hearing on the same date at its Motions Session at 10:00 a.m. This request is made for the purpose of responding to all of the matters described in this Court's Order and discussing all essential matters relative to the preparation of this case for trial, especially the stipulation of facts, evidence, and issues.\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. On \[date\], following the presentation of an oral status report by the parties on \[date\], among other things this Court ordered the parties to make a further oral status report at its Motions Session at 10:00 a.m. on \[date\], in Washington, D.C., for the purpose of informing the Court "exactly what issues and/or items have been settled and inform the Court further as to what issues and/or items the parties expect to have been settled when this case is called for trial on \[date\]."\
\
2\. The parties have been diligently preparing various drafts of stipulations, incorporating voluminous evidence, approximating two full file cabinets in volume.\
\
3\. The parties have made substantial progress but have not reached a formal agreement as to any final portion of the stipulation.\
\
4\. An orderly and expeditious trial cannot take place without a comprehensive stipulation, which incorporates the above described documents.\
\
5\. For the above reasons, it is believed that this Court will not want to require a trial of this case until a comprehensive stipulation has been executed.\
\
6\. It is anticipated that a large number of witnesses will be required, to some extent depending upon whether various third party records can be stipulated without objection.\
\
7\. Accordingly, the Court's informal guidance will be beneficial in furthering the parties efforts to be ready for an orderly and efficient trial presentation.\
\
WHEREFORE, it is prayed that this motion be granted.\
\
**Exhibit 35.11.1-55**\
\
### Tax Court Rule 91(f) Motion\
\
|  |\
| :-: |\
| **MOTION TO SHOW CAUSE WHY PROPOSED FACTS IN EVIDENCE**<br>**SHOULD NOT BE ACCEPTED AS ESTABLISHED** |\
\
RESPONDENT MOVES, pursuant to the provisions of Rule 91(f) of the Tax Court's Rules of Practice and Procedure, that the Court issue an Order To Show Cause requiring the above-named petitioners, at the earliest practical time, to show cause why the facts and evidence set forth in the attached copy of respondent's proposed Stipulation of Facts, marked Exhibit A, should not be accepted as established for the purposes of this case.\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. The Court by its trial notice set the above-entitled case for trial at the \[city, state\] trial session which commences on \[date\]. This motion is timely under the provisions of Rule 91(f) (1), which requires such motion to be filed not later than 45 days prior to the date set for the call of the case from a trial calendar.\
\
2\. This case involves the petitioners' liability for deficiencies in income taxes and additions to taxes for the taxable years \[year(s)\]. The deficiencies in taxes and additions to taxes, which were asserted under I.R.C. § 6663(a), total $ \[amount\] . During the years in issue, the petitioners received taxable income from various third-party sources.\
\
3\. In a telephone conversation with respondent's counsel on \[date\], petitioners' counsel stated that in the absence of any settlements of this case, \[he/she\] refuses to stipulate to any facts involved in the case. \[He/she\] added that \[he/she\] wouldn't even stipulate to the taxpayers' names.\
\
4\. Respondent has set forth in Exhibit A, attached hereto, a proposed Stipulation of Facts along with Exhibits, in accordance with the requirements of Rule 91(a) of the Tax Court Rules of Practice and Procedure.\
\
5\. Respondent has set forth in Exhibit B, attached hereto, numbered in conformance with Exhibit A, the source or present location of the evidence on which each fact in Exhibit A is based.\
\
6\. In compliance with the Proof of Service requirement of Rule 91(f) (1) (E) and pursuant to the provisions of I.R.C. § 7455, a copy of this motion, together with the attachments, was served on petitioners' counsel by certified mail on \[date\], as shown by the Certificate of Service signed by an attorney for respondent, a copy of which is attached hereto as Exhibit C.\
\
WHEREFORE, it is prayed:\
\
(1) That this motion be granted and that the Court order the petitioners to show cause why the facts and evidence covered by this motion, set forth in Exhibit A attached hereto, should not be accepted as established for the purpose of this case in accordance with Rule 91(f) of the Court's Rules of Practice and Procedure; and\
\
(2) If pursuant to the Order To Show Cause, the petitioners do not agree to accept as established the facts set forth in attached Exhibit A, a hearing thereon be held at a convenient date prior to \[date\].\
\
|  |\
| :-: |\
| EXHIBIT A |\
| **STIPULATION OF FACTS** |\
| It is hereby stipulated that, for the purpose of this case, the following statements may be accepted as true, except as qualified herein, and all exhibits referred to herein and attached hereto, are incorporated in this stipulation and made a part thereof. The parties reserve their right to object to the admission of such facts and exhibits on the grounds of materiality and relevancy. Either party may introduce other and further evidence not inconsistent with the facts herein stipulated or the contents of the exhibits. |\
| 1\. \[Set forth specific facts\]. |\
| 2\. \[Set forth specific facts\]. |\
|  |\
| EXHIBIT B |\
| **SOURCE AND LOCATION OF EVIDENCE SUPPORTING EXHIBIT A** |\
| 1\. \[Set forth source and location of evidence supporting facts (ex., petitioner's personal knowledge)\]. |\
| 2\. \[Set forth source and location of evidence supporting facts (ex., income tax return)\]. |\
\
**Exhibit 35.11.1-56**\
\
### Motion for Partial Summary Judgment\
\
| **MOTION FOR PARTIAL SUMMARY JUDGMENT** |\
| :-: |\
| RESPONDENT MOVES, pursuant to the provisions of Rule 121 of the Court's Rules of Practice and Procedure, for a partial summary adjudication in respondent's favor in the above-entitled case upon the sole issue of whether petitioner is liable for an addition to tax under I.R.C. § 6662(d) for the year \[year\] as determined in the statutory notice of deficiency upon which this case is based. |\
| IN SUPPORT THEREOF, respondent respectfully states: |\
| 1\. This motion is made at least 30 days after the date that the pleadings in this case were closed and within such time as not to delay the trial. T.C. Rule 121(a). |\
| 2\. In the notice of deficiency upon which this case is based, respondent determined that during the taxable year \[year\] petitioner received unreported gross income in the amount of $ \[amount\] , that petitioner is liable for a resulting deficiency in income tax of $ \[amount\] and that petitioner is liable for an addition to tax under I.R.C. § 6662(d) of $ \[amount\]. |\
| 3\. The petition raises no justiciable issues, nor presents any genuine issue of material fact for trial. Upon review of the documents filed, respondent's counsel believes the Court may render a decision in this case as a matter of law. |\
| 4\. \[Set forth appropriate legal analysis\] |\
| WHEREFORE, it is prayed that this motion be granted. |\
\
**Exhibit 35.11.1-57**\
\
### Motion for Summary Judgment and Supporting Affidavit\
\
|  |\
| :-: |\
| **MOTION FOR SUMMARY JUDGMENT** |\
\
RESPONDENT MOVES, pursuant to Rule 121 of the Court's Rules of Practice and Procedure, for a summary adjudication in respondent's favor upon all of the legal issues in controversy.\
\
IN SUPPORT THEREOF, respondent respectfully shows unto the Court:\
\
1\. On \[date\], respondent issued a statutory notice to petitioner involving his \[year\] personal income tax liabilities and asserting additions to tax under I.R.C. § 6662(d).\
\
2\. On \[date\], a petition was filed with the Tax Court alleging that respondent erred in determining deficiencies in the amount of $ \[amount\], and section 6662(d) penalties in the amount of $ \[amount\].\
\
3\. In respondent's answer, respondent denied petitioner's allegations \[optional: and alleged an increased deficiency to $ \[amount\] for the \[year\] tax year.\
\
4\. Petitioner is liable for a deficiency for tax year \[year\] of $ \[amount\] instead of the $ \[amount\] determined in the statutory notice of deficiency.\
\
5\. \[Set forth appropriate legal analysis\].\
\
6\. In further support of this motion, respondent \[optional: files a memorandum of law herewith and\] respectfully states that counsel of record has reviewed the administrative file and has concluded, on the basis of the review and the facts deemed admitted, that there remains no genuine issue of material fact for trial, and that the record made in this case, including the supporting affidavit and exhibits annexed thereto, amply support the pending motion for summary judgment.\
\
WHEREFORE, it is prayed that this motion be granted and that the determination of the Commissioner be sustained.\
\
|  |\
| :-: |\
| **AFFIDAVIT OF \[NAME OF ATTORNEY\]** |\
| State of \[name of State\], to wit: |\
| I, \[name\], being duly sworn, depose and state under oath that: |\
| 1\. I am an attorney admitted to practice before the United States Tax Court and this case has been assigned to me. |\
| 2\. I am competent to testify as to formal matters involved in this case because the Commissioner's administrative file has come into my custody and control in connection with the defense of this matter. |\
| 3\. Attached as Exhibit A is a true and correct copy of the statutory notice of deficiency, upon which this case is based, dated \[date\]. |\
| 4\. In respondent's answer, respondent alleged facts concerning the penalty under I.R.C. § 6662(d) and increased deficiency for the \[year\] year, for which the burden of proof is placed on respondent pursuant to statute and T.C. Rule 142. |\
| 5\. Attached as Exhibit B is a certified copy of the petitioner's transcript of account, verifying the amounts shown in the statutory notice of deficiency. \[Optional: This transcript also establishes an additional deficiency of $ \[amount\] based on \[provide basis for increased deficiency\]. |\
| 6\. Petitioner has not presented any documents or other evidence to challenge the Commissioner's determination of deficiency in this case. |\
|  |\
\
### Note:\
\
An unsworn declaration pursuant to 28 U.S. C. § 1746 may be used in lieu of a sworn affidavit.\
\
**Exhibit 35.11.1-58**\
\
### Motion for Protective Order in Opposition to Petitioner's Motion for Partial Summary Judgment\
\
|  |\
| :-: |\
| **MOTION FOR PROTECTIVE ORDER** |\
| RESPONDENT MOVES, pursuant to Tax Court Rule 103(a) (1), that the Court enter a protective order prohibiting the use by petitioners of a Motion for Partial Summary Judgment in the above-entitled case. Respondent believes that the relief sought by respondent's motion is appropriate; however, nothing herein constitutes a waiver of respondent's right to file a notice of objection on or before the due date in the event the relief requested herein is denied or otherwise not granted. |\
| IN SUPPORT THEREOF, respondent respectfully states: |\
| 1\. These cases involve losses claimed as a result of commodity tax straddles executed between \[date(s)\]. Generally, the purpose of a commodity tax straddle is (1) to defer short term capital gains from unrelated transactions from the year of realization to a subsequent year and (2) convert short-term capital gains to long-term. 1001 (1984). See Fox v. Commissioner, 82 T.C. |\
| 2\. Petitioners claimed substantial losses which resulted in deficiencies as follows: |\
|  | Year | Amount of Loss<br> $<br> $ | Amount of Deficiency<br> $<br> $ |\
| 3\. The above subject cases are set for trial at a Special Session of the Court in \[location\], scheduled to commence on \[date\]. |\
| 4\. On \[date\], petitioners filed a Motion for Partial Summary Judgment. Petitioners seek partial summary judgment on the issue of the deductibility of their tax straddle created losses. For the petitioners to prevail, the Court is required to conclude that the petitioners' tax straddles were entered into for profit and that the putative losses constituted genuine or real losses. |\
| 5\. Respondent submits that Petitioners' Motion for Partial Summary Judgment is inappropriate because: |\
| a. The issue petitioners address — whether the transaction was entered into for a profit — is inherently factual and there exists a patent genuine issue of material fact requiring extensive trial testimony (transactional and expert); |\
| b. The petitioners have failed to address an independent basis for the disallowance of the tax straddle losses even assuming arguendo petitioners were to prevail on the profit motive issue; and |\
| c. The use of summary judgment would unduly delay the proceedings and constitutes a burdensome exercise misdirected toward an unrealistic, unattainable objective which needlessly wastes the time of the Court and respondent. |\
| 6\. To be allowable under Section 108 of the Deficit Reduction Act of 1984, Pub. L. 98-369, 98 Stat. 494, 630, as amended by section 1808(d) of the Tax Reform Act of 1986, Pub. L. 99-514, 100 Stat. 2817 (DEFRA), petitioners must establish that their pre- \[year\] tax straddles satisfy the following test: any loss from such disposition shall be allowed for the taxable year of disposition if such position is part of a transaction entered into for profit. |\
| 7\. The profit motive requirement of section 108 of DEFRA is identical to the profit motive requirement of I.R.C. § 165(c) (2) which provides: "Losses incurred in any transaction entered into for a profit, though not connected with a trade or business . . ." |\
| 8\. Treas. Reg. § 1.165-13T, Q & A (2) provides the relevant standard as follows: |\
|  | A transaction is considered entered into for profit if the transaction is entered into for profit within the meaning of section 165(c) (2) of the Code. In this respect, section 108 of the Act restates existing law applicable to straddle transactions. All the circumstances surrounding the transaction, including the magnitude and timing for entry into, and disposition of, the positions comprising the transaction are relevant in making the determination whether a transaction is considered entered into for profit. Moreover, in order for section 108 of the Act to apply, the transaction must have sufficient substance to be recognized for Federal income tax purposes. Thus, for example, since a "sham" transaction would not be recognized for tax purposes, section 108 of the Act would not apply to such a transaction. |\
| 9\. Petitioners' Motion for Partial Summary Judgment has wholly failed to address the profit motive (or intent) issue mandated by the "entered into for profit" requirement of section 108 of DEFRA. Instead, petitioners have addressed themselves to the irrelevant question of the theoretical possibility of a scintilla of profit. Even assuming that were the issue — which it is not — there still remains a factual issue. |\
| 10\. While only a partial listing, among the relevant facts not addressed by petitioners are the following: |\
| a. Petitioners' understatement of commission costs, including specifically their: |\
| (1) failure to include the costs attributable to the bid-offer differential, which are substantial; and |\
| (2) failure to allocate petitioners' fixed expenses to the transactions at issue. |\
| b. Petitioners' recidivism, e.g., their history of utilizing noneconomic tax straddles, created substantial tax losses over the period \[date(s)\], inclusive, while in reality suffering economic loss limited only to the minimal out-of-pocket expenses. Fox v. Commissioner, 82 T.C. 1001 (1984). |\
| c. Petitioners' possible utilization of prearranged trades to create tax losses. |\
| d. Petitioners' failure to adhere to a profit purpose throughout the tax straddle transaction as evidenced by the utilization of noneconomic switch transactions for the sole purpose of realizing paper tax losses. |\
| 11\. Regardless of the standard of profit motive requirement, the issue is inherently factual and not susceptible to disposition by summary judgment. See, e.g., In re Yarn Processing Patent Validity Litigation, 498 F.2d 271 (5th Cir. 1974). |\
| 12\. Profit motive aside, there remains an independent basis for disallowance of a substantial part of petitioners' tax straddle created losses. Petitioners claimed losses which are being challenged on the ground that no real loss occurred. |\
| 13\. Losses created through accounting manipulations are not allowable. Fox v. Commissioner, 82 T.C. 1001 (1984). Independent of the existence of a straddle, there has been no genuine realization of a loss. McWilliams v. Commissioner, 331 U.S. 694 (1947). |\
| 14\. Requiring a complete response would be unduly burdensome. In order to respond to petitioners' motion respondent would be compelled to file a detailed factual statement including: |\
| a. A detailed explanation of petitioners' normal or regular trading activity demonstrating that petitioners' straddle trading activity was a separate and distinct tax motivated endeavor. See, e.g., Brown v. United States, 426 F.2d 355 (Ct. Cl. 1970). |\
| b. Petitioners' history of utilizing tax straddle transactions to defer and convey substantial unrelated (nonstraddle) income through economically insignificant transactions. |\
| c. Petitioners' history of losses from their tax straddle transactions. |\
| d. Requiring the submission of expert affidavits including possibly a complete transactional analysis of petitioners tax straddle transactions and the costs associated therewith; and |\
| e. Requiring the disclosure of impeachment evidence. |\
| 15\. In view of the inherent factual issues, it is respectfully submitted that devoting substantial time to the resolution of the profit motive issue in the context of summary judgment would not be in the best interest of the Court or the parties. |\
| WHEREFORE, it is prayed that this motion be granted. |\
\
**Exhibit 35.11.1-59**\
\
### Joint Motion to Submit Case Under Rule 122\
\
| **JOINT MOTION FOR LEAVE TO SUBMIT CASE UNDER RULE 122** |\
| :-: |\
| THE PARTIES JOINTLY MOVE for leave to submit this case, pursuant to Rule 122 of the Tax Court's Rules of Practice and Procedure, and request that the case be assigned to a division of the Court for briefing and report or decision. |\
| IN SUPPORT THEREOF, the parties respectfully show unto the Court: |\
| 1\. The petition in this case was filed with the Court on \[date\] . |\
| 2\. The answer to that petition was filed on \[date\]. |\
| 3\. The pleadings are closed and the parties are in agreement that this case does not require a trial for the submission of evidence. |\
| 4\. The parties also agree that the case may be submitted on the basis of the pleadings and the facts recited in the attached stipulation which is being filed concurrently with this motion. |\
| 5\. The parties request the Court to set the filing of simultaneous opening briefs at 60 days and simultaneous reply briefs at 30 days. |\
| WHEREFORE, it is prayed that this motion be granted. |\
\
**Exhibit 35.11.1-60**\
\
### Motion for Entry of Decision\
\
|  |\
| :-: |\
| **MOTION FOR ENTRY OF DECISION** |\
\
RESPONDENT MOVES, pursuant to the provisions of Tax Court Rule 50, that the Court enter a decision in the above-entitled case pursuant to the agreement of the parties and in accordance with the attached proposed decision document (Exhibit A), which reflects a deficiency in income tax due from petitioner for the taxable year \[year\] in the amount of $ \[amount\].\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. Prior to the date the Court had set for trial of this case, petitioner and respondent reached a basis of settlement of the above-captioned matter; however, the parties were unable to execute a decision document reflecting the settlement prior to this date.\
\
2\. On \[date\], respondent represented to the Court that the case was settled and requested additional time in which to submit the decision document.\
\
3\. On \[date\], respondent mailed petitioner's representative a proposed decision document, a copy of which is attached as Exhibit A. The accompanying letter requested that petitioner's representative execute and return the decision document by \[date\]. A copy of this letter is attached as Exhibit B.\
\
4\. On \[date\], respondent telephoned petitioner's representative in regard to the decision document. Petitioner's representative assured respondent that the executed decision document would be forthcoming.\
\
5\. On \[date\], respondent mailed a letter to petitioner's representative stating that if the decision document was not signed and returned by \[date\], this motion would be filed with the Court. A copy of this letter is attached as Exhibit C.\
\
6\. Not having received any communication from petitioner's representative by \[date\], this motion is submitted to the Court in order that the agreement reached by petitioner and respondent, as represented to the Court on \[date\], might be effectuated by the Court by entering a decision determining a deficiency in income tax due from petitioner for the taxable year \[year\] in the amount of $ \[amount\], as shown in Exhibit A.\
\
WHEREFORE, it is prayed that this motion be granted.\
\
**Exhibit 35.11.1-61**\
\
### Motion to Vacate Decision\
\
|  |\
| :-: |\
| **MOTION TO VACATE DECISION** |\
\
RESPONDENT MOVES that the Court vacate the decision entered in the above-entitled case.\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. Attached hereto as Exhibit A is a copy of the decision received by \[Field Counsel office\], on \[date of receipt\]. The Court placed the date of \[date of decision\], on that decision, when the year of entry should have been \[correct year\].\
\
2\. The respondent has contacted petitioner's counsel to advise of the typographical error and the respondent is submitting this motion as \[his/her\] motion rather than a joint motion solely because of the 30-day time constraint of Rule 162 of the Tax Court's Rules of Practice and Procedure.\
\
3\. The parties in this case continue with the desire to be bound by the settlement agreement reached. Accordingly, the respondent has submitted to the petitioner a new decision document so that the Court can reenter the decision with a current date of entry. That new decision will be submitted to the Court as soon as it has been returned to the respondent by petitioner's counsel.\
\
4\. The respondent believes that the Court's file should show the date the entered decision was received by mail from the respondent, and that date should be in \[correct year\] . If the Court requires further evidence of the time of submission of the original decision document, respondent requests such an order be issued.\
\
WHEREFORE, it is prayed that this motion be granted.\
\
**Exhibit 35.11.1-62**\
\
### TEFRA Partnership: Motion to Dismiss for Lack of Jurisdiction Pursuant to IRC § 6226 (b)(1)\
\
|  |\
| :-: |\
| **MOTION TO DISMISS FOR LACK OF JURISDICTION** |\
| RESPONDENT MOVES that the above-entitled case be dismissed for lack of jurisdiction on the ground that the tax matters partner has filed a readjustment petition within the 90-day period set forth in I.R.C. § 6226(a) with respect to the same notice of Final Partnership Administrative Adjustment, and pursuant to I.R.C. § 6226(b) (1) a partner other than the tax matters partner may file a petition only if the tax matters partner does not file a readjustment petition. |\
| IN SUPPORT THEREOF, respondent respectfully states: |\
| 1\. On \[date\], pursuant to I.R.C. § 6223 (a) (2), the respondent issued a notice of Final Partnership Administrative Adjustment to \[name of Tax Matters Partner\], \[address\], tax matters partner of (name of partnership) for the taxable year(s) \[year(s)\]. |\
| 2\. On \[date\], pursuant to I.R.C. § 6223 (a) (2) and (d) (2), the respondent issued notices of Final Partnership Administrative Adjustment to all notice partners, including the petitioners, \[name\], partners other than the tax matters partner \[or the designated member of a 5 percent group pursuant to § 6223(b) (2)\] of \[name of partnership\]. A copy of this notice is attached to the petition as Exhibit A. |\
| 3\. On \[date\], pursuant to I.R.C. § 6226(a) \[Name of Tax Matters Partner\], of \[Name of Partnership\] filed a petition \[or complaint\] in \[name of court\] Docket No. \[docket no.\] with respect to the attached notice of Final Partnership Administrative Adjustment. Such petition (or complaint) was filed within the 90-day period prescribed by I.R.C. § 6226(a). |\
| 4\. The instant petition, Docket No. \[docket no.\] was filed on \[date\] with respect to the same notice of Final Partnership Administrative Adjustment. |\
| 5\. The Court should dismiss the instant case for lack of jurisdiction because pursuant to I.R.C. § 6226(b) (1), any notice partner (and any five-percent group) may file a petition for readjustment with respect to a notice of Final Partnership Administrative Adjustment only if the tax matters partner does not file a readjustment petition within the 90-day period set forth in I.R.C. § 6226(a). |\
| WHEREFORE, respondent requests that this motion be granted. |\
|  |\
\
### Note:\
\
If there is any question as to the validity of the petition by the tax matters partner, the above motion must be submitted for prereview to Procedure & Administration.\
\
**Exhibit 35.11.1-63**\
\
### TEFRA Partnership: Motion to Dismiss for Lack of Jurisdiction Pursuant to IRC § 6226 (b)(2), (b)(4)\
\
|  |\
| :-: |\
| **MOTION TO DISMISS FOR LACK OF JURISDICTION** |\
| RESPONDENT MOVES that the above-entitled case be dismissed on the ground that it is a duplication of a previously filed petition regarding the same notice of Final Partnership Administrative Adjustment. |\
| IN SUPPORT THEREOF, respondent respectfully states: |\
| 1\. On \[date\], pursuant to I.R.C. § 6223 (a) (2), the respondent issued a notice of Final Partnership Administrative Adjustment to \[name of tax matters partner\], \[address\], tax matters partner of \[name of partnership\] for the taxable year(s) \[year (s)\]. |\
| 2\. On \[date\], pursuant to I.R.C. § 6223 (a) (2) and (d) (2), the respondent issued notices of Final Partnership Administrative Adjustment to all notice partners, including the petitioner, \[name\], partners other than the tax matters partner \[or the designated member of a five-percent group pursuant to § 6223(b) (2)\] of \[name of partnership\]. A copy of this notice is attached to the petition as Exhibit A. |\
| 3\. The tax matters partner, pursuant to I.R.C. § 6226(a), had 90 days after the mailing of the Final Partnership Administrative Adjustment to file a petition for readjustment of partnership items. |\
| 4\. The parties understand that no petition for readjustment of the partnership items was filed by the tax matters partner. |\
| 5\. On \[date\], pursuant to I.R.C. § 6226(b) (1), \[name of partner(s)\], partners other than the tax matters partner for the designated member of a 5 percent group pursuant to § 6223(b) (2) of \[name of partnership\], filed in Docket No. \[docket no.\], a petition for readjustment of partnership items with respect to the attached notice of Final Partnership Administrative Adjustment. |\
| 6\. The instant petition, Docket No. \[docket no.\] was filed on \[date\], with respect to the same notice of Final Partnership Administrative Adjustment. |\
| 7\. Pursuant to I.R.C. § 6226(b) (2) and (4) the Court should dismiss the instant case as a duplication of a previously filed petition regarding the same partnership taxable year(s). |\
| WHEREFORE, respondent requests that this motion be granted. |\
|  |\
\
### Note:\
\
If there is any question as to the validity of the first petition, the above motion must be submitted for prereview to Procedure & Administration.\
\
**Exhibit 35.11.1-64**\
\
### TEFRA Partnership: Motion to Dismiss for Lack of Jurisdiction — TEFRA Items Only\
\
|  |\
| :-: |\
| **MOTION TO DISMISS FOR LACK OF JURISDICTION** |\
\
RESPONDENT MOVES that the Court dismiss the above-captioned case for lack of jurisdiction on the ground that no valid statutory notice of deficiency under I.R.C. § 6212 was issued to the petitioner for the year 2001, the year purportedly in dispute in the above case.\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. A document entitled notice of deficiency was issued on \[date\] (Notice), to petitioner with respect to the taxable year \[year\] and purported to determine a deficiency in income tax in the amount of $ \[amount\]. The petition filed in this case is based upon the January Notice.\
\
2\. All of the adjustments to petitioner's \[tax year\] taxable income appearing in the Notice arise from the petitioner's interest in, and deductions claimed from, a partnership entitled \[name of partnership\].\
\
3\. \[name of partnership\] is a TEFRA partnership which for the taxable year \[year\] has its tax treatment determined at the partnership level pursuant to I.R.C. § 6221 through § 6234. The partnership is not excluded from the TEFRA provisions by reason of the small partnership exception of I.R.C. § 6231(a) (1) (B) (i) since the partnership had more than ten partners at one time during the taxable year. A notice of the beginning of administrative proceedings under § 6223(a) (1) was issued by respondent with respect to the \[name of partnership\] prior to the Notice in this case.\
\
4\. There are no non-TEFRA partnership items appearing in the Notice upon which the petition in this case was based.\
\
5\. The \[date\] notice is invalid and prohibited by I.R.C. § 6225. Maxwell v. Commissioner, 87 T.C. 783 (1986).\
\
6.No valid statutory notice of deficiency under I.R.C. § 6212 was issued to petitioner for the taxable year \[year\].\
\
7\. Petitioner's counsel has been contacted and has no objection to the granting of this motion.\
\
WHEREFORE, respondent requests that this motion be granted.\
\
**Exhibit 35.11.1-65**\
\
### TEFRA Partnership: Motion to Dismiss for Lack of Jurisdiction and to Strike — TEFRA and Non-TEFRA Items\
\
|  |\
| :-: |\
| **MOTION TO DISMISS AND TO STRIKE PARTNERSHIP ITEMS** |\
\
RESPONDENT MOVES that the court dismiss the portion of the above-captioned case insofar as it relates to adjustments from or to \[name of partnership\] and to strike the portion of the adjustments and pleadings pertaining to (and only to) \[name of partnership\].\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. A notice of deficiency was issued on \[date\], to petitioner with respect to a deficiency in income tax for the taxable year \[year\].\
\
2\. Certain, but not all, of the adjustments to petitioner's \[year\] taxable income appearing in the \[date\], notice of deficiency arise from the petitioner's interest in, and deductions claimed from, a partnership entitled \[name of partnership\].\
\
3\. \[name of partnership\] is a TEFRA partnership which for the taxable year \[year\] has its tax treatment determined at the partnership level pursuant to I.R.C. § 6221 through § 6234. The partnership is not excluded from the TEFRA provisions by reason of the small partnership exception of I.R.C. § 6231(a) (1) (B) (i) since the partnership had more than ten partners at one time during the taxable year. A notice of the beginning of administrative proceedings under I.R.C. § 6223(a) (1) was issued by respondent with respect to the \[name of partnership\] prior to the \[date\], notice in this case.\
\
4\. There are additional non-TEFRA partnership items appearing in the \[date\], notice upon which the petition in this case is based.\
\
5\. The \[date\] notice is valid, as non-TEFRA partnership items were adjusted and a deficiency was determined with respect to such non-TEFRA partnership items. However, insofar as adjustments to or from \[name of partnership\] were determined, the notice is invalid and prohibited by I.R.C. § 6225. Maxwell v. Commissioner, 87 T.C. 783 (1986).\
\
6\. Petitioner’s counsel has been contacted and has no objection to the granting of this motion.\
\
WHEREFORE, respondent requests that this motion be granted.\
\
**Exhibit 35.11.1-66**\
\
### TEFRA Partnership: Motion to Dismiss for Lack of Jurisdiction and to Strike With Respect to Additions to Tax\
\
|  |\
| :-: |\
| **MOTION TO DISMISS FOR LACK OF JURISDICTION**<br>**AND TO STRIKE WITH RESPECT TO ADDITIONS TO TAX** |\
\
RESPONDENT MOVES that the Court dismiss the above-captioned case insofar as it relates to additions to tax and to strike that portion of the pleadings pertaining to additions to tax.\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. On \[date\], pursuant to I.R.C. § 6223(a) (2), the respondent issued a notice of Final Partnership Administrative Adjustment to \[name of tax matters partner\], tax matters partner of \[name of partnership\], determining adjustments to the taxable year \[insert applicable tax years ending before August 6, 1997\] partnership return of \[name of partnership\].\
\
2\. In the \[date\], notice of partnership administrative adjustment, the respondent included an addendum raising additions to tax under I.R.C. § 6662. This addendum was attached for informational purposes only.\
\
3\. On \[date\], pursuant to I.R.C. § 6226(a), \[name of ax matters partner\] of \[name of partnership\] filed the instant petition with respect to the notice of final partnership administrative adjustment for the taxable year \[year\].\
\
4\. In the petition, petitioner seeks a redetermination of adjustments to the partnership return of \[name of partnership\] and the penalties under I.R.C. § 6662.\
\
5\. For taxable years ending before August 6, 1997, the Tax Court only has jurisdiction to determine partnership items of \[name of partnership\]. See I.R.C. § 6226(f).\
\
6\. The additions to tax are affected items as defined in I.R.C. § 6231(a) (5) that require factual determinations to be made at the partner level. See N.C.F. Energy Partners v. Commissioner, 89 T.C. 741 (1987). These items must be determined in a statutory notice of deficiency following the completion of the partnership proceeding. GAF v. Commissioner, 114 T.C. 519, 528 (2000).\
\
7\. The Court should dismiss the instant case with respect to the additions to tax because, pursuant to I.R.C. § 6226(f), the Court only has jurisdiction over partnership items in this proceeding.\
\
8\. Petitioner's counsel has been contacted and has no objection to the granting of this motion.\
\
WHEREFORE, respondent requests that this motion be granted.\
\
**Exhibit 35.11.1-67**\
\
### Declaratory Judgment Case: Motion for Joinder of Additional Parties\
\
| **MOTION FOR JOINDER OF ADDITIONAL PARTIES** |\
| :-: |\
| RESPONDENT MOVES, pursuant to the provisions of Tax Court Rule 215(a) (2), that the Court enter an order joining the Board of Trustees of the \[name of pension plan\] as a party to the above-captioned action. |\
| IN SUPPORT THEREOF, respondent respectfully states: |\
| 1\. The above-captioned case involves the qualification of the \[name of pension plan\] under I.R.C. § 401(a) (2). |\
| 2\. The Board of Trustees of the \[name of pension plan\], not presently a party to this action, is the plan administrator for the pension plan referred to in paragraph 1 above. |\
| 3\. Pursuant to T.C. Rule 217 this action requires the stipulation of the administrative record. |\
| 4\. Since the administrative record consists primarily of correspondence with the plan administrator rather than the petitioner, respondent believes that the Board of Trustees of the \[name of pension plan\] should be a party to the stipulation of the administrative record. |\
| 5\. Complete relief cannot be accorded among those already parties to this action and in the interests of justice, joinder of the Board of Trustees of the \[name of pension plan\] is required. |\
| 6\. Respondent has attempted unsuccessfully to determine the petitioners' position on this motion. |\
| WHEREFORE, it is prayed that this motion be granted. |\
\
**Exhibit 35.11.1-68**\
\
### Declaratory Judgment Case: Motion to Dismiss for Lack of Jurisdiction\
\
|  |\
| :-: |\
| **MOTION TO DISMISS FOR LACK OF JURISDICTION** |\
\
RESPONDENT MOVES that the above-entitled case be dismissed for lack of jurisdiction on the ground that the petitioner failed to exhaust its administrative remedies at the time the petition herein was filed.\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. On \[date\], the organization filed Form 1023, Application For Recognition of Exemption, under section 501 (c) (3) of the Internal Revenue Code.\
\
2\. On \[date\], the Form 1023 was returned to the organization. The organization was requested to provide additional information including the articles of incorporation, the certification of incorporation, a statement of receipts and expenditures and a statement of assets and liabilities.\
\
3\. The resubmitted Form 1023 was received by the Internal Revenue Service on \[date\].\
\
4\. By letter \[date\], the organization was requested to provide information which was omitted from the Form 1023 filed with the Service. The requested information included a request regarding an explanation of the organization's activities and its relationship to its founders and/or directors.\
\
5\. Additional information was submitted to the Internal Revenue Service on or about \[date\].\
\
6\. By letter dated \[date\], the respondent issued a proposed adverse determination letter in which the organization was given 30 days to protest the determination set forth in the letter.\
\
7\. By letter dated \[date\], the organization protested the proposed adverse determination letter issued on \[date\].\
\
8\. By letter dated \[date\], the organization submitted an amendment to the Articles of Incorporation.\
\
9\. By letter dated \[date\], a conference which was scheduled for \[date\] with the Appeals Office was confirmed.\
\
10\. A conference was held with an appeals officer and a representative of the organization on \[date\].\
\
11\. By letter dated \[date\], the organization submitted additional information regarding its activities. Such information was requested by the appeals officer during the conference held on \[date\].\
\
12\. By letter dated \[date\], the organization requested from the appeals officer a status report with respect to its request for exempt status.\
\
13\. On \[date\], the appeals officer advised the organization's representative by telephone that the submitted information was being considered and processed by the Internal Revenue Service.\
\
14\. On \[date\], the administrative file and record and the proposed final adverse determination letter were submitted to the Area Counsel for review.\
\
15\. On \[date\], the file and record and the proposed final adverse determination letter were returned by the Area Counsel to the Appeals office, with suggested changes with respect to the final adverse determination letter.\
\
16\. On \[date\], the organization filed a complaint in the United States District Court for the District of \[state\] in which the organization requested the district court to determine that it is an organization exempt from taxation under the provisions of section 501 (c) (3).\
\
17\. On \[date\], the petitioner filed with the Tax Court a petition in which the organization requested that the Court determine that the organization is an organization exempt from taxation under the provisions of section 501(c) (3). The petition was served on the Chief Counsel's office on \[date\].\
\
18\. On \[date\], the respondent issued a final adverse determination to the organization with respect to the exempt status under section 501(c) (3).\
\
19\. On the date the petition was filed with the Tax Court, \[date\] I the Internal Revenue Service had not issued a final adverse determination letter to the organization.\
\
20\. The respondent had been working within its administrative procedures in discussing with the organization and its representative the requirements for exempt status and in evaluating the information submitted by the organization prior to \[date\] I the date the petition herein was filed.\
\
21\. I.R.C. § 7428 requires the petitioner to exhaust all administrative remedies available to it within the Internal Revenue Service before the Tax Court can issue a declaratory judgment decree under the authority of that section.\
\
22\. Treas. Reg. § 601.201(n) provides procedures for the appeal of disagreed issues to the Appeals office.\
\
23\. Treas. Reg. § 601.201(n) (7) provides additional procedures for applications filed for exempt status under 501(c) (3). Pursuant to this regulation, the 270-day period referred to in section 7428(b) (2) will be considered by the Service to begin on the date a substantially completed Form 1023 is submitted. A substantially completed Form 1023 is one that is signed by an authorized individual and includes an employee identification number, a statement of receipts and expenditures, a balance sheet for the current year and the three preceding years, a statement of proposed activities, a description of anticipated receipts and contemplated expenditures, a copy of the organizing or enabling document, and a copy of the adopted bylaws.\
\
24\. Treas. Reg. § 601.201(n) (7) requires an organization to file a substantially completed Form 1023, to timely submit all additional information requested to perfect the exemption application, and to exhaust all administrative appeals available within the Service.\
\
25\. Section 7428(b) (2) provides that a declaratory judgment will not be issued by the Court unless the organization establishes that it has exhausted all administrative remedies available to it within the Internal Revenue Service.\
\
26\. Section 7428 does not provide that an organization can automatically petition the Court for declaratory judgment upon the expiration of the 270-day period from the date of the initial filing of the Form 1023 with the Service.\
\
27\. It is the respondent's position that all the facts and circumstances surrounding the submission of the Form 1023 should be evaluated in order to determine whether the petitioner exhausted its administrative remedies on the date the petition herein was filed.\
\
28\. The respondent in this case has proceeded diligently in processing the application, and, therefore, it is respondent's position that the petitioner had failed to exhaust its administrative remedies on \[date\], the date the petition herein was filed.\
\
29\. Additional information was sought from the organization with respect to its application on \[dates\]. This information was being considered and evaluated by the Service according to its procedures.\
\
30\. It is the respondent's position that the organization failed to exhaust its administrative remedies at the time the petition herein was filed with the Court on \[date\].\
\
WHEREFORE, it is prayed that this motion be granted.\
\
**Exhibit 35.11.1-69**\
\
### Declaratory Judgment Case: Motion to Extend Time Within Which to Stipulate as to Administrative Record\
\
| **MOTION TO EXTEND TIME WITHIN WHICH TO STIPULATE**<br>**AS TO THE ADMINISTRATIVE RECORD** |\
| :-: |\
| RESPONDENT MOVES that the Court extend the time within which to stipulate as to the administrative record in the above entitled case from \[date\] to \[date\]. |\
| IN SUPPORT THEREOF, respondent respectfully states: |\
| 1\. On \[date\], the Court extended the time within which to stipulate as to the administrative record to \[date\]. |\
| 2\. Copies of the administrative record and Motion to Stipulate as to the Administrative Record have been transmitted to petitioner's counsel for review, and the parties are discussing the contents of the record. |\
| 3\. The additional time requested herein will allow the parties sufficient time to transmit the administrative record and associated documents to the Court. |\
| 4\. On \[date\], petitioner's counsel advised counsel for the respondent that \[he/she\] had no objection to the granting of this motion and that \[he/she\] would be signing the stipulation as to the administrative record and transmitting same to respondent for filing with the Court. |\
| WHEREFORE, it is prayed that this motion be granted. |\
\
**Exhibit 35.11.1-70**\
\
### Declaratory Judgment Case: Motion for Order to Show Cause Why Case Should Not Be Submitted on Administrative Record as Provided in T.C. Rule 217\
\
|  |\
| :-: |\
| **MOTION FOR ORDER TO SHOW CAUSE WHY CASE SHOULD NOT BE SUBMITTED**<br>**ON THE BASIS OF THE ADMINISTRATIVE RECORD** |\
\
RESPONDENT MOVES, pursuant to Rule 217 of the Tax Court's Rules of Practice and Procedure, that the Court issue an Order to Show Cause why this case should not be submitted on the basis of the administrative record filed by respondent on \[date\] and appropriately certified as to its genuineness.\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. This case involves a declaratory judgment action pursuant to I.R.C. § 7428. The issue is whether the petitioner qualifies as an organization described in I.R.C. § 501(c) (3), which is exempt from tax under I.R.C. § 501(a).\
\
2\. Tax Court Rule 217(a) provides that disposition of an action for declaratory judgment will ordinarily be made on the basis of the administrative record as defined in T. C. Rule 210(b) (12). The Rule further provides that only with permission of the Court, upon good cause shown, will any party be permitted to introduce before the Court any evidence other than that presented before the Internal Revenue Service and contained in the administrative record as so defined.\
\
3\. Tax Court Rule 210(b) (12) defines the administrative record as including the request for determination and all documents, papers, and protests submitted to the Internal Revenue Service as well as written correspondence between the Internal Revenue Service and petitioner, all pertinent returns, and the notice of determination by the Commissioner.\
\
4\. Tax Court Rule 217(b) (1) provides that the Court will expect the parties to file with the Court the entire administrative record stipulated as to its genuineness within 30 days after service of the answer; and if the parties are unable to file such a stipulated administrative record, then, not sooner than 30 days or later than 45 days after service of the answer, the Commissioner shall file with the Court the entire administrative record as defined in T.C. Rule 210 (b) (12), appropriately certified as to its genuineness by the Commissioner or by an official authorized to act for the Commissioner.\
\
5\. In accordance with T.C. Rule 217(b), counsel for respondent made an attempt by letter dated \[date\] to stipulate the genuineness of the entire administrative record, a copy of which letter is attached hereto as Exhibit A.\
\
6\. Petitioner's counsel failed to respond or to advise counsel for respondent of his willingness to stipulate to the administrative record.\
\
7\. In conformity with T.C. Rule 217(b) (1), counsel for respondent filed with the Court on \[date\] the entire administrative record, as defined by T.C. Rule 210(b) (12), appropriately certified by an official authorized to act for the Commissioner.\
\
8\. The administrative record in this case as defined in T.C. Rule 210(b) (12) and as filed by the respondent constitutes the only source of evidence upon which to determine whether petitioner qualifies as an organization described in I.R.C. § 501(c) (3) which is exempt from tax under I.R.C. § 501(a).\
\
9\. Petitioner has not shown good cause why this case should not be submitted and disposed of on the basis of the administrative record as defined in T.C. Rule 210(b) (12).\
\
WHEREFORE, it is prayed that this motion be granted and the Court order the petitioner to show cause why this case should not be submitted on the basis of the administrative record as filed by respondent.\
\
|  |\
| :-: |\
| EXHIBIT A |\
| \[Letterhead\] |\
|  |\
| \[name and address of petitioner<br> or petitioner's counsel |\
| Dear \[Name\]: |\
| Re: \[Name of Company\] v. Commissioner<br> Docket No. \[docket no.\] |\
| Enclosed are an original and two copies of a Stipulation as to the Administrative Record in the above-cited case. Under Rule 217(b)(1) of the Tax Court's Rules of Practice and Procedure the parties are expected, within 30 days after service of the answer, to stipulate to the genuineness of the Administrative Record. Our records indicate the answer was filed on \[date\], and you should by now have been served by the Court with a copy of the answer. |\
| You will note the proposed stipulation is numbered to correspond with the numbers of items listed in the index that was attached to the respondent's answer. I assume you have in your possession either the originals or copies of all these documents. |\
| Please note further that orally furnished information and communications that are not reduced to writing do not constitute part of the "administrative record" as defined in T.C. Rule 210(b)(12). Houston Lawyer Referral Service, Inc. v. Commissioner, 69 T.C. 570 (1978). |\
|  |\
|  | Sincerely, |\
\
**Exhibit 35.11.1-71**\
\
### Notice of Proceeding Under Bankruptcy Code\
\
| **NOTICE OF PROCEEDING IN BANKRUPTCY** |\
| :-: |\
| RESPONDENT NOTIFIES the Court that pursuant to the Bankruptcy Code, 11 U.S.C. § 362(a) (8), this Court should stay its proceedings with respect to the petitioner, \[name\], who, on \[date\] filed a Chapter \[#\] petition with the United States Bankruptcy Court for \[District\] after filing a timely petition with this Court on \[date\]. A copy of the Bankruptcy Court's Notice of First Meeting of Creditors and of automatic stay is attached hereto as Exhibit A. |\
\
**Exhibit 35.11.1-72**\
\
### Motion to Consolidate for Trial, Briefing and Opinion\
\
| **MOTION TO CONSOLIDATE** |\
| :-: |\
| RESPONDENT MOVES that the Court consolidate the above entitled cases for purposes of the trial, briefing and opinion. |\
| IN SUPPORT THEREOF, respondent respectfully states: |\
| 1\. Neither of the above-entitled cases have been calendared for trial. |\
| 2\. Petitioners, \[petitioner name\] and \[petitioner 2 name\], were formerly husband and wife. |\
| 3\. The common issue in each of the above-entitled cases pertains to the dependency exemptions with regard to the two children of the former marriage of \[petitioner\] and \[petitioner 2\]. |\
| 4\. The issue is the same in each of the above-entitled cases, which will necessitate that the same evidence be introduced in each case. |\
| 5\. The time of the Court and of the parties will be materially conserved by the consolidation of these cases. |\
| 6\. Counsel for \[petitioner\] has advised respondent's counsel that \[he/she\] \[has no objection / objects\] to consolidation. |\
| 7\. Counsel for \[petitioner 2\] has advised respondent's counsel that \[he/she\] \[has no objection / objects\] to consolidation. |\
| WHEREFORE, it is prayed that this motion be granted. |\
\
**Exhibit 35.11.1-73**\
\
### Motion to Change Place of Trial\
\
|  |\
| :-: |\
| **MOTION TO CHANGE PLACE OF TRIAL** |\
\
RESPONDENT MOVES, pursuant to the provisions of Tax Court Rule 140(c), that the Court change the place of trial in this case from \[city, state\] to \[city, state\].\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. This case was originally scheduled for trial at the Trial Session of this Court that was scheduled to begin in \[city, state\], on \[date\]. On \[date\], petitioner filed a motion for continuance because \[reason for motion to change place of trial\] . The Court continued the case on \[date\].\
\
2\. The case was next scheduled for trial at the session of Court that was to begin in \[city, state\], on \[date\]. Just prior to the time of the trial, the petitioner filed a motion for continuance on the ground that \[state grounds\] precluded the proper preparation of the case for trial. In order to not unduly delay the trial of the case, however, petitioner requested that the place of trial be changed to \[city, state\] and that the case be calendared on a scheduled \[date\], \[city, state\] trial calendar. Judge \[name\] continued the case from the \[date\], \[city\] trial session and indicated he/she would recommend the case be placed on a \[month, year\] \[city\] trial calendar, the next scheduled trial calendar in the vicinity of \[state\] that \[he/she\] thought the case might be placed on.\
\
3\. The case was not calendared on the \[month, year\] \[city\] trial calendar, but has been tentatively scheduled for a \[date\] \[city\] trial calendar. The only reason that the parties considered \[city, state\] as a possible place of trial in \[month, year\], was that it was a then current trial calendar that would permit an early disposition of the case. Neither petitioner nor respondent have any connection with \[city, state\] and, accordingly, there is presently no reason for trying the case in \[city, state\].\
\
4\. Since petitioner is located in \[city\], as are most of the witnesses that the respondent will call in this case, it is requested that the place of trial of this case be changed from \[city, state\], to \[city, state\].\
\
5\. Respondent has contacted petitioner's representative and has been advised that petitioner has \[objected/no objection\] to the granting of this motion.\
\
WHEREFORE, it is prayed that this motion be granted.\
\
**Exhibit 35.11.1-74**\
\
### Motion to Correct Transcript (Joint)\
\
| **JOINT MOTION TO CORRECT TRANSCRIPT** |\
| :-: |\
| THE PARTIES JOINTLY MOVE that the Court correct the transcript of the trial of the above-captioned case, since the errors outlined below appear in the transcript in its current form. |\
| IN SUPPORT THEREOF, the parties respectfully state: |\
| 1\. That trial of the above-captioned matter took place in \[city, state\], on \[date\]. |\
| 2\. That the official transcript of the trial of the above captioned case contains the following errors, which should be corrected as follows:<br> <br>1. The sentence beginning on page \[number\], line \[number\] and ending on page \[number\], line \[number\], which currently reads, \[recite language\], should be corrected to read, \[recite correct language\], since the transcript does not correctly reflect that which was stated at trial by counsel for the respondent, in this regard; and<br>   <br>2. On page \[number\], line \[number\] of the transcript, the Internal Revenue Code section which is currently typed as \[section number\] should be corrected to read, \[correct section number\]. |\
| WHEREFORE, the parties pray that the motion be granted. |\
\
**Exhibit 35.11.1-75**\
\
### Motion to Change Caption — (Nonjurisdictional)\
\
| MOTION TO CORRECT CAPTION |\
| :-: |\
| RESPONDENT MOVES, pursuant to the provisions of Rule 63(e) of the Tax Court's Rules of Practice and Procedure, that the Court amend the caption of this case to read: |\
|  |\
| \[PETITIONER'S NAME\] and | )<br> ) |  |\
| \[PETITIONER'S SPOUSE'S NAME\], | )<br> ) |  |\
| Petitioners, | )<br> ) |  |\
| v. |  | )<br> ) | Docket No. \[docket no.\] |\
| COMMISSIONER OF INTERNAL REVENUE, | )<br> ) |  |\
| Respondent. | ) |  |\
| IN SUPPORT THEREOF, respondent respectfully states: |\
| 1\. Petitioners' correct legal names are \[petitioner's name\] and \[petitioner's spouses's name\] as shown by the signatures on the petition filed by petitioners for the taxable year \[year\], a copy of which is annexed hereto as Exhibit A. |\
| 2\. On \[date\], respondent was advised by counsel for petitioners that their correct legal names were \[petitioner's name\] and \[petitioner's spouses's name\]. |\
| 3\. Petitioners' counsel has advised counsel for the respondent that the names shown on the petition were due to typographical errors. |\
| 4\. Petitioners' counsel has advised counsel for respondent that he has no objection to the granting of this motion. |\
| WHEREFORE, it is prayed that this motion be granted. |\
|  |\
\
### Note:\
\
In the instance where a decision document (or other pleading) is filed contemporaneously with such a motion to change caption, the Field attorney should ensure that the companion filing bears the corrected caption, and not the original erroneous caption.\
\
**Exhibit 35.11.1-76**\
\
### Motion to Substitution of Party and to Change Caption\
\
|  |\
| :-: |\
| **MOTION FOR SUBSTITUTION OF PARTY AND TO CHANGE CAPTION** |\
\
RESPONDENT MOVES, pursuant to the provisions of Rule 63 of the Court's Rules of Practice and Procedure, that the Court substitute \[name of executor/personal representative\], as a party in this case, and change the caption to read \[name of petitioner\], \[name of executor/personal representative), EXECUTOR/PERSONAL REPRESENTATIVE.\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. On or about \[date\], petitioner, \[name\] filed a U.S. Individual Income Tax return for the taxable year \[year\].\
\
2\. On \[date\], respondent issued a statutory notice of deficiency to the petitioner, \[name\], determining a deficiency in the amount of $ \[amount\].\
\
3\. On \[date\], a petition from the aforementioned statutory notice of deficiency was filed in the name of \[name\]. The petition was signed by \[name\], petitioner's \[executor/personal representative\].\
\
4\. On \[date\], the undersigned counsel for respondent spoke with \[name of executor/personal representative\]. \[Name of executor/personal representative\] stated that his relationship to petitioner, \[name\], is that of \[executor/personal representative\]. \[Name of executor/personal representative\] provided proper documentation of the appointment to the undersigned counsel for respondent.\
\
5\. Rule 63(a) of the Court's Rules of Practice and Procedure provides that if a petitioner dies, the Court, on motion of a party or the decedent's successor or representative or on its own initiative, may order substitution of the proper parties.\
\
6\. Respondent respectfully submits that under the circumstances of this case, \[name\], petitioner's \[executor/personal representative\], should be added as a party to represent the petitioner.\
\
WHEREFORE, it is prayed that this motion be granted.\
\
**Exhibit 35.11.1-77**\
\
### Sample Letter To Attorneys in Conflict Situations Involving Planning, Promoting or Operating a Tax Shelter\
\
| \[Letterhead\] |\
| :-: |\
| **\[Insert the name of petitioner’s counsel\]**<br>**\[Insert counsel’s address\]** |\
|  | Reference: **\[Insert Petitioner’s Name\]** v. Commissioner<br> Tax Court Docket No. **\[Insert docket no.\]** |\
| Dear **\[Insert name of petitioner’s counsel\]**: |\
| The above-referenced Tax Court case lists you as the attorney of record for the petitioner. I am concerned that your representation of the petitioner may present a conflict of interest stemming from your involvement in developing and promoting the tax shelter at issue. Because I have an obligation to advise the Court at an early stage if its decision could be subject to collateral attack, I wish to bring this matter to your attention at an early date, before the parties engage in settlement negotiations or trial preparation. |\
| **\[Insert Factual circumstances that indicate a conflict of interest.\]**<br>### Example:<br>It appears you planned and/or promoted the transaction giving rise to the adjustment in Docket Number \[Insert docket no.\]. Under the American Bar Association’s Model Rules of Professional Conduct, your representation of taxpayers who invested in the transaction planned and/or promoted by you may present a conflict of interest. |\
|  |\
|  |\
| Specifically, Tax Court Rule 24(g) provides, in pertinent part, that "If any counsel of record… was involved in planning or promoting a transaction or operating an entity that is connected to any issue in a case… then such counsel must either secure the informed consent of the client... withdraw from the case; or take whatever other steps are necessary to obviate a conflict of interest or other violation of the ABA Model Rules of Professional Conduct, and particularly rules 1.7, 1.8, and 3.7 thereof." Under Tax Court Rule 201(a) practitioners must "carry on their practice in accordance with the letter and spirit of the Model Rules of Professional Conduct of the American Bar Association." |\
| Rule 1.7 (a) of the ABA Model Rules provides that a lawyer shall not represent a client if the representation involves a concurrent conflict of interest, which includes the representation of one client that is directly adverse to another client or there is a significant risk that the representation of one or more clients will be materially limited by the lawyer’s responsibilities to another client, a former client, or a third person or by the personal interests of the lawyer. Under Rule 1.7(b), however, a lawyer may represent a client when a conflict exists if each affected client gives informed consent, confirmed in writing. Such a waivable conflict may exist in your representation of petitioner. |\
| Please consult with the petitioner about the potential conflict and advise me, in writing, as to whether **\[he/she\]** agrees to your continued representation after full disclosure of the relevant facts. Please provide your written assurances by **\[Insert date\]**. |\
|  | Sincerely, |\
| **\[Optional language that may be added after last paragraph above if attorney may also be a witness:\]** |\
| In addition, Rule 3.7 of the ABA Model Rules of Professional Conduct reads "\[a\] lawyer shall not act as an advocate at a trial in which the lawyer is likely to be a necessary witness unless: (1) the testimony relates to an uncontested issue; (2) the testimony relates to the nature and value of legal services rendered in the case; or (3) disqualification of the lawyer would work substantial hardship on the client." |\
| While the conflict presented under Rule 1.7 is waivable, Rule 3.7 prohibits your representation of petitioner as none of the above exceptions to Rule 3.7 apply in this case. Please advise me, in writing, no later than **\[Insert date\]** regarding how you will satisfy your obligations under the Tax Court Rules and also under the ABA Model Rules of Professional Conduct. |\
\
**Exhibit 35.11.1-78**\
\
### Sample Letter To Attorneys in Conflict Situations Involving Multiple Representation; IRC § 6015 at Issue\
\
| \[Letterhead\] |\
| :-: |\
| \[Insert the name of petitioners’ counsel\]<br> \[Insert counsel’s address\] |\
|  | Reference: | \[Insert Petitioners’ Name\] v. Commissioner<br> Tax Court Docket No. \[Insert docket no.\] |\
| Dear \[Insert name of petitioners’ counsel\]: |\
| The above-referenced Tax Court case lists you as the attorney of record for both petitioners. Because of the facts noted below, I am concerned that your representation in this case may present a conflict of interest. Thus, I am bringing this matter to your attention at an early date, before the parties engage in settlement negotiations or trial preparation, so that you may have the opportunity to consult with petitioners and provide written assurances that both have agreed in writing to your continued representation. |\
| The petitioners jointly petitioned the Tax Court to review their liability arising from their joint income tax return for tax year \[Insert year\]. In the petition, you have asserted that \[requesting spouse\] is entitled to relief from joint and several liability under I.R.C. § 6015 . Pursuing innocent spouse relief on behalf of \[requesting spouse\] may result in \[her/his\] being relieved of joint and several liability, leaving \[nonrequesting spouse\] solely liable for the deficiency and interest \[Insert penalty if applicable\] at issue. By representing both Mr. and Mrs. \[Insert name\], it appears that your representation presents a conflict of interest. |\
| Specifically, Tax Court Rule 24(g) provides, in pertinent part, that "If any counsel of record… represents more than one person with differing interests with respect to any issue in a case…, then such counsel must either secure the informed consent of the client... withdraw from the case; or take whatever other steps are necessary to obviate a conflict of interest or other violation of the ABA Model Rules of Professional Conduct , and particularly rules 1.7, 1.8, and 3.7 thereof ." Rule 1.7(a) of the ABA Model Rules provides that a lawyer shall not represent a client if the representation involves a concurrent conflict of interest, which includes the representation of one client that is directly adverse to another client. Rule 1.7(b), however, provides that a lawyer may represent a client when a conflict exists if each affected client gives informed consent, confirmed in writing. Such a waivable conflict may exist in your representation of Mr. and Mrs. \[Insert name\]. |\
|  |\
| Please consult with the petitioners regarding this potential conflict and advise me, in writing, as to whether they have both agreed to your continued representation after full disclosure of the relevant facts. Please provide your written assurances by \[Insert date\]. |\
|  | Sincerely, |\
\
**Exhibit 35.11.1-79**\
\
### Conflict of Interest Situations Where Petitioner’s Attorney Is a Potential Witness\
\
| \[Letterhead\] |\
| :-: |\
| \[Insert the name of petitioner’s counsel\]<br> \[\[Insert counsel’s address\] |\
|  | Reference: | \[Insert Petitioner’s Name\] v. Commissioner<br> Tax Court Docket No. \[Insert docket no.\] |\
| Dear \[Insert name of petitioner’s counsel\]: |\
| As you know, the above case has been calendared for trial at the Tax Court's trial session in \[location\], beginning \[date\]. |\
| It has been brought to my attention that there is an issue regarding your representation of the petitioners in the above-referenced case. \[Insert factual circumstances that indicate a potential conflict of interest\]<br> <br>### Example:<br>Based on your capacity as the preparer of petitioner's 2007 Form 1040, U.S. Individual Income Tax Return ("Form 1040" ), and as petitioner's representative before the Tax Court, it appears that your representation presents a conflict of interest. |\
| In addition to a deficiency and an addition to tax under I.R.C. § 6651 (a)(1), the AAA XX,XXXX, notice of deficiency asserted that petitioner is liable for the I.R.C. § 6662(a) accuracy-related penalty. Further, a common defense to the accuracy-related penalty asserted by taxpayers is that they in good faith reasonably relied upon their tax return preparer in the preparation of their income tax return. In light of your involvement in the matters at issue in this case, it would seem that your testimony regarding the preparation of petitioner's 2007 Form 1040 is necessary to an effective trial of the case. As part of its case at trial, therefore, the IRS anticipates calling you as a witness in your capacity as petitioner's return preparer. |\
| Tax Court Rules 24(g) and 20l govern the conduct of attorneys before the Tax Court. Rule 24(f) provides, in relevant part, "If any counsel of record … is a potential witness in a case, then such counsel must … withdraw from the case; or take whatever steps are necessary to obviate a conflict of interest or other violation of the ABA Rules of Professional Conduct, and particularly Rules 1.7, 1.8, and 3.7 thereof. The Court may inquire into the circumstances of counsel’s employment in order to deter such violations." |\
| Model Rule 3.7 of the ABA Model Rules of Professional Conduct provides that a lawyer shall not act as an advocate at a trial in which the lawyer is likely to be a necessary witness except where the testimony relates to an uncontested issue, or the testimony relates to the nature and value of legal services rendered in the case, or disqualification would render a substantial hardship on the client. |\
| None of the listed exceptions appear to apply to this case, and accordingly, as a necessary witness, your continued representation of the petitioner is prohibited by the rules of professional conduct mentioned above. Please advise, in writing, no later than \[insert date\] of the steps you plan to take to obviate the potential conflict of interest. |\
|  |  |  | Sincerely, |\
\
**Exhibit 35.11.1-80**\
\
### Discovery Checklist (Interrogatories, Production of Documents, Admissions Depositions, Motions to Compel)\
\
![This is an Image: 30026161.gif](https://www.irs.gov/pub/xml_bc/30026161.gif)\
\
> This is an example of a discovery checklist for interrogatories, production of documents, admissions depositions, and motions to compel.\
\
[Please click here for the text description of the image.](https://www.irs.gov/media/157736 "")\
\
![This is an Image: 30026162.gif](https://www.irs.gov/pub/xml_bc/30026162.gif)\
\
> This is page 2 of an example of a discovery checklist for interrogatories, production of documents, admissions depositions, and motions to compel.\
\
[Please click here for the text description of the image.](https://www.irs.gov/media/157741 "")\
\
![This is an Image: 30026163.gif](https://www.irs.gov/pub/xml_bc/30026163.gif)\
\
> This is page 3 of an example of a discovery checklist for interrogatories, production of documents, admissions depositions, and motions to compel.\
\
[Please click here for the text description of the image.](https://www.irs.gov/media/157746 "")\
\
![This is an Image: 30026164.gif](https://www.irs.gov/pub/xml_bc/30026164.gif)\
\
> This is page 4 of an example of a discovery checklist for interrogatories, production of documents, admissions depositions, and motions to compel.\
\
[Please click here for the text description of the image.](https://www.irs.gov/media/157751 "")\
\
**Exhibit 35.11.1-81**\
\
### Respondent's Interrogatories to Petitioner\
\
|  |\
| :-: |\
| **RESPONDENT'S INTERROGATORIES TO PETITIONER** |\
\
Respondent requests that petitioner answer under oath, in accordance with T.C. Rule 71, the following interrogatories:\
\
1\. Attached hereto and marked Exhibit \[letter\] is a list of deposits made by the petitioner during \[year\] at the \[bank name\] , account no. \[#\], and the \[bank name \], account no. \[#\]. With respect to each of these deposits listed on Exhibit \[letter\], please answer in detail the following questions:\
\
a. Whether the petitioner contends that a particular deposit does not represent income taxable to him during the year \[year\].\
\
b. In regard to each particular deposit which the petitioner contends does not represent taxable income to him in \[year\] explain, identify the deposit items which are the source for each deposit. When used with respect to a deposit item which constitutes a financial instrument, such as a check, money order, draft, or other negotiable instrument, the term identify shall mean to state the issue date of such instrument, its amount, payee, identifying number, letters, or symbols, identity of issuer, maker, or drawer, identity of financial institution on which drawn, name and identifying number of account on which drawn, endorsement, if any, and maturity date, if any.\
\
c. In regard to each particular deposit which the petitioner contends does not represent taxable income to him in \[year\] explain the legal basis and the factual circumstances in regard to the source of each such deposit in sufficient detail so that the respondent may understand the factual and legal reasons as to why the petitioner believes a particular deposit does not represent income taxable to him during the year \[year\].\
\
2\. On petitioner's \[year\] Federal income tax return (Form 1040) I petitioner claimed a total interest expense deduction of $ \[amount\]. During the audit of petitioner's Federal income tax return for the year \[year\] I petitioner supplied documentary evidence to substantiate interest expense deductions in the amounts of \[DOLLAR AMOUNT\] from \[bank name\] I and $ \[amount\] from \[bank name\].\
\
a. Please identify the amounts and name of other creditors to whom petitioner made interest payments during the year \[year\] I exclusive of the interest deductions previously allowed.\
\
b. Identify the documentary evidence and/or witnesses petitioner intends to offer at the trial of this case to support the additional interest deductions which petitioner identified in response to subparagraph a above.\
\
3\. Explain the factual circumstances as to why petitioner should not be held liable for the delinquency penalty provided by I.R.C. § 6651(a) (1) in view of the fact that petitioner did not file his \[year\] Federal income tax return until \[year\].\
\
PLEASE TAKE NOTICE that a copy of such answers must be served upon the undersigned within 30 days after service of these interrogatories.\
\
**Exhibit 35.11.1-82**\
\
### Respondent's Request for Production of Documents\
\
| **RESPONDENT'S REQUEST FOR PRODUCTION OF DOCUMENTS** |\
| :-: |\
| Respondent, pursuant to Tax Court Rule 72, requests that the petitioner produce at \[location\] for inspection and copying on \[date\], and continuing from day to day thereafter for so long as reasonably necessary to examine and copy them, the following documents: (The documents referred to are requested for the period beginning on \[date\] and ending \[date\]). |\
| 1\. All contracts dealing with the petitioner's purchase of real estate. |\
| 2\. All deeds by which the petitioner acquired real estate. |\
| 3\. All contracts for the disposition of real estate. |\
| 4\. All deeds by which the petitioner disposed of real estate. |\
| 5\. All journal entries, general and special ledger accounts dealing with the acquisition and disposition of real estate. |\
| PLEASE RESPOND to this request pursuant to T.C. Rule 72(b) within 30 days of service to \[name of respondent's attorney\] at the address shown below. |\
\
**Exhibit 35.11.1-83**\
\
### Respondent's Request to Petitioner for Permission for Entry, Inspection, Measuring, and Photographing Property/Objects/Operations Thereon\
\
| **RESPONDENT'S REQUEST FOR PERMISSION FOR ENTRY, INSPECTION,**<br>**MEASURING AND PHOTOGRAPHING PROPERTY, OPERATIONS AND OBJECTS** |\
| :-: |\
| RESPONDENT, pursuant to Tax Court Rule 72, requests that petitioner: |\
| 1\. Permit respondent, through his attorney and \[names of other individuals, such as expert witnesses or their delegates\], to enter petitioner's premises located at \[address\] so that respondent may inspect, measure, and/or photograph said property indicated above and any designated object or operation thereon. Specific items to be inspected, measured or photographed, either by individual item or by category, are described with particularity in Exhibit \[letter\] to this request. |\
| 2\. Specify the date and time for entry, inspection, measuring and/or photographing the aforementioned premises, designated object or operation thereon, including the equipment described in Exhibit \[letter\] as \[preferred date\], or the mutually agreed date, during normal working hours and preferably beginning on or about 9:00 a.m., and lasting until completion. If respondent's inspection, measuring, and/or photographing is not completed on the first day of entry, a reasonable further entry (or entries) for the purpose of completion is to occur on other mutually agreed reasonable date and time. |\
| PLEASE RESPOND to this request pursuant to T.C. Rule 72(b), within 30 days of service to \[name of respondent's attorney\] at the address shown below. |\
\
**Exhibit 35.11.1-84**\
\
### Respondent's Request for Admissions\
\
| **RESPONDENT'S REQUEST FOR ADMISSIONS** |\
| :-: |\
| Respondent, pursuant to Tax Court Rule 90, requests that the petitioner within 30 days after the service of this document admit the facts set forth in each of the following requests for purposes of the pending action only and subject to all pertinent objections to admissibility which may be interposed at trial. If the petitioner can admit only a part (or a part as qualified) of a particular request for admission, the petitioner should specify so much as is true (or true as qualified) and deny only the remainder of said request. Further, if the petitioner cannot truthfully admit or deny a particular request for admission, the petitioner should state in detail the reasons why this is so. |\
| 1\. Attached hereto and marked Exhibit A is an authentic copy of the federal income tax return filed by the petitioner for the taxable year \[year\]. |\
| 2 . \[additional requests for admission\] . |\
| PLEASE TAKE NOTICE that a written answer to this request must be filed with the Tax Court and a copy served upon the undersigned within 30 days after service of this request for admissions. |\
\
**Exhibit 35.11.1-85**\
\
### Motion to Review Sufficiency of Petitioner's Objections to Respondent's Requests for Admissions\
\
|  |\
| :-: |\
| **RESPONDENT'S MOTION TO REVIEW SUFFICIENCY OF**<br>**PETITIONER'S OBJECTIONS TO RESPONDENT'S REQUEST FOR ADMISSIONS** |\
\
RESPONDENT MOVES, pursuant to Rule 90(e) of the Court's Rules of Practice and Procedure, that the Court order the petitioner to serve answers to the respondent's requests for admissions.\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. The petition in the case was filed on \[date\]. Respondent's answer was filed on \[date\]. A reply was filed on \[date\].\
\
2\. Subsequently, numerous conferences have been held regarding the facts of this case and various information and documents have been exchanged in compliance with T.C. Rule 90(a). Despite this, to date, respondent's counsel does not have any stipulations or admission as to any facts in regard to the net worth and personal expenditures allegations set forth in respondent's answer.\
\
3\. On \[date\], respondent served upon petitioner and filed with this Court his Requests For Admissions, a copy of which is attached hereto as Exhibit A.\
\
4\. On \[date\], petitioner served upon respondent his objections to respondent's request for admissions, a copy of which is attached hereto as Exhibit B.\
\
5\. Petitioner's objection is based primarily on \[his/her\] erroneous assumption that \[he/she\] has a privilege under the Fifth Amendment to refuse to answer respondent's requests for admission. Petitioner is not presently and has not been previously under criminal investigation by the agents of the respondent and therefore does not have a legitimate fear of prosecution. Accordingly, petitioner's claim that \[his/her\] answers to said requests for admissions would result in self-incrimination are unfounded.\
\
WHEREFORE, respondent prays that this motion be granted.\
\
**Exhibit 35.11.1-86**\
\
### Motion to Compel Responses to Respondent's Interrogatories\
\
|  |\
| :-: |\
| **MOTION TO COMPEL RESPONSES TO RESPONDENT'S INTERROGATORIES** |\
\
RESPONDENT MOVES, pursuant to the provisions of Rules 71(c) and 104(b) of the Court's Rules of Practice and Procedure, that the Court enter an order compelling the petitioner to answer the interrogatories served on petitioner on \[date\].\
\
RESPONDENT FURTHER MOVES, pursuant to the provisions of Rule 104 of the Court's Rules of Practice and Procedure, that the Court order, on failure of the petitioner to completely comply with any order issued by it in respect to this motion to compel, that \[specify sanctions requested\].\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. Respondent sent a letter to the petitioner on \[date\] in which respondent invited petitioner to a conference on \[date\] at \[location\] and also informally requested the petitioner to answer certain questions. Attached hereto and marked Exhibit A is a copy of said letter. \[Describe any other attempts to informally conduct informal discovery with respect to issues covered by interrogatories.\]\
\
2\. Petitioner failed to attend the conference scheduled for \[date\], failed to furnish the respondent with answers to said questions and failed to contact the respondent for the purpose of scheduling another conference. \[Substitute other information concerning conference as appropriate.\]\
\
3\. On \[date\], pursuant to T.C. Rule 71, respondent served on the petitioner Respondent's Interrogatories, which is attached hereto as Exhibit B.\
\
4\. On \[date\], petitioner mailed to respondent "Petitioner's Response to Respondent's Interrogatories" in which \[he/she\] objected to respondent's request in its entirety. Such response is attached hereto as Exhibit C. \[Substitute allegations concerning lack of response, or incomplete or evasive response, as appropriate\] .\
\
5\. To date, none of the interrogatories have been answered by the petitioner. \[Substitute allegations concerning evasive or incomplete response as appropriate\].\
\
6\. On \[date\], respondent's counsel called petitioner's counsel who reported that \[describe attempts to contact petitioner or petitioner's representative and any explanation from petitioner for failing to respond to interrogatories.\]\
\
7\. The answers to said interrogatories are all relevant to this case and are necessary for the respondent both to properly and timely prepare his defense against the contentions of the petitioner.\
\
8\. Petitioner's failure to answer these interrogatories frustrates compliance with T.C. Rule 91, which requires the parties to stipulate all relevant facts and documents.\
\
WHEREFORE, respondent prays that this motion be granted.\
\
**Exhibit 35.11.1-87**\
\
### Motion to Compel Production of Documents\
\
|  |\
| :-: |\
| **MOTION TO COMPEL PRODUCTION OF DOCUMENTS** |\
\
RESPONDENT MOVES, pursuant to the provisions of Rules 72(b) and 104(b) of the Court's Rules of Practice and Procedure, that the Court enter an order requiring petitioner to produce at \[location\], for inspection and copying within \[number of days\] and to continue from day to day for so long as is reasonably necessary to examine and copy, the documents set forth in Respondent's Request for Production of Documents served on petitioner on \[date\].\
\
RESPONDENT FURTHER MOVES, pursuant to the provisions of Rule 104 of the Court's Rules of Practice and Procedure that the Court order, on failure of the petitioners to completely comply with any order issued by it in respect to this motion to compel, that \[specify sanctions requested\].\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. Respondent sent a letter to the petitioner on \[date\] in which respondent invited petitioner to a conference on \[date\] at \[location\] and also informally requested the petitioner to bring various documents to this conference. Attached hereto and marked Exhibit A is a copy of said letter. \[Describe any other attempts to informally obtain the requested documents.\]\
\
2\. Petitioner failed to attend the conference scheduled for \[date\], failed to furnish the respondent with the requested documents, and failed to contact the respondent for the purpose of scheduling another conference. \[Substitute other information concerning conference as appropriate.\]\
\
3\. On \[date\], pursuant to Rule 72, respondent served on the petitioner Respondent's Request for Production of Documents, which is attached hereto as Exhibit B.\
\
4\. On \[date\], petitioner mailed to respondent "Petitioner's Response to Respondent's Request for Production of Documents" in which \[he/she\] objected to respondent's request in its entirety. Such response is attached hereto as Exhibit c. \[Substitute allegations concerning lack of response, or incomplete or evasive response, as appropriate\].\
\
5\. To date, none of the requested documents have been provided to respondent. \[Substitute allegations concerning evasive or incomplete response as appropriate.\]\
\
6\. On \[date\], respondent's counsel called petitioner's counsel who reported that \[describe attempts to contact petitioner or petitioner's representative and any explanation from petitioner for failing to produce documents.\]\
\
7\. The documents requested are all relevant to this case and are necessary for the respondent both to properly and timely prepare his defense against the contentions of the petitioner.\
\
8\. Petitioner's failure to respond substantively to the request for documents frustrates compliance with T.C. Rule 91, which requires the parties to stipulate all relevant facts and documents.\
\
WHEREFORE, respondent prays that this motion be granted.\
\
**Exhibit 35.11.1-88**\
\
### Motion to Compel Entry, Inspection, Etc.\
\
|  |\
| :-: |\
| **RESPONDENT'S MOTION FOR ORDER COMPELLING PETITIONERS TO**<br>**PERMIT ENTRY, INSPECTION, MEASURING, AND PHOTOGRAPHING PROPERTY**<br>**AND DESIGNATED OBJECTS** |\
\
RESPONDENT MOVES, pursuant to the provisions of Rules 72(b) and 104(b) of the Court's Rules of Practice and Procedure, that the Court enter an order requiring that, within ten days after entry thereof, petitioners allow respondent to enter upon the premises of petitioners' residence located at \[street address\], for the purpose of inspecting, measuring, and photographing property and designated objects.\
\
RESPONDENT FURTHER MOVES, pursuant to the provisions of T.C. Rule 104(c) that, upon failure of petitioners to comply completely with the discovery order, the Court impose sanctions, including dismissal of the petition.\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. This case appears on a trial calendar at \[city, state\] scheduled to commence on \[date\].\
\
2\. The petition was filed on \[date\]. The case became at issue upon the filing of the respondent's answer on or about \[date\]. The issues are largely factual.\
\
3\. Petitioners' attorney has held numerous meetings with the \[city\] Appeals office. After exhausting all settlement possibilities, this case was returned to the Field Counsel's office for trial preparation on \[date\].\
\
4\. Respondent sent a letter to petitioners' counsel dated \[date\], inviting petitioners' counsel to a conference on \[date\], and also informally requesting permission for entry. Annexed hereto and marked as Exhibit A is a copy of the request without attachments.\
\
5\. Petitioners' counsel did not attend the conference scheduled for \[date\], nor did \[he/she\] respond to respondent's informal request for entry upon the premises of petitioners' residence for the purpose of measuring, inspecting, and photographing property and designated objects.\
\
6\. On \[date\], pursuant to T.e. Rule 72(a) (2), respondent served on counsel for petitioners' Respondent's Request to Petitioners for Permission for Entry, Inspection, Measuring, and Photographing Property and Designated Objects, a copy of which is annexed hereto as Exhibit B.\
\
7\. \[Insert paragraph(s) containing facts concerning respondent's efforts to obtain compliance from petitioner.\]\
\
8\. \[Insert specific reason(s) why inspection is necessary for defense of case.)\
\
9\. Respondent's Request to Petitioners for Permission for Entry, Inspection, Measuring, and Photographing Property and Objects is relevant to this case and is necessary for respondent to properly and timely prepare his defense against the contentions of the petitioners.\
\
10\. Petitioners' failure to respond substantively to the Request for Permission for Entry, Inspection, Measuring, and Photographing Property and Objects frustrates compliance with T.C. Rule 91, which requires the parties to stipulate to all relevant facts.\
\
WHEREFORE, it is prayed:\
\
(1) That the Court enter an order compelling petitioners to comply with Respondent's Request to Petitioners for Permission for Entry, Inspection, Measuring, and Photographing Property and Objects within ten days from the entry thereof;\
\
(2) That should petitioners fail to comply with the order of the Court, prayed for above, the Court enter an order pursuant to T.C. Rule 104(c) (3) dismissing the petition;\
\
(3) In the alternative, if the Court does not dismiss the petitioners' petition, that the Court enter an order precluding petitioners from introducing any evidence to support claims or defenses with respect to any matter which was subject to Respondent's Request to Petitioners for Permission for Entry, Inspection, Measuring, and Photographing Property and Objects; and\
\
(4) That the Court impose such other and further sanctions upon petitioners as the Court may deem appropriate under the circumstances.\
\
**Exhibit 35.11.1-89**\
\
### Motion to Impose Sanctions\
\
|  |\
| :-: |\
| **MOTION TO IMPOSE SANCTIONS** |\
\
RESPONDENT MOVES for an order, pursuant to Rule 104(c) of the Court's Rules of Practice and Procedure, imposing sanctions upon the petitioner for failure to comply with the Court's order dated \[date\].\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. On \[date\], the Court ordered petitioner to produce and make available to respondent's trial counsel for inspection and copying all documents requested in Respondent's Request For Production of Documents by \[date\].\
\
2\. Petitioner has not made available to respondent's counsel any of the requested documents and therefore has failed to comply with this Court's order of \[date\].\
\
3\. \[Describe attempts to contact petitioner or petitioner's representative and any explanation from petitioner for failing to comply with Court's order\].\
\
WHEREFORE, respondent prays that this motion be granted and the Court impose the following sanctions:\
\
\[Request sanctions that are appropriate based upon petitioner's failure to comply\] .\
\
(a) That the above-entitled case be dismissed for lack of prosecution and that a decision be entered finding that there is due from the petitioner a deficiency in income tax for the taxable year \[year\] in the amount of $ \[amount\], as set forth in the statutory notice of deficiency dated \[date\], upon which notice this case is based; or, in the alternative,\
\
(b) That all documents covered by the respondent's request, which the petitioner should have made available in response to the respondent's Request For Production of Documents, shall be excluded from evidence in this case, and\
\
(c) That the issues, to which the respondent's discovery request pertains, shall be taken as established as set forth in the notice of deficiency dated \[date\].\
\
(d) That the assignments of error in the petition which involve the subject matter covered by said production of documents be stricken and petitioners be prohibited from offering evidence to rebut the determination made in the notice of deficiency with regard to the subject matter covered by Respondent’s \[Interrogatories/Request for Production of Documents\].\
\
(e) Any other sanctions that the Court may deem appropriate.\
\
**Exhibit 35.11.1-90**\
\
### Transmittal Memorandum to Manager for Service of Subpoena\
\
| **Date:** |  |\
| --: | --- |\
| **To:** | \[Manager\], \[Division\] |\
| **From:** | \[Name of Associate Area Counsel\]<br> Associate Area Counsel |\
| **Subject:** | \[Name\] v. Commissioner Docket<br> No. \[docket no.\] |\
| \\_\\_\\_\_\_\_ |\
|  | Transmitted are the original and. one copy of the following subpoena(s) and subpoena(s) duces tecum for service upon witness(es) in connection with the above entitled case: |\
|  |  | \[List subpoena(s) and subpoena(s) duces tecum\] |\
|  | Also transmitted are Form(s) 2431, Subpoena Instructions and Questionnaire, for use by the agent who will serve the subpoena(s) and a letter to each witness requesting his or her agreement to appear when notified and Agreement to Appear forms, to be signed by each witness if he or she so agrees. The attention of the person serving the subpoena is directed to the instruction on the reverse side of Form 2431. |\
|  | It will be appreciated if you will immediately effect service of the subpoena(s) and return the completed original(s) of the subpoena(s), Form 2431 and the Agreement to Appear. |\
|  | Enclosures: |\
|  |  | Subpoena(s)<br> Forms 2431<br> Letter(s) to witness(es) |\
\
**Exhibit 35.11.1-91**\
\
### Letter Explaining Witness' Appearance\
\
| \[Letterhead\] |\
| :-: |\
|  | Re: | \[Petitioner’s name\] v. Commissioner<br> Docket No. \[docket no.\] |\
| Dear \[Petitioner’s name\]: |\
| The above case will be called at the trial session commencing on the date and at the place shown in the subpoena served on you. At that time it is expected that the Court will fix the specific date for trial. |\
| We want to avoid your spending unnecessary time in Court waiting for the trial to commence, but we do not know the exact day and hour which the Court will select to start the trial since several other cases are also set for trial on this session. If you will agree to be ready and respond immediately when notified of the exact date and time of trial, you will be excused from responding to the earlier return date shown on the subpoena. If you do not agree to this condition, you will be required to appear in Court on the date specified and will not be allowed to depart without leave of the Court. If you do agree, please fill out the attached Agreement to Appear and return it to the person serving the subpoena. We will try to notify you at least 24 hours in advance of the time your presence in the courtroom will be needed. Your mileage and witnesses fees will be reimbursed if you sign a claim therefor on Form 1157, which will be furnished following your appearance. |\
| If you have any questions about this letter or the subpoena which has been served, please contact the attorney in charge of the case, \[name of respondent’s attorney\] at the above address. \[He/she\] may be reached at \[telephone number\]. |\
|  | Sincerely, |\
|  | \[Name\]<br> Area Counsel |\
|  | By:\_\_\_\_\_\_\_\_ |\
\
**Exhibit 35.11.1-92**\
\
### Witness Agreement to Appear\
\
|  | Agreement to Appear |\
| --- | --- |\
|  | Re: \[Petitioner’s name\] v. Commissioner<br> Docket No. \[docket no.\] |\
| I, \[witness’s name\], hereby agree that I will be ready to appear in the United States Tax Court in response to the subpoena served on me today when notified by the \[appropriate Field Counsel office\], Internal Revenue Service, as to the exact date and time when my appearance is needed. |\
|  | Date: \_\_\_\_\_\_\_\_ |\
|  | Signature: \_\_\_\_\_\_\_\_ |\
|  | My telephone number at home is \_\_\_\_\_\_\_\_ |\
|  | My telephone number at work is \_\_\_\_\_\_\_\_ |\
|  | My home address is \_\_\_\_\_\_\_\_ |\
|  | My business address is \_\_\_\_\_\_\_\_ |\
|  | \\_\\_\\_\_\_\_\_\_ |\
|  | \[Signature of person receiving agreement\] |\
\
**Exhibit 35.11.1-93**\
\
### Letter to Third Party Customer in Regard to Subpoena on Financial Institution\
\
| \[Letterhead\] |\
| :-: |\
| \[Name & address of customer\] |\
| Dear \[Petitioner’s name\]: |\
|  | Re: | \[Petitioner’s name\] v. Commissioner<br> Docket No. \[docket no.\] |\
| The above-entitled case is set for hearing before the United States Tax Court at a session commencing in \[city, state\], on \[date of calendar call\]. In connection with the trial of this case, this office is serving a subpoena duces tecum on \[name of financial institution\], calling for it to furnish certain records and information concerning your transactions with \[name of financial institution\], which we believe are relevant to matters before the Tax Court. A copy of this subpoena duces tecum is attached hereto. |\
| Records and information concerning your transactions which are held by the financial institution named in the attached subpoena duces tecum are being sought by this office in accordance with the Right to Financial Privacy Act of 1978 for the following purpose: |\
| \[Set forth purpose for subpoenaing the customer records\] |\
| If you desire that such records or information not be made available, you must:<br> <br>1. Fill out the accompanying Motion paper and sworn statement (affidavit) or write one of your own, stating that you are the customer whose records are being requested by the Government and either giving the reasons you believe that the records are not relevant to the legitimate law enforcement inquiry stated in this notice or any other legal basis for objecting to the release of the records.<br>   <br>2. File the Motion and statement by mailing or delivering them to the Clerk of the United States Tax Court, 400 Second Street, N.W., Washington, D.C. 20217.<br>   <br>3. Serve the Government authority requesting the records by mailing or delivering a copy of your Motion and statement to the undersigned at \[address\].<br>   <br>4. Be prepared to come to Court and present your position in further detail. |\
| You do not need to have a lawyer although you may wish to employ one to represent you and protect your rights. |\
| If you do not follow the above procedures, upon the expiration of \[ten days from the date of service or 14 days from the date of mailing of this notice\], the records or information requested therein will be made available. These records may be transferred to other Government authorities for legitimate law enforcement inquiries, in which event you will be notified after the transfer. |\
| This case before the United States Tax Court is being handled by \[name of Field attorney\] of this office. If you have any questions in connection with this matter, please call \[phone number\], or write the undersigned at the address shown above. |\
|  | Sincerely, |\
|  | Area Counsel |\
|  | By: \_\_\_\_\_\_\_\_ |\
| Enclosures:<br> (1) Copy of subpoena duces tecum<br> (2) Form Motion to Quash to be completed by you<br> (3) Form Affidavit to be completed by you |\
\
\\_\\_\\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\
\
**_Note:_**This procedure is not required if the customer is a corporation, trust, or partnership of six or more individuals. _See_ 12 U.S.C. §§ 3401(4), 3401(5).\
\
**Exhibit 35.11.1-94**\
\
### Enclosure: Form Motion to Quash Subpoena Served on Financial Institution\
\
|  |\
| --- |\
| UNITED STATES TAX COURT |\
|  |\
| \[NAME\] | )<br> ) |  |\
| Petitioner(s), | )<br> ) |  |\
| v. |  | )<br> ) | Docket No. \[docket no.\] |\
| COMMISSIONER OF INTERNAL REVENUE, | )<br> ) |  |\
| Respondent. | ) |  |\
| **MOTION TO QUASH SUBPOENA DUCES TECUM** |\
| \[Customer's name\], a third party customer of a financial institution, moves that the subpoena duces tecum, served on \[date\] by the respondent on \[financial institution\] be quashed. \[Financial institution\] is a financial institution within the meaning of the Right to Privacy Act of 1978. |\
| IN SUPPORT THEREOF, the undersigned alleges as follows: |\
| 1\. I am a customer of \[Financial institution\]. In that capacity it has maintained certain records covering my financial transactions with it. |\
| 2\. On \[date\] , the respondent served a subpoena duces tecum on \[Financial institution\] , calling for \[Financial institution\] to appear at the hearing of the above case before the United States Tax Court at \[city, state\], on \[date\], and bring certain information concerning my financial transactions as set forth in the subpoena duces tecum. A copy of this subpoena duces tecum is attached hereto as Exhibit 1. |\
| 3\. I am not a party to this proceeding before the Tax Court. My reasons for believing that this subpoena duces tecum to the financial institution should be quashed are set forth in my sworn statement (affidavit) attached hereto as Exhibit 2. |\
| WHEREFORE, it is prayed that this motion be granted and the subpoena duces tecum be quashed. |\
|  |  |\
|  | \[Name & address of customer\] |\
\
**Exhibit 35.11.1-95**\
\
### Enclosure: Form Affidavit of Third Party Customer\
\
|  |\
| :-: |\
| **AFFIDAVIT** |\
| I, \[Name & address of customer\], having been duly sworn, depose and say as follows: |\
| 1\. I am not a party to the proceeding before the United States Tax Court entitled \[caption of case\], which is set for trial before a trial session of that Court to be held in \[city, state\] , on \[date\]. |\
| 2\. I am a customer of \[financial institution\], a financial institution within the meaning of the Right to Privacy Act of 1978. The Commissioner of Internal Revenue, who is the respondent in the above Tax Court case, has subpoenaed from that institution certain records and information concerning my financial transactions with it. |\
| 3\. I am asking that this subpoena duces tecum be quashed. |\
| My reasons for this are as follows:<br> \[set forth reasons\] |\
|  |\
|  |  |\
| \[Name & Address of Customer\] |\
| Subscribed and sworn to before me this \_\_day of \_\_, 20\_. |\
|  | Notary Public \[State or jurisdiction\]<br> My commission expires: \_ |\
\
**Exhibit 35.11.1-96**\
\
### Letters to Financial Institution: Right to Financial Privacy Act — Motion to Quash Denied\
\
| \[Letterhead\] |\
| :-: |\
|  | Re: | \[Petitioner’s name\] v. Commissioner<br> Docket No. \[docket no.\] |\
| \[Name and address of financial institution\] |\
| Dear \[Name\]: |\
| On \[date\], this office served a subpoena duces tecum calling for a representative of your organization to appear before the United States Tax Court on \[date\] and produce certain records and information on \[customer name\], a customer of your organization within the meaning of the Right to Financial Privacy Act of 1978. This is to certify that the Commissioner of Internal Revenue has complied with the applicable provisions of section 1107 of the Act. |\
| \[Customer name\]’s Motion to Quash the subpoena duces tecum served on you has been denied by the Tax Court. The government has complied with the provisions of section 1110 of the Act concerning a customer challenge. Therefore, it is appropriate for you to respond to the subpoena duces tecum and bring the requested records and information to the hearing, which is presently scheduled for \[date\]. |\
|  |  |  |  | Sincerely, |\
|  |  |  |  | Area Counsel |\
|  |  |  | By: | \\_\\_\\_\_\_\_\_\_ |\
\
**Exhibit 35.11.1-97**\
\
### Letters to Financial Institution: Right to Financial Privacy Act — No Motion to Quash Filed\
\
| \[Letterhead\] |\
| :-: |\
|  |  | Re: \[Petitioner’s name\] v. Commissioner<br> Docket No. \[docket no.\] |\
| \[Name and address of financial institution\] |\
| Dear \[Name\]: |\
| On \[date subpoena served on financial institution\], this office served a subpoena duces tecum calling for a representative of your organization to appear before the United States Tax Court on \[date of appearance\] andproduce certain records and information on \[name of customer\], a customer of your organization within the meaning of the Right to Financial Privacy Act of 1978. |\
| This is to certify that the Commissioner of Internal Revenue has complied with the applicable provisions of section 1107 of the Act. Ten days have expired from the date of the service on \[name of customer\] or fourteen days from the date of mailing of the notice to \[name of customer\], and within such time he has not filed a sworn statement and Motion to Quash in the United States Tax Court, as required by the Act. Therefore, it is now proper for you to comply with the terms of the subpoena duces tecum and bring the financial records of \[name of customer\] to the hearing before the Tax Court in accordance with section 1103(b) of the Act. |\
|  |  |  |  | Sincerely, |\
|  |  |  |  | Area Counsel |\
|  |  |  | By: | \\_\\_\\_\_\_\_\_\_ |\
\
**Exhibit 35.11.1-98**\
\
### Motion For Writ of Habeas Corpus Ad Testificandum\
\
|  |\
| :-: |\
| **RESPONDENT'S MOTION FOR WRIT OF HABEAS CORPUS AD TESTIFICANDUM** |\
\
RESPONDENT MOVES, pursuant to I.R.C. § 7456(a), that \[initials or name\], an inmate at the Federal Correction Institution located at \[address\], be made available as a witness for respondent in the trial of the captioned case, which is scheduled for the trial session beginning \[date\].\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. The captioned case is scheduled for trial during the Tax Court trial-session in \[city\] beginning on \[date\].\
\
2\. Respondent and petitioner have agreed, subject to the Court's ratification, that trial of this case should begin on \[date\] i it is anticipated that trial of this case will involve at least eight (8) hours of trial time.\
\
3\. Respondent requires the testimony of \[initials or name\] to rebut anticipated testimony of petitioner or petitioner's witnesses and to aid in satisfying respondent's burden or proof relating to the assertion of the fraud penalty.\
\
4\. \[Initials or name\], who is presently incarcerated in the Federal Correction Institution, located at \[address\], has agreed to testify for respondent at this trial; therefore, it is requested that \[initials or name\] be made available in the United States Tax Court located on the xth floor of \[address\], at \[time\] of \[date\].\
\
5\. This witness is intended to be used both for the purpose of providing direct testimony and for the purpose of rebutting anticipated testimony.\
\
WHEREFORE, respondent prays that the motion be granted.\
\
**Exhibit 35.11.1-99**\
\
### Sample letter to Witness in Prison\
\
| \[Letterhead\] |\
| :-: |\
| \[Name and address of petitioner or petitioner’s counsel\] |\
|  | In re: \[Petitioner’s name\] v. Commissioner<br> Docket No. \[docket no.\] |\
| Dear \[Name\]: |\
| As you are aware, your Tax Court case has recently been scheduled for trial on the \[date\] trial calendar in \[city, state\]. In order for you \[or your client - substitute throughout if the letter is addressed to petitioner’s counsel\] to testify during your trial, you must file a Motion for Writ of Habeas Corpus Ad Testificandum with the Tax Court requesting your release from prison. Your motion should state that your case has been scheduled on \[date\] trial calendar to be held in \[city, state\]; the reason why you need to be present at the trial; your complete name and prisoner identification number; the name and location of the prison; the name and address (and, if possible the phone number) of the warden of the prison; and any other information which might aid the court in securing your release from prison. |\
| It is advisable that this motion be received in the Tax Court at least six weeks prior to the date of the calendar in order to allow the Tax Court sufficient time to make the necessary arrangements for your release, in the event your motion is granted by the Tax Court. |\
| If you require any further information regarding this matter, please write or telephone me at \[phone number\]. |\
|  |  | Sincerely, |\
\
**Exhibit 35.11.1-100**\
\
### Expert Witness Procurement Flow Chart\
\
| _Expert Witness Procurement Flow Chart_ |\
| :-: |\
|  |  |  |  |\
|  | Atty/STA decides to hire and expert |  |\
|  |  |  |  |\
|  | Atty/COTR prepare requisition package for review by manager |  |\
|  |  |  |  |\
|  | Requisition sent to AAC for review/approval (and higher management approval if required due to cost or type of case) |  |\
|  |  |  |  |\
|  | Requisition package sent to General Legal Services Public Contracts and Technology Law for review if legal issues are presented |  |\
|  |  |  |  |\
|  | COTR sends requisition to F&M for funds approval |  |\
|  |  |  |  |\
|  | After F&M grants funds approval, funds are committed on RTS by COTR |  |\
|  |  |  |  |\
|  | COTR then transmits requisition package to Procurement, with notification to COTR |  |\
|  |  |  |  |\
|  | Procurement issues purchase order or contract; sends to Counsel |  |\
|  |  |  |  |\
\
**Exhibit 35.11.1-101**\
\
### Expert Witness Procurement — Billing and Related Processes\
\
![This is an Image: 30026189.gif](https://www.irs.gov/pub/xml_bc/30026189.gif)\
\
> This is a flowchart of billing and related processes in an expert witness procurement.\
\
[Please click here for the text description of the image.](https://www.irs.gov/media/157756 "")\
\
**Exhibit 35.11.1-102**\
\
### Obtaining Testimony of a Witness in a Foreign Country: Application for a Letter Rogatory\
\
| **APPLICATION FOR ISSUANCE OF A LETTER ROGATORY**<br>**AUTHORIZING A FOREIGN DEPOSITION** |\
| :-: |\
| RESPONDENT submits this application under Rules 81(a) and (e) (2) of the Tax Court's Rules of Practice and Procedure for a letter rogatory authorizing the respondent to take a foreign deposition of \[name of deponent\]. The \[name of deponent\] will be required to produce \[describe documents or records\], and will be propounded questions intended to authenticate the foreign documents \[or, alternatively and only for purposes of authentication of foreign records of regularly conducted activity, will be requested to execute a certification form meeting the requirements of Rule 902(12) of the Federal Rules of Evidence. |\
| IN SUPPORT THEREOF, respondent respectfully states: |\
| \[In numbered paragraphs, state briefly the nature of the case, the name and address of the proposed deponent, the scope of the examination, and why the foreign evidence is necessary (including unsuccessful attempts to obtain the information by administrative means)\] |\
| \[State whether petitioner's counsel objects to the granting of the application\] |\
| WHEREFORE, it is prayed that this application be granted and that the letter rogatory submitted herewith be issued. |\
\
**Exhibit 35.11.1-103**\
\
### Obtaining Testimony of a Witness in a Foreign Country: Letter Rogatory\
\
|  |\
| --- |\
| UNITED STATES TAX COURT |\
|  |\
| \[NAME\] | )<br> ) |  |\
| Petitioner, | )<br> ) |  |\
| v. |  | )<br> ) | Docket No. \[docket no.\]<br> Judge \[name\] |\
| COMMISSIONER OF INTERNAL REVENUE, | )<br> ) |  |\
| Respondent. | ) |  |\
| **REQUEST FOR INTERNATIONAL JUDICIAL ASSISTANCE** |\
| TO: \[NAME OF THE COURT IN REQUESTED COUNTRY\] |\
| The United States Tax Court presents its compliments to you and requests your assistance described herein as necessary in the interests of justice. The assistance requested is that \[the appropriate judicial authority\] of the United States of America compel the appearance of the \[name of deponent\] to give evidence \[and/or produce documents\] . |\
| WHEREAS, this proceeding is properly under the jurisdiction of and is now pending before the United States Tax Court located in \[city and state\], United States of America, between petitioner, \[name\], and the respondent, \[name\] |\
| WHEREAS, the claims asserted in this action arise out of \[brief description and year of tax liability\] |\
| WHEREAS, a significant issue exists as to \[describe issue\] |\
| WHEREAS, \[explain why deposition of witness/person (name, nationality and address) is necessary, in connection with the issue in the case\] |\
| WHEREAS, \[description of documents or other evidence to be produced\] |\
| WHEREAS, \[generally, the questions that the witness will be asked, including questions intended to authenticate the foreign documents\] |\
| WHEREAS, \[list the laws of the applicant country which govern the matter pending before the court in the requested country; and list any special rights of witnesses pursuant to the laws of the applicant country\]; |\
| WHEREAS, \[list any special methods or procedures to be followed, including, for example, the need to schedule the deposition at the earliest possible date because of an impending trial date\]; |\
| NOW, I, \[name of Judge\], United States Tax Court Judge, pursuant to \[applicable Tax Court rules\], hereby request that, in furtherance of justice and by the proper and usual process of your court, you summon \[name of deponent\], or an authorized agent to appear before you or some competent person appointed by you, at a time and place by you to be fixed, there to answer questions upon oral deposition and produce for inspection and copying the documents listed in \[Exhibit number\] attached hereto that are within \[name of deponent\] 's custody, possession or control; and that you will cause the testimony to be committed to writing, and such books, papers, records or other things which said witness produces to be returned under cover duly sealed and addressed to \[name and address of attorney\], United States of America. |\
| This court expresses its appreciation to you for your courtesy and assistance in this matter and states that, pursuant to the authority of 28 U.S.C. § 1782, the Courts of the United States stand ready and willing to do the same for you in a similar matter when required. |\
| \[The requesting court should include a statement expressing a willingness to reimburse the judicial authorities of the receiving state for costs incurred in executing the requesting court's letter rogatory. **Note that effective June 1, 2002, there is a $650.00 consular fee for processing letters rogatory. Counsel are requested to submit a certified bank check in the amount of $650.00 payable to the U.S. Embassy**\]. |\
|  |\
|  | \[Signature of requesting Judge\]<br> \[Typed name of requesting Judge\]<br> \[Name of requesting Court\]<br> \[City, State, United States of America\] |\
| Date |\
| \[Seal of Court\] |\
\
**Exhibit 35.11.1-104**\
\
### Motion for Protective Order\
\
|  |\
| :-: |\
| **MOTION FOR PROTECTIVE ORDER** |\
\
RESPONDENT MOVES, pursuant to the provisions of Rule 103(a) (2) of the Court's Rules of Practice and Procedure, that the Court enter an order that respondent, at this time, need not answer the request for admissions served on him by petitioner.\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. On \[date\], petitioner filed \[his/her\] petition in the above-captioned case.\
\
2\. On \[date\], respondent filed \[his/her\] answer.\
\
3\. On \[date\], petitioner filed \[his/her\] reply\
\
4\. On \[date\], petitioner served on respondent a request for admissions, a copy of which is attached here to as Exhibit A.\
\
5\. Petitioner has had no informal conferences with respondent's counsel with respect to this case. Respondent has not denied the petitioner the right to any informal conference.\
\
6\. Respondent is willing to meet with petitioner at a mutually convenient time to discuss the issues involved herein and attempt to stipulate facts in accordance with T.C. Rule 91 (a).\
\
7\. T.C. Rule 90(a) provides in part that the Court expects the parties to attempt to attain the objectives of such a request through informal consultation or communication before utilizing the procedures provided by this Rule.\
\
8\. Petitioner has not complied with the letter or spirit of T.C. Rule 90 regarding admissions and the use of purported request for admissions by petitioner herein is an abuse of the Court's procedures. Branerton Corp. v. Commissioner, 61 T.C. 691 (1974), Odendhal v. Commissioner, 75 T.C. 400 (1980).\
\
9\. This motion is made without prejudice to respondent's right to assert specific objections to any of the attached requests for admissions in accordance with T.C. Rule 90(c) at a later appropriate time.\
\
WHEREFORE, respondent prays that this motion be granted.\
\
**Exhibit 35.11.1-105**\
\
### U.S. Tax Court Standing Pretrial Order\
\
| **UNITED STATES TAX COURT** |\
| :-: |\
| **WASHINGTON, D.C.**<br> www.ustaxcourt.gov |\
| **STANDING PRETRIAL ORDER** |\
\
**The attached Notice Setting Case for Trial notifies the parties that this case is calendared for trial at the trial session beginning on \[day, date\]**\
\
**Communication Between the Parties.** The parties shall begin discussing settlement and/or preparation of a stipulation of facts as soon as practicable. Valuation cases and reasonable compensation cases are generally susceptible of settlement, and the Court expects the parties to negotiate in good faith with this goal in mind. All minor issues should be settled so that the Court can focus on the issue(s) needing a Court decision. If a party has trouble communicating with another party or complying with this Order, the affected party should promptly advise the Court in writing, with a copy to each other party, or request a conference call for the parties and the trial Judge.\
\
**Continuances.** Continuances (i.e., postponements of trial) will be granted only in exceptional circumstances. See Rule 133, Tax Court Rules of Practice and Procedure. (The Court’s Rules are available at www.ustaxcourt.gov.) Even joint motions for continuance are not granted automatically.\
\
**Sanctions.** The Court may impose appropriate sanctions, including dismissal, for any unexcused failure to comply with this Order. See Rule 131(b). Such failure may also be considered in relation to sanctions against and disciplinary proceedings involving counsel. See Rule 202(a).\
\
**Electronic Filing (eFiling).** eFiling is required for most documents (**except the petition**) filed by parties represented by counsel in cases in which the petition is filed on or after July 1, 2010. Petitioners not represented by counsel may, but are not required to, eFile. For more information about eFiling and the Court’s other electronic services, see www.ustaxcourt.gov.\
\
To help the efficient disposition of all cases on the trial calendar:\
\
**1\. Stipulation.** It is ORDERED that all facts shall be stipulated (agreed upon in writing) to the maximum extent possible. All documents and written evidence shall be marked and stipulated in accordance with Rule 91(b), unless the evidence is to be used only to impeach (discredit) a witness. Either party may preserve objections by noting them in the stipulation. If a complete stipulation of facts is not ready for submission at the start of the trial or when otherwise ordered by the Court, and if the Court determines that this is due to lack of cooperation by either party, the Court may order sanctions against the uncooperative party.\
\
**2\. Trial Exhibits.** It is ORDERED that any documents or materials which a party expects to use (except solely for impeachment) if the case is tried, but which are not stipulated, shall be identified in writing and exchanged by the parties at least 14 days before the first day of the trial session. The Court may refuse to receive in evidence any document or material that is not so stipulated or exchanged, unless the parties have agreed otherwise or the Court so allows for good cause shown.\
\
**3\. Pretrial Memoranda.** It is ORDERED that, unless a basis of settlement (resolution of the issues) has been reached, each party shall prepare a Pretrial Memorandum containing the information in the attached form. Each party shall serve on the other party and file the Pretrial Memorandum not less than 14 days before the first day of the trial session.\
\
**4\. Final Status Reports.** It is ORDERED that, if the status of the case changes from that reported in a party’s Pretrial Memorandum, the party shall submit to the undersigned and to the other party a Final Status Report containing the information in the attached form. A Final Status Report may be submitted to the Court in paper format, electronically by following the procedures in the "Final Status Report" tab on the Court’s Web site or by fax sent to 202-521-3378. (Only the Final Status Report may be sent to this fax number; any other documents will be discarded.) The report must be received by the Court no later than 3 p.m. eastern time on the last business day (normally Friday) before the calendar call. The Final Status Report must be promptly submitted to the opposing party by mail, email, or fax, and a copy of the report must be given to the opposing party at the calendar call if the opposing party is present.\
\
**5\. Witnesses.** It is ORDERED that witnesses shall be identified in the Pretrial Memorandum with a brief summary of their anticipated testimony. Witnesses who are not identified will not be permitted to testify at the trial without a showing of good cause.\
\
**6\. Expert Witnesses.** It is ORDERED that unless otherwise permitted by the Court, expert witnesses shall prepare a written report which shall be submitted directly to the undersigned and served upon each other party at least 30 days before the first day of the trial session. An expert witness's testimony may be excluded for failure to comply with this Order and Rule 143(g).\
\
**7\. Settlements.** It is ORDERED that if the parties have reached a basis of settlement, a stipulated decision shall be submitted to the Court prior to or at the call of the calendar on the first day of the trial session. Additional time for submitting a stipulated decision will be granted only where it is clear that all parties have approved the settlement. The parties shall be prepared to state for the record the basis of settlement and the reasons for delay. The Court will specify the date by which the stipulated decision and any related settlement documents will be due.\
\
**8\. Time of Trial.** It is ORDERED that all parties shall be prepared for trial at any time during the trial session unless a specific date has been previously set by the Court. Your case may or may not be tried on the same date as the calendar call, and you may need to return to Court on a later date during the trial session. Thus, it may be beneficial to contact the Court in advance. Within 2 weeks before the start of the trial session, the parties may jointly contact the Judge’s chambers to request a time and date certain for the trial. If practicable, the Court will attempt to accommodate the request, keeping in mind other scheduling requirements and the anticipated length of the session. Parties should jointly inform the Judge as early as possible if they expect trial to require 3 days or more.\
\
**9\. Service of Documents.** It is ORDERED that every pleading, motion, letter, or other document (with the exception of the petition and the posttrial briefs, see Rule 151(c)) submitted to the Court shall contain a certificate of service as specified in Rule 21(b), which shows that the party has given a copy of that pleading, motion, letter or other document to all other parties.\
\
\[Judge’s name\]\
\
Judge\
\
Dated:\
\
**Exhibit 35.11.1-106**\
\
### Pretrial Memorandum\
\
|  |\
| --- |\
| **Trial Calendar:**<br>**Date:** | \[city, State\]<br> \[day, date\] |\
| **PRETRIAL MEMORANDUM FOR**(Petitioner/Respondent)<br> Please type or print legibly<br> (This form may be expanded as necessary) |\
| **NAME OF CASE:** \_ | **DOCKET NO.(S):** \_ |\
| **ATTORNEYS:** |\
| Petitioner: \_\_<br> Tel. No.: \_ | Respondent: \_\_<br> Tel. No.: \_ |\
| **AMOUNTS IN DISPUTE:** |\
| Year(s)/Period(s) | Deficiencies/Liabilities | Additions/Penalties |\
|  |\
| **STATUS OF CASE:**<br> Probable Settlement \_ Probable Trial \_ Definite Trial \_ |\
| **CURRENT ESTIMATE OF TRIAL TIME:** \_ |\
| **MOTIONS YOU EXPECT TO MAKE:** (Title and brief description) |\
|  |\
| **STATUS OF STIPULATION OF FACTS:** Completed \_ In Process \_ |\
| **ISSUES:** |\
|  |\
| **WITNESS(ES) YOU EXPECT TO CALL:**<br> (Name and brief summary of expected testimony) |\
|  |\
| **SUMMARY OF FACTS:**<br> (Attach separate pages, if necessary, to inform Court of facts in chronological narrative form) |\
|  |\
| **BRIEF SYNOPSIS OF LEGAL AUTHORITIES:**<br> (Attach separate pages, if necessary, to discuss fully your legal position) |\
|  |\
| **EVIDENTIARY PROBLEMS:** |\
|  |\
| DATE: \_ | \_\_<br> Petitioner/Respondent |\
| Trial Judge: | **\[Judge's name\]**<br>**United States Tax Court, \[room no.\]**<br>**400 Second Street, N.W.**<br>**Washington, D.C. 20217**<br>**\[Judge’s chambers phone no.\]** |\
\
**Exhibit 35.11.1-107**\
\
### Letter Enclosing Settlement Documents\
\
| \[letterhead\] |\
| :-: |\
| \[Name and address of petitioner(s)\] |\
|  |  | In re: \[Name\] v. Commissioner<br> Docket No. \[docket no.\] |\
|  |\
\
Dear Mr./Mrs./Ms. \[name\]:\
\
In order to finalize our settlement, we must file with the Tax Court a decision document that shows the amount of tax and additions to tax/penalties that you owe based on that settlement.\
\
Enclosed are the following documents:\
\
|  |\
| --- |\
|  | 1. | A decision document (original and two copies) that shows the amount that you owe; |\
|  | 2. | A Statement of Account that shows the calculation of the amount owed and all the payments and other credits that are reflected on the records of the Internal Revenue Service for the tax year(s) at issue in your case; |\
|  | 3. | A calculation of the estimated interest that you owe based on your settlement if you pay the entire amount of tax \[additions to tax/penalties\] and interest by \[date\]; and |\
|  | 4. | Publication 594, which explains the collection process. |\
\
Please carefully review the Statement of Account, the interest computations and the decision document to make sure that you agree with them. It is important that they be correct because the United States Tax Court will usually not change its decision, even if there is a mistake, unless the Court is notified of the mistake within 30 days after the decision is accepted by the Court. If you believe that there are mistakes in our calculations of the amount you owe or in the decision, please telephone me as soon as possible.\
\
If you agree with the calculations and the decision document, please sign the original and one copy of the decision document and return them to this office for filing with the Tax Court. The remaining copy as well as the Statement of Account and the calculation of interest are for your records. \[Please note that because the title of the Tax Court case is under both of your names, both of you must sign the decision.\] \[The United States Tax Court has ordered the parties to file the decision by \[date decision due with Court\], so you should return the decision to us before that date so that we can file it with the court on time.\]\
\
Once the decision document is filed and entered by the Tax Court, the Internal Revenue Service will send you a bill for the amount you owe. \[Because a joint return was filed, both spouses are jointly and severally liable for the tax, any additions to tax and penalties and the interest.\] In case you want to pay the tax, \[additions to tax/penalties\] and interest before you receive the bill, you may do so. As previously noted, the interest calculations are estimates and only apply until \[dates noted above\]. A final computation will be made at the Service Center. The interest you owe will increase if full payment is not made by those dates. Also, interest will continue to run on the unpaid portions if you pay less than the total amount due.\
\
If you decide to immediately pay some or all of the amount you owe, please mail a check to the \[name and address of local Service Center\]. The check should be made payable to the United States Treasury. In order to process the check and apply the payments appropriately, please include all of the following information with your check:\
\
|  |\
| --- |\
|  | 1. | Your name(s) and address(es). |\
|  | 2. | Your Social Security number(s). |\
|  | 3. | The tax year(s) for which you are paying. |\
|  | 4. | The type of tax due (for example, income tax, estate tax, excise tax). |\
|  | 5. | The total amount of your payment. If you owe tax for more than one year, the Internal Revenue Service will also need to know how much you are paying for each year. You should also state how much of each year’s payment you are paying towards tax, \[how much for the additions to tax,\] and how much you are paying towards interest. |\
|  | 6. | A copy of the decision document which you have signed. |\
\
Please be advised that you should not consider any agreement to settle this case final and binding until we have executed the decision documents and mailed them to the Tax Court for filing. If you have any questions about this matter, please let me know.\
\
|  |\
| --- |\
|  | Very truly yours, |\
|  |  |\
|  | \[Attorney’s name\]<br> Tax Court Bar # |\
\
**Exhibit 35.11.1-108**\
\
### Letter to Tax Court Judge Reporting Status of Settled Cases\
\
| \[Letterhead\] |\
| :-: |\
| \[Date\] |\
| The Honorable \[Name\]<br> Judge, United States Tax Court<br> 400 Second Street, N.W.<br> Washington, DC 20217 |\
| Re: \[Name\] v. Commissioner, Docket No. \[docket no.\] |\
| Dear Judge \[Name\]: |\
| This refers to the trial calendar in \[city and state\] on \[date\] at which you presided. At that trial calendar, this case was reported settled but the parties were unable to file settlement documents while the Court was in session. |\
| The purpose of this letter is to advise that, as of this date, the parties to this case have been unable to submit settlement documents, the reason for the delay, and the estimated date when the settlement documents will be filed with the Court. \[Examples are listed below.\] |\
| \[Example 1\] A recomputation is expected to be completed within two weeks. Decision documents will be forwarded shortly thereafter. It is expected that the signed decision documents will be forwarded to the Court within four weeks of this date. |\
| \[Example 2\] Petitioners state that they have signed the decision documents and mailed them to us. We expect to forward them to the Court within ten days. |\
| \[Example 3\] Complications have arisen in the recomputations. The petitioner and respondent are hopeful that stipulated decision documents will be filed within 30 days. |\
| \[Example 4\] Stipulated decision documents signed by the petitioners have been received. They will be forwarded to the Court within 24 hours. |\
|  | Very truly yours, |\
|  |\
|  | \[Attorney\] |\
| cc: \[petitioner or petitioner’s counsel\]<br> bcc: \[Area Counsel\] |\
\
**Exhibit 35.11.1-109**\
\
### Cases Involving a Complete Settlement or Concession Requiring a Report to Joint Committee\
\
This exhibit illustrates cases involving a complete settlement or concession, as distinguished from a partial settlement or concession, in which a report to the Joint Committee is required covering all the years shown before any settlement document is filed with the court.\
\
Settlement of docketed years involving a tentative allowance of a refund or credit under I.R.C. § 6411 not previously reported to the Joint Committee and deficiencies resulting from the settlement:\
\
|  |\
| --- |\
| Taxable<br>Year | Kind of<br>Tax | Previous<br> Allowance,<br>Sec, 6411 | Deficiency | Net Overpayment<br>for Year |\
| \[year\] | Income | $ 1,800,000 | $ 100,000 | $ 1,700,000 |\
|  | Interest assessed and paid | 1,860,000 | 100,000 | 1,760,000 |\
| \[year\] | Income | 450,000 | 120,000 | 330,000 |\
| \[year\] | Income | -0- | 80,000 | (80,000) |\
|  |  |  |  |  |\
| Aggregate net overpayment for report to Joint Committee | $ 2,070,000 |\
\
|  |\
| --- |\
| Settlement of docketed years not involving a tentative allowance: |\
| Taxable Year | Kind of Tax | Overpayment | Deficiency for Year | Net Overpayment |\
| \[year\] | Income | $ 400,000 |  | $ 400,000 |\
| \[year\] | Income | 100,000 | 100,000 | (100,000) |\
| \[year\] | Income | 1,800,000 |  | 1,800,000 |\
| \[year\] | Income |  | 40,000 | (40,000) |\
| Aggregate net overpayment for all years for report to Joint Committee: | $ 2,060,000 |\
\
**Exhibit 35.11.1-110**\
\
### Cases Involving a Complete Settlement Note Requiring Review by Joint Committee\
\
This exhibit illustrates cases involving a complete settlement, as distinguished from a partial settlement or concession, in which review by the Joint Committee is not required because the aggregate net overpayment for all years is less than the jurisdictional amount.\
\
| 1\. Settlement of docketed years involving a tentative allowance of a refund or credit under I.R.C. § 6411 not previously reported to the Joint Committee and deficiencies resulting from the settlement: |\
| --- |\
| Taxable<br> Year | Kind of Previous Allowance,Tax | Sec. 6411 | Deficiency | Net Overpayment<br> for Year |\
| \[year\] | Income | $ 900,000 | $ 300, 000 | $ 600,000 |\
| \[year\] | Income | 1,500,000 | 250,000 | 1,250,000 |\
| \[year\] | Income | 200,000 | -0- | 200,000 |\
| \[year\] | Income | 100,000 | 170,000 | (70,000) |\
| Aggregate net overpayment for all years | $ 1,980,000 |\
\
| 2\. Settlement of docketed years not involving a tentative allowance: |\
| --- |\
| Taxable<br> Year | Kind of<br> Tax | Overpayment | Deficiency | Net Overpayment<br> for Year |\
| \[year\] | Income | $ 1,200,000\* |  |  |\
|  | Fraud Penalty Assessed and Paid | 140,000\* |  |  |\
|  | Interest Assessed and Paid | 20,000\* |  |  |\
|  | Delinquency Penalty |  | $ 150,000 |  |\
|  | Negligence Penalty |  | 30,000 |  |\
| Total |  | $ 1,360,000 | $ 180,000 |  |\
|  |  |  |  | $ 1,180,000 |\
| \[year\] | Income |  | $ 160,000 |  |\
|  | Fraud Penalty |  | 30,000 |  |\
| Total |  |  | $ 190,000 |  |\
|  |  |  |  | (190,000) |\
| Aggregate net overpayment for all years | $ 990,000 |\
| \*Paid after issuance of statutory notice |  |\
\
**Exhibit 35.11.1-111**\
\
### Method of Computing the Aggregate Minimum Net Overpayment\
\
1. | 1\. Report to Joint Committee required: |\
| --- |\
| Taxable<br> Year | Kind of<br> Tax | Overpayment Attributable to Issues Settled or Conceded | Maximum Deficiency Which Remaining Issues Could Produce | Minimum Net<br> Overpayment<br> for Year |\
| \[year\] | Income | $ 2,140,000 | $ 40,000 | $ 2,100,000 |\
| \[year\] | Income | 160,000 | 20,000 | 140,000 |\
| Aggregate minimum net overpayment for report to Joint Committee | $ 2,240,000 |\
\
\
\
\
\
\
| 2\. Report to Joint Committee not required: |\
| --- |\
| Taxable<br> Year | Kind of<br> Tax | Overpayment Attributable to Issues Settled or Conceded | Maximum Deficiency Which Remaining Issues Could Produce | Minimum Net<br> Overpayment<br> for Year |\
| \[year\] | Income | $ 400,000 | $ 280,000 | $ 120,000 |\
| \[year\] | Income | 1,020,000 | 160,000 | 860,000 |\
| Aggregate minimum net overpayment | $ 980,000 |\
\
\
\
\
\
\
| 3\. Report to Joint Committee required because the tentative allowances not previously been reported to the Joint Committee will cause an aggregate net overpayment in excess of the jurisdictional amount even if all issues in the Tax Court case are disposed of by trial or settlement favorable to the respondent: |\
| --- |\
| Taxable<br> Year | Kind of<br> Tax | Previous Allowance,<br> or Conceded | Maximum Potential Deficiency inControversy | Minimum Overpayment (Maximum Deficiency)for Year |\
| \[year\] | Income | $ 2,200,000 | $ 100,000 | $ 2,100,000 |\
| \[year\] | Income |  | 80,000 | (80,000) |\
| Aggregate net overpayment for report to the Joint Committee | $ 2,020,000 |\
\
\
**Exhibit 35.11.1-112**\
\
### Joint Committee Report\
\
| \[letterhead\] |\
| :-: |\
|  | \[initials\]<br> \[name and telephone number\] |\
| The Chairperson<br> Joint Committee on Taxation<br> Attn: Senior Refund Counsel<br> Room 3565<br> Internal Revenue Building<br> 1111 Constitution Avenue, N.W.<br> Washington D.C. 20224 |\
\
Dear Chairperson:\
\
As required by section 6405 of the Internal Revenue Code, the following refunds or credits of income tax owing to \[case name\] of \[city, state\] in Docket No. \[docket number\] are reported before entry of stipulation:\
\
|  |\
| --- |\
|  | Taxable Year | Type of Tax | Section 6405(a) Refund |  |\
|  | \[year\] | Income | $ 1,900,000 |  |\
|  | \[year\] | Income | 1,300,000 |  |\
|  |  |  | $ 3,200,000 |  |\
\
Counsel’s proposed settlement of an issue relating to \[description of issue\] will cause a net aggregate overpayment in excess of the jurisdiction amount. The principal cause of the overpayments in \[year\] and \[year 2\] was \[brief description of cause\]. The years \[years\] are before the Tax Court. With respect to \[year\], there is a deficiency of $ \[amount\] and a section 6405(b) credit in the amount of $ \[amount 2\], for a net deficiency of $ \[deficiency amount\]. Accordingly, the section 6405(a) refund for purposes of the computation to determine if the threshold for Joint Committee jurisdiction is met is $ \[amount\]. Counsel’s proposed disposition is more fully explained in the attached Counsel Settlement Memorandum.\
\
The taxable income and tax liability reported on the returns and the taxable income as finally determined are as follows:\
\
|  |\
| --- |\
|  | Year | Taxable Income (Loss) | Tax Liability | Finally Determined Taxable Income (Loss) Prior To Allowance of NOLD |\
|  | \[year\] | $ 65,000,000 | $ 31,000,000 | $ 60,000,000 |\
|  | \[year\]\* | (3,000,000) | -0- | (2,500,000) |\
\
\*Consolidated return.\
\
Net operating loss deduction allowed:\
\
|  |\
| --- |\
|  | Year | Amount | Carryback From |  |\
|  | \[year\] | $ 1,200,000 | \[year\] |  |\
\
Taxpayer History\
\
The taxpayer was incorporated in \[state\] on \[date\], for \[original business\]. It has since expanded to \[current business\]. The taxpayer’s stock is publicly owned and listed on the New York Stock Exchange. The taxpayer has a subsidiary but did not file consolidated returns for \[years\].\
\
The \[year\] return is a consolidated return and $ \[amount\] of the finally determined consolidated loss of $ \[amount\] is attributable to the taxpayer. The principal causes for the \[year\] loss were \[description of causes\].\
\
The overpayments for \[years\] were caused by \[describe cause of overpayments\].\
\
Prior Examination and Appeals History\
\
The revenue agent made numerous adjustments for the years \[years\]. Most of these adjustments have been agreed to by the taxpayer at the examination level. However, no agreement was reached as to the issues concerning \[description of issues\]. Subsequently, a 30-day letter was issued by the Examination Division and the taxpayer filed a protest with respect to the two unagreed issues. The Revenue Agent’s Report, which sets forth both the agreed and unagreed adjustments for the years \[years\], was issued on \[date\].\
\
The case was sent to the \[city\] Appeals office for consideration. As part of the appeals process, the issue concerning \[describe\] was resolved. However, no agreement was reached as to the issue concerning \[describe\]. Action by Appeals is more fully explained in the attached Appeals Transmittal Memorandum and Supporting Statement dated \[date\].\
\
The overassessments are approved.\
\
|  |\
| --- |\
|  | Very truly yours, |\
|  |\
|  | Area Counsel |\
\
Attachments:\
\
Appeals Transmittal Memorandum and Supporting Statement\
\
Appeals Audit Statement\
\
Counsel Settlement Memorandum\
\
\\_\\_\\_\_\_\_\
\
**_Note:_** The name, symbols, and telephone number of the attorney preparing the report should be indicated. While the report is addressed to the Chairman, Joint Committee on Taxation, the envelope should be addressed to Senior Refund Counsel, Room 3565, Internal Revenue Service, 1111 Constitution Avenue, N .W., Washington, DC 20224.\
\
**Exhibit 35.11.1-113**\
\
### Letter to the Joint Committee\
\
| U.S. DEPARTMENT OF JUSTICE<br> TAX DIVISION |\
| :-: |\
| \[identifying initials\]<br> \[identifying case designation\] |\
|  | \[date\] |\
| The Honorable Chairperson<br> Joint Committee on Taxation<br> Room 1015<br> Longworth House Office Bldg.<br> Washington, D.C. 20515 |\
|  | Re: | \[case name\]<br>Civil Action No. \[docket number\] |\
| Dear Ms. Chairperson: |\
| In accordance with the provisions of section 6405 of the Internal Revenue Code and the letter dated \[date\], from \[name of Chief Counsel\], Chief Counsel, Internal Revenue Service, there is transmitted herewith a copy of our letter of this date to Chief Counsel, Internal Revenue Service, and a copy of a Memorandum dated \[date\], in support of the proposed settlement, under the authority vested in the Attorney General under I.R.C. § 7122 and Executive Order 6166, in full settlement of all issues involved in the case of \[case name\], now pending in the United States District Court for the \[district\], Civil Action No. \[docket number\]. The proposed settlement would result in the refund of approximately $ \[amount\] in tax plus assessed interest paid, and statutory interest, for the years \[years\]. |\
| The period of 30 days during which the overassessment will be withheld from final settlement expires on \[date\]. |\
|  |  |  | Very truly yours, |\
|  |  |  | \[NAME\]<br> Assistant Attorney General<br> Tax Division |\
|  |  |  | By: |\
|  |  |  | \\_\\_\\_\_\_\_\_\_\_\_ |\
|  |  |  | \[NAME\]<br> Chief, Office of Review |\
| Enclosures: |  |  |\
|  | 1 cc letter to Chief Counsel<br> 1 cc Supporting Memorandum dated \[date\] |\
\
**Exhibit 35.11.1-114**\
\
### Joint Motion for Voluntary Binding Arbitration\
\
**JOINT MOTION FOR VOLUNTARY BINDING ARBITRATION**\
\
THE PARTIES JOINTLY MOVE the Court to issue an order directing the parties to submit the issue of the valuation of oil, gas, and mineral (subsurface) rights to an agreed upon expert pursuant to the stipulation filed concurrently herewith.\
\
IN SUPPORT THEREOF, the parties respectfully state:\
\
1\. The above entitled cases are currently calendared for trial at the trial session of \[date\], in \[city, state\].\
\
2\. The parties have prepared a Stipulation to be Bound by Findings of an Expert under supervision by the Court, with a view to reaching an agreement of the parties for entry of a decision in these cases.\
\
3\. The only issue to be submitted to the expert is a totally factual issue requiring the valuation of certain subsurface rights in land purchased from a partnership which includes the petitioners.\
\
4\. The parties hereby request the Court to issue an Order providing for Court supervision and appropriate instructions to the parties and to the expert.\
\
5\. Authority for this procedure is derived from T.C. Rule 124, providing for voluntary binding arbitration.\
\
6\. The parties attach hereto as Exhibit A, a proposed order covering this procedure for consideration by the Court.\
\
WHEREFORE, it is prayed the parties motion be granted.\
\
**Exhibit 35.11.1-115**\
\
### Joint Motion for Stipulation to be Bound by Findings of Arbitrator\
\
|  |\
| :-: |\
| **STIPULATION TO BE BOUND BY FINDINGS OF ARBITRATOR** |\
\
Pursuant to T.C. Rule 124, the parties hereto, petitioner, \[name\], and respondent, the Commissioner of Internal Revenue, hereby stipulate and agree to submit certain issue\[s\] in the above-entitled case to binding arbitration on the following basis:\
\
1\. The parties agree to be bound by the final report of an arbitrator and further agree not to take any appeal from such report to a judge of the United States Tax Court or to any higher appellate court.\
\
2\. The parties have agreed on the identity of an arbitrator, who is: \[name, address, and telephone number\]. This person has agreed to serve as the arbitrator subject to the approval of the Court.\
\
\[OR\]\
\
2\. The parties have agreed on a procedure to select an arbitrator under which \[describe procedures\]. Upon selection of the arbitrator, the parties will notify the Court of the identity of the arbitrator by supplementing this stipulation. The supplemental stipulation shall include the name, address and telephone number of the arbitrator so that the Court can issue an appropriate order under T.C. Rule 124(b) (3) to appoint the arbitrator.\
\
3\. The matter to be submitted to and determined by the arbitrator is the following factual issue: (description of issue)\
\
4\. The parties agree that the above-described issue is factual in nature and does not present any issues of law and does not require the arbitrator to rule on any issue of law in preparing a final report.\
\
5\. The parties will file herewith a joint motion requesting the United States Tax Court to issue an order directing the parties to proceed under the terms of this stipulation. Such joint motion is based upon the mutual understanding that the Court's order will charge the arbitrator to conduct \[his/her) activities in accordance with the terms and procedures set forth in this Stipulation.\
\
6\. The parties agree that the following documents and information will be submitted to, or made available to, the arbitrator for consideration:\
\
a. \[Itemize documentation and other evidentiary facts.)\
\
b. \[If relevant, describe the agreed access of the arbitrator to such documentation, including, if appropriate, the location at which such access is to be made available.\]\
\
No other documents or information will be submitted or made available to the arbitrator except with the joint agreement of both parties.\
\
7\. The parties agree that the documents listed in Paragraph Six of this Stipulation shall be provided to the arbitrator together with a copy of this Stipulation under cover of a joint letter signed by counsel for each of the parties, within \[insert\] days after entry of the order described in Paragraph Five. \[The parties further agree that access provided for in Paragraph Six of this Stipulation shall be provided to the arbitrator within \[#\] days after entry of the order described in Paragraph Five.\]\
\
\[OPTIONAL\]\
\
8\. a. The parties agree that the arbitrator, upon request, shall have the right to interview \[ names\], and no other persons, except upon joint agreement of both parties. The parties shall specify the form and content of the questions to be asked by the arbitrator. The parties shall specify the dates of the interview(s). Any such interviews shall be held only after reasonable opportunity is given to counsel for both parties to be present.\
\
b. The parties agree that the arbitrator, upon request, shall have the right to inspect \[insert item, _e.g._, specific property or documents\], and no other evidentiary material, except upon joint agreement of both parties. Such inspection shall occur only after reasonable opportunity is given to counsel for both parties to be present.\
\
9\. The parties agree that there shall be no ex-parte communication with the arbitrator by either party. In addition, no party or witness or agent for a party shall have contact with the arbitrator without prior notice to the other party and reasonable opportunity for counsel for all parties to be present during such contact with the arbitrator.\
\
10\. The parties agree that the methodology to be used by the arbitrator in deciding the issue described in Paragraph Three above must follow the principles set forth below: \[insert guidelines here\]\
\
11\. The parties agree that the arbitrator shall be directed to complete a final written report no later than \[#\] days after the order granting binding arbitration is signed by this Court.\
\
12\. The parties agree that the arbitrator's final written report shall explain in detail the determination of the issue made by the arbitrator and the methodology utilized in such determination.\
\
13\. The parties agree that the final report of the arbitrator shall be simultaneously mailed by the arbitrator by certified mail to counsel for the parties at the address undersigned below and to the supervising judge of the United States Tax Court at 400 Second Street, N.W., Washington, D.C. 20217.\
\
14\. Each party shall pay an equal share of the total cost of the arbitrator's fees, including all reasonable expenses incurred by the arbitrator.\
\
15\. The parties shall make timely payment in full to the arbitrator for services rendered within a reasonable period of time after receipt of the final report by the parties, but in no event later than 30 days after receipt of the final report by the parties.\
\
16\. No later than \[#\] days after the date of the arbitrator's final report, the parties shall file with the Tax Court for entry by the supervising judge a stipulated decision on the issue determined by the arbitrator.\
\
**Exhibit 35.11.1-116**\
\
### Joint Motion to Continue for Settlement Purposes\
\
**JOINT MOTION TO CONTINUE FOR SETTLEMENT PURPOSES**\
\
THE PARTIES JOINTLY MOVE, pursuant to the provisions of Rule 133 of the Tax Court's Rules of Practice and Procedure, that the Court remove the above-entitled case from the trial session of the Court scheduled to commence in \[city, state\], on \[date\], for the purposes of settlement pursuant to T.C. Rule 124.\
\
IN SUPPORT THEREOF, the parties respectfully inform the Court, that on \[date\], the parties filed a joint motion for voluntary binding arbitration pursuant to the provisions of T.C. Rule 124.\
\
WHEREFORE, it is prayed that this motion be granted.\
\
**Exhibit 35.11.1-117**\
\
### Model Agreement to Mediate\
\
| **AGREEMENT TO MEDIATE** |\
| :-: |\
|  |\
\
1\. **The Mediation Process**. This mediation is intended to help \[name of taxpayer\] and the Internal Revenue Service (the PARTIES) reach their own negotiated settlement of the issues to be mediated. See (2) below for the participants in the mediation process. To accomplish this goal, the mediator will act as a facilitator, assist in defining the issues and promote settlement negotiations between the PARTIES. The mediator will inform and discuss with the PARTIES the rules and procedures pertaining to the mediation process. The mediator will not have settlement authority and will not render a decision regarding any issue in dispute. The PARTIES WILL CONTINUE TO HAVE SETTLEMENT AUTHORITY FOR ALL ISSUES CONSIDERED UNDER THE MEDIATION PROCESS.\
\
2\. **Nature of Process, Withdrawal**. The mediation process is optional. The participants in the mediation session from \[name of taxpayer\], will be \[name\], \[title\]; and from the Office of Chief Counsel, will be \[name and title\]. The PARTIES must have participants attending the mediation session with decisionmaking authority, or such persons should be available by telephone. Either party may withdraw from the mediation process at any time prior to reaching a settlement of the issues to be mediated by notifying the other party and the mediator in writing.\
\
Each PARTY:\
\
a) may involve other appropriate persons in the mediation;\
\
b) must notify the mediator and the other PARTY two weeks before the mediation session regarding participants on their mediation team; and\
\
c) may withdraw from the process at any time prior to reaching a settlement of the issues to be mediated by notifying the other PARTY and the mediator in writing.\
\
3\. **Selection of Mediator, Costs**. The PARTIES, by mutual agreement, will select a mediator. The mediator may be a non-IRS individual or an Appeals representative, with previous mediation training or experience. Co-mediators can also be selected. A mediator shall have no official, financial, or personal conflict of interest with respect to the PARTIES, unless such interest is fully disclosed in writing to the parties, and they agree that the mediator may serve. The costs of a non-IRS mediator or co-mediator will be shared equally by the PARTIES, subject to applicable rules and regulations for Government procurement. If an Appeals mediator or co-mediator is selected, the IRS will pay the expenses associated with the mediator (or co-mediator). Due to the inherent conflict that results because the Appeals mediator is an employee of the IRS, Appeals will provide to the taxpayer a statement confirming the employee’s proposed service as a mediator, that the person is a current employee of the IRS and that a conflict results from that mediator’s continued status as an IRS employee.\
\
4\. **Issues to be Mediated**. The mediation session will encompass the following items at issue in the Tax Court petition filed in \[Name of petitioner\] v. Commissioner, Docket No. \[docket no.\].\
\
a) \[issue #1\]\
\
b) \[issue #2\]\
\
5\. **Submission of Materials**. Each PARTY will present to the mediator a separate written summation not to exceed 20 pages (exclusive of exhibits consisting of pre-existing documents and reports) regarding the items in issue. The mediator will have the right to ask either PARTY for additional information before the mediation session if deemed necessary for a full understanding of the issues to be mediated. A copy of the information a PARTY gives to the mediator will be provided simultaneously to the other PARTY.\
\
| 6\. **Proposed Schedule** |  |\
| --- | --- |\
| Below is a schedule which will be followed by the PARTIES in preparation for the mediation process: |\
|  | Date for selection of mediator: | By month, day, year |  |\
|  | Date for submission of materials to mediator and other party: | A date which is two weeks before the date of the mediation session |  |\
|  | Date for submission of participant’s list to mediator and other party: | A date which is two weeks before the date of the mediation session |  |\
|  | Mediation session: | By month, day, year |  |\
\
.\
\
7\. **Place of Mediation**: The PARTIES should attempt to select a site near \[name of taxpayer\]’s office or an Internal Revenue Service Counsel office.\
\
8\. **Confidentiality**: The mediation process will be confidential. \[name of taxpayer\] acknowledges that the Mediator and the other persons invited by the PARTIES to participate in the mediation, will have access to all of \[name of taxpayer\]’s return or return information pertaining to the issues being mediated pursuant to I.R.C.§§ 6103(b), 6103(c) and 6103(n) and the regulations thereunder. (See attached Consent to and Acknowledgment of Disclosure of Return and Return Information.) Service employees involved in any way in the mediation process, and any person under contract to the Service that the Service invites to participate, will be subject to the confidentiality and disclosure provisions of the Internal Revenue Code, including I.R.C.§§ 6103, 7213 and 7431. IRS employees, \[name of taxpayer\], the outside mediator, and persons invited to participate by the PARTIES in the mediation shall not voluntarily, or through discovery or compulsory process, disclose any information regarding the mediation process or any communication made during the mediation process, including the settlement terms.\
\
9\. **I.R.C. § 7214(a)(8) Disclosure**: The PARTIES to this agreement acknowledge that Service employees involved in this mediation are bound by the I.R.C. § 7214(a)(8) disclosure requirements concerning violations of any revenue law.\
\
10\. **No Record**. There will be no stenographic record or tape recording of the mediation process.\
\
11\. **Ex Parte Contacts Prohibited**. There will be no ex-parte contacts with the mediator outside the mediation session.\
\
12\. **Stipulation of Settled Issues or Decision Document**. If the mediation process enables the PARTIES to reach an agreement on the issues, Counsel will draft a stipulation of settled issues or a decision document for the PARTIES’ signature and submission to the Tax Court. If the PARTIES cannot reach agreement on the issues being mediated, the PARTIES will prepare for trial as normal.\
\
13\. **Precedential Use**: A settlement reached by the PARTIES through mediation shall not serve as an estoppel in any other proceeding. Such settlement may not be considered in any factually unrelated proceeding and may not be used as precedent.\
\
| NAME OF TAXPAYER | INTERNAL REVENUE SERVICE |\
| --- | --- |\
| By:\_\_\_\_\_\_\_\_ | By: \_\_\_\_\_\_\_\_<br> \[Title\] |\
| Date:\_\_\_\_\_\_\_\_ | Date:\_\_\_\_\_\_\_\_ |\
\
**Exhibit 35.11.1-118**\
\
### Model Mediation Participants List\
\
Case Name:\_\_\_\_\_\_\_\_\
\
Submitted by:\_\_\_\_\_\_\_\_\
\
Date:\_\_\_\_\_\_\_\_\
\
All participants who will attend the mediation on behalf of \[name of party\], including witnesses, consultants, and attorneys, are listed below. This form must be sent to the other PARTY and to the mediator two weeks before the mediation session.\
\
|  |  |  |\
| --- | --- | --- |\
| NAME | AFFILIATION | ADDRESS |\
\
**Exhibit 35.11.1-119**\
\
### Motion for Substitution of Exhibits\
\
|  |\
| :-: |\
| **MOTION FOR SUBSTITUTION OF EXHIBITS** |\
\
RESPONDENT MOVES that the document attached hereto be admitted into evidence in the above-entitled case and substituted for the uncertified copy of the same document admitted during the trial on \[date\].\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. The trial of the above-captioned proceeding was held on \[date\], at the Small Tax Case Trial Session in \[city, state\], the Honorable \[name\] presiding.\
\
2\. At the trial, the respondent moved the admission into evidence as respondent's exhibit an uncertified copy of pages \[page numbers\] of a transcript in the judicial proceedings in the case of \[petitioner's name\], in the Circuit Court for the County of \[name\], \[state\].\
\
3\. At that time, respondent requested that the record be kept open to permit respondent to substitute a certified copy of the partial transcript in the case of \[petitioner's name\], in the Circuit Court for the County of \[name\], \[state\], for the uncertified copy referred to in paragraph \[number\] herein.\
\
4\. The Court admitted into evidence the uncertified copy of the transcript of the state court proceedings subject to the substitution by respondent of certified copy of those pages of the transcript within 45 days from \[date\], which date is \[date\]\
\
5\. The respondent has attached hereto a certified copy of pages \[#\] through \[#\], inclusive and pages \[#\] and \[#\], inclusive of the state court proceedings which were previously introduced into evidence by respondent, together with the certification of the Deputy Clerk of the Circuit Court for the County of \[name\], \[state\], identifying said pages as true and accurate copies.\
\
6\. Said certificate transcript is admissible into evidence as a self-authenticating public record pursuant to Rules 902(4) and 901(7) of the Federal Rules of Evidence and pursuant to the hearsay exception contained in Rule 803(8).\
\
WHEREFORE, respondent requests that this motion be granted.\
\
**Exhibit 35.11.1-120**\
\
### Motion to Withdraw Exhibit for Purposes of Copying\
\
|  |\
| :-: |\
| **MOTION TO WITHDRAW EXHIBIT FOR PURPOSES OF COPYING** |\
\
RESPONDENT MOVES, pursuant to Tax Court Rules 50 and 143(d), that the Court permit respondent to withdraw respondent's Exhibit \[#\], the U.S. Individual Income Tax Return, Form 1040, filed by \[petitioner's name\], for tax year \[year\], for purposes of copying that return and substituting the copy for the original in the Court record.\
\
IN SUPPORT OF THIS MOTION, respondent respectfully states:\
\
1\. These cases were tried before the Honorable \[Judge's name\] on \[date\], and the original \[year\] return filed by \[petitioner's name\] was submitted into evidence at the Court's request.\
\
2\. Special Agent \[name\] has advised respondent's counsel that as a part of a related investigation, \[agent's name\] desires to make copies of the original \[year\] federal return filed by \[petitioner's name\].\
\
3\. Respondent's counsel expects that the exhibit may be withdrawn, copied, and a copy returned to the Court within four weeks.\
\
WHEREFORE, respondent respectfully requests that this motion be granted.\
\
**Exhibit 35.11.1-121**\
\
### Notice of Intent Not to File Answering Brief\
\
| NOTICE OF INTENT NOT TO FILE ANSWERING BRIEF |\
| :-: |\
| RESPONDENT HEREBY NOTIFIES the Court of his intention not to file an answering brief in the above-captioned case, for the reason that respondent’s opening brief adequately addresses the relevant factual and legal aspects of this case. |\
\
**Exhibit 35.11.1-122**\
\
### Example of Brief Cover Sheet\
\
|  |\
| --- |\
| UNITED STATES TAX COURT |\
|  |\
| \[NAME\] | )<br> ) |  |\
| Petitioner, | )<br> ) |  |\
| v. |  | )<br> ) | Docket No. \[docket no.\] |\
| COMMISSIONER OF INTERNAL REVENUE, | )<br> ) |  |\
| Respondent. | ) |  |\
|  |\
| **BRIEF FOR RESPONDENT** |\
|  |\
|  | \[NAME\]<br> Chief Counsel<br> Internal Revenue Service |\
\
OF COUNSEL:\
\
\[NAME\]\
\
Division Counsel\
\
\[Division\]\
\
\[NAME\]\
\
Area Counsel\
\
\[Division Area\]\
\
\[NAME\]\
\
Associate Area Counsel\
\
\[Division Area\]\
\
\[NAME of Field counsel\]\
\
Attorney\
\
\[Division Area\]\
\
Internal Revenue Service\
\
\[address\]\
\
\[telephone number\]\
\
**Exhibit 35.11.1-123**\
\
### Joint Motion to Correct Record on Appeal\
\
|  |\
| :-: |\
| **JOINT MOTION TO CORRECT RECORD ON APPEAL** |\
\
THE PARTIES JOINTLY MOVE, pursuant to the provisions of Rule 10(e) of the Federal Rules of Appellate Procedure, that the Court revise the decision in the above-entitled case to reflect that said decision was entered pursuant to the opinion of the Court filed \[date\], in \[Petitioner's name\] v. Commissioner, \[case citation\] and that the supplemental record reflecting the Court's order be certified and transferred to the United States Court of Appeals for the \[Circuit\].\
\
IN SUPPORT THEREOF, the parties respectfully state:\
\
1\. The Court entered a stipulated decision in this case on \[date of decision\], a copy of which is attached hereto and marked Exhibit A.\
\
2\. Prior to entry of this decision, this case was part of a consolidated group of cases, cases that were the subject of the Court's opinion in \[Petitioner's name\] v. Commissioner, \[case citation\] .\
\
3\. Subsequent to the issuance of the Court's opinion, respondent's trial counsel, \[Name of respondent's counsel\], ceased to be involved in the case.\
\
4\. Subsequent to the issuance of the Court's opinion, the petitioners and substitute counsel for the respondent, \[name of respondent's counsel\], conclusively resolved by agreement all issues in this case except those relating to the federal income tax consequences of the transfer of warrants by \[petitioner's name\] to a foreign situs trust and the subsequent sale of the stock acquired as a result of the exercise of the warrants that was the subject of the Court's opinion in \[Petitioner's name\] v. Commissioner, \[case citation\] .\
\
5\. Subsequently, respondent's attorney, \[name of respondent's counsel\], was assigned the responsibility of preparing an appropriate decision document for this case.\
\
6\. \[Name of respondent's counsel\] was not informed that the petitioners intended to appeal any issues in the case and believed all issues had been settled pursuant to an agreement.\
\
7\. \[Name of respondent's counsel\] prepared the stipulated decision that was entered by the Court in this case.\
\
8\. Petitioners' counsel, pursuant to T.C. Rule 190, filed a notice of appeal on \[date\]. A copy of the notice of appeal is attached hereto as Exhibit B.\
\
9\. Petitioners' counsel was not aware that a stipulated decision should only be filed in the event of a fully agreed case. Petitioners' counsel and respondent's counsel were not aware that the parties should have filed a decision pursuant to T.C. Rule 155 in lieu of a stipulated decision, indicating that the issues in this case were settled pursuant to an agreement when in fact there was an agreement only as to some issues.\
\
10\. Revision of the Court's decision is necessary in order for the record on appeal to accurately reflect that the decision on appeal was not a fully agreed decision but a decision pursuant to the opinion of the Court on a contested issue.\
\
WHEREFORE, the parties respectfully request that this motion be granted.\
\
**Exhibit 35.11.1-124**\
\
### Tabular Form of Decision: Several Years\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to agreement of the parties in this case, it is: |\
| ORDERED AND DECIDED: That there are deficiencies in income taxes and additions to the tax due from the petitioner as follows: |\
| Deficiencies | Additions to Tax |\
| Taxable Year<br> 2000<br> 2001<br> 2002 | Income Tax<br> $30,000<br> 500<br> 2,000 | § 6663 (a)<br> $15,000<br> none<br> none | § 6654 (a)<br> none<br> $25<br> none |\
|  |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that interest will be assessed as provided by law on the deficiencies and additions to tax due from petitioner. |\
| It is further stipulated that, effective upon the entry of the decision by the Court, petitioner waives the restriction contained in I.R.C. § 6213(a) prohibiting assessment and collection of the deficiencies and additions to tax (plus statutory interest) until the decision of the Tax Court has become final. |\
\
**Exhibit 35.11.1-125**\
\
### Tabular Form of Decision: Multiple Petitioners\
\
|  |\
| --- |\
| UNITED STATES TAX COURT |\
|  |\
| \[NAME\], and<br> \[NAME 2\], and<br> \[NAME 3\], | )<br> )<br> ) |  |\
| Petitioners, | )<br> ) |  |\
| v. |  | )<br> ) | Docket No. \[number\] |\
| COMMISSIONER OF INTERNAL REVENUE, | )<br> ) |  |\
| Respondent. | ) |  |\
\
| **DECISION** |\
| :-: |\
| Pursuant to agreement of the parties in this case, it is |\
| ORDERED AND DECIDED that there are deficiencies in income taxes due for the years 2000, 2001, and 2002 from the petitioners as shown below: |\
|  | Income Tax Deficiencies |\
| Taxable Year<br> 1999<br> 2000<br> 2001 | \[name\] and<br> \[name 2\] only<br> $2,000.00<br> —<br> — | \[name\] only<br> —<br> $7,000.00<br> — | \[name\] and<br> \[name 3\] only<br> —<br> —<br> $1,000.00 |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that interest will be assessed as provided by law on the deficiencies due from petitioners. |\
| It is further stipulated that, effective upon the entry of this decision by the Court, petitioners waive the restriction contained in I.R.C. § 6213(a), prohibiting assessment of the deficiencies (plus statutory interest) until the decision of the Tax Court has become final. |\
\
**Exhibit 35.11.1-126**\
\
### Paragraph Form of Decision: Tax and Penalty\
\
| **DECISION** |\
| :-: |\
| Pursuant to agreement of the parties in this case, it is |\
| ORDERED and DECIDED: That there are deficiencies in income taxes due from the petitioner for the taxable years \[years\] in the amounts of $ \[amount\] and $ \[amount 2\], respectively; and |\
| That there is no addition to the tax due from the petitioner for the taxable year \[year 1\], under the provisions of I.R.C. § 6651 (a) (1); and |\
| That there is an addition to the tax due from the petitioner for the taxable year \[year 2\], under the provisions of I.R.C. § 6651 (a) (1), in the amount of $ \[amount\]. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that interest will be assessed as provided by law on the deficiencies and additions to tax due from petitioner. |\
| It is further stipulated that, effective upon the entry of the decision by the Court, petitioner waives the restriction contained in I.R.C. § 6213(a) prohibiting assessment and collection of the deficiencies and additions to tax (plus statutory interest) until the decision of the Tax Court has become final. |\
\
**Exhibit 35.11.1-127**\
\
### Claim For Increased Deficiency\
\
| **DECISION** |\
| :-: |\
| Pursuant to agreement of the parties in this case, it is |\
| ORDERED and DECIDED: That there are deficiencies in income taxes due from the petitioner for the taxable years \[year 1\] and \[year 2\] in the amounts of $ \[amount 1\] and $ \[amount 2\], respectively. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that respondent claims an increased deficiencies in income tax for the taxable year \[year 1\] in the amount of $ \[increased amount\], pursuant to the provisions of I.R.C. § 6214(a). |\
| It is further stipulated that interest will be assessed as provided by law on the deficiency(ies) in tax, addition(s) to tax, and penalty(ies) due from petitioner(s) . |\
| It is further stipulated that, effective upon the entry of the decision by the Court, petitioner waives the restriction contained in I.R.C. § 6213(a) prohibiting assessment and collection of the deficiency (plus statutory interest) until the decision of the Tax Court has become final. |\
\
**Exhibit 35.11.1-128**\
\
### Deficiency in Income Tax (Simple Stipulated Decision)\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to agreement of the parties in this case, it is |\
| ORDERED AND DECIDED: That there is a deficiency in income tax due from the petitioner for the taxable year \[year\] in the amount of $ \[amount\]. |\
|  |\
|  | Judge. |\
| Entered: \[date\] |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that interest will be assessed as provided by law on the deficiency(ies) in tax, addition(s) to tax, and penalty(ies) due from petitioner(s). |\
| It is further stipulated that interest will be credited or paid as provided by law on any overpayment in tax due to petitioner(s). |\
| It is further stipulated that, effective upon the entry of this decision by the Court, petitioner waives the restriction contained in I.R.C. § 6213(a) prohibiting assessment and collection of the deficiency (plus statutory interest) until the decision of the Tax Court has become final. |\
|  |\
\
### Note:\
\
The above stipulation paragraphs are common to all stipulated decisions, including settled cases, Rule 155 cases and cases on remand. Unless otherwise documented and acknowledged by petitioner(s), the deficiency interest paragraph should be used in all settled deficiency cases. The overpayment interest paragraph can be included if an overpayment is determined and the inclusion of the paragraph is requested by petitioner(s). The waiver paragraph should be used in all settled deficiency cases unless the petitioner refuses to execute the stipulation and there are good reasons for that refusal. See CCDM 35.8.2.5, Interest Paragraphs in Stipulated Decision Documents\
\
.\
\
**Exhibit 35.11.1-129**\
\
### Overpayment Based on Claim: Return Filed Within Period as Extended\
\
| **STIPULATION** |\
| :-: |\
| It is hereby stipulated that the following statement shows the petitioner's income tax liability for the taxable year \[year\]: |\
| Tax assessed and paid | $ 5,000.00 |  |\
| Payments: |  |  |  |\
| \[date\] | $ 3,000.00 |  |  |\
| \[date\] | $ 1,000.00 |  |  |\
| \[date\] | $ 1,000.00 |  |  |\
| Total payments | $ 5,000.00 |  |  |\
| Tax liability |  | $ 4,0000.00 |  |\
| Overpayment |  | $ 1,0000.00 |  |\
\
I.R.C. §§ 6511(b)(2) and 6512(b)(3)(C)\
\
Return filed, \[date\], pursuant to six-month extension granted for filing the return from \[date\]\
\
Claim filed \[date\]\
\
No agreements executed\
\
Deficiency notice mailed \[date\]\
\
|  |\
| --- |\
|  | \[NAME OF CHIEF COUNSEL\]<br> Chief Counsel<br> Internal Revenue Service |\
| \\_\\_\\_\_\_\_\_\_\_\_\_\_\_\_\_\_<br> Counsel for Petitioner<br> \[Name and address\] | By:\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_<br> \[name\] |\
| Date:\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ | Date:\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |\
|  |  |\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to the stipulation of the parties filed in the above-entitled case, and incorporating herein the facts stipulated by the parties as the findings of the Court, it is |\
| ORDERED and DECIDED: That there is an overpayment in income tax for the taxable year \[date\] in the amount of $1,000.00, which amount was paid on \[date\] , and for which amount a claim for refund was filed on \[date\] , which was within the period provided by I.R.C. § 6511(b)(2), and which claim had not been disallowed before the date of the mailing of the notice of deficiency. |\
|  | Judge. |\
| Entered: |  |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in the above-entitled case in accordance with the stipulation of the parties submitted herewith. |\
|  | \[NAME OF CHIEF COUNSEL\]<br> Chief Counsel<br> Internal Revenue Service |\
| \\_\\_\\_\_\_\_\_\_\_\_\_\_\_\_\_\_<br> Counsel for Petitioner<br> \[Name and address\] | By:\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_<br> \[Name\] |\
| Date:\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ | Date:\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |\
\
**Exhibit 35.11.1-130**\
\
### Overpayment Based on Claim: Different Years and Different Bases for Overpayment\
\
| **STIPULATION** |\
| :-: |\
| It is hereby stipulated that the following statement shows the petitioner's income tax liabilities for the taxable years \[years\]: |\
| **\[year\]** |\
| Net tax assessed and paid |  |  | $ 5,300.00 |\
|  | Payments: |  |  |  |\
|  | \[date\] | $ 400.00 |  |  |\
|  | \[date\] statutory date | $ 2,000.00 |  |  |\
|  | \[date\] | $ 2,200.00 |  |  |\
|  | \[date\] | $ 1,200.00 |  |  |\
|  | Total payments |  | $ 5,800.00 |  |\
|  | Less: Allowance, \[date\] | $ 500.00 |  |  |\
|  | Net payment |  | $ 5,300.00 |  |\
| Tax Liability |  |  | $ 4,000.00 |\
| Overpayment |  |  | $ 1,300.00 |\
\
I.R.C. §§ 6511(b)(2) and 6512(b)(3)(B)\
\
Return filed \[date\]\
\
No claim filed\
\
No agreement executed\
\
Deficiency notice mailed \[date\]\
\
| **\[year 2\]** |\
| :-: |\
| Tax assessed and paid |  |  | $ 6,000.00 |\
|  | Payments: |  |  |  |\
|  | \[date\] | $ 1,200.00 |  |  |\
|  | \[date\] | $ 1,200.00 |  |  |\
|  | \[date\] | $ 1,200.00 |  |  |\
|  | \[date\] | $ 1,200.00 |  |  |\
|  | \[date\] | $ 1,200.00 |  |  |\
|  | Total payments |  | $ 6,000.00 |  |\
| Tax Liability |  |  | $ 5,200.00 |\
| Overpayment |  |  | $ 800.00 |\
\
I.R.C. §§ 6512(b)(3)(A)\
\
Return filed \[date\]\
\
No claim filed\
\
No agreement executed\
\
Deficiency notice mailed \[date\]\
\
| **DECISION** |\
| :-: |\
| Pursuant to the stipulation of the parties filed in the above-entitled case, and incorporating herein the facts stipulated by the parties as the findings of the Court, it is |\
| ORDERED and DECIDED: That there is an overpayment in income tax for the taxable year \[year\] in the amount of $1,300.00, which amount was paid: $100.00 on \[date\], and $1,200.00 on \[date\]; and for which amount a claim for refund could have been filed, under the provisions of I.R.C. § 6511(c), on \[date\], the date of the mailing of the notice of deficiency; |\
| That there is an overpayment in income tax for the taxable year \[year\] in the amount of $800.00, which amount was paid after the mailing of the notice of deficiency. |\
|  | Judge. |\
| Entered: |  |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in the above-entitled case in accordance with the stipulation of the parties submitted herewith. |\
\
**Exhibit 35.11.1-131**\
\
### Overpayment Based on Claim: Same Year and Different Bases of Overpayment\
\
| **STIPULATION** |\
| :-: |\
| It is hereby stipulated that the following statement shows the petitioner’s income tax liability for the taxable year \[year\] : |\
| **\[year\]** |\
| Tax assessed and paid |  |  | $ 175,000.00 |\
|  | Payments: |  |  |  |\
|  | \[date\] | $ 50,000.00 |  |  |\
|  | \[date\] | $ 25,000.00 |  |  |\
|  | \[date\] | $ 25,000.00 |  |  |\
|  | \[date\] | $ 75,000.00 |  |  |\
|  | Total payments |  | $ 175,000.00 |  |\
| Tax Liability |  |  | $ 70,000.00 |\
| Overpayment |  |  | $ 105,000.00 |\
\
I.R.C. §§ 6511(b)(2) and 6512(b)(3)(A), (B) & (C)\
\
Return filed \[date\]\
\
Claim filed \[date\]\
\
No agreements executed\
\
Deficiency notice mailed \[date\]\
\
| **DECISION** |\
| :-: |\
| Pursuant to the stipulation of the parties filed in the above-entitled case, and incorporating herein the facts stipulated by the parties as the findings of the Court, it is |\
| ORDERED and DECIDED: That there is an overpayment in income tax for the taxable year \[year\] in the amount of $105,000, of which amount $75,000 was paid after the mailing of the notice of deficiency; $25,000 was paid on \[date\] for which amount claim for refund was filed on \[date\], which was within the period provided by I.R.C. § 6511(b) (2), and which claim had not been disallowed before the date of the mailing of the notice of deficiency; and $5,000 was paid on \[date\], for which amount a claim for refund could have been filed, under the provisions of I.R.C. § 6511(b)(2), on \[date\], the date of the mailing of the notice of deficiency. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in the above-entitled case in accordance with the stipulation of the parties submitted herewith. |\
\
**Exhibit 35.11.1-132**\
\
### Overpayment Based on Claim: Jeopardy Assessment — Tax and Penalty\
\
| **STIPULATION** |\
| :-: |\
| It is hereby stipulated that the following statement shows the petitioner’s income tax liability for the taxable year \[year\]: |\
| Net tax assessed and paid |  |  | $ 7,500.00 |\
|  | Payments: |  |  |  |\
|  | \[date\] | $ 150.00 |  |  |\
|  | \[date\] | $ 400.00 |  |  |\
|  | \[date\] (jeopardy assessment | $ 7,000.00 |  |  |\
|  | Total payments |  | $ 7,550.00 |  |\
|  | Less: Allowance, \[date\] | $ 50.00 |  |  |\
|  | Net payment |  | $ 7,500.00 |  |\
| Tax liability |  |  | $ 6,500.00 |\
| Overpayment |  |  | $ 1,000.00 |\
| It is further stipulated that the following statement shows the petitioner’s liability for addition to the tax under I.R.C. § 6662(d) for the taxable year \[year\]: |\
| Addition to tax paid, \[date\] (jeopardy assessment) |  | $ 3,500.00 |  |\
| Liability for addition to the tax |  |  | $ 3,000.00 |\
| Overpayment |  |  | $ 500.00 |\
\
I.R.C. § 6512(b)(3)(A)\
\
Return filed \[date\]\
\
No claim filed\
\
No agreements executed\
\
Deficiency notice mailed \[date\]\
\
| **DECISION** |\
| :-: |\
| Pursuant to the stipulation of the parties filed in the above-entitled case, and incorporating herein the facts stipulated by the parties as the findings of the Court, it is |\
| ORDERED AND DECIDED: That there is an overpayment in income tax for the taxable year \[year\] in the amount of $1,000.00, and an overpayment in addition to the tax under the provisions of I.R.C. § 6662(d) in the amount of $500.00, both of which amounts were paid after the mailing of the notice of deficiency. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in the above-entitled case in accordance with the stipulation of the parties submitted herewith. |\
\
**Exhibit 35.11.1-133**\
\
### Overpayment Based on Claim: Gift Tax\
\
| **STIPULATION** |\
| :-: |\
| It is hereby stipulated that the following statement shows the petitioner’s gift tax liability for the calendar year \[year\]: |\
|  | Tax assessed and paid, \[date\] | $ 5,000.00 |\
|  | Tax liability | $ 4,500.00 |\
|  | Overpayment | $ 500.00 |\
| I.R.C. §§ 6511(b)(2) and 6512(b)(3)(B)<br> Return filed \[date\]<br> No claim filed<br> Deficiency notice mailed \[date\] |\
| **DECISION** |\
| Pursuant to the stipulation of the parties filed in the above-entitled case, and incorporating herein the facts stipulated by the parties as the findings of the Court, it is |\
| ORDERED and DECIDED: That there is an overpayment in gift tax for the calendar year \[year\] in the amount of $500.00, which amount was paid on \[date\], and for which amount a claim for refund could have been filed, under the provisions of I.R.C. § 6511(b)(2), on \[date\], the date of the mailing of the notice of deficiency. |\
|  |  | Judge. |\
| Entered: |  |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in accordance with the stipulation of the parties submitted herewith. |\
\
**Exhibit 35.11.1-134**\
\
### Overpayment Based on Claim: Estate Tax\
\
| **STIPULATION** |\
| :-: |\
| It is hereby stipulated that the following statement shows the petitioner’s estate tax liability: |\
| Tax assessed and paid |  |  | $ 20,000.00 |\
|  | Payments: |  |  |  |\
|  | \[date\] | $ 500.00 |  |  |\
|  | \[date\] | $ 20,000.00 |  |  |\
|  | Total payments |  | $ 20,500.00 |  |\
| Tax liability |  |  | $ 20,000.00 |\
| Overpayment |  |  | $ 500.00 |\
\
I.R.C. §§ 6511(b)(2) and 6512(b)(3)(B)\
\
Return filed \[date\]\
\
No claim filed.\
\
Deficiency notice mailed \[date\]\
\
It is further stipulated that the petitioner may claim credit for State estate, inheritance, legacy, or succession taxes, and may present to the Internal Revenue Service proof of such payment within the statutory period.\
\
| **DECISION** |\
| :-: |\
| Pursuant to the stipulation of the parties filed in the above-entitled case, and incorporating herein the facts stipulated by the parties as the findings of the Court, it is |\
| ORDERED and DECIDED: That there is an overpayment in estate tax in the amount of $500.00, which amount was paid on \[date\], and for which amount a claim for refund could have been filed, under the provisions of I.R.C. § 6511(b) (2), on \[date\], the date of the mailing of the notice of deficiency. |\
|  | Judge. |\
| Entered: |  |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in the above entitled case in accordance with the stipulation of the parties submitted herewith. |\
\
**Exhibit 35.11.1-135**\
\
### Overpayment Due to Credit for State Inheritance Taxes: Refund Suit or Claim\
\
| **STIPULATION** |\
| :-: |\
| It is hereby stipulated that the following statement shows the petitioner’s net estate tax liability: |\
| Tax assessed and paid |  |  | $ 1,000.000.00 |\
|  | Payments: |  |  |  |\
|  | \[date\] | $ 100,000.00 |  |  |\
|  | \[date\] | $ 1,000,000.00 |  |  |\
|  | Total payments |  | $ 1,100,000.00 |  |\
| Net tax liability (after credit for state inheritance taxes) | $ 1,005,000.00 |\
| Overpayment (by reason of credit for state inheritance taxes) | $ 95,000.00 |\
\
I.R.C. §§ 2011(c), 6511(b)(2), 6512(b)(3)(C), and 6532\
\
Return filed \[date\]\
\
Claim filed \[date\]\
\
Suit for refund commenced \[date\]\
\
Deficiency notice mailed \[date\]\
\
Petition filed \[date\]\
\
| **DECISION** |\
| :-: |\
| Pursuant to the stipulation of the parties filed in the above-entitled case, and incorporating herein the facts stipulated by the parties as the findings of the Court, it is |\
| ORDERED and DECIDED: That there is an overpayment in estate tax in the amount of $95,000.00 which amount was paid on \[date\], and for which amount a claim for refund was filed \[date\], which was within the period provided by I.R.C. § 6511(b) (2), and in respect of which claim a suit for refund had been commenced before the mailing of the notice of deficiency and within the period specified in I.R.C. § 6532, and which amount includes credit for State inheritance taxes, claim for which was filed within the period provided by I.R.C. § 2011(c). |\
|  | Judge. |\
| Entered: |  |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in the above-entitled case in accordance with the stipulation of the parties submitted herewith. |\
\
**Exhibit 35.11.1-136**\
\
### Overpayment by Transferee\
\
| **STIPULATION** |\
| :-: |\
| It is hereby stipulated that the following statement shows the petitioner’s liability as transferee of assets of \[name and location\], transferor, with respect to the income tax liability of the transferor for the taxable year \[year\]: |\
| Transferee tax assessed against, and paid by petitioner | $ 1,200.00 |\
|  | Payments: |  |  |  |\
|  | \[date\] | $ 600.00 |  |  |\
|  | \[date\] | $ 600.00 |  |  |\
| Total payments | Total payments |  | $ 1,200.00 |  |\
| Tax liability of transferor |  | $ 1,000.00 |\
| Overpayment due petitioner as transferee |  | $ 200.00 |\
| I.R.C. § 6512(b)(3)(A)<br> No claim filed<br> Liability notice mailed \[date\] |\
| It is further stipulated that the following statement shows the petitioner’s liability for interest as provided by law as transferee of assets of \[name and location\], transferor, with respect to the income tax liability of the transferor for the taxable year \[year\]: |\
\
|  |\
| --- |\
| Transferee interest assessed against, and paid by petitioner |\
| Payments: |  |  |\
|  | \[date\] | $ 60.00 |  |\
|  | \[date\] | $ 30.00 |  |\
| Total payments |  | $ 90.00 |\
| Liability for interest as transferee | $ 70.00 |\
| Overpayment |  | $ 20.00 |\
\
I.R.C. § 6512(b)(3)(A)\
\
No claim filed\
\
Liability notice mailed \[date\]\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to the stipulation of the parties filed in the above-entitled case, and incorporating herein the facts stipulated by the parties as the findings of the Court, it is |\
| ORDERED and DECIDED: That there is an overpayment of transferee liability in the amount of $200.00 and an overpayment of transferee interest in the amount of $20.00, both of which amounts were paid after the mailing of the notice of liability, and which amounts are with respect to the income tax liability of the petitioner as transferee of \[name and location\], transferor, for the taxable year \[year\] |\
|  | Judge. |\
| Entered: |  |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in the above-entitled cases in accordance with the stipulation of the parties submitted herewith. |\
\
**Exhibit 35.11.1-137**\
\
### Overpayment from Estimated Tax Payments or Tax Withheld: Return as a Claim — Deficiency and Overpayment for Same Year\
\
| **STIPULATION** |\
| :-: |\
| It is hereby stipulated that the following statement shows the petitioner’s income tax liabilities for the taxable years \[year 1\] and \[year 2\]: |\
| **\[year 1\]** |\
|  | Tax paid |  | $ 1,000.00 |\
|  | Payments: |  |  |\
|  |  | \[statutory date\] | $ 1,000.00 |  |\
|  |  | \[date\] | 300.00 |  |\
|  | Total payments | $ 1,300.00 |  |\
|  | Tax liability |  | $ 1,000.00 |\
|  | Overpayment |  | $ 300.00 |\
\
I.R.C. §§ 6512(b)(3)(A) and 6511(b)(2)\
\
Return filed \[date\]\
\
No claim filed\
\
No agreements executed\
\
Deficiency notice mailed \[date\]\
\
| **\[year 2\]** |\
| :-: |\
|  | Tax liability | $ 5,000.00 |\
|  | Tax liability reported on return | 4,500.00 |\
|  | Statutory deficiency | $ 500.00 |\
|  | Tax paid, \[statutory date\] | $ 6,000.00 |\
|  | Tax liability | 5,000.00 |\
|  | Overpayment | $ 1,000.00 |\
\
I.R.C. §§ 6512(b)(3)(C) and 6511(b)(2),\
\
Return filed \[date\]\
\
Claim (in return) filed \[date\] (statutory date)\
\
No agreements executed\
\
Deficiency notice mailed \[date\]\
\
It is further stipulated that, effective upon the entry of the Court’s decision, petitioner waives the restrictions, if any, contained in I.R.C. § 6213(a) on the assessment and collection of the deficiency, plus statutory interest.\
\
It is further stipulated that interest will be assessed as provided by law on the deficiency(ies) in tax, addition(s) to tax, and penalty(ies) due from petitioner(s).\
\
| **DECISION** |\
| :-: |\
| Pursuant to the stipulation of the parties filed in the above-entitled case, and incorporating herein the facts stipulated by the parties as the findings of the Court, it is |\
| ORDERED and DECIDED: That there is an overpayment in income tax for the taxable year \[year 1\] in the amount of $ \[amount\], which amount was paid within three years before the mailing of the notice of deficiency, and which notice of deficiency was mailed within three years from the date of the filing of the return; and |\
| That there is a statutory deficiency in income tax due from the petitioner for the taxable year \[year 2\], in the amount of $ \[amount 2\], and that there is an overpayment in income tax for the taxable year \[year 3\] in the amount of $\[amount 3\], which amount was paid on \[date\], and for which amount claim for refund was filed on \[date\], which was within the period provided by I.R.C. § 6511(b) (2), and which claim had not been disallowed before the date of the mailing of the notice of deficiency. |\
|  | Judge. |\
| Entered: |  |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in the above-entitled case in accordance with the stipulation of the parties submitted herewith. |\
\
**Exhibit 35.11.1-138**\
\
### Overpayment Resulting From Application of Earned Income Tax Credit: Previous Assessment\
\
| **STIPULATION** |\
| :-: |\
| It is hereby stipulated that the following statement shows the petitioner’s income tax liability for the taxable year \[year\]: |\
|  | Payments: |  |\
|  | \[date\] (earned income credit) | $ 2,300.00 |\
|  | Tax liability (previously assessed) | $ 1,500.00 |\
|  | Deficiency to be assessed: | -0- |\
|  | Overpayment | $ 800.00 |\
\
I.R.C. §§ 6512 (b)(3)(C) and 6511(b)(2)\
\
Return filed \[date\]\
\
Claim (in return) filed \[date\]\
\
Deficiency notice mailed \[date\]\
\
| **DECISION** |\
| :-: |\
| Pursuant to the stipulation of the parties in this case, and incorporating herein the facts stipulated by the parties as the findings of the Court, it is |\
| ORDERED AND DECIDED: |\
| That there is no deficiency in income tax due from the petitioner for the taxable year \[year\]; and |\
| That there is an overpayment due to the petitioner for the taxable year \[year\] in the amount of $ \[amount\], which amount was paid on \[date\], and for which a claim was filed on \[date 2\], which was within the period provided under I.R.C. § 6511(b) (2), and which claim was not disallowed before the mailing of the notice of deficiency. |\
|  | Judge. |\
| Entered: |  |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in accordance with the stipulation of the parties submitted herewith. |\
\
**Exhibit 35.11.1-139**\
\
### Overpayment From Application of EITC Plus Withholding\
\
| **STIPULATION** |\
| :-: |\
| It is hereby stipulated that the following statement shows the petitioner’s income tax liability for the taxable year \[year\]: |\
|  | Payments: |  |\
|  |  | \[date\] (earned income credit) | $ 3,000.00 |\
|  |  | \[date\] (withholding) | 100.00 |\
|  | Total payments: | $ 3,100.00 |\
|  | Tax liability (previously assessed) | -0- |\
|  | Deficiency to be assessed: | -0- |\
|  | Overpayment | $ 3,100.00 |\
\
I.R.C. §§ 6512 (b)(3)(C) and 6511(b)(2)\
\
Return filed \[date\]\
\
Claim (in return) filed \[date\]\
\
Deficiency notice mailed \[date\]\
\
| **DECISION** |\
| :-: |\
| Pursuant to the stipulation of the parties in this case, and incorporating herein the facts stipulated by the parties as the findings of the Court, it is |\
| ORDERED AND DECIDED: |\
| That there is no deficiency in income tax due from the petitioner for the taxable year \[year\]; and |\
| That there is an overpayment due to the petitioner for the taxable year \[year\] in the amount of $ \[amount\], which amount was paid on \[date\], and for which a claim was filed on \[date\], which was within the period provided under I.R.C. § 6511(b) (2), and which claim was not disallowed before the mailing of the notice of deficiency. |\
|  | Judge. |\
| Entered: |  |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in accordance with the stipulation of the parties submitted herewith. |\
\
**Exhibit 35.11.1-140**\
\
### Undisputed Overpayment Refunded Pending Appeal Under RRA § 3463 (lRC §§ 651 2(b)(1), 6213(a))\
\
| **STIPULATION** |\
| :-: |\
| It is hereby stipulated that the following statement shows the petitioner’s income tax liability for the taxable year \[year\]: |\
|  | Net income tax assessed: |  | $ 12,000.00 |\
|  | Payment: |  |  |\
|  |  | \[date\] | $ 12,000.00 |  |\
|  | Income tax liability: |  | $ 16,000.00 |\
|  | Deficiency in income tax: |  | (4,000.00) |\
|  | Negligence penalty assessed: |  | 3,000.00 |\
|  | Payment: |  |  |\
|  |  | \[date\] | 3,000.00 |  |\
|  | Liability for negligence penalty: |  | 0.00 |\
|  | Overpayment of negligence penalty: |  | $ 3,000.00 |\
| It is further stipulated that the overpayment of the negligence penalty was not disputed during the appeal of this case and was refunded to the petitioner on \[date\], pursuant to I.R.C. § 6512(b)(1). |\
\
| **DECISION** |\
| :-: |\
| Pursuant to the stipulation of the parties filed in the above-entitled case, and incorporating herein the facts stipulated by the parties as the findings of the Court, it is |\
| ORDERED and DECIDED: That for the taxable year \[year\] there is a deficiency in income tax in the amount of $ \[amount\] and an overpayment for the negligence penalty in the amount of $ \[amount 1\] |\
|  | Judge. |\
| Entered |  |\
| \\* \\* \\* \* \* |\
\
**Exhibit 35.11.1-141**\
\
### Interim Assessments: No Deficiency to Be Assessed or to Be Paid\
\
| **DECISION** |\
| :-: |\
| Pursuant to agreement of the parties in this case, it is |\
| ORDERED and DECIDED: That the deficiencies in income taxes for the taxable years \[year 1\] and \[year 2\] in the amounts of $ \[amount\] and $ \[amount 2\], respectively, have been assessed and paid since the mailing of the notice of deficiency; and |\
| That there are now no deficiencies in income taxes due from the petitioner for the taxable years \[year 1\] and \[year 2\] . |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. |\
\
**Exhibit 35.11.1-142**\
\
### Interim Assessments: Deficiency to Be Assessed or to Be Paid\
\
| **DECISION** |\
| :-: |\
| Pursuant to agreement of the parties in this case, it is |\
| ORDERED and DECIDED: That the following statement shows the petitioner’s income tax liabilities for the taxable years \[year 1\] and \[year 2\]: |\
| **\[year 1\]** |\
| Deficiency, without taking into consideration the assessment subsequent to the mailing of the deficiency notice on \[date\]: |  |  | $ 10,000.00 |\
| Assessment, \[date\]: | Paid<br> Not paid | $ 5,000.00<br>3,750.00 | 8,750.00 |\
| Deficiency (to be assessed): |  |  | $ 1,250.00 |\
| **\[year 2\]** |\
| Deficiency, without taking into consideration the assessment subsequent to the mailing of the deficiency notice on \[date\]: |  |  | $ 3,450.00 |\
| Assessment, \[date\] (paid) |  |  | 3,450.00 |\
| Deficiency (to be assessed) |  |  | None |\
|  |\
|  | Judge. |\
| Entered: |  |  |  |\
| \\* \\* \\* \* \* |\
| It is further stipulated that, effective upon the entry of this decision by the Court, petitioner waives the restriction contained in I.R.C. § 6213(a) prohibiting assessment and collection of the deficiency and unpaid prior assessment (plus statutory interest) until the decision of the Tax Court has become final. |\
|  |  |  |  |\
| **_Note:_**See Exhibit 35.11.1-148 and Exhibit 35.11.1-149 with respect to jeopardy assessments and the notes thereon, particularly if there is any question as to the amount of the subsequent assessment or whether such assessment has been paid; also for use of jeopardy assessment forms, with modifications, for interim assessment cases. |\
\
**Exhibit 35.11.1-143**\
\
### Interim Payment: Deficiency to Be Assessed\
\
| **DECISION** |\
| :-: |\
| Pursuant to agreement of the parties in this case, it is |\
| ORDERED AND DECIDED: That the following statement shows the petitioner’s income tax liabilities for the taxable years \[year 1\] and \[year 2\]: |\
| **\[year 1\]** |\
| Tax liability | $ 11,450.00 |\
| Tax assessed and paid \[date\]: | 7,450.00 |\
| Deficiency to be assessed: | $ 4,000.00 |\
| Tax paid \[date\] (paid after mailing of statutory notice, but not assessed) | 4,000.00 |\
| Unpaid deficiency | None |\
| **\[year 2\]** |\
| Tax liability | $ 4,600.00 |\
| Tax assessed and paid \[date\]: | 1,000.00 |\
| Deficiency to be assessed: | $ 3,600.00 |\
| Tax paid \[date\] (paid after mailing of statutory notice, but not assessed) | 2,000.00 |\
| Unpaid deficiency: | $ 1,600.00 |\
|  |  |\
|  | Judge. |\
| Entered: |  |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. It is further stipulated that, effective upon entry of this decision by the Court, petitioner waives the restriction contained in I.R.C. § 6213(a) prohibiting assessment and collection of the deficiency (plus statutory interest) until the decision has become final. |\
\
**Exhibit 35.11.1-144**\
\
### Advance Payment: Fully Paid — Unassessed Payment\
\
| **DECISION** |\
| :-: |\
| Pursuant to agreement of the parties in this case, it is |\
| ORDERED and DECIDED: That there is a deficiency in income tax due from the petitioners for the taxable year \[year\] in the amount of $ \[amount\] . |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that petitioners made an advance payment of tax on the determined deficiency for the taxable year \[year\] in the amount of $ \[amount\] on \[date\]. |\
| It is further stipulated that effective upon the entry of this decision by the Court, petitioner waives the restriction contained in I.R.C. § 6213(a) prohibiting assessment and collection of the deficiency (plus statutory interest) until the decision of the Tax Court has become final. |\
\
**Exhibit 35.11.1-145**\
\
### Unassessed Payments\
\
| **STIPULATION** |\
| :-: |\
| It is hereby stipulated that the following statement shows the petitioner’s income tax liability for the taxable year \[year\]: |\
|  | Tax liability | $ 145,000.00 |\
|  | Tax assessed and paid: |  |\
|  |  | \[date\] | 100,000.00 |\
|  | Deficiency (to be assessed) | $ 45,000.00 |\
|  | Tax paid, \[date\] (paid after mailing of statutory notice, but not assessed) | $ 50,000.00 |\
|  | Overpayment | $ 5,000.00 |\
\
I.R.C. §§ 6512(b)(3)(A) and 6511(b)(2)\
\
Return filed \[date\]\
\
No claim filed\
\
No agreements executed\
\
Deficiency notice mailed \[date\]\
\
| **DECISION** |\
| :-: |\
| Pursuant to the stipulation of the parties filed in the above-entitled case, and incorporating herein the facts stipulated by the parties as the findings of the Court, it is |\
| ORDERED and DECIDED: That there is a deficiency in income tax for the taxable year \[year\] in the amount of $ \[amount\], which amount was paid after the mailing of the notice of deficiency and an overpayment for the year \[year\] in the amount of $ \[amount 2\]. |\
|  | Judge. |\
| Entered: |  |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in the above-entitled case in accordance with the stipulation of the parties submitted herewith. |\
| It is further stipulated that, effective upon the entry of the decision by the Court, petitioner waives the restriction contained in I.R.C. § 6213(a) prohibiting assessment of the deficiency (plus statutory interest) until the decision of the Tax Court has become final. |\
\
**Exhibit 35.11.1-146**\
\
### Jeopardy Assessments: Paragraph Form of Decision\
\
| **DECISION** |\
| :-: |\
| Pursuant to agreement of the parties in this case, it is |\
| ORDERED and DECIDED: That there are deficiencies in income taxes due from the petitioner for the taxable years \[year 1\] and \[year 2\] in the amounts of $ \[amount 1\] and $ \[amount 2\], respectively, without taking into consideration the jeopardy assessment made on \[date\]; |\
| That there is no addition to the tax due from the petitioner for the taxable year \[year 1\], under the provisions of I.R.C. § 6663(a), without taking into consideration the jeopardy assessment made on \[date\]; and |\
| That there is an addition to the tax due from the petitioner for the taxable year \[year 2\], under the provisions of I.R.C. § 6663(a) in the amount of $ \[amount\], without taking into consideration the jeopardy assessment made on \[date\]. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that, effective upon the entry of this decision by the Court, petitioner waives the restriction contained in I.R.C. § 6213(a) prohibiting collection of the deficiencies in taxes, additions to the tax, and unpaid prior assessment (plus statutory interest) until the decision of the Tax Court has become final. |\
\
\\_\\_\\_\_\_\_\
\
### Note:\
\
No waiver of assessment is necessary because tax and penalty have already been jeopardy assessed.\
\
**Exhibit 35.11.1-147**\
\
### Jeopardy Assessments: Tabular Form of Decision\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to agreement of the parties in this case, it is |\
| ORDERED AND DECIDED: That the following statement shows the deficiencies in income taxes and additions to the tax due from the petitioner for the taxable years \[year 1\] to \[year 2\] , inclusive, without taking into consideration the jeopardy assessments made on \[dates\]: |\
| Year<br> 2000<br> 2001<br> 2002 | Deficiency<br> Income Tax <br> $ 8,000.00<br> $ 22,000.00<br> $ 3,000.00 | Additions to Tax<br> I.R.C. § 6663 (a)<br> $ 4,000.00<br> $ 11,000.00<br> None |  |\
|  |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is further stipulated that, effective upon the entry of this decision by the Court, petitioner waives the restriction contained in I.R.C. § 6213(a) prohibiting collection of the deficiencies in taxes, additions to the tax, and unpaid prior assessment (plus statutory interest) until the decision of the Tax Court has become final. |\
\
**Exhibit 35.11.1-148**\
\
### Jeopardy Assessments: Additional Deficiency to Be Assessed\
\
| **DECISION** |\
| :-: |\
| Pursuant to agreement of the parties in this case, it is |\
| ORDERED and DECIDED: That the following statement shows the deficiency in income tax and penalty due from the petitioner for the taxable year \[year\]: |\
| \[year\] |\
|  | Deficiency in income tax, without taking into consideration the jeopardy assessment made prior to the mailing of the deficiency notice on \[date\]: $100,000.00 |  | $ 100,000.00 |\
|  | Assessment (jeopardy), \[date\] (paid): |  | 90,000.00 |\
|  | Deficiency (to be assessed): |  | $ 10,000.00 |\
|  | Addition to the tax, I.R.C. § 6663(a), without taking into consideration jeopardy assessment made prior to the mailing of the deficiency notice of \[date\]: |  | $ 45,000.00 |\
|  | Assessment (jeopardy), \[date\]: |  |  |\
|  |  | Paid \[date\]<br> Unpaid | $ 20,000.00<br> 20,000.00 |  | $ 40,000.00 |\
|  | Penalty (to be assessed) |  | $ 5,000.00 |  |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that, effective upon the entry of the decision by the Court, petitioner waives the restriction contained in I.R.C. § 6213(a) prohibiting assessment and collection of the deficiency in tax, penalty, and unpaid prior assessment of tax (plus statutory interest) until the decision of the Tax Court has become final |\
\
**Exhibit 35.11.1-149**\
\
### Jeopardy Assessments: Partial Payment — Excessive Assessment (Paragraph Form)\
\
| **DECISION** |\
| :-: |\
| Pursuant to agreement of the parties in this case, it is |\
| ORDERED and DECIDED: That there is a deficiency in income tax due from the petitioner for the taxable year \[year 1\] in the amount of $ \[amount 1\], without taking into consideration the jeopardy assessment subsequent to the mailing of the deficiency notice on \[date\]; and |\
| That there is a deficiency in income tax due from the petitioner for the taxable year \[year 2\] in the amount of $\[amount 2\], without taking into consideration the jeopardy assessment subsequent to the mailing of the deficiency notice on \[date\], of which amount $ \[amount\] was paid \[date\]. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that, effective upon the entry of this decision by the Court, petitioner waives the restriction contained in I.R.C. § 6213(a) prohibiting assessment and collection of the deficiencies and unpaid prior assessment (plus statutory interest) until the decision of the Tax Court has become final. |\
\
**Exhibit 35.11.1-150**\
\
### Jeopardy Assessments: Partial Payment — Excessive Assessment (Tabular Form)\
\
| **DECISION** |\
| :-: |\
| Pursuant to agreement of the parties in this case, it is |\
| ORDERED and DECIDED: That the following statement shows the petitioner’s income tax liabilities for the taxable years \[year 1\] and \[year 2\]: |\
| \[year 1\] |\
|  | Deficiency, without taking into consideration the jeopardy assessment subsequent to the mailing of the deficiency notice on \[date\] | $ 8,000.00 |  |\
| \[year 2\] |\
|  | Deficiency, without taking into consideration the jeopardy assessment subsequent to the mailing of the deficiency notice on \[date\] | $ 4,500.00 |  |\
|  | Paid, \[date\] |  | 3,000.00 |\
|  | Deficiency (to be paid) |  | $ 1,500.00 |\
|  |  | Judge. |  |\
| Entered: |  |  |  |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that, effective upon the entry of this decision by the Court, petitioner waives the restriction contained in I.R.C. § 6213(a) prohibiting assessment and collection of the deficiencies and unpaid prior assessment (plus statutory interest) until the decision of the Tax Court has become final. |\
|  |  |  |\
| **_Note:_**This form illustrates cases in which the jeopardy assessment was made after the mailing of the statutory notice.<br> It is preferable to use the form for the first year in the foregoing example, even though part of the subsequent assessment has been paid. However, if the petitioner insists upon the decision indicating the amount of payment, the example for the second year may be used.<br> For cases in which the amount of the assessed jeopardy is in excess of the stipulated deficiency, the excess assessment is not reflected in either the stipulation or decision portions of the document. The petitioner is furnished a copy of the computation statement which shows the assessment to be abated. For partial payment cases it is preferable to use Exhibit 35.11.1-141, 142, 144, or 145.<br>_See_ Exhibit 35.11.1-141 with respect to interim assessments. This form may also be used for interim (termination) assessment cases by substituting the word "interim" for the word "jeopardy" before the word "assessment." |\
\
**Exhibit 35.11.1-151**\
\
### Prior Unpaid Assessments\
\
| **DECISION** |\
| :-: |\
| Pursuant to agreement of the parties in this case, it is |\
| ORDERED and DECIDED: That the following statement shows the petitioner’s income tax liability for the taxable year \[year\]: |\
|  | Tax liability |  |  | $ 40,000.00 |\
|  | Tax assessed: | Paid<br> Not Paid | $ 10,000.00<br> $ 20,000.00 | $ 30,000.00 |\
| Deficiency (to be assessed) |  |  | $ 10,000.00 |\
|  |  |  | Judge. |\
| Entered: |  |  |  |  |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that, effective upon the entry of this decision by the Court, petitioner waives the restriction contained in I.R.C. § 6213(a) prohibiting assessment and collection of the deficiency and unpaid prior assessment (plus statutory interest) until the decision of the Tax Court has become final. |\
\
**Exhibit 35.11.1-152**\
\
### Duplication of Liability Due From Transferor and/or Several Transferees\
\
| **DECISION** |\
| :-: |\
| Pursuant to agreement of the parties in this case, it is |\
| ORDERED and DECIDED: That there is a liability of $ \[amount\], plus interest thereon as provided by law from \[date\], to the date such liability is paid, due from the petitioner as transferee of assets of the \[name and location of entity\], transferor, for unpaid income tax of the transferor for the taxable year ended \[year\]. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that the aforesaid liability, plus interest as provided by law, is a duplication of the deficiency set forth in the case of the \[name and location of entity\], transferor, Docket No. \[docket no.\], in which case a stipulation of deficiency is concurrently being filed with the United States Tax Court. |\
| It is further stipulated that the aforesaid liability, plus interest as provided by law, is a duplication of the liability set forth in the case of \[name\], \[city, state\], transferee, Docket No. \[docket no.\], in which case a stipulation of liability is concurrently being filed with the United States Tax Court. |\
| It is further stipulated that the payment of the entire amount of the liability of the transferor in the amount of $ \[amount\], plus interest as provided by law, by anyone or a combination of the petitioners liable therefore, will discharge the instant petitioner from liability. |\
| It is further stipulated that, effective upon the entry of the decision by the Court, petitioner waives the restriction contained in I.R.C. § 6213(a) prohibiting assessment and collection of the liability (plus statutory interest) until the decision of the Tax Court has become final. |\
\
**Exhibit 35.11.1-153**\
\
### No Transferee Liability: By Reason of Payment\
\
| **DECISION** |\
| :-: |\
| Pursuant to agreement of the parties in this case, it is |\
| ORDERED and DECIDED: That the deficiency in estate tax, plus interest thereon as provided by law, due from the Estate of \[name\], Deceased, \[city, state\], transferor, has been assessed and paid; and |\
| That there is now no liability due from the petitioner for estate tax and interest as transferee and fiduciary of assets of the Estate of \[name\], Deceased, the aforesaid transferor. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in the above-entitled case. |\
| \\_\\_\\_\_\_\_ |\
| ### Note:<br>In this form there is no transferee liability because the transferor's liability for original or deficiency tax has been paid by the transferor or another transferee after the issuance of the statutory notice. If the transferee liability was paid before settlement by the transferee whose case is being stipulated, use the interim assessment forms with appropriate modification. |\
\
**Exhibit 35.11.1-154**\
\
### No Transferee Liability: Transferee of a Transferee\
\
| **DECISION** |\
| :-: |\
| Pursuant to agreement of the parties in this case, it is |\
| ORDERED and DECIDED: That there is no liability due from the petitioner, as successive transferee of assets of \[name of company\], \[city, state\], transferee of assets of \[name of company 2\], \[city, state\], transferor, for income taxes of the transferor for the taxable years \[year 1\] and \[year 2\] . |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. |\
| \\_\\_\\_\_\_\_ |\
| ### Note:<br>This form illustrates two points: Transferee of a transferee and no transferee liability. For the latter point it is determined that the petitioner is not a transferee of the alleged transferor or that the transferor owed no unpaid tax. Thus, there was no liability due from the transferee at any time. |\
\
**Exhibit 35.11.1-155**\
\
### Unlimited Transferee Liability: Single Tax — One Year\
\
| **DECISION** |\
| :-: |\
| Pursuant to agreement of the parties in this case, it is |\
| ORDERED and DECIDED: That there is a liability in the amount of $ \[amount\] plus interest thereon as provided by law from \[date\], to the date such liability is paid, due from the petitioner as transferee and fiduciary of assets of the Estate of \[name\], \[city, state\], transferor, for unpaid income tax of the transferor for the taxable year \[year\]. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that, effective upon the entry of the decision by the Court, petitioner waives the restriction contained in I.R.C. § 6213(a) prohibiting assessment and collection of the liability (plus statutory interest) until the decision of the Tax Court has become final. |\
\
**Exhibit 35.11.1-156**\
\
### Unlimited Transferee Liability: Single Tax for Several Years\
\
| **DECISION** |\
| :-: |\
| Pursuant to agreement of the parties in this case, it is |\
| ORDERED and DECIDED: That there are liabilities in the amounts of \[amount\] and \[amount 2\], plus interest thereon as provided by law from \[date\] and \[date 2\], respectively, to the date such liabilities are paid, due from the petitioner as transferee of assets of the \[name of company\], \[city, state\], transferor, for unpaid income taxes of the transferor for the taxable years \[years\]. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that, effective upon the entry of the decision by the Court, petitioner waives the restriction contained in I.R.C. § 6213(a) prohibiting assessment and collection of the liability (plus statutory interest) until the decision of the Tax Court has become final. |\
\
**Exhibit 35.11.1-157**\
\
### Unlimited Transferee Liability: Tax and Penalty — One Year\
\
| **DECISION** |\
| :-: |\
| Pursuant to agreement of the parties in this case, it is |\
| ORDERED and DECIDED: That there is a liability in the amount of $ \[amount\] plus interest thereon as provided by law from \[date\] to the date such liability is paid, due from the petitioner as transferee of assets of \[name\], \[city, state\], transferor, for unpaid income tax and addition to the tax of the transferor under the provisions of I.R.C. § 6663(a) for the taxable year \[year\]. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that, effective upon the entry of the decision by the Court, petitioner waives the restriction contained in I.R.C. § 62l3(a) prohibiting assessment and collection of the liability (plus statutory interest) until the decision of the Tax Court has become final. |\
\
**Exhibit 35.11.1-158**\
\
### Unlimited Transferee Liability: Taxes and Penalties — Several Years\
\
| **DECISION** |\
| :-: |\
| Pursuant to agreement of the parties in this case, it is |\
| ORDERED and DECIDED: That the following statement shows the liabilities due from the petitioner as transferee and trustee of assets of the \[name of company\], \[city, state\], transferor, for unpaid taxes and additions to the tax of the transferor for the taxable years ended \[dates\]: |\
| Year Ended \[date\] |\
|  | Income Tax | $ 10,000.00 |\
|  | Addition to tax \[I.R.C. § 6663(a)\] | 5,000.00 |\
|  | Liability | $ 15,000.00 |\
| plus interest as provided by law on $ \[tax amount\] of the liability from \[date\], and on $ \[addition amount\] of the liability from \[date of notice and demand to transferor for penalty\] to the date of payment. |\
| Year Ended \[date\] |\
|  | Income Tax | $ 45,000.00 |\
|  | Addition to tax \[I.R.C. § 6663(a)\] | 20,000.00 |\
|  | Liability | $ 65,000.00 |\
| plus interest as provided by law on $ \[tax amount\] of the liability from \[date\], and on $ \[addition amount\] of the liability from \[date of notice and demand to transferor for penalty\] to the date of payment. |\
|  |  | Judge |\
| Entered: |  |  |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that, effective upon the entry of the decision by the Court, petitioner waives the restriction contained in I.R.C. § 6213(a) prohibiting assessment and collection of the liability (plus statutory interest) of the transferor for the taxable years ended \[dates\]. |\
\
**Exhibit 35.11.1-159**\
\
### Limited Transferee Liability: One Tax and Single Transfer of Assets\
\
| **DECISION** |\
| :-: |\
| Pursuant to agreement of the parties in this case, it is |\
| ORDERED and DECIDED: That there is a liability in the amount of $ \[amount\] , plus interest thereon as provided by law from \[date of transfer\] to the date such liability is paid, due from the petitioner as transferee of assets of the \[name of company\], \[city, state\], transferor, for unpaid income tax of the transferor for the taxable year \[year\]. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that, effective upon the entry of the decision by the Court, petitioner waives the restriction contained in I.R.C. § 6213(a) prohibiting assessment and collection of the liability (plus statutory interest) of the transferor for the taxable year \[year\] |\
\
**Exhibit 35.11.1-160**\
\
### Limited Transferee Liability: Several Taxes, Penalties and Transfers of Assets\
\
| **DECISION** |\
| :-: |\
| Pursuant to agreement of the parties in this case, it is |\
| ORDERED and DECIDED: That the following statement shows the liabilities due from the petitioner as transferee of assets of \[entity name\], \[city, state\], transferor, for unpaid income taxes and additions to the tax under the provisions of I.R.C. § 6663(a), of the transferor for the taxable years \[year 1\] and \[year 2\]: |\
| \[year 1\] |\
|  | Income Tax | $ 30,000.00 |\
|  | Addition to tax (I.R.C. § 6663(a)) | 10,000.00 |\
|  | Liability | $ 40,000.00 |\
| plus interest on the above liability as provided by law from \[date of transfer\] to the date of payment. |\
| \[year 2\] |\
|  | Income Tax | $240,000.00 |\
|  | Addition to tax (I.R.C. § 6663(a)) | 120,000.00 |\
|  | Liability | $360,000.00 |\
| plus interest on the above liability as provided by law as follows: On $\[amount 1\] from \[first date of transfer\]; on $\[amount 2\] from \[second date of transfer\]; and on $\[amount 3\] from \[third date of transfer\] to date of payment. |\
|  |  | Judge. |\
| Entered: |  |  |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that, effective upon the entry of the decision by the Court, petitioner waives the restriction contained in I.R.C. § 62 13(a) prohibiting assessment and collection of the liability (plus statutory interest) until the decision of the Tax Court has become final. |\
\
**Exhibit 35.11.1-161**\
\
### Limited Transferee Liability: Deficiency and Unpaid Tax for One or More Years — Single Transfer of Assets\
\
| **DECISION** |\
| :-: |\
| Pursuant to agreement of the parties in this case, it is |\
| ORDERED and DECIDED: That there is a liability of $ \[amount\], plus interest thereon as provided by law from \[date\], to the date such liability is paid, due from the petitioner as transferee of assets of \[name of entity\], \[city, state\], transferor, for an unpaid deficiency in income tax and income tax for the taxable year \[year 1\], and unpaid deficiencies in income taxes for the taxable years \[year 2\] and \[year 3\], of the transferor. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that, effective upon the entry of the decision by the Court, petitioner waives the restriction contained in I.R.C. § 6213(a) prohibiting assessment and collection of the liability (plus statutory interest) until the decision of the Tax Court has become final. |\
\
**Exhibit 35.11.1-162**\
\
### Net Operating Losses: Tentative Net Operating Loss Not in Issue\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to the agreement of the parties in the above entitled case, it is |\
| ORDERED AND DECIDED: That there is a deficiency in income tax due from the petitioner for the taxable year \[year 1\] in the amount of $ \[amount\]. |\
| That there is no addition to the tax due from the petitioner for the taxable year \[year 1\] under the provisions of I.R.C. § 6662. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that, effective upon the entry of the decision by the Court, petitioner waives the restriction contained in I.R.C. § 6213(a) prohibiting assessment and collection of the deficiency (plus statutory interest) until the decision of the Tax Court has become final. |\
| It is further stipulated that, notwithstanding the entry by the Court of the foregoing decision, the respondent may make an assessment, under the provisions of I.R.C. § 6213(b) (3) of any additional tax determined to be due for the taxable year \[year 1\] by reason of an allowance made on \[date 2\], under the provisions of section 6411 relative to a tentative net operating loss carryback allowance from \[year 1\] to \[year 2\]. |\
| Petitioner agrees to waive any defense of res judicata if respondent makes an assessment pursuant to I.R.C. § 6213(b) (3) of any additional tax determined to be due for the taxable year ended \[year 1\] by reason of the tentative allowance made on \[date 2\]. Respondent likewise agrees that, if respondent makes a timely assessment pursuant to I.R.C. § 6213(b) (3), respondent will raise no defense of res judicata if petitioner subsequently files a refund claim or refund suit. Each party has entered into this agreement in reliance on these representations. |\
\
\\_\\_\\_\_\_\_\
\
### Note:\
\
It is always preferable to audit the loss year before entry of decision for the carryback year. This form should be used only when it is inadvisable or impossible to delay entry of decision until the loss year audit is completed.\
\
This form may also be used for other tentative carryback allowances ( _e.g_., investment credit) under section 6411.\
\
**Exhibit 35.11.1-163**\
\
### Net Operating Losses: Excessive Tentative Net Operating Loss Placed in Issue\
\
| **STIPULATION** |\
| :-: |\
| It is hereby stipulated that the following statement shows the petitioner’s income tax liability for the taxable year \[year 1\]: |\
|  | Tax liability computed without allowance for net operating loss carryback from \[year 2\] to \[year 1\]: | $ 4,000.00 |  |\
|  | Tax assessed and paid (\[date\]): | $ 4,000.00 |  |\
|  | Less tentative carryback allowance made on \[date\]: | 3,500.00 |  |\
|  | Net tax assessed and paid: | $ 500.00 |  |\
|  | Deficiency without allowance for net operating loss carryback: | $ 4,000.00 |  |\
|  | Reduction in liability due to net operating loss carryback | 1,000.00 |  |\
|  | Deficiency in income tax after allowance for net operating loss carryback: | $ 3,000.00 |  |\
| It is further stipulated that, effective upon the entry of the decision by the Court, petitioner waives the restriction contained in I.R.C. § 6213(a) prohibiting assessment and collection of the deficiency until the decision of the Tax Court has become final. |\
| **DECISION** |\
| Pursuant to the stipulation of the parties filed in the above-entitled case, and incorporating herein the facts so stipulated as the findings of the Court, it is |\
| ORDERED AND DECIDED: That there is a deficiency in income tax due from the petitioner for the taxable year \[year 1\] in the amount of $ \[amount\] |\
|  | Judge. |\
| Entered |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. |\
\
**Exhibit 35.11.1-164**\
\
### Net Operating Losses: Deficiency Prior to Net Operating Loss Carryback; Overpayment After Net Operating Loss Carryback\
\
| **STIPULATION** |\
| :-: |\
| It is hereby stipulated that the following statement shows the petitioner’s income tax liabilities for the taxable year \[year 1\]: |\
|  | Tax liability, computed without allowance for net operating loss carryback from \[year 2\] to \[year 1\] | $ 100,000.00 |\
|  | Tax assessed and paid | 80,000.00 |\
|  | Deficiency, without allowance for net operating loss carryback | $ 20,000.00 |\
|  | Tax paid |  | $ 80,000.00 |\
|  | Payments: |  |  |\
|  |  | March 15, 2000<br> June 14, 2000<br> September 15, 2000<br> December 15, 2000 | $ 20,000.00<br> 20,000.00<br> 20,000.00<br>20,000.00 |  |\
|  | Total payments | $ 80,000.00 |  |\
|  | Tax liability, after allowance for net operating loss carryback | 70,000.00 |\
|  | Overpayment |  | $ 10,000.00 |\
\
I.R.C. §§ 6512(b)(2)(B) and 6511(d)(2)\
\
Return filed \[date\]\
\
No claim filed\
\
No agreements executed\
\
Deficiency notice mailed \[date\]\
\
| **DECISION** |\
| :-: |\
| Pursuant to the stipulation of the parties in the above entitled case, and incorporating herein the facts stipulated by the parties as the findings of the Court, it is |\
| ORDERED and DECIDED: That there is an overpayment in income tax for the taxable year \[year 1\] in the amount of $10,000.00, which amount was paid on \[date\], and for which amount a claim for refund could have been filed under the provisions of I.R.C. § 6511(d)(2) on \[date 2\], the date of the mailing of the notice of deficiency. |\
|  | Judge. |\
| Entered: |  |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in the above-entitled case in accordance with the stipulation of the parties submitted herewith. |\
\
**Exhibit 35.11.1-165**\
\
### Net Operating Losses: Overpayment Due Solely to Net Operating Loss Carryback — No Deficiency Prior to Carryback\
\
| **STIPULATION** |\
| :-: |\
| It is hereby stipulated that the following statement shows the petitioner’s income tax liability for the taxable year ended \[date\]: |\
|  | Net tax assessed and paid | $ 1,000,000.00 |\
|  |  | Payments: |  |  |  |\
|  |  |  | July 15, 2000<br> October 14, 2000<br> January 14, 2000<br> April 15, 2000 | $ 300,000.00<br> 300,000.00<br> 300,000.00<br>300,000.00 |  |  |\
|  |  | Total payments |  | $ 1,200,000.00 |  |\
|  |  | Less: Allowance |  |  |  |\
|  |  |  | August, 2000 |  | 200,000.00 |  |\
|  |  | Net payments |  | $ 1,000,000.00 |  |\
|  | Tax liability, after allowance for net operating loss carryback from the fiscal year ended April 30, 2000 |  |  | 900,000.00 |\
|  | Overpayment |  |  | $ 100,000.00 |\
\
I.R.C. §§ 6512(b)(3)(B) and 6511(d)(2)\
\
Return filed \[date\]\
\
No claim filed\
\
No agreements executed\
\
Deficiency notice mailed \[date\]\
\
| **DECISION** |\
| :-: |\
| Pursuant to the stipulation of the parties filed in the above-entitled case, and incorporating herein the facts stipulated by the parties as the findings of the Court, it is |\
| ORDERED and DECIDED: That there is an overpayment in income tax for the taxable year ended \[date\], which amount was paid on \[date 2\], in the amount of $ \[amount\], and for which amount a claim for refund could have been filed under the provisions of I.R.C. § 6511(d) (2) on \[date 3\], the date of the mailing of the notice of deficiency. |\
|  | Judge. |\
| Entered: |  |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in the above-entitled case in accordance with the stipulation of the parties submitted herewith. |\
\
**Exhibit 35.11.1-166**\
\
### Net Operating Losses: Deficiency Both Before and After Net Operating Loss Carryback — No Carryback Claim Filed\
\
| **STIPULATION** |\
| :-: |\
| It is hereby stipulated that the following statement shows the petitioner’s income tax liabilities for the taxable years \[year 1\] and \[year 2\]: |\
| \[year 1\] |\
|  | Tax liability, computed without allowance for net operating loss carryback from \[year 2\] to \[year 1\] | $ 250,000.00 |\
|  | Tax assessed and paid | 200,000.00 |\
|  | Deficiency, without allowance for net operating loss carryback | $ 50,000.00 |\
|  | Reduction in liability due to net operating loss carryback | 20,000.00 |\
|  | Deficiency, after allowance for net operating loss carryback | $ 30,000.00 |\
|  | No net operating loss carryback claim filed |  |\
| \[year 2\] |\
|  | Tax liability, computed without allowance for net operating loss carryback from \[year 2\] to \[year 1\] | $ 300,000.00 |\
|  | Tax assessed and paid | 100,000.00 |\
|  | Deficiency, without allowance for net operating loss carryback | $ 200,000.00 |\
|  | Reduction in liability due to net operating loss carryback | 100,000.00 |\
|  | Deficiency, after allowance for net operating loss carryback | $ 100,000.00 |\
|  | No net operating loss carryback claim filed |  |\
| It is further stipulated that, effective upon entry of this decision by the Court, petitioner waives the restriction contained in I.R.C. § 6213(a) prohibiting assessment of the deficiency (plus statutory interest) until the decision of the Tax Court has become final. |\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to the stipulation of the parties filed in the above-entitled case, and incorporating herein the facts stipulated by the parties as the findings of the Court, it is |\
| ORDERED and DECIDED: That there are deficiencies in income taxes due from the petitioner for the taxable years \[year 1\] and \[year 2\] in the amounts of $ \[amount 1\] and $ \[amount 2\], respectively. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in the above-entitled case in accordance with the stipulation of the parties submitted herewith. |\
\
**Exhibit 35.11.1-167**\
\
### Net Operating Losses: Overpayment Before and After Allowance for Net Operating Loss Carryback\
\
| **STIPULATION** |\
| :-: |\
| It is hereby stipulated that the following statement shows the petitioner’s income tax liabilities for the taxable year \[year 1\]: |\
|  | Tax assessed and paid |  | $ 400,000.00 |\
|  |  | Payments: |  |  |\
|  |  |  | March 15, 2000<br> June 15, 2000<br> September 15, 2000<br> December 15, 2000 | $ 100,000.00<br> 100,000.00<br> 100,000.00<br>100,000.00 |  |\
|  | Total payments |  | $ 400,000.00 |\
|  | Tax liability, after allowance for net operating loss carryback from \[year 2\] to \[year 1\] |  | 300,000.00 |\
|  | Overpayment |  | $ 100,000.00 |\
| I.R.C. §§ 6512(b)(3)(B) and 6511(d)(2)<br> Return filed \[date\]<br> No claim filed<br> No agreements executed<br> Deficiency notice mailed \[date\] |\
| \\* \\* \\* \* \* |\
|  | Overpayment, due to net operating loss carryback |  | $ 50,000.00 |\
|  | Overpayment, before allowance for net operating loss carryback |  | 50,000.00 |\
|  | Total overpayment, as shown above |  | $ 100,000.00 |\
\
| **DECISION** |\
| :-: |\
| Pursuant to the stipulation of the parties filed in the above-entitled case, and incorporating herein the facts stipulated by the parties as the findings of the Court, it is |\
| ORDERED and DECIDED: That there is an overpayment in income tax for the taxable year \[year 1\] in the amount of $ \[amount\], which amount was paid on \[date\], and for which amount a claim for refund could have been filed under the provisions of I.R.C. § 6511(d)(2), on \[date 2\], the date of the mailing of the notice of deficiency. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in the above-entitled case in accordance with the stipulation of the parties submitted herewith. |\
\
**Exhibit 35.11.1-168**\
\
### Net Operating Losses: Deficiency Before and Overpayment After Net Operating Loss Carryback (Notice Sent under 6-Year Period of IRC § 6501(e) and Overpayment Based on Carryback Claim)\
\
| **STIPULATION** |\
| :-: |\
| It is hereby stipulated that the following statement shows petitioner’s income tax liability for the taxable year \[year 1\]: |\
|  | Tax liability, computed without allowance for net operating loss carryback from \[year 2\] to \[year 1\] |  | $ 100,000.00 |\
|  | Tax assessed and paid |  | 50,000.00 |\
|  | Deficiency, without allowance for net operating loss carryback |  | $ 50,000.00 |\
|  | Tax paid |  | $ 50,000.00 |\
|  |  | Payments: |  |  |\
|  |  |  | April 15, 2000<br> June 15, 2000<br> September 14, 2000<br> December 14, 2000 | $ 12,500.00<br> 12,500.00<br> 12,500.00<br>12,500.00 |  |\
|  |  | Total payments | $ 50,000.00 |  |\
|  | Tax liability, after allowance for net operating loss carryback |  | 48,000.00 |\
|  | Overpayment |  | $ 2,000.00 |\
| I.R.C. §§ 6512(b)(3)(C) and 6511(d)(2)<br> Return filed \[date\]<br> Claim for net operating loss carryback filed \[date\]<br> No agreement executed<br> Deficiency notice mailed \[date\] |\
| It is further stipulated that, effective upon the entry of this decision by the Court, petitioner waives the restriction contained in I.R.C. § 6213(a) prohibiting assessment and collection of the deficiency, plus statutory interest, until the decision of the Tax Court has become final. |\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to the stipulation of the parties filed in the above-entitled case, and incorporating herein the facts stipulated by the parties as the findings of the Court, it is |\
| ORDERED and DECIDED: That there is an overpayment in income tax for the taxable year \[year 1\] in the amount of $ \[amount\], which amount was paid on \[date\], and for which amount a claim for refund was filed on \[date\], which was within the period provided by I.R.C. § 6511(d) (2), and which claim had not been disallowed before the date of the mailing of the notice of deficiency. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in the above-entitled case in accordance with the stipulation of the parties submitted herewith. |\
\
**Exhibit 35.11.1-169**\
\
### Motion to Stay Proceedings: Deficiency in Estate Tax (Extended Payment under IRC § 6161) — Stipulation\
\
| **STIPULATION OF AGREED ADJUSTMENTS** |\
| :-: |\
| THE PARTIES HERETO agree as follows: |\
| 1\. The audit statement attached hereto as Exhibit A correctly reflects the adjustments which give rise to the deficiency in estate tax due from the petitioner in the amount of $ \[amount\] as of \[date\]. |\
| 2\. The statement of account attached hereto as Exhibit B correctly reflects the account of the petitioner as of \[date\] |\
| 3\. The parties agree that the time for payment of the liability in estate tax is extended under I.R.C. § 6161. |\
| 4\. The sole purpose of leaving this case open is to allow petitioner the right to claim the amounts of interest accruing on the installment payments as an expense of administration under I.R.C. § 2053. |\
| 5\. Upon the Court's granting of the parties' joint motion for postponement of entry of decision in this case, petitioner waives the restrictions contained in I.R.C. § 6213(a) prohibiting assessment and collection of the deficiency set forth in paragraph 1 above (plus statutory interest) until the decision of the Tax Court has become final. |\
\
**Exhibit 35.11.1-170**\
\
### Motion to Stay Proceedings: Deficiency in Estate Tax (Extended Payment Under IRC § 6161) — Motion\
\
| **JOINT MOTION TO STAY PROCEEDINGS** |\
| :-: |\
| THE PARTIES JOINTLY MOVE the Court to remove the above entitled case from the Trial Session of the Court scheduled to commence at \[location\] on \[date\] and to postpone any further proceedings until the final installment of tax is due or paid, whichever occurs earlier. |\
| IN SUPPORT THEREOF, the parties respectfully state: |\
| 1\. A stipulation of settled issues is being filed with the Court by the parties along with this motion. |\
| 2\. The parties have agreed that payment of the estate tax liability shall be deferred under I.R.C. § 6161. |\
| 3\. In Estate of Bailly v. Commissioner, 81 T.C. 246 (1983), this Court held that when payment of the estate tax liability has been deferred under I.R.C. § 6166, the amount of interest to be incurred on the federal and state tax liabilities may be deducted under I.R.C. § 2053(a) (2) only as that interest accrues. |\
| 4\. In Estate of Bailly v. Commissioner, 81 T.C. 949 (1983), this Court held that under I.R.C. § 7459(c) a decision requires a specific dollar amount; therefore, entry of a decision that would, by its terms, be an indefinite amount changing over time is precluded. |\
| 5\. The parties have agreed that entry of a decision in this case should be postponed until the final installment of the estate tax liability is due or paid, whichever occurs earlier. |\
| WHEREFORE, the parties pray that this motion be granted. |\
\
**Exhibit 35.11.1-171**\
\
### Motion to Remove Small Tax Case Designation in a Collection Due Process Case\
\
|  |\
| :-: |\
| **MOTION TO REMOVE SMALL TAX CASE DESIGNATION** |\
\
RESPONDENT MOVES, pursuant to Tax Court Rules 50 and 171(c), that the Court enter an order removing the small case designation from this case and that these proceedings be conducted under the Court’s regular case procedures.\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. On or about February 1, 2007, respondent sent petitioner a _Final Notice—Notice of Intent to Levy and Notice of Your Right to Request a Hearing under I.R.C. § 6330_ (CDP Notice). A copy of the CDP Notice is attached hereto as Exhibit A.\
\
2\. In response to the CDP Notice, petitioner timely submitted a Form 12153, Request for a Collection Due Process or Equivalent Hearing, which lists the taxable periods as 2000-2004. A copy of the Form 12153 is attached hereto as Exhibit B.\
\
3\. Appeals issued a Notice of Determination covering the years listed on the hearing request. A copy of the Notice of Determination is attached hereto as Exhibit C. Petitioner subsequently filed a timely petition with the Court covering the years listed on the Notice of Determination.\
\
4\. Section 7463(f)(2) provides that a CDP case may be conducted under "S case" procedures with respect to "a determination in which the unpaid tax does not exceed $50,000." Section 7463(f)(2) requires that the total unpaid tax, not just the amount of tax in dispute, as of the date of the determination must not exceed $50,000.00 for a CDP case to qualify for small case status. Leahy v. Commissioner, 129 T.C. 71 (2007); Schwartz v. Commissioner, 128 T.C. 6 (2007). The term "tax" includes all accrued and unassessed interest and penalties on the underlying tax liability, as well as all assessed interest and penalties. SeeSchwartz v. Commissioner, 128 T.C. 6, n.1 (2007); see also I.R.C. §§ 6601(e)(1) and 6665(a)(2).\
\
**Select the paragraph 5 that applies to your case: Use the first paragraph when there is no question that the total unpaid tax as of the Determination exceeded $50,000. Use the second paragraph when the amount of total unpaid tax is close to $50,000 and so an INTST transcript must be obtained to establish the actual total unpaid tax as of the Determination.**\
\
5\. As of the date listed on the CDP notice, the amount of unpaid tax for the year(s) at issue exceeded $50,000. See Exhibit A. Between the date the Internal Revenue Service calculated the amount due in Exhibit A and the date the Notice of Determination was issued, petitioner has made no payments toward the tax liabilities at issue. See Exhibit D, Form 4340 transcripts. Thus, the total unpaid tax for the case at issue as of the date of the Notice of Determination was greater than $50,000.00, and this case is not eligible for small case designation.\
\
5\. Attached as Exhibit D is an INTST transcript for the year(s) at issue. According to the INTST transcript, the total unpaid tax for the case at issue as of the date of the Notice of Determination is $51,000. Thus, this case is not eligible for small case designation.\
\
6\. Respondent contacted petitioner regarding this Motion, and petitioner said that he does not object to the granting of this Motion.\
\
WHEREFORE, it is prayed that this Motion be granted.\
\
**Exhibit 35.11.1-172**\
\
### Failure to Pay Addition to Tax for Returns Prepared Under IRC § 6020(b)\
\
|  |\
| --- |\
| (1) **No Addition Under Section 6651 (a)(2):**The following language should be used when preparing decision documents in which the notice of deficiency determines an amount due under section 6651 (a)(2) for years prior to the enactment of section 6651 (g) and the taxpayer has not filed a return: |\
|  | _That there is no addition to tax due from the petitioner for the taxable year \[year\], under the provisions of I.R.C. § 6651(a)(2)._ |\
| This paragraph can be used to dispose of the addition where it has been erroneously placed in a statutory notice for 1995 and earlier years. |\
| (2) **Addition Under Section 6651 (a)(2):** The following language should be used when preparing decision documents in which it is determined that the addition under section 6651 (a)(2) applies. |\
|  | (a) **Addition Determined and 50 Months Has Already Transpired** |\
|  |  | _That there is an addition to tax due from the petitioner for the taxable year \[year\], under the provisions of I.R.C. § 6651(a)(2), in the amount of $ \[amount\]._ |\
|  | (b) **Addition Accruing Monthly Less Than 50 Months Elapsed** |\
|  |  | (i) Case Conceded In Full By Taxpayer |\
|  |  |  | _That there is an addition to tax due from the petitioner for the taxable year \[year\] under the provisions of I.R.C. § 6651(a)(2) of 0.5% of the amount of \[amount\] commencing on the due date of the petitioner1s return and accruing for each month or fraction thereof during which the petitioner fails to pay, not exceeding 25% in the aggregate._ |\
|  |  | (ii) Case Settled For Reduced Deficiency<br> I.RC. § 6651 (c)(2) provides that if the amount required to be shown as tax on a return is less than the amount shown as tax on such return, subsections (a)(2) and (b)(2) shall be applied by substituting such lower amount. |\
|  |  |  | _That there is an addition to tax due from the petitioner for the taxable year \[year\] under the provisions of I.R.C. § 6651(a)(2) of 0.5% of the amount of the income tax required to be shown on the return, \[amount\] commencing on the due date of the petitioner's return and accruing for each month or fraction thereof during which the petitioner fails to pay, not exceeding 25% in the aggregate._ |\
|  |  | (iii) Delinquent Return Filed By Taxpayer |\
|  |  |  | _That there is an addition to tax due from the petitioner for the taxable year \[year\] under the provisions of I.R.C. § 6651(a)(2) of 0.5% of the amount of the income tax shown on the return, \[amount\] commencing on the due date of the petitioner's return and accruing for each month or fraction thereof during which the petitioner fails to pay, not exceeding 25% in the aggregate._ |\
|  | (c) **Notice Sets Forth The Addition to Tax In a Sum Certain**<br> The following language should be used if the addition under section 6651 (a)(2) is in the notice in a sum certain from the due date of the return to the date of the notice, and the amount of the ultimate addition to tax is greater than the amount in the notice. If the ultimate addition to tax is greater than the amount in the notice, we will have to move for an increase in addition to tax. The increased addition to tax language should be in the stipulation paragraph (below the judge's signature). |\
|  |  | _It is further stipulated that the respondent claims an increased addition to tax under the provisions of I.R.C. § 6651(a) (2), for the taxable year \[year\] of .5% of the amount of the income tax shown on the return, commencing on the due date of the petitioner's return and accruing for each month or fraction thereof during which the petitioner fails to pay, not exceeding 25% in the aggregate, pursuant to the provisions of I.R.C. § 6214 (a)._ |\
|  | This paragraph should be modified if Counsel knows either the exact amount of the addition or uses the "required to be shown" language in the addition paragraph. |\
|  | (d) **Section 6651 (a)(2) Addition Is Not Applicable; Section 6651 (a)(1) Addition Understated**<br> Where it is determined that section 6651 (a)(2) is not applicable, the section 6651 (a)(1) addition will have been understated by 0.5% for five months and the Field attorney will need to move for an increased section 6651 (a)(1) addition to tax. Since this addition only runs for five months, the Service will be able to determine an exact amount. Use the following increased addition to tax paragraph: |\
|  |  | _It is further stipulated that the respondent claims an increased addition to tax under the provisions of I.R.C. § 6651(a)(1), for the taxable year \[year\], in the amount of $ \[amount\]._ |\
\
**Exhibit 35.11.1-173**\
\
### Innocent Spouse Decision Documents: IRC § 6015(e)(1)(A) Cases — Denial IRC § 6015(e)\
\
_Use this exhibit when petitioner has petitioned from a final determination letter under I.R.C. § 6015(e)(1 )(A) and relief has been denied in full._\
\
| **UNITED STATES TAX COURT** |\
| :-: |\
|  |\
| \[NAME\] | )<br> ) |  |\
| Petitioner, | )<br> ) |  |\
| and<br> \[INTERVENOR'S NAME, if any\], | )<br> )<br> )<br> ) | Docket No. \[docket no.\] |\
| Intervenor, | )<br> ) |  |\
| v. | )<br> ) |  |\
| COMMISSIONER OF INTERNAL REVENUE, | )<br> ) |  |\
| Respondent. | ) |  |\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to the agreement of the parties in this case, it is |\
| ORDERED AND DECIDED: That petitioner is not entitled to relief under I.R.C. § 6015(b), (c), or (f) with respect to \[his/her\] income tax liability for the taxable year \[year\]. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in this case.<br> It is further stipulated that interest will be assessed as provided by law on the tax liability due from petitioner.<br> It is further stipulated that, effective upon the entry of this decision by the Court, petitioner waives the restrictions contained in I.R.C. § 6015(e)(1)(B)(i) prohibiting collection of the assessment (plus statutory interest) until the decision of the Tax Court becomes final. |\
|  |  | \[NAME\]<br> Chief Counsel<br> Internal Revenue Service |\
| \_\_ | By: | \_\_ |\
| \[Petitioner's Name\]<br> Petitioner<br> \[Address\]<br> Telephone: \[Phone number\]<br> Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ \_ |  | \[Name\]<br> \[Title\]<br> Tax Court Bar No. \[#\]<br> \[Address\]<br> Telephone: \[Phone number\] |\
| \_\_ |  | \_\_ |\
| \[Intervenor's Name\]<br> Intervenor<br> \[Address\]<br> Telephone: \[Phone number\]<br> Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ \_ |  | \[Name\]<br> Associate Area Counsel<br> Tax Court Bar No. \[#\]<br> Telephone: \[Phone number\]<br> Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ \_ |\
\
**Exhibit 35.11.1-174**\
\
### Innocent Spouse Decision Documents: IRC § 6015(e)(1)(A) Cases — Relief Granted in Full, No Overpayment\
\
_Use this exhibit when petitioner has petitioned from final determination letter under section 6015(e)(1)(A), relief has been granted in full, and there is no overpayment._\
\
| **UNITED STATES TAX COURT** |\
| :-: |\
|  |\
| \[NAME\] | )<br> ) |  |\
| Petitioner, | )<br> ) |  |\
| and<br> \[INTERVENOR'S NAME, if any\], | )<br> )<br> )<br> ) | Docket No. \[docket no.\] |\
| Intervenor, | )<br> ) |  |\
| v. | )<br> ) |  |\
| COMMISSIONER OF INTERNAL REVENUE, | )<br> ) |  |\
| Respondent. | ) |  |\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to the agreement of the parties in this case, it is |\
| ORDERED AND DECIDED: That there are no income taxes due from petitioner for the taxable years \[year I\] and \[year 2\], after application of l.R.C. § 6015(b); |\
| That there are no additions to tax due from petitioner under the provisions of I.R.C. § 6651(a)(2), after application of I.R.C. § 6015(b); and |\
| That there are no overpayments in income tax due to petitioner for the taxable years \[year 1\] and \[year 2\]. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in this case. |\
|  |  | \[NAME\]<br> Chief Counsel<br> Internal Revenue Service |\
| \_\_ | By: | \_\_ |\
| \[Petitioner's Name\]<br> Petitioner<br> \[Address\]<br> Telephone: \[Phone number\]<br> Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ |  | \[Name\]<br> \[Title\]<br> Tax Court Bar No. \[#\]<br> \[Address\]<br> Telephone: \[Phone number\] |\
| \_\_ |  | \_\_ |\
| \[Intervenor's Name\]<br> Intervenor<br> \[Address\]<br> Telephone: \[Phone number\]<br> Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ |  | \[Name\]<br> Associate Area Counsel<br> Tax Court Bar No. \[#\]<br> Telephone: \[Phone number\]<br> Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ |\
\
**Exhibit 35.11.1-175**\
\
### Innocent Spouse Decision Documents: IRC § 6015(e)(1)(A) Cases — Relief Granted in Full, Overpayment\
\
_Use this exhibit when petitioner has petitioned from final determination letter under section 6015(e)(1 )(A) and relief has been granted in full, resulting in an overpayment._\
\
|  |\
| --- |\
| **UNITED STATES TAX COURT** |\
|  |\
| \[NAME\] | )<br> ) |  |\
| Petitioner, | )<br> ) |  |\
| and<br> \[INTERVENOR'S NAME, if any\], | )<br> ) |  |\
| Intervenor, | )<br> ) | Docket No. \[docket no.\] |\
| v. |  | )<br> ) |  |\
| COMMISSIONER OF INTERNAL REVENUE, | )<br> ) |  |\
| Respondent. | ) |  |\
| **STIPULATION** |\
| It is hereby stipulated that the following statement shows petitioner's income tax liability for taxable year \[year\] after the application of I.R.C. § 6015(b): |\
| Tax and penalties assessed: |  | $10,000.00 |  |\
| Unpaid balance as of \[date\]: |  | $ 5,000.00 |  |\
| Unpaid deficiency assessment<br> Unpaid penalty assessment | $4,000.00<br> 1,000.00 |  |  |\
| Payments after \[date\]:<br> \[date of payment\] |  |  | $3,000.00 |\
| Relief granted under I.R. C. § 60 15(b) for the following amounts of income tax and penalty: |\
| Unpaid deficiency assessment<br> Unpaid penalty assessment | $2,000.00<br> 500.00 |  |  |\
| Total relief granted under I.R.C. § 6015(b): |  | $ 2,500.00 |  |\
| Unpaid tax liability after application ofI.R.C. § 601 5(b): |  |  | $2,500.00 |\
| Overpayment |  |  | $ 500.00 |\
| I.R.C. §§ 6015(g)(1), 6511(b)(2)(B), and 6512(b)(3)(C)<br> Return filed \[date\]<br> Claim (Form 8857, Request for Innocent Spouse Relief), filed \[date\]<br> No agreement executed<br> Final determination letter mailed \[date\] |\
| It is further stipulated that petitioner is not entitled to relief under I.R.C. § 6015 for payments made prior to \[date\]. |\
| It is further stipulated that interest will be credited or paid as provided by law on any overpayment in tax due to petitioner. |\
\
|  |\
| --- |\
|  |  | \[NAME\]<br> Chief Counsel<br> Internal Revenue Service |\
|  |\
| \_\_ | By: | \_\_ |\
| \[Petitioner's Name\]<br> Petitioner<br> \[Address\]<br> Telephone: \[Phone number\]<br> Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ |  | \[Name\]<br> \[Title\]<br> Tax Court Bar No. \[#\]<br> \[Address\]<br> Telephone: \[Phone number\] |\
| \_\_ |  | \_\_ |\
| \[Intervenor's Name\]<br> Intervenor<br> \[Address\]<br> Telephone: \[Phone number\]<br> Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ |  | \[Name\]<br> Associate Area Counsel<br> Tax Court Bar No. \[#\]<br> Telephone: \[Phone number\]<br> Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ |\
\
|  |\
| --- |\
| **UNITED STATES TAX COURT** |\
|  |\
| \[NAME\] | )<br> ) |  |\
| Petitioner, | )<br> ) |  |\
| and<br> \[INTERVENOR'S NAME, if any\], | )<br> ) |  |\
| Intervenor, | )<br> ) | Docket No. \[docket no.\] |\
| v. |  | )<br> ) |  |\
| COMMISSIONER OF INTERNAL REVENUE, | )<br> ) |  |\
| Respondent. | ) |  |\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to the stipulation of the parties in this case, and incorporating herein the facts stipulated by the parties as the findings of the Court, it is |\
| ORDERED AND DECIDED: That there is no income tax due from petitioner for the taxable year \[year\], after application of l.R.C. § 6015(b); |\
| That there are no penalties due from petitioner for the taxable year \[year\], under the provisions of l.R.C. § 6662, after application of l.R.C. § 6015(b); and |\
| That there is an overpayment in income tax for the taxable year \[year\] in the amount of $ \[amount\], which was paid on \[date\], and for which amount a Form 8857 (which was treated as a claim for refund) was filed on \[date\], which was within the period provided by I.R.C. § 6511 (b)(2). |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in this case. |\
\
|  |\
| --- |\
|  |  | \[NAME\]<br> Chief Counsel<br> Internal Revenue Service |\
|  |\
| \_\_ | By: | \_\_ |\
| \[Petitioner's Name\]<br> Petitioner<br> \[Address\]<br> Telephone: \[Phone number\]<br> Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ |  | \[Name\]<br> \[Title\]<br> Tax Court Bar No. \[#\]<br> \[Address\]<br> Telephone: \[Phone number\] |\
| \_\_ |  | \_\_ |\
| \[Intervenor's Name\]<br> Intervenor<br> \[Address\]<br> Telephone: \[Phone number\]<br> Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ |  | \[Name\]<br> Associate Area Counsel<br> Tax Court Bar No. \[#\]<br> Telephone: \[Phone number\]<br> Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ |\
\
**Exhibit 35.11.1-176**\
\
### Innocent Spouse Decision Documents: IRC § 6015(e)(1)(A) Cases — Partial Relief Granted, No Overpayment\
\
![This is an Image: 30026253.gif](https://www.irs.gov/pub/xml_bc/30026253.gif)\
\
> This is an example of a decision document re: a final determination letter under IRC § 6015(e)(1 )(A), partial relief has been granted, and there is no overpayment.\
\
[Please click here for the text description of the image.](https://www.irs.gov/media/157761 "")\
\
![This is an Image: 30026254.gif](https://www.irs.gov/pub/xml_bc/30026254.gif)\
\
> This is page 2 of an example of a decision document re: a final determination letter under IRC § 6015(e)(1 )(A), partial relief has been granted, and there is no overpayment.\
\
[Please click here for the text description of the image.](https://www.irs.gov/media/157766 "")\
\
**Exhibit 35.11.1-177**\
\
### Innocent Spouse — Decision Documents in Deficiency Cases Involving IRC § 6015 — Relief Denied in Full\
\
_Use this exhibit when one spouse has petitioned from a statutory notice of deficiency under section 6213(a) and there is a settlement with regard to the deficiency amount resulting in no grant of relief from joint and several liability under section 6015 being necessary._\
\
| **UNITED STATES TAX COURT** |\
| :-: |\
|  |\
| \[NAME\] | )<br> ) |  |\
| Petitioner, | )<br> ) |  |\
| v. | )<br> ) | Docket No. \[docket no.\] |\
| COMMISSIONER OF INTERNAL REVENUE, | )<br> ) |  |\
| Respondent. | ) |  |\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to the agreement of the parties in this case, it is |\
| ORDERED AND DECIDED: That there is a deficiency in income tax due from petitioner in the amount of $ \[amount\] for the taxable year \[year\]; and |\
| That petitioner is not entitled to relief under I.R.C. § 6015(b), (c), or (f) with respect to the deficiency for the taxable year \[year\]. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in this case. |\
| It is further stipulated that interest will be assessed as provided by law on the deficiency due from petitioner. |\
| It is further stipulated that, effective upon the entry of this decision by the Court, petitioner waives the restrictions contained in I.R.C. § 6213(a) prohibiting assessment and collection of the deficiency (plus statutory interest) until the decision of the Tax Court becomes final. |\
|  |\
|  |  | \[NAME\]<br> Chief Counsel<br> Internal Revenue Service |\
|  |\
| \_\_ | By: | \_\_ |\
| \[Petitioner's Name\]<br> Petitioner<br> \[Address\]<br> Telephone: \[Phone number\]<br> Email: \[Email address\] |  | \[Name\]<br> \[Title\]<br> Tax Court Bar No. \[#\]<br> \[Address\]<br> Telephone: \[Phone number\]<br> Email: \[Email address\] |\
|  |  | \_\_ |\
| Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ |  | \[Name\]<br> Associate Area Counsel<br> Tax Court Bar No. \[#\]<br> Telephone: \[Phone number\]<br> Email: \[Email address\]<br> Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ |\
\
\_\_\
\
### Note:\
\
If the individual who filed a joint return with petitioner does not petition from the notice of deficiency, but intervenes in the case, then that individual should not be captioned as a petitioner, but instead should be captioned as an intervenor.\
\
**Exhibit 35.11.1-178**\
\
### Innocent Spouse — Decision Documents in Deficiency Cases Involving IRC § 6015 — Relief Granted in Full, No Overpayment\
\
_Use this exhibit when both spouses petition from a statutory notice of deficiency under section 6213(a), one of the spouses raises relief from joint and several liability under section 6015, relief is granted in full, and there is no overpayment._\
\
| **UNITED STATES TAX COURT** |\
| :-: |\
|  |\
| \[NAMES\] | )<br> ) |  |\
| Petitioners, | )<br> ) |  |\
| v. |  | )<br> ) | Docket No. \[docket no.\] |\
| COMMISSIONER OF INTERNAL REVENUE, | )<br> ) |  |\
| Respondent. | ) |  |\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to the agreement of the parties in this case, it is |\
| ORDERED AND DECIDED: That there are deficiencies in income tax and penalties due from petitioners, before application of I.R.C § 6015**\[(b), (c), or (f), select applicable subsection\]**, as follows: |\
|  | Deficiencies |\
|  | Year | Income Tax | Penalty<br>I.R.C. § 6662(a) |\
|  | 2017<br> 2018 | $100,000.00<br> $100,000.00 | $20,000.00<br> $20,000.00 |\
| That, after the application of I.R.C. § 6015 **\[(b), (c), or (f), select applicable subsection\]**, the following deficiencies in income tax and penalties are due from **\[Requesting petitioner’s name\]**: |\
|  | Year | Income Tax | Penalty<br>I.R.C. § 6662(a) |\
|  | 2017<br> 2018 | None<br> None | None<br> None |\
| That, after application of I.R.C. § 6015 **\[(b), (c), or (f), select applicable subsection\]**, the following deficiencies in income tax and penalties are due from **\[Nonrequesting petitioner’s name\]**: |\
|  | Year | Income Tax | Penalty<br>I.R.C. § 6662(a) |\
|  | 2017<br> 2018 | $100,000.00<br> $100,000.00 | $20,000.00<br> $20,000.00 |\
| That there are no overpayments in income tax due to petitioners for the taxable years 2017 and 2018. |\
|  | Judge. |  |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in this case. |\
| It is further stipulated that interest will be assessed as provided by law on the deficiencies due from petitioner, **\[Nonrequesting petitioner's name\]**. |\
| It is further stipulated that, effective upon the entry of this decision by the Court, petitioner **\[Nonrequesting petitioner’s name\]** waives the restrictions contained in I.R.C. § 6213(a) prohibiting assessment and collection of the deficiencies (plus statutory interest) until the decision of the Tax Court becomes final. |\
\
|  |\
| --- |\
|  |  | \[NAME\]<br> Chief Counsel<br> Internal Revenue Service |\
|  |\
| \_\_ | By: | \_\_ |\
| \[Petitioner Wife's Name\]<br> Petitioner<br> \[Address\]<br> Telephone: \[Phone number\]<br> Email: \[Email address\]<br> Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ |  | \[Name\]<br> \[Title\]<br> Tax Court Bar No. \[#\]<br> \[Address\]<br> Telephone: \[Phone number\]<br> Email: \[Email address\] |\
|  |  | \_\_ |\
| \[Petitioner Husband's Name\]<br> Petitioner<br> \[Address\]<br> Telephone: \[Phone number\]<br> Email: \[Email address\]<br> Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ |  | \[Name\]<br> Associate Area Counsel<br> Tax Court Bar No. \[#\]<br> Telephone: \[Phone number\]<br> Email: \[Email address\]<br> Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ |\
\
**Exhibit 35.11.1-179**\
\
### Innocent Spouse Decision Documents: IRC § 6015(e)(1)(A) Cases — Relief Granted in Part, No Overpayment — Joint Petitioners\
\
_Use this exhibit when both spouses petition from a statutory notice of deficiency under section 6213(a), one of the spouses raises relief from joint and several liability under section 6015, relief is granted in part, and there is no overpayment._\
\
| **UNITED STATES TAX COURT** |\
| :-: |\
|  |\
| \[NAMES\] | )<br> ) |  |\
| Petitioners, | )<br> ) |  |\
| v. |  | )<br> ) | Docket No. \[docket no.\] |\
| COMMISSIONER OF INTERNAL REVENUE, | )<br> ) |  |\
| Respondent. | ) |  |\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to the agreement of the parties in this case, it is |\
| ORDERED AND DECIDED: That there are deficiencies in income tax and penalties due from petitioners, before application of I.R.C. § 6015(b), as follows: |\
|  | Deficiencies |\
|  | Year | Income Tax | Penalty<br>I.R.C. § 6662(a) |\
|  | 2000<br> 2001 | $100,000.00<br> $100,000.00 | $20,000.00<br> $20,000.00 |\
| That the following deficiencies in income tax and penalties are due from petitioners, after application of I.R.C. § 6015(b): |\
|  | Joint Liability |\
|  | Year | Income Tax | Penalty<br>I.R.C. § 6662(a) |\
|  | 2000<br> 2001 | None<br> $30,000.00 | None<br> $6,000.00 |\
|  | Additional Amount Due from \[Nonrequesting Petitioner's Name\] |\
|  | Year | Income Tax | Penalty<br>I.R.C. § 6662(a) |\
|  | 2000<br> 2001 | $100,000.00<br> $70,000.00 | $20,000.00<br> $14,000.00 |\
| That there are no overpayments in income tax due to petitioners for the taxable years 2000 and 2001. |\
|  | Judge. |  |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in this case. |\
| It is further stipulated that interest is not included in the above-referenced amounts of income tax and penalties and that interest will be assessed as provided by law on the deficiencies due from petitioners. |\
| It is further stipulated that, effective upon the entry of this decision by the Court, petitioners waive the restrictions contained in I.R.C. § 6213(a) prohibiting assessment and collection of the deficiencies (plus statutory interest) until the decision of the Tax Court becomes final. |\
\
|  |\
| --- |\
|  |  | \[NAME\]<br> Chief Counsel<br> Internal Revenue Service |\
|  |\
| \_\_ | By: | \_\_ |\
| \[Petitioner Wife's Name\]<br> Petitioner<br> \[Address\]<br> Telephone: \[Phone number\]<br> Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ |  | \[Name\]<br> \[Title\]<br> Tax Court Bar No. \[#\]<br> \[Address\]<br> Telephone: \[Phone number\] |\
|  |  | \_\_ |\
| \[Petitioner Husband's Name\]<br> Petitioner<br> \[Address\]<br> Telephone: \[Phone number\]<br> Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ |  | \[Name\]<br> Associate Area Counsel<br> Tax Court Bar No. \[#\]<br> Telephone: \[Phone number\]<br> Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ |\
\
**Exhibit 35.11.1-180**\
\
### Innocent Spouse Decision Documents: IRC § 6015(e)(1)(A) Cases — Relief Granted in Part, No Overpayment — One Petitioner\
\
_Use this exhibit when only one spouse petitions from a statutory notice of deficiency under section 6213(a), raising relief from joint and several liability under section 6015, relief is granted in part, and there is no overpayment._\
\
| **UNITED STATES TAX COURT** |\
| :-: |\
|  |\
| \[NAMES\] | )<br> ) |  |\
| Petitioner, | )<br> ) |  |\
| v. |  | )<br> ) | Docket No. \[docket no.\] |\
| COMMISSIONER OF INTERNAL REVENUE, | )<br> ) |  |\
| Respondent. | ) |  |\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to the agreement of the parties in this case, it is |\
| ORDERED AND DECIDED: : That there are deficiencies in income tax and penalties due from petitioner, before application of l.R.C. § 6015(b), as follows: |\
|  | Deficiencies |\
|  | Year | Income Tax | Penalty<br>I.R.C. § 6662(a) |\
|  | 2000<br> 2001 | $100,000.00<br> $100,000.00 | $20,000.00<br> $20,000.00 |\
| That the following deficiencies in income tax and penalties are due from petitioner, after application of I.R.C. § 6015(b): |\
|  | Deficiencies |\
|  | Year | Income Tax | Penalty<br>I.R.C. § 6662(a) |\
|  | 2000<br> 2001 | $10,000.00<br> $30,000.00 | $2,000.00<br> $6,000.00 |\
| That there are no overpayments in income tax due to petitioner for the taxable years 2000 and 2001. |\
|  | Judge. |  |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in this case. |\
| It is further stipulated that interest is not included in the above-referenced amounts of income tax and penalties and that interest will be assessed as provided by law on the deficiencies due from petitioner. |\
| It is further stipulated that, effective upon the entry of this decision by the Court, petitioner waives the restrictions contained in I.R.C. § 6213(a) prohibiting assessment and collection of the deficiencies (plus statutory interest) until the decision of the Tax Court becomes final. |\
\
|  |\
| --- |\
|  |  | \[NAME\]<br> Chief Counsel<br> Internal Revenue Service |\
|  |\
| \_\_ | By: | \_\_ |\
| \[Petitioner\]<br> Petitioner<br> \[Address\]<br> Telephone: \[Phone number\]<br> Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ |  | \[Name\]<br> \[Title\]<br> Tax Court Bar No. \[#\]<br> \[Address\]<br> Telephone: \[Phone number\] |\
|  |  | \_\_ |\
|  |  | \[Name\]<br> Associate Area Counsel<br> Tax Court Bar No. \[#\]<br> Telephone: \[Phone number\]<br> Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ |\
\
**Exhibit 35.11.1-181**\
\
### Employment Tax: Decision Document in Settled IRC § 7436 Case — IRC § 530 in Favor of Petitioner\
\
|  |\
| --- |\
| UNITED STATES TAX COURT |\
|  |\
| \[NAME\], | )<br> ) |  |\
| Petitioner, | )<br> ) |  |\
| v. |  | )<br> )<br> ) | Docket No. \[docket no.\]<br> Employment |\
| COMMISSIONER OF INTERNAL REVENUE, | )<br> ) |  |\
| Respondent. | ) |  |\
| **DECISION** |\
| It is ORDERED AND DECIDED: |\
| That petitioner, whose taxpayer identification number is \[TIN\] is entitled to treatment under section 530 of the Revenue Act of 1978 with respect to \[worker\], the individual classified as an employee by respondent in the Notice of Determination for purposes of federal employment taxes under subtitle C of the Internal Revenue Code, with respect to the taxable periods ending \[date 1\], through and including \[date 2\]; |\
| That the proper amount of employment tax with respect to the above determination is $ \[amount\]. |\
| That the issue whether \[worker\] was an employee of petitioner for purposes of federal employment taxes under subtitle C of the Internal Revenue Code, with respect to the taxable periods ending \[date 1\], through and including \[date 2\], is moot. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
\
**Exhibit 35.11.1-182**\
\
### Employment Tax: Decision Document in Settled IRC § 7436 Case — Employment Status Decision in Favor of Petitioner\
\
|  |\
| --- |\
| UNITED STATES TAX COURT |\
|  |\
| \[NAME\], | )<br> ) |  |\
| Petitioner, | )<br> ) |  |\
| v. |  | )<br> )<br> ) | Docket No. \[docket no.\]<br> Employment |\
| COMMISSIONER OF INTERNAL REVENUE, | )<br> ) |  |\
| Respondent. | ) |  |\
| **DECISION** |\
| It is ORDERED AND DECIDED: |\
| That \[worker\], whose taxpayer identification number is \[TIN\], is not classified as an employee of the petitioner for purposes of federal employment taxes under Subtitle C of the Internal Revenue Code with respect to the taxable periods ending \[date 1\], through and including \[date 2\]; |\
| That the proper amount of employment tax with respect to the above determination is $ \[amount\]. |\
| That the issue whether petitioner is entitled to treatment under section 530 of the Revenue Act of 1978 with respect to \[worker\] for the taxable periods ending \[date 1\], through and including \[date 2\], is moot. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
\
**Exhibit 35.11.1-183**\
\
### Employment Tax: Decision Document in Settled IRC § 7436 Case — Decision in Favor of Respondent\
\
|  |\
| --- |\
| **UNITED STATES TAX COURT** |\
|  |\
| \[NAME\], | )<br> ) |  |\
| Petitioner, | )<br> ) |  |\
| v. |  | )<br> )<br> ) | Docket No. \[docket no.\]<br> Employment |\
| COMMISSIONER OF INTERNAL REVENUE, | )<br> ) |  |\
| Respondent. | ) |  |\
| **DECISION** |\
| It is ORDERED AND DECIDED: |\
| That \[worker), whose taxpayer identification number is \[TIN), is classified as an employee of the petitioner for purposes of federal employment taxes under Subtitle C of the Internal Revenue Code with respect to the taxable periods ending \[date 1), through and including \[date 2); |\
| That with respect to \[worker), the petitioner is not entitled to treatment under section 530 of the Revenue Act of 1978, as amended, for the periods ended \[date 1), through and including \[date 2); |\
| That the proper amount of employment tax under the above determination is as shown below: |\
\
|     |     |     |     |     |     |\
| --- | --- | --- | --- | --- | --- |\
|  |\
|  | \[Year\] Tax Period Ending \[date\] |\
|  | Type of Tax | Mar. 31 | June 30 | Sept. 30 | Dec. 31 |\
|  | FICA<br> ITW<br> FUTA<br> Addition to Tax:<br> I.R.C. § \[#\]<br> Penalty I.R.C. § \[#\] | $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\] | $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\] | $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\] | $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\]<br> $ \[amount\] |\
|  | TOTAL | $ \[amount\] | $ \[amount\] | $ \[amount\] | $ \[amount\] |\
|  |\
|  | Judge. |  |\
| Entered: |\
| \\* \\* \\* \* \* |\
\
|  |\
| --- |\
| It is stipulated that the term "federal employment taxes" refers to income tax withholding (lTW) under I.R.C. § 3402(a), the tax imposed by the Federal Insurance Contributions Act (FICA) under I.R.C. §§ 3101, 3102(a), and 3111, and the tax imposed by the Federal Unemployment Tax Act (FUTA) under I.R.C. § 3301(a). |\
| It is further stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that interest will be assessed as provided by law on the tax due from the petitioner. |\
| It is further stipulated that, effective upon the entry of this decision by the Court, petitioner waives the restrictions contained in I.R.C. § 6213(a) prohibiting assessment and collection of the tax (plus statutory interest) until the decision of the Tax Court becomes final. |\
|  |  | \[NAME\]<br> Chief Counsel<br> Internal Revenue Service |\
|  |\
| \_\_ | By: | \_\_ |\
| \[Name\]<br> Counsel for Petitioner<br> Tax Court Bar No. \[#\]<br> Telephone:<br> Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ |  | \[Name\]<br> \[Title\]<br> Tax Court Bar No. \[#\]<br> Telephone:<br> Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ |\
\
**Exhibit 35.11.1-184**\
\
### Declaratory Judgement Cases: Retirement Plans\
\
| **DECISION** |\
| :-: |\
| Pursuant to agreement of the parties in the above-entitled case, it is |\
| DECLARED, ADJUDGED AND DECIDED: That the \[name of the pension plan\] is qualified under I.R.C. § 401(a) for plan years ending \[date\] and \[date 2\]. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in the above-entitled case. |\
| It is further stipulated that this decision will not prejudice the rights of any parties that may exist under title I of ERISA or any applicable state or local law. |\
\
**Exhibit 35.11.1-185**\
\
### Declaratory Judgement Cases: Exempt Organizations\
\
**_(a) Exempt Status Denied_**\
\
| **DECISION** |\
| :-: |\
| Pursuant to the agreement of the parties in the above-entitled case, it is |\
| DECLARED, ADJUDGED AND DECIDED: That petitioner is not qualified as an organization described in I.R.C. § 501 (c) (3), as amended, and is not exempt from taxation under I.R.C. § 501 (a). |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in the above-entitled case. |\
\
**_(b) Exempt Organization/Private Foundation Status Determined_**\
\
| **DECISION** |\
| :-: |\
| Pursuant to agreement of the parties in the above-entitled case, it is |\
| DECLARED, ADJUDGED AND DECIDED: That petitioner is a \[is other than a\] private foundation within the meaning of I.R.C. § 509 (a). |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in the above-entitled case. |\
\
**Exhibit 35.11.1-186**\
\
### TEFRA: Rule 248(a) Decision per Settlement — Tabular Format — TEFRA Partnership\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to Rule 248(a) of the Tax Court Rules of Practice and Procedure, it is |\
| ORDERED AND DECIDED: That the following statement shows the adjustments to the partnership items of the \[name of partnership ) for the taxable years \[year(s)\]: |\
|  |\
| **\[year 1\]** |\
| **Partnership Item** | **As Reported** | **As Determined** |\
| Depreciation<br> XYZ Film<br> DEF Equipment | $ 500,000.00<br> 120,000.00 | $ 60,000.00<br> 70,000.00 |\
| Basis<br> XYZ Film<br> DEF Equipment | 1,250,000.00<br> 870,000.00 | 50,000.00<br> 60,000.00 |\
| Interest expense<br> First Federal Note | 15,000.00 | 6,000.00 |\
|  |\
| **\[year 2\]** |\
| **Partnership Item** | **As Reported** | **As Determined** |\
| Depreciation<br> XYZ Film<br> DEF Equipment<br> ABC Building | $ 500,000.00<br> 120,000.00<br> 300,000.00 | $ 50,000.00<br> 70,000.00<br> 40,000.00 |\
| Basis<br> XYZ Film<br> DEF Equipment<br> ABC Building | 1,250,000.00<br> 870,000.00<br> 8,600,000.00 | 50,000.00<br> 60,000.00<br> 3,000,000.00 |\
| That the First Federal Note of the \[name of partnership\] in the face amount of $ \[amount\], constitutes a borrowing from a person with an interest in the activity other than as a creditor, within the meaning of IRC § 465(b)(3), for the years \[year(s)\]. |\
| Judge. |  |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision pursuant to Tax Court Rule 248(a). |\
| It is further stipulated that the undersigned Tax Matters Partner of \[name of partnership\] for the taxable years \[year(s)\], by executing this stipulation, consents to the entry of the foregoing decision in this case and certifies that no party objects. |\
| \[name of partnership\]<br> TAX MATTERS PARTNER |\
|  |\
| By: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_<br> Date: \_\_\_\_\_\_\_\_\_\_\_\_\_<br> \[name\]<br> President<br> \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_<br> \[name\]<br> Counsel for Petitioner<br> \[Address\] |\
\
|  |\
| --- |\
|  | \[NAME\]<br> Chief Counsel<br> Internal Revenue Service<br> By: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_<br> \[Associate Area Counsel\]<br> Date: \_\_\_\_\_\_\_\_\_\_\_\_\_ |\
\
**Exhibit 35.11.1-187**\
\
### TEFRA Partnership: Rule 248(b) Motion for Entry of Decision, Certificate and Decision — Tax Matters Partner is a Participating Partner\
\
|  |\
| :-: |\
| **MOTION FOR ENTRY OF DECISION** |\
\
RESPONDENT MOVES, pursuant to Rule 248(b) of the Tax Court's Rules of Practice and Procedure, that the decision document lodged concurrently with this motion be entered as the decision in this case.\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. Respondent and petitioner, \[name\], tax matters partner, have entered into a settlement agreement, the terms of which are reflected in the decision document lodged concurrently herewith.\
\
2\. The tax matters partner agrees to the proposed decision in the case but does not certify that no party objects to the granting of the Commissioner's Motion for Entry of Decision.\
\
3\. No partner, other than the tax matters partner, is a participating partner to this action within the meaning of T.C. Rule 247(b) in that no other partner has filed an election to participate. The time within which to file a notice of election to participate under T.C. Rule 245(b) has expired.\
\
4\. All partners of the partnership that meet the interest requirements of I.R.C. § 6226(d) are treated as parties to this action pursuant to I.R.C. § 6226(c) and T.C. Rule 247(a). Once a decision is entered in this matter the respondent intends to assess each party by way of computational adjustment based on the decision.\
\
WHEREFORE, respondent requests that the motion be granted, and that the decision be entered.\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to Rule 248(b) of the Tax Court Rules of Practice and Procedure, it is |\
| ORDERED AND DECIDED: That the following statement shows the adjustments to the partnership items of the \[name of partnership\] for the taxable years \[years\]. |\
|  |\
| **\[year 1\]** |\
| **Partnership Item** | **As Reported** | **As Determined** |\
| Depreciation<br> XYZ Film<br> DEF Equipment | $ 500,000.00<br> 120,000.00 | $ 60,000.00<br> 70,000.00 |\
| Basis<br> XYZ Film<br> DEF Equipment | 1,250,000.00<br> 870,000.00 | 50,000.00<br> 60,000.00 |\
| Interest expense<br> First Federal Note | 15,000.00 | 6,000.00 |\
|  |\
| **\[year 2\]** |\
| **Partnership Item** | **As Reported** | **As Determined** |\
| Depreciation<br> XYZ Film<br> DEF Equipment<br> ABC Building | $ 500,000.00<br> 120,000.00<br> 300,000.00 | $ 50,000.00<br> 70,000.00<br> 40,000.00 |\
| Basis<br> XYZ Film<br> DEF Equipment<br> ABC Building | 1,250,000.00<br> 870,000.00<br> 8,600,000.00 | 50,000.00<br> 60,000.00<br> 3,000,000.00 |\
| That the \[title of obligation\] of the \[name of partnership\] in the face amount of $ \[amount\] , constitutes a borrowing from a person with an interest in the activity other than as a creditor, within the meaning of I.R.C. § 465 (b) (3), for the years \[years\]. |\
|  | Judge. |  |\
| Entered: |\
| \\* \\* \\* \* \* |\
\
\\_\\_\\_\_\
\
### Note:\
\
The certificate of service for all motions must reflect service on the TMP, regardless of whether the TMP is participating, in addition to service on the petitioner. T.C. Rule 246.\
\
**Exhibit 35.11.1-188**\
\
### TEFRA Partnership: Rule 248(b) Motion for Entry of Decision, Certificate and Decision — Tax Matters Partner is not a Participating Partner\
\
|  |\
| :-: |\
| **MOTION FOR ENTRY OF DECISION** |\
\
RESPONDENT MOVES, pursuant to Rule 248(b) of the Tax Court Rules of Practice and Procedure that the decision document lodged concurrently with this motion be entered as the decision in this case.\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. Respondent and petitioner, \[name\], a partner other than the tax matters partner, have entered into a settlement agreement, the terms of which are reflected in the decision document lodged concurrently herewith.\
\
2\. No partner, other than the petitioner, is a participating partner to this action within the meaning of T.C. Rule 247(b) in that no other partner has filed an election to intervene or participate. The time within which to file a notice of election to intervene or participate under T.C. Rule 245(a) or (b) has expired.\
\
3\. All partners of the partnership that meet the interest requirements of I.R.C. § 6226(d) are treated as parties to this action pursuant to I.R.C. § 6226(c) and T.C. Rule 247(a). Once a decision is entered in this matter the respondent intends to assess each party by way of computational adjustment based on the decision.\
\
WHEREFORE, it is prayed that this motion be granted and that the decision be entered.\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to Rule 248(b) of the Tax Court Rules of Practice and Procedure, it is |\
| ORDERED AND DECIDED: That the following statement shows the adjustments to the partnership items of the \[name of partnership\] for the taxable years \[years\]: |\
|  |\
| **\[year 1\]** |\
| **Partnership Item** | **As Reported** | **As Determined** |\
| Depreciation<br> XYZ Film<br> DEF Equipment | $ 500,000.00<br> 120,000.00 | $ 60,000.00<br> 70,000.00 |\
| Basis<br> XYZ Film<br> DEF Equipment | 1,250,000.00<br> 870,000.00 | 50,000.00<br> 60,000.00 |\
| Interest expense<br> First Federal Note | 15,000.00 | 6,000.00 |\
|  |\
| **\[year 2\]** |\
| **Partnership Item** | **As Reported** | **As Determined** |\
| Depreciation<br> XYZ Film<br> DEF Equipment<br> ABC Building | $ 500,000.00<br> 120,000.00<br> 300,000.00 | $ 50,000.00<br> 70,000.00<br> 40,000.00 |\
| Basis<br> XYZ Film<br> DEF Equipment<br> ABC Building | 1,250,000.00<br> 870,000.00<br> 8,000,000.00 | 50,000.00<br> 60,000.00<br> 3,000,000.00 |\
|  | Judge. |  |\
| Entered: |\
| \\* \\* \\* \* \* |\
\
**Exhibit 35.11.1-189**\
\
### TEFRA Partnership: Rule 248(b) Motion for Entry of Decision, Certificate and Decision — Cash Out-of-Pocket Settlements\
\
|  |\
| :-: |\
| **MOTION FOR ENTRY OF DECISION** |\
\
RESPONDENT MOVES, pursuant to Rule 248(b) of the Tax Court's Rules of Practice and Procedure, that the decision document lodged concurrently with this motion be entered as the decision in this case.\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. Respondent and petitioner, \[name\], tax matters partner, have entered into a settlement agreement.\
\
2\. The tax matters partner agrees to the proposed decision in the case but does not certify that no party objects to the granting of the respondent's Motion for Entry of Decision.\
\
3\. No partner, other than the tax matters partner, is a participating partner in this action within the meaning of T.C. Rule 247(b) in that no other partner has filed an election to participate. The time within which to file a notice of election to participate under T.C. Rule 245(b) has expired.\
\
4\. All partners of the partnership that meet the interest requirements of I.R.C. § 6226(d) are treated as parties to this action pursuant to I.R.C. § 6226(c) and T.C. Rule 247(a). Once a decision is entered in this matter, the respondent intends to make an assessment against each person who has not entered into a settlement and is still a party to the action at that time by way of a computational adjustment based on the decision.\
\
5\. On \[date\], respondent mailed to the tax matters partner, all notice partners, and such other partners of which counsel was aware, a letter setting forth the terms upon which respondent would be willing to enter into a settlement agreement regarding the partner's partnership items. Respondent's letter gave all partners who had not previously done so, 60 days to indicate their willingness to settle and provide appropriate documentation for settlement. Respondent's letter indicated that respondent would prepare a closing agreement \[or other specific settlement document\] for partners indicating a willingness to settle, and would give such partners an additional 30 days to sign and return the settlement document. Partners who had previously indicated a willingness to settle and provided satisfactory documentation were given 60 days to return signed copies of the included agreement forms.\] The letter stated that a settlement would occur when respondent cosigned the agreement form. Respondent's letter further informed the partners that respondent would file a Rule 248(b) Motion For Entry of Decision at the end of the above periods upholding the adjustments in the notice of Final Partnership Administrative Adjustment. The letter also stated that respondent would object to any motion to participate made for the purpose of belatedly seeking to obtain the settlement terms described ln the letter.\
\
WHEREFORE, respondent requests that the motion be granted, and that the decision be entered.\
\
\\_\\_\\_\
\
### Note:\
\
T.C. Rule 248(b) motions in the exhibits pertaining to cases where the TMP is not participating, may be similarly modified, i.e., paragraph one will no longer state that the decision conforms to the settlement, paragraph four will also be modified, and a new final paragraph is needed. Of course, the motions should not be modified for settlements that do not involve allowance of cash out-of- pocket deductions.\
\
**Exhibit 35.11.1-190**\
\
### TEFRA Partnership: Rule 248(b) Cash Out-of-pocket Settlements — Sample Letter to TMP and Partners\
\
Dear \[taxpayer’s name\]:\
\
We propose to settle the adjustments to your return(s) flowing from the \[name of partnership\] taxable year(s) \[year(s)\]. These adjustments are currently the subject of a petition to the Tax Court filed on behalf of the partners. We propose to settle the dispute by allowing you a deduction in \[specify year in which deduction will be allowed\] equal to the amount of the cash you actually invested in the partnership (cash out-of-pocket) and disallowing all other deductions and credits you claimed in any taxable year relating to the above partnership. \[describe other terms of settlement, if any, e.g., eliminating any phantom income in later years, reduction of basis, etc.\]\
\
Failure to take action with respect to this letter may result in a decision being entered by the Tax Court making you liable for the tax attributable to your share of the partnership adjustments and terminating your ability to contest these adjustments.\
\
\[ _Alternative 1_: Respondent includes the agreement forms with the initial letter. The forms already contain a deduction for previously verified cash invested.\]\
\
The settlement is contingent on you signing the enclosed \[Form 870-L(AD) or closing agreement\]. This settlement is further contingent on you returning the agreement form to the address above within 60 days of the date of this letter, and is contingent upon the Commissioner of Internal Revenue accepting the agreement as indicated by a signature on the \[Form 870-L(AD) or closing agreement\] indicating agreement.\
\
\[ _Alternative 2_: Agreement forms to be prepared by respondent after partner returns documentation.\]\
\
If you are amenable to settling on the above basis, please sign on the fine provided below indicating your willingness to settle, and return a copy of this letter to the above address with proof of your cash investment. Copies of cancelled checks (front and back), related receipts, or other proof of payment should be included with a signed copy of this letter indicating your willingness to settle. Once you have provided this information, we will prepare a settlement form, \[Form 870-L(AD) or closing agreement\], and send the form to you for your signature.\
\
The settlement is contingent on you returning this letter to the above address with acceptable documentation of your cash investment within 60 days of the date of this letter. The settlement is further contingent on you signing the agreement form that we will subsequently send to you, and returning it within 30 days of the date of the transmittal fetter enclosing the settlement form. Finally, the settlement is contingent upon the Commissioner of Internal Revenue accepting the agreement as indicated by a signature on the \[Form 870-L(AD) or closing agreement\] indicating his/her agreement.\
\
I wish to settle on the basis stated above. Enclosed is documentation of my cash invested in the partnership.\
\
\\_\\_\\_\_\_\_\_\_\_\_\_\_\
\
(Signature and date)\
\
I do not wish to settle.\
\
\\_\\_\\_\_\_\_\_\_\_\_\_\_\
\
(Signature and date)\
\
Acceptance on behalf of the Commissioner will cause your partnership items to convert to nonpartnership items. Consequently, after that date you will no longer be a party to the court proceeding under Internal Revenue Code sections 6226(c) and (d) and 6231(b)(1)(C), and you will not be bound by the subsequent decision entered by the court in that proceeding.\
\
After the response period\[s\] above, counsel for the Government will file a motion for entry of decision and a proposed decision under Tax Court Rule 248(b). The proposed decision will reflect the adjustments asserted in the notice of final partnership administrative adjustment (FPAA), which are the subject of the pending Tax Court proceeding.\
\
After the Government files its motion and proposed decision, Tax Court Rule 248(b)(4) affords any partner who opposes the settlement and wants to prosecute the case, an opportunity to come forward and elect to participate in the action. The partners who have not settled have 60 days from the date the Government files its motion to move to participate in the court proceeding. The Note to Rule 248 states:\
\
If such a motion is filed and granted, then the partnership action will continue with the objecting partners as participating partners. It is contemplated, however, that any objecting partners would have to make a substantial showing in order for the Court to grant their motion.\
\
90 T.C. 1353, 1375-1376 (1988).\
\
Since this letter gives you a chance to accept the settlement and notifies you that the Government will file a Rule 248(b) motion and proposed decision upholding the FPAA, the Government will object to any motion to participate if the purpose is simply to belatedly obtain the settlement terms set forth above. If you do not settle your adjustments and the court grants the Government’s motion for entry of decision, the Government will make an assessment against you for the tax attributable to your portion of the adjustments to the partnership return that were asserted in the FPAA.\
\
|  |  |\
| --- | --- |\
|  | \\_\\_\\_\_\_\_\_\_\_\_\_\_<br> \[signature\] |\
\
**Exhibit 35.11.1-191**\
\
### TEFRA Partnership: Notice Of Objection To Motion To Participate Out Of Time\
\
|  |\
| :-: |\
| **NOTICE OF OBJECTION** |\
\
On \[date\], movant filed a motion for leave to participate out of time. Respondent objects to the granting of such motion.\
\
IN SUPPORT THEREOF, the respondent respectfully states:\
\
1\. On \[date\], respondent filed a motion for entry of decision pursuant to Rule 248(b) of the Tax Court Rules of Practice and Procedure.\
\
2\. The motion informed the court that on \[date\], respondent mailed to the tax matters partner, all notice partners, and such other partners of which counsel was aware, a letter setting forth the terms upon which respondent would be willing to enter into a settlement agreement regarding the partners' partnership items. Respondent's letter gave all partners who had not previously done so, 60 days to indicate their willingness to settle and provide appropriate documentation for settlement. Respondent's letter indicated that respondent would prepare a closing agreement \[or other specific settlement document\] for partners indicating a willingness to settle, and would give such partners an additional 30 days to sign and return the settlement document. \[Partners who had previously indicated a willingness to settle and provided satisfactory documentation were given 60 days to return signed copies of the included settlement agreements.\] Respondent's letter further informed the partners that respondent would file a Rule 248(b) Motion For Entry of Decision at the end of the above periods upholding the adjustments in the notice of Final Partnership Administrative Adjustment. The letter also stated that respondent would object to any motion to participate made for the purpose of belatedly seeking to obtain the settlement terms described in the letter.\
\
3\. It is respondent's understanding and belief that movant seeks leave to participate solely for the purpose of belatedly seeking to obtain the settlement terms described in the letter referred to in paragraph 2, above.\
\
4\. Tax Court Rule 248(b) (4) affords any partner who opposes the settlement and wants to prosecute the case, an opportunity to come forward and elect to participate in the action. The partners who have not settled have 60 days from the date the Government files its motion to move to participate in the court proceeding. The Note to Rule 248 states:\
\
> if such a motion is filed and granted, then the partnership action will continue with the objecting partners as participating partners. It is contemplated, however, that any objecting partners would have to make a substantial showing in order for the Court to grant their motion.\
\
90 T.C. 1353, 1375-1376 (1988).\
\
5\. Movant has not made the requisite substantial showing required by T.C. Rule 248(b) (4). Movant seeks to participate, not for the purpose of continuing the litigation, but to obtain the settlement terms that were previously made available to movant by respondent in the letter dated \[date\], that was referred to in paragraph 2, above.\
\
WHEREFORE, respondent requests that the motion to participate out of time be denied.\
\
**Exhibit 35.11.1-192**\
\
### TEFRA Partnership: Motion to Appoint a Tax Matters Partner\
\
|  |\
| :-: |\
| **MOTION TO APPOINT A TAX MATTERS PARTNER** |\
\
RESPONDENT MOVES! pursuant to Rule 250 of the Court's Rules of Practice and Procedure that the Court designate a tax matters partner (TMP) to represent the partnership in this action.\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. For the taxable year \[year\], \[name of partnership\] is a TEFRA partnership. Accordingly! the tax treatment for this year is determined at the partnership level pursuant to I.R.C. § 6221.\
\
2\. On \[date\], a Notice of Final Partnership Administrative Adjustment (FPAA) was mailed to \[name of partnership\] .\
\
3\. The sale general partner of \[name of partnership\] is \[name\] All other partners are limited partners. Accordingly \[name\] was the tax matters partner of \[name of partnership\] for the taxable year \[year\] pursuant to I.R.C. § 6231(a)(7).\
\
4\. On \[date\], the tax matters partner filed the petition in this case as tax matters partner in accordance with I.R.C. § 6226(a) .\
\
5\. On \[date\], the tax matters partner filed a voluntary bankruptcy petition in the United States District Court for the \[District\] of \[State\] under Chapter \[#\].\
\
6\. Under Treas. Reg § 301.6231(a)(7)-1(1)(1)(iv), the designation as tax matters partner will be terminated when the partnership items of the tax matters partner become nonpartnership items under section 6231(c). under I.R.C. § 6231(c)(1)(E), partnership items become nonpartnership items in the case of other areas that the Secretary determines by regulation to present special enforcement considerations.\
\
7\. Under Treas. Reg. § 301.6231(c)-7(a), the Secretary has determined that the filing of a petition in bankruptcy presents special enforcement considerations, such that partnership items are converted to nonpartnership items as of the date such petition is filed. Since the partnership items of \[namel were converted to nonpartnership items as of the date of the filing of the petition with the United States Bankruptcy Court, the designation of \[namel as the tax matters partner of this partnership was terminated as of that date. See Computer Programs Lambda, Ltd. v. Commissioner, 89 T.C. 198 (1987).\
\
8\. Once a tax matters partner has filed a petition in bankruptcy, the same person cannot be redesignated as the tax matters partner. Barbados # 7, Ltd. v.Commissioner, 92 T.C. 804 (1989)\
\
9\. Tax Court Rule 250(b) provides that the Court may appoint another partner as tax matters partner upon termination of that status of the existing TMP. Tax Court Rule 246 requires that all papers filed in this case must be served upon the tax matters partner. Further, if any settlements are reached with any partner, T.C. Rule 248 requires that respondent serve notice of such settlement upon the tax matters partner, who then must serve notices upon all parties to the action. Motions for entry of decision and proposed forms of decision under T.C. Rule 248(b) must also be served on the TMP who is responsible for forwarding copies of those documents to all nonparticipating parties. Respondent will not be able to comply with these rules so long as no successor tax matters partner has been appointed in accordance with T.e. Rule 250.\
\
10\. Respondent has not been notified by the partnership that it has designated a successor tax matters partner in accordance with Treas. Reg.§ 30l.6231(a) (7)-l.\
\
11\. Respondent's counsel has been informed by petitioner's counsel that petitioners do not object to the granting of this motion.\
\
WHEREFORE, it is prayed that this motion be granted.\
\
\\_\\_\\_\_\_\
\
### Note:\
\
The above motion must be forwarded to Procedure & Administration for review prior to filing with the Court.\
\
**Exhibit 35.11.1-193**\
\
### TEFRA Partnership: Penalty Only Affected Item — Decision Document\
\
| **DECISION** |\
| :-: |\
| Pursuant to the agreement of the parties in this case, with respect to petitioners' interest in \[partnership names\] which are subject to the unified partnership audit and litigation procedures of I.R.C. §§ 6221 et seq., it is |\
| ORDERED and DECIDED: That there is no addition to the tax due from the petitioners for the taxable year \[year\] under the provision of I.R.C. § 6662(b) (1) with respect to adjustments, attributable to their investment in \[partnership name\]. |\
| That there is no addition to the tax due from the petitioners for the taxable year \[year\] under provision of I.R.C. § 6662(b) (1) with respect to adjustments attributable to their investment in \[partnership 2 name\]. |\
| That there is an addition to the tax due from petitioners for the taxable year \[year\] under the provision of I.R.C. § 6662(b) (3) in the amount of $ \[amount\] attributable to their investment in \[partnership 2 name\]. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in this case. |\
| It is further stipulated that, effective upon the entry of this decision by the Court, petitioners waive the restriction contained in I.R.C. § 6213(a) prohibiting assessment and collection of the deficiencies in tax, if any and additions to the tax (if any) and statutory interest if applicable until the decision of the Tax Court has become final. |\
\
**Exhibit 35.11.1-194**\
\
### Compromise by the Attorney General\
\
| **DECISION** |\
| :-: |\
| Pursuant to agreement of the parties in this case, it is |\
| ORDERED and DECIDED: That the deficiencies in income taxes due from the petitioner for the taxable years \[year 1\] and \[year 2\] have been discharged by the acceptance by the Attorney General of the United States of a sum offered in settlement thereof, and That by reason of the aforesaid settlement there are now no deficiencies in income taxes due from the petitioner for the taxable years \[year 1\] and \[year 2\] . |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. |\
\
**Exhibit 35.11.1-195**\
\
### Adjudication by Another Court Having Concurrent Jurisdiction with Tax Court: Another Court Disposed of All Issues Pending in Tax Court\
\
| **STIPULATION** |\
| :-: |\
| It is hereby stipulated that the petitioner's liability for income tax and additions to the tax for the taxable year ended \[date\], was adjudicated by the United States District Court for the \[District\] of \[State\], which Court entered a judgment on \[date\], in the case of United States v. \[Name\], Civil Action No. \[case number\], \[case citation (if reported)\]. |\
| It is further stipulated that said judgment of the United States District Court became final on \[date\] and that said liability has been assessed and paid. |\
| It is further stipulated that by reason of the aforesaid adjudication by the said United States District Court, which court had concurrent jurisdiction with the Tax Court, and that by reason of the assessment and payment of said liability there are now no deficiencies in income tax and additions to the tax, under the provisions of I.R.C. §§ 6651(a) (1) and 6662(a) due from the petitioner for the taxable year ended \[date\]. |\
| **DECISION** |\
| Pursuant to the agreement of the parties in this case, and incorporating herein the facts stipulated by the parties as the findings of the Court, it is: |\
| ORDERED and DECIDED: That there are now no deficiencies in income tax and additions to the tax, under the provisions of I.R.C. §§ 6651(a) (1) and 6662(a), due from nor overpayment due to the petitioner for the taxable year ended \[date\]. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. |\
\
**Exhibit 35.11.1-196**\
\
### Adjudication by Another Court Having Concurrent Jurisdiction with Tax Court: All Issues Before Tax Court Not Disposed of by Another Court\
\
|  |\
| :-: |\
| **STIPULATION** |\
| It is hereby stipulated that the petitioner's income tax liability for the taxable year \[year\] was adjudicated by the United States District court for the \[District\] of \[State\], which Court entered a judgment on \[date\], in the case of United States v. \[Name\], Civil Action No. \[case number\], \[case citation (if reported)\], which judgment became final on \[date\], and that said liability has been assessed and paid. |\
| It is further stipulated that, by reason of the aforesaid adjudication of the United States District Court, which Court had concurrent jurisdiction with the Tax Court, and by reason of the assessment and payment of said liability, there is now no deficiency in income tax due from the petitioner for the taxable year \[year\]. |\
| It is further stipulated that said United States District Court did not adjudicate or otherwise determine the petitioner's income tax liability for the taxable year \[year 2\]. |\
| It is further stipulated that there is a deficiency in income tax due from the petitioner for the taxable year \[year 2\] in the amount of $ \[amount\]. |\
| **DECISION** |\
| Pursuant to the agreement of the parties in this case, and incorporating herein the facts stipulated by the parties as the findings of the Court, it is |\
| ORDERED and DECIDED: That there is now no deficiency in income tax due from the petitioner for the taxable year \[year\] and |\
| That there is a deficiency due from the petitioner for the taxable year \[year 2\] in the amount of $ \[amount\]. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that, effective upon the entry of the decision by the Court, petitioner waives the restriction contained in I.R.C. § 6213(a) prohibiting assessment and collection of the deficiency (plus statutory interest) until the decision of the Tax Court has become final. |\
\
\\_\\_\\_\_\_\_\
\
### Note:\
\
This form may be applicable where the related case was a bankruptcy or receivership.\
\
**Exhibit 35.11.1-197**\
\
### Rule 155 Computation: Computation Face Sheet\
\
_**(1) First Page**_\
\
|  |\
| --- |\
| UNITED STATES TAX COURT |\
|  |\
| \[NAME\] | )<br> ) |  |\
| Petitioner, | )<br> ) |  |\
| v. |  | )<br> ) | Docket No. \[docket no.\] |\
| COMMISSIONER OF INTERNAL REVENUE, | )<br> ) |  |\
| Respondent. | ) |  |\
|  |\
| RESPONDENT'S COMPUTATION FOR ENTRY OF DECISION |\
| The attached computation is submitted, on behalf of the respondent, in compliance with the Court's opinion determining the issues in this case, together with a proposed decision which is being lodged concurrently with said computation. |\
| This computation is submitted without prejudice to respondent's right to contest the correctness of the decision entered herein by the Court. |\
|  | \[NAME\]<br> Chief Counsel<br> Internal Revenue Service<br> By: |\
| OF COUNSEL:<br> \[Name\],<br> Area Counsel<br> \[Name\],<br> Attorney |\
\
**_(2) Second page_**\
\
|  |\
| --- |\
| Without prejudice to the right of appeal, it is agreed that the attached computation is in accordance with the opinion of the Tax Court in the above-entitled case. |\
|  | \_<br> Counsel for Petitioner,<br> \[Name and address\] |\
\
\\_\\_\\_\_\_\
\
### Note:\
\
In "S" cases, delete the second paragraph of the Computation Face Sheet since there is no right of appeal. Section 7463(b). Also omit from the second page the phrase: "Without prejudice to the right of appeal," and state instead: "The parties agree that the attached computation is in accordance with the opinion of the Tax Court in the above-entitled case."\
\
**Exhibit 35.11.1-198**\
\
### Rule 155 Computation: Proposed Decision\
\
_**(1) First Page**_\
\
|  |\
| --- |\
| **UNITED STATES TAX COURT** |\
|  |\
| \[NAME\] | )<br> ) |  |\
| Petitioner, | )<br> ) |  |\
| v. |  | )<br> ) | Docket No. \[docket no.\] |\
| COMMISSIONER OF INTERNAL REVENUE, | )<br> ) |  |\
| Respondent. | ) |  |\
|  |\
| DECISION |\
| Pursuant to the opinion of the Court filed \[date\], and incorporating herein the facts recited in the respondent's computation as the findings of the Court, it is |\
| ORDERED and DECIDED: \[ _See_ decision forms for settled cases as to the terminology and format to be used in the operative portion of the decision document\]. |\
|  | Judge. |\
| Entered: |\
\
**_(2) Second page_**\
\
|  |\
| --- |\
| The parties stipulate that the foregoing decision is in accordance with the opinion of the Court and the respondent's computation, and that the Court may enter this decision, without prejudice to the right of either party to contest the correctness of the decision entered herein. |\
|  | \[NAME\]<br> Chief Counsel<br> Internal Revenue Service<br> By: |\
| Counsel for Petitioner,<br> \[Name and address\] |\
\
\\_\\_\\_\_\_\
\
### Note:\
\
In "S" cases, omit from the second page of the proposed decision the phrase: "Without prejudice to the right of either party to contest the correctness of the decision entered herein" , and state instead: "The parties stipulate that the foregoing decision is in accordance with the opinion of the Court and respondent's computation, and that the Court may enter this decision."\
\
**Exhibit 35.11.1-199**\
\
### Rule 155 Computation: Computation Statement — Tabular Form, Deficiency, Tax, Penalty, Husband and Wife, Joint and Several Liability, Separate Docket Numbers\
\
| **COMPUTATION STATEMENT** |\
| :-: |\
|  | In re: | \[Name of case\] |  |  |\
|  |  | \[Petitioner’s address\] |  |  |\
|  |  | Docket No. \[docket no.\] |  |  |\
|  |  |  |  |  |\
| Year |  | Deficiency<br>Income Tax | Addition to Tax<br>I.R.C. § 6663(a) |  |\
| 2000 |  | $10,000.00 | $ 7,000.00 |  |\
| 2001 |  | 5,000.00 | 2,000.00 |  |\
|  |  |  |  |  |\
| The aforesaid deficiencies in income taxes and additions to the tax are duplications of the deficiencies and additions to the tax set forth in the case of \[case name\], Docket No. \[docket no.\], in which a computation pursuant to the Court’s opinion dated \[date\] is concurrently being filed with the Tax Court. The petitioners in Docket Nos. \[docket no.\] and \[docket no.\] are jointly and severally liable for said deficiencies and additions to the tax, plus statutory interest, and the payment of the entire amount of said deficiencies and additions to the tax, plus interest, by either petitioner, or by the petitioners jointly, will discharge the instant petitioner from liability. |\
| The details supporting the above computations are set forth on attached pages \[#\] to \[#\], inclusive. |\
|  |  |  |  |  |\
| **_Note_**: This form illustrates the use of the tabular form for the first part of the Computation Statement for deficiencies in either taxes or penalties. Most of the Rule 155 forms set forth herein illustrate two or more principles involved in setting up the first part of the Computation Statement. For example, this form also illustrates the cases of a husband and wife who are jointly and severally liable for the deficiencies and penalties, but who filed separate petitions with the Tax Court. In this instance, a Computation Statement must be prepared for each docket number and since the decision in each case must provide for the full liability, there is a duplication determined by the Tax Court similar to that in transferee cases. In determining the format of the first part of the Computation Statement forms set forth herein, there should be considered not only the Rule 155 forms, but also the various illustrations shown in the forms of settlement documents. The applicable taxable period or year, or calendar year, should be specified in the manner illustrated for income and gift tax cases. In estate tax cases, only the date of death is specified in part one of the Computation Statement. |\
\
**Exhibit 35.11.1-200**\
\
### Rule 155 Computation: Computation Statement — Narrative Form, Deficiency, Tax, Penalty, Interim Assessment, Jeopardy Assessment, Overpayment\
\
|  |\
| :-: |\
| **COMPUTATION STATEMENT** |\
|  | In re: | \[Case name\]<br> \[Petitioner’s address\]<br> Docket No. \[docket no.\] |\
|  |  |  |  |  |  |  |\
| Income Tax |\
| \[year 1\] |  |\
| Deficiency |  | None |  |\
| Deficiency in tax |  | $ 5,000.00 |  |\
| Addition to the tax<br> I.R.C. § 6663(a) |  | $ 2,000.00 |  |\
| \[year 2\] |  |\
| Deficiency, without taking into consideration the assessment subsequent to the mailing of the deficiency notice on \[date\]. |  | $ 10,000.00 |  |\
| Assessment, \[date\]: |  |  |  |\
|  | Paid | $ 5,000.00 |  |  |  |\
|  | Not paid | 3,750.00 |  | 8,750.00 |  |\
| Deficiency (to be assessed) |  |  |  | $ 11,000.00 |  |\
| \[year 3\] |  |\
| Deficiency in tax, without taking into consideration the jeopardy assessment made prior to the mailing of the deficiency notice of \[date\] |  | $ 10,000.00 |  |\
| Assessment (jeopardy), \[date\] |  |  |  |\
|  | Paid | $ 5,000.00 |  |  |  |\
|  | Not Paid | 4,000.00 |  | 9,000.00 |  |\
| Deficiency in tax (to be assessed) |  | 1,000.00 |  |\
| Addition to the tax (I.R.C. § 6663(a)), without taking into consideration the jeopardy assessment made prior to the mailing of the deficiency notice on \[date\] |  | 5,000.00 |  |\
| Assessment (jeopardy), \[date\] (not paid) |  | $ 4,500.00 |  |\
| Deficiency in addition to the tax (to be assessed) |  | $ 500.00 |  |\
| \[year 4\] |  |\
| Tax assessed and paid |  | $ 5,300.00 |  |\
| Payments: |  |  |  |\
| April 15, \[year\] (statutory date) | $ 2,400.00 |  |  |  |\
| \[date 2\] | 1,700.00 |  |  |  |\
| \[date 3\] | 1,200.00 |  |  |  |\
| Total payments | $ 5,300.00 |  |  |  |\
| Tax liability |  | $ 4,300.00 |  |\
| Overpayment |  | $ 1,000.00 |  |\
| I.R.C. §§ 6512(b)(3)(C) and 6511(b)(2)<br> Return filed \[date\]<br> Claim filed \[date\]<br> No agreement executed<br> Deficiency notice mailed \[date\] |\
| The details supporting the above computations are set forth on attached pages \[#\] to \[#\] , inclusive. |\
\
**Exhibit 35.11.1-201**\
\
### Rule 155 Computation: Computation Statement — Overpayment of Tax and Penalty, Jeopardy Assessment\
\
| **COMPUTATION STATEMENT** |\
| :-: |\
|  |  | In re: | \[Name of case\]<br> \[Petitioner’s address\]<br> Docket No. \[docket no.\] |  |  |\
| Income Tax |\
| \[year 1\] |\
|  | Net tax assessed and paid |  |  | $ 7,500.00 |\
|  | Payments: |  |  |  |\
|  |  | April 15, \[year\]<br> (statutory date) | $ 150.00 |  |  |\
|  |  | \[date 1\] | 400.00 |  |  |\
|  |  | \[date 2\] | 6,250.00 |  |  |\
|  |  | \[date 3\] (jeopardy assessment) | 750.00 |  |  |\
|  |  | Total payments |  | $ 7,550.00 |  |\
|  |  | Less: Allowance, \[date\] |  | 50.00 |  |\
|  | Net payment |  | $ 7,500.00 |  |\
|  |  | Tax liability |  |  | $ 6,500.00 |\
|  |  | Overpayment in tax |  |  | $ 1,000.00 |\
| I.R.C. §§ 6512(b)(3)(A), 65l2(b)(3)(B) and 6511(c)<br> Return filed \[date\]<br> No claim filed<br> Agreement executed \[date\] (extending statutory period to \[date\])<br> Deficiency notice mailed \[date\] |  |\
|  | Addition to the tax (I.R.C. § 6663(a))<br> paid, \[date\] (jeopardy assessment) |  |  | $ 3,500.00 |\
|  | Liability for addition to the tax |  |  | 3,000.00 |\
|  | Overpayment in addition to the tax |  |  | $500.00 |\
| I.R.C. § 6512(b)(3)(A)<br> Return filed \[date\]<br> No claim filed<br> Agreement executed, \[date\] (extending statutory period to \[date\])<br> Deficiency notice mailed \[date\] |  |  |\
| The details supporting the above computation are set forth on attached pages \[#\] to \[#\], inclusive. |\
\
**Exhibit 35.11.1-202**\
\
### Rule 155 Computation: Computation Statement — Transferee Liability, Computation for Transferor and/or Several Transferees Covering Duplication of Liability in Cases Before Court\
\
| **COMPUTATION STATEMENT** |\
| :-: |\
|  | In re: | \[Name of petitioner\], Transferee of Assets of \[Name of transferor\]<br> \[Petitioner’s address\]<br> Docket No. \[docket no.\] |\
|  |  |  |  |\
|  | \[Name of transferor\],<br> Transferor \[Transferor’s address\] |\
|  | Income Tax<br> \[year 1\] |\
|  | Liability | $ \[amount\] |\
|  | plus interest on the above liability as provided by law from \[date\] to the date of payment. |\
\
The aforesaid liability of the above-named petitioner, plus interest as provided by law, is a duplication of the deficiency set forth in the case of \[name of transferor\], transferor , Docket No. \[docket no.\], and of the liability set forth in the case of \[name of other transferee before the Court\],transferee, Docket No. \[docket no.\] in which cases computations of liability pursuant to the Court’s opinion dated \[date\] are concurrently being filed with the Tax Court of the United States. The payment of the entire amount of the liability of the transferor, plus interest as provided by law, by any one, or a combination of the petitioners liable therefor, will discharge the instant petitioner from liability.\
\
The details supporting the above computation are set forth on attached pages \[#\] to \[#\], inclusive.\
\
**Exhibit 35.11.1-203**\
\
### Rule 155 Computation: Computation Statement — Carryback, Overpayment\
\
| **COMPUTATION STATEMENT** |\
| :-: |\
| In re: | \[Name of case\]<br> \[Petitioner’s address\]<br> Docket No. \[docket no.\] |\
|  |  |  |  |  |  |\
| Income Tax<br> \[year 1\] |\
| Tax liability, computed without allowance for net operating loss carryback from \[year 2\] to \[year 1\] |  | $ 300,000.00 |\
| Tax assessed and paid |  | 200,000.00 |\
| Deficiency, without allowance for net operating loss carryback |  | $ 100,000.00 |\
| Reduction in liability due to net operating loss carryback |  | 75,000.00 |\
| Deficiency, after allowance for net operating loss carryback |  | $ 25,000.00 |\
| No net operating loss carryback claim filed |  |  |\
| \[year 2\] |\
| Tax liability, computed without allowance for net operating loss carryback from \[year 2\] to \[year 1\] |  | $100,000.00 |\
| Tax assessed and paid |  | 75,000.00 |\
| Deficiency, without allowance for net operating loss carry-back |  | $ 25,000.00 |\
| Tax paid |  | $ 75,000.00 |  |\
| Payments: |  |  |  |\
|  | \[date\] |  |  | $ 20,000.00 |  |\
|  | \[date 2\] |  |  | 20,000.00 |  |\
|  | \[date 3\] |  |  | 20,000.00 |  |\
|  | \[date 4\] |  |  | 15,000.00 |  |\
|  | Total payments |  |  | $ 75,000.00 |\
| Tax liability, after allowance for net operating loss carry-back |  |  | 60,000.00 |\
| Overpayment |  |  | $15,000.00 |\
|  |\
\
I.R.C. §§ 6512(b)(3)(C) and 6511(d)(2)\
\
Return filed \[date\]\
\
Claim for net operating loss carryback filed, \[date\]\
\
Agreement executed \[date\] (extending statutory period to \[date\])\
\
Deficiency notice mailed \[date\]\
\
The details supporting the above computations are set forth on attached pages \[#\] to \[#\], inclusive.\
\
**Exhibit 35.11.1-204**\
\
### Rule 155 Computation: Computation Statement — Estate Tax, State Estate Tax\
\
| **COMPUTATION STATEMENT** |\
| :-: |\
|  | In re: | \[Name of case\]<br> \[Petitioner’s address\]<br> Docket No. \[docket no.\] |  |\
|  |  | Date of death: \[date\] |  |\
|  |  |  |  |\
|  | Estate tax deficiency | $ 50,000.00 |  |\
| The petitioner may claim credit for State estate, inheritance, legacy or succession taxes, and may present to the Internal Revenue Service proof of such payment within the statutory period. |\
| The details supporting the above computation are set forth on attached pages \[#\] to \[#\], inclusive. |\
|  |  |\
| **_Note:_**Normally the gross deficiency in estate tax is provided for in the Tax Court’s decision, and the petitioner may within the statutory period submit to the Service support for any claim for State estate taxes. However, if the petitioner submits proof of partial payment of State estate taxes and a partial credit is allowed in part two of the Computation Statement, the credit paragraph as illustrated in this form should be modified to set forth both the partial credit allowed and the maximum credit for which claim may be made. In this instance, however, the decision of the Tax Court should be for the gross deficiencies. |\
| If proof of the entire credit is submitted and allowed in part two of the Computation Statement, the deficiency set forth in part one of the Computation Statement and in the Tax Court’s decision would be for the net deficiency. In the latter instance, the word net should be added before the word deficiency, and the credit paragraph should be omitted from part one of the Computation Statement. |\
\
**Exhibit 35.11.1-205**\
\
### Rule 155 Computation: Computation Statement — Short Form, No Change in Amount of Deficiency/Computation from that Shown in Statutory Notice — No Overpayment Involved\
\
| **COMPUTATION STATEMENT** |\
| :-: |\
|  |  | In re: | \[Name of case\]<br> \[Petitioner’s address\]<br> Docket No. \[docket no.\] |  |\
|  |  |  |  |  |\
| Income Tax |\
|  |  | Year | Deficiency |  |\
|  |  | 2000 | $ 6,000.00 |  |\
|  |  | 2001 | 3,000.00 |  |\
| The deficiencies in income taxes due from the petitioner as shown above are as set forth in the notice of deficiency dated \[date\], a copy of which is attached to the petition in the above-entitled case. |\
|  |  |  |\
| **_Note:_** The short form may be used only in cases in which the deficiency to be determined by the Court is in the same amount as determined in the statutory notice. However, it may not be used in cases involving any of the following factors: an overpayment; an adjustment in the Computation Statement which results in a lesser deficiency to be assessed or to be paid; restrictive interest computations; or in any case in which there are any special or additional computations necessary which are not shown in the supporting statement to the statutory notice. When the short form is appropriately used, part two and three of the Computation Statement may be omitted. |\
\
**Exhibit 35.11.1-206**\
\
### Rule 155 Computation: Computation Statement — Portion of Overpayment Barred Notice sent under 6-year period of IRC 6501(e)\
\
| **COMPUTATION STATEMENT** |\
| :-: |\
|  | In re: | \[Name of case\]<br> \[Petitioner’s address\]<br> Docket No. \[docket no.\] |  |\
|  |\
| Income Tax<br> \[year 1\] |\
|  | Tax assessed and paid |  | $ 15,000.00 |\
|  |  | Payments: |  |  |\
|  |  | \[date\] | $ 10,000.00 |  |\
|  |  | \[date\] | 5,000.00 |  |\
|  |  | Total payments | $ 15,000.00 |  |\
|  | Tax liability |  | 9,000.00 |\
|  | Overpayment |  | $ 6,000.00 |\
|  | Overpayment barred by statute of limitations |  | 1,000.00 |\
|  | Net overpayment allowable |  | $ 5,000.00 |\
| I.R.C. § 6512(b)(3)(A)<br> Return filed \[date\]<br> No claim filed<br> No agreements executed<br> Deficiency notice mailed \[date\] |  |  |\
|  |  |  |\
| **_Note:_** Where there is a stipulated decision involving a barred overpayment, it is not necessary for the stipulation document to so indicate. The amount of the stipulated liability should be increased by the amount of the barred overpayment so that the stated overpayment will be the amount which can be refunded or credited. |\
\
**Exhibit 35.11.1-207**\
\
### Award Data Sheet\
\
| **AWARD DATA SHEET** |\
| :-: |\
| A. | CASE CAPTION AND DOCKET NO. |\
| B. | NAME AND ADDRESS OF PAYEE(S) 1 |\
| C. | PAYEE(S) TAX IDENTIFICATION NUMBER2 |\
| D. | NAME, ADDRESS, AND TELEPHONE NUMBER OF PETITIONER’S COUNSEL 3 |\
| E. | TOTAL AMOUNT OF AWARD4 |\
| F. | BREAKDOWN BETWEEN ATTORNEY’S FEE AND OTHER COSTS |\
| G. | AMOUNT TO BE OFFSET, IF ANY5 |\
| H. | BRIEF STATEMENT OF WHY THE AWARD WAS MADE6 |\
| I. | WAS THE AWARD THE RESULTS OF A SETTLEMENT? |\
|  | Y or N |\
|  | IF YES, WAS THE AWARD APPROVED BY THE APPROPRIATE OFFICIAL? 7 |\
|  |  |  |  |\
| IMPORTANT: ATTACH COPY OF DECISION ENTERED BY THE TAX COURT |\
| If you have any questions concerning this matter, please contact \[name\] at \[telephone number\]. |\
|  |  |  |\
|  | 1 Name(s) of payee(s) must be exactly as set forth in court’s Order or stipulation of settlement. |\
|  | 2 If there are multiple payees, e.g., husband and wife, include tax identification number for each payee. |\
|  | 3 In general, the check will be made payable to the payee(s) but delivered to petitioner’s counsel. |\
|  | 4 Amount includes attorney’s fees, costs, experts, etc. |\
|  | 5 For this purpose only, the amount of the award that is eligible to be offset is limited to any unpaid deficiency that is determined in the court’s Decision that contains the award, exclusive of interest, regardless of whether the interest has been assessed. |\
|  | 6 This should not be a statement of the legal issue. Similarly, a statement that the award was ordered by the court or our position was not substantially justified is not sufficient. |\
|  | 7 Settlement of administrative costs in excess of $5,000 and settlement of litigation costs in excess of $25,000 must be approved by the Associate Chief Counsel (Procedure and Administration). |\
|  |  |  |  |\
\
**Exhibit 35.11.1-208**\
\
### Payment Memorandum with Offset\
\
| \[letterhead\] |\
| :-: |\
| Judgment Fund Section<br> Financial Management Service<br> Department of the Treasury<br> 3700 East-West Hightway, Mail Stop 6F03<br> Hyattsville, MD 20782 |\
| Matter of: | \[Petitioner’s name\] v. Commissioner<br> Tax Court Docket No. \[docket no.\] |\
| Dear Sir or Madam: |  |\
| Enclosed for payment is a copy of a decision awarding litigation costs to the taxpayers in the above-entitled case. All necessary approvals have been obtained and no further review of this matter will be taken. The payment of these litigation costs by the General Accounting Office has been authorized, therefore, we request that this payment be processed. |\
| Please note that the decision in this case also determines a deficiency due to the government which is greater than the amount of the award to the taxpayer. PLEASE REQUEST ON THE CERTIFICATE THAT THE AWARD BE PAID ON SF-l081. In order for the SF-1081 to be prepared the following information will need to be transmitted with the certificate: |\
|  | Name of Taxpayer: \[petitioner\]<br> Taxpayer Identification Number: \[TIN\]<br> Secondary TIN: N/A<br> Type of Tax: Individual Income Tax<br> Year of Deficiency: \[year\]<br> Service Center for Processing: \[city, state\] |\
| The ALC number for the \[city\] Service Center is \[ALC no.\]. The account to which the payment is to be made is the Refund appropriation account. The number of this account is 20X0903. |\
| All further pertinent information to enable you to process this matter for payment is included on the enclosed Adverse Judgment Data sheet. |\
| Please notify this office when payment has been made. If you have any questions, please call \[name\] at \[phone #\] . Thank you for your cooperation. |\
|  |  |  | Sincerely, |\
|  |  |  | \[NAME\]<br> Chief Counsel<br> Internal Revenue Service |\
|  |  |  | By:\_\_\_\_\_\_\_\_ |\
| Enclosures:<br> Decision<br> Adverse Judgment Data Sheet |  |\
| cc: Area Counsel |  |\
\
**Exhibit 35.11.1-209**\
\
### Payment Memorandum without Offset\
\
| \[letterhead\] |\
| :-: |\
| Judgment Fund Section<br> Financial Management Service<br> Department of the Treasury<br> 3700 East-West Hightway, Mail Stop 6F03<br> Hyattsville, MD 20782 |\
| Matter of: | \[Petitioner’s name\] v. Commissioner<br> T.C. Docket No. \[docket no.\] |\
| Dear Sir or Madam: |\
| Enclosed for payment is a copy of a decision awarding litigation costs to the taxpayer in the above-entitled case. All necessary approvals have been obtained and no further review of this matter will be taken. The payment of these litigation costs by the General Accounting Office has been authorized, therefore, we request that this payment be processed. All pertinent information to enable you to process this matter for payment is included on the enclosed Adverse Award Judgment Sheet. |\
| Please notify this office when payment has been made. If you have any questions, please call \[name\] at \[phone no.\] . Thank you for your cooperation. |\
|  |  | Sincerely, |\
|  |  | \[NAME\]<br> Chief Counsel<br> Internal Revenue Service |\
|  |  | By:\_\_\_\_\_\_\_\_ |\
| Enclosures:<br> Decision<br> Adverse Award Judgment Sheet |  |\
| cc: Area Counsel |  |\
\
**Exhibit 35.11.1-210**\
\
### Collection Due Process Case: Stipulation of Facts Attaching Administrative Record\
\
|  |\
| :-: |\
| **STIPULATION OF FACTS** |\
\
In accordance with Tax Court Rule 91(e), the parties agree to this Stipulation of Facts pursuant to the general terms of this preamble, unless specifically expressed otherwise. All stipulated facts shall be conclusive. All stipulated exhibits shall be considered authentic. All copies shall be considered electronic reproductions of the originals and shall be treated as if originals. Any relevance or materiality objection may be made with respect to all or any part of this stipulation at the time of submission, but all other evidentiary objections are waived unless specifically expressed within this stipulation.\
\
1\. At the time of the filing of the Tax Court petition, the petitioner was a resident of Dallas, Texas.\
\
2\. From 1999 through present, the petitioner resided at 1234 Main Street, Dallas Texas, 75030.\
\
3\. On April 1, 2007, a Letter 3172, Notice of Federal Tax Lien Filing and Your Right to a Hearing under I.R.C. § 6320 was sent to the petitioner for his 2005 income tax liability. Attached and marked as Exhibit 1-J is a true and correct copy of the Letter 3172.\
\
4\. On May 1, 2007, respondent received a Form 12153, Request for a Collection Due Process or Equivalent Hearing, filed by the petitioner. Attached and marked as Exhibit 2-J is a true and correct copy of the Form 12153.\
\
5\. Attached and marked as Exhibit 3-J is a TXMOD-A transcript for petitioner’s income tax liability for tax year 2005 dated May 1, 2007.\
\
6\. On May 15, 2007, Settlement Officer \[name\] mailed a letter to the petitioner scheduling a hearing for May 30, 2007. Attached and marked as Exhibit 4-J is a true and correct copy of the May 15, 2007 letter.\
\
7\. Attached and marked as Exhibit 5-J is a true and correct copy of a Form 433-A, Collection Information Statement for Wage Earners and Self-Employed Individuals, signed by the petitioner and dated May 20, 2007.\
\
8\. On April 15, 2006, the petitioner filed a Form 1040 Individual Income Tax Return, for the taxable year 2005. Attached and marked as Exhibit 6-J is a true and correct copy of the petitioner’s Form 1040 for the taxable year 2005.\
\
9\. On October 1, 2006, a statutory notice of deficiency was sent to the petitioner for his taxable year 2005. Attached and marked as Exhibit 7-J is a true and correct copy of the statutory notice of deficiency sent to the petitioner for his taxable year 2005. Attached and marked as Exhibit 8-J is a true and correct copy of the certified mail list for the 2005 statutory notice of deficiency.\
\
10\. On May 30, 2007, a conference was held between the petitioner and Settlement Officer \[name\].\
\
11\. Attached and marked as Exhibit 9-J is a true and correct copy of the Appeals Case Activity Record prepared by Settlement Officer \[name\].\
\
12\. Attached and marked as Exhibit 10-J is a true and correct copy of the Appeals Transmittal and Case Memo dated May 30, 2007.\
\
13\. On June 30, 2007, a Notice of Determination Concerning Collection Action under Section 6320 and/or 6330 and Attachment 3193 was sent to the petitioner. Attached and marked as Exhibit 11-J is a true and correct copy of the Notice of Determination.\
\
14\. Exhibits 1-J through 11-J constitute the administrative record in the above captioned case.\
\
15\. Attached and marked as Exhibit 12-J is a true and correct copy of a letter dated July 30, 2007, mailed to petitioner from his personal physician, Dr. \[name\], discussing petitioner’s present medical condition.\
\
16\. Attached and marked as Exhibit 13-J is a Form 4340 for petitioner’s income tax liability for tax year 2005 dated May 1, 2008.\
\
|  |\
| --- |\
|  |  |  |  |\
| Counsel for Petitioner |  | Counsel for Respondent |  |\
\
**Exhibit 35.11.1-211**\
\
### Motion to Remand in a Collection Due Process Case\
\
|  |\
| :-: |\
| **MOTION TO REMAND** |\
\
RESPONDENT MOVES that the Court remand this Collection Due Process case to the respondent's Office of Appeals for further consideration.\
\
IN SUPPORT THEREOF, respondent states:\
\
**Sample Alternative paragraphs:**\
\
1\. During the Collection Due Process (CDP) hearing, the petitioner requested a face-to-face conference at the Office of Appeals closest to his residence. The settlement officer assigned to conduct the hearing spoke by telephone to petitioner on July 1, 2007. On September 1, 2007, Appeals issued to petitioner a Notice of Determination Concerning Collection Action(s) under Section 6320 and/or 6330 upholding the notice of federal tax lien filing. The petitioner was not advised that the telephone conversation constituted his hearing, nor was he advised that his request for a face-to-face conference had been denied. Accordingly, the petitioner is entitled to a new CDP hearing, to be held as a face-to-face conference at the Atlanta Office of Appeals.\
\
1\. During the Collection Due Process (CDP) hearing, the petitioner submitted an offer-in-compromise. The settlement officer assigned to conduct the hearing rejected the offer-in-compromise as she determined that the petitioner was not in compliance with filing of all required tax returns. The settlement officer was incorrect, however, as petitioner was actually in full compliance with the filing requirements. Accordingly, this case should be remanded to the Atlanta Office of Appeals for a new CDP hearing during which petitioner’s offer-in-compromise should be reconsidered.\
\
\\* \\* \\* \* \* \* \* \* \*\
\
2\. Where respondent has abused respondent’s discretion, this Court may remand the case to the Office of Appeals to hold a new hearing, where a new hearing is necessary and will be productive. Lunsford v. Commissioner, 117 T.C. 183, 189 (2001).\
\
3\. This case should be remanded to the Office of Appeals in order that the hearing prescribed by section 6330 may be conducted with the petitioner and/or a duly authorized representative.\
\
4\. Petitioner does not object to the granting of this motion.\
\
WHEREFORE, respondent requests that this motion be granted.\
\
**Exhibit 35.11.1-212**\
\
### Notice of Determination Addressing Only Tax Liability or Collection Issues Not Sustained\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to the agreement of the parties in this case, it is |\
| ORDERED AND DECIDED: |\
| That the determinations set forth in the Notice of Determination Concerning Collection Action under Section 6320 and/or 6330 issued to petitioner on \[ _insert date of notice of determination_\], for petitioner’s \[ _insert type of tax_\] tax liability for taxable year \[ _insert year_\], and upon which this case is based, are not sustained. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision. |\
| **Insert the following paragraphs as applicable:** |\
| It is further stipulated that respondent will abate the \[ _insert type of tax_\] tax liability for taxable year \[ _insert year_\] on the basis that \[ _e.g., the assessment was not made within the applicable statute of limitations; the statutory notice of deficiency was not sent to petitioner’s last known address and petitioner did not receive it in time to file a Tax Court petition_.\]<br> -------------------- |\
| It is further stipulated that respondent will abate the balance of petitioner’s outstanding \[ _insert type of tax\]_ tax liability for taxable year \[ _insert year_\] on the basis that \[ _e.g., the statute of limitations for collection has expired; the tax liability was discharged in bankruptcy and respondent has determined that no further collection action will be taken_.\]<br> -------------------- |\
| It is further stipulated that respondent will take no further collection action with respect to the \[ _insert type of tax_\] tax liability for taxable year \[ _insert year_\]. |\
| **If the statute of limitations for assessment has not expired include the following paragraph:** |\
| It is further stipulated that the above-referenced tax liability will be abated without prejudice to respondent’s right to reassess the tax liability for taxable year \[ _insert year_\] pursuant to the deficiency procedures prescribed in the Internal Revenue Code, to the extent permitted by law. |\
\
### Note:\
\
A stipulated decision document that significantly departs from this example should be submitted to Branch 3 or 4, Procedure & Administration, for pre-review.\
\
**Exhibit 35.11.1-213**\
\
### Notice of Determination Addressing Only Tax Liability or Collection Issues Sustained in Full\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to the agreement of the parties in this case, it is |\
| ORDERED AND DECIDED: |\
| That the determinations set forth in the Notice of Determination Concerning Collection Action under Section 6320 and/or 6330 issued to petitioner on \[ _insert date of notice of determination_\], for petitioner’s \[ _insert type of tax_\] tax liability for taxable year \[ _insert year_\], and upon which this case is based, are sustained in full. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that, effective upon the entry of this decision by the Court, petitioner waives the restrictions contained in I.R.C. § 6330(e) prohibiting collection of the \[ _insert type of tax_\] tax liability (plus statutory interest) until the decision of the Tax Court becomes final. |\
| **If Supplemental Notice is issued after remand:** |\
| Pursuant to the agreement of the parties in this case, it is |\
| ORDERED AND DECIDED: |\
| That the determinations set forth in the Notice of Determination Concerning Collection Action under Section 6320 and/or 6330 issued to petitioner on \[ _insert date of notice of determination_\], for petitioner’s \[ _insert type of tax_\] tax liability for taxable year \[ _insert year_\], and upon which this case is based, as supplemented by the Notice of Determination issued on \[ _insert date of supplemental notice_\], are sustained in full. |\
\
### Note:\
\
A stipulated decision document that significantly departs from this example should be submitted to Branch 3 or 4, Procedure & Administration, for pre-review.\
\
**Exhibit 35.11.1-214**\
\
### Notice of Determination Addressing Only Tax Liability or Collection Issues Sustained in Full if Collection Alternative Agreed to Outside CDP Case\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to the agreement of the parties in this case, it is |\
| ORDERED AND DECIDED: |\
| That the determinations set forth in the Notice of Determination Concerning Collection Action under Section 6320 and/or 6330 issued to petitioner on \[ _insert date of notice of determination_\], for petitioner’s \[ _insert type of tax_\] tax liability for taxable year \[ _insert year_\], and upon which this case is based, are sustained in full. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that the collection of petitioner’s \[ _insert type of tax_\] tax liability for taxable year \[ _insert year_\] shall be closed as currently uncollectible for reason of economic hardship as provided under the conditions specified on Form 53, Report of Currently Not Collectible Taxes. |\
| OR |\
| It is further stipulated that collection of petitioner’s \[ _insert type of tax_\] tax liability for taxable year \[ _insert year_\] shall be made in accordance with the terms of the \[ _insert date of installment agreement_\] Installment Agreement entered into between the parties pursuant to the provisions of I.R.C. § 6159. |\
| OR |\
| It is further stipulated that collection of petitioner’s \[ _insert type of tax_\] tax liability for taxable year \[ _insert year_\] shall be made in accordance with the terms of the \[ _insert date of offer-in-compromise_\] Offer in Compromise entered into between the parties pursuant to the provisions of I.R.C. § 7122. |\
\
### Note:\
\
A stipulated decision document that significantly departs from this example should be submitted to Branch 3 or 4, Procedure & Administration, for pre-review.\
\
**Exhibit 35.11.1-215**\
\
### Notice of Determination – Underlying Tax Properly at Issue and No Abuse of Discretion\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to the agreement of the parties in this case, it is |\
| ORDERED AND DECIDED: |\
| That the determinations set forth in the Notice of Determination Concerning Collection Action under Section 6320 and/or 6330 issued to petitioner on \[ _insert date of notice of determination_\], for petitioner’s \[ _insert type of tax_\] tax liability for taxable year \[ _insert year_\], and upon which this case is based, are sustained \[ _insert "in full" if the underlying tax liability is not adjusted; insert "except as provided herein" if the underlying tax liability is adjusted_\]. |\
| That the tax imposed on petitioner by the Internal Revenue Code for taxable year \[ _insert year_\] is as follows : |\
|  | **Year** | **\[Insert type of tax\] Tax** | **Addition to tax I.R.C. §** | **Addition to tax I.R.C. §** |\
|  | \-\-\---- | $xxxx.xx | $xxxx.xx | $xxxx.xx |\
|  |  |  | Judge. |  |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that interest is not included in the above-referenced tax liability, and that interest will be assessed as provided by law on the tax liability. |\
| It is further stipulated that fees and collection costs related to the above referenced tax liability, and interest thereon, are not included in the tax liability and shall remain due and owing. |\
| It is further stipulated that, effective upon the entry of this decision by the Court, petitioner waives the restrictions contained in I.R.C. § 6330(e) prohibiting collection of the tax liability (plus statutory interest) until the decision of the Tax Court becomes final. |\
| **Insert if applicable:** |\
| It is further stipulated that unassessed additions to tax under I.R.C. § \[ _insert applicable code section_\] will be assessed as provided by law on the above-referenced tax liability. |\
| **Insert any of the following paragraphs as appropriate:** |\
| It is further stipulated that the above-referenced tax liability does not include a payment in the amount of \[ _insert amount_\] that was made on \[ _insert date of payment_\] and applied to petitioner’s tax liability for taxable year \[ _insert year_\]. It is further stipulated that the above-referenced tax liability does not include petitioner’s withholding credits in the amount of \[ _insert amount_\] for taxable year \[ _insert year_\]. |\
| It is further stipulated that the above-referenced tax liability does not include an advance payment of estimated tax in the amount of \[ _insert amount_\] made by petitioner on \[ _insert day of payment_\] for taxable year \[insert year\]. |\
| It is further stipulated that petitioner is entitled to an overpayment credit in the amount of \[ _insert amount_\] from his \[ _insert year_\] tax year which will be applied to petitioner’s tax liability for taxable year \[ _insert year_\]. It is further stipulated that there are no overpayments due to petitioner for taxable year \[ _insert year_\]. |\
| It is further stipulated that the amount of petitioner’s unpaid \[ _insert type of tax_\] tax liability for taxable year \[ _insert year_\] is \[ _insert amount_\]. |\
\
### Note:\
\
A stipulated decision document that significantly departs from this example should be submitted to Branch 3 or 4, Procedure & Administration, for pre-review.\
\
**Exhibit 35.11.1-216**\
\
### Notice of Determination – Underlying Tax Not at Issue, but Adjusted and No Abuse of Discretion\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to agreement of the parties in this case, it is |\
| ORDERED AND DECIDED: |\
| That the determinations set forth in the Notice of Determination Concerning Collection Action(s) under Section 6320 and/or 6330 issued to petitioner on \[ _insert date of notice of determination_\], for petitioner’s \[ _insert type of tax_\] tax liability for taxable year \[ _insert year_\], and upon which this case is based are sustained in full. |\
| Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that the tax imposed on petitioner by the Internal Revenue Code for taxable year \[ _insert year_\] is as follows: |\
| **Year** | **\[Insert type of tax\] Tax** | **Addition to tax I.R.C. §** | **Addition to tax I.R.C. §** |\
| \-\-\---- | $xxxx.xx | $xxxx.xx | $xxxx.xx |\
| It is further stipulated that interest is not included in the above-referenced tax liability, and that interest will be assessed as provided by law on the tax liability. |\
| It is further stipulated that fees and collection costs related to the above referenced tax liability, and interest thereon, are not included in the tax liability and shall remain due and owing. |\
| It is further stipulated that, effective upon the entry of this decision by the Court, petitioner waives the restrictions contained in I.R.C. § 6330(e) prohibiting collection of the tax liability (plus statutory interest) until the decision of the Tax Court becomes final. |\
| **Insert if applicable:** |\
| It is further stipulated that unassessed additions to tax under I.R.C. § \[ _insert applicable code section_\] will be assessed as provided by law on the above-referenced tax liability. |\
| **Insert any of the following paragraphs as appropriate:** |\
| It is further stipulated that the above-referenced tax liability does not include a payment in the amount of \[ _insert amount_\] that was made on \[ _insert date of payment_\] and applied to petitioner’s tax liability for taxable year \[ _insert year_\]. |\
| It is further stipulated that the above-referenced tax liability does not include petitioner’s withholding credits in the amount of \[ _insert amount_\] for taxable year \[ _insert year_\]. |\
| It is further stipulated that the above-referenced tax liability does not include an advance payment of estimated tax in the amount of \[ _insert amount_\] made by petitioner on \[ _insert day of payment_\] for taxable year \[ _insert year_\]. |\
| It is further stipulated that petitioner is entitled to an overpayment credit in the amount of \[ _insert amount_\] from his \[ _insert year_\] tax year which will be applied to petitioner’s tax liability for taxable year \[ _insert year_\]. |\
| It is further stipulated that there are no overpayments due to petitioner for taxable year \[ _insert year_\]. |\
| It is further stipulated that the amount of petitioner’s unpaid \[ _insert type of tax_\] tax for taxable year \[ _insert year_\] is \[ _insert amount_\]. |\
\
### Note:\
\
A stipulated decision document that significantly departs from this example should be submitted to Branch 3 or 4, Procedure & Administration, for pre-review.\
\
**Exhibit 35.11.1-217**\
\
### Notice of Determination Addressing CDP Issues and Interest Abatement of No Abuse of Discretion in Denial of Abatement of Interest\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to the agreement of the parties in this case, it is |\
| ORDERED AND DECIDED: |\
| \[ _Insert all appropriate paragraphs that are above the Court’s signature in Exhibits 35.11.1-214-218 for the CDP issues_.\] |\
| That petitioner is not entitled to abatement of interest under I.R.C. § 6404 with respect to taxable year \[ _insert year_\]. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision. |\
| \[ _Insert all appropriate paragraphs that are below the Court’s signature in Exhibits 35.11.1-214-218 for the CDP issues_.\] |\
\
**Use the following language if the decision concedes abatement of interest**\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to the agreement of the parties in this case, it is |\
| ORDERED AND DECIDED: |\
| That the determinations set forth in the Notice of Determination Concerning Collection Action(s) under Section 6320 and/or 6330 issued to petitioner on \[ _insert date of Notice of Determination_\], for petitioner’s \[ _insert type of tax_\] tax liability for taxable year \[ _insert year_\], and upon which this case is based, are sustained except as provided herein. |\
| \[ _Insert all appropriate paragraphs that are above the Court’s signature in Exhibits 35.11.1-214-218 for the CDP issues_\]; |\
| That interest assessed on petitioner’s \[ _insert type of tax_\] tax liability for taxable year \[ _insert year_\] will be abated under I.R.C. § 6404 for the period beginning \[ _insert date_\], and ending \[ _insert date_ \]. |\
| OR |\
| That interest will not be assessed on petitioner’s \[ _insert type of tax_\] tax liability for taxable year \[ _insert year\]_ for the period beginning \[ _insert date_\], and ending \[ _insert date_\]. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision. |\
| \[ _Insert all appropriate paragraphs that are below the Court’s signature in Exhibits 35.11.1-214-218 for the CDP issues_.\] |\
\
### Note:\
\
A stipulated decision document that significantly departs from this example should be submitted to Branch 3 or 4, Procedure & Administration, for pre-review.\
\
**Exhibit 35.11.1-218**\
\
### Notice of Determination Addressing CDP Issues and Innocent Spouse Relief\
\
**I. Use the following language if innocent spouse relief is denied.**\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to the agreement of the parties in this case, it is |\
| ORDERED AND DECIDED: |\
| \[ _Insert all appropriate paragraphs that are above the Court’s signature in Exhibits 35.11.1-214-218 for the CDP issues_.\]; |\
| That petitioner is not entitled to relief under I.R.C. § 6015 \[ _insert applicable subsection (b), (c) or (f)_\] with respect to petitioner’s joint and several income tax liability for taxable year \[ _insert year_\]. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision. |\
| \[ _Insert all appropriate paragraphs that are below the Court’s signature in Exhibits 35.11.1-214-218 for the CDP issues_.\] |\
\
**II. Use the following language if innocent spouse relief is granted.**\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to the agreement of the parties in this case, it is |\
| ORDERED AND DECIDED: |\
| That the determinations set forth in the Notice of Determination Concerning Collection Action(s) under Section 6320 and/or 6330 issued to petitioner on \[ _insert date of notice of determination_\] for petitioner’s joint and several income tax liability for taxable year \[ _insert year_\], and upon which this case is based, are not sustained; |\
| That there is no income tax due from petitioner for taxable year \[ _insert year_\], after application of I.R.C. § 6015 \[ _insert applicable subsection (b), (c), or (f)_\]; |\
| That there are no additions to tax due from petitioner under the provisions of I.R.C. § \[ _insert applicable code section_\] for taxable year \[ _insert year_\] after application of I.R.C. § 6015 \[ _insert applicable subsection (b), (c) or (f)_\]; |\
| **Insert as applicable:** |\
| That there is no overpayment in income tax due to petitioner for taxable year \[ _insert year_\]. |\
| OR |\
| That there is an overpayment in income tax for taxable year \[ _insert year_\] in the amount of \[ _insert amount_\], which was paid on \[ _insert date of payment_\] and for which amount a Form 8857 (which was treated as a claim for refund) was filed on \[ _insert appropriate date_\], which was within the period provided by I.R.C. § 6511(b)(2).\]<br> <br>### Note:<br>If there is an overpayment, also add a stipulation providing the calculation of the overpayment. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that respondent will take no further collection action with respect to the income tax liability that was assessed against petitioner on \[ _insert date of assessment_\] for taxable year \[ _insert year_\]. |\
\
**III.Use the following language if partial innocent spouse relief granted.**\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to the agreement of the parties in this case, it is |\
| ORDERED AND DECIDED: |\
| That the determinations set forth in the Notice of Determination Concerning Collection Action(s) under Section 6320 and/or 6330 issued to petitioner on \[ _insert date of notice of determination_\] for petitioner's joint and several income tax liability for taxable year \[ _insert year_\], upon which this case is based are sustained, except as provided herein. |\
| That the amount of petitioner’s liability for income tax and additions to tax for taxable year \[ _insert year_\] after application of I.R.C. § 6015 \[ _insert applicable subsection (b), (c), or (f)_\] is as follows : |\
| Year | Income Tax | Addition to Tax<br> I.R.C. § xxxx |  |\
| That there are no overpayments in income tax due to petitioner for taxable year \[ _insert year_\]. |\
|  | Judge. |  |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision. |\
| \[ _Insert all appropriate paragraphs that are below the Court’s signature in Exhibits 35.11.1-214-218 for the CDP issues._\] |\
\
**IV. Use the following language if innocent spouse relief is granted, in whole or in part, for some years, but denied for other years.**\
\
|  |\
| :-: |\
| **DECISION** |\
| Pursuant to the agreement of the parties in this case, it is |\
| ORDERED AND DECIDED: |\
| \[ _Insert all appropriate paragraphs that are below the Court’s signature in Exhibits 35.11.1-214-218 for the CDP issues_.\] |\
| That there is a liability in income tax and penalties due from the petitioner, before application of I.R.C. § 6015 \[ _insert applicable subsection (b), (c) or (f)_\], as follows: |\
| Year | Income Tax | Penalty<br> I.R.C. § xxxx |  |\
| That the following liability in income tax and penalties are due from petitioner, after application of I.R.C. § 6015 _\[insert applicable subsection (b), (c) or (f)_\]: |\
| Year | Income Tax | Penalty<br> I.R.C. § xxxx |  |\
| That there are no overpayments in income tax due to petitioner for the taxable years \[ _insert years_\]. |\
|  | Judge. |  |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is hereby stipulated that the Court may enter the foregoing decision in this case. |\
| \[ _Insert all appropriate paragraphs that are below the Court’s signature in Exhibits 35.11.1-214-218 for the CDP issues_.\] |\
\
### Note:\
\
A stipulated decision document that significantly departs from this example should be submitted to Branch 3 or 4, Procedure & Administration, for pre-review.\
\
**Exhibit 35.11.1-219**\
\
### Motion to Change Caption in Collection Due Process Case\
\
|  |\
| :-: |\
| **MOTION TO CHANGE CAPTION** |\
\
RESPONDENT MOVES that the Court enter an order correcting the caption in the above-entitled case by changing the docket number to read 1143-09"L" and designating this case as a Lien or Levy Action provided for in I.R.C. § 6320(c) or 6330(d) and T.C. Rules 330 through 334.\
\
IN SUPPORT THEREOF, respondent states:\
\
1\. In the petition, the petitioner states that she is challenging the filing of a notice of federal tax lien with respect to her 2000-2004 income tax liabilities.\
\
2\. The petition appears to be an appeal of a Notice of Determination Concerning Collection Action(s) under Section 6320 and/or 6330 issued by respondent on March 1, 2009, a copy of which is attached as Exhibit A.\
\
3\. The copy of the petition served on respondent does not include an "L" in the docket number.\
\
4\. Petitioner informed respondent that she intended to seek review of the Notice of Determination as a lien action brought under sections 6320(c) and 6330(d).\
\
5\. Petitioner does not object to the filing of this motion.\
\
WHEREFORE, it is prayed that this motion be granted.\
\
**Exhibit 35.11.1-220**\
\
### Motion to Dismiss for Mootness in a Collection Due Process Case\
\
|  |\
| :-: |\
| **MOTION TO DISMISS ON GROUND OF MOOTNESS** |\
\
RESPONDENT MOVES, pursuant to T.C. Rule 53, that this case be dismissed as moot given that, subsequent to the filing of the petition, the tax liability for taxable year 2000 has been paid in full and the proposed levy is no longer necessary.\
\
IN SUPPORT THEREOF, respondent states:\
\
1\. On August 1, 2007, respondent issued a Final Notice-Notice of Intent to Levy and Notice of Your Right to a Hearing ("CDP Notice" ) to petitioner with respect to his/her income tax liability, including penalties and interest, for taxable year 2000.\
\
2\. In response to the Final Notice, petitioner requested a collection due process ("CDP" hearing with respondent’s Office of Appeals pursuant to I.R.C. § 6330(b)(1).\
\
3\. On January 15, 2008, Appeals issued a Notice of Determination Concerning Collection Action(s) under Section 6320 and/or 6330 approving the proposed levy to collect the liability arising with respect to taxable year 2000.\
\
4\. On January 30, 2008, petitioner filed a Petition for Lien or Levy Action under Code Section 6320(c) or 6330(d) in the present case.\
\
5\. Subsequently, petitioner paid all outstanding income taxes, penalties, and interest with respect to taxable year 2000. Attached to this motion as Exhibit A is a Form 4340, Certificate of Assessments, Payments, and Other Specified Matters for taxable year 2000, that is current through May 1, 2009, which reflects this payment.\
\
6.As a result of the full payment of petitioner’s liabilities subject to the Notice of Determination, respondent no longer needs nor intends to levy to collect petitioner’s income tax liability for taxable year 2000, which gave rise to the petition in the instant case. As there is no remaining case or controversy to sustain this Court’s jurisdiction, this action is no longer justiciable. SeeGreene-Thapedi v. Commissioner, 126 T.C.1 (2006). Accordingly, this case is moot, and the petition should be dismissed.\
\
7\. Petitioner objects/does not object to the granting of this motion.\
\
WHEREFORE, it is prayed that this motion be granted.\
\
**Exhibit 35.11.1-221**\
\
### Motion to Dismiss for Lack of Jurisdiction in a CDP Case, No CDP Notice of Determination (and No Notice of Deficiency or Other Determination Issued)\
\
|  |\
| :-: |\
| **MOTION TO DISMISS FOR LACK OF JURISDICTION** |\
\
RESPONDENT MOVES, pursuant to T.C. Rule 53, that this case be dismissed for lack of jurisdiction upon the grounds that no notice of determination under I.R.C. § 6320 or 6330 was sent to petitioner for taxable year 2004, nor has respondent made any other determination with respect to taxable year 2004 that would confer jurisdiction on this Court.\
\
IN SUPPORT THEREOF, respondent states:\
\
1\. Petitioner attached to the petition a Notice of Levy. Such document, attached hereto as Exhibit A, may indicate that petitioner is seeking to invoke the Court’s jurisdiction under I.R.C. § 6330(d) in this case.\
\
2\. The Tax Court cannot acquire jurisdiction with respect to a proposed levy unless, and until, there is a determination by respondent’s Office of Appeals and the taxpayer seeks review of that determination within 30 days thereof. Offiler v. Commissioner, 114 T.C. 492, 498 (2000).\
\
3\. Respondent has diligently searched respondent’s records and has found no indication that any Notice of Determination Concerning Collection Action(s) under Section 6320 and/or 6330 was sent to petitioner with respect to taxable year 2004. Attached to this motion as Exhibit A is a Form 4340, Certificate of Assessments, Payments and Other Specified Matters for taxable year 2004, that is current through May 1, 2009.\
\
**Use the following paragraphs if decision letter is attached to the petition:**\
\
1\. Petitioner attached to the petition a Decision Letter Concerning Equivalent Hearing under Section 6320 and/or 6330 of the Internal Revenue Code. Such document, attached hereto as Exhibit A, may indicate that petitioner is seeking to invoke the Court’s jurisdiction under section 6330(d). Petitioner was issued a Decision Letter, rather than a Notice of Determination Concerning Collection Action(s) under Section 6320 and/or 6330, because he did not timely request a hearing under section 6330. Treas. Reg. § 301.6330-1(i)(1).\
\
2\. A Final Notice-Notice of Intent to Levy and Notice of Your Right to Request a Hearing under I.R.C. § 6330 (the collection due process notice, hereinafter referred to as the "CDP Notice" ) dated February 1, 2007, was sent to petitioner by certified mail on February 1, 2007, as shown by the postmark date stamped on the IRS certified mail list. Copies of the CDP Notice and IRS certified mail list, showing the date the CDP Notice was delivered to the Post Office to be sent by certified mail, are attached as Exhibits B and C, respectively.\
\
3\. Respondent received petitioner’s Request for a Collection Due Process Hearing on Form 12153 on March 15, 2007, as evidenced by respondent’s date stamp thereon. A copy of petitioner’s Request for a Collection Due Process or Equivalent Hearing is attached as Exhibit D.\
\
4\. Pursuant to section 6330(a)(3)(B) and Treas. Reg. § 301.6330-1(b)(1) petitioner must submit a written request for a hearing with respect to a CDP notice issued under section 6330 within the 30-day period commencing the day after the date of the CDP notice. Any written request for a CDP hearing should be filed with the IRS office at the address indicated on the notice. Treas. Reg. § 301.6330-1(c)(2) Q&A-C6. If the address on the CDP Notice is used and the written request is postmarked within the applicable 30-day response period, then in accordance with section 7502, the request will be considered timely even if it is not received by the correct IRS office until after the 30-day response period. Treas. Reg. § 301.6330-1(c)(2) Q&A-C4.\
\
5\. Petitioner’s request for hearing was not received within the 30-day period, and was not timely mailed.\
\
6\. A taxpayer who makes an untimely request for a CDP hearing is not entitled to a CDP hearing. Treas. Reg. § 301.6330-1(i)(1); Kennedy v. Commissioner, 116 T.C. 255 (2001). Because petitioner did not make a timely written request for a hearing under section 6330, the Office of Appeals properly held an equivalent hearing and issued a Decision Letter. Under the circumstances described above, the Tax Court lacks jurisdiction of this matter under section 6330 and T.C. Rule 330.\
\
\\*\\*\\*\*\*\*\*\*\*\*\*\*\*\
\
4\. Respondent has diligently searched respondent’s records and has determined that no other determination has been made by respondent that would confer jurisdiction on this Court.\
\
5\. Petitioner has not demonstrated that a Notice of Determination sufficient to confer jurisdiction on this Court with respect to tax year 2004 was issued by Appeals as required by section 6330(d)(1).\
\
6\. Under the circumstances described above, the Tax Court lacks jurisdiction of this matter under section 6330 and T.C. Rule 330(b).\
\
7\. Petitioner objects to the granting of this motion.\
\
WHEREFORE, respondent requests that this motion be granted.\
\
**Exhibit 35.11.1-222**\
\
### Motion to Dismiss for Lack of Jurisdiction in a CDP Case\
\
Petition Includes Taxes and/or Periods Not Included in CDP Notice of Determination (and Not Included on any Notice of Deficiency or Any Other Determination)\
\
|  |\
| :-: |\
| **MOTION TO DISMISS FOR LACK OF JURISDICTION**<br>**AND TO STRIKE AS TO TAXABLE YEAR 1997** |\
\
RESPONDENT MOVES, pursuant to T.C. Rules 52 and 53, that petitioner’s claim with respect to taxable year 1997 be dismissed upon the ground that no notice of determination under I.R.C. § 6320 or 6330 was sent to petitioner for taxable year 1997, nor has respondent made any other determination with respect to taxable year 1997 that would confer jurisdiction on this Court, and that all references to taxable year 1997 be stricken from the petition.\
\
IN SUPPORT THEREOF, respondent states:\
\
1\. Respondent sent to petitioner a Final Notice-Notice of Intent to Levy and Notice of Your Right to a Hearing (the collection due process notice, which hereinafter is referred to as the "CDP Notice" ), dated October 1, 2007, advising petitioner that respondent intended to levy to collect unpaid liabilities for taxable years 1998 through and including 2002, and that petitioner could receive a collection due process hearing with Appeals. A copy of the CDP Notice is attached hereto as Exhibit A.\
\
2\. Respondent has diligently searched respondent’s records and has found no indication that any Final Notice-Notice of Intent to levy and Notice of Your Right to a Hearing was sent to petitioner with respect to taxable year 1997. Attached to this motion as Exhibit B is a Form 4340, Certificate of Assessments, Payments, and Other Specified Matters for taxable year 1997, that is current through May 1, 2009.\
\
3\. On October 20, 2007, petitioner requested a collection due process hearing from respondent for taxable years 1997 through 2002. A copy of the Form 12153 Request for a Collection Due Process or Equivalent Hearing is attached hereto as Exhibit C.\
\
4\. On December 1, 2007, respondent sent to petitioner a Notice of Determination Concerning Collection Action(s) under Section 6320 and/or 6330, informing petitioner that she was not entitled to the relief requested. On the first page of the Notice of Determination, under the headings "Tax Type/Form Number" and Tax Period(s) Ended, income tax for taxable year 1997 is not included. Moreover, income tax for taxable year 1997 is not included in the attachment to the Notice of Determination, which describes the determinations of respondent’s Office of Appeals with respect to collection of petitioner’s tax liabilities by proposed levy. A copy of the Notice of Determination is attached hereto as Exhibit D.\
\
5\. On December 31, 2007, petitioner timely commenced the above-entitled case by filing a petition with the Court pursuant to section 6330(d) and T.C. Rule 331(a). In the petition, petitioner requests relief with respect to taxable years 1997 through 2002.\
\
6\. Respondent has diligently searched respondent’s records and has found no indication that any Notice of Determination Concerning Collection Action(s) under Section 6320 and/or 6330 was sent to petitioner with respect to taxable year 1997.\
\
7\. Respondent has diligently searched respondent’s records and has determined that no other determination has been made by respondent that would confer jurisdiction on this Court.\
\
8\. Petitioner has not demonstrated that a notice of determination sufficient to confer jurisdiction on this Court with respect to taxable year 1997 was issued by respondent’s Office of Appeals as required by section 6330(d)(1).\
\
9\. Under the circumstances described above, the Tax Court lacks jurisdiction of this matter.\
\
10\. Petitioner objects to the granting of this motion.\
\
WHEREFORE, respondent requests that this motion be granted.\
\
**Exhibit 35.11.1-223**\
\
### Motion to Dismiss for Lack of Jurisdiction in a CDP Case, Invalid Notice of Determination\
\
(Because No CDP Lien or Levy Notice Was Issued For Certain Taxes and Periods Listed in Notice of Determination, and No Notice of Deficiency or Other Determination Has Been Issued for Such Taxes and Periods)\
\
|  |\
| :-: |\
| **MOTION TO DISMISS FOR LACK OF JURISDICTION**<br>**AND TO STRIKE AS TO TAXABLE YEAR 1997** |\
\
RESPONDENT MOVES, pursuant to T.C. Rules 52 and 53, on the grounds that the Notice of Determination Concerning Collection Action(s) under Section 6320 and/or 6330 sent to petitioner for taxable year 1997 is invalid and cannot confer jurisdiction on this Court under I.R.C. § 6320(c) or 6330(d), nor has respondent made any other determination with respect to taxable year 1997 that would confer jurisdiction on this Court, and that all references to taxable year 1997 be stricken from the petition.\
\
IN SUPPORT THEREOF, respondent respectfully states:\
\
1\. Respondent sent to petitioner a Final Notice-Notice of Intent to Levy and Notice of Your Right to a Hearing (the collection due process notice, hereinafter referred to as the "CDP Notice" ), dated October 1, 2007, advising petitioner that respondent intended to levy to collect unpaid liabilities for 1998 through and including 2002, and that petitioner could receive a hearing with respondent’s Office of Appeals. A copy of the CDP Notice is attached hereto as Exhibit A.\
\
2\. Respondent has diligently searched respondent’s records and has found no indication that any Final Notice-Notice of Intent to Levy and Notice of Your Right to a Hearing was sent to petitioner with respect to taxable year 1997. Attached to this motion as Exhibit B is a Form 4340, Certificate of Assessments, Payments, and Other Specified Matters for taxable year 1997 that is current through May 1, 2009.\
\
3\. On October 20, 2007, petitioner requested a collection due process hearing from respondent for taxable years 1997 through 2002. A copy of the Form 12153 Request for a Collection Due Process or Equivalent Hearing is attached hereto as Exhibit C.\
\
4\. On June 1, 2008, respondent sent to petitioner a Notice of Determination Concerning Collection Action(s) under Section 6320 and/or 6330, informing petitioner that he was not entitled to the relief requested. A determination with respect to the collection of petitioner’s liability for taxable year 1997 was erroneously included in the Notice of Determination. The attachment to the Notice of Determination, however, recognizes that the CDP Notice was only for the tax years 1998 through 2002. A copy of the Notice of Determination is attached hereto as Exhibit D.\
\
5\. On June 20, 2008, petitioner timely commenced the above-entitled case by filing a petition with the Court pursuant to section 6330(d) and T.C. Rule 331(a).\
\
6\. Section 6330(c)(2)(A) provides that during the collection due process hearing (the "CDP hearing" ) with Appeals, the taxpayer may raise "any relevant issue relating to the unpaid tax or the proposed levy...."\
\
7\. Treas. Reg. § 301.6330-1(e)(1) provides that the taxpayer may raise any relevant issue relating to the unpaid tax during the CDP hearing process and the taxpayer also may raise "challenges to the existence or amount of the tax liability for any tax period shown on the CDP Notice if the taxpayer did not receive a statutory notice of deficiency for that tax liability or did not otherwise have an opportunity to dispute that tax liability." (Emphasis added.)\
\
8\. Thus, petitioner was not entitled to make any challenges with respect to taxable year 1997 on his Request for a Collection Due Process Hearing or as part of his CDP hearing, because that taxable year was not shown on the CDP Notice. The fact that the appeals officer erroneously included taxable year 1997 in the Notice of Determination, and made a determination with respect to this taxable year does not entitle petitioner to judicial review thereof. Cf. Treas. Reg. § 301.6330-1(e)(3) Q&A-E11; Behling v. Commissioner, 118 T.C. 572 (2002). See alsoWilson v. Commissioner, 131 T.C. 47 (2008) (written determination purporting to be a Notice of Determination that could be petitioned to Tax Court was not subject to judicial review where the attached appeals case memorandum established that the taxpayer had received an equivalent hearing because of untimely hearing request and could not petition the Tax Court).\
\
9\. Because it was improper for petitioner to challenge in the CDP hearing the collection of his 1997 tax liabilities, this Court does not have jurisdiction over that taxable year in the judicial review of the Notice of Determination.\
\
10\. Respondent has diligently searched respondent’s records and has determined that no other determination has been made by respondent that would confer jurisdiction on this Court.\
\
11\. Petitioner objects to the granting of this motion.\
\
WHEREFORE, respondent requests that this motion be granted.\
\
**Exhibit 35.11.1-224**\
\
### Motion to Dismiss for Lack of Jurisdiction in a CDP Case, Late-Filed Petition\
\
|  |\
| :-: |\
| **MOTION TO DISMISS FOR LACK OF JURISDICTION** |\
\
RESPONDENT MOVES, pursuant to T.C. Rule 53, that this case be dismissed for lack of jurisdiction upon the ground that the petition was not filed within the time prescribed by I.R.C. § 6330(d) or § 7502.\
\
IN SUPPORT THEREOF, respondent states:\
\
1\. The Notice of Determination Concerning Collection Action(s) under Section 6320 and/or 6330 dated June 1, 2008, upon which the above-entitled case is based, was sent to petitioner at her last known address by certified mail on June 1, 2008, as shown by the postmark date stamped on the IRS certified mail list, a copy of which is attached hereto as Exhibit A.\
\
2\. The 30-day period for timely filing a petition with this Court from the Notice of Determination expired on Tuesday, July 1, 2008, which date was not a legal holiday in the District of Columbia.\
\
3\. The petition was filed with the Tax Court on August 1, 2008, which date is 61 days after the mailing of the Notice of Determination.\
\
4\. The copy of the petition served upon respondent bears a notation that the petition was mailed to the Tax Court on July 11, 2008, which date is 40 days after the mailing of the Notice of Determination.\
\
5\. The petition was not filed with the Court within the time prescribed by sections 6330(d) or 7502.\
\
6\. Petitioner objects to the granting of this motion.\
\
WHEREFORE, it is prayed that this motion be granted.\
\
**Exhibit 35.11.1-225**\
\
### Remand Memorandum to Appeals in a Collection Due Process Case\
\
|  | **Office of Chief Counsel**<br>**Internal Revenue Service**<br>**m e m o r a n d u m**<br> \[insert org symbols; name\]<br> TL-\[insert number\] |\
| --- | --- |\
| date: | \[Insert date\] |\
| to: | IRS – Appeals |\
| from: | \[insert name, title, organization\] |\
| subject: | Remand of CDP case for Supplemental Hearing<br> Jane Doe v. Commissioner<br> Docket No. \[insert number\] |\
|  | As indicated by the attached Order, the Tax Court has remanded this case for a supplemental CDP hearing, the scope of which is detailed in the attached Motion for Remand. |\
|  | Verification of Validity of Assessments |\
|  | To comply with the court’s order, the assigned settlement officer (SO) must verify that the Notices of Deficiency (SNDs) for the 1999-2006 tax years were (1) actually mailed; and (2) mailed to petitioner’s last known address at the times the notices were issued. Reliance on computer transcripts alone to determine whether each SND was mailed to petitioner’s last known address is insufficient because petitioner used more than one address on documents filed with the Service during the relevant periods. The SO should obtain (if not already in the administrative file) the SNDs, the certified mail lists showing the mailing of the SNDs, and the document(s) upon which the Service determined that the addresses shown on the SNDs constituted petitioner’s last known address at the appropriate times. The SO should explain in the Supplemental Notice of Determination (Letter 3978) how he determined that each SND was mailed to the last known address, referencing the source document(s). If any SND, related certified mail list, or source document is unavailable, the SO should explain in the Letter 3978 how he otherwise determined that the SND in question was (1) mailed; (2) mailed to the last known address. |\
|  | Offer in Compromise |\
|  | The court order also requires remand for purposes of allowing petitioner to submit a collection alternative. In the original CDP hearing, Appeals erroneously failed to consider requested financial information which was timely submitted but did not reach the SO in time due to an office error in routing the mail. |\
|  | The Court directed Appeals to conduct the supplemental CDP hearing no later than January 15, 2013. The hearing should be held at the Appeals office located closest to the petitioner’s residence (or some other place as mutually agreed upon, at a reasonable and mutually agreed upon date and time, but no later than January 15, 2013). If additional time is needed to locate any missing records, please advise by late December and I will file a motion asking the Court for additional time to conduct the hearing. The Court has also requested that the parties provide status reports by February 15, 2013. |\
|  | If you or the SO have any questions, please feel free to call me at 555-666-9999. Please ensure the SO sends me a copy of the draft Letter 3978 before issuance to review for compliance with the order, and in sufficient time for me to prepare my status report. |\
|  |  |  |  |\
|  |  | \[insert name<br> title<br> organization\] |\
|  | Enclosures (3):<br> Tax Court Order dated November 15, 2012<br> Tax Court Opinion<br> Administrative File |\
|  | cc: without attachments<br> \[Taxpayer’s representative |\
\
**Exhibit 35.11.1-226**\
\
### Motion for Summary Judgment in a CDP Case, IRC 6330(c)(2)(B)\
\
|  |\
| :-: |\
| **MOTION FOR SUMMARY JUDGMENT** |\
\
RESPONDENT MOVES, pursuant to T.C. Rule 121, for summary adjudication in respondent's favor, because, pursuant to I.R.C. § 6330(c)(2)(B), petitioner’s receipt of the statutory notice of deficiency precludes her from challenging the underlying tax liability for taxable year 2004, the only error assigned in the petition.\
\
IN SUPPORT THEREOF, respondent states:\
\
1\. The pleadings in this case were closed on February 1, 2009. This motion is made at least 30 days after the date that the pleadings in this case were closed and within such time as not to delay the trial. T.C. Rule 121(a).\
\
2\. Filed with this motion is a declaration by \[name\], the settlement officer in respondent’s Office of Appeals who conducted petitioner’s collection due process ("CDP" ) hearing, setting out the relevant documents contained in the administrative record from the CDP hearing.\
\
3\. Attached to this motion as Exhibit A is a Form 4340, Certificate of Assessments, Payments, and Other Specified Matters for taxable year 2004, that is current through May 1, 2009.\
\
4\. Respondent sent to petitioner a Final Notice - Notice of Intent to Levy and Notice of Your Right to a Hearing (the collection due process notice, hereinafter referred to as the "CDP Notice" ), dated March 1, 2008, advising petitioner that respondent intended to levy to collect her unpaid liabilities for taxable year 2004, and offering the petitioner an opportunity for a hearing with respondent’s Office of Appeals. Declaration Exhibit A.\
\
5\. Petitioner timely filed Form 12153, Request for a Collection Due Process or Equivalent Hearing, on March 30, 2008. Declaration Exhibit B.\
\
6\. Respondent sent to petitioner a Notice of Determination Concerning Collection Action(s) under Section 6320 and/or 6330, dated September 1, 2008, sustaining the proposed levy with respect to petitioner’s income tax liability for tax year 2004. Declaration Exhibit E.\
\
7\. In her petition, petitioner argues that the settlement officer erred in determining that she could not challenge the existence of the underlying tax liability. Pursuant to section 6330(c)(2)(B), petitioner cannot raise during the CDP hearing the existence or amount of the underlying tax liability if petitioner received a statutory notice of deficiency for that tax liability.\
\
8\. Pursuant to section 6330(c)(1), the settlement officer conducting a CDP hearing is required to verify compliance with all requirements of applicable law or administrative procedures. In cases involving deficiency assessments, such verification includes determining whether the statutory notice of deficiency was properly issued. Hoyle v. Commissioner, 131 T.C. 197 (2008).\
\
9\. The Form 4340 transcript attached to this motion as Exhibit A shows that the assessment for the 2004 year was made following the default of a statutory notice of deficiency. The Notice of Determination attached as Declaration Exhibit E describes the documents reviewed by Settlement Officer \[name\] to confirm the validity of that assessment. Those documents are also attached as exhibits to her declaration. Respondent properly mailed the statutory notice of deficiency to the petitioner’s last known address on September 1, 2005. A copy of the notice of deficiency for taxable year 2004 sent to petitioner’s residence on September 1, 2005, is attached hereto as Declaration Exhibit F. Also attached is an IRS certified mail list showing that the notice of deficiency for 2004 was mailed to petitioner’s residence on September 1, 2005. Declaration Exhibit G. Accordingly, the administrative record in this case shows that the settlement officer properly verified that the assessment for the 2004 year was properly made following issuance of a statutory notice of deficiency to the petitioner’s last known address.\
\
10\. While proper issuance of a statutory notice of deficiency is the relevant inquiry for purposes of verifying the validity of an assessment, for purposes of determining whether a taxpayer can raise liability under section 6330(c)(2)(B), actual receipt of the statutory notice must be determined. Treas. Reg. § 301.6330-1(e)(3) Q&A-E2 provides that receipt of a statutory notice of deficiency for purposes of section 6330(c)(2)(B) means receipt in time to petition the Tax Court for a redetermination of the deficiency asserted in the notice of deficiency. Respondent is entitled to rely upon presumptions of official regularity and delivery where the record reflects proper mailing of the statutory notice of deficiency. Sego v. Commissioner, 114 T.C. 604, 610 (2000); Bailey v. Commissioner, T.C. Memo. 2005-241. There is no evidence that the statutory notice of deficiency was returned to the Service, nor has petitioner ever denied its receipt. Thus, the presumptions of official regularity and delivery have not been rebutted. Bailey v. Commissioner, supra.\
\
11\. The presumptions of official regularity and delivery establish that the petitioner received the statutory notice of deficiency in sufficient time to petition the Tax Court. Thus, Appeals properly determined that the petitioner could not raise underlying liability.\
\
12\. Because it was improper for the petitioner to challenge in the CDP hearing the existence or amount of petitioner’s liability with respect to taxable year 2004, the validity of petitioner’s underlying tax liability is not properly at issue before this Court. Sego v. Commissioner, 114 T.C. 604 (2000).\
\
13\. The petitioner raises no issues other than that she should be permitted to challenge the existence of the underlying tax liability. Pursuant to T.C. Rule 331(b)(4), all other issues are deemed conceded. Lunsford v. Commissioner, 117 T.C. 183 (2001).\
\
14\. Respondent states that counsel of record has reviewed the administrative file, the pleadings, and all written proof submitted, and, on the basis of this review, concludes that there is no genuine issue of any material fact for trial.\
\
15\. Petitioner objects to the granting of this motion.\
\
WHEREFORE, it is prayed that this motion be granted.\
\
**Exhibit 35.11.1-227**\
\
### Motion for Summary Judgment in a CDP Case, Abuse of Discretion Issues\
\
|  |\
| :-: |\
| **RESPONDENT’S MOTION FOR SUMMARY JUDGMENT**<br>**AND TO IMPOSE A PENALTY UNDER I.R.C. § 6673** |\
\
RESPONDENT MOVES, pursuant to T.C. Rule 121, for summary adjudication in respondent's favor upon all issues presented in this case.\
\
RESPONDENT FURTHER MOVES that the Court impose a penalty in an appropriate amount, pursuant to I.R.C. § 6673, as petitioner has instituted these proceedings primarily for the purpose of delay and petitioner's position in the present case is frivolous and groundless.\
\
IN SUPPORT THEREOF, respondent states:\
\
1\. The pleadings in this case were closed on February 1, 2009. This motion is made at least 30 days after the date that the pleadings in this case were closed and within such time as not to delay the trial. T.C. Rule 121(a).\
\
2\. Filed with this motion is a declaration by \[name\], the settlement officer in respondent’s Office of Appeals who conducted petitioner’s collection due process ("CDP" ) hearing, setting out the relevant documents contained in the administrative record from the CDP hearing.\
\
3\. Attached to this motion as Exhibit A is a Form 4340, Certificate of Assessments, Payments, and Other Specified Matters for taxable year 2000, that is current through May 1, 2009.\
\
4\. Petitioner filed an income tax return for taxable years 2000. Respondent conducted an examination of the return for taxable year 2000. On February 1, 2002, respondent sent a statutory notice of deficiency to petitioner, proposing a tax liability. Declaration Exhibit A. As petitioner did not petition the Tax Court with respect to the proposed liability, on June 1, 2002, respondent assessed the tax liability, along with additions to tax and interest. Declaration Exhibit B.\
\
5\. Respondent sent to petitioner a Final Notice-Notice of Intent to Levy and Notice of Your Right to a Hearing (the collection due process notice, hereinafter referred to as the "CDP Notice" ), dated September 1, 2002, advising petitioner that respondent intended to levy to collect unpaid liabilities for taxable year 2000, and that petitioner could receive a hearing with respondent’s Office of Appeals. Declaration Exhibit C.\
\
6\. On September 15, 2002, petitioner submitted a Form 12153, Request for a Collection Due Process or Equivalent Hearing. Declaration Exhibit D.\
\
7\. On March 1, 2003, a telephone conference was held between Settlement Officer \[name\] and petitioner. Declaration Exhibit E.\
\
8\. After the conference, the settlement officer provided petitioner with a copy of the Form 4340 transcript for petitioner's tax liability for taxable year 2000. Declaration Exhibit F.\
\
9\. On April 1, 2003, Appeals issued to petitioner a Notice of Determination Concerning Collection Action(s) under Section 6320 and/or 6330. Declaration Exhibit G.\
\
10\. On April 15, 2003, petitioner filed with this Court a Petition for Lien or Levy Action under Code Section 6230(c) or 6330(d).\
\
11\. When the underlying tax liability is properly at issue, the Court decides the issue of liability de novo. Sego v. Commissioner, 114 T.C. 604, 610 (2000). The Court reviews the Office of Appeals’ administrative determination regarding nonliability issues for an abuse of discretion. Goza v. Commissioner, 114 T.C. 176 (2000). Since petitioner has not raised any liability issues, the determination should be reviewed for abuse of discretion.\
\
12\. In his petition, petitioner argues that the settlement officer did not produce documents which show a valid assessment was made. The settlement officer, however, provided petitioner with a copy of a Form 4340 transcript of his account. Declaration Exhibit H. This transcript identifies the taxpayer, the character of the liability assessed, the taxable period and the amount of the assessment. Absent a showing of irregularity, a Form 4340 is sufficient to establish that a valid assessment was made. Nestor v. Commissioner, 118 T.C. 162 (2002). As petitioner does not allege that there were any irregularities in the assessment procedure, petitioner’s argument that there was no valid assessment has no merit.\
\
13\. Pursuant to section 6330(c)(3), the determination of an appeals officer must take into consideration (A) the verification that the requirements of applicable law and administrative procedures have been met, (B) issues raised by the taxpayer, and (C) whether any proposed collection action balances the need for the efficient collection of taxes with the legitimate concern of the person that any collection be no more intrusive than necessary. As stated in the attachment to the Notice of Determination, attached as Declaration Exhibit I, the settlement officer considered all three of these matters. The settlement officer fully responded to petitioner's challenges to the proposed collection action at the collection due process hearing. Because the settlement officer fully complied with the requirements of section 6330(c)(3), particularly in responding to the issues raised by petitioner, there was no abuse of discretion.\
\
14\. Section 6673(a)(1) authorizes the Tax Court to impose a penalty, not in excess of $25,000, on a taxpayer, if it appears that the taxpayer has instituted or maintained a proceeding primarily for delay, or that the taxpayer’s position in the proceeding is frivolous or groundless. I.R.C. § 6673(a). In collection due process proceedings, this Court has imposed the penalty when petitioner raises frivolous and groundless arguments with respect to the legality of the federal tax laws. Burke v. Commissioner, 124 T.C. 189 (2005).\
\
15\. In his request for a hearing and his petition, petitioner argues that the income tax is unconstitutional and may only be imposed against federal employees. These allegations establish that petitioner is using the collection due process proceedings as a vehicle to raise frivolous and groundless arguments against the federal income tax system. Petitioner was warned that the Tax Court may impose a penalty for such arguments by the settlement officer in a letter sent to petitioner dated October 30, 2002. Declaration Exhibit J.\
\
16\. Respondent states that counsel of record has reviewed the administrative file, the pleadings, and all written proof submitted, and, on the basis of this review, concludes that there is no genuine issue of any material fact for trial.\
\
17\. Petitioner objects to the granting of this motion.\
\
WHEREFORE, it is prayed that this motion be granted.\
\
**Exhibit 35.11.1-228**\
\
### Declaration in Support of Motion for Summary Judgment in a CDP Case\
\
|  |\
| :-: |\
| **DECLARATION OF \[NAME OF APPEALS OFFICER\]** |\
| I, \[name\], declare: |\
| 1\. I am a settlement officer employed in the Atlanta, Office of Appeals, Internal Revenue Service, Department of the Treasury, who was assigned to petitioner’s appeal under I.R.C. § 6330 of the Service’s proposed collection action with respect to petitioner’s unpaid liabilities for taxable year 2004. |\
| 2\. Pursuant to this assignment, I made the determination under section 6330(c)(3) to permit the collection action to proceed. The reasons for, and the facts underlying, my determination are found in the Notice of Determination, dated September 1, 2008, a true and correct copy of which is attached hereto as **Exhibit E**. |\
| 3\. My determination was made after a telephone conference with petitioner on May 1, 2008, and after reviewing the following documents, true and correct copies of which are marked as exhibits, and attached to this declaration: |\
| **Exhibit A**: Letter 1058, Final Notice-Notice of Intent to Levy and Notice of Your Right to a Hearing, dated March 1, 2008, issued to petitioner for collection of her unpaid tax liabilities for taxable year 2004. |\
| **Exhibit B**: Form 12153, Request for a Collection Due Process or Equivalent Hearing, filed by petitioner and received by respondent on April 10, 2008. |\
| **Exhibit C**: Letter, dated April 15, 2008, to petitioner scheduling a telephone conference. |\
| **Exhibit D**: TXMOD-A transcript, dated May 1, 2008. |\
| **Exhibit E**: Notice of Determination Concerning Collection Action(s) under Section 6320 and/or 6330, dated September 1, 2008. |\
| **Exhibit F**: Statutory Notice of Deficiency for 2004 taxable year, dated September 1, 2005. |\
| **Exhibit G**: IRS Certified Mail List bearing USPS date of September 1, 2005. |\
| Pursuant to 28 U.S.C. §1746, I declare under penalty of perjury that the foregoing is true and correct. |\
| Executed on |  |  |  |  |\
|  |  |  | \[name\] |  |\
\
**Exhibit 35.11.1-229**\
\
### Motion to Permit Levy in a Collection Due Process Case\
\
|  |\
| :-: |\
| **RESPONDENT’S MOTION TO PERMIT LEVY** |\
\
RESPONDENT MOVES, pursuant to Tax Court Rule 50(a) and I.R.C. § 6330(e)(2), that the Court remove the suspension of the levy under I.R.C. § 6330(e)(1) as the underlying tax liability is not at issue and respondent has shown good cause for the removal of the suspension of the levy.\
\
IN SUPPORT THEREOF, respondent states:\
\
1\. Section 6330(e)(1) provides, in pertinent part, that, except as provided in paragraph (2), if a hearing is requested under section 6330(a)(3)(B), the levy actions which are the subject of the requested hearing "shall be suspended for the period during which such hearing, and appeals therein, are pending." Paragraph 2 of section 6330(e) provides that: "Paragraph (1) shall not apply to a levy action while an appeal is pending if the underlying tax liability is not at issue in the appeal and the court determines that the Secretary has good cause not to suspend the levy."\
\
2\. In the present case, the underlying tax liabilities for 2000-2004 are not at issue. Petitioner failed to file a valid tax return for 2000-2004 reporting his income. Petitioner received the Statutory Notice of Deficiency for 2000-2004 and petitioned the Tax Court. This case was dismissed for lack of prosecution on January 10, 2007, in favor of respondent after petitioner raised frivolous arguments that his income is not taxable at T.C. Memo. 2007-10.\
\
3\. In the present levy review case, petitioner has made only frivolous or groundless assertions challenging the validity of the assessments. The assessments with respect to the taxable years in this case were valid. Copies of the Forms 4340 were reviewed and provided to petitioner reflecting that assessments were properly made and notices and demands for payment were mailed to petitioner for each of the taxable years at issue.\
\
4\. Respondent submits that "good cause" clearly exists to remove the suspension upon levy in this case, in accordance with section 6330(e)(2). SeeBurke v. Commissioner, 124 T.C. 189 (2005). The purpose of the collection due process statutes, sections 6320 and 6330, is to provide taxpayers with a forum to raise relevant issues with respect to a proposed levy or notice of federal tax lien. I.R.C. § 6330(c)(2)(A); Internal Revenue Service Restructuring and Reform Act of 1998, H.R. Conf. Rep. No. 105-599, 105 Cong., 2d Sess., 263-267 (1998). Petitioner is not using the collection due process statutes for this purpose. Rather, petitioner is using the collection due process statutes solely as a mechanism to delay collection. As noted supra, petitioner has continued to waste judicial resources, after numerous warnings, by continuing to pursue frivolous and groundless arguments which have been rejected numerous times by this and other courts. If the motion is granted, respondent will be able to immediately commence levies instead of having to wait until this Court’s decision is final and/or all appeals by petitioner are exhausted.\
\
5\. In sum, all of the aforementioned facts establish good cause for the Court to issue an Order permitting levy under section 6330(e)(2). We request this motion be handled expeditiously, to minimize any further unnecessary delays in collection. An order or decision disposing of this case on the merits will not moot Respondent’s request because permission to levy would enable Respondent to proceed with levy during the period in which petitioner may file an appeal and while any appeal is pending.\
\
6\. Respondent is filing simultaneously with this motion a Motion for Summary Judgment and to Impose a Penalty under I.R.C. Section 6673.\
\
7\. Petitioner objects to this motion.\
\
**Exhibit 35.11.1-230**\
\
### Motion in Limine in Collection Due Process Case\
\
|  |\
| :-: |\
| **RESPONDENT’S MOTION IN LIMINE TO EXCLUDE EVIDENCE**<br>**NOT CONTAINED IN THE ADMINISTRATIVE RECORD** |\
\
PURSUANT TO Tax Court Rules 50(a) and 143(a), respondent hereby moves that the Court not permit the admission of the testimony of Mr. \[name\] on the grounds that Mr. \[name\]’s testimony constitutes evidence outside of the administrative record and is not relevant as to whether the settlement officer abused her discretion.\
\
IN SUPPORT THEREOF, respondent states:\
\
1\. On February 1, 2007, respondent issued petitioner a Notice of Determination Concerning Collection Action(s) Under Section 6320 and/or 6330 (hereinafter, "Notice of Determination" ), which sustained a proposed levy for petitioner’s income tax liabilities for the years 2000-2005. Petitioner timely filed a petition with the Tax Court on February 28, 2007, contesting the Notice of Determination.\
\
2\. In his petition, petitioner does not challenge the underlying tax liabilities. Therefore, the Court reviews the Notice of Determination for an abuse of discretion. **Goza v. Commissioner**, 114 T.C. 176 (2000).\
\
3\. The First, Eighth and Ninth Circuits have held that Tax Court review of nonliability issues arising under sections 6320 and 6330 is limited to the administrative record. Keller v. Commissioner, 568 F.3d 710, 718 (9th Cir. 2009); Murphy v. Commissioner, 469 F.3d 27 (1st Cir. 2006), aff’g 125 T.C. 301 (2005); Robinette v. Commissioner, 439 F.3d 455 (8th Cir. 2006), rev’g 123 T.C. 85 (2004). Respondent urges the Court to adopt the record rule as enunciated by the First, Eighth and Ninth Circuits in this case.\
\
4\. In cases arising under section 6330 of the Internal Revenue Code, the administrative record consists of all of the information the settlement officer reviewed in making her determination. Treas. Reg. §§ 301.6320-1(f)(2) Q&A F4; 301.6330-1(f)(2) Q&A F4. Attached as Exhibit A to this motion is a declaration from the settlement officer attaching the complete administrative record in this case.\
\
5\. In his Trial Memorandum, petitioner lists Mr. \[name\] as a witness that petitioner expects to call at the trial in this case. Respondent anticipates that Mr. \[name\] will testify as to events and circumstances that occurred subsequent to the settlement officer’s determination to proceed with collection in this case, or to facts and matters that were not considered by the settlement officer.\
\
6\. Evidence outside of the administrative record may be admissible if the administrative record does not adequately explain the basis of the agency determination or if there is a dispute over what happened during the hearing process. Murphy v. Commissioner, 125 T.C. 301 (2005), aff’d, 469 F.3d 27 (1st Cir. 2006) (new evidence regarding an irregularity in the conduct of a hearing or some defect in the record may be presented at trial, even if the record rule is applicable); Robinette v. Commissioner, 439 F.3d 455, 461 (8th Cir. 2006) ("Of course, where a record created in informal proceedings does not adequately disclose the basis for the agency’s decision, then it may be appropriate for the reviewing court to receive evidence concerning what happened during the agency proceedings" ) (citation omitted). The administrative record in this case, however, not only completely discloses all of the factors that the settlement officer considered in making her determination but also confirms that she did not omit any relevant factor required to make such determination, and the petitioner has failed to allege material facts or otherwise make a prima facie showing that any exceptions to the record rule applies.\
\
7\. The testimony offered by petitioner should also be excluded because it is not admissible under the Federal Rules of Evidence. In particular, the evidence is not relevant as required by Federal Rule of Evidence 401, as it does not have a tendency to make the existence of any fact that is of consequence in determining whether the settlement officer abused his or her discretion more probable or less probable than it would be without the evidence. Evidence that the petitioner had an opportunity to present but failed to produce at the CDP hearing is not relevant to the question of whether the settlement officer abused her discretion. _See_ Murphy v. Commissioner, 125 T.C. 301 (2005), aff’d, 469 F.3d 27 (1st Cir. 2006).\
\
WHEREFORE, respondent requests that this motion be granted.\
\
**Exhibit 35.11.1-231**\
\
### Answer — Affirmative Allegations: Civil Fraud Penalty — Collateral Estoppel of Certain Issues After a Criminal Conviction under IRC 7206(1)\
\
8\. FURTHER ANSWERING the petition, and in support of the determination that a part of the underpayment of tax required to be shown on petitioner's income tax return for the taxable year \[year\] is due to fraud, respondent affirmatively relies upon the doctrine of collateral estoppel (issue preclusion), and alleges:\
\
(a) \[Name\], petitioner herein, is the same person who was the defendant in the criminal case of United States of America v. \[name\] \[court, Docket No.\]. The judgment entered in that case became final on \[date\].\
\
(b) Respondent is a party in privity with the United States of America, the prosecuting party in the criminal case described above in which petitioner was the defendant.\
\
(c) The indictment filed on \[date\], in that criminal case, set forth the following charge against petitioner:\
\
THE GRAND JURY CHARGES:\
\
|  |\
| --- |\
|  |  | That on or about \[date\], in \[city\], \[state\], \[name\], a resident of \[city\], \[state\], did willfully make and subscribe a U.S. Individual Income Tax Return for the calendar year \[year\], which was verified by a written declaration that it was made under the penalties of perjury and was filed with the Internal Revenue Service, at \[city\], \[state\], which said income tax return he \[she\] did not believe to be true and correct as to every material matter in that the said return reported \[state each false item of income reported, _e.g._ dividend income in the amount of $, interest income in the amount of $,\] whereas, as he \[she\] then and there well knew and believed, he \[she\] received \[state each item\] in addition to that heretofore stated; in violation of Title 26, United States Code, Section 7206(1). |\
\
(d) Petitioner on \[date\], entered a plea of guilty to the charge set forth against him \[her\] in the indictment.\
\
(e) On \[date\], the United States District Court entered its judgment pursuant to the guilty plea, a certified copy of which is attached hereto as Exhibit A.\
\
(f) Among the issues of fact determined in the criminal case was whether petitioner did in fact willfully and knowingly file a false income tax return for the taxable year \[year\], and whether he \[she\] did in fact by such means understate his \[her\] income for that year.\
\
(g) One of the issues in the instant case is whether the addition to the tax imposed by section 6663(a) should be imposed against petitioner for the taxable year \[year\].\
\
(h) An issue in the instant case is the same as an issue which was presented and determined adversely to petitioner in the criminal case to the extent that the imposition of the addition to the tax against petitioner for the taxable year \[year\], under section 6663(a), and the judgment of conviction of petitioner for violation of section 7206(1), are each dependent upon findings that petitioner for that taxable year did in fact willfully and knowingly file a false income tax return for that year and that he \[she\] did in fact by such means understate a part of the income realized by him \[her\] for that year.\
\
(i) The prior criminal conviction of petitioner under section 7206(1) for the taxable year \[year\] is conclusive and binding on petitioner, and by reason thereof petitioner is estopped in the instant case, under the doctrine of collateral estoppel (issue preclusion), from denying that he \[she\] willfully and knowingly filed a false income tax return for the taxable year \[year\] and that the return understated income.\
\
WHEREFORE, respondent prays that . . .\
\
( _x_) the court determine that for taxable year \[year\] petitioner is estopped under the doctrine of collateral estoppel (issue preclusion) from denying that petitioner did willfully and knowingly file a false income tax return and by such means understated income for that year.\
\
**Exhibit 35.11.1-232**\
\
### Request For Translation\
\
|  | For Translator’s use only: | Translation Number<br> Number of pages<br> Languages<br> Date R’cd Date R’tnd<br> Hours<br> Notes |\
| --- | --- | --- |\
| **REQUEST FOR TRANSLATION** |\
| Requestor Name \_\_ Position Title \_ |\
| Case Name \_\_\_\_ |\
| Type of Case \_\_\_ |\
| Office Name \_\_ Office Symbols \_\_ |\
| Phone\_ Fax \_ Email \_\_ |\
| Mailing Address \_\_\_\_ |\
| \\_\\_\\_\_\_\_ |\
| Date Submitted \_\_ Return Date Desired \_\_ |\
| What type of translation do you need? Full \[ \] Partial \[ \] Rough Draft \[ \] Summary \[ \] |\
| Explain Partial / Summary: \_\_\_\_ |\
| \\_\\_\\_\_\_\_ |\
| **PLEASE NOTE: Translation requests are limited to 10 pages.** Please give a description and explanation of any background information attached: |\
| \\_\\_\\_\_\_\_ |\
| NOTE: FOR FIRST TIME USERS OF THIS SERVICE, HOW DID YOU LEARN ABOUT IT? |\
| \\_\\_\\_\_\_\_ |\
| If mailing your item, please send a copy\* of the document, not the original, to: |\
| By Mail:<br> Internal Revenue Service<br> Office of the Deputy Commissioner, International<br> Attn: Office of Tax Treaty, SE:LM:IN:T:1<br> 1111 Constitution Avenue, NW<br> Washington, DC 20224 | By Fax:<br> (202) 435-5049 |\
| \\* _The copy of your document will not be returned but will be kept for 6 months and then destroyed._ |\
| **LANGUAGES TRANSLATED: French, German, Italian, Portuguese, and Spanish into English only** For languages other than these, arrangements to contact a translator outside of IRS may need to be made. See CCDM 35.4.5.9. |\
\
**Exhibit 35.11.1-233**\
\
### Sample Letter Accepting a Valid Qualified Offer\
\
\[Determine whether an Audit Statement is sufficient or whether a Form 3623, Statement of Account, is also required using the same standards applied in settling a case that does not have a qualified offer. If an Audit Statement or interest computations cannot be obtained in time to respond to the qualified offer before it expires, the language may be modified to indicate that an AuditStatement or interest computations will be forwarded under separate cover.\
\
Dear **\[insert petitioner(s)’ representative’s name\]:**\
\
This letter is in reference to your qualified offer dated**\[insert date of letter\]**. We are prepared to accept the offer, which we understand to be an agreement to a deficiency of **\[insert dollar amount\]** for **\[insert tax year\]**, in addition to**\[insert penalty amount\]** in penalties. Interest will be assessed as provided by law.\
\
In order to finalize our settlement, we must file with the Tax Court a decision document that shows the amount of tax and additions to tax/penalties that petitioner(s) owe based on that settlement.\
\
Enclosed are the following documents:\
\
1. A decision document (original and two copies) that shows the amount that petitioner(s) owe;\
\
2. An Audit Statement that shows the computation of the tax owed under the terms of the settlement \[and a Form 3623, Statement of Account, that shows the amount owed and all the payments and other credits that are reflected on the records of the Internal Revenue Service for the tax year(s) at issue in this case\];\
\
3. A calculation of the estimated interest that petitioner(s) owe based on the settlement if petitioner(s) pay the entire amount of tax \[additions to tax/penalties\] and interest by \[date\]; and\
\
4. Publication 594, which explains the collection process.\
\
\
Please carefully review the Audit Statement \[and Statement of Account\], the interest computations and the decision document to make sure that you agree with them. It is important that they be correct because the United States Tax Court will usually not change its decision, even if there is a mistake, unless the court is notified of the mistake within 30 days after the decision is entered by the court. If you believe that there are mistakes in our calculations of the amount petitioner(s) owe or in the decision document, please telephone me as soon as possible.\
\
If you agree with the calculations and the decision document, please sign the original and one copy of the decision document and return them to this office for filing with the Tax Court. The remaining copy, as well as the Audit Statement \[and Statement of Account\] and the calculation of interest, are for your records. \[The United States Tax Court has ordered the parties to file the decision by \[date decision due with court\], so you should return the decision document to me before that date so that we can file it with the court on time.\]\
\
Once the decision document is filed and entered by the Tax Court, the Internal Revenue Service will send petitioner(s) a bill for the amount he/she/they owe. \[Because a joint return was filed, both spouses are jointly and severally liable for the tax, any additions to tax and penalties and the interest.\] In case petitioner(s) want to pay the tax, \[additions to tax/penalties\] and interest before he/she/they receive the bill, petitioner(s) may do so. As previously noted, the interest calculations are estimates and only apply until \[dates noted above\]. A final computation will be made at the Service Center. The interest petitioner(s) owe will increase if full payment is not made by those dates. Also, interest will continue to run on the unpaid portions if petitioner(s) pay less than the total amount due. If petitioner(s) decide to immediately pay some or all of the amount he/she/they owe, petitioner(s) should mail a check to the \[name and address of local Service Center\]. The check should be made payable to the United States Treasury. In order to process the check and apply the payments appropriately, petitioner(s) should include all of the following information with the check:\
\
1. Petitioner(s) name(s) and address(es).\
\
2. Petitioner(s) Social Security number(s).\
\
3. The tax year(s) for which payment is being made.\
\
4. The type of tax due (for example, income tax, estate tax, excise tax).\
\
5. The total amount of petitioner(s) payment. If petitioner(s) owe tax for more than one year, the Internal Revenue Service will also need to know how much he/she/they are paying for each year. Petitioner(s) should also state how much of each year’s payment he/she/they are paying towards tax, \[how much for the additions to tax,\] and how much towards interest.\
\
6. A copy of the decision document that you have signed.\
\
\
Please be advised that you should not consider any agreement to settle this case final and binding until we have executed the decision document and mailed it to the Tax Court for filing.\
\
If you have any questions please contact me at telephone number **\[insert telephone number\]**. If you believe we have misconstrued your offer please respond in writing explaining the misunderstanding.\
\
Sincerely,\
\
Senior Attorney\
\
(Small Business/Self-Employed)\
\
T.C. Bar No.\
\
**Exhibit 35.11.1-234**\
\
### Sample Letter Rejecting a Valid Qualified Offer\
\
Dear**\[insert petitioner(s)’ representative’s name\]:**\
\
This letter is in reference to your qualified offer dated **\[insert date of letter\]**. We understand your offer to be an agreement to a deficiency of **\[insert dollar amount\]** for **\[insert tax year\]**, in addition to **\[insert penalty amount\]** in penalties. We do not find these terms to be an acceptable settlement and reject your qualified offer.\
\
If you wish to submit a new settlement offer or if you believe that we have misconstrued your offer, please respond in writing.\
\
Sincerely,\
\
Senior Attorney\
\
(Small Business/Self-Employed)\
\
T.C. Bar No.\
\
**Exhibit 35.11.1-235**\
\
### Sample Letter Accepting an Offer that is Not a Qualified Offer because it Was Not Timely Made\
\
\[Determine whether an Audit Statement is sufficient or whether a Form 3623, Statement of Account, is also required using the same standards applied in settling a case that does not have a qualified offer. If an Audit Statement or interest computations cannot be obtained in time to respond to the qualified offer before it expires, the language may be modified to indicate that an AuditStatement or interest computations will be forwarded under separate cover.\]\
\
Dear **\[insert petitioner(s)’ representative’s name\]**:\
\
This letter is in reference to your offer dated **\[insert date of letter\]**. The offer does not meet the requirements of a qualified offer because it was not timely made during the qualified offer period as described in I.R.C. § 7430(g) and Treas. Reg. § 301.7430-7(c)(7). Pursuant to section 7430(g), a qualified offer must be submitted to the United States during the qualified offer period, which ends “on the date which is 30 days before the date the case is first set for trial.” This case was first set for trial on **\[insert trial date\]** by court order dated **\[insert order date\]**. Therefore, the qualified offer period ended on **\[insert date 30 days before trial date\]**. Because your offer was submitted after that date, it is not a valid qualified offer under the statute.\
\
Nevertheless, we have reviewed your offer as a standard offer for settlement. We are prepared to accept your offer, which we understand to be an agreement to a deficiency of **\[insert dollar amount\]** for**\[insert tax year\]**, in addition to **\[insert penalty amount\]**in penalties. Interest will be assessed as provided by law.\
\
In order to finalize our settlement, we must file with the Tax Court a decision document that shows the amount of tax and additions to tax/penalties that petitioner(s) owe based on that settlement.\
\
Enclosed are the following documents:\
\
1. A decision document (original and two copies) that shows the amount that petitioner(s) owe;\
\
2. An Audit Statement that shows the computation of the tax owed under the terms of the settlement \[and a Form 3623, Statement of Account that shows the calculation of the amount owed and all the payments and other credits that are reflected on the records of the Internal Revenue Service for the tax year(s) at issue in this case\];\
\
3. A calculation of the estimated interest that petitioner(s) owe based on the settlement if petitioner(s) pay the entire amount of tax \[additions to tax/penalties\] and interest by \[date\]; and\
\
4. Publication 594, which explains the collection process.\
\
\
Please carefully review the Audit Statement \[and Statement of Account\], the interest computations and the decision document to make sure that you agree with them. It is important that they be correct because the United States Tax Court will usually not change its decision, even if there is a mistake, unless the court is notified of the mistake within 30 days after the decision is entered by the court. If you believe that there are mistakes in our calculations of the amount petitioner(s) owe or in the decision document, please telephone me as soon as possible.\
\
If you agree with the calculations and the decision document, please sign the original and one copy of the decision document and return them to this office for filing with the Tax Court. The remaining copy, as well as the Audit Statement \[and Statement of Account\] and the calculation of interest, are for your records. \[The United States Tax Court has ordered the parties to file the decision by \[date decision due with court\], so you should return the decision document to me before that date so that we can file it with the court on time.\]\
\
Once the decision document is filed and entered by the Tax Court, the Internal Revenue Service will send petitioner(s) a bill for the amount he/she/they owe. \[Because a joint return was filed, both spouses are jointly and severally liable for the tax, any additions to tax and penalties and the interest.\] In case petitioner(s) want to pay the tax, \[additions to tax/penalties\] and interest before he/she/they receive the bill, petitioner(s) may do so. As previously noted, the interest calculations are estimates and only apply until \[dates noted above\]. A final computation will be made at the Service Center. The interest petitioner(s) owe will increase if full payment is not made by those dates. Also, interest will continue to run on the unpaid portions if petitioner(s) pay less than the total amount due. If petitioner(s) decide to immediately pay some or all of the amount he/she/they owe, petitioner(s) should mail a check to the \[name and address of local Service Center\]. The check should be made payable to the United States Treasury. In order to process the check and apply the payments appropriately, petitioner(s) should include all of the following information with the check:\
\
1. Petitioner(s) name(s) and address(es).\
\
2. Petitioner(s) Social Security number(s).\
\
3. The tax year(s) for which payment is being made.\
\
4. The type of tax due (for example, income tax, estate tax, excise tax).\
\
5. The total amount of petitioner(s) payment. If petitioner(s) owe tax for more than one year, the Internal Revenue Service will also need to know how much petitioner(s) are paying for each year. Petitioner(s) should also state how much of each year’s payment he/she/they are paying towards tax, \[how much for the additions to tax,\] and how much towards interest.\
\
6. A copy of the decision document that you have signed.\
\
\
Please be advised that you should not consider any agreement to settle this case final and binding until we have executed the decision document and mailed it to the Tax Court for filing.\
\
If you have any questions please contact me at telephone number **\[insert telephone number\]**. If you believe we have misconstrued your offer please respond in writing explaining the misunderstanding.\
\
Sincerely,\
\
Senior Attorney\
\
(Small Business/Self-Employed)\
\
T.C. Bar No.\
\
**Exhibit 35.11.1-236**\
\
### Sample Letter Rejecting an Offer that is Not a Qualified Offer Because it Includes Interest\
\
Dear **\[insert petitioner’s representative’s name\]**:\
\
This letter is in reference to your offer dated **\[insert date of letter\]**. We have concluded that the offer does not meet the qualified offer requirements contained in I.R.C. § 7430 and the corresponding regulations and is, therefore, not a valid qualified offer.\
\
The offer states that petitioner(s) agree to pay **\[insert dollar amount\]** to settle the petitioner(s)’s tax liability, including penalties and interest. Pursuant to section 7430(g)(1)(B) and Treas. Reg. §§ 301.7430-(7)(c)(1)(ii) and (3), the offered amount must be determined without regard to interest, unless interest is a contested issue in the case.\
\
Generally, interest can be a contested issue only if the court in which the proceeding was brought has jurisdiction to determine the amount of interest due on the underlying tax, penalties, additions to tax and additional amounts. The Tax Court is a court of limited jurisdiction and it may exercise its jurisdiction only to the extent authorized by Congress. _Naftel v. Commissioner_, 85 T.C. 527, 529 (1985). The Tax Court does not have jurisdiction to decide questions related to interest in a deficiency case. _Commissioner v. McCoy_, 484 U.S. 3 (1987). _See also Smith v. Commissioner_, T.C. Memo. 2009-33. Thus, the Tax Court does not have jurisdiction over the interest in this case. Because the Tax Court lacks jurisdiction over interest in this case, interest cannot be a contested issue under these facts. Therefore, the inclusion of interest in the offered amount violates the rules of section 7430(g).\
\
Pursuant to section 7430(g)(2)(B) and Treas. Reg. § 301.7430-7(c)(7), the qualified offer period ends 30 days prior to the date the case is first calendared for trial. The qualified offer period is still open. You may submit a new offer that complies with section 7430(g) and the corresponding regulations during the qualified offer period. If you have any questions please contact me at telephone number**\[insert telephone number\]**. If you believe we have misconstrued your offer please respond in writing explaining the misunderstanding.\
\
Sincerely,\
\
Senior Attorney\
\
(Small Business/Self Employed)\
\
T.C. Bar No.\
\
[More Internal Revenue Manual](https://www.irs.gov/irm)\
\
Copy link\
\
✓\
\
Thanks for sharing!\
\
Find any service\
\
[AddToAny](https://www.addtoany.com/ "Share Buttons")\
\
[More…](https://www.irs.gov/irm/part35/irm_35-011-001#addtoany "Show all")\
\
A2A