---
url: "https://www.irs.gov/irm/part35/irm_35-007-002"
title: "35.7.2 Preparation of Briefs | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-007-002#main-content)

- 35.7.2 [Preparation of Briefs](https://www.irs.gov/irm/part35/irm_35-007-002#idm140689634496832)
  - 35.7.2.1 [Form and Contents of Brief](https://www.irs.gov/irm/part35/irm_35-007-002#idm140689634496416)

    - 35.7.2.1.1 [Cover Sheet](https://www.irs.gov/irm/part35/irm_35-007-002#idm140689634501312)
    - 35.7.2.1.2 [Contents Page](https://www.irs.gov/irm/part35/irm_35-007-002#idm140689634323136)
    - 35.7.2.1.3 [Citations Page](https://www.irs.gov/irm/part35/irm_35-007-002#idm140689634319472)
    - 35.7.2.1.4 [Preliminary Statement](https://www.irs.gov/irm/part35/irm_35-007-002#idm140689634314304)
    - 35.7.2.1.5 [Questions Presented](https://www.irs.gov/irm/part35/irm_35-007-002#idm140689634303920)
    - 35.7.2.1.6 [Respondents Request for Findings of Fact](https://www.irs.gov/irm/part35/irm_35-007-002#idm140689634484848)
    - 35.7.2.1.7 [Points Relied Upon](https://www.irs.gov/irm/part35/irm_35-007-002#idm140689634461392)
    - 35.7.2.1.8 [Argument](https://www.irs.gov/irm/part35/irm_35-007-002#idm140689634456240)
    - 35.7.2.1.9 [Conclusion](https://www.irs.gov/irm/part35/irm_35-007-002#idm140689634434400)
    - 35.7.2.1.10 [Execution](https://www.irs.gov/irm/part35/irm_35-007-002#idm140689634429600)
    - 35.7.2.1.11 [Appendix](https://www.irs.gov/irm/part35/irm_35-007-002#idm140689634425008)
    - 35.7.2.1.12 [Initialed Page](https://www.irs.gov/irm/part35/irm_35-007-002#idm140689619601376)

  - 35.7.2.2 [Procedures for Preparation of Briefs](https://www.irs.gov/irm/part35/irm_35-007-002#idm140689619597280)

    - 35.7.2.2.1 [Research](https://www.irs.gov/irm/part35/irm_35-007-002#idm140689619575248)
    - 35.7.2.2.2 [New Issues](https://www.irs.gov/irm/part35/irm_35-007-002#idm140689619565600)
    - 35.7.2.2.3 [Burden of Proof](https://www.irs.gov/irm/part35/irm_35-007-002#idm140689619561296)
    - 35.7.2.2.4 [Concessions in the Brief](https://www.irs.gov/irm/part35/irm_35-007-002#idm140689619551968)
    - 35.7.2.2.5 [Review in Field](https://www.irs.gov/irm/part35/irm_35-007-002#idm140689619548208)

# Part 35. Tax Court Litigation

# Chapter 7. Tax Court Briefs

# Section 2. Preparation of Briefs

* * *

## 35.7.2 Preparation of Briefs

**35.7.2.1** **(08-11-2004)**

### Form and Contents of Brief

1. All briefs are typewritten double spaced.

2. The taxpayer before the court should be referred to as the petitioner rather than the taxpayer. The petitioner in another case may be referred to as the taxpayer, and it should be made clear that the reference is not to the petitioner in the instant case. An intervenor may be referred to as the intervenor.

3. Page Limitations. Page limitations imposed by the Tax Court in briefs, either verbally or by court order, must scrupulously be respected. Any attempts to circumvent such limitations through the use of small fonts or type styles, overuse of single spaced footnotes, nonstandard margins or line spacing, or other similar devices are strictly prohibited. Footnotes must be in the same typeface and point size as the body of the brief.



1. Unless otherwise specified, any page limitations imposed by the court are presumed to apply to the brief from cover to cover. It includes such pages as the cover sheet, contents page, citations page, and conclusion. Any attempt to circumvent the page limitations by removing any of the required pages from the brief is strictly prohibited. If an appendix is expected to be included in the brief, the page limitation set by the court is presumed to include the appendix as well.

2. If there is any question whether the page limitations apply to only a portion of the brief ( _e.g._, to the argument portion), the attorney should ask the court to clarify this at trial. Unless an express statement is obtained from the court at the time of trial explaining the imposed page limitations, the page limitations are presumed to apply to the brief in its entirety. If a question as to page limitations arises after trial, including changes to fonts, which would also enhance the appearance of the brief, counsel should arrange a conference call with the judge and petitioner or petitioner’s counsel to clarify the court’s order. Changes should never be made unilaterally.

3. In cases where the Tax Court imposes a page limitation with respect to a brief (or other document) which is to be reviewed in an Associate office, the Field attorney must inform the Associate office of all details concerning the limitation, including what portion of the document the limitation covers; for example, whether the limitation applies cover-to-cover, or to the argument alone.

4. The appropriate response to petitioner's violation of court-imposed page limitations will vary from case to case. Responses may include a letter to, or conference call with the court, or a motion to strike the offending document. If petitioner violates a court-imposed page limitation, the Field attorney should consult with the Associate office which reviewed respondent’s corresponding brief, if any, who will in turn consult with APJP, Branch 3, in order to promote consistency of approach to this issue throughout the Office of Chief Counsel. If the respondent’s corresponding brief was not reviewed by an Associate office, petitioner’s violation of page limitations should be coordinated directly with APJP, Branch 3.

5. If respondent is found, or is alleged, to have violated the page limitations imposed by the court, the responsible field attorney and manager should immediately contact APJP, Branch 3 for assistance when the violation is discovered, so that the most effective corrective action or response to the allegation may be determined.


4. Additionally, the petitioner or a judge may request that briefs be hyperlinked. Hyperlinked briefs are electronic briefs that permit the user to electronically access information that is contained in the brief ( _e.g._, cited cases, exhibits, etc.). Field Counsel should avoid agreeing to hyperlinked briefs due to present budgetary and technical uncertainties and limitations. In any event, APJP, Branch 3 should be contacted at the earliest opportunity if a hyperlinked brief is being considered as the type of brief that will be used.


**35.7.2.1.1** **(08-11-2004)**

#### Cover Sheet

1. Each brief will have a cover sheet which shall contain the caption of the case, the type of brief being filed, the typed name of the Chief Counsel and the typed names of the attorneys "of Counsel." _See_ Exhibit 35.11.1–122. The address and telephone number of Field Counsel is optional as an entry on the cover sheet. It must, however, to be in compliance with T. C. Rule 23(a)(3), be shown on the Conclusion page containing signatures. _See_ CCDM 35.7.2.1.9 and CCDM 35.7.2.1.10.


**35.7.2.1.2** **(08-11-2004)**

#### Contents Page

1. The Contents page shall list each section of the brief and the page numbers where each item may be found in the brief.


**35.7.2.1.3** **(08-11-2004)**

#### Citations Page

1. The Citations page shall contain four subsections: Cases (alphabetically arranged); Code Sections; Regulations; and Miscellaneous (citations such as rulings, law review articles, committee reports, etc.). A reference is made to the page or pages in the brief where the citations appear. Citations of case authorities should be complete. Citation of unofficial or parallel sources, such as AFTR or USTC, should be used only where no official cite is available. Citations should be underscored on the Citations page as well as in the Argument portion of the brief. In order that there be uniformity in the manner of citing case authority, law review articles, etc., attorneys are to observe the provisions of the Uniform System of Citation, as supplemented by the Chief Counsel’s Legal Citation Supplement.


**35.7.2.1.4** **(08-11-2004)**

#### Preliminary Statement

1. The Preliminary Statement page of the brief contains the caption of the case with a statement as to the type of brief being filed, followed by the heading Preliminary Statement. The Preliminary Statement contains the following information:



1. It states the years, kinds and amounts of taxes and additions to the tax involved, separately as to each year.

2. The name of the judge and the date and place of trial should always be shown, and there should be stated the nature of the evidence upon which the case was submitted, _i.e._, pleadings, stipulations of fact, testimony, etc. It is not necessary to state the number of witnesses or exhibits.

3. The due date of respondent’s brief should be stated. This statement should include the original due date as well as any extensions of time that have been granted. It is unnecessary to state when the petitioner’s brief is or was due.

4. In some cases the court erroneously enters a decision for the petitioner or the respondent when a Rule 155 computation is necessary. Similarly, the court sometimes enters a decision under Rule 155 when a recomputation is unnecessary. Such mistakes might be avoided if the court were advised on this matter at the time the brief is filed. Therefore, if concessions have been made by either party, or if all the adjustments made in the statutory notice have not been contested by the petitioner, or if respondent has asked for an increased deficiency or the petitioner has requested an overpayment, such factors should be noted, with a statement as to the necessity for a Rule 155 computation.


**35.7.2.1.5** **(08-11-2004)**

#### Questions Presented

1. The following should be noted with respect to listing the Questions Presented:



1. Each question should be stated in a separately numbered paragraph.

2. Only the issues to be decided by the court should be listed.

3. The issues must be stated in clear and concise statements. An issue should never begin with "Did the Commissioner" or similar language. A direct informative statement of the issues which the court is called upon to decide should be made. The statement should be brief and to the point. It should not be so general and abstract as to fail to disclose the matters at issue, and should present the issues from the respondent’s point of view, but not in a manner which is unfair to the petitioner.

4. Following a statement of the issues to be decided by the court, there should be stated in a paragraph removed from the Questions Presented the assignments of error in the petition which are conceded either by the petitioner or by the respondent, giving references to the pleadings, stipulation of facts, or transcript supporting such concessions.

5. All issues raised by the pleadings ( _i.e._, the petition and answer and amendments thereto) must be accounted for on the Questions Presented page. These issues are either issues to be decided by the court or issues which have been conceded, settled, or abandoned by the parties.


**35.7.2.1.6** **(08-11-2004)**

#### Respondent’s Request for Findings of Fact

1. If the court directs the filing of seriatim briefs, the petitioner usually files the first brief and the respondent files an answering brief. Under T.C. Rule 151, the Respondent’s Request for Findings of Fact will be in the following order.



1. A specific statement is required in respondent’s reply brief concerning whether respondent agrees or disagrees with each of petitioner’s requested findings. Therefore, the respondent’s brief should specifically state whether there is agreement as to each of the petitioner’s requested findings (including findings of ultimate fact) in whole or in part.

2. As to each of petitioner’s requested findings with which the respondent disagrees, respondent’s brief shall set forth the objection, the reason for the objection, and the finding which the respondent believes the evidence requires. Generally, it is not sufficient to object to petitioner’s requested findings of fact solely on the ground that the requested findings are not supported by the record. The disputed findings of fact should be analyzed, and the specific objection clearly defined and argued. If after careful analysis it is determined that the sole objection is that the requested findings are not supported by the record, this objection should be made. Any portion of the record that is contrary to the requested findings should be referenced in the objection. The respondent’s brief will address the petitioner’s requested findings in numerical order.

3. In unusual circumstances, such as when the petitioner’s requested findings are wholly inadequate under the Tax Court’s rules, the attorney should discuss with the reviewer the question of strict compliance with subsections a. and b. of CCDM 37.2.1.5(1) above. The Tax Court has called attention to violations of T.C. Rule 151(e) in respondent’s seriatim briefs. Attorneys should follow the court’s rules unless they have been authorized by their reviewer not to follow them in a specific case.

4. In seriatim briefs the additional findings requested should be numbered consecutively following those of the petitioner. The additional findings requested should not be a repetition of petitioner’s findings. If the only objection to certain of petitioner’s findings is that they are incomplete, additions thereto should be requested under the same paragraph number.


2. If the court orders the simultaneous filing of briefs, respondent’s requested findings of fact should be complete within themselves. All facts essential to support the respondent’s position should be requested in the original brief. There rarely should be any reason to request additional findings of fact in the reply brief. The reply brief should set forth respondent’s agreement or disagreement with each of petitioner’s requested findings in the manner set forth in T. C. Rule 151.

3. The facts must be stated in clear and concise language in short paragraphs of related material. When practicable, all facts with respect to each issue should be requested in consecutive paragraphs, and there may be headings in the requested findings to indicate the facts which pertain to each specific issue.

4. After each requested finding, reference should be made to the pleadings, transcript, or exhibits, etc., supporting such request. Examples: (Pet., par. 4(b)); (Ans., par. 8); (Reply, par. 10(c)); (Stip., par. 12); (Tr. 132); (Ex. 12-J).

5. The court should be asked to find the facts from the pleadings, stipulation of facts, and oral and documentary evidence. A quotation from the transcript of testimony of a witness is not a request for a finding of fact. The requested finding should not take the form, "Witness A testified that, ‘the automobile had a useful life of five years.’" Rather, it should be in the form, "The automobile had a useful life of five years" (unless the issue in dispute is whether the witness actually so testified, rather than the fact testified to). Only in rare and unusual circumstances should testimony of witnesses be set forth in extended form. The argument on the requested finding should never be made a part of the findings of fact. The findings should be in language which the court could adopt verbatim as its findings of fact. Findings of ultimate fact must be in every brief. Such ultimate facts and conclusions should be stated last.

6. In some briefs a finding must be made as to the place where the tax returns were filed; if no statutory return was filed for one or more of the years involved, a finding to that effect should also be requested. The fact that a return was or was not filed for any year or years involved may be essential to a determination of an overpayment, or may be essential in determining venue on appeal of a decision of the Tax Court. See paragraph (7) below.

7. In every brief involving a petitioner other than a corporation, a finding must be requested as to the legal residence of the petitioner as of the date the petition was filed with the Tax Court. If legal residence is not established by the record before the court, a finding to that effect should also be requested if a supplemental stipulation cannot be secured. Findings should also be requested for both an executor’s or other personal representative’s legal residence and the domicile of a decedent or other principal party. For a corporate petitioner, a finding must be requested as to the principal place of business or principal office or agency of the corporate petitioner as of the date the petition was filed with the Tax Court. If the corporation has no principal place of business or principal office or agency in the United States as of the date the petition was filed, a finding to that effect should be requested together with the request for a finding as to the Service office with which the corporation’s tax return was filed. If no return was filed, a finding to that effect should be requested. The reason for requesting these findings is that, in the case of a petitioner other than a corporation, venue of the circuit court on appeal from a Tax Court decision is determined by the location of petitioner’s legal residence as of the date the petition was filed with the Tax Court; if no legal residence is established, venue is in the U.S. Court of Appeals for the District of Columbia Circuit. In the case of a corporate petitioner, venue is determined by its principal place of business or by its principal office or agency as of the date the petition was filed with the Tax Court. If the corporation’s principal place of business or principal office or agency in any judicial circuit is not established, venue is then in the court of appeals for the circuit wherein the income tax return was filed. If no return was filed, venue would then be in the District of Columbia circuit. Specific findings by the court will eliminate any uncertainty as to which court of appeals is the appropriate reviewing court.


**35.7.2.1.7** **(08-11-2004)**

#### Points Relied Upon

1. Under the heading Points Relied Upon the principal points upon which the respondent relies should be stated in clear and concise language. _See_ T.C. Rule 151. Its primary purpose is to give the judge a quick summary of the respondent’s position on the issues to be decided. The attorney should bear in mind that the judge’s initial conception of the respondent’s position on brief may be obtained from what is stated under Points Relied Upon. It should be short, rarely more than two pages; it should be carefully written; and it should not be a mere repetition of the Argument portion of the brief.


**35.7.2.1.8** **(08-11-2004)**

#### Argument

01. In seriatim briefs, it may be desirable to open the Argument with a concise statement of the essential facts. This is due to the requirements under T.C. Rule 151 concerning the findings of fact. The statement of the facts should be brief and limited to the essential facts to which the argument will be directed. In simultaneous briefs it is not always necessary to summarize the facts. However, in cases which involve long and complicated findings of facts, it may be desirable to give at the beginning of the argument on each issue a concise statement of the facts to which the argument will be directed. The summary of facts set forth in the Argument portion should be separated under the Argument headings to which the facts apply.

02. The argument with respect to each issue should begin by setting forth the specific section or sections of the statutes and regulations which are applicable to the issue to which the argument pertains. There are two general methods of setting forth the statutes and regulations.



    1. If the interpretation of the language of the statutes or regulations is not an issue, such as in primarily factual questions, the opening of the argument may be illustrated as follows: "The issue is whether $6,800 paid by the petitioner to its sole stockholder is deductible as interest paid or accrued within the taxable year on indebtedness within the meaning of I.R.C. § 163(a) and Treas. Reg. § 1.163–1."

    2. If the interpretation of the statutes or regulations is the issue being argued, the pertinent excerpts from the statutes or regulations, or both, should be quoted at the beginning of the argument. If the statute or regulation quoted in the brief is not currently in force, that fact should be noted.


03. An argument as to each issue should be made separately, under appropriate subheadings. Argument headings should be informative of respondent’s argument which follows. They should be direct statements corresponding to some extent to the statements of the Questions Presented. There may be more headings in the Argument than Questions Presented.

04. The argument should be direct and specific. Long paragraphs should be avoided; concise paragraphs are easier to read and communicate the idea more effectively. Stilted language and involved sentences should be avoided. The primary concern in writing a brief is to set up an affirmative case for the respondent. The facts supporting the respondent’s determination should be argued, and failure of proof arguments should be made. Even in seriatim briefs, the respondent’s position should first be argued and followed by a reply to the petitioner’s argument. The main points listed by the petitioner should be answered, and the principal cases relied upon distinguished as much as possible. Merely saying that the petitioner’s position is absurd or has no merit is no answer to the argument presented. When decisions are lacking to support the respondent’s view the attorney should concentrate on presenting practical, logical arguments as to why the court should adopt a particular view.

05. The attorney should remember that the brief is being written for the Office of Chief Counsel. The brief should be in keeping with the dignity of the office. Flowery adjectives, hyperbole, and catch phrases should generally not be used. The argument is more effective and dignified without superfluous words and phrases. Their insertion in a brief may only serve to create a prejudice in the mind of the judge, regardless of the kind of a case the respondent may have. The argument should not indulge in clashes with opposing counsel or with witnesses, unless there is a basis in the record and a compelling reason relevant to presenting the case for doing so.

06. The effectiveness of the argument is not governed by the number of cases which appear on the Citations page or in the Argument portion. Obvious legal principles which are well established by authority do not require extensive citation. The cases cited should be chosen with care and should be the cases which represent the strongest authority in support of respondent’s position. The application of a cited case to the issue involved should be clearly shown. Such application is not always as obvious as the attorney may believe. Quotations from a cited case should be short and should be used sparingly. If the complete quotation is long, a preface in the attorney’s own words should introduce it.

07. Tax Court memorandum opinions generally do not carry the weight of regular opinions and should not be cited when there are other comparable published decisions which can be more effectively relied upon. They are not to be disregarded, however, and should be used if they are the strongest available authority.

08. While published revenue rulings are not given the same weight as case law or regulations, they should nevertheless be cited in briefs wherever applicable in explanation of the Service’s position. Respondent may not argue against his published position.

09. Ordinarily, cases in which a nonacquiescence is outstanding should not be cited in support of respondent’s position. If such a case is cited for an issue which was won by respondent, the phrase "nonacq. on other issue" should follow the citation. Acquiescences also should be cited.

10. When simultaneous briefs are filed by the parties, it generally is not acceptable to anticipate the arguments to be made by the petitioner and to answer such arguments in respondent’s original brief. This should be done by way of a reply brief. In seriatim briefs, respondent’s reply brief, of course, should answer all arguments advanced in petitioner’s opening brief, but the answering brief should not anticipate arguments to be made in the petitioner’s reply brief. When necessary, new arguments advanced by the petitioner in his/her reply brief may be answered by a supplemental brief or surrepply brief.


**35.7.2.1.9** **(08-11-2004)**

#### Conclusion

1. The Conclusion is a separate page of the brief. The Conclusion should not be a detailed summarization of the preceding Argument. If no concession has been made by the respondent and if no increased deficiency has been requested, the Conclusion should read: "It follows that the determination of the Commissioner of Internal Revenue should be sustained." If there has been a concession of any kind, the court should be asked to sustain the Commissioner’s determination "as modified herein." If an increased deficiency has been claimed in the answer or amended answer, that fact should be referred to in the Conclusion.


**35.7.2.1.10** **(08-11-2004)**

#### Execution

1. The name and title of the Chief Counsel and the names of the attorneys of record should be typed on the same page with the Conclusion. As with all documents and correspondence submitted to the Tax Court, the attorney’s Tax Court practitioner number should be typed immediately below the name of the attorney signing the document. All briefs, memoranda in lieu of briefs, and letters to the court in lieu of briefs are executed in Field Counsel. The attorneys listed Of Counsel and/or Counsel of Record on the cover sheet and on the Conclusion page should be the same. The address and telephone number of the appropriate field office should be included pursuant to T.C. Rule 23(a)(3).


**35.7.2.1.11** **(08-11-2004)**

#### Appendix

1. If specific provisions of statutes and regulations are included in the brief, they may be set forth in an appendix. If legislative history is involved in the interpretation of a provision of a statute, significant portions of committee reports may also be included. (2) Sometimes, in cases involving complex corporate reorganizations, it is helpful to prepare a diagram to be inserted in the appendix to aid in the analysis of the intercorporate relationship. Care must be taken to include only evidence of record in the preparation of any such diagram. Also, if it would be helpful to show the context of pertinent material cited in the brief when the context is too lengthy for complete quotation in the brief, it may be placed in the appendix.


**35.7.2.1.12** **(08-11-2004)**

#### Initialed Page

1. The Initialed Page of a brief should state the type of brief, the name and docket number of the case, and should contain columns in which the writer of the brief, the immediate reviewer and all other reviewers will write their names (not initials) and show the date each completed work on the brief. When the brief is filed, the page will be attached to the photocopy of the brief which has been stamped Initialed Copy.


**35.7.2.2** **(08-11-2004)**

### Procedures for Preparation of Briefs

1. Upon conclusion of the trial session, the attorney should immediately begin to prepare the briefs.

2. In requesting time for filing briefs in cases tried under the regular procedures, the attorney should anticipate the time which will be required to complete briefs for all cases the attorney tried at the session. Every effort should be made by the attorney to complete the draft of the brief in sufficient time so that it may be reviewed and filed with the court on or prior to the original due date.

3. Many of the judges of the court are reluctant to grant extension motions for filing briefs. This applies even in cases in which the judge grants less time than is permitted by the court’s rules. It is particularly difficult to obtain extensions of time in "S" cases in which the filing of briefs is permitted. Thus, it may be necessary for the reviewer to reassign either regular or "S" cases after trial in order for the briefs to be timely filed.



1. A motion for extension of time to file a brief may be filed only when a delay in time preparation is unavoidable and there is a sufficient basis and justification for the court to grant it. For example, if the transcript is not received within the time provided in the court’s contract with the reporting service, such fact would be grounds to support a motion for extension of time. Such a motion should be promptly filed if additional time for preparation of the brief is required. The fact that one attorney tried several cases at a given session, is working on pre-90-day cases or other matters in the office, or is preparing trial cases for a forthcoming session is not an unavoidable delay or extraordinary circumstance justifying the granting of the motion.

2. Field Counsel should establish adequate controls and procedures for timely preparation, review in Field Counsel, and forwarding of briefs to the appropriate Associate office. In establishing such procedures, Field Counsel should bear in mind the difficulties encountered in obtaining extensions of time for filing of briefs, the necessity for an adequate review by field reviewers, and review by the appropriate Associate offices.

3. A granted motion for extension of time filed by either party extends the due date of the brief for both parties. Also, acceptance by the court of petitioner’s brief filed late automatically extends the due date of respondent’s reply brief. _See_ T.C Rule 25(c). More specifically, after a case is submitted, the court usually sets the dates on which opening and reply briefs are due. If a party’s brief is received late and leave is granted to file the brief out of time, the time for filing the reply briefs is automatically extended to a new date, which is determined by advancing the date of service of the late brief by the number of days originally allowed for filing a reply brief. For example, if opening briefs were due on September 1, reply briefs were due on October 1, and the petitioner’s late brief was not served on the respondent until September 5, the due date of the reply brief is extended to October 5. It should be noted that the late service of a timely filed brief does not extend the time to file a reply brief.

4. Field Counsel should not rely on the petitioner to file an extension motion. Moreover, the Field attorney should not request petitioner’s attorney to file an extension motion when there is not sufficient justification for the respondent to file such a motion. If the reviewer determines that there are sufficient reasons for respondent to file an extension motion, the petitioner should be requested to join in a joint motion, to endorse respondent’s motion, or to agree to a statement in respondent’s motion of an agreement to the extension, as practical under the circumstances. If petitioner does not agree, the motion should nevertheless state petitioner’s counsel has been advised that it will be filed and does not agree to the extension.

5. The Field attorney has the responsibility of advising his reviewer of extraordinary circumstances which may prevent timely filing of the brief. The reviewer is responsible for maintaining controls and establishing procedures in accordance with instructions from Division Counsel to assure timely filing of briefs or timely notification to petitioner’s counsel of the filing of extension motions. A determination as to whether a brief can be timely filed or whether there are justifiable reasons for an extension motion should be made by Field Counsel at least two weeks before the due date of the brief. This procedure on filing briefs avoids criticism of the Service by petitioner’s counsel. It is also a courtesy which one attorney should extend to another.

6. It is recognized by the Office of Chief Counsel, and generally by most of the judges of the court, that there are instances in which problems are not anticipated by Field Counsel but arise only upon review of the brief by Associate offices. In a limited number of such cases it may be necessary to file a motion for an extension of time. The reviewing attorney in the appropriate Associate office has the responsibility, as soon after the assignment of the brief as possible, of bringing to the attention of the reviewer any problem which may require an extension of time to permit complete consideration of the issues and positions to be taken. If it is determined by the reviewer that an extension motion is necessary, Field Counsel should be notified by telephone of the necessity for filing an extension motion and the reasons therefor. Field Counsel should then promptly request agreement to the extension motion of petitioner’s counsel by telephone. The motion, prepared in the appropriate Associate office, should recite whether or not the petitioner’s counsel has any objection to the extension request.

7. If hyperlinked briefs are being considered, Field Counsel must notify APJP, Branch 3 immediately. In any event, Field Counsel should avoid agreeing to the use of hyperlinked briefs and should promptly seek consultation with APJP, Branch 3. _See_ CCDM 35.7.2.1(4).


**35.7.2.2.1** **(08-11-2004)**

#### Research

1. Before trial of the case and in the preparation of the Pretrial Memorandum, the attorney should have completed considerable research into the law of the case. After the trial the attorney should endeavor to complete the legal research on the points developed at the trial without waiting for the transcript. This is particularly important in cases in which the judge limits the time for filing briefs.

2. In the course of research, consideration should be given to the _Golsen_ rule. The _Golsen_ rule is a self-imposed rule of the Tax Court that it will follow the rule of law laid down by the court of appeals to which an appeal from the decision in the case before it will lie. _Golsen v. Commissioner_, 54 T.C. 742 (1970), _aff’d on other grounds_, 445 F.2d 985 (10th Cir. 1970), _cert denied_, 404 U.S. 940 (1971). In cases that are consolidated for trial, briefing and opinion, the Tax Court could reach differing results for petitioners in the same consolidated group; the differing results depend on the controlling appellate court opinions in the various circuits to which appeals would lie. _See, e.g., Lewis v. Commissioner_, T.C.Memo. 1986–155. The same problem can arise in joint petitions filed under T. C. Rule 61.


**35.7.2.2.2** **(08-11-2004)**

#### New Issues

1. New issues may not be raised and presented to the court for the first time in the brief. What is a new issue, and what argument or theory is considered as inherent in the issues raised by the pleadings, often present a troublesome problem. Discretion will have to be carefully exercised in this area. A general test, which is not applicable in all instances, is whether a new theory or new argument or new grounds set forth in the brief would have compelled the petitioner to submit new or additional evidence had petitioner known the respondent would take such a position. In any instance in which this problem arises, the transmittal memorandum or letter to the appropriate Associate office on the brief should specifically point out this fact.


**35.7.2.2.3** **(08-11-2004)**

#### Burden of Proof

1. In preparation of the brief, the attorney must not rely too heavily upon statutory presumptions or upon the failure of the petitioner to carry the burden of proof. The Tax Court will not decide a case on failure of proof if it can be avoided; rarely does burden of proof become dispositive except upon a complete failure of proof or evidence on each side in precise equipoise. Where possible, the court will decide an issue without reference to the burden of proof. During the course of the trial, the attorney should have presented to the court all of the facts available to support the Commissioner’s determination. These facts should be the basis of the primary argument in the brief. Statutory presumptions and the prima facie correctness of the Commissioner’s determinations have their place, but they should not be depended upon to the exclusion of the available evidence in the record which can be used on behalf of the Service. _See_ CCDM 35.3.1.14 and CCDM 35.4.1.6 for discussions of the burden of proof.

2. When the burden of proof is on the Service, the Field attorney must develop at trial, and present on brief, the facts which fully support any burden placed upon the Service.

3. There are only limited situations in which the court can take judicial notice of a fact. Facts which the attorney could have put in evidence at the trial, but did not, cannot be used in the brief to prove issues upon which the respondent has the burden of proof. Facts of which the Tax Court can take judicial notice should be determined prior to the trial and not in the process of preparing the brief.

4. In a case where the court or the petitioner asserts that the burden of proof has shifted to the respondent under the provisions of section 7491(a), the Field attorney, and the Associate Chief Counsel attorney reviewing the brief, if any, should coordinate the issue with APJP, Branch 3.


**35.7.2.2.4** **(08-11-2004)**

#### Concessions in the Brief

1. If, after trial, Field Counsel concludes that one or more of the issues, but not the entire case, should be settled or conceded, the court should be so advised by an appropriate statement on the Questions Presented page of the brief.


**35.7.2.2.5** **(08-11-2004)**

#### Review in Field

1. The Field reviewer has the primary responsibility for a quality review of the brief. This review includes a determination that: the issues to be litigated are adequately defined on the Questions Presented page along with a proper notation of all issues raised by the pleadings or at the trial which have been conceded by either party or settled by the parties; the Findings of Fact chronologically, convincingly, and based upon accurate citations to the record, set forth the relevant facts of record and thereby lay the factual pattern upon which the legal argument is made; the Points Relied Upon clearly but briefly set forth respondent’s position on the issues litigated; the Argument on each factual issue is adequately supported by the requested findings of fact; in the Argument, the application of the statutes, regulations, case law, and ruling position of the Service to the facts is clear and convincing; and the Brief as a whole is a well-written and persuasive document which meets the high standards and maintains the dignity of the Office of Chief Counsel. In addition, the Brief should be carefully proofread, comply with all required specifications concerning format and form, and free of typographical and clerical errors.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-007-002#addtoany "Show all")

A2A