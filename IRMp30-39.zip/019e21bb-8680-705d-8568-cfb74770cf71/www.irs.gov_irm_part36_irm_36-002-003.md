---
url: "https://www.irs.gov/irm/part36/irm_36-002-003"
title: "36.2.3 Conflicts in Appeal or Certiorari Recommendations and Settlement Offers | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part36/irm_36-002-003#main-content)

- 36.2.3 [Conflicts in Appeal or Certiorari Recommendations and SettlementOffers](https://www.irs.gov/irm/part36/irm_36-002-003#idm140076797282144)
  - 36.2.3.1 [Conflicts in Appeal or Certiorari Recommendations](https://www.irs.gov/irm/part36/irm_36-002-003#idm140076770988672)

    - 36.2.3.1.1 [Conflicts with Department of Justice - General](https://www.irs.gov/irm/part36/irm_36-002-003#idm140076781430752)
    - 36.2.3.1.2 [Conflicts with Department of Justice - Appeal Recommendations](https://www.irs.gov/irm/part36/irm_36-002-003#idm140076812090384)

      - 36.2.3.1.2.1 [Delivery of Conflicting Recommendation](https://www.irs.gov/irm/part36/irm_36-002-003#idm140076797320368)
      - 36.2.3.1.2.2 [Memorandum to Associate](https://www.irs.gov/irm/part36/irm_36-002-003#idm140076797385616)
      - 36.2.3.1.2.3 [Coordination with Other Associate Offices](https://www.irs.gov/irm/part36/irm_36-002-003#idm140076797364672)
      - 36.2.3.1.2.4 [Associate Chief Counsel Recommendation](https://www.irs.gov/irm/part36/irm_36-002-003#idm140076766407824)

  - 36.2.3.2 [Offers in Settlement](https://www.irs.gov/irm/part36/irm_36-002-003#idm140076812081648)

    - 36.2.3.2.1 [Procedures](https://www.irs.gov/irm/part36/irm_36-002-003#idm140076781970016)
    - 36.2.3.2.2 [Conflicts with Department of Justice Recommendation](https://www.irs.gov/irm/part36/irm_36-002-003#idm140076782688080)
    - 36.2.3.2.3 [Cases Remanded to the Tax Court after Settlement](https://www.irs.gov/irm/part36/irm_36-002-003#idm140076790433008)

  - 36.2.3.3 [Court Costs in Appellate Cases](https://www.irs.gov/irm/part36/irm_36-002-003#idm140076764105376)

# Part 36. Appellate Litigation and Actions on Decision

# Chapter 2. Appeal/Certiorari Recommendations

# Section 3. Conflicts in Appeal or Certiorari Recommendations and SettlementOffers

* * *

## 36.2.3 Conflicts in Appeal or Certiorari Recommendations and Settlement Offers

**36.2.3.1** **(08-11-2004)**

### Conflicts in Appeal or Certiorari Recommendations

1. This subsection discusses conflicts with the Department of Justice concerning appeal or certiorari recommendations.


**36.2.3.1.1** **(08-11-2004)**

#### Conflicts with Department of Justice - General

1. The recommendations of the Tax Division will sometimes conflict with those of the Office of Chief Counsel. Conflicts of this nature may involve both whether to appeal the case or certain issues and whether or not to raise certain arguments, including additional arguments.

2. When its recommendation to the Solicitor General conflicts with that of the Office of Chief Counsel, the Appellate Section will send to the appropriate Associate office copies of its recommendation at the same time it is forwarded to the Assistant Attorney General for approval. Time and circumstances permitting, the Assistant Attorney General has agreed to withhold final action on the Tax Division's recommendation in order to reconcile the differences. A conference may be held to discuss the recommendations.


**36.2.3.1.2** **(08-11-2004)**

#### Conflicts with Department of Justice - Appeal Recommendations

1. The procedures for addressing conflicts with the Department of Justice are similar regardless of the trial court in which the case originated. In Tax Court cases, the conflict in recommendations will not involve any of the trial sections in the Tax Division.


**36.2.3.1.2.1** **(08-11-2004)**

##### Delivery of Conflicting Recommendation

1. Upon receipt of the conflicting recommendation from the Tax Division, copies of both the Chief Counsel's appeal letter and the Tax Division's recommendation are made and immediately hand-carried to the responsible Associate Chief Counsel and the reviewer and attorney handling the case.

2. In some instances, the attorney may be advised by phone, email or fax that a proposed recommendation of the Tax Division to the Solicitor General differs from the recommendation of the Chief Counsel. In that instance, the attorney should alert the reviewer of the potential conflict immediately. If the proposed recommendation is available, it should be distributed as described above.


**36.2.3.1.2.2** **(08-11-2004)**

##### Memorandum to Associate

1. Upon learning that the Tax Division's recommendation to the Solicitor General is contrary in whole or in part to the Chief Counsel's recommendation regarding appeal or certiorari, the Associate may require the branch attorney to prepare a brief memorandum to the Associate Chief Counsel for decision as to whether a conference should be sought.

2. The memorandum may be signed by the attorney or branch managers and should identify the case, its issues, and discuss the reasons for any action recommended, including whether a conference should or should not be sought with the Department of Justice.

3. If the Appellate Section opposes prosecution of the appeal on the basis of a position set forth in a regulation, revenue ruling, or revenue procedure, the memorandum should address the merits of that position.

4. Any unusual factors in the case should be brought to the attention of the reviewers, such as:



   - Interest expressed in the case by the Department of the Treasury, the Commissioner, the Chief Counsel, or other divisions of the Service

   - Comments on the case by the news media or tax commentators

   - Extraordinarily large or small amount of tax involved

   - Other cases pending in litigation

   - Major issues affecting an entire industry, or adverse or favorable precedent within the appellate circuit


5. The memorandum should consider the following options:



   - Acquiescence to the Tax Division's recommendation

   - A protest conference with the Tax Division

   - The submission of additional views to the Tax Division or Solicitor General

   - Permitting the Solicitor General to determine the appeal issue on the existing writings without further discussion


6. The Associate Chief Counsel attorney should ensure that the reviewers and Associate Chief Counsel have all the pertinent documents and files. At a minimum, this requires transmittal of copies of the appeal letter, the briefs, and the court's opinion. Any other memoranda or guidance that may be helpful in obtaining a quick grasp of the case should also be sent with the memorandum.


**36.2.3.1.2.3** **(08-11-2004)**

##### Coordination with Other Associate Offices

1. If the conflict with the Tax Division involves an issue or argument within the jurisdiction of another branch within the Associate's office, or in another Associate's office, the decision with respect to further action should be coordinated with that branch or Associate.

2. Due to the time constraints, informal communication is imperative, either by phone, email or in person. The matter must be brought to the attention of the appropriate manager as quickly as possible.

3. Copies of the Tax Division's memorandum and the appeal letter should be hand-carried to the chief of the appropriate branch or front office of the other Associate. Generally, a transmittal form addressed to the branch chief or Associate and signed by the attorney's reviewer should be attached, pointing out the conflict and requesting comments or suggestions as to further action. A response date should also be requested. Copies should also be provided to the appropriate Division Counsel.


**36.2.3.1.2.4** **(08-11-2004)**

##### Associate Chief Counsel Recommendation

1. The Associate Chief Counsel may convey the office's views to the Tax Division by telephone, or may request that the Office of Chief Counsel be given the opportunity of a protest conference with the Department of Justice attorneys to urge adoption of the Office of Chief Counsel's recommendation.


**36.2.3.2** **(08-11-2004)**

### Offers in Settlement

1. In all cases, except those filed in the Tax Court, compromise authority vests with the Department of Justice when the case is referred for suit or defense. In Tax Court cases, compromise authority is vested in the Department of Justice when a notice of appeal is filed. The Department of Justice uses the term settlement and not compromise.

2. The basic principles in the settlement of a court of appeals case are generally the same as in the settlement of a trial court case, taking into consideration the lower court's holding on the issues.



1. Offers that might have been acceptable prior to the trial court's decision may no longer be acceptable in view of the facts established in the record and the court's holding. Thus, generally, a court's holding for the Government is not susceptible to settlement when the case is on appeal.

2. The clearly erroneous standard of review is used by appellate courts for issues that are primarily factual. Since the clearly erroneous standard is a high standard that is difficult to meet, compromise of a factual issue generally should not be recommended to the Department of Justice unless it reasonably appears that the determination by the lower court cannot be sustained in the appellate court.

3. Settlement of court of appeals cases is usually upon the basis of recent rulings or other recent Service position, recent court decisions, new legislation, doubtfulness of the lower court's holding as a matter of law, etc. In some instances settlement of a case on appeal may be justified upon the basis of its relationship to other cases or the effect of an appellate decision on the overall administration of the tax laws.

4. In the instance of Tax Court cases, consideration must be given to the value of preserving the integrity of an opinion of a Court with national jurisdiction in proportion to the chances that an appellate panel of non-specialist judges may overturn the holding.


3. The Office of Chief Counsel does not favor offers based solely upon inability of the taxpayer to pay the deficiency determined by the Tax Court, or liability determined in litigation in district court or the Court of Federal Claims. The taxpayer's ability to pay the correct tax liability should be a matter for consideration by the Area Director, or other Service officials, upon the filing of an offer-in-compromise after conclusion of the litigation.


**36.2.3.2.1** **(08-11-2004)**

#### Procedures

1. The Department of Justice will request the views and recommendation of the Office of Chief Counsel when it receives a compromise offer in a case on appeal. The Associate office handling the case will in turn provide a copy of the offer letter to the Area Counsel attorney involved in the case in the court below. Normally, the recommendation of the Chief Counsel's office should be submitted to the Department of Justice within 15 working days of receipt. The Associate Chief Counsel attorney should prepare a letter addressed to the Assistant Attorney General, Tax Division, Department of Justice.



1. Before submitting a letter recommending acceptance of the compromise offer to the reviewer, the Associate Chief Counsel attorney must solicit and consider the views of the Area Counsel attorney who handled the case in the lower court.

2. If the Associate Chief Counsel attorney recommends rejection of the compromise offer, and the recommendation is approved by the reviewer, the letter will be signed in the name of the Chief Counsel by the reviewer without further review.

3. If the attorney's recommendation is to accept the offer, and the recommendation is approved by the attorney's reviewer, the reviewer should forward the proposed letter to the Associate Chief Counsel. The letter will be signed by the Associate or Chief Counsel as appropriate.

4. The Associate Chief Counsel attorney should bear in mind the status of the case and whether the offer requires immediate reply. If received just prior to the hearing in the court of appeals, it may be necessary to transmit to the Department of Justice the Chief Counsel's recommendation on the offer within one or two days of receipt.

5. If the offer is not considered acceptable, the letter should usually indicate what offer, if any, the Office of Chief Counsel would consider an acceptable basis of settlement.


2. Any inquiries received directly from the taxpayer by Chief Counsel attorneys regarding settlement of a case should be immediately forwarded to the Department of Justice as they have jurisdiction over the case.

3. If the settlement offer would result in an overpayment, the Associate Chief Counsel attorney should request the appropriate Area Counsel office to immediately secure an updated transcript of account unless it is readily apparent that no settlement should be recommended.



1. Upon receipt of the transcript of account, the Area Counsel office should request that a computation statement be made reflecting the settlement offer. _See_ CCDM 34.7.

2. If it is recommended to the Department of Justice that the settlement offer not be accepted and a counter-offer is suggested, a computation should be transmitted to the Department of Justice along with the views of the Chief Counsel.


4. In many instances, the taxpayer requests a conference with the Department of Justice prior to submitting a definite offer. In some instances, a conference is requested simultaneously with or after the submission of the offer.



1. The Department of Justice arranges the conference and invites participation on behalf of the Chief Counsel.

2. The assigned attorney participates fully in these conferences. The attorney is not just an observer and is expected to be thoroughly familiar with the facts and law on the issues involved. The attorney must remember, however, that the Department of Justice attorney manages the conference and is in full control.

3. The Associate Chief Counsel attorney should express the Office of Chief Counsel's views on the issues involved and not the attorney's personal views. The Chief Counsel's official views on the settlement are set forth in the letter to the Department of Justice.

4. If a conference is arranged after receipt of the offer, the letter to the Department of Justice thereon generally should not be forwarded until after the conference is held, and the factors developed at such conference should be taken into consideration in determining the position of the Office of Chief Counsel.


5. If the offer is recommended for acceptance, the attorney should ascertain whether by reason of payment of the deficiency determined by the Tax Court, or otherwise, the acceptance of such offer would result in an overpayment in excess of $2 million, which would require reporting to the Joint Committee on Taxation. See section 6405.



1. If the total of the deficiencies determined by the Tax Court, together with interest thereon, are in excess of $2 million and an appeal bond was not filed, a fax should be sent to the Internal Revenue Service Campus to ascertain whether such deficiencies and interest have been paid in whole or in part.

2. Even though the Chief Counsel's recommendation is against acceptance of the offer, if it appears from informal discussion with the Department of Justice that the department may accept the offer and such acceptance would result in a Joint Committee case, the attorney should note that it will be a Joint Committee case in the letter to the Department of Justice.


6. When the offer is acted upon based on litigation hazards by or on behalf of the Attorney General, the Department of Justice notifies the taxpayer of the action taken, and forwards a copy of the acceptance or rejection letter to the Office of Chief Counsel. If the offer is accepted by the Department of Justice, the letter from the Department of Justice should be sent to the Area Director as indicative of the final determination in the case unless the case is remanded for the determination of other issues.

7. If the Department of Justice forwards to the Office of Chief Counsel an offer-in-compromise based solely upon inability to pay the determined deficiency in a Tax Court case or the judgment in a district court or Court of Federal Claims case, appropriate recommendations should be made.



1. In this instance it may be necessary to have the revenue officer verify the reported assets and liabilities of the taxpayer before final consideration can be given. In these cases the Department of Justice usually attempts to delay the court of appeals proceedings to permit this verification.

2. If such offer is accepted by the Department of Justice, the department will arrange for the dismissal of the appeal and the case will be closed upon an administrative settlement pursuant to the offer as accepted.

3. For these types of offers the decision of the Tax Court is not revised to accord with the amount to be paid by the taxpayer. It is essential that the Tax Court decision remain undisturbed as to the correct determination of tax liability, particularly if the accepted offer embodies a collateral agreement under which the taxpayer, for a period of years, pays a percentage of his earnings towards the tax liability determined by the Tax Court.

4. In these cases it should be noted on the closing memorandum that the case was handled by administrative settlement and a copy of the letter and other accompanying documents from the Department of Justice should be attached to the closing memorandum.


**36.2.3.2.2** **(08-11-2004)**

#### Conflicts with Department of Justice Recommendation

1. The provisions of CCDM 36.2.3, Conflicts in Appeal or Certiorari Recommendations, are generally applicable to situations where there is a conflict in recommendations regarding settlement of cases on appeal.


**36.2.3.2.3** **(08-11-2004)**

#### Cases Remanded to the Tax Court after Settlement

1. If the case is settled without a decision on the merits by a court of appeals, it is generally remanded to the lower court. Normally, the Department of Justice decides, upon such settlement, to file a stipulation with the court of appeals for remand of the case to the Tax Court for entry of a revised decision in accordance with the agreement of the parties.

2. In some instances the Department of Justice decides to file the computation of the revised tax liability, pursuant to the settlement, with the court of appeals. In this instance the remand specifies the deficiency or overpayment that is to be entered by the Tax Court in its revised decision. Also, in some instances, a court of appeals may enter a judgment, with computations, which does not require further action by the Tax Court.

3. See also CCDM 36.2.5.12, Cases Remanded to the Tax Court/Recomputations.


**36.2.3.3** **(08-11-2004)**

### Court Costs in Appellate Cases

1. Under Fed. R. App. P. 39(a), the following rules apply unless the law provides or the court orders otherwise:



1. If an appeal is dismissed, costs shall be taxed against the appellant.

2. If a judgment is reversed, costs shall be taxed against the appellee.

3. If a judgment is affirmed, costs are taxed against the appellant.

4. If a judgment is affirmed or reversed in part, modified, or vacated, costs shall be taxed only as the court orders.


2. Costs relating to the printing of the briefs and appendix are awardable in the court of appeals.

3. Costs for or against the United States, its agency, or officer will be assessed under Rule 39(a) only if authorized by law. Fed. R. App. P. 39(b).

4. Prevailing taxpayers were once able to recover in the Tax Court certain costs incurred in regard to appeals if costs had been awarded to that party by the appellate court. Recoverable costs were those for preparation and transmission of the record, appeal bonds, and filing of the notice of appeal. In _Rodrigues v. Commissioner_, T.C. Memo. 1982–324, the Tax Court held that there is no statutory authority permitting the award of those costs in the Tax Court. Since Rule 39(e) of the Federal Rules of Appellate Procedure makes these costs awardable only by the trial court, the Tax Court's holding precludes their recovery.

5. Section 6673(b)(3) provides for the assessment and collection, in the same manner as a tax, of any monetary sanctions, penalties or costs awarded by the court of appeals to the United States.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part36/irm_36-002-003#addtoany "Show all")

A2A