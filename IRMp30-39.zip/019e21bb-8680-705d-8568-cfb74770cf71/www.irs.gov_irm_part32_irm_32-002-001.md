---
url: "https://www.irs.gov/irm/part32/irm_32-002-001"
title: "32.2.1 Introduction to the Chief Counsel Publication Handbook | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part32/irm_32-002-001#main-content)

- 32.2.1  [Introduction to the Chief Counsel Publication Handbook](https://www.irs.gov/irm/part32/irm_32-002-001#idm140208784291632)
  - 32.2.1.1  [Role of Published Guidance in Tax Administration](https://www.irs.gov/irm/part32/irm_32-002-001#idm140208757478208)
  - 32.2.1.2  [Purpose of the Publication Handbook](https://www.irs.gov/irm/part32/irm_32-002-001#idm140208757573648)
  - 32.2.1.3  [Updating the Publication Handbook](https://www.irs.gov/irm/part32/irm_32-002-001#idm140208784301888)
  - Exhibit  32.2.1-1  [Review of Tax Regulations under Executive Order 12866](https://www.irs.gov/irm/part32/irm_32-002-001#idm140208784300208)

# Part 32. Published Guidance and Other Guidance to Taxpayers

# Chapter 2. Chief Counsel Publication Handbook

# Section 1. Introduction to the Chief Counsel Publication Handbook

* * *

## 32.2.1 Introduction to the Chief Counsel Publication Handbook

#### Manual Transmittal

November 12, 2019

#### Purpose

(1) This transmits new CCDM 32.2.1, Publication Handbook, Introduction to the Chief Counsel Publication Handbook.

#### Material Changes

(1) CCDM 32.2.1.1 is being updated to add text regarding the Policy Statement on the Tax Regulatory Process.

#### Effect on Other Documents

This section supersedes CCDM 32.2.1, dated August 11, 2004.

#### Audience

Chief Counsel

#### Effective Date

(11-12-2019)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**32.2.1.1** **(11-12-2019)**

### Role of Published Guidance in Tax Administration

1. The mission of the Internal Revenue Service is to provide America’s taxpayers top quality service by helping them understand and meet their tax responsibilities and by applying the tax law with integrity and fairness to all. It is the duty of the Service to correctly apply the laws enacted by Congress; to determine the reasonable meaning of various Internal Revenue Code provisions in light of the Congressional purpose in enacting them; and to perform this work in a fair and impartial manner, with neither a government nor a taxpayer point of view.

2. At the heart of administration is interpretation of the Internal Revenue Code. It is the responsibility of each person in the Service charged with the duty of interpreting the law to try to find the proper interpretation of the statutory provision and not to adopt a strained construction in the belief that he or she is "protecting the revenue." The revenue is properly protected only when we ascertain and apply the proper interpretation of the statute.

3. The mission of the Office of Chief Counsel is to serve America’s taxpayers fairly and with integrity by providing correct and impartial interpretation of the internal revenue laws and the highest quality legal advice and representation for the Service. Chief Counsel’s primary means of providing correct and impartial interpretation of the internal revenue laws is through the publication of its interpretations in the Internal Revenue Bulletin (IRB).

4. Published Guidance will be issued in accordance with the policies expressed in the March 5, 2019 Department of the Treasury Policy Statement on the Tax Regulatory Process. See Exhibit 32.2.1-1


**32.2.1.2** **(08-11-2004)**

### Purpose of the Publication Handbook

1. This Handbook, to be referred to as the Chief Counsel Publications Handbook, is the authoritative source for procedures and instructions pertaining to preparing, reviewing, and processing publications. For purposes of this Handbook, publications are defined as revenue rulings, revenue procedures, notices, announcements, and news releases. This Handbook can be cited as the Chief Counsel Publications Handbook or CCDM 32.2.


**32.2.1.3** **(08-11-2004)**

### Updating the Publication Handbook

1. This Handbook will be periodically updated. Suggestions for corrections or revisions should be submitted to the Associate Chief Counsel (PA) with a courtesy copy to the Associate office of the drafting attorney.


**Exhibit 32.2.1-1**

### Review of Tax Regulations under Executive Order 12866

![This is an Image: 29173001.gif](https://www.irs.gov/pub/xml_bc/29173001.gif)

> Page 1 of Review of Tax Regulations under Executive Order 12866 memorandum.

[Please click here for the text description of the image.](https://www.irs.gov/media/29173001.gif "")

![This is an Image: 29173002.gif](https://www.irs.gov/pub/xml_bc/29173002.gif)

> Page 2 of Review of Tax Regulations under Executive Order 12866 memorandum.

[Please click here for the text description of the image.](https://www.irs.gov/media/29173002.gif "")

![This is an Image: 29173003.gif](https://www.irs.gov/pub/xml_bc/29173003.gif)

> Page 3 of Review of Tax Regulations under Executive Order 12866 memorandum.

[Please click here for the text description of the image.](https://www.irs.gov/media/29173003.gif "")

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part32/irm_32-002-001#addtoany "Show all")

A2A