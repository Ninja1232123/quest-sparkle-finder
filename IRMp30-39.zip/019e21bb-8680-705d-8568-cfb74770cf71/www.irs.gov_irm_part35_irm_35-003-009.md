---
url: "https://www.irs.gov/irm/part35/irm_35-003-009"
title: "35.3.9 Miscellaneous Motions | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-003-009#main-content)

- 35.3.9 [Miscellaneous Motions](https://www.irs.gov/irm/part35/irm_35-003-009#idm140270551686224)
  - 35.3.9.1 [Motions Pertaining to Discovery](https://www.irs.gov/irm/part35/irm_35-003-009#idm140270551685808)

    - 35.3.9.1.1 [Review of Sufficiency of Response to a Request for Admissions](https://www.irs.gov/irm/part35/irm_35-003-009#idm140270551644432)
    - 35.3.9.1.2 [Protective Orders](https://www.irs.gov/irm/part35/irm_35-003-009#idm140270551501280)
    - 35.3.9.1.3 [Discovery Enforcement Actions and Sanctions](https://www.irs.gov/irm/part35/irm_35-003-009#idm140270551497744)

  - 35.3.9.2 [Motions Pertaining to Bankruptcy](https://www.irs.gov/irm/part35/irm_35-003-009#idm140270551494000)

    - 35.3.9.2.1 [Bankruptcy Prior to Tax Court Petition](https://www.irs.gov/irm/part35/irm_35-003-009#idm140270551490576)
    - 35.3.9.2.2 [Bankruptcy While in Tax Court](https://www.irs.gov/irm/part35/irm_35-003-009#idm140270551486320)

  - 35.3.9.3 [Oral Motions](https://www.irs.gov/irm/part35/irm_35-003-009#idm140270551480976)
  - 35.3.9.4 [Extensions of Time](https://www.irs.gov/irm/part35/irm_35-003-009#idm140270551629664)
  - 35.3.9.5 [Motions to Consolidate](https://www.irs.gov/irm/part35/irm_35-003-009#idm140270551624416)
  - 35.3.9.6 [Motions to Change Place of Trial](https://www.irs.gov/irm/part35/irm_35-003-009#idm140270551614112)
  - 35.3.9.7 [Withdrawal of Counsel](https://www.irs.gov/irm/part35/irm_35-003-009#idm140270551609584)
  - 35.3.9.8 [Motions to Correct Transcript](https://www.irs.gov/irm/part35/irm_35-003-009#idm140270551603456)
  - 35.3.9.9 [Motions to Correct Caption or for Substituted Petitioner](https://www.irs.gov/irm/part35/irm_35-003-009#idm140270551503296)
  - 35.3.9.10 [Motion to Enter Decision Following Adjudication by Another Courtof Concurrent Jurisdiction](https://www.irs.gov/irm/part35/irm_35-003-009#idm140270551561104)
  - 35.3.9.11 [Motion that Court Retain Custody of Materials](https://www.irs.gov/irm/part35/irm_35-003-009#idm140270551555696)
  - 35.3.9.12 [Motion for Stay of Civil Proceedings](https://www.irs.gov/irm/part35/irm_35-003-009#idm140270551543264)
  - 35.3.9.13 [Fugitives From Justice](https://www.irs.gov/irm/part35/irm_35-003-009#idm140270551534944)

# Part 35. Tax Court Litigation

# Chapter 3. Motions

# Section 9. Miscellaneous Motions

* * *

## 35.3.9 Miscellaneous Motions

**35.3.9.1** **(08-11-2004)**

### Motions Pertaining to Discovery

1. This section discusses motions pertaining to discovery.


**35.3.9.1.1** **(08-11-2004)**

#### Review of Sufficiency of Response to a Request for Admissions

1. See CCDM 35.4.3.6 for a more detailed discussion on enforcement motions and sanctions for discovery matters. A motion to review the sufficiency of any response or objection to a request for admissions may be filed with the court by the requesting party. The court can be expected to schedule a hearing on the motion in Washington, D.C., but upon request will consider holding the hearing at another location. T.C. Rule 50(b)(2). Under T.C. Rule 50(b), the court may require a written response to such motion, and will not necessarily hold a hearing depending on the nature of the case and the particular problems involved. Thus, the Field attorney should consider the preparation of an objection to the motion and specifically request a hearing.

2. Generally, the hearing on a motion to review the sufficiency of a response set for Washington, D.C. will be handled by attorneys assigned to APJP, Branch 3. Field Counsel, however, can designate the Field attorney to argue the motion. The legal and administrative files should be sent to APJP, Branch 3 immediately upon request. In some situations APJP, Branch 3 may request that the Field attorney attend the hearing if possible.

3. When the respondent moves for review of the petitioner’s response, the motion will be prepared, executed and filed in the field.


**35.3.9.1.2** **(08-11-2004)**

#### Protective Orders

1. See CCDM 35.4.6.5 and T.C. Rule 103 for a discussion of motions for protective orders.


**35.3.9.1.3** **(08-11-2004)**

#### Discovery Enforcement Actions and Sanctions

1. See CCDM 35.4.3.6 for a discussion of discovery enforcement motions and sanctions.


**35.3.9.2** **(08-11-2004)**

### Motions Pertaining to Bankruptcy

1. This section discusses motions pertaining to bankruptcy.


**35.3.9.2.1** **(08-11-2004)**

#### Bankruptcy Prior to Tax Court Petition

1. If the Tax Court petition was filed in violation of the automatic stay, _see_ CCDM 35.2.1.1.8(10), a motion to dismiss for lack of jurisdiction should be filed.


**35.3.9.2.2** **(08-11-2004)**

#### Bankruptcy While in Tax Court

1. See CCDM 35.2.1.1.8 for a discussion of the impact of the filing of a bankruptcy petition on a Tax Court proceeding.

2. The Field attorney is an officer of the Tax Court and has an obligation to notify that court of any impediment to continuation of its proceedings when a petitioner in the Tax Court is in bankruptcy. If the petitioner has not previously notified the Tax Court, the appropriate document to be prepared immediately on acquiring knowledge of the bankruptcy case is a Notice of Proceeding in Bankruptcy. Exhibit 35.11.1–70. If possible, petitioner or petitioner’s counsel should join in the notice to the Tax Court advising the court of all essential details including the location of the court, the date of filing, the name and address of the trustee, if any, etc. In particular, the Notice of Proceeding in Bankruptcy must inform the Tax Court of the status of the automatic stay since it is the existence of the stay that affects how the Tax Court will proceed. After notification of the stay imposed on the Tax Court proceeding by the bankruptcy case, the Tax Court will suspend all actions with respect to its case. Generally, the Tax Court will order the parties to prepare a status report (e.g., within six months). The court may also order that either party report as soon as the party has knowledge that the automatic stay has been lifted by the bankruptcy court. The Tax Court has asked specifically that trial counsel monitor the bankruptcy proceedings and conscientiously report as soon as possible on the status of the automatic stay. The Field attorney and reviewer should always consult with CBS, Branch 2 to determine the current office litigating position in any situation involving related bankruptcy proceedings. Exhibit 35.11.1–1, Issues Requiring Associate Office Review. If an answer has not been filed as of the commencement of the bankruptcy case, the Notice of Proceeding in Bankruptcy should include a request for 60 days to answer from the date respondent is notified by the Tax Court of the lifting of its stay.

3. The bankruptcy court without lifting the automatic stay may determine the merits of the substantive tax issues that are before the Tax Court. Once the decision of the bankruptcy court has become final, it will be necessary to close out the pending Tax Court case. The appropriate motion to be filed in that instance will be a Motion for Entry of Decision and the ground for the motion is the res judicata effect of the bankruptcy court’s determination. In the alternative, the parties may submit a stipulated decision in conformity with the bankruptcy court’s judgment. Similarly, if the automatic stay is lifted and a decision of the Tax Court becomes final before action by the bankruptcy court on the merits, the Field attorney should forward a copy of the final decision and opinion, if any, to the Territory Manager, Insolvency. Pursuant to Treas. Reg. § 301.6871(b)-1(b), the Service may file a copy of the Tax Court’s decision with the bankruptcy court and move that court to resolve the government’s claim against the bankruptcy estate.


**35.3.9.3** **(08-11-2004)**

### Oral Motions

1. Tax Court Rule 50 provides that motions made during a hearing or at trial need not be in writing unless the court so directs. If the court directs respondent to file a written motion it shall be filed with the court prior to completion of the trial or prior to the time designated by the court. When the Field attorney intends to make a certain motion during a trial calendar or motion session, a written motion should be prepared in advance for presentation to the court.


**35.3.9.4** **(08-11-2004)**

### Extensions of Time

1. Every effort should be made by the Field attorney, reviewers, and those responsible for the filing of motions, answers, briefs, etc., to file these documents timely in accordance with the rules of the Tax Court. If with due diligence this cannot be done, and good and valid reasons exist for requesting an extension of time within which to move or answer or within which to file a brief, such reasons should be embodied in the motion for an extension of time. The Field attorney should also contact the petitioner or petitioner’s counsel in order to request concurrence in the motion. The endorsement of the petitioner, or petitioner’s counsel, is not needed, but a statement should be put in the motion if petitioner has no objection. A refusal to concur should also be noted in the motion. If the Field attorney cannot contact petitioner or petitioner’s counsel, this fact should be stated in the motion for extension of time. These motions should be prepared and completed for filing with the Tax Court a sufficient length of time before the due date of the document for which the extension of time is requested in order that the court may timely act upon the extension motion.


**35.3.9.5** **(08-11-2004)**

### Motions to Consolidate

1. When two or more cases are at issue involving the same taxpayer, presenting a series of years, or if there are several taxpayers’ petitions which raise the same issue or substantially the same issue as to which the same evidence would be introduced in each case, and in similar circumstances, a motion to consolidate the proceedings should, in due course, be filed with the Tax Court pursuant to T.C. Rule 141, setting forth the reasons for so moving. Exhibit 35.11.1–71. A motion to consolidate should be used particularly if different petitioners raise the tax effect of a transaction to which they were parties and the Service is in a whipsaw position. The motion should request consolidation for the purpose of the trial, the filing of briefs, and the promulgation of the opinion. Cases are never consolidated for decision. All the cases to be consolidated must be on the same trial calendar or on the general docket for the same place of trial. The caption to consolidate the cases should list the various petitioners and their docket numbers in numerical order beginning with the earliest docket number. If there is a related case not on the trial calendar which should be consolidated with those on the trial calendar, a preliminary step should be taken to have the case placed on the trial calendar, i.e., a Motion to Calendar and Consolidate or, in the Alternative, to Continue should be filed. Exhibit 35.11.1–52. If the place of trial of a related case is not in the same city as the other case, a motion to change place of trial should likewise be filed. _See_ Exhibit 35.11.1–72. If other noncommon issues have been raised by the petitioner, the parties may consult with the trial judge on whether those issues should be tried with the consolidated issues or tried separately.

2. When the taxpayers agree to consolidate related cases, it is preferable to file the motion as soon as practicable and before the issuance of the trial calendar. This will assure that all cases which should be tried together will be set at the same session of the court. It also simplifies the filing of motions pertaining to the consolidated group of cases.

3. If consolidation of an "S" case with a regular case is advisable, a separate motion to remove "S" designation should accompany the motion to consolidate. The motion to consolidate should omit the "S" designation in anticipation of the court granting the motion to remove the "S" designation.

4. In filing motions to consolidate (or any document concerning consolidated cases) the docket numbers must be listed in sequential order (earliest docket number first and so on). The earliest docket becomes the lead case in the consolidated group.


**35.3.9.6** **(08-11-2004)**

### Motions to Change Place of Trial

1. See CCDM 35.2.2.14.1 for a discussion of motions to change place of trial.

2. See Exhibit 35.11.1–72 for a sample motion to change place of trial.


**35.3.9.7** **(08-11-2004)**

### Withdrawal of Counsel

1. A motion by counsel for the petitioner to withdraw as attorney of record may be acted upon by the court ex parte if the motion indicates that such attorney has complied with the court’s rules on withdrawal. T.C. Rule 24(c) requires that a motion to withdraw the appearance as counsel of record set forth the current mailing address and telephone number of the party in respect of whom or by whom the motion is filed. If counsel cannot communicate with the party, then the motion: (1) should so state; (2) include the last known address and telephone number of the party; and (3) any other information which might aid the court in reaching the party. The motion must also show that prior notice of the motion has been given by petitioner’s counsel to petitioner, or by petitioner to petitioner’s counsel, as the case may be. With respect to the withdrawal of counsel in cases calendared for trial, upon the granting of such motion the court may remind the petitioner that the withdrawal of counsel is not sufficient alone under the rules of the court to form a basis for a continuance of the case from the trial session at which it is set. When afforded the opportunity, respondent should state either objection or no objection to withdrawal, but it is noted that respondent’s objections to withdrawal of counsel are rarely, if ever, successful. Objection to withdrawal of counsel therefore should only be made if respondent will suffer substantial prejudice should counsel be permitted to withdraw.


**35.3.9.8** **(08-11-2004)**

### Motions to Correct Transcript

1. If errors of substance appear in the transcript of the testimony and proceedings at the trial, an appropriate motion should be prepared to correct the record designating the page and line and stating the manner in which the record is to be corrected. Every effort should be made to secure the agreement of counsel for the petitioner to these corrections. If the petitioner has found errors in the record to be corrected which can be agreed to by the respondent, all of the errors to which both parties agree should be embodied in a joint motion. A motion to correct the transcript be filed with the court cannot be obviated through a stipulation of the parties. Motions to correct the transcript should be filed as soon after the receipt of the transcript as possible and before the filing of the brief. See Exhibit 35.11.1–73 for a sample motion to correct transcript.


**35.3.9.9** **(08-11-2004)**

### Motions to Correct Caption or for Substituted Petitioner

1. In estate and trust cases in which the caption on the petition is not in accord with T.C. Rule 23(a)(1), the following procedures are applicable: The petitioner, or counsel for petitioner, should be contacted and attention called to the incorrect caption of the petition with the suggestion that petitioner file a motion to correct the caption on the petition to which the respondent will not object. In the event this course of action is not feasible or the petitioner refuses to correct the caption, a motion to correct the caption should be prepared. This motion should be filed and granted whenever possible prior to the filing of a motion going to the jurisdiction of the court or to the contents of the petition, or the filing of an answer. When such course of action is not feasible, a motion to correct the caption should accompany the first other type of document to be filed with the court. In this latter instance, the other type of document will bear the old caption. Exhibit 35.11.1–74. Where the motion to correct caption, whether petitioner’s or respondent’s, has been filed but has not been granted prior to service or filing of the other document, the Field attorney should check the Tax Court’s website (docket search) and, if necessary contact APJP, Branch 3, to determine whether the other type of document should be filed bearing the new or the old caption.

2. T.C. Rule 63 sets forth the requirements for substitution of parties and for change of the name of the party petitioner. A motion for substitution of the party petitioner or to change the name of the party petitioner is ordinarily filed by the petitioner; however, the motion may be filed by respondent in appropriate circumstances as an accommodation to petitioner. When the petitioner’s counsel indicates a necessity to substitute a party petitioner or to change the name of the petitioner, it will save the time of both the court and the parties if such motion is endorsed No Objection on the part of the respondent if the facts with respect to the party petitioner justify it. Usually, this situation arises in cases in which individual petitioners may die or become incapacitated prior to the submission of the case to the court for decision and such individual petitioner’s executor, administrator, or other personal representative is to be substituted as the party petitioner. It may also arise with respect to corporate petitioners when the original corporation is merged into another corporation (or under certain circumstances dissolved prior to the court’s decision). There are, of course, other instances in which it is necessary to substitute party petitioners or change the name of the party petitioners, and the Field attorney should be aware of this situation and make the necessary statutory and case law research on the particular facts of the case. _See_, _e.g._, Exhibit 35.11.1–75. In any event in which the necessity for a change of the party petitioner comes to the attention of Field Counsel, petitioner’s counsel should be contacted and requested to file an appropriate motion with the court which will be Endorsed No Objection on behalf of the respondent.

3. It is important not only that each case be properly captioned, but that appropriate substitution of party petitioners or a change in the name of the party petitioner be timely made prior to the entry of the court’s decision. This course of action will assure that the decision is entered with respect to the proper party against whom the deficiency or liability should be assessed.

4. In cases having related bankruptcy or receivership aspects, problems may arise as to the proper party to prosecute the Tax Court case. The Field attorney should research the applicable statutory and case law to determine whether it is necessary to substitute the trustee, receiver, or other fiduciary as the party petitioner in the Tax Court case. _See_ CCDM 35.2.1.1.8. If it is determined that the trustee, receiver, or other fiduciary is the proper party to prosecute the Tax Court case and should be substituted as the party petitioner, the fiduciary should be contacted. In the event a satisfactory arrangement cannot be worked out with the fiduciary, the Tax Court should be notified by an appropriate motion as to the necessity for the substitution of the party petitioner. There are many legal questions involved in this course of action as to whether the fiduciary must enter the Tax Court case, or what the effect of a Tax Court decision is on the bankruptcy or receivership case in the event the fiduciary does not, pursuant to an order of the Tax Court, enter such proceeding as the party petitioner. Each case must be handled on its specific facts and circumstances, and a practical approach taken in solving the problem. In some cases it may be necessary to dispose of the Tax Court case without substitution of the proper party petitioner. Guidance may be sought from APJP, Branch 3 and CBS, Branch 2 concerning how best to proceed in these situations.


**35.3.9.10** **(08-11-2004)**

### Motion to Enter Decision Following Adjudication by Another Court of Concurrent Jurisdiction

1. Occasions may arise in which the Tax Court and another court have concurrent jurisdiction of the taxpayer and the subject matter in litigation. These are usually two cases having related insolvency proceedings and, under certain circumstances, may involve decedent estate cases. While it is the preference of the Office of Chief Counsel that generally the merits of the tax liability should be determined by the Tax Court and not in the related proceedings, this will not always be possible. In some instances the court in the related proceedings determines the merits of the tax liability. Field Counsel may seek legal advice concerning any problem involved in this type of situation from CBS, Branch 2 and APJP, Branch 3. If the court in the related proceedings has in fact determined the merits of the tax liability, an assessment has been made consistent with such determination, and the amount of such assessment with applicable additions to the tax has been or is to be collected, the Tax Court case must, nevertheless, be properly closed by the entry of a decision. If the other court has in fact determined the merits of all issues, all taxes, and all penalties pending before the Tax Court, it is preferable that the Tax Court case be closed by a stipulated decision of the parties. If this is not possible, a motion to enter decision should be filed. In such instance, the motion or the stipulation should make reference to the other court which has concurrent jurisdiction with the Tax Court, to the entry of a judgment in the other court determining the tax and penalty liability, and that by reason of the determination of the other court having concurrent jurisdiction there is a deficiency and penalty due from the taxpayer in the amount determined by the other court.


**35.3.9.11** **(08-11-2004)**

### Motion that Court Retain Custody of Materials

1. In a settled case or small tax case, it is the procedure of the Tax Court to destroy or otherwise dispose of the entire file, except for the decision document and accompanying stipulation, after the expiration of 18 months from the date of entry of decision. In a regular case decided on the merits or dismissed, the court will dispose of or destroy all exhibits not returned to the parties, but will retain the remainder of the file in accordance with its retention schedule (generally 20 years). Destruction or disposition of the exhibits in the latter instance may occur at any time after 90 days after the decision has become final. T.C. Rule 143(d)(2). Therefore, the Field attorney should request the return of any necessary original exhibits of the respondent when closing the case.

2. Although such instances are rare, cases may arise where it is desirable that the court retain custody of a document or other part of a file which would otherwise be destroyed or returned to a party, or even of an entire file. The following examples of such instances are illustrative only and are not to be deemed all-inclusive:



1. Manufactured evidence has been introduced by a petitioner, representative, or witness, and subsequent commencement of criminal, disciplinary or other proceedings is a distinct possibility.

2. An item of evidence or testimony (typically in a case settled after trial) may be needed for another case.

3. Continued possession by the court of the material in question may facilitate the stipulating of facts or the making of admissions in another case.


3. In such cases, a motion should be made requesting the court to retain the item or items needed, or the entire file, whichever is applicable for a specified period. The period specified should ordinarily be no longer than one year, with later motions to be made as and when needed. The motion should be made concurrently with the filing of the computation. In those instances where the court enters decision without requiring a computation, it should be made promptly upon notification of entry of decision. Where the need for retention becomes apparent only after entry of decision, the motion should be made immediately when the need becomes apparent. It should be noted that the 18 month period for destruction of records in settled cases runs from the date of entry of decision rather than from the date the decision becomes final.

4. Tax Court Rule 157 for a specialized motion by the petitioner to retain the court’s file in estate tax cases in which a section 6166 election has been made to extend the time for payment of the estate tax, in order to facilitate the modification of such decision in accordance with section 7481(d).


**35.3.9.12** **(08-11-2004)**

### Motion for Stay of Civil Proceedings

1. See CCDM 35.2.1.1.5.1, CCDM 35.2.2.5, CCDM 35.4.1.5.1, CCDM 35.4.6.4 and CCDM 35.5.3.4 for a discussion of the need to coordinate cases with criminal aspects.

2. There is no Tax Court rule or specific authority providing for a motion of this type and respondent should use it only on rare occasions. Some authority is found in T.C. Rule 103(a). The purpose served by such a motion is to protect the respondent from being ordered to reveal facts, theories, or identity of witnesses that are necessary or appropriate to successful prosecution of a pending criminal tax case. To allow the petitioner to discover in a civil tax case even the factual portion of the special agent’s report, for example, would be contrary to Rule 16(a)(2) of the Federal Rules of Criminal Procedure, which protects from discovery any reports and memoranda or other internal documents made by government agents in connection with the investigation or prosecution of a criminal case. A motion for stay may also be appropriate when petitioner has a valid Fifth Amendment privilege to be asserted in response to discovery, since the court will be reluctant to impose a sanction as a penalty for failure to respond to discovery on the basis of a valid constitutional privilege and respondent will otherwise be unable to obtain discovery responses to aid in trial preparation. A motion for stay of civil proceedings, except in rare and extremely compelling circumstances, should not be filed by respondent while a case involving the same tax years is still in the investigatory stage and the criminal matter has not even been referred to DJ. The pivotal stage at which a criminal tax case gains an existence of its own is when the case is referred by the Service to DJ with a recommendation of prosecution. Thus, criminal prosecution may be considered too remote by the Tax Court, and that court may be very reluctant to grant a stay, if the case has not reached DJ.


**35.3.9.13** **(08-11-2004)**

### Fugitives From Justice

1. \[Reserved\]


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-003-009#addtoany "Show all")

A2A