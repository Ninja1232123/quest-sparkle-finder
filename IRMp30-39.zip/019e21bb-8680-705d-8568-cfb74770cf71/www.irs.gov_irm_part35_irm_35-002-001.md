---
url: "https://www.irs.gov/irm/part35/irm_35-002-001"
title: "35.2.1 Tax Court Petitions | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-002-001#main-content)

- 35.2.1  [Tax Court Petitions](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887185816288)
  - 35.2.1.1  [Analysis of New Tax Court Petitions](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887186927920)
    - 35.2.1.1.1  [Statutory Notices of Deficiency and other Notices Issued by the Service](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887185639088)
    - 35.2.1.1.2  [Assessment of Uncontested Deficiencies](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887185568416)
    - 35.2.1.1.3  [Unaudited Returns](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887158566384)
    - 35.2.1.1.4  [Jeopardy Assessment](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887158563264)
      - 35.2.1.1.4.1  [Possessor of Cash](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887158561248)
      - 35.2.1.1.4.2  [Notification of Jeopardy Assessment or Abatement](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887158557728)
    - 35.2.1.1.5  [Coordination with Criminal, Refund and Collection Cases](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887157365520)
      - 35.2.1.1.5.1  [Criminal Cases](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887157362576)
      - 35.2.1.1.5.2  [Refund Cases](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887185384448)
      - 35.2.1.1.5.3  [Collection Cases](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887185616384)
    - 35.2.1.1.6  [Premature Petitions](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887185611120)
    - 35.2.1.1.7  [Imperfect Petitions](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887185604656)
    - 35.2.1.1.8  [Duplicate Petitions](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887185382896)
    - 35.2.1.1.9  [Effect of Bankruptcy](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887185381264)
    - 35.2.1.1.10  [Initial Review of"S" Cases](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887156988576)
    - 35.2.1.1.11  [Initial Review of Interest Abatement Cases](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887156986944)
    - 35.2.1.1.12  [Initial Review of Collection Due Process (CDP) Cases](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887156977696)
    - 35.2.1.1.13  [Review of Tax Shelter Cases](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887156972912)
    - 35.2.1.1.14  [Significant Case Procedures](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887156971280)
    - 35.2.1.1.15  [Initial Review of TEFRA Cases](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887190037040)
    - 35.2.1.1.16  [Initial Review of Declaratory Judgment Cases Under TEGEDC’s Jurisdiction and Section 7436 Cases](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887190030736)
      - 35.2.1.1.16.1  [Initial Review of EP Declaratory Judgment Cases](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887190028688)
      - 35.2.1.1.16.2  [Initial Review of EO Declaratory Judgment Cases](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887190022176)
      - 35.2.1.1.16.3  [Initial Review of Declaratory Judgment Cases Relating to Government Obligations](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887157513056)
      - 35.2.1.1.16.4  [Initial Review of Worker Classification Cases under Section 7436](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887157510800)
    - 35.2.1.1.17  [TEFRA: Munro Stipulation for Deficiency Cases](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887157498064)
    - 35.2.1.1.18  [TEFRA Statute of Limitations: Coordination With CIC Audit](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887185554624)
    - 35.2.1.1.19  [Jurisdictional Issues](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887185550672)
    - 35.2.1.1.20  [Motions Addressing the Petition](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887185548016)
    - 35.2.1.1.21  [Initial Review of BBA Cases](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887185546192)
    - 35.2.1.1.22  [Initial Review of Passport Cases](https://www.irs.gov/irm/part35/irm_35-002-001#idm139887185542240)

# Part 35. Chief Counsel Directives Manual Tax Court Litigation

# Chapter 2. Petition and Answer

# Section 1. Tax Court Petitions

* * *

## 35.2.1 Tax Court Petitions

#### Manual Transmittal

August 09, 2023

#### Purpose

(1) This transmits a new subsection to CCDM 35.2.1.1.22, Initial Review of Passport Cases and revised CCDM 35.2.1.1.11, Interest Abatement Cases.

#### Material Changes

(1) CCDM 35.2.1.1.22 provides procedures for initial review and coordination of new passport cases filed in the Tax Court pursuant to section 7345.

(2) CCDM 35.2.1.1.11 (1) was revised to delete the requirement that area counsel attorneys coordinate every docketed Tax Court interest abatement case with the national office.

(3) CCDM 35.2.1.1.11(3) was revised to advise area counsel attorneys to consult CC:PA:6 or 7 for any needed help with interest abatement issues in the context of partnership audits conducted under the Bipartisan Budget Act of 2015.

(4) CCDM 35.2.1.1.11(4) -- stating that the Tax Court’s small case procedures do not apply to interest abatement actions -- was deleted. An IRC provision (section 7463(f)(3)) added by the Protecting Americans from Tax Hikes Act of 2015 permits Tax Court small case treatment for interest abatement cases, if the abatement sought is $50,000 or less.

(5) CCDM 35.2.1.1.11(5) was revised to cite an IRC provision (section 6404(h)(1)(A)(ii)) that had not been adopted the last time section 35.2.1.1.11 was revised.

#### Effect on Other Documents

CCDM 35.2.1, dated July 14, 2022, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(08-09-2023)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure and Administration)

**35.2.1.1** **(07-14-2022)**

### Analysis of New Tax Court Petitions

1. Upon receipt of a case that is unanswered, the answer should be filed as soon as possible so that the procedures of Rev. Proc. 2016-22, 2016-15 I.R.B. 577, can be promptly implemented. It is the responsibility of the attorney and reviewer to make certain that Tax Court answers and other documents are prepared and mailed for timely filing with the court. While clerical tasks may be assigned to support staff, the ultimate responsibility for timely compliance with the court's rules cannot be shifted by assignment to such personnel. It is the responsibility of the attorney and supervisor to maintain a system that monitors whether, in fact, documents mailed to the court have been filed with the court. Any untimely filed answer, brief, or other Tax Court document must be reported, in writing, to the Associate Chief Counsel (P&A) with copies to Division Counsel and the appropriate Field Counsel office officials.

2. If the case involves an unsettled legal issue, the attorney should determine whether there are issues of a similar type that are pending in an Associate office by contacting the designated subject matter attorney listed in the Code and Subject Matter Directory. The pendency of similar issues in an Associate office may indicate the existence of a policy question and it may be necessary in the future to request legal advice to determine whether the policy considerations will have impact upon the particular case. See CCDM Part 31 and CCDM Part 33 for a discussion of the procedures available to determine the Service's position on legal issues. For fraud answers that have a related criminal case, the attorney from Division Counsel/Associate Chief Counsel (CT) who last handled the matter should be contacted to ensure proper coordination and assistance in developing the facts prior to answer. If it is agreed that disclosure under Fed. R. Crim. P. 6(e) is appropriate, Division Counsel/Associate Chief Counsel (CT) is responsible for coordinating the matter with the appropriate United States Attorney's office.

3. If, after careful research and full coordination of a legal issue, it is finally determined prior to the filing of the answer that the notice of deficiency asserts an erroneous position, Rule 33(b) of the Tax Court's Rules of Practice and Procedure would require the attorney to concede the issue in the answer.

4. All Tax Court petitions and amended petitions are screened in both the appropriate Associate office and the Field Counsel office to which they are assigned to identify significant cases ( See , CCDM 35.11.1-1, Issues Requiring Associate Office Review) and to determine which of these cases should be excluded from the significant case procedures because the issues in the case either: (a) involve well-settled principles of law; or (b) are not sufficiently complex or important to warrant the special commitment of resources envisioned by the procedures. Any case excluded from the significant case procedures will be handled under normal operating procedures.

5. Tax Court petitions are also screened in the Technical Services Support Branch to identify cases within the jurisdiction of the Division Counsel (Tax Exempt and Government Entities) (TEGEDC). Tax Court petitions and amended petitions are to be screened again by the respective Field Counsel office to confirm identification of TEGEDC cases and issues. If a TEGEDC case or issue is identified, the attorney should comply with the guidelines for coordination of TEGE issues and transfer of appropriate TEGEDC cases. See Exhibit 35.11.1-3.


**35.2.1.1.1** **(07-14-2022)**

#### Statutory Notices of Deficiency and other Notices Issued by the Service

01. Promptly upon receipt of an unanswered case, the attorney should review the petition and the statutory notice. Additional information may be needed to file a motion or answer.

02. If no notice of deficiency is attached to the petition, the attorney should determine whether a notice of deficiency has in fact been issued. If a notice of deficiency has not been issued because the tax year is still under examination, the petition is premature. Generally, Appeals Account and Processing Support (APS) will send Field Counsel a Form 15022, IRS Certification - Income/Gift/Estate Tax Statutory Notice of Deficiency NOT Issued, when APS discovers that a petition is premature for any year upon its attempt to locate an administrative file. _See_ _CCDM 35.2.1.1.6_, Premature Petitions. For any such year, the attorney should file a motion to dismiss for lack of jurisdiction. _See_ CCDM 35.3.2.5, Absence of a Valid Statutory Notice. Field Counsel should also remind Examination personnel that the statute of limitations on assessment is not tolled by a premature petition, and the ASED must be protected by extending the statute of limitations with Form 872, Consent to Extend the Time to Assess Tax, or other appropriate form, or by issuing a notice of deficiency. _See_ _CCDM 35.2.1.1.6_, Premature Petitions.

03. The statutory notice attached to the petition should be cross-checked against the statutory notice shown in the administrative file to insure that the petitioner has attached a correct and a complete copy of the statutory notice. If not, it will be necessary to make a denial in the answer and allege that a correct and complete copy of the statutory notice is attached to the answer.

04. The statutory notice and petition must be examined to determine that the party to whom the statutory notice was sent is the same as the petitioner. If there is a variance, it will be necessary to determine whether the petitioner is legally the party entitled to file a petition. If not, a motion to dismiss for lack of jurisdiction may be necessary. Similarly, it will be necessary to determine that the years petitioned are years that are contained in a statutory notice. If not, a jurisdictional motion may be required.

05. The notice of deficiency should also be reviewed to ensure that there are no jurisdictional defects. If the notice is not valid as a result of some defect, immediate consideration should be given to issuing a valid statutory notice, assuming the statute of limitations has not expired. Factors to consider in reviewing the validity of a statutory notice include:



    1. That the statutory notice was sent to the proper party and to the last-known address. _See_ CCDM 35.3.2.3, Motions to Dismiss for Lack of Jurisdiction, and CCDM 35.3.2.4, Timeliness of Petition, at http://publish.no.irs.gov/getpdf.cgi?catnum=29843.

    2. If an individual petitioner is incompetent or deceased, that the person to whom the notice was sent properly qualifies as the representative.

    3. If the addressee is a transferee, that transferee liability is properly asserted.

    4. If the addressee is a corporation, that the notice is properly addressed, that the corporation is still in existence, and that the officers have the authority to institute suit.

    5. That the statutory notice was sent to the petitioner by certified mail or registered mail.

    6. If the addressee is an estate or a trust, that the notice is properly addressed, that the estate or trust is still in existence, and that the representative has the authority to institute suit.


06. If the petition is executed other than by the petitioner and the circumstances suggest a question as to the authority of the representative to act on behalf of the petitioner, further information should be solicited to determine the authority to act for the petitioner. One such circumstance would be a representative who has been identified as either not admitted to practice before the Tax Court or whose representation has not been recognized by the court.

07. IRC section 7602(e) prohibits the service from using financial status or economic reality techniques to determine the existence of a petitioner's unreported income unless the Service has a"reasonable indication that there is a likelihood of unreported income." Section 7602(e) concerns the use of indirect methods to reconstruct the taxpayer's income through circumstantial evidence. The statutory notice should be reviewed to determine whether the Service used an indirect method. If an indirect method was used, the attorney must review the administrative file to ascertain whether the Service had a reasonable indication that the petitioner was underreporting his or her income prior to utilizing the financial status or economic reality audit techniques. If there is no evidence in the administrative file to show the Service had such an indication, serious consideration should be given to conceding the case. The attorney should contact the revenue agent to determine if the agent had any evidence of unreported income not contained in the administrative file before conceding the case, and should consider seeking legal advice to confirm the proposed position in the case.

08. The statutory notice should also be reviewed to verify that the notice states the last day on which the taxpayer may file a petition with the Tax Court. If the petition is filed on or before the date specified on the statutory notice, the petition will be treated as timely even though it would be untimely under the normal 90 or 150 day rule. The notice of deficiency should also advise taxpayers of the right to contact the local Taxpayer Advocate and provide the location and telephone number of that office, although failure to do so does not render the notice invalid.

09. The attorney should verify that the statutory notice of deficiency was issued by the Service within three years after the due date for filing the tax return for each year raised in the Tax Court petition. If the statutory notice was issued more than three years after the due date, the attorney should review the administrative file to see if the statute of limitations for assessment was extended or whether a statute of limitations other that the usual three-year statute applies. See CCDM 35.2.2.4.3, Collateral Estoppel and Res Judicata. If the statutory notice was issued late as to any particular year and no exception applies to keep the statute open, the attorney should concede that year in the answer, even if the petition does not plead a statute of limitations defense. _See_ _CCDM 35.2.1.1(3)_. It is the longstanding policy of the Office of Chief Counsel to notify the taxpayer or representative of the existence of an expired statute of limitations even if it has not been assigned as error in the petition (and thus deemed conceded under the court's rules), notwithstanding the lack of any duty under the ABA Model Rules of Professional Conduct to make such a disclosure.

10. In worker classification cases under IRC section 7436, a Notice of Employment Tax Determination Under IRC Section 7436 (Letter 3523) is used, rather than a notice of deficiency. The Service sends the Letter 3523 by certified or registered mail. The Letter 3523 advises taxpayers of the opportunity to seek Tax Court review and provides information on how to do so. The Letter 3523 should include a schedule identifying the workers the Service has determined should be classified as employees and/or a list of workers for which the Service determined that Section 530 of the Revenue Act of 1978 does not apply. The Letter 3523 should also show each kind of tax with its proposed employment tax adjustment by taxable period.

11. The above considerations also apply to other types of determination letters issued by the Service, including adverse determination letters in interest abatement, spousal relief, administrative costs, collection due process, and transferee liability cases. Careful research of the statutory requirements for each type of determination letter should be conducted to determine that the Service has satisfied all jurisdictional requirements for the respective cases. _See also_ _CCDM 35.2.1.1.15_, Initial Review of Certain Declaratory Judgment Cases Under TEGEDC’s Jurisdiction and Section 7436 Cases, for other notices of determination issued by the Service that can be petitioned to the Tax Court.

12. In cases where a federal district court has ordered restitution for the tax periods covered by the statutory notice of deficiency, the attorney should review the statutory notice to make sure the liabilities listed on the statutory notice of deficiency are not based on the restitution order. Assessment of the amount of restitution ordered by a federal district court is not subject to deficiency procedures under IRC section 6213(b)(5), and therefore, is not reviewable by the Tax Court. The Service, however, may conduct a civil examination for the same periods for which restitution was ordered. For those tax periods covered by the restitution order, only those tax liabilities and penalties determined by the Service as a result of a civil examination are subject to deficiency procedures. Thus, the statutory notice should only cover the amounts determined by the civil examination and, with respect to the penalties, only to the extent they are based on a deficiency. See CCDM 33.1.2.8.11, Statutory Notices in Cases Having Criminal Aspects. See also _CCDM 35.2.1.1.5.1_, Criminal Cases.


**35.2.1.1.2** **(07-14-2022)**

#### Assessment of Uncontested Deficiencies

1. A petition should be examined immediately to determine whether each of the tax periods/years in the notice of deficiency or Letter 3523 have been petitioned. If a tax period/year has not been petitioned, Appeals should immediately be requested to initiate assessment of the tax for that tax period/year because the statute of limitations continues to run as to any tax period/year for which no Tax Court petition is filed. The Service may have less than 60 days remaining on the statute of limitations on assessment by the time a petition has been received by the Field Counsel office, so prompt action is critical. As an administrative rule, the assessment of the tax period/year(s) not petitioned should be made within 60 days from the date of the filing of the original petition with the Tax Court to ensure that it is timely made within the suspension period of section 6503. Additional pleadings or motions by petitioner or respondent will not extend the period within which an assessment must be made. Similarly, when a joint and several determination of a deficiency is made against a husband and wife and only one party petitions from the statutory notice, a timely assessment of the deficiency or liability must be made against the party not petitioning. First, consideration should be given to informally contacting the petitioner to see if the omission was inadvertent. If so, petitioners should be asked to file an amended petition before the limitations period would otherwise expire. If the omission of the spouse was not inadvertent, Appeals should be requested to make an assessment of the deficiency against the nonpetitioning spouse. Appeals should also be asked to request that collection activity be withheld during the pending litigation. If there is any doubt whether a particular year or party is before the court, the doubt should be resolved in favor of making the assessment. An improper assessment can be reversed and corrected but a missed assessment cannot be cured after the statute has expired.

2. There are circumstances in which collection against a nonpetitioning spouse might be appropriate: for example, if the petitioning spouse is seeking relief solely as an innocent spouse; if it is anticipated that the nonpetitioning spouse may file a bankruptcy petition (although in this situation the filing of a federal tax lien may be sufficient to protect the government's interest); if the majority of assets are held in the name of the nonpetitioning spouse; or if there is any other reason to believe a jeopardy situation exists against the nonpetitioning spouse.

3. If collection is not withheld because it is anticipated that the nonpetitioning spouse may file a bankruptcy petition, extreme care must be taken to avoid violation of the automatic stay provisions of 11 U.S.C. § 362(a)(6), which expressly prohibits any act to collect, assess, or recover a prepetition claim against the debtor. Section 362(h) provides for damages, in the nature of costs, attorneys' fees, and actual and punitive damages, for violation of the automatic stay provisions. Accordingly, all efforts to assess or collect after a petition in bankruptcy is filed must be immediately terminated. Additionally, it is possible that transfers received by the Service from the nonpetitioning spouse will be considered preferential transfers subject to avoidance by the trustee in bankruptcy. 11 U.S.C. § 547. If so, it is likely that the Service's interest in any property returned to the estate will be protected by the filing of a notice of federal tax lien since the notice is not considered a preference item. However, to be a nonpreference item, the notice of federal tax lien must be properly filed so as to be perfected and enforceable against a bona fide purchaser at the time of the commencement of the nonpetitioning spouse's bankruptcy case. 11 U.S.C. § 545. Accordingly, Appeals should be instructed to take steps to file a notice of federal tax lien, when appropriate, as soon as possible.

4. If it comes to the attention of the attorney that the Service is continuing collection activity against the nonpetitioning spouse although requested by Appeals to withhold such activity, the attorney should consult with representatives of Collection to determine why they believe collection activity is necessary when the litigation concerning the amount of the deficiency is pending. If an agreement cannot be reached on withholding collection activity, the matter should be reconciled through the appropriate management officials of the respective organizations.

5. If, for a particular tax period/year, the taxpayer petitions from a notice of deficiency or Letter 3523 that includes both tax and penalties, and it is clear from the petition that the taxpayer assigns error only with respect to the penalties, no assessment of the tax deficiency or employment taxes should be made for that tax period/year since all matters relating to that tax period/year are still pending before the court and assessment continues to be restricted. Sections 6213(a), 6512. The case should be treated in the same manner as a case in which the statutory notice recites that certain adjustments were agreed to by the petitioner before the notice was issued. The taxpayer's concession should be confirmed in the answer and will be accounted for in the stipulation of facts or the Rule 155 computation, since the court's decision must recite a determination of both the conceded tax and redetermined penalty amounts. Care must also be taken in preparing the answer where specific adjustments from the statutory notice have not been assigned as error. As a general rule, that portion of the deficiency or employment tax attributable to the issues that were either not raised or conceded by the petitioner should not be assessed, absent the execution of a waiver of the restrictions on assessment.

6. The petition and statutory notice should also be examined for adjustments over which the deficiency or 7436 procedures may not be applicable. This applies particularly to those penalties under section 6651 (including section 6651(f)), which are based upon amounts shown on the taxpayer's return. _See_ section 6665. These amounts should not be included in the statutory notices but should be immediately assessed if the statute of limitations has not expired.


**35.2.1.1.3** **(08-11-2004)**

#### Unaudited Returns

1. Unaudited returns may be requisitioned by the attorney in connection with trial preparation, or such returns may be contained in the administrative files in cases which are referred to the attorney by Appeals for trial preparation. As a general rule, such returns should be immediately photocopied and the original returns sent back to the appropriate administrative official. Regardless of the method by which an unaudited return comes into the possession of the attorney, appropriate control records must be maintained. Such control records, however, do not relieve the attorney assigned the case of the responsibility of protecting the government against the running of the statute of limitations on such returns. For returns which are included in administrative files forwarded to Field Counsel offices by Appeals, extra care must be used in determining that no unaudited returns are included therein without specific control records being made thereon. Unaudited returns should be returned to Appeals or to the Area Director, as appropriate, in sufficient time to secure appropriate waivers and, in the absence of waivers, to effectuate assessments or issue any necessary statutory notices within the statutory period. If it becomes absolutely necessary for the attorney to retain an unaudited return for a period of time, such return must be released to the appropriate administrative official, preferably six months and in no event later than 90 days prior to the expiration of the statute of limitations.


**35.2.1.1.4** **(08-11-2004)**

#### Jeopardy Assessment

1. Jeopardy assessments are not subject to the usual restrictions on assessment imposed by deficiency procedures, and may be made prior to the mailing of a notice of deficiency or during the pendency of a Tax Court proceeding. In such situations, a notice of deficiency allowing Tax Court review, or a notification to the Tax Court in a pending case, is sent subsequent to the making of the jeopardy assessment.


**35.2.1.1.4.1** **(08-11-2004)**

##### Possessor of Cash

1. Whenever a jeopardy or termination assessment is made against a possessor of cash using the presumptions of section 6867, the Service is required to issue a notice of deficiency. Section 6867 applies to situations where an individual is found in physical possession of a large amount of cash. There are no court decisions authorizing the use of section 6867 to make a jeopardy or termination assessment against a corporation, nor does the statutory language support such an interpretation. In any case pending in the Tax Court where the petitioner-possessor of cash is a corporation, the case should be conceded and a decision should be entered that there is no deficiency against the corporation as possessor of cash.

2. In cases where the issue of the Tax Court's jurisdiction has been raised, the respondent should concede that the court has jurisdiction to determine whether the facts on the date of the assessment against the possessor warranted the use of section 6867. Such facts include whether the person had physical possession of cash or cash equivalents in excess of $10,000, whether the possessor claimed the cash as his or hers, and whether the possessor identified another person as the owner and the person could be readily identified by the Service as the true owner. In construing section 6867, the Tax Court has jurisdiction to determine the identity of the true owner even as late as the date of trial. The relevant time for determining ownership of the cash is the time of assessment, not the time of trial.


**35.2.1.1.4.2** **(08-11-2004)**

##### Notification of Jeopardy Assessment or Abatement

1. Section 6861(c) requires the Service to notify the Tax Court of the deficiency or liability, in whole or in part, which is pending redetermination before the court and which has been jeopardy assessed. This section also requires that notification be given to the Tax Court of the abatement of the assessment of a deficiency or liability, in whole or in part, which is pending redetermination by the Tax Court and which was jeopardy assessed either before or after the issuance of the statutory notice.

2. The notification to the Tax Court of any jeopardy assessment or abatement thereof is applicable to tax, penalty and interest which have been so assessed or abated. If the jeopardy assessment or abatement was made prior to the issuance of the statutory notice, a statement is included in the statutory notice regarding such assessment or abatement. If such information is adequately set forth in the statutory notice and a copy of such notice is on record with the Tax Court, no further notification need be given. The attorney should ascertain that a copy of the statutory notice, including the information pertaining to the jeopardy assessment or abatement, is in fact on file with the Court. If the tax or penalty involved in the Tax Court case was jeopardy assessed, in whole or in part, subsequent to the issuance of the statutory notice upon which the petition to the Tax Court is based, or if such assessment was abated, in whole or in part, after the issuance of the statutory notice, notification must be given to the Tax Court. See Exhibits 35.11.1–4 through 35.11.1–6.

3. The notice to the Tax Court shall set forth the date of the jeopardy assessment and shall show separately for each year and for each type of tax involved the amount of the deficiency or liability, including penalty and interest assessed, in connection with the assessment of the tax. In a notice of abatement of jeopardy assessment there shall be shown, in addition to the date and amount of the jeopardy assessment, the date and amounts of such assessments which were abated. See Exhibits 35.11.1–4 through 35.11.1–6.

4. In cases in which the jeopardy assessment is set forth in the statutory notice and a copy of such notice is not filed with the court, the respondent's notice of the jeopardy assessment should be filed simultaneously with the first document the respondent files in the case. If the first document is the answer, attaching the notice of jeopardy assessment reflecting the assessment will suffice. If the jeopardy assessment (either original or supplemental assessment) is made after the issuance of the statutory notice, the notice to the court should be filed as soon as possible after the jeopardy assessment has been made. Likewise, in any instance in which tax, penalty, or interest which was jeopardy assessed is abated, a notice of such abatement should be immediately filed with the court.


**35.2.1.1.5** **(08-11-2004)**

#### Coordination with Criminal, Refund and Collection Cases

1. Generally speaking, a related case for coordination purposes is any pending case or matter which could be materially affected by a proposed action in a particular Tax Court case, or any pending case or matter in which a proposed action would materially affect a particular Tax Court case. The cases may be related because they involve the same petitioner, either for the same or for different taxes or taxable years or for different aspects of the same tax liability; or because they involve the same or similar issues arising out of the same or similar transactions; or because they involve different petitioners whose relationship is such that action taken with respect to one may materially affect the action to be taken with respect to the other. The case or matter related to the Tax Court case may be another Tax Court case or one pending before another court or at some other stage in its development; it may be pending at various administrative levels within the Service, or before any Associate or Field Counsel office, Treasury, or the Department of Justice. All related circumstances cannot be precisely described, nor can the extent of the coordination appropriate in every instance be specifically detailed. Attorneys and managers should exercise judgment in determining the relationship of related cases or other matters.


**35.2.1.1.5.1** **(10-18-2016)**

##### Criminal Cases

01. A related criminal case or a Tax Court case having open criminal aspects may not be defined with exactitude. The related criminal case may involve either a case to which Criminal Investigation jurisdiction has attached, or in which there is a proposed or pending criminal prosecution of either the petitioner or of another person so related to the petitioner that the action proposed, or to be taken, in either the Tax Court case or the criminal case may materially affect the other. Thus, the criminal case and the Tax Court case may be related for coordination and other purposes described in this manual even though each involves different petitioners and even though the taxable years involved in the two cases are not the same. Furthermore, the Tax Court case is to be considered related to the criminal case for coordination purposes even though the Division Counsel/Associate Chief Counsel (CT) authorized the issuance of the statutory notice during the criminal investigation of the petitioner, or related taxpayer, and even though clearance with DOJ was not required prior to issuance of the statutory notice upon which the Tax Court case is based. A Tax Court case may have criminal aspects if there is involved proposed or pending criminal prosecution of the petitioner, or a related taxpayer, for alleged criminal violations of the Internal Revenue Code or the provisions of Title 18 or Title 31 of the United States Code involving revenue matters.

02. The purpose for coordinating civil and criminal cases is to balance criminal and civil aspects of a case. See Policy Statement P-4-26. If the case is nondocketed, the civil and criminal considerations should be weighed by the special agent in charge, the Area Director and the attorney. The ability to overcome the statute of limitations through the assertion of fraud should be considered by the attorney. If the case is a docketed case, the criminal case should be protected to the extent possible while at the same time complying with the rules, orders, and directives of the Tax Court. Because the statutory notice would have been approved with awareness of the standards of the policy statement, the case should not automatically be deferred pending a resolution of the criminal matter. Consideration should be given in each case as to whether the collection of the revenue may be imperiled by the referral of the case for criminal prosecution (as for example: aging witnesses, increasing doubts as to collectibility, etc.) and the potential impact upon the criminal case if the Tax Court case were to progress to trial first. Any prospective action toward settlement or trial preparation should be closely coordinated with the criminal tax function to ensure that the potential impact upon the criminal case is thoroughly considered.

03. Field Counsel offices will coordinate related civil and criminal cases pending within the area, and the appropriate Associate office and the Division Counsel/Associate Chief Counsel (CT) will coordinate such cases in the Associate office. Area Counsel (CT) is charged with the responsibility for coordinating on all cases worked by Criminal Investigation Posts of Duty in that area. Once an area charged with a related criminal matter has concurred in the issuance of a statutory notice of deficiency, it is unnecessary to secure the agreement of all other offices which subsequently become charged with the criminal matter to any action required in the processing of the resulting Tax Court case. It is essential, however, that the office currently charged with the related criminal matter be informed of any significant developments in the Tax Court. This means that copies of the pleadings (i.e., petition, answer, reply), motions for judgment on the pleadings or summary judgment, and request for discovery or admissions and responses thereto will be furnished upon receipt or service to the office currently charged with the criminal matter. The letter or memorandum transmitting each of the foregoing documents will also request that any additional information developed by the office currently charged with the criminal matter (other than information which may not be disclosed for civil purposes, i.e., certain grand jury or wiretap evidence) be furnished. In this way the offices charged with the civil liability and the criminal matter will each be kept informed of all developments which might affect their cases, and the positions taken in both cases will be consistent.

04. Each Field Counsel office shall establish procedures for the prompt coordination of the civil and criminal aspects of cases within the framework of the procedures contained herein. The procedures should identify the cases to be routed to Field Counsel offices for personal consideration by the appropriate officials.

05. Because of the time limitations on actions to be taken in the Tax Court, DOJ agreed to the following:



    1. If the criminal aspect is with Criminal Investigation or Field Counsel at the time of the issuance of the deficiency notice, consideration is to be given at that time as to the likely effect of proceeding with the civil aspects of the case in the Tax Court under the discovery, admission, and pleading requirements of the Tax Court's rules.

    2. If the criminal aspects of the case were pending in DOJ at the time the statutory notice was issued, concurrence in the issuance of the notice would have embodied consideration of the likelihood of the petitioner invoking the discovery, admission, and pleading provisions of the Tax Court's rules and of the effect of the utilization of these procedures on the criminal case.

    3. In the filing of answers or amended answers or in providing information under the discovery and admission provisions of the Tax Court's rules, there should be coordination between the tax litigation and criminal tax functions. The attorney should protect the criminal aspects of the case to the extent possible under the Tax Court's rules.

    4. DOJ should be advised in the criminal reference letter of all actions taken up to the date of such letter in the related civil case.

    5. For cases in which action is taken in the Tax Court after referral of the criminal case, DOJ should be advised of the action taken and furnished with copies of all pertinent documents relating to the Tax Court case which may have a bearing on the criminal aspects. For any unusual action, every effort must be made to contact DOJ either formally or informally prior to taking definitive action to the extent time permits.


06. If time permits, consideration should be given to whether prereview of a proposed action should be requested. If the field determination is that a prereview is appropriate, the matter should be referred to the Division Counsel/Associate Chief Counsel (CT) or DOJ.

07. Copies of all letters to DOJ in matters requiring coordination should be forwarded to the Division Counsel/Associate Chief Counsel (CT) for postreview.

08. The pendency of a related criminal case alone is not a reason acceptable to the Tax Court for the refusal by respondent to file an adequate answer. The Tax Court requires adequate affirmative pleadings by the respondent in all fraud cases (including those involving the fraud delinquency penalty), and the action of that court in striking inadequate allegations relating to fraud has been held not to constitute reversible error in the absence of a finding by the court of appeals of abuse of discretion on the part of the Tax Court. The contents of the answer required under the rules of the Tax Court in support of civil fraud are not limited or controlled by decisions of the district courts with respect to a defendant's motion in a criminal case for a bill of particulars. The Tax Court may require fuller disclosure than would district courts and, if the respondent elects not to make the required disclosure to avoid peril to the criminal case, the affirmative allegations of fraud may be stricken.

09. The attorney shall prepare an adequate answer alleging at least the minimum details required by the Tax Court as to the fraud items which will be relied upon in the trial of the case. The fraud allegations, to the extent feasible, shall be consistent with the theory of fraud to be relied upon in the criminal case, but the allegations should be tailored to avoid disclosures that would imperil a successful criminal prosecution. Only after coordination with Criminal Investigation or DOJ, as the circumstances may require, may the answer or other pleading make reference to a pending criminal investigation of the petitioner or a third party. If the coordinating parties agree that reference may be made to a pending criminal investigation of the petitioner, such reference may be made whether an indictment has been published or not. On the other hand, particular care should be taken to see that the pleading makes no reference to any criminal investigation of a third party if that investigation has not resulted in the publication of an indictment unless the third party has specifically authorized the disclosure of such information to the court or the third party has publicly disclosed such information. Any problem that may arise in preparing the affirmative allegations should be brought to the attention of the appropriate Field Counsel.

10. When criminal prosecution has been referred to or is pending with DOJ or the US Attorney, a letter should be sent to DOJ with a copy of the directly filed answer. Copies of the letter and answer should be forwarded to Division Counsel/Associate Chief Counsel (CT) for postreview. A copy of the petition and statutory notice should be attached to the letter to the Department of Justice, unless copies have been previously provided.

11. Consistent with the agreement reached with DOJ, the proposed answer need not be prereviewed by DOJ unless there is an unusual aspect to the case or unless in the opinion of the attorney it is a case requiring such coordination. In making that determination, the time constraints for filing an answer should be considered. If it is determined that there should be prereview, the attorney should send a letter to DOJ requesting prereview and enclosing a copy of the proposed answer. Copies of this letter and the proposed answer should be forwarded to Division Counsel/Associate Chief Counsel (CT).

12. The foregoing paragraphs of this section relate only to cases which have been referred to DOJ. For cases which are pending with Criminal Investigation at the time of the preparation of the answer, it is not necessary that a copy of the answer be coordinated with Criminal Investigation; it will be assumed that approval of the issuance of the statutory notice authorizes preparation of an appropriate answer. However, a copy of the answer should be sent to Criminal Investigation.

13. Before preparing and filing an answer to the Tax Court petition that was filed for the same years covered by the criminal restitution order, the attorney must make sure that the allegations set forth in the petition address only the liabilities determined in the statutory notice of deficiency and do not cover any amounts assessed solely based on a restitution order per IRC § 6201(a)(4)(A). A taxpayer may not challenge the amount of restitution on the basis of the existence or amount of the underlying tax liability per IRC § 6201(a)(4)(C). If a petition includes challenges to the assessment of periods and amounts of underlying tax liability determined by the criminal restitution order, the attorney should consider filing a motion to dismiss the petition for lack of jurisdiction. Nonetheless, if a taxpayer petitions the Tax Court based on the statutory notice of deficiency issued following an examination for the same tax years for which restitution is ordered, such petition is valid and the Tax Court will have jurisdiction over the entire deficiency without regard to the restitution ordered.


**35.2.1.1.5.2** **(08-11-2004)**

##### Refund Cases

1. A Tax Court case and a refund suit shall be considered related cases if the concession or settlement of one, or the course of action to be pursued at the trial of one, may have a material effect upon the disposition of the other. Thus, the two cases may be related because they involve the same or related taxpayers, either for the same or different taxes or taxable years; or because they involve the same or similar facts or issues; or because they involve issues arising out of the same transactions.

2. The handling and processing of Tax Court cases and refund suits to their ultimate disposition must be closely coordinated so as to establish a consistent litigation position in all the courts. See CCDM 35.4.1.5.2, Coordination with Refund Cases, and CCDM 35.5.3.3, Coordination of Tax Court and Refund Cases.


**35.2.1.1.5.3** **(04-05-2012)**

##### Collection Cases

1. A Tax Court case and a collection suit or other general litigation matter, whether handled by a trial attorney or in the national office, should be considered related cases, if significant action in one may have a material effect upon the other. Related general litigation matters may include a collection suit or other suits to enforce liens resulting from jeopardy assessments; claims filed in bankruptcy, receivership, probate court proceedings; injunction suits; suits to enforce administrative summons; various other state or federal court proceedings; and various administrative collection activities or International matters. Related collection activities usually relate to the same tax liability which is involved in the Tax Court case, and a settlement of such liability on the merits in either case may be dispositive of the other. In some related collection matters, however, the tax liability involved may not be the same as that in the Tax Court case, but if there is a direct relationship between the two and action with respect to one may materially affect the other, appropriate coordination procedures should be followed.

2. The Service can use tax treaties to collect United States income taxes that have been assessed (e.g., treaties with Denmark, Sweden, France, Netherlands and Canada have collection assistance provisions). There are other procedural mechanisms to assist in such collection efforts, such as issuance of a _writ ne exeat republica_, or procuring the appointment of a receiver for foreign assets. _See_ section 7402(a). Issues concerning collection of assets located offshore should be coordinated with Branch 1 of the Office of Associate Chief Counsel (International), who will then coordinate with the Associate Chief Counsel (P&A), Branch 3 or 4 as appropriate.


**35.2.1.1.6** **(07-31-2018)**

#### Premature Petitions

1. Petitions to the Tax Court in deficiency cases require the issuance of a valid notice of deficiency, or the petitions are subject to dismissal for lack of jurisdiction. If a notice of deficiency has not been issued because the tax year is still under examination, the petition is premature.

2. Appeals Account and Processing Support (APS) reviews Tax Court petitions when researching docket lists to determine the location of the administrative files. When APS cannot locate a notice of deficiency in a deficiency case, APS sends a Form 15022, IRS Certification - Income/Gift/Estate Tax Statutory Notice of Deficiency NOT Issued, to the manager of the Examination group controlling the taxpayer’s return. The manager will complete Form 15022, certifying that the notice of deficiency in question has not been issued and including his or her contact information. A Form 15022 reviewer will then check IRS systems to confirm that no other notice of deficiency or notice of determination has been issued to the taxpayer and, once confirmed, will send the Form 15022 back to APS. APS will forward the Form 15022 to Field Counsel in lieu of the administrative file. _See_ IRM 8.20.5.5.1.5.1, Premature Petition Carding and Certification Procedure.

3. The suspension of the period of limitations on assessment in IRC section 6503(a) does not apply if the Service did not issue a notice of deficiency. Examination personnel will continue to work the case even while the year remains docketed in Tax Court. Counsel will be available to assist Examination personnel in ensuring that the period of limitations on assessment does not expire, including reviewing deficiency notices.

4. Attorneys should move to dismiss the case for lack of jurisdiction. For a discussion of jurisdictional motions in premature petition cases, _see_ CCDM 35.3.2.4(3).


**35.2.1.1.7** **(08-11-2004)**

#### Imperfect Petitions

1. \[Reserved\]


**35.2.1.1.8** **(08-11-2004)**

#### Duplicate Petitions

1. For a discussion of duplicate petitions, see CCDM 35.3.2.9, Duplicate Petition.


**35.2.1.1.9** **(07-14-2022)**

#### Effect of Bankruptcy

01. The Bankruptcy Code gives bankruptcy courts primary jurisdiction under 11 U.S.C. § 505 to hear and decide the merits of any unpaid tax, fine or penalty relating to a tax or any addition to the tax of the debtor or the bankruptcy estate.

02. In controversies between the Service and taxpayers in bankruptcy, the bankruptcy court may abstain from determining the merits of a tax controversy in favor of the Tax Court. The bankruptcy court cannot determine a tax if the tax was already contested before and adjudicated in another court, including contested cases resulting in a default judgment or settlement. 11 U.S.C. § 505(a)(2)(A). The bankruptcy court’s jurisdiction is also limited with regard to determining refund claims; a claim for refund must be filed with the Service and the Service must be given 120 days to examine it before the bankruptcy court can make the determination. 11 U.S.C. § 505(a)(2)(B). _See_ Rev. Proc. 81-18, 1981-1 C.B. 688.

03. If , a Tax Court case was filed before the bankruptcy case was filed and the bankruptcy court lifts the stay to allow a Tax Court case to proceed, the trustee may intervene under section 7464 to protect the interests of the bankruptcy estate. Intervention, however, is not mandatory. Attorneys should be concerned about questions such as:



    1. Whether the trustee must be substituted as a party for the debtor under T.C. Rule 63 because the trustee is in a fiduciary capacity; and

    2. Whether the trustee can file a petition on the taxpayer's behalf.


04. The jurisdiction of the bankruptcy court extends to both dischargeable and nondischargeable taxes. If the Service filed a proof of claim listing the tax at issue, the bankruptcy court has jurisdiction to determine the merits of the tax. That court also exercises subject matter jurisdiction over a Chapter 11 corporate debtor’s tax liabilities that arise during the administration of the bankruptcy case (prior to confirmation of the Chapter 11 plan). Once the bankruptcy court lifts the stay to allow the Tax Court to proceed, both courts have jurisdiction. Res judicata will apply to the first decision entered. _See McQuade v. Commissioner_, 84 T.C. 137 (1985); _Florida Peach Corp. v. Commissioner_, 90 T.C. 678 (1988).

05. When a bankruptcy case is filed, an automatic stay of certain acts arises by operation of law. The automatic stay applies to any act



    - To commence or continue any judicial, administrative, or other action or proceeding against the debtor (11 U.S.C. § 362(a)(1))

    - To enforce any judgment obtained against the debtor prior to bankruptcy (11 U.S.C. § 362(a)(2))

    - To exercise control over property of the estate (11 U.S.C. § 362(a)(3))

    - To create, perfect or enforce any lien against the debtor or the debtor's property (11 U.S.C. § 362(a)(4) and (5))

    - To collect, assess, or recover any claim against the debtor (11 U.S.C. §362(a)(6))

    - To set off any debt owing the debtor against any claim against him (11 U.S.C. § 362(a)(7))


### Note:

Pursuant to section 362(a)(6), the automatic stay prohibits acts to collect taxes that arose before the bankruptcy case was filed. Accordingly, collection actions such as serving notices of levy or filing notices of federal tax lien are stayed while the automatic stay remains in effect. The Service may, however, conduct an audit to determine tax liability, may issue a notice of deficiency, and may assess an otherwise assessable liability, notwithstanding the automatic stay. 11 U.S.C. § 362(b)(9).

The Bankruptcy Abuse Prevention and Consumer Protection Act of 2005 made some significant changes to the automatic stay. Most importantly, the automatic stay does not go into effect or terminates 30 days after the petition date in certain cases where the debtor has filed multiple bankruptcy petitions. 11 U.S.C. §§ 362(c)(3), 362 (c)(4), 362(j). Issues arising under these sections should be coordinated with the Office of Associate Chief Counsel (Procedure and Administration).

06. The automatic stay also prohibits the commencement or continuation of certain proceedings before the Tax Court. 11 U.S.C. 362(a)(8). For bankruptcy cases commenced prior to October 17, 2005, section 362(a)(8) stayed all Tax Court proceedings concerning the debtor. For bankruptcy cases of individuals filed on or after October 17, 2005, the automatic stay applies only to the Tax Court proceedings for tax periods/years that ended before the bankruptcy case was commenced. For bankruptcy cases of nonindividuals (corporations), the stay typically applies to all Tax Court proceedings for tax periods/years ending before the confirmation of a Chapter 11 plan or during the administration of a Chapter 7 case.

07. Where a petition in bankruptcy is filed after a case is docketed in the Tax Court, the Tax Court must be notified of the bankruptcy by filing of a notice of the bankruptcy proceeding so the court can stay the proceedings. See Exhibit 35.11.1-71, Notice of Proceeding Under Bankruptcy Code; CCDM 35.3.9.2.2(2), Bankruptcy While in Tax Court.

08. If a statutory notice of deficiency/Letter 3523 is issued after a bankruptcy case was commenced, the taxpayer is prohibited from petitioning the Tax Court during the time the automatic stay is in effect under section 362(a)(8). A party in interest in the bankruptcy case may request that the bankruptcy court lift the stay to permit the filing of a petition in the Tax Court. 11 U.S.C. § 362(d). If the court does so, the bankruptcy court and the Tax Court will have concurrent jurisdiction and, as stated above, the trustee may choose to intervene in the Tax Court proceeding. Section 7464. Where the bankruptcy court lifts the stay, it also may reserve the right to rule on the Service’s tax claim.

09. Even though the Service may issue a notice of deficiency/Letter 3523 while a stay is in effect without violating the stay, the taxpayer-debtor cannot petition the Tax Court while the stay is in effect. Consequently, where the taxpayer files a Tax Court petition in violation of the stay, the Tax Court case must be dismissed on jurisdictional grounds. The appropriate motion to be filed by the Service would be a motion to dismiss for lack of jurisdiction. If the stay is not lifted and a Tax Court petition is filed in violation of the stay, a motion to dismiss for lack of jurisdiction should be filed, not a notice of proceeding in bankruptcy. See Exhibit 35.11.1-40, Motions to Dismiss for Lack of Jurisdiction: Violation of Bankruptcy Code Stay Provision.

10. If the debtor is not an individual (such as a corporation), notices of deficiency/Letters 3523 for tax periods that end during the administration of the bankruptcy case should be issued to the trustee (if one has been appointed). If the debtor is an individual and the tax year ends after the bankruptcy case was commenced, the notice of deficiency/Letter 3523 should be issued to the debtor.

11. The automatic stay provisions under 11 U.S.C. § 362(a)(8) continue until the happening of the earliest of certain specific events.



    1. Approval by the bankruptcy court of a motion by the debtor to lift the stay to permit the debtor to petition the Tax Court (11 U.S.C. § 362(d)).

    2. The bankruptcy court concludes the proceeding and closes the bankruptcy case (11 U.S.C. § 362(c)(2)(A)).

    3. The bankruptcy court dismisses the case (11 U.S.C. § 362(c)(2)(B)).

    4. The bankruptcy court grants or denies a discharge (11 U.S.C. §362(c)(2)(C)).


12. The attorney should assemble complete factual information , including the dates the bankruptcy petition was filed, the statutory notice was issued, the stay was lifted, the discharge was granted or denied, and the bankruptcy case was dismissed or closed. The reason is that jurisdictional questions may still arise as to the timeliness of the Tax Court petition and whether the petitioner is the proper party.

13. Section 6213(f) suspends the running of the 90-day or 150-day period while the stay is in effect plus an additional 60 days. The application of section 6213(f) in the context of various scenarios involving the relative timing of issuance of a notice of deficiency and the commencement of bankruptcy is discussed in Rev. Rul. 2003-80, 2003-29 I.R.B. 83. When respondent files a motion to dismiss for lack of jurisdiction because the Tax Court petition was filed during the automatic stay, the Tax Court has asked that respondent calculate the time under section 6213(f) during which the taxpayer may still (or could have) file(d) a timely petition to the Tax Court. The attorney, as an officer of the court and public servant, should notify the petitioner-taxpayer of the jurisdictional defect when discovered and apprise the petitioner of the remaining number of days to timely file a new Tax Court petition before the time expires. It is particularly important that the attorney determine whether a Tax Court petition was filed on a day when the automatic stay was in effect. It is equally important that the attorney verify the exact status of the bankruptcy proceedings in order to properly inform the Tax Court of the specific dates on which relevant events took place that might affect the stay.

14. If a debtor receives a statutory notice of deficiency/Letter 3523 after the bankruptcy case was dismissed, closed, or a discharge has been granted or denied, the automatic stay provisions do not apply and the taxpayer has the usual 90-day or 150-day statutory period within which to petition the Tax Court. This will be a fairly common occurrence where the taxes determined in the statutory notice/Letter 3523 are nondischargeable and neither the Service nor the debtor requested the bankruptcy court to rule on the merits of the government's claim while the case was pending in that court.

15. In a collection due process case, the taxpayer has 30 days to file an appeal of the notice of determination to the Tax Court, pursuant to section 6330(d). The running of this 30-day appeal period, unlike the running of the normal 90-day or 150-day period for filing a Tax Court petition from a notice of deficiency, is not suspended during bankruptcy. Thus, a taxpayer who files bankruptcy after the IRS issues a notice of determination but before the taxpayer files an appeal to the Tax Court must obtain relief from the stay to obtain review of the notice of determination, as otherwise the filing period may expire before the appeal can be filed.

16. The Tax Court has held that the issuance of a notice of determination in a CDP levy case is the continuation of an administrative collection action against the petitioner that was or could have been commenced pre-petition and, thus, a violation of the automatic stay under section 362(a)(1) that renders the notice void. _Smith v. Commissioner_, 124 T.C. 36 (2005). Therefore, when the taxpayer files for bankruptcy prior to issuance of the notice of determination, and then files a Tax Court petition, the Tax Court will dismiss the case for lack of jurisdiction on the ground that the notice of determination is void because the Tax Court petition was filed in violation of 11 U.S.C. § 362(a)(8). Counsel should contact the Associate Chief Counsel (Procedure and Administration) for advice as to the proper jurisdictional motion upon learning that the notice of determination was issued during the automatic stay.

17. It is of critical importance that the Tax Court be apprised of the precise party or parties involved in a bankruptcy proceeding. Quite frequently, the caption in a bankruptcy case itself will be misstated. For example, if a case is styled "John Jones and the J. Jones Corp." or "The J. Jones Corp., John Jones, President," it is critical to determine whether both John Jones (the individual) and J. Jones have filed for bankruptcy or whether only the corporation has filed. Similarly, the caption involving a parent and subsidiaries may be erroneously stated in the bankruptcy court pleadings. It is critical to confirm exactly which person or entity has filed and whether the particular filing affects the jurisdiction of the Tax Court.

18. If the bankruptcy judge decides that the bankruptcy court, rather than the Tax Court, should determine the tax liability, such litigation is to be handled by the attorney as a general litigation case. Conversely, if the Tax Court is to determine the amount of tax liability, the litigation will continue to be handled by the attorney as a tax litigation case.

19. If litigation had commenced in the Tax Court and in that action the merits of any tax liability had been tried prior to the date of bankruptcy, the attorney may seek to have the stay modified or terminated so that the Tax Court may proceed to determine the tax controversy. If the stay is lifted or terminated, the Tax Court and bankruptcy court may have concurrent jurisdiction. It may be preferable for the same attorney to handle both the tax litigation aspect of the case as well as the general litigation aspect (the attorney might also handle the bankruptcy case directly if he or she is a Special Assistant United States Attorney).

20. When an affiliated group of corporations files consolidated returns, Treas. Reg. § 1.1502-77(a) provides that any Tax Court petition for members of the group must be filed by the common parent as the agent for the group. If the common parent is in bankruptcy, however, the automatic stay in 11 U.S.C. § 362(a)(8) prohibits the common parent from filing a Tax Court petition. _See J & S Carburetor Co. v. Commissioner_, 93 T.C. 166 (1989). If solvent subsidiaries are actually barred from obtaining a preassessment adjudication of the tax liability, a court might prohibit the Service from initiating collection efforts against the subsidiaries. Accordingly, in appropriate circumstances, the Department of Justice should be asked to file a motion for modification of the automatic stay in bankruptcy court under 11 U.S.C. § 362(d) to permit the common parent to file the Tax Court petition. Alternatively, in appropriate circumstances, the appropriate official may be advised to notify the common parent that the Service will deal with each member of the group on a separate basis with respect to the consolidated tax liability so as to permit the filing of a Tax Court petition by the individual solvent subsidiaries. _See_ Treas. Reg. § 1.1502-77(a).


**35.2.1.1.10** **(08-11-2004)**

#### Initial Review of"S" Cases

1. \[Reserved\]


**35.2.1.1.11** **(08-10-2021)**

#### Initial Review of Interest Abatement Cases

1. Interest abatement cases no longer must be automatically coordinated with the Associate Chief Counsel (P&A). Such cases remain subject, however, to Exhibits 31.1.1-1 and 35.11.1-1, _Issues Requiring Associate Office Review_. For example, any docketed abatement cases involving an issue of first impression must be coordinated with the Associate Chief Counsel (P&A), Branch 3 or 4 beginning when the trial attorney first receives service of a Tax Court petition.

2. The trial attorney should review the petition for review of failure to abate interest to be sure it contains the information required under T.C. Rule 281(b) or (c), and, as in any case where a Tax Court petition is filed, either answer the petition or file an appropriate motion in accordance with T.C. Rules 36 and 37. See also CCDM 35.1.1.9, Interest Abatement Claims.

3. The abatement of interest provisions are applicable in the context of a TEFRA partnership audit. During the partnership level proceeding, the action of the person(s) representing the partnership will be attributed to all partners for purposes of section 6404(e). Similarly, a Service error or delay in relation to an act at the partnership level can properly give rise to a request for abatement of interest by the partners. The partnership, as a fiduciary of a partner, may file an administrative claim on behalf of a partner. The partnership must comply with all of the requirements of Treas. Reg. §301.6404-1 when filing the claim. Each partner must file a separate petition for review with the Tax Court because section 6404(h) only grants to the Tax Court jurisdiction over cases brought by taxpayers and a partnership is not a taxpayer. Further, the Tax Court rules do not generally allow joinder of multiple petitioners in a single petition. For interest abatement cases arising in the context of a partnership proceeding under the Bipartisan Budget Act of 2015, the trial attorney should contact P&A Branch 6 or 7 for any needed assistance.

4. To ensure that interest abatement cases are handled properly and petitions are reviewed thoroughly, the trial attorney must take the following steps within 30 days of service of the petition:



1. Identify jurisdictional issues such as: no Notice of Final Determination and no qualification under the 180 day waiting period rule of section 6404(h)(1)(A)(ii); abatement request denied prior to July 31, 1996; petition seeks abatement of tax or penalties; or no statement that petitioner meets requirements of section 7430(c)(4)(A)(ii);

2. Identify summary judgment issues such as: the tax year begins on December 31, 1978 or earlier; the petition seeks abatement of interest on employment taxes; or interest is attributable to an error on delay in the performance of a managerial act and the tax year begins prior to July 31, 1996; and

3. Ensure that the case has the **AI** TLCATS subtype.


**35.2.1.1.12** **(04-05-2012)**

#### Initial Review of Collection Due Process (CDP) Cases

1. Sections 6320 and 6330 establish formal procedures giving taxpayers rights to administrative hearings and judicial review when the Service engages in collection action by filing a notice of federal tax lien or proposing a levy (in limited situations, taxpayers only have hearing rights after an actual levy). The Tax Court has jurisdiction to review notices of determination issued by the Office of Appeals in CDP cases.

2. The Tax Court has promulgated rules that set forth the procedures for review of an Appeals notice of determination under sections 6320(c) and 6330(d). T.C. Rules 330 through 334. The attorney should review the petition to be sure it contains the information required by T.C. Rule 331 and either answer the petition or file an appropriate motion in accordance with T.C. Rules 36 and 37. See CCDM 35.3.23 on CDP motions.

3. The Tax Court will address only those issues raised in the petition and in the trial memorandum, and issues not raised will be deemed conceded. T.C. Rule 331(b)(4). General allegations are not sufficient to raise an issue under T.C. Rule 331(b)(4), which has been most strictly applied in cases involving frivolous arguments.

4. The Small Tax Case procedures under section 7463 apply to CDP cases. See CCDM 35.1.3.2.1 on determining S case status in CDP cases.

5. In any CDP proceeding in which the petitioner raises a claim for relief from joint and several liability and the other spouse is not a party to the litigation, the trial attorney must serve notice on the other individual who filed the joint return for the years at issue. See CCDM 35.2.2.12.2, Notification of Nonpetitioning Spouse.


**35.2.1.1.13** **(08-11-2004)**

#### Review of Tax Shelter Cases

1. \[Reserved\]


**35.2.1.1.14** **(08-11-2004)**

#### Significant Case Procedures

1. See CCDM 31.2.1 for Significant Case Procedures.


**35.2.1.1.15** **(08-11-2004)**

#### Initial Review of TEFRA Cases

1. Prior to the Tax Equity and Fiscal Responsibility Act of 1982 (TEFRA), separate proceedings were required for each partner in a partnership. Now, pursuant to sections 6221 through 6233, the tax treatment of partnership items is determined at the partnership level in a unified partnership proceeding. T.C. Rules 240 through 251 contain specific procedures for readjustment of partnership items under section 6226 and adjustments to partnership items under section 6228.

2. Upon receipt of a petition or complaint in a partnership action, the attorney must determine if other actions have been filed and, if more than one petition or complaint has been filed, which one must be dismissed. The attorney should also review the petition to determine whether it was timely filed. For a discussion of various jurisdictional motions that may need to be filed in TEFRA proceedings, see CCDM 35.3.7.2, Jurisdictional Motions.

3. It is the responsibility of the assigned attorney to compute the amount in dispute and have that amount entered on TLCATS no later than the time that the case is answered. The amount in dispute in TEFRA cases is computed by multiplying the amount shown as the total adjustments on the FPAA/FSAA by the highest marginal rate for individuals under section 1. The formula for calculating the amount in dispute is as follows: (total net adjustments in FPAA/FSAA \* highest marginal rate) + credits disallowed in FPAA/FSAA = amount in dispute.

4. Upon completion of a TEFRA entity level proceeding, the Service is required to follow the standard deficiency procedures with respect to additions to tax or additional amounts. Section 6230(a)(2)(A); Temp. Treas. Reg. § 301.6231(a)(6)-1T(c).

5. Following a TEFRA partnership or subchapter S corporation proceeding, affected item notices of deficiency are sometimes issued for penalties or other affected items attributable to partnership/subchapter S item adjustments. Frequently, when a decision is entered in these affected item proceedings, no reference is made to the TEFRA entity. This leads to confusion regarding the application of section 6212(c) which generally prohibits the issuance of second notices of deficiency in non-TEFRA cases.

6. Section 6230(a)(2)(C) overrides section 6212(c) allowing affected item notices of deficiency to be issued notwithstanding that an earlier non-TEFRA notice of deficiency has been issued. Conversely, it also allows non-TEFRA notices of deficiency to be issued notwithstanding that an affected item notice of deficiency has previously been issued for the same taxable year.


**35.2.1.1.16** **(07-14-2022)**

#### Initial Review of Declaratory Judgment Cases Under TEGEDC’s Jurisdiction and Section 7436 Cases

1. This section discusses review of declaratory judgment cases under sections 7428, 7476, and those involving governmental obligations along with workers classification cases under section 7436, all of which are under the jurisdiction of the office of Division Counsel (TEGEDC).


**35.2.1.1.16.1** **(07-14-2022)**

##### Initial Review of EP Declaratory Judgment Cases

1. Pursuant to section 7476, the Tax Court is authorized to issue declaratory judgments with regard to letter rulings issued by the Commissioner in cases concerning the qualification of retirement plans. Declaratory judgment cases arising under section 7476 are handled by the office of Division Counsel (TEGEDC).

2. Authority to issue final adverse determination letters with respect to the initial or continuing qualification (including termination) and revocation letters (following an examination) of certain retirement plans under subchapter D of chapter 1 of the Code has been delegated to the TE/GE Director, Employee Benefits Plans (final adverse determination letters) and Director, EP Examinations (revocation letters). See Deleg. Order No. 7-1 (Rev. 1); Deleg. Order No. 7-14. The Independent Office of Appeals is authorized to issue such letters on appeals from proposed adverse determination and revocation letters.

3. Declaratory judgement petitions under section 7476 will be assigned to the office of Division Counsel (TEGEDC).

4. Immediately upon receipt of a section 7476 declaratory judgment case, the assigned TEGEDC attorney should request the complete administrative file from to the office that issued the determination or revocation letter. Immediately upon receipt of the file, the assigned TEGEDC attorney should examine the petition and file to determine whether there are jurisdictional questions to be raised by motion and should coordinate with the Associate Chief Counsel (P&A) and/or the Associate Chief Counsel (Employee Benefits, Exempt Organizations, and Employment Taxes) (EEE), where appropriate.

5. Pursuant to T.C. Rule 211(b), every petition shall be entitled Petition for Declaratory Judgment (Retirement Plan). The petition shall include all of the items enumerated in T.C. Rule 211(c). If the petition is not accompanied by a copy of the final adverse determination letter, respondent's answer should include an appropriate allegation and a copy of the letter should be attached. Similarly, if the petition does not allege exhaustion of administrative remedies, respondent's answer should make such an allegation, if appropriate.

6. If the petition covers a year for which a deficiency could be assessed, the assigned TEGEDC attorney should make sure that consents for extending the statute of limitations are obtained or that a statutory notice of deficiency has been or will be timely issued. The declaratory judgment is limited to the issue of plan qualification. Tax liability will never be an issue in a declaratory judgment action, and the action will not stay the running of any statute of limitations.


**35.2.1.1.16.2** **(07-14-2022)**

##### Initial Review of EO Declaratory Judgment Cases

1. Section 7428 allows organizations to seek a declaratory judgment in the case of an actual controversy involving a determination by the Secretary (or failure by the Secretary to make a determination) as to the initial or continuing qualification (and/or classification) as:



1. An organization described in section 501(c) or 501(d) and which is exempt under section 501(a);

2. An organization described in section 170(c)(2);

3. A private foundation as defined in section 509(a); or

4. A private operating foundation as described in section 4942(j)(3).


2. Only the Tax Court, District Court for the District of Columbia, and the Court of Federal Claims have section 7428 jurisdiction.

3. Declaratory judgement petitions under section 7428 will be assigned to the office of Division Counsel (TEGEDC).

4. The remedy under section 7428 is not exclusive. Exempt organizations may also litigate their exempt status in conjunction with suits for redetermination of deficiencies in the Tax Court or suits for refund in the Court of Federal Claims or a district court.

5. If an organization's exemption is revoked, and it timely files a petition for a declaratory judgment, individuals may continue to deduct contributions of up to $1,000 from the time of publication of the notice of revocation until the date of the court decision. Section 7428(c).

6. Authority to issue determination letters with respect to (i) the exempt status of organizations under section 501(a) (other than under section 401 (a)) and 521 except in the case of an organization under the jurisdiction of the Independent Office of Appeals; (ii) an organization’s status under section 507, 508, 509, 4940(d)(2), 4942(g)(2), 4942(j)(3), 4945(f), 4945(g), 4947, 4948, 6033 and eligibility to receive deductible contributions under sections 170(c)(2) through 170(c)(5); and (iii) withholding of information from public inspection under section 6104(a)(1)(D), has been delegated to the Director, Exempt Organizations (EO) Ruling and Agreements. If a proposed adverse determination is appealed, the Independent Office of Appeals is authorized to issue the final determination letter. Deleg. Order No. 7-2 (Rev. 2).

7. The Director, Exempt Organizations (EO) Examinations is delegated authority to issue revocations of rulings or determination letters of letters determining that an organization does not qualify for exemption for an audited tax year and reclassifications of foundation status. The TE/GE Division Commissioner with the concurrence of the office of Division Counsel (TEGEDC), is authorized to require pre-issuance review, by TEGEDC, of final adverse determination letters. If a proposed revocation is appealed, the Independent Office of Appeals is authorized to issue the final determination letter. Deleg. Order No. 7-17.

8. After review of these final letters, the files will be returned to the sending office in the Office of the Commissioner (TE/GE).

9. The purpose of review by the office of Division Counsel (TEGEDC) is to ensure that the letter clearly and succinctly specifies each and every ground upon which the Service relies to support its adverse determination or ruling.


**35.2.1.1.16.3** **(07-14-2022)**

##### Initial Review of Declaratory Judgment Cases Relating to Government Obligations

1. When declaratory judgment petitions relating to governmental obligations are served on the Commissioner, they will be assigned to the office of Division Counsel (TEGEDC), and an attorney from that office will be assigned to litigate the case. Immediately upon receipt of a declaratory judgment case, the assigned attorney should request the complete administrative file from the office and/or attorney who prepared the adverse ruling. Cases arising under section 103 arise relatively infrequently and may have wide-ranging application. These cases are extremely sensitive for the Office of Chief Counsel and for Treasury. Thus, significant coordination of such cases is usually required.


**35.2.1.1.16.4** **(07-14-2022)**

##### Initial Review of Worker Classification Cases under Section 7436

1. Generally, principles set forth in the CCDM regarding the handling of deficiency cases apply to cases under section 7436 as well. _See_ section 7436(d).

2. For further information about section 7436, _see_ Rev. Proc. 2022-13; Letter 3523, Notice of Determination of Worker Classification, Catalog 33170R (Rev. 01/2002); Publication 3953, (Questions and Answers About Tax Court Proceedings for Determination of Employment Status Under I.R.C. § 7436, Catalog 33273Z. In addition, assistance in handling these cases can be obtained from the employment tax specialists in the offices of the Division Counsel (TEGEDC) and the Associate Chief Counsel (EEE).

3. Rev. Proc. 87-24, 1987-1C.B. 720, concerning Counsel referral of newly docketed cases to Appeals for settlement consideration by its terms applies only to deficiency cases. Similarly, cases under section 7436 docketed in the Tax Court will be referred by the attorney to the Appeals function for consideration of settlement unless the Notice of Employment Tax Determination Under IRC § 7436 (Letter 3523) was issued by Appeals. Cases in which Appeals issued such a Letter 3523 may be referred to Appeals unless the attorney determines that there is little likelihood that a settlement of all or a part of the case can be achieved in a reasonable period of time.

4. In worker classification cases under section 7436, Letter 3523 is used, rather than a notice of deficiency. The Service sends the Letter 3523 by certified or registered mail. The Letter 3523 advises taxpayers of the opportunity to seek Tax Court review and provides information on how to do so. The Letter 3523 should include a schedule identifying which workers the Service has determined should be classified as employees and/or a list of workers for which the Service determined that Section 530 of the Revenue Act of 1978 does not apply. The Letter 3523 should also show each kind of tax with its proposed employment tax adjustment by taxable period.

5. Section 7436 grants the Tax Court jurisdiction to make a determination with respect to the Commissioner's determination that one or more individuals performing services for a person are employees of such person for purposes of Subtitle C, Employment Taxes, and/or that such person is not entitled to treatment under subsection (a) of section 530 of the Revenue Act of 1978 with respect to such individual. (The text of section 530 of the Revenue Act of 1978, as amended, although not codified in the Internal Revenue Code of 1986, can usually be found in the publisher's notes following section 3401(a)). The Commissioner's determination must have been made in connection with an audit of the person and as part of the examination. For the Tax Court to have jurisdiction, there must be an actual controversy involving one or both of the Commissioner's determinations. Upon the person's filing of a petition, the Tax Court has jurisdiction to determine whether the Commissioner's determination is correct and the proper amount of employment tax under such determination.

6. The Tax Court's determination under section 7436 has the force and effect of a Tax Court decision and is reviewable as such unless proceedings are conducted under the small case procedures described in section 7463. _See_ T.C. Rules 290-295.

7. The taxes imposed under Subtitle C, Employment Taxes, include the Federal Insurance Contributions Act (FICA) taxes, Railroad Retirement Tax Act (RRTA) taxes, Federal Unemployment Tax Act (FUTA) taxes, Railroad Unemployment Repayment Tax (RURT), and Collection of Income Tax at Source on Wages or Income Tax Withholding (ITW). "Employment tax" includes the additions to tax, additional amounts, and penalties provided by chapter 68A of the Code (sections 6651–6665). Thus, the Tax Court has jurisdiction to determine the proper amount of the additions to tax, additional amounts, and penalties that relate to the employment tax imposed by subtitle C with respect to determinations of employment status and/or section 530 treatment.

8. Section 7436(b) provides that a pleading seeking Tax Court review of the Service's determinations may be filed only by "the person for whom the services are performed." Thus, workers may not seek review of the Service's determinations under section 7436. In addition, because the statute specifies that there be an actual controversy that the workers performing services "for such person" are employees" of such person," review may not be sought by a third party that has not been determined by the Service to be the employer of the workers.


**35.2.1.1.17** **(04-05-2012)**

#### TEFRA: Munro Stipulation for Deficiency Cases

1. In _Munro v. Commissioner_, 92 T.C. 71 (1989), the Tax Court upheld the validity of a statutory notice of deficiency that disallowed net partnership losses instead of eliminating them from the return before doing the statutory notice computation. The court ruled that it was impermissible for the Service to disallow the partnership losses in the statutory notice even if this was done solely for computational purposes and was not intended to be a substitute for issuing a notice of final partnership administrative adjustment (FPAA) as required by section 6225. More importantly, the court held that the partnership items (whether income, loss, deduction or credits) included on a taxpayer's return should be completely ignored in determining whether a deficiency exists that is attributable to nonpartnership items. Hence, the Service may not assume the correctness of its proposed adjustments to partnership items for computational purposes in determining a deficiency, and taxpayers may not offset net partnership losses against their taxable income for purposes of deficiency proceedings.

2. A literal application of _Munro_, would require recomputing tax liability without taking any partnership items into account. Where the partnership items are losses, such a computation can artificially raise taxable income into a higher bracket and correspondingly increase the deficiency. Should the petitioner ultimately prevail as to any of the partnership losses, he or she would receive a refund but in the meanwhile the petitioner has had all of the tax shifted into the deficiency procedure.

3. While it is preferable to avoid the inflated deficiency problem for nonoversheltered cases, a subsequent statute of limitations claim could adversely affect the Service if the differential deficiency is not sought.



1. With regard to settled cases, the problem can be resolved by a stipulation between the parties, incorporated in the decision document, stating that for purposes of computing the deficiency the petitioner's partnership items have been treated as if they were correctly reported on the return, and any change to the deficiency liability caused by resolution of the TEFRA proceeding could be assessed at the conclusion of the TEFRA proceeding as a computational adjustment. The Tax Court has indicated that it will accept stipulated decision documents incorporating the language contained in Exhibit 35.11.1-7. The stipulated language contained in Exhibit 35.11.1–7 is to be incorporated verbatim in the decision document. Any deviation from this language must have the prior approval of the Associate Chief Counsel (P&A), Branch 6 or 7.

2. With regard to all other cases that are currently in the system to which the _Munro_ opinion applies, the attorney should contact petitioner's counsel to apprise them of the computational problem. Moreover, the attorney should attempt to obtain a letter from petitioner's counsel that when a stipulated decision or T.C. Rule 155 computation is filed with the Tax Court, the decision document will include the stipulation language contained in Exhibit 35.11.1-7. Petitioner's counsel should also be notified of our intention to seek an increased deficiency and increased penalties if petitioner's counsel does not agree to the stipulation. This discussion should be held with petitioner's counsel as early in the case as possible so as to avoid any claim of surprise, and all discussions with petitioner's counsel concerning this matter should be documented.

3. If a written agreement cannot be secured from petitioner's counsel within a reasonably short period of time, the attorney should file a motion for leave to file an amendment to the answer, together with the amendment to the answer, seeking an increased deficiency and increased penalties under section 6214(a). The motion should indicate that the increase is solely attributable to a recomputation that was required in order to comply with the Tax Court's opinion in _Munro_. See Exhibit 35.11.1-8. Such motions should be forwarded to the Associate Chief Counsel (P&A), Branch 6 or 7 for review prior to being filed with the Tax Court. Attorneys should not wait until the eve of trial to file the motion for leave.

4. A _Munro_ stipulation may be used (at the discretion of the attorney) to include in the deficiency computation before the court carryovers/carrybacks of net losses from other taxable years which include unresolved partnership losses, but only if all nonpartnership items have been resolved for the years generating the carryover/carryback losses. The _Munro_ stipulation does not allow the Service to assess changes to carryover/carryback amounts attributable to the subsequent resolution of nonpartnership items for other years. Consequently, the parties must resolve the nonpartnership items for a year generating the carryover/carryback amount before the _Munro_ stipulation can be used to include in the deficiency computation unresolved partnership items originating from that same year. Failure of the petitioner to resolve the portion of the net losses from other years attributable to nonpartnership items forecloses the use of the _Munro_ stipulation for these other years.

5. The above procedures are also applicable to cases that have been tried and are either awaiting the opinion of the Tax Court or are at the T.C. Rule 155 stage. Once again, attorneys should not wait until the opinion is rendered or the T.C. Rule 155 computation is being submitted to file the motion for leave. Such unexplained delay in raising the issue may result in the court denying the motion.

6. If the petitioner is willing to sign a stipulation including the language contained in Exhibit 35.11.1-7, and an agreement to this effect can be obtained in writing, it may be possible to file an agreed T.C. Rule 155 computation with the court in lieu of filing a motion for leave to seek an increased deficiency and increased penalties. If this is done, however, it is important for the attorney to make certain that the stipulation is expressly incorporated by reference into the decision that is entered by the court.


4. Since at the time that a statutory notice of deficiency is issued it is unknown whether the case will be settled, tried or defaulted, it is necessary to prepare such notices in accordance with _Munro_. Otherwise, if a case is defaulted and _Munro_ computations were not used in preparing the statutory notice of deficiency, the Service will only be permitted to assess the amount of the deficiency and penalties that are reflected in the notice. Section 6213(c). Moreover, the Service may be precluded from assessing and collecting the differential deficiency at the completion of the TEFRA proceeding if the petitioner subsequently challenges the assessment or collection of said differential deficiency on the ground that it is barred by the expiration of the statute of limitations.

5. Whenever non-TEFRA adjustments are to be made to a petitioner's return that contains TEFRA items and a _Munro_ computation must be made, deficiencies shall be computed as follows:



1. All TEFRA items that have been reported on the petitioner's return shall be removed to determine the modified taxable income.

2. However, if the treatment of any TEFRA item has been finally determined, e.g., by reason of a no change, a settlement or a completed TEFRA proceeding, those TEFRA items whose treatment have been finally determined shall not be removed.

3. Similarly, if there is no ongoing TEFRA proceeding with respect to the TEFRA items at the time that the computation is being made, those TEFRA items shall not be removed.

4. The non-TEFRA adjustments that are contained in the statutory notice will be added. The result will be the modified taxable income as corrected.

5. The tax on the amount in step (a) (the modified taxable income) will be calculated.

6. The tax on the amount in step (d) (the modified taxable income as corrected) will be calculated.

7. The amount in step (c) will be subtracted from the amount in step (d). The difference will be the deficiency that should be reflected in the statutory notice.


6. The _Munro_ computations apply to all years ending after the enactment of TEFRA on September 3, 1982. For years ending after August 5, 1997, the _Munro_ computations continue to apply without change, except in the case of the oversheltered returns.


**35.2.1.1.18** **(04-05-2012)**

#### TEFRA Statute of Limitations: Coordination With CIC Audit

1. If a corporate petitioner that is classified as a Coordinated Industry Case is a partner in one or more TEFRA partnerships, special care must be taken to assure that the statute of limitations for assessment of tax attributable to the partnership items flowing from the TEFRA partnership(s) is properly protected. For a discussion of this issue, see CCDM 35.9.3.5, Closing TEFRA Cases. Moreover, if this issue is encountered, legal advice should be sought from the Associate Chief Counsel (P&A), Branch 6 or 7 so that all steps necessary to timely and adequately protect the respective statutes of limitations can be taken.

2. Special care must also be taken when issuing affected item notices of deficiency to assert penalties, etc. against the partners following the conclusion of a partnership proceeding. Since the issuance of such a notice to a taxpayer who is subject to a CIC audit can potentially create statute of limitations problems, such notices should not be issued without the knowledge and consent of the CIC examiner. If this should occur, however, the attorney should contact the Associate Chief Counsel (P&A), Branch 6 or 7 immediately upon finding out about it.


**35.2.1.1.19** **(08-11-2004)**

#### Jurisdictional Issues

1. See CCDM 35.3.2, Jurisdictional Defects, for a discussion of jurisdictional motions concerning untimely petitions, the absence of a valid statutory notice, jurisdiction over parties, taxpayers and tax years, invalid petitions and payments on deficiencies made before issuance of the statutory notice. For jurisdictional issues in declaratory judgment cases under sections 7428, 7476, and 7478, and worker classification cases under section 7436, see CCDM 35.3.8, Motions in Declaratory Judgment Cases and Section 7436 Worker Classification Cases, and _CCDM 35.2.1.1.15_.


**35.2.1.1.20** **(08-11-2004)**

#### Motions Addressing the Petition

1. See CCDM 35.3.3, Motions Pertaining to Pleadings, for a discussion of motions to strike, motions for a more definite statement and motions to dismiss for failure to state a claim upon which relief can be granted.


**35.2.1.1.21** **(08-10-2021)**

#### Initial Review of BBA Cases

1. The Bipartisan Budget Act of 2015 (BBA) repealed the TEFRA partnership procedures, including the electing large partnership provisions, and replaced them with a new centralized partnership audit regime. For taxable years beginning January 1, 2018, the tax treatment of all items in a partnership return is governed by rules established by BBA. Partnerships may also elect to have BBA rules apply for taxable years beginning after November 2, 2015. T.C. Rules 255.1 through 225.7 contain specific procedures for partnership actions under section 6234(a)(1).

2. Upon receipt of a petition or complaint in a partnership action, the attorney must determine whether other actions have been filed and, if more than one petition or complaint has been filed, which one must be dismissed. The attorney should also review the petition to determine whether it was timely filed, and whether the petition was filed by the properly designated partnership representative. This step is important because, unlike in TEFRA proceedings, only the designated partnership representative has the authority to act on behalf of a partnership and bind the entity to any final decision made in the proceeding. For a discussion of various jurisdictional motions that may need to be filed in BBA proceedings, see CCDM 35.3.7.2, Jurisdictional Motions.

3. The amount of any deficiency that is being disputed - known under BBA as the imputed underpayment (IU) as determined in the FPA - should be entered on TLCATS no later than the time that the case is answered.


**35.2.1.1.22** **(08-09-2023)**

#### Initial Review of Passport Cases

1. All docketed passport cases must be coordinated with the Associate Chief Counsel (P&A), Branch 3 or 4, beginning at the time the trial attorney first receives service of a Tax Court petition contesting the Service's certification of the taxpayer as an individual having a seriously delinquent tax debt.

2. The attorney should review the petition to be sure it contains the information required under T.C. Rule 351, and, as in any case where a Tax Court petition is filed, either answer the petition or file an appropriate motion in accordance with T.C. Rules 36 and 37.

3. The attorney should review the transcripts for the periods included in the seriously delinquent tax debt to ensure that all elements of the seriously delinquent tax debt have been met and that the certification has not been reversed.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-002-001#addtoany "Show all")

A2A