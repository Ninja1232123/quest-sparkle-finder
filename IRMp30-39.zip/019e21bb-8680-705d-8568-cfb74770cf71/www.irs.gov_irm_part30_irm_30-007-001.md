---
url: "https://www.irs.gov/irm/part30/irm_30-007-001"
title: "30.7.1 Information Systems | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part30/irm_30-007-001#main-content)

- 30.7.1 [Information Systems](https://www.irs.gov/irm/part30/irm_30-007-001#idm139658756344496)
  - 30.7.1.1 [Information Systems within the Office of Chief Counsel](https://www.irs.gov/irm/part30/irm_30-007-001#idm139658733478000)
  - 30.7.1.2 [CASE Management Information Systems](https://www.irs.gov/irm/part30/irm_30-007-001#idm139658747249136)

    - 30.7.1.2.1 [CASE-MIS Subsystems](https://www.irs.gov/irm/part30/irm_30-007-001#idm139658730375040)

      - 30.7.1.2.1.1 [General Litigation (CASE-GL)](https://www.irs.gov/irm/part30/irm_30-007-001#idm139658730015296)
      - 30.7.1.2.1.2 [TECHMIS (CASE-TM)](https://www.irs.gov/irm/part30/irm_30-007-001#idm139658731228464)
      - 30.7.1.2.1.3 [Apollo (CASE-LC)](https://www.irs.gov/irm/part30/irm_30-007-001#idm139658730614304)
      - 30.7.1.2.1.4 [CASE-MIS Time Reporting (CASE-TR)](https://www.irs.gov/irm/part30/irm_30-007-001#idm139658741966432)

    - 30.7.1.2.2 [Tax Litigation Counsel Automated Tracking System (TLCATS)](https://www.irs.gov/irm/part30/irm_30-007-001#idm139658736606304)
    - 30.7.1.2.3 [Office of Chief Counsel Case Numbers](https://www.irs.gov/irm/part30/irm_30-007-001#idm139658755731488)
    - 30.7.1.2.4 [User Access to CASE-MIS](https://www.irs.gov/irm/part30/irm_30-007-001#idm139658731620032)

  - 30.7.1.3 [Workload and Time Reporting Requirements](https://www.irs.gov/irm/part30/irm_30-007-001#idm139658756646160)

    - 30.7.1.3.1 [Participation](https://www.irs.gov/irm/part30/irm_30-007-001#idm139658753270128)
    - 30.7.1.3.2 [Responsibilities](https://www.irs.gov/irm/part30/irm_30-007-001#idm139658748309824)
    - 30.7.1.3.3 [CASE-TR Permission Roles](https://www.irs.gov/irm/part30/irm_30-007-001#idm139658756930768)
    - 30.7.1.3.4 [Reporting Time](https://www.irs.gov/irm/part30/irm_30-007-001#idm139658752236352)

      - 30.7.1.3.4.1 [Reporting Requirements](https://www.irs.gov/irm/part30/irm_30-007-001#idm139658750033008)

    - 30.7.1.3.5 [Time Reports](https://www.irs.gov/irm/part30/irm_30-007-001#idm139658757028064)
    - 30.7.1.3.6 [Time Reporting for the Enforcement Revenue Information System (ERIS)](https://www.irs.gov/irm/part30/irm_30-007-001#idm139658745033952)
    - 30.7.1.3.7 [Problem Resolution and Program Modifications](https://www.irs.gov/irm/part30/irm_30-007-001#idm139658743891424)
    - 30.7.1.3.8 [Records](https://www.irs.gov/irm/part30/irm_30-007-001#idm139658728108096)

      - 30.7.1.3.8.1 [File Storage](https://www.irs.gov/irm/part30/irm_30-007-001#idm139658738754464)
      - 30.7.1.3.8.2 [Records Retrieval, Review and Destruction](https://www.irs.gov/irm/part30/irm_30-007-001#idm139658744809712)

  - 30.7.1.4 [Uniform Issue List](https://www.irs.gov/irm/part30/irm_30-007-001#idm139658731039552)
  - Exhibit 30.7.1-1 [Tax Litigation Counsel Automated Tracking System (TLCATS) Archived Reports](https://www.irs.gov/irm/part30/irm_30-007-001#idm139658743557648)
  - Exhibit 30.7.1-2 [File Retention Schedule](https://www.irs.gov/irm/part30/irm_30-007-001#idm139658744441968)

# Part 30. Administrative

# Chapter 7. Management Systems

# Section 1. Information Systems

* * *

## 30.7.1 Information Systems

**30.7.1.1** **(05-08-2007)**

### Information Systems within the Office of Chief Counsel

1. This section establishes policy and procedures for CASE Management Information Systems, workload and time reporting requirements, and the Uniform Issue List.

2. The Chief Counsel Executive Steering Committee (CC ESC) replaced the Information Management Policy Board (IMPB) in order to meet the Office of Management and Budget's (OMB) governance requirements for CASE. Information concerning the CC ESC and policies and procedures governing information technology services has been relocated to CCDM 30.7.3, Technology Services.


**30.7.1.2** **(12-21-2010)**

### CASE Management Information Systems

1. The Counsel Automated Systems Environment (CASE) encompasses CASE-MIS, Counsel's Management Information System. CASE-MIS is comprised of a number of subsystems all of which are Counsel-designed and maintained. All but Tax Litigation Counsel Automated Tracking System (TLCATS), one of the subsystems discussed below, are Oracle-based and housed at the National Office. TLCATS is a DB2 mainframe system housed at the Martinsburg Computing Center.

2. CASE-MIS includes the following subsystems:



   - Time Reporting (CASE-TR)

   - General Litigation (CASE-GL)

   - General Legal Services (CASE-GLS)

   - Criminal Tax (CASE-CT)

   - Technical Management Information System (TECHMIS or CASE-TM)

   - Apollo (CASE-LC)

   - Disclosure Litigation (CASE-DL)

   - Tax Litigation

   - Finance & Management (CASE-CO)

   - Tax Litigation Counsel Automated Tracking System (TLCATS )


**30.7.1.2.1** **(10-05-2005)**

#### CASE-MIS Subsystems

1. The CASE-MIS subsystems are used by the Office of Chief Counsel to track time keeping, human resources information, and various work products of the office. CASE-MIS subsystems provide vital information about work load within the entire organization. Executives use this information to determine resource needs (staffing and budget). The Associate Chief Counsel, Finance and Management (F&M) is responsible for justifying those needs to the Commissioner, the Department of Treasury, the Office of Management and Budget, and to Congress. The statistical data collected from CASE-MIS provides Chief Counsel with the ability to justify resource needs.

2. There are several subsystems discussed below, which track specific work products by specific offices (i.e., CASE-GL, CASE-DL, CASE-CT, etc.). Within Chief Counsel, the Associate Chief Counsel offices provide legal guidance to the IRS and taxpayers through formal and informal advice, policy, procedures, and regulations. In addition to legal guidance, the Associate Chief Counsel offices coordinate tax litigation with field office attorneys and the Department of Justice. Division Counsel Attorneys also track case specific work on CASE-MIS subsystems.

3. In addition, the subsystems CASE-HR tracks personnel information on all Chief Counsel employees and CASE-TR tracks time reported.


**30.7.1.2.1.1** **(12-21-2010)**

##### General Litigation (CASE-GL)

1. The CASE-GL subsystem of CASE-MIS provides managers with case and workload tracking, statistical information on workload, industry program issues, and large case identification.

2. The CASE-GL manual is available online and can be accessed while you are in the system. For more details, see CASE-GL Handbook, _Chapter 3, System Use Guidelines_.

3. Cases can be opened, updated/modified, reassigned, tracked, and closed on the CASE-GL subsystem. For more case processing information, see CASE-GL Handbook Chapters 5-7.

4. Cross referencing is a feature which enables a user to query data and locate specific cases and assignments. See CASE-GL Handbook, _Chapter 8, Retrieving Information Online_.

5. Various reports are available in CASE-GL which provide local, area, division, and national data to assist with workload management and functional trends. Information can be retrieved on case/workload inventory and suspense dates to track timeliness. For a listing of available reports and instructions, see CASE-GL Handbook, _Chapter 9, Retrieving Information: Reports_.


**30.7.1.2.1.2** **(12-21-2010)**

##### TECHMIS (CASE-TM)

1. The Technical Management Information System, also referred to as TECHMIS or the subsystem CASE-TM, provides Chief Counsel users with tools to efficiently track work products. All organizations in Chief Counsel use this system.

2. The TECHMIS subsystem integrates the tracking of many types of cases and workload categories within a single system. There are standard operating procedures and consolidated key case opening functions in the Legal Processing Division. See CASE-TM Handbook, Chapter 5 for information on opening cases.

3. Various CASE-TM reports are available for tracking workload. See CASE-TM Handbook, Chapter 9.

4. CASE-TM also contains the Business Plan report with a list of case categories. See CASE-TM Handbook, Chapter 10.


**30.7.1.2.1.3** **(12-21-2010)**

##### Apollo (CASE-LC)

1. The Apollo subsystem of CASE-MIS was developed in 2002 to track Notice Cases for Large Business and International (LB&I), Small Business/Self-Employed (SB/SE) and Tax Exempt and Government Entities (TEGE) that fall under CCDM 38.2.2, Grand Jury Procedures. Information available in Apollo includes:



   - Work plans

   - Attorney assignment

   - Litigation dates

   - Work plan due dates

   - Expert witnesses


2. Access to Apollo is available to senior executives, managers, attorneys, and paralegals within the organization. Information is restricted based on permission level in the system and jurisdiction over the case.

3. Numerous reports are available on Apollo, including the work plan report (LC Large Case) and work plan due date report for the field and the Associate offices.


**30.7.1.2.1.4** **(12-21-2010)**

##### CASE-MIS Time Reporting (CASE-TR)

1. The time reporting segment of CASE-MIS, CASE-TR, requires that Chief Counsel executives, managers, attorneys, and paralegals track time spent on case and non-case work. Managers may direct other employees to track their time in CASE-TR. CASE-TR tracks time spent on all types of work by all Chief Counsel offices. See CCDM 30.7.1.4 and CASE-TR Handbook, _Chapter 4, Standard Operating Procedures_.

2. Although TLCATS tracks Tax Litigation data, TLCATS interfaces with the CASE-TR subsystem on a daily basis to allow the tracking of time. Data in TLCATS is downloaded to a file and then uploaded to CASE-MIS. This download/upload feature permits time spent on cases tracked by TLCATS to be posted in CASE-TR. See CCDM 30.7.1.4 and CASE-TR Handbook, _Chapter 7, Processing Cases_.

3. Reports available in CASE-TR provide local, area, division, and national information to assist with staffing and budget needs which make possible the following:



   - Chief Counsel Quarterly (CCQ) report

   - Counsel Business Reviews

   - Strategic Business Plan

   - Cost analyses

   - Revenue/resource allocation projection

   - Planning model development

   - Enforcement Revenue Information System (ERIS)

   - Local and area management decisions

   - Program evaluation



     ### Note:



     See CASE-TR Handbook, _Chapter 9, Retrieving Information with Reports_.


**30.7.1.2.2** **(12-21-2010)**

#### Tax Litigation Counsel Automated Tracking System (TLCATS)

1. The Tax Litigation Counsel Automated Tracking System (TLCATS) is a nationwide automated system for tracking docketed and non-docketed cases from opening through closing. TLCATS allows a user to:



   - Enter and update information on cases

   - Perform research

   - Send and receive messages

   - Request and print reports

   - Track cases on Tax Court calendars

   - Track the mailing and receipt of files and documents


2. Access to TLCATS is controlled by a userid and password reflecting the user's security level. See Tax Litigation Handbook, _Chapter 2, System Security_, for access information.

3. Messages may be exchanged with Chief Counsel offices nationwide. Transmittals may be sent and acknowledged between Chief Counsel offices nationwide to track the mailing and receipt of cases and documents. See Tax Litigation Handbook, _Chapter 4, Messages and Transmittals_, for additional information.



### Note:



TLCATS messages have replaced telegram notices as a means of sending directives relating to Tax Court documents when the message is so urgent that the normal process of printing and distribution would unduly delay action.

4. The Docket and Records Branch, Legal Processing Division, in the Office of the Associate Chief Counsel, Procedure & Administration (P&A) establishes the regular, small, and declaratory judgment cases directly on TLCATS from Tax Court petitions. Once entered on TLCATS, the petitions are then electronically served (e-TCS) to the assigned office for updating as necessary. See Tax Litigation Handbook, Chapters 5, 8, 9, 10, 11, and 14 for instructions on updating and entering additional information.

5. Tax Refund complaints are actions filed in Federal District Court or U.S. Court of Federal Claims. Refund cases are entered into TLCATS by the receiving organization and updated as necessary. Complaints filed in Federal District Court and the Court of Federal Claims are assigned to the appropriate Division Counsel local counsel office. See Tax Litigation Handbook, Chapter 6 for instructions on Tax Refund cases.

6. TLCATS tracks review of a statutory notice of deficiency or other non-docketed cases in which a statute of limitations must be monitored. These cases are entered into the system by the receiving organization and updated as necessary. See Tax Litigation Handbook, Chapter 7 for instructions on Non-Docketed cases.

7. Numerous reports are available on TLCATS. For a complete listing of available reports and instructions, see Tax Litigation Handbook, Chapter 12.

8. Information from the TLCATS database can be obtained by online inquiry. The information may be used to answer a wide variety of questions concerning case inventory. See Tax Litigation Handbook, _Chapter 13, Inquiry_.


**30.7.1.2.3** **(10-05-2005)**

#### Office of Chief Counsel Case Numbers

1. Case numbers, also referred to as docket numbers and jacket numbers, are assigned to all cases in Chief Counsel, whether they are docketed or non-docketed. Some tax litigation work is tracked on the Tax Litigation Counsel Automated Tracking System (TLCATS); consequently, the procedures for those cases are different. All other cases will be numbered in accordance with the procedures below.

2. Petitions filed in the U.S. Tax Court will be assigned docket numbers by the court. Refund litigation and tax litigation non-docketed (Statutory Notice) cases will be assigned case numbers generated by TLCATS. All other cases will be assigned case numbers in the CASE-MIS subsystems where the case is worked.

3. The **_case number_** will consist of the segments below to identify the subsystem and/or case category, number, and the calendar year, as appropriate. Segments of all case numbers will be separated by hyphens (-).





> **_Examples:_** POSTF-123456-95, REG-234567-96, GL-345678-95, CT-456789-98, TL-N-567-98, and TL-R-678-98





1. _**Subsystem**_ — For cases opened in certain CASE-MIS subsystems, the case number is prefaced with CT (Criminal Tax), GL (General Litigation), GLS (General Legal Services) or F&M (Finance & Management), identifying the subsystem.

2. _**Case Category**_ — For cases specifically opened in the TECHMIS (CASE-TM) subsystem, the number is prefaced with the category of the case,



      > **_Examples:_** POSTF = Postfiling; REG = Regulations; TRNIN = Internal Training, Instructor

3. _**Generated Number**_ — This is a sequential number generated by the subsystems, except for docketed cases.

4. _**Year Segment**_ — The final segment of each case number will consist of the last two digits of the calendar year in which the case is opened (or docketed, for Tax Court cases).


4. **_Case Name_** — To enable easy retrieval of cases in the CASE-MIS subsystems, use no punctuation and enter the name of the case as follows:



   - Last name

   - First name

   - Middle initial

   - Jr, Sr, Estate of

   - "The" at the end



     ### Note:



     For a corporation or partnership, enter the name exactly as shown on the petition or complaint, keeping in mind that "the" , "LLPs," and "LLCs" go at the end.


**30.7.1.2.4** **(05-17-2006)**

#### User Access to CASE-MIS

1. To ensure that data files and sensitive information are protected on our computer systems, the following guidelines for adding, deleting or modifying employee access to CASE-MIS need to be followed.



### Note:



Instructions regarding logins for the LAN can be found in the F&M Administrative Handbook under "Security Guidelines for Networks."

2. Prior to an account being established allowing a user to access CASE-MIS subsystems, an Information System User Registration/Change Request, available through Online 5081 must be completed. This automated system has been developed to:



   - Identify, authorize, and register IRS information system users

   - Communicate the Information Systems Security Rules to information system users

   - Obtain a signed statement from each user that the user has read and understands the rules and their consequences

   - Provide the necessary information to the person assigned to establish system access (e.g., System Administrators, Security Officers, etc.)


### Note:

The definition of a _"user"_ is the person for whom the request is prepared (i.e., the person being registered or authorized to access and use or operate an information subsystem).

3. Online 5081 is an automated process that is initiated by a manager or employee. The Chief, Systems Coordination Branch, in the F&M Planning and Finance Division (or designee) has final approval for allowing an employee's access to CASE-MIS. Managers will use appropriate information to make proper suitability determinations prior to granting employees access to systems.

4. The Systems Coordination Branch will conduct a semi-annual review of users’ access and the Online 5081 system to ensure employees have only those privileges needed to accomplish their responsibilities.

5. Separating employees’ access rights will be deleted immediately when they leave the IRS. Open accounts will be periodically checked to ensure separated employees no longer have access.

6. All current administrative accounts will be assigned to individual users.


**30.7.1.3** **(12-21-2010)**

### Workload and Time Reporting Requirements

1. CASE-TR tracks all executive, manager, attorney, paralegal, and other professional time spent on cases and projects for the internal information needs of the Office of Chief Counsel. The definitions and rules described in this subsection for reporting time are based on business rules that were established by user groups from all Chief Counsel functional areas who designed the automated time reporting system, CASE-TR. Their recommendations were approved by senior management before implementation of CASE-TR.

2. The purpose of workload and time reporting in CASE-MIS is to provide management with workload and time statistics for planning, analysis, and evaluation of Chief Counsel program areas. An essential element of obtaining and allocating resources is computing the cost of accomplishing mission/objectives. Time reporting is vital in computing costs.

3. The workload and time data collected from CASE-MIS supports essential management initiatives such as:



   - Budget requests and justifications

   - Management information reports

   - Strategic planning process

   - Program evaluation

   - Cost and trends analyses

   - Revenue/resource allocation projection

   - Enforcement Revenue Information System (ERIS)

   - IRS Data Book and other annual workload reports

   - Chief Counsel quarterly workload and time reports

   - Staffing Allocation Model

   - Management decisions nationwide


4. The workload and time reporting requirements listed in this section pertain to CASE-TR, CASE-GL, and CASE-TM. See Tax Litigation Handbook 40.1.5.1.2 for TLCATS requirements.

5. Workload and time reporting requirements, the duties and responsibilities of each office and coordinator, and the criteria for reporting workload and time information are outlined later in this section. All offices are responsible for ensuring that the data entered into CASE-MIS is accurate, complete, and timely. Procedures relating to entry of data into CASE-TR, processing of documents containing ERIS information, and production of time reports are contained in the CASE-TR Handbook. Additional information on workload data and production of reports is contained in the CASE-GL Handbook and the CASE-TM Handbook.


**30.7.1.3.1** **(10-05-2005)**

#### Participation

1. All Chief Counsel Offices are responsible for the entry of workload and time information. This includes indirect and direct, case, and non-case specific time.

2. Executives, managers (legal and non-legal), attorneys and paralegals are required to report 100% of their direct and indirect time in CASE-TR. Management may require other professional, administrative, and clerical support personnel to report their time.


**30.7.1.3.2** **(05-17-2006)**

#### Responsibilities

1. The Associate Chief Counsel, Finance and Management (F&M) implements national management information systems that support Counsel's business programs. The workload and time reporting function is assigned to the Planning and Finance Division (PF), which coordinates this through the Systems, Associate, and Division Coordinators. PF has the following responsibilities:



1. Coordinate, participate in, and provide support to groups designated to insure that business rules and standard operating procedures reflecting how all users will update and maintain CASE-MIS data are in place and disseminated

2. Serve as a technical liaison with the Office of Information Systems to assist in the resolution of system problems affecting workload and time reporting requirements

3. Identify CASE-MIS training requirements for managers, employees, and data input operators, and work with other offices regarding the delivery of that training

4. Provide advice and interpretation on a variety of issues concerning the administration and implementation of the workload time reporting requirements

5. Update and publish the CCDM provisions for reporting workload and time information and issue instructions periodically to coordinators and employees required to enter their time in CASE-TR (from now on referred to as participants)

6. Issue guidelines to all offices covering the procedures for conducting on-going data validity reviews, conduct special validity and accuracy reviews as assigned by the Associate Chief Counsel (F&M), and monitor and develop periodic reports regarding data validation efforts and results

7. Respond to ad hoc requests for workload and time information as requested by the Associate Chief Counsel (F&M) and other key executives

8. Archive all time and workload electronic and hard copy files (both current and historical)

9. Ensure that form and format of workload time reports are useful, effective, and efficient


2. In addition to the responsibilities listed in paragraph (1), Planning and Finance Division has the following specific time reporting responsibilities:



1. Maintain several tables in CASE-MIS which house information such as the workload and time reporting categories, employee job types, and aspect codes

2. Generate the Chief Counsel Quarterly Report (CCQ)

3. Maintain the current list of time-reporting categories and their definitions and standardized time sheets for electronic or hard copy distribution

4. Generate national summary time reports


3. Systems Coordinators (Coordinators) are responsible for ensuring that all program requirements are communicated to all participants and any problems are reported to management. Among other things, their duties are to:



1. Facilitate effective communications between PF and the data input operators on the workload and time reporting problems and notify participants of changes made in a timely manner

2. Perform periodic sample system audits to ensure data validity and accuracy, and respond to a variety of questions about the validity of the data

3. Work toward having prompt input of data for assigned area

4. Coordinate generation and printing of reports requested by management

5. Provide leadership and oversight to employees who use CASE-TR, which includes interaction with TLCATS

6. Maintain the automated systems

7. Administer and recommend changes

8. Monitor and resolve case entries and tracking discrepancies nationwide across all subsystems


4. The data entry operator designated by the office manager or support team leader is responsible for entering time and workload data promptly and accurately into the system. The office manager or support team leader, or their designees, will decide who does the actual data entry. The duties of the data entry operator are:



1. Enter all time from the participants' time sheets by COB Wednesday of the week following the week to be reported, when appropriate

2. Maintain a file of time sheets for at least six months following the end of the quarter to allow for possible audits of the system, when applicable

3. Periodically run a CASE-TR Exceptions Report to verify that 100% of all employees' time has been posted


**30.7.1.3.3** **(12-21-2010)**

#### CASE-TR Permission Roles

1. The ability of individuals to interact with CASE-TR depends upon the CASE-MIS permission role each is assigned. Although an individual may be able to see all the menu selections available under a particular category, they will only be able to access those screens which pertain to their access role.

2. These roles ensure system security and reduce the risks of improper access to information. If management determines that an employee has a valid requirement for additional access to the system, a request must be submitted through their appropriate Systems, Division, or Associate Chief Counsel Coordinator to the Counsel Information Systems Office (CISO). See the CASE-TR Handbook for the list and description of permission roles.


**30.7.1.3.4** **(05-17-2006)**

#### Reporting Time

1. The total hours for the reporting week should reflect all hours worked, including compensated and uncompensated hours. Total time includes time taken for annual, sick, and administrative leave.

2. Compensatory/credit hours taken, including religious compensatory hours taken, should not be entered if the hours are compensation for time previously worked and reported. In addition, time donated through the leave donation process should not be entered.

3. _**Corrections and Late Entries**_. The need for accurate and complete information requires that the data be input timely and accurately. When corrections and late entries are unavoidable, there are no time limitations for making corrections or adding records to the database after the end of the week to be reported. However, because data extracts will be downloaded timely, it is critical that all time be posted as specified in this document to ensure that management decisions are based on valid data. Thus, corrections or additions of data after an extract has been downloaded will not be included in statistical reports created or provided by Planning and Finance, and generally will not cause the extract to be downloaded. Regardless, it is important for future reports that the database be as accurate as possible; thus, corrections and additional data are encouraged even after the initial extract has been downloaded. When in doubt in this regard or significant errors are detected which require changes, Coordinators should contact the Systems Coordination Branch Chief in PF for advice.

4. Time spent on travel and meetings should be charged to the specific case or project requiring the travel or meeting.

5. Special Indirect categories have been developed for use exclusively by executives and managers, both legal and non-legal. Any substantive work (including review, additional research, discussions, or meetings) related to a case should be charged to the case.

6. Time spent as a student, regardless of the subject, should be charged to the appropriate _"Indirect Training"_ (As Student) category (Chief Counsel sponsored training or IRS sponsored training). Time spent as an instructor, regardless of the subject, should be charged to an open case/project under the appropriate _" Direct Training"_ (As Instructor) category (e.g., External Training & Public Outreach, Internal Training-Instructor, IRS Training-Instructor).

7. Time should be reported in 15–minute increments, rounding to the nearest 15 minutes, 30 minutes, 45 minutes, or full hour. The system has been programmed to require a minimum of 15 minutes to be input on each case before it can be closed, since it would be rare for a case to not consume at least 15 minutes of time.



### Example:



.25 for fifteen minutes, .5 for a half hour, .75 for three quarters of an hour, or 1.5 for an hour and a half.

8. The week for CASE-TR purposes begins on Sunday at 12:00 a.m. and ends on Saturday at 11:59 p.m. CASE-TR identifies a reporting week by the Saturday date, i.e., the last day of the week. Therefore, when running a time report be careful to identify the proper begin and end dates in the parameter values.



### Example:



If April 1 falls on a Tuesday and April 30 falls on a Wednesday, requesting a time report for April 1 - 30 will exclude time data from April (the report will pull from April 1 - April 26).

9. _**Reporting Period Ending During the Week**_. PF generally prepares quarterly and fiscal year-end statistical reports; thus, time has to be divided for the weeks containing the quarter ending dates of December 31, March 31, June 30, and September 30. When these dates occur on a day other than Saturday, separate time sheets must be completed for the days of the week that fall in the new quarter.



### Example:



If December 31 falls on a Wednesday, separate time sheets are prepared for Sunday, December 28, through Wednesday, December 31, and Thursday, January 1, through Saturday, January 3.


**30.7.1.3.4.1** **(05-17-2006)**

##### Reporting Requirements

1. Planning and Finance Division (PF) is responsible for sending out quarterly data cut-off notices to the Systems Coordinators and CASE-TR Coordinators requesting that they insure that everyone who is required to report time and workload is aware of the cut-off time for getting that information into CASE-MIS.

2. Coordinators are responsible for ensuring that all data is entered no later than the close of business on the fifth working day following the end of the quarter to enable PF to run the Chief Counsel Quarterly Report (CCQ) extract or other reports shortly thereafter.

3. Coordinators are also encouraged to run an Exceptions Report to verify that all required employees listed in the job types below have reported 100% of their time.




| _**Code**_ | _**Job Type**_ |
| --- | --- |
| ATT | Attorney |
| SLA | Senior Litigation Attorney |
| STA | Special Trial Attorney |
| LCI | Law Clerk/Intern |
| LMN | Legal Manager |
| NMN | Non-Legal Manager |
| PAR | Paralegal |


**30.7.1.3.5** **(12-21-2010)**

#### Time Reports

1. _**Programmed Time Reports**_. All offices participating in CASE-TR have the ability to generate time reports. Reports are available summarizing Division Counsel and Associate Chief Counsel offices’ functional time, down to the participant level. Reports contain a summary of hours by case number or category. Instructions for generating and printing reports are contained in the CASE-TR Handbook. Quarterly and fiscal year cumulative time and workload statistics may also be obtained from the Chief Counsel Quarterly Report (CCQ) available on-line through the Chief Counsel Intranet.

2. Offices should run their own reports to assist them in making management decisions and in preparing evaluations. They are highly encouraged to run reports regularly to ensure that time is being input on schedule and that it is valid and accurate. Refer to the CASE-TR Handbook for instructions on retrieving information with reports online.

3. _**Special Ad Hoc Queries**_. Counsel offices may request ad hoc queries from CASE-MIS by contacting their Systems, Division, or Associate Coordinator. National Office functions may request ad hoc queries by contacting the Planning & Finance Division (PF). Ad hoc queries encompassing national summary data may be requested by contacting PF. Such requests need the approval of the Chief Counsel, Division Counsel, Associate Chief Counsel (or their Deputy), or a Special Counsel to the Chief Counsel. While every effort will be made to comply with each request, these will be filled in order of priority during peak periods in the year.

4. PF maintains the archives of select output records for a period of five years.


**30.7.1.3.6** **(05-17-2006)**

#### Time Reporting for the Enforcement Revenue Information System (ERIS)

1. CASE-TR is the vehicle for gathering cost data to be input into the Enforcement Revenue Information System (ERIS) and other projects. ERIS is managed by the IRS Chief Financial Officer to account for revenues collected and costs incurred from conducting enforcement activities. ERIS also provides an automated link between certain types of cases tracked by these enforcement activities. Through these functions, ERIS supports managers in their efforts to manage enforcement functions and obtain measures of cost and revenue. Form 1734 , Transmittal Memorandum, provides this information to ERIS for the Chief Counsel tax litigation function. For additional information about the ERIS automated system, please refer to IRM 8.20.2 .

2. CASE-TR is programmed to generate an automated version of the Form 1734, Transmittal Memorandum. With Division Counsel management approval, other documents may be used as long as the hours and grade computation is in conformance with the formula displayed below.

3. Six fields on the automated Form 1734 are required for ERIS. Two fields ("Total Counsel hours worked" and "Average Employee grade" ) are computer-generated. The other four must be completed by the attorney/paralegal when applicable. The hours worked are a summary of all hours posted on the case.

4. _**Formula for hours and grade computation in the Form 1734**_. For each employee, multiply the number of hours worked on the case by grade. This produces hours by grade. Add hours by grade for each employee to produce total hours by grade. Divide total hours by grade by total hours worked on the case to obtain the average grade.



### Example:



One GS-14 attorney, one GS-13 attorney, and one GS-12 paralegal worked on the same case. The GS-14 spent 100 hours, the GS-13 spent 50 hours and the GS-12 spent 25 hours. Hours by grade are as follows: GS-14 = 1400 hours, GS-13 = 650, and GS-12 = 180. Total hours are 2230. \[(100 x 14) + (13 x 50) + (12 x 25) = 2230\] Average grade is 12.74 \[2230/(100 + 50 + 50) = 12.74\].


**30.7.1.3.7** **(05-17-2006)**

#### Problem Resolution and Program Modifications

1. _**Problem Resolution**._ Participants should sequentially follow these steps should any problems with the CASE-TR system be encountered:



1. Refer to the procedures contained in this section or the CASE-TR User handbook for answers to questions regarding the use of the system

2. Contact their appropriate Systems, Division, or Associate Coordinator if the questions cannot be resolved through such research

3. Coordinators who cannot resolve the problem at the local level should contact the Systems Coordinator Branch Chief for assistance


2. Requests for **_simple modifications_** not requiring programming and modifications to workload and time reporting categories, procedures, or requirements are approved and implemented by Planning and Finance Division (PF). Offices may submit requested changes to PF. The requester will be notified promptly if requests are not approved and will be kept informed of implementation status of those which are approved.

3. Requests for changes which require CASE-MIS **_programming modifications_** should be submitted as a Systems Change Request (SCR) to CISO. Contact the appropriate Systems, Division, or Associate Coordinator to prepare the SCR form. All SCRs will be coordinated with the CASE-MIS User Group, who will make approval recommendations to the Associate Chief Counsel (F&M). All recommendations that may result in system changes affecting workload and time reporting are routed through PF for coordination prior to being forwarded for approval. PF ensures that changes to the system are consistent with existing workload and time reporting policies and procedures.


**30.7.1.3.8** **(05-17-2006)**

#### Records

1. The Associate Chief Counsel (F&M), through the Planning and Finance Division, is responsible for:



   - Downloading workload and time data generated by Division Counsel and Associate Chief Counsel Office functions and reporting functions within Chief Counsel

   - Filing and storing workload and time data (see CCDM 30.7.1.4.9)

   - Documenting and cataloging data based on the report type and date

   - Providing copies of archived reports to requesters


2. The following reports are archival sources of workload and time data:



   - Counsel Time & Record Keeping System (CASE-TR a/k/a CTRS)

   - Chief Counsel Quarterly (CCQ) Reports

   - Tax Litigation Counsel Automated Tracking System (TLCATS) Reports


**30.7.1.3.8.1** **(05-17-2006)**

##### File Storage

1. Files will be maintained for two years, until the material has become obsolete, or is superseded by another document in accordance with the Records Control Schedule for Chief Counsel. See IRM 1.15.13. Necessary exceptions to this policy, such as retaining TLCATS, CASE-TR (formerly Counsel Time Reporting System (CTRS)), and workload reports for ten years, may be made or arranged by the Director, Planning and Finance Division. See CCDM 30.9.1, File Management, for overall information about Counsel's file management system.

2. Electronic and optical historical archives will consist of the following reports:



1. TLCATS download which includes monthly Division Counsel, Associate Chief Counsel and U.S. totals, as well as the quarterly totals (see Exhibit 30.7.1-1)

2. Historical files of the CTRS download (prior to CASE-TR of June, 1996), which include a quarterly summary of hours for District, Region, National Office, and U.S. totals by series

3. CCQ extract, which includes the quarterly and cumulative yearly summary of workload and hours by business unit and program areas


3. Files will be stored in designated areas in accordance with IRM and CCDM directives regarding access and security. See CCDM 30.6.1, Security of Confidential Information, Official Documents, Tax Data, Personnel, and Property.


**30.7.1.3.8.2** **(05-17-2006)**

##### Records Retrieval, Review and Destruction

1. Written or e-mail requests for copies of archived reports may be made to the Director, Planning and Finance Division (CC:FM:PF). PF will provide the records to the requestor as soon as possible in a format appropriate to the file retrieval process.

2. Periodic reviews by CC:FM:PF of the hard copy archives will be performed to identify files with expired retention periods (see Exhibit 30.7.1-2), duplicate copies, or obsolete material. Identified files will be properly disposed of based on content and format.


**30.7.1.4** **(10-05-2005)**

### Uniform Issue List

1. The Uniform Issue List (UIL) consists of index terms used within the Office of Chief Counsel and the Internal Revenue Service for describing legal issues arising under the Internal Revenue Code and for locating materials which have been indexed according to this system.

2. The index is the Office of Chief Counsel's cross-functional code-based numerical index. It is used to identify issues in all management information systems that require issue tracking. It is also used to index written determinations issued under IRC § 6110 that are released to the public.

3. The index also contains appendices of indexing terms specific to different segments of Counsel.

4. The Uniform Issue List is prepared by the Office of Chief Counsel, and is issued as Internal Revenue Publication 1102. It applies to all personnel in the Office of Chief Counsel and is used by some IRS functions.

5. Copies of the Uniform Issue List are distributed according to the Internal Management Document Distribution System (IMDDS) Schedule and additional copies may be obtained from the Area Distribution Centers.

6. Requests for new Uniform Issue List numbers require management approval and should be sent to the Chief Counsel Library for inclusion in the UIL database. The Library will vet the request and make a referral to the Office of the Associate Chief Counsel, Procedure & Administration (P&A), who will check with whatever Counsel office has an interest.

7. A current copy of the Uniform Issue List resides on the Chief Counsel Intranet. The printed copy is revised only after major tax legislation. Revisions are coordinated by the Associate Chief Counsel (P&A) with the legal functions and sent to the Chief Counsel Library for inclusion in the UIL database.


**Exhibit 30.7.1-1**

### Tax Litigation Counsel Automated Tracking System (TLCATS) Archived Reports

| **Report** | **Title** |
| --- | --- |
| TL-531 | Alphabetical List of Tax Shelters |
| TL-701 | Error Listing (U.S. Version) |
| TL-702 | Tax Court Case Receipts |
| TL-703 | Tax Court Case Revenue & Recovery Rates |
| TL-704 | Tax Court Cases - Current Inventory (U.S. Version) |
| TL-708 | Tax Court Receipts Pro Se & Represented |
| TL-709 | Caseload Statistics |
| TL-711 | Receipts, Disposals and Inventory of Tax Cases |
| TL-711D | Receipts, Disposals and Inventory of Tax Cases (Division/Associate) |
| TL-711R | Receipts, Disposals and Inventory of Tax Cases (Area/Assistant) |
| TL-711U | Receipts, Disposals and Inventory of Tax Cases (U.S.) |
| TL-712 | Receipts, Disposals and Inventory of Refund Litigation Cases |
| TL-712D | Receipts, Disposals and Inventory of Refund Litigation Cases (Division/Associate) |
| TL-712R | Receipts, Disposals and Inventory of Refund Litigation Cases (Area/Assistant) |
| TL-712U | Receipts, Disposals and Inventory of Refund Litigation Cases (U.S.) |
| TL-714 | Refund Cases with Overpayments More Than $999,999 |
| TL-714 | Tax Court Cases with Overpayments More Than $999,999 |
| TL-715D | Receipts, Disposals and Pending Inventory of Non-Docketed Cases (Division/Associate) |
| TL-715R | Receipts, Disposals and Pending Inventory of Non-Docketed Cases (Area/Assistant) |
| TL-715U | Receipts, Disposals and Pending Inventory of Non-Docketed Cases (U.S.) |
| TL-770 | Monthly Tax Shelter Receipts, Disposals, and Inventory Report |
| TL-771 | Monthly Tax Shelter Receipts Summary |
| TL-772 | Monthly Tax Shelter Disposals Summary |
| TL-773 | Monthly Tax Shelter Inventory Summary |
| TL-776 | Monthly ZZ Shelter Receipts, Disposals and Inventory Report |
| TL-777 | Monthly Listing pending ZZ Shelter Cases |
| TL-870 | Summary of TL Non-Docketed Advisory Opinions Timeliness |

**Exhibit 30.7.1-2**

### File Retention Schedule

| **REPORT** | **MONTHLY** | **QUARTERLY** | **2ND/4TH QUARTER** | **FISCAL YEAR** | **RETENTION PERIOD** |
| --- | --- | --- | --- | --- | --- |
| \*TLCATS Reports |  |  |  | X | < 5 Years |
| \*TLCATS Reports |  | X |  |  | Between 2-5 Years |
| TLCATS Reports | X |  |  |  | \> 2 Years |
| \*CASE-TR Summary of Hours |  |  |  | X | < 5 Years |
| CASE-TR Summary of Hours Reports |  |  | X |  | Between 2-5 Years |
| CASE-TR Summary of Hours Reports |  | X |  |  | \> 2 Years |
| CCQ Extract (Case Workload and Time Data Extract) |  | X |  |  | < 5 Years |

\*This schedule provides for file retention for at least the minimum time required by the IRM and the CCDM.

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part30/irm_30-007-001#addtoany "Show all")

A2A