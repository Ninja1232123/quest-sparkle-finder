---
url: "https://www.irs.gov/irm/part35/irm_35-008-004"
title: "35.8.4 Special Problems of Assessment and Payment | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-008-004#main-content)

- 35.8.4 [Special Problems of Assessment and Payment](https://www.irs.gov/irm/part35/irm_35-008-004#idm140379494978944)
  - 35.8.4.1 [Deficiencies Jeopardy Assessments](https://www.irs.gov/irm/part35/irm_35-008-004#idm140379494978496)
  - 35.8.4.2 [Interim Assessments](https://www.irs.gov/irm/part35/irm_35-008-004#idm140379495019680)
  - 35.8.4.3 [Unassessed Payments](https://www.irs.gov/irm/part35/irm_35-008-004#idm140379495014160)
  - 35.8.4.4 [Unpaid Assessments](https://www.irs.gov/irm/part35/irm_35-008-004#idm140379495083648)
  - 35.8.4.5 [Withheld Tax and Estimated Tax Payments](https://www.irs.gov/irm/part35/irm_35-008-004#idm140379495076288)
  - 35.8.4.6 [Recomputation Requests](https://www.irs.gov/irm/part35/irm_35-008-004#idm140379495069600)
  - 35.8.4.7 [Transferee and Fiduciary Liability Cases](https://www.irs.gov/irm/part35/irm_35-008-004#idm140379495038848)

    - 35.8.4.7.1 [Allocation of Liability](https://www.irs.gov/irm/part35/irm_35-008-004#idm140379495034960)
    - 35.8.4.7.2 [Interest on Transferee Liability](https://www.irs.gov/irm/part35/irm_35-008-004#idm140379495030384)

      - 35.8.4.7.2.1 [General Guidelines on Interest Issues](https://www.irs.gov/irm/part35/irm_35-008-004#idm140379495026400)
      - 35.8.4.7.2.2 [Interest in Transferee Rule 155 Cases](https://www.irs.gov/irm/part35/irm_35-008-004#idm140379494967424)

    - 35.8.4.7.3 [Overpayment to Transferees](https://www.irs.gov/irm/part35/irm_35-008-004#idm140379494963040)
    - 35.8.4.7.4 [Duplicate Liability](https://www.irs.gov/irm/part35/irm_35-008-004#idm140379494956512)
    - 35.8.4.7.5 [No Transferee Liability Cases](https://www.irs.gov/irm/part35/irm_35-008-004#idm140379494949312)
    - 35.8.4.7.6 [Fiduciary Liability Cases](https://www.irs.gov/irm/part35/irm_35-008-004#idm140379494938256)

# Part 35. Tax Court Litigation

# Chapter 8. Decisions, Orders of Dismissal, and Other Final Judgments

# Section 4. Special Problems of Assessment and Payment

* * *

## 35.8.4 Special Problems of Assessment and Payment

**35.8.4.1** **(08-11-2004)**

### Deficiencies — Jeopardy Assessments

1. Generally, a statutory deficiency as defined by section 6211 is to be determined by the court in each deficiency case. Exceptions to this general rule are discussed herein. Jeopardy assessments made prior to the issuance of a statutory notice are not taken into consideration in determining the statutory deficiency. In every deficiency case in which there has been a jeopardy assessment prior to the issuance of the statutory notice, there must be stipulated or provided in the Rule 155 computation, and the court must determine, the deficiency without taking into consideration the jeopardy assessment. If the agreed deficiency upon settlement or upon a Rule 155 computation is in excess of the amount of the jeopardy assessment, the additional deficiency to be assessed must also be determined by the court. If the jeopardy assessment has been paid, in whole or in part, and such payment results in an overpayment of tax or penalty, an overpayment must be stipulated and determined by the court’s decision. If jeopardy assessments were made after the issuance of the statutory notice, the case may be closed as an interim assessment case or as a jeopardy assessment case, with appropriate modification of the forms in Exhibits 35.11.1–141 through 35.11.1–143 and Exhibits 35.11.1–146 through 35.11.1–150.

2. Prior unpaid assessments, excessive credits claimed for tax withheld or estimated tax payments, and interim assessments must be considered in drafting the settlement or Rule 155 documents. In some instances, these documents must include a determination of the deficiency to be assessed or the deficiency to be paid to provide a basis upon which the Service may assess and/or collect the tax due. Some of these exceptional circumstances are hereinafter discussed. The attorney must determine whether the amount of the redetermined or agreed deficiency in tax or penalty is in excess of the amount of tax or penalty determined in the statutory notice. If so, an amendment to answer or stipulation must be filed to put the additional amount in issue.

3. For special rules applicable when a jeopardy or termination assessment has been made against a possessor of cash using the presumptions of section 6867, _see_ CCDM 35.2.1.1.4.1.


**35.8.4.2** **(08-11-2004)**

### Interim Assessments

1. An interim assessment is an assessment (other than a jeopardy assessment) of tax or penalty made after issuance of the statutory notice. These assessments are usually for amounts paid by the taxpayer on the deficiency determined by the Service. If the paid assessment results in an overpayment, the case is to be closed as an overpayment case. If there is a net deficiency after taking into consideration the paid interim assessment, however, the case is to be closed as an interim assessment case. In this instance, the settlement or Rule 155 documents should determine the deficiency without taking into consideration the assessment made subsequent to the mailing of the statutory notice. The amount of the subsequent assessment, with an indication of whether such assessment is paid or unpaid, in whole or in part, and the deficiency remaining to be assessed, should be shown in the settlement or Rule 155 documents. The waiver paragraph of the stipulation and combined stipulation and decision documents must be carefully drafted to prevent any subsequent misunderstanding that collection will include the deficiency (to be assessed) as well as the unpaid portion of the interim assessment. _See_ Exhibit 35.11.1–141.


**35.8.4.3** **(08-11-2004)**

### Unassessed Payments

1. Remittances which have not been assessed, such as advance payments made after the issuance of a statutory notice of deficiency, voluntary remittances in the nature of a cash bond, excess collection, or similar accounts on the records of the Service should be taken into consideration in closing a case by settlement stipulation or by a Rule 155 computation. Such amounts do not have to be assessed except in Joint Committee cases. _See_ CCDM 35.5.4. The transcript of petitioner’s account should usually be checked to determine the status of the account before preparing and filing a decision document with the Tax Court. Under Rev. Proc. 84–58, 1984–2 C.B. 501, post-statutory notice of deficiency remittances will be treated as payments of tax, unless specifically instructed otherwise by the taxpayer. Such payments will be posted to the taxpayer’s account as soon as received and ordinarily will not be assessed until after the decision is entered. Any posted payment will stop the running of interest on the deficiency and will be treated as any other assessed amount in that interest will be paid on any overpayment resulting therefrom, from the date the account was posted. No interest will be paid on amounts posted as a cash bond. If at the time of preparing the decision documents there is a net deficiency and the post-statutory notice payment has been assessed, use the interim assessment forms, Exhibit 35.11.1–141 and 35.11.1–142. If there is a net deficiency and the post-statutory notice payment has not been assessed, use the interim payment form, Exhibit 35.11.1–143. If there is an overpayment resulting from an assessed payment, use the appropriate overpayment form, Exhibits 35.11.1–129 through 35.11.1–137. If there is a net overpayment and the payment has not been assessed, use the unassessed payment forms, Exhibits 35.11.1–144 and 35.11.1–145.

2. A cash bond is not a payment of tax. The Tax Court does not have jurisdiction under section 6512(b)(2) to find an overpayment resulting from a deposit in the nature of a cash bond in excess of the deficiency. Accordingly, any bond case should be treated as an ordinary deficiency case, _i.e._, disregard the bond in determining whether there is an overpayment and in preparing the decision document. The bond should, however, be referenced in the stipulation filed concurrently with the decision to acknowledge that a remittance was made.


**35.8.4.4** **(08-11-2004)**

### Unpaid Assessments

1. Administrative difficulties have arisen when decisions, based on settlement stipulations or Rule 155 computations, do not take into consideration previous assessments (except jeopardy assessments) which have not been paid in full. Such unpaid assessments are usually nonpayment of original or returned tax. When this factor is involved in either a settlement or an agreed Rule 155 computation, there should be a clear and definite understanding in writing with the petitioner that the unpaid assessment is due and is to be paid in addition to the agreed upon deficiency. A "best practice" is to obtain payment of the unpaid assessment prior to the execution of the stipulation or the filing of the agreed Rule 155 computation. If this is not feasible, the form of the stipulation or the Rule 155 computation to which the petitioner agrees should clearly show the amount of the assessment which is due and unpaid. _See_ Exhibits 35.11.1–151 and 35.11.1–200. In cases involving a substantial amount of unpaid assessment of original tax, and payment thereof will not be made prior to filing the settlement stipulation or agreed Rule 155 computation, it may be advisable to secure a collateral agreement signed by the taxpayer (not just the attorney) that the unpaid original tax is due. Such collateral agreement should be clear and unambiguous that the taxpayer owes not only the statutory deficiency stipulated, but also the unpaid assessed tax. For Rule155 cases in which the petitioner does not agree with the respondent’s computation, any unpaid assessment of original tax should be clearly shown in the computation and the court’s decision. _See_ Exhibit 35.11.1–200.


**35.8.4.5** **(08-11-2004)**

### Withheld Tax and Estimated Tax Payments

1. Tax withheld and estimated tax payments are not assessed when the returned tax is assessed. Estimated tax payments are credited and given an account number when actually made. Withheld tax is not specifically assessed as to the taxpayer whose tax is withheld, but is assessed in connection with payment by the taxpayer’s employer. A statutory deficiency is determined without regard to tax withheld and estimated tax payments. When the taxpayer has claimed a credit on the return for tax withheld or estimated tax payments in amounts exceeding that actually withheld or paid, the decision document should reflect both the deficiency in payment and the statutory deficiency. Therefore, the decision of the court will form a basis upon which administrative officials can assess and collect the unpaid portions of the taxpayer’s tax liability for the year involved. If the terms of a settlement or a Rule 155 computation result in a statutory deficiency as well as an overpayment of tax by reason of tax withheld and/or estimated tax payments, the stipulation or Rule 155 and decision documents should provide for both the statutory deficiency and the overpayment. Where the total net tax paid, including the tax withheld and estimated tax payments, equals the settled or Rule 155 tax liability so that there is no additional tax to be collected, but there is additional tax to be assessed, the usual form of determining a deficiency may be used with an additional clause indicating the deficiency has been paid but not assessed. If the statutory deficiency has been assessed after the mailing of the statutory notice, the case should be closed as an interim assessment case.


**35.8.4.6** **(08-11-2004)**

### Recomputation Requests

1. Field Counsel. A recomputation of the tax liability in a case is necessary when the court’s opinion requires it under Rule 155. It may also be necessary in settled cases. In some instances, a computation, or a partial computation, may be necessary in the preparation and trial of a case. For computations, submit a request to Appeals via Form 1734. Transmit the Form 1734 to Appeals with a copy of the court’s opinion, Area Counsel’s decision, as appropriate, and the administrative file. It is unnecessary to send the legal file. Set forth on Form 1734 the specific adjustments to be made to the statutory notice computation.



1. A Rule 155 computation should specifically describe the adjustments to be made to the statutory notice computation. The comments on the adjustments should be in clear concise language and should include any necessary interpretation. If a time limit is involved, specifically set forth the date when the recomputation is needed.


2. Associate offices: A computation of the tax liability in cases handled by an Associate office may be necessary under certain circumstances. Primarily, these will involve cases on remand from a court of appeals or the Supreme Court. In most circumstances, the case should be transferred to Field Counsel for further proceedings under a mandate from a reviewing court. In the rare situation where the Associate office is handling a case on remand, the request for the computation should be made through the assistance of the Field Counsel office in which the case originated. A memorandum should be prepared by the Associate office attorney assgined to the case requesting Field Counsel to obtain a recomputation. This memorandum will set forth the adjustments to be made in the prior computation under Rule 155 or in the statutory notice, as appropriate. If the computation is pursuant to remand, a copy of the court of appeals or Supreme court opinion is to be forwarded with the request. The memorandum should set forth the interpretation of the opinion as to the adjustments to be made in the recomputation, and any admissions, concessions, etc., made by the parties. The administrative file will be forwarded with the request memorandum if the file is in the possession of the Associate office attorney; otherwise Field Counsel will be asked to forward the file to Appeals. The legal file should not be forwarded to the Appeals office.


**35.8.4.7** **(08-11-2004)**

### Transferee and Fiduciary Liability Cases

1. For tried cases, all of the issues raised as to the amount of transferee liability and the interest on such liability should be settled by the court’s opinion. In this event, the computation would follow the court’s holding in these matters. For settled cases, the settlement stipulation should determine the amount of the liability as well as the beginning date for the running of interest on such liability.

2. The terminology used in transferee cases, designating the fiduciary capacity of the petitioner in the answer or other pleading, will also be used in the Rule 155 computation and the settlement stipulation.


**35.8.4.7.1** **(08-11-2004)**

#### Allocation of Liability

1. In cases involving the liability of a transferee for several taxes and penalties of the transferor, the settlement stipulation or Rule 155 computation and the court’s decision should not allocate the liability of the transferee among the liabilities of the transferor for taxes and penalties for the several years. This will avoid any issue being raised at a later date that a particular liability of the transferee was extinguished when the transferor’s liability for that tax or penalty has been paid.


**35.8.4.7.2** **(08-11-2004)**

#### Interest on Transferee Liability

1. Generally, the court is not requested to, or may be unable to, determine the exact amount of interest on the transferee liability. Nevertheless, to avoid belated disagreements or lawsuits over interest, and to form a basis for the assessment and collection of interest on the liability, the court should determine the date or dates from which interest is to run on the stipulated or Rule 155 liability. In overpayment cases, the amount of interest to be refunded or credited to the transferee (other than interest on the determined overpayment) must be determined in dollars and cents.


**35.8.4.7.2.1** **(08-11-2004)**

##### General Guidelines on Interest Issues

1. The following general guidelines will be used to resolve the issue of interest in settled transferee liability cases.



1. In unlimited liability cases, interest will be provided in the stipulation and court’s decision on the agreed liability from the due date of the tax by the transferor to the date of payment;

2. In unlimited liability cases in which the transferor’s liability for a penalty is involved, the interest to the transferee should be determined as follows: (i) If the penalty is imposed under sections 6651(a)(1), 6653, 6662, or 6663, the transferee’s liability for interest is calculated from the due date of the tax by the transferor to the date of payment; (ii) If the penalty is imposed under a Code section other than sections 6651(a)(1), 6653, 6662, or 6663, the interest to the transferee is calculated from the date of the notice and demand to the transferor for the penalty, up to the date of payment. _See generally_ section 6601(e);

3. In limited liability cases, if there is more than one date for the transfer of assets, the court must determine in the decision the various dates of transfers and the portion of the total liability which is attributable to each transfer date. These dates and the allocation of the liabilities thereto should be settled by the parties as a part of the overall settlement of the case.

4. _See_ Exhibits 35.11.1–155 through 35.11.1–161 for sample decision documents in unlimited and limited transferee liability cases..


**35.8.4.7.2.2** **(08-11-2004)**

##### Interest in Transferee Rule 155 Cases

1. In Rule 155 cases, any question concerning interest and the period for which interest due from the transferee runs should be decided in the court’s opinion. In the absence of interest issues being raised by the pleadings, the general provisions for interest as set forth in subparagraph (2) above, for settled cases, should be followed in the Rule 155 computation.


**35.8.4.7.3** **(08-11-2004)**

#### Overpayment to Transferees

1. Generally, a true transferee cannot obtain a refund of tax paid by the transferor. The transferee, however, can obtain a refund or credit of amounts previously paid as transferee if such amounts were paid as transferee within the limitation periods provided by the applicable provisions of the internal revenue laws. This rule applies to transferees, generally, even though they may be assignees of rights or specific claims of the transferor since section 3477 of the Revised Statutes (31 U.S.C. § 3727), prohibiting assignments of a claim against the government, applies to claims for refunds of taxes. When the transferee is legally entitled to claim a refund of transferee liability actually paid, the stipulation or Rule 155 computation and the court’s decision should include a breakdown of the overpayment as between overpayment of transferee liability and overpayment of interest (if any) paid on such liability (other than interest on the overpayment). If there is no overpayment of interest (other than the regular interest on the determined liability overpayment), the stipulation or Rule 155 document should so provide. All of the necessary data supporting this allowed overpayment must be set forth in the stipulation or the Rule 155 computation. As in any other overpayment case, the court’s decision must include a determination of the necessary essentials for an overpayment. If a case involves a potential overpayment to a transferee, and if there is any substantial question whether the overpayment is allowable by law, or as to the form of stipulating or providing for the overpayment in the Rule 155 computation, the matter should be forwarded to P&A for review.


**35.8.4.7.4** **(08-11-2004)**

#### Duplicate Liability

1. When cases of the transferor and one or more transferees, or the cases of several transferees, are pending in the Tax Court, the combined amount of the deficiencies and/or liabilities stipulated or redetermined in the Rule 155 computation in all such cases may exceed the transferor’s liability. In this event, the petitioners may question the total amount to be collected from the liable parties. In these instances, the separate stipulation document or the stipulation portion of the combined document may contain a duplication paragraph. For Rule 155 computations, the face sheet or the stipulation portion of the decision document may also contain a duplication paragraph. The duplication paragraph in either a stipulated or a Rule 155 case is a nonoperating paragraph. It is not, and should not be, made part of the court’s decision. Its sole purpose is to assure the various petitioners that only the amount of the liability due from the transferor, plus interest thereon, will be collected. This is so even though the total amount of the liability determined in the court’s decision as due from the transferor and/or several transferees exceeds the liability for tax, penalty, and interest due from the transferor. The duplication paragraph should not be included in either the stipulation or Rule 155 document when only one transferee is before the court, or when the total liability stipulated or redetermined in the Rule 155 computation does not exceed the liability of the transferor for unpaid original tax, deficiencies in tax, or penalties plus interest. _See_ Exhibit 35.11.1–152.


**35.8.4.7.5** **(08-11-2004)**

#### No Transferee Liability Cases

1. Cases settled on the basis of no transferee liability are of two types:



1. It is determined under the settlement that there is no original or deficiency tax, penalty, or interest due from the transferor, or that the petitioner is not in fact a transferee of the alleged transferor. In this instance, as a matter of law, there is no transferee liability.

2. On the date of the issuance of the statutory notice the petitioner was liable as a transferee for tax, penalty, and interest due from the transferor. But, due to payment of the transferor’s liability for tax and penalty plus interest, after the issuance of the statutory notice, there is at the time of settlement no transferee liability. This situation requires a stipulation and decision that the tax, penalty, and interest due from the transferor has been assessed and paid, and because of such payment, there is now no transferee liability due from the petitioner.


2. The Rule 155 computation and court’s decision in decided cases will follow the same procedure set forth in paragraph (a), above, in stipulated cases, when applicable. In decided cases, the court in its opinion determines either that there is no transferee liability or that by reason of payment there is now no liability due from the transferee before the court.

3. When there is no transferee liability, as determined by settlement or by the court’s opinion, the attorney must use extreme care in drafting stipulation or Rule 155 documents. The distinction between the two types made in paragraph (1), above, must be carefully observed. _See_ Exhibits 35.11.1–153 and 35.11.1–154.


**35.8.4.7.6** **(08-11-2004)**

#### Fiduciary Liability Cases

1. As in transferee cases, the amount of the fiduciary liability is either determined by the settlement agreement of the parties or by the court’s opinion. The settlement stipulation or the Rule 155 computation, together with the court’s decision, must make a determination of such liability as well as interest on the liability. The transferee procedural instructions on settlement and Rule 155, together with the exhibit forms with appropriate modification, should be used in fiduciary liability cases. _See_ Exhibits 35.11.1–152 through 35.11.1–161.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-008-004#addtoany "Show all")

A2A