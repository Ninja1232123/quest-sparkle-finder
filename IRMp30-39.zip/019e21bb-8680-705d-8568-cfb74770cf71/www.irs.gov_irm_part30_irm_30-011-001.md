---
url: "https://www.irs.gov/irm/part30/irm_30-011-001"
title: "30.11.1 FOIA Requests for Chief Counsel Records | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part30/irm_30-011-001#main-content)

- 30.11.1 [FOIA Requests for Chief Counsel Records](https://www.irs.gov/irm/part30/irm_30-011-001#idm139788303591120)
  - 30.11.1.1 [Administrative Processing of FOIA Requests for Chief Counsel Records](https://www.irs.gov/irm/part30/irm_30-011-001#idm139788308714576)
  - 30.11.1.2 [Receipt and Processing of FOIA Request](https://www.irs.gov/irm/part30/irm_30-011-001#idm139788309441888)
    - 30.11.1.2.1 [Evaluation of Request](https://www.irs.gov/irm/part30/irm_30-011-001#idm139788308606144)
    - 30.11.1.2.2 [Search for Records](https://www.irs.gov/irm/part30/irm_30-011-001#idm139788293729280)
    - 30.11.1.2.3 [Period to Respond](https://www.irs.gov/irm/part30/irm_30-011-001#idm139788293080464)
  - 30.11.1.3 [National Office Responsibilities](https://www.irs.gov/irm/part30/irm_30-011-001#idm139788292992752)
  - 30.11.1.4 [Review by DLS Paralegal Specialists](https://www.irs.gov/irm/part30/irm_30-011-001#idm139788293738928)
  - 30.11.1.5 [Area Counsel or Associate Area Counsel Office Responsibilities](https://www.irs.gov/irm/part30/irm_30-011-001#idm139788293735696)
  - 30.11.1.6 [Congressional Records](https://www.irs.gov/irm/part30/irm_30-011-001#idm139788307929088)
  - 30.11.1.7 [Coordinating FOIA Requests Relating to Litigation or Examinations](https://www.irs.gov/irm/part30/irm_30-011-001#idm139788307926432)
  - 30.11.1.8 [Discretionary Disclosure](https://www.irs.gov/irm/part30/irm_30-011-001#idm139788307919248)
  - 30.11.1.9 [Response to Disclosure Office](https://www.irs.gov/irm/part30/irm_30-011-001#idm139788309427968)

# Part 30. Administrative

# Chapter 11. Freedom of Information Act Requests for Chief Counsel Records

# Section 1. FOIA Requests for Chief Counsel Records

* * *

## 30.11.1 FOIA Requests for Chief Counsel Records

#### Manual Transmittal

August 09, 2018

#### Purpose

(1) This transmits revised CCDM 30.11.1, Freedom of Information Act Requests for Chief Counsel Records; FOIA Requests for Chief Counsel Records.

#### Background

CCDM 30.11.1 is completely revised to provide current policy and procedures relating to the processing of Freedom of Information Act (FOIA) requests for records maintained by the Office of Chief Counsel.

#### Material Changes

(1) CCDM 30.11.1.1 is revised to describe the role of Procedure & Administration (P&A) Branch 6 and 7 attorneys in the FOIA administrative process.

(2) CCDM 30.11.1.2 is revised to update and clarify procedures regarding the receipt and processing of FOIA requests for Chief Counsel records.

(3) New CCDM 30.11.1.4, Congressional Records, is added to provide guidance and cross-references relating to FOIA requests for congressional documents.

(4) New CCDM 30.11.1.5, FOIA Requests Relating to Litigation or Examinations, is added to incorporate and update the content of Chief Counsel Notice CC-2006-016 and to provide guidance for coordinating responses to related requests for information.

(5) CCDM 30.11.1.7, Discretionary Disclosure, is revised to clarify the Office of Chief Counsel’s policy and procedures for discretionary disclosure and to incorporate the deliberative process privilege 25-year sunset clause, as mandated by the FOIA Improvement Act of 2016.

(6) Organizational titles and references are updated and minor typographical errors are corrected throughout the section.

#### Effect on Other Documents

CCDM 30.11.1, dated 05-01-2009, is superseded. This section incorporates Chief Counsel Notice CC-2006-016.

#### Audience

Chief Counsel

#### Effective Date

(08-09-2018)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure and Administration)

**30.11.1.1** **(08-09-2018)**

### Administrative Processing of FOIA Requests for Chief Counsel Records

1. This section covers the processing of Freedom of Information Act (FOIA) requests for records maintained in the National Office, which includes all Associate Chief Counsel and Division Counsel Headquarters offices, and for records maintained in Area or Associate Area Counsel Offices.

2. All FOIA requests for National Office Chief Counsel records are coordinated with and processed by the Office of Associate Chief Counsel (Procedure & Administration). All FOIA requests for other Chief Counsel records are coordinated with and processed by the Area or Associate Area Counsel Office where the records are maintained.

3. Procedure & Administration (P&A) Branches 6 and 7 attorneys are available to answer questions regarding FOIA-related issues, such as:



   - Determining whether a FOIA request is legally sufficient, _e.g._, not overbroad

   - Working with a requester to narrow the scope of a FOIA request

   - Searching for Chief Counsel records originating outside of P&A

   - Determining whether specific records or groups of records are responsive to a FOIA request


**30.11.1.2** **(08-09-2018)**

### Receipt and Processing of FOIA Request

1. **National Office**. A Disclosure Office within the Office of Governmental Liaison, Disclosure, and Safeguards (GLDS) will forward a copy of any FOIA request for National Office Chief Counsel records to the Chief, Disclosure and Litigation Support Branch (DLS) in the Legal Processing Division within P&A. Upon receipt of the request, a case will be opened in TECHMIS as FOIA-XXXXXX-YY (category D/A-L (Disclosure Advice and Litigation) and subcategory FOIA/R (FOIA Requests)), and the request will be assigned to a paralegal specialist in DLS for processing.

2. **Area Counsel and Associate Area Counsel Offices**. A Disclosure Office within GLDS will forward a copy of any FOIA request for other Chief Counsel records to the appropriate Area or Associate Area Counsel office where responsive records are likely be found. Upon receipt of the request from the Disclosure Office, a case will be opened in TECHMIS as FOIA-XXXXXX-YY (category D/A-L (Disclosure Advice and Litigation) and subcategory FOIA/R (FOIA Requests)), and the request will be assigned to a field attorney or paralegal specialist.


**30.11.1.2.1** **(08-09-2018)**

#### Evaluation of Request

1. For requests received in the National Office, the DLS paralegal specialist will first evaluate whether the request satisfies the procedural requirements of the FOIA and applicable regulations, with particular attention to whether it reasonably describes the records for which access is being sought and whether the request seeks National Office Chief Counsel records. If the answer to either question is negative, a memorandum will be prepared within three working days of the date of assignment containing an appropriate explanation and the request will be returned to the Disclosure Office. The TECHMIS case will then be closed.

2. For requests received in Area or Associate Area Counsel Offices, the Disclosure Office will determine prior to forwarding the request to the Counsel office whether the request satisfies all procedural requirements.

3. Upon receipt of a valid FOIA request, if the field attorney or DLS paralegal specialist determines that some IRS office(s) other than the Counsel Office may have responsive records and therefore needs to be provided with a search memorandum, the field attorney or DLS paralegal specialist will contact the Disclosure Office caseworker with that information. The field attorney or DLS paralegal specialist will document such notification in the case file history sheets.

4. If a DLS paralegal specialist or field attorney receives a FOIA request involving novel or complex issues or sensitive subjects, the FOIA request should be brought to the attention of the Office of Associate Chief Counsel (P&A). P&A Branch 6 and 7 attorneys are available to assist with addressing these issues. FOIA requests involving sensitive subjects or that otherwise may warrant Counsel review include:



1. Requests from major news media outlets or tax publishers

2. Requests from or concerning persons, entities, issues, or programs that have generated or may generate media attention

3. Requests from or concerning any member or committee of Congress

4. Requests that may have national political implications, usually from organizations known to have national political influence

5. Requests from NTEU (or other national unions) for information on a national policy or program

6. Requests for information (other than Public Information Listing (PIL) or Oaths of Office) about IRS or Chief Counsel executives


**30.11.1.2.2** **(08-09-2018)**

#### Search for Records

1. **National Office**. Once it is confirmed that the request satisfies all procedural requirements, the DLS paralegal specialist assigned to the request will complete a search of TECHMIS in order to determine the location(s) of all responsive records. The DLS paralegal specialist will send a search memorandum to the appropriate office(s) requesting responsive records. National Office attorneys should carefully read the search memorandum and conduct their searches for responsive records in accordance with IRM 11.3.13.6 et seq.



1. **Closed files in DRU.**For records maintained in closed legal files stored in the P&A Docket, Records and User Fee Branch (DRU), the DLS paralegal specialist will request the legal file from DRU by use of Form 9612, Request for Records.

2. **Closed files in other locations.**For records maintained in closed legal files that are stored in locations other than DRU or that cannot be located, the DLS paralegal specialist is to send a memorandum to the appropriate office(s), to the attention of the designated point of contact, requesting that the files be forwarded to the Chief, DLS. If records were not compiled into a legal file, the originating office should take immediate steps to preserve and gather all records to constitute a legal file and then forward the file to the Chief, DLS.



      ### Note:



      If the TECHMIS search does not provide information regarding the location of the responsive records, the DLS paralegal specialist will consult with P&A Branches 6 and 7 to identify the appropriate originating office(s) to which to direct the search memorandum.





      ### Note:



      For requests limited to public comments and public hearing information , the DLS paralegal specialist should notify the Disclosure Office that the records are available through www.regulations.gov.


2. **Area Counsel or Associate Area Counsel Offices**. Upon receipt of a valid FOIA request from the Disclosure Office, the assigned field attorney or paralegal specialist will determine which records are responsive to the request.

3. **Search Questionnaires.**When an office conducts a search for responsive records, the office must complete the search questionnaire identifying the amount of time spent and the grade level of each individual who performed the search.

4. **Requests for Previously Processed Copies of section 6110/FOIA Material in the National Office**. If there has been a prior section 6110/FOIA request for records, the DLS paralegal specialist should first determine whether additional records may have been generated since the prior request was processed. If so, the steps set forth in 30.11.1.2.2(1) should be followed. If, however, no additional records are expected to have been created, in lieu of retrieving the closed legal file, the DLS paralegal specialist will obtain a copy of the records, as previously disclosed, and a copy of any written articulation covering redactions in those records from the file room. DLS will then review the records, bearing in mind any changes which may be brought about by the passage of time or other changes in circumstances. For example, if the records had previously been withheld because they related to a pending investigation that has since been closed and release of the records would no longer interfere with the investigation, there may no longer be a basis for withholding the records. Similarly, records that were previously withheld under the deliberative process privilege and are 25 years old may no longer be withheld under that justification. See Note at CCDM 30.11.1.8(1).


**30.11.1.2.3** **(08-09-2018)**

#### Period to Respond

1. **Search.** Agencies are required to respond to FOIA requests within 20 business days of receipts. Accordingly, offices should complete their searches for responsive records as soon as possible upon receiving a search memorandum. If the search cannot be completed by the original due date, the assigned attorney must promptly contact DLS or the Disclosure Office with an estimated date of completion. Such contacts are to be documented in the case file.

2. **Expedited treatment.** For any FOIA request for which the Disclosure Office has granted expedited treatment , the applicable time periods will be truncated by 50% or as otherwise directed by the Disclosure Office.


**30.11.1.3** **(08-09-2018)**

### National Office Responsibilities

1. Upon receiving all responsive records, the DLS paralegal specialist will review the records for their appropriate disclosure treatment and respond, on behalf of the Office of Chief Counsel, to the Disclosure Office.

2. The office or offices maintaining or creating the requested records (originating offices) are not required to make any disclosure recommendations, but may do so if they wish.



1. For those requests that the DLS paralegal specialist did not obtain directly from the originating office, the paralegal specialist will send an email to the office, to the attention of the designated point of contact, inquiring whether the office wishes to review the disclosure treatment recommended by DLS. The originating office is to respond within five working days. Once the office receives the DLS paralegal specialist’s proposed response and package of records, the office is expected to provide its concurrence, or if there is any disagreement, the office’s proposed changes, within ten working days of the date of DLS’s email.

2. For those requests that the originating office(s) provided responsive records and expressed an interest in reviewing DLS’s recommendations on the disclosure of such records, the DLS paralegal specialist will email the office, to the attention of the designated point of contact, and inform the office that the disclosure package is ready for review. The office is expected to provide its concurrence, or if there is any disagreement, the office’s proposed changes, within ten working days of the date of DLS’s email. Any disagreements are to be resolved under Counsel’s reconciliation procedures.


3. DLS will coordinate with other offices as appropriate and document any such coordination in the case file history notes.




| _**Example 1:**_ If a record located in a National Office file originated in or was maintained by an Area or Associate Area Counsel office, DLS should consult and coordinate with the appropriate field office for disclosure recommendations. |
| --- |
| _**Example 2:**_ If the record was generated outside of the Office of Chief Counsel, but is now of institutional interest to Counsel, **e.g.**, examination records relevant to a disputed Tax Court case, DLS should consult and coordinate with appropriate IRS office(s) for disclosure recommendations. |
| _**Example 3:**_ For those FOIA requests involving records that contain information received from or that may otherwise be of interest to treaty partners, the originating office should consult and coordinate with the Office of Associate Chief Counsel (International). |

4. To the extent the file contains records created by another agency (including Treasury), the attorney will first determine whether Counsel has any institutional interest that warrants withholding the other agency records. If so, the attorney will inform the Disclosure Office of the need to coordinate disclosure with the other agency or to transfer the request. If no institutional interest for withholding exists, the attorney will separate the other agency’s records from the Counsel records and note their origin. See 31 C.F.R. part 1, § 1.5(c)(2).



### Note:



Whenever published guidance records are the subject of a FOIA request, the office should contact Treasury Office of Tax Policy to coordinate the disclosure recommendations with respect to the records.


**30.11.1.4** **(08-09-2018)**

### Review by DLS Paralegal Specialists

1. Upon receipt of all records and any disclosure recommendations from National Office attorneys, the DLS branch will review both the records and recommendations and make an independent determination of what records should be recommended for release to the requester. If DLS disagrees with the originating office’s recommendations, DLS will coordinate with that office to reach an agreement. If an agreement cannot be reached, the disagreement will be resolved under Counsel reconciliation procedures. See CCDM 31.1.4.6.

2. After final disclosure determinations are reached, DLS will respond on behalf of the Office of Chief Counsel to the Disclosure Office.


**30.11.1.5** **(08-09-2018)**

### Area Counsel or Associate Area Counsel Office Responsibilities

1. Records in any legal file, including a pending litigation case file, are generally not to be withheld on a blanket or **per se** basis. Rather, the attorney must determine whether each record within a file is subject to one or more FOIA exemptions.

2. The attorney assigned to respond to the FOIA request will forward one complete clean set of the responsive records and one set of responsive records with clearly marked redactions to the Disclosure Office.

3. The attorney shall also provide a written articulation as to why each of the proposed redactions should be made.

4. The attorney shall complete the search questionnaire identifying the amount of time spent and the grade level of the individual performing the search.

5. The attorney may choose to coordinate with the IRS office. In that event, the coordination with the IRS office will be noted in any transmittal of the responsive records, and responsibility for the assertion of any exemptions will be attributed to the Counsel attorney or IRS office, as warranted. For example, the attorney may want to contact the Appeals Officer, if an Appeals Case Memorandum is among the responsive records, in order to determine whether the Appeals Case memorandum, or any portion, should be released or withheld. If it is necessary for the field attorney to coordinate with IRS offices, the attorney will notify the Disclosure Office of the need to coordinate. This will alert the Disclosure Office to ask for additional time, if necessary, to respond to the request.

6. To the extent the file contains records created by another agency (including Treasury), the attorney will first determine whether Counsel has any institutional interest that warrants withholding the other agency records. If so, the attorney will inform the Disclosure Office of the need to coordinate disclosure with the other agency or to transfer the request. If no institutional interest for withholding exists, the attorney will separate the other agency’s records from the Counsel records and note their origin. _See_ 31 C.F.R. part 1, § 1.5(c)(2).


**30.11.1.6** **(08-09-2018)**

### Congressional Records

1. The FOIA provides for the disclosure of federal agency records. Congress is not a federal agency, and, therefore, congressional documents are not subject to FOIA. When Congress creates a document and provides it to the IRS, the document retains its status as a congressional record if Congress has manifested a clear intent to control the document.

2. See CCDM 34.9.1.2 for procedures on responding to requests for documents received from Congress or created by the IRS in response to a congressional committee inquiry. For a detailed discussion of Joint Committee on Taxation documents, see CCDM 35.5.4.9.


**30.11.1.7** **(08-09-2018)**

### Coordinating FOIA Requests Relating to Litigation or Examinations

1. **Searching for FOIA Requests.** Counsel employees responding to discovery requests or involved in examinations should coordinate with HQ Disclosure Policy and Program Operations (PPO, formerly known as HQ Disclosure) to determine whether a FOIA request for similar records has been made by, or on behalf of, the taxpayer. PPO’s inventory management system tracks all FOIA requests filed nationwide with the IRS and includes data on subpoenas and other requests for IRS information.



1. Counsel employees should email disclosure.referral@irs.gov requesting a search of the inventory management system for relevant FOIA requests. Counsel employees should provide as much information as possible in order to assist Disclosure personnel in their search.


2. **Coordinating Responses.**While FOIA is a separate, distinct, and independent process. Disclosure personnel and Counsel employees should coordinate responses to related requests for information to ensure consistency in asserting privileges, redacting records, or withholding records entirely. Counsel employees and Disclosure personnel should consider whether release of any records sought in a FOIA request would have an adverse effect on current litigation or examination.



1. If the records responsive to the FOIA request are from functions other than Counsel, Disclosure personnel should provide copies of the records located in these other functions to the Counsel employee on an expedited basis.

2. If the search has already been completed. Counsel employees should receive all responsive records immediately in order to make disclosure recommendations to the Disclosure personnel.


**30.11.1.8** **(08-09-2018)**

### Discretionary Disclosure

1. Some FOIA exemptions are mandatory in nature and cannot be waived, e.g., FOIA exemption (b)(3) in conjunction with section 6103, which specifically prohibits the disclosure of returns and return information. Certain FOIA exemptions are not mandatory and can be waived as a matter of agency discretion. The most common discretionary exemptions can be found in FOIA Exemption (b)(5), which incorporates various common law or governmental privileges recognized in discovery, including the deliberative process privilege (sometimes referred to as "governmental or executives privilege" ), the work product doctrine, and the attorney-client privilege. The IRS’s decision to assert these privileges in responses to FOIA requests will be consistent with the application of these same privileges in the context of discovery.



### Note:



In accordance with the FOIA Improvement Act of 2016, the deliberative process privilege cannot be asserted for records created 25 years or more before the date of the FOIA request. Questions regarding the deliberative process sunset provision should be directed to P&A Branches 6 and 7.

2. The decision to waive any applicable exemption or privilege during discovery, at trial, or in response to FOIA requests will be made only after a full and deliberate consideration of the institutional ( _i.e._, public accountability, safeguarding national security, law enforcement effectiveness, and the promotion of candid and complete deliberations), commercial, and personal privacy interests that could be implicated by disclosing this information. See Policy Statement 11-13, IRM 1.2.19.1.1 (4/23/2004).

3. The Office of Chief Counsel has considered the institutional interests implicated by the disclosure of the following four categories of documents (paragraphs 4-7 below) and has determined that discretionary privileges and FOIA exemptions are to be asserted in accordance with the procedures described below, except in extraordinary circumstances after consultation and coordination with the affected Associate Chief Counsel or Area Counsel office.

4. **Documents pertaining to published guidance.** Discretionary discovery privileges or FOIA exemptions will be asserted for documents pertaining to published guidance. Published guidance includes regulations, revenue rulings, revenue procedures, notices, and announcements that are disclosed to the public by publication in the Federal Register or the Internal Revenue Bulletin. See 5 U.S.C. § 552(a)(1) and (2).

5. **Documents pertaining to statements of agency policy and interpretations adopted by the agency, administrative staff manuals, and instructions to staff within the meaning of FOIA, 5 U.S.C. § 552(a)(2)(B) and (C), including written determinations under section 6110.** The discretionary exemptions or privileges will be asserted for documents that are generated during the preparation of any statements of agency policy (including written determinations subjects to section 6110), and interpretations adopted by the agency, administrative staff manuals, and instructions to staff within the meaning of FOIA, 5 U.S.C. § 552(a)(2)(B) and (C).



1. Written determinations subject to the disclosure requirements of section 6110 are Private Letter Rulings, Technical Advice Memoranda, Chief Counsel Advice, and Determination Letters.

2. Other statements of agency policy and interpretations within the Office of Chief Counsel include Actions on Decisions, General Counsel Memoranda, and field-authored advice reviewed in the National Office.

3. Administrative staff manuals and instructions to staff within the Office of Chief Counsel include the Chief Counsel Directives Manual and Chief Counsel Notices.

4. Examples of privileged documents may include memoranda weighing reasons for and against the proposed policy, drafts, or meeting notes that reflect the exchange of opinions between agency personnel on the matter being considered.


6. **Documents pertaining to litigation.** The decision to release information contained in this group of documents will be made after full consideration of the appropriate factors. The decision to waive the exemption or privilege will be documented in writing and approved by the designated level of authority, as set forth below. Documents pertaining to litigation include documents prepared by Counsel attorneys as well as documents maintained in the administrative files of the IRS to which the litigation pertains. The procedural requirements to elevate and coordinate are triggered only in those cases when waiver of the discretionary privileges or FOIA exemptions is recommended. Because the FOIA can be used as a discovery tool, Counsel employees will coordinate their responses in discovery with IRS personnel processing FOIA requests seeking the same documents or information. Counsel employees should consider the impact of the assertion or waiver of discretionary privileges on their own pending cases, on other pending cases, or future cases.



1. **Cases governed by Significant Case Procedures or Cases included in the Treasury Significant Litigation Report.** The decision to waive any applicable discretionary privileges or FOIA exemptions for documents pertaining to these cases may be waived only by the Division Counsel Headquarters Office, in consultation with the affected Associate Chief Counsel office.

2. **Cases in litigation that involve an issue for which the Office of Chief Counsel requires coordination with the National Office.**Discretionary discovery privileges or FOIA exemptions for documents pertaining to these cases may be waived only by the Associate Area Counsel in coordination with the affected Associate Chief Counsel office.

3. **Cases in litigation handled by the Associate Chief Counsel.**Discretionary discovery privileges or FOIA exemptions for documents pertaining to these cases may be waived only by the Associate Chief Counsel.

4. **All other cases in litigation.**Discretionary discovery privileges or FOIA exemptions for documents pertaining to these cases may be waived only by the Associate Area Counsel.


7. **Documents pertaining to nondocketed legal advice.**Discretionary discovery privileges or FOIA exemptions for documents pertaining to these matters may be waived only by the Associate Area Counsel in consultation with the affected IRS client at the supervisory level.


**30.11.1.9** **(08-09-2018)**

### Response to Disclosure Office

1. **National Office**. After reviewing the requested records, the Chief, DLS, will transmit to the Disclosure Office one clean set and one redacted set of the requested records and set forth in a separate memorandum the recommendations of the Office of Chief Counsel concerning disclosure of those records. DLS will also forward the search questionnaire completed by the Counsel office(s) to the Disclosure Office.

2. **Area Counsel or Associate Area Counsel Office** — After reviewing the records, the attorney will transmit one clean set and one redacted set of the requested records and set forth the recommendations of the Area or Associate Area Counsel Office concerning disclosure of those records. The attorney will also forward the search questionnaire completed by the Counsel office to the Disclosure Office.

3. Once the memorandum is sent to the Disclosure Office, the TECHMIS case will be closed.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part30/irm_30-011-001#addtoany "Show all")

A2A