---
url: "https://www.irs.gov/irm/part34/irm_34-009-001"
title: "34.9.1 Disclosure, Testimony, and Production of Documents | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part34/irm_34-009-001#main-content)

- 34.9.1  [Disclosure, Testimony, and Production of Documents](https://www.irs.gov/irm/part34/irm_34-009-001#idm139917084125200)
  - 34.9.1.1  [Testimony Authorizations](https://www.irs.gov/irm/part34/irm_34-009-001#idm139917113050064)
  - 34.9.1.2  [Definitions](https://www.irs.gov/irm/part34/irm_34-009-001#idm139917113100960)
  - 34.9.1.3  [Requests and Demands for Testimony, Responses to Interrogatories, and Production of Documents](https://www.irs.gov/irm/part34/irm_34-009-001#idm139917113082304)
    - 34.9.1.3.1  [Requests or Demands by any Party (including other Government agencies) in a Non-IRS Matter](https://www.irs.gov/irm/part34/irm_34-009-001#idm139917113065152)
  - 34.9.1.4  [Preparation and Approval of Testimony and Production Authorizations](https://www.irs.gov/irm/part34/irm_34-009-001#idm139917085623408)
    - 34.9.1.4.1  [Requests Requiring Additional Authorization](https://www.irs.gov/irm/part34/irm_34-009-001#idm139917085589184)
  - 34.9.1.5  [Technical Assistance](https://www.irs.gov/irm/part34/irm_34-009-001#idm139917085577232)

# Part 34. Chief Counsel Directives Manual Litigation in District Court, Bankruptcy Court, Court of Federal Claims, and State Court

# Chapter 9. Disclosure, Testimony, and Production of Documents

# Section 1. Disclosure, Testimony, and Production of Documents

* * *

## 34.9.1 Disclosure, Testimony, and Production of Documents

#### Manual Transmittal

June 25, 2021

#### Purpose

(1) This transmits revised CCDM 34.9.1, Litigation in District Court, Bankruptcy Court, Court of Federal Claims, and State Court; Disclosure, Testimony, and Production of Documents.

#### Background

CCDM 34.9.1.4 is revised to provide current policies and procedures relating to the approval of requests for testimony of Office of Chief Counsel attorneys.

#### Material Changes

(1) CCDM 34.9.1.4 is revised to require that in addition to the authorization required by Delegation Order No. 11-2, any subpoena or request for deposition or trial testimony of a Chief Counsel attorney with respect to their official duties or activities must be approved by the Associate Chief Counsel (Procedure and Administration) and brought to the attention of the Deputy Chief Counsel (Operations) after coordination with the Associate Chief Counsel having subject-matter jurisdiction over the issues in the case.

#### Effect on Other Documents

CCDM 34.9.1 dated May 3, 2013 is superseded.

#### Audience

Chief Counsel

#### Effective Date

(06-25-2021)

Richard G. Goldman

Deputy Associate Chief Counsel

(Procedure and Administration)

**34.9.1.1** **(05-03-2013)**

### Testimony Authorizations

1. These procedures provide instructions for the preparation or review of the agency’s responses to requests and demands for testimony and production of internal revenue records or information in "IRS matters," "non-IRS matters," and "IRS congressional matters." IRM 11.3.35, Requests and Demands for Testimony and Production of Documents, provides detailed instructions and procedures for IRS employees concerning authorization of testimony and the production of documents. Specifically:



1. _IRS matters_. When testimony or document production is sought in an IRS matter by a party to the litigation other than the government ( _e.g._, the defendant in a criminal tax case, a petitioner in a U.S. Tax Court case, the plaintiff in a refund litigation case, or the plaintiff in a Federal Tort Claims Act case), the attorney primarily assigned to the litigation is responsible for preparing the proposed authorization and submitting it for approval.

2. _Non-IRS matters_. When testimony or document production is sought in a non-IRS matter, the IRS Disclosure Office is responsible for preparing the proposed authorization and submitting it for approval. IRM 11.3.35.7, Procedures in Non-IRS Matters. See IRM 11.3.35.5, Requests Requiring Headquarters Authorization, for further guidance as to requests requiring IRS headquarters authorization or additional coordination. IRS officials charged with preparing or authorizing testimony or document production are instructed to coordinate with the appropriate Counsel office before acting. IRM 11.3.35.4(5), Requests Authorized by Field Officials.

3. _IRS congressional matters_. When testimony or document production is sought in an IRS congressional matter, the Office of Legislative Affairs is to be contacted for further instruction. These authorizations must also be cleared through the Associate Chief Counsel (Procedure & Administration). IRM 11.3.35.5(3), Requests Requiring Headquarters Authorization.


2. **Authority**. Under the General Housekeeping Statute, 5 U.S.C. 301, heads of executive or military departments may prescribe regulations for, among other things, the custody, use, and preservation of their records, papers, and property. Many departments and agencies, including the IRS, have promulgated regulations under this statute for the disclosure of their official records and information. Generally, these are termed Touhy regulations, after the Supreme Court’s decision in United States ex rel. Touhy v. Regan, 340 U.S. 462 (1951). In Touhy, the Supreme Court held that an agency employee could not be held in contempt for refusing to disclose agency records or information when following the instructions of his or her supervisor regarding the disclosure.



1. The IRS’s Touhy regulations concerning the production of written records by, and the oral testimony of, its current and former officers, employees and contractors are found at Treas. Reg. §§ 301.9000-1 to 301.9000-7. These regulations require, with limited exceptions, current and former IRS officers, employees, and contractors to obtain prior approval before they may produce IRS records or information or testify in judicial or administrative proceedings or in congressional matters in response to a request or demand for testimony or production of documents.

2. Delegation Order No. 11-2 sets forth the IRS and Chief Counsel officials who may authorize testimony or disclosure of IRS records or information in response to requests or demands for such information.

3. Exhibit 1.2.2-2, Delegation Order 11-2 Reference Chart , contains tables referencing various testimony and production scenarios and those responsible for the preparation and review of the testimony authorizations.

4. The scope of the authorization will be restricted in accordance with applicable disclosure laws ( _e.g._, IRC §§ 6103, 6104, 6105, 6110, 4424 and the Privacy Act, 5 U.S.C. 552a).

5. Without a written authorization, a current or former IRS officer, employee, or contractor may appear at the court, administrative agency or other authority, or to the Congress (including a committee or subcommittee) in person to advise that he or she is awaiting instructions from an authorizing official with respect to the request or demand for testimony or production of documents. Treas. Reg. § 301.9000-3(a).


3. There are a few exceptions when authorization is not required to testify or disclose IRS records or information to any court or governmental agency, or to the Congress (including a committee or subcommittee). Treas. Reg. § 301.9000-3(b). These exceptions are:



1. To respond to a request or demand by the attorney (or other government representative) who is representing the IRS in a particular IRS matter. Treas. Reg. § 301.9000-3(b)(1);

2. To respond only in writing, under the direction of the attorney or other government representative who is representing the IRS in a particular IRS matter, to a request or demand, including, but not limited to, admissions, document production, and written interrogatories. Treas. Reg. § 301.9000-3(b)(2);



      ### Note:



      This includes cases referred by or on behalf of the IRS to the Department of Justice (including an office of an U.S. Attorney) for defense, prosecution, or affirmative action, including but not limited to criminal tax cases, refund litigation cases, promoter injunction cases, wrongful collection actions, summons enforcement cases, bankruptcy cases, Federal tort claims, Bivens actions, Freedom of Information and Privacy Act litigation, and actions affecting the personnel rights of current and former IRS employees. Treas. Reg. § 301.9000-6, Example 5; IRM 11.3.35.6(3), Procedures in IRS Matter Cases.

3. To respond to a request or demand for expert or opinion testimony, issued to a former IRS officer, employee, or contractor, when the testimony sought involves general knowledge (such as information contained in published procedures of the IRS or Office of Chief Counsel) gained while the former officer, employee, or contractor was employed or under contract, respectively. Treas. Reg. § 301.9000-3(b)(3); or

4. When the testimony or production of IRS records or information is accomplished in accordance with an existing, more specific IRS procedure. Treas. Reg. § 301.9000-3(b)(4). These procedures include, but are not limited to, requests under the Freedom of Information Act or Privacy Act, requests for certain IRS records under 26 C.F.R. § 601.702(d) (e.g. tax returns and transcripts of accounts, approved applications for tax exemption under section 6104, public comments to published guidance), disclosures to state tax agencies under section 6103(d), and disclosures to the Department of Justice (DOJ) pursuant to an ex parte order under section 6103(i)(1).


**34.9.1.2** **(05-03-2013)**

### Definitions

01. "IRS records or information" means "any material (including copies thereof) contained in the files (including paper, electronic, or other media files) of the IRS, any information relating to material contained in the files of the IRS, or any information acquired by an IRS officer or employee, while an IRS officer or employee , as part of the performance of official duties or because of that IRS officer’s or employee’s official status with respect to the administration of the internal revenue laws or any other laws administered by or concerning the IRS." Treas. Reg. § 301.9000-1(a).



    1. IRS records or information includes, but is not limited to, returns and return information as those terms are defined in IRC § 6103(b), tax convention information as defined in IRC § 6105, information gathered during Bank Secrecy Act and money laundering investigations, leave, payroll, and other personnel records, management records and reports, and statistical records. This term also includes Office of Personnel Management records, Equal Employment Opportunity Commission records, Office of Government Ethics records, and Department of Labor records that are in the custody of the IRS.

    2. IRS records or information also includes information received, generated or collected by an IRS contractor pursuant to the contractor’s contract or other agreement with the IRS.

    3. The term does not include records or information obtained by IRS officers and employees solely for the purpose of a Federal grand jury investigation while under the direction and control of U.S. Attorney’s Office. The term does, however, include records or information obtained by IRS before, during or after a Federal grand jury investigation if the records or information are obtained at the administrative stage of a criminal investigation, from IRS files such as transcripts or tax returns, or for use in a subsequent civil investigation.


### Note:

When a discovery request or demand for production of documents received by the IRS includes any documents received from or created by the IRS in response to a congressional committee inquiry, the congressional committee will be notified of the request or demand. Any response to the discovery request or demand should be coordinated with the congressional committee. Field Disclosure or Counsel personnel who receive such requests or demands for testimony or document production are to contact the Chief, Disclosure in HQ for non-IRS matters and Branches 6 or 7 of the Office of the Associate Chief Counsel (Procedure & Administration) for IRS matters, respectively, who, in conjunction with the IRS Legislative Affairs Division, will coordinate with the appropriate congressional committee.

02. "IRS officers and employees" means all officers and employees of the United States appointed by, employed by, or subject to the directions, instructions or orders of the Commissioner or IRS Chief Counsel and also includes former officers and employees. Treas. Reg. § 301.9000-1(b).

03. "IRS contractor" means any person, including the person’s current and former employees, maintaining IRS records or information pursuant to a contract or agreement with the IRS, and also includes former contractors. Treas. Reg. § 301.9000-1(c).

04. A "request" is "any request for testimony of an IRS officer, employee or contractor or for the production of IRS records or information, oral or written, by any person, which is not a demand." Treas. Reg. § 301.9000-1(d).

05. A "demand" is "any subpoena, or other order, of any court, administrative agency or other authority or the Congress, or a committee or subcommittee of the Congress, and any notice of deposition (either upon oral examination or written questions), request for admissions, request for production of documents or things, written interrogatories to parties, or other notice of, request for, or service for discovery in a matter before any court, administrative agency, or other authority." Treas. Reg. § 301.9000-1(e).

06. An "IRS matter" is any matter before any court, administrative agency or other authority in which the United States, the Commissioner, the IRS (including the Office of Chief Counsel), or any IRS officer or employee (including an officer or employee of the Office of Chief Counsel) acting either in an official capacity, or in his or her individual capacity if DOJ or the IRS has agreed to represent or provide representation to the IRS officer of employee, is a party and that is directly related to official business of the IRS or to any law administered by or concerning the IRS, including, but not limited to, judicial and administrative proceedings described in sections 6103(h)(4) and (l)(4). Treas. Reg. § 301.9000-1(f).

07. An "IRS congressional matter" is any matter before the Congress, or a committee or subcommittee of the Congress, which is related to the administration of the internal revenue laws or other laws administered by or concerning the IRS, or to IRS records or information. Treas. Reg. § 301.9000-1(g).

08. A "non-IRS matter" is any matter that is neither an IRS matter nor an IRS congressional matter. Treas. Reg. § 301.9000-1(h).

09. A "testimony authorization" is a written instruction or oral instruction memorialized in writing within a reasonable period by an authorizing official that sets forth the scope of and limitations on proposed testimony and/or disclosure of IRS records or information issued in response to a request or demand for IRS records or information. A testimony authorization may grant or deny authorization to testify or disclose IRS records or information and may make an authorization effective only upon the occurrence of a precedent condition, such as the receipt of a taxpayer consent complying with IRC § 6103(c). Treas. Reg. § 301.9000-1(i).

10. An "authorizing official" is a person with delegated authority to authorize testimony or the disclosure of IRS records or information. Treas. Reg. § 301.9000-1(j).


**34.9.1.3** **(05-03-2013)**

### Requests and Demands for Testimony, Responses to Interrogatories, and Production of Documents

1. _Requests for Answers, Records, or Testimony in Actions Pertaining to Tax Administration_. No authorization is needed when testimony or production of documents is requested by Chief Counsel attorneys in a Tax Court case or by U.S. Attorneys or Department of Justice attorneys (including offices of an U.S. Attorney) for use in cases that arise under the internal revenue laws or related statutes and that have been referred by the IRS to the Department of Justice for prosecution or defense. Treas. Reg. § 301.9000-3(b)(1); IRM 11.3.35.6(3), Procedures in IRS Matter Cases.

2. _Requests by a Non-Government Party for Answers to Written Interrogatories or Written Production of Documents in IRS Matters._ The procedures set forth in Treas. Reg. § 301.9000-4 do not apply to the answering of written interrogatories served in connection with Tax Court cases or cases referred by or on behalf of the IRS to the Department of Justice or Office or offices of a U.S. Attorney for defense, prosecution or other affirmative action. IRM 11.3.35.3(8), Definitions. Additionally, those procedures do not apply to petitioner’s notices to produce documents in the Tax Court or document production requests in cases referred by or on behalf of the IRS to the Department of Justice (including offices of an U.S. Attorney for defense, prosecution or affirmative action, unless such production is called for together with the testimony of an employee or contractor. Treas. Reg. § 301.9000-3(b)(2); IRM 11.3.35.6(4), Procedures in IRS Matter Cases.

3. _Demands by a Non-Government Party for Testimony or Production of Documents in IRS Matters_. Subpoenas requiring an IRS officer, employee, or contractor to provide testimony or produce documents directly, rather than through government counsel, in an IRS matter require authorization. Treas. Reg. § 301.9000-3(a); IRM 11.3.35.6(4), Procedures in IRS Matter Cases.

4. _Requests or Demands for Testimony or Production of Documents from Former Employees and Contractors_. Except when the testimony being sought involves general knowledge (such as information contained in published procedures of the IRS or Office of Chief Counsel) gained while employed or under contract, former employees and contractors who receive a request or demand for IRS records or information (including the production of any records former employees or contractors may have taken with them upon their departure from the IRS or Office of Chief Counsel) must receive authorization to disclose such information. Treas. Reg. § 301.9000-3(b)(3).

5. _Demands by Opposing Counsel for Grand Jury Information_. Disclosure of information or records obtained by an employee solely for the purpose of a federal grand jury investigation, while under the direction and control of the U.S. Attorney is not IRS records or information and therefore not subject to the IRS procedures on requests for disclosure found in the IRS’s Touhy regulations. Treas. Reg. § 301.9000-1(a); IRM 11.3.35.9, Grand Jury Data.



1. Employees receiving subpoenas from opposing counsel regarding grand jury information obtained by an employee solely for the purpose of a federal grand jury investigation while under the direction and control of the U.S. Attorney’s Office in a grand jury investigation should request guidance from the Department of Justice (usually the Assistant U.S. Attorney assigned to the grand jury investigation) to obtain any direction necessary pursuant to Fed. Crim. Proc. Rule 6(e), which limits disclosure of matters occurring before a grand jury. IRM 11.3.35.9(2), Grand Jury Data. The Counsel attorney handling the subpoena or request should contact the Area Counsel (Criminal Tax) for coordination or assistance.

2. Testimony sought by opposing counsel regarding information obtained during the administrative stage of a criminal investigation that is later referred to a grand jury requires authorization pursuant to Treas. Reg. § 301.9000-3, because the employee in that early stage of the investigation is performing official duties on behalf of the IRS or because of the employee’s official status with respect to the administration of the internal revenue laws or any other laws administered by or concerning the IRS. See Treas. Reg. § 301.9000-6, Example 4. The Counsel attorney handling the subpoena or request should contact the Area Counsel (Criminal Tax) for coordination or assistance.

3. Testimony sought by opposing counsel with regard to returns or return information, obtained by a grand jury pursuant to IRC 6103(h)(2), requires authorization pursuant to Treas. Reg. § 301.9000-1. Returns and return information retain their status as such even when turned over to a grand jury.


6. _Requests for Information or Testimony Received from a Foreign Government_. Foreign government requests for testimony or production of records from an IRS or Chief Counsel employee must be approved by the Director, Competent Authority and International Coordination (within IRS' Large Business and International business unit) and Branch 7 the Office of the Associate Chief Counsel (International).


**34.9.1.3.1** **(05-03-2013)**

#### Requests or Demands by any Party (including other Government agencies) in a Non-IRS Matter

1. A request or demand for IRS records or information for use in a non-IRS matter must be accompanied by a written statement made by or on behalf of any party seeking the testimony or disclosure of IRS records or information. Treas. Reg. § 301.9000-5(a). IRC 6103 generally bars the disclosure of tax records in such matters.

2. The written statement must set forth:



1. A brief description of the parties to, and the subject matter of, the proceeding and the issues

2. A summary of the testimony, IRS records or information sought, the relevance to the proceeding, and the estimated volume of IRS records involved

3. The time that will be required to present the testimony (on both direct and cross-examination)

4. Whether any of the IRS records or information is a return or return information, and the statutory authority for the disclosure of such return or return information (and, if no consent to disclose pursuant to IRC § 6103(c) accompanies the request or demand, the reason such consent is not necessary)

5. Whether a declaration by an IRS officer, employee, or contractor under penalties of perjury pursuant to 28 U.S.C. § 1746 would suffice in lieu of deposition or trial testimony

6. Whether deposition or trial testimony is necessary in a situation in which IRS records or information may be authenticated under applicable rules of evidence and procedure

7. Whether IRS records or information are available from other sources

8. A statement that the request or demand allows a reasonable time (generally, at least fifteen business days) for compliance


       Treas. Reg. § 301.9000-5(a)


3. Failure to provide the written statement may result in the IRS’s opposition to the demand. The requirement of a written statement may be waived by the authorizing official for good cause. Treas. Reg. § 301.9000-5(b).

4. Any Area or Associate Chief Counsel employee who receives or is notified of a court order or court issued subpoena requiring the disclosure of return or return information in a non-IRS matter should contact Branches 6 or 7 of the Office of Associate Chief Counsel (Procedure & Administration) promptly for assistance.

5. The Area or Associate Chief Counsel employee that receives a demand (including an attorney-issued subpoena) should contact the attorney for the party responsible for the subpoena, explain that IRC 6103 prohibits the disclosure of returns or return information, and ask that the subpoena be withdrawn.

6. The Area or Associate Chief Counsel employee should memorialize the conversation, including the specific reason for refusal, _e.g._, that IRC 6103 prohibits the disclosure, and copy the local U.S. Attorney on the letter.

7. If the party attempts to enforce the subpoena, the Area or Associate Chief Counsel employee should request the local U.S. Attorney to defend the IRS against the party’s motion to compel.

8. Personnel who appear in non-IRS matters must provide feedback to the Disclosure Office regarding the nature of the testimony given and the documents produced. Feedback may be given in oral or written format. IRM 11.3.35.15(3), Briefing the Employee Who Will Testify.


**34.9.1.4** **(06-25-2021)**

### Preparation and Approval of Testimony and Production Authorizations

1. **Authorizations Per Delegation Order No. 11–2**. Delegation Order No. 11–2, Authority to Permit Disclosure of Tax Information and to Permit Testimony or the Production of Documents, identifies the IRS and Chief Counsel officials who may authorize (or deny) disclosures of returns and return information that are confidential pursuant to IRC 6103, but which may nonetheless be disclosed pursuant to an exception as provided by the Internal Revenue Code.

2. **Delegation Order No. 11–2 Tables** . In Delegation Order No. 11–2 there are tables that specify the judicial or administrative proceedings that do or do not require testimony authorizations. The tables also identify IRS and Chief Counsel officials who may authorize or deny testimony and production of documents when requested or demanded by any subpoena, notice of oral deposition, or other order of a court, administrative agency, or other authority, pursuant to Treas. Reg. § 301.9000-3. Chief Counsel employees may be contacted by IRS and Counsel employees who have received requests and demands for testimony or records and should refer to the Treasury Regulations and the Testimony Authorization tables mentioned above, for guidance on how to assist those employees.



1. Table 1 of Delegation Order No. 11-2 covers testimony authorizations in U.S. Tax Court proceedings. In Tax Court cases, no testimony authorization is required when testimony or production of documents is requested on behalf of the Commissioner. When testimony or production of documents is requested on behalf of the petitioner, the Chief Counsel attorney assigned to the matter is responsible for preparing the testimony authorization. The Area Counsel for the Chief Counsel attorney assigned to the matter is the authorizing official. Delegation Order No. 11-2, Table 1.

2. Table 2 of Delegation Order No. 11-2 covers testimony authorizations in cases referred by or on behalf of the IRS to the Department of Justice (including an office of an U.S. Attorney) for defense, prosecution or other affirmative action, when the U.S. government is a party and is represented by DOJ in refund, collection, summons, and FBAR litigation; U.S. Bankruptcy, U.S. Court of Federal Claims, and State Court Collection Litigation; U.S. District Court Criminal Tax prosecution; and U.S. District Court Disclosure, Privacy Act, and FOIA litigation. No testimony authorization is required when testimony or production of records is requested by the government. The Chief Counsel attorney assigned to the matter is responsible for preparing the testimony authorization and his or her Area Counsel or Associate Chief Counsel is the authorizing official. Delegation Order No. 11-2, Table 2.

3. Table 3 of Delegation Order No. 11-2 covers testimony authorizations in cases referred by or on behalf of the IRS to the Department of Justice (including an office of an U.S. Attorney) for defense, prosecution, or other affirmative action, in IRS matters that involve Personnel, Labor Relations, Procurement, Bivens, and FTCA. No testimony authorization is required when testimony or production of records is requested by the government. The General Legal Services (GLS) attorney assigned to the matter is responsible for preparing the testimony authorization. The Deputy Associate Chief Counsel (GLS) or the Area Counsel (GLS) with the concurrence of the Associate Chief Counsel (GLS) or Deputy Associate Chief Counsel (GLS) are the authorizing officials. Delegation Order No. 11-2, Table 3.

4. Table 4 of Delegation Order No. 11-2 covers testimony authorizations in judicial and administrative proceedings in a non-IRS matter and testimony or production of records is sought from a Headquarters employee or function. The Chief, Disclosure is the authorizing official. A headquarters Privacy, Government Liaison, and Disclosure (PGLD) caseworker prepares the authorization and it is reviewed by Branches 6 or 7 of Procedure and Administration. Delegation Order No. 11-2, Table 4.

5. Table 5 of Delegation Order No. 11-2 covers testimony authorizations in judicial and administrative proceedings when the IRS is not a party and testimony or production of records is sought from someone other than a Headquarters employee or function. A Disclosure Manager prepares the authorization and it is reviewed by the liaison Area Counsel servicing the Disclosure Manager’s geographical location. The PGLD Area Manager is generally the authorizing official. Delegation Order No. 11-2, Table 5.

6. Table 6 of Delegation Order No. 11-2 covers testimony authorizations in non-IRS matters that involve Title 31, Bank Secrecy Act judicial and administrative proceedings when the IRS is not a party, but a Federal, State, or Local government is a party and expert testimony is sought from IRS employees maintaining this information. A HQ PGLD employee prepares the authorization and coordinates the authorization with the Small Business/Self-Employed (SB/SE) or Criminal Investigation (CI) Divisions as appropriate. It is reviewed by Branches 6 or 7 of Procedure and Administration. The Chief, Disclosure is the authorizing official. Delegation Order No. 11-2, Table 6.

7. Table 7 of Delegation Order No. 11-2 covers testimony authorizations in any matter involving requests by congressional committees for testimony or production of records from any IRS or Chief Counsel employee or function. Staff designated by the Director, Legislative Affairs will prepare the authorization. Depending on the matter, the Director, Legislative Affairs may designate a headquarters PGLD caseworker to prepare the authorization. The authorization is reviewed by Branches 6 or 7 of Procedure and Administration. The Deputy Commissioners are the authorizing officials for matters under their respective jurisdictions. The authority to authorize interviews (but not testimony) of IRS employees may be delegated to the Director, Legislative Affairs. Delegation Order No. 11-2, Table 7.


### Note:

Because of the inherently sensitive confidentiality and privilege issues presented by such testimony, in addition to the authorization required by Delegation Order No. 11-2, any testimony of a Chief Counsel attorney in response to a subpoena or request for deposition or trial testimony with respect to their official duties or activities must be approved by the Associate Chief Counsel (Procedure Administration) and brought to the attention of the Deputy Chief Counsel (Operations) after coordination with the Associate Chief Counsel having subject-matter jurisdiction over the issues in the case.

3. **Collecting the Necessary Information**. Generally, in preparing an authorization for a current or former IRS officer, employee, or contractor to testify or produce IRS records in response to a request or demand for testimony or production of documents, it will be necessary to ascertain the following facts in addition to the caption of the litigation, the nature of the litigation, and the court (or deposition) location:



01. The return date of the request or demand

02. The name, title, and post-of-duty of the current or former IRS officer, employee, or contractor upon whom the request or demand was served

03. On whose behalf and by whom the request or demand was served

04. The nature of the testimony or documents subject to the request or demand

05. Whether the request or demand would require the disclosure of information that would identify, or tend to identify, a confidential informant, tax treaty (convention) information protected under IRC § 6105, or would require the release of other sensitive or privileged information

06. In the case of tax information, whether the party requesting or demanding the information is entitled to it under any of the provisions of IRC § 6103

07. In the case of tax treaty (convention) information, whether the party requesting or demanding the information is entitled to it under IRC § 6105

08. Whether the request or demand would require the disclosure of information that would seriously impair federal tax administration

09. Whether there is an open civil or criminal tax investigation and, if so, the IRS function that has jurisdiction over the investigation

10. The availability or feasibility of producing the information or testimony sought; _i.e._ time limits and volume or format of documents


4. **Scope of the Testimony Authorization**. The determination of whether employees should be allowed to testify and what records or information, if any, may be disclosed must take into account applicable statutes, privileges, and constitutional requirements ( _e.g._ IRC §§ 6103, 6104, 6105, 6110, 4424, the Privacy Act, deliberative process privilege, attorney-client privilege, work product doctrine, etc.). Treas. Reg. § 301.9000-2.



1. In non-IRS matters, whether the burden on agency resources outweighs the possible benefit to the government should be considered in determining whether to authorize testimony. Generally, IRS resources should not be expended in private litigation. Requests for IRS expert testimony in private litigation will generally be denied. The local Disclosure Officer should offer alternate sources or methods for obtaining the requested records or information, to the extent practicable ( _e.g._, Freedom Of Information Act (FOIA) requests, Forms 4506, IRC §§ 6103(c) or (e) disclosures).


5. **Format of the Testimony Authorization.** In drafting testimony authorizations, it is important to consider the two purposes that such authorizations serve: to identify the scope and limitations of IRS records or information to be produced and to provide a basis upon which to decline to produce records or information either due to statutory proscriptions or privilege, or because they are that are outside the scope of the records or information deemed responsive to the request or demand..



### Note:



Sample testimony authorizations are located at Exhibit 34.12.1-32., Sample Testimony Authorization, and Exhibit 34.12.1-35, IRS Employee Testimony Authorization for FRCP 30(b)(6) Deposition.

6. **Response to Demands for Testimony or Documents Outside the Scope of the Testimony Authorization or Prior to Issuance of an Authorization**. An IRS employee faced with a court order to testify or produce records or information prior to receiving authorization should respectfully decline to testify. To the extent necessary, Disclosure or Counsel personnel or government counsel (usually an Assistant U.S. Attorney) should accompany the employee to explain the situation.



1. If an employee is faced with a court order to testify or produce records or information that is not authorized to be disclosed, the subpoenaed employee should appear and decline to respond with assistance and under the guidance of government counsel.

2. An employee should not be held in contempt of court for refusing to testify or disclose agency records or information in accordance with the terms of a testimony authorization or when awaiting instructions.

3. The authorizing official should consider coordinate with the Department of Justice (including an office of an U.S. Attorney) and the party requesting the testimony. This may result in the withdrawal of the subpoena or the filing of a motion to quash or a motion for a protective order. If an acceptable alternative is not reached, then the subpoenaed employee will appear and respectively decline to testify.


**34.9.1.4.1** **(05-03-2013)**

#### Requests Requiring Additional Authorization

1. In non-IRS matters, the following requests or demands for testimony or production of documents must be authorized by the Chief, Disclosure.



1. Requests made to IRS employees assigned to a Headquarters office, including employees of the Office of Chief Counsel assigned to an Associate or Division Counsel headquarters office

2. Requests in non-IRS matters that involve Title 31, Bank Secrecy Act judicial and administrative proceedings where the IRS is not a party, but a Federal, State, or Local government is a party and expert testimony is sought from IRS employees maintaining this information

3. Requests that may require a disclosure to a competent authority under a tax treaty pursuant to IRC § 6103(k)(4), or requests for information received by the IRS under a tax treaty, regardless of whether the information was previously disclosed pursuant to the treaty



      ### Note:



      Authorization will be provided in these cases only after the approval of the Deputy Commissioner, International (LB&I) is secured.

4. Requests made to IRS employees assigned to the Martinsburg, Tennessee, and Detroit Computing Centers

5. Employees appearing voluntarily or upon request before a state legislative body

6. Employees in Puerto Rico, Guam, the Virgin Islands, or other U.S. possessions or protectorates



      ### Note:



      Certain cases identified by the Chief, HQ Disclosure will be authorized by the Director, PGLD or at a higher management level because of their particular sensitivity.


2. The following requests or demands for testimony or production of documents must be authorized by the Commissioner, the appropriate Deputy Commissioner, or other delegated official in accordance with Delegation Order No. 11-2:



1. Requests for testimony made by a congressional committee (these requests should be immediately brought to the attention of the Office of Legislative Affairs)



      ### Note:



      Requests for interviews made by a congressional committee may be authorized by the Director, Legislative Affairs.

2. Requests involving disclosure to the President or certain other persons under IRC § 6103(g)

3. Requests involving disclosure to correct a misstatement of fact under IRC § 6103(k)(3)


3. These authorizations must be cleared though Branches 6 or 7 of the Office of the Associate Chief Counsel (Procedure and Administration).


**34.9.1.5** **(08-11-2004)**

### Technical Assistance

1. All requests for assistance concerning this section should be directed to the Office of the Associate Chief Counsel (Procedure & Administration).


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part34/irm_34-009-001#addtoany "Show all")

A2A