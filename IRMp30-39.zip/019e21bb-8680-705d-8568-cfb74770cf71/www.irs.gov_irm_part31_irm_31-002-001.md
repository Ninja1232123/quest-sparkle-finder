---
url: "https://www.irs.gov/irm/part31/irm_31-002-001"
title: "31.2.1 Significant Case Program | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part31/irm_31-002-001#main-content)

- 31.2.1  [Significant Case Program](https://www.irs.gov/irm/part31/irm_31-002-001#idm140684212568352)
  - 31.2.1.1  [Basic Principles of Significant Case Coordination](https://www.irs.gov/irm/part31/irm_31-002-001#idm140684212430512)
  - 31.2.1.2  [Definitions](https://www.irs.gov/irm/part31/irm_31-002-001#idm140684212424736)
  - 31.2.1.3  [Significant Cases Under Exam](https://www.irs.gov/irm/part31/irm_31-002-001#idm140684242258576)
  - 31.2.1.4  [Significant Cases Approaching Litigation](https://www.irs.gov/irm/part31/irm_31-002-001#idm140684242243568)
  - 31.2.1.5  [Docketed Significant Cases - Screening](https://www.irs.gov/irm/part31/irm_31-002-001#idm140684242236128)
  - 31.2.1.6  [Significant Case - National Coordination Procedures](https://www.irs.gov/irm/part31/irm_31-002-001#idm140684242225968)
  - 31.2.1.7  [Significant Case - National Project Coordination](https://www.irs.gov/irm/part31/irm_31-002-001#idm140684212395648)
  - 31.2.1.8  [Significant Cases - Division Coordination](https://www.irs.gov/irm/part31/irm_31-002-001#idm140684212376384)
  - 31.2.1.9  [Significant Cases - Department of Justice Cases Procedures](https://www.irs.gov/irm/part31/irm_31-002-001#idm140684212373408)
  - 31.2.1.10  [Significant Case Reports](https://www.irs.gov/irm/part31/irm_31-002-001#idm140684212367552)
  - Exhibit  31.2.1-1  [Significant Case Workplan](https://www.irs.gov/irm/part31/irm_31-002-001#idm140684212359632)

# Part 31. Chief Counsel Directives Manual Guiding Principles

# Chapter 2. Significant Case Coordination

# Section 1. Significant Case Program

* * *

## 31.2.1 Significant Case Program

#### Manual Transmittal

December 22, 2023

#### Purpose

(1) This transmits revised CCDM 31.2.1, Significant Case Program.

#### Background

CCDM 31.2.1 is being revised to provide new procedures for coordination of cases in the Significant Case Program.

#### Material Changes

(1) CCDM 31.2.1.1 was revised to remove discretion of executives to exclude any case that meets the definition of "Significant" from the Significant Case Coordination procedures and to explicitly require executive oversight of each case that is identified as "Significant."

(2) CCDM 31.2.1.2 was revised to clarify definitions and remove redundant explanations of terms explained elsewhere.

(3) CCDM 31.2.1.3 was revised to change the term "Nondocketed Significant Case" to "Significant Case Under Exam."

(4) CCDM 31.2.1.3 was revised to require concurrence of an executive, or a delegate authorized to speak for an Associate Chief Counsel or Deputy Associate Chief Counsel with regard to the Significant issue, of all advice provided by Associate offices; and by an executive or second-level reviewer of all advice provided by Field offices (other than routine Field advice) in all Nondocketed cases classified as "Significant."

(5) CCDM 31.2.1.3 and 4 were revised to explicitly require executive approval of the classification of Significant Cases Under Exam and Cases Approaching Litigation as "Significant."

(6) Screening procedures were updated to reflect uniformity across all Chief Counsel offices, and to increase threshold for mandatory screening of docketed case from $1M to $5M.

(7) CCDM 31.2.1.7 contains the procedures for National Project Coordination, including Project work plans and coordination of lead cases and other cases within the Project, which were formerly set forth as Exhibit 31.2.1-1.

(8) CCDM 31.2.1.10 assigns responsibility for Significant Case Reports to the Chief Counsel Finance and Management office or any successor unit performing similar functions.

(9) New Exhibit 31.2.1-1, Significant Case Workplan, was added; obsolete exhibits have been removed.

#### Effect on Other Documents

This section supersedes CCDM 31.2.1 dated August 11, 2004. We note that due to clerical oversight, the body of the CCDM section originally published on August 10, 2023 was the incorrect version and is being replaced by the corrected version. Additionally, due to clerical oversight the obsolete exhibits were not removed in the August 10, 2023 publication and are now being removed.

#### Audience

Office of Chief Counsel

#### Effective Date

(12-22-2023)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**31.2.1.1** **(12-22-2023)**

### Basic Principles of Significant Case Coordination

1. These Significant Case Coordination Procedures provide guidance for determining which cases in the Office of Chief Counsel meet the definition of “Significant,” as set forth below, and prescribe procedures for handling cases meeting the definition.

2. While all cases are important to the involved taxpayer and are essential to the nation’s overall tax system, certain cases individually or collectively have an identifiable, unusual, or unique impact on tax administration. Such cases, referred to in these procedures as “Significant Cases,” require a heightened level of coordination and oversight and demand a contribution of resources from both the field and National Office components of the Office of Chief Counsel in order to achieve the Office’s desired standards of consistency, accuracy, and timeliness. These procedures are intended to ensure that the necessary resources are available and are devoted to such cases to achieve these objectives.

3. All cases identified as Significant will be subject to a level of executive oversight greater than that accorded to cases not subject to these procedures, which remain subject to the general coordination and review procedures prescribed in the CCDM, such as those in sections 31.1 (Guiding Principles); 35.11.1-1 (Issues Requiring Associate Office Review); and 33.1 (Legal Advice).

4. Whether a case meets the definition of “Significant” as set forth in these procedures may change over the life of the case, due to emergence of additional facts, refined understanding of applicable law, revelations about the taxpayer’s position, new developments in the law, or other factors. Assuming Division Counsel and Associate Chief Counsel offices having jurisdiction over the case and issues involved concur, the case should be re-classified and handled according to its new classification.

5. It is anticipated that Division Counsel and Associate Chief Counsel offices will normally agree as to whether a case will be treated as a Significant Case and subject to the coordination procedures set forth herein. Existing reconciliation procedures should be used if the Division Counsel and the Associate Chief Counsel do not agree.


**31.2.1.2** **(12-22-2023)**

### Definitions

01. Significant Case. Includes any case described in one or more of the following categories:



    1. A case involving the validity of a statute or a regulation.

    2. A case involving an issue of importance to tax administration, such as a case of first impression; one involving the interpretation of a new statute or regulation when there are no reported opinions or when published guidance is pending; one affecting large numbers of taxpayers or an industry; or one falling within an operating division’s major strategic goal.

    3. A case likely to attract congressional or public attention on a national level.

    4. A case in which the government seeks to distinguish a position set forth in published guidance.

    5. A case involving an issue that has been designated for litigation or is under consideration for designation for litigation.

    6. A case involving an issue coordinated under a strategic compliance/coordination initiative; or

    7. A case involving a “Listed Transaction,” within the meaning of Treas. Reg. § 1.6011-4(b)(2), or a “Transaction of Interest” under Treas. Reg. § 1.6011-4(b)(6).


02. Case Approaching Litigation. A case in which a notice preceding court filing (e.g., statutory notice of deficiency or Notice of Final Partnership Adjustment (NFPA)) is being prepared, or a case likely to be litigated as a refund, bankruptcy, declaratory judgment, injunction, or summons enforcement case.

03. Division Counsel. One of the tax litigation business units of the Office of Chief Counsel. The term may be used to identify either the business unit or the executive who is the head of the business unit.

04. Associate Chief Counsel. One of the technical tax functions of the Office of Chief Counsel and the Associate Chief Counsel Procedure & Administration office. The term may be used to identify either the business unit or the executive who is the head of the business unit.

05. National Coordination Case. A Tax Court case determined to require high level and regular coordination between Division Counsel and at least one Associate Chief Counsel office.

06. National Project Coordination Case. A case that is part of a group of docketed tax shelter cases or any other group of similar or related cases that are determined collectively to be Significant and to require a high level of coordination, both between Division Counsel and Associate Chief Counsel offices and among Division Counsel offices. The group of cases is referred to as a "National Project."

07. Division Coordination Case. A Tax Court case classified as Significant and not requiring the level of coordination between Division Counsel and Associate Chief Counsel offices required for a National Coordination case.

08. Lead Attorney. The Office of Chief Counsel attorney with responsibility for development, litigation (if docketed in Tax Court), and resolution of the case. Generally, the Lead Attorney in a Significant Case is an attorney in a Division Counsel office.

09. Principal Associate Attorney. An attorney in an Associate Chief Counsel office who is responsible for coordinating Associate Chief Counsel participation in either a National Coordination Case or a National Project and who is expected to become knowledgeable about the case or Project as a whole. All Nationally Coordinated cases and National Projects will have an assigned Principal Associate Attorney, also known as the PAA.

10. Project Coordinator. The Project Coordinator is a Division Counsel attorney or manager assigned to a National Project with responsibility for developing, managing, coordinating, and controlling cases within the Project.


**31.2.1.3** **(12-22-2023)**

### Significant Cases Under Exam

1. Screening for Significant Cases Under Exam



1. Because of their day-to-day involvement in advising the IRS in cases under examination, attorneys and front-line managers in Division Counsel are uniquely situated to identify cases under examination that involve one or more issues of potential significance. Attorneys and front-line managers in the Associate Chief Counsel offices may also identify cases under examination of potential significance and should work with Division Counsel employees to ensure that such cases are evaluated and, if the criteria are met, classified as “Significant Cases Under Examination” and handled accordingly.

2. If an attorney and front-line manager identify a case as potentially meeting the criteria of a Significant Case, they should confer with the front-line manager’s executive management to determine whether the case should be classified as a Significant Case Under Examination. Consultation with the appropriate Associate Chief Counsel office should be undertaken, if it has not already occurred and agreement reached.

3. If the case is classified as a Significant Case Under Exam, the Lead Attorney and front-line manager are responsible for identifying the case as such in the Office of Chief Counsel’s time/inventory reporting system (e.g., applying the Nondocketed Significant Case Aspect Code (NSC) in TECHMIS).

4. If at any point the Division Counsel and Associate Chief Counsel offices do not agree on whether the case should be treated as significant, existing reconciliation procedures should be used as set forth in CCDM 31.1.4.6.


2. Coordination of Significant Cases Under Examination.



1. Once a case has been classified as a Significant Case Under Examination or subject to National Project Coordination, coordination between Division Counsel and Associate Chief Counsel with jurisdiction over the issue(s) that meets the criteria of Significant is required. The nature of the issue and the stage of development of the case will determine the type and level of coordination required. The appropriate coordination required for a particular Significant Case Under Examination or cases that are part of a National Project is a matter of judgment to be exercised by the executives with oversight of the casework in the Division Counsel and Associate Chief Counsel offices, as applicable. An example of cases that may not require Associate Chief Counsel office coordination are those involving an issue coordinated under a strategic compliance/coordination initiative in which the Service’s legal position is established.

2. Advice and work products on Significant Cases Under Examination are to be cleared at appropriate levels of management and with all concerned offices. To assure that appropriate coordination occurs:


       (i) Any written or oral communication within the Office of Chief Counsel related to the case should identify both the case as a Significant Case Under Examination and the Associate Chief Counsel office(s) with jurisdiction of the issue(s) that meet the criteria of Significant so that the proper level of review will be conducted.


       (ii) Before legal advice related to the issue that meets the criteria of Significant is provided by an Associate Chief Counsel office in a Significant Case Under Examination, the Associate Chief Counsel or a delegate who is an executive or a delegate authorized to speak for an Associate Chief Counsel or Deputy Associate Chief Counsel with regard to the significant issue in the Significant Case Under Examination should be made aware of and concur in the content of the proposed advice. Through this concurrence, the Office of Chief Counsel’s desired standards of consistency, accuracy, and timeliness will be achieved by ensuring that the Service’s legal position is being advanced throughout the life cycle of the Significant Case. However, for example, in a National Project, Associate Chief Counsel or delegate concurrence is not required in every case. Rather, in a National Project, it is required in the first instance that the legal position or analysis is communicated to the Division Counsel attorney. Further, because of the number of cases affected, the Associate Chief Counsel must concur with the legal position being taken in the first instance and when new issues or arguments are developed. If the Associate Chief Counsel has previously concurred with the legal analysis or position, additional concurrence is not required for other cases in the National Project.


       (iii) Other than advice on routine matters (e.g., in which the Service’s legal position is well-established), advice rendered by Division Counsel in a Significant Case Under Examination should be concurred in by a second-level reviewer or executive.


       (iv) Regular briefings of the IRS, Division Counsel and Associate Chief Counsel executives with responsibility for the case, or group of related cases, should occur, with a format and schedule as agreed to by the applicable executives. The Division Counsel office is responsible for scheduling and moderating the meeting, until such time as jurisdiction transfers to the Associate Office, such as during the appellate process.


3. Consideration may also be given to whether the case requires assistance from a Special Trial Attorney (STA).


**31.2.1.4** **(12-22-2023)**

### Significant Cases Approaching Litigation

1. Screening for Significant Cases Approaching Litigation



1. Division Counsel attorneys and front-line managers should regularly review their cases under examination to identify Significant Cases in which a notice preceding court filing (e.g., statutory notice of deficiency or Notice of Final Partnership Adjustment (NFPA)) is being prepared, or in which litigation is likely or imminent. It is important to identify when a case with an issue that meets Significant criteria is approaching litigation so that appropriate resources for trial preparation and trial can be identified. Often, this screening will involve re-classifying a Significant Case Under Examination to a Significant Case Approaching Litigation, as a means to notify all stakeholders that litigation is likely or imminent. Consideration should also be given to whether the case requires assistance from or assignment to a Special Trial Attorney. Cases that are subject to National Project Coordination procedures should be re-classified from Significant Case Under Examination to Significant Case Approaching Litigation by the National Project Management team, rather than through the procedures in this section.

2. If the front-line manager identifies such a case, the front-line manager should compile information essential for meaningful consideration of whether the case should be reported and treated as a Significant Case Approaching Litigation.

3. The front-line manager should convey the necessary information to the Division Counsel with jurisdiction over the case, or a delegate of the Division Counsel who is also an executive, for a determination whether the case should be treated as a Significant Case Approaching Litigation. Consultation with the Associate Chief Counsel office having jurisdiction over the issues of potential significance should occur if it has not already occurred and agreement reached. If the case has previously been classified as a Significant Case Under Examination, the Division Counsel or delegate should ensure that the relevant Associate Chief Counsel is aware that the case is approaching litigation. The Division Counsel and Associate Chief Counsel should ensure that the attorneys and managers assigned to the case are notified of the decision to classify a case as Significant Case Approaching Litigation so all stakeholders are aware that ligation is likely or imminent.

4. The Division Counsel office with jurisdiction over the case is responsible for identifying the case as a Significant Case Approaching Litigation in the Office of Chief Counsel’s time/inventory reporting system (e.g., applying the identifier for Significant Case Approaching Litigation (SCAL) in TECHMIS).


2. Coordination of Significant Cases Approaching Litigation. For those cases determined to be Significant Cases Approaching Litigation, responsible executives should ensure that appropriate coordination is occurring and that all affected components of the Office of Chief Counsel have been informed about the matter so that appropriate resources are marshaled in anticipation of docketing of the case. Procedures used for coordination of Significant Cases Under Examination should be used to the extent they have not previously been employed.


**31.2.1.5** **(12-22-2023)**

### Docketed Significant Cases - Screening

1. Screening of Tax Court Petitions. Tax Court petitions (including amended petitions) will be screened in the Associate Chief Counsel and Division Counsel offices as described in section 31.2.1.5(3). The primary purpose of such screening is to determine if the case should be classified as Significant, and if so, to determine whether the case should be subject to National, National Project, or Division coordination procedures.

2. Screening of Complaints. Complaints in refund cases initiated in the United States District Court or the Court of Federal Claims, bankruptcy cases involving the merits of a tax liability, declaratory judgment suits, and summons actions recommended for enforcement, will be screened in the Division Counsel and Associate Chief Counsel offices as described in section 31.2.1.5(3). The primary purpose of screening is to determine which of the complaints or recommended summons enforcement actions represent Significant Cases. Such classification is not intended to supersede the existing procedures for classifying a case as Standard or S.O.P. for purposes of referral to the Department of Justice. A case deemed Significant should be classified as “Standard.” However, not all Standard cases meet the definition of Significant Cases.

3. Screening Process. To ensure that issues in litigation meeting the criteria of Significant are appropriately identified, the Division Counsel attorney responsible for responding to a Tax Court petition (except one in which Small Tax Case procedures have been requested) or for a Complaint in a refund case will consider whether the case may meet Significant Case criteria as outlined in _CCDM 31.2.1.2_. Procedure and Administration’s Legal Processing Division (LPD) will send each Tax Court petition with an amount at issue totaling more than $5 million to the Associate Chief Counsel offices that LPD determines have subject matter implicated by an issue in the petition. Any Associate Chief Counsel attorney who reviews a Tax Court petition received from LPD or otherwise becomes aware of a Tax Court or refund case that may meet Significant Case criteria should contact the responsible Division Counsel attorney within fifteen days of receipt by the office of the petition or other information regarding the case, unless otherwise agreed for a particular case. For all Tax Court petitions and Complaints with amounts at issue totaling more than $5 million and for any case in which the Division Counsel attorney determines or is notified by an Associate Chief Counsel attorney that a case may meet Significant Case criteria, the Division Counsel attorney will follow the Division Counsel screening process to determine whether the case should be reported and treated as a Significant Case and subject to National or Division Coordination procedures. The Division Counsel attorney and the Associate attorney, and their respective managers should engage in informal discussion to evaluate the incoming case, whether the issue is Significant, and the appropriate level of coordination, with differences of opinion resolved through the reconciliation process.

4. The decision to classify a docketed case as Significant and to subject it to National, National Project, or Division Coordination procedures is made by the Division Counsel and Associate Chief Counsel offices with a stake in the case (e.g., the Associate Chief Counsel office with jurisdiction of the issue, the Division Counsel office who may assign the Lead Attorney to the case). Existing reconciliation procedures should be used if the Division Counsel and Associate Chief Counsel offices do not agree that the case should be classified as Significant or do not agree about the necessary coordination procedures to be used. Once a decision has been made, the responsible Division Counsel and Associate Chief Counsel should ensure that attorneys and managers assigned to the case are notified of the decision.

5. The Lead Attorney and front-line manager are responsible for identifying the case as a Significant Case subject to either National, National Project, or Division Coordination in the Office of Chief Counsel’s time/inventory reporting system (e.g., the Docketed Significant Case Aspect Code (DSC) in TECHMIS.


**31.2.1.6** **(12-22-2023)**

### Significant Case - National Coordination Procedures

1. In Significant docketed cases for which National Coordination is determined to be appropriate, there must be a continual, active working partnership between the Division Counsel and Associate Chief Counsel offices for the duration of the case, from initial case planning and development through pretrial practice, trial preparation, trial, submission of briefs, and appellate consideration. In such cases, every person and every office involved in the case is encouraged to make meaningful contributions during the entire litigation process. Executives in both the Division Counsel and Associate Chief Counsel offices must be directly engaged within the scope of their respective roles. As applicable within these roles, executives will be expected to participate in the development of substantive legal positions and decisions about litigation tactics and strategy, and to understand the positions taken in significant pleadings, motions, and briefs. Their involvement must go well beyond traditional notions of management review and oversight. Litigation decisions, such as whether to try or settle a case, whether to use alternative dispute resolution, or whether to employ an expert witness, should be made by the Division Counsel office after appropriate coordination with the Associate Chief Counsel office on the technical legal position.

2. Case assignments. Each Significant Case subject to National Coordination procedures will be assigned a Lead Attorney and a Principal Associate Attorney. In the field, the Lead Attorney is often assisted by a trial team of attorneys. While these assisting co-counsel may participate in coordination, the Lead Attorney is principally responsible for coordination. Normally, a single Principal Associate Attorney will be assigned. Additional attorneys in Associate Chief Counsel offices may also play a significant role in coordination, especially if the issue for which the case was coordinated has elements or ramifications beyond the jurisdiction of the Associate Chief Counsel office of the Principal Associate Attorney and the input of an additional Associate Chief Counsel office or offices is needed. When this occurs, the Lead Attorney should work through the PAA and it remains the responsibility of the PAA to identify and involve necessary colleagues within the National Office as required, including colleagues in other Associate Chief Counsel offices, and ensure the Lead Attorney is included in all necessary discussion and communication. If a case contains separate and distinct issues each of which merits National Coordination, each such issue would have a Principal Associate Attorney from the relevant Associate Chief Counsel office.

3. Litigation Workplan. The litigation workplan is the mechanism through which case planning, development, trial preparation, trial, briefing, and appeal consideration are memorialized, reviewed, and approved. The litigation workplan should be a comprehensive, objective summary of the case that takes into account both parties’ positions and realistically identifies risk as well as strengths in the government’s position. While frequent informal coordination is expected between Division Counsel and Associate Chief Counsel attorneys in cases subject to National Coordination, regular review and approval of the litigation workplan by the responsible executives assures that the substantive legal positions are being developed in accord with the Office of Chief Counsel’s legal position and litigation decisions are considered at the required level. Workplans in National Coordination cases will be prepared using a prescribed template. _See_ _Exhibit 31.2.1-1_.

4. Workplan Preparation. The Lead Attorney is responsible for the initial workplan and all updates, in consultation with the Principal Associate Attorney. The Principal Associate Attorney provides technical expertise to ensure that the legal positions in the workplan reflect the position of the Office of Chief Counsel. The workplan is a dynamic document that is revised periodically to reflect newly developed facts, refinements to the government’s legal position, responses to the taxpayer’s arguments, required case development, and other future actions by the trial team. After the initial workplan, updates may be prepared at any time, but must be made at least every six months. The Lead Attorney must bring to the attention of the Principal Associate Attorney any material changes of fact as the case is developed for trial. The Principal Associate Attorney must promptly notify the Lead Attorney of any changes in the position of the Office of Chief Counsel as to the legal issues set forth in the workplan.

5. Workplan Approval. The initial workplan will be due to the Division Counsel executive assigned responsibility for the case 45 days after the answer is filed if the case is determined to be subject to National Coordination at the time of the petition, or 45 days after the determination is made if it occurs later, unless the 45 day deadline is extended by the Division Counsel executive. The Division Counsel executive assigned responsibility for the case will approve the initial workplan and send it to the Principal Associate Attorney 60 days after the answer is filed or the determination for National Coordination occurs. The Principal Associate Attorney will review the workplan and forward it for concurrence on the technical position by the Associate Chief Counsel or a delegate who is an executive. If the concurrence of the Associate or delegate is subject to qualifications or comments, these should be discussed with the Lead Attorney and Division Counsel officials as necessary, prior to the Associate’s or delegate’s concurrence. The Associate’s concurrence will occur within 30 days after approval by the Division Counsel executive, with extensions permitted by mutual agreement. After the initial workplan is approved, subsequent proposed updated workplans will be prepared and reviewed by both the Division Counsel and the Associate Chief Counsel executives at least every six months. The Principal Associate Attorney is responsible for assuring that the Associate Chief Counsel’s approval of each individual workplan and update, along with any revisions agreed to by the Division Counsel and Associate Chief Counsel offices during the Associate Chief Counsel’s 30-day review period, is documented and timely transmitted to the Lead Attorney. The parties may agree to extend the deadline to review and approve updates to the workplan.

6. Resolution of Issues. The Issue Results Form is prepared to memorialize resolution of all National Coordination issues in a case. The form is part of the workplan template. See _Exhibit 31.2.1-1_.



1. The form will be prepared within 60 days of the date of the following events;


       (i) Settled issue: the earlier of the filing of the decision document or a stipulation of settled issues covering the coordinated issue.


       (ii) Tried issue (including dispositive motions) not appealed: the conclusion of the 90-day appeal period following entry of the Tax Court decision.


       (iii) Appealed issue: when the Tax Court decision becomes final.

2. Preparation, Review, and Approval. The Lead Attorney will prepare the Issue Results Form for settled or tried issues, consulting with the Principal Associate Attorney before finalizing. The Principal Associate Attorney will prepare the report for appealed issues, except that if the issue is remanded and not appealed after remand, the report will be prepared by the Lead Attorney. The report will be reviewed and approved by the appropriate Division Counsel executive responsible for the case and the Associate Chief Counsel executive responsible for the issue, or their respective delegates.


7. Retention of workplan. The Lead Attorney and the Principal Associate Attorney will retain the most recent, updated version of the workplan that has been agreed to by executives, including any comments of the Associate Chief Counsel office relative to the version proposed by Division Counsel on which approval was conditioned after consultation with the Division Counsel office and mutual agreement. The most recent workplan will be stored to be readily accessible by executives. Prior iterations of the workplan will be archived in an accessible location. The final workplan will be retained in the case legal file.


**31.2.1.7** **(12-22-2023)**

### Significant Case - National Project Coordination

1. National Projects. A National Project can contain only non-docketed cases, only docketed cases, or a mix of both. Due to the number of cases affected, National Projects typically are of importance to the Office of Chief Counsel and to executives at the highest levels. Besides the need for Division Counsel’s orderly management of the cases in the Project, sound legal positions developed by Division Counsel and Associate offices working together must be advanced consistently across the entire population of cases in the Project. As a Project evolves, new challenges are likely to emerge continually. There must be an active working partnership between the Division Counsel and Associate Chief Counsel offices for the duration of the Project to address a wide range of activities, including advice in non-docketed cases, test case selection, settlement strategies, pretrial development, trial, and briefing.

2. National Project Management. Each Project will have a Division Counsel executive who, along with the Project Coordinator and other assigned management officials, will define the parameters of the project. Each case within a Project will be assigned to a Division Counsel attorney or trial team; front-line management of each case will be determined based on the needs of the Project and case. At its inception, the Project will be assigned its own POSTSP ("Special Project-Post Filing") number in CASE-MIS and will be assigned a UIL (Uniform Issue List) number or other appropriate designation in any future case tracking system adopted by the Office of Chief Counsel. Each individual case in the Project should have this same UIL number or other issue identifier.

3. Project Workplans. Each group of National Project cases will have a Project workplan which will address all cases and activity in the Project overall in a collective manner. The "Project Coordinator" for the Project is responsible for timely preparing and updating of Project workplans, with assistance from assigned Division Counsel attorneys and the Principal Associate Attorney. Project workplans are subject to the same approval process as National Coordination Case workplans. All cases within the National Project will be handled consistently with the legal position and strategy set forth in the Project workplan and should follow processes and utilize resources identified by the Project Coordinator.



1. In the Project workplan, basic information about the Project will be provided and key persons involved with the Project will be identified. The Project workplan will reflect as "Related Cases" a list of all cases in the Project, identified through automation by means of the Project UIL or other identifying number. For each case in the Project, this will reflect the case name, case type, assigned attorney and organization, office, contact information, and status of the case.

2. For each issue involved in a typical case within the Project, the Project workplan will state the UIL Number applicable to the substantive issue, UIL description, tax periods in which the issue is present, an "Issue Description," a "Statement of Facts" setting forth the typical fact pattern for the issue for cases in the project, the "Government Position" including reference to all relevant published guidance, and the "Taxpayer Position" setting forth typical taxpayer arguments in this type of case to the extent these are known. Penalties will be handled as distinct issues, with specific discussions of the facts (including facts concerning approval of the penalty), government position, and taxpayer position relating to each penalty. As appropriate, the workplan can include cites to the Project's electronic case management site for further information.

3. After discussion of issues, the Project workplan will contain a "Status and Planning" section addressing:


       (i) The specific status of the Project overall, including the characteristics, status, and posture of particular cases or groupings of cases, plus information concerning any upcoming litigation of any case or cases in the Project, and


       (ii) Further strategy and plans for controlling, advancing, and disposing of the Project, including target dates. To complete and update this section, the Project Coordinator may have to secure information related to individual cases to supplement the Project Coordinator’s direct knowledge.

4. The front page of the Project workplan should include the following items, as applicable:


       (i) Project Name


       (ii) CASE-MIS POSTSP Number for the Project


       (iii) Project UIL Number


       (iv) Tax Years Involved


       (v) Project Coordinator - Name, Organization, Contact Information


       (vi) Key Counsel Contacts - Name, Organization, Contact Information


       (vii) Counsel Executive Team - Names, Organization, Contact Information


       (viii) Principal Associate Attorney - Name, Organization, Contact Information


       (ix) IRS Executive Team - Names, Organization, Contact Information


       (x) IRS Management Official - Name, Organization, Contact Information


       (xi) Other IRS Contacts - Names, Organization, Contact Information


       (xii) Appeals Contact - Name, Organization, Contact Information


       (xiii) Related Cases - Download from CASE-MIS all of the cases with the Project UIL number (may be included in an appendix if voluminous)


       (xiv) Key Promoters - Names, Names of promoter firm, Address of Key Individual


       (xv) Key Opposing Counsel - Names, Names of Firms, Addresses, Contact Information


4. Handling of Cases within the Project. Consistent with expectations in all casework, an attorney assigned a case within a Project is expected to responsibly develop or otherwise handle the attorney’s individual case, under the supervision of the assigned front-line manager. Attorney responsibilities include keeping the Project Coordinator informed consistent with directions prescribed by the Project Coordinator as to manner and frequency of reporting and information required. In addition to adhering to the Project workplan, attorneys and front-line managers assigned to cases in the Project should understand and follow all process guides and other resources identified by the Project Coordinator. The Project Coordinator must notify Division Counsel attorneys with cases in a Project of any changes in the position of the Office of Chief Counsel as to the legal issue(s) involved, or whether the status of a case will change to a National Coordination case. **See** (5) below.

5. Lead Case(s) for the Project. At some point in the life of the Project, the Project Coordinator, in coordination with other Project decision-makers, may identify a docketed case, or small number of docketed cases, in the Project that is likely to be the first case in the Project to be presented in court, i.e., the "lead docketed case" (or cases). This may be the first case that becomes docketed, or another case identified for its particular characteristics or other reasons. Since the handling of the lead docketed case (or cases) will have broad impact, once identified, it will be considered a National Coordination case under the Significant Case Procedures and will be subject to those procedures. Any such lead case (or cases) for the Project will be among the cases in the Project inventory list in the Project workplan and will be mentioned in the discussion of the overall status of the Project. Extensive discussion of the particulars of the lead docketed case is not required in the Project workplan as such specifics are available in the workplan for the lead case. All other cases in the Project that are not the lead docketed case (or cases) will be covered as part of the Project workplan. There may be circumstances where a case within a Project moves forward faster in litigation than the original lead case. In such circumstances, the faster moving case should become subject to National Coordination procedures, either in addition to or in lieu of the original lead case.


**31.2.1.8** **(12-22-2023)**

### Significant Cases - Division Coordination

1. Coordination. Coordination with the Associate Chief Counsel offices for Significant Cases subject to Division Coordination will be handled under the general Guidelines for Coordination set forth at CCDM 31.1.4.1, the provisions relating to legal advice at CCDM 33.1.1, and the Issues Requiring Associate Office Review at CCDM 35.11.1.1. Depending on the needs of the case and subject to agreement between the responsible Division Counsel and Associate Chief Counsel, an Associate Chief Counsel Attorney may be designated to work with the Lead Attorney over the life of the case.

2. Oversight. Executive oversight of cases subject to Division Coordination is provided by Division Counsel, or a delegate who is an executive. The responsible executive and structure of this oversight will be determined based on the needs of the case, as approved by the Division Counsel and memorialized in the case file.


**31.2.1.9** **(12-22-2023)**

### Significant Cases - Department of Justice Cases Procedures

1. General. Each Significant Case that is being handled by the Department of Justice will be assigned a Lead Attorney and Principal Associate Attorney, who may be assigned as Lead Attorney if the Significant issue is purely a question of law. The Lead Attorney and the Principal Associate Attorney are responsible for assuring an active working relationship with the Department of Justice on Significant Cases.

2. For Department of Justice cases classified as Significant, the Division Counsel office will designate a Lead Attorney to be primarily responsible for coordination with the Tax Division of the Department of Justice and the Associate Chief Counsel offices with jurisdiction over the issues, and for apprising Division Counsel management of developments, litigation strategy, and status updates. In certain cases, there may be Division Counsel attorneys assigned as Special Assistant United States Attorneys to handle aspects of the case.

3. The Lead Attorney prepares the defense, referral, or settlement letters to the Department of Justice, in coordination with the Principal Associate Attorney and other subject matter experts. In addition to review required by Division Counsel management when the Lead Attorney is a Division Counsel attorney, these letters are reviewed by the appropriate Associate Chief Counsel office(s) prior to delivery to the Department of Justice.

4. The Lead Attorney is responsible for remaining in close contact with the Department of Justice attorney assigned to the case as the case progresses in litigation. The Lead Attorney should be aware of the general status of the case, the key actions in case development, the overall litigation strategy, the milestones, and the timetables that are expected to apply. The Lead Attorney should also take responsibility for coordinating required action by the Office of Chief Counsel, such as clarification of office position on legal issues in the form of supplemental correspondence, assistance in the retention of expert witnesses, or assistance with further factual development. In certain Department of Justice cases classified as Significant, it may be appropriate for the Lead Attorney and the Principal Associate Attorney to use a workplan, or specific components of a workplan, to ensure close coordination within the Office of Chief Counsel on all aspects of the case.

5. Other Coordination Procedures Applicable to Bankruptcy Cases. The coordination procedures in this chapter supplement the large bankruptcy coordination procedures set forth in CCDM 34.3.1.3.


**31.2.1.10** **(12-22-2023)**

### Significant Case Reports

1. Reports on Significant Cases are an integral part of the Significant Case program as they enable the Chief Counsel, Deputy Chief Counsels and all appropriate Division Counsel and Associate Chief Counsel executives to monitor the Chief Counsel Significant Case program. The reports will contain the case status, issue(s), amount(s) at issue, tax year(s), statute of limitations for Significant Case under Examination, Lead Attorney, Principal Associate Attorney (if assigned), and Division Counsel and Associate Chief Counsel (if applicable) executive with oversight responsibility, as available in the Office of Chief Counsel time/inventory reporting system.

2. The Chief Counsel Finance and Management office, or any successor unit that provides support services to the Chief Counsel tax litigation business units, will generate the following reports using information reported in the Chief Counsel time reporting system:



1. Docketed Cases Screened. Following case screening as described herein, at least monthly, a report will be generated reflecting all petitions and complaints with amounts at issue of more than $5 million and reflecting the determinations of the Division Counsel and Associate Chief Counsel Offices, respectively, as to whether the case is Significant, and if Significant, whether subject to National Coordination, National Project Coordination, or Division Coordination.

2. Cases Under Examination Classified as Significant. Cases under examination classified as Significant and identified with the Nondocketed Significant Case Aspect Code (NSC) in TECHMIS (or other identifier in any successor case tracking system adopted by the Office of Chief Counsel) will be included on a bi-monthly report.

3. Cases Approaching Litigation Classified as Significant. Cases under examination classified as Significant and identified with the Significant Cases Approaching Litigation Aspect Code (SCAL) in TECHMIS (or other identifier in any successor case tracking system adopted by the Office of Chief Counsel) will be included on a bi-monthly report.

4. Significant Docketed Cases. Docketed cases classified as Significant and identified with an Aspect Code (SC) in TLCATS (or other identifier in any successor case tracking system adopted by the Office of Chief Counsel) and whether subjected to National Coordination, Project Coordination or Division Coordination procedures will be included on a bi-monthly report.

5. Significant Department of Justice Cases. Department of Justice cases classified as Significant and identified with the Significant Department of Justice case Aspect Code (SDOJ) in TECHMIS (or other identifier in any successor case tracking system adopted by the Office of Chief Counsel) will be included on a bi-monthly report.


3. Report Distribution. Within fifteen days of the end of the month, the Chief Counsel Finance and Management office (or any successor unit that provides support services to the Chief Counsel tax litigation business units) will distribute the applicable reports to the Chief Counsel, Deputy Chief Counsels, and all appropriate Associate office and Division Counsel executives.


**Exhibit 31.2.1-1**

### Significant Case Workplan

![This is an Image: 29422032.gif](https://www.irs.gov/pub/xml_bc/29422032.gif)

> Page 1 of the Significant case workplan form.

[Please click here for the text description of the image.](https://www.irs.gov/media/372501 "")

![This is an Image: 29422033.gif](https://www.irs.gov/pub/xml_bc/29422033.gif)

> Page 2 of the Significant case workplan form.

[Please click here for the text description of the image.](https://www.irs.gov/media/372506 "")

![This is an Image: 29422034.gif](https://www.irs.gov/pub/xml_bc/29422034.gif)

> Page 3 of the Significant case workplan form. Page 3 focuses on the issue summary.

[Please click here for the text description of the image.](https://www.irs.gov/media/372511 "")

![This is an Image: 29422035.gif](https://www.irs.gov/pub/xml_bc/29422035.gif)

> Page 4 of the Significant case workplan form. Page 4 focuses on the issue narratives.

[Please click here for the text description of the image.](https://www.irs.gov/media/372516 "")

![This is an Image: 29422036.gif](https://www.irs.gov/pub/xml_bc/29422036.gif)

> Page 5 of the Significant case workplan form. If there is a second issue, page 5 is designated for it.

[Please click here for the text description of the image.](https://www.irs.gov/media/372521 "")

![This is an Image: 29422037.gif](https://www.irs.gov/pub/xml_bc/29422037.gif)

> Page 6 of the Significant case workplan form. Page 6 is designated for the second issue’s narrative.

[Please click here for the text description of the image.](https://www.irs.gov/media/372526 "")

![This is an Image: 29422038.gif](https://www.irs.gov/pub/xml_bc/29422038.gif)

> Page 7 of the Significant case workplan form. If there is a third issue, page 7 is designated for it.

[Please click here for the text description of the image.](https://www.irs.gov/media/372531 "")

![This is an Image: 29422039.gif](https://www.irs.gov/pub/xml_bc/29422039.gif)

> Page 8 of the Significant case workplan form. Page 8 is designated for the third issue’s narrative.

[Please click here for the text description of the image.](https://www.irs.gov/media/372536 "")

![This is an Image: 29422040.gif](https://www.irs.gov/pub/xml_bc/29422040.gif)

> Page 9 of the Significant case workplan form. If there is a forth issue, page 9 is designated for it.

[Please click here for the text description of the image.](https://www.irs.gov/media/372541 "")

![This is an Image: 29422041.gif](https://www.irs.gov/pub/xml_bc/29422041.gif)

> Page 10 of the Significant case workplan form. Page 10 is designated for the fourth issue’s narrative.

[Please click here for the text description of the image.](https://www.irs.gov/media/372546 "")

![This is an Image: 29422042.gif](https://www.irs.gov/pub/xml_bc/29422042.gif)

> Page 11 of the Significant case workplan form. Page 11 is designated for the workplan summary.

[Please click here for the text description of the image.](https://www.irs.gov/media/372551 "")

![This is an Image: 29422043.gif](https://www.irs.gov/pub/xml_bc/29422043.gif)

> Page 12 of the Significant case workplan form. Page 12 is also designated towards workplan summary.

[Please click here for the text description of the image.](https://www.irs.gov/media/372556 "")

![This is an Image: 29422044.gif](https://www.irs.gov/pub/xml_bc/29422044.gif)

> Page 13 of the Significant case workplan form. Page 13 is designated for the issue results.

[Please click here for the text description of the image.](https://www.irs.gov/media/372561 "")

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part31/irm_31-002-001#addtoany "Show all")

A2A