---
url: "https://www.irs.gov/irm/part35/irm_35-003-005"
title: "35.3.5 Motions for Disposition without Trial | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-003-005#main-content)

- 35.3.5 [Motions for Disposition without Trial](https://www.irs.gov/irm/part35/irm_35-003-005#idm140265800391424)
  - 35.3.5.1 [Introduction](https://www.irs.gov/irm/part35/irm_35-003-005#idm140265808487280)
  - 35.3.5.2 [Motion for Judgment on the Pleadings](https://www.irs.gov/irm/part35/irm_35-003-005#idm140265829559440)
  - 35.3.5.3 [Motion for Summary Judgment](https://www.irs.gov/irm/part35/irm_35-003-005#idm140265820964624)
  - 35.3.5.4 [Motion to Submit Under T.C. Rule 122](https://www.irs.gov/irm/part35/irm_35-003-005#idm140265822508912)
  - 35.3.5.5 ["No Change" Letter Treated as Motion for Entry of Decision](https://www.irs.gov/irm/part35/irm_35-003-005#idm140265812771616)

# Part 35. Tax Court Litigation

# Chapter 3. Motions

# Section 5. Motions for Disposition without Trial

* * *

## 35.3.5 Motions for Disposition without Trial

#### Manual Transmittal

August 12, 2019

#### Purpose

(1) This transmits new CCDM 35.3.5, Motions, Motions for Disposition without Trial.

#### Material Changes

(1) CCDM 35.3.5.3(2) was revised to include whistleblower cases in the list of situations where summary judgement procedures would be applicable.

(2) CCMD 35.3.5.3(6), was added to reflect that summary judgment is an effective mechanism to dispose of whistleblower award disputes when the Service did not take an administrative or judicial action against the target taxpayer, did not collect any proceeds based on the whistleblower's information, the target taxpayer voluntarily changes its behavior for years outside of the years that are the subject of the action, or the facts of the case do not warrant a mandatory award under I.R.C. 7623(b).

#### Effect on Other Documents

This section supersedes CCDM 35.3.5.3 dated April 11, 2004.

#### Audience

Chief Counsel

#### Effective Date

(08-12-2019)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**35.3.5.1** **(08-11-2004)**

### Introduction

1. The Tax Court Rules provide for three procedures for the early disposition of cases on their substantive merits without the necessity of trial: judgment on the pleadings under T.C. Rule 120, summary judgment under T.C. Rule 121, and submission of a fully stipulated case to the court under T.C. Rule 122. In addition, there are miscellaneous motions resulting in the disposition of cases without trial on essentially procedural grounds.


**35.3.5.2** **(08-11-2004)**

### Motion for Judgment on the Pleadings

1. This motion is not often used by the respondent since most petitions are drafted in a form that is not susceptible to the respondent admitting the allegations as they are written, nor would the pleadings ordinarily present a nonfrivolous substantive issue for disposition without matters outside the pleadings having to be considered. This motion, however, may be used routinely in cases involving frivolous legal arguments when the time has passed for filing a motion to dismiss for failure to state a claim. This type of motion may not be used in cases involving fraud, transferee, or other issues as to which the burden of proof is upon the respondent, unless the affirmative allegations in the answer have been deemed admitted under T.C. Rule 37. A motion for judgment on the pleadings should be used with caution. There must be clarity and certainty that not only are all of the facts that are necessary for the motion stated in the petition and admitted in the answer, but also that such facts are properly stated. The allegations of fact in the petition and their admission in the answer must be sufficient to form a factual basis upon which the court can, as a matter of law, decide the issues for the respondent. This type of motion should never be used in cases in which the statutory notice of deficiency was not issued within the period of limitations whether or not the statute of limitations was raised as an issue in the petition. If such issue is not raised initially in the petition, the court may, at the hearing on the motion for judgment on the pleadings, permit the issue to be raised. _See_ section 7459(e) as to the effect of the court holding that the assessment and collection of any tax is barred by the statute of limitations. Petitioners have attempted to use this type of motion when material facts alleged in the petition have been denied in the answer. Such procedure is improper since the petitioner in his or her motion must find sufficient admitted facts or facts otherwise appearing in the record to support his or her motion.

2. A motion for judgment on the pleadings can be employed only after the pleadings are closed (T.C. Rule 38) and it is clear from the pleadings themselves that the case presents no genuine issues of fact but only issues of law. The pleadings and admissions therein form the only basis for the motion. If matters outside the pleadings are presented to the court and are not excluded, the motion will be treated as one for summary judgment, and the parties will be given a reasonable opportunity to present all material pertinent to such a motion by T.C. Rule 121. In cases where the burden of proof is on the respondent and affirmative allegations have been made in the answer, use of the motion would be appropriate only if the allegations have been deemed admitted under T.C. Rule 37(c). The motion can only be used where the granting of the motion will result in a decision for the moving party. Motions for judgment on the pleadings may be directly filed with the court if the issue is one for which a brief could be directly filed with the court. All other motions for judgment on the pleadings are to be forwarded to the appropriate Associate Chief Counsel for review before filing with the court. _See_ Exhibit 35.11.1–1, Tax Court Documents Requiring Associate Office Review.


**35.3.5.3** **(08-12-2019)**

### Motion for Summary Judgment

01. The primary purpose of the summary judgment procedure is to pierce the allegations of the pleadings and show that there is no genuine issue of material fact, although it appears that an issue is raised by the pleadings. Summary judgment may be utilized to resolve all or part of the issues in a case. Where the parties are disposed to stipulate the case and submit it under T.C. Rule 122 (Submission Without Trial), summary judgment should not be used as a substitute for that procedure. The submission of a case without trial (under T.C. Rule 122) is preferable since the respondent will be better able to set forth the facts with clarity and completeness. The submission of a case on stipulation will promote opinions which will tend to have more precedent value because of the clarity and completeness of the facts. In instances where the granting of a motion for summary judgment does not resolve all of the issues in a case (partial summary judgment), the order to be entered by the court does not constitute a decision and accordingly, no assessment may be made. _See_ T.C. Rule 121(c).

02. The following is a partial list of situations where summary judgment procedures would be applicable.



    1. In situations where there is no genuine issue of material fact and respondent is entitled to judgment as a matter of law.

    2. In situations where the petition raises merely vexatious or frivolous issues, summary judgment may be an appropriate mechanism utilized to dispose of the case at an earlier time and without the necessity of a trial.

    3. Summary judgment may be used to separate out pretended or patently immaterial issues of fact which have been denied by respondent, but which would foreclose a judgment on the pleadings under T.C. Rule 120. Under T.C. Rule 121(c), the Court may rule upon the immaterial or pretended issues of fact and eliminate them from the case.

    4. In a multi-issue case where the petitioner maintains one or more frivolous issues, partial summary judgment can be utilized to narrow the issues in the case and conserve respondent’s trial preparation time.

    5. Where the law favors respondent, but the petitioner has injected inflammatory or emotional issues or facts which should have no bearing on the case, partial summary judgment could be used to remove those issues or facts from the case prior to trial.

    6. In instances where the petitioner does not assign error to the respondent’s assertions of fraud or transferee liability, which under the provisions of T.C. Rule 34(b)(4) are deemed to be conceded, partial summary judgment may be available to finalize that concession. Field attorneys should only use this type of procedure where communication with petitioner’s attorney has failed to confirm the apparent concession. _See_ Exhibit 35.11.1–56.

    7. Summary judgment may present a proper vehicle to dispose of cases controlled by collateral estoppel, res judicata and rule of the circuit.

    8. In a whistleblower case where the administrative record is adequate and the Whistleblower Office did not abuse its discretion when making its determination, summary judgment is an appropriate mechanism to dispose of the case at an earlier time and without the necessity of a trial.


03. If respondent seeks summary judgment, any facts should be carefully formulated because respondent may be bound to those facts if the motion is ultimately denied or partially allowed. Although respondent could be successful in a partial summary judgment, the facts utilized in support of the motion may adversely affect respondent’s chances of success in the issues remaining for trial. The use of summary judgment may also be a premature disclosure of the evidence available to the Service. The use of summary judgment procedures in the district courts has resulted in holdings that a party cannot amend or change positions to rely on another theory after the one used on summary judgment has failed. The reasoning of these cases is that the courts do not want the parties to test legal theories and is a form of judicial estoppel. Since the Tax Court may adopt the same reasoning, each Field attorney should advance all of respondent’s legal arguments in the motion for summary judgment in order not to later be precluded from arguing any of them. If one of respondent’s theories is based upon a disputed fact, summary judgment may still be used provided respondent concedes that there is no issue of fact if respondent’s legal theory is accepted but at the same time maintains that there is a genuine dispute as to material facts if respondent’s theory is rejected or petitioner’s theory is adopted. Such a procedure is risky unless the concession is absolutely clear or leaves no doubt that there is a dispute as to the facts.

04. Motions for summary judgment may be directly filed with the court if the issue is one for which a brief could be directly filed with the court. _See_ Exhibit 35.11.1–1, Issues Requiring Associate Office Review. All other motions for summary judgment are to be forwarded to the Technical Support Services Branch for assignment to the appropriate Associate Office for review before filing with the Court.

05. T.C. Rule 121 provides that a motion for summary judgment can be made at any time commencing 30 days after the pleadings are closed, but within such time as not to delay the trial. Accordingly, motions for summary judgment should rarely be filed after the issuance of the trial calendar or 90 days prior to trial. Each motion by respondent should include as a final allegation of the motion that the Field attorney has reviewed the administrative file, the pleadings, and any written proof submitted and has concluded there is no genuine issue as to any material fact left for trial on the merits of the motion (whether for partial or full summary judgment) as supported by the record in the case (including any attachments to his or her separate affidavit). _See_ Exhibit 35.11.1–57.

06. In whistleblower cases, the Tax Court only has jurisdiction with respect to the Whistleblower Office’s award determination. The Tax Court lacks authority to direct the Service to proceed with an administrative or judicial action in response to a whistleblower’s information regarding alleged underpayments of tax or violations of internal revenue laws. A whistleblower award is dependent upon both the initiation of an administrative or judicial action and the collection of proceeds. A motion for summary judgment should be made whenever the Service did not take an administrative or judicial action against the target taxpayer, the Service did not collect any proceeds based on the whistleblower’s information, the target taxpayer voluntarily changes its behavior for years outside of the years that are the subject of the administrative or judicial action, or the facts of the case do not warrant a mandatory award under section 7623(b). All motions for summary judgment in whistleblower cases should state the appropriate standard and scope of review. The Tax Court reviews the Whistleblower Office’s award determinations on the administrative record for an abuse of discretion. Accordingly, if the administrative record is adequate and the Whistleblower Office did not abuse its discretion when making the determination, the Tax Court should grant the motion for summary judgment.

07. The opposing party to a motion for summary judgment shall file a written response within such period as the Court may direct. _See_ T.C. Rule 121(b). A written response should always be filed whenever petitioner files a summary judgment motion (other than a frivolous filer type motion) even if not ordered to do so by the court. The response should include all defenses, such as material facts in controversy, any necessary affidavits, and a memorandum of law in support of respondent’s substantive position. Exhibit 35.11.1–57. If respondent is opposing a motion for summary judgment on the basis that there is a genuine issue of material fact, an affidavit or declaration should always be used even it merely states that the Field attorney is unable to obtain affidavits from necessary witnesses. _See_ T.C. Rule 121(e). In the alternative, a motion for protective order may be considered, as discussed below. The Tax Court has emphasized that when opposing a motion for summary judgment, one cannot rely upon mere allegations or denials in the pleadings, but must set forth specific facts showing that there is a genuine issue for trial. If respondent is opposing a motion for summary judgment on the basis that inadequate discovery has been performed and the motion currently cannot be opposed with specific facts, a notice of objection can be filed stating that discovery has not been initiated by the Field attorney. The notice of objection should state what specific information respondent expects would be elicited in discovery. When a petitioner files a motion for summary judgment as soon as the Tax Court Rules allow, or respondent is having problems obtaining discovery, respondent likewise will have difficulty opposing the motion with specific facts. In such instances, the Field attorney should consider the use of a motion for protective order pursuant to T.C. Rule 103(a)(1), on the ground of undue burden. Exhibit 35.11.1–58. Respondent’s response to petitioner’s motion for summary judgment may be filed directly with the court unless it concerns a matter which should be reviewed by an Associate Office. _See_ Exhibits 35.11.1–1, Issues Requiring Associate Office Review. If the response is to be reviewed in the Associate Office, it should be received at least five business days prior to the date set by the court for filing the response.

08. Pursuant to T.C. Rule 121(b) a party may use an affidavit to overcome pleading allegations. All motions for summary judgment filed on behalf of the Service pursuant to T.C. Rule 121 should be accompanied by an affidavit or declaration of the Field attorney under penalties of perjury pursuant to 28 U.S.C. § 1746, unless the respondent is relying exclusively on the pleadings concerning a purely legal issue. The affidavit or declaration must be made on personal knowledge and will set forth facts that would otherwise be admissible in evidence. _See_ Exhibit 35.11.1–57. The affidavit or declaration should state:



    1. The captioned case has been assigned to the Field attorney for defense of the Service.

    2. The Field attorney is competent to testify to matters involved in this case because the Service’s administrative file has come into the attorney’s custody and control in connection with the defense.

    3. By separate allegation for each document or group of documents the Field attorney attaches written proof to the affidavit including sworn or certified copies of documents whose authenticity may be in dispute.

    4. The Field attorney may also include any other facts not in writing of which the attorney has personal knowledge that would otherwise be admissible if the attorney were to testify in the case.


09. Examples of written materials or documents already in the record or facts to be added to the record by the Field attorney’s affidavit include:



    - Depositions (written or oral) obtained under the Court’s rules

    - Answers to interrogatories

    - Responses to requests for admissions

    - Items covered by judicial notice

    - Statutory presumptions

    - Undenied allegations in the pleadings

    - Limited oral testimony

    - Documents obtained through formal or informal discovery


10. At the hearing, T.C. Rule 121 contemplates that the court may utilize limited oral testimony to determine whether there is a material issue of fact. Accordingly, former recorded testimony may be used in support of a motion for summary judgment.

11. If summary judgment is denied, the evidence submitted in support thereof, to the extent not found in the court’s order or not constituting admissions, must be offered at the trial to be received in evidence. For example, answers to interrogatories not in the court’s order must be offered at the trial.

12. The burden is on the moving party to establish the lack of a triable issue of fact and any doubts are usually resolved against the moving party.

13. T.C. Rule 121(b) provides that when a motion for summary judgment is made and supported as provided in this rule, an opposing party may not rest upon the mere allegations or denials of a pleading. T.C. Rule 121(b) goes on to suggest that the opposing party respond by means of affidavits or otherwise as provided in the rule. T.C. Rule 121(e) provides for situations where affidavits are not available to the party opposing the motion. Petitioner’s motion should be opposed if there are any material issues of fact in controversy. _See_ T.C. Rule 121 and the note thereunder. The opposing party to a motion for summary judgment must set forth specific facts showing that there is a genuine issue for trial if the motion is to be defended on these grounds. The motion can be opposed by advising the court by affidavit that the only legal available method of controverting the facts set forth in the affidavit of the moving party is through cross-examination of the affiant or testimony of third parties from whom affidavits cannot be obtained. If, however, an affidavit sets forth information which was not verified by the revenue agent, but which is susceptible to verification, an opposing affidavit should be prepared, if possible. If the allegations of the affidavit can be readily verified, a mere statement that cross-examination is necessary may not prevail. For example, in a substantiation case the petitioner may state that a specific sum was paid to a specific charity on a particular date, which assertions have not been verified by the revenue agent. Under these circumstances the charity should be contacted to determine whether an opposing affidavit is feasible. The Field attorney should draft all affidavits. In addition, the Field attorney shall accompany every notice of objection to a petitioner’s motion for summary judgment (where the defense is that material facts are in dispute) with an affidavit or declaration stating at least the allegations in _CCDM 35.3.5.3_(8)(a) and (b). The Field attorney’s affidavit must also have attached the affidavit of the revenue agent or other witnesses whose testimony controverts facts alleged by the petitioner to support summary judgment. If an opposing affiant or declarant is unavailable, pursuant to T.C. Rule 121(e) the Field attorney’s affidavit should allege that fact.

14. T.C. Rule 121(f) provides that where an affidavit is presented in bad faith or for the purpose of delay, the court may order the party presenting the affidavit to pay to the other party (reimbursement for) reasonable expenses which the filing of the affidavits caused, including reasonable counsel’s fees. Additionally, the offending party or counsel may be found guilty of contempt or otherwise disciplined by the court. These sanctions may extend to Chief Counsel attorneys. Any sanctions sought against opposing counsel must be approved by the Sanctions Officer, who is the Associate Chief Counsel (P&A). If sanctions are sought against a Chief Counsel attorney, this must be reported to the Sanctions Officer, through Procedure and Administration, Branches 1/2.

15. If respondent’s motion for summary judgment is denied and subsequent discovery and/or stipulation reveals no material dispute of facts, the motion for summary judgment may be renewed. The doctrine of res judicata does not apply to the court’s determination with respect to whether a motion for summary judgment lies.


**35.3.5.4** **(08-11-2004)**

### Motion to Submit Under T.C. Rule 122

1. A motion to submit a case under T.C. Rule 122 is always a joint motion of the parties. This motion should make it clear to the court upon what facts the case is submitted. The submission of a case under T.C. Rule 122 is upon the basis of admissions in pleadings, admissions obtained pursuant to Rule 90, a stipulation as to the administrative record in a declaratory judgment case, a stipulation of facts with attached exhibits and/or testimony by deposition. The stipulation accompanies the motion for submission under Rule 122. If depositions are involved, the stipulation of facts should offer the deposition in evidence with objections by either party as to competency, etc., and request the court to accept it in evidence subject to such objections. T.C. Rule 85. The objections may be argued on brief. Care should be taken to insure that documents and information obtained under T.C. Rules 71, 72 and 74 are made a part of the stipulation of facts since, unlike responses to requests for admissions, such matters are not a part of the court’s record until formally offered in evidence. In the motion, the parties should request the court to fix a time for the filing of briefs or for oral arguments, as appropriate. _See_ Exhibit 35.11.1–58. A motion under Rule 122 should not be used when the case is submitted without trial at a calendar call because it is unnecessary and is already assigned to the judge handling the trial calendar. If section 7491(c) is applicable, the Field attorney must include stipulations regarding any penalties asserted in the notice of deficiency sufficient to carry respondent’s burden of production with respect to the penalties.

2. In order for the name of the Field attorney to appear on the court’s opinion as attorney for the respondent, the attorney’s name may be shown under the heading, Counsel of Record, on the Rule 122 motion and all subsequent pleadings and briefs.

3. Respondent should consider filing a motion for an order to show cause why a case involving a declaratory judgment should not be submitted under Rule 122 if petitioner refuses to file a joint motion.


**35.3.5.5** **(08-11-2004)**

### "No Change" Letter Treated as Motion for Entry of Decision

1. Petitioners sometimes send the court no change letters or other correspondence from the Service to the effect that they have satisfied the Service that there is no deficiency or that the deficiency is in a lesser amount that petitioner no longer contests. The Tax Court will usually issue an order filing the letter as Petitioner’s Motion for Entry of Decision, and direct respondent to file a notice of objection or notice of no objection to the motion. The order will not be a self-executing show-cause order; rather, it will request a response from respondent concerning whether or not an objection is contemplated. If respondent lacks sufficient information or is otherwise unable to respond within the time designated by the court, a motion to extend the time within which to respond should promptly be filed. The court will take appropriate action on the motion, which may include a hearing, after the response is filed. In most cases, respondent will have no objection to the entry of a no deficiency decision, and a Notice of No Objection should be filed (even if the court’s order suggests that no response need be filed if there is no objection). In the case of an overpayment resulting from the Service’s no change letter, a stipulated decision document will be required from the parties; in that event, a response to the court’s order should state the need for an overpayment decision and be accompanied by the stipulated decision, if possible, or state when such a decision may be expected.

2. If respondent becomes aware of (and confirms) a no change letter before petitioner forwards a copy to the Tax Court, a stipulated decision reflecting no deficiency should be secured from petitioner and filed with the court. Alternatively, if petitioner’s signature to a decision document cannot be secured, respondent may file a motion for entry of decision, attaching a copy of the no change letter as an exhibit to the motion. _See_ Exhibit 35.11.1–59.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-003-005#addtoany "Show all")

A2A