---
url: "https://www.irs.gov/irm/part35/irm_35-005-002"
title: "35.5.2 Settlements by Counsel | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-005-002#main-content)

- 35.5.2 [Settlements by Counsel](https://www.irs.gov/irm/part35/irm_35-005-002#idm140384804079968)
  - 35.5.2.1 [Attorneys Authority](https://www.irs.gov/irm/part35/irm_35-005-002#idm140384812548896)
  - 35.5.2.2 [Settlement Negotiations](https://www.irs.gov/irm/part35/irm_35-005-002#idm140384809359168)
  - 35.5.2.3 [Determination of Service Position](https://www.irs.gov/irm/part35/irm_35-005-002#idm140384809333264)
  - 35.5.2.4 [Settlement on the Merits](https://www.irs.gov/irm/part35/irm_35-005-002#idm140384805749568)
  - 35.5.2.5 [Role of Judges in Settlement Negotiations](https://www.irs.gov/irm/part35/irm_35-005-002#idm140384812446592)
  - 35.5.2.6 [Collection Aspects of the Settlement](https://www.irs.gov/irm/part35/irm_35-005-002#idm140384808223840)
  - 35.5.2.7 [Settlements Affecting Other Years or Other Taxpayers](https://www.irs.gov/irm/part35/irm_35-005-002#idm140384815076160)
  - 35.5.2.8 [Providing Taxpayers with Payoff Amounts](https://www.irs.gov/irm/part35/irm_35-005-002#idm140384803568528)
  - 35.5.2.9 [Settlement Procedures in "S" Cases](https://www.irs.gov/irm/part35/irm_35-005-002#idm140384807554752)
  - 35.5.2.10 [Reporting Settlements to the Court](https://www.irs.gov/irm/part35/irm_35-005-002#idm140384803685136)
  - 35.5.2.11 [Post-Trial Notice of Settled Cases](https://www.irs.gov/irm/part35/irm_35-005-002#idm140384806928976)
  - 35.5.2.12 [Settlement After Trial](https://www.irs.gov/irm/part35/irm_35-005-002#idm140384815203648)
  - 35.5.2.13 [Action After Opinion or Decision](https://www.irs.gov/irm/part35/irm_35-005-002#idm140384827568704)
  - 35.5.2.14 [Counsel Settlement Memorandum](https://www.irs.gov/irm/part35/irm_35-005-002#idm140384832273488)
  - 35.5.2.15 [Administrative Processing of Settlements](https://www.irs.gov/irm/part35/irm_35-005-002#idm140384812756448)
  - 35.5.2.16 [Closing Settled Cases in Field Counsel Offices](https://www.irs.gov/irm/part35/irm_35-005-002#idm140384812417616)
  - 35.5.2.17 [Collateral and Closing Agreements](https://www.irs.gov/irm/part35/irm_35-005-002#idm140384808213808)
  - 35.5.2.18 [Settlement of Declaratory Judgment Cases and Worker Classification Cases under section 7436](https://www.irs.gov/irm/part35/irm_35-005-002#idm140384814513344)
    - 35.5.2.18.1 [Exempt Organization Declaratory Judgment Procedures](https://www.irs.gov/irm/part35/irm_35-005-002#idm140384820283776)
    - 35.5.2.18.2 [Employee Plan Declaratory Judgment Cases](https://www.irs.gov/irm/part35/irm_35-005-002#idm140384803514912)
    - 35.5.2.18.3 [Governmental Obligation Declaratory Judgment Cases](https://www.irs.gov/irm/part35/irm_35-005-002#idm140384811261264)
    - 35.5.2.18.4 [Worker Classification Cases under Section 7436](https://www.irs.gov/irm/part35/irm_35-005-002#idm140384812753936)
  - 35.5.2.19 [Settlement of Docketed Collection Due Process Cases](https://www.irs.gov/irm/part35/irm_35-005-002#idm140384803511216)

# Part 35. Tax Court Litigation

# Chapter 5. Settlement Procedures

# Section 2. Settlements by Counsel

* * *

## 35.5.2 Settlements by Counsel

#### Manual Transmittal

August 06, 2019

#### Purpose

(1) This transmits revised CCDM 35.5.2, Settlement Procedures; Settlements by Counsel.

#### Material Changes

(1) New subsection CCDM 35.5.2.19 is added to give guidance on the settlement of CDP cases.

#### Effect on Other Documents

CCDM 35.5.2, dated December 31, 2012, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(08-06-2019)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**35.5.2.1** **(08-11-2004)**

### Attorney’s Authority

1. Although the Field attorney may negotiate a settlement, the attorney does not necessarily have the authority to bind the government. Acceptance of a negotiated settlement is always conditioned upon approval by the appropriate official. For example, in some coordinated cases, Field Counsel, the Department of Justice (DOJ), or the Associate offices must review or approve a settlement agreement. In addition, in cases requiring a report to the Joint Committee on Taxation under section 6405, the attorney should advise petitioner or petitioner’s counsel that no settlement may be entered into until the government has complied with the requirements of that section. In all situations, internal delegations of authority must be consulted to determine what officials may enter into binding settlement agreements in docketed cases and the extent of an attorney’s settlement authority must be clearly communicated to the opposing party during settlement negotiations.

2. It is critically important to make clear in correspondence concerning settlement negotiations, e.g., letters communicating settlement positions, acknowledging settlement offers, or proposing counter offers, that any proposed settlement is not final until formal notice of acceptance is made by the appropriate official. The parties may, for example, specifically agree not to be bound to any proposed settlement until a decision document or stipulation of settlement is filed with the court, or specific terms of a settlement agreement are read into the court’s record. These precautions are necessary to ensure that tentative settlement agreements are not enforced against the respondent prior to the intention of the appropriate official to formally accept a settlement offer.

3. The Tax Court looks to contract principles to determine whether the parties have reached an enforceable settlement agreement. _Dorchester Industries, Inc. v. Commissioner_, 108 T.C. 320 (1997), _aff’d_, 208 F.3d 205 (3d Cir. 2000). The Tax Court in _Dorchester_ announced that it will no longer follow _Cole v. Commissioner_, 30 T.C. 665 (1958), _aff’d_, 272 F.2d 13 (2d Cir. 1959), which had held that settlement agreements are not binding until filed as a stipulation or made part of the record. The court may therefore enforce a settlement agreement evidenced solely by an exchange of correspondence between the parties, particularly where the parties have communicated to the court that they have achieved a settlement agreement. See, _e.g., Manko v. Commissioner_, T.C. Memo. 1995–10. The court may also enforce a settlement agreement even in the absence of communication of the fact of the agreement to the court. The parties should expect that any unequivocal communication of an acceptance of a settlement offer will be irreversibly binding and enforceable, unless the communication expressly sets forth any conditions that must be satisfied before achieving a binding agreement, including any required procedures for formal acceptance of a settlement offer.

4. It is imperative that all communications to the court concerning potential settlements clearly state the existence of any conditions attached to achieving a final, binding settlement agreement (such as approval from the supervising officials, substantiation of items, satisfying the requirements of section 6405, or the completion of related events, such as the execution of a closing agreement covering nondocketed years), and specify that, until all such conditions have been satisfied, neither the petitioner nor the court should consider the case settled. In the absence of such qualifications, the parties should expect that the court will enforce the reported settlement, even if the agreement has not been finalized through execution of a decision document and even though one of the parties no longer agrees to be bound to the reported settlement.


**35.5.2.2** **(08-11-2004)**

### Settlement Negotiations

1. With the exception of certain relatively rare test cases, it has long been the position of the Office of Chief Counsel that sincere efforts should be made to settle those cases susceptible of settlement. In general, the Office of Chief Counsel regards all cases susceptible of settlement except those which involve negligible litigation hazards and cases designated for litigation.


**35.5.2.3** **(12-31-2012)**

### Determination of Service Position

1. Before a Field attorney can make an informed decision about settlement, it is necessary to ascertain the Service’s current position on the issues involved in the case. See CCDM 31.1.1.1.1, Determination of Service Position, and CCDM 33.1.1.1, Legal Advice in General, for a discussion on how to determine the position of the Service and the required coordination procedures.


**35.5.2.4** **(12-31-2012)**

### Settlement on the Merits

1. Cases and issues are to be settled on the merits. This usually involves a settlement on the merits of each issue before the court. Lump sum or blanket settlements which include tax, penalty, and interest should be avoided, and generally should not be entertained or accepted. The Service has a definite policy against settlements without statutory interest on the deficiency. Generally, in deficiency cases other than transferee liability cases, the Tax Court has no jurisdiction over interest on the deficiency and the amount of the deficiency in tax or penalty (other than the transferee liability cases) should be agreed upon without regard to the statutory interest which is to be assessed. In extraordinary circumstances, a lump sum settlement may be justified; but in such cases there must be an allocation between tax, penalty, and interest, and the interest to the agreed date of payment must be computed and omitted from the settlement stipulation.

2. No case is to be settled on a so-called nuisance basis, either for or against the government. What constitutes a nuisance settlement is dependent upon the circumstances in each case. When each issue is settled on its merits, the fact that the resulting deficiency is a small percentage of the deficiency asserted in the statutory notice would not be construed as a "nuisance" settlement.

3. Penalties must be settled on the merits. Attorneys are not to use penalties as a "bargaining point" in resolving a taxpayer’s other tax adjustments. In deciding whether to settle docketed cases, attorneys must consider the hazards of litigation with respect to the penalties independent of the hazards of litigation with respect to the underlying tax adjustments. See Policy Statement 20-1, Penalties are used to enhance voluntary compliance (IRM 1.2.20.1.1(9)). In cases involving individuals, Chief Counsel attorneys will have the burden of production under section 7491(c) to establish the taxpayer’s liability for any penalty; taxpayers will have the burden to establish defenses such as reasonable cause, substantial authority, or similar defenses to the imposition of penalties. The Counsel Settlement Memorandum must reflect the analysis of the hazards of litigation of the penalty issue. See CCDM 35.5.2.14, Counsel Settlement Memorandum.

4. The parties in a settlement stipulation can agree to eliminate or partially concede penalties to amounts less than the statutory percentage. If criminal prosecution against the petitioner (or related taxpayer involving the same transaction) has been recommended to DOJ, however, coordination is required before any such agreement can be finalized. See CCDM 35.5.3.4, Tax Court Cases Having Criminal Aspects, and CCDM 38.3.1.8, Balancing Criminal and Civil Aspects.


**35.5.2.5** **(12-31-2012)**

### Role of Judges in Settlement Negotiations

1. The attorney and reviewer should not conduct any settlement negotiations in the presence of the trial judge. See CCDM 35.6.1.5, No Settlement Negotiations before the Trial Judge.


**35.5.2.6** **(12-31-2012)**

### Collection Aspects of the Settlement

1. Normally, the collection aspects of an agreed deficiency are not considered in the disposal of a deficiency or transferee liability case. It is preferable that all settlements be effectuated by a merits settlement rather than upon the basis of inability to pay. This general guideline is applicable even though there may be a substantial basis for concluding that the petitioner may not be able to pay the agreed deficiency. In this instance, the case should be settled on its merits, and if the petitioner is unable to pay such deficiency, he can later file an offer in compromise based upon doubt as to collectability. Offers in compromise should not be solicited except in the most unusual circumstances.

2. In appropriate cases, steps may be taken before filing the settlement stipulation to make definite arrangements for the payment of the agreed deficiency if it is determined that the Service will experience serious difficulty in the collection of the agreed deficiency.

3. As a general rule, every effort should be made to file a settlement stipulation with the court with the agreement of the petitioner as soon as it is executed, even though the petitioner intends to file an offer in compromise. If such an agreement on the filing of the stipulation cannot be reached with the petitioner, and it is concluded by Field counsel that due to unusual circumstances the offer in compromise should be processed before the filing of the settlement stipulation, escrow procedures should be followed. See CCDM 33.3.2, Offers in Compromise, and CCDM 35.8.6.2.1, Service Offer in Compromise Cases . Unreasonable delay should not be permitted to occur due to the petitioner’s filing of a series of offers in compromise. Also, judgment must be used in agreeing to a continuance of a calendared case due to the filing of an offer in compromise. In the latter instance, if the offer appears to have been filed for the purpose of securing a continuance of the trial, the continuance motion should be strongly opposed, and every effort should be made to dispose of the case, either by trial or settlement on the merits without a continuance.


**35.5.2.7** **(08-11-2004)**

### Settlements Affecting Other Years or Other Taxpayers

1. A settlement of a pending Tax Court case is not necessarily determinative of the action the Service may take on similar issues for years not before the court or with respect to related taxpayers. If there are certain issues and certain factual situations which are classified as continuing issues, the disposition of the docketed years may have a direct effect upon the disposition of other years. In such a situation, there should be coordination of such continuing issues with Appeals and/or Examination. Similarly, if the proposed settlement may affect related taxpayers, there should be coordination with Appeals and/or Examination.

2. When a settlement is negotiated by Counsel, the Service normally will follow such settlement and the basis therefor, when appropriate, with respect to the nondocketed years of the same taxpayer or as to related taxpayers. This factor should be kept in mind in the settlement of cases and in the preparation of the settlement memorandum. The fact that a similar issue is pending before Appeals or the Area Director is not a deterrent to the settlement of the Tax Court case, but thorough consideration should be given to the views of Appeals, or the Area Director. When feasible, an overall settlement of all pending cases, both docketed and nondocketed, should be accomplished at the same time. When this is not feasible, the Tax Court case may be settled apart from the nondocketed case after taking into consideration the effect of such action on the nondocketed matter or on the tax liability of the related taxpayers.

3. In considering the settlement of a year or years that are docketed before the Tax Court, Counsel has no authority to settle a case by taking into account issues from years not before the court that have no relationship to the issues or years before the court.


**35.5.2.8** **(12-31-2012)**

### Providing Taxpayers with Payoff Amounts

1. In certain Tax Court settlements, and whenever requested by the petitioner, Field attorneys must provide petitioners with a computation of their total tax liability (including tax, penalties and estimated interest), which will be due in accordance with the terms of the settlement. These procedures will apply to Tax Court cases involving individual taxpayers whose cases will not require restricted interest computations or interest netting computations. Cases requiring a restricted interest computation include those involving carrybacks, offsetting of overpayments and underpayments between two or more years, section 6621(c) increased interest and the time-sensitive components of the fraud and negligence penalties (returns due from 1982 through 1987).

2. Providing petitioners with their payoff amounts, including estimated interest, in accordance with the terms of a settlement should enable petitioners to better evaluate and appreciate the consequences of the settlement and encourage earlier payment of the amount due. Field Counsel should ensure that employees are aware of the procedures to process any payment tendered by taxpayers. Ordinarily, no payment should be refused.

3. Settlements are often reached in a face-to-face meeting, either at Field Counsel offices, trial sessions or elsewhere, or through telephone conversations. Accordingly, Field Counsel should establish procedures to ensure that someone trained in making these computations is available, in person or on the phone, so that the computations may be made and the information provided to the petitioner at the time the decision document is presented to the petitioner or representative for signature.

4. Where the settlement negotiations have been conducted by correspondence, the computation of tax liability, including interest, should be included in the letter transmitting the decision document to the petitioner or representative for signature. See Exhibit 35.11.1–108, Letter Enclosing Settlement Documents, for a form letter that may be used for transmitting the decision document and the computation of the amount, including interest, that is due from the petitioner. If Exhibit 35.11.1–108 is not used, Field attorneys should be certain to include language informing the petitioner that the interest computation is only an estimate and that a final bill will be forwarded from the Service Center. Furthermore, in cases requiring restricted interest computations, the petitioner should be informed that once the stipulation and/or decision documents are filed and entered by the Tax Court, the computation of interest due will be calculated and billed.

5. Appeals staff will assist Field Counsel in preparing these computations.


**35.5.2.9** **(08-11-2004)**

### Settlement Procedures in "S" Cases

1. The purpose of the "S" case procedure is to reduce the time involved in the preparation, execution, and filing of settlement documents in a small case.

2. Computations. Small cases ("S" or regular) may be settled on the basis of a specific dollar amount agreed upon by both parties to approximate the amount that would have been reached if formal computations had been made. It is intended that this approach be utilized in simple cases where the finalization of decision documents would clearly be better facilitated because of the presence of the petitioner. This approach should not be utilized where the computations are complex or there are related years or related taxpayers which may be affected by the decision and/or the underlying computations.

3. Contact with Collection. If it would facilitate the settlement of a small case, consideration should be given to assisting the petitioner in making the initial contact with Collection.

4. Counsel Settlement Memoranda. The Office of Chief Counsel encourages brevity in Counsel Settlement Memoranda in small cases. It would be appropriate to incorporate by reference and attach that portion of the Appeals Case Memo which sets forth the issues and facts in a small case along with a brief statement of the basis of settlement, making clear any variations or changes from the case memo.


**35.5.2.10** **(12-31-2012)**

### Reporting Settlements to the Court

1. See the discussion at CCDM 35.6.1.5, No Settlement Negotiations before the Trial Judge, regarding the settlements at the time of trial.

2. The executed decision documents in all cases, including "S" cases, which are calendared for trial should be promptly sent to the court if they can be mailed so as to arrive at the court not less than ten working days prior to the commencement of the trial session. Settlement documents executed after that time should be filed at the trial session. In addition, Field attorneys should abide by any pre-trial orders that are issued by the Tax Court judge for any particular trial session.


**35.5.2.11** **(12-31-2012)**

### Post-Trial Notice of Settled Cases

1. The Tax Court has adopted a procedure whereby the trial judge will retain jurisdiction over cases that are reported settled by the parties at the trial session. The trial judge will allow the parties a specified time in which to file the settlement documents. Every effort should be made to have the decision documents filed while the court is in session or as soon as possible thereafter. If the decision documents cannot be filed while the court is in session, then the Field attorney should file the decision documents with the Tax Court in Washington, D.C.

2. The trial judge should be kept apprised of the status of cases in which settlement documents cannot be filed within the time originally allowed. If, for example, the trial judge suspends the case for 60 or 90 days after the date of the calendar, and if the decision documents cannot be filed on or before the due date, a letter on Office of Chief Counsel letterhead should be sent to the trial judge at least two weeks before the due date briefly describing the status of the case, i.e., the reason for the delay and the time when the trial judge can expect to receive the decision documents. A separate letter must be prepared for each case. The trial judge should be kept advised by subsequent letters at least every 30 days of the status of the cases reported settled. The letter should specify the calendar at which the case appeared. See Exhibit 35.11.1-109, Letter to Tax Court Judge Reporting Status of Settled Cases.

3. The letter should be sent directly to the Tax Court, with copies sent to the petitioner or petitioner’s counsel. In the event the trial judge states that he/she prefers to be informed of the status informally by telephone, the attorney should follow up this informal communication with a letter to the judge and copies to the petitioner or petitioner’s counsel.

4. The Associate Area Counsel should continuously monitor those cases that were reported to the Tax Court as settled. The Field attorney should also be diligent in ensuring that the stipulated decision document is filed as soon as possible.

5. Where a case has been reported settled, but the petitioner or representative refuses to execute the decision documents reflecting such settlement or unreasonably procrastinates in the execution of such decision documents, the status report letter may so inform the court. The status report should refer to the trial calendar at which the case was reported settled, state what efforts respondent has made to obtain an executed decision document, and report the basis upon which the case was settled. In some circumstances such as where specific terms of the settlement have been entered in the record, counsel may consider filing a motion for entry of a decision.


**35.5.2.12** **(08-11-2004)**

### Settlement After Trial

1. After the trial of a case and receipt of the transcript and before briefs are filed, the Field attorney should examine the transcript and the exhibits introduced into evidence to determine whether the case or any issue being litigated should be conceded or whether upon the basis of the record before the court further settlement conferences should be held with the petitioner and/or the petitioner’s counsel. This is particularly important in cases in which the Service was not aware of all of the facts or evidence prior to the trial of the case. It is also important to examine the record from the standpoint of whether, in winning the issues, bad law would be created, or for some other substantial and justifiable reason, the issues should not be litigated further. Field attorneys should coordinate such considerations with the appropriate Associate Chief Counsel office with subject matter jurisdiction over the underlying issues in the case.

2. If Field Counsel concludes, after trial and before briefs are filed, that one or more of the issues should be settled or conceded, but not the entire case, such settlement agreement or concession will be stated in the respondent’s brief or other appropriate document to be filed with the court. In this instance, the attorney will prepare a Counsel Settlement Memorandum on the settlement or concession, which will be included in the legal file.

3. After briefs have been filed, but before issuance of an opinion by the court, Field Counsel still may decide to settle or concede issues in the case. If briefs in the case were reviewed by an Associate office, the Field Counsel should not take action to settle such issues without first coordinating with the Associate office on whether there is any objection to the proposed settlement or concession. If the whole case or an issue is to be settled or conceded, the attorney will prepare a Counsel Settlement Memorandum. Settlements or concessions at this stage must be carefully monitored in order to avoid conflict with the court. The trial judge should be kept informed of the settlement possibility in a telephone conference or other joint communication. In no event should a last-minute settlement or concession be sent to the court as a surprise that could undercut work already done on an opinion about to be issued.


**35.5.2.13** **(12-31-2012)**

### Action After Opinion or Decision

1. After issuance of an opinion or entry of a decision by the Tax Court, any action inconsistent with the opinion or decision of the court is a highly sensitive and serious matter. Proposed settlement action at this stage requires coordination and approval at the Division Counsel and Associate Chief Counsel level. This is applicable to all settlement decisions, as well as to cases which have been decided on the merits. (See discussion at CCDM 35.9.1.2.4, Motions for Reconsideration of Findings or Opinion). If, after the entry of a decision, the petitioner submits an offer of settlement, such offer together with the recommendation of Field Counsel, should be forwarded to the appropriate Division Counsel and Associate Chief Counsel office for coordination.

2. After a decision of the court has become final, the Tax Court is generally without jurisdiction to vacate or modify in any respect its decision. Therefore, Field Counsel must not enter into any agreement, or make any commitments whatsoever, with respect to the modification of a Tax Court decision after it has become final.

3. Section 7481 authorizes the Tax Court to modify a final decision in an estate tax case solely to reflect the estate’s entitlement to a deduction for interest paid during an extended-payment period on the federal or state estate tax liability. Thus the Tax Court may enter a final decision in an estate tax case in which an extended-payment period is elected and subsequently, if necessary, modify the decision at the end of the extended-payment period to reflect interest actually paid by the estate. The Tax Court has discretion to hold a hearing on this matter at the end of the extended-payment period.


**35.5.2.14** **(08-11-2004)**

### Counsel Settlement Memorandum

1. If Field Counsel proposes to settle or concede an issue or issues, the Field attorney will immediately prepare a Counsel Settlement Memorandum setting forth the issues and the basis for the settlement or concession. The memorandum should be concise, but it should set forth sufficient facts and law to make clear the basis of settlement on each issue settled. In appropriate instances, the legal and factual discussion may incorporate by reference the Appeals transmittal memorandum and case memo and the attorney’s conference memoranda.

2. The memorandum must justify the action taken in the case. If an issue not previously considered by Appeals is settled, the memorandum must set forth the essential facts and the applicable law. If an issue previously considered by Appeals is being settled, the memorandum should include at least the following:



1. A brief summary of the essential facts upon which the decision is based, including any new facts not previously considered by Appeals

2. An appraisal of facts previously considered if it differs from that of Appeals

3. A discussion of the applicable law

4. If an essential factor in the settlement is litigation hazards, such hazards should be set forth and explained


3. If the settlement will affect other years of the same taxpayer not before the court or the tax liabilities of other taxpayers, the memorandum should also discuss the effect on these related matters. In considering the settlement of a year or years that are docketed before the Tax Court, Counsel has no authority to settle a case by taking into account issues from years not before the court that have no relationship to the issues or years before the court.

4. The originals of Counsel Settlement Memoranda prepared by Counsel and addressed to the appropriate Area Director (for Appeals), together with the required number of copies, will be forwarded to the appropriate Appeals office. The initialed copies of these documents will be placed in the legal files, and copies will be furnished to the local Appeals office.


**35.5.2.15** **(08-11-2004)**

### Administrative Processing of Settlements

1. Appeals will prepare all necessary computations in settlements or concessions. In addition to the preparation of the necessary computations, Appeals will process necessary collateral agreements, closing agreements, Joint Committee memoranda, the rejection or approval of outstanding claims for refunds of related taxes, and any other matters affected by the settlement of the issues.

2. Normally, the Counsel Settlement Memorandum should be the basis for Appeals’ preparation of the necessary tax computations and related documents. If, however, it is necessary to have a computation of the tax liability prepared quickly, before the memorandum can be completed, so that a decision can be filed with the court at the trial session, the Field attorney should prepare and forward to Appeals a memorandum setting forth the adjustments to be made in computing the tax liability on the basis of the settlement. In trial session settlements, every effort should be made to have the necessary computations completed so that the decision documents can be filed with the court during the session.

3. Upon the closing by Field Counsel of a case upon the basis of a Counsel Settlement Memorandum, Appeals will prepare and forward to the Service Center the necessary documents and data for assessment and collection of the deficiency or the refund or credit of the overpayment determined in the Tax Court’s decision.


**35.5.2.16** **(12-31-2012)**

### Closing Settled Cases in Field Counsel Offices

1. Upon receipt of the Tax Court’s decision in cases disposed of by settlement, action should immediately be taken in the preparation of the case for closing. The decision should be checked and certified, if accurate, by the Field attorney. See CCDM 35.9.3, Closing Procedures.


**35.5.2.17** **(12-31-2012)**

### Collateral and Closing Agreements

1. It may be necessary as a part of the settlement of a Tax Court case either to obtain a collateral agreement from the petitioner or to enter into a closing agreement in order to cover aspects of the settlement which will not be disposed of by the decision entered in the docketed case. A collateral agreement is an agreement on the part of the taxpayer in consideration of the government’s acceptance of the settlement offered in the Tax Court case. The case law is divided as to whether a collateral agreement legally binds the parties. A closing agreement and a compromise, under sections 7121 and 7122, are the only types of agreements which, under the Internal Revenue laws, are absolutely binding upon both the petitioner and respondent for years not in litigation. See IRM 8.13.1, Processing Closing Agreements in Appeals.

2. Normally, it is advisable to settle only as to the years and parties before the Tax Court and not to tie in either the settlement of other years or a settlement with respect to related taxpayers as a part of the settlement of the docketed case. In some instances, however, it is necessary to consider other years or related taxpayers. This situation may exist in a settlement which shifts income from one year to another or from one taxpayer to another, or in which the settlement determines the amount or basis of depletion or depreciation which would carry over to other years not before the court, or to other similar types of situations. For most cases, a collateral agreement is sufficient. Most petitioners will abide by the agreement for future years, and it will generally be followed by the Service in the determination of the petitioner’s liability for future years. In cases under Appeals’ sole jurisdiction, Appeals will obtain any necessary collateral agreement and will take appropriate action in informing the Area Manager of the terms of the agreement. The Field attorney should obtain any necessary collateral agreement if the settlement is pursuant to a Counsel Settlement Memorandum. In doing so Field Counsel should give consideration to the views of Appeals or the Area Director as to the contents of the collateral agreement. Upon the closing of the case, copies of all collateral agreements should be forwarded to Appeals with a request that a copy thereof be forwarded to the appropriate Area Director.

3. Collateral agreements are unilateral in nature and are not executed by or on behalf of the Service or the Chief Counsel. The agreement will speak for itself, and Field Counsel should not make any specific commitments as to the position of the Service for future years. The agreement should set forth the specific item, with an amount, which the petitioner agrees is taxable income or a deductible item for other years as the consideration for the acceptance of his settlement offer in the Tax Court case.

4. A closing agreement is normally prepared by either the Area Director or Appeals. In settlements reached by Field Counsel, the closing agreement normally will be prepared by or in close consultation with the Field attorney since the attorney is in the best position to know the intent and effect of the settlement. Since the open years to which the agreement will apply may be pending investigation with the Area Director, appropriate coordination should be made with that office and Appeals.

5. The closing agreement should be specific in its terms and should not contain collateral matters which are not a part of the agreement. Matters outside of the agreement itself, or which pertain to a taxpayer not a party to the agreement, but which should be considered in review of the agreement, should be contained in an accompanying memorandum. The closing agreement must not include an agreement as to the amount of tax liability or deficiency for any year over which the Tax Court has jurisdiction since the liability for the docketed years should be fixed by the decision of the Tax Court; but the amount of liability or deficiency may be agreed upon for a nondocketed year. Closing agreements prepared by Appeals or Counsel will be processed in accord with the instructions in the Internal Revenue Manual. Delegation Order 8-3, Closing Agreements Concerning Internal Revenue Tax Liability (IRM 1.2.47.4), and IRM 8.13.1, Processing Closing Agreements in Appeals. For agreements received by the Office of Chief Counsel, see IRM 8.13.1.2.14, Receiving and Reviewing Officers’ Recommendations, as to signatures for the "receiving officer" and the "reviewing officer." As explained in IRM 8.13.1.8, Agreements Processed by the Office of Chief Counsel, the Chief Counsel is authorized (Delegation Order 8-3) to enter into and approve a closing agreement with a taxpayer with respect to any prospective transactions or completed transactions if the request to the Chief Counsel for determination or ruling was made before any affected returns have been filed.

6. The Counsel Settlement Memorandum covering disposition of the Tax Court case will be executed prior to the processing of a proposed closing agreement prepared in connection therewith. The memorandum should include the basis and justification for the Service entering into a closing agreement affecting years not before the Tax Court. If it is finally determined that a closing agreement will not be approved and executed in the case, the case will be processed for disposition solely on the years before the Tax Court, either by trial or settlement. If the petitioner’s offer for settlement of the Tax Court case is contingent upon final approval of a closing agreement, and it is determined that such agreement will not be approved, any previously executed Counsel Settlement Memorandum will be revoked. Thereafter, if the case is settled on a basis covering only the Tax Court years, a new memorandum will be prepared, if necessary.

7. Settlements should be made without closing agreements whenever the revenue can reasonably be protected by collateral agreements. Every effort should be made to expedite the processing of closing agreements in Tax Court cases in order that the time necessarily involved in the additional review and consideration will result in as little delay as possible in the disposition of the Tax Court case.


**35.5.2.18** **(08-11-2004)**

### Settlement of Declaratory Judgment Cases and Worker Classification Cases under section 7436

1. The Tax Court is authorized to issue declaratory judgments with regard to letter rulings issued by the Service in numerous areas, including the determination on all items other than partnership items and affected items (section 6234(c)); status and classification of organizations regarding their exemption from tax (section 7428); worker classification (section 7436); qualification of retirement plans (section 7476); valuation of gifts (section 7477); status regarding tax exemption of certain governmental obligations (section 7478); and eligibility of an estate to make installment payments under section 6166 (section 7479). Declaratory judgment cases arising under sections 7428 and 7476 are generally handled by Field Counsel. Cases arising under sections 7477 and 7478 are relatively rare and almost always require extensive coordination. For these reasons they are typically handled by attorneys from the Associate Chief Counsel office with subject matter jurisdiction over the issues in the case.

2. Declaratory judgment cases should be handled very carefully. They often have wide-ranging application and in many instances, enormous economic impact for affected persons, organizations and the Treasury. Attorneys should not hesitate to seek assistance within the Associate office if they have questions not answered by this chapter.


**35.5.2.18.1** **(12-31-2012)**

#### Exempt Organization Declaratory Judgment Procedures

1. Once a petition has been filed, Counsel acquires exclusive settlement authority. Rev. Proc. 87–24, 1987–1 C.B. 720. In cases in which the Office of Chief Counsel believes concession or settlement is appropriate, this decision should be coordinated with the office of the Commissioner, Tax Exempt and Government Entities Division(TE/GE). Coordination is necessary to insure a proper and complete resolution of all issues, including those raised by the proposed settlement, and to permit the Commissioner (TE/GE), with Field Counsel’s assistance, to draft an appropriate qualification or classification letter to effect the settlement.

2. Because the issues raised in declaratory judgment cases are generally continuing ones, settlement is generally limited to those cases in which all parties agree that the organization either qualifies or fails to qualify for the exemption or classification it seeks. An appropriate stipulated decision can then be submitted to the court. See CCDM 35.8.5.11, Decisions in Declaratory Judgment Cases, for decision documents in settled declaratory judgment cases.


**35.5.2.18.2** **(08-11-2004)**

#### Employee Plan Declaratory Judgment Cases

1. Exclusive jurisdiction in employee plan declaratory judgment cases will vest in the Office of Chief Counsel upon the filing of a petition for a declaratory judgment. Declaratory judgment actions are not settled in the same manner as deficiency cases. Unlike the situation in deficiency cases where the Tax Court determines the facts de novo, its jurisdiction in declaratory judgment cases based on an application for a determination letter is limited to a review of the administrative record upon which the respondent based the determination. In revocation cases, however, which are based on a Form 5500 examination, a case may be resolved on the basis of the administrative record only if the parties agree to such procedure. Furthermore, the Tax Court was not given jurisdiction to adjudicate the qualification of a plan which was not submitted to the Service for an administrative determination. It follows that the court has no jurisdiction to adjudicate the qualification of a plan which is amended after an adverse administrative determination, since the amended plan is, in effect, a different plan as to which there has been neither an administrative determination nor the administratively required preliminary notification to interested parties. Field attorneys should seek assistance on how to proceed from the Division Counsel/Associate Chief Counsel (TEGE) if a Tax Court petition raises these types of issues.

2. As settlements often affect future years as well as past years, and often affect individuals not before the court, all settlements must be carefully considered and extensively coordinated with the Commissioner (TE/GE) and Division Counsel/Associate Chief Counsel (TEGE). Coordination is necessary to ensure a proper and complete resolution of all issues, including those raised by the proposed settlement; to maintain and implement consistent settlement philosophy in employee plan cases; and to permit the Commissioner (TE/GE), with Field Counsel’s assistance, to draft an appropriate qualification or classification letter to effect the settlement. An appropriate stipulated decision can then be submitted to the court.


**35.5.2.18.3** **(08-11-2004)**

#### Governmental Obligation Declaratory Judgment Cases

1. The Office of Chief Counsel has exclusive settlement authority under Rev. Proc. 87–24, 1987–1 C.B. 720, in governmental obligation declaratory judgment cases. Any settlement proposals with respect to adverse rulings involving governmental obligations will be considered by the Division Counsel/Associate Chief Counsel (TEGE), with the understanding that the issuance of an adverse ruling under section 103 under these circumstances is generally a commitment by the Division Counsel/Associate Chief Counsel (TEGE) to defend the ruling.


**35.5.2.18.4** **(12-31-2012)**

#### Worker Classification Cases under Section 7436

1. Settlement of these cases should be coordinated with the Area Counsel (TEGE) or the national office of the Division Counsel/Associate Chief Counsel (TEGE) because of the several worker classification related determinations that the Tax Court addresses in these proceedings. See Exhibit 35.11.1–3, Transfer of Cases and Coordination of Issues With Division Counsel/Associate Chief Counsel (TE/GE), for guidelines on coordination of these cases.


**35.5.2.19** **(08-06-2019)**

### Settlement of Docketed Collection Due Process Cases

1. The settlement of liability issues in CDP cases should be done in a manner consistent with the polices applied in deficiency cases. See CCDM 31.1.1.1.3.1, _Settlement Policies in Deficiency Proceedings_. If Appeals erroneously failed to address liability, the liability should generally be resolved through settlement or trial, as liability is reviewed de novo by the Tax Court. In some instances, though, remand to Appeals for consideration of the underlying liability may be helpful to develop facts or facilitate settlement to avoid further litigation.

2. For non-liability issues in CDP cases, if the administrative record is complete and Appeals did not err or abuse its discretion, Counsel should generally defend the determination.

3. Settlement through acceptance of a collection alternative such as a new offer in compromise or installment agreement where there has been no abuse of discretion by Appeals may be appropriate when it is necessary for the fair treatment of a taxpayer or when a lack of settlement could result in unfavorable legal precedent. Otherwise, the determination should be defended and the taxpayer should be encouraged to submit a collection alternative after the litigation is concluded.

4. Counsel does not have the authority to directly accept collection alternatives from taxpayers on behalf of the Service. If Counsel seeks to settle a docketed CDP case through a collection alternative, Counsel must request the assistance of the Service to evaluate and accept or reject the proposed collection alternative. See IRM 5.8.10.12.2, _Docketed Collection Due Process (CDP) Cases_, for guidance on requesting consideration of offers in compromise in docketed CDP cases.

5. In lieu of settlement, Counsel can consider filing a motion to remand in the instances discussed in CCDM 35.3.23.7, _Motion to Remand_.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-005-002#addtoany "Show all")

A2A