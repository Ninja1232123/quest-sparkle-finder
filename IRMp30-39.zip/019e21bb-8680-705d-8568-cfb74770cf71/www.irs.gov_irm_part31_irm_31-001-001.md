---
url: "https://www.irs.gov/irm/part31/irm_31-001-001"
title: "31.1.1 Legal Work | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part31/irm_31-001-001#main-content)

- 31.1.1  [Legal Work](https://www.irs.gov/irm/part31/irm_31-001-001#idm140645346265904)
  - 31.1.1.1  [General Principles for Handling Legal Work](https://www.irs.gov/irm/part31/irm_31-001-001#idm140645374188096)
    - 31.1.1.1.1  [Determination of Service Position](https://www.irs.gov/irm/part31/irm_31-001-001#idm140645374301216)
    - 31.1.1.1.2  [Policies of the Service](https://www.irs.gov/irm/part31/irm_31-001-001#idm140645346301376)
    - 31.1.1.1.3  [Principles of Litigation](https://www.irs.gov/irm/part31/irm_31-001-001#idm140645374306304)
      - 31.1.1.1.3.1  [Settlement Policy in Deficiency Proceedings](https://www.irs.gov/irm/part31/irm_31-001-001#idm140645374149200)
  - 31.1.1.2  [Roles within the Office of Chief Counsel](https://www.irs.gov/irm/part31/irm_31-001-001#idm140645374292416)
    - 31.1.1.2.1  [Published Guidance](https://www.irs.gov/irm/part31/irm_31-001-001#idm140645374388672)
    - 31.1.1.2.2  [Litigation](https://www.irs.gov/irm/part31/irm_31-001-001#idm140645374418496)
    - 31.1.1.2.3  [Pre-Review of Litigation Documents by the Associate Chief Counsel](https://www.irs.gov/irm/part31/irm_31-001-001#idm140645374402768)
    - 31.1.1.2.4  [Sanctions and Attorneys Fees](https://www.irs.gov/irm/part31/irm_31-001-001#idm140645346297104)
    - 31.1.1.2.5  [Appellate Matters](https://www.irs.gov/irm/part31/irm_31-001-001#idm140645346286912)
    - 31.1.1.2.6  [Tax Court Liaison](https://www.irs.gov/irm/part31/irm_31-001-001#idm140645346310512)
    - 31.1.1.2.7  [Legal Advice](https://www.irs.gov/irm/part31/irm_31-001-001#idm140645343965920)
  - Exhibit  31.1.1-1  [Issues Requiring Associate Office Review](https://www.irs.gov/irm/part31/irm_31-001-001#idm140645343970880)

# Part 31. Chief Counsel Directives Manual Guiding Principles

# Chapter 1. Guiding Principles

# Section 1. Legal Work

* * *

## 31.1.1 Legal Work

#### Manual Transmittal

July 19, 2023

#### Purpose

(1) This transmits revised Exhibit CCDM 31.1.1-1, Issues Requiring Associate Office Review.

#### Material Changes

(1) CCDM 31.1.1-1 is revised to update the items for which Associate Office review is required.

#### Effect on Other Documents

This section supersedes CCDM 31.1.1, dated November 1, 2019.

#### Audience

Chief Counsel

#### Effective Date

(07-19-2023)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**31.1.1.1** **(08-11-2004)**

### General Principles for Handling Legal Work

1. The role of the Office of Chief Counsel is to ensure the correct and uniform application of the tax laws. It is, therefore, the responsibility of each component of the Office, individually and collectively, to ensure that all published guidance, documents filed in litigation, and legal advice issued to the Service or to taxpayers accurately reflect the position of the Office.

2. It is the responsibility of each individual Chief Counsel attorney to ensure the uniform application of the tax laws and the fair disposition of cases. Both objectives require the attorney to thoroughly develop the facts and issues in the case before the trial or settlement of a case or the issuance of advice to any component of the Service. Where there is any doubt regarding the position of the Service, the attorney must request advice from the office or offices responsible for developing and maintaining the Service’s position on the proper interpretation of the section or sections at issue. The overall Service objective of uniform application of the tax laws must be kept in mind to ensure that the correct legal theory is maintained at all times.

3. In interpreting and applying the provisions of the Internal Revenue Code, our responsibilities must be discharged in a balanced and impartial manner, with neither a "Government" nor a "taxpayer" point of view. It is our responsibility to find the true meaning of the statutory provision and not to adopt a strained construction with the goal of maximizing revenue. We properly protect the revenue only when we ascertain and apply the true meaning of the statute.

4. The proper handling of problems of interpretation and application of the tax laws requires cooperation and consultation between the various offices in Chief Counsel, the Operating Divisions and other components of the Service, and the Department of the Treasury. Uniform interpretation requires efforts to arrive at common understanding of the problems involved and efforts to reach common ground for handling these problems. Although each component of the Office has a separate and distinct role to play in achieving our mission, the positions taken must be consistent with the above principles and should reflect a consensus arrived at through close coordination across all Division Counsel and Associate Chief Counsel offices. Anything signed or approved by or in the name of the Chief Counsel must represent the position of the entire office and not merely the position of a particular division or office.


**31.1.1.1.1** **(08-11-2004)**

#### Determination of Service Position

1. Service position, as a general rule, is initially determined in published guidance, which includes regulations (including proposed regulations), revenue rulings, revenue procedures, and notices and announcements published in the Internal Revenue Bulletin. It is important that all documents issued by the Office reflect service positions where it is unclear whether a published position covers a particular situation, the Associate Office with responsibility for the guidance at issue should be consulted.

2. The Office of Chief Counsel will also occasionally transmit procedural guidance or litigating positions through Chief Counsel notices, litigation guideline memoranda (LGMs), or other documents. While such documents are not approved by the Commissioner, and, thus, cannot be relied upon by taxpayers as a statement of Service position, they should not be disregarded by Chief Counsel attorneys. Where it is unclear whether positions set forth in the documents cover a particular situation, the Associate office that issued the document should be consulted.

3. Similarly, Technical Advice Memoranda (TAMs) and Private Letter Rulings (PLRs) can only be relied upon by the particular taxpayer whose case they address. Although not precedential, such documents should be reviewed for discussions of legal analysis as applied to particular factual scenarios. Consultation with the Associate office is appropriate prior to taking a position that appears contrary to the position taken in the TAM or PLR.


**31.1.1.1.2** **(08-11-2004)**

#### Policies of the Service

1. In some instances the terms "policy" and "position" are used in documents interchangeably. Normally, the use of the word "policy" within the Service is confined to those matters in which the Commissioner exercises discretion or has an established policy statement on the matter in question. Thus, the term "policy" should not be used unless the reference is to a matter that is the subject of a policy statement or other document approved by the Commissioner or his delegate. In general, briefs, actions on decision, and legal memoranda should refer to the "position" of the Office. In particular cases, the Office of Chief Counsel may have an established "position" on the law which is to be followed by all Associate Chief Counsel and Division Counsel offices, but it is not generally characterized as "policy." The Chief Counsel may, however, promulgate policies to be followed by the Office in handling matters within its jurisdiction, such as the litigation and settlement of cases.


**31.1.1.1.3** **(08-11-2004)**

#### Principles of Litigation

1. The proper method for conveying the positions of the Office and the policies of the Service is through published guidance. In contrast, litigation should be used as an enforcement tool to advance and defend established positions, not as a vehicle for making policy. The importance of litigation to the administration of the tax law is not measured by the amount of taxes collected through litigation, but rather by its success in defending the Service’s position on the proper interpretation of the tax laws. The position taken in a case must be one that is reasonable based on the facts of the case and one which makes the maximum contribution to a sound tax system. Thus, it is the broad effect of the case which must govern our litigation attitude in specific cases. This litigation policy is applicable to all cases, including those we refer to the Department of Justice.

2. The position taken in any case must represent the official position of the Service, not just the position of a particular division or office. Attorneys as well as supervisors must always take cognizance of the fact that a position taken solely to win a case against one taxpayer may in the future be used by other taxpayers against the Service. These principles apply with equal force even when the sole or primary purpose of the argument is to improve the Government’s position in settlement negotiations. Thus, the development of the litigation position of the Office of Chief Counsel must take into consideration the broad effect of such position as it affects all taxpayers in the administration of the tax laws.

3. In applying the litigation policy of the Office, it may be necessary in particular cases to settle or concede an issue which ordinarily would be litigated. This type of situation usually arises in cases where, under the existing facts and circumstances, it would be unwise to use that case as a vehicle to establish the broad objectives of the Service. Also, where an appellate court has decided an issue in a case contrary to the Service position, it may be necessary to settle or concede the issue in cases appealable to that court until an appropriate case can be litigated in another circuit. These types of cases must be coordinated with the Associate Office or Offices responsible for interpretation of the section or sections at issue. The Associate Office should consider whether guidance is appropriate to help resolve the issue.

4. Consistent with Executive Order 12988 on Civil Justice Reform, it is the policy of the Office of Chief Counsel, unless there are compelling reasons otherwise, to settle or eliminate as many issues as is feasible or justifiable prior to submission of a case for decision by the court. Every effort should be made to settle the issue or issues on which there are no real basic differences between the parties.


**31.1.1.1.3.1** **(08-06-2019)**

##### Settlement Policy in Deficiency Proceedings

1. As part of the Office’s responsibility for defending the positions of the Service in deficiency proceedings, it is the policy of the Office of Chief Counsel that cases and issues being tried in the Tax Court will be settled on the merits. Even when the amount in controversy is small, the Office will defend the Commissioner’s determination and conduct cases in a manner that supports the Service’s tax administration priorities.

2. Settlement on the merits usually involves a stipulation as to each issue before the court. Lump sum or blanket settlements which include tax, penalty, and interest should be avoided, and generally should not be entertained or accepted. The Service has a definite policy against settlements without statutory interest on the deficiency.

3. No case is to be settled on a so called "nuisance basis" either for or against the Government. What constitutes a nuisance settlement is dependent upon the circumstances in each case. When each issue is settled on its merits, the fact that the resulting deficiency is a small percentage of the deficiency amount in the statutory notice does not result in a "nuisance basis" settlement.

4. In keeping with the policy of settling cases based on the merits of the position determined by the Service, collection aspects of a case are not normally considered as part of a Tax Court settlement. Where a collection based settlement can be considered in a manner consistent with the settlement principles outlined above, an offer in compromise based on collectibility can be considered by the Service prior to the conclusion of the Tax Court case. Such offers should only be considered where the taxpayer would be willing to stipulate to the full amount of the deficiency prior to final acceptance of the compromise. For procedures to follow in such cases, see CCDM 35.5.2.6, Collection Aspects of the Settlement.

5. See CCDM 35.5.2.19 for information on settlements in CDP cases specifically.


**31.1.1.2** **(08-11-2004)**

### Roles within the Office of Chief Counsel

1. The role of the Associate Chief Counsel is to develop and maintain the technical positions of the Internal Revenue Service with respect to proper interpretation of the Code. Associate offices fulfill this role principally through the issuance of published guidance, the legal review of proposed policies and procedures, the issuance of program advice and other advisory products and the review of positions to be taken in the courts in the course of litigation.

2. The role of the Division Counsel is to provide legal service to specific components of the Service through litigation on their behalf, providing legal advice in specific cases, and providing strategic advice to the executive leadership of those components. Division Counsel develops and executes litigation strategy and provides legal advice based on the technical positions developed and announced by the Associate Chief Counsel.

3. To the extent that a regulation or ruling does not provide clear guidance on the position of the Service, or that position is not clear from existing case law or the unambiguous language of the Code, the Division Counsel or Associate Chief Counsel must seek advice from the Associate office with responsibility for the subject matter at issue. Coordination is particularly important where there has been a statutory change, new regulations have been issued, published guidance is pending, or there has been a significant new court opinion.


**31.1.1.2.1** **(08-11-2004)**

#### Published Guidance

1. Published guidance generally refers to that body of guidance that sets forth the definitive position of the Service, as approved by the Commissioner and the Department of the Treasury. Published guidance must be followed by all components of the Service and can be relied upon by taxpayers in litigation. For purposes of this section, published guidance includes treasury decisions, notices of proposed rulemaking, revenue rulings, revenue procedures, and Internal Revenue Bulletin notices and announcements.

2. The Associate Chief Counsel is responsible for the development and issuance of all published guidance. In the course of drafting published guidance, the Associate Chief Counsel is charged with building a consensus among all interested parties within the Department of the Treasury, including other offices within Counsel, the operating divisions and other components of the Service, and the Office of Tax Policy, and with elevating significant, unresolved issues to the appropriate official for determination. To the extent necessary, the Associate Chief Counsel is also responsible for coordinating with other Federal agencies, such as the Department of Justice.

3. The Division Counsel has two key roles to play in the development and issuance of published guidance.



1. Although the Associate Chief Counsel will be primarily responsible for identifying the need for published guidance based on new legislation and the Service’s program level needs, the Division Counsel is uniquely qualified to identify areas of the law that are unclear to both taxpayers and the Service in the day-to-day resolution of cases. The Division Counsel should bring such issues to the attention of the appropriate Associate and begin a dialogue that will result in issuance of appropriate published guidance.

2. Published guidance should reflect not only the correct interpretation of the law, but also the practical realities of applying the law in the course of administering the tax system. Division Counsel should contribute to the published guidance process by advising the Associate Chief Counsel on the Service’s ability to apply the proposed guidance as a practical matter.


**31.1.1.2.2** **(08-11-2004)**

#### Litigation

1. Division Counsel has primary responsibility for the litigation of cases in the Tax Court and the referral of general litigation and refund cases to the Department of Justice. In this role, Division Counsel is responsible for development and execution of litigation strategy, including selection of cases to litigate, whether to try or settle particular cases, whether to agree to mediation/arbitration, whether to employ expert witnesses, etc.

2. In the course of litigation, Division Counsel must determine that the position to be advanced in Tax Court or other litigation accurately reflects the Service’s position on the law. To the extent that position is unclear, Division Counsel must coordinate with the appropriate Associate Chief Counsel. This coordination may be accomplished through informal or formal advice procedures, as appropriate for the issue or case.


**31.1.1.2.3** **(06-03-2014)**

#### Pre-Review of Litigation Documents by the Associate Chief Counsel

1. In general, documents to be filed in Tax Court, as well as letters to the Department of Justice regarding the prosecution or defense of cases in the bankruptcy or district courts, will not be subject to pre-review by the Associate Chief Counsel. Mandatory pre-review of such documents will, however, be required where:



1. The continued development of the Service’s position on either the law or the appropriate use of a particular type of motion or other procedural mechanism warrants close coordination between field counsel and national office subject matter experts;

2. The case raises novel or significant issues. Novel or significant issues include issues relating to recently enacted legislation, issues of first impression, and issues relating to the validity of a regulation or revenue ruling; or

3. The document to be filed or the proposed letter to the Department of Justice advocates a position contrary to the position taken in published guidance or attempts to distinguish a case from a position taken in published guidance based on the facts of the case.


2. The Associate Offices, in conjunction with Division Counsel, will establish a list of issues in which pre-review will be required. This will ensure that uniform positions and procedures are adopted and that the published guidance being prepared by the Associate Office is informed by the practical information to be derived from this review. The Associate Chief Counsel and Division Counsel will consult regarding the prompt removal of any pre-review requirement once the Service’s position has become sufficiently established that pre-review is no longer necessary. For a list of issues for which pre-review is mandatory, see Exhibit 31.1.1-1, Issues Requiring Associate Office Review, and Exhibit 35.11.1.-1, Issues Requiring Associate Office Review. Each office is, however, responsible for determining whether pre-review or coordination is warranted based on the standards articulated in paragraph (1), above, regardless of whether the case involves an issue specifically included on the established pre-review list. In addition certain Tax Court documents require review by the Associate Offices.


**31.1.1.2.4** **(08-24-2012)**

#### Sanctions and Attorneys Fees

1. As provided in Executive Order 12988 on Civil Justice Reform, a motion for sanctions must be reviewed by the agency sanctions officer. This includes motions by the Government asking the court to sanction opposing parties, as well as motions by opposing parties seeking sanctions against counsel, the United States, the Service, or its employees. The Associate Chief Counsel (Procedure and Administration) is the designated sanctions officer for the Office of Chief Counsel.

2. Sanctions subject to review by the sanctions officer under the Executive Order include motions to sanction a taxpayer’s representative for violations of section 6673(a)(2), sanctions under the Tax Court Rules of Practice and Procedure, and sanctions based on the Tax Court’s inherent power to regulate conduct in cases that come before it, including any such sanctions imposed or sought to be imposed against Chief Counsel attorneys or Service employees.

3. In addition to the review required by the Executive Order, it is the policy of the Office that certain other matters involving sanctions will also be subject to pre-review by the Sanctions Officer. Those matters include letters advising opposing counsel of a potential conflict of interest or of a potential motion to disqualify based on a conflict, letters to the Department of Justice recommending that sanctions be sought against an opposing party, and any referral of a private practitioner to the IRS Office of Professional Responsibility. Requests for imposition of the section 6673(a)(1) penalty and motions for attorneys fees (unless involving alleged misconduct by counsel) are generally not subject to Sanctions Officer procedures. Procedures for obtaining the required review are found at CCDM 35.10.2.2.3, Sanctions Requiring National Office Review.


**31.1.1.2.5** **(08-24-2012)**

#### Appellate Matters

1. Adverse decisions of the Tax Court, Federal District Courts, the Court of Federal Claims, and the Courts of Appeals will be reviewed by the appropriate Associate Office which will prepare a letter to the Department of Justice recommending for or against appeal. Procedures for preparing appeal recommendations can be found in CCDM 36.2, Appeal/Certiorari Recommendations.


**31.1.1.2.6** **(08-11-2004)**

#### Tax Court Liaison

1. Procedural issues relating to practice before the Tax Court cut across all divisions and offices. In order to maintain uniformity in this area, the Associate Chief Counsel (Procedure and Administration) acts as the Office’s liaison with the Tax Court and the Court of Federal Claims and is responsible for matters of Tax Court procedure.


**31.1.1.2.7** **(08-24-2012)**

#### Legal Advice

1. Division Counsel offices are responsible for providing legal advice relating to case development to their respective clients. Such advice is not subject to pre-review by the Associate Chief Counsel except to the extent consultation is necessary to determine the position of the Service. For procedures regarding pre-review of legal advice, see CCDM Part 33, Legal Advice.

2. Associate offices are responsible for providing legal advice to the Operating Divisions, other components of the Service, and Division Counsel regarding the technical position of the Service with respect to proper interpretation of the Code.

3. Occasionally, the field client will request case-specific advice directly from the Associate Chief Counsel, rather than going to local Division Counsel, or may turn to local Division Counsel for advice on matters of interpretation of the Code that may be of national application. In such cases, the receiving office should review the request and either forward the request to the appropriate office or coordinate the response as appropriate.


**Exhibit 31.1.1-1**

### Issues Requiring Associate Office Review

Certain issues listed below by respective Associate office require National Office review. An issue on the Associate office review list must be coordinated regardless of the stage of the case in which the issue arises ( _e.g._, whether in examination or in litigation). Coordination on these issues should be commenced at the earliest opportunity and well before litigation, if possible.

### Note:

With respect to “S” cases it is recognized that coordination might take place later than normally expected with regular cases, typically after they are returned from Appeals.

Advice issued to the client, briefs and motions filed with the Tax Court, and suit and defense letters sent to the Department of Justice must reflect positions consistent with Service legal positions and policies and uphold the office’s reputation for the highest quality of written product. In order to ensure these attributes, documents involving novel or significant issues contained on the Associate office review list will be reviewed in Associate offices before issuance or filing of the document. The Associate Chief Counsel and Division Counsel will consult regarding the prompt removal of any pre-review requirement once the Service’s position has become sufficiently established that pre-review is no longer necessary.

The issues list set forth below contains both generic and specific significant issues. Any issue included on either list must be coordinated with the affected Associate offices. Although some Associate offices may not have a specific issue list, coordination of generic significant issues with those offices is required and should be done at the earliest opportunity. Also refer to the Significant Case Program coordination procedures at CCDM 31.2.1.1 for additional guidance for additional items that may need to be coordinated with Division Counsel.

There are issues that do not require Associate office review. An issue not described in the generic or specific significant issues list is presumed not to require Associate office review. Court documents that contain no issues requiring Associate office review and that are not of a nature that requires Associate office review may be filed directly without Associate office review. Defense and suit letters that do not contain issues on this list may be sent to the Department of Justice without Associate office review regardless of their classification as Standard or S.O.P. See CCDM 34.8.1, Settlement Procedures Overview.

Even though a case does not contain any of the issues described below, novel, unusual, or unique questions may be presented. The Division Counsel office is expected to communicate informally with the appropriate Associate office when these issues arise. In some cases, the Associate office will want to review certain documents before they are filed or issued. It is the responsibility of the attorney and the reviewer in the Division Counsel office to identify those issues that warrant review by an Associate office and to forward the document for both pre-review and review according to current procedures. For those briefs, motions, and letters that are directly filed or sent to the Department of Justice by the Division Counsel office, it is the responsibility of the Division Counsel reviewer to ensure that they are correct factually and legally and of the highest quality. In addition, attorneys and reviewers in Division Counsel are still required to perform any necessary substantive issue coordination among Division Counsel offices pursuant to existing issue coordination procedures.

When an issue is identified as significant and requires coordination, it is the responsibility of the Division Counsel office to seek and the Associate offices to provide timely advice. All such requests, and any advice provided, should generally be in writing. Generally, the Division Counsel and Associate office attorneys will come to an agreement with respect to the timing of the advice that will be given, and if an agreement cannot be reached, then the issue should be elevated through the respective management chains. In exigent situations, such as an expiring statute of limitations or court deadline, the Division Counsel and Associate office attorneys should discuss the urgency for the advice, and the advice should be provided by the Associate office in sufficient time to take the appropriate action before the exigent event. If the advice is not timely sought by the Division Counsel office, or is not timely provided by the Associate office, the Division Counsel office may proceed with the proposed position subject to modifying or changing the position, as appropriate, to reflect the correct legal position after the advice request has been fully considered and coordinated. Before doing so, however, the Division Counsel office must notify the appropriate Associate office and their Division Counsel of their intent to do so. The attorney in the Associate office who receives such notice must promptly notify his or her Associate Chief Counsel of the Division Counsel office’s intent. The failure to timely seek or provide advice when circumstances would have permitted timely coordination is a performance issue that should occur only in rare circumstances. It should be addressed at the management level. This will typically require a post-filing review of the circumstances leading to the event and a discussion between the relevant Division Counsel and Associate Chief Counsel as to how to prevent a reoccurrence.

### Note:

The below list of issues, code sections, and documents requiring Associate office review is also contained in Exhibit 35.11.1-1.

**I. Generic Significant Issues that Require Associate Office Review with the Affected Associate Office**

An issue will be significant such that it requires relevant Associate office review regardless of the underlying code section or subject matter if it involves any of the following:

01. The validity of a regulation, temporary regulation, revenue ruling, revenue procedure, or other published guidance item (coordination with P&A also required).

02. An issue of importance to tax administration, such as:


     a. An issue of first impression;


     b. An interpretation of a statute or regulation when there have been no prior judicial opinions addressing the interpretation, including the Inflation Reduction Act, Pub. L. No. 117-169; and the Tax Cuts and Jobs Act, Pub. L. No. 115-97;


     c. An issue affecting large numbers of taxpayers or an industry; or


     d. An issue falling within an operating division’s major strategic goal.

03. An issue likely to attract congressional or public attention on a national level.

04. An issue where the Government attempts to distinguish a regulation, proposed regulation, temporary regulation, revenue ruling, or revenue procedure.

05. A position that is inconsistent with a proposed Treasury regulation.

06. A change in litigation position as identified in a Chief Counsel Notice.

07. An argument contrary to Chief Counsel advice.

08. Any statute or statutory amendment that has been enacted within the year preceding the filing date of the document or the due date of the letter to the Department of Justice.

09. Nonfrivolous constitutional challenges to statutes, regulations, published guidance or Service administrative practices or any nonfrivolous assertion of the application of the Religious Freedom Restoration Act. Examples of frivolous constitutional issues that need not be reviewed are contained in The Truth About Frivolous Tax Arguments that can be found at https://www.irs.gov/privacy-disclosure/the-truth-about-frivolous-tax-arguments-introduction.

10. Issues appearing on the current Priority Guidance Plan (PGP) of pending published guidance projects. The current PGP can be found at https://www.irs.gov/uac/priority-guidance-plan.

11. An issue considered for designation for litigation under CCDM 33.3.6, which is subject to the separate procedures under that section that control the coordination between the Division Counsel and Associate offices.

12. An issue that will not be referred to Appeals under Rev. Proc. 2016-22, 2016-15 I.R.B. 577, sec 3.03, for a technical tax reason, as opposed to a strategic or tactical reason involving the preparation and trial of the case, if the issue is otherwise considered significant.

13. Matters to be submitted to the Justice Department Office of Legal Counsel.


**II. Other Specific Issues Requiring Review by an Associate Office**

In addition to the foregoing issues, the following specific issues require review by an Associate office:

CNTA

1. Section 7803(a)(3) (execution of duties in accord with taxpayer rights).

2. Section 7803(c) (Office of the Taxpayer Advocate).

3. Section 7811, including the authority to issue a Taxpayer Assistance Order and the tolling of the statute of limitations.


Corporate

01. Section 267(f) (deferral of loss resulting from corporate related-party sales or exchanges).

02. Section 269 (acquisitions made to evade or avoid income tax).

03. Stock basis shifting transactions (for example, situations in which the seller shifts basis to a small number of remaining shares after a stock redemption or section 304 transaction).

04. Section 331/332/Granite Trust transaction, specifically situations in which 80% shareholder sells part of stockholdings to a related or accommodation party then engages in a section 331 liquidation.

05. Section 351 (formation of a corporation) with repatriation transaction.

06. Section 355 (spin off transactions), specifically:


     a. The device factor relating to nature and use of assets as described in Notice 2015-59;


     b. The weighing of significant device factors (other than pro rata distributions) with business purpose;


     c. Planned sales of stock after the transaction;


     d. Retention of Controlled corporation stock by the Distributing corporation after the transaction;


     e. Distribution of the stock of a Controlled corporation in a transaction potentially subject to section 355, and, as part of the same plan, the Distributing corporation or the Controlled corporation liquidates into or merges with the parent corporation or another related corporation (i.e., **drop-spin-liquidate** and **drop-spin-merge**);


     f. Delayed payments of debt or distributions to shareholders related to a spin off (i.e., delay in **boot purge** in a D/355);


     g. Spinoff transactions that are structured to allow the distributing group to claim losses on distribution but still qualify under section 355; or


     h. Distributing corporation debt to be retired with Controlled corporation securities.

07. Transactions that do not qualify under section 332 or section 355 but are intended to be tax-free reorganizations in reliance on §1.368-2(k) (e.g., corporate subsidiary elects to be a disregarded entity, distributes an appreciated asset to its parent, then elects to be taxed as a corporation or converts back into a corporation in the same state or in a different state).

08. Section 385 (debt v. equity) especially related party intercompany debt created or utilized as part of a larger structured transaction.

09. Section 482, specifically situations in which the parties involved are domestic.

10. Situations in which a subsidiary corporation, either directly or indirectly, owns stock of its parent (i.e., "hook" stock).

11. Situations in which an issuing corporation issues stock to its 100 percent shareholder that tracks the economic performance of a lower-tier entity (i.e., "tracking" stock), including any transactions in which the holder of the tracking stock claims an ordinary worthless stock loss under section 165(g)(3).

12. Intercompany debt transactions that inflate basis when debt is moved outside the consolidated group.

13. Situations relating to transactions involving Special Purpose Acquisition Companies (SPACs), including formation, acquisitions, capital raising, and wind-ups.

14. Situations in which a taxpayer uses nonqualified preferred stock (NQPS) as defined in section 351(g) to obtain benefits to which it otherwise would not be entitled.

15. A rescission of any or all of a corporate transaction pursuant to Rev. Rul. 80-58, 1980-1 C.B. 181.

16. Transactions under CC:CORP’s jurisdiction in which statutory economic substance and judicial doctrines (including economic substance, substance over form, and other common law doctrines) might be asserted.


Income Tax and Accounting

01. Section 36B refundable credit for coverage under a qualified health plan, limited to coordination when a case with an issue of first impression is nearing trial, including review of pretrial memorandums, motions for summary judgment, draft stipulations of facts, and briefs.

02. Section 61(a)(12), limited to issues involving whether a discharge or forgiveness of a liability is one for which the taxpayer did not receive a previously untaxed accession to wealth (for example, the taxpayer did not receive loan proceeds or the liability was under a guaranty, indemnity or similar agreement).

03. Section 108(a)(1)(B), limited to whether an interest in a retirement plan is an asset for purposes of applying the insolvency exclusion.

04. Section 162, limited to deductibility of a payment of a shareholder’s expenses in the context of a corporate reorganization or buyout and unreasonable compensation in the context of mergers or buyouts or golden parachute payments.

05. Section 163, limited to deductibility of mortgage interest following a foreclosure or short sale of the underlying property.

06. Section 170 charitable contribution deductions involving quid pro quo issues for contributions to churches or religious organizations.

07. Section 274(a), except where the issue is whether an activity constitutes entertainment, amusement, or recreation, or where the issue is the deductibility of country club dues; section 274(d), except where the substantiation issue is strictly factual; section 274(e); section 274(g); section 274(k); section 274(l); section 274(m); and section 274(n).

08. Section 460, limited to issues involving (1) completion year in the case of a contract for the construction and sale of a home in a development, or (2) whether a real estate developer that constructs infrastructure and amenities, but not homes, qualifies for the home construction contract exemption.

09. Section 1400Z-2, regarding special rules for capital gains invested in Opportunity Zones.

10. Section 5000A requirements to maintain minimum essential coverage, where the shared responsibility payment is raised as an issue and not merely a computational adjustment, including the issue of whether it is an excise tax or penalty for purposes of bankruptcy priority, and decisions in deficiency cases that require below-the-line language due to an adjustment to the shared responsibility payment and involve an overpayment in tax.

11. Section 6055 reporting of health insurance coverage.

12. Issues involving digital assets, including virtual currency, digital currency, crypto-assets, and cryptocurrency, not addressed by Notice 2014-21 or other public guidance, involving novel issues or issues likely to attract national attention, unless the issue only involves substantiation.


International

01. Issues arising under international provisions of the Tax Cuts and Jobs Act (TCJA) and international issues arising under the Inflation Reduction Act of 2022 (IRA 22).

02. International aspects of the corporate alternative minimum tax (sections 55, 56A, and 59).

03. Issues arising under U.S. income tax treaties, estate and gift tax treaties, or other international agreements (including IGAs and TIEAs), and sections 894, 898 and 7852(d).

04. Issues arising under section 482 (transfer pricing) and related portions of section 6662(e).

05. Issues arising under section 367 or section 721(c) (other than routine issues).

06. Characterization and non-routine sourcing of income under Subchapter N.

07. U.S. nexus and related rules including trade or business, ECI and branch profits tax, and FIRPTA (sections 864, 872-875, 882-884, 897, 1445 and 1446) (other than ancillary computational issues or routine compliance issues).

08. Issues involving foreign governments (sections 892, 893, and 895).

09. Matters involving international shipping and air transport (sections 883, 887 and related international agreements (equivalent exemptions)).

10. Availability of and limitations on foreign tax credits (other than ancillary computational issues).

11. Non-routine matters involving controlled foreign corporations or their U.S. shareholders (sections 951-965) or PFICs or their U.S. shareholders (sections 1291-1298).

12. Foreign currency issues (other than translation issues) arising under sections 985-989.

13. Chapters 3 and 4 withholding on foreign persons and accounts (sections 871, 881, and 1441-1474).

14. Issues involving U.S. territories.

15. Non-routine issues involving the residence or expatriation of individuals (sections 877, 877A, and 7701(b)).

16. Issues involving the expatriation of corporations (section 7874) (other than ancillary computational issues).

17. International information gathering issues arising with respect to summonses issued pursuant to a tax treaty or other international agreement, quashes or enforcement of formal document requests (section 982), and enforcement of requests for foreign documents under section 6038A(e).

18. Contact with individuals physically located in a foreign jurisdiction, including requests for documents, interviews, depositions, or participation in formal or informal proceedings.

19. Non-routine issues involving dual consolidated losses (section 1503(d)).

20. Issues involving cross border debt equity (section 385).

21. Non-routine issues involving foreign trusts and foreign gifts (subchapter J and sections 6048, 6039F, and 6677).

22. Issues involving insurance excise tax (section 4371).

23. Economic substance and common law doctrines relating to international matters.


Passthroughs and Special Industries

01. A tax shelter that is a listed transaction within the description in Treas. Reg. §1.6011-4(b)(2). Issues concerning reportable transactions, partnership arguments and judicial doctrines. In the case of syndicated conservation easement transactions described in Notice 2017-10, 2017-4, I.R.B. 544, issues involving section 170 do not require Associate office review unless such transaction involves a novel, unusual, or unique question under section 170.

02. Valuation of interests in closely-held entities such as partnerships, S-corporations and LLCs.

03. Chapter 49 and sections 9008 and 9010 of the Affordable Care Act

04. Sections 513, 543 and 613 regarding rents and royalties paid for oil and gas interests or whether payments to tax-exempt organizations constitute rent or royalties.

05. Sections 2501, and 2512, and Treas. Reg. § 25.6019-4 - the treatment of pecuniary (defined value) transfer clauses for gift tax purposes.

06. Sections 4001 through 4907 -excise taxes in chapters 31, 32, 33, 35, 36 subchapters B and D, 38, and 40.

07. Sections 6415, 6416, 6426, and 6427 – certain excise tax refunds and credits.

08. Treas. Reg. § 1.701-2 – Partnership Anti-Abuse Rule.

09. Estate and gift tax treatment of split-dollar life insurance agreements.

10. The treatment of taxes for valuation purposes, i.e., tax-affecting..

11. Section 199A except where the only issue is whether there is a trade or business under section 162.

12. The recharacterization of long term capital gains as short term capital gains under section 1061 with respect to certain partnership interests granted in connection with the performance of services.

13. Disguised fee for services under section 707(a)(2)(A).

14. Basis adjustments under sections 734(b), 743(b), or 732 resulting from a transfer of a partnership interest in a non-recognition transaction or distribution of partnership property involving related parties under section 267 and 707(b).


Procedure and Administration

01. The applicability of the Administrative Procedure Act.

02. Section 7421 (Anti-Injunction Act) – where a suit does not facially seek to enjoin a tax assessment or collection but a defense letter recommends asserting the AIA on the ground that that is the suit’s purpose in substance; or where a suit seeks to enjoin the exam process, such as the issuance of a summons.

03. Challenges to the jurisdictional nature of a statutory deadline or claims that a deadline is subject to equitable tolling.

04. The untimely filing of a petition in a CDP case (except when raised in answers, Rule 37(c) motions, and stipulated decisions sustaining the determination by Appeals).

05. Bankruptcy issues under 11 U.S.C § 523(a)(1)(B)(i) involving a Form 1040 filed after the due date.

06. Any suit letter recommending that the Government:


     a. Join with other creditors to commence an involuntary bankruptcy case against an individual, partnership, or corporation; or


     b. File an objection to confirmation under 11 U.S.C. § 1129(d) on the ground that the principal purpose of the plan is tax avoidance.

07. Injunction, mandamus, or declaratory judgment sought by the Government. Preparer/promoter injunction referrals and injunctions to prevent pyramiding, however, do not require Associate office review unless the case involves a novel substantive issue.

08. Novel privilege issues involving informants, including confidentiality, disclosure, third-party contacts, and the government informant’s privilege.

09. Sanctions officer issues, including misconduct on the part of Service employees or Division Counsel or opposing counsel, disqualification of counsel, recusal or disqualification of judges, referrals to the Office of Professional Responsibility, section 6673(a)(2) penalty against counsel for unreasonable or vexatious multiplication of proceedings in Tax Court or other ethical issues in litigation.

10. Any constitutional or conscience-based objections to the use of a Social Security Number (SSN) or Taxpayer Identification Number (TIN).

11. Novel issues related to same-sex marriage.

12. Protective orders:


     a. Any motion for protective order to be filed under T.C. Rule 103 and/or section 7461, except a routine protective order filed during whistleblower litigation, regardless of whether petitioner consents or opposes;


     b. Any proposed statement of agreement, consent, or "no objection" to the granting of a petitioner’s motion for protective order under T.C. Rule 103 and/or section 7461 (see CCDM 35.4.6.5); or


     c. Any motion for protective order with a covered entity as defined by 45 CFR § 160.103 of the HIPAA regulations, regardless of forum.

13. Disclosure issues - production of congressional materials in discovery and deliberative process privilege claims for records over 25 years old.

14. "Clawback" agreements and inadvertent production claims:


     a. Any proposed court order under Fed. R. Evid. 502(d) or non-waiver agreement under Fed. R. Evid. 502(e) that purports to protect from waiver any privilege other than the attorney-client privilege or the work product doctrine, or to modify the IRS’s obligation under section 6103; and


     b. Any demand for return of documents produced to the IRS in discovery on the ground that it was inadvertently produced privileged material pursuant to Fed. R. Civ. P. 26(b)(5) or any other rule or order of court, where Chief Counsel is considering refusing to acquiesce in the demand.

15. Alternative dispute resolution - requests or agreements to seek arbitration or mediation in any docketed Tax Court cases.

16. Section 6015 - the effect on the allocation of a deficiency under section 6015(c) due to the tax benefits rule of section 6015(d)(3)(B); res judicata and meaningful participation under section 6015(g)(2); claims solely for relief from unpaid interest or penalties; untimely Tax Court petition (stand-alone cases); jurisdiction in the Federal district courts; and cases in which the trial attorney and manager believe that the evidence does not warrant following the Service’s determination to grant relief.

17. Section 6050W – requirement to file information returns for payment card and third party network payments on Form 1099-K, including penalties for failure to file and for filing incorrect returns.

18. Section 6109 – the issuance or use of individual taxpayer identification numbers (ITINs) after the effective date of section 203 of the PATH Act of 2015.

19. Sections 6221 through 6241 –


     a. The interpretation of or validity of an action taken under the centralized partnership audit regime enacted by the Bipartisan Budget Act of 2015 sec. 1101 of the BBA).


     b. TEFRA: Foreign withholding under chapters 3 and 4.

20. Section 6306 – contracting for collection services.

21. Section 6330 and 6320 collection due process – briefs, motions, and other Tax Court documents raising novel or significant issues. Issues that are considered novel or significant include (but are not limited to):


     a. Challenges to the admission of evidence based on the administrative record rule;


     b. Whether challenges concerning validity of assessment, periods of limitation, or the application of payments and credits are liability issues under section 6330(c)(2)(B).


     c. Issues involving whether a notice of determination was issued in violation of the bankruptcy automatic stay; and


     d. Issues involving whether the untimely filing of a request for CDP hearing in Appeals or petition in Tax Court in response to a notice of determination is subject to equitable tolling.

22. Section 6332(d)(2) – penalty for failure to honor levy.

23. Section 6404(g) – Tax Court jurisdiction over interest suspension (Corbalis issue).

24. Sections 6601 and 6611 issues involving restricted interest; section 6621 issues involving the appropriate interest rate to be used; section 6621(d)(interest netting); Tax Court motions to redetermine interest; suits for additional overpayment interest filed in the Court of Federal Claims or District Court.

25. Section 6751(b) – issues concerning the timing of written supervisory approval of penalties where supervisory approval would not be timely under existing Tax Court precedent that is being challenged; and any other supervisory approval issue either not directly addressed by Tax Court precedent or on which Tax Court precedent is being challenged (Graev/Chai/Clay issues).

26. Closing agreements (section 7121) involving novel or significant issues, such as:


     1\. Section 482 transfer pricing issues;


     2\. New partnership audit and adjustment provisions in Bipartisan Budget Act of 2015;


     3\. Delegation order challenges;


     4\. Consent to publicize a closing agreement.

27. Section 7345 – revocation or denial of passport.

28. Section 7430 – issues relating to section 7430; answer to petitions including requests for costs; any purported qualified offer; motions for costs; responses or briefs filed in opposition to taxpayers’ motions for costs; settlements of section 7430 claims regardless of whether authority for approval is required. For more specific coordination requirements in section 7430 matters, see CCDM 35.10.1.

29. Section 7602 – limited to designated summonses, John Doe summonses, summonses to third parties for foreign-based records (so-called Bank of Nova Scotia summonses), LB&I promoter summonses, summonses for audit or tax accrual workpapers, cases where section 7612, the Right to Financial Privacy Act or Health Insurance Portability and Accountability Act has been argued in a suit to enforce or quash summons, cases where the government advocates assertion of the tax shelter exception of section 7525(b).

30. Section 7623 whistleblower matters (including briefs, motions, and other Tax Court filings) involving novel or significant issues or any disclosure regarding the existence or identity of a whistleblower. Issues that are considered novel and significant include: non-routine privilege and taint issues, motions to compel information protected by section 6103, post-decision enforcement of protective orders, any arguments requiring an interpretation of the statute, and any arguments requiring an interpretation or application of the regulations.

31. Section 7701(o) – the application of the codified economic substance doctrine under section 7701(o) in novel cases.


Employment Taxes

01. Issues regarding scope of Additional Medicare Tax under FICA, RRTA, or SECA including decisions that contain language referencing the AdMT.

02. Section 107 – exclusion for parsonage or parsonage allowances.

03. Section 1402(a)(13) – whether any partner of a federal tax partnership (including state law LPs, LLCs, LLPs, etc.) is a limited partner for purposes of the exclusion from self-employment tax under section 1402(a)(13).

04. Sections 3131 – 3133 – issues involving leave credits for qualified sick and family leave wages under sections 3131 through 3133 of the Code or the FFCRA.

05. Issues involving credits allowed to self-employed individuals for qualified leave equivalent amounts as provided by the uncodified sections 7002 and 7004 of FFCRA or the uncodified sections 9642 and 9643 of ARP.

06. Section 3134 - issues involving the employee retention credit under section 3134 of the Code or section 2301 of the CARES Act.

07. Section 3231(e) – definition of "compensation" under RRTA.

08. Section 3401(d)(1) – issues regarding identification of employer in control of the payments of the wages.

09. Section 3504 – issues involving application of Treas. Reg. § 31.3504-2.

10. Section 3511 – determination of liability if a Certified Professional Employer Organization is involved.

11. Section 7705 – issues regarding CPEO certification, suspension or revocation.

12. Section 6432—issues involving the COBRA premium tax credit under the American Rescue Plan Act of 2021.

13. Issues involving the deferral of the employer portion of social security tax under section 2302 of the CARES Act.


Employee Plans/Qualified Plans/Executive & Nonqualified Deferred Compensation/IRAs

01. Section 72(t) – exceptions to the 10% additional tax.

02. Sections 401 through 418 – qualification issues for employee benefit plans involving diversion or misuse of plan assets, egregious failures relating to coverage, nondiscrimination, or benefit limitations, and deductions issues for employee benefit plans involving non-cash contributions.

03. Section 402/408 – failure to roll over within 60 days.

04. Section 409(l)(3) and 409(p) – issues involving preferred stock or synthetic equity.

05. Section 409A – issues involving nonqualified deferred compensation plans.

06. Section 414(e) – definition of a church plan.

07. Section 420 – transfer of excess pension assets to retiree health accounts.

08. Section 457A – issues involving nonqualified deferred compensation plans of nonqualified entities.

09. Section 457(b) - eligible deferred compensation plans.

10. Section 457 (f) – ineligible deferred compensation.

11. Section 4971 – pension underfunding taxes in bankruptcy cases.

12. Section 4975 – issues involving prohibited transactions, including transactions involving qualified plans and individual retirement arrangements (IRAs).

13. Section 4980 - tax on reversions from a qualified pension plan when there is a transfer of 401(h) account assets (retiree medical account in the defined benefit plan) upon termination of a pension plan.

14. Section 4985 – excise tax on stock compensation on insiders of inverting corporations.


Health and Welfare Plans

01. Section 45R – employee health insurance expenses of small employer.

02. Section 51 – Work Opportunity Credit and controlled group rules under section 52.

03. Section 79 – issues involving group term life insurance plans utilizing cash value life insurance policies.

04. Section 501(c)(9) – voluntary employees’ beneficiary associations (VEBAs), but only issues involving multiple employer plans.

05. Section 512(a)(3)(E) – unrelated business taxable income (UBTI) for voluntary employees’ beneficiary associations (VEBAs).

06. Section 4976 – excise tax on welfare benefit funds providing a disqualified benefit.

07. Section 4980B – excise tax for failure to satisfy continuation coverage requirements of group health plans.

08. Section 4980D – excise tax for failure to meet certain group health plan requirements.

09. Section 4980H – shared responsibility payment for employers regarding health coverage.

10. Section 6056 – certain employers required to report on health insurance coverage.


Government Entities

1. Issues regarding identification of taxpayers as federal, state or local governments or Indian Tribal Governments.


Tax Exempt Organizations

01. Section 501(c)(3) – issues involving internet churches or schools.

02. Section 501(c)(3) – issues involving health maintenance organizations.

03. 501(c)(3) and 501(c)(4)—issues involving an accountable care organization’s initial or ongoing qualification as an organization described in section 501(c)(3) or 501(c)(4).

04. Sections 501(c)(3) and 511-514 – issues involving joint ventures or partnerships.

05. Sections 501(m) and 511-514 – issues involving commercial type insurance.

06. Section 501(r) – additional requirements for certain hospitals.

07. Section 509(a)(3) – issues involving whether supporting organizations satisfy the relationship test.

08. Section 512 – issues involving unrelated business taxable income (UBTI) and voluntary employee beneficiary associations (VEBAs).

09. Section 529A – Qualified ABLE Programs.

10. Section 4958 – excess benefit transaction issues involving indirect transactions, the rebuttable presumption, the interaction with the requirements for exemption, and interaction with section 4967 (taxes on prohibited benefits).

11. Section 4966—issues involving sponsoring organizations, donor-advised funds, and whether a distribution from a donor-advised fund is a taxable distribution.

12. Section 4967—whether a distribution results in one or more persons receiving a more than incidental benefit.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part31/irm_31-001-001#addtoany "Show all")

A2A