---
url: "https://www.irs.gov/irm/part33/irm_33-003-007"
title: "33.3.7 Tax Forms, Tax Publications, and Public Use Forms | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part33/irm_33-003-007#main-content)

- 33.3.7 [Tax Forms, Tax Publications, and Public Use Forms](https://www.irs.gov/irm/part33/irm_33-003-007#idm140483791858800)
  - 33.3.7.1 [Tax Forms and Tax Publications Program](https://www.irs.gov/irm/part33/irm_33-003-007#idm140483791860736)

    - 33.3.7.1.1 [Tax Forms Coordinating Committee](https://www.irs.gov/irm/part33/irm_33-003-007#idm140483791891872)
    - 33.3.7.1.2 [Responsibilities of the Office of Chief Counsel](https://www.irs.gov/irm/part33/irm_33-003-007#idm140483791941680)

  - 33.3.7.2 [Counsel Review and Clearance Procedure for Tax Forms, Instructions, and Publications](https://www.irs.gov/irm/part33/irm_33-003-007#idm140483791962496)

# Part 33. Legal Advice

# Chapter 3. Other Legal Advice

# Section 7. Tax Forms, Tax Publications, and Public Use Forms

* * *

## 33.3.7 Tax Forms, Tax Publications, and Public Use Forms

**33.3.7.1** **(08-11-2004)**

### Tax Forms and Tax Publications Program

1. The Tax Forms and Publications Division, W:CAR:MP:T, is responsible for the program of tax forms and tax publications. The focus of this section is on the activities of the Office of Chief Counsel and its representative to the Tax Forms Coordinating Committee (the Committee).


**33.3.7.1.1** **(08-11-2004)**

#### Tax Forms Coordinating Committee

1. Tax forms and instructions combine the technical and administrative requirements of all functions of the Service, and are often the only contact between the Service and the taxpayer. All functions of the Service are represented. For Chief Counsel, one person from the Office of the Associate Chief Counsel (Procedure & Administration) is designated as its representative on the Committee. The Committee, among its duties, reviews and approves all tax forms.


**33.3.7.1.2** **(08-11-2004)**

#### Responsibilities of the Office of Chief Counsel

1. The Office of Chief Counsel is responsible for advising the Committee on current developments in legislation, regulations, litigation, and other legal aspects of forms and instructions. In the development of tax forms and instructions, the Office of Chief Counsel is also responsible for the technical accuracy of interpretations of legislation for which regulations have not been published and of regulations which are in the process of being amended. It is responsible for interpreting the applicable Code sections and for reviewing the forms and instructions.

2. The Chief Counsel representative to the Committee is the Counsel contact for any Service office that has a question about which Counsel office to contact if they need advice on the development or revision of a form.


**33.3.7.2** **(08-12-2010)**

### Counsel Review and Clearance Procedure for Tax Forms, Instructions, and Publications

01. Each Associate and Division Counsel Office should designate a person to serve as the Tax Forms and Publications Coordinator, and another person to serve as the backup Coordinator, for review and clearance of tax forms, instructions, and publications (tax products) for their office. These representatives will meet on a regular basis to determine in advance, on a product by product basis:



    1. The Associate Office that has primary responsibility for clearing each tax product on behalf of Counsel, and

    2. The tax product that each Associate and Division Counsel Office would like to review on coordination because the tax product impacts their office’s subject matter jurisdiction or client programs.


02. As new tax products are developed, they will be referred to each office's representative to determine primary and secondary responsibility for clearance and review.

03. The list identifying primary responsibility and secondary interest among Associate and Division Counsel for clearance and review of recurring tax products will be provided to the Technical Services Support Branch (CC:PA:LPD:TSS) to facilitate case opening and assignment.

04. The Tax Forms & Publications Division will send all tax forms, publications, and instructions, along with the accompanying Document Clearance Record, to the Technical Services Support Branch at Forms & Publications — Counsel Review, which is a dedicated mailbox for Counsel review of tax forms and publications. The Technical Services Support Branch will open a primary workload item to the Associate Office named on the list as having responsibility for clearing the product on behalf of Counsel and assistance workload items for the offices that wish to review that product on coordination.



    1. To facilitate the tracking of Counsel's review and clearance of tax products, cases will be opened using a naming convention that reflects the year of the product and the name of the product (for example, "2006 Tax Product Review, Form 1099−MISC" ).

    2. The Associate Office with primary responsibility will provide consolidated comments on behalf of Counsel to the Tax Forms & Publications Division within 28 days of the date of receipt in the Technical Services Support Branch. The standard time period for Counsel review of all tax products will be 28 days. The Technical Services Support Branch will enter due dates in CASE−MIS based on this standard. For this reason, assistance workload items will be assigned a due date five work days before the due date of the primary assignment. The primary office may grant an office additional time for review as long as the extension does not preclude a timely response to the Tax Forms & Publications Division.

    3. For products requiring expedited (non−standard) review, the office with primary responsibility will negotiate an appropriate comment period with the Tax Forms & Publications Division and will inform the Technical Services Support Branch of the negotiated due date. The primary office has authority to consolidate review requirements as necessary or appropriate for expedited review.

    4. The Technical Services Support Branch will create paper files for the Associate Counsel Offices with primary responsibility.


05. The Technical Services Support Branch will send an email acknowledgment of receipt to:



    1. The Tax Forms & Publications Division indicating the assignment to the Associate Office with primary responsibility, the name of that office’s Tax Forms & Publications Coordinator and the backup Coordinator, and the assigned due date for response.

    2. The Tax Forms & Publications Coordinator for the Associate Office with primary responsibility and the Associate and Division Counsel Coordinators assigned workload items, and a copy to the backup Coordinator. The email should attach an electronic version of the tax product and include the TECHMIS number of the tax product and the due date for the combined response to Tax Forms & Publications, as well as the due date for the workload items.


06. Each Associate and Division Counsel will review the assigned tax product and designate all changes as either a legally required change ( _i.e._, change that affects the substance of or technical meaning of the text) or a recommended change ( _i.e._, one that is nonsubstantive or discretionary that would include stylistic or editorial changes not affecting the technical meaning of the text).

07. The Associate Office assigned primary responsibility will:



    1. Collect comments (designated as either legally required or recommended changes) from the offices who asked to review the item on coordination

    2. Consolidate the comments (designated as either legally required or recommended changes) into one document

    3. If there are legally required changes, prepare a memorandum addressing the need for these changes and providing Counsel−wide concurrence subject to the legally required changes being made by Tax Forms & Publications, and forward the document and the memorandum to Tax Forms & Publications (see paragraph 9 below for further instructions on legally required changes)

    4. If there are no changes, or only nonsubstantive changes are recommended, sign the Document Clearance Record on behalf of Chief Counsel and forward the document and the clearance record to Tax Forms & Publications

    5. Maintain a copy of all documents forwarded to Tax Forms & Publications


08. To the extent that there is no disagreement, it is expected that the Tax Forms & Publications Division will make the legally required changes. If Tax Forms & Publications disagrees with a legally required change, Tax Forms & Publications will contact the office with primary responsibility to reconcile any difference of opinion. Differences that cannot be resolved by the office with primary responsibility will be elevated to the appropriate levels. If that office did not provide the legally required change at issue, the primary office should coordinate with the commenting office in working through the issue with Tax Forms & Publications.

09. Tax Forms & Publications will provide the primary Associate Office with a Document Clearance Record and a "final draft" of the tax product to confirm that all agreed legally required changes have been made. It should be rare that an office will ask for additional legally required changes after receiving the "final draft" if the agreed changes have been made. The primary Associate Office will then sign the Document Clearance Record on behalf of Chief Counsel understanding that the document is moving to print status.

10. These procedures do not preclude an Associate or Division Counsel Office from working informally with Tax Forms & Publications Division during the development of a tax product. However, all final comments must be made through the primary Associate Office to Tax Forms & Publications Division under the formal review and clearance process. In addition, Associate and Division Counsel Offices are encouraged to coordinate with Treasury upon receipt of an assignment from the Technical Services Support Branch to the extent that there is a tax policy or statutory interpretation issue or matter relating to the tax product.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part33/irm_33-003-007#addtoany "Show all")

A2A