---
url: "https://www.irs.gov/irm/part31/irm_31-001-003"
title: "31.1.3 Signature Principles | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part31/irm_31-001-003#main-content)

- 31.1.3 [Signature Principles](https://www.irs.gov/irm/part31/irm_31-001-003#idm140019736485616)
  - 31.1.3.1 [Matters Prepared for Signature of Commissioner, Chief Counsel, orHigher Authority](https://www.irs.gov/irm/part31/irm_31-001-003#idm140019731550528)
  - 31.1.3.2 [Matters Prepared for Signature of the Associate Chief Counsel, AssistantChief Counsel, Branch Chief, or Designated Reviewer](https://www.irs.gov/irm/part31/irm_31-001-003#idm140019727248400)
  - 31.1.3.3 [Matters Prepared for Signature of the Division Counsel or Area Counsel](https://www.irs.gov/irm/part31/irm_31-001-003#idm140019733551744)
  - 31.1.3.4 [Signature Authority for Other Documents](https://www.irs.gov/irm/part31/irm_31-001-003#idm140019730940320)
  - 31.1.3.5 [Execution of Tax Court Documents](https://www.irs.gov/irm/part31/irm_31-001-003#idm140019741720320)
  - 31.1.3.6 [Signature of Correspondence Prepared in Field Offices](https://www.irs.gov/irm/part31/irm_31-001-003#idm140019726256080)

# Part 31.Guiding Principles

# Chapter 1. Guiding Principles

# Section 3. Signature Principles

* * *

## 31.1.3 Signature Principles

**31.1.3.1** **(08-11-2004)**

### Matters Prepared for Signature of Commissioner, Chief Counsel, or Higher Authority

1. Matters are prepared for the signature of the Chief Counsel, Commissioner, or higher authority when designated on the transmittal or referral document or otherwise on the basis of protocol or judgment. Correspondence prepared for the Commissioner’s signature or signature by officials in the Department of Treasury or the White House should be prepared following the format prescribed in IRM 1.10.1.

2. All matters prepared for the signature of the Commissioner or a Treasury Department official are routed to that official through the offices of the Associate Chief Counsel and the Chief Counsel.

3. All matters prepared for the signature of the Chief Counsel should be routed through the Associate Chief Counsel unless otherwise directed.


**31.1.3.2** **(08-11-2004)**

### Matters Prepared for Signature of the Associate Chief Counsel, Assistant Chief Counsel, Branch Chief, or Designated Reviewer

1. Matters are prepared for the signature of the Associate Chief Counsel, an Assistant Chief Counsel, a branch chief, or other designated reviewer based upon delegated authority or the document transmitting the matter to the appropriate office for action. The authority delegated to the Associate Chief Counsel and Assistant Chief Counsel is set out in CCDM 30.3.

2. The procedures governing the document to be issued may require a document be signed at a specific level in certain circumstances. The following sections should be consulted to determine any specific signature requirements:



   - Appellate matters (see CCDM 36.2.1.1.4)

   - Closing agreements (see, e.g., CCDM 32.3.4.7.5)

   - Matters for publication (see CCDM 32.1 and CCDM 32.2)

   - Letter Rulings (see, e.g., CCDM 32.3.1.2.9, CCDM 32.3.4.4)

   - Congressional correspondence (see CCDM 33.6.3)

   - Appointment of receivers (see CCDM 34.4.1.8)


3. In organizations with Assistant Chief Counsel, matters are prepared for the signature of an Assistant Chief Counsel when designated on the transmittal or referral document or on the basis of a delegation of authority from the Associate Chief Counsel. In those organizations, matters for the approval of the Associate or higher should be routed through the appropriate Assistant Chief Counsel.


**31.1.3.3** **(08-11-2004)**

### Matters Prepared for Signature of the Division Counsel or Area Counsel

1. Matters are prepared for the signature of the Division Counsel or Area Counsel based upon delegated authority or the document transmitting the matter to the appropriate office for action. The authority delegated to the Division Counsel and Area Counsel is set out in CCDM 30.3.


**31.1.3.4** **(08-11-2004)**

### Signature Authority for Other Documents

1. Signature authority for certain documents relating to:



   - Matters under the subject matter jurisdiction of the Assistant Chief Counsel (Disclosure and Privacy Law) are discussed in CCDM 37.

   - Criminal tax matters are discussed in CCDM 38.

   - Matters arising under the subject matter jurisdiction of the Associate Chief Counsel (General Legal Services) are discussed in CCDM 39.


**31.1.3.5** **(08-11-2004)**

### Execution of Tax Court Documents

1. All documents executed with respect to Tax Court matters are executed on behalf of the Chief Counsel. Thus, all official papers in Tax Court matters must be executed in accordance with delegated authority. This delegated authority may be a direct delegation from the Chief Counsel or a redelegation with the approval of the Chief Counsel.

2. Documents that are to be filed with the Tax Court and prepared in field offices are executed in the name of the Chief Counsel by Associate Area Counsel or by delegated assistants pursuant to delegated authority, except those that must be coordinated with the Associate offices. See Exhibit 31.1.1–1, Exhibit 35.11.1–1 and Exhibit 35.11.1–2.


**31.1.3.6** **(08-11-2004)**

### Signature of Correspondence Prepared in Field Offices

1. General correspondence prepared in field offices, including correspondence with the Department of Justice regarding matters in litigation, is prepared for the signature of the Associate Area Counsel or other person based on the authority delegated by the Division Counsel, except those matters that must be prepared by or coordinated with the Associate offices. See CCDM 31.1.3.4; Exhibit 31.1.1–1, Exhibit 35.11.1–1 and Exhibit 35.11.1–2.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part31/irm_31-001-003#addtoany "Show all")

A2A