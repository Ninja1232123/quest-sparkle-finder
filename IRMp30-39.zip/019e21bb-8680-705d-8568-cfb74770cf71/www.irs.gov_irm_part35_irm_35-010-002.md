---
url: "https://www.irs.gov/irm/part35/irm_35-010-002"
title: "35.10.2 Penalties and Sanctions | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-010-002#main-content)

- 35.10.2  [Penalties and Sanctions](https://www.irs.gov/irm/part35/irm_35-010-002#idm139875088956096)
  - 35.10.2.1  [Penalties Claimed Under Section 6673](https://www.irs.gov/irm/part35/irm_35-010-002#idm139875088941952)
    - 35.10.2.1.1  [Section 6673(a)(1)](https://www.irs.gov/irm/part35/irm_35-010-002#idm139875088986880)
    - 35.10.2.1.2  [Section 6673(a)(2)](https://www.irs.gov/irm/part35/irm_35-010-002#idm139875088975872)
  - 35.10.2.2  [Miscellaneous Sanctions and Costs Provisions](https://www.irs.gov/irm/part35/irm_35-010-002#idm139875088490080)
    - 35.10.2.2.1  [Discovery Sanctions](https://www.irs.gov/irm/part35/irm_35-010-002#idm139875088488080)
    - 35.10.2.2.2  [Signing of Pleadings: T.C. Rule 33(b)](https://www.irs.gov/irm/part35/irm_35-010-002#idm139875088486288)
    - 35.10.2.2.3  [Sanctions Requiring National Office Review](https://www.irs.gov/irm/part35/irm_35-010-002#idm139875088480608)

# Part 35. Chief Counsel Directives Manual Tax Court Litigation

# Chapter 10. Special Procedures When Attorneys' Fees and Sanctions Are Sought

# Section 2. Penalties and Sanctions

* * *

## 35.10.2 Penalties and Sanctions

#### Manual Transmittal

December 21, 2023

#### Purpose

(1) This transmits revised CCDM 35.10.2, Penalties and Sanctions.

#### Background

I.R.C. § 6673 provides that the U.S. Tax Court may impose a penalty of up to $25,000 when it determines that proceedings before it have been instituted or maintained by the taxpayer primarily for delay, the taxpayer’s position in such proceeding is frivolous or groundless, or the taxpayer unreasonably failed to pursue available administrative remedies. It also provides that the court may require counsel to pay excess costs if the court determines that counsel multiplied the proceedings in any case unreasonably and vexatiously. Instructions are provided to ensure that decision documents determining the penalty are properly prepared and directed to the appropriate individual for assessment of the penalty.

#### Material Changes

(1) CCDM 35.10.2 is revised to update cross references within the CCDM and other intra-organizational references.

(2) CCDM 35.10.2.1.1 is revised to update model decision document language for disposition of a penalty under I.R.C. § 6673(a)(1).

(3) CCDM 35.10.2.1.2 is revised to add model decision document language for disposition of a penalty under I.R.C. § 6673(a)(2).

(4) CCDM 35.10.2.1.2 is revised to address the responsibility of the Field attorney to ascertain the TIN of petitioner's counsel prior to closing the case to facilitate assessment of the penalty under I.R.C. § 6673(a)(2) if imposed by the court.

#### Effect on Other Documents

CCDM 35.10.2, dated August 11, 2004, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(12-21-2023)

Richard G. Goldman

Deputy Associate Chief Counsel

(Procedure & Administration)

**35.10.2.1** **(08-11-2004)**

### Penalties Claimed Under Section 6673

1. Section 6673(a)(1) currently authorizes the Tax Court to impose a penalty not exceeding $25,000 if a taxpayer



1. Institutes or maintains a proceeding primarily for delay;

2. Takes a position that is frivolous, or

3. Unreasonably fails to pursue available administrative remedies.


2. The section 6673(a)(1) penalty should be claimed in all cases where the principal arguments being made by the petitioner are those already deemed frivolous and without merit by the courts, in certain cases where the petitioner (or a related party) has already litigated the same issue in an earlier case and lost, and in other cases where circumstances warrant.

3. In order to provide an effective deterrent, it is important that the Service win those cases in which the section 6673(a)(1) penalty is asserted. Before raising the issue, the Field attorney should review the facts of the case carefully to determine whether imposition of the penalty is appropriate. The factual background of the case should provide evidence of the taxpayer’s knowledge or conduct that shows that the petitioner knew or should have known that the position was frivolous or that such actions were merely designed to delay the payment of tax. The penalty may be raised in " S" or regular cases and in conjunction with any other penalty, although particular care should be exercised when asserting the penalty in a fraud case. The penalty should be claimed in any tax shelter case where it is clear that the petitioner should have conceded the case. _See_ H.R. Rep. No. 247, 101st Cong., 1st Sess. 1399–1400.

4. Although the penalty can be claimed at any time prior to entry of decision, as a rule, the claim should be affirmatively pleaded at the earliest possible time. The claim may be raised in the answer, by amendment to the answer, or by oral or written motion. A written motion for the penalty must be made in conjunction with another dispositive motion, such as a motion for judgment by default or dismissal for failure to prosecute, a motion for summary judgment, or a motion to dismiss for failure to state a claim upon which relief can be granted. An oral motion may be made at a calendar call. The penalty claim, however, should not be asserted with a dispositive motion if the case is to be returned to Appeals for possible settlement while the motion is still pending with the Tax Court.

5. In every case, the factual basis upon which the penalty is claimed must be affirmatively pleaded. In a case where the penalty is claimed in the answer or amendment to the answer, the Service’s position is that T.C. Rule 37 requires the petitioner to file a reply. Where a reply is not filed by the petitioner, respondent should file a motion under T.C. Rule 37(c) requesting an order that the undenied affirmative allegations in the answer be deemed admitted.


**35.10.2.1.1** **(12-21-2023)**

#### Section 6673(a)(1)

1. A penalty award under section 6673(a)(1) is solely within the discretion of the court and can be awarded **sua sponte**. In regard to the burden of proof, T.C. Rule 142 provides that the burden of proof shall be upon the respondent with respect to any new matter. Since a claim for the penalty constitutes a new matter, the respondent must be prepared to discharge the burden of proof in every case in which the penalty claim is asserted. At the same time, the facts should not be overpleaded to support the penalty claim. While, technically, the burden of proof is on respondent, the level of proof necessary to sustain the penalty award is not as high as that in a fraud case. Moreover, respondent does not assume the burden of proving the amount of the penalty to be paid since that determination lies within the sound discretion of the court. Thus, a penalty in an appropriate amount should be requested.

2. In claiming the penalty under section 6673(a)(1), respondent must avoid taking any position that may have the appearance of an attempt by the Service to inhibit or discourage citizens from resorting to the courts when they are in good faith raising a colorable challenge to the Commissioner’s determination. Therefore, where a case raises new issues or raises them in a novel way, or where a case raises a colorable claim in good faith, the penalty should not be claimed.

3. In some cases, it may be appropriate to notify the taxpayer at the prepetition stage that a penalty under section 6673(a)(1) may be imposed if a frivolous petition is filed with the Tax Court. When it is determined that such notification would discourage the filing of a frivolous petition, such notification may be given to the taxpayer, _e.g._, in a letter sent with the statutory notice of deficiency.

4. Petition Filed. In any instance where a petition was filed, separate section 6673(a)(1) penalties should not be asserted against each of the petitioners in the absence of compelling evidence. An aggregate penalty in excess of $25,000 may not be asserted against multiple petitioners without the advance approval of the Associate Chief Counsel (Procedure & Administration) (“P&A”).



1. Where there is good reason to believe a petitioner will be uncooperative, or has previously litigated the same issue, and/or continues to assert frivolous arguments, a letter may refer to those previous cases and raise the possibility of asserting the section 6673 penalty if appropriate.


5. Because of the large number of cases which appear to warrant the penalty and the importance of continuing to win the cases in which the penalty is claimed, the Office of Chief Counsel believes the penalty should not be claimed in any case where there is doubt as to whether the facts warrant the penalty. If there is any question as to whether a claim for the section 6673(a)(1) penalty should be filed, the attorney handling the case should seek informal advice from the Associate Chief Counsel (P&A), Branches 1 and 2.

6. Whenever the section 6673(a)(1) penalty is requested, whether the case is settled or decided, the decision document must address the issue above the Judge’s signature line. It should either state "That there is no penalty due from petitioner under I.R.C. § 6673(a)(1)," or "That there is a penalty due from petitioner pursuant to I.R.C. § 6673(a)(1) in the amount of $\[amount\]." This issue may be compromised in the settlement of a case.


**35.10.2.1.2** **(12-21-2023)**

#### Section 6673(a)(2)

1. Section 6673(a)(2) authorizes the Tax Court to require any attorney or other person admitted to practice before the court to pay excess costs, expenses, and attorneys’ fees that are incurred because the attorney or other person unreasonably and vexatiously multiplied any proceeding before the court. If the attorney is appearing on behalf of the Commissioner, the United States is to pay these costs in the same manner as an award of these costs by a district court. This provision is comparable to the authority already provided to the district courts under 28 U.S.C. § 1927. Section 6673(a)(2), like 28 U.S.C. § 1927, subjects the attorney or other practitioner to personal liability for the excess, not total, costs generated by the unreasonable or vexatious multiplication of proceedings.

2. Prior to requesting the section 6673(a)(2) penalty, attorneys should first submit the matter to the Associate Chief Counsel (P&A), Branches 1 and 2, for initial review and approval. After that review, if it is determined that further action is needed, the branches will refer the matter to the Associate Chief Counsel (P&A), who must approve all requests for the section 6673(a)(2) penalty in the capacity of Sanctions Officer. **See** Exhibit 35.11.1–1 Issues Requiring Associate Office Review.

3. Whenever the section 6673(a)(2) penalty is requested against respondent’s counsel, the decision document must address the issue above the Judge’s signature line. It should either state "That there is no penalty due from respondent to petitioner under I.R.C. § 6673(a)(2)," or "That respondent shall pay a penalty to petitioner in the amount of $\[amount\], representing attorney’s fees and costs awarded pursuant to to I.R.C. § 6673(a)(2).”

4. Whenever the section 6673(a)(2) penalty is successfully requested against petitioner’s counsel, the court’s order should address the penalty imposed and the amount imposed. When this occurs, it is the responsibility of the Field attorney to ascertain the taxpayer identification number (“TIN”) of petitioner’s counsel prior to closing the case. In a closing memorandum attaching the court’s order, petitioner’s counsel’s name and TIN should be provided so that the Service may assess the 6673(a)(2) penalty. If difficulties arise ascertaining the TIN, the attorney may reach out to the Associate Chief Counsel (P&A), Branches 1 and 2, for informal advice.


**35.10.2.2** **(08-11-2004)**

### Miscellaneous Sanctions and Costs Provisions

1. There are other sanctions included within the Tax Court’s rules of which the trial attorney should be aware in the preparation and development of a case. These include sanctions under T.C. Rules 104 and 33(b), as discussed below.


**35.10.2.2.1** **(08-11-2004)**

#### Discovery Sanctions

1. In addition to specific enforcement actions and sanctions that are included as a part of specific rules, T.C. Rule 104 provides more detailed or additional sanctions directed at any failure to comply with the rules governing discovery and admissions.


**35.10.2.2.2** **(12-21-2023)**

#### Signing of Pleadings: T.C. Rule 33(b)

1. _See_ CCDM 35.2.2.1.1 for a discussion of an attorney’s obligations under T.C. Rule 33(b).

2. When the Tax Court orders a party to pay damages or counsel fees to the Service under T.C. Rule 33(b), the Field attorney should advise the court and the party ordered to make the payment that a check, made payable to the U.S. Treasury, should be forwarded to the Field Counsel’s office. Upon receipt, Field Counsel will forward the check to the local administrative officer with a memorandum briefly stating the nature of the payment. The administrative officer will promptly deposit the payment according to the provisions of the Prompt Deposit Act. Such payments will be treated as miscellaneous receipts and will be deposited into the general fund of the Treasury.

3. In regard to sanctions imposed on respondent under T.C. Rule 33(b), generally a Service employee can be reimbursed for payment of such sanctions if the sanctions were necessarily incurred by the employee in the performance of official duties while acting in compliance with valid agency regulations or instructions. Under these circumstances, appropriated funds may be used to reimburse the employee for his or her payment of the court-ordered sanctions, although a case-by-case determination will be required to support such reimbursement. Appropriated funds cannot be used to reimburse an attorney for a court-ordered payment to an opposing party where the attorney was not acting pursuant to agency regulations or instructions. The Associate Chief Counsel (P&A), Branches 1 and 2, should be contacted immediately whenever there arises a possibility that monetary sanctions will be imposed on respondent’s counsel so that proper representation and reimbursement possibilities can be determined.


**35.10.2.2.3** **(12-21-2023)**

#### Sanctions Requiring National Office Review

1. Pursuant to the Civil Justice Reform Executive Order, Field attorneys are encouraged to seek sanctions against opposing parties for abusive practices. Field attorneys should normally first attempt to resolve disputes that might warrant the filing of a sanction motion with opposing counsel. Motions or other correspondence involving ethical and sanctions issues, including potential conflicts of interest issues, are not eligible for direct filing and should be submitted to the Associate Chief Counsel (P&A), Branches 1 and 2 for review.

2. After review by the Associate Chief Counsel (P&A), and after coordination with the Associate Chief Counsel (GLS), the proposed correspondence or motion will be forwarded for final approval by the Associate Chief Counsel (P&A). The Associate Chief Counsel (P&A) is the Sanctions Officer designated for purposes of the Civil Justice Reform Executive Order. The documents requiring review under this section include (**See** Exhibit 35.11.1–1 Tax Court Issues Requiring Associate Office Review):



   - Motions under T.C. Rules 33(b), 70(e), 90(d), 104(c)(4)

   - Motions for an order of contempt of court under section 7456(c) of the Code or under any rule of practice and procedure of the Tax Court

   - Motions to impose penalties against counsel under section 6673(a)(2)

   - Motions for personal sanctions against counsel under any provision of law or rule of practice and procedure

   - Letters or motions concerning conflicts of interest


3. Further, referrals of private practitioners to the Director of the Office of Professional Responsibility as a result of conduct before Counsel will also be sent to the Sanctions Officer, who will coordinate the complaint with Associate Chief Counsel (GLS). Likewise references of practitioners to the Tax Court for disciplinary proceedings pursuant to T.C. Rule 202, or to disciplinary boards, must receive the prior approval of the Sanctions Officer.

4. If a motion falling within any of the above listed categories is filed by a petitioner with respect to respondent or respondent’s counsel in the Tax Court, the Associate Chief Counsel (P&A), Branches 1 and 2, should be immediately notified. Further, any proposed response or proposed notice of objection to petitioner’s motion must be reviewed by the Associate Chief Counsel (P&A), Branches 1 and 2. That branch will promptly refer the matter to the Sanctions Officer. **See** Exhibit 35.11.1–1, Tax Court Issues Requiring Associate Office Review. **See also** CCDM 39.1.1, Matters Relating to Ethics and General Government.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-010-002#addtoany "Show all")

A2A