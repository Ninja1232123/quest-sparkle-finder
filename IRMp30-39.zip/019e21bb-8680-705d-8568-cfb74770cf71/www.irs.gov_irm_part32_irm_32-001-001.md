---
url: "https://www.irs.gov/irm/part32/irm_32-001-001"
title: "32.1.1 Overview of the Regulations Process | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part32/irm_32-001-001#main-content)

- 32.1.1  [Overview of the Regulations Process](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524209639616)
  - 32.1.1.1  [Role of Published Guidance in Tax Administration](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524209787472)
  - 32.1.1.2  [Types of Documents and Regulatory Guidance](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524182808752)
    - 32.1.1.2.1  [Advance Notice of Proposed Rulemaking](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524182292688)
    - 32.1.1.2.2  [Notice of Proposed Rulemaking](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524182290224)
    - 32.1.1.2.3  [Temporary Regulations](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524209775152)
    - 32.1.1.2.4  [Final Regulations](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524209772624)
      - 32.1.1.2.4.1  [Final Regulations Amended by Reference to Temporary Regulations](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524209770256)
    - 32.1.1.2.5  [Treasury Decision (TD)](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524209768272)
    - 32.1.1.2.6  [Interpretative Regulations](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524209766224)
    - 32.1.1.2.7  [Legislative Regulations](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524209763824)
    - 32.1.1.2.8  [How to Determine If a Rule Is Interpretative or Legislative](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524182704752)
  - 32.1.1.3  [Participants in the Regulatory Process](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524182700512)
    - 32.1.1.3.1  [Office of Tax Policy, Department of Treasury (OTP)](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524182699360)
    - 32.1.1.3.2  [The Office of the Federal Register (OFR)](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524182692864)
      - 32.1.1.3.2.1  [The Federal Register System](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524182690144)
      - 32.1.1.3.2.2  [The Daily Federal Register](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524182865536)
      - 32.1.1.3.2.3  [The Code of Federal Regulations (CFR)](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524182854880)
      - 32.1.1.3.2.4  [Federal Register Liaison Officers](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524182786000)
    - 32.1.1.3.3  [Publications and Regulations Branch](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524182778096)
    - 32.1.1.3.4  [Office of Management and Budget](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524182847152)
  - 32.1.1.4  [Summary of the Regulations Process](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524182845408)
    - 32.1.1.4.1  [Priority Guidance Plan](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524182842032)
    - 32.1.1.4.2  [Stakeholder Suggestions](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524182837104)
    - 32.1.1.4.3  [Publication Criteria](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524182829360)
    - 32.1.1.4.4  [Drafting Team](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524182820752)
    - 32.1.1.4.5  [Coordination](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524182816560)
    - 32.1.1.4.6  [Review and Approval](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524182811632)
  - 32.1.1.5  [Confidentiality](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524209758944)
  - Exhibit  32.1.1-1  [Policy Statement on the Tax Regulatory Process](https://www.irs.gov/irm/part32/irm_32-001-001#idm140524209754336)

# Part 32. Published Guidance and Other Guidance to Taxpayers

# Chapter 1. Chief Counsel Regulation Handbook

# Section 1. Overview of the Regulations Process

* * *

## 32.1.1 Overview of the Regulations Process

#### Manual Transmittal

November 13, 2019

#### Purpose

(1) This transmits revised CCDM 32.1.1, Regulations Handbook, Overview of the Regulations Process.

#### Material Changes

(1) CCDM 32.1.1.1 is being updated to add text regarding the Policy Statement on the Tax Regulatory Process.

(2) CCDM 32.1.1.3.4 is being updated to add the role of the Office of Management and Budget.

(3) Exhibit 32.1.1-1, the Department of the Treasury Policy statement on the Tax regulatory Process, is added.

#### Effect on Other Documents

This section supersedes CCDM 32.1.1, dated August 2, 2018.

#### Audience

Chief Counsel

#### Effective Date

(11-13-2019)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**32.1.1.1** **(11-13-2019)**

### Role of Published Guidance in Tax Administration

1. The mission of the Internal Revenue Service is to provide America’s taxpayers top quality service by helping them understand and meet their tax responsibilities and by applying the tax law with integrity and fairness to all. It is the duty of the IRS to correctly apply the laws enacted by Congress; to determine the reasonable meaning of various Internal Revenue Code provisions in light of the Congressional purpose in enacting them; and to perform this work in a fair and impartial manner, with neither a government nor a taxpayer point of view.

2. At the heart of sound tax administration is interpretation of the Code. It is the responsibility of each person in the IRS charged with the duty of interpreting the law to try to find the proper interpretation of the statutory provision and not to adopt a strained construction in the belief that he or she is "protecting the revenue." The revenue is properly protected only when we ascertain and apply the proper interpretation of the statute.

3. The mission of the Office of Chief Counsel is to serve America’s taxpayers fairly and with integrity by providing correct and impartial interpretation of the internal revenue laws and the highest quality legal advice and representation for the IRS. Chief Counsel’s primary means of providing correct and impartial interpretation of the internal revenue laws is through published guidance.

4. The Office of Associate Chief Counsel is solely responsible for issuing published guidance. This Handbook, to be referred to as the Chief Counsel Regulation Handbook, is the authoritative source for procedures and instructions for the Office of Associate Chief Counsel to use in drafting and preparing regulations. Each Associate office may have its own special processing procedures, and the drafting team should consult its Associate Chief Counsel office publications/regulations coordinator to determine its processing procedures.

5. Regulations will be issued in accordance with the policies expressed in the March 5, 2019 Department of the Treasury Policy Statement on the Tax Regulatory Process. See _Exhibit 32.1.1-1_ .


**32.1.1.2** **(08-02-2018)**

### Types of Documents and Regulatory Guidance

1. IRS/Treasury issues several different types of regulatory guidance, which are separately described in this subsection.

2. The drafting team must select the proper type of guidance document based on the content and nature of the guidance issued. Each type of guidance document has its own general characteristics and uses. To ensure consistency, care should be taken to select the appropriate vehicle for disseminating information to the public.

3. Attorneys must consider the appropriate form of guidance and document the decision to use that form of guidance in the legal file. Factors to consider when determining the appropriate form of guidance may include, but are not limited to, the following:



   - The purpose for the guidance and possible guidance alternatives

   - The scope of the guidance’s application

   - The effect on taxpayer’s rights

   - The effect on taxpayer’s duties

   - The degree of deference needed for the guidance

   - Whether the guidance will be controversial

   - Whether public comments are necessary or helpful

   - Whether the guidance is of short-term or long-term value

   - Whether the guidance should include the application of law to a factual scenario

   - Advantages of the type of guidance selected


4. Questions regarding the appropriate guidance document may be directed toward the Office of the Associate Chief Counsel (Procedure & Administration).

5. Following the rules and procedures in the Regulation and Publication Handbooks ensure compliance with applicable statutory and administrative requirements. See [CCDM 32.1.2.1 Procedural Requirements for Regulations; The Legal File](http://publish.no.irs.gov/getpdf.cgi?catnum=38994), and [CCDM 30.9.2, File Management; Guidelines for Specific Categories of Case Files](http://publish.no.irs.gov/getpdf.cgi?catnum=29714).

6. Samples of the various types of guidance documents are provided in the CCDM as Exhibits 32.1.4-2 through 32.1.4-8. Although the samples are based on previously issued guidance, some samples have been updated to provide current model language and are not exact reprints of the original guidance. The samples should not be relied on for substantive statements of law. An Advance Notice of Proposed Rulemaking (ANPRM) describes a problem or situation, announces that the agency is considering regulatory action, describes the agency’s anticipated regulatory approach, and seeks input from the public about the issues, the need for regulation, and the adequacy of the agency’s proposed regulatory action. When aAn ANPRM is issued, it is typically is issued early in the rulemaking process, but can be issued at any time in the regulatory process it becomes clear that an ANPRM would be the most appropriate form of guidance. See Exhibit 32.1.4-2 for a sample ANPRM. See Exhibit 32.1.4-5 for a sample temporary regulation.


**32.1.1.2.1** **(08-02-2018)**

#### Advance Notice of Proposed Rulemaking

1. An Advance Notice of Proposed Rulemaking (ANPRM) describes a problem or situation, announces that the agency is considering regulatory action, describes the agency’s anticipated regulatory approach, and seeks input from the public about the issues, the need for regulation, and the adequacy of the agency’s proposed regulatory action. An ANPRM is issued, typically is issued early in the rulemaking process, but can be issued at any time in the regulatory process it becomes clear that an ANPRM would be the most appropriate form of guidance. See Exhibit 32.1.4-2 for a sample ANPRM.


**32.1.1.2.2** **(08-02-2018)**

#### Notice of Proposed Rulemaking

1. A Notice of Proposed Rulemaking (NPRM) announces to the public that an agency is considering modifying regulations as published in the Code of Federal Regulations (CFR) or issuing rules on matters not addressed in existing regulations. In either circumstance, an NPRM sets out the proposed regulatory text. NPRMs contain a preamble that explains the rules and requests public comments on the suggested changes. NPRMs may also contain a Notice of Hearing. Unlike Treasury Decisions (TDs), NPRMs do not have full force and legal effect unless and until they are adopted as final regulations. Prior to adoption, proposed regulations may be withdrawn or modified at any time. See Exhibit 32.1.4-3 for a sample NPRM.

2. Taxpayers generally may not rely on proposed regulations for planning purposes, except if there are no applicable final or temporary regulations in force and there is an express statement in the preamble to the proposed regulations that taxpayers may rely on them currently. If there are applicable final or temporary regulations in force, taxpayers may only rely on proposed regulations for planning purposes in the limited circumstance if the preamble to the proposed regulations contain an express statement permitting taxpayers to rely on them currently, notwithstanding the existence of the final or temporary regulations.

3. If there are no final or temporary regulations currently in force addressing a particular matter, but there are proposed regulations on point, the Office of Chief Counsel generally should look to the proposed regulations to determine the office’s position on the issue. The Office of Chief Counsel ordinarily should not take any position in litigation or advice that would yield a result that would be harsher to the taxpayer than what the taxpayer would be allowed under the proposed regulations.


**32.1.1.2.3** **(08-02-2018)**

#### Temporary Regulations

1. Temporary regulations are issued to provide immediate guidance to the public and IRS and Counsel employees prior to publishing final regulations. Temporary regulations are effective when published by the Office of the Federal Register. See Exhibit 32.1.4-5 for a sample temporary regulation.

2. Section 7805(e) requires the IRS to publish a cross-referencing NPRM when it publishes a temporary regulation. Section 7805(e) also provides that a temporary regulation expires (sunsets) within three years of issuance, which is the date the regulation is filed for public inspection with the Federal Register.


**32.1.1.2.4** **(08-02-2018)**

#### Final Regulations

1. Final regulations are issued after considering the public comments on the proposed regulations. The preamble of a final rule also cites to the underlying NPRM and other rulemaking history (for example, an ANPRM), discusses and analyzes public comments received and explains the agency’s final decision. A final regulation is almost always preceded by an NPRM. See Exhibit 32.1.4-6 for a sample final regulation.


**32.1.1.2.4.1** **(08-02-2018)**

##### Final Regulations Amended by Reference to Temporary Regulations

1. Existing final regulations may be amended by reference to temporary regulations issued in the same Treasury Decision (TD). See CCDM 32.1.5.7.4.3.2 for specific instructions regarding amending existing final regulations by reference to temporary regulations in the same TD. See Exhibit 32.1.4-8 for a sample final regulation amended by reference to temporary regulation.


**32.1.1.2.5** **(08-02-2018)**

#### Treasury Decision (TD)

1. A Treasury Decision (TD) is a document that contains the text of a final or temporary regulation. The TD adds new text to or removes or revises text already published in the Code of Federal Regulations (CFR). It contains a preamble that explains the rule. It must state the applicability for the regulation and effective date for the change made to the CFR. A TD is cited as legal authority and is binding on taxpayers as well as the IRS, unless invalidated.


**32.1.1.2.6** **(09-23-2011)**

#### Interpretative Regulations

1. The Administrative Procedure Act (APA) exempts interpretative rules from the APA’s notice and comment requirements. Generally, rules or statements issued by an agency to advise the public of the agency’s construction of the statutes it administers are considered interpretative. Most IRS/Treasury regulations are considered interpretative because the underlying statute implemented by the regulation contains the necessary legal authority for the action taken and any effect of the regulation flows directly from that statute. See CCDM 32.1.1.2.7 and CCDM 32.1.1.2.8, below, and CCDM 32.1.5.4.7.5.1(2), Administrative Procedure Act, for further discussion on whether a regulation is interpretive or legislative.


**32.1.1.2.7** **(08-02-2018)**

#### Legislative Regulations

1. Regulations required to follow the APA's notice and comment procedure are referred to as legislative rules or substantive rules. Legislative rules are required when Congress simply provided an end result, without any guidance as to how to achieve the desired result or when a statutory provision does not provide adequate authority for the regulatory action taken.


**32.1.1.2.8** **(08-02-2018)**

#### How to Determine If a Rule Is Interpretative or Legislative

1. Whether a regulation is promulgated under a specific grant of authority in the Internal Revenue Code does not govern whether the regulation is interpretative or legislative.

2. If Congress simply provided anend result, without any guidance as to how to achieve the desired result, then regulations promulgated to achieve that result are considered to be legislative.

3. If Congress provided specific rules and merely left gaps for the Secretary to fill, regulations filling those gaps are considered interpretative.

4. If the regulation repeats law subsumed in the underlying legislation, then the regulation is considered interpretative.


**32.1.1.3** **(08-11-2004)**

### Participants in the Regulatory Process

1. In addition to the drafting team designated by the Office of Associate Chief Counsel, various other government personnel have roles in the regulatory process. The respective roles of the various participants are described in this subsection. The role of the drafting team is described in CCDM 32.1.3.2, The Drafting Team.


**32.1.1.3.1** **(08-02-2018)**

#### Office of Tax Policy, Department of Treasury (OTP)

1. The Department of Treasury Office of Tax Policy (OTP) includes the Office of Tax Legislative Counsel (TLC), the Office of Benefits Tax Counsel (BTC), and the Office of International Tax Counsel (ITC). OTP is responsible for



1. Establishing policy criteria reflected in regulations and rulings, and, together with the IRS and the Office of Chief Counsel, preparing regulations and rulings,

2. Negotiating tax treaties for the United States and represents the United States in meetings and in the workings of multilateral organizations dealing with tax policy matters,

3. Providing economic and legal policy analysis for domestic and international tax policy decisions,

4. Assists the Secretary of the Treasury in developing and implementing tax policies and programs, including the development of the Priority Guidance Plan (PGP), and

5. Providing the official estimates of all Government receipts for the President’s budget, fiscal policy decisions, and Treasury cash management decisions.


2. Information about the OTP, TLC, BTC, and ITC is available on the Department of Treasury web site at [http://www.treasury.gov/about/organizational-structure/offices/Pages/Tax-Policy.aspx](http://www.treasury.gov/about/organizational-structure/offices/Pages/Tax-Policy.aspx).


**32.1.1.3.2** **(08-11-2004)**

#### The Office of the Federal Register (OFR)

1. The Federal Register Act established the Office of the Federal Register (OFR) in 1935. The OFR informs citizens of their rights and obligations by providing ready access to the official text of Federal laws, Presidential documents, administrative regulations and notices, and descriptions of Federal organizations, programs and activities.

2. The OFR staff performs the final review of all Federal regulation documents (and other documents submitted for publication in the Federal Register) for compliance with OFR document drafting requirements prior to filing them for public inspection (the filing date) and publishing them in the daily Federal Register (FR) (the publication date). The OFR also maintains and revises the CFR.


**32.1.1.3.2.1** **(08-02-2018)**

##### The Federal Register System

1. The Federal Register system operates under the authority of the Administrative Committee of the Federal Register. The Federal Register system contains two primary publications:



   - The daily Federal Register; and

   - The annually revised Code of Federal Regulations


2. Together, these publications provide the up-to-date text of all Federal agency regulations.


**32.1.1.3.2.2** **(08-11-2004)**

##### The Daily Federal Register

1. The Federal Register (FR) is a daily publication of the Office of the Federal Register (OFR), National Archives and Records Administration (NARA). The OFR sorts and publishes documents in the FR by categories. The categories applicable to IRS/Treasury regulations are:



   - Rules and Regulations — documents having general applicability and legal effect, (final and temporary regulations), including IRS prepared corrections to rules and regulations (final and temporary regulations)

   - Proposed Rules — documents notifying the public of the proposed issuance of rules and regulations (ANPRMS and NPRMs), including IRS prepared corrections to NPRMs

   - Corrections — documents that contain editorial corrections of previously published documents

   - Notices — documents other than rules and proposed rules that are applicable to the public (for example, notices of public hearings and meetings)


2. The OFR will not accept a document that combines material that would appear in different categories of the FR. For example, the OFR will not publish a document containing a proposed regulation if it also contains material pertaining to a temporary or final regulation. However, because both temporary and final regulations appear in the Rules and Regulations category, the OFR will publish a document containing both of those documents. The FR uses the terms "rules" and "regulations" interchangeably.

3. Publishing a regulation in the FR has certain legal effects:



   - Provides the public notification that a document exists and provides its contents

   - Establishes the text as a true copy of the original document

   - Indicates the date the agency issued the regulation

   - Provides evidence of the document that is acceptable to a court of law (prima facie evidence)


4. The Federal Register is available on-line at [http://www.archives.gov/federal-register/index.html](http://www.archives.gov/federal-register/index.html).

5. The OFR offers an on-line tutorial about the FR, what it is and how to use it at [http://www.archives.gov/federal-register/about/workshop-schedule.html](http://www.archives.gov/federal-register/about/workshop-schedule.html).


**32.1.1.3.2.3** **(08-02-2018)**

##### The Code of Federal Regulations (CFR)

1. The CFR is an annual codification of the rules of each executive department and Federal agency. The OFR revises the CFR April 1 of each year. The CFR is divided into 50 titles that represent areas subject to Federal regulations. Title 26 (Internal Revenue) contains temporary and final regulations. CFR Titles are divided into chapters, usually named for the issuing agency. Chapters are numbered in Roman numerals. Title 26 has only one chapter: Chapter I - Internal Revenue Service, Department of the Treasury. Chapters are divided into Parts.

2. Parts are numbered in Arabic numerals throughout each Title. A part contains a unified body of regulations pertaining to a function or specific subject matter of the issuing agency. Subparts, usually capital letters, group related subject matter within a part. The section is the basic unit of the CFR. The section number consists of the part number followed by a period and a sequential number. In general, the sequential number for IRS/Treasury regulations begins with the Code section number. For example, one of the regulations addressing section 61 of the Code is numbered §1.61-1.

3. Title 26 contains twenty volumes with the following contents:



|     |     |
| --- | --- |
| Volumes 1 – 13 | Part 1 (Subchapter A — Income Tax) |
| Volume 14 | (Subchapter A — Income Tax, continued)<br> (Subchapter B — Estate and Gift Tax) |
| Volumes 15 – 20 | (Subchapter C — Employment Taxes and Collection of Income Tax at Source)<br> Parts 40–49<br> Parts 50–299 (Subchapter D — Miscellaneous Excise Taxes)<br> Parts 300–499 (Subchapter F — Procedure and Administration)<br> Parts 500–599 (Subchapter G — Regulations under Tax Conventions)<br> (Subchapter H — Internal Revenue Practice) |

4. The parts used most frequently by the IRS are:



   - Part 1 Final Income Tax Regulations

   - Part 20 Estate Taxes

   - Part 25 Gift Taxes

   - Part 26 Tax on Certain Generation-Skipping Transfers

   - Part 31 Employment Taxes and Collection of Income Tax at Source

   - Part 35a Temporary Regulations Concerning Backup Withholding

   - Part 48 Manufacturers and Retailers Excise Tax

   - Part 301 Procedure and Administration

   - Part 601 Statement of Procedural Rules


5. The CFR is available on-line at [https://www.gpo.gov/fdsys/browse/collectionCfr.action?collectionCode=CFR](https://www.gpo.gov/fdsys/browse/collectionCfr.action?collectionCode=CFR). The eCFR is available at [https://www.ecfr.gov/](https://www.ecfr.gov/)..


**32.1.1.3.2.4** **(08-02-2018)**

##### Federal Register Liaison Officers

1. A Federal Register Liaison Officer (FRL) is an official representative of his or her agency who is authorized to work with the Office of the Federal Register to ensure that the agency’s documents meet publication requirements and that the OFR accommodates the agency’s publication requests whenever possible.

2. The duties of the FRL include:



1. Reviewing draft regulations and provide comments before "Green" circulation, signature package, and delivery to Federal Register to ensure compliance with FR publication requirements

2. Advising drafting attorneys on OFR publication requirements

3. Answering questions on regulation drafting procedures if the drafting attorney needs assistance after reviewing the Regulation Handbook and after requesting assistance from the Associate Chief Counsel office’s publications/regulations coordinator

4. Requesting special handling or withdrawal of document, when necessary

5. Distributing dates that the agency submitted documents to the OFR for publication and inform appropriate agency staff of file and publication date information

6. Suggesting corrections when the regulation does not comply with FR requirements and OFR corrections alter the substance of the regulation

7. Submitting corrected material, as requested by the OFR


3. The drafting team should contact the Associate Chief Counsel office’s publications/regulations coordinator or the Publications and Regulations Branch in the Legal Processing Division of CC:PA for the names and phone numbers of the Office of Chief Counsel FRLs.


**32.1.1.3.3** **(08-11-2004)**

#### Publications and Regulations Branch

1. The Office of Chief Counsel Publications and Regulations Branch, Legal Processing Division, Office of Associate Chief Counsel (Procedure and Administration) provides administrative and technical support to attorneys publishing regulations. The FRLs are part of this branch.

2. In addition, other staff members of this branch perform some of the same duties as the FRLs. The staff members also help attorneys prepare the forms and other material required by Federal administrative laws, obtain RINs, schedule public hearings, process public comments, and prepare correction notices and the IRS portion of the Unified Agenda.


**32.1.1.3.4** **(11-13-2019)**

#### Office of Management and Budget

1. The Office of Information and Regulatory Affairs within the Office of Management and Budget reviews IRS regulations in accordance with Executive Order 12866.


**32.1.1.4** **(08-11-2004)**

### Summary of the Regulations Process

1. Federal income tax regulations are the official Treasury interpretation of the Code. Although the Regulation Handbook specifically addresses regulation projects, many of the principles and procedures discussed are equally applicable to other forms of published guidance, such as notices, revenue rulings, and revenue procedures. _See_ the Publication Handbook for further guidance on those types of publications.

2. Regulations are the most authoritative form of published guidance. Only regulations may be used to affect existing regulations. Other forms of published guidance may be used to announce how the IRS may address an issue in regulations, but they do not have the force and effect of regulations.


**32.1.1.4.1** **(08-02-2018)**

#### Priority Guidance Plan

1. Each year the IRS and Treasury develop a Priority Guidance Plan (PGP). The PGP identifies the issues on which the IRS and Treasury will focus its resources during the published guidance plan year. The IRS and Treasury solicit recommendations from the public for items that should be included on the PGP. The IRS and Treasury also consider recommendations from within the IRS, the Office of Chief Counsel, and other government agencies. Interested parties may submit recommendations for guidance at any time during the year. The PGP is updated as needed. The updates provide the IRS and Treasury with greater flexibility to address the need for additional guidance that may arise during the published guidance plan year resulting from new legislation, changes in policy, or other emerging circumstances. If new projects must be added during the published guidance plan year, the Office of Chief Counsel and Treasury may have to reevaluate which projects must be published and those for which publication may be deferred. As the need arises, the IRS and Treasury work on published guidance projects that do not appear on the PGP.

2. Any petitions for rulemaking submitted to the IRS under section 5 U.S.C. § 553(e) will be considered during the PGP process, and the publication of the PGP will provide notice to the petitioner as to whether the IRS and Treasury intend to publish the requested guidance.

3. Executive Orders 13563, 13777, and 13879 direct agencies to consider how best to promote review of certain regulations. Consistent with Executive Order 13563, the IRS annually solicits public recommendations with respect to regulations that may be outmoded, ineffective, insufficient, or excessively burdensome and that should be modified, streamlined, expanded, or repealed. The responsible Associate Chief Counsel office should consider each recommendation for retrospective review and be prepared to justify a decision to not undertake a recommended project. Additionally, in formulating the PGP, each Associate office should independently consider whether, based on its knowledge and experience, there are any existing regulations within the Associate office's subject matter jurisdiction that meet the description set forth above and should be included on the PGP for appropriate action in accordance with the executive orders.


**32.1.1.4.2** **(08-02-2018)**

#### Stakeholder Suggestions

1. In response to a TIGTA audit dated March 31, 2003, the Office of Chief Counsel agreed to maintain files of stakeholders’ suggestions for published guidance and the office’s response to those requests. The Office of Chief Counsel also agreed to provide written acknowledgement of requests for published guidance with assurances that the requests will be given due consideration.

2. The Office of Chief Counsel receives suggestions for published guidance from many sources within the IRS, as well as from external sources, such as the American Bar Association, the Tax Executives Institute, the American Institute of Certified Public Accountants, industry representatives, and interested taxpayers. These suggestions should be given serious consideration in the process of selecting and prioritizing guidance initiatives for inclusion in the annual PGP.

3. The IRS and Treasury annually publish a Notice inviting recommendations from the public for items to be included on the PGP for the upcoming year. The Notice usually is published in the Internal Revenue Bulletin in late April or early May, and seeks comments by the end of May, but also reminds the public that suggestions may be submitted to the IRS at any time during the year. In addition to the Internal Revenue Bulletin, the Notice is posted on regualtions.gov, the IRS website, and is published in the popular tax press, as well as on scores of publicly accessible Internet web sites.

4. Each Associate Chief Counsel office should consider issuing published guidance concerning substantially similar matters that are repeated subjects of private letter ruling requests, technical assistance memoranda, or other requests for legal advice.

5. To facilitate the appropriate consideration of these suggestions, the Publications and Regulations Branch, Legal Processing Division, in the office of the Associate Chief Counsel (Procedure and Administration), will forward to the appropriate Associate office the stakeholder suggestions for published guidance sent to the Office of Chief Counsel or submitted and posted on regulations.gov.

6. Suggestions for published guidance from external sources that are received directly by attorneys or Associate offices should be sent to the Publications and Regulations Branch. The Publications and Regulations Branch will acknowledge receipt of all suggestions for published guidance received from external sources and will maintain a file of these suggestions.

7. Each Associate Chief Counsel office should maintain organized files regarding requests for published guidance from both internal and external sources that involve issues within that office’s subject matter jurisdiction. These files should be maintained in a way that facilitates retrieval of suggestions for consideration in selecting and prioritizing issues to be included on a future PGP or an update to the list. Each suggestion, whether from internal or external stakeholders, should be evaluated in light of the criteria described in CCDM 32.1.1.4.3 and the annual PGP solicitation Notice, and each Associate office should document the reasons for its decision to recommend for or against inclusion of a suggestion on the PGP.


**32.1.1.4.3** **(08-02-2018)**

#### Publication Criteria

1. When selecting projects for the PGP, the IRS and Treasury consider the following:



   - Whether the recommended guidance resolves significant issues relevant to many taxpayers

   - Whether the recommended guidance reduces the burden or cost on taxpayers, the public, or the government

   - Whether the recommended guidance promotes sound tax administration

   - Whether the recommended guidance can be drafted in a manner that will enable taxpayers to easily understand and apply the guidance

   - Whether the recommended guidance involves regulations that are outmoded, ineffective, insufficient, or excessively burdensome or costly and that should be modified, streamlined, expanded, or repealed

   - Whether the IRS can administer the recommended guidance on a uniform basis; and

   - Whether the recommended guidance reduces controversy or lessens the burden on taxpayers or the IRS


2. Matters should be recommended for publication only if they meet at least one of the above criteria.



### Note:



A subject that is primarily a determination of fact rather than an interpretation of law should not ordinarily be recommended for publication, even though the subject meets one or more of the above criteria.

3. In addition to the factors described above, the IRS and Treasury consider whether the guidance is required by statute, the number of taxpayers affected by the proposed guidance, and the resources available to complete all the guidance projects proposed for a particular year. The IRS and Treasury strive to include the most important suggestions for guidance on the PGP each year.

4. The current PGP is posted on [https://www.irs.gov/uac/priority-guidance-plan](https://www.irs.gov/uac/priority-guidance-plan).


**32.1.1.4.4** **(08-02-2018)**

#### Drafting Team

1. Associate Chief Counsel offices are solely responsible for issuing published guidance. However, on some projects, members of Operating Divisions may be involved in the development of a project.



1. The Associate office having jurisdiction of the principal issue in the project assigns the project to a docket attorney and reviewer (generally referred to as the "drafting team" ).

2. The drafting team works closely with the Associate (or Associate Office front office staff) in the analysis and drafting of the project.


2. In some projects, a member of the Chief Counsel’s staff may also be closely involved with the analysis and drafting of the project. See CCDM 32.1.2, Procedural Requirements for Regulation Projects, for instructions for opening projects, maintaining files, and related matters.


**32.1.1.4.5** **(08-02-2018)**

#### Coordination

1. OTP assigns a Treasury Attorney-Advisor to projects simultaneously with the assignment of the projects in Counsel. Treasury attorneys are involved in projects from the project’s earliest stages and provide assistance in developing published guidance. The Treasury attorney will ensure proper coordination and review in OTP and, in the case of regulations, the Office of the General Counsel.

2. If the project has issues that are not within the office with primary jurisdiction, the drafting team coordinates with the Associate office having jurisdiction of those issues.

3. The drafting team must also coordinate guidance projects with the relevant Division Counsel(s) and Operating Divisions. The drafting team should coordinate guidance projects with the Department of Justice where appropriate, for example if the regulation will impact pending litigation. Early in the published guidance plan year, the Associate and Division Counsel will discuss any projects of interest to the Division Counsel and its Operating Division client. In addition, the Associate informs the Division Counsel’s publication coordinator or designee of guidance developments during the year. This includes making sure that the Division Counsel office is apprised of any new project on which work has commenced. The Division Counsel publication coordinator or designee is responsible for further coordination both within Division Counsel and with the Operating Division. The role of Division Counsel is described more fully in CCDM 32.1.6.1 , Review, Approval, and Publication of Regulations.


**32.1.1.4.6** **(09-23-2011)**

#### Review and Approval

1. During the development of the regulation, certain projects may need to be briefed to the Chief Counsel or Treasury for policy issues. Policy issues may be briefed informally, by memorandum, or otherwise. Some issues may be briefed formally to a Deputy Chief Counsel and senior Treasury officials, who will, if necessary, brief the Chief Counsel and the Assistant Secretary, respectively. Some projects may require a formal joint briefing of the Chief Counsel and the Assistant Secretary of the Treasury.

2. The drafting attorney prepares a Conference Memorandum to memorialize the decisions reached on the policy issues after any briefing. The Conference Memorandum should be circulated to everyone who attended the briefing. After a decision is reached on the policy issues, the draft regulation is circulated among the Associate offices, Division Counsel, and other interested parties (the "green" circulation package, _see_ CCDM 32.1.6.7 for further discussion of the "green" circulation draft) for comment. The review process is discussed more fully in CCDM 32.1.6, Review, Approval, and Publication of Regulations.

3. After receiving comments, and incorporating comments to the extent possible on the green circulation package, the drafting team prepares a final draft for approval (the "pink" or "signature package," _see_ CCDM 32.1.6.8 for further discussion of the signature package). All regulation projects, including ANPRMs, must be approved by the Chief Counsel, the Commissioner, and the Assistant Secretary of the Treasury (Tax Policy). The clearance process is described more fully in CCDM 32.1.6.8.4.


**32.1.1.5** **(08-02-2018)**

### Confidentiality

1. The PGP is available to the public, and the drafting team may discuss and disclose to the public the fact that a regulation project is on that list. Generally, the drafting team should not discuss projects that are not on the PGP. With respect to an item that does not appear on the PGP, the drafting team may indicate, without referencing any particular document, whether the IRS is considering working on guidance with respect to that subject or issue.

2. During the development of a regulation, it may be appropriate and often advisable for the drafting team to receive input from interested parties outside of IRS/Treasury regarding the issues raised in the project. However, the drafting team should not disclose the contents of a regulation during meetings with those outside interested parties. Before engaging in any discussions with outside interested parties about a regulation project, the drafting team must obtain the approval of the drafting team’s Associate Chief Counsel. As appropriate, the drafting team should coordinate with other offices, such as Disclosure & Privacy Law and General Legal Services, to determine what may be discussed with outside interested parties.

3. The contents of regulations should be available to the public for the first time when filed by the Office of the Federal Register. Thus, while Counsel and OTP are drafting a regulation, information concerning the rules to be adopted should not be disclosed outside the Department of the Treasury. In appropriate circumstances, however, the Commissioner or a Deputy Commissioner, the Chief Counsel or a Deputy Chief Counsel, or an Associate or Deputy Associate Chief Counsel may authorize earlier dissemination of this information. In certain circumstances, it may be appropriate to disclose this information outside the Department of the Treasury, for example, the Department of Justice may need to be apprised of a developing project if it affects a case in litigation. This prohibition does not apply to routine coordination necessary with other government agencies (e.g., Department of Labor and Pension Benefit Guaranty Corporation on pension regulations).


**Exhibit 32.1.1-1**

### Policy Statement on the Tax Regulatory Process

![This is an Image: 29172001.gif](https://www.irs.gov/pub/xml_bc/29172001.gif)

> First page of the Policy Statement on the Tax Regulatory Process memo.

[Please click here for the text description of the image.](https://www.irs.gov/media/29172001.gif "")

![This is an Image: 29172002.gif](https://www.irs.gov/pub/xml_bc/29172002.gif)

> Second page of the Policy Statement on the Tax Regulatory Process memo.

[Please click here for the text description of the image.](https://www.irs.gov/media/29172002.gif "")

![This is an Image: 29172003.gif](https://www.irs.gov/pub/xml_bc/29172003.gif)

> Third page of the Policy Statement on the Tax Regulatory Process memo.

[Please click here for the text description of the image.](https://www.irs.gov/media/29172003.gif "")

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part32/irm_32-001-001#addtoany "Show all")

A2A