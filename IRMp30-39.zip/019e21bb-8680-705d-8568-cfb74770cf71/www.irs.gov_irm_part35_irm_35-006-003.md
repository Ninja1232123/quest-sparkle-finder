---
url: "https://www.irs.gov/irm/part35/irm_35-006-003"
title: "35.6.3 Tax Court Procedures for Reporting Potentially Dangerous Persons | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-006-003#main-content)

- 35.6.3 [Tax Court Procedures for Reporting Potentially Dangerous Persons](https://www.irs.gov/irm/part35/irm_35-006-003#idm139724064511392)
  - 35.6.3.1 [Purpose](https://www.irs.gov/irm/part35/irm_35-006-003#idm139724054771232)
  - 35.6.3.2 [Background](https://www.irs.gov/irm/part35/irm_35-006-003#idm139724104015376)
  - 35.6.3.3 [Security Guidelines and Reporting Procedures](https://www.irs.gov/irm/part35/irm_35-006-003#idm139724104012208)
  - 35.6.3.4 [Disclosure Aspects](https://www.irs.gov/irm/part35/irm_35-006-003#idm139724069664368)
  - 35.6.3.5 [Armed Escorts](https://www.irs.gov/irm/part35/irm_35-006-003#idm139724103989408)
  - 35.6.3.6 [Prisoners](https://www.irs.gov/irm/part35/irm_35-006-003#idm139724072940016)

# Part 35. Tax Court Litigation

# Chapter 6. Trial

# Section 3. Tax Court Procedures for Reporting Potentially Dangerous Persons

* * *

## 35.6.3 Tax Court Procedures for Reporting Potentially Dangerous Persons

**35.6.3.1** **(08-11-2004)**

### Purpose

1. The procedures for reporting potentially dangerous persons are intended to make court proceedings as safe as possible for the court, the public, and respondent’s personnel, while safeguarding the petitioner’s privacy.

2. The purpose of these instructions is to inform Field attorneys of security guidelines for potentially dangerous persons and to establish reporting procedures to the Tax Court by calendar administrators or persons responsible for the administration and the oversight of trial sessions.


**35.6.3.2** **(08-11-2004)**

### Background

1. Recent events have brought the need to remind attorneys to develop a greater awareness of personal security in their dealings with potentially dangerous persons. In an effort to provide adequate safety for its employees, the Service has developed the Potentially Dangerous Taxpayer (PDT) System, which has significantly improved the Service’s ability to alert all affected employees to the existence of a person who may be dangerous. Field attorneys should be aware that no contact is to be made with a person classified as a PDT until efforts have been made to ensure their safety. As described below, Criminal Investigation and the Treasury Inspector General for Tax Administration (TIGTA) should be contacted immediately to determine what action needs to be taken.


**35.6.3.3** **(08-11-2004)**

### Security Guidelines and Reporting Procedures

01. Upon return of the administrative file from Appeals for trial preparation, the Field attorney will review the file for records displaying a PDT indicator. The PDT indicator is represented by the symbol \*PDT\*, as displayed on the following documents and data bases:



    - National Computer Center (NCC) Transcripts (except Privacy Act Transcripts).

    - Microfilm Replacement System (MRS) Transcripts.

    - Federal Tax Deposits (FTD) Alerts.

    - Integrated Data Retrieval System (IDRS) Transcripts.

    - Tax Module (TXMOD).

    - Entity Module (ENMOD).

    - Taxpayer Delinquency Account (TDA).

    - Taxpayer Delinquency Investigation (TDI).

    - Audit Information Management System (AIMS), including AIMS Weekly Updates, AIMS Charge-outs (Forms 5546), and AIMS Display (AMDIS).

    - Daily Transaction Register.


02. If none of the above-listed records are contained in the administrative file, the attorney should immediately request a transcript.

03. When the PDT indicator appears on an internal document or data base pertaining to a person with whom the attorney is to have a personal contact, the attorney should apprise the calendar administrator and the attorney’s reviewer. The calendar administrator, or the attorney’s reviewer if no calendar has been set, should contact TIGTA, with the person’s full name and SSN or EIN, to ascertain the basis for designating the person as potentially dangerous.

04. For purposes of identifying a nondesignated PDT person as a potential security threat to the Tax Court, the Service’s PDT criteria will be utilized. The six criteria are divided into tax and nontax-related incidents, with the first four being tax-related incidents. The PDT criteria are:



    1. Persons who physically assault Service employees.

    2. Persons who attempt to intimidate Service employees with a show of weapons.

    3. Persons who make specific threats of bodily harm to Service employees.

    4. Persons who use animals to threaten or intimidate Service employees.

    5. Persons who have committed the acts set forth in any of the above criteria, but whose acts have been directed against employees of other governmental agencies at federal, state, county, or local levels.

    6. Persons who are not classified as PDTs through application of the above five criteria, but who have demonstrated a clear propensity towards violence, through acts of violent behavior within the five-year period immediately preceding the time of classification as potentially dangerous.


05. The criterion of CCDM 35.6.3.3(4)(f) would permit treatment of the person as a PDT only where incidents of violent behavior outside the tax context (such as barroom brawls and domestic violence) are determined to have a nexus with the person’s anticipated behavior when confronted with Service personnel in the performance of their tax administration duties. This nexus to tax administration is necessary because of the Privacy Act’s information gathering limitations. Specifically, 5 U.S.C. § 552a(e)(1) states that each agency which maintains a system of records shall maintain in its records only such information about an individual as is relevant and necessary to accomplish a purpose of the agency required to be accomplished by statute or by executive order of the President. Once this nexus is established, the Service may, on a case-by-case basis, gather and maintain information pertaining to nontax-related incidents. Therefore, a determination that a nondesignated PDT person poses a potential security threat to the Tax Court should be based only on incidents in which the person’s behavior falls within one of the established PDTcriteria.

06. If the case is to be returned by the Field attorney to Appeals, the transmittal memorandum attached to the administrative file should indicate whether the Service has classified the person as a PDT or if there is information which satisfies any of the above PDT criteria. Before sending the case back to Appeals, a copy of the transmittal memorandum should be placed in the legal file.

07. If a person was not previously classified by the Service as a PDT, recent incidents may warrant such a classification by the Field attorney, based upon application of the PDT criteria to these incidents. If the attorney discovers new information about the person that would trigger any of the PDT criteria set forth in CCDM 35.6.3.3(4), TIGTA should be notified, and the information noted in the legal and the administrative files. In addition to disclosing whether or not a person is a potential security threat to the Tax Court, as discussed in CCDM 35.6.3.3(9), the following actions should be taken:



    1. If the recent incident does not involve an overt threat or assault, the attorney should report the information (through the Associate Area Counsel) to the Territory Manager or Area Director, as appropriate.

    2. If the recent incident does involve an immediate threat or assault, in addition to documenting the information in the person’s file, the attorney should contact TIGTA, and also report the information to the Territory Manager or Area Director.

    3. Where it is ultimately determined, under the PDT program, that the recent incident does not give rise to a classification of the person as a PDT, the information reflecting that incident should be purged from the legal and administrative files.


08. At least two weeks before the beginning of the trial session, the calendar administrator must determine whether any petitioners, potential witnesses, or other persons expected to attend a trial session constitute a potential threat to the safety of individuals present at the court. The determination may be made after consulting TIGTA. Area Counsel is to be informed of any determinations that persons meet any of the PDT criteria and pose a potential security threat to individuals present at the trial session.

09. The calendar administrator is required to make an oral report by telephone to the Office of the Clerk of the Court regarding the security situation for every trial calendar. The report must state whether any of the individuals related to cases on the calendar pose a potential security threat. Upon request, the Tax Court’s staff may be told of an incident giving rise to the potential security threat.

10. If the Tax Court’s staff determines, upon consultation with the trial judge, that a person appears to pose a security threat, and/or that additional information needs to be released to the U.S. Marshals Service, the calendar administrator will be responsible for coordination with TIGTA. The Tax Court is solely responsible for all contact with the U.S. Marshals Service, and if necessary will arrange for the U.S. Marshals Service to contact the calendar administrator. With the assistance of TIGTA, the calendar administrator will secure the release of information necessary for the security of the Tax Court.

11. If any witnesses, representatives, observers, or other persons expected to appear have been determined to meet any of the PDT criteria and pose a potential security threat, the Tax Court’s staff must be so informed.

12. An oral security report by the calendar administrator, including a negative report if no petitioners, witnesses, or other persons are a known potential security threat, is required to be given to the Tax Court’s staff at least two weeks before every session. Updates should also be made if additional information becomes available. In exigent circumstances in the event that contact with the Tax Court’s staff is not possible, the trial judge should be contacted directly. In such an instance, care should be exercised to discuss only the potential security situation and, if possible, communications should be limited to the judge’s clerical or secretarial staff.


**35.6.3.4** **(08-11-2004)**

### Disclosure Aspects

1. Section 6103 contains the statutory scheme regarding the confidentiality and disclosure of federal tax returns and return information. Section 6103(a) provides that tax returns and return information are confidential and may not be disclosed, with certain exceptions. Information that a petitioner or witness is a potential security threat to the Tax Court falls within the section 6103(b)(2) definition of confidential return information.

2. Disclosure by the calendar administrator to the Tax Court’s staff, to the effect that persons related to docketed cases either do or do not pose potential security threats to Tax Court sessions, or that witnesses scheduled to appear pose such threats, or subsequent disclosures to the U.S. Marshals Service, all for the ultimate purpose of ensuring the safety of all persons appearing in the Tax Court, are authorized under section 6103. Further, since such disclosures are authorized under section 6103, they constitute routine uses under the Privacy Act of 1974, 5 U.S.C. § 552a(b)(3).


**35.6.3.5** **(08-11-2004)**

### Armed Escorts

1. An attorney or other Service employee may be threatened with bodily harm by a belligerent person, or other circumstances may develop in which attempts to interfere with the administration of tax laws results in the need for protection. All attorneys should be aware of the seriousness of threats, regardless of how insignificant such incidents or information may appear on the surface, and report such concerns, as appropriate.

2. If an attorney believes that an armed escort is necessary, the attorney will inform the calendar administrator of the facts and circumstances involved. If the calendar administrator determines that the assignment of an armed escort is justified, the attorney will request Criminal Investigation to assign an agent as an armed escort. The initial request should be made by telephone to give Criminal Investigation ample time to schedule an escort. If the request is the direct result of a recent threat or assault, a telephonic and written report must be made to TIGTA, with the details of the threat or the assault. If it is determined that an armed escort is necessary at the session, the Tax Court’s staff will be informed as previously provided herein to allow the Tax Court to coordinate with the U.S. Marshals Service, even if the Service armed escort is to remain outside the courtroom. In no event should an armed escort enter the courtroom without the express permission of the trial judge.


**35.6.3.6** **(08-11-2004)**

### Prisoners

1. Witnesses or petitioners in prison are not subject to the procedures and guidance contained in these instructions. _See_ CCDM 35.4.4.4.8 and CCDM 35.4.4.4.9 on obtaining the testimony of persons who are incarcerated.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-006-003#addtoany "Show all")

A2A