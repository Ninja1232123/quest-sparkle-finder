---
url: "https://www.irs.gov/irm/part33/irm_33-003-004"
title: "33.3.4 Division Counsel (LB&I) Industry Program | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part33/irm_33-003-004#main-content)

- 33.3.4 [Division Counsel (LB&I) Industry Program](https://www.irs.gov/irm/part33/irm_33-003-004#idm140352955684752)
  - 33.3.4.1 [Purpose and Organization of Industry Program](https://www.irs.gov/irm/part33/irm_33-003-004#idm140352953678352)

    - 33.3.4.1.1 [Industry Counsel (Including Associate Industry Counsel)](https://www.irs.gov/irm/part33/irm_33-003-004#idm140352989587952)

  - 33.3.4.2 [Procedures for Associate Chief Counsel Review of Proposed Coordinated Issue Papers](https://www.irs.gov/irm/part33/irm_33-003-004#idm140352965701696)

    - 33.3.4.2.1 [Review Process](https://www.irs.gov/irm/part33/irm_33-003-004#idm140352989575872)
    - 33.3.4.2.2 [Time-Frame for Review](https://www.irs.gov/irm/part33/irm_33-003-004#idm140352958257856)
    - 33.3.4.2.3 [Status Update](https://www.irs.gov/irm/part33/irm_33-003-004#idm140352958272672)
    - 33.3.4.2.4 [De-coordination Procedures](https://www.irs.gov/irm/part33/irm_33-003-004#idm140352954797376)

  - 33.3.4.3 [Coordination with Industry and Issue Programs](https://www.irs.gov/irm/part33/irm_33-003-004#idm140352954790848)

# Part 33. Legal Advice

# Chapter 3. Other Legal Advice

# Section 4. Division Counsel (LB&I) Industry Program

* * *

## 33.3.4 Division Counsel (LB&I) Industry Program

**33.3.4.1** **(12-10-2010)**

### Purpose and Organization of Industry Program

1. These provisions outline the organization and operation of the Industry Program (IP) in the Office of Division Counsel (Large Business and International) (LB&I), and describe the policy of providing informed, practical, and expedited legal support to the LB&I Pre-Filing and Technical Guidance program and Appeals. The Industry Program replaces the former Industry Specialization Program.

2. The International Field Counsel Program in Division Counsel (LB&I) is not covered in these provisions and will be covered in a separate CCDM section.

3. **Technical Advisors**. Technical Advisors work within the Office of Pre-filing and Technical Guidance (LB&I). They serve as nationwide experts in a particular industry or on a particular issue. They identify and develop significant industry issues, and other specifically designated issues, to ensure uniform and consistent treatment of issues nationwide.

4. **Deputy Area Counsel (Industry Programs)**. The Deputy Area Counsel (Industry Programs) provides primary support to the Area Counsel and Industry Director staff with respect to industry specific pre-filing, filing, and post-filing activities. They oversee and supervise the Industry Counsel, who serve as the primary Counsel liaison with the Technical Advisors aligned within their area’s respective industries or issues.


**33.3.4.1.1** **(12-10-2010)**

#### Industry Counsel (Including Associate Industry Counsel)

01. The Office of Chief Counsel provides the legal interpretation of the internal revenue laws. Industry Counsel play a critical role in fulfilling this responsibility for industry issues. They provide direct legal support to Technical Advisors, field examiners, appeals officers, and other field attorneys. They also facilitate coordination of industry issues with the Associate offices.

02. Industry Counsel are selected by the Area Counsel for the Area with responsibility for that particular industry or issue. To provide continuity and adequate support, more than one attorney may be designated as Industry Counsel, or Associate Industry Counsel, including additional attorneys from other Areas.

03. LB&I attorneys designated to provide support to Technical Advisors for an issue rather than for an industry are, for purposes of this subsection, considered Industry Counsel to those Technical Advisors. They are often referred to as "Issue Counsel." In general, the duties and responsibilities of Industry Counsel and Issue Counsel are identical. References in this section to "Industry Counsel" should be read to include Issue Counsel.

04. Industry Counsel develop a close working relationship with the Technical Advisors. They actively seek to identify and assist with the management of industry issues. They provide timely, informed, and practical advice on substantive, procedural, and tactical questions. They work with the Technical Advisor to prepare material for team meetings, requests for published guidance projects, requests for formal legal advice, and proposed Coordinated Issue Papers. They also work with Appeals in developing Appeals Settlement Guidelines and Appeals Coordinated Issues.

05. Industry Counsel work with the Technical Advisor to maintain channels of communication and effective working relationships with industry groups, taxpayers, and their representatives. They attend periodic industry working sessions to discuss emerging issues, recent developments, and other matters of significance relating to the industry.

06. Industry Counsel provide assistance nationwide to field attorneys, examination personnel and Appeals. They are familiar with the major industry cases. They assist examination teams and field counsel advising the teams in obtaining other Counsel support in areas such as requesting legal advice, case development, and issue coordination. They are aware of settlement trends on significant industry issues and provide advice as requested on settlement of specific cases. They take an active role in coordinating litigation affecting industry issues, and recommendations for designating industry issues for litigation. They may participate in the trial of an industry issue, depending on their workload and the significance of the issue.

07. Industry Counsel keep informed about significant industry issues that are under consideration by Associate Chief Counsel offices. They comment on, and may be included in, any guidance project relating to a significant industry issue. In particular, Industry Counsel ensure that the Associate Chief Counsel offices have a full understanding of the industry background and potential ramifications of such issues.

08. Industry Counsel are Division Counsel’s experts as to their assigned industry or issue. Industry Counsel gain knowledge of industry practices and issues. Priority is given to developing and sharing industry expertise through external and internal training, subscribing to trade publications and attending industry meetings.

09. The Deputy Commissioner (International), the Industry Director, the Director, Pre-Filing & Technical Guidance, or Field Specialists may assemble Emerging Issue Teams, which may recommend coordination, administrative guidance, or published legal guidance for emerging issues. In most instances, these teams will include Industry Counsel.

10. Industry projects and cases will occupy a substantial part of the Industry Counsel’s workload. Each Industry Counsel and supervisor will give industry assignments priority over other work assigned. Other work will be reassigned when necessary to accommodate this priority.

11. Associate Offices. An Associate Office, at the request of Division Counsel (LB&I), may appoint an attorney to be available for coordination of industry issues with the Industry Counsel and Technical Advisor.


**33.3.4.2** **(08-11-2004)**

### Procedures for Associate Chief Counsel Review of Proposed Coordinated Issue Papers

1. Technical Advisors are responsible for developing coordination of key industry compliance issues. One tool used by Technical Advisors to ensure nationwide examination consistency in development and treatment of an issue is the Coordinated Issue Paper (CIP). The CIP is processed by the Director (Pre-Filing &Technical Guidance) and approved by an Associate Chief Counsel office. After review and approval, the CIP is distributed to the field managers.


**33.3.4.2.1** **(12-10-2010)**

#### Review Process

1. The CIP is submitted to the Director (Pre-Filing & Technical Guidance). The Director (PFTG) forwards the paper to the Division Counsel (LB&I) headquarters (attn: Special Counsel (PFTG)). Division Counsel (LB&I) controls and forwards the CIP to Technical Services Section (TSS) for assignment to the Associate Chief Counsel office with primary issue jurisdiction. To the extent possible, Division Counsel indicates the appropriate Associate office for assignment. The Associate office has 90 days to review the CIP once received by TSS. The prime Branch is responsible for ensuring that all issues in the CIP are properly coordinated with the Associate office(s) having jurisdiction over the relevant issue. These coordination efforts must be completed within the time allowed for review and the prime Branch issues one response that contains all Counsel comments on the proposed CIP. TSS runs a report of the pending CIP assignments monthly. Copies of this report are furnished to each Associate and Division Counsel (LB&I).

2. **Initial Contact with LB&I**. Within seven calendar days, the prime attorney should contact the Technical Advisor responsible for drafting the CIP and Division Counsel (LB&I) to inform them that the CIP is under review.

3. **Request for Assistance from Other Associates**. If the prime attorney identifies issues that are outside the prime Associate office’s jurisdiction, an assistance request should be prepared within seven calendar days of assignment. Division Counsel (LB&I) should be notified of assistance requests.



1. The prime attorney will send an assistance request, along with a WLI TECHMIS control sheet for the assistance WLI, to each office providing assistance. All relevant background material (e.g., draft CIP, prior legal advice) will be attached to each assistance request. It is the responsibility of the attorney to ensure that the WLI assistance information is entered into TECHMIS.

2. The assistance request must state the date by which the prime attorney needs the response in order to respond within 90 days. Generally, the office providing assistance should have no less than 45 calendar days to respond.

3. It is the prime attorney’s responsibility to follow up on all requests for assistance to ensure that the response is received in time to be incorporated into Counsel’s response. Late outstanding assistance requests should be promptly elevated to a Branch reviewer.


4. **Scope of Review**. In general, the Associate Chief Counsel reviews proposed CIPs for technical accuracy. Counsel will also evaluate and comment on the appropriateness of the CIP in light of factors such as pending or anticipated guidance or litigation activities. Counsel may approve the CIP as written or recommend changes. If Counsel concludes that the CIP has technical flaws, it will state its reasons, outline the problems that need to be addressed and recommend solutions.



1. The prime attorney is encouraged to work directly with the Technical Advisor and Industry Counsel informally (by telephone, email, fax, memoranda, or conference) to revise or supplement the CIP, as needed. The CIP remains assigned to the prime attorney pending the resolution of any questions or suggested revisions.

2. After completing the review (and receiving assistance, if any, from other Associate offices), the prime attorney prepares and forwards, through normal review channels, a final comment memorandum. The final comment memorandum will describe or include a version of the CIP that can be approved by Counsel without further substantive review. Alternatively, if the CIP cannot be revised to be legally correct or, if the issue addressed is inappropriate for a CIP, the final comment memorandum will state that conclusion. For procedures regarding resolution of conflicting views, see IRM 4.51.2.4, LB&I Coordinated Issues.

3. If, at any time during its review of the CIP, the prime attorney briefs the Associate Chief Counsel relative to the CIP or its issue, the Director (Pre-Filing & Technical Guidance) and Division Counsel (LB&I) will be advised of, and may be invited to participate in, the briefing.


5. **Signature level and Case Closure**. Counsel’s comment memorandum regarding the CIP is signed by the Associate Chief Counsel and forwarded, via the Division Counsel (LB&I), to the Director (PFTG). The CIP file should be organized and submitted for closing and all TECHMIS assignments, including all WLIs, should be closed.


**33.3.4.2.2** **(12-10-2010)**

#### Time-Frame for Review

1. The review of CIPs will be completed within 90 days of receipt and assignment by TSS. The review is complete when the Associate Chief Counsel executes Counsel’s final comment memorandum. If completion cannot occur within the 90 days, the prime attorney will communicate the reasons for the delay, and the expected completion date, directly to the Technical Advisor and the Division Counsel (LB&I), with information copies to the Associate Chief Counsel, Director (PFTG) and TSS.


**33.3.4.2.3** **(12-10-2010)**

#### Status Update

1. The Special Counsel (Pre-Filing and Technical Guidance) in the Office of the Division Counsel (LB&I) will be the primary contact to inquire about the status of any proposed CIP which is under development or pending review in Counsel.


**33.3.4.2.4** **(12-10-2010)**

#### De-coordination Procedures

1. The authority to de-coordinate an issue rests solely with the Commissioner (LB&I), generally based on advice from the Director (PFTG) and/or Industry Director(s) in consultation with Division Counsel (LB&I).


**33.3.4.3** **(12-10-2010)**

### Coordination with Industry and Issue Programs

1. Coordination with Industry Counsel is required whenever Counsel attorneys encounter issues in these areas.

2. Practice group attorneys should coordinate industry and issue specialization issues, in both docketed and nondocketed cases, with Industry Counsel.



1. Practice group attorneys (including Special Trial Attorneys) in all Divisions will contact Industry Counsel on issues which:

      • Are the subject of a coordinated issue paper or the Industry Issue Resolution process,

      • Have been identified as emerging industry issues on the relevant Industry Technical Advisor website,

      • Gave the potential to become an industry issue, or

      • May significantly affect an industry issue.

2. For assistance in determining whether an issue requires coordination, the attorney may consult the LB&I Technical Advisors web pages, which include specific industry guides (available through the Service’s LB&I PFTG site ), or contact either the Industry Counsel or Technical Advisor.

3. If the practice group attorney and Associate Area Counsel remain uncertain about which Industry Counsel should be contacted, they should contact their Deputy Area Counsel (Industry Programs) for assistance. Responsibility for assuring appropriate coordination resides with the practice group Associate Area Counsel.


3. The Industry Counsel may take an active role in cases affecting industry issues. Unless otherwise agreed, the practice group attorney will retain primary responsibility for handling an industry issue. The practice group attorney will informally coordinate with the Industry Counsel via telephone and email to ensure that industry issues are developed and handled in a manner that promotes consistency and the proper legal outcome. Practice group attorneys will send to the Industry Counsel copies of their written advice (including email messages) on industry issues. If there is a disagreement between the practice group attorney and Industry Counsel that cannot be resolved between them, they must elevate the issue to their respective managers for resolution.

4. When an Industry Counsel is contacted on an issue arising from a specific audit, the Industry Counsel must advise the Associate Area Counsel responsible for the audit location. When a taxpayer contacts an Associate Chief Counsel Office concerning a significant industry issue, the attorney in the Associate Office should notify the Industry or Issue Counsel. When an Industry Counsel receives an inquiry directly from an audit team or field attorney, the Industry Counsel should coordinate with the Technical Advisor and Associate Chief Counsel, as appropriate.

5. Industry Counsel should coordinate with the appropriate Associate Chief Counsel Office to assure an issue reflects the correct interpretation of the law as applied to the facts of the particular case. The Industry Counsel should consult with the Technical Advisor concerning proposals for published guidance that may affect industry issues.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part33/irm_33-003-004#addtoany "Show all")

A2A