---
url: "https://www.irs.gov/irm/part35/irm_35-007-003"
title: "35.7.3 Review of Briefs | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-007-003#main-content)

- 35.7.3 [Review of Briefs](https://www.irs.gov/irm/part35/irm_35-007-003#idm140689619592736)
  - 35.7.3.1 [Prebriefing Discussion](https://www.irs.gov/irm/part35/irm_35-007-003#idm140689619580480)
  - 35.7.3.2 [Review of Briefs by the Associate offices](https://www.irs.gov/irm/part35/irm_35-007-003#idm140689634322384)

    - 35.7.3.2.1 [Briefs Not Directly Filed With the Tax Court](https://www.irs.gov/irm/part35/irm_35-007-003#idm140689608013072)
    - 35.7.3.2.2 [Submitting a Brief for Review](https://www.irs.gov/irm/part35/irm_35-007-003#idm140689608016688)
    - 35.7.3.2.3 [Purpose and Scope of Review Coordination with Field](https://www.irs.gov/irm/part35/irm_35-007-003#idm140689593974512)
    - 35.7.3.2.4 [Reviewing Attorneys Responsibility and Revisions of Briefs](https://www.irs.gov/irm/part35/irm_35-007-003#idm140689634491456)
    - 35.7.3.2.5 [Brief Review Checksheet](https://www.irs.gov/irm/part35/irm_35-007-003#idm140689634312336)

  - 35.7.3.3 [Briefs Directly Filed With the Tax Court](https://www.irs.gov/irm/part35/irm_35-007-003#idm140689590496320)

    - 35.7.3.3.1 [Briefs Which May Be Directly Filed by Field Counsel](https://www.irs.gov/irm/part35/irm_35-007-003#idm140689608012864)
    - 35.7.3.3.2 [Filing and Service of Briefs](https://www.irs.gov/irm/part35/irm_35-007-003#idm140689634318080)

# Part 35. Tax Court Litigation

# Chapter 7. Tax Court Briefs

# Section 3. Review of Briefs

* * *

## 35.7.3 Review of Briefs

**35.7.3.1** **(08-11-2004)**

### Prebriefing Discussion

1. Prebriefing is only required for briefs that must be reviewed in an Associate office. The position taken in all briefs must be in accord with Service position. The Field attorney should determine Service position on the legal issues before trial, coordinating with the Associate office as appropriate. If points are developed at trial or new cases are decided before the brief is completed in Field Counsel which raise questions as to whether the case, or an issue therein, should be submitted to the court for decision, appropriate inquiries should be made of the Associate office. It may be preferable to complete the brief and forward it to the Associate office with a memorandum setting forth the particular items which should be considered in review and in determination of the position of the Service because of the new developments.

2. In preparing a brief, the Field attorney and the reviewer should always bear in mind that the brief is prepared in the name of the Chief Counsel, and that the Field attorney is stating the legal position of the Office of Chief Counsel and not necessarily the attorney’s or reviewer’s personal views. Changes made in the brief by an Associate office are intended solely to place the brief in such form and substance as may be approved for execution on behalf of the Chief Counsel.

3. The following procedures must be followed for any brief which is not directly filed with the Tax Court ( _see_ CCDM 35.7.3.3):



1. These procedures are intended to create a dialogue between Field Counsel and the Associate office so that Field Counsel can be aware of recent developments in office position, the Associate office can be aware of the existence of the case and necessity of a brief, and agreement on the substantive content of the brief can occur before resources are expended on drafting the brief. Prebriefing discussion should reduce the need for making major substantive changes in the brief at the last minute and will provide an additional mechanism to resolve differences of opinion before final review of the brief. Such discussion could also result in a determination that formal review by an Associate office is unnecessary or only abbreviated review is appropriate.

2. These procedures are not intended to modify the significant case coordination procedures set forth in CCDM 31.2.1, nor to supplant normal procedures for determining the Service’s position. The design of these procedures is to enhance and supplement a team concept to setting forth, in the most effective way possible, the litigation position of the Service.


4. Within ten working days from the date that briefing dates are set, Field Counsel will send the following prebriefing materials by email to the Technical Services Support Branch or if mailed, to the





> Associate Chief Counsel
>
> (CC:PA:LPD:TSS)
>
> Room 5331
>
> 1111 Constitution Avenue, N.W.
>
> Washington, D.C. 20224:





1. A copy of the statutory notice of deficiency or other appropriate notice of determination, and the pleadings if the pleadings raise any new issue not contained in the notice;

2. A copy of the stipulation(s) of facts (but generally not stipulated exhibits);

3. Copies of all trial memoranda filed by all parties;

4. Copies of any exhibits or trial submissions crucial to the resolution of the case; and

5. A prebrief memorandum disclosing any critical evidence or case citation not revealed by the above items, and advising of the briefing schedule and any problems in the case which might not be revealed by items a. through d. or the record, and any previous Associate office involvement. Ordinarily, other trial preparation documents such as discovery and trial transcripts will not be considered as mandatory initial submissions. Attorneys should use their sound judgment in providing the material necessary for an informed and knowledgeable review of the issues in the case. As part of the prebrief discussion, the assigned Field and Associate offices attorneys should arrange for the prompt submission to the assigned Associate office attorneys of all relevant materials (by fax, email, or mail) necessary for review of the brief. Once an Associate office attorney is assigned on TLCATS, any such materials to be used in reviewing the brief should be sent to the attention of that attorney and clearly labeled as supplemental brief review material. For example, if the issue involves an interpretation of a written document ( _e.g._, contract, will, trust, etc.), that document would be considered crucial and should be submitted with the initial documents. It is anticipated that the prebrief memorandum will not be extensive and normally will be included on the transmittal form with the required and optional document submissions.


5. Upon receipt of the prebrief memorandum, the case will be assigned for review by an attorney in an Associate office who will be responsible for the review of the brief itself. Field Counsel will be notified informally (usually by telephone or email) of this assignment within five days of receiving the prebrief memorandum. The prebrief memorandum shall be coordinated with an Associate office under the procedures for briefs. The Associate offices will determine whether (1) the position asserted for respondent is consistent with the Service position, (2) arguments need to be added or modified, and (3) the Associate offices can supply informal assistance in the preparation of the brief. The appropriate Associate offices will orally advise Field Counsel in every case of its views within ten working days from the day the prebrief memorandum is received by the Associate office, even if no changes or additions are proposed. Advice provided by the Associate offices will be memorialized and reviewed as informal advice and copies will be mailed or sent via email to the submitting field attorney. The attorney in the Associate office will provide the Field attorney with copies of any documents that will assist Field Counsel in preparing the brief (such as position papers, memoranda, and briefs presenting the same issue in similar cases). If the Associate office and Field Counsel do not agree on the proper formation or content of the brief, the attorneys (and if necessary, their reviewers) will resolve the dispute during the time of brief preparation.

6. In the course of the review and discussion, the Associate office may waive final prefiling review of the brief, even if the issue does not appear on the direct file list or if review of the brief is normally mandatory ( _see_ CCDM 35.7.3.2). Such a waiver will be memorialized via email to the submitting field attorney for retention in the legal file. This procedure does not modify the internal mailing date requirements for review.

7. Field Counsel and the Associate offices should also coordinate on reply briefs in a fashion which will carry out the objectives of these procedures.


**35.7.3.2** **(08-11-2004)**

### Review of Briefs by the Associate offices

1. Briefs which require review are reviewed by the Associate offices having jurisdiction of the principal issue or issues involved. The work handled by each of Associate offices is divided by subject matter and/or Internal Revenue Code sections. To the extent feasible, there are attorneys with expertise in each Associate office on the important subject matters in litigation. Thus, while a brief is assigned to one Associate office for overall review, there is appropriate coordination with other Associate offices as to issues involving the specialities of those offices


**35.7.3.2.1** **(08-11-2004)**

#### Briefs Not Directly Filed With the Tax Court

1. It is imperative that all briefs filed with the Tax Court assert positions consistent with Service’s legal positions and policies and uphold the office’s reputation for the highest quality of written product. In order to ensure these attributes, a number of briefs, prepared by Field attorneys, are reviewed by the Associate offices before filing. A brief must be reviewed by an Associate office if any issue appears on Exhibit 35.11.1–1, Issues Requiring Associate Office Review.

2. Even though a case involves issues which do not require review, novel, unusual or unique questions may be presented. It is the responsibility of the docket attorney and the reviewer in Field Counsel to identify those cases involving issues presenting such questions as to warrant review by an Associate office, and to forward the brief for such review according to present procedures.


**35.7.3.2.2** **(08-11-2004)**

#### Submitting a Brief for Review

1. All briefs requiring review by an Associate office are to be submitted via email to "TSS4510" for receipt at least ten calendar days prior to the due date, so that there will be time for an adequate review of the brief and for any coordination of the case which may be necessary. Reply briefs should be received seven calendar days prior to the due date. If the due date of the brief is 30 days or less from the date of trial, Field Counsel and the Associate office will consult and agree on the date that the brief must be submitted for review. A Field reviewer and Associate office branch reviewer can also agree to shorten the required review periods for other cases. Any agreement to deviate from the ten day and seven day rules should be memorialized in a fax or email from the Associate office reviewer to the Field reviewer, so that there will be no confusion concerning the required due date. At the time the brief is emailed to the Technical Services Support Branch ("TSS4510" ), the legal file containing a copy of the brief and background documents should be mailed to:



> Associate Chief Counsel
>
> (CC:PA:LPD:TSS)
>
> Room 5331
>
> 1111 Constitution Avenue, N.W.
>
> Washington, D.C. 20224

2. Only the final draft of a brief ready for filing with the Tax Court should be sent to the Associate office for review. By submitting a brief to "TSS4510" by email, the Field reviewer attests that the brief has been reviewed and, except for review by the Associate offices and a signature, is ready for filing with the Tax Court. The email transmittal must be sent by the reviewing manager (or a delegate) in Field Counsel to the mailbox "TSS4510." If the brief is sent by a delegate, the transmittal message should explicitly state that "\[Name and title\] has completed the brief review so that, except for Associate office review and signature, it is ready for filing with the Tax Court, and has authorized \[sender’s name\] to forward the brief."

3. The emailed memorandum transmitting the brief to the Associate offices should point out: questions of first impression; novel or unusual problems; lack of conformity with regulations, rulings, etc.; or any other feature which Field Counsel deems advisable for special consideration by the Associate offices. The transmittal should specifically state whether the court has imposed any page limitation on the brief and provide a complete description of any such limitation ( _e.g._, whether it applies to any particular portion of the brief, such as the Argument or Points Relied Upon portions). This information is extremely helpful to the Associate offices in timely completing the review of the brief. If trouble areas are spotted prior to a detailed review, the Associate offices will be able to determine at an earlier date whether an extension motion may be required so that petitioner’s counsel can be advised.

4. In the exceptional case where the filing of the brief is to be made by an Associate office, the transmittal memorandum should state whether petitioner is represented by attorneys with different office addresses, or whether petitioners in a consolidated group are represented by different attorneys. This information is necessary so that the Associate office may file with the court enough copies of the brief for all counsel.

5. A brief will be considered received as of the date it is " received" in the "TSS4510" mailbox if it is received by 3:00 p.m. Eastern Time on a day on which the United States Postal Service delivers regular mail to the Associate office. Transmittals received in the "TSS4510" mailbox after 3:00 p.m. Eastern Time on a business day, or on any weekend or holiday, will be deemed received on the next business day.

6. For review of seriatim and reply briefs, a copy of the petitioner’s brief should be forwarded upon receipt by the Field attorney.

7. Briefs must be prepared in Word and must be named using the " .doc" extension; any transmittal should specify which version was used. Briefs over 60 pages must be zipped before being transmitted. Drafts may be exchanged directly between the assigned attorneys under the prereview process, without a formal brief review assignment, if all the parties have agreed to work on a draft of the brief. The submission of a draft, however, will not comply with the prereview or pre-filing brief review requirements. To facilitate necessary changes, all briefs must be accompanied by a computer disk containing the brief in Word format, utilizing the features for automatically generating the Table of Authorities, Table of Contents, and automatic paragraph numbering. The Field attorney should request sufficient briefing time at the conclusion of the trial to ensure that these time requirements are met. New software specifications will be provided if and when the Office of Chief Counsel migrates to a succeeding word processing platform.

8. The above information is required to be provided in the brief transmittal, whether by email or by Form 2237, Counsel Transmittal Memorandum.


**35.7.3.2.3** **(08-11-2004)**

#### Purpose and Scope of Review — Coordination with Field

1. The Associate offices are primarily concerned with whether the position taken on the issues is in accord with the Service’s position, or in accord with an Associate office’s interpretation of the applicable provision of the statutes, regulations, rulings, and the decided cases. If the Associate office determines that changes are necessary before the brief can be filed on behalf of the Chief Counsel, the Associate office will discuss the proposed changes with Field Counsel. In such cases, the Associate office will provide their proposed changes to Field Counsel not later than two working days prior to the due date of the brief.

2. It is recognized by the Associate offices that the Field attorney has pride in the brief and in the way of presenting the issues to the court; therefore, to the extent practicable, substantial changes should be discussed with the Field attorney and the Field reviewer. Should Field Counsel disagree with the changes proposed by the Associate office, Field Counsel must determine whether to request reconciliation with respect to the proposed changes. Field Counsel must incorporate the Associate office’s substantive changes into the brief, unless reconciliation procedures have been followed resulting in a final determination by that the Associate office’s changes were erroneous, unnecessary, or inappropriate.

3. Within five days of receiving the brief, the appropriate Associate office will acknowledge receipt of the brief and provide the person submitting the brief the names of the attorneys assigned to such brief. Matters requiring extensive consideration by an Associate office should be anticipated by Field Counsel and in such cases the briefs should be received by the Associate office in sufficient time to permit adequate and complete consideration. Ordinarily, after completion of review in the appropriate Associate offices, Field Counsel will make any necessary changes to the brief as agreed upon between Field Counsel and the Associate offices and mail the completed brief to the Tax Court for filing. A copy of the completed brief as filed must be sent to the Associate offices for normal copying and distribution. Alternatively, Field Counsel and an Associate office may agree that the filing of any individual brief will be made by an Associate office.


**35.7.3.2.4** **(08-11-2004)**

#### Reviewing Attorney’s Responsibility and Revisions of Briefs

1. The Associate office attorney assigned to the review of a brief has the following responsibilities:



1. To ascertain the facts of the case in detail and to research the applicable statutes, regulations, rulings, case law, and office positions.

2. To verify the legal arguments made are based on requested findings of fact and that those facts are supported by the record before the court.

3. To determine whether the position taken by Field Counsel is in accord with current Service position, whether there is under consideration the establishment of a Service position which may be affected by the position taken in the brief, and whether the proposed position is in accord with the position taken in published guidance or in other cases pending in Tax Court, the district courts, the court of Federal Claims, the courts of appeals or the Supreme Court.

4. To ascertain whether there are any technical problems involved which necessitate coordination with other Associate offices or with the Commissioner’s office.

5. To analyze whether a logical and sound legal argument has been made on the issues as well as to ascertain the overall effectiveness of the brief.

6. To bring to the attention of the reviewer any problem or potential problem in the submission of the brief or case to the court.


2. Changes are not to be made in a Field Counsel brief merely for the sake of change or because the reviewing attorney would have used a different style in writing. All changes proposed by the reviewing attorney in a brief are to be made only with the approval of the reviewer.

3. The Associate office will advise Field Counsel of proposed changes to be made in the brief at least two days before the brief due date absent exigent circumstances.


**35.7.3.2.5** **(08-11-2004)**

#### Brief Review Checksheet

1. A brief review checksheet is utilized by Associate offices in their review of Tax Court briefs. The checksheet is intended to help field offices identify strengths and weaknesses, concentrate on any shortcomings, and ultimately obtain a better quality product. The checksheet identifies several quality factors which should be of interest to the originating field office and gives the Associate office’s evaluations and comments on those factors.

2. A checksheet will be prepared by the Associate office on each Tax Court brief received for review. Briefs will be evaluated in accordance with the general guidelines for brief form and content set forth in CCDM 35.7.2 _et seq_. The reviewing attorney will complete the checksheet and add any pertinent comments that may be of benefit to the originating office. Copies of the completed checksheet will be sent to the originating field office, and to Division Counsel.


**35.7.3.3** **(08-11-2004)**

### Briefs Directly Filed With the Tax Court

1. This subsection discusses briefs that are directly filed with the Tax Court.


**35.7.3.3.1** **(08-11-2004)**

#### Briefs Which May Be Directly Filed by Field Counsel

1. Briefs addressing issues that are not listed on Exhibit 35.11.1–1 (Issues Requiring Associate Office Review) may be directly filed with the Tax Court by Field Counsel. As a general rule, if there is any doubt or hesitation as to whether the brief is one of the types which should be reviewed by an Associate office, it would be preferable to send it to such office for review prior to filing.

2. For those briefs which are directly filed by Field Counsel, it is the responsibility of the Field reviewer to ensure that they are correct factually and legally and of the highest quality.

3. The timely filing of briefs with the court is critical. While the "timely mailing as timely filing" provisions of section 7502 apply to the filing of Tax Court briefs, field offices ideally should mail all briefs in sufficient time so that they will be received by the court on or before the due date. See T.C. Rule 22. Each brief should be mailed separately by certified mail or via a designated private delivery service qualified under section 7502(f). The brief should not be mailed in the same envelope with any other documents being directly filed with the court. If possible, the person posting the brief by certified mail should attempt to have the United States Postal Service postmark the envelope containing the brief. In addition, a postmarked sender’s receipt for certified mail, or receipt provided by a designated private delivery service under section 7502(f), should be retained in the event it is necessary to prove timely mailing of the brief to the court.

4. Field Counsel must forward two copies of every directly filed brief to the Technical Services Support Branch ("TSS4510"), Associate Chief Counsel (CC:PA:LPD:TSS), Room 5331, 1111 Constitution Avenue, N.W., Washington, D.C. 20224 at the same time the original is mailed to the court. The transmittal to TSS4510 should identify the issues and the exception which permits the direct filing without review by an Associate office. One copy of the brief will be forwarded TSS4510 to the appropriate Associate office for determination if formal post review of the brief is required. Within five days of the receipt of the brief, the Associate office will make the determination if formal post review of the brief is required. This determination will be recorded on the Post Review of Direct Filed Briefs form and returned to TSS4510. One copy of the direct filed brief will be forwarded to the Digest room where they are indexed and stored for future use.


**35.7.3.3.2** **(08-11-2004)**

#### Filing and Service of Briefs

1. Ordinarily, Field Counsel will direct mail all briefs to the Tax Court for filing, including those briefs required to be reviewed by the Associate offices. _See_ CCDM 35.7.3.2. Alternatively, Field Counsel and an Associate office may agree that the filing of any individual brief will be made by the Associate office. T.C. Rule 151(c) provides that service of briefs will be made by the Clerk of the Court unless the brief bears a certificate of service, and except that, in the event of simultaneous briefs, briefs are not to be served until the corresponding brief of the other party has been filed, unless the court directs otherwise. Accordingly, simultaneous briefs ordinarily should not be served on the opposing party. Instead, the Clerk will effectuate service on petitioner upon receipt of petitioner’s brief.

2. Petitioners’ counsel often furnish courtesy copies of their briefs to the respondent’s attorney or serve their briefs directly on respondent’s field office. In the spirit of the Tax Court’s rule mandating simultaneous service of simultaneous briefs, respondent’s counsel should generally avoid reading petitioner’s brief until counsel has either direct mailed respondent’s brief to the court or otherwise confirmed that respondent’s brief has been filed.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-007-003#addtoany "Show all")

A2A