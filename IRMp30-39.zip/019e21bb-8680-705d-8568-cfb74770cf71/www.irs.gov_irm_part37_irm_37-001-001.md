---
url: "https://www.irs.gov/irm/part37/irm_37-001-001"
title: "37.1.1 Written Determinations Under Section 6110 | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part37/irm_37-001-001#main-content)

- 37.1.1 [Written Determinations Under Section 6110](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624295700960)
  - 37.1.1.1 [Administration of Section 6110](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624294969408)

    - 37.1.1.1.1 [Definitions](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624334543664)

  - 37.1.1.2 [Procedures for Release to Public](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624308531008)

    - 37.1.1.2.1 [Editing for Section 6110 Purposes](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624300370480)
    - 37.1.1.2.2 [Guidelines and Standards for Deletion and Review Other ThanChief Counsel Advice](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624334403344)
    - 37.1.1.2.3 [Disagreement as to Deletions Other Than Chief Counsel Advice](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624334358512)
    - 37.1.1.2.4 [Preparation of Section 6110 Copies Other Than Chief CounselAdvice](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624289514784)
    - 37.1.1.2.5 [Mailing Procedures Written Determinations Other than ChiefCounsel Advice](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624291396128)
    - 37.1.1.2.6 [Section 6110 Coordination](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624319475888)
    - 37.1.1.2.7 [Pre-issuance Associate Chief Counsel Quality Review](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624319435168)
    - 37.1.1.2.8 [Requests for Additional Disclosure](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624291581360)
    - 37.1.1.2.9 [Communications from Third Parties](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624306524160)

  - 37.1.1.3 [Processing Chief Counsel Advice](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624319528752)

    - 37.1.1.3.1 [Taxpayer Specific Chief Counsel Advice](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624319485408)
    - 37.1.1.3.2 [Non-Taxpayer Specific Chief Counsel Advice](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624280032304)

  - 37.1.1.4 [Administrative Disclosure Cases](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624296792784)
  - 37.1.1.5 [Section 6110 Disclosure Suits](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624283946752)

    - 37.1.1.5.1 [Actions to Restrain Disclosure](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624292580000)
    - 37.1.1.5.2 [Actions to Compel Disclosure](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624334534096)

  - 37.1.1.6 [Requisitioning of Technical Records](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624290835136)
  - 37.1.1.7 [Coordination of Proposed Disclosure of Information Contained inService Technical Files](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624307924736)
  - 37.1.1.8 [User Fees](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624334356000)

    - 37.1.1.8.1 [Determining the Correct Fee for a Submission](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624319404144)
    - 37.1.1.8.2 [Refunds](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624319433040)
    - 37.1.1.8.3 [Additional Fee](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624287896128)
    - 37.1.1.8.4 [Returned Checks](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624319443040)
    - 37.1.1.8.5 [Appeals](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624305256304)

  - 37.1.1.9 [Request for Delay of Disclosure for Public Inspection](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624282215328)

    - 37.1.1.9.1 [Initial Request for Delay](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624284113648)
    - 37.1.1.9.2 [Request for Additional Delay](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624298363808)
    - 37.1.1.9.3 [Procedures](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624306419280)

  - Exhibit 37.1.1-1 [General Coding Sheet (Green sheet)](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624302490912)
  - Exhibit 37.1.1-2 [Refund Request for User Fee Chief Counsel](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624305410608)
  - Exhibit 37.1.1-3 [Refund Codes](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624294595696)
  - Exhibit 37.1.1-4 [Information Sent to IR 5334 after Requesting an Additional Fee](https://www.irs.gov/irm/part37/irm_37-001-001#idm139624294201440)

# Part 37. Disclosure

# Chapter 1. Sections 6110 and 6103 of Title 26

# Section 1. Written Determinations Under Section 6110

* * *

## 37.1.1 Written Determinations Under Section 6110

**37.1.1.1** **(08-11-2004)**

### Administration of Section 6110

1. This section covers the processing of written determinations authored by professional employees in the national office under section 6110. Section 6110 requires that written determinations must be made available for public inspection. For purposes of this subsection, "national office " means Associate or Division Counsel offices.

2. Docket, Records and User Fees. The Docket, Records, and User Fee Branch (Docket & Records) within the office of the Associate Chief Counsel (P&A), Legal Processing Division, controls all incoming fee cases on CASE-MIS and forwards them to the appropriate office. The Docket & Records Branch is also responsible for storing and managing the records of the Associate Chief Counsel (Corporate), the Associate Chief Counsel (International), the Associate Chief Counsel (Passthroughs & Special Industries), the Associate Chief Counsel (Financial Institutions & Products), the Associate Chief Counsel (Income Tax & Accounting), and the Associate Chief Counsel (Tax Exempt/Government Entities).

3. Disclosure and Litigation Support Branch. The Disclosure and Litigation Support Branch (Disclosure Branch) within the Office of the Associate Chief Counsel (P&A), Legal Processing Division, is responsible for the processing of written determinations, including Chief Counsel advice, for public inspection in accordance with section 6110. The Disclosure Branch processes requests by taxpayers for additional deletions to the written determinations and their background file documents. The Disclosure Branch also mails all rulings, technical advice memorandums, and Chief Counsel advice that are subject to disclosure under section 6110. Copies of outgoing correspondence may be faxed to taxpayers at the request of the branch. Requests for public inspection delays, because a transaction has not been completed, are processed by the Disclosure Branch.


**37.1.1.1.1** **(08-11-2004)**

#### Definitions

1. Written determinations. "Written determination" means a ruling, determination letter, technical advice memorandum, or Chief Counsel advice. The public inspection provisions apply only if the written determination is issued. A letter ruling is issued when it is signed by the appropriate official (e.g., branch chief, senior technician reviewer) and mailed by the Disclosure Branch or picked up by the taxpayer or a representative of the taxpayer. A technical advice memorandum is issued on the date the requesting official furnishes a copy to the taxpayer. Correspondence relating to withdrawals of letter ruling requests and technical advice requests is not subject to public inspection. Also, technical advice memorandums that are being reconsidered in an Associate Office before a copy is furnished the taxpayer are not subject to public inspection. In these instances, no written determination has been issued for section 6110 purposes.



### Note:



By statutory definition, Treasury regulations are not written determinations subject to section 6110.

2. Background File Documents. "Background file document" includes the request for a written determination, any written material submitted in support of the request, and any communication — written or otherwise — between the Service and persons outside the Service in connection with the written determination received before issuance of the written determination.



### Note:



Communications between the Service and the Department of Justice relating to a pending civil or criminal case or investigation do not fall within communications covered by section 6110.

3. Other Background Documents. Written determination files contain information other than the final determination letter and the statutorily defined "background file documents." These might include, for example, drafts of the letter or memorandum and communications within or between the Service and/or Office of Chief Counsel (other than the request). These other documents, while not subject to public disclosure under section 6110, are subject to the FOIA. See CCDM 30.11 for treatment of these documents.

4. Chief Counsel Advice. "Chief Counsel advice" is written advice or instruction prepared by any national office component of the Office of Chief Counsel that is issued to counsel or service field or Service campus employees which interprets or sets forth policy with respect to a revenue provision. See section 6110(i)(1). A Chief Counsel advice is issued when the drafting office date stamps the final copy and forwards it to the recipient. See CCDM 33.1.1.5.3.3 .

5. Other Chief Counsel Documents. Section 6110(i)(2) provides that the Secretary may, by regulation, designate any other advice prepared by the Office of Chief Counsel as Chief Counsel advice subject to section 6110 procedures. Once regulations are promulgated, these procedures will apply to such designated documents as well.


**37.1.1.2** **(08-11-2004)**

### Procedures for Release to Public

1. While the specifics of drafting written guidance are covered elsewhere in the CCDM, the following considerations should be kept in mind while drafting written determinations in order to assist the section 6110 process.


**37.1.1.2.1** **(08-11-2004)**

#### Editing for Section 6110 Purposes

1. If a taxpayer conference is scheduled in accordance with established procedures, the professional employee to whom the matter is assigned (professional employee) may discuss suggested deletions if it appears that the language in question will ultimately appear in the written determination and the language is not in the Office of Chief Counsel’s view properly withheld under section 6110(c). Otherwise, suggested deletions should not be discussed with the taxpayer until the written determination is prepared, reviewed, and is ready for signature and mailing.

2. Taxpayers’ names, addresses, and other identifying details of the person to whom the written determination pertains and of _any other person_ should not be used in the written determination. See CCDM 37.1.1.2.2. To facilitate the editing process and aid reader comprehension, symbols, letters of the alphabet, or other designations such as " taxpayer" , "parent" , "subsidiary" , and "authorized representative" must be used in the body of the written determination in lieu of names and numbers. A legend will be included on the first page of the written determination to identify the letters of the symbols used in the body of the letter ruling. Symbols should also be used for other identifying information (addresses, etc.).



### Note:



The author will avoid the inclusion of information that would result in unnecessary disclosure of tax return information. For example, the inclusion of exact dollar amounts, detailed descriptions of property, dates and amounts of stock purchases for stock in public trade, and tax years should be avoided unless such information is _absolutely_ necessary for the recipient’s understanding of the written determination. While some of this information may not identify the taxpayer, it may result in the gratuitous disclosure of return information.

3. Symbols should be used in the body of the written determination if reference to specific dates could identify the taxpayer involved in the written determination. In written determinations that deal with extensions of time, etc., general time frames, such as "within 60 days" or " 3 months," should be used instead of specific dates as use of such specific dates could identify the taxpayer.


**37.1.1.2.2** **(08-11-2004)**

#### Guidelines and Standards for Deletion and Review — Other Than Chief Counsel Advice

1. Before written determinations are made available for public inspection, Treas. Reg. § 301.6110-3 requires the deletion of names, addresses, and identifying numbers (including telephone, license, social security, employee identification, credit card, and selective service numbers) of any person, other than the identifying details of a person who makes a third-party communication discussed in Treas. Reg. § 301.6110(4(a).

2. The regulations also require the deletion of any other information that would permit a person generally knowledgeable with respect to the appropriate community to identify any person in the written determination.

3. The appropriate community could be an industry or geographical community and will vary with the problem involved. For example, the " community" for a steel company will be all steel producers, but may also be the locale in which the main plant is to be located if the written determination deals with a land transaction. The standard is not, however, one of a person with inside knowledge of the particular taxpayer.

4. After the written determination is approved by the reviewer, the appropriate deletions will be made to an electronic version of the document and saved in Word format. Other deletions required include the legend, person to contact, and the contact telephone number. In the case of a technical advice memorandum, the identification of the requesting office is also redacted. A copy of the redacted version of the written determination must remain in the administrative file for eventual forwarding to the Disclosure Branch and the Docket & Records Branch.

5. The initiator prepares and signs the Form M-6691, Written Determination Checklist. The checklist is made part of the administrative file. The first level reviewer, after ensuring that all required actions listed on the checklist have been completed, also signs the checklist.

6. When the written determination is ready for signature and there is agreement between the taxpayer and the Office of Chief Counsel as to suggested deletions reflected in the written determination, it will be signed by the appropriate person. Additionally, in the case of a technical advice memorandum, if no suggested deletions are made by the taxpayer, it will be signed by the appropriate person after deletions required by section 6110 (c) have been made.


**37.1.1.2.3** **(08-11-2004)**

#### Disagreement as to Deletions — Other Than Chief Counsel Advice

1. If there is a disagreement between the taxpayer and the Office of Chief Counsel as to suggested deletions reflected in the written determination, the taxpayer will be contacted by telephone by the professional employee to whom the case was assigned to resolve the disagreement. The conclusion reached in the written determination will not be discussed or alluded to in the conversation. If agreement cannot be reached during the conversation, the taxpayer will be invited to submit, within 14 calendar days of the conversation, further information, lines of reasoning, or other material in support of the view that such material be redacted. The taxpayer will be advised that if no response is received, or in the event of ultimate inability to agree, the written determination will reflect the Office of Chief Counsel’s deletions. A copy of the draft written determination _will not_ be sent to the taxpayer for purposes of examining the Office of Chief Counsel’s suggested deletions.

2. If the taxpayer cannot be contacted by telephone, a short letter will be prepared. This letter will be prepared for the same signature level as the related written determination and will be signed by the person who will sign the related written determination. The letter will specify the areas of disagreement and invite a telephone or written response. The letter will inform the taxpayer that if no response is received within 14 calendar days of the date of the letter, or in the event of ultimate inability to agree, the written determination will be issued reflecting the Office of Chief Counsel’s deletions.


**37.1.1.2.4** **(08-11-2004)**

#### Preparation of Section 6110 Copies — Other Than Chief Counsel Advice

1. For all written determinations other than Chief Counsel advice, after signature and closing, but before transmittal to the Disclosure & Litigation Support Branch and Docket & Records Branch for processing, the issuing branch will make a copy of the full text unredacted version of the written determination, an electronic version, and a sufficient number of photocopies of the highest quality of the redacted version of the written determination for distribution as follows:



   - One copy for each addressee

   - One copy for each person (such as an authorized representative) who is to be furnished a copy of the written determination

   - Two copies for public inspection purposes

   - One copy for the administrative file



     ### Note:



     _All_ published guidance, i.e., Revenue Rulings, Revenue Procedures, Notices, and Announcements, and all legal advice such as Private Letter Rulings, Technical Advice Memorandums, and Chief Counsel advice, _must_ be written using the eWord macros and redacted using the eWord toolbar.


2. After completion of the action required by paragraph (1), above, the issuing branch will forward the photocopies of the redacted version and the administrative file to the Disclosure & Litigation Support Branch. The redacted electronic version will be forwarded using the eWord " submit" function within five days of completion or issuance of the written determination.

3. The issuing branch is responsible for annotating on the original and all copies



1. The Code section identification number from Publication 1102, Uniform Issue List, on the upper left corner; and

2. Any third-party communications. The third-party annotations shall consist of the date on which the contact was made and the category of the person making the contact, such as "Congressional" , " Treasury" , or "trade association." See CCDM 37.1.1.2.9 for third-party communication.


4. Before transmittal to the Disclosure & Litigation Support Branch, the determination of whether or not the case is subject to section 6110 procedures will be noted on the Branch Case Assignment Data Sheet.

5. The file will then be forwarded through appropriate channels to the Disclosure & Litigation Support Branch for processing. In submitting the file for processing, branch personnel will date all copies of the written determination and all of the administrative documents in the file. If the taxpayer has indicated a desire to pick up the written determination in person, see paragraph (6) below.

6. Neither taxpayers nor their representatives are permitted to pick up letter rulings in person. Taxpayers or their representative may request that the Service fax a copy of a letter ruling to either the taxpayer or representative provided the request is in writing and includes the recipient’s fax number. Further, a representative must be authorized to receive either the original or a copy, pursuant to either a power of attorney or a Form 8821, Tax Information Authorization. The professional employee will prepare a Form M-7372, Fax Cover Sheet, and attach it to the top of the administrative file when the file is forwarded to the Disclosure & Litigation Support Branch. Fax copies will be prepared and sent by the Disclosure & Litigation Support Branch. The professional employee should caution the taxpayer or the representative that the fax copy is not an "issued" copy since it does not contain the appropriate Notice of Intention to Disclose and, therefore, that they are not entitled to rely on it. The case file is forwarded through normal channels to the Disclosure & Litigation Support Branch, with the blue paper Form M-7372 prominently displayed. If a copy cannot be sent by fax, it will be mailed.


**37.1.1.2.5** **(08-11-2004)**

#### Mailing Procedures — Written Determinations Other than Chief Counsel Advice

1. The Disclosure & Litigation Support Branch is responsible for mailing all letter rulings and technical advice memorandums.



### Note:



Before the professional employee forwards the written determination to the Disclosure & Litigation Support Branch to be mailed to the taxpayer, the employee will ascertain whether the mailing address of the taxpayer is current. This is particularly important if the response has been delayed for a significant amount of time after receipt of the request.

2. In the case of letter rulings, the mailing will consist of the original of the letter ruling, an additional photocopy if requested by the taxpayer, a redacted copy of the letter ruling, and a completed copy of a Notice of Intention to Disclose (Ruling), Notice 437. The Notice 437 will be dated in accordance with a schedule maintained by the Chief, Disclosure & Litigation Support Branch.

3. Post-issuance contacts with letter ruling recipients regarding deletions will not be handled by employees in the Associate offices. Accordingly, any such contact should be referred to the Chief, Disclosure & Litigation Support Branch, as provided in the Notice of Intention to Disclose.

4. Technical advice memorandums that are subject to section 6110 will be mailed by the Disclosure & Litigation Support Branch. That mailing will contain



   - A Special Handling Notice (Document 6919)

   - The technical advice transmittal memorandum (Form M(6000)

   - The technical advice memorandum

   - Three copies of a Notice of Intention to Disclose (Technical Advice) (Notice 438)

   - A redacted copy of the technical advice memorandum

   - Instructions for dating the Notice of Intention to Disclose


5. After receiving the technical advice memorandum, the requesting office must either request reconsideration of the technical advice memorandum or furnish a copy of it to the taxpayer.



### Note:



Technical advice memoranda involving a criminal or civil fraud investigation and jeopardy or termination assessment are not furnished to taxpayers until all actions relating to such investigation or assessment are completed. At that time, the taxpayer will also be furnished a dated Notice of Intention to Disclose and the redacted copy of the technical advice memorandum. Response and mailing instructions for the taxpayer to follow appear on the Notice of Intention to Disclose.

6. The technical advice transmittal memorandum will not be furnished to the taxpayer and deletions to the technical advice memorandum will not be discussed with the taxpayer.

7. Responsibility for approving taxpayer requests for post-issuance deletions has been assigned to the Disclosure & Litigation Support Branch.


**37.1.1.2.6** **(08-11-2004)**

#### Section 6110 Coordination

1. The Director of the Legal Processing Division is responsible for furnishing guidance to professional employees in the national office on any questions involving section 6110. As the "6110 coordinator" , the Director may obtain legal advice on section 6110 questions from the Assistant Chief Counsel (DPL).

2. The Chief, Disclosure & Litigation Support Branch is responsible for reviewing, prior to use, all pattern or standardized responses to letter ruling or technical advice requests to ensure that such responses do not contain disclosures prohibited by section 6110.


**37.1.1.2.7** **(08-11-2004)**

#### Pre-issuance Associate Chief Counsel Quality Review

1. National office professional employees performing pre-issuance quality reviews of written determinations are responsible for ensuring that all section 6110 requirements are complied with before approving the release of the written determination.


**37.1.1.2.8** **(08-11-2004)**

#### Requests for Additional Disclosure

1. Section 6110(f)(4) and Treas. Reg. § 301.6110-5(d) provide that any person may request disclosure of any material redacted from a written determination. Any requests for additional disclosure or calls concerning additional disclosure received by any of the branches should be forwarded for processing to the Chief, Disclosure & Litigation Support Branch. CCDM 37.1.1.4.


**37.1.1.2.9** **(08-11-2004)**

#### Communications from Third Parties

1. Except as discussed in paragraph (3) below, a "third-party communication" means any communication, by whatever means, concerning a pending request for a written determination that is received by any Service employee (including Chief Counsel employees) from any person outside the Service other than the person to whom the written determination pertains or the authorized representative of such person.

2. A revenue ruling is not a written determination within the meaning of section 6110. See CCDM 37.1.1.1.1. Therefore, third-party communications do not include those received by a Service employee concerning an issue under consideration solely in a proposed revenue ruling. When release of a letter ruling or technical advice memorandum is being held pending resolution of the issue in a proposed revenue ruling or some other document that is not a written determination (such as a proposed revenue procedure or technical study project), and a communication to a Service employee on the revenue ruling or other document pertains to the issue in the pending letter ruling or technical advice memorandum, the communication will be treated as a third-party communication concerning the request for letter ruling or technical advice memorandum if the exception in paragraph 3 below does not apply.

3. Pursuant to Treas. Reg. § 301.6110-4(b), third-party communications do not include communications received by the Service from employees of the Service or the Office of Chief Counsel, from the Chief of Staff of the Joint Committee on Taxation, from the Department of Justice with respect to any pending civil or criminal case or investigation, or from another Government agency (including Treasury) in response to a request made by the Service to such agency for assistance involving the expertise of such agency.

4. Section 6110(d) and Treas. Reg. § 301.6110-4(a) provide that a written record of all third-party communications must be made. Form M-6535, Memorandum of Third Party Contact, has been developed for this purpose. The same section of the regulations requires that a notation of such communication is to be made on the copies of the written determination open for public inspection. In the case of a third-party communication concerning a proposed revenue ruling or other document that is not a written determination, the professional employee receiving the communication will ascertain whether it meets the definition of a third-party communication as described in CCDM 37.1.1.2.9. If it does, the employee will prepare the required documentation and forward it to the affected branch so that the proper notation can be made on the copies of the written determination that will be available for public inspection.

5. A third-party communication received by a Service employee outside the Associate offices that pertains to a pending request for a written determination should be documented and furnished to the Chief, Disclosure & Litigation Support Branch.

6. _All_ contacts that qualify as third-party communications under Treas. Reg. § 301.6110-4 _must_ be noted on the front page of the written determination. The third party annotation should be placed in the upper left corner and shall consist of the date on which the contact was made and the category of the person making the contact, such as, "Congressional" , "Treasury" , etc. The third party contact categories are listed on Form M-6535. See Treas. Reg. § 301.6110-4.


**37.1.1.3** **(08-11-2004)**

### Processing Chief Counsel Advice

1. The procedures set forth in CCDM 37.1.1.2 apply to Chief Counsel advice (CCA) as defined in CCDM 37.1.1.1.1(4), _except_ as defined in this section.


**37.1.1.3.1** **(08-11-2004)**

#### Taxpayer Specific Chief Counsel Advice

1. The professional employee with primary control of the case will fax ( _not_ email) a copy of the issued CCA on the date of issuance to the field attorney requesting comments on any proposed redactions of taxpayer identifiers or privileged information (e.g., attorney-client, attorney work product or deliberative process privilege material). The field must respond within three business days. The professional employee assigned to the case will follow up to ensure receipt of the fax. If no comments are received from the field within three business days, it is deemed that the proposed redactions are appropriate.

2. The professional employee then prepares the CCA as follows:



1. One original signature to be mailed to requesting office.

2. Two paper copies of black and gray version: one copy with redactions made and section 6110 information highlighted to be forwarded to the Disclosure & Litigation Support Branch, and one copy with redactions made and section 6110 information highlighted, annotated with the reasons for the redactions to be retained with the file.

3. Two black and white paper copies and an electronic version of the black and white version; the two paper copies are forwarded to the Disclosure & Litigation Support Branch.

4. The electronic black and white version must be forwarded using the "submit" button on the eWord toolbar.


3. The professional employee with primary control of the case completes the checksheet reflecting:



   - That the black and gray version has been made; one paper copy has been forwarded to the Disclosure & Litigation Support Branch and another paper copy is retained for the file, annotated with the reasons for redaction

   - The uniform issue list numbers

   - That the black and white version has been made and two copies in paper form have been forwarded to the Disclosure & Litigation Support Branch and an electronic version of the black and white has been submitted through eWord

   - Taxpayer’s or taxpayer representative’s address


4. The professional employee (or secretary)



1. Mails the original signature version to the requesting office.

2. Retains an annotated copy of the black and gray version.

3. Forwards the other copy of the black and gray version, all paper copies of the black and white version and the checksheet to the Disclosure & Litigation Support Branch.

4. A copy of the checksheet should be retained with the file.


5. The Disclosure & Litigation Support Branch is responsible for mailing out the black and gray and the black and white versions to the taxpayer with the Form 437A, Notice of Intention to Disclose (CCA). The Notice sets forth the dates for the various steps along the road to public inspection, including the release date.

6. The file is closed on CASE-MIS and returned to the Docket & Records Branch in Room 5336.


**37.1.1.3.2** **(08-11-2004)**

#### Non-Taxpayer Specific Chief Counsel Advice

1. The professional employee assigned to the case faxes ( _not email_) a copy of the issued CCA on the date of issuance to the field attorney requesting comments on any proposed redactions of privileged information. The field must respond within three business days. The professional employee assigned to the case will follow up to ensure receipt of the fax. If no comments are received from the field within three business days, it is deemed that the proposed redactions are appropriate.

2. The professional employee then prepares the CCA as follows:



1. One original signature to be mailed to requesting office.

2. Two paper copies and an electronic version of the black and white version; the two paper copies are forwarded to the Disclosure & Litigation Support Branch.

3. The electronic version must be forwarded using the "submit " button on the eWord toolbar.


3. The professional employee with primary control of case completes the checksheet reflecting



   - The uniform issue list number(s)

   - That the black and white version has been made and two copies in paper form have been forwarded to the Disclosure & Litigation Support Branch

   - An electronic version has been forwarded using the "submit " button on the eWord toolbar


4. The professional employee (or secretary):



1. Mails the original signature version to the requesting office.

2. Retains an annotated copy of the black and white version.

3. Forwards the two black and white copies with the checksheet to the Disclosure & Litigation Support Branch.

4. A copy of the checksheet should be retained with the file.

5. The file is closed on CASE-MIS and returned to the Docket & Records Branch in Room 5336.


**37.1.1.4** **(08-11-2004)**

### Administrative Disclosure Cases

1. Restrain Disclosure. Section 6110(f) provides that any taxpayer to whom a written determination pertains (or successor in interest, executor or other person authorized by law to act for or on behalf of the taxpayer), or who has a direct interest in maintaining the confidentiality of a written determination or background file document may file an administrative request to restrain disclosure of information from the written determination (or background file document).

2. The administrative request to restrain disclosure will be directed to: Chief, Disclosure & Litigation Support Branch CC:PA:LPD:DLS



> P.O. Box 7604
>
> Ben Franklin Station
>
> Washington, DC 20044

3. The Chief, Disclosure & Litigation Support Branch is responsible for analyzing and responding to the request and will assign the request to a paralegal specialist who will contact the originating office for recommendations on the taxpayer’s request to restrain disclosure. The paralegal specialist will prepare a letter for signature by the Chief, Disclosure & Litigation Support Branch to notify the taxpayer whether the request to restrain disclosure is granted or denied. The paralegal specialist will retain a copy of all correspondence and document any conversations with the issuing branch in the file.

4. Compel Disclosure. Members of the public may request additional disclosure of information in a written determination or background file documents. Such requests will be submitted to the Chief, Disclosure & Litigation Support Branch at the address above.


**37.1.1.5** **(08-11-2004)**

### Section 6110 Disclosure Suits

1. Section 6110 provides the Tax Court with jurisdiction over actions to restrain disclosure of written determinations and background file documents.

2. Authority over actions to restrain or compel disclosure. Actions to restrain or compel disclosure are the responsibility of the Associate Chief Counsel (P&A).


**37.1.1.5.1** **(08-11-2004)**

#### Actions to Restrain Disclosure

1. Actions to restrain disclosure must be filed not later than 60 days after the date on a Notice of Intention to Disclose (Notice). If a petition is not filed, the Service is required by statute to make the disclosure not earlier than 75 days or later than 90 days after mailing of the Notice. Civil damages are provided by section 6110(i) if the Service fails to follow the procedures prescribed in section 6110(g). Thus, professional employees must be especially sensitive to time constraints in these actions.

2. Immediately upon receipt of a petition to restrain disclosure the assigned attorney must notify the Disclosure & Litigation Support Branch of the petition and ensure that disclosure of the affected documents are withheld until further notice. As soon as possible, the assigned attorney should obtain the disclosure rulings file and, if necessary, any underlying file related to the ruling. The attorney should consult his supervisor in any action brought anonymously for special instructions on maintaining the confidentiality of the action under Rules 227 and 228.

3. In cases in which a petition is filed by a person other than the person to whom the written determination pertains, section 6110(f)(3)(B) requires the Service to notify the person to whom it pertains by registered or certified mail within 15 days after service of the petition on the respondent to enable that person to intervene in the action. The attorney is responsible for providing the notice required by section 6110(f)(3)(B).

4. The attorney should immediately examine the petition and the underlying files to determine whether there are any jurisdictional or other defects that should be raised by motion after service of the petition. The answer must also be filed within 30 (not 45) days of service.

5. The following are some of the jurisdictional defects that should be raised by motion:



1. Untimely Petition. If the petition is not filed on or before the 60 th day after mailing of the Notice, a motion to dismiss for lack of jurisdiction should be filed.

2. No Notice. If a Notice has not been issued with respect to a written determination or a background file document, a motion to dismiss for lack of jurisdiction should be filed.

3. Exhaustion of Administrative Remedies. The Tax Court does not have jurisdiction unless the petitioner has exhausted his administrative remedies. A motion to dismiss for lack of jurisdiction should be filed in appropriate circumstances.


**37.1.1.5.2** **(08-11-2004)**

#### Actions to Compel Disclosure

1. Upon exhaustion of administrative remedies (as described in CCDM 37.1.1.4 at paragraph (4) and Treas. Reg. § 301.6110-1), section 6110(f)(4) permits any person seeking to compel additional disclosure of information in a written determination or in background file documents to file either a petition with the Tax Court or a complaint in the United States District Court for the District of Columbia for an order to compel additional disclosure.

2. Intervention. Within 15 days of the Office of Chief Counsel’s receipt of the notice of petition in Tax Court or complaint in district court, the attorney assigned to the case will send a notice to each person identified by name and address in the written determination or background file documents, by registered or certified mail, to the last known address of each person. Any person to whom the written determination or background file documents pertains may intervene in the proceeding.

3. Once notice is sent to the person to whom the written determination or background file documents pertains, the Office of Chief Counsel is no longer responsible for defending the action.

4. If notice is not sent as required by section 6110(f)(4)(B), the Office of Chief Counsel is responsible for defending each item of information from disclosure to the public.

5. Cross-reference. For treatment of petitions to compel disclosure in Tax Court, see CCDM 35.4.6. For complaints filed in district court, see CCDM 34.1 and CCDM 34.9.


**37.1.1.6** **(08-11-2004)**

### Requisitioning of Technical Records

1. The Docket & Records Branch is required to make technical files available for use by Treasury officials. Technical files include all Treasury Decision files, revenue ruling files, revenue procedure files, private letter ruling files, technical advice files, Chief Counsel advice files, General Counsel Memorandum files, and Office Memorandum files. Technical files may be the subject of FOIA requests, discovery orders, and requests for background file documents pursuant to section 6110.

2. National office personnel must submit Form 9612, Request for Records, when requisitioning records. Form 9612, copies of which may be obtained from the Docket, Records, & User Fees Branch, is a three-part form that is used to requisition a record. (The form is also available on the IRS website at www.irs.gov under Forms and Publications. If using the website form, make two copies to accompany the original.) The requisitioning office should prepare the form according to the instructions printed and forward the three parts of the form to the Docket & Records Branch. Records requisitioned by national office personnel may not be forwarded to field counsel offices, but must be returned directly to the Docket & Records Branch. Under no circumstances are national office personnel permitted to transfer technical files to other offices without approval.

3. Field counsel offices may request technical records directly from the Docket, Records & User Fees Branch by submitting a memorandum, specifying the records needed to: Chief, Docket, Records & User Fees Branch. Field counsel offices need not submit Form 9612, which is used only to obtain the original record, since the field will receive a copy of the file requested, whereas national office personnel receive the original file.

4. Increasingly, taxpayers and their attorneys are making discovery requests for the Service’s technical files. To aid Office of Chief Counsel attorneys in determining whether material has previously been released through discovery, the FOIA or section 6110, attorneys may call the national office for information concerning prior disclosures from technical files and will report any subsequent disclosures from the technical files of which they are aware to the national office. The following procedures apply.

5. Every technical file contains a log sheet identifying any person who made a previous request for the file and the context of that particular request (e.g., whether the request was in response to a FOIA request or a discovery request or for research purposes).

6. Attorneys wishing information regarding how a prior access request was processed should call the Chief, Docket Records & User Fees Branch. The information contained on the log sheet will enable the Docket & Records Branch to advise attorneys whether there was a prior access request and if so, refer those attorneys to the appropriate Associate office that handled the previous request. The field attorney should then contact the appropriate office to ascertain how the prior access request was processed. It may be possible to determine what prior disclosures have been made by reference to the log sheet.

7. All personnel who become aware of any additional disclosures or demands for access (e.g., FOIA appeals or litigation, section 6110 litigation, disclosures pursuant to court order) must notify the appropriate Associate office of the additional disclosures.


**37.1.1.7** **(08-11-2004)**

### Coordination of Proposed Disclosure of Information Contained in Service Technical Files

1. As noted in CCDM 37.1.1.6, material contained in the technical files may be subject to FOIA requests, discovery requests or orders, and requests for background file documents pursuant to section 6110. It is important to be aware that material and information contained in such files may be exempt from disclosure on the basis of one or more governmental or other privileges. See CCDM 35.4.6.3.3.

2. In order to maintain a consistent position with respect to the disclosure of technical file information and assertion of privileges for material contained in Service files, _any_ proposed disclosure of information or material contained in Service technical files requisitioned from the Docket, Records & User Fees Branch must be coordinated with the Associate Chief Counsel (P&A) prior to the proposed disclosure. Procedure and Administration has the responsibility for coordination of formal and informal legal advice on issues relating to discovery, assertion of privileges, and the FOIA. Accordingly, _no_ disclosure of information or materials contained in Service technical files may be made prior to coordination with P&A


**37.1.1.8** **(08-11-2004)**

### User Fees

1. User fees for requests for rulings, opinion letters, determination letters, and similar requests were first required by section 10511 of the Revenue Act of 1987, Pub. L. 100–203, enacted on December 22, 1987. The requirement has been extended several times since. The provision has not been made permanent so that the Congress may examine the impact of the provision on taxpayer compliance. H.R. Rept. 100-391, 100th Cong., 1st Sess. (pt. 3) (1987); S. Prt. 100-63, 100th Cong., 1st Sess. (pt. 27) (1987). The acts that have authorized the continuation of the requirement are noted in first revenue procedure of the year (Rev. Proc. 200X-1), which provides procedures for a taxpayer to obtain guidance from the national office in the form of a private letter ruling.

2. Any general questions regarding user fees should be directed to the Chief, Docket, Records & User Fees Branch.


**37.1.1.8.1** **(08-11-2004)**

#### Determining the Correct Fee for a Submission

1. Incoming ruling requests are screened by the Docket, Records & User Fees Branch.

2. The reviewer who has prime jurisdiction for the ruling request is responsible for ultimately determining that the correct fee is charged for the request, such as where a request involves several transactions, determining whether the transactions are unrelated (and, if so, coordinating with another branch to determine the additional fee).

3. The Chief, Docket & Records Branch may be able to provide the reviewer with information that helps in determining the correct fee. The rules for determining the correct fee to be paid by the taxpayer are in the revenue procedures concerning these submissions published in the first Internal Revenue Bulletin of the year.

4. The amount of the user fee submitted with the ruling request and the user fee code will be entered on a coding sheet by the Docket & Records Branch. See Exhibit 37.1.1-1.

5. The reviewer is responsible for checking the coding sheet prepared by the Docket & Records Branch to confirm that the correct fee has been charged.


**37.1.1.8.2** **(08-11-2004)**

#### Refunds

1. The amount of the user fee is payable in advance and is refundable only if the Service refuses to respond to the request. The fee is not refundable if the person making the request withdraws the request prior to the issuance of the ruling or determination. H.R. Rept. 100-391, 100th Cong., 1st Sess. (pt. 3) (1987); S. Prt. 100-63, 100th Cong., 1st Sess. (pt. 27) (1987).

2. The Docket, Records & User Fees Branch will include a User Fee Refund Request form in all case files. See Exhibit 37.1.1-2. The Docket & Records Branch completes Part I of the form with information from the user fee data base.

3. The reviewer is responsible for submitting a User Fee Refund Request form to the Docket, Records & User Fees Branch in Room 5334 for all requests for refunds. The refund codes for the form are listed in Exhibit 37.1.1-3.

4. When the Docket, Records & User Fees Branch is able to determine that a ruling request contains more than the correct fee, the Docket, Records & User Fees Branch still deposits the check; but, it also marks a box on the coding sheet and forwards the case to the rulings branch recommending that a refund be authorized. If the branch chief or person assigned to review the case agrees, the branch completes Part II of the User Fee Refund Request form and sends it to the Docket, Records & User Fees Branch.

5. Grounds for making a refund are addressed in examples in the revenue procedure addressing rulings, opinion letters, determination letters, and similar requests that is published in the first Internal Revenue Bulletin of the year.



### Note:



One of the examples provides that a user fee will not be refunded when a case is closed due to the failure to timely provide additional information; however, another example allows an Associate or Assistant Chief Counsel to authorize a refund after "taking into account all the facts and circumstances, including the Service’s resources devoted to the request." An Associate or Assistant Chief Counsel’s office may set a policy concerning the level of "resources devoted to the request" that justifies a refund and the branches within that office may apply that policy uniformly without obtaining explicit authorization for a particular case from the Associate or Assistant Chief Counsel.

6. If the User Fee Refund Request form is not in the file, in general, the branch must contact the Docket, Records & User Fees Branch who will complete Part 1 of the form. (The Docket, Records & User Fees Branch will use information from the front of the check to complete Part I.) If the taxpayer placed a copy of the front of the check in the request for the ruling, the branch will be able to use that information to complete the form that is available as an Office of Chief Counsel macro and forward it to the Docket, Records & User Fees Branch.


**37.1.1.8.3** **(08-11-2004)**

#### Additional Fee

1. The reviewer who has primary jurisdiction over the request is ultimately responsible for determining whether an additional fee is required. See CCDM 37.1.1.8.1.

2. An additional fee case includes a case for which no fee had been submitted with the initial ruling request.

3. When the Docket, Records & User Fees Branch is able to determine that an additional fee is required, the request will be held and not processed until the correct fee is received. The Docket, Records & User Fees Branch will request the correct fee by letter. The taxpayer has 30 days from the date of the request to mail the correct fee. If the fee is not submitted timely, the ruling request will be returned to the taxpayer. There may be a cycle of as many as 30 days from the response due date until the time the request is actually mailed back to the taxpayer. It may be possible to immediately reopen the case if the additional fee is received during this cycle. If an issuing branch determines that an additional fee is required, the branch has several alternatives.

4. The branch may return the request to the taxpayer. The return of a request to the taxpayer may adversely affect substantive rights if the request is not perfected and resubmitted to the Service within 30 days of the date of the cover letter from the branch returning the request.

5. The reviewer may send a Request for Additional Fee form to the Chief, Docket, Records & User Fees Branch, who will follow the procedures in paragraph (3). Substantive consideration of the request will usually be deferred.

6. When an expedited procedure is necessary, the branch may contact the taxpayer or taxpayer’s representative and request immediate submission of the fee and advise the taxpayer that the request will be returned if the fee is not received within a time period that the branch determines is appropriate. Substantive consideration of the request will usually be deferred. The check must be sent to the Docket, Records & User Fees Branch. After requesting the fee by telephone, the branch must send the form titled Information Sent to IR 5334 after Requesting an Additional Fee, Exhibit 37.1.1-4, to the Docket, Records & User Fees Branch to enable it to associate the check with the ruling request when it arrives. The Docket, Records & User Fees Branch will inform the branch when the fee arrives. If a fee is not received within the time period set by the branch, the branch will return the request to the taxpayer. The return of a request to the taxpayer may adversely affect substantive rights if the request is not perfected and resubmitted to the Service within 30 days of the date of the cover letter from the branch returning the request.


**37.1.1.8.4** **(08-11-2004)**

#### Returned Checks

1. The Docket, Records & User Fees Branch will advise the reviewer in the issuing branch that the check has been returned for insufficient funds and will contact the taxpayer or the taxpayer’s representative and request a new check for the user fee.

2. The reviewer should suspend action on the case until notified that the fee has been received. If the Docket, Records & User Fees Branch does not receive the fee within the allotted time period, the Docket, Records & User Fees Branch will notify the reviewer who may close the case without further action.


**37.1.1.8.5** **(08-11-2004)**

#### Appeals

1. A taxpayer or a taxpayer’s representative may request reconsideration and, if desired, the opportunity for an oral discussion if the taxpayer or taxpayer’s representative believes the user fee charged is either not applicable or incorrect. The taxpayer or the representative makes the request by sending a letter to the office of the appropriate Associate Chief Counsel. Additional information about this procedure can be found in the revenue procedure addressing rulings, opinion letters, determination letters, and similar requests that is published in the first Internal Revenue Bulletin of the year.


**37.1.1.9** **(08-11-2004)**

### Request for Delay of Disclosure for Public Inspection

1. Section 6110(g) provides two bases for delays for making written determinations available for public inspection.


**37.1.1.9.1** **(08-11-2004)**

#### Initial Request for Delay

1. The person to whom a written determination pertains, or his authorized representative, may make a written request to postpone the date of disclosure of a written determination if the transaction to which it pertains has not been completed. The written request for delay shall set forth the date on which the transaction is expected to be completed.

2. The release date of the written determination will be postponed until 15 days after the Commissioner has determined that the transaction set forth has occurred, but not to exceed 90 days. See section 6110(g)(3).

3. The period of extension for 90 days, if applicable, is calculated from the date the written determination is scheduled to be released, as designated on the Notice of Intention to Disclose.


**37.1.1.9.2** **(08-11-2004)**

#### Request for Additional Delay

1. If the transaction is not completed within the initial 90 day delay period, the person to whom a written determination pertains, or his authorized representative, may request an additional delay of up to 180 days. The additional period of postponement will be granted only if good cause is shown to justify the additional delay. See section 6110(g)(4).

2. Good cause is shown if the person requesting the delay of disclosure demonstrates to the satisfaction of the Commissioner that it is likely that the lack of such extension will cause interference with consummation of the pending transaction.



### Example:



A corporate taxpayer finds itself the possible target of a hostile takeover. The taxpayer enters into merger negotiations with a "white knight" corporation to obtain a more favorable treatment for the stockholders. Because written determinations are sanitized to prevent the general public (i.e., someone without inside knowledge) from identifying the taxpayer, the hostile corporation, due to its familiarity with the taxpayer, might nevertheless be able to identify the taxpayer and use the information in the released written determination to interfere with the negotiations and/or the merger transaction.

3. Good cause is _not_ shown if the person to whom the written determination pertains



   - Asks for a reconsideration of an adverse determination and requests delay of disclosure pending the reconsideration

   - Requests delay of disclosure pending the outcome of litigation or

   - Requests an additional delay solely on the basis that the transaction is not yet completed


4. If the only basis upon which an additional delay is sought is that the transaction is not yet completed, the Disclosure & Litigation Support Branch should contact the person seeking the additional delay to ask for any additional information substantiating whether disclosure would interfere with the pending transaction before making a final determination on the request for additional delay.


**37.1.1.9.3** **(08-11-2004)**

#### Procedures

1. Requests for delay should be addressed to:



> Internal Revenue Service
>
> Attention: Chief, Disclosure and Litigation Support Branch
>
> CC:PA:LPD:DLS
>
> P.O. Box 7604
>
> Ben Franklin Station
>
> Washington, D.C. 20044

2. If necessary, the request for delay may be faxed in addition to, but not instead of, being mailed or hand carried to the Disclosure & Litigation Support Branch.

3. If a request for initial or additional delay is received by the issuing branch, that office is responsible for forwarding the request for delay to the Chief, Disclosure & Litigation Support Branch, within two business days.

4. The initial request for delay must be received by the Commissioner within 60 days after the Notice of Intention to Disclose was mailed. Upon receipt of an initial request for delay, the Disclosure & Litigation Support Branch will arrange for the document to be withdrawn from the original proposed release date and reassigned to a date 15 days after the transaction is to be completed, or 90 days from the initial proposed release date, whichever is earlier.

5. The request for an additional delay in disclosure must be received 30 days before the new proposed disclosure date following the initial 90 day postponement. Upon receipt of the request for additional delay, the Disclosure & Litigation Support Branch will determine, based on the information set forth in the request for additional delay, whether the requester has demonstrated that a good cause for an additional postponement exists.

6. In making this determination, the Disclosure & Litigation Support Branch may, as appropriate, coordinate with the issuing branch and the office of the Assistant Chief Counsel (DPL) to determine whether the information in the request for delay is adequate to demonstrate good cause for an additional delay of disclosure.

7. If the transaction for which a postponement has been granted is complete prior to the expected date, the person requesting a delay shall notify the Chief, Disclosure & Litigation Support Branch that the transaction is complete. The written determination will then be made available for public inspection on the earlier of (a) 30 days after the Disclosure & Litigation Support Branch is notified of the completion of the transaction or (b) the date on which the written determination was scheduled to be made available for public inspection.

8. If the transaction is not completed after the additional period of postponement, the written determination shall be available for public inspection no later than 360 days after the Notice of Intention to Disclose is mailed.


**Exhibit 37.1.1-1** **08–11–2004**

### General Coding Sheet (Green sheet)

![This is an Image: 39102001.gif](https://www.irs.gov/pub/xml_bc/39102001.gif)

There is currently no description available for this image. For help with this image, please call the IRS.gov Helpdesk at 1-800-876-1715.

[Please click here for the text description of the image.](https://www.irs.gov/media/157826 "")

**Exhibit 37.1.1-2** **08–11–2004**

### Refund Request for User Fee Chief Counsel

![This is an Image: 39102002.gif](https://www.irs.gov/pub/xml_bc/39102002.gif)

There is currently no description available for this image. For help with this image, please call the IRS.gov Helpdesk at 1-800-876-1715.

[Please click here for the text description of the image.](https://www.irs.gov/media/157831 "")

**Exhibit 37.1.1-3** **08–11–2004**

### Refund Codes

|     |     |
| --- | --- |
| **REFUND CODES** |
| 01 | One issue. General information issued. No fee required. |
| 02 | More than one issue. Ruling not issued as to all questions presented. Lower fee applicable. |
| 03 | Lower fee applicable. |
| 04 | Fee reconsidered upon request of taxpayer. Lower fee applicable. |
| 05 | Higher fee applicable. Ruling not perfected. Additional fee requested, but not submitted. Fee already paid is refunded. |
| 06 | Refusal to rule. One issue. |
| 07 | Refusal to rule on one of multiple issues. Lower fee applicable. |
| 08 | More than one fee submitted. |
| 09 | Reconsideration. Refund applicable to transaction with respect to which the Service agrees that an earlier decision not to rule on an issue was in error. Fee for the reconsideration request will be refunded |
| 10 | Reconsideration. Service agrees ruling was erroneous or unresponsive. Fee for the reconsideration request is refunded. |
| 11 | Supplemental request. Service agrees mistake was made (e.g., as to statement of facts or citation of a Code section) in the original ruling or determination letter. Fee for the supplemental request is refunded. |
| 12 | Section 7805(b) relief granted in connection with the revocation, in whole or in part, of a previously issued ruling or determination letter. Fee for the 7805(b) request is refunded. |
| 13 | Automatic Approval for Accounting Method or Accounting Period case. No Fee required. |
| 14 | No fee required. |
| 98 | Discretionary. An Associate or Assistant Chief Counsel may authorize a refund after taking into account all the facts and circumstances, including the Service’s resources devoted to the request. A branch may apply the policy of such an office without obtaining case by case authorizations. |

**Exhibit 37.1.1-4** **08–11–2004**

### Information Sent to IR 5334 after Requesting an Additional Fee

![This is an Image: 39102003.gif](https://www.irs.gov/pub/xml_bc/39102003.gif)

There is currently no description available for this image. For help with this image, please call the IRS.gov Helpdesk at 1-800-876-1715.

[Please click here for the text description of the image.](https://www.irs.gov/media/157836 "")

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part37/irm_37-001-001#addtoany "Show all")

A2A