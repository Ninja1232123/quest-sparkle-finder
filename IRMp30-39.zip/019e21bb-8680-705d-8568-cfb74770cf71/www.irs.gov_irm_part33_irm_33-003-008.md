---
url: "https://www.irs.gov/irm/part33/irm_33-003-008"
title: "33.3.8 Whistleblower Taint Review Procedures | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part33/irm_33-003-008#main-content)

- 33.3.8  [Whistleblower Taint Review Procedures](https://www.irs.gov/irm/part33/irm_33-003-008#idm140103119432064)
  - 33.3.8.1  [Whistleblower Taint Review](https://www.irs.gov/irm/part33/irm_33-003-008#idm140103119361488)
  - 33.3.8.2  [Counsel Assistance in the IRS Taint Review Process](https://www.irs.gov/irm/part33/irm_33-003-008#idm140103091934384)
  - 33.3.8.3  [Identifying Taint Concerns Outside of the IRS Taint Review Process](https://www.irs.gov/irm/part33/irm_33-003-008#idm140103119417760)
  - 33.3.8.4  [Identifying Taint](https://www.irs.gov/irm/part33/irm_33-003-008#idm140103119411200)

# Part 33. Legal Advice

# Chapter 3. Other Legal Advice

# Section 8. Whistleblower Taint Review Procedures

* * *

## 33.3.8 Whistleblower Taint Review Procedures

#### Manual Transmittal

November 22, 2019

#### Purpose

(1) This transmits new CCDM 33.3.8, Whistleblower Taint Review Procedures.

#### Material Changes

(1) CCDM 33.3.8.1, Whistleblower Taint Review, provides an overview of the taint review process for whistleblower information.

(2) CCDM 33.3.8.2, Counsel Assistance in the IRS Taint Review Process, details Counsel’s responsibilities when the IRS requests assistance in the Taint Review Process.

(3) CCDM 33.3.8.3, Identifying Concerns Outside of the IRS Taint Review Process, provides guidance on handling information that appears to raise concerns.

(4) CCDM 33.3.8.4, Identifying Taint, identifies situations and relationships that may generate taint concerns and incorporates the procedures in Chief Counsel Notice 2010-004, _Clarification of CC Notice 2008-011 - Limitations on Informant Contacts: Current Employees and Taxpayer Representatives_.

#### Effect on Other Documents

Chief Counsel Notice 2010-004, _Clarification of CC Notice 2008-011 - Limitations on Informant Contacts: Current Employees and Taxpayer Representatives_, issued February 17, 2010, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(11-22-2019)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure and Administration)

**33.3.8.1** **(11-22-2019)**

### Whistleblower Taint Review

1. Whistleblower information received by the IRS Whistleblower Office that identifies potential tax noncompliance may be referred to an appropriate IRS Operating Division for investigation. As part of the referral, a claim may be assigned to an Operating Division whistleblower Subject Matter Expert (SME). Prior to assignment to an examination team, the SME may debrief, or interview, the whistleblower and will perform a taint review of the whistleblower’s information.

2. The taint review is a process where the SME evaluates the IRS’s ability to use the whistleblower’s information. The Office of Chief Counsel and the IRS Whistleblower Office assist, as needed. The IRS uses the taint review procedures to insulate the investigation functions from information that could jeopardize subsequent adjustments and collection activity. The IRS also uses the taint review procedures to insulate licensed professionals within the IRS, such as attorneys and certified public accountants, and the Office of Chief Counsel from potential ethical concerns. For example, outside of the taint review process, there may be ethical concerns with reviewing or providing assistance with respect to information that is known to be privileged.

3. During a taint review, the SME seeks to identify and evaluate potential evidentiary, ethical, legal, or privilege concerns associated with the whistleblower’s information. The relationship of the whistleblower to the target taxpayer and the government must be considered as part of the taint review. Tainted information can include, but is not limited to, information that is subject to a valid claim of privilege and information that may be subject to Fourth Amendment concerns and the Exclusionary Rule. Information the taint review determines is privileged will not be further used by the IRS or Counsel and must be returned by the SME to the IRS Whistleblower Office.

4. The SME requests Counsel’s assistance when the SME identifies a potential privilege issue during a taint review. The SME may also request Counsel’s assistance addressing other evidentiary, ethical, or legal issues (collectively referred to as "taint concerns" or "taint issues" ) identified during the taint review. Counsel’s review, however, is not limited to the issue(s) the SME identified, and Counsel should identify any potential privilege or other taint concerns when assisting the IRS with cases that involve whistleblower information. Counsel attorneys should always consider whether information provided by a whistleblower could be subject to privilege or other taint concerns.


**33.3.8.2** **(11-22-2019)**

### Counsel Assistance in the IRS Taint Review Process

1. Before whistleblower information is sent out for investigation, Operating Division Subject Matter Experts (SMEs) conduct taint reviews to evaluate the IRS’s ability to use the information.

2. During the taint review, the SME looks for information that may be subject to evidentiary, ethical, legal, or privilege concerns. As part of this process, the SME may debrief, or interview, the whistleblower to attempt to resolve questions or concerns with the information.

3. The SME should request Counsel’s assistance when the SME identifies any potential privilege issue during a taint review. The SME should also request Counsel’s assistance addressing certain evidentiary concerns. The SME may also request legal assistance from Counsel during the taint review process regardless of whether the SME identifies any issues requiring coordination with Counsel.

4. Each Division Counsel will identify one or more Whistleblower Taint Review Points of Contact (Taint Review POC). When a SME requests assistance, the SME will contact the appropriate Taint Review POC and the Taint Review POC will then assign a whistleblower taint review attorney to evaluate the whistleblower information to determine whether the information is privileged or subject to other taint concerns. A whistleblower taint review attorney is a Counsel attorney who is not involved in the IRS investigation of the target taxpayer and will not be the docket attorney if a matter involving the target taxpayer were litigated. All novel taint issues must be coordinated with Branch 5 of the Office of the Associate Chief Counsel (Procedure and Administration). It is Counsel’s responsibility to determine if the information is subject to a recognized privilege or other taint concerns.

5. The existence of a privilege is a fact specific inquiry. A whistleblower taint review attorney may identify questions or concerns about the whistleblower information that need to be resolved as part of the review. The whistleblower taint review attorney should work with the SME to resolve these questions or concerns, when possible. This may include participating in a debriefing or interview of the whistleblower.

6. If Counsel determines that information is privileged or identifies other taint concerns associated with the information, the whistleblower taint review attorney will prepare written advice for the SME detailing all taint concerns and identifying the material determined to be privileged. The written advice will reflect Counsel’s determinations and will recommend that the SME segregate the identified privileged information from the non-privileged information and return the privileged information and Counsel’s written advice to the Whistleblower Office. If Counsel determines that there are no taint concerns with the information, the whistleblower taint review attorney will convey this conclusion to the SME.

7. Generally, non-privileged information may be sent to the IRS Operating Division for investigation. Counsel’s written advice may, however, also note other taint concerns associated with the information and recommend that additional materials not be sent to the Operating Division.

8. Counsel’s written advice may also recommend possible alternatives for proceeding with the case, including the possibility of assignment of a new examiner/examination team.

9. The SME or the Operating Division may request additional advice from the whistleblower taint review attorney when implementing the recommendations in Counsel’s written advice.


**33.3.8.3** **(11-22-2019)**

### Identifying Taint Concerns Outside of the IRS Taint Review Process

1. An Operating Division Subject Matter Expert (SME) may refer information to the Operating Division for investigation without identifying potential privilege or taint concerns. Additionally, in some cases a SME may not have been assigned to conduct a taint review.

2. If, in the course of providing legal advice to the IRS, a Counsel attorney receives information that appears to be subject to taint concerns, including privilege, he or she should immediately stop reviewing the information and consult with his or her manager and the appropriate Taint Review POC. In appropriate cases, the Taint Review POC will assign a whistleblower taint review attorney to review the information for privilege or other taint concerns. The whistleblower taint review attorney will contact the appropriate Operating Division contact for assignment of a SME (if one is not already assigned).

3. If in the course of trial preparation of a Tax Court case, a Counsel attorney becomes aware of any potentially privileged information contained in the legal or administrative file, the Counsel attorney should alert their manager to the existence of potentially privileged information. The manager will alert the Taint Review POC, who will coordinate with Branch 5 of the Office of Associate Chief Counsel (Procedure and Administration) on how to proceed in the docketed Tax Court case.

4. If Counsel determines that information is privileged or identifies other taint concerns associated with the information, the whistleblower taint review attorney will prepare written advice detailing the taint concerns and identifying the material determined to be privileged. The written advice will evaluate the impact of taint on any existing case and will recommend possible alternatives for proceeding with the case, including, for example, assigning a new examiner or examination team or not pursuing the issue. The written advice will also reflect Counsel’s recommendation that the examination team send the complete whistleblower file to the SME. The written advice will advise the SME to then segregate privileged information from any non-privileged information and return the privileged information and Counsel’s written advice to the Whistleblower Office. Generally, non-privileged information may be sent to the IRS Operating Division for investigation. Counsel’s written advice may, however, also note other taint concerns associated with the information and recommend that the additional materials not be sent to the Operating Division.

5. The SME or the Operating Division may request additional advice from the whistleblower taint review attorney when implementing the recommendations in Counsel’s written advice.


**33.3.8.4** **(11-22-2019)**

### Identifying Taint

1. The taint review process includes a privilege review to identify any potentially privileged information and a review for potential evidentiary, ethical, or legal issues.

2. Relationships that may result in privileged communications include attorney/client relationships, tax practitioner/client relationships, and spousal relationships.



1. The attorney/client privilege applies to confidential communications between a lawyer and a client in the course of that relationship in professional confidence. The communication includes advice given by the lawyer in the course of representing the client and includes disclosure by the client to the lawyer or persons assisting the lawyer in working on legal matters. When conducting the taint review, to determine if the attorney/client privilege may apply, Counsel should consider whether the client is seeking or the lawyer is providing legal advice or business advice, whether the communications are made in confidence, whether the communications are made while third parties are present, as well as any other issues that could impact whether the privilege has been waived. See CCDM 35.4.6.3.3, Privileges; and see generally, IRM 25.2.1, General Operating Division Guidance for Working Whistleblower Claims.

2. The tax practitioner privilege is codified in I.R.C. § 7525 and extends the same protections as the attorney/client privilege for tax advice communications between a client and a federally authorized tax practitioner (FATP) if the tax advice communications would have been privileged if they had been between a client and a lawyer in his or her capacity as such. A FATP is any individual authorized under Federal law to practice before the Service if that practice is subject to 31 U.S.C. § 330. Tax advice is advice given by a FATP within the scope of that individual’s authority to practice as a FATP. This privilege only applies in non-criminal tax matters and non-criminal tax proceedings in Federal court. This privilege does not apply to written communications in connection with the direct or indirect promotion of the participation of a person in any tax shelter. See CCDM 35.4.6.3.3, Privileges; See generally, IRM 25.2.1, General Operating Division Guidance for Working Whistleblower Claims.

3. The spousal communication privilege protects confidential communications made between spouses while married. This privilege survives the dissolution of the marriage. If something was communicated to a spouse during a marriage, either spouse can prevent the other from testifying based on that communication, regardless of whether the marriage has been dissolved. See CCDM 35.4.6.3.3, Privileges; See generally, IRM 25.2.1, General Operating Division Guidance for Working Whistleblower Claims.


3. The taint review process also considers whether the whistleblower information is protected by the work product doctrine. This doctrine protects materials prepared by or for an attorney in anticipation of litigation. See CCDM 35.4.6.3.3, Privileges; See generally, IRM 25.2.1, General Operating Division Guidance for Working Whistleblower Claims.

4. The review for potential evidentiary or legal concerns should include, but not be limited to, a consideration of whether the government is at risk of violating an individual’s Fourth Amendment rights against unreasonable searches and seizures if it uses a whistleblower as an instrument or agent of the government. This issue could arise when a whistleblower is a current employee of a taxpayer and the government acts as something other than a passive recipient of the information provided by the whistleblower. In all cases, the government must act as a passive recipient of information provided by whistleblowers.

5. Regardless of the existence of privilege, the IRS must also exercise caution when dealing with information from certain types of whistleblowers, including whistleblowers who are current employees of a taxpayer and whistleblowers who are current representatives of a taxpayer. In these instances, it is critical from an evidentiary standpoint that the IRS act as a passive recipient of information. It is not appropriate to accept information from a whistleblower who is also the taxpayer’s representative in any administrative matter pending before the IRS or in any litigation in which the IRS has an interest. The IRS’s ability to receive information provided by a current employee whistleblower, however, may include, on a case-by-case basis, limited follow-up contacts, including debriefing to clarify information previously submitted by the whistleblower. Additionally, once an individual provides information on a taxpayer to the IRS as a whistleblower, the IRS and Counsel should, thereafter, decline to interact with the whistleblower as a representative of the taxpayer.

6. The IRS may contact the Taint Review POC for Counsel’s assistance when handling information from a whistleblower who is a current employee or representative of a taxpayer. The Taint Review POC must coordinate the situations outlined below with Branch 5 of the Office of Associate Chief Counsel (Procedure and Administration).



1. When a current employee whistleblower submits additional information to the IRS, the IRS should contact the Taint Review POC for Counsel’s assistance.

2. When an individual who represents the taxpayer is or may become a whistleblower, the IRS should contact the Taint Review POC for Counsel’s assistance.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part33/irm_33-003-008#addtoany "Show all")

A2A