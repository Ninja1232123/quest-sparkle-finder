---
url: "https://www.irs.gov/irm/part30/irm_30-006-002"
title: "30.6.2 Emergency Preparedness | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part30/irm_30-006-002#main-content)

- 30.6.2 [Emergency Preparedness](https://www.irs.gov/irm/part30/irm_30-006-002#idm139658747690752)
  - 30.6.2.1 [Emergency Planning and Response](https://www.irs.gov/irm/part30/irm_30-006-002#idm139658752149856)
  - 30.6.2.2 [Occupant Emergency Plan](https://www.irs.gov/irm/part30/irm_30-006-002#idm139658749452640)
  - 30.6.2.3 [Continuity of Operations Plan](https://www.irs.gov/irm/part30/irm_30-006-002#idm139658743485168)
  - 30.6.2.4 [Business Resumption Plan](https://www.irs.gov/irm/part30/irm_30-006-002#idm139658735375808)
  - 30.6.2.5 [Release of Employees in Emergency Circumstances](https://www.irs.gov/irm/part30/irm_30-006-002#idm139658730892192)

    - 30.6.2.5.1 [Procedure for the Washington, DC Metro Area](https://www.irs.gov/irm/part30/irm_30-006-002#idm139658746489040)
    - 30.6.2.5.2 [Procedures for Field Offices](https://www.irs.gov/irm/part30/irm_30-006-002#idm139658748661504)
    - 30.6.2.5.3 [Individual Absences Due to Emergency Conditions](https://www.irs.gov/irm/part30/irm_30-006-002#idm139658749046960)

  - 30.6.2.6 [Communications During an Emergency Event](https://www.irs.gov/irm/part30/irm_30-006-002#idm139658753522048)

    - 30.6.2.6.1 [Government Emergency Telecommunications Service (GETS) Card](https://www.irs.gov/irm/part30/irm_30-006-002#idm139658732720032)
    - 30.6.2.6.2 [Wireless Priority Service (WPS)](https://www.irs.gov/irm/part30/irm_30-006-002#idm139658736581472)
    - 30.6.2.6.3 [Chief Counsel Emergency Hotline](https://www.irs.gov/irm/part30/irm_30-006-002#idm139658733478384)

# Part 30. Administrative

# Chapter 6. Security and Emergency Preparedness

# Section 2. Emergency Preparedness

* * *

## 30.6.2 Emergency Preparedness

#### Manual Transmittal

January 23, 2014

#### Purpose

(1) This transmits revised CCDM 30.6.2, Security and Emergency Preparedness; Emergency Preparedness.

#### Material Changes

(1) CCDM 30.6.2.4 was updated to correspond to the language in the 2011 Agreement between the Office of Chief Counsel and NTEU.

(2) The IRM reference in CCDM 30.6.2.1 was updated and hyperlinked.

#### Effect on Other Documents

CCDM 30.6.2 dated October 26, 2007 is superseded.

#### Audience

Chief Counsel

#### Effective Date

(01-23-2014)

Michael T. Cochis

Director, Planning and Management Division

**30.6.2.1** **(01-23-2014)**

### Emergency Planning and Response

1. The purpose for developing emergency plans is to provide emergency management guidelines for managers and employees to reduce the effects of incidents and emergencies that could harm employees and/or deny access to or damage the facility. Information regarding emergency planning and response may be found in IRM 10.2.9, Occupant Emergency Plan, and in directives from the General Services Administration (GSA) and the Department of Homeland Security.

2. All employees should be aware of the Homeland Security Advisory System which uses color-coded alerts to indicate the general level of security. Specific responses at each level will vary by locality and facility.


**30.6.2.2** **(01-19-2006)**

### Occupant Emergency Plan

1. The Occupant Emergency Plan (OEP) provides guidance for employees to follow in the event of an emergency. It is designed to reduce the threat to personnel, property, and other assets within the office, building or facility. Due to the variety of sizes, locations and functions of facilities, it is impractical to develop a standard OEP suitable for all offices.

2. The servicing AWSS office coordinates the OEP for each location in cooperation with GSA and other resident federal agencies. The Associate Chief Counsel (Finance and Management) will coordinate with AWSS for the Headquarters Office. In field offices, the F&M Office Manager will coordinate the OEP with AWSS after soliciting input from the Managing Counsel, and notify AWSS of subsequent changes.

3. On an annual basis, Office Managers, the Managing Counsel and Headquarters Administrative Officers will ensure that employees are familiar with the procedures in the OEP, and will ensure that copies of the OEP are available to all employees.

4. When it is necessary for employees to leave the work area during an emergency, managers will implement the procedures in the OEP to safely evacuate employees. Each manager and the Managing Counsel will maintain information off-site so that they are able to reach his/her direct reports and key employees in an emergency.

5. Employees should be familiar with the OEP and know whom to call and what actions to take in the event of an emergency.


**30.6.2.3** **(01-19-2006)**

### Continuity of Operations Plan

1. The Associate Chief Counsel (Finance and Management) participates with the IRS in the refinement of the Continuity of Operations Plan (COOP) in accordance with federal mandates to ensure that Chief Counsel can continue to perform its significant functions during and after an emergency.

2. The COOP identifies responsibilities, information and procedures necessary to ensure that Counsel and IRS essential functions continue in the event of an emergency situation which may disrupt or threaten the ability to operate in the Washington, D.C. metropolitan area. The COOP focuses only on those functions that cannot be suspended for a 30-day period without adversely affecting operations.

3. The COOP provides guidance for, and facilitates the preparation of, site- and activity-specific plans and procedures to safeguard Counsel and IRS staff. The plan presents policy, guidance, and operational procedures to ensure the necessary personnel, equipment, and information are available to provide uninterrupted continuation of essential functions from an alternate location for up to 30 days.


**30.6.2.4** **(01-23-2014)**

### Business Resumption Plan

1. A Business Resumption Plan (BRP) is a guide for the orderly re-establishment of operations after an incident which disrupts program operations. The disruption may be caused by fires, natural disasters, or other critical emergencies. The objective of the plan is to resume processing of critical functions as quickly as possible and eventually return to full, normal operations.

2. The Associate Chief Counsel (Finance and Management) has oversight of business recovery and business resumption operations throughout the Office of Chief Counsel and is responsible for coordinating the BRP with the IRS for the Headquarters Office.

3. The F&M Area Managers are responsible for coordinating BRPs with the Matrix Area Team Leader and IRS organizations for posts of duty within their jurisdiction.

4. Managers will keep a copy of the BRP off-site, along with the names, addresses, and contact information for all employees in his or her organization. In field offices, F&M Office Managers and the Managing Counsel will maintain a full list of contact information for all employees at the post of duty.

5. Employees will provide emergency contact information to the Office. This information should generally include contacts both in and out of the area in which the employee lives, if available. This information will be entered into HR Connect (or its successor). Employees will be required to verify their information on a yearly basis and will be encouraged to make updates as their information changes.

6. Employees should be familiar with the BRP, their office emergency point of contact and phone number(s) to call in the event of an emergency.



   - The Office of Chief Counsel’s Emergency Hotline provides information in an emergency — 1-877-456-6565

   - The IRS Emergency Hotline has information on office closings — 1-866-743-5748


**30.6.2.5** **(01-19-2006)**

### Release of Employees in Emergency Circumstances

1. The determination to close offices requires the exercise of judgment that ensures the safety and security of employees. This section explains the procedures to be followed when an office at a particular location will be officially closed for business for all or part of a business day.


**30.6.2.5.1** **(01-19-2006)**

#### Procedure for the Washington, DC Metro Area

1. The Chief Counsel's Headquarters office at 1111 Constitution Ave. (and posts of duty in the Washington DC metro area) will coordinate with the Commissioner's office in making determinations (in accordance with Office of Personnel Management guidelines) to close the office in the event of an emergency situation.

2. Finance and Management will notify appropriate offices when the Headquarters office has an unscheduled closure.


**30.6.2.5.2** **(01-19-2006)**

#### Procedures for Field Offices

1. IRS has established Senior Commissioner’s Representatives (SCR) and Administrative Officers who have the authority to make decisions regarding office closings within their jurisdiction. Based on the circumstances, IRS may take the position that local management may close the office "as appropriate" . These decisions are often, but not always, made in conjunction with the local Federal Executive Board. The Managing Counsel in each POD has the authority to make all office closing decisions in Counsel field offices. When practical, the Managing Counsel will coordinate with the SCR or IRS Administrative Officer in making decisions on office closings. The decision to close will apply to all employees at the site.

2. Under hazardous weather conditions, field offices will generally follow the lead of the local IRS office. Once a Managing Counsel has made a decision to close an office, the Office Manager is responsible for notifying appropriate Area Counsel(s) and the F&M Area Manager of emergency field office closings and those individuals are responsible for notifying their chain of command. The Managing Counsel should inform the Matrix Area Team Leader. Notification should be made expeditiously, and can be by e-mail, phone, or fax.

3. Where the circumstance is limited to Counsel (e.g., there is a fire or other safety hazard in a building occupied only by Counsel, or electricity or plumbing is disrupted on Counsel’s floor), the Managing Counsel makes the decision about whether or not to close an office. The decision will be shared with the Matrix Area Team Leader.


**30.6.2.5.3** **(01-19-2006)**

#### Individual Absences Due to Emergency Conditions

1. When conditions call for the delayed opening of the office and/or unscheduled leave policy, employees should notify their manager as soon as possible if they decide to remain at home for the entire day and use annual leave or leave without pay.

2. When emergency conditions exist and the office is not closed, managers will confer with the Managing Counsel. A manager may excuse an employee's late arrival, on an individual basis, without charge to leave or loss of pay. For more detailed information regarding emergency conditions and bargaining unit employees, see Article 12, Section 3 of the Counsel-NTEU contract.

3. If an employee’s continuing efforts to reach the office are unsuccessful due to emergency conditions, the employee is expected to inform their manager of this situation as soon as possible. Managers will consult with the Managing Counsel in determining whether administrative leave can be used for part or all of the employee’s absence. Managers will consider reasonably acceptable documentation provided by the employee that they made reasonable efforts to reach the office.


**30.6.2.6** **(10-26-2007)**

### Communications During an Emergency Event

1. This subsection describes available methods of communication that the Office of Chief Counsel will use during an emergency event.


**30.6.2.6.1** **(10-26-2007)**

#### Government Emergency Telecommunications Service (GETS) Card

1. A Government Emergency Telecommunications Service (GETS) card is issued to those individuals who perform essential functions to maintain continuity of government posture before, during and after crisis situations.

2. Within the Office of Chief Counsel, all individuals in the following positions will be authorized a GETS card:



   - Senior Executive Service

   - Matrix Managing Counsel

   - Deputy Matrix Managing Counsel

   - FM Area Manager

   - CT Area Counsel

   - GLS Area Counsel

   - TEGE Area Counsel


**30.6.2.6.2** **(10-26-2007)**

#### Wireless Priority Service (WPS)

1. Wireless Priority Service (WPS) is provided to those individuals who perform essential functions to maintain continuity of government posture before, during and after crisis situations.

2. Within the Office of Chief Counsel, all individuals in the following positions will be authorized Wireless Priority Service (WPS):



   - Chief Counsel

   - Deputy Chief Counsel (Technical)

   - Deputy Chief Counsel (Operations)

   - Associate Chief Counsel Finance and Management

   - Associate Chief Counsel General Legal Services

   - Division Counsel Large and Mid-Size Business

   - Division Counsel Small Business/Self-Employed

   - Division Counsel/Associate Chief Counsel Tax Exempt and Government Entities

   - Division Counsel/Associate Chief Counsel Criminal Tax

   - Matrix Area Team Leader


**30.6.2.6.3** **(10-26-2007)**

#### Chief Counsel Emergency Hotline

1. The Chief Counsel Emergency Hotline is available during emergency events to provide Counsel specific information to Counsel staff.

2. The Chief Counsel Emergency Hotline also provides voicemail for Counsel staff to report their status and/or location during an emergency event. The voicemail is also be used for clarification of information provided or ask questions that may only apply to them.

3. The Chief Counsel Emergency Hotline operates on a telephone located in the office of the Finance and Management, Area Manager (3), Dallas, TX.

4. The Chief Counsel Emergency Hotline operating location will be relocated to the office of the Finance and Management, Area Manager (2), Atlanta, GA in the event that telephone service is not available to the office of the Finance and Management, Area Manager Area (3).

5. Messages on the Chief Counsel Emergency Hotline will be time stamped and updated at a minimum daily during an emergency event.

6. Messages on the Chief Counsel Emergency Hotline will be sent via email to all Counsel staff during an emergency event.

7. Messages on the Chief Counsel Emergency Hotline will also be posted on the Chief Counsel Home Page during an emergency event.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part30/irm_30-006-002#addtoany "Show all")

A2A