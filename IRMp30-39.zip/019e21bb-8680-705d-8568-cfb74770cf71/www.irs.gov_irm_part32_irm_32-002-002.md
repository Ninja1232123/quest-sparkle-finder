---
url: "https://www.irs.gov/irm/part32/irm_32-002-002"
title: "32.2.2 Summary of the Published Guidance Process | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part32/irm_32-002-002#main-content)

- 32.2.2 [Summary of the Published Guidance Process](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984155126784)
  - 32.2.2.1 [General Information About Revenue Rulings, Revenue Procedures, Notices, Announcements, and News Releases](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984126431904)
  - 32.2.2.2 [Purpose of Revenue Rulings, Revenue Procedures, Notices, Announcements, and News Releases](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984134895152)
  - 32.2.2.3 [Definitions](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984155101088)

    - 32.2.2.3.1 [Revenue Ruling Defined](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984118536144)
    - 32.2.2.3.2 [Revenue Procedure Defined](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984110362000)
    - 32.2.2.3.3 [Notice Defined](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984114859760)
    - 32.2.2.3.4 [Announcement Defined](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984126479392)
    - 32.2.2.3.5 [News Release Defined](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984116081104)

  - 32.2.2.4 [Distinction Between Revenue Rulings and Revenue Procedures](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984125080752)
  - 32.2.2.5 [Congressional Review of Rules](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984107678928)
  - 32.2.2.6 [Identifying and Establishing a Publication Project](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984107307760)

    - 32.2.2.6.1 [Identifying Issues](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984134149376)
    - 32.2.2.6.2 [Guidance Priority List](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984128398528)
    - 32.2.2.6.3 [Stakeholder Requests for Published Guidance](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984109902928)
    - 32.2.2.6.4 [Publication Criteria](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984134142336)

      - 32.2.2.6.4.1 [Unprecedented Subject and Significant Issue](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984123641824)
      - 32.2.2.6.4.2 [Revises Published Service Position or Procedure](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984155113136)
      - 32.2.2.6.4.3 [Reflects a Matter or Matters the Service is Required by Law or Regulation to Publish](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984115358640)
      - 32.2.2.6.4.4 [Materially Assists in the Administration of Tax Laws](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984129914544)
      - 32.2.2.6.4.5 [Affects the Rights or Duties of Taxpayers or Tax Exempt Organizations](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984133175984)

    - 32.2.2.6.5 [Recommendation to Establish a Publication Project](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984123142272)
    - 32.2.2.6.6 [Establishment and Control of a Publication Project](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984135547968)

      - 32.2.2.6.6.1 [Updates on CASE-MIS](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984109082816)
      - 32.2.2.6.6.2 [Milestones](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984110237408)

        - 32.2.2.6.6.2.1 [Issues Memorandum](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984131028176)
        - 32.2.2.6.6.2.2 [Coordination with Other Offices before Initial Circulation Draft](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984123584224)
        - 32.2.2.6.6.2.3 [Initial Circulation Draft](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984133109216)
        - 32.2.2.6.6.2.4 [Coordination With Treasury on Material Issues](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984107744112)
        - 32.2.2.6.6.2.5 [Chief Counsel or Joint Briefing](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984128412960)
        - 32.2.2.6.6.2.6 [Tracking Interim Milestones](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984113360176)

  - 32.2.2.7 [Nonpublication of Projects Originally Recommended for Publication](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984112031456)

    - 32.2.2.7.1 [Standards for Nonpublication](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984108951472)
    - 32.2.2.7.2 [Nonpublication Memorandum](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984116692416)

      - 32.2.2.7.2.1 [How Addressed and Approved](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984129138640)
      - 32.2.2.7.2.2 [Body of Nonpublication Memorandum](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984110355936)

  - 32.2.2.8 [Effect on Other Documents](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984107253104)

    - 32.2.2.8.1 [Use of Terms](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984108449536)

  - 32.2.2.9 [Responsibility for Publishing Revenue Rulings, Revenue Procedures, Notices, Announcements, and News Releases](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984120646672)

    - 32.2.2.9.1 [Responsibility for Administering the System](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984129030592)
    - 32.2.2.9.2 [Responsibility for Preparing Revenue Rulings, Revenue Procedures, Notices, Announcements, and News Releases](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984116563648)
    - 32.2.2.9.3 [Responsibilities Within the Offices of the Associate Chief Counsel](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984135534784)
    - 32.2.2.9.4 [Services Performed by the Bulletin Unit](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984108251056)

  - 32.2.2.10 [Force and Effect of Revenue Rulings, Revenue Procedures, Notices, Announcements, and News Releases](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984128403632)
  - Exhibit 32.2.2-1 [Format for Nonpublication Memorandum](https://www.irs.gov/irm/part32/irm_32-002-002#idm139984110775888)

# Part 32. Published Guidance and Other Guidance to Taxpayers

# Chapter 2. Chief Counsel Publication Handbook

# Section 2. Summary of the Published Guidance Process

* * *

## 32.2.2 Summary of the Published Guidance Process

#### Manual Transmittal

April 14, 2017

#### Purpose

(1) This transmits revised CCDM 32.2.2, Chief Counsel Publication Handbook; Summary of the Published Guidance Process.

#### Background

This section incorporates recent recommendations to update procedures for drafting published guidance into section CCDM 32.2.2.3.

#### Material Changes

(1) CCDM 32.2.2.3 is revised to provide factors to consider when determining the appropriate form of guidance and to provide cross-references.

(2) The current version of CCDM 32.2.2.3(1) is revised to provide a separate paragraph for contact information in new CCDM 32.2.2.3(3).

(3) The current version of CCDM 32.2.2.3(2) is reorganized as new CCDM 32.2.2.3(4) and revised to add cross-references.

(4) The current version of CCDM 32.2.2.3(2) is revised to provide factors to consider when determining the appropriate form of guidance.

(5) CCDM 32.2.2.3(3) is inserted to provide contact information.

(6) CCDM 32.2.2.3(4) is inserted and cross-references have been added.

#### Effect on Other Documents

CCDM 32.2.2, dated September 16, 2011, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(04-14-2017)

Kathryn A. Zuba

Acting Associate Chief Counsel

(Procedure & Administration)

**32.2.2.1** **(08-11-2004)**

### General Information About Revenue Rulings, Revenue Procedures, Notices, Announcements, and News Releases

1. Revenue rulings, revenue procedures, notices, and announcements are issued only by the national office and are published in the IRB. Publication in the IRB provides an orderly system for dissemination of information and promotes effective communication with the tax community. IRBs issued for a calendar year are consolidated as two Cumulative Bulletins (CB).

2. Although the IRB is the authoritative instrument of the Commissioner for publishing revenue rulings, revenue procedures, notices, and announcements, it may be beneficial to immediately release certain publications directly to the news media for faster public dissemination. In these situations, the Service’s Media Relations office should be contacted.

3. A news release may be appropriate in those situations in which there is a significant need to alert the general news media (as distinguished from the commercial tax services and the financial, professional, and trade publications that routinely disseminate information published in the IRB). The issuance of a news release is, however, supplemental to, and not in lieu of, publication in the IRB. Maintaining the integrity of an orderly publication system through the IRB contributes significantly to good tax administration. Therefore, the preparation of news releases should be limited to those circumstances in which the need is clearly justified.


**32.2.2.2** **(08-11-2004)**

### Purpose of Revenue Rulings, Revenue Procedures, Notices, Announcements, and News Releases

1. Official publications published by the Service provide information and guidance for taxpayers, Service personnel, and others. Their purpose is to help Service personnel apply the tax laws correctly and uniformly and to help taxpayers voluntarily comply with the tax laws.


**32.2.2.3** **(04-14-2017)**

### Definitions

1. Each publication has its own general characteristics and uses. To ensure consistency, care should be taken to select the appropriate vehicle for disseminating information to the public.

2. Attorneys must consider the appropriate form of guidance and document the decision to use that form of guidance in the related file. Factors to consider when determining the appropriate form of guidance may include, but are not limited to, the following:



   - The purpose of the guidance and the possible guidance alternatives

   - The scope of the guidance’s application

   - The effect on taxpayer’s rights

   - The effect on taxpayer’s duties

   - The degree of deference needed for the guidance

   - Whether the guidance will be controversial

   - Whether public comments are necessary or helpful

   - Longevity of the guidance

   - Whether the guidance should include the application of law to a factual scenario

   - Advantages of the type of guidance selected


3. Questions regarding the appropriate document may be directed toward the Office of the Associate Chief Counsel (Procedure and Administration).

4. Following the rules and procedures in the Publication Handbook ensures compliance with the various statutory and administrative requirements. See [CCDM 32.1.2.1 Procedural Requirements for Regulations; The Legal File](http://publish.no.irs.gov/getpdf.cgi?catnum=38994), and [CCDM 30.9.2, File Management; Guidelines for Specific Categories of Case Files](http://publish.no.irs.gov/getpdf.cgi?catnum=29714).


**32.2.2.3.1** **(08-11-2004)**

#### Revenue Ruling Defined

1. A revenue ruling is an official interpretation by the Service of the Internal Revenue Code, related statutes, tax treaties, and regulations. It is the conclusion of the Service on how the law is applied to a specific set of facts. For further information, see section 601.601(d)(2) of the Statement of Procedural Rules.


**32.2.2.3.2** **(08-11-2004)**

#### Revenue Procedure Defined

1. A revenue procedure is an official statement of a procedure by the Service that affects the rights or duties of taxpayers or other members of the public under the Internal Revenue Code, related statutes, tax treaties, and regulations, or information that, although not necessarily affecting the rights and duties of the public, should be a matter of public knowledge.


**32.2.2.3.3** **(08-11-2004)**

#### Notice Defined

1. A notice is a public pronouncement by the Service that may contain guidance that involves substantive interpretations of the Internal Revenue Code or other provisions of the law. Notices may be used in circumstances in which a revenue ruling or revenue procedure would not be appropriate. In addition, notices may be used to solicit public comments on issues under consideration, in connection with non-regulatory guidance, such as a proposed revenue procedure. A notice also can be used to relate what regulations will say in situations in which the regulations may not be published in the immediate future.


**32.2.2.3.4** **(08-11-2004)**

#### Announcement Defined

1. An announcement is a public pronouncement that has only immediate or short-term value. For example, an announcement can be used to summarize the law or regulations without making any substantive interpretation or to notify taxpayers of the existence of an election or an approaching deadline for making an election.


**32.2.2.3.5** **(08-11-2004)**

#### News Release Defined

1. A news release is a nontechnical publication targeted at the nonpractitioner public through the general news media. A news release is appropriate if the matter is likely to be covered in a major newspaper. Because news releases are, in effect, proposed articles for these newspapers to run, technical discussion must be kept to a minimum, and material like Internal Revenue Code section numbers is generally relegated to the end of the article, far away from the lead. News releases are not published in the IRB.

2. News releases are generally drafted by the staff of the Service’s Media Relations office, but may be reviewed by Chief Counsel personnel. The Media Relations staff can often provide helpful guidance regarding whether a news release is appropriate.

3. The decision to disseminate information in the form of a news release must be approved at the Associate Chief Counsel or higher level.


**32.2.2.4** **(08-11-2004)**

### Distinction Between Revenue Rulings and Revenue Procedures

1. Revenue rulings and revenue procedures are alike in that both are issued only by the national office and both are for the information and guidance of taxpayers, Service personnel, and others concerned. One numerical series is used for revenue rulings and another is used for revenue procedures. Whether an item is published as a revenue ruling or revenue procedure depends on its content.

2. The revenue ruling series is used to set forth statements of Service position or to interpret the law with respect to particular tax issues. The revenue procedure series is used to announce statements of procedure or general instructional information. A holding on a substantive tax issue to the effect that taxpayers must meet some procedural requirement is a statement of Service position and is not the proper subject for a revenue procedure.

3. Generally, a revenue ruling states a Service position, whereas a revenue procedure provides instructions concerning a Service position that enable taxpayers to achieve a particular result. For example, a revenue ruling may hold that taxpayers may deduct certain automobile expenses, and a revenue procedure may provide the procedures that eligible taxpayers must follow to compute the amount of the deduction by using certain mileage rates in lieu of determining actual operating expenses.

4. A revenue ruling does not ordinarily include a statement of Service practice or procedure, and a revenue procedure does not ordinarily include a statement of Service position on a substantive tax issue. When a matter involves both a statement of Service position on a substantive tax issue and a statement of practice or procedure, it normally requires the issuance of both a revenue ruling and a revenue procedure. They should be issued simultaneously and should be cross-referenced.

5. In certain circumstances it may be appropriate to include limited procedural guidance in a revenue ruling or provide a holding on substantive tax issues in a revenue procedure. For example, a revenue ruling that holds that certain expenses are deductible, rather than subject to capitalization, may contain a procedure for taxpayers to change their method of accounting to conform to the holding of the revenue ruling. In certain cases a revenue procedure can provide a holding on substantive tax issues where it sets forth safe harbors, guidelines, or conditions. See Rev. Proc. 97-13. These situations should be rare and the general rule stated in paragraph (4) should usually be followed.


**32.2.2.5** **(08-11-2004)**

### Congressional Review of Rules

1. The Small Business Regulatory Enforcement Fairness Act of 1996 (SBREFA) added new chapter 8 to title 5, United States Code. This chapter provides that no rule can become effective until the issuing agency submits a report containing certain information to the House of Representatives, the Senate, and the Comptroller General of the General Accounting Office (GAO). These congressional review provisions became effective March 29, 1996.

2. SBREFA applies to most revenue rulings and revenue procedures (with an exception for certain ministerial rules) and may apply to notices and announcements, which are evaluated on a case-by-case basis.

3. See CCDM 32.2.8.2 for additional guidance concerning Congressional review of rules.


**32.2.2.6** **(08-11-2004)**

### Identifying and Establishing a Publication Project

1. The need for published guidance can be identified from a number of internal and external sources. The procedures in this Handbook should be followed regardless of the source.

2. An important consideration in evaluating potential publication projects is the need to eliminate impediments to electronic filing.


**32.2.2.6.1** **(09-16-2011)**

#### Identifying Issues

1. Issues to be published are identified from many sources, including, but not limited to:



   - Issues in various types of cases, such as technical advice and letter rulings

   - Comments and suggestions from the Commissioner and other Service personnel

   - Comments and suggestions from taxpayers, practitioners, outside organizations (including issues raised through the industry issues resolution program), tax publications and periodicals, continuing legal education programs for tax professionals, and other comments on tax law directed at professionals or the taxpaying public

   - Comments and suggestions from the Chief Counsel, Deputy Chief Counsel, Associate Chief Counsel, and Division Counsel (and their staffs), and from Treasury personnel

   - Announcements of acquiescence or nonacquiescence on Tax Court opinions

   - Chief Counsel Notices bearing the title "CHANGE IN LITIGATION POSITION" ("CLP" )

   - Recently enacted legislation

   - Common issues in private letter ruling requests (Associate Chief Counsel offices should annually review the uniform issue list codes related to private letter rulings issued during the past year to determine whether the issuance of published guidance may be appropriate for any of the common issues in these requests)


**32.2.2.6.2** **(09-16-2011)**

#### Guidance Priority List

1. Each year the IRS and Treasury develop a Guidance Priority List (GPL), which is also sometimes referred to as the Priority Guidance Plan (or "business plan" ). The GPL identifies the issues that will be addressed in published guidance during the business plan year. The IRS and Treasury solicit recommendations from the public for items that should be included on the GPL. The IRS and Treasury also consider recommendations from within the Service, the Office of Chief Counsel, and other government agencies. Interested parties may submit recommendations for guidance at any time during the year.

2. The GPL may be updated periodically. These updates provide the IRS and Treasury with greater flexibility to address the need for additional guidance that may arise during the business plan year resulting from new legislation, changes in policy, or other emerging circumstances. If new projects must be added during the business plan year, the Office of Chief Counsel and Treasury may have to reevaluate which projects must be published and those for which publication may be deferred. As the need arises, the IRS and Treasury work on published guidance projects that do not appear on the GPL.


**32.2.2.6.3** **(09-16-2011)**

#### Stakeholder Requests for Published Guidance

1. The Office of Chief Counsel receives suggestions for published guidance from many sources within the IRS, as well as from external sources, such as the American Bar Association, the Tax Executives Institute, and the American Institute of Certified Public Accountants. These suggestions should be given serious consideration in the process of selecting and prioritizing guidance initiatives for inclusion in the annual Guidance Priority List. In addition, each Associate Chief Counsel office should strongly consider issuing published guidance concerning substantially similar matters that are repeated subjects of private letter ruling requests, technical assistance memoranda, or other requests for legal advice.

2. The IRS and Treasury annually publish a Notice inviting recommendations from the public for items to be included on the GPL for the upcoming year. The Notice usually is published in the Internal Revenue Bulletin in late April or early May, and seeks comments by the end of May, but also reminds the public that suggestions may be submitted to the IRS at any time during the year. In addition to the Internal Revenue Bulletin, the Notice is posted on the IRS website, and is published in the popular tax press, as well as on scores of publicly accessible Internet web sites.

3. To facilitate the appropriate consideration of these suggestions, the Publications and Regulations Branch, Legal Processing Division, in the Office of the Associate Chief Counsel (Procedure and Administration), will forward to the appropriate Associate office the stakeholder suggestions for published guidance sent to the Office of Chief Counsel.

4. Suggestions for published guidance from external sources that are received directly by attorneys or Associate offices should be sent to the Publications and Regulations Branch. The Publications and Regulations Branch will acknowledge receipt of all suggestions for published guidance received from external sources and will maintain a file of these suggestions.

5. Each Associate office should maintain organized files regarding requests for published guidance from both internal and external sources that involve issues within that office’s subject matter jurisdiction. These files should be maintained in a way that facilitates retrieval of suggestions for consideration in selecting and prioritizing issues to be included on a future Guidance Priority List or an update to the list. Each suggestion, whether from internal or external stakeholders, should be evaluated in light of the criteria described in CCDM 32.2.2.6.4, and each Associate office should document the reasons for its decision to recommend for or against inclusion of a suggestion on the GPL.


**32.2.2.6.4** **(04-28-2009)**

#### Publication Criteria

1. When selecting projects for the GPL, the IRS and Treasury consider the following:



   - Whether the recommended guidance resolves significant issues relevant to many taxpayers

   - Whether the guidance may be appropriate for enhanced public involvement through the process described in Notice 2007-17, 2007-12 I.R.B. 748

   - Whether the recommended guidance promotes sound tax administration

   - Whether the recommended guidance can be drafted in a manner that will enable taxpayers to understand and apply the guidance easily

   - Whether the IRS can enforce the recommended guidance on a uniform basis

   - Whether the recommended guidance reduces controversy or lessens the burden on taxpayers or the IRS


2. Matters should be recommended for publication only if they meet at least one of the foregoing criteria.



### Note:



A subject that is primarily a determination of fact rather than an interpretation of law should not ordinarily be recommended for publication, even though the subject meets one or more of the above publication criteria.

3. In addition to the factors described above, the IRS and Treasury consider whether the guidance is required by statute, the number of taxpayers affected by the proposed guidance, and the resources available to complete all the guidance projects proposed for a particular year. The IRS and Treasury strive to include the most important suggestions for guidance on the GPL each year.


**32.2.2.6.4.1** **(08-11-2004)**

##### Unprecedented Subject and Significant Issue

1. The subject is unprecedented (meaning it is not covered by statute, treaty, or regulations; or it is not covered by publications, court opinions previously published in the IRB, or by an open publication project) and has a significant issue as indicated below.



1. **Significant Impact on Taxpayers or Tax Exempt Organizations**. An issue affects a significant number of taxpayers if a large number of taxpayers need the conclusion in order to prepare their tax returns or to comply with the tax laws. The issue would meet this standard even though its revenue impact is minor for an individual taxpayer. Such issues warrant publication and are typically later incorporated into Publication 17, Your Federal Income Tax. On the other hand, issues not currently answered by statute, regulations, or revenue rulings, that affect few taxpayers or involve an obvious application of an existing published principle, are of insufficient importance or interest to warrant publication.

2. **Substantial Segment of Industry(ies)**. An issue may qualify under this criterion even though the industry has a small number of entities. What is important is that the IRS notify all entities in the industry simultaneously of a newly established position. For example, in the excise tax area, a letter ruling to one company that a product line is nontaxable would give that company a major competitive advantage over other entities producing the same product. Thus, there may be a publishable issue even though there are only a few entities affected and the aggregate revenue involved is not great.

3. **Significant Impact Upon Revenue.** An issue may qualify for this criterion if it will have a significant impact upon revenue. It includes the publication of issues derived from letter rulings and technical advice.

4. **Invalid Tax Transactions.** An issue may qualify under this criterion if it includes anticipating invalid tax shelters and tax schemes and taking prompt action to prevent proliferation of these transactions, rather than waiting to deal with them at a later time in the return examination program.

5. **Significant Legal Issue**. An issue may qualify under this criterion if it addresses a significant legal issue. It includes definitions of basic concepts, such as partnerships, associations, trusts, and similar terms if clarification is needed, even though revenue impact may be minimal. This standard would also apply to clarification of regulation or treaty provisions.

6. **Uniform Application of the Tax Law**. An issue may qualify under this criterion if there is a lack of uniformity in application of the tax law to that issue. An example would be evidence of conflicting positions on an issue by examination personnel in different areas. Similarly, conflicting court opinions would be a basis for publication in certain instances.


**32.2.2.6.4.2** **(08-11-2004)**

##### Revises Published Service Position or Procedure

1. A position or procedure is _revised_, for this purpose, if it is amplified, clarified, distinguished, modified, obsoleted, revoked, superseded, supplemented, or suspended.


**32.2.2.6.4.3** **(08-11-2004)**

##### Reflects a Matter or Matters the Service is Required by Law or Regulation to Publish

1. The following are examples of matters the Service is required by law or regulation to publish. Under section 6621, the Service periodically publishes the interest rates applicable to tax deficiencies and refunds. In the municipal bond area, the Service periodically publishes several different statistical tables setting forth safe harbors, state ceilings, and similar data.


**32.2.2.6.4.4** **(08-11-2004)**

##### Materially Assists in the Administration of Tax Laws

1. This criterion covers the publication of projects that facilitate the letter ruling, determination letter, and technical advice programs. It also encompasses substantive publications on relatively routine subjects, where tax practitioners might otherwise seek a letter ruling. Also covered are many of the publishable topics that are proposed by Treasury, the Commissioner, professional associations, or through the Industry Issue Resolution Program.


**32.2.2.6.4.5** **(08-11-2004)**

##### Affects the Rights or Duties of Taxpayers or Tax Exempt Organizations

1. This criterion covers many of the publications that provide instruction and information to the public.


**32.2.2.6.5** **(08-11-2004)**

#### Recommendation to Establish a Publication Project

1. Recommendations for proposed publications can be made by the Treasury, Service personnel, and Chief Counsel personnel.

2. Recommendations for proposed publications should be made in the manner provided by the Associate office to which the recommendation is being made.


**32.2.2.6.6** **(08-11-2004)**

#### Establishment and Control of a Publication Project

1. The Associate Chief Counsel will establish procedures for opening approved publications projects in the Associate offices.

2. The appropriate CASE category should be used when opening a publications project. A project opened as a Revenue Ruling (RR), Revenue Procedure (RP), or as a Notice/Announcement (NOT) must be approved by the Associate Chief Counsel.

3. If a project warrants publication but the appropriate format cannot yet be determined it can be opened with the CASE category Published Guidance/Proposals and Studies (PGP). This category is also appropriate for preparing or reviewing special studies of technical issues that require extensive research and cannot be handled in the normal course of operations. For example, a case can be opened under this category to determine whether a publication is needed on a particular tax issue. Projects under this category must be approved by the Associate Chief Counsel. If a recommendation warrants further consideration or study, a publication project may be opened in order to explore the issues raised in the recommendation.

4. In those cases in which the proposed publication is based upon an underlying letter ruling or technical advice, it must be titled by reference to the primary issue addressed (a generic title) rather than to the taxpayer’s name, for example, "Corporate Continuance Statutes" not "Smith Corp." A notice or announcement project should include the type of guidance in the title since both publications are opened with the CASE category NOT. If the name of the project contains a reference to another publication, then the new project name should begin with the identification of that publication, for example, "Rev. Rul. 83-100, Revocation of" rather than "Revocation of Rev. Rul. 83-100."


**32.2.2.6.6.1** **(04-28-2009)**

##### Updates on CASE-MIS

1. The drafting attorney is responsible for ensuring that a publication project is updated to reflect milestones during the development of the publication and closed in accordance with the CASE-MIS handbook.

2. Each Associate office is required to enter status report and progress updates into CASE-MIS.

3. In August 2008, the Office of Chief Counsel issued new Business Plan Tracking Instructions describing the procedures for tracking published guidance projects in CASE-MIS. The Business Plan Tracking Instructions are available on the F&M Chief Counsel Intranet website under Planning and Finance, Systems Coordination Branch. The instructions reflect revisions made to CASE-MIS to more accurately describe the status of published guidance projects and to capture target and milestone dates.

4. Two new reports are available on CASE-MIS to track the progress of published guidance projects. The Business Plan Status Report reflects milestone dates and other relevant information, and may be generated using various values to provide customized information. The Business Plan Mandatory Date Report allows users to quickly see which cases need immediate action based on the parameters selected by the user.


**32.2.2.6.6.2** **(04-28-2009)**

##### Milestones

1. The Office of Chief Counsel uses various milestones to manage the published guidance process. Those milestones are reflected in the revised status codes described in the August 2008 Business Plan Tracking Instructions. These milestones assist in identifying whether a published guidance project is on track to be issued by its target publication date. Only the dates for "interim milestones" , described in CCDM 32.2.2.6.6.2.6, must be estimated and tracked on CASE-MIS. The other steps in the published guidance process described in more detail below also may be appropriate for tracking the progress of particular projects. The formal interim milestones set forth in CCDM 32.2.2.6.6.2.6 are not intended to be used as inflexible deadlines. Rather, it is understood that target dates are changed for a variety of reasons inherent in the published guidance process. Ultimately it is more important for the Associate offices to meet the target publication dates of the individual projects over interim milestone date projections, and that an annual measurement is a more accurate reflection of the relative success of the Associate office in publishing guidance than a measurement of whether interim milestones have been met.

2. In addition to the mandatory green circulation draft, each Associate office may consider one or more of the following steps to complement the milestones tracked on CASE-MIS:



   - Issues memorandum

   - Coordination with other offices before initial circulation draft

   - Initial circulation draft

   - Coordination with Treasury on material issues

   - Chief Counsel or joint briefing


3. Associate offices should identify which of these steps may be appropriate for each project and establish target dates for completion. Except for the green circulation draft, whether any specific step described below is appropriate for a project is within the judgment and discretion of the Associate office. The steps taken and the order in which they are completed will be governed by factors such as the complexity of the project and type of guidance being issued, as well as the relationship a particular office has with Treasury and the participating IRS operating divisions. It is anticipated that the need for particular steps will be revisited throughout the plan year as published guidance projects progress towards completion and as developments arise.

4. These interim milestones and steps, in conjunction with the target publication date, should provide an early warning of whether delays are being encountered with respect to a project, without imposing an undue administrative burden on the Associate office. Progress on these milestones, specifically, whether and which of the interim milestones have been completed, when viewed in relation to the target publication date, will assist in determining which projects are subject to delay.


**32.2.2.6.6.2.1** **(04-28-2009)**

###### Issues Memorandum

1. The preparation of an issues memorandum is strongly encouraged for virtually all published guidance projects. Ideally, an issues memorandum will be prepared at a relatively early stage in the process, preferably before any significant drafting has been done. For certain more complex projects, it may be desirable to prepare additional issues memoranda as the project progresses to reflect newly identified issues and recommendations or significant revisions to the previously identified issues and recommendations. This may be appropriate, for example, in advance of a Chief Counsel or joint briefing.

2. There is no prescribed format for the issues memorandum and the level of detail is left to the discretion of the Associate office. In general, however, the issues memorandum should identify the significant issues raised in the project and should include an analysis and recommended resolution. The issues memorandum should present alternative and opposing positions, as well as whether coordination with specific offices is needed to prepare a circulation draft. Preparation of an issues memorandum will assist the Associate office in determining which other steps would be appropriate for the project, such as whether coordination should occur prior to circulation of a draft or whether a Chief Counsel or joint briefing will be needed.

3. This step will be considered to have been completed when the initial issues memorandum is approved by the Associate Chief Counsel. In general, this step should be completed well before the target publication date.


**32.2.2.6.6.2.2** **(04-28-2009)**

###### Coordination with Other Offices before Initial Circulation Draft

1. This step is designed to ensure that the Associate office coordinates with other Associate offices, Division Counsel or IRS functions that are either directly affected by an issue in the project or with subject matter jurisdiction over an issue in the project. This coordination may be formal or informal and should be prior to any widespread circulation of a draft. It is expected that the coordination contemplated by this step will ordinarily occur at the developmental stage of the process, such as during the preliminary draft or precirculation stage. It is recognized, however, that this step may be appropriate more than once during the course of the project, since the need for additional coordination with other offices may arise as the project progresses. In this regard, the circulation of preliminary drafts to a wider audience is strongly encouraged. Required coordination with other offices is discussed in CCDM 32.2.5, Coordination and Clearance.


**32.2.2.6.6.2.3** **(08-11-2004)**

###### Initial Circulation Draft

1. This step is mandatory for all published guidance projects. The circulation draft is discussed in CCDM 32.2.6.4, General Circulation. This step is intended to provide offices that are not involved in the development of a project with a meaningful opportunity for comment. The existing practice in some offices has been to only do a general circulation shortly before the expected publication of the project. This practice tends to minimize any meaningful opportunity for comment by functions that were not previously involved in the drafting process and frequently results in consternation and resistance on the part of the initiating Associate office when comments are received late in the game that may delay or derail the project. Consequently, the circulation of preliminary drafts to a wider audience is strongly encouraged. Moreover, the circulation draft should ordinarily be circulated several months prior to the date the Associate office anticipates beginning the formal approval process for the publication package. Depending on the nature and extent of the comments received, it is sometimes appropriate to circulate additional drafts prior to beginning the publication package approval process.

2. This step will be considered to have been completed when a draft is widely circulated outside the Associate office responsible for the project. In general, the target date for this step should be about two to four months prior to the target publication date.


**32.2.2.6.6.2.4** **(04-28-2009)**

###### Coordination With Treasury on Material Issues

1. This step entails soliciting input from Treasury regarding material issues in the project. Materials issues are those issues requiring direction from Treasury in order to meaningfully move the project towards completion. Ideally, this coordination will occur at a relatively early stage in the process. It is recognized, however, that this step may be appropriate more than once during the course of the project, since the need for additional coordination with Treasury may arise as the project progresses and additional issues are identified and developed. This step differs from the joint briefing milestone described in CCDM 32.2.2.6.6.2.5 in that the coordination contemplated in this step is generally informal and is at a level below the Assistant Secretary for Tax Policy.


**32.2.2.6.6.2.5** **(04-28-2009)**

###### Chief Counsel or Joint Briefing

1. This step is appropriate when a decision is needed by the Chief Counsel or Assistant Secretary for Tax Policy regarding policy or other significant issues in the project. A Chief Counsel or joint briefing is often used to resolve conflicts. In some complex projects, more than one Chief Counsel or joint briefing may be needed. A Chief Counsel or joint briefing is a formal briefing at which all interested offices or functions will be represented. Accordingly, a briefing package normally will be distributed ahead of time to the participants and a conference memorandum will be prepared after the briefing summarizing the decisions that were made at the briefing.


**32.2.2.6.6.2.6** **(04-28-2009)**

###### Tracking Interim Milestones

1. The August 2008 Business Plan Tracking Instructions describe revised interim milestone fields on CASE-MIS. While interim milestone dates are not mandatory, they are required for all Guidance Priority List items. The revised milestone date fields are: Green Sheet, Pink Sheet, CC Review, Commissioner Review, OTP Review. It is expected that target dates for the interim milestones that are considered appropriate for the project will be established near the beginning of the business plan year or shortly after a project is opened, for projects that are begun during the business plan year. Each target date is considered met when a project enters the next appropriate status, and once the appropriate status code is entered the checkbox next to the milestone is automatically populated. The field can be updated but the checkbox will remain checked. For example, if a case that reached status 718 (Pink Sheet) required extensive rewriting, you may put the status back to 717 (Green Sheet circulation). The new green sheet circulation date will be noted on the case history screen but the green sheet will continue to be shown as completed. Reports will show the last date a project has passed the milestone.

2. Since the interim milestones are intended to be a management tool, not an evaluative tool, the target dates for the milestones may be changed by the Associate office as appropriate. In addition, there is only one target date field per interim milestone, which will be overridden whenever a new target date is entered for that milestone.


**32.2.2.7** **(08-11-2004)**

### Nonpublication of Projects Originally Recommended for Publication

1. If a project is recommended for nonpublication, a memorandum discussing the reason for closing the project must be prepared and approved by the appropriate officials before the project is closed on CASE-MIS. For the format of a nonpublication memorandum, see Exhibit 32.2.2-1.

2. The standards for nonpublication of an open guidance project and the details concerning what should be included in a nonpublication memorandum are contained in this section.


**32.2.2.7.1** **(08-11-2004)**

#### Standards for Nonpublication

1. An open publication project may be identified as an appropriate subject for nonpublication by the drafting attorney or by any person in the review process.

2. An open publication project may be closed by nonpublication for any of the following reasons:



   - The matter involves an issue specifically addressed by another open publication project.

   - The issue is answered by statute, treaty, or regulations, or will be answered by pending legislation; answered by publications or court opinions previously published in the IRB; involves a determination of fact rather than an interpretation of law; or is of insufficient importance or interest to warrant publication.

   - The matter is recommended for nonpublication by an Associate Chief Counsel, a Division Counsel, the Chief Counsel, the Commissioner, or by a Treasury official.


**32.2.2.7.2** **(08-11-2004)**

#### Nonpublication Memorandum

1. If an open publication project is identified as an appropriate subject for nonpublication, a nonpublication memorandum is prepared by the drafting attorney. After the memorandum is approved, the original is included in the case file and one copy is sent to the Associate office, which will notify those who reviewed the proposed publication of the nonpublication action.

2. The format for typical nonpublication memoranda is set forth in Exhibit 32.2.2-1.


**32.2.2.7.2.1** **(08-11-2004)**

##### How Addressed and Approved

1. A nonpublication memorandum is based on one of the criteria in CCDM 32.2.2.7.1. The nonpublication memorandum is addressed to the appropriate Associate office in which the branch having jurisdiction of the subject matter is located. An approval legend for the Associate Chief Counsel signature is typed as the last line of the memorandum (following a "concurred in" legend for the branch reviewer). See Exhibit 32.2.2-1.


**32.2.2.7.2.2** **(08-11-2004)**

##### Body of Nonpublication Memorandum

1. The body of the nonpublication memorandum must contain the following in separate paragraphs:



1. Introduction. A statement that the project is under consideration; a description of the basis of the project; the date of issuance of any relevant document; and a brief statement of the issue, holding, or procedure to assist the reviewing officials in reaching a decision concerning Nonpublication

2. Background or Reason for Nonpublication Recommendation. A discussion of the developments or events that led to a conclusion that the matter should be closed by nonpublication. The memorandum should contain sufficient information for the reviewing officials to determine the validity of the recommended closing without reviewing the file.

3. Recommendation Regarding Nonpublication. A direct recommendation that the project be closed and no further consideration be given to its publication. The reason for the recommendation should be stated


2. Files closed by nonpublication will be retained in accordance with the records control schedule set forth in IRM 1.15.14, Records Control Schedule for Internal Revenue Service for Associate Chief Counsel Offices.


**32.2.2.8** **(08-11-2004)**

### Effect on Other Documents

1. Each publication project should be reviewed for its potential effect on prior publications. A publication may be used to effect a change in a prior publication issued in an equal or lower series. A publication may never be used to effect a change in a prior publication issued in a higher series. Regulations would be the highest series, followed by revenue rulings and revenue procedures, then notices and announcements, and lastly, news releases. For example, when appropriate, a revenue ruling may be used to modify a revenue ruling, revenue procedure, notice, or announcement. A revenue ruling may never be used to modify a regulation. See CCDM 32.1.5.4.7.4, Required Format for Regulations, for information on the effect of regulations on other publications.

2. When a publication affects a prior publication a separate section with the heading EFFECT ON OTHER DOCUMENTS must be used in the new publication. Include the title of the affected document and the effect of the new publication. For example: Rev. Rul. 69-259 is modified and superseded. See also CCDM 32.2.3.5.1.2.6, Effect on Other Revenue Rulings (or Documents), and CCDM 32.2.3.5.2.1.6, Effect on Other Revenue Procedures (or Documents).

3. When a proposed publication affects a prior publication, one of the terms (or a combination of terms) described below is used. These are the only terms that may be used to describe the effect of a publication on a prior publication.


**32.2.2.8.1** **(08-11-2004)**

#### Use of Terms

1. _**Amplified**_ is used when no change is being made in a prior published position, but the prior position is being extended to apply to a variation of the facts. Thus, if an earlier publication held that a principle applied to A and the new publication holds that the same principle also applies to B the earlier publication is amplified. (Compare with modified, below.)

2. _**Clarified**_ is used when the language in a prior publication is being made clear because the language in the prior document has caused, or may cause, some confusion. It is not to be used when a position in a prior publication is being changed.

3. _**Distinguished**_ is used when a proposed publication mentions a prior publication and points out an essential difference between them.

4. _**Modified**_ is used when the substance of a previously published position is being changed. Thus, if a prior publication held that a principle applied to A but not to B and the new publication holds that it applies to both A and B, the prior publication is modified because it changes a published position. Consideration should be given to the application of section 7805(b)(8). (Compare with _amplified_ and _clarified_.)

5. _**Obsoleted**_ is used when a previous publication is not considered determinative with respect to future transactions. This term is used in a revenue ruling that lists previously published revenue rulings that are obsoleted because of changes in law or regulations. A publication also may be obsoleted because the substance has been included in regulations subsequently adopted.

6. _**Revoked**_ is used when the position in a previous publication is not correct and the correct position is being stated in a new publication. Consideration should be given to the application of section 7805(b)(8) regarding retroactivity.

7. _**Superseded**_ is used when the new publication does nothing more than restate the substance and situation of a previous publication (or publications). _Superseded_ is also used when it is desired to republish in a single publication a series of situations, issues, etc., that were published previously over a period of time in separate publications.



### Note:



If the new publication does more than restate the substance of a prior publication, a combination of terms is required. For example, modified and superseded describes a situation in which the substance of a previously published ruling is being changed in part and is continued without change in part, and it is desired to restate the valid portion of the previous publication in a new self-contained publication. In such a case, the previous publication first is modified and then, as modified, is superseded. See also CCDM 32.2.3.5.1.2.6 , Effect on Other Revenue Rulings (or Documents).

8. _**Supplemented**_ is used only in situations in which a list, such as a list of the names of countries, is published and that list is expanded by adding names in subsequent publications. After the original publication has been supplemented several times, a new publication should be published to include the list in the original publication and the additions, and all prior publications in the series are superseded.

9. _**Suspended**_ is used only in rare situations to show that previously published guidance will not be applied pending some future action, such as the issuance of new or amended regulations, the outcome of cases in litigation, or the outcome of a Service study.


**32.2.2.9** **(09-16-2011)**

### Responsibility for Publishing Revenue Rulings, Revenue Procedures, Notices, Announcements, and News Releases

1. The procedures concerning the responsibilities of persons throughout the publication process will vary depending on the organizational structure and the procedures of the Associate office.


**32.2.2.9.1** **(08-11-2004)**

#### Responsibility for Administering the System

1. The Chief Counsel is responsible for administering a system for publishing revenue rulings, revenue procedures, notices, and announcements in the IRB, and for assisting in the creation of news releases, including standards for style and format.

2. The Associate Chief Counsels are responsible for the management and operation of the publications program. The Associate offices are also responsible for day-to-day managing of the publications program, monitoring the progress of each proposed publication, and conducting periodic reviews of the publications inventory. The Associate offices prepare periodic status reports, set target dates, prepare memoranda or take other follow-up action needed to move proposed publications through the review process, and coordinate all incoming memoranda from the Chief Counsel, the Commissioner, and Treasury with respect to proposed publications in the review process. The Associate offices are also responsible for ensuring that the congressional review of rules reports are completed and timely forwarded to the Publications and Regulations Branch for delivery. See CCDM 32.2.8.2, Congressional Review of Rules.


**32.2.2.9.2** **(08-11-2004)**

#### Responsibility for Preparing Revenue Rulings, Revenue Procedures, Notices, Announcements, and News Releases

1. Each Associate Chief Counsel is responsible for:



   - Identifying issues and procedures affecting taxpayers’ rights and duties on which published guidance is needed

   - Drafting publications to reflect interpretations that come within the criteria set forth in CCDM 32.2.2.6.4

   - Coordinating proposed publications with any affected offices (see CCDM 32.2.5, Coordination and Clearance)

   - Clearing proposed publications

   - Referring proposed publications to the Chief Counsel, the Commissioner, and Treasury

   - Transmitting to the Bulletin Unit (SE:W:CAR:MP:T:T:SP) approved revenue rulings, revenue procedures, notices, and announcements for publication

   - Coordinating news releases with Media Relations (CL:C:MR) for release to the public


**32.2.2.9.3** **(09-16-2011)**

#### Responsibilities Within the Offices of the Associate Chief Counsel

1. The Associate Chief Counsel (PA), coordinating with the Division Counsel/Associate Chief Counsel (TEGE) and other Associate Chief Counsel, is responsible for preparing the annual revenue procedures that pertain to procedures for issuing letter rulings and procedures for furnishing technical advice. The Associate Chief Counsel (Corporate) is responsible for preparing the annual "no-rule" revenue procedure consolidating the no-rule areas for the Associate Chief Counsel (except International) and the Division Counsel/Associate Chief Counsel (TEGE). The Associate Chief Counsel (International) is responsible for preparing the annual "no-rule" revenue procedure covering matters under the jurisdiction of International.


**32.2.2.9.4** **(08-11-2004)**

#### Services Performed by the Bulletin Unit

1. The Bulletin Unit (SE:W:CAR:MP:T:T:SP), in connection with the publication of revenue rulings, revenue procedures, notices, and announcements:



1. Assigns a number to each approved publication and schedules publication in the IRB

2. Reviews index entries and the Highlights for the IRB (on Form 12972, Internal Revenue Bulletin Submission Record)

3. Sends the manuscript copy to the printer


**32.2.2.10** **(08-11-2004)**

### Force and Effect of Revenue Rulings, Revenue Procedures, Notices, Announcements, and News Releases

1. Revenue rulings provide precedents to be used in the disposition of other cases and may be cited and relied upon for that purpose. See Rev. Proc. 89–14, 1989–1 C.B. 814. Revenue rulings do not have the force and effect of Treasury regulations. They can be affected by subsequent legislation, treaties, regulations, revenue rulings, revenue procedures, and decisions of the Supreme Court of the United States.

2. Taxpayers generally may rely upon revenue rulings and revenue procedures in determining their tax treatment if their facts and circumstances are substantially the same as those in the revenue ruling or revenue procedure. See Rev. Proc. 89–14 .

3. For purposes of applying the substantial understatement portion of the accuracy-related penalty imposed by IRC § 6662(b)(2) and (d), all notices and announcements issued by the Service and published in the IRB are considered authority and the Service is bound by the substantive or procedural guidance provided in a notice or announcement to the same extent as a revenue ruling or revenue procedure. See Rev. Rul. 90–91, 1990–2 C.B. 262.

4. Chief Counsel attorneys must follow legal positions established by publications in papers filed in Tax Court or in defense letters or suit letters sent to DOJ. Chief Counsel attorneys may not rely on case law to take a position that is less favorable to a taxpayer in a particular case than the position set forth in a publication. For example, if a revenue ruling provides that a particular expense may be currently deducted, Chief Counsel attorneys should not challenge the deduction even though under the applicable case law, the expense should be capitalized.


**Exhibit 32.2.2-1**

### Format for Nonpublication Memorandum

|  | **Office of Chief Counsel** |
| --: | --- |
|  | **Internal Revenue Service** |
|  | **memorandum** |
|  | \[Branch symbols and initiator's name\]<br>\[TECHMIS number\] |
| **date:** |  |
| **to:** | File |
| **from:** | \[Insert name\]<br>Associate Chief Counsel |
| **subject:** | \[Regulation or Other Form of Published Guidance\] to be Closed by Nonpublication |
|  |  |
|  | We have under consideration the publication of a \[regulation or other form of published guidance\] based on a \[describe source of regulation or other form of published guidance project\]. The proposed \[regulation or other form of published guidance\] would address \[insert description of project\]. |
|  | \[Insert discussion of the reason(s) for nonpublication. This memorandum should contain sufficient information to enable the Associate Chief Counsel to determine whether the project should be closed without the Associate Chief counsel needing to review the legal file.\] |
|  | Action |
|  | Accordingly, this project is being closed and no further consideration will be given to its publication. |
|  | The file in this case should be classified \[add file classification\] and returned to \[insert name of initiator\]. |

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part32/irm_32-002-002#addtoany "Show all")

A2A