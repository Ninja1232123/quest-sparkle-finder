---
url: "https://www.irs.gov/irm/part35/irm_35-008-006"
title: "35.8.6 Decision Documents | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-008-006#main-content)

- 35.8.6 [Decision Documents](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379495028192)
  - 35.8.6.1 [TEFRA Cases](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379465490096)

    - 35.8.6.1.1 [Rule 248(a) Decision Documents](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379468739616)
    - 35.8.6.1.2 [Rule 248(b) Decision Documents](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379474841072)
    - 35.8.6.1.3 [Rule 248(c) Decision Documents](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379473889184)
    - 35.8.6.1.4 [Closing Settled TEFRA Cases](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379495075360)
    - 35.8.6.1.5 [Decisions for TEFRA Penalty Only Cases](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379456806976)

  - 35.8.6.2 [Settlement Documents in Cases Having Other Procedural or Judicial Aspects](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379474007168)

    - 35.8.6.2.1 [Service Offer in Compromise Cases](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379453063504)
    - 35.8.6.2.2 [Attorney Generals Offer in Compromise Refund Suits](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379461691056)
    - 35.8.6.2.3 [Cases Having Concurrent Jurisdiction with Another Case](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379461346304)

  - 35.8.6.3 [Rule 155 Decisions](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379462288496)

    - 35.8.6.3.1 [Computations](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379460832448)

      - 35.8.6.3.1.1 [Time Limitations](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379459900864)
      - 35.8.6.3.1.2 [Computation by Appeals](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379469667984)
      - 35.8.6.3.1.3 [Face Sheet, Computation Statement, and Proposed Decision](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379451444352)
      - 35.8.6.3.1.4 [Review of Computation](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379468938240)
      - 35.8.6.3.1.5 [Decision Document](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379449441072)
      - 35.8.6.3.1.6 [Small Tax Cases](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379470958816)
      - 35.8.6.3.1.7 [Claim for Increased Deficiency](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379460193472)

    - 35.8.6.3.2 [Responsibility of Attorney and Reviewer](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379461724880)

      - 35.8.6.3.2.1 [Forwarding Rule 155 Documents to Petitioner for Approval](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379460234240)
      - 35.8.6.3.2.2 [Failure of Petitioner to Approve](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379456149440)

    - 35.8.6.3.3 [Contested Rule 155 Computations](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379475472528)

  - 35.8.6.4 [Stipulated Decision Documents in Collection Due Process (CDP) Cases](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379461491360)

    - 35.8.6.4.1 [Nonliability Issues](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379471120912)
    - 35.8.6.4.2 [Liability Issues](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379469550320)
    - 35.8.6.4.3 [Sections 6404 and 6015 Issues](https://www.irs.gov/irm/part35/irm_35-008-006#idm140379458698832)

# Part 35. Tax Court Litigation

# Chapter 8. Decisions, Orders of Dismissal, and Other Final Judgments

# Section 6. Decision Documents

* * *

## 35.8.6 Decision Documents

#### Manual Transmittal

July 25, 2012

#### Purpose

(1) This transmits revised CCDM 35.8.6, Decisions, Orders of Dismissal, and Other Final Judgments; Decision Documents.

#### Material Changes

(1) CCDM 35.8.6.4 was added to explain the kinds of stipulated decision documents that should be used in common situations presented in Collection Due Process cases.

(2) Organizational references to APJP were updated to refer to the appropriate P&A practice group.

(3) Exhibit numbers were corrected where necessary. Titles and hyperlinks were added to 33 references throughout the section.

#### Effect on Other Documents

CCDM 35.8.6, dated August 11, 2004, is superseded. This revision incorporates procedures contained in Chief Counsel Notice CC-2009-010.

#### Audience

Chief Counsel

#### Effective Date

(07-25-2012)

Deborah A. Butler

Associate Chief Counsel

(Procedure and Administration)

**35.8.6.1** **(07-25-2012)**

### TEFRA Cases

1. TEFRA partnership and S corporation decisions are reviewed by the Associate Chief Counsel (Procedure and Administration), branches 6 and 7 except as noted. Certain TEFRA decisions may be directly filed with the court, if they follow the format set forth as reflected in the subject exhibits. Any deviation from the form of the appropriate Exhibit will require review of the decision by branches 6 or 7. Those decisions which may be directly filed are:



1. T.C. Rule 248(a) — Stipulated Decisions. See Exhibit 35.11.1–187, Declaratory Judgement Cases: Exempt Organizations, for the proper format for the decision.

2. T.C. Rule 248(b) — Motion for Entry of Decision and Decision. See Exhibit 35.11.1–188 , TEFRA: Rule 248(a) Decision per Settlement — Tabular Format — TEFRA Partnership; Exhibit 35.11.1–189, TEFRA Partnership: Rule 248(b) Motion for Entry of Decision, Certificate and Decision — Tax Matters Partner is a Participating Partner; and Exhibit 35.11.1–190, TEFRA Partnership: Rule 248(b) Motion for Entry of Decision, Certificate and Decision — Tax Matters Partner is not a Participating Partner for the proper format for the motion and decision.


**35.8.6.1.1** **(07-25-2012)**

#### Rule 248(a) — Decision Documents

1. Rule 248(a) provides that a stipulation consenting to the entry of decision executed by the Tax Matters Partner and filed with the court shall bind all parties. The signature of the TMP constitutes a certification by him that no party objects to entry of decision. The signature must be that of the TMP rather than his counsel. Such a stipulation will also be signed by counsel for the Service. See Exhibit 35.11.11.1–187, Declaratory Judgement Cases: Exempt Organizations.


**35.8.6.1.2** **(07-25-2012)**

#### Rule 248(b) — Decision Documents

1. Rule 248(b) provides that if all participating partners have settled or do not object to entry of decision, then, after the expiration of the time within which to file a notice of election to intervene or to participate, the Service shall submit to the court a proposed decision document and motion for entry of decision. The motion should state: (i) that all of the participating partners have entered into a settlement agreement with the Service, or that all such partners do not object to the granting of the Service’s motion, and (ii) the Tax Matters Partner (if a participating partner) agrees to the proposed decision in the case but does not certify that no party objects to the granting of the Service’s motion. The proposed decision shall be in the form prescribed by Rule 155 ( _i.e._, the decision shall contain no stipulation or signature line for the parties, etc.). The certificate of service should reflect service on both the petitioner and the TMP (regardless of whether the TMP is the partner who filed the petition or elected to intervene in the action). T.C. Rule 246. Within three days from the date on which the Service’s motion for entry of decision is filed with the court, the Service shall serve on the TMP a certificate showing the date on which the Service’s motion was filed with the court. Within three days after receiving the Commissioner’s certificate, the TMP shall serve on all other parties to the action other than the participating partners, a copy of the Service’s motion for entry of decision, a copy of the proposed decision, a copy of the certificate showing the date that the motion for entry of decision was filed, and a copy of Rule 248. The court will enter the decision if no partner seeks to intervene within 60 days of the date the Service filed the motion (or if a motion to intervene is filed and the motion to intervene is denied). See Exhibit 35.11.1–189, TEFRA Partnership: Rule 248(b) Motion for Entry of Decision, Certificate and Decision — Tax Matters Partner is a Participating Partner, and Exhibit 35.11.1–190, TEFRA Partnership: Rule 248(b) Motion for Entry of Decision, Certificate and Decision — Tax Matters Partner is not a Participating Partner.

2. **Cash Out-Of-Pocket Settlements Under Rule 248(b)**. Appeals and counsel may settle cases allowing the partners a deduction for their cash invested. A deduction for cash out-of-pocket is not a partnership item, however, which can be reflected in a proposed decision submitted under Rule 248(b). Consequently, respondent shall use the following procedure in submitting proposed Rule 248(b) motions where settlement is based on cash out-of-pocket. Respondent shall send a letter to the Tax Matters Partner, each notice partner, and any other partner of which counsel is aware. The letter should set forth the settlement terms and advise the partners that execution of specific settlement documents, _e.g._, a closing agreement or Form 870–P, Agreement to Assessment and Collection of Deficiency in Tax for Partnership Adjustments, is required as a condition of settlement. The letter shall state that acceptance of the terms and execution of the required documents by the partner, as well as receipt of those executed documents by respondent, must occur by specified dates (for example, the letter may require an initial response within 60 days and execution of the settlement form within 30 days of the date it is sent). The letter should also advise the partners that after the close of the specified period(s), respondent will file a Rule 248(b) motion with a proposed decision reflecting all adjustments set forth in the notice of Final Partnership Administrative Adjustment. See Exhibit 35.11.1–192, TEFRA Partnership: Rule 248(b) Cash Out-of-pocket Settlements — Sample Letter to TMP and Partners, for a sample letter. As settlements are entered into with the partners, the provisions of Rule 248(c) pertaining to notice of settlement must be complied with. After the close of the specified period, respondent will file a Rule 248(b) motion and proposed decision reflecting all the FPAA adjustments. See Exhibit 35.11.1–191 , TEFRA Partnership: Rule 248(b) Motion for Entry of Decision, Certificate and Decision — Cash Out-of- Pocket Settlements, for a sample motion for use with cash out-of-pocket settlements. Since the partnership items of the settling partners will convert to nonpartnership items and those partners will no longer be parties to the partnership proceeding, the decision entered by the court will only affect the nonsettling partners. Sections 6226(d)(1)(A) and 6231(b)(1)(C).



1. Rule 248(b)(4) provides that any partner who objects to the proposed decision may move to participate within sixty days after respondent files the above motion. Often the sole reason for filing motions to participate has been to seek the benefits of the respondent’s settlement position. Since under the procedure described in subparagraph (i), the nonparticipating partners will be given a chance to accept the settlement and informed that if they fail to do so within a prescribed period, the respondent will file a Rule 248(b) motion and proposed decision upholding the adjustments set forth in the notice of FPAA, objections to the motion for entry of decision for the purpose of seeking the benefits of respondent’s settlement position are inappropriate and should be opposed. Accordingly, Field Counsel should file a notice of objection with respect to any motion for leave to file a notice of election to participate if the sole ground for the motion is to enable the partner to belatedly seek the benefits of the respondent’s settlement position. See Exhibit 35.11.1–193, TEFRA Partnership: Notice Of Objection To Motion To Participate Out Of Time, for a sample notice of objection. Such a partner should be seeking relief under the consistent settlement provisions rather than objecting to the Rule 248(b) motion. Treas. Reg. § 301.6224(c)-3(c) sets forth the procedure for requesting consistent settlement terms.

2. Since the cash out-of-pocket Rule 248(b) procedures require more lead time to allow for a defined settlement period prior to submitting the Rule 248(b) motion, respondent should start the process as soon as possible after settlement with the participating partners. This is especially important if a case is calendared.


**35.8.6.1.3** **(07-25-2012)**

#### Rule 248(c) — Decision Documents

1. If all participating partners have settled, then T.C. Rule 248(a) or (b) is applicable rather than Rule 248(c)(1). If less than all participating partners have settled, then Rule 248(c)(1) and/or (2) will apply. Rule 248(c)(1) provides that the Service shall file with the court a notice of settlement agreement or notice of consistent agreement (pursuant to section 6224(c)(2)), whichever may be appropriate, identifying the participating partners who have entered into the agreement. This subsection of Rule 248 deals only with participating partners. With respect to any partner (participating or nonparticipating), Rule 248(c)(2) requires the Service to serve on the Tax Matters Partner, within seven days after a settlement agreement is executed by both a partner and the Service, a statement which sets forth the identity of the parties to the settlement; the date of the settlement agreement; the years to which the settlement agreement relates; and the terms of the settlement as to each partnership item and the allocation of such items among the partners. Within seven days of receiving the statement, the TMP shall serve a copy of the statement on all parties to the action. The requirement of Rule 248(c)(2) does not apply in the case of a consistent agreement. The procedures for complying with Rule 248(c)(2) differ according to whether the case is in the jurisdiction of Appeals or the Field attorney.

2. **Field Counsel Jurisdiction**. Any agreements received at Service Centers, Examination or Appeals offices will be sent to the Field attorney before the agreements are executed by the Service. Acceptance of the settlement agreement or consistent agreement does not occur until the agreement is executed by the Service. Field attorneys should make that position clear in any contact with partners, the TMP, or any representative of said partners. Field Counsel does not have the authority to sign the settlement agreements on behalf of the Commissioner as there is no delegation order extending that authority. The supervisory Appeals officers must execute such agreements.



1. In an effort to comply with T.C. Rule 248(c)(2) and administratively keep track of dates of settlement agreements, the Field attorney should batch the settlement agreements so that every 30 days a package will be submitted to Appeals for signature. By batching, the Service will be able to control dates the agreements are executed. Therefore only one letter will be sent to the TMP for each 30-day period and that letter will list investors who have signed agreements.

2. The Field attorney is to prepare a package which will be submitted to Appeals. Appeals will execute the agreements and serve the tax matters partner. However, Field Counsel is responsible for providing everything in the package that is necessary for serving the TMP. The package should include: (1) a letter and envelope addressed to the TMP; (2) a statement listing the investors who have signed the agreements (copies of the actual agreement form are not to be sent to the TMP); (3) a copy of a schedule which shows the adjustments agreed to; and (4) a copy of T.C. Rule 248.

3. Authority to sign settlement agreements has been delegated to the supervisory Appeals officers of each Appeals office. The Appeals office will execute the settlement agreements on behalf of the Service and mail the letter and statement to the TMP, by certified mail, on the day the agreements are signed. The Appeals office will then process the agreements, forwarding them to the Service Center for assessment.


3. **Appeals Office Jurisdiction**. If a docketed case is in Appeals’ jurisdiction, Appeals will prepare the package to be submitted to the TMP, and will serve the TMP once the agreements are executed. Therefore, any agreements received by the Service Centers, Examination, and Field Counsel are to be forwarded to Appeals. Similarly, the agreements will be processed and forwarded to the Service Center for assessment. It is important that the field attorney advise the Appeals office of any changes in the status of the TMP or address changes for the TMP that Field Counsel may receive. It is also important to keep in mind that the Field attorney is ultimately responsible to the Tax Court for compliance with the court’s rules while a case is docketed, whether or not Field Counsel or Appeals has settlement authority. Therefore, Field Counsel should obtain and keep copies of any packages served on the TMP by Appeals.



1. T.C. Rule 250 — Substitution or Determination of TMP. Once a petition has been filed, only the court may remove or appoint a TMP under this rule. The court will also determine who the TMP is when this issue is in dispute or unclear pursuant to a motion by either petitioners or respondent. Rule 250 motions must be prereviewed by Associate Chief Counsel (P&A), . Both legal and administrative files should be submitted with the proposed motion. See Exhibit 35.11.1–194, TEFRA Partnership: Motion to Appoint a Tax Matters Partner.


**35.8.6.1.4** **(08-11-2004)**

#### Closing Settled TEFRA Cases

1. Unlike settled deficiency cases which normally contain waivers of restrictions on assessment, cases settled under T.C. Rule 248 do not contain a waiver paragraph permitting immediate assessment of the deficiency. Nevertheless, all settled TEFRA cases should be closed in the same seven day period in which settled statutory notice cases are closed.


**35.8.6.1.5** **(07-25-2012)**

#### Decisions for TEFRA Penalty Only Cases

1. If the TEFRA entity to which the penalties or other affected items are attributable is not referenced in the affected item decision, confusion may arise as to whether non–TEFRA notices of deficiency may subsequently be issued. Thus, decision documents filed in TEFRA affected item cases should specifically note that the penalties and other affected items are attributable to a specific TEFRA partnership so that the application of section 6230(a)(2)(C) is clear. See Exhibit 35.11.1–195, TEFRA Partnership: Penalty Only Affected Item — Decision Document.


**35.8.6.2** **(07-25-2012)**

### Settlement Documents in Cases Having Other Procedural or Judicial Aspects

1. See general principles at CCDM 31.1.4.2.4, Coordination of Related Cases or Matters in Litigation.


**35.8.6.2.1** **(07-25-2012)**

#### Service Offer in Compromise Cases

1. Section 7122 provides that the Secretary may compromise any civil or criminal case arising under the internal revenue laws prior to reference to the Department of Justice (DOJ) for prosecution or defense; and the Attorney General or his delegate may compromise any such case after reference to the DOJ for prosecution or defense. Compromises by the Service are based primarily on the inability of a taxpayer to pay the deficiency, penalty, and interest determined to be due. See CCDM 33.3.2, Offers in Compromise.

2. If a settlement is reached in a docketed Tax Court case but it is determined that a petitioner’s offer in compromise should be considered before the settlement is finalized and a stipulation is filed with the Tax Court, the procedures set forth below should be followed by Field Counsel. To the extent practicable, Field Counsel should also act in accordance with the general guidelines set forth for offers in compromise. See generally IRM 5.8, Offer In Compromise.

3. If an offer in compromise is submitted by a petitioner while the petitioner’s case is pending in the Tax Court, a stipulation of the full amount of the deficiencies and penalties (those determined in the statutory notice or those redetermined on the merits by agreement of the parties) should be obtained from the petitioner. The reason for requiring the stipulation of the full amount, as determined or as redetermined in such cases, is to protect the Service’s ability to collect additional amounts pursuant to a collateral agreement in the event the financial status of the petitioner should change. Also, the Service could seek collection of the full liability if the petitioner defaults on the payments.

4. Unless the petitioner agrees to the immediate filing of the stipulation referred to in paragraph (3), it should be held in escrow in the possession of Field Counsel, and not in the possession of Appeals or the Area Director, pending the disposition of the offer in compromise. The stipulation will be executed by or on behalf of the petitioner, but will not be executed on behalf of Counsel until the offer in compromise is determined to be acceptable. If the offer in compromise is rejected, the stipulation should be returned to the petitioner or destroyed unless the petitioner submits an amended offer in compromise. If the offer in compromise is determined to be acceptable, the stipulation should be executed on behalf of Counsel and then filed with the Tax Court.

5. The letter accepting the offer in compromise should not be sent to the petitioner until the amounts specified in the stipulation referred to in paragraph (3) have been assessed.


**35.8.6.2.2** **(07-25-2012)**

#### Attorney General’s Offer in Compromise Refund Suits

1. Cases settled on the basis of an offer in compromise accepted by the Attorney General are situations in which there are pending cases in the district courts and Court of Federal Claims and also in the Tax Court. While these usually are related Tax Court and refund suit cases, they may also involve Tax Court and collection suit cases. The coordination instructions must be followed before the Tax Court settlement can be finalized, both in instances in which the offer is finally passed upon by the Attorney General and in those cases in which the Tax Court case is disposed of without a simultaneous disposition of the district court or Court of Federal Claims case. Usually, in the settlement by the Attorney General, any deficiency in tax or penalty to be collected in the Tax Court case is offset in the compromise of the refund case; therefore, the stipulation would state that there has been an acceptance of an offer in compromise by the Attorney General, and that by reason thereof there is now no deficiency in tax or penalty due in the Tax Court case. If a deficiency in tax or penalties is to be collected in the Tax Court case, the regular form of stipulation is to be used. See Exhibit 35.11.1–196, Compromise by the Attorney General.


**35.8.6.2.3** **(07-25-2012)**

#### Cases Having Concurrent Jurisdiction with Another Case

1. If a case is pending in the Tax Court and also in another court having concurrent jurisdiction over the parties and subject matter, it must be handled based upon the attendant facts and circumstances. If the Tax Court case is disposed of first, no problem arises. If the other court determines the tax and penalty liabilities prior to the decision of the Tax Court, the Tax Court case must nevertheless be closed by stipulation or motion. In such instances, the type of stipulation used is similar to those in cases where the related district court case was compromised by the Attorney General. Reference is made, however, to the other court having concurrent jurisdiction and its final determination of the tax and penalty liabilities (rather than to the compromise of such tax and penalty liabilities by the Attorney General). See Exhibit 35.11.1–197, Adjudication by Another Court Having Concurrent Jurisdiction With Tax Court: Another Court Disposed of All Issues Pending in Tax Court, and Exhibit 35.11.1–198, Adjudication by Another Court Having Concurrent Jurisdiction With Tax Court: All Issues Before the Tax Court Not Disposed of by Another Court.


**35.8.6.3** **(08-11-2004)**

### Rule 155 Decisions

1. When the court withholds entry of its decision to permit the parties to compute the tax pursuant to the opinion, the requirements of Rule 155 should be followed.


**35.8.6.3.1** **(08-11-2004)**

#### Computations

1. In most cases, Field Counsel will prepare a computation and forward it to the petitioner for approval. The objective is to file an agreed computation with the court. If the petitioner initially files a computation, the Field attorney must thoroughly review it, and, if necessary, file an objection thereto. This objection must be accompanied by an alternative computation. These must be filed on or before the date specified in the notice issued by the Tax Court. Failure to object and file an alternative computation will result in the court’s entry of decision in accordance with the petitioner’s computation.


**35.8.6.3.1.1** **(08-11-2004)**

##### Time Limitations

1. Field Counsel must make every effort to secure the entry of a decision under Rule 155 at the earliest date possible after the opinion is promulgated. A request for assistance in preparing the computation should be forwarded to Appeals immediately upon receipt of the opinion.

2. If the Field attorney decides to recommend appeal in a Rule 155 case, the appeal recommendation should be prepared during the time Appeals is preparing the computation. The appeal recommendation should be transmitted to the Technical Services Support Branch as soon as practicable. Where feasible, the legal file should accompany the appeal recommendation. Where Field Counsel forwards an appeal recommendation to the Associate Chief Counsel (P&A), the Rule 155 computation is to be direct filed with the Tax Court by the Field attorney. Copies of the computation should simultaneously be forwarded to Associate Chief Counsel (P&A). The transmittal should clearly indicate that the Rule 155 computation was directly filed with the Tax Court.

3. All Rule 155 computations and proposed decisions are directly filed with the Tax Court whether agreed or unagreed. Unless there are substantial and bonafide reasons for delay, the Rule 155 computation should be filed within 60 days of the opinion. If the computation cannot be filed within that period or within the time set by the court, the reasons should be specified in a letter to the judge. This time limitation is a directive for the occasional overdue computation and should not be considered the general due date for Rule 155 computations.

4. Field Counsel should establish controls for the timely filing of Rule 155 computations. Agreements should be negotiated with the Area Manager (Appeals) and other affected Area Managers concerning the procedures and time limitations necessary to assure the prompt preparation and early completion of Rule 155 computations, including the acquisition of any required transcripts of account and other necessary documents or information. Field Counsel should also either review or postreview all reasons for delay in the filing of computations considered overdue.


**35.8.6.3.1.2** **(08-11-2004)**

##### Computation by Appeals

1. When an opinion requires a Rule 155 computation, the request for the computation should be made immediately to Appeals. To avoid unnecessary delays, the Field attorney should anticipate which documents Appeals will need to complete the computation. The attorney should either retain copies or substitute photocopies for original documents from the administrative file that were introduced into evidence at the trial.

2. The attorney should collaborate with Appeals to facilitate completion of a correct computation at the earliest possible date that reflects respondent’s viewpoint of the issues before the court. Ordinarily, the Field attorney will not forward the legal file to Appeals. The attorney must determine the specific adjustments to the statutory notice that are in issue before the court requiring adjustment for an accurate computation. Accordingly, the request for a Rule 155 computation should advise Appeals regarding the following:



   - Any concessions and admissions made in the stipulation of fact, at the trial, in the brief, or otherwise

   - Any affirmative issues raised in the pleadings and whether such issues were settled, conceded or decided by the court

   - The interpretation to be followed in the computation, if the opinion requires interpretation because of ambiguity or is susceptible to more than one interpretation

   - In estate tax cases, whether there are additional allowable deductions for administrative expenses incurred by petitioner at or after trial which may be claimed in the Rule 155 computation

   - In cases where there may be a delay, recomputation of the tax liability should not be deferred until the ADP transcript of account is received


3. The auditor will address statutory adjustments involving medical expense, contributions, etc., in accordance with the adjustments to income required by the court’s opinion. Issues not raised by the pleadings will be handled by the Appeals auditor in accordance with the statutory notice.


**35.8.6.3.1.3** **(07-25-2012)**

##### Face Sheet, Computation Statement, and Proposed Decision

1. The Rule 155 computation is composed of three documents: the computation face sheet, the computation statement, and the proposed decision. The attorney prepares the computation face sheet, and Appeals prepares the computation statement and proposed decision. The attorney should ensure Appeals is aware that the Tax Court requires a separate computation statement for each docket number.

2. The computation face sheet is the legal document entitled Respondent’s Computation for Entry of Decision. This transmits the computation statement to the court. In agreed cases it consists of two pages. The first page bears the caption of the case and the signature block for the Chief Counsel. The second page contains a statement to the effect that the petitioner is in agreement with the respondent’s computation and the signature block for the petitioner or petitioner’s counsel. In unagreed cases only the first page, executed on behalf of the Chief Counsel, is filed with the court. In both agreed and unagreed cases, the first page of the face sheet should provide that a separate proposed decision is being lodged concurrently with the computation. See Exhibit 35.11.1–199, Rule 155 Computation: Computation Face Sheet.

3. The following material uses the term deficiency. Worker classification employment tax cases under section 7436 do not involve a deficiency (as defined in section 6211). The principles set forth below, however, apply to section 7436 cases as if the section 7436 notice of determination were a notice of deficiency. In addition, Rule 155 computations and decisions in certain post-assessment proceedings such as interest abatement, spousal relief, and collection due process cases do not determine "deficiencies." Often, such cases determine "liabilities" or determine periods of interest abatement or other forms of relief. The computation statement is divided into three parts.



1. **The first part of the computation statement** contains the caption of the document, the name and address of the petitioner, the case docket number, and the summary of so much of the computation and statement of account (without supporting details) as is necessary for the court to consider to enter a proper decision. In many respects this part of the statement resembles a settlement stipulation. In overpayment cases, for example, the computation of the overpayment and statutory facts supporting it must be shown in the same manner as in settlement stipulations. Where the court’s opinion calls for a Rule 155 decision, and the deficiency is the same as that determined in the statutory notice, and there are no adjustments in the computation of the tax liability or in the amounts paid by the petitioner, a short form computation statement may be used provided a complete and accurate copy of the statutory notice is in the court’s files. The short form may be used only where there are no adjustments to be made. The court’s opinion should have stated that the decision will be entered for the respondent. The short form may not be used in overpayment cases or when the decision is to be entered for the petitioner.

2. **The second part of the computation statement** contains the complete recomputation of the tax liability. This part consists of the basic computation upon which the summary in the first part is based, as well as the details necessary for the administrative closing of the case under the court’s decision. In many cases the computation for the court’s decision is different from the computation necessary for administrative use. The deficiency determined by the court may or may not be the same as the amount to be assessed by the Service pursuant to the decision, or the overpayment amount determined by the court may or may not be the same as the overassessment on the Service’s records. Furthermore, the second part of the computation statement may, in appropriate cases, contain an interest computation that is not subject to the Tax Court’s jurisdiction.

3. **The third part of the computation statement** — necessary for all overpayment cases — is the statement of account. This lists the dates and amounts of all assessments and payments of the taxes and penalties involved. The statement of account also contains: (1) any reconciliation necessary between the deficiency to be determined by the court and the assessment to be made by the Service, or any difference between the overpayment and the overassessment; and (2) the facts addressing any prior unpaid assessments, interim assessments, underpayment of claimed tax withheld or estimated tax payments, etc., which are special circumstances necessary to be considered in drafting the first part and in obtaining a correct decision.

4. Sample computation statements in tabular and narrative forms covering various tax liabilities and taxpayer account situations are set forth in Exhibits 35.11.1–201 through 35.11.1–208.


**35.8.6.3.1.4** **(08-11-2004)**

##### Review of Computation

1. The Field attorney should review the completed computation to confirm that it accurately reflects the court’s opinion and forms a sufficient basis for entry of a correct decision. In reviewing the computation, the attorney should ensure that:



   - It starts with the net income shown in the statutory notice and shows adjustments based upon the court’s opinion

   - Tax and penalty are separately stated

   - No interest is shown in the first part of the computation statement except that which is to be determined by the court in transferee cases

   - The statement of account, based upon the transcript of account supports the overpayment

   - Facts establishing whether the overpayment is barred or not barred are shown

   - The unpaid part of any assessed tax or penalty and the unassessed part of any paid tax or penalty are clearly shown

   - Deficiencies are determined without regard to jeopardy assessments, except where paid, and then only when such payments, together with other payments of prior assessments, exceed the tax liability

   - Each assessment of tax and penalty is shown separately, and each payment of tax and penalty is separately shown, together with the date of each payment

   - All years as to which the court has jurisdiction even though the opinion may not affect one or more years are included

   - A separate computation is made for each docket number


**35.8.6.3.1.5** **(07-25-2012)**

##### Decision Document

1. A separate proposed decision document should be prepared in all Rule 155 cases with the endorsement or stipulation paragraph placed on a separate page. In agreed cases the endorsement/stipulation page will be executed by or on behalf of both parties. In unagreed cases only the first page of the proposed decision will be lodged with the court. The terminology and format as well as the procedures for preparing, executing, and lodging proposed decisions in settled cases are equally applicable in Rule 155 cases. A sample proposed decision document for use in submitting a Rule 155 computation is set forth in Exhibit 35.11.1–200, Rule 155 Computation: Proposed Decision.


**35.8.6.3.1.6** **(08-11-2004)**

##### Small Tax Cases

1. Under section 7463, a decision of the Tax Court in a small tax case is not appealable. If a Rule 155 computation is required in an "S" case, the phrases "without prejudice to the right of appeal" and "without prejudice to the right of either party to contest the correctness of the decision entered herein" should be deleted from the second pages of the computation face sheet and decision document, respectively.


**35.8.6.3.1.7** **(08-11-2004)**

##### Claim for Increased Deficiency

1. Unlike settlement stipulations, a claim for an increased deficiency in tax or penalty over the amount determined in the statutory notice cannot be made for the first time in computations or decision documents filed under Rule 155. If the claim for increased deficiency has not been previously made in the answer or amended answer, an amendment to the answer making that request, together with a motion for leave to file the amendment to answer, must be filed simultaneously with the computation. Whenever possible, the petitioner’s agreement to the motion for leave should be obtained. A copy of the amendment to answer and the original of the motion for leave to file should be forwarded to the petitioner with the computation for endorsement. Difficulties have been encountered in obtaining increased deficiencies in Rule 155 computations. It is preferable and in some cases necessary for the Field attorney, prior to the closing of the trial record, to obtain permission to file an amendment to the answer asking for an increased deficiency. In lieu of an amendment to answer, the parties may file a supplemental stipulation of facts agreeing that an increased deficiency is due as a result of the court’s opinion. A telephone conference should be scheduled with the presiding judge to inform the court that an increased deficiency is being claimed as a result of the court’s opinion and to determine whether a supplemental stipulation will be agreeable in lieu of an amendment to answer.


**35.8.6.3.2** **(08-11-2004)**

#### Responsibility of Attorney and Reviewer

1. The Field attorney and reviewer have the same responsibility in submitting to the court a computation statement and proposed decision upon which a legally adequate decision can be entered as they have in submitting settlement stipulations. It is incumbent upon the attorney to assist Appeals in preparing the first part of the computation statement. The court bases its decision on the first part of the statement, which is similar in many respects to a settlement stipulation. The court will hold the Field attorney ultimately responsible for the correctness of a computation submitted on behalf of the respondent. The computation statement must support the decision requested by the respondent. The Field attorney and reviewer must review the Rule 155 documents and determine whether they are accurate and complete before forwarding them to the petitioner for approval.


**35.8.6.3.2.1** **(08-11-2004)**

##### Forwarding Rule 155 Documents to Petitioner for Approval

1. The original and two copies of the face sheet (not executed on behalf of the Chief Counsel), a copy of the computation, and the original and two copies of the proposed decision, if prepared, should be sent to the petitioner, or petitioner’s counsel, for approval, accompanied by a transmittal letter.

2. The transmittal letter should contain a statement similar to the following:



"The computations are based on Internal Revenue Service records as of \[date of transcript of account\] for the taxable year(s) involved. If there have been any transactions since that date, either additional payments made or credits or refunds received, which affect these taxable years, please call them to our attention so that correct computations may be filed with the court. Once the Tax Court decision becomes final it may not be vacated to correct any error as to payments made by the petitioner."

3. The attorney should set a date in the transmittal letter on or before which the petitioner should inform Counsel either:



   - That the computation is approved, returning the original and one copy each of the face sheet and proposed decision properly executed

   - That the computation is not approved, with the reasons for not approving it. The petitioner should be advised that upon failure to approve, or if agreement is not reached on a revised computation, respondent’s computation will be filed with the court shortly after the date stated in the transmittal letter


4. The date set for the return of the face sheet and proposed decision should be fixed in light of the complexity of the computation. The Field attorney should bear in mind that the petitioner’s counsel is quite familiar with the opinion, although perhaps not with the respondent’s interpretation of that opinion. The date for returning the computation should be fixed so that the computation can be timely filed with the Tax Court.


**35.8.6.3.2.2** **(08-11-2004)**

##### Failure of Petitioner to Approve

1. If the petitioner fails to agree with respondent’s computation within the period set, then the face sheet, the computation statement and the proposed decision may be filed directly with the Tax Court provided the Field attorney and reviewer are convinced that respondent’s computation correctly reflects the court’s opinion.

2. If there is a substantial question as to the interpretation of the court’s opinion and assistance is needed to prepare the computation, a proposed Rule 155 computation and decision should be forwarded to the Associate Chief Counsel (P&A), with a memorandum that includes:



   - A list of the adjustments concerning which there is a question of interpretation

   - Petitioner’s interpretation of the adjustments

   - Field Counsel’s interpretation of the adjustments

   - The reasons why Field Counsel recommends the interpretation reflected in respondent’s computation


3. The time period given to petitioner to either approve or disapprove respondent’s computation should be reasonable, but not indefinite. Most judges will not permit undue delay in the filing of computations. In any event, the computation, whether or not approved by or on behalf of the petitioner, must be filed on or before the date requested by the court or set by court order.

4. If Field Counsel files an unagreed computation directly with the Tax Court, copies of the computation, proposed decision, and legal file should not be sent to the Associate Chief Counsel (P&A) unless the court sets a hearing on the contested computation. Legal files and Field Counsel’s recommendation concerning appeal should always be forwarded to the Associate Chief Counsel (P&A), when the court’s opinion has decided an issue adverse to the respondent, regardless of whether the computation is agreed or unagreed.


**35.8.6.3.3** **(07-25-2012)**

#### Contested Rule 155 Computations

1. If the petitioner initially files a computation, an objection and an alternative computation should be filed by the date specified in the court’s notice of filing. If an unagreed computation is filed first, the petitioner must file an objection and alternative computation by the date specified in the court’s notice. Generally, any argument on contested computations is handled by a P&A attorney except when defense of the computation warrants argument by the trial attorney. Whether a trial attorney will argue the computation will depend to a large extent upon the location of the respective Associate Area Counsel office as well as the importance and complexity of the issues to be decided at the hearing. Associate Area Counsel, after consultation with the Associate Chief Counsel (P&A), will determine whether the trial attorney will appear at the hearing.

2. Arguments under Rule 155 are confined strictly to the question of whether the computation conforms with the opinion. It does not afford an opportunity to reargue the issues and matters already covered by the opinion, or to argue new issues. In all contested computations, the trial attorney should prepare a detailed memorandum covering all phases of the disputed items for the use by the P&A attorney.

3. In an estate tax case, petitioner may be entitled to deduct expenses incurred at or after the trial. The amount of the deduction generally is fixed by agreement. If the parties are unable to agree, the case may be reopened for further trial on this issue pursuant to T.C. Rule 156.

4. If the petitioner agrees to respondent’s computation and proposed decision, but an unagreed computation has already been filed, the agreed computation and proposed decision may be filed directly with the court. Prior to any hearing, Field Counsel may confer with the petitioner or petitioner’s counsel to seek an agreed computation. When necessary, a revised computation, or an amendment to the prior computation, should be promptly prepared and filed. In the event an agreement is reached after an unagreed computation has been sent to the court, a telephone conference should be promptly arranged to inform the judge that an agreement has been reached and that an agreed computation is being filed with the court, so that the court does not prematurely process the unagreed computation.


**35.8.6.4** **(07-25-2012)**

### Stipulated Decision Documents in Collection Due Process (CDP) Cases

1. This subsection discusses the sample decision documents that may be used in common situations presented in CDP cases. Individual cases will vary, of course, and the sample stipulated decision documents will need to be adapted to fit the particular facts of each case. Please contact the Associate Chief Counsel (P&A), branch 3 or 4, if you have questions.

2. CDP cases concern two kinds of issues: nonliability issues, which are reviewed by the courts for abuse of discretion, and liability issues, which are reviewed de novo. "Liability" refers to the proper amount of tax imposed by the Code. Nonliability issues include those involving the Service’s compliance with applicable law and administrative procedures, the conduct of the administrative hearing, collection alternatives, and the appeals officer’s determination to proceed with collection.

3. When decision documents contain language indicating that the taxpayer waives restrictions in section 6330(e) prohibiting collection until the decision of the Tax Court becomes final, the suspension of the collection statute of limitations in section 6330(e) is also no longer in effect as of the date of the decision is entered. See CCDM 35.9.3.6, Closing Collection Due Process Cases, which explains the importance of returning a CDP case to Collection as soon as possible once the collection statute of limitations resumes running and of clearly communicating the actions required by the decision document, such as ensuring that invalid assessments are abated.


**35.8.6.4.1** **(07-25-2012)**

#### Nonliability Issues

1. When, with respect to a nonliability issue, the appeals officer abused his discretion in conducting the hearing or in making the determination, the error was harmless, the notice of determination should be defended. If reconsideration of the case by Appeals is required because the error is not harmless, the attorney should generally file a Motion for Remand to Appeals to allow the appeals officer to correct the error and issue a supplement to the notice of determination. A sample motion to remand is in Exhibit 35.11.1-213, Motion to Remand in a Collection Due Process Case. On the other hand, some nonliability issues involving the application of law to uncontested facts may not require reconsideration by Appeals even if the error was not harmless. These issues may include whether the unpaid tax was discharged in bankruptcy, whether the statute of limitations has expired, or whether a notice of deficiency was properly issued. If an issue does not require further fact finding or a determination by Appeals, and the case is to be conceded and the tax abated, the decision document should state that the notice of determination is not sustained as in the sample decision at Exhibit 35.11.1-214, Notice of Determination Addressing Only Tax Liability or Collection Issues Not Sustained. When the assessment is conceded as invalid but the assessment period is still open, the sample paragraph stating that respondent’s right to reassess the tax liability is preserved should be included.

2. A motion to dismiss on ground of mootness, rather than a stipulated decision document, should be filed if the tax liability has been paid in full and no issues have been raised that would invoke the Tax Court’s overpayment jurisdiction under sections 6404(h) or 6015(e). See CCDM 35.3.23.4, Motion to Dismiss on the Ground of Mootness. Similarly, a motion to dismiss on the ground of mootness should be filed if the assessment has been abated. The attorney should also ensure that the lien has been, or will be, released or the proposed levy will be abandoned before filing the motion. If the Service has agreed to abate the assessment but the abatement has not been completed, a motion to dismiss on ground of mootness should not be filed. Instead, a stipulated decision document setting forth the basis for the abatement should be filed. A sample decision is contained in Exhibit 35.11.1-214, Notice of Determination Addressing Only Tax Liability or Collection Issues Not Sustained.. If some, but not all, tax periods at issue have been paid or abated, a stipulated decision can be filed stating that the issues associated with the pertinent tax periods are moot, and then separately addressing the unpaid periods.

3. If the taxpayer is conceding the case in full and the underlying tax liability is not at issue, then a stipulated decision document stating that the determinations are sustained in full should be filed. A sample decision is contained in Exhibit 35.11.1-215, Notice of Determination Addressing Only Tax Liability or Collection Issues Sustained in Full. If the taxpayer is conceding the case in full but a collection alternative has been agreed to outside CDP, then the collection alternative should be referred to below the judge’s signature as in the sample decision in Exhibit 35.11.1-216, Notice of Determination Addressing Only Tax Liability or Collection Issues Sustained in Full if Collection Alternative Agreed to Outside CDP Case. An example would be when Appeals properly rejected an offer-in-compromise but after the notice of determination was issued the taxpayer experienced a substantial adverse change in circumstances making the offer-in-compromise acceptable. While the appeal to Tax Court is pending, the taxpayer submits financial documentation and this is forwarded with taxpayer’s offer-in-compromise to the Collection function, which accepts the offer. The acceptance of the offer should not be referred to above the line because the offer was accepted outside of the CDP hearing and the court has no jurisdiction in connection with the offer. Note that if Appeals had erred in concluding that the financial documentation was not submitted, a motion for remand should generally be filed rather than a document not sustaining the determination.

4. An attorney is not authorized to accept offers-in-compromise or installment agreements. Accordingly, the stipulated decision document should not stipulate that a case has been resolved by an offer-in-compromise or installment agreement until the collection alternative has been already accepted by the Collection function or other authorized Service function. If the collection alternative has not yet been accepted, the stipulated decision document can provide that the petitioner has been given a specific period of time to submit a collection alternative to the Service.


**35.8.6.4.2** **(07-25-2012)**

#### Liability Issues

1. When the taxpayer challenges the underlying tax liability (i.e., the proper amount of tax imposed by the Code), the attorney must first determine whether the challenge is precluded under section 6330(c)(2)(B). If the challenge to the underlying tax liability is not precluded, then the stipulated decision document must set forth the amount of the underlying tax liability, which is referred to in the decision document as the amount of tax imposed by the Internal Revenue Code. See Exhibit 35.11.1-217 Notice of Determination – Underlying Tax Properly at Issue and No Abuse of Discretion. The amounts of the liability and additions to tax should be calculated as of the date the decision is entered. Stipulations as to interest should generally be below the line and state that interest accrues in accordance with law. If the amount of interest that accrued on the tax liability was specifically at issue, the amount of interest agreed to can be put above the line. Any stipulation as to overpayments should be placed below the line, because the Tax Court does not have jurisdiction under the CDP provisions to determine an overpayment or order its refund (unless the overpayment arises under section 6404(h) or 6015(e)). If the underlying tax liability is not properly at issue but adjustments are agreed to, the amount of the underlying tax liability should be set forth below the judge’s signature. See Exhibit 35.11.1-218, Notice of Determination – Underlying Tax Not at Issue, but Adjusted and No Abuse of Discretion.


**35.8.6.4.3** **(07-25-2012)**

#### Sections 6404 and 6015 Issues

1. CDP cases may involve claims for interest abatement under section 6404 or relief from joint and several liability under section 6015. For sample decisions for cases in which the notice of determination addresses both CDP issues and interest abatement, see Exhibit 35.11.1-219, Notice of Determination Addressing CDP Issues and Interest Abatement of No Abuse of Discretion in Denial of Abatement of Interest. For sample decisions in which the notice of determination addresses both CDP issues and relief from joint and several liability, also see Exhibit 35.11.1-220, Notice of Determination Addressing CDP Issues and Innocent Spouse Relief.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-008-006#addtoany "Show all")

A2A