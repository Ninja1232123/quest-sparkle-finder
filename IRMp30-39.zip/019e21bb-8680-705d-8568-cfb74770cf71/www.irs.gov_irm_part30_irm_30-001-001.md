---
url: "https://www.irs.gov/irm/part30/irm_30-001-001"
title: "30.1.1 Mission Statement, and the Strategic and Program Plan | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part30/irm_30-001-001#main-content)

- 30.1.1 [Mission Statement, and the Strategic and Program Plan](https://www.irs.gov/irm/part30/irm_30-001-001#idm139987268370000)
  - 30.1.1.1 [Office of Chief Counsel Mission](https://www.irs.gov/irm/part30/irm_30-001-001#idm139987268325760)
  - 30.1.1.2 [The Chief Counsel Directives Manual](https://www.irs.gov/irm/part30/irm_30-001-001#idm139987268322352)

    - 30.1.1.2.1 [Relationship with IRS Policy](https://www.irs.gov/irm/part30/irm_30-001-001#idm139987268319616)
    - 30.1.1.2.2 [Maintenance of the CCDM](https://www.irs.gov/irm/part30/irm_30-001-001#idm139987268316048)
    - 30.1.1.2.3 [Historical Versions of the CCDM](https://www.irs.gov/irm/part30/irm_30-001-001#idm139987268311216)

  - 30.1.1.3 [StrategicPlanning](https://www.irs.gov/irm/part30/irm_30-001-001#idm139987268306880)

    - 30.1.1.3.1 [Objectives of Strategic Planning](https://www.irs.gov/irm/part30/irm_30-001-001#idm139987268329920)
    - 30.1.1.3.2 [Role of the Senior Executives](https://www.irs.gov/irm/part30/irm_30-001-001#idm139987268300400)
    - 30.1.1.3.3 [Role of Finance and Management](https://www.irs.gov/irm/part30/irm_30-001-001#idm139987268297312)
    - 30.1.1.3.4 [Associate Chief Counsel and Division Counsel Performance Measures and Standards](https://www.irs.gov/irm/part30/irm_30-001-001#idm139987268292752)

      - 30.1.1.3.4.1 [Delegation of Associate Chief Counsel or Division Counsel Goals](https://www.irs.gov/irm/part30/irm_30-001-001#idm139987268289696)
      - 30.1.1.3.4.2 [Associate Chief Counsel and Division Counsel SES Assessments](https://www.irs.gov/irm/part30/irm_30-001-001#idm139987268287904)
      - 30.1.1.3.4.3 [Role of the Planning and Management Division](https://www.irs.gov/irm/part30/irm_30-001-001#idm139987268285936)

# Part 30. Administrative

# Chapter 1. Office of Chief Counsel Mission Statement

# Section 1. Mission Statement, and the Strategic and Program Plan

* * *

## 30.1.1 Mission Statement, and the Strategic and Program Plan

#### Manual Transmittal

May 28, 2014

#### Purpose

(1) This transmits revised CCDM 30.1.1, Office of Chief Counsel Mission Statement; Mission Statement, Strategic and Program Plan

#### Material Changes

(1) This section was revised to reflect updates to Counsel’s strategic planning process and recent changes to the role and structure of the Planning and Management Division (PMD). Affected subsections are: CCDM 30.1.1.3, CCDM 30.1.1.3.1, CCDM 30.1.1.3.2, CCDM 30.1.1.3.3, CCDM 30.1.1.3.4.

(2) Organizational titles for the Planning and Management Division were changed in CCDM 30.1.1.2.2, CCDM 30.1.1.2.3, CCDM 30.1.1.3.4.2 and CCDM 30.1.1.3.4.3 as a result of the reorganization of the office of the Associate Chief Counsel (Finance and Management), Planning and Finance Division.

(3) CCDM 30.1.1.3.4.2 and CCDM 30.1.1.3.4.3 were revised to reflect updates to the executive performance plans.

(4) CCDM 30.1.1.2.2 and CCDM 30.1.1.2.3 were revised to incorporate the most recent procedures for the management of the CCDM program issued in CCDM 30.2.1.

(5) Typographical errors were corrected throughout the section and hyperlinks were updated.

#### Effect on Other Documents

CCDM 30.1.1 dated November 27, 2006 is superseded.

#### Audience

Chief Counsel

#### Effective Date

(05-28-2014)

Michael T. Cochis

Director, Planning and Management Division

**30.1.1.1** **(08-11-2004)**

### Office of Chief Counsel Mission

1. The mission of the Office of the Chief Counsel is to serve America’s taxpayers fairly and with integrity by providing correct and impartial interpretation of the internal revenue laws and the highest quality legal advice and representation for the Internal Revenue Service.

2. This mission encompasses providing the correct legal interpretation of the internal revenue laws, representing the IRS in litigation, and providing all other legal support needed by the IRS to carry out its mission of serving America’s taxpayers. In carrying out these responsibilities, Counsel must interpret the law with complete impartiality so that the American public will have confidence that the tax law is being applied with integrity and fairness.


**30.1.1.2** **(08-11-2004)**

### The Chief Counsel Directives Manual

1. The Chief Counsel Directives Manual (CCDM), published as Parts 30 through 39 of the Internal Revenue Manual, is the authoritative statement of policy and guidance for the IRS Office of Chief Counsel on matters covered therein.

2. While some parts and sections of the CCDM may contain specific procedures or processes, it is neither designed nor intended to be a comprehensive checklist or "how to" guide for every action or process. Step-by-step guides or operating instructions may be developed outside of the CCDM, where appropriate. The principal intent of the CCDM is to clearly and concisely reflect Chief Counsel policy and guidance on critical functions for the effective operation of the Chief Counsel organization.


**30.1.1.2.1** **(08-11-2004)**

#### Relationship with IRS Policy

1. In some cases, the Office of Chief Counsel follows IRS policy and procedures, such as for travel. For all Personnel Policy, since the Office of Chief Counsel is part of the Legal Division of the Department of the Treasury, our policies, guidance, and procedures may differ from those of the IRS.

2. Where the Office of Chief Counsel, as a matter of policy, has elected to adopt an IRS policy, guidance, or procedure on a particular matter, then the pertinent section of the CCDM shall state that the Chief Counsel expressly adopts and incorporates that specific IRS policy, guidance, or procedure. For those sections, any change to IRS policy will automatically change Office of Chief Counsel policy.

3. Where an Office of Chief Counsel policy may be substantively the same as that for the IRS, but the Chief Counsel has elected not to expressly adopt and incorporate IRS policy, the Chief Counsel policy in the CCDM will be stated without reference to the parallel IRS policy. For those sections, any change to IRS policy will not affect Office of Chief Counsel policy on that particular matter, unless the Chief Counsel expressly decides to approve a change.


**30.1.1.2.2** **(05-28-2014)**

#### Maintenance of the CCDM

1. All Associate Chief Counsel and Division Counsel offices are responsible for ensuring that the CCDM reflects the current policies, guidance, and procedures of the Office of Chief Counsel. Designated Associate Chief Counsel or Division Counsel offices are responsible for monitoring the currency of their assigned CCDM parts and ensuring that they are updated in a timely fashion. Because provisions of the CCDM affect many different organizations, the Part Manager does not have exclusive control of all substantive elements of its assigned part. The role of the Part Manager is to identify the need for changes, coordinate the changes with the affected or interested organizations, and ensure the changes are finalized and forwarded to the Planning and Management Division for processing and publication.

2. The CCDM Parts will be managed by the following organizations:




| _Part_ | _Title_ | _Managed By_ |
| --- | --- | --- |
| 30 | Administrative | Associate Chief Counsel (F&M) |
| 31 | Guiding Principles | Associate Chief Counsel (P&A) |
| 32 | Published Guidance and Other Guidance to Taxpayers | Associate Chief Counsel (P&A) |
| 33 | Legal Advice | Associate Chief Counsel (P&A) |
| 34 | Litigation in District Court, Bankruptcy Court, Court of Federal Claims, and State Court | Associate Chief Counsel (P&A) |
| 35 | Tax Court Litigation | Associate Chief Counsel (P&A) |
| 36 | Appellate Litigation and Actions on Decision | Associate Chief Counsel (P&A) |
| 37 | Disclosure | Associate Chief Counsel (P&A) |
| 38 | Criminal Tax | Associate Chief Counsel (CT) |
| 39 | General Legal Services | Associate Chief Counsel (GLS) |

3. The Associate Chief Counsel (Finance and Management), through the Planning and Management Division, is responsible for the administrative oversight of the CCDM. This includes processing all changes provided by the issuing office for the CCDM, and ensuring that the current version of the CCDM is published in accordance with IRS policy. The Planning and Management Division will coordinate with the IRS Service-wide Policy Directives and Electronic Research (SPDER) and Media and Publications organizations and will issue procedures within the Office of Chief Counsel for publication of the CCDM. For detailed information, see CCDM 30.2.1, Office of Chief Counsel Directives System.


**30.1.1.2.3** **(05-28-2014)**

#### Historical Versions of the CCDM

1. The Planning and Management Division will submit historical records of all changes to the CCDM to the Federal Records Center per the current Records Control Schedule.

2. The historical CCDM content is available at the IRS Historical Research Library.

3. Electronic versions of the current CCDM are available through:



   - The IRM Numerical Index

   - The CCDM Online


**30.1.1.3** **(05-28-2014)**

### StrategicPlanning

1. The Office of Chief Counsel’s strategic planning process culminates with the issuance of its Major Strategies/Operational Priorities (MSOP) document which outlines the Office’s major objectives. The MSOP is the key means for the Office to communicate these objectives throughout the organization. Progress towards MSOP objectives is reported quarterly through the IRS Business Performance Review (BPR) process.

2. The MSOP sets the general direction for the Office's efforts while paralleling and supporting the Commissioner’s and Treasury’s strategic planning efforts.


**30.1.1.3.1** **(05-28-2014)**

#### Objectives of Strategic Planning

1. The Office of Chief Counsel’s MSOP, supported by specific measures, goals and objectives identified in the BPR and Executive Performance Agreements, represents what the Office is striving to achieve and how the Office will judge its success, both qualitatively and quantitatively. The Major Strategies through FY 2014 include:



   - • Enhance Legal Support to All IRS Units

   - Combat Fraud, Promoted Tax Schemes and Abusive Tax Avoidance Transactions

   - Manage the Litigation Program Effectively

   - Enhance Tax Administration/Compliance Through Published Guidance

   - Attract and Retain Highly Qualified Employees

   - Secure Business Operations


**30.1.1.3.2** **(05-28-2014)**

#### Role of the Senior Executives

1. The strategic planning process serves as a framework for senior management involvement and guidance. It also provides for greater integration between planning, budgeting, and performance accountability mechanisms.

2. In addition to providing their own input and discussion into the MSOP, senior executives work closely with their IRS and Treasury colleagues to incorporate their ideas concerning their future direction and priorities.

3. The Chief Counsel reviews accomplishment of the strategic priorities through the IRS Business Performance Review (BPR) process. The Chief Counsel shares the status of priority accomplishment with the IRS Commissioner during quarterly BPR meetings.


**30.1.1.3.3** **(05-28-2014)**

#### Role of Finance and Management

1. The Planning and Management Division in the Office of Associate Chief Counsel (F&M) initiates strategic planning for the Office of Chief Counsel by working with each Associate Chief Counsel or Division Counsel to develop the MSOP based on the Commissioner’s Plan and new priorities. The Planning and Management Division:



   - Provides staff support for the strategic executive meetings

   - Facilitates alignment of MSOP to IRS & Treasury’s Strategic Plans and Executive performance plans

   - Ensures that the MSOP is published each fiscal year and posted to the Office of Chief Counsel’s web page

   - Produces the BPR on a quarterly basis to measure and discuss success with business objectives


**30.1.1.3.4** **(05-28-2014)**

#### Associate Chief Counsel and Division Counsel Performance Measures and Standards

1. At the beginning of each fiscal year, each Associate Chief Counsel and Division Counsel develops an Executive Performance Agreement (EPA) that translates the broad MSOP objectives into specific objectives for that year. Specific performance measures are coordinated between the Associate Chief Counsel or Division Counsel and the Deputies Chief Counsel to ensure that they support both the goals of the MSOP and overall management goals of the Chief Counsel. The Associate Chief Counsel or Division Counsel Operational Plans also propose the standards by which performance of the goals will be measured.

2. The performance measures and standards are documented in a formal EPA that is signed by the Deputies Chief Counsel and the respective Associate Chief Counsel or Division Counsel. Each Associate Chief Counsel and Division Counsel is accountable for the accomplishment of the objectives in their performance plan and for the business results.


**30.1.1.3.4.1** **(08-11-2004)**

##### Delegation of Associate Chief Counsel or Division Counsel Goals

1. Each Associate Chief Counsel and Division Counsel is responsible for ensuring that their goals are incorporated into the performance plans of their subordinate SES and Grade 15 managers, positions, and organizations.


**30.1.1.3.4.2** **(05-28-2014)**

##### Associate Chief Counsel and Division Counsel SES Assessments

1. Assessments are written at the middle and end of the fiscal year by Associate Chief Counsel and Division Counsel to document their performance in accomplishing EPA objectives. The final appraisals, performed by the Deputies Chief Counsel, rely on the Associate Chief Counsel and Division Counsel SES assessments. These are supplemented by statistics gathered by the Planning and Management Division.


**30.1.1.3.4.3** **(05-28-2014)**

##### Role of the Planning and Management Division

1. The Planning and Management Division, under the direction of the Associate Chief Counsel (Finance and Management) assists the goal-writing process by drafting EPAs based on guidance from new directives and priorities established by the Chief Counsel. It distributes drafts, collates comments, and provides staff support at executive meetings until the objectives are finalized. The Planning and Management Division also helps construct quantifiable and measurable goals and collects and analyzes statistical data to assist in the self-assessment process.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part30/irm_30-001-001#addtoany "Show all")

A2A