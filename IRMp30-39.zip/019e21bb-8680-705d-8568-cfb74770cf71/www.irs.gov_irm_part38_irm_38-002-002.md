---
url: "https://www.irs.gov/irm/part38/irm_38-002-002"
title: "38.2.2 Grand Jury Procedures | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part38/irm_38-002-002#main-content)

- 38.2.2 [Grand Jury Procedures](https://www.irs.gov/irm/part38/irm_38-002-002#idm140388117921344)
  - 38.2.2.1 [Introduction to Grand Jury Procedures](https://www.irs.gov/irm/part38/irm_38-002-002#idm140388117750448)
  - 38.2.2.2 [Referrals for Grand Jury Investigation](https://www.irs.gov/irm/part38/irm_38-002-002#idm140388117928432)
    - 38.2.2.2.1 [Types of Grand Jury Referrals](https://www.irs.gov/irm/part38/irm_38-002-002#idm140388117243728)
    - 38.2.2.2.2 [Standards of Review](https://www.irs.gov/irm/part38/irm_38-002-002#idm140388131736160)
    - 38.2.2.2.3 [Review by the Associate Chief Counsel (Criminal Tax)](https://www.irs.gov/irm/part38/irm_38-002-002#idm140388117579696)
    - 38.2.2.2.4 [Use of Grand Jury Information](https://www.irs.gov/irm/part38/irm_38-002-002#idm140388129193152)
    - 38.2.2.2.5 [Conferences in Grand Jury Cases](https://www.irs.gov/irm/part38/irm_38-002-002#idm140388117298848)
  - 38.2.2.3 [Criminal Investigation/Service Initiated Requests for Grand Jury Investigation](https://www.irs.gov/irm/part38/irm_38-002-002#idm140388118297872)
    - 38.2.2.3.1 [Counsels Role](https://www.irs.gov/irm/part38/irm_38-002-002#idm140388132203856)
    - 38.2.2.3.2 [Content and Style of Grand Jury Request Memorandum](https://www.irs.gov/irm/part38/irm_38-002-002#idm140388117639728)
  - 38.2.2.4 [Government AttorneyInitiated Request for Grand Jury Assistance](https://www.irs.gov/irm/part38/irm_38-002-002#idm140388117685184)
    - 38.2.2.4.1 [Procedures](https://www.irs.gov/irm/part38/irm_38-002-002#idm140388118283808)
  - 38.2.2.5 [Grand Jury Expansion Requests](https://www.irs.gov/irm/part38/irm_38-002-002#idm140388117294160)
    - 38.2.2.5.1 [Combination Grand Jury Expansion Request and Evaluation](https://www.irs.gov/irm/part38/irm_38-002-002#idm140388119724112)
  - 38.2.2.6 [Processing Grand Jury Evaluation Cases](https://www.irs.gov/irm/part38/irm_38-002-002#idm140388117362400)
  - 38.2.2.7 [Pending Civil Matters in Grand Jury Cases](https://www.irs.gov/irm/part38/irm_38-002-002#idm140388117402496)
    - 38.2.2.7.1 [Administrative Summonses](https://www.irs.gov/irm/part38/irm_38-002-002#idm140388117410208)

# Part 38. Criminal Tax

# Chapter 2. Review of Criminal Tax Cases

# Section 2. Grand Jury Procedures

* * *

## 38.2.2 Grand Jury Procedures

#### Manual Transmittal

December 20, 2018

#### Purpose

(1) This transmits revised CCDM 38.2.2, Review of Criminal Tax Cases; Grand Jury Procedures.

#### Material Changes

(1) CCDM 38.2.2.3.1 has been edited to add a reference to Exhibit 38.3.1-11, Sample Grand Jury Request memorandum.

(2) CCDM 38.2.2.3.2 has been added to provide detailed guidance on the drafting of Chief Counsel’s Grand Jury Request memorandum. The highlighted sections of the memorandum include the: (1) identification of the criminal subject(s), (2) Counsel’s recommendation, (3) executive summary, (4) standard of review, (5) facts, (6) law and analysis, (7) explanation of why the referral is necessary and appropriate, (8) legal impediments or other detracting factors, and (9) conclusion.

#### Effect on Other Documents

CCDM 38.2.2, dated August 7, 2008, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(12-20-2018)

Edward F. Cronin

Division Counsel/Associate Chief Counsel

(Criminal Tax)

**38.2.2.1** **(10-03-2007)**

### Introduction to Grand Jury Procedures

1. This section establishes procedures related to criminal investigations conducted by a grand jury. A grand jury is a criminal investigative body wholly independent of the Service and Chief Counsel.

2. The transmission of an administrative criminal investigation to a grand jury eliminates the potential of any further Service and Chief Counsel control over the conduct of, and authority to conclusively determine the prosecutive potential arising out of that investigation. For example, IRC § 7602(d) provides that an administrative summons cannot be issued, nor can summons enforcement action be taken with respect to any person referred to the Department of Justice (DOJ) for prosecution.

3. Following transmission of an administrative criminal investigation to a grand jury, Service and Chief Counsel personnel may access and use grand jury matters for criminal purposes only to the extent:



1. Requested by an attorney for the Government to assist the attorney in the performance of his/her duty to enforce the federal criminal law

2. Permitted by court order

3. Such matters become public in the course of trial or other public judicial proceedings


4. Grand jury matters may not be accessed and used at any time by Service and Chief Counsel personnel for civil purposes unless:



1. Permitted by court order

2. Such matters become public in the course of trial or other public judicial proceedings. In this situation the information should be obtained exclusively from the public record and not from the grand jury records


5. Chief Counsel attorneys who receive disclosure of matters occurring before the grand jury that are subject to the secrecy provisions of Rule 6(e) shall be excluded from the involvement in non-grand jury matters concerning the same individuals, entities, and subject matter being investigated by the grand jury unless all of the information to which they had access as assistants to the attorney for the Government is the subject of a Rule 6(e) Order or a matter of public record. Chief Counsel attorneys who are currently involved in civil cases concerning the individuals, entities, or subject matter that become the subject of a grand jury investigation referral normally shall be excluded from involvement in a grand jury investigation; however, these attorneys are not automatically precluded from participation in decisions regarding the making of grand jury referrals unless material subject to Rule 6(e) restrictions is involved.

6. The attorney for the Government will usually request the assistance of Service and Chief Counsel personnel in writing prior to the time that such personnel access information subject to the secrecy requirements of Rule 6(e).



1. Such requests should, to the extent possible, name specific Service and Chief Counsel personnel and also authorize disclosure to additional Service and Chief Counsel personnel deemed necessary to provide the requested assistance to the attorney for the Government.

2. If it is deemed necessary to disclose matters occurring before the grand jury to a Service or Chief Counsel employee who is not specifically named in the request of the attorney for the Government, the attorney for the Government should be informed promptly in writing of the identity of the person(s) to whom this information was disclosed so that the provisions of Rule 6(e)(3)(B) may be complied with. To the extent possible, the attorney for the Government should approve disclosures before they occur.


7. Service and Chief Counsel personnel who assist an attorney for the Government do so as assistants to that attorney for the Government rather than as employees for the Service or Chief Counsel. Thus, all Service and Chief Counsel procedures that are inconsistent with the function of the grand jury must give way to the grand jury concepts. The functions and procedures of the grand jury, however, do not override the limitations on disclosure contained in IRC § 6103.


**38.2.2.2** **(08-11-2004)**

### Referrals for Grand Jury Investigation

1. Grand jury investigations consist of either specific taxpayer targets or projects or both. It is within the province of the Service to determine whether its commitment of personnel will be to an investigation conducted by a grand jury. The Service has concluded that such commitment will be to the administrative process unless, in the opinion of the approving Service officials, a grand jury investigation is necessary and appropriate in the circumstances. A grand jury is considered to be necessary and appropriate in the circumstances where it is apparent that the administrative process cannot develop the relevant facts within a reasonable period of time, or coordination of the tax investigation with an ongoing grand jury investigation would be more efficient, and the case has significant deterrent potential.

2. A referral for grand jury investigation is accomplished by the Special Agent in Charge (SAC) referring a recommendation for such to a DOJ component. The Criminal Tax attorney’s responsibility in the grand jury process is to review and evaluate the request and to provide a legal analysis to the SAC.



### Note:



See Tax Division Direction No. 86-59 to determine which DOJ component (i.e., Tax Division or US Attorney) should be sent the referral. In addition, questions concerning the proper interpretation of the Directive should be forwarded directly to the Tax Division.


**38.2.2.2.1** **(08-11-2004)**

#### Types of Grand Jury Referrals

1. A referral for grand jury investigation can emanate from:



1. A request by Criminal Investigation for the initiation of a grand jury investigation, also known as a Service initiated request for grand jury investigation

2. A request by an attorney for the Government for Service participation in a grand jury investigation


2. While DOJ may convert a referral for prosecution to an authorization to conduct a grand jury investigation, such cases, unless expressly referred to herein are not considered as "grand jury referrals" within the purview of these provisions.


**38.2.2.2.2** **(08-11-2004)**

#### Standards of Review

1. Regardless of which type of grand jury referral is involved, the review by Counsel is to determine:



1. Whether there are articulable facts supporting a reasonable belief that a crime has been committed

2. Whether referral for grand jury investigation would be necessary and appropriate in the circumstances

3. Whether there are legal impediments or other factors that substantially detract from or negate the prospect of ultimately developing admissible evidence necessary to establish guilt beyond a reasonable doubt and reasonable probability of conviction


**38.2.2.2.3** **(08-07-2008)**

#### Review by the Associate Chief Counsel (Criminal Tax)

1. Grand jury cases involving the following sensitive individuals and/or issues will be forwarded by the Criminal Tax attorney to the Associate Chief Counsel (CT) for review, evaluation, and preparation of the criminal evaluation memorandum:



01. Currently serving elected federal officials, (i.e., Members of Congress)

02. Current Article III judges, (i.e., United States District Court Judges)

03. Current high-level Executive Branch officials, (i.e., Cabinet level officials)

04. Currently serving elected statewide officials, (i.e., Governor, Attorney General)

05. Current members of the highest court of a state

06. Currently serving mayors of municipalities having a population in excess of 250,000

07. Cases involving perjury, subornation of perjury, or false declaration occurring during a Untied States Tax Court proceeding under 18 U.S.C. §§ 1621, 1622, and 1623

08. Cases where the proposed target of the grand jury investigation is an IRC § 501(c) or (d) organization

09. Publicly traded companies (defined as companies that have issued securities through an initial public offering and whose shares are traded on the open market)

10. Companies with annual gross revenues exceeding $10,000,000,000.00


2. While mandatory coordination with the Associate Chief Counsel (CT) is required in the above situations, communication consistent with Rule 6(e) is encouraged in other grand jury investigations involving local individuals who receive national and/or regional media coverage.


**38.2.2.2.4** **(08-11-2004)**

#### Use of Grand Jury Information

1. If information considered to be "matters occurring before the grand jury" under Rule 6(e) is involved, that information is provided to Service officials by an attorney for the Government for the purpose of determining whether the Service wishes to commit personnel to assist the attorney for the Government in the grand jury investigation.

2. All information considered to be "matters occurring before the grand jury" not the subject of a court order under Rule 6(e) making such information available to the Service and Counsel for use independent of the grand jury secrecy rule, shall be carefully controlled.

3. Service and Counsel personnel are not entitled to access or use information subject to the restrictions of Rule 6(e) for any purpose other than assisting an attorney for the Government in the grand jury investigation.

4. Counsel should restrict the number of persons having access to the grand jury information to the minimum number essential to conduct a proper evaluation.


**38.2.2.2.5** **(08-11-2004)**

#### Conferences in Grand Jury Cases

1. Conferences should not be offered to taxpayers who are the subject of a grand jury investigation recommendation, nor should these taxpayers be advised of the existence of the grand jury recommendation.


**38.2.2.3** **(08-11-2004)**

### Criminal Investigation/Service Initiated Requests for Grand Jury Investigation

1. When Criminal Investigation considers that a grand jury investigation is necessary and appropriate and believes that a grand jury investigation would develop further evidence establishing prosecutable Title 26 or Title 26-related violation(s), the investigating special agent prepares a report, fully exhibited, which comprehensively discusses to the extent possible:



1. Identification of the criminal case(s) which is considered probable, inclusive of all tax returns at issue, identification of all specific taxpayers involved, and all indicia of wrongdoing that reflects the contemplated offenses

2. The progress of the investigation to date, inclusive of all investigative steps already taken; all evidence already developed, identification of all witnesses interviewed and the testimony of such witnesses; and the status of administrative summonses issued but not complied with, including any summons enforcement proceedings involving the taxpayer, as well as a statement showing any civil action that is under way or contemplated on the subject for any year

3. The reason(s) why seeking a grand jury investigation is believed to be necessary and appropriate in the circumstances. By way of illustration, and not by way of limitation, facts such as the following may indicate that the administrative process cannot develop the relevant facts within a reasonable time:


       — Lack of cooperation by important witnesses;


       — Efforts by the taxpayer to impede orderly investigation by intimidation of witnesses, destruction or threat of destruction of records or evidence;


       — The secreting of evidence; and


       — Severe time limitations imposed by the statute of limitations

4. The potential deterrent effect of the anticipated case(s) on an area of noncompliance, together with the reason(s) for concluding the anticipated case(s) is sufficiently significant to tax administration to warrant transferring further investigation responsibility to a grand jury

5. Recommendations as to testimony and documentary evidence to be sought before the grand jury together with identification of possible witnesses from whom such testimonial and documentary evidence may be obtainable

6. Any other factor that in the judgment of the special agent bears upon the recommendation for grand jury investigation


**38.2.2.3.1** **(12-20-2018)**

#### Counsel’s Role

1. Counsel will review the Form 9131, Request for Grand Jury Investigation, and accompanying exhibits in accordance with the standard set forth in CCDM 38.2.2.2.2 and will prepare a Grand Jury Request memorandum for the SAC, reviewing and evaluating the Grand Jury Request. See Exhibit 38.3.1-11.

2. The Criminal Tax attorney’s review of a Service initiated grand jury request will be completed within 20 workdays of receipt of the special agent’s report and exhibits.

3. The Associate Chief Counsel (CT) will review and evaluate Service initiated grand jury requests involving sensitive individuals/organizations. See CCDM 38.2.2.2.3.


**38.2.2.3.2** **(12-20-2018)**

#### Content and Style of Grand Jury Request Memorandum

01. Although the content and style of the memorandum must be tailored to the individual case, it should contain the information discussed in this subsection.

02. Criminal Subject(s). This section contains the name and address of the target(s).

03. Counsel’s Recommendation. This section contains Counsel’s recommendation as to whether the information contained in the Form 9131 package meets the required standard under IRM 38.2.2.2.2.

04. Standard of Review. This section lists the three pronged standard of review for Grand Jury Requests.

05. Executive Summary. In a nutshell, summarize the target’s identity and alleged criminal conduct that gives rise to the anticipated criminal violation(s) and the year(s) involved.

06. Facts. Provide a brief description of the information presented in the Form 9131 package, including a description of the target (age, background, education, etc.), contemplated charges (cite statutes), and years under investigation. The facts section should also include the source of the investigation, non-tax charges and current status (if applicable), each target’s relative culpability, target’s known current life style, tax filing history and bank account information, known civil activity, and citations to and explanations of any relevant technical tax statutes.

07. Law and Analysis. Describe the proposed violations and years involved, along with specific facts that support a finding that a crime has been committed. The discussion should include a detailed analysis of the following factors:



    - List each violation, including its specific elements, and cite to recent cases from the appropriate circuit.

    - Apply the relevant facts cited within the Facts section to the specific elements of the violation.

    - Conclude whether the articulable facts standard has been satisfied.


08. Referral for a Grand Jury Investigation is Necessary and Appropriate. Discuss the unique facts of the investigation in light of the necessary and appropriate standard set forth in the IRM. Boilerplate and conclusory language should be avoided.

09. Legal Impediments or Other Detracting Factors. List and describe the main legal impediments in the case. Case citations are preferred when discussing legal issues.

10. Conclusion. In this section note whether the 9131 package has established articulable facts supporting a reasonable belief the subject has committed the alleged violations and if there are an significant legal impediments.


**38.2.2.4** **(08-11-2004)**

### Government Attorney—Initiated Request for Grand Jury Assistance

1. Requests to the Service for participation by Service personnel in grand jury investigations are sometimes initiated by US Attorneys, Chiefs of Organized Crime Strike Forces, or DOJ. Such requests may arise out of an ongoing grand jury investigation which has developed evidence of a Title 26-related violation(s).

2. Such requests may also arise out of information received by the attorney for the Government from non-grand jury sources.


**38.2.2.4.1** **(08-11-2004)**

#### Procedures

1. Generally, the referral channels within the Service and the standards of review applicable to Service initiated requests for grand jury investigation apply also to requests to the Service for grand jury assistance.

2. The Criminal Tax attorney’s review and evaluation of the request should be accomplished within ten workdays of receipt. If Counsel’s review and evaluation cannot be accomplished within this time frame, the SAC should be notified.



1. In emergency situations where immediate approval is necessary, Counsel may be asked to telephonically notify the SAC of his/her recommendation/evaluation.

2. If this procedure is utilized, a written confirmation addressed to the SAC setting forth, in addition to the usual contents of an expansion recommendation, an explanation of the reasons for resorting to the telephonic procedure, will be sent within five workdays of the telephonic procedure.


3. Targets not the subject of the request by the attorney for the Government may not be added to the request without the concurrence of the SAC and the attorney for the Government, and can only be recommended as a transactional referral pursuant to the provisions of IRC § 6103(h)(2)(C). If discussion of the additional targets does not qualify as a transactional referral, the addition of targets must proceed as a Service initiated request for grand jury investigation as outlined above.

4. In the criminal evaluation memorandum to the SAC, there should be a paragraph setting forth the names and job titles of all Counsel personnel, inclusive of docket attorney, supervisors, and support staff, who accessed the information in the course of providing the requested evaluation.

5. Tax Division Directive No. 86-59 will apply to most US Attorney requests to broaden an existing grand jury investigation to include Title 26 offenses.


**38.2.2.5** **(08-11-2004)**

### Grand Jury Expansion Requests

1. Subsequent to referral of a case for grand jury investigation, the attorney for the Government may determine the scope of the investigation should be expanded to include additional subjects, additional taxable periods, additional types of tax, or a combination thereof. In this circumstance, the attorney for the Government may request that the Service consider committing its resources to the contemplated expanded aspects of the ongoing investigation. Expansion request procedures are appropriate only for adding additional subject(s), taxable period(s), or type(s) of tax to an ongoing authorized Title 26 grand jury investigation. An expansion request shall be governed by the standards set forth in CCDM 38.2.2.2.2.

2. Requests for expansion of a grand jury will be handled in accordance with the procedures outlined in CCDM 38.2.2.4.1(2).


**38.2.2.5.1** **(08-11-2004)**

#### Combination Grand Jury Expansion Request and Evaluation

1. A combination grand jury expansion request and evaluation, commonly referred to as a "Combo" , should be directed to the Criminal Tax attorney responsible for the review and evaluation of the grand jury investigation to the SAC. The grand jury criminal evaluation memorandum must clearly indicate that both the expansion request and evaluation of the grand jury evidence are being discussed. See CCDM 38.2.2.6 for Grand Jury Evaluation Procedures.


**38.2.2.6** **(08-11-2004)**

### Processing Grand Jury Evaluation Cases

1. Unless noted below, there are no procedural differences between reviewing and evaluating a grand jury case and an administrative case.

2. No conferences will be held in cases investigated by grand jury.

3. As a result of a request from a US Attorney or an Assistant US Attorney, the Criminal Tax attorney will review and evaluate all matters presented for sufficiency in law and identification of any legal or other impediments that detract from the prospects of successful prosecution. A grand jury criminal evaluation memorandum will be prepared by the Criminal Tax attorney on the basis of this evaluation. The grand jury criminal evaluation memorandum will be signed by the Criminal Tax attorney given signature authority, or the Area Counsel (CT), and transmitted to the SAC.

4. The Criminal Tax attorney’s review of the case and completion of the grand jury criminal evaluation memorandum is to occur within 30 days of receipt of copies of the special agent’s report and exhibits. The 30 days for completion of the Criminal Tax attorney’s review can be extended an additional 15 days upon the approval of the Area Counsel (CT).

5. The grand jury criminal evaluation memorandum utilizes the format of the administrative criminal evaluation memorandum with the following addition: the concluding paragraph of the grand jury criminal evaluation memorandum will provide the name(s) and job title(s) of all Counsel personnel who had access to the grand jury material.


**38.2.2.7** **(08-11-2004)**

### Pending Civil Matters in Grand Jury Cases

1. Once a matter has been referred to DOJ for grand jury investigation, the Service is not automatically barred from conducting a civil examination of the same or related tax liabilities wholly independent of the grand jury investigation. It is recommended that such civil activity should not be taken, however, without prior consultation with DOJ.


**38.2.2.7.1** **(10-03-2007)**

#### Administrative Summonses

1. Administrative summonses cannot be served, or if previously served, judicially enforced, in the matter of the tax liability of a grand jury subject for the same taxes and taxable periods that constitute the basis of the referral for grand jury investigation.

2. Any questions about the advisability of summons issuance should be referred to the Associate Chief Counsel (CT) for coordination with Branches 6 and 7 in the office of the Associate Chief Counsel (Procedure & Administration).


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part38/irm_38-002-002#addtoany "Show all")

A2A