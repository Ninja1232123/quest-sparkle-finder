---
url: "https://www.irs.gov/irm/part32/irm_32-003-003"
title: "32.3.3 Information Letters | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part32/irm_32-003-003#main-content)

- 32.3.3 [Information Letters](https://www.irs.gov/irm/part32/irm_32-003-003#idm140273577228096)
  - 32.3.3.1 [Scope of Information Letters](https://www.irs.gov/irm/part32/irm_32-003-003#idm140273575388736)
  - 32.3.3.2 [Information Letters to be Available for Public Inspection](https://www.irs.gov/irm/part32/irm_32-003-003#idm140273586789312)
  - 32.3.3.3 [Procedures for Writing Information Letters](https://www.irs.gov/irm/part32/irm_32-003-003#idm140273590055232)
  - 32.3.3.4 [Redaction Process](https://www.irs.gov/irm/part32/irm_32-003-003#idm140273598052720)
  - 32.3.3.5 [Effect of Information Letters](https://www.irs.gov/irm/part32/irm_32-003-003#idm140273577723824)

# Part 32. Published Guidance and Other Guidance to Taxpayers

# Chapter 3. Letter Rulings, Information Letters, and Closing Agreements

# Section 3. Information Letters

* * *

## 32.3.3 Information Letters

**32.3.3.1** **(08-11-2004)**

### Scope of Information Letters

1. Information letters call attention to a well-established interpretation or principle of tax law (including a treaty) without applying it to a specific set of facts.

2. An information letter may be issued if a taxpayer’s letter ruling request does not meet the requirements of CCDM 32.3.1.14 Requirements with Respect to Submission of Requests for Letter Rulings and the Service believes that general information will help the taxpayer.


**32.3.3.2** **(08-11-2004)**

### Information Letters to be Available for Public Inspection

1. The Service makes information letters available on a quarterly basis for public inspection and copying. The purpose of releasing these letters is to increase public confidence that the tax system operates fairly and in an even-handed manner with respect to all taxpayers. The Service releases information letters that respond to inquiries postmarked (or, if not mailed, received) after January 1, 2000, and issued by the following offices:



   - Associate Chief Counsel (Corporate)

   - Associate Chief Counsel (Financial Institutions and Products)

   - Associate Chief Counsel (Income Tax and Accounting)

   - Associate Chief Counsel (International)

   - Associate Chief Counsel (Passthroughs and Special Industries)

   - Associate Chief Counsel (Procedure and Administration)

   - Division Counsel/Associate Chief Counsel (Tax Exempt and Government Entities)


### Note:

For information letters issued on matters within the jurisdiction of the Commissioner, Tax Exempt and Government Entities Division, see the annual revenue procedure for Tax Exempt and Government Entities.

2. The requirement to release information letters applies to responses that provide general statements of well-defined law without applying them to a specific set of facts. The requirement applies to information letters written to the following:



   - Members of the public

   - Members of Congress who request information on their own behalf or on behalf of a constituent.


3. The requirement to release information letters does not apply to the following types of responses:



   - Responses to federal or state agencies

   - Responses that merely transmit Service publications or other publicly available material without significant legal discussion

   - Responses to taxpayer or third party contacts that are inquiries with respect to a pending request for a letter ruling or technical advice memorandum (whose disclosure is subject to section 6110)

   - Responses to taxpayer or third party communications with respect to any investigation, audit, litigation, or other enforcement action

   - Except for responses issued by the headquarters office of the Commissioner, Tax Exempt and Government Entities, responses issued by the field or a director. See the annual revenue procedure of Tax Exempt and Government Entities for information letters issued by the headquarters office of the Commissioner, Tax Exempt and Government Entities.


4. Certain responses may require that the information letters be treated as letter rulings and processed under the procedures in CCDM 32.3.1.14 Requirements with Respect to Submission of Requests for Letter Rulings and 32.3.2 Letter Rulings (including disclosure under section 6110).



### Note:



Managers must review responses to inquiries before they are issued to ensure that the responses provide general information and are not substitutes for letter rulings and that the responses do not pertain to a pending request for a letter ruling, technical advice memorandum, or chief counsel advice, or to any investigation, audit, litigation, or other enforcement action.


**32.3.3.3** **(08-11-2004)**

### Procedures for Writing Information Letters

1. To ensure that information letters can be released to the public readily and efficiently, initiators should use the following drafting guidelines concerning content and style:



1. Raise and address an issue, but do not use the letter as a substitute for a letter ruling (which applies the law to a specific set of facts)

2. Provide a brief statement of the facts as needed to be responsive to the inquiry

3. Provide a concise statement of the issue or inquiry and a general discussion of the applicable law

4. If needed, set forth rationales and conclusions, but take care not to apply the law to a specific set of facts

5. Include an identified addressee and a salutation to that addressee

6. Limit personal or taxpayer-specific references to the first and/or second paragraph.


**32.3.3.4** **(08-11-2004)**

### Redaction Process

1. In releasing information letters, the Service balances privacy interests with the public interest in understanding the internal revenue laws.

2. Before making any information letter available for public inspection, Associate Chief Counsel and Division Counsel/Associate Chief Counsel (TEGE) offices will delete any name, address, and other identifying information as appropriate under the Freedom of Information Act (FOIA), 5 U.S.C. § 552 (for example, FOIA personal privacy exemption of 5 U.S.C. § 552(b)(6) and tax details exempt pursuant to section 6103, as incorporated into FOIA by 5 U.S.C. § 552(b)(3)).

3. Information letters are not written determinations as defined in section 6110.


**32.3.3.5** **(08-11-2004)**

### Effect of Information Letters

1. Information letters are advisory only and have no binding effect on the Service.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part32/irm_32-003-003#addtoany "Show all")

A2A