---
url: "https://www.irs.gov/irm/part35/irm_35-001-001"
title: "35.1.1 Tax Court Jurisdiction and Proceedings | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-001-001#main-content)

- 35.1.1  [Tax Court Jurisdiction and Proceedings](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914906832)
  - 35.1.1.1  [Introduction](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914937376)
  - 35.1.1.2  [Types of Proceedings](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914934976)
  - 35.1.1.3  [Claims for Relief from Joint and Several Liability](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914897328)
  - 35.1.1.4  [Review of Final Partnership Adjustments (BBA)](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914893936)
  - 35.1.1.5  [Review of Final Partnership Administrative Adjustments](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914890992)
  - 35.1.1.6  [Review of Partnership Administrative Adjustments Where Administrative Adjustment Request Is Not Allowed in Full](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914887984)
  - 35.1.1.7  [Review of Final Partnership Administrative Adjustments for Large Partnership](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914884912)
  - 35.1.1.8  [Review of Large Partnership Administrative Adjustments Where Administrative Adjustment Request Is Not Allowed in Full](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914492464)
  - 35.1.1.9  [Statutory Interest Determinations](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914489392)
  - 35.1.1.10  [Interest Abatement Claims](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914485216)
  - 35.1.1.11  [Actions for Administrative Costs](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914482272)
  - 35.1.1.12  [Enforcement of Overpayment Decisions](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914479296)
  - 35.1.1.13  [Modification of Decisions in I.R.C. § 6166 Estate Tax Cases](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914475824)
  - 35.1.1.14  [Review of Jeopardy Assessments in Ongoing Tax Court Cases](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914472800)
  - 35.1.1.15  [Review of Certain Sales of Seized Property](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914470000)
  - 35.1.1.16  [Review of Collection Due Process](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914466944)
  - 35.1.1.17  [Disclosure Actions](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914464384)
  - 35.1.1.18  [Review of Whistleblower Office Determinations](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914461776)
  - 35.1.1.19  [Injunction Authority](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914459120)
  - 35.1.1.20  [Declaratory Judgment and Other Proceedings](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914456016)
    - 35.1.1.20.1  [Declaratory Judgment Relating to Oversheltered Return](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914450240)
    - 35.1.1.20.2  [Declaratory Judgment Relating to Qualification of Exempt Organization](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914447280)
    - 35.1.1.20.3  [Declaratory Judgment Relating to Worker Classification](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914444304)
    - 35.1.1.20.4  [Declaratory Judgment Relating to Qualification of Retirement Plan](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914440400)
    - 35.1.1.20.5  [Declaratory Judgment Relating to Gift Valuation](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914437424)
    - 35.1.1.20.6  [Declaratory Judgment Relating to Government Obligations](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914434432)
    - 35.1.1.20.7  [Declaratory Judgment Relating to Eligibility of an Estate to Make Installment Payments under Section 6166](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914430480)
  - 35.1.1.21  [Certification Actions Involving Passports](https://www.irs.gov/irm/part35/irm_35-001-001#idm140329914427360)

# Part 35. Chief Counsel Directives Manual Tax Court Litigation

# Chapter 1. Tax Court Jurisdiction

# Section 1. Tax Court Jurisdiction and Proceedings

* * *

## 35.1.1 Tax Court Jurisdiction and Proceedings

#### Manual Transmittal

June 29, 2022

#### Purpose

(1) This transmits new CCDM 35.1.1, Tax Court Jurisdiction, Tax Court Jurisdiction and Proceedings.

#### Background

This section is being revised to add certification actions involving passports under I.R.C. § 7345(e) to the description of the types of proceedings over which the Tax Court has jurisdiction. The section also describes Title XXXIV of the Tax Court’s Rules of Practice and Procedure (Tax Court Rules 350 through 354), adopted by the Tax Court in November 2018, setting forth procedures governing passport-related actions under section 7345.

#### Material Changes

(1) CCDM 35.1.1.2(2), Types of Proceedings, has been updated to add certification actions involving passports (section 7345(e)) to the list of actions over which the Tax Court has jurisdiction.

(2) New section CCDM 35.1.1.21, Certification Actions Involving Passports, is added to describe passport actions in the Tax Court under section 7345 and the Tax Court Rules governing such actions.

#### Effect on Other Documents

CCDM 35.1.1, dated August 9, 2021, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(06-29-2022)

Richard G. Goldman

Deputy Associate Chief Counsel

(Procedure & Administration)

**35.1.1.1** **(08-11-2004)**

### Introduction

1. The United States Tax Court is established as a court of record under Article I of the Constitution by section 7441 of the Internal Revenue Code. The Tax Court’s jurisdiction is generally prescribed by section 7442, but specific grants of jurisdiction are interspersed throughout the Code. The procedure under which the court operates is prescribed in sections 7451 through 7465. Pursuant to its statutory authority in section 7453, the court has promulgated Rules of Practice and Procedure under which it operates. Except in proceedings conducted under sections 7436(c) and 7463, the rules of evidence applicable in the Tax Court are the rules of evidence applicable in trials without a jury in the United States District Court for the District of Columbia. Section 7453. The specific Internal Revenue Code provisions conferring Tax Court jurisdiction are discussed in subsequent text.


**35.1.1.2** **(06-29-2022)**

### Types of Proceedings

1. The Tax Court has jurisdiction to redetermine whether deficiencies determined by the Commissioner are correct. The provisions of sections 6211 through 6216 relate to deficiency proceedings.

2. Other jurisdictional grants by Congress to the Tax Court are listed below (and described at _CCDM 35.1.1.3_ through _CCDM 35.1.1.17_):



   - Claims for relief from joint and several liability (section 6015(e))

   - Review of final partnership administrative adjustments (section 6226)

   - Review where an administrative adjustment request is not allowed in full (section 6228)

   - Review of partnership adjustments of a large partnership (section 6247)

   - Review where an administrative adjustment request is not allowed in full for a large partnership (section 6252)

   - Redetermination of interest on deficiencies or overpayments determined by the Tax Court (section 7481(c))

   - Interest abatement claims (section 6404(i))

   - Actions for administrative costs (section 7430(f)(2))

   - Enforcement of overpayment decision by the Tax Court if not refunded by the Service within 120 days after the decision of the court has become final (section 6512(b)(2))

   - Modification of final decision in an estate tax case to reflect interest paid pursuant to section 6166 (section 7481(d))

   - Review of the reasonableness and appropriateness of a jeopardy assessment where taxpayer has petitioned the Tax Court to redetermine a deficiency (section 7429(b)(2)(B))

   - Review of sale by the Service of seized property pending decision by the Tax Court in a deficiency proceeding (section 6863(b)(3)(C))

   - Review of collection due process cases (sections 6320 & 6330)

   - Disclosure actions (section 6110(f)(3))

   - Review of Whistleblower Office determinations (section 7623(b)(4))

   - Certification actions involving passports (section 7345(e))


3. See _CCDM 35.1.1.19_ for other proceedings in the Tax Court involving various declaratory judgments and worker classification cases under section 7436 where Congress has given specific grants of jurisdiction to the Tax Court.


**35.1.1.3** **(08-11-2004)**

### Claims for Relief from Joint and Several Liability

1. Section 6015(e) grants the Tax Court jurisdiction to determine relief from joint and several liability under section 6015. The Tax Court has jurisdiction to determine relief from joint and several liability under section 6015 when a petitioner raises a claim for relief under this section in several contexts, e.g., a deficiency proceeding under section 6213(a), a stand-alone proceeding under section 6015(e), or a collection due process proceeding under section 6330. The court reviews the Service’s determinations under section 6015(b) and (c) de novo but reviews the Service’s determinations under section 6015(f) for abuse of discretion. Section 6015(e)(1)(A) is effective with respect to any liability for tax arising after July 22, 1998, and any liability for tax arising on or before such date but remaining unpaid as of that date. _See_ T.C. Rules 320–325.


**35.1.1.4** **(08-09-2021)**

### Review of Final Partnership Adjustments (BBA)

1. Section 6234(a), effective for partnership years beginning on or after January 1, 2018, grants the Tax Court jurisdiction to determine all partnership items for the partnership for the partnership year to which a notice of final partnership adjustments relates, the proper allocation of such items among the partners, and the applicability of any penalty, addition to tax, or additional amount that relates to an adjustment to a partnership item. A decision under section 6234 has the same force and effect as a regular Tax Court decision and is reviewable as such. _See_ T.C. Rules 255.1-255.7.


**35.1.1.5** **(08-11-2004)**

### Review of Final Partnership Administrative Adjustments

1. Section 6226, effective for partnership years beginning after September 3, 1982, grants the Tax Court jurisdiction to determine all partnership items for the partnership for the partnership year to which a notice of final partnership administrative adjustments relates, the proper allocation of such items among the partners, and the applicability of any penalty, addition to tax, or additional amount that relates to an adjustment to a partnership item. A decision under section 6226 has the same force and effect as a regular Tax Court decision and is reviewable as such. _See_ T.C. Rules 240–251.


**35.1.1.6** **(08-11-2004)**

### Review of Partnership Administrative Adjustments Where Administrative Adjustment Request Is Not Allowed in Full

1. Section 6228, effective for partnership years beginning after September 3, 1982, grants the Tax Court jurisdiction to determine those partnership items to which the part of the tax matters partner’s request under section 6227 not allowed by the Commissioner relates and those items with respect to which the Commissioner asserts adjustments as offsets. A decision under section 6228 has the same force and effect as a regular Tax Court decision and is reviewable as such. _See_ T.C. Rules 240–251.


**35.1.1.7** **(08-11-2004)**

### Review of Final Partnership Administrative Adjustments for Large Partnership

1. Section 6247, effective for partnership years ending on or after December 31, 1997, grants the Tax Court jurisdiction to determine all partnership items for the large partnership for the partnership year to which a notice of final partnership administrative adjustments relates, the proper allocation of such items among the partners, and the applicability of any penalty, addition to tax, or additional amount for which the partnership may be liable under section 6242(b). A decision under section 6247 has the same force and effect as a regular Tax Court decision and is reviewable as such. _See_ T.C. Rules 300–305.


**35.1.1.8** **(08-11-2004)**

### Review of Large Partnership Administrative Adjustments Where Administrative Adjustment Request Is Not Allowed in Full

1. Section 6252, effective for partnership years ending on or after December 31, 1997, grants the Tax Court jurisdiction to determine those large partnership items to which the part of the tax matters partner’s request under section 6251 not allowed by the Commissioner relates and those items with respect to which the Commissioner asserts adjustments as offsets. A decision under section 6252 has the same force and effect as a regular Tax Court decision and is reviewable as such. _See_ T.C. Rules 300–305.


**35.1.1.9** **(08-11-2004)**

### Statutory Interest Determinations

1. Section 7481(c), effective for assessments of deficiencies redetermined by the Tax Court and made after November 10, 1988, grants the Tax Court jurisdiction to resolve disputes that arise over the Commissioner’s post-decision computation of interest. The Tax Court may redetermine interest in either of the following situations: (1) an assessment has been made by the Secretary under section 6215, which includes interest, and the taxpayer has paid the entire amount of the deficiency plus interest claimed by the Secretary; or (2) the Tax Court finds under section 6512(b) that the taxpayer has made an overpayment. If the court determines either that the taxpayer has made an overpayment of interest or that the Secretary has made an underpayment of interest, the court will enter an order determining an overpayment of tax pursuant to section 6512(b)(1). A decision with respect to overpayment of interest is reviewable on appeal in the same manner as a decision of the Tax Court with respect to the deficiency. _See_ T.C. Rule 261.


**35.1.1.10** **(08-11-2004)**

### Interest Abatement Claims

1. Section 6404(i), effective for requests for abatement made after July 30, 1996, grants the Tax Court jurisdiction to determine whether the Commissioner’s failure to abate interest under section 6404 was an abuse of discretion. A Tax Court decision under section 6404 is reviewable on appeal in the same manner as a regular decision of the Tax Court but only as to the matters determined in such decision. _See_ T.C. Rules 280–284.


**35.1.1.11** **(08-11-2004)**

### Actions for Administrative Costs

1. Section 7430(f)(2), effective with respect to proceedings commenced after November 10, 1988, establishes jurisdiction in the Tax Court to decide appeals of taxpayers from decisions by the Internal Revenue Service denying awards for reasonable administrative costs within the meaning of section 7430(c)(2). _See_ T.C. Rules 270–274 and CCDM 35.10.1.2.


**35.1.1.12** **(08-11-2004)**

### Enforcement of Overpayment Decisions

1. Section 6512(b)(2) grants jurisdiction for the Tax Court to order the Commissioner to refund the amount of an overpayment redetermined by the Tax Court but not paid within 120 days after the Tax Court decision is final, together with statutory interest thereon. Pursuant to section 6512(b)(2), as amended by the Taxpayer Relief Act of 1997, effective July 30, 1997, an order of the Tax Court disposing of a motion to enforce the overpayment determination is reviewable in the same manner as a decision of the Tax Court but only with respect to the matters determined in such order. _See_ T.C. Rule 260.


**35.1.1.13** **(08-11-2004)**

### Modification of Decisions in I.R.C. § 6166 Estate Tax Cases

1. Section 7481(d), effective with respect to Tax Court cases for which a decision was not final on November 11, 1988, establishes jurisdiction in the Tax Court to reopen a case in order to modify a final decision affected by the extension of time for payment of an estate tax deficiency under section 6166. _See_ T.C. Rule 262 and CCDM 35.9.1.3.2.3.


**35.1.1.14** **(08-11-2004)**

### Review of Jeopardy Assessments in Ongoing Tax Court Cases

1. Section 7429(b)(2)(B), effective for assessments or levies made on or after July 1, 1989, establishes jurisdiction in the Tax Court to review in the same manner as a United States District Court the reasonableness of the jeopardy assessment or levy made for deficiencies that are presently and properly before the Tax Court for redetermination. Any Tax Court determination under section 7429(b)(2)(B) is final and conclusive and is not reviewable in any other court. _See_ T.C. Rule 56.


**35.1.1.15** **(08-11-2004)**

### Review of Certain Sales of Seized Property

1. Section 6863(b)(3)(C), effective February 8, 1989, for review of the Commissioner’s determination to sell certain seized property, establishes jurisdiction in the Tax Court to order a stay or approval or disapproval, pending resolution of the underlying tax deficiency, of the sale by the Service of the seized property. Any order of the court disposing of a motion filed under section 6863(b)(3)(C) is reviewable on appeal in the same manner as a decision of the Tax Court with respect to the deficiency. _See_ T.C. Rule 57.


**35.1.1.16** **(08-11-2004)**

### Review of Collection Due Process

1. Section 6330, effective with respect to collection actions commenced after January 19, 1999, grants the Tax Court jurisdiction to review the lien or levy determination made by the Office of Appeals under sections 6320 or 6330. _See_ T.C. Rules 330–334.


**35.1.1.17** **(08-11-2004)**

### Disclosure Actions

1. Section 6110(f)(3) establishes jurisdiction in the Tax Court to review determinations by the Commissioner with respect to whether, and to what extent, written determinations and background file documents may be disclosed to the public. _See_ T.C. Rules 220–229A.


**35.1.1.18** **(08-15-2019)**

### Review of Whistleblower Office Determinations

1. Section 7623(b)(4), effective with respect to whistleblower information provided on or after December 20, 2006, grants the Tax Court jurisdiction to review any whistleblower office determination regarding an award under paragraphs (1), (2), or (3) of section 7623(b) when the conditions of section 7623(b)(4) have been satisfied. _See_ T.C. Rules 340-344.


**35.1.1.19** **(08-11-2004)**

### Injunction Authority

1. Ancillary to the primary jurisdiction for redetermining deficiencies, section 6243(a) of the Technical and Miscellaneous Revenue Act of 1988 (TAMRA) amended section 6213(a), effective November 11, 1988, to grant the Tax Court authority to enjoin a premature assessment or collection of the deficiency, which is the subject matter of a notice of deficiency timely petitioned to the Tax Court. The Tax Court has promulgated T.C. Rule 55, effective July 1, 1990, to implement its jurisdiction to restrain assessment or collection. Any order by the Tax Court resolving such an injunction proceeding is treated as, and may be appealed, as a final decision of the Tax Court, pursuant to section 7482(a)(3), effective November 11, 1988.


**35.1.1.20** **(08-15-2019)**

### Declaratory Judgment and Other Proceedings

1. Under specific jurisdictional grants by Congress listed below and described at CCDM 35.1.1.18.2 through 35.1.1.18.8, the Tax Court has jurisdiction to review certain administrative determinations by the Commissioner:



   - Treatment of items other than partnership items with respect to an oversheltered return (section 6234(c))

   - Status and classification of organizations under section 501(c)(3) (section 7428)

   - Determination of worker classification (section 7436)

   - Qualification of certain retirement plans (section 7476)

   - Valuation of certain gifts (section 7477)

   - Status of certain governmental obligations (bonds) (section 7478)

   - Eligibility of an estate with respect to installment payments under section 6166 (section 7479).


**35.1.1.20.1** **(08-15-2019)**

#### Declaratory Judgment Relating to Oversheltered Return

1. Section 6234(c) grants the Tax Court jurisdiction to make a declaration with respect to the Commissioner’s determination on all items other than partnership items and affected items (which require partnership level determinations as described in section 6230(a)(2)(A)(i)) for the taxable year to which a notice of adjustment relates. Any such declaration has the force and effect of a Tax Court decision and is reviewable as such. _See_ T.C. Rules 310–316.


**35.1.1.20.2** **(08-15-2019)**

#### Declaratory Judgment Relating to Qualification of Exempt Organization

1. Section 7428 grants the Tax Court jurisdiction to make a declaration with respect to the Commissioner’s determination (or failure to make a determination) of initial or continuing qualification of an organization under section 501(c)(3) or with respect to its initial or continuing classification as a private foundation, as defined in section 509(a), or a private operating foundation, as defined in section 4942(j)(3). Any such declaration has the force and effect of a Tax Court decision and is reviewable as such. _See_ T.C. Rules 210–218.


**35.1.1.20.3** **(08-15-2019)**

#### Declaratory Judgment Relating to Worker Classification

1. Section 7436 grants the Tax Court jurisdiction to make a declaration with respect to the Commissioner’s determination that one or more individuals performing services for such person are employees of such person for purposes of Subtitle C, Employment Taxes, and that such person is not entitled to treatment under subsection (a) of section 530 of the Revenue Act of 1978 with respect to such individual. The Tax Court has jurisdiction to determine whether such determination by the Commissioner is correct and the proper amount of employment tax under such determination. Any such declaration has the force and effect of a Tax Court decision and is reviewable as such, unless the proceedings are conducted under the small case procedures described in section 7463. _See_ T.C. Rules 290–294.


**35.1.1.20.4** **(08-15-2019)**

#### Declaratory Judgment Relating to Qualification of Retirement Plan

1. Section 7476 grants the Tax Court jurisdiction to make a declaration with respect to the Commissioner’s determination (or failure to make a determination) of the initial or continuing qualification of a retirement plan. Any such declaration has the force and effect of a Tax Court decision and is reviewable as such. _See_ T.C. Rules 210–218.


**35.1.1.20.5** **(08-15-2019)**

#### Declaratory Judgment Relating to Gift Valuation

1. Section 7477, effective for gifts made after August 5, 1997, grants the Tax Court jurisdiction to make a declaration with respect to the Commissioner’s determination of the value of any gift shown on the return of any gift tax imposed by Chapter 12 of the Code. Any such declaration has the force and effect of a Tax Court decision and is reviewable as such. _See_ T.C. Rules 210–218.


**35.1.1.20.6** **(08-15-2019)**

#### Declaratory Judgment Relating to Government Obligations

1. Section 7478 grants the Tax Court jurisdiction to make a declaration with respect to the Commissioner’s determination (or failure to make a determination) regarding whether interest on prospective obligations will be excludable from gross income under section 103(a). Any such declaration has the force and effect of a Tax Court decision and is reviewable as such. _See_ T.C. Rules 210–218. Tax Court decisions relating to governmental obligations may only be reviewed by the United States Court of Appeals for the District of Columbia Circuit. _See_ section 7482(b)(3).


**35.1.1.20.7** **(08-15-2019)**

#### Declaratory Judgment Relating to Eligibility of an Estate to Make Installment Payments under Section 6166

1. Section 7479, effective for estates of decedents dying after August 5, 1997, grants the Tax Court jurisdiction to make a declaration with respect to the Commissioner’s determination (or failure to make a determination) regarding whether an estate is eligible to make an installment payment election under section 6166 and whether the extension of time provided in section 6166 has ceased to apply. Any such declaration has the force and effect of a Tax Court decision and is reviewable as such. _See_ T.C. Rules 210–218.


**35.1.1.21** **(06-29-2022)**

### Certification Actions Involving Passports

1. Section 7345 provides for the revocation or denial of individuals’ passports in certain cases of tax delinquencies. Section 7345(e)(1) provides that any individual who has been notified as having been certified as having a seriously delinquent tax debt may bring a civil action to determine whether the certification was erroneous or should have been reversed. _See also_ T.C. Rules 350-354 (setting forth procedures governing passport-related actions under section 7345). The action may be filed in either a federal district court or the Tax Court. If an individual files actions in both federal district court and the Tax Court, the court in which the first action was filed shall have sole jurisdiction. Section 7345(e)(1).


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-001-001#addtoany "Show all")

A2A