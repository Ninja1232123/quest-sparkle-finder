---
url: "https://www.irs.gov/irm/part35/irm_35-005-001"
title: "35.5.1 Introduction | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-005-001#main-content)

- 35.5.1 [Introduction](https://www.irs.gov/irm/part35/irm_35-005-001#idm140380249093952)
  - 35.5.1.1 [Responsibilities of the Office of Chief Counsel](https://www.irs.gov/irm/part35/irm_35-005-001#idm140380249092960)
  - 35.5.1.2 [Responsibilities of Appeals](https://www.irs.gov/irm/part35/irm_35-005-001#idm140380249094496)
  - 35.5.1.3 [Management of Tax Court Cases](https://www.irs.gov/irm/part35/irm_35-005-001#idm140380225201952)
  - 35.5.1.4 [Settlements by Appeals](https://www.irs.gov/irm/part35/irm_35-005-001#idm140380219264544)

    - 35.5.1.4.1 [Settlement Procedures](https://www.irs.gov/irm/part35/irm_35-005-001#idm140380249100688)
    - 35.5.1.4.2 [Docketed Cases](https://www.irs.gov/irm/part35/irm_35-005-001#idm140380249141280)
    - 35.5.1.4.3 [Negotiations Concluded Without Full Settlement](https://www.irs.gov/irm/part35/irm_35-005-001#idm140380213204352)

# Part 35. Tax Court Litigation

# Chapter 5. Settlement Procedures

# Section 1. Introduction

* * *

## 35.5.1 Introduction

**35.5.1.1** **(08-11-2004)**

### Responsibilities of the Office of Chief Counsel

1. All action taken for the Service in the United States Tax Court is taken by or on behalf of the Chief Counsel pursuant to the authority vested in that official by statute and by delegation from the Commissioner of Internal Revenue and General Counsel of the Treasury, approved by the Secretary. The Chief Counsel, in fulfilling this function, acts through delegated representatives.

2. Please refer to the pertinent IRM provisions concerning delegations of authority for more information about delegations.

3. The Office of Chief Counsel has the responsibilities of the drafting of counsel settlement memoranda, the adequate preparation for trial, the trial of the case, and the determination that a correct and proper decision is entered by the court in each case.


**35.5.1.2** **(08-11-2004)**

### Responsibilities of Appeals

1. The appeals function in the handling and processing of Tax Court cases has been delegated to the Area Directors of Appeals and their associates and assistants. In this Part, wherever the term Appeals office or Appeals is used, it refers to the appeals function in the handling and processing of Tax Court matters.

2. Appeals responsibilities include, among others, the preparation of the necessary write-up for settlement or defense of cases referred to Appeals, the preparation of settlement and Rule 155 computations, and the general administrative details necessary to closing a case to the Area Director for the proper assessment of the deficiency or liability, or the refund or credit of the overpayment determined in the Tax Court’s decision.


**35.5.1.3** **(08-11-2004)**

### Management of Tax Court Cases

1. The established goals of both the Office of Chief Counsel and the Service are to settle as many Tax Court cases as possible at the earliest possible date prior to the cases being calendared for trial, to prepare adequately for trial those cases not settled, and to dispose of all pending cases in the most efficient and expeditious manner. In the fulfillment of this responsibility, Counsel and Appeals have separate functions to perform. It is in the performance of these separate functions with coordination and joint planning that these goals can be achieved. Therefore, as Counsel and Appeals perform their separate functions, each should be cognizant of the effect of action taken by one on the duties and responsibilities of the other.

2. The respective roles of Appeals and Counsel in the development and disposition of Tax Court cases are stated in Rev. Proc. 87-24, 1987-1 C.B. 720, or succeeding revenue procedure and pertinent IRM provisions. It is important that petitioners and their counsel not only understand that the Service handles Tax Court cases in accordance with Rev. Proc. 87-24, 1987-1 C.B. 720, but also that they know what those procedures are and what steps they should take for an early disposition of their cases. In cases in which the statutory notices were issued by Examination or the Service Center, Appeals will take appropriate steps to inform the petitioner or petitioner’s counsel of the Revenue Procedure. Likewise, in those cases in which Counsel retains the case or an issue in the case rather than referring the case to Appeals, it is sometimes necessary for Counsel to take action with respect to acquainting the petitioners or their counsel with the limits of the Revenue Procedure.

3. One of the primary purposes of Rev. Proc. 87-24, 1987-1 C.B. 720 is to expedite the disposition of Tax Court cases. After a basis of settlement has been reached with the petitioner, it is essential that the administrative details for processing the settlement be completed at the earliest possible date.


**35.5.1.4** **(08-11-2004)**

### Settlements by Appeals

1. This subsection discusses settlements by Appeals.


**35.5.1.4.1** **(08-11-2004)**

#### Settlement Procedures

1. Rev. Proc. 87-24, 1987-1 C.B. 720, sets forth, in general terms, the respective settlement procedures of Appeals and the Office of Chief Counsel in docketed Tax Court cases. In general, Appeals has settlement responsibility over docketed cases referred to it pursuant to these procedures until the case is returned to the Office of Chief Counsel. A case or an issue in a case may be reserved by Counsel rather than referring it to Appeals. IRM 2.2.4 regarding some exceptions to appeals referrals. Field Counsel reviewers and Appeals Team managers will confer on a regular basis to identify those cases within Appeals jurisdiction that should be referred to Counsel for discovery or where there is no settlement progress and/or the case is likely to appear on a trial calendar.

2. Certain cases may meet the requirements to qualify the case for "designated for litigation" status. Once a case is designated for litigation, the designated issue will not be resolved without a full concession by the taxpayer, unless it is subsequently de-designated. _See_ CCDM 33.3.6 for the procedures on designating a case for litigation.

3. The procedures outlined below do not apply to actions arising under section 6110 (public inspection of written determinations) or declaratory judgment actions arising under section 7428 (status and classification of organizations under section 510(c)(3), etc.), section 7476 (qualification of certain retirement plans), or section 7478 (status of certain governmental obligations). In such cases, Counsel will have exclusive settlement and trial authority.


**35.5.1.4.2** **(08-11-2004)**

#### Docketed Cases

1. If a basis of settlement is reached with respect to some or all of the issues in a docketed case, a decision document or settlement stipulation is prepared reflecting settlement of these issues. After the petitioner and/or the petitioner’s representative have signed the decision document or settlement stipulation, Appeals forwards the document along with any necessary computations to Field Counsel, who signs and files the document with the Tax Court. In a regular case, if a settlement is reached after a conference has been held with the petitioner and/or counsel, Appeals will prepare a transmittal memorandum with the case memorandum and either a decision document executed by the petitioner or the necessary computations for the preparation of a decision document by Field Counsel. These documents should be prepared and sent to Counsel as quickly as possible after the settlement conference.

2. Appeals also will prepare any necessary collateral agreements or take any action required toward processing a closing agreement, if such agreements are a part of the overall settlement of the case.

3. Normally, the proposed decision document will be forwarded to the petitioner, or petitioner’s representative, by Appeals. Where Field Counsel prepares the document or there are collateral agreements or Form 870-AD agreements to be obtained, only one letter transmitting such documents to the petitioner or petitioner’s counsel for execution should be sent. In this event, these documents may be sent either by Counsel or Appeals, whichever is most appropriate in the particular case.

4. Appeals will furnish to Counsel an extra copy of the settlement computation statement to be given to the petitioner or petitioner’s counsel when Counsel forwards the proposed decision for signature by or on behalf of the petitioner. It is contemplated that a copy of the settlement computation will be forwarded to the petitioner in each case. Particularly in complicated cases, or cases in which it appears that there may later develop some difficulty over the computation of the settlement liability or the decision of the Tax Court entered pursuant thereto, it is essential that a copy of the computation be forwarded to the petitioner or petitioner’s counsel with the settlement documents.

5. Normally, Field Counsel will review the settlement documents prepared by Appeals during its settlement jurisdiction for form and accuracy only, without regard to the substance of a settlement effectuated by Appeals. Field Counsel may, however, initiate contact with Appeals if questions arise upon review concerning the substance of a proposed settlement. In any such communication, care must be exercised to honor the restrictions on ex parte communications with Appeals.

6. Counsel should endeavor to forward settlement documents to the court promptly upon receipt.

7. If the proposed settlement offer involves related cases or matters that could be materially affected by this action, disagreements between Appeals and Field Counsel on whether the offer should be accepted will be resolved by the Field Counsel with the advice and assistance of the Area Director of Appeals.

8. Appeals has responsibility to prepare the necessary computations for settled docketed cases, including the audit statement of account, for both Appeals and Field Counsel.

9. Nothing in this section supersedes any outstanding delegation order or IRM provision concerning Appeals’ authority and procedures with respect to subchapter D of chapter 1 (pension, profit sharing, etc.), or initial or continuing exempt status and foundation classification.


**35.5.1.4.3** **(08-11-2004)**

#### Negotiations Concluded Without Full Settlement

1. If a full settlement is not effected by Appeals with the petitioner or petitioner’s counsel, or if the taxpayer declines to discuss settlement after being given an opportunity to do so, the administrative file will be returned promptly to Field Counsel for trial preparation. Appeals will prepare a transmittal memorandum and case memo setting forth the issues that are settled and any that remain unsettled. The transmittal memorandum and case memo, together with the administrative file, are forwarded to Field Counsel for preparation for trial.

2. Whenever a docketed case is returned to Counsel, authority to dispose of the case by trial or settlement rests with Counsel, unless Counsel and Appeals agree that Appeals should continue with settlement negotiations over some or all of the issues. Thus, in some situations Counsel will prepare a case for trial while Appeals simultaneously conducts settlement negotiations for some or all of the issues in the case. Additionally, Counsel and Appeals may agree to return the entire case to Appeals if there is a strong settlement likelihood for all or part of the case and such transfer will promote more efficient disposition of the case. Repetitive transfers of the case between Counsel and Appeals should be avoided.

3. In cases reconsidered by Appeals, if no change is made in a conclusion reached in a prior transmittal memorandum and case memo, Appeals will prepare a memorandum for the file on the further conference. In any instance in which additional issues are settled or new facts are developed at the conference, such settled issues or new facts will be discussed in the conference memorandum or incorporated into a new transmittal memorandum and Appeals case memo.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-005-001#addtoany "Show all")

A2A