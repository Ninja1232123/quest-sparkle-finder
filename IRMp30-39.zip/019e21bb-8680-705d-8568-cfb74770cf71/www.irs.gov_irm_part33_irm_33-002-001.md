---
url: "https://www.irs.gov/irm/part33/irm_33-002-001"
title: "33.2.1 Issuing Technical Advice Memorandum and Technical Expedited Advice Memoranda | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part33/irm_33-002-001#main-content)

- 33.2.1 [Issuing Technical Advice Memorandum and Technical Expedited AdviceMemoranda](https://www.irs.gov/irm/part33/irm_33-002-001#idm140642378091072)
  - 33.2.1.1 [Purpose and Authority](https://www.irs.gov/irm/part33/irm_33-002-001#idm140642383156320)
  - 33.2.1.2 [Definitions](https://www.irs.gov/irm/part33/irm_33-002-001#idm140642380739040)
  - 33.2.1.3 [Priorities](https://www.irs.gov/irm/part33/irm_33-002-001#idm140642377745984)
  - 33.2.1.4 [Change in Position](https://www.irs.gov/irm/part33/irm_33-002-001#idm140642373232592)
  - 33.2.1.5 [Deferral of Technical Advice Memorandum or Technical Expedited AdviceMemorandum Pending Publication of a Revenue Ruling](https://www.irs.gov/irm/part33/irm_33-002-001#idm140642395776976)
  - 33.2.1.6 [Coordination With, and Assistance From, Other Branches or AssociateOffices](https://www.irs.gov/irm/part33/irm_33-002-001#idm140642386179552)
  - 33.2.1.7 [Cases Where Regulations Not Issued](https://www.irs.gov/irm/part33/irm_33-002-001#idm140642386326944)
  - 33.2.1.8 [Information as to Status](https://www.irs.gov/irm/part33/irm_33-002-001#idm140642390120304)
  - 33.2.1.9 [Standards for Requesting Advice and Legal Effect of Advice](https://www.irs.gov/irm/part33/irm_33-002-001#idm140642385451200)

    - 33.2.1.9.1 [Legal Effect of Technical Advice and Technical Expedited Advice](https://www.irs.gov/irm/part33/irm_33-002-001#idm140642393612848)

  - 33.2.1.10 [Effect of Section 6110 on Technical Advice and Technical ExpeditedAdvice Procedures](https://www.irs.gov/irm/part33/irm_33-002-001#idm140642387547664)

    - 33.2.1.10.1 [Section 6110 Procedures Applicable to Requests for Technical Adviceand Technical Expedited Advice](https://www.irs.gov/irm/part33/irm_33-002-001#idm140642391750624)
    - 33.2.1.10.2 [Section 6110 Procedures Applicable to Issuing Technical Advice andTechnical Expedited Advice Issuance](https://www.irs.gov/irm/part33/irm_33-002-001#idm140642393164624)

# Part 33. Legal Advice

# Chapter 2. Technical Advice and Technical Expedited Advice

# Section 1. Issuing Technical Advice Memorandum and Technical Expedited AdviceMemoranda

* * *

## 33.2.1 Issuing Technical Advice Memorandum and Technical Expedited Advice Memoranda

**33.2.1.1** **(08-11-2004)**

### Purpose and Authority

1. Associate Chief Counsel offices issue technical advice memoranda and technical expedited advice memoranda to Examination and to Appeals. Technical advice memoranda or technical expedited advice memoranda represent the views of the Office of Chief Counsel as to the application of tax law, tax treaties, regulations, revenue rulings, or other published precedents to the facts of specific cases, and are issued primarily as a means of assisting Service personnel in closing cases and establishing and maintaining uniformity in the treatment of issues. The Deputy Chief Counsel (Operations) will monitor pending technical advice and follow up with Associate Chief Counsel offices with respect to any over 180 days old.



### Note:



The second revenue procedure each year (e.g., Rev. Proc. 2004-2) sets forth detailed guidance on the technical advice and technical expedited advice processes.

2. The Associate Chief Counsel act as the primary assistants to the Chief Counsel in providing principles and rules for uniformly interpreting and applying the federal tax laws under their respective jurisdictions. An executive in each Associate Chief Counsel office will be designated to serve as the "responsible official" to manage technical advice memoranda and expedited technical advice memoranda over which that office has primary or assistance responsibility.

3. The procedures for obtaining technical advice specifically applicable to federal firearms taxes under subtitle E of the Internal Revenue Code are under the jurisdiction of the Alcohol and Tobacco Tax and Trade Bureau of the Treasury Department.

4. The procedures for obtaining technical advice or technical expedited advice specifically on employee plans and exempt organizations are under the jurisdiction of the Commissioner, Tax Exempt and Government Entities Division. Separate procedures and a separate Rev. Proc. (see Rev. Proc. 2004-5 or its successors) apply to matters within the jurisdiction of the Commissioner (TEGE).

5. The procedures that apply to technical advice or technical expedited advice for employee plans and exempt organizations (see Rev. Proc. 2004-5 or its successors) are followed in obtaining technical advice or technical expedited advice on exemption of farmers’ cooperatives from tax under section 521, even though the Associate Chief Counsel (PSI) has jurisdiction for issuing technical advice or technical expedited advice under this section.


**33.2.1.2** **(08-11-2004)**

### Definitions

1. "Technical advice" means written guidance issued in the form of a legal memorandum by the Associate office with subject matter jurisdiction over the issue raised upon the request of examination or Appeals submitted in accordance with the provisions of the second revenue procedure published each year (e.g., Rev. Proc. 2004-2), in response to any technical or procedural question that develops during any proceeding on the interpretation and proper application of tax law, tax treaties, regulations, revenue rulings, notices, or other precedents published by the Office of Chief Counsel to a specific set of facts. These proceedings include:



   - The examination of a taxpayer’s return,

   - Consideration of a taxpayer’s claim for refund or credit,

   - Any matter under exam or in appeals pertaining to tax-exempt bonds, tax credit bonds, or mortgage credit certificates; and

   - Any other matter involving a specific taxpayer under the jurisdiction of the Territory Manager or the Appeals area director, such as an examination to determine whether obligations issued are described in section 103(a).


2. Technical advice memoranda may address issues in an Appeals Office but not issues in a docketed case for any year involving that taxpayer (or related taxpayer within the meaning of section 267 or member of an affiliated group of which the taxpayer is a member within the meaning of section 1504). Examination or Appeals may raise an issue in any tax period, even though technical advice may have been asked for or furnished for the same or similar issue for another tax period.

3. "Technical expedited advice" means technical advice issued in an expedited manner. In general, if the taxpayer, field or area office, field counsel, and the Associate office all agree, any issue eligible for a technical advice memorandum can be submitted for a technical expedited advice memorandum.

4. The term "taxpayer" includes any person subject to any provision of the Internal Revenue Code (including an issuer of section 103 obligations) and, when appropriate, their authorized representatives.


**33.2.1.3** **(08-11-2004)**

### Priorities

1. Requests for technical advice and technical expedited advice generally are given priority and processed expeditiously.

2. The Chief Appeals and the Operating Division Commissioners may furnish the appropriate Associate Chief Counsel a list of technical advice and technical expedited advice cases already under consideration that require expeditious action. Associate offices should handle these cases as expeditiously as possible.

3. Because the procedures associated with the issuance of a technical expedited advice memorandum help expedite certain aspects of the technical advice process, the Associate offices will attempt to issue all technical expedited advice memoranda within 60 calendar days of receipt, provided that the Service and the taxpayer submit all required information in a timely manner.


**33.2.1.4** **(08-11-2004)**

### Change in Position

1. When consideration of a particular issue indicates that a longstanding holding of a Branch in letter rulings, technical advice memoranda, or technical expedited advice memoranda (or a previously issued letter ruling, technical advice memorandum, or technical expedited advice memorandum that is not a position of long standing but is one that was signed by an authority higher than a Branch Chief) should be reversed or substantially modified, further work on that particular issue will be suspended. A memorandum will be prepared from the Branch Chief (or other reviewer) to the Associate Chief Counsel setting forth



   - Administrative history of the position

   - Effect of changes in the law, if any, on the position (include citations or excerpts of pertinent provisions of Committee Reports)

   - Effect of court decisions, if any, on the position

   - Factors that are causing particular concern

   - Recommended position that should be taken

   - Basis or rationale for the proposed change in position


2. The memorandum will also include an approval line for the signature of the Associate Chief Counsel. The case file(s) will be attached to the memorandum and forwarded to the Associate Chief Counsel for consideration.

3. If the Associate Chief Counsel approves the Branch’s recommendation, the case file will be returned to the originating Branch and the approval memorandum will serve as the basis for a revenue ruling project. The underlying letter ruling, technical advice memorandum, or technical expedited advice memorandum should be prepared for release simultaneously with publication of the revenue ruling in the Internal Revenue Bulletin.

4. When consideration of a letter ruling request, technical advice request, or technical expedited advice request indicates that the holding will be substantially different from the holding in a previously issued letter ruling, technical advice memorandum, or technical expedited advice memorandum that is not a position of longstanding, and was not approved by an authority higher than a Branch Chief, the Associate Chief Counsel will be notified before final action is taken and given the information required by (1) above. If the Associate Chief Counsel decides that the proposed holding should supersede the holding in the earlier letter ruling, technical advice memorandum, or technical expedited advice memorandum, issuance of the letter ruling, technical advice memorandum, or technical expedited advice memorandum may be suspended by the Associate Chief Counsel pending publication of a revenue ruling; however, if the earlier letter ruling, technical advice memorandum, or technical expedited advice memorandum was signed by the Associate Chief Counsel or higher authority, the recommended change should be brought to the attention of the Associate Chief Counsel.


**33.2.1.5** **(08-11-2004)**

### Deferral of Technical Advice Memorandum or Technical Expedited Advice Memorandum Pending Publication of a Revenue Ruling

1. In processing requests for technical advice or technical expedited advice, it is necessary to identify at the earliest possible date those requests containing issues on which the Service position should be published prior to (or concurrent with) the issuance of responses to such requests. Upon identification of such a request, the responsible branch should notify the Associate Chief Counsel. The Associate Chief Counsel, Division Counsel Headquarters, and Treasury must agree that general guidance is necessary before a published guidance project will be initiated.

2. Factors to consider when determining whether general published guidance is necessary:



   - Whether the issue has broad application to similarly situated taxpayers or an industry.

   - Whether the issue is important to a clear understanding of the tax laws.


3. In general, a technical advice memorandum or a technical expedited advice memorandum should be issued in advance of the published guidance, unless policy considerations require otherwise. If the release of a technical advice memorandum or a technical expedited advice memorandum will be delayed pending publication of a Service position, the appropriate Associate office will so inform the Director or Appeals Office. See CCDM 33.2.1.8.


**33.2.1.6** **(08-11-2004)**

### Coordination With, and Assistance From, Other Branches or Associate Offices

1. Work assigned to a particular office within the Office of Chief Counsel may at times involve matters in which other segments of the Office of Chief Counsel or other components of the Service have an interest. Assistance should be sought from any Associate office that has assigned expertise in the subject matter involved in a project or whose operational area may be affected by the position to be taken. See CCDM 31.1.4 .

2. As discussed in CCDM 33.2.2.1.1, if a request for a technical advice memorandum or a technical expedited advice memorandum will include issues requiring involvement of more than one Associate office, representatives from each Associate office involved must participate in the presubmission conference.


**33.2.1.7** **(08-11-2004)**

### Cases Where Regulations Not Issued

1. Technical advice memoranda and technical expedited advice memoranda involving Code provisions under which regulations have not been issued ordinarily are prepared for the signature of the Associate Chief Counsel with subject matter jurisdiction.

2. See CCDM 32.3.2.3.2.2(2) for caveats to be included in technical advice memoranda and technical expedited advice memoranda in cases prior to adoption of temporary or final regulations.


**33.2.1.8** **(08-11-2004)**

### Information as to Status

1. A taxpayer may obtain information as to the status of the request for technical advice or technical expedited advice by contacting the examination or Appeals office that requested the advice.

2. The requesting office will be given status updates on the technical advice or technical expedited advice request once a month by the Associate’s office assigned to the request. If the Associate office has initiated a published guidance project to address the issue presented in the request for technical advice or technical expedited advice, the Associate office assigned to the request must also inform the requesting office of the status of the published guidance project.

3. The requesting office may obtain current information as to the status of the request for technical advice or technical expedited advice by calling the Associate office attorney or reviewer assigned to the request for technical advice or technical expedited advice.

4. Field counsel can also request to be informed as to the status on a monthly basis.

5. The Technical Services Branch will issue a monthly report to the Chief Counsel, Associate Chief Counsel and Division Counsel regarding the status of pending technical advice requests and pending presubmission conference requests. The report will include a list of TAMs completed during the preceding months of the fiscal year.


**33.2.1.9** **(08-11-2004)**

### Standards for Requesting Advice and Legal Effect of Advice

1. Technical advice or technical expedited advice may be requested by a Director on any technical or procedural question that develops during the examination of a taxpayer’s return, or consideration of a claim for refund or credit filed by a taxpayer. Technical advice or technical expedited advice may also be requested by an Appeals Office in the processing and consideration of a nondocketed case. Field offices are encouraged to request technical advice or technical expedited advice at the earliest possible stage of the proceedings on any technical or procedural question that cannot be resolved on the basis of law, regulations, or a clearly applicable revenue ruling or other published precedent. If an issue on which technical advice or technical expedited advice is appropriate is not identified until the case is in Appeals, a decision to request such advice (in nondocketed cases) should be made prior to or at the first conference. (The provisions of CCDM 33.2.1.9(7) and Rev. Proc. 2004-5, or its successors, are applicable to exempt organizations under the jurisdiction of examination or Appeals offices.) Technical advice or technical expedited advice should be requested in every case in which any of the following conditions exist:



1. The law and regulations are not clear as to their application to the issue being considered and there is no published precedent for determining the proper treatment of the issue;

2. There is reason to believe that a lack of uniformity in the disposition of the issue exists;

3. A doubtful or contentious issue is involved in a number of cases;

4. The issue is so unusual or complex as to warrant consideration by an Associate office; or

5. The examination or Appeals office believes that securing technical advice or technical expedited advice from an Associate office would be in the best interests of the Service.


2. Technical advice or technical expedited advice may not be requested in the following situations:



1. With respect to a taxable period if a prior disposition of the same taxpayer’s case for the same taxable period was based on mutual concessions (ordinarily with Form 870-AD (Offer of Waiver of Restrictions on Assessment of Deficiency in Tax and of Acceptance of Overassessment));

2. With respect to the same taxpayer or same transaction, when the issue is under the jurisdiction of Appeals and the applicability of more than one kind of federal tax depends upon the resolution of that issue; or

3. With respect to the same issue of the same taxpayer (or a related taxpayer within the meaning of sections 267 or 1504) if the issue is in a docketed case for that taxpayer for any taxable year (except for estate tax issues of a taxpayer in a docketed case, in which case the director can request advice on the issue if the appeals officer and field counsel agree to the issuance of the advice).


3. Examination may request technical advice or technical expedited advice:



1. On an issue previously considered in a prior Appeals disposition, not based on mutual concessions of the same taxpayer for the same taxable periods, only when the Appeals Office that had that case concurs in the request; and

2. On an issue even though the Appeals Office has the identical issue under consideration in the case of another taxpayer (not related within the meaning of sections 267 or 1504) in an entirely different transaction.


4. Examination or Appeals may raise an issue in any taxable period, even though they may have asked for and been furnished technical advice or technical expedited advice with regard to the same or a similar issue in any other taxable period.

5. If examination or Appeals is of the opinion that a letter ruling previously issued to a taxpayer should be modified or revoked, they will inform the taxpayer that in their opinion, the letter ruling should be modified or revoked. If, after the development of the facts and consideration of the taxpayer’s comments, if any, examination or Appeals still believes the letter ruling should be modified or revoked, they will request the appropriate Associate office to reconsider the ruling and the referral to the Associate office is treated as a request for technical expedited advice.

6. When a taxpayer’s request for a letter ruling on a completed transaction involving an income tax issue is received after the return is filed, a letter ruling will generally not be issued by an Associate office to the taxpayer because jurisdiction of all issues in a tax return is in examination. Any doubt whether a return has been filed should be resolved by contacting the responsible Operating Division. If it is determined that a return has been filed, the Operating Division is asked whether the request should be returned or treated as a request for technical advice or technical expedited advice. If the Operating Division decides to request technical advice or technical expedited advice, they are asked to advise the taxpayer of the taxpayer’s rights to file a written statement and to request a conference with the Associate’s office with subject matter jurisdiction. A letter ruling may be issued on a completed transaction concerning excise taxes, either before or after the return is filed, if the same issue is not before any field office in an active examination of the liability of the same taxpayer for the same or prior period, or is not being considered by an Appeals Office.

7. In section 521 cases, the Operating Division or Appeals Office must request technical advice or technical expedited advice on qualification for exemption not covered by published precedent or if non-uniformity may exist. In addition, if a proposed disposition by an Appeals Office is contrary to a prior letter ruling, technical advice memorandum, or technical expedited advice memorandum issued with respect to an organization, the proposed disposition must be submitted to the Associate office for approval. See Rev. Proc 2004-5 for section 7805(b) procedures in section 521 cases. Cases in which an Associate Chief Counsel issues technical advice or technical expedited advice to examination with respect to an organization’s qualification or an organization’s status may not be appealed to the Appeals Office. The case will be disposed of in examination in accordance with the holding in the technical advice memorandum or technical expedited advice memorandum. Similarly, if technical advice or technical expedited advice is issued to the Appeals Office, the advice is binding and the case will be disposed of in accordance with the holding in the memorandum. See Rev. Proc. 2004-5, or its successors, for other technical advice or technical expedited advice provisions applicable to organizations seeking recognition of exempt status under section 521 and the procedure to be followed if an organization protests an adverse determination letter issued by examination.

8. Requests for an extension of time or other application for relief under section 301.9100-1 of the Regulations on Procedure and Administration made after the examination of the taxpayer’s return has begun or made after the issues in the return are being considered by an Appeals Office are letter ruling requests and are subject to the procedures of Rev. Proc. 2004-1, 2004-1 C.B. 1, or its successors. See CCDM 32.3. All such requests must be submitted to the Associate office by the taxpayer. The Associate office will notify the field office considering the return (examination, Appeals or counsel) that a request for section 301.9100-1 relief has been submitted. The Associate office will mail the letter ruling on the section 301.9100-1 request to the taxpayer and send the appropriate field office a copy.

9. A taxpayer can request that an issue be referred to the Associate office for a technical advice memorandum or a technical expedited advice memorandum while the taxpayer’s case is under the jurisdiction of examination or Appeals. The taxpayer can make the request orally or in writing, but should direct the request to the examining agent or appeals officer. See CCDM 33.2.2.4 for procedures when the examining agent or appeals officer concludes that a taxpayer’s request for a technical advice memorandum or a technical expedited advice memorandum does not warrant referral to the Associate office.


**33.2.1.9.1** **(08-11-2004)**

#### Legal Effect of Technical Advice and Technical Expedited Advice

1. A holding in a technical advice memorandum or a technical expedited advice memorandum applies only to the taxpayer for whom the advice was requested.

2. Except in rare or unusual circumstances, a holding in a technical advice memorandum or a technical expedited advice memorandum that is favorable to the taxpayer is applied retroactively.

3. Because technical advice or technical expedited advice usually is issued only on closed transactions, a holding that is adverse to the taxpayer also is applied retroactively unless the Associate Chief Counsel with jurisdiction over the technical advice memorandum or technical expedited advice memorandum exercises the discretionary authority under section 7805(b) to limit the retroactive effect of the holding. (The procedures in CCDM 32.3 and CCDM 33.2 are applicable to questions of nonretroactive application under section 7805(b).) Likewise, a holding in a technical advice memorandum or a technical expedited advice memorandum that modifies or revokes a holding in a prior technical advice memorandum or technical expedited advice memorandum will be applied retroactively, with one exception. That is, if the new holding is less favorable to the taxpayer, it generally will not be applied to the period in which the taxpayer relied on the prior holding in situations involving continuing transactions of the type described in CCDM 32.3.

4. If a technical advice memorandum or a technical expedited advice memorandum relates to a continuing action or a series of actions, it is ordinarily applied until specifically withdrawn or until the conclusion is modified or revoked by enactment of legislation, ratification of a tax treaty, or issuance of a United States Supreme Court decision, regulations (temporary or final), a revenue ruling, or other statement published in the Internal Revenue Bulletin. Publication of a notice of proposed rulemaking does not affect the application of a technical advice memorandum or a technical expedited advice memorandum.

5. Generally, a technical advice memorandum or a technical expedited advice memorandum that revokes or modifies a letter ruling, technical advice memorandum, or technical expedited advice memorandum will not be applied retroactively with respect to the taxpayer to whom, or with respect to whom, the ruling or memorandum was originally issued or to a taxpayer whose tax liability was directly involved in such ruling or memorandum if:



1. There has been no misstatement or omission of material facts;

2. The facts subsequently developed are not materially different from the material facts on which the ruling or memorandum was based;

3. There has been no change in the applicable law;

4. The ruling was originally issued with respect to a prospective or proposed transaction; and

5. The taxpayer directly involved in the ruling or memorandum acted in good faith in relying upon the ruling or memorandum and the retroactive revocation would be to the taxpayer’s detriment.


6. A tax practitioner may not obtain the non-retroactive application to one client of a modification or revocation of a ruling or a memorandum previously issued to, or in connection with, another client.

7. When a ruling to a taxpayer or a memorandum involving a taxpayer is revoked with retroactive effect, the technical advice memorandum or technical expedited advice memorandum will, except in fraud cases, set forth the grounds upon which the revocation is being made and the reasons why the revocation is being applied retroactively.

8. See CCDM 37.1 for section 6110 considerations.


**33.2.1.10** **(08-11-2004)**

### Effect of Section 6110 on Technical Advice and Technical Expedited Advice Procedures

1. Section 6110 requires that, subject to deletion of certain information, technical advice memoranda and technical expedited advice memoranda are open to public inspection.


**33.2.1.10.1** **(08-11-2004)**

#### Section 6110 Procedures Applicable to Requests for Technical Advice and Technical Expedited Advice

1. The field or area office submitting a request for technical advice or technical expedited advice must notify the taxpayer of the request and advise the taxpayer to submit a statement of suggested deletions required by section 6110(c) within ten calendar days. The deletion statement will be submitted with the technical advice or technical expedited advice request.

2. If the taxpayer does not submit a deletion statement within the required ten days, the field or area office may decline to submit the request for advice or, if technical advice or technical expedited advice is still required, submit the request for technical advice or technical expedited advice, stating that the taxpayer did not submit a deletion statement after a request had been made for such a statement. Where a request for technical advice or technical expedited advice is received without a deletion statement from the taxpayer, the Associate office will make those deletions that in its judgment are required by section 6110(c). See CCDM 37.1 for additional information on processing technical advice and technical expedited advice requests under section 6110.

3. A technical advice memorandum or a technical expedited advice memorandum that modifies, revokes, supersedes or otherwise affects an earlier memorandum involving the same taxpayer should provide, in the opening or closing paragraph, the date of the earlier memorandum, its control number and TAM or TEAM number, and how it affects the earlier memorandum. An example would be: Technical advice memorandum dated May 15, 1994 (TR-113455-94, TAM #) is modified to the extent it concludes that X is not subject to tax. The TAM or the TEAM number may be obtained from the Disclosure & Litigation Support Branch, Legal Processing Division (Procedure & Administration). The Disclosure & Litigation Support Branch will stamp the subsequent memorandum "Refer to Written Determination No. \_," and write in the number assigned to the earlier memorandum. If the taxpayer requests that the date be deleted for purposes of section 6110, the Associate office attorney should contact the Disclosure & Litigation Support Branch for further instructions.


**33.2.1.10.2** **(08-11-2004)**

#### Section 6110 Procedures Applicable to Issuing Technical Advice and Technical Expedited Advice Issuance

1. Generally, before replying to the request for technical advice or technical expedited advice, the Associate office informs the taxpayer orally or in writing of the material likely to appear in the technical advice memorandum or the technical expedited advice memorandum that the taxpayer proposed be deleted but that the Service determined should not be deleted. If so informed, the taxpayer may submit within ten calendar days any further information, arguments, or other material to support the position that the material should be deleted. The Service attempts, if possible, to resolve all disagreements about proposed deletions before the Associate office replies to the request for technical advice or technical expedited advice; however, the taxpayer does not have the right to a conference to resolve any disagreements about material to be deleted from the text of the technical advice memorandum or the technical expedited advice memorandum. These matters, however, may be considered at any conference otherwise scheduled for the request.

2. Technical advice and technical expedited advice replies from the Associate office that are subject to section 6110 will contain:



   - The technical advice or technical expedited advice transmittal memorandum

   - The technical advice memorandum or the technical expedited advice memorandum

   - Three copies of a Notice of Intention to Disclose, Notice 438

   - A redacted copy of the technical advice memorandum or the technical expedited advice memorandum

   - Instructions for dating the Notice of Intention to Disclose


3. The Associate office attorney and reviewer are responsible for redacting the technical advice memorandum or the technical expedited advice memorandum and preparing the copies (with envelopes addressed for distribution) to be submitted to CC:PA:LPD:DLS.

4. Within 30 calendar days after the date the technical advice memorandum or the technical expedited advice memorandum is mailed from the Associate office, the field or area office must either request reconsideration or furnish to the taxpayer a copy of the technical advice memorandum or the technical expedited advice memorandum, the redacted copy of the memorandum, and a completed Notice of Intention to Disclose. The technical advice or the technical expedited advice transmittal memorandum will not be furnished to the taxpayer and deletions to the technical advice memorandum or the technical expedited advice memorandum will not be discussed with the taxpayer.

5. The Notice of Intention to Disclose sent to the taxpayer will be completed and dated in accordance with the instructions furnished to the requesting office. The date of mailing of the Notice of the Intention to Disclose will be documented and a copy of the Notice (containing the dates inserted by the field or area office) will be forwarded immediately with an accompanying transmittal memorandum to the Disclosure & Litigation Support Branch at the address provided in the technical advice or technical expedited advice transmittal memorandum.

6. Unredacted copies of a technical advice memorandum or a technical expedited advice memorandum can only be provided to individuals whose tax administration duties with respect to that particular case require disclosure.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part33/irm_33-002-001#addtoany "Show all")

A2A