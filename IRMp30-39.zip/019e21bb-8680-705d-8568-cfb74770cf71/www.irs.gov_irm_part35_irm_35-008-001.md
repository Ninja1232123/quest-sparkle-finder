---
url: "https://www.irs.gov/irm/part35/irm_35-008-001"
title: "35.8.1 General Requirements for Tax Court Decisions and Other Final Dispositions | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-008-001#main-content)

- 35.8.1 [General Requirements for Tax Court Decisions and Other Final Dispositions](https://www.irs.gov/irm/part35/irm_35-008-001#idm140463588130848)
  - 35.8.1.1 [Tax Courts Decision](https://www.irs.gov/irm/part35/irm_35-008-001#idm140463601872032)
  - 35.8.1.2 [Supplemental Tax Court Proceedings](https://www.irs.gov/irm/part35/irm_35-008-001#idm140463587455760)
  - 35.8.1.3 [Dismissal Order](https://www.irs.gov/irm/part35/irm_35-008-001#idm140463615045776)
    - 35.8.1.3.1 [Voluntary Dismissals in Whistleblower Proceedings](https://www.irs.gov/irm/part35/irm_35-008-001#idm140463596791840)
  - 35.8.1.4 [Use of Paragraph or Tabular Form](https://www.irs.gov/irm/part35/irm_35-008-001#idm140463605715680)
  - 35.8.1.5 [Only Essential Facts Included](https://www.irs.gov/irm/part35/irm_35-008-001#idm140463597613776)
  - 35.8.1.6 [Each Tax and Each Addition to Tax Separately Stated-Jurisdiction](https://www.irs.gov/irm/part35/irm_35-008-001#idm140463608581936)
  - 35.8.1.7 [Certification of Decision or Dismissal Order](https://www.irs.gov/irm/part35/irm_35-008-001#idm140463596039216)
  - 35.8.1.8 [Review of Petitioners Transcript of Account](https://www.irs.gov/irm/part35/irm_35-008-001#idm140463588150816)
    - 35.8.1.8.1 [Present Status of Petitioners Account](https://www.irs.gov/irm/part35/irm_35-008-001#idm140463588090800)
    - 35.8.1.8.2 [Analysis of Transcript of Account](https://www.irs.gov/irm/part35/irm_35-008-001#idm140463590292336)

# Part 35. Tax Court Litigation

# Chapter 8. Decisions, Orders of Dismissal, and Other Final Judgments

# Section 1. General Requirements for Tax Court Decisions and Other Final Dispositions

* * *

## 35.8.1 General Requirements for Tax Court Decisions and Other Final Dispositions

#### Manual Transmittal

August 15, 2019

#### Purpose

(1) This transmits revised CCDM 35.8.1, Decisions, Orders of Dismissal, and Other Final Judgments; General Requirements for Tax Court Decisions and Other Final Dispositions.

#### Material Changes

(1) CCDM 35.8.1.1 was revised to describe the standard and scope of review in whistleblower proceedings..

(2) CCDM 35.8.12 was revised to merge duplicative paragraphs.

(3) CCDM 35.8.1.3.1 was added to describe the voluntary dismissal process in whistleblower proceedings. In the absence of the statutory requirement to enter a decision deciding a deficiency, the Tax Court applies Federal Rule of Civil Procedure 41(a)(2), which permits dismissal in the sound discretion of the court.

#### Effect on Other Documents

This section supersedes CCDM 35.8.1 dated July 30, 2014.

#### Audience

Chief Counsel

#### Effective Date

(08-15-2019)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**35.8.1.1** **(08-15-2019)**

### Tax Court’s Decision

1. Every decision in every case (except declaratory judgment and section 7436 cases) entered by the Tax Court based upon a settlement stipulation, Rule 155 computation, or findings of fact and opinion of the court, must determine either a deficiency or no deficiency (in transferee cases, a liability or no liability); an overpayment or no overpayment (or in some circumstances, a statutory deficiency and an overpayment or no overpayment), or other appropriate determination within the jurisdiction of the court, such as in interest abatement, collection due process, relief from joint and several liability, whistleblower proceedings, or partnership level proceedings. This determination must be made as to each tax and penalty for each year or period placed in controversy by the pleadings and over which the court has jurisdiction. In transferee cases, the court must determine the liability due from the transferee as well as the interest due on the liability. In section 7436 cases, the court may determine the proper amount of employment taxes. In whistleblower proceedings, the court reviews whistleblower award determinations for abuse of discretion on the administrative record.

2. Normally, if the statutory notice determines a deficiency for a year which is not placed in controversy by the petition, such deficiency is immediately assessed. If such deficiency has not been previously assessed and time for such assessment has not expired, an immediate assessment should be obtained. Also, if the statutory notice determines a penalty which is not specifically put in controversy in the petition, but the penalty is applicable to a tax that has been placed in controversy, this penalty must be included in the settlement or Rule 155 documents as well as in the court’s decision. If a tax is not placed in controversy, but a penalty relating to that tax is placed in controversy, neither the tax nor the penalty may be assessed until the decision is final unless the petitioner executes a waiver for the assessment of these taxes. In other words, tax and related penalty for the same year constitute a single cause of action.

3. In preparing a decision document, special attention must be given to the lead sentence. If the decision is entered pursuant to an opinion of the court, it is critical that the lead sentence read as follows:



|     |
| --- |
| "Pursuant to the opinion of the court filed \[date\], and incorporating herein the facts recited in the respondent’s computation as the findings of the court, it is . . ." etc. |

4. If there are settled issues that were not the subject of the court’s opinion, they are addressed in a separate stipulation filed with the court. The settlement of these issues should not be referred to in the lead sentence of the decision document. A reference to an agreement of the parties in the lead sentence may be used against the Service to deny the ability to appeal the adverse decision, especially if the second page of the decision document does not reserve the right of the parties to contest the correctness of the decision entered. In a case where issues are erroneously referred to in the lead sentence of the decision document as settled, the decision must be revised as part of the record on appeal before an appeal can be taken from the adverse part of the decision. _See_ Exhibit 35.11.1–123. If all of the issues in the case have been settled by the parties and have not been subject to an opinion of the court, the lead sentence in the decision document should read as follows:



|     |
| --- |
| "Pursuant to the stipulation of the parties filed in the above-entitled case, and incorporating herein the facts stipulated by the parties as the findings of the court, \[or "Pursuant to the agreement of the parties . . ." \] it is . . ." etc. |





### Note:



This wording will preclude an appeal from the decision. The wording of the lead sentence is also important because it signals how the decision will be processed by the Legal Processing Division within Procedure & Administration.


**35.8.1.2** **(08-15-2019)**

### Supplemental Tax Court Proceedings

1. After a decision of the Tax Court becomes final and appellate proceedings have been exhausted, the Tax Court has jurisdiction to conduct certain supplemental proceedings. _See_ CCDM 35.1.1.8, **Statutory Interest Determinations**, and T.C. Rule 261, _Proceeding to Redetermine Interest_. _See_ CCDM 35.1.1.11, **Enforcement of Overpayment Decisions**, and T.C. Rule 260, _Proceeding to Enforce Overpayment Determination_. _See_ CCDM 35.1.1.12, **Modification of Decisions in I.R.C. § 6166 Estate Tax Cases**, and T.C. Rule 262, _Proceeding to Modify Decision in Estate Tax Case Involving Section 6166 Election_. **See also** the related rules in the title XXV of the Tax Court Rules of Practice and Procedure.


**35.8.1.3** **(08-11-2004)**

### Dismissal Order

1. In cases closed by a dismissal order of the court for failure to properly prosecute or for lack of prosecution, the court should also make a determination of the deficiency, liability, overpayment, or other determination appropriate to the type of proceeding involved. If the pleadings do not reflect the correct amount in a deficiency case, the Field attorney must file a correct copy of the statutory notice or other computations necessary for the court to make a proper determination in the dismissal order. This is necessary since a dismissal order for failure to properly prosecute or for lack of prosecution is a determination on the merits, and the cause of action cannot be further litigated in another court. In some rare instances, the dismissal order may contain a statement that the court is unable to determine the deficiency due from the petitioner. This type of order, together with the statutory notice, is sufficient to form a basis for assessment. Section 7459(d). In dismissal orders based upon lack of jurisdiction, it is not proper for the court to make a merit determination.


**35.8.1.3.1** **(08-15-2019)**

#### Voluntary Dismissals in Whistleblower Proceedings

1. In deficiency cases, a petitioner may move to withdraw the petition without prejudice. If the Tax Court dismisses the case on a ground other than lack of jurisdiction, section 7459(d) requires that the Tax Court enter a decision deciding that the deficiency is the amount determined by the Secretary. A taxpayer may not withdraw his petition to avoid the entry of decision. However, section 7459(d) only applies to petitions filed to redetermine a deficiency.

2. In the absence of the statutory requirement to enter a decision deciding a deficiency, the Tax Court applies Federal Rule of Civil Procedure 41(a)(2), which permits dismissal in the sound discretion of the court. The Tax Court should grant dismissal unless the defendant will suffer clear legal prejudice. For example, the Commissioner will suffer no prejudice if the taxpayer’s right to petition all courts has expired.

3. The section 7459(d) requirement to enter a decision deciding a deficiency does not apply to whistleblower proceedings. Consequently, the Tax Court applies Federal Rule of Civil Procedure 41(a)(2) when evaluating whether to grant petitioner’s motion to withdraw or for voluntary dismissal.


**35.8.1.4** **(08-11-2004)**

### Use of Paragraph or Tabular Form

1. In preparing a settlement stipulation and decision document, it is preferable to use the paragraph form for cases involving:



   - A deficiency in tax for one, two or three years only

   - A deficiency in tax and addition to the tax for one year

   - In any other case in which the paragraph form would not unduly lengthen such documents


2. The tabular form generally should be used only in deficiency cases where there are a number of years involved, or where there are taxes and penalties of various types for several years. The tabular form must not be used in overpayment cases. The computation of each overpayment of tax and each overpayment of addition to the tax must be separately stated in order for the court to make necessary jurisdictional determinations with respect to each payment. For the same reason, the tabular form must not be used for an overpayment of tax and a deficiency in addition to the tax for the same year.

3. When the tabular form is used for the computation, settlement stipulation, or proposed decision, use extreme care in the terminology and symbols used. Under longstanding conventions used to prepare decision documents, a zero is not used to indicate there is no deficiency in either tax or penalty, since it may be mistakenly interpreted to indicate that the tax or penalty was not at issue in the case. Rather, the term "none" in the tabular form is to be used, which means that the tax or penalty for the indicated year was determined in the statutory notice and/or raised as an issue in the pleadings, and that under the Rule 155 computation or settlement there is no deficiency in tax or penalty for that year. The use of a dash (-) in a column for a tax or penalty means that a tax or penalty for the indicated year was not determined in the statutory notice.


**35.8.1.5** **(08-11-2004)**

### Only Essential Facts Included

1. The Rule 155 computation (first part of statement for court) and the settlement documents must include all necessary facts for the entry of a decision that will make a complete determination of the entire case. Irrelevant or extraneous matters should not be included in such documents. The proposed decision document sets forth the determination of the court as to each tax and penalty, and for each year placed in controversy. Generally, the deficiency to be determined in the decision in a deficiency case is a statutory deficiency as defined by section 6211. Also generally, an overpayment is to be determined in the decision in accordance with the provisions of section 6512(b). Neither the stipulation nor the proposed decision should set forth an overassessment. The court has no jurisdiction over overassessments, only overpayments.

2. In applying these instructions to a particular case, it may be necessary or desirable to include in the separate stipulation document or in the Rule 155 computation statement additional facts not essential to the court’s decision but essential or desirable to close the case administratively or for other purposes. Such nonessential facts should not be included in the decision document or computation fact sheet.


**35.8.1.6** **(07-30-2014)**

### Each Tax and Each Addition to Tax Separately Stated-Jurisdiction

1. Each tax and each addition to tax for each year over which the court has jurisdiction must be separately stated in the Rule 155 computation or settlement stipulation, and decision. This will ensure that the court’s decision will dispose of each tax and addition to tax for each year placed in controversy. Care should be taken to correctly label applicable additions to tax or penalties as prescribed in the Code in decision documents and accompanying papers. In addition, steps must be taken to ensure that the correct Code section(s) specifying the additions to tax or penalties being determined by the court are set forth in the decision documents.

2. If the taxpayer has put in controversy a tax or other item over which the court does not have jurisdiction, the jurisdictional aspects of the case must be disposed of before a decision may be entered by the court. For settled cases, the stipulated decision may be accompanied by an agreed motion to dismiss for lack of jurisdiction and to strike insofar as the case pertains to a tax or addition to tax over which the court does not have jurisdiction. For Rule 155 cases where the jurisdictional element has not been disposed of by the court’s opinion, a motion to dismiss the case, in part, and to strike for the tax or addition to tax over which the court does not have jurisdiction, should be filed simultaneously with the Rule 155 computation. Jurisdictional provisions should not be included in a Rule 155 computation or in the face sheet. These jurisdictional matters should be set out by a separate joint motion (if possible) of the parties. If a joint motion is not practicable, respondent’s motion to dismiss should be filed in which petitioner’s position on the granting of the motion is set forth in accordance with T.C. Rule 50(a).

3. Some (now repealed) time-sensitive penalties require special attention because they cannot be precisely computed until the date the tax is assessed, which will usually be subsequent to the entering of the decision in a docketed case. When the base amount of the deficiency on which such a penalty will be computed can be determined, however, this amount should be stated in the decision document. For example, a decision determining the time-sensitive negligence penalty under former section 6653(a)(2) should state:



|     |
| --- |
| There is an addition to the tax due from the petitioner for the taxable year \[year\], under the provisions of I.R.C.§ 6653(a)(2) in an amount equal to 50 percent of the statutory interest due on $\[amount\]. |

4. These additions apply to returns due to be filed from January 1, 1982, through December 31, 1986. For returns due to be filed between January 1, 1987, and December 31, 1987, this language can be adapted to the similar provisions of sections 6653(a)(1)(B) and (b)(1)(B). Alternatively, additions to the tax can be shown in tabular form. See Exhibits 35.11.1–124 and 35.11.1–125. In addition, the language above can be substituted for the language relating to the penalties in Exhibit 35.11.1–126. This language is not necessary for additions to tax imposed on returns due after December 31, 1987. In 1987, Congress repealed the time-sensitive component of the sections 6653(a) and 6653(b) additions to tax. The accuracy-related penalties enacted in 1989 (sections 6662 and 6663) also have no time-sensitive component.

5. For settlement purposes, the operative amount of the deficiency may be determined in any reasonable manner, _e.g._, by percentage estimation or exact computation of tax due to the negligent or fraudulent items. On the other hand, in cases decided by the court, the court will require findings of fact as to which portion of the deficiency is due to negligence or fraud if those components are necessary to the court’s determination in the case. The Field attorney should attend to this matter on brief and, further, insure that the opinion makes clear which portion of the deficiency is due to negligence or fraud.

6. Because the Tax Court does not have jurisdiction to determine the interest payable on tax deficiencies or overpayments except in post-decision supplemental proceedings, it is not appropriate to include determinations of deficiency interest in a Rule 155 computation, settlement stipulation, or decision. The rate of interest is set by statute on all deficiencies and overpayments and is not a proper subject for disposition by settlement. Care should be taken to include prescribed stipulations acknowledging that interest will be assessed on the deficiency or overpayment as required by law in all settlement decision documents. In cases in which an overpayment is shown on a decision document, attorneys should also include a statement providing that the overpayment does not include any underpayment interest liability for the relevant taxable period. See CCDM 35.8.2.5 (3).


**35.8.1.7** **(08-11-2004)**

### Certification of Decision or Dismissal Order

1. The court’s decision or order of dismissal is the final order closing the case. When the decision or order becomes final, it generally cannot thereafter be vacated or modified. The court’s decision or order, together with the administrative computation upon which it is based, must form the basis for the administrative closing of the case by the assessment and collection of any amount due from the petitioner, or the refund or credit of any overpayment due to the petitioner.

2. On the legal file copy of each decision and dismissal order not prepared or approved by respondent prior to entry, the Field attorney will sign and date a certification to the effect that the decision or order is proper and that a correct decision or order has been entered in the case. The stamped certification will be in ten-point letters and read as follows:



|     |     |
| --- | --- |
| a. For decisions: "Decision is correct and in accord with stipulation, opinion or Tax Ct. R. 155 computation. " |
| \\_\\_\\_\_\_\_\_\_\_\_\_\_<br> (Attorney) | \\_\\_\\_\_\_\_\_\_\_\_\_\_<br> (Date) |
| b. For dismissal orders: " Dismissal order has determined the correct deficiency or overpayment." |
| \\_\\_\\_\_\_\_\_\_\_\_\_\_<br> (Attorney) | \\_\\_\\_\_\_\_\_\_\_\_\_\_<br> (Date) |
| c. It is the responsibility of the reviewer to see that the certification is made by the attorney immediately upon receipt of the decision or dismissal order. It is recommended that a CATS suspense event be created for the completion of the certification no later than 15 days after entry of the decision or dismissal order. |

3. For cases in which the files are in an Associate office due to a pending appeal recommendation, the Field attorney, immediately upon receipt of the decision or order, will certify such decision or order and forward it to the Associate Chief Counsel (P&A).

4. A separate certification is not required in settled cases or Rule 155 cases when the court adopts and enters the proposed decision submitted by the respondent. In these instances, the initials of the attorney and reviewer on the initialed copy of the proposed decision will be deemed a certification that the decision is proper and correct. A separate certification must be made in all settled or Rule 155 cases when the court prepares its own decision or does not adopt the decision proposed by the respondent.


**35.8.1.8** **(08-11-2004)**

### Review of Petitioner’s Transcript of Account

1. This sub-section discusses the review of petitioner’s transcript of account.


**35.8.1.8.1** **(08-11-2004)**

#### Present Status of Petitioner’s Account

1. The decision or final order of the court must make all of the necessary determinations to permit the administrative officials to close the case by assessment and collection of the amount due from the petitioner, or to refund or to credit the amount of any overpayment due to the petitioner. When the Tax Court’s decision or dismissal order becomes final, it generally cannot thereafter be vacated or modified to correct a mistake in the amount of tax to be assessed and collected or to correct the amount of overpayment of tax to be credited or refunded to the petitioner. _See_ section 7481. Thus, in cases closed by a decision of the court upon the basis of a settlement stipulation or Rule 155 computation, the attorney needs a transcript of the taxpayer’s account as reflected on Service records. Appeals has the primary responsibility in settled cases for determining the accuracy and completeness of the transcript of account. Appeals should also be requested to secure an updated transcript of account if the Field attorney has a substantial question concerning the status of a petitioner’s account. The legal file for all settled or Rule 155 cases must contain a copy of the transcript of account relied upon in the settlement stipulation or Rule 155 computation.

2. For Rule 155 cases, an updated transcript of account will be obtained:



   - In overpayment and jeopardy assessment cases

   - In cases where there is an indication that interim payments may have been made by the petitioner since the date of the prior statement of account

   - Where it appears that the prior statement of account is erroneous

   - Where otherwise necessary to prepare a correct Rule 155 computation


3. The determination of whether to obtain an updated statement of account is the Field attorney’s primary responsibility, with the assistance of the Appeals auditors. When forwarding the court’s opinion to Appeals for a Rule 155 computation, it is often desirable to indicate whether an updated statement of account is needed, or to request that the auditors consider the necessity for one in view of the court’s opinion, the record at the trial, or other information which has come to the attorney’s attention.

4. Ordinarily, there is no need for to request a "certified " transcript of account. Such a request increases the time needed to secure the transcript. But if it is anticipated that the petitioner will contest, at trial, any date or amount of any item on the transcript, Appeals should be directed to obtain a certified transcript of account. The attorney should then offer the certified transcript in evidence at the trial.


**35.8.1.8.2** **(08-11-2004)**

#### Analysis of Transcript of Account

1. The following material uses the term deficiency. Worker classification employment tax cases under section 7436 do not involve a deficiency (as defined in section 6211). In addition, other types of proceedings in the Tax Court may not involve statutory deficiencies, such as interest abatement, collection due process, and relief from joint and several liability cases. The principles set forth below apply to section 7436 cases as if the section 7436 notice of determination were a notice of deficiency. Transcripts may also be necessary to prepare decision documents in other non-deficiency cases.

2. After filing a petition with the Tax Court, many petitioners pay all or part of the asserted deficiency to stop the running of interest. Section 6213(b)(4) authorizes the assessment of such payments without a specific assessment waiver. Under Rev. Proc. 84–58, 1984–2 C.B. 501, however, post-statutory notice of deficiency remittances will not necessarily be assessed. Such payments will stop the running of interest and any resultant overpayment will bear interest, regardless of whether the tax has been assessed. The attorney must consider the advance payment of asserted deficiencies, whether or not assessed. Such payments should be reflected on the transcript of account.

3. In making a partial payment of assessed tax, penalty, and interest, a taxpayer may specifically direct the manner of the application of the payment. The Service Center should apply such payment as allocated by the taxpayer. In the absence of an allocation by the taxpayer, Rev. Proc. 2002-26, 2002-1 C.B. 746 provides how to apply the partial payment. Such payment is applied first to tax, penalty, and interest, in that order, for the period that the service determines will best serve its interest, and then to tax, penalty, and interest, in that order, for the next period so determined, until the total payment is applied. Advance payments of asserted deficiencies being contested in the Tax Court, in the absence of a specific allocation by the taxpayer, should be applied as provided in Rev. Proc. 2002-26, as described. Except in Joint Committee cases, such advance payments of tax, penalties, and interest need not be assessed in accord with Rev. Proc. 84–58, 1984–2 C.B. 501.

4. The Field attorney should become familiar with the terminology and symbols used by the Service Center to reflect the status of the petitioner’s account on the transcript of account. The attorney should check the transcript of account when preparing the settlement stipulation or reviewing the Rule 155 computation for the following items:



1. The assessment of original or deficiency tax, penalty, or interest as to each year or period involved in the Tax Court case. The penalty should be segregated as to kind, _i.e._, fraud, delinquency, negligence, etc. Care should be exercised in transferee cases to determine what part of the assessed interest is transferee liability and what part is transferee interest.

2. The abatement, credits and refunds of tax, penalty and interest are properly accounted for.

3. The date and amount of each payment for each year involved.

4. The transcript of account indicates that any voluntary remittances made by the taxpayer toward the asserted deficiency, are properly accounted for.

5. The transcript of account should reflect all payments, including tax withheld and estimated tax payments, made by the taxpayer for the year or years involved.

6. Any other factor pertaining to the taxpayer’s account on Service records or on the return which should be considered by the attorney.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-008-001#addtoany "Show all")

A2A