---
url: "https://www.irs.gov/irm/part37/irm_37-001-002"
title: "37.1.2 Disclosure of Information | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part37/irm_37-001-002#main-content)

- 37.1.2 [Disclosure of Information](https://www.irs.gov/irm/part37/irm_37-001-002#idm139624334347904)
  - 37.1.2.1 [Purpose and Background](https://www.irs.gov/irm/part37/irm_37-001-002#idm139624307546512)
  - 37.1.2.2 [Disclosure to Committees and Members of Congress](https://www.irs.gov/irm/part37/irm_37-001-002#idm139624308627008)

    - 37.1.2.2.1 [Disclosure to Members of Congress](https://www.irs.gov/irm/part37/irm_37-001-002#idm139624315457312)

  - 37.1.2.3 [Other Provisions of Section 6103](https://www.irs.gov/irm/part37/irm_37-001-002#idm139624314940656)
  - 37.1.2.4 [Other Internal Revenue Code Sections](https://www.irs.gov/irm/part37/irm_37-001-002#idm139624302027904)
  - 37.1.2.5 [Freedom of Information Act (FOIA) and Privacy Act of 1974](https://www.irs.gov/irm/part37/irm_37-001-002#idm139624284192224)
  - 37.1.2.6 [Matters under Consideration of Field Offices](https://www.irs.gov/irm/part37/irm_37-001-002#idm139624314897568)
  - 37.1.2.7 [Publications](https://www.irs.gov/irm/part37/irm_37-001-002#idm139624315427936)
  - 37.1.2.8 [Section 6110 Index](https://www.irs.gov/irm/part37/irm_37-001-002#idm139624334544784)
  - 37.1.2.9 [Jurisdiction over Coordination of Litigation Involving DisclosureIssues](https://www.irs.gov/irm/part37/irm_37-001-002#idm139624280101296)

    - 37.1.2.9.1 [Coordination of Section 7431 Unauthorized Disclosure or InspectionSuits](https://www.irs.gov/irm/part37/irm_37-001-002#idm139624294334224)

  - 37.1.2.10 [Disclosure of Other Material](https://www.irs.gov/irm/part37/irm_37-001-002#idm139624280097376)
  - 37.1.2.11 [Testimony Authorizations](https://www.irs.gov/irm/part37/irm_37-001-002#idm139624293695088)

# Part 37. Disclosure

# Chapter 1. Sections 6110 and 6103 of Title 26

# Section 2. Disclosure of Information

* * *

## 37.1.2 Disclosure of Information

**37.1.2.1** **(08-11-2004)**

### Purpose and Background

1. These instructions provide procedures relating to the disclosure of information (including classified and confidential material) to persons outside the Service.

2. IRM 11.3, Disclosure of Official Information, provides procedural and technical guidance with respect to disclosure of official information.

3. Section 6103 provides that returns and return information shall be confidential and may not be disclosed except as authorized by the Code. The term "return information" includes any information received or prepared by Service employees with respect to a return or with respect to the determination of the existence or possible existence of liability of any person for any tax, penalty, or interest. The term also includes any part of a written determination or related background file document that has been redacted in accordance with section 6110(c) or (i). Return information also includes advanced pricing agreements and closing and similar agreements. See section 6103(b)(2)(C) and (D).

4. Section 1905 of Title 18 provides criminal penalties for the disclosure "in any manner or to any extent not authorized by law" of any information coming to Federal officers or employees relating to the amount or source of any income, profits, losses, expenditures, operations, processes, style of work, etc., of any person, firm, partnership, corporation, or association.

5. Sections 7213 and 7213A provide criminal penalties for the willful unauthorized disclosure or inspection (respectively) of returns and return information. Section 7431 provides civil penalties for unauthorized disclosure or inspection of returns and return information.

6. The Privacy Act, 5 U.S.C. § 552a, prohibits nonconsensual disclosures of agency records maintained on an individual except for those disclosures permitted by 5 U.S.C. § 552a(b)(1) - (12).

7. Questions relating to disclosure matters arising within the Office of Chief Counsel should be referred to the Assistant Chief Counsel (DPL). Questions which involve disclosures of returns or return information in personnel matters pursuant to section 6103(l)(4) will be coordinated with the Office of Associate Chief Counsel, General Legal Services (GLS).


**37.1.2.2** **(08-11-2004)**

### Disclosure to Committees and Members of Congress

1. Disclosure of returns and return information may be made to the following committees upon written request of the chairpersons of these committees:



   - House Ways and Means Committee

   - Senate Finance Committee

   - Joint Committee on Taxation or

   - any other committee specifically authorized by resolution of the House or Senate (or, in the case of joint committees, by concurrent resolution) to inspect such returns or return information.


2. Disclosure may also be made to the Chief of Staff of the Joint Committee on Taxation, upon that person's written request.


**37.1.2.2.1** **(08-11-2004)**

#### Disclosure to Members of Congress

1. Individual Members of Congress have no special statutory rights to obtain returns or return information. Members are at times asked by constituents to provide assistance in securing rulings or obtaining other information from the Service. In determining what confidential information, if any, can be provided to the Member, a determination must be made as to what extent the taxpayer has consented to disclosure to the Member, or to what extent the taxpayer has designated the Member to receive such information on behalf of the taxpayer. Section 6103(c) governs disclosure of returns and return information to the designee of a taxpayer. See Treas. Reg. § 301.6103(c)-1. Nothing herein would preclude giving general information (as opposed to returns or return information) to an individual Member upon the Member's request for general information.

2. Following are examples illustrating the Office of Chief Counsel's practices in handling inquiries from Members that contain potential disclosure issues. If there is any doubt whether return information should be disclosed to a Member, the Assistant Chief Counsel (DPL) should be consulted.



|     |
| --- |
| _**Example a.**_ A taxpayer writes to the Service concerning a tax issue with a notation that a copy of the correspondence is being sent to a Member. There is no indication that the taxpayer has provided any additional communication to the Member of Congress. Subsequently, the Member submits the copy of the taxpayer's letter to the Service and requests information concerning the matter. Since there is no indication of a written request by the taxpayer for, or consent by the taxpayer to, disclosure to the Member, the Service may not provide any return information to the Member. The Member should be advised accordingly and informed that the Service will reply directly to the taxpayer. |
| _**Example b.**_ A taxpayer writes to the Service concerning a tax issue. The taxpayer subsequently writes to a Member of Congress asking the Member to secure information from the Service regarding the taxpayer's letter. The taxpayer sets forth in the letter to the Member the pertinent facts of the transaction upon which the letter is premised. The Member submits to the Service a copy of the taxpayer's letter, and requests information concerning the matter. In this case, there appears little doubt that the taxpayer has requested the Member to act on the taxpayer's behalf. Accordingly, the Service can provide return information to the Member, but only to the extent necessary for the Member to comply with the taxpayer's request for information or assistance. This could include a copy of the response letter. As provided in section 6103(c), the Service shall not disclose return information if it is determined that disclosure would seriously impair Federal tax administration. For further information, see Treas. Reg. § 301.6103(c)-1. |
| _**Example c.**_ A taxpayer writes a letter to a Member of Congress asking the Member to obtain information relating to the status of a request for a written determination. The Member of Congress furnishes to the Service this letter (or a copy) from the taxpayer and requests information regarding the present status of the case. The status may be given in general terms (e.g., awaiting consideration, under study, in review, etc.). If the date the written determination will be issued is requested, the approximate date it is expected to be issued will be given if it can be ascertained with reasonable accuracy. The fact that a case has been referred to another area within the Office of Chief Counsel may be disclosed. The name of the particular person or specific office where the case is pending _will not_ be released. |
| _**Example d.**_ A taxpayer writes a letter to a Member of Congress asking the Member to obtain information relating to the status of a request for a written determination. If the Member does not furnish the letter from the taxpayer, no information regarding the taxpayer's request to the Service may be disclosed to the Member because status information is "return information" within the meaning of section 6103. Therefore, even affirmation or denial that the taxpayer has a pending request for a written determination may not be made. |
| _**Example e.**_ A taxpayer contacts a Member of Congress to seek aid in having a case expedited by processing it ahead of regular order. The taxpayer must submit a written request to the Associate Chief Counsel setting forth the reasons that justify such action; such requests are resolved on their merits. In these cases, the Member is advised of this rule. The case is not taken out of order merely upon a congressional request. |


**37.1.2.3** **(08-11-2004)**

### Other Provisions of Section 6103

1. Section 6103 also provides for the disclosure of certain returns and return information in other circumstances. Discussed herein are some of those circumstances likely to arise in the Office of Chief Counsel. Guidance may be sought as necessary from the Assistant Chief Counsel (DPL). See also IRM 11.3, Disclosure of Official Information, for additional information.

2. Disclosure may be made to such person as the taxpayer may designate in a request for, or consent to, such disclosure. The procedures for the disclosure of information in response to a written and nonwritten request or consent are found at Treas. Reg. § 301.6103(c)-1. The Service can refuse to disclose return information to such a designee, however, if it is determined that the disclosure would seriously impair Federal tax administration. See section 6103(c).

3. Disclosure may be made, upon written request, to persons having a material interest as described in section 6103(e). The Service can refuse to disclose return information to any person having a material interest if it is determined that such disclosure would seriously impair Federal tax administration. See section 6103(e)(7).

4. Disclosures are permissible to officers and employees of the Department of the Treasury when required for the performance of their official tax administration duties. See section 6103(h)(1).

5. In general, returns or return information may not be disclosed to the Department of Justice for purposes of tax administration unless the taxpayer is or may be a party to a judicial proceeding (or the proceeding arose out of, or in connection with, determining the taxpayer's civil or criminal liability, or the collection of such civil liability in respect to any tax imposed under this title), the treatment of an item reflected on such return is or may be directly related to the resolution of an issue in the proceeding, or if the information relates or may relate to a transactional relationship between the taxpayer and a party to the proceeding. See section 6103(h)(2).


**37.1.2.4** **(08-11-2004)**

### Other Internal Revenue Code Sections

1. Section 6104 permits public inspection of approved applications for tax exempt status of organizations described in sections 501(c) and (d), or the notice status of an organization filed under section 527(i). Certain information pertaining to 501(c) or (d) and 527 organizations may not be required to be disclosed or made available for public inspection under section 6104.

2. Section 6105(a) provides generally "that tax convention information shall not be disclosed." Tax convention information includes any agreement entered into with the competent authority of a foreign government; any application for relief under a tax convention; any background information related to the agreement or application for relief; any document implementing an agreement; and, any other information exchanged under the agreement that is treated by the agreement as confidential or secret. The Associate Chief Counsel (International), Branch 1, should be consulted with respect to issues arising from the treatment of information received under a tax convention.

3. In the event a Service or Office of Chief Counsel employee is requested to provide evidence or an affidavit to a foreign country, see CCDM 34.9.1.3(7).


**37.1.2.5** **(08-11-2004)**

### Freedom of Information Act (FOIA) and Privacy Act of 1974

1. For procedures relating to implementation of the FOIA, see CCDM 30.11.

2. For procedures implementing the Privacy Act, 5 U.S.C. § 552a, see CCDM 37.2.1.


**37.1.2.6** **(08-11-2004)**

### Matters under Consideration of Field Offices

1. National office Counsel employees shall not discuss with the taxpayer matters under consideration by a field office unless the specific matter relates to a ruling request by the taxpayer, a request for technical advice, or a Chief Counsel advice that involves the taxpayer which is pending in that professional employee's office. The national office attorney should not contact the taxpayer with respect to a Chief Counsel advice without first contacting the field attorney.


**37.1.2.7** **(08-11-2004)**

### Publications

1. Publications that are designated "Official Use Only" may not be given or the contents disclosed to persons outside the Service by employees. Requests for such documents will be handled in the same manner as requests for records under the FOIA. See CCDM 30.11 and IRM 11.3.12, Classification of Documents.


**37.1.2.8** **(08-11-2004)**

### Section 6110 Index

1. Publication 1078, the Section 6110 Index, is the official publication for the release of written determinations to the public under section 6110. The Index is published each Friday and is available to the public from the Freedom of Information Reading Room, and at www.irs.gov/foia.

2. The Section 6110 Index is arranged by Code section with various identifying subheadings. Each written determination is assigned a 7-digit ruling number that appears on each written determination published and is referenced to specific Code sections for inclusion in the Index. The Section 6110 Index is cumulated on a weekly basis and a new Index is initiated each quarter. The Section 6110 Index in each issue is followed by all the written determinations scheduled for public inspection for that week.


**37.1.2.9** **(08-11-2004)**

### Jurisdiction over Coordination of Litigation Involving Disclosure Issues

1. The Associate Chief Counsel (P&A) is responsible for coordinating litigation in disclosure matters. The work in this area is performed by attorneys in the office of the Assistant Chief Counsel (DPL). This responsibility extends to all litigation matters that involve alleged improper inspection or disclosure of returns and return information (section 7431), the FOIA (5 U.S.C. § 552), and the Privacy Act (5 U.S.C. § 552a). See also CCDM 37.2.1.1 and CCDM 37.2.2.

2. Any litigation received by a field office that involves solely disclosure issues should be immediately referred to the Assistant Chief Counsel (DPL) for handling through the Technical Services Support Branch. The complaint should be sent (or faxed at (202) 622-4817) to the Technical Services Support Branch (TSS) for case opening. In the event of a short deadline for response to a complaint, the complaint can also be faxed to DPL at (202) 622-6292.

3. In any litigation cases where disclosure issues are raised along with other issues, DPL will have the responsibility for presenting the Office of Chief Counsel's views on the disclosure issues to the Department of Justice. To this end, _as soon as the complaint is received in the field office_, a copy of the complaint should be express mailed or faxed (at (202) 622-4817) to TSS in IR 5329 and to the Assistant Chief Counsel (DPL) at (202) 622-6292.



### Note:



The DPL attorney will coordinate with the field attorney assigned to the case.


**37.1.2.9.1** **(08-11-2004)**

#### Coordination of Section 7431 Unauthorized Disclosure or Inspection Suits

1. If the complaint alleges jurisdiction under section 7431, the opening entry in the CASE-MIS database must include the dollar amount of damages claimed by the plaintiff(s). If the complaint does not state the amount of damages claimed with any particularity, the DPL attorney shall estimate the maximum potential liability from the facts at hand. If, after investigation of the facts, or discovery between the parties, the facts reveal that the potential liability is different from the amount first entered in the database, the attorney should change the amount to reflect current potential liability.

2. DPL attorneys are to check regularly, no less than quarterly, as to the status of the pending litigation with the Tax Division trial counsel and specifically note the contacts in the legal file.

3. If a damages claim is based on multiple legal theories including section 7431, and more than one Counsel function is assigned to work on the case as a result, the attorney with primary responsibility for the damages aspect of the litigation must ensure coordination with the other Counsel offices, as appropriate, and place in the primary case file a statement of which attorney will provide outcome notification to the Deputy Chief Counsel (Operations).

4. For all complaints alleging an unauthorized inspection or disclosure of returns or return information, the DPL attorney is to send an information copy of the complaint to Counsel for the Treasury Inspector General for Tax Administration (TIGTA).

5. Memorandum to the Service. Upon receipt of a decision involving an unauthorized inspection or disclosure claim for damages under section 7431, DPL attorneys must ensure that the following steps are taken with regard to giving notice to affected Service offices:



1. Notify appropriate Service management of the outcome, whether the Government wins or settles on a favorable basis, or whether the result is a loss or settlement adverse to the Government's position.

2. Include in the notice a statement of the dollar amount of damages awarded or agreed to, when the result is a loss or settlement adverse to the Government's position.

3. Advise appropriate Service management of the Treasury Department standards governing referral to TIGTA (see Treasury Order 115-01 www.treas.gov/regs/to115–01.htm).

4. Provide a recommendation as to whether, if the case has not previously been referred to TIGTA, a referral is appropriate in light of the outcome of the case.


6. If an Office of Chief Counsel employee has been found to have violated any of the provisions of section 6103, prepare notification to the Deputy Chief Counsel (Operations) of the background and outcome of the damages in litigation.


**37.1.2.10** **(08-11-2004)**

### Disclosure of Other Material

1. For treatment of printed manual material, see IRM 11.3.12.4.1.

2. For treatment of Law Enforcement Manual material, see IRM 11.3.12.4.3.

3. For treatment of training material, see IRM 11.3.12.5.


**37.1.2.11** **(08-11-2004)**

### Testimony Authorizations

1. For information on what situations require the preparation of testimony authorizations, who should prepare the authorization, and who has signature authority, see CCDM 34.9.1.1.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part37/irm_37-001-002#addtoany "Show all")

A2A