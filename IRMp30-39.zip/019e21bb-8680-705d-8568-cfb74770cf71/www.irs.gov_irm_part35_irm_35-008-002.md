---
url: "https://www.irs.gov/irm/part35/irm_35-008-002"
title: "35.8.2 Settlement Documents | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-008-002#main-content)

- 35.8.2 [Settlement Documents](https://www.irs.gov/irm/part35/irm_35-008-002#idm140689619594800)
  - 35.8.2.1 [Preparation of Decision Documents](https://www.irs.gov/irm/part35/irm_35-008-002#idm140689634309056)
  - 35.8.2.2 [Forms of Stipulation Documents](https://www.irs.gov/irm/part35/irm_35-008-002#idm140689611262240)
  - 35.8.2.3 [Claim for Increased Deficiency or Alternative Penalty](https://www.irs.gov/irm/part35/irm_35-008-002#idm140689588088672)
  - 35.8.2.4 [Waiver Paragraph](https://www.irs.gov/irm/part35/irm_35-008-002#idm140689598374608)
  - 35.8.2.5 [Interest Paragraphs in Stipulated Decision Documents](https://www.irs.gov/irm/part35/irm_35-008-002#idm140689585817232)
  - 35.8.2.6 [Preparing Decision Documents for Cases Involving Claims for AttorneysFees Under Section 7430](https://www.irs.gov/irm/part35/irm_35-008-002#idm140689605621040)
  - 35.8.2.7 [Settlement Documents for "S" Cases](https://www.irs.gov/irm/part35/irm_35-008-002#idm140689602366000)
  - 35.8.2.8 [Review and Processing Settlement Documents](https://www.irs.gov/irm/part35/irm_35-008-002#idm140689599633312)

    - 35.8.2.8.1 [Processing in Field Office](https://www.irs.gov/irm/part35/irm_35-008-002#idm140689590018624)
    - 35.8.2.8.2 [Responsibility of Attorney and Review by Reviewer](https://www.irs.gov/irm/part35/irm_35-008-002#idm140689588089088)
    - 35.8.2.8.3 [Filing and Lodging Documents](https://www.irs.gov/irm/part35/irm_35-008-002#idm140689598331680)

# Part 35. Tax Court Litigation

# Chapter 8. Decisions, Orders of Dismissal, and Other Final Judgments

# Section 2. Settlement Documents

* * *

## 35.8.2 Settlement Documents

**35.8.2.1** **(08-11-2004)**

### Preparation of Decision Documents

1. As a general rule, the decision document will be prepared by Appeals, executed by the petitioner, and then transmitted by Appeals to Field Counsel. Exceptions exist where the case involves complexities that require unusual considerations in the drafting of the decision document or related documents. Examples are cases involving:



01. Net operating loss carrybacks

02. Tentative carryback cases

03. Closing cases without considering tentative carryback allowances

04. Jeopardy assessments

05. Prior unpaid assessments

06. Excessive claims for withholding tax or estimated tax payments

07. Overpayments

08. Transferee or fiduciary liabilities

09. Relief from joint and several liability

10. Imposition of accumulated earnings tax under section 531

11. Other complex matters upon request by Appeals

12. Collection due process cases

13. Abatement of interest cases

14. TEFRA cases

15. Employment taxes under section 7436.


2. Also, even though Appeals may prepare decision documents and have them executed by or on behalf of petitioners, it is the Field attorney’s responsibility to assure that only correct decision documents are filed with the court. Thus, every decision document must be carefully reviewed for form and accuracy by the Field attorney before submission to the court.


**35.8.2.2** **(08-11-2004)**

### Forms of Stipulation Documents

1. For most cases solely involving deficiencies or liabilities for taxes or penalties, including employment taxes in section 7436 cases, the form of the settlement document will be a combination stipulation and decision. This is one document executed by or on behalf of the parties. It is submitted to the court, and, upon execution by the judge, becomes the decision of the court. Deficiency or liability cases which have complicated factors may require the filing of a separate stipulation document and the submission to the court of a decision document. For specific rules regarding decision documents in section 7436 cases, _see_ CCDM 35.8.5.11.

2. In more complex cases involving overpayments in taxes or penalties, both overpayments and deficiencies, or other special circumstances, the parties execute and file with the court a separate settlement stipulation setting forth the essential factors and basis upon which the court may enter an appropriate decision. The parties will also prepare and submit to the court a separate proposed decision which is in accord with the stipulation, for the convenience of the court. The proposed decision recites that it is in accord with the stipulation and includes a stipulation of the parties that the court may enter the decision.

3. If the parties cannot agree on the wording or contents of a proposed decision but the case is otherwise settled in all respects, the taxpayer should be requested to execute a separate settlement stipulation to be filed with the court. In such cases, the Field attorney should consider filing a motion for entry of decision, including a proposed decision as an exhibit. This motion may be filed either with or subsequent to the filing of the settlement stipulation.

4. The settlement exhibit forms herein set forth the required format for separate stipulation documents, combined stipulation and decision documents, and separate decision documents. The exhibits are not all-inclusive, and the attorney and the reviewer must determine the specific form and contents necessitated by the facts and circumstances of each case. Each type of settlement document has definite requirements. For example, the decision portion of the combined stipulation and decision document must provide that the decision is pursuant to agreement of the parties, as opposed to pursuant to an opinion of the court. Also, when a separate stipulation is filed, the proposed decision must incorporate therein the facts stipulated by the parties as the findings of the court. Further, the separate stipulation must embody all of the necessary facts and the basis upon which an adequate legal decision can be entered under the requirements of the appropriate internal revenue laws. Likewise, the proposed decision, either in a separate document or a combined document, must make the necessary determination required by the appropriate internal revenue laws. These illustrations are not all-inclusive, but merely illustrate principles to be used in the drafting of these documents.


**35.8.2.3** **(08-11-2004)**

### Claim for Increased Deficiency or Alternative Penalty

1. Unless a claim for increased deficiency is made, the stipulated amount of deficiency in tax or penalty for each year cannot be in excess of the tax deficiency or addition to tax determined in the statutory notice of deficiency. It is preferable that a claim for the increased deficiency be made in an answer or an amended answer. If it has not been previously made, the stipulation should contain a statement that: "Claim is made for the increased deficiency in tax (or addition to the tax) in the amount of $\[amount\] for the taxable year \[year\], pursuant to the provisions of I.R.C. § 6214(a) " . Likewise, if one penalty is included in the stipulation in lieu of another penalty in the statutory notice, and that penalty has not been previously claimed in the answer, a claim for the new penalty must be included in the stipulation. _See_ Exhibit 35.11.1–127.


**35.8.2.4** **(08-11-2004)**

### Waiver Paragraph

1. In every case in which a deficiency or a liability (including the proper amount of employment tax in section 7436 cases) is stipulated, the separate stipulation document or the stipulation part of the combined stipulation and decision document should contain a paragraph waiving the restrictions on the assessment and/or collection of the deficiency or liability, plus interest. The waiver paragraph is unnecessary and may be omitted only if no further amount, including interest, is to be either assessed or collected from the petitioner. This paragraph is a nonoperating paragraph insofar as the decision of the Tax Court is concerned. Therefore, no essential fact which must be stipulated to form the basis of the court’s decision, or which is an integral part of the court’s decision, should be included in this paragraph. The purpose of the waiver paragraph is twofold: to enable the Service to assess and/or collect the tax and penalty determined in the decision, together with interest thereon, without waiting for the decision to become final under the provisions of the internal revenue laws; and to avoid any misunderstanding at a later date as to the amounts to be collected under the terms of the settlement, whether such amounts involve a statutory deficiency or liability, a deficiency to be assessed, or unpaid portions of prior assessments. For specific rules regarding decision documents in section 7436 cases, _see_ CCDM 35.8.5.11.

2. The exhibits illustrate different wordings of the waiver paragraph to conform with the facts set forth in the form. Extreme care must be used in the wording of the waiver paragraph to fit the specific facts of the case being settled.

3. Some of the special circumstances which require a careful wording of the waiver paragraph are as follows (For specific rules regarding the waiver paragraph in section 7436 cases, _see_ CCDM 35.8.5.11):



1. In deficiency cases, the waiver paragraph provides for waiving the restrictions on the assessment of the tax (and additions to the tax), plus statutory interest. In transferee and personal liability cases, however, the waiver is on the assessment and collection of the liability, plus interest as provided by law. The interest provisions in the waiver paragraph in transferee and personal liability cases are not a substitute for, but are in addition to, the mandatory requirements that the decision of the Tax Court must determine the amount of the liability and make a determination as to interest.

2. In cases involving both tax and penalty, the language to be used to specify the deficiencies is deficiencies in tax and addition to the tax or penalty, as labeled in the relevant Code section imposing the addition or penalty.

3. Singular terminology is used for a single deficiency or liability, and plural terminology is used where there is more than one deficiency or liability.

4. The term deficiency or deficiencies is generally used when the tax involved is that of the petitioner, and the term liability or liabilities is always used in transferee and fiduciary liability cases, and in other post-assessment proceedings not involving a statutory deficiency, such as interest abatement, collection due process, and spousal relief cases.

5. If the deficiency or liability has been paid in full, but not assessed, the waiver paragraph will only be for the assessment of the deficiency or liability. Likewise, if the deficiency or liability has been assessed, but not paid, the waiver will only be for the collection of the deficiency or liability. If the entire deficiency or liability stipulated, including statutory interest, has been assessed and paid, the waiver paragraph may be omitted.

6. Generally, in jeopardy assessment cases, the waiver paragraph provides only for collection but not for assessment. The settled deficiency is usually less than the previous jeopardy assessment amount. If, however, the stipulated deficiency is in an amount greater than the tax or penalty jeopardy assessment amount, the waiver paragraph will provide for the assessment and collection of the deficiency in tax or penalty to be assessed, and a waiver on the collection of the amount of the deficiency in tax or penalty previously assessed as a jeopardy assessment.

7. Prior unpaid assessment and interim assessment cases are similar to jeopardy assessment cases. The waiver paragraph must cover the assessment and collection of any remaining amounts of the deficiency or liability to be assessed and a waiver on the collection of the unpaid portion of the deficiency or liability previously assessed.

8. In cases in which there are stipulated both a statutory deficiency and an overpayment, the waiver paragraph must cover the assessment of the statutory deficiency or liability.

9. If the petitioner objects to the inclusion of the waiver paragraph, and the Field attorney and the reviewer agree that the settlement should nevertheless be accepted, the stipulation without the paragraph may be signed and filed. In such instances, however, counsel must ensure that the assessment is made promptly when the restrictions on assessment expire. In many cases, only 60 days may remain to make a timely assessment. Even when the waiver paragraph is omitted, petitioner must acknowledge in a stipulation that statutory interest will be assessed on the deficiency as provided by law.


**35.8.2.5** **(08-11-2004)**

### Interest Paragraphs in Stipulated Decision Documents

1. The Service does not settle Tax Court cases by waiving statutory interest assessments. In every case in which a deficiency or an additional liability is stipulated, it must be made clear to petitioners, and documented, that the Service will not settle the case without petitioners acknowledging that interest will be computed and assessed as provided by a law. Accordingly, the separate stipulation document or the stipulation part of the combined stipulation and decision document should contain the following paragraph:



|     |
| --- |
| It is stipulated that interest will be assessed as provided by law on the deficiency(ies) in tax, addition(s) to tax, and penalty(ies) due from petitioner(s). ( _See_ Exhibit 35.11.1–128). |

2. The deficiency interest paragraph is not necessary only if the circumstances otherwise make it clear that the Service will impose interest as provided by law ( _e.g._, the Field attorney, after notifying petitioners or their representative, made an oral statement on the record before the court that makes it clear that the Service has not waived its right to assess interest as provided by law). Also, the paragraph need not include a reference to any liability not applicable to the petitioners’ case ( _e.g._, if, pursuant to the decision, no penalties are due from petitioners, the reference to penalties may be excluded from the paragraph).

3. The Service also recognizes its obligation to pay overpayment interest as provided by law. Thus, when requested by petitioners, the Field attorney may include a paragraph regarding interest on an overpayment in any stipulated decision document in which an overpayment in tax is determined for one or more years. The paragraph, which will be included in the separate stipulation document or the stipulation part of the combined stipulation and decision document, should provide:



|     |
| --- |
| It is stipulated that interest will be credited or paid as provided by law on any overpayment in tax due to petitioner(s). |

4. In every section 7436 case in which a proper amount of employment tax greater than zero is stipulated, the separate stipulation document or the stipulation part of the combined stipulation and decision document should contain the following paragraph:



|     |
| --- |
| It is stipulated that interest will be assessed as provided by law on the tax, addition(s) to tax, and penalty(ies) due from petitioner. |

5. As a general rule, decisions in section 7436 cases are reviewed and approved by Division Counsel\\/Associate Chief Counsel (TEGE), EOEG:ET1.

6. These interest paragraphs are nonoperating paragraphs insofar as the decision of the Tax Court is concerned. Rather, their purpose is to avoid any misunderstanding at a later date as to the amounts to be collected under the terms of the settlement (whether such amounts involve a statutory deficiency or liability, a deficiency to be assessed, unpaid portions of prior assessments, overpayments), and specifically, that interest will be assessed. Essential facts that must be stipulated to form the basis of the court’s decision, or that are an integral part of the court’s decision, should not be included in these paragraphs.


**35.8.2.6** **(08-11-2004)**

### Preparing Decision Documents for Cases Involving Claims for Attorney’s Fees Under Section 7430

1. T.C. Rule 231(a)(1) requires that the stipulated decision submitted to the court in fully agreed cases include a reference to the disposition of the litigation costs issue, if the issue has been raised. _See_ CCDM 35.10.1.1

2. When the litigation or administrative costs issue has been raised in settled or litigated cases and the parties agree on the disposition of this issue, the decision document must include either a provision which states that the petitioner is not entitled to costs under section 7430 or a provision stating that petitioner is entitled to $ \[amount\] in costs under section 7430. For a discussion of settlement procedures and settlement authority, please refer to CCDM 35.10.1.1.2. See also requirements of T.C. Rule 232(e).

3. When the parties cannot agree on the award of litigation or administrative costs in settled cases, the parties will submit a stipulation of settlement which shall include the elements described in T.C. Rule 231(c). The rule provides that the stipulation of settlement is to accompany a motion for costs. This stipulation of settlement is binding upon the parties.

4. T.C. Rule 232(f) provides that the court will enter an order granting or denying petitioner’s motion for litigation costs and determining the amount of such costs, if any, when the parties cannot agree to the amount of costs to be awarded. Thereafter, the parties or either of them shall submit a proposed decision to the court setting forth separately in the decision document the amount of the award of litigation costs, if any, determined by the court. The decision document should state that the court determined either no costs or costs in the amount of $ \[amount\].


**35.8.2.7** **(08-11-2004)**

### Settlement Documents for "S" Cases

1. The instructions in CCDM 35.8 addressing Decisions and Rule 155 computations are applicable to "S" cases, except that any language directed toward preserving the rights to appeal should be omitted from the computation for entry of decision and the decision. If the petitioner has not disputed all of the adjustments in the notice, the stipulation-decision or Rule 155 computation and decision must include the disputed adjustments in arriving at the deficiency or overpayment to be entered for each year involved.

2. Since no appeal can be taken from the decision, no action on decision is required. The case will be closed after the expiration of 90 days, when the decision becomes final. _See_ section 7481(b).


**35.8.2.8** **(08-11-2004)**

### Review and Processing Settlement Documents

1. If documents to be filed with the Tax Court on behalf of both the petitioner and the respondent are not executed by the petitioner, they must be executed by an attorney or other representative admitted to practice before the court who has duly entered an appearance on behalf of the petitioner in the case. This fact must be checked by the attorney prior to forwarding the documents for execution on behalf of the petitioner. Settlement documents are not executed on behalf of the Chief Counsel until after execution on behalf of the petitioner and when they are ready for filing with the court.


**35.8.2.8.1** **(08-11-2004)**

#### Processing in Field Office

1. After a basis for settlement has been reached, the computation should be made and the settlement documents prepared, reviewed, executed, and filed as soon as possible. This will enable the tax to be assessed, or refund made, at the earliest time. This is important to taxpayers in small tax cases, as well as to the Service where substantial amounts are involved.

2. After the settlement documents have been prepared, the original and two copies are forwarded to the petitioner or petitioner’s counsel for execution. The transmittal letter that accompanies these documents requests the petitioner or counsel to execute the original and one copy, and to return them to Field Counsel. Upon the return of the settlement documents executed by or on behalf of the petitioner, the executed copy will be the initialed copy and will be initialed by the attorney and the reviewer. After execution on behalf of the Chief Counsel, the original and required copies will be processed to the court.


**35.8.2.8.2** **(08-11-2004)**

#### Responsibility of Attorney and Review by Reviewer

1. Before settlement documents are forwarded for execution on behalf of the petitioner, they shall be reviewed and approved by the reviewer as to their contents and adequacy to support a correct decision by the court and to form a basis for the administrative closing of the case. The initialing of the transmittal letter to the petitioner, or petitioner’s counsel, will be deemed a certification by the attorney and the reviewer as to the adequacy of the settlement documents.

2. The attorney in the preparation of the settlement documents and the reviewer in the review must keep in mind that once a decision of the Tax Court becomes final, as a practical matter it cannot be vacated or modified, and that both must have a complete understanding of the essential facts in each case and the technical requirements to be applied to the facts in the drafting of the settlement documents. The form and terminology used in these documents must clearly, explicitly, and concisely set forth the essential facts of the settlement and the findings and determination necessary for a legal decision.


**35.8.2.8.3** **(08-11-2004)**

#### Filing and Lodging Documents

1. A separate stipulation document is filed with the court. It will be stamped "filed" by the court. The combined stipulation and decision document or the separate decision document, however, is not "filed" . Instead, it is executed by the judge, and it becomes "entered" as the court’s decision. In effect, the combined or separate decision documents are "lodged" with the court until the decision is entered on the court’s records. The date of the decision is the date it is entered, not the date on which a judge executes the decision document. _See_ section 7459. One copy of the entered decision is served on the respondent. A separate stipulation document, however, is never served on the parties because the court merely files this document.

2. When settlement documents are filed at trial sessions, Field Counsel will date stamp the initialed copy of the combined settlement and decision document, or the separate decision document "lodged" with the court. The stamped date is the date this document is "lodged " with the court. Field Counsel will also date stamp the initialed copy of the separate stipulation document "filed" at the trial session. The stamped date is the date the separate stipulation document is "filed" with the court. Many Field attorneys request the trial clerk at the trial session to stamp the initialed copy of the separate stipulation document as filed. This practice is satisfactory and may be used in lieu of stamping the initialed copy of the separate stipulation document as provided above.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-008-002#addtoany "Show all")

A2A