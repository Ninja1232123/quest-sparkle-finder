---
url: "https://www.irs.gov/irm/part35/irm_35-003-007"
title: "35.3.7 Motions in Partnership Actions | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-003-007#main-content)

- 35.3.7  [Motions in Partnership Actions](https://www.irs.gov/irm/part35/irm_35-003-007#idm140216360968272)
  - 35.3.7.1  [Review Required in TEFRA Cases](https://www.irs.gov/irm/part35/irm_35-003-007#idm140216360388736)
  - 35.3.7.2  [Review Required in BBA Cases](https://www.irs.gov/irm/part35/irm_35-003-007#idm140216333587456)
  - 35.3.7.3  [Jurisdictional Motions: TEFRA Cases](https://www.irs.gov/irm/part35/irm_35-003-007#idm140216360613504)
  - 35.3.7.4  [Jurisdictional Motions: BBA Cases](https://www.irs.gov/irm/part35/irm_35-003-007#idm140216360392016)

# Part 35. Chief Counsel Directives Manual Tax Court Litigation

# Chapter 3. Motions

# Section 7. Motions in Partnership Actions

* * *

## 35.3.7 Motions in Partnership Actions

#### Manual Transmittal

August 13, 2021

#### Purpose

(1) This transmits revised CCDM 35.3.7, Motions, Motions in Partnership Actions.

#### Background

This section incorporates the centralized partnership audit regime established under the Bipartisan Budget Act of 2015 (BBA) while also accommodating ongoing TEFRA cases.

#### Material Changes

(1) The current title of CCDM section 35.3.7 is revised to "Motions; Motions in Partnership Actions" to reflect that the section covers partnership proceedings under both TEFRA and the BBA.

(2) CCDM section 35.3.7.1 is retitled "Review Required in TEFRA Cases," and adds new subsection 35.3.7.1(1)(g), Motions to Dismiss for Lack of Jurisdiction Pursuant to I.R.C. §6226(a)(1), to the list of TEFRA motions that attorneys may file directly with the Tax Court.

(3) New section 35.3.7.2, "Review Required in BBA Cases," is added to provide guidance to attorneys handling motions in BBA proceedings.

(4) Existing CCDM section 35.3.7.2 is renumbered 35.3.7.3 and retitled "Jurisdictional Motions: TEFRA Cases."

(5) New section 35.3.7.4, "Jurisdictional Motions: BBA Cases," is added to provide guidance to attorneys on jurisdictional considerations in BBA cases. It also lists the motions to dismiss a BBA petition on jurisdictional grounds that must be reviewed by P&A Branch 6 or 7.

#### Effect on Other Documents

This section supersedes CCDM 35.3.7, dated August 11, 2004.

#### Audience

Chief Counsel

#### Effective Date

(08-13-2021)

Richard G. Goldman

Deputy Associate Chief Counsel

(Procedure & Administration)

**35.3.7.1** **(08-13-2021)**

### Review Required in TEFRA Cases

1. All TEFRA partnership motions must be reviewed by the Associate Chief Counsel (P&A), Branch 6 or 7, except as noted below. Certain TEFRA motions may be directly filed with the Tax Court, if they follow the format set forth in Exhibits 35.11.1–62 through 35.11.1–66 for the respective motions. Any deviation from the format of the appropriate exhibit will require review of the motion by the Associate Chief Counsel (P&A), Branch 6 or 7. Those motions that may be directly filed are:



1. T.C. Rule 248(a) –– Stipulated Decisions. _See_ Exhibit 35.11.1–186 for the proper format for stipulated decision documents;

2. T.C. Rule 248(b) –– Motion for Entry of Decision and Decision. _See_ Exhibits 35.11.1–187 through 35.11.1–190 for the proper format for Rule 248 motions for entry of decision and accompanying documents;

3. Motions to Dismiss for Lack of Jurisdiction Pursuant to I.R.C. § 6226(b)(1) (Duplicate petition filed by notice partner when Tax Matters Partner (TMP) has filed a petition). Exhibit 35.11.1–61. If there is any question as to the validity of the petition filed by the TMP, the motion to dismiss must be reviewed by the Associate Chief Counsel (P&A), Branch 6 or 7;

4. Motions to Dismiss for Lack of Jurisdiction Pursuant to I.R.C. § 6226(b)(2) and (b)(4) (Duplicate petitions filed by notice partners). Exhibit 35.11.1–62. If there is any question as to the validity of the prior petition, the motion to dismiss must be submitted to the Associate Chief Counsel (P&A), Branch 6 or 7 for review;

5. Motions to Dismiss for Lack of Jurisdiction –– TEFRA Items in Deficiency Notice. _See_ Exhibit 35.11.1–63 for the proper format of this motion;

6. Motions to Dismiss for Lack of Jurisdiction and to Strike –– TEFRA and Non–TEFRA Items. If a deficiency notice contains TEFRA and non–TEFRA items, only the TEFRA items should be dismissed. _See_ Exhibit 35.11.1–65 for the proper format of this motion;

7. Motions to Dismiss for Lack of Jurisdiction Pursuant to I.R.C. § 6226(a)(1) (90-day statute of limitation for TMP to petition a notice of a final partnership administrative adjustment (FPAA)).


2. In addition to the sample motions referenced above, _CCDM 35.3.7.3_ discusses TEFRA jurisdictional motions in more detail and provides guidance on what facts need to be alleged in the motions. All other TEFRA motions not referenced above must be reviewed by the Associate Chief Counsel (P&A), Branch 6 or 7; (e.g., any motion to dismiss for lack of jurisdiction because the notice partner filed within the 90-day period, or affected items in the FPAA). If there is any question as to the validity of a petition filed by the TMP, or the validity of a prior filed petition, motions to dismiss must be submitted to the Associate Chief Counsel (P&A), Branch 6 or 7, for review. Exhibit 35.11.1–1 (Tax Court Documents Requiring Associate Office Review).


**35.3.7.2** **(08-13-2021)**

### Review Required in BBA Cases

1. All BBA partnership motions must be reviewed by the Associate Chief Counsel (P&A), Branch 6 or 7, except as noted below. These BBA documents may be directly filed with the Tax Court:



1. T.C. Rule 255.7 - Stipulated Decisions. See Exhibit 35.11.1-186 for the proper format for stipulated decision documents;

2. T.C. Rule 255.7 - Motion for Entry of Decision and Decision. See Exhibit 35.11.1-187 through 35.11.1-190 for the proper format for Rule 248 motions for entry of decision and accompanying documents;

3. Motions to Dismiss for Lack of Jurisdiction Pursuant to I.R.C § 6234(a) (90-day statute of limitation for partnership to petition court for readjustment of FPA).


2. In addition to the sample documents referenced above, _CCDM 35.3.7.4_ discusses BBA jurisdictional motions in more detail and provides guidance on what facts need to be alleged in the motions. All other BBA motions not referenced above must be reviewed by the Associate Chief Counsel (P&A), Branch 6 or 7. If there is any question as to the validity of petition filed by the partnership representative, or the validity of a prior-filed petition, motions to dismiss must be submitted to Associate Chief Counsel (P&A), Branch 6 or 7. Exhibit 35.11.1-1 (Tax Court Documents Requiring Associate Office Review).


**35.3.7.3** **(08-13-2021)**

### Jurisdictional Motions: TEFRA Cases

1. The procedure contained in sections 6221 through 6234 governs audit procedures relating to partnership and affected items. Section 6225 precludes normal deficiency proceedings with reference to TEFRA partnership adjustments. Any statutory notice of deficiency which contains only partnership items is invalid in its entirety because it attempts to determine a deficiency for partnership items other than through procedures prescribed by sections 6221through 6233. Exhibit 35.11.1–63.

2. Where an invalid statutory notice of deficiency is issued, i.e., a notice containing only partnership item or affected item adjustments, respondent should file a motion to dismiss for lack of jurisdiction. The motion should state that no valid statutory notice of deficiency under section 6212 was issued and that the notice is invalid and prohibited by section 6225. The motion should further indicate that: (a) the items on the statutory notice are partnership items; (b) the statutory notice is invalid in its entirety insofar as it attempts to determine a deficiency for partnership items or affected items other than through the procedures prescribed by sections 6221 through 6234; and (c) the motion to dismiss for lack of jurisdiction is without prejudice to the right of the respondent to proceed under sections 6221 through 6234 to deal with the (name of TEFRA partnership), as appropriate, including the issuance of a notice of final partnership administrative adjustment under section 6223(a)(2) should such action be appropriate and timely. The motion should also allege sufficient facts and provide sufficient documentation for the court to make an independent determination that the items in question arise from a TEFRA partnership. The motion should also state why the partnership does not fall within the small partnership exception to TEFRA: i.e., it had more than ten partners at any point during the taxable year or it had a pass-thru or nonresident alien as a partner. Section 6231(a)(1)(B)(i). If a notice of beginning of administrative proceeding or final partnership administrative adjustment has been issued to the partnership, these facts and the respective dates of issuance should be stated and a copy of the notice attached as an exhibit. If a petition has been filed with respect to a notice of final partnership administrative adjustment, this should also be noted. Exhibit 35.11.1–63.

3. If a statutory notice of deficiency is issued which contains adjustments to partnership or affected items and nonpartnership items, the entire statutory notice would not be invalid. In such a situation, to preserve the validity of the statutory notice with respect to the nonpartnership item adjustments, the respondent should file a motion to dismiss for lack of jurisdiction and to strike. The motion to dismiss and to strike should reference the portion of the adjustments and pleadings pertaining to (and only to) the partnership. The motion should state that the statutory notice is valid, as nonpartnership items were adjusted and a deficiency was determined with respect to such nonpartnership items, but insofar as adjustments to partnership items or affected items were determined, the notice is invalid and prohibited by section 6225. The motion should also indicate that: the statutory notice of deficiency is invalid only insofar as it attempts to determine a deficiency for partnership items or affected items other than through the procedures prescribed by sections 6221 through 6234, and the notice is otherwise valid. Additional facts should be alleged and exhibits attached as outlined in the preceding paragraph. Exhibit 35.11.1–64.

4. In a TEFRA proceeding, the court only has jurisdiction over partnership items pursuant to section 6226(f). Partnership items are items required to be taken into account for the partnership’s taxable year under any provision of subtitle A to the extent regulations provide that such item is more appropriately determined at the partnership level than at the partner level. Section 6231(a)(3). If nonpartnership items, such as penalties or additions to tax (other than on adjustments to partnership items), are raised in a petition with respect to a notice of Final Partnership Administrative Audit, a motion to dismiss for lack of jurisdiction and to strike must be filed. Exhibit 35.11.1–65.

5. Commencement of Action — Section 6226(a) and (b). Upon receipt of a petition or complaint in a partnership action, the Field attorney must determine whether other actions have been filed and, if more than one petition or complaint has been filed, which one must be dismissed. A list of petitions filed with respect to a partnership taxable year is available through TLCATS. The Tax Court’s website also should be checked. The attorney with responsibility over the duplicate petition must contact the attorney with the lead case to ensure that the lead case was correctly determined and that there are no jurisdictional defects with respect to the lead case. The Field attorney with responsibility over a case to be dismissed shall prepare a motion to dismiss. This includes motions to dismiss duplicate petitions if there is any question as to the validity of the first petition.



1. Filing by tax matters partner pursuant to section 6226(a). The Tax Matters Partner, within 90 days after the mailing of the notice of Final Partner Administrative Adjustment, may file a petition for readjustment of partnership items in the Tax Court, the district court in which the partnership’s principal place of business is located, or the Court of Federal Claims. Note that the filing period may actually be longer than 90 days if the 90th day falls on a Saturday, Sunday or legal holiday in the District of Columbia. Section 7503. During such 90-day period, no other partner may file a petition for judicial review. If any person other than the TMP files a petition in this 90-day period, the Field attorney should first determine if the petition was filed on behalf of the TMP and whether the TMP is willing to ratify the petition, i.e., file an amended petition in the name of the proper party, or file a motion to amend caption to reflect the correct TMP. If the petitioner is unwilling to have the TMP ratify the improper petition or ratification is otherwise unavailable, the Field attorney should prepare a motion to dismiss the action for lack of jurisdiction under section 6226(a). If, however, the petition that was filed during the 90-day period was filed by a notice partner (or a 5-percent group), the court will have jurisdiction if no other petition is filed during the 150-day period. Section 6226(b)(5) treats premature petitions as filed on the last day of the 60-day period. The motion should state that only the tax matters partner may file a petition in the first 90 days after a notice of FPAA is issued to the tax matters partner and that the petitioner is not the tax matters partner. The motion should set forth why the filing party is not the TMP, i.e., not properly designated as such, not the largest profits interest general partner in the absence of a designation by the partnership, or not selected by the Service as TMP under Rev. Proc. 88–16, 1988–1 C.B. 691. If the Service identifies the petitioner as an indirect partner of the partnership, Forms K-1 of both the source partnership in question as well as the tier partnership will need to be attached so that the court may independently determine the petitioner’s status with respect to the source partnership. The motion should set forth the Field attorney’s attempt to determine the availability of the defense of ratification. The motion should identify the actual TMP, and plead sufficient facts and attach sufficient documentation so that the court may independently determine who the TMP is, e.g., it may be necessary to include copies of the Form K-1s to show the general partner with the largest profits interest who would be TMP in the absence of a designation by the partnership. The motion should also inform the court of all other petitions filed with respect to the partnership taxable year, including invalid petitions, as well as any jurisdictional motions filed with respect to these cases.

2. Filing by notice partner or representative of five-percent group pursuant to section 6226(b). Section 6226(b)(1) provides that, if the TMP does not file a petition during the period provided by section 6226(a), any notice partner or five-percent group ( _see_ section 6223(a) and (b)(2)) with an interest in the outcome (section 6226(d)) may, within 60 days following the close of such 90-day period, file a petition with any of the courts in which the TMP could have filed a petition. A partner does not have an interest in the outcome after the partnership items of the partner become nonpartnership items under section 6231(b). Such a partner does not have standing, pursuant to section 6226(d)(2), to file a petition pursuant to section 6226(b). Note, however, that the interest requirement does not apply to a TMP who files a petition pursuant to section 6226(a) in the 90-day period, although it will apply to a TMP who files as a notice partner pursuant to section 6226(b). Note, also, that a TMP no longer having an interest under section 6231(c) terminates their TMP designation. Treas. Reg. § 301.6231(a)(7)-1(1)(1)(iv). Such termination of TMP status would deny that partner standing to petition the Tax Court. If a partner’s partnership items convert to nonpartnership items by reason of settlement after he has filed a petition, T.C. Rule 248, which governs stipulated decision documents and notices of settlement, applies. CCDM 35.8.6.1.1. If a TMP files a petition for readjustment of partnership items within the period provided by section 6226(b), the petition is proper and timely under section 6226(b) so long as the TMP has an interest in the outcome of the proceeding. By filing a petition during the 60-day period, however, the TMP loses the right to control the litigation, and the petition will be treated just like any other petition filed by a notice partner.


6. Priority of Actions. If the TMP files a petition during the period provided for under section 6226(a), then all petitions filed during the period provided for under section 6226(b) must be dismissed for lack of jurisdiction. The motion to dismiss should state (a) the date of issuance of the notice of final partnership administrative adjustment and that a petition was filed by the TMP within 90 days of the issuance of the notice of FPAA, giving the date and docket number of the petition filed by the TMP; (b) that a petition may be filed by a notice partner pursuant to section 6226(b)(1) only if the tax matters partner has not filed a petition pursuant to section 6226(a); (c) that the court lacks jurisdiction over the notice partner petition pursuant to section 6226(b)(1). _See_ Exhibit 35.11.1–61. The attorney with responsibility over the case to be dismissed must contact the attorney with responsibility over the TMP case to ensure that there are no jurisdictional defects with respect to the TMP petition. If there is any question as to the validity of the petition by the TMP, the motion to dismiss must be submitted for prereview to the Associate Chief Counsel (P&A), Branch 6 or 7.

7. Priority of Actions When More Than One Petition is Filed by Partner with Standing Pursuant to Section 6226(b)(1) –– Section 6226(b)(2)–(4). A petition may be filed pursuant to section 6226(b)(1) by a notice partner or five-percent group, only if the TMP does not file a petition pursuant to section 6226(a) in the first 90 days after a notice of FPAA is issued to the TMP. If the TMP does not file a petition during this initial period, then the first action filed in the Tax Court during the 60-day period provided by section 6226(b) will establish jurisdiction, or if no petition is filed with the Tax Court, the first action filed in either the district court or Court of Federal Claims will go forward. All other actions shall be dismissed. The Field attorney assigned to a case which must be dismissed shall file a motion to dismiss his case for lack of jurisdiction pursuant to sections 6226(b)(2) and 6226(b)(4). The motion must inform the court of the case which will go forward stating that it was the first case to be filed in the Tax Court pursuant to section 6226(b)(1). The motion should further state that the first case brought in the Tax Court shall go forward pursuant to section 6226(b)(2) and all subsequent petitions filed during the period provided by section 6226(b) must be dismissed pursuant to section 6226(b)(4). _See_ Exhibit 35.11.1–62. The attorney with responsibility over the case to be dismissed must coordinate with the attorney with responsibility over the lead case. Motions to dismiss duplicate petitions, if there is any question as to the validity of the case to go forward, must be reviewed by the Associate Chief Counsel (P&A), Branch 6 or 7.

8. Untimely petitions. Upon receipt of a petition in a partnership action, the Field attorney must first determine if the petition was timely filed during the periods provided for under sections 6226(a) or 6226(b). If the petition has been untimely filed, then a motion to dismiss for lack of jurisdiction must be filed. Once this determination is made, the Field attorney must promptly notify the Examination Support Unit in the key case Service Center in writing that the petition was untimely filed and that a prompt assessment of deficiencies due to adjustments of partnership items must be made unless some other timely petition was filed. This is because the suspension provision of section 6229(d) will toll the period of limitations until the court decision becomes final only where a petition has been timely filed by the Tax Matters Partner, a notice partner, or a 5% group. In this respect the statute suspension provisions under TEFRA do not parallel section 6503(a)(1). Section 6229(d) provides that if a notice of a Final Partnership Administrative Adjustment is mailed to the TMP, the running of the period of limitations is suspended (1) for the period during which an action may be brought under section 6226 (and, if an action with respect to such administrative adjustment is brought during such period, until the decision of the court in such action becomes final), and (2) for one year thereafter. Therefore, where a petition is untimely filed and there are no other timely filed petitions with regard to that administrative adjustment, the one year period of section 6229(d)(2) begins to run upon the default of the FPAA. Similarly, section 6225(a) bars assessment of tax attributable to partnership items for 150 days after mailing the FPAA to the TMP and, if a proceeding is begun in the Tax Court during such 150-day period, until the decision of the court becomes final. This means that if an untimely petition is filed, the prohibition on assessment under section 6225 is lifted after the 150 day period and the one year suspension period of section 6229(d)(2) will expire one year after expiration of the period for petitioning cases, or one year after the decision becomes final in timely petitioned cases. Therefore, the written notification to the appropriate Examination Support Unit must identify when the one year suspension period under section 6229(d) begins or ends. The adjustments reflected on the FPAA should be used as a basis for assessing all investors.


**35.3.7.4** **(08-13-2021)**

### Jurisdictional Motions: BBA Cases

1. For taxable years beginning in 2018 when BBA applies, the procedures contained in sections 6221 through 6241 govern audit procedures relating to partnership-related items. Partnerships may elect-in these procedures for any partnership taxable year beginning after November 2, 2015 and before January 1, 2018 in the manner prescribed by Treas. Reg. § 301.9100-22.

2. Under section 6223, only a Partnership Representative (PR) has authority to act on behalf of the partnership, including in BBA proceedings. A PR may be designated by the partnership or, if such designation by the partnership is not in effect, by the Secretary. The partnership and all partners to the partnership are bound by final decision made in BBA proceeding by a properly designated PR. The Tax Court promulgated Rule 255.6 governing the identification and removal of a PR before the court.

3. The court only has jurisdiction over partnership-related items for the partnership taxable year to which the notice of final partnership adjustment relates pursuant section 6234(c). A partnership-related item is any item or amount shown or required to be shown on the partnership’s return or required to be maintained in the partnership’s books and records that is relevant to determining the Chapter 1 liability of any person. Treas. Reg. § 301.6241-1(6)(ii). Any adjustment made to a partnership-related item must be made at the partnership level. Section 6221(a).

4. Filing by Partnership Representative pusuant to section 6234(a). the PR, within 90 days after the mailing of the notice of final partnership adjustment, may file a petition for readjustment of partnership-related items in the Tax Court, the district court in which the partnership’s principal place of business is located, or the Court of Federal Claims. Note that the filing period may actually be longer than 90 days if the 90th day falls on a Saturday, Sunday or legal holiday in the District of Columbia. Section 7503. Only the PR may file a petition for judicial review. If any person other than the PR files a petition in this 90-day period, the Field attorney should first confirm whether the person who filed the petition is the PR, and, if not, the Field attorney should prepare a motion to dismiss the action for lack of jurisdiction under section 6234(a) and section 6223. Branches 6 and 7 of the Associate Chief Counsel (P&A) can assist with any necessary coordination on BBA issues.

5. Untimely petitions. Upon receipt of a petition in a BBA action, the Field attorney must first determine if the petition was timely filed during the period prescribed by section 6234(a), taking into account if the statute of limitations has been tolled or extended by section 6241(6)(B) or for any other appropriate reason. If the petition has been untimely filed, then a motion to dismiss for lack of jurisdiction must be filed.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-003-007#addtoany "Show all")

A2A