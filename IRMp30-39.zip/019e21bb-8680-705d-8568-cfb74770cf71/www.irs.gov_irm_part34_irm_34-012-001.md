---
url: "https://www.irs.gov/irm/part34/irm_34-012-001"
title: "34.12.1 Litigation Exhibits | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part34/irm_34-012-001#main-content)

- 34.12.1  [Litigation Exhibits](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140472794384)
  - 34.12.1.1  [Supplementary Material](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140474981664)
  - Exhibit  34.12.1-1  [Notice of Acceptance or Rejection of Plan of Reorganization](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140474970448)
  - Exhibit  34.12.1-2  [Supplemental Provisions](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140472782048)
  - Exhibit  34.12.1-3  [Large Case Bankruptcy Letter](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140473827232)
  - Exhibit  34.12.1-4  [Immediate Assessment Under IRC 6871 Letter](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140473273792)
  - Exhibit  34.12.1-5  [Basic Checklist for Analyzing Revenue Officer Report-Federal Tax](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140473839184)
  - Exhibit  34.12.1-6  [Basic Checklist, Things to Know Re: Security Interest Date](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140474087152)
  - Exhibit  34.12.1-7  [Basic Checklist, Things to Know Re Security Interest — Realty](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140501874560)
  - Exhibit  34.12.1-8  [Preparation of Suit Letters — Checklist](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140501858752)
  - Exhibit  34.12.1-9  [Memorandum from Chief Counsel to General Counsel, Treasury Department, Re: Appointing Agent (where tax lien is not senior lien)](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140474393376)
  - Exhibit  34.12.1-10  [Document Executed by General Counsel Appointing the Agent (where tax lien is not senior lien)](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140472963440)
  - Exhibit  34.12.1-11  [Memorandum from Chief Counsel to Commissioner of the Internal Revenue – Re: Appointing Agent (where tax lien is senior lien)](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140472944080)
  - Exhibit  34.12.1-12  [Document Executed by Commissioner of the Internal Revenue Appointing Agent (where tax lien is senior lien)](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140473298576)
  - Exhibit  34.12.1-13  [Letter to Agent Advising of Appointment](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140473279088)
  - Exhibit  34.12.1-14  [Letter to Tax Division of Department of Justice Advising It of Appointment of Agent](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140474061264)
  - Exhibit  34.12.1-15  [Motion for Writ of Ne Exeat](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140474032688)
  - Exhibit  34.12.1-16  [Affidavit with Motion in the United States District Court](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140473994976)
  - Exhibit  34.12.1-17  [Writ of Ne Exeat](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140472904224)
  - Exhibit  34.12.1-18  [Order for Writ of Ne Exeat](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140472868112)
  - Exhibit  34.12.1-19  [Bond With Writ](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140472832976)
  - Exhibit  34.12.1-20  [Certificate for Appointment of Receiver](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140473736224)
  - Exhibit  34.12.1-21  [Petition](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140473720560)
  - Exhibit  34.12.1-22  [Declaration](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140473633472)
  - Exhibit  34.12.1-23  [Order](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140473568736)
  - Exhibit  34.12.1-24  [Approval of Settlements by Associate Chief Counsel and Division Commissioner When Required — Closing Agreement](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140473526688)
  - Exhibit  34.12.1-25  [Settlement Letter for Branch Chief’s Signature or Associate Area Counsel Signature](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140473502144)
  - Exhibit  34.12.1-26  [Letter to Joint Committee](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140473431136)
  - Exhibit  34.12.1-27  [Adjudication by Another Court Having Concurrent Jurisdiction With Tax Court](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140473401584)
  - Exhibit  34.12.1-28  [Dismissal of Related Refund Suit](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140472766432)
  - Exhibit  34.12.1-29  [Compromise by the Attorney General](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140472728128)
  - Exhibit  34.12.1-30  [Stipulation for Entry of Judgment in a U.S. District Court](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140472714624)
  - Exhibit  34.12.1-31  [Stipulation for Entry of Judgment in the Court of Federal Claims](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140472683504)
  - Exhibit  34.12.1-32  [IRS Employee Testimony Authorization](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140472657840)
  - Exhibit  34.12.1-33  [Chart for Determining Campus to Process Refund](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140472617696)
  - Exhibit  34.12.1-34  [Questions and Answers Regarding Prohibition Against Requesting Taxpayers to Waive Right to Bring Civil Actions Against the United States](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140472592848)
  - Exhibit  34.12.1-35  [IRS Employee Testimony Authorization for FRCP 30(b)(6) Deposition](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140472567168)
  - Exhibit  34.12.1-36  [Campus Addresses and Contacts (For Payment Memoranda Purposes Only)](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140472528976)
  - Exhibit  34.12.1-37  [Sample Payment Memorandum (Refund Pursuant to Judgment, Form 8690)](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140472489280)
  - Exhibit  34.12.1-38  [Glossary of Terms and Legal References for Electronic Discovery](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140472446144)
  - Exhibit  34.12.1-39  [Litigation Hold Checklist](https://www.irs.gov/irm/part34/irm_34-012-001#idm140140472408080)

# Part 34. Chief Counsel Directives Manual Litigation in District Court, Bankruptcy Court, Court of Federal Claims, and State Court

# Chapter 12. Litigation Exhibits

# Section 1. Litigation Exhibits

* * *

## 34.12.1 Litigation Exhibits

#### Manual Transmittal

July 19, 2022

#### Purpose

(1) This transmits revised CCDM 34.12.1, Litigation Exhibits.

#### Background

The template IRS Testimony Authorizations (routine and Federal Rule of Civil Procedure 30(b)(6) versions) require updating because of the change to the standard of discovery in the Federal Rules of Civil Procedure. Fed. R. Civ. P. 26(b)(1) was amended to delete the previous standard that permitted discovery of matters "reasonably calculated to lead to the discovery of admissible evidence" and to insert a proportionality element that permits discovery regarding any nonprivileged matter that is relevant to any party’s claim or defense and proportional to the needs of the case.

#### Material Changes

(1) CCDM 34.12.1, Exhibit 34.12.1-32, **IRS Employee Testimony Authorization**, and CCDM Exhibit 34.12.1-35, **IRS Employee Testimony Authorization for FRCP 30(b)(6) Depositions**, are revised to reflect the current version of Fed. R. Civ. P. 26 (Duty to Disclose; General Provisions Governing Discovery).

#### Effect on Other Documents

CCDM 34.12.1, dated August 17, 2018, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(07-19-2022)

Richard G. Goldman

Deputy Associate Chief Counsel

(Procedure & Administration)

**34.12.1.1** **(05-10-2013)**

### Supplementary Material

1. This section provides sample documents and other material used in Counsel’s litigation practice as described in CCDM 34.1.1 through CCDM 34.11.1. These exhibits have been consolidated into a single chapter for ease of use.


**Exhibit 34.12.1-1**

### Notice of Acceptance or Rejection of Plan of Reorganization

|  |
| --- |
| UNITED STATES BANKRUPTCY COURT FOR THE \[DISTRICT\] |
|  |
| In Re \[NAME\] | ) |  |
|  | ) | Case No. \[#\] |
|  | Debtor | ) |  |
|  |
| NOTICE OF ACCEPTANCE OR REJECTION OF PLAN OF REORGANIZATION |
|  |
| Having considered the interest and claims of the United States filed and presented herein for taxes outstanding against the debtor, \[name\], I, \[Name of Associate Area Counsel\] in pursuance of the provisions and authority delegated to me by the Secretary of the Treasury by Treasury Department Order No. 101-5, and Department of Treasury General Counsel Order No.4, as revised, and by virtue of Section 1126(a) of the Bankruptcy Code, do hereby certify that I \[accept / reject\] the plan for the reorganization of the above mentioned debtor with respect to the interests and claims of the United States for taxes. |
|  | \_\_<br> \[ASSOCIATE AREA COUNSEL\] |

**Exhibit 34.12.1-2**

### Supplemental Provisions

PURPOSE. This exhibit suggests provisions for which Field attorneys may wish to negotiate with respect to supplemental provisions that can be used in proposed plans of reorganization under chapter 11 of the Bankruptcy Code.

PROVISIONS. The following provisions may be used:

1. The amount of the Internal Revenue Service’s claim for unpaid taxes, as set forth in its proof of claim and as approved by the bankruptcy court, together with interest at a rate of \_\_\_per cent per annum or such higher rate as may be hereafter established under the Internal Revenue Code, plus statutory interest on the unpaid tax liability which will have accrued between the date of the petition and the date of confirmation, plus prepetition and post-petition penalties, will be paid in monthly installments of $ \_\_\_per month. Interest will be computed from the date of confirmation to the date of each monthly payment; the first such installment shall be due on the \_\_\_day of the first month following confirmation of the plan of arrangement and on the \_\_\_day of each month thereafter until such time as the amount of said claim plus interest has been fully paid. No other unsecured claims, except administration claims in this proceeding, will be paid until the claim of the Internal Revenue Service, together with interest, has been paid in full.

2. Any unpaid federal tax liabilities of the debtor arising between the filing of the petition in this case, and confirmation of the plan of reorganization will be paid in full upon confirmation.

3. To the extent that any federal tax lien attached to any property owned by the debtor as of the date of the filing of the petition in this case, such property shall remain subject to such federal tax lien until such time as the amount of such lien has been fully satisfied.

4. All installment payments made pursuant to this agreement shall be made to the Internal Revenue Service, for the attention of the Chief, Insolvency Group. The Insolvency Group may apply each installment payment to the claim for unpaid taxes, penalties, or interest as they, in their sole discretion, may determine. During the pendency of this agreement, the debtor agrees to timely file all required federal tax returns.

5. The debtor, after confirmation, shall segregate and hold separate and apart from all other funds all moneys withheld from employees or collected from others for taxes under any internal revenue laws of the United States and shall deposit the moneys so withheld and collected in a separate bank account in trust for the United States not later than within the calendar week next after such collecting or withholding. At the time of making such deposit in such separate bank account, the debtor will notify the Chief, Insolvency Group, or his/her delegate, of the date and place of deposit and the amount of money deposited with respect to each such item of federal tax. The debtor will pay from said bank account to the Insolvency Manager or his/her delegate the proper amounts at the time and in the manner prescribed by applicable internal revenue laws.

6. Default.



1. If the debtor fails to make any installment payment required under this agreement within 21 days after the due date of such installments; or if the debtor fails to make any deposit of any currently accruing employment tax liability to the separate bank account as provided above or fails to make any payment of any tax to the Internal Revenue Service within 10 days of the due date of such deposit or payment; or if the debtor fails to file any required federal tax return by the due date of such return, or if the debtor violates any other provisions of this agreement, the Insolvency Manager or his/her delegate, may, in his/her sole discretion, declare the debtor is in default of this agreement. Failure to declare that the debtor is in default does not constitute a waiver by the Insolvency Manager or his/her delegate of the right to declare that the debtor is in default.

2. If the Insolvency Manager declares the debtor to be in default of its obligations under this agreement, the entire unpaid liability under the installment agreement, together with any unpaid current liabilities, shall upon demand in writing become immediately due and payable upon any officer or director of the debtor.

3. If full payment is not made within 21 days of such demand, the Internal Revenue Service may collect any unpaid liabilities through the administrative collection provisions of the Internal Revenue Code or by any other procedure authorized by law.

4. So long as any part of the Internal Revenue Service’s claim which is subject to this agreement remains unpaid or so long as any tax liabilities accruing during the pendency of this proceeding or while this agreement is in effect, remain unpaid:



      1. No lien, mortgage, or other security interest shall be created to provide a priority as to payment equal to or superior to that of the United States under the plan;

      2. No increase in management fees or compensation (except with the express consent of the Insolvency Group) shall be made in favor of any administrative or executive officer or official of the debtor (including any director of the debtor) or any other business organized or made use of in effectuating this plan; and

      3. No dividends shall be paid or allowed to stockholders of the debtor or of any concern organized or made use of in effectuating this plan.


5. All statutes of limitation on the collection of any federal taxes due from the debtor or involved in this plan are suspended during the pendency of this plan and for such further time as any part of the aforementioned taxes remain unpaid, and for one year thereafter.

6. Any refunds or other credits to which the debtor may become entitled for any reason before completion of the payment of the federal taxes under this plan may be credited to apply to the last payment or payments required to be made under this plan.

7. In the event that additional outstanding federal taxes not covered by proofs of claim are determined to be due from the debtor, such additional items shall be paid by continuing the installment payments so long as necessary but in no event shall the period of any installment payments exceed six years; in the event that the allowance of claims for such additional liabilities shall cause the period for installment payments, including interest, to extend beyond six years, the amount of each monthly installment payment shall be increased in a sufficient amount so that the period for full payment shall not exceed six years.

8. If by the carryover of any net operating loss or any credit including but not limited to investment tax credit, the debtor becomes entitled to a reduction in taxes it would otherwise be required to pay, an amount equivalent to the tax savings will be paid and applied to the unpaid portion of the claim of the Internal Revenue Service or to any tax liabilities accruing during the pendency of this proceeding.


**Exhibit 34.12.1-3**

### Large Case Bankruptcy Letter

![This is an Image: 29689021.gif](https://www.irs.gov/pub/xml_bc/29689021.gif)

> This is the first page of an example of a large case bankruptcy letter.

[Please click here for the text description of the image.](https://www.irs.gov/media/157691 "")

![This is an Image: 29689022.gif](https://www.irs.gov/pub/xml_bc/29689022.gif)

> This is page 2 of an example of a large case bankruptcy letter.

[Please click here for the text description of the image.](https://www.irs.gov/media/157696 "")

![This is an Image: 29689023.gif](https://www.irs.gov/pub/xml_bc/29689023.gif)

> This is page 3 of an example of a large case bankruptcy letter.

[Please click here for the text description of the image.](https://www.irs.gov/media/157701 "")

![This is an Image: 29689024.gif](https://www.irs.gov/pub/xml_bc/29689024.gif)

> This is page 4 of an example of a large case bankruptcy letter.

[Please click here for the text description of the image.](https://www.irs.gov/media/157706 "")

![This is an Image: 29689025.gif](https://www.irs.gov/pub/xml_bc/29689025.gif)

> This is page 5 of an example of a large case bankruptcy letter.

[Please click here for the text description of the image.](https://www.irs.gov/media/157711 "")

![This is an Image: 29689026.gif](https://www.irs.gov/pub/xml_bc/29689026.gif)

> This is page 6 of an example of a large case bankruptcy letter.

[Please click here for the text description of the image.](https://www.irs.gov/media/157716 "")

**Exhibit 34.12.1-4**

### Immediate Assessment Under IRC 6871 Letter

|  |
| --- |
|  | \[Letterhead\] |
|  |
| Date: | Person to Contact:<br> Contact Telephone Number: |
|  |
| The deficiency in tax is being assessed against you under the provisions of section 6871 of the Internal Revenue Code. Accordingly, no petition for the redetermination of the deficiency may be filed with the United States Tax Court as prescribed by that section. If, after a conference, you are still not in agreement with the findings, the deficiency and such interest, additional amounts, and additions to the tax may be presented for adjudication in accordance with law to the court before which the bankruptcy or receivership proceeding is pending. |
| Attention is called to the rights and priorities of the United States under applicable provisions of the Bankruptcy Act or Bankruptcy Reform Act of 1978 and under 31 U.S.C. § 3713(a). Except with respect to a trustee acting in accordance with the provisions of the Bankruptcy Reform Act of 1978, 31 U.S.C. § 3713(b) imposes personal liability upon every executor, administrator, assignee, or other person who, in paying debts of the person or estate for whom or for which he or she acts, fails to observe the priority in payment prescribed by law in favor of the United States. |
| The Area Director is authorized to file proof of claim for any tax liability in proceedings under the Bankruptcy Reform Act and in receivership cases. The filing of proof of claim will not prejudice an application to this office for reconsideration of the above-mentioned tax. If the bankruptcy was filed under the Bankruptcy Act and you do not agree with the findings shown in the attached statement, you may file a written protest within 30 days from the date of this letter and send it to our address shown on this letter. The protest should be declared true under penalties of perjury which may be done by adding the following declaration: |
|  | "Under penalties of perjury, I declare that I have examined this protest and any accompanying schedules and statements, and, to the best of my knowledge and, to the best of my knowledge and belief, it is true, correct, and complete." |
| We will transfer your protest and case to the Appeals office nearest you. They will contact you to arrange a conference. |
| If, after a conference, you are still not in agreement with the findings, the deficiency and such interest, additional amounts, and additions to the tax may be presented for adjudication in accordance with law to the court before which the bankruptcy or receivership proceeding is pending. |
| If the bankruptcy was filed under the Bankruptcy Reform Act of 1978 and you do not agree with the findings shown in the attached statement, you are not entitled to an Appeals conference. Instead, you should ask the bankruptcy court to determine the amount of any unpaid liability. |
| If you have any questions, please contact the person whose name and telephone number are shown in the heading of this letter. |
|  |
|  | \[Signature block\] |
|  |
| Enclosure: |
|  | Statement |

**Exhibit 34.12.1-5**

### Basic Checklist for Analyzing Revenue Officer Report-Federal Tax

|  |
| --- |
| 1\. Name and type of taxpayer (corporation, individual, joint). |
| 2\. Type of tax ( _e.g._, income, employment tax, excise tax). |
| 3\. Assessment: |
|  | a. Date of assessment, by type and period of tax. |
|  | b. Was assessment timely made? |
|  | c. Balance due as of recent date. |
| 4\. Notice of federal tax lien: |
|  | a. Date(s) of filing. |
|  | b. Place(s) of filing. |
| (The use of a table is recommended for all cases which include the above items) |
| 5\. Seizure: |
|  | a. Date of notice before levy - IRC § 6331(d) |
|  | b. Any letters, publications sent to the taxpayer required under IRC§§ 6320 and 6330 (Collection Due Process) and notices sent and any hearing conducted in connection with the above. |
|  | c. Date of notice of seizure. |
|  | d. Date of sale if any. |
| 6\. Suspension of statute of limitations: |
|  | a. Dates and terms of consensual waivers. |
|  | b. Copies of installment agreements and offers-in-compromise. |
|  | c. Dates and term of pendency of court proceedings (special rule for bankruptcy cases). |

**Exhibit 34.12.1-6**

### Basic Checklist, Things to Know Re: Security Interest Date

| _SECURITY INTEREST — PERSONALTY_ |
| :-: |
| 1\. Security agreement: |
|  | a. Date of execution. |
|  | b. Description of collateral. |
|  | c. Amount and description of loan. |
| 2\. Financing statement: |
|  | a. Information in 1 (above) for Financing Statement. |
|  | b. Date executed and filed. |
|  | c. Place(s) of filing. |
| 3\. Amount of loan(s) described in note and whether to be disbursed in installments. |
| 4\. Date(s) loaned money disbursed to debtor. |
| 5\. Balance due on note: |
|  | a. Time of filing of notice of federal tax lien. |
|  | b. 45 days after N.F.T.L. filing. |
|  | c. At time of actual knowledge of creditor of taxes. |
| 6\. Date creditor received actual knowledge or notice of federal taxes. |
| 7\. Was collateral in existence at date of filing of notice of federal tax lien (or 45 days thereafter), or at date of levy? |
| 8\. Possession of collateral—who had it and when (constructive possession?). |

**Exhibit 34.12.1-7**

### Basic Checklist, Things to Know Re Security Interest — Realty

| _SECURITY INTEREST — REALTY_ |
| :-: |
| 1\. Type of interest conveyed ( _e.g._, fee simple, lease, executory real estate contract). |
| 2\. Date of recording of instrument conveying property to taxpayer. |
| 3\. Date of execution and recording of mortgage, deed of trust, or other notice of lien. |
| 4\. Place(s) of recording of mortgage, deed of trust, or other notice of lien. |
| 5\. Who took possession and when (constructive possession?). |
| 6\. Property description: |
|  | a. If by metes and bounds, does description make an enclosed area? |
|  | b. County and state of location. |
| 7\. Minerals—realty versus personalty. |
| 8\. Mechanic lien rights accrued but not yet perfected by recording? |

**Exhibit 34.12.1-8**

### Preparation of Suit Letters — Checklist

|  |
| --- |
| ( _Note_: This checklist is to be used as a supplement to, not a substitute for, official directives.) |
| **1\. General and Specific Requirements for Suits** |
|  | (a) Tax Data. Is it set forth completely? Is the Form 4340 complete and current? Each item of tax and penalty specifically identified? |
|  | (b) Periods of Limitation on Assessment and Collection. Was tax assessed over three years from the date return was due? Has the normal ten-year period for collection after assessment expired? Explain extensions of and exceptions to these periods. Are deadline dates set forth clearly for DOJ? Are there special periods applicable to estate and gift taxes? Waivers? Is proof submitted? |
|  | (c) Penalties. What evidence can DOJ present to the court to show why and how each penalty was incurred? Are IRC sections cited? |
|  | (d) Administrative Remedies. Specifically, what efforts were made by the Area Director to effect collection? Were they exhausted? |
|  | (e) Field Counsel Collection Efforts. Are they described in the letter to DOJ? |
|  | (f) Refiling of Notice of Lien. If applicable, set forth in the DOJ letter. |
|  | (g) Recommendation to DOJ. Is the letter specific as to the action we want DOJ to take? |
|  | (h) Taxpayer TIN. Is the taxpayer’s TIN (prefixed by SSN: or EIN: as appropriate) in the caption following the taxpayer’s name? |
|  | (i) Collection Due Process. If there have been any prior proceedings under IRC §§ 6320 or 6330, include an issue preclusion analysis. |
|  | (j) Pending Administrative Actions. Are there any pending Offers in Compromise, Installment Agreements, or other actions (e.g. pending actions with the Taxpayer Advocate)? If so, referral may be inappropriate. |
| **2\. Foreclosure of the Tax Lien** |
|  | (a) Administrative efforts? |
|  | (b) Will assets be dissipated or concealed? |
|  | (c) Property description. Is it adequate? |
|  | (d) Competing lienors. Is there a discussion of the merits of their claims and are addresses included? |
|  | (e) Reducing the Tax Claim to Judgment in the same action. DOJ wants a recommendation, pro or con, in every foreclosure letter. |
|  | (f) Receiver. Is one needed? The certificate for a receiver is not sent by the DOJ letter. It is supplied by letter transmittal but is sent with a proposed letter to Division Counsel (Small Business/Self Employed). |
|  | (g) Principal Residence. If the property at issue is a principal residence, has the approval of the Area Director been obtained? |
| **3\. IRC § 6334(e)(1) Proceeding** |
|  | (a) Property Description. If the property at issue is the principal residence of the taxpayer’s spouse, former spouse, or minor child, include the name of that person or persons. |
|  | (b) Status Investigation. Has an investigation been made pursuant to IRC § 6331(j)? |
|  | (c) Collection Due Process. If there have been any prior proceedings under IRC §§ 6320 or 6330, include an issue preclusion analysis. |
|  | (d) Approval. The written approval of the Area Director should be included with the suit letter. |
| **4\. Reducing the Tax Claim to Judgment.** |
|  | (a) Does the letter describe collection efforts since assessment and how we can reasonably expect DOJ to collect after the judgment is obtained? |
|  | (b) What assets do we expect to be available later? |
|  | (c) Is IRC § 7401 cited? |
| **5\. Transferee Liability and Fraudulent Conveyance.** There are three methods by which to proceed. |
|  | (a) Is state law adequately discussed? |
| **6\. Enforcing the Levy.** Has foreclosure of the tax lien been considered and discussed? |
| **7\. Intervention** |
|  | (a) Jurisdiction. Are the facts and applicable law set forth? |
|  | (b) State Courts. Will the Government’s right be protected? Would an alternative action, such as removal, be more effective? |
|  | (c) Timeliness |
| **8\. Construction Contracts** |
|  | (a) Amount Subject to Lien. Does it represent progress payments or retained fund? |
|  | (b) Progress payment. Did we serve a levy? |
|  | (c) Competing lienors. Are they and the priority of their claims described? |
|  | (d) Laborers and materialmen. Does the tax lien arise from labor paid under the contract? Does it encumber payments due to unpaid laborers and materialmen under the same contract? |
|  | (e) Priority. Did any of the federal tax liens arise prior to the contract? |
|  | (f) State Law. Does it provide a statutory trust fund designating the Government as a beneficiary? |
|  | (g) Government Contracts. Can we effect a setoff? |
|  | (h) Miller Act. Performance Surety Bond, 40 U.S.C. § 270a. Can we collect under this statute? |
|  | (i) Third party liability. Did third parties pay wages or supply funds so as to be liable for withheld taxes under IRC § 3505? |
| **9\. Trust Fund Recovery Penalty Cases (IRC § 6672).** Does the file show financial status of primary obligor and the possibility of collecting from other officers, partners or employees? Are "responsibility" and "willfulness" set forth in the file? |
| **10\. Miscellaneous** |
|  | (a) Signature of Chief Counsel. Letter should be signed by Field Counsel. |
|  | (b) Sensitive Cases. Could this case cause notoriety? |
|  | (c) Coordination. Should we contact other divisions of the Office of Chief Counsel or National Office of the Service? |
|  | (d) Fraud. Can the Government carry the burden of proof? |
|  | (e) Constitutional questions, tainted evidence and illegal evidence. Discussion adequate? |
|  | (f) SOP Procedures. Have SOP procedures been complied with? |

**Exhibit 34.12.1-9**

### Memorandum from Chief Counsel to General Counsel, Treasury Department, Re: Appointing Agent (where tax lien is not senior lien)

|  |
| --: |
|  | **Office of Chief Counsel**<br>**Internal Revenue Service**<br>**m e m o r a n d u m** |
| **date:** |  |
| **to:** | THE GENERAL COUNSEL<br> TREASURY DEPARTMENT |
| **from:** | Chief Counsel<br> Internal Revenue Service |
| **subject:** | Request for Appointment of Agent in United States v. \[Name\]<br> Civil No. \[case no. and citation\] |
|  | ACTION FORCING EVENT: The Department of Justice, Tax Division, has requested appointment of an agent to purchase \[#\] properties at a judicial foreclosure sale in the event no purchasers offer the required minimum bid. \[#\] of the properties are encumbered only by federal tax liens. The purchase of these properties \[and/or\] appointment of the agent may be authorized by the Deputy Commissioner, Internal Revenue Service. \[However, on the third property, the federal tax liens are junior to a mortgage. In such cases the General Counsel (through delegation from the Secretary) has the authority to authorize the purchase of the property and appointment of the agent. Thus, we are simultaneously requesting that the General Counsel authorize our agent to purchase this third property\] |
|  | RECOMMENDATION: I recommend that you sign the attached appointment document authorizing agent \[name\] to purchase the subject property. |
|  | BACKGROUND AND ANALYSIS: This action was commenced by the United States to reduce to judgment assessments of outstanding income tax, penalties, and interest against \[name(s)\] (taxpayers) and to foreclose federal tax liens against \[#\] properties equitably owned by the taxpayers, \[but held by \[name\] as nominee\]. The properties are: \[property addresses\]. \[Describe properties, _e.g._, the properties are rental apartment residences; are vacant, the tenants having been evicted by the United States Marshals Service; are subject to a mortgage, which has priority over the filed federal tax liens\]. |
|  | On \[date\], the District Court found the taxpayers liable for numerous assessments and that the Government was entitled to foreclose upon the \[#\] subject properties, because the taxpayers’ transfer of the \[#\] properties to \[name\] was a fraudulent conveyance under \[State\] law. On appeal, the \[#\] Circuit upheld the foreclosure, but reversed the District Court’s finding that the taxpayers were liable for civil penalties under I.R.C. § 6702 for certain tax years. The District Court amended final judgment, dated \[date\], indicates that \[name\] is liable for penalties and taxes totaling $ \[amount\] and \[name 2\] is liable for taxes totaling $ \[amount\] (copy attached). The amended judgment decrees that the tax liens of the United States are foreclosed and the property sold with the proceeds of the sale to be paid over to the United States, after the loan amount secured by a mortgage on the \[property\] is paid in full. As of \[date\], the loan balance owed is $ \[amount\]. |
|  | A judicial sale of the \[properties\] was conducted by the Marshals Service on \[date\]. At that sale, \[describe particular incidents of the sale, and also why the United States should purchase the property ( _e.g._, disruptive taxpayers, refusal of court to grant other relief, lack of other collection alternatives)\]. |
|  | The statutes and delegations provide that under 31 U.S.C. § 3715, the Secretary is authorized to purchase real property upon which the United States has a lien at a judicial foreclosure sale. Section 7403(c) of the Internal Revenue Code grants similar authority, limited to purchase of property upon which the United States has a first lien. You have been delegated authority under 31 U.S.C. § 3715. Treasury Order 101-05 (January 7, 1999), paragraph 9 (delegating authority to General Counsel to perform any function the Secretary of the Treasury is authorized to perform). Similarly, the Commissioner has been delegated authority under I.R.C. § 7403(c). Treasury Order 150-10 (delegating to Commissioner the Secretary’s authority to enforce and administer the internal revenue laws). The Commissioner has further delegated that authority to the Deputy Commissioner. Delegation Order 193 (Rev. 6). Appointment of an agent is necessary because currently there is no delegation of authority from the General Counsel or the Deputy Commissioner to any Service officer or employee to purchase property at a judicial foreclosure sale pursuant to I.R.C. § 7403(c) or 31 U.S.C. § 3715. |
|  | Because the Secretary’s delegation to the Commissioner is limited to the authority found in I.R.C. § 7403(c), to purchase property on which the United States has a first lien, appointment of an agent by you under 31 U.S.C. § 3715 is necessary to purchase the \[property\], on which the United States is the junior lienor. A request for appointment of an agent to purchase the \[#\] other properties on which the United States has a first lien is being submitted to the Deputy Commissioner. |
|  | Agent \[name\], Internal Revenue Service Property Appraisal and Liquidation Specialist (PALS), who is familiar with the properties and with the proceedings, has agreed to act as agent on behalf of the United States. \[PALS name\] estimates the fair market value and the minimum bid for the \[property\] to be $ \[amount\] and $\[amount\], respectively. We recommend that, pursuant to the provisions of 31 U.S.C. § 3715, you appoint \[PALS name\], IRS PALS to act as agent of the United States with authority to bid on the interests of the taxpayers in the \[property\], but not to bid higher than the minimum bid amount. If the United States purchases the property, the Marshals Service will be required by the judgment to pay approximately $\[amount\] to \[mortgagor\]. The remainder of the purchase price will be credited to reduce the judgment amount and the taxpayers’ liabilities. \[PALS name\] will then sell the property in a private sale, at which he expects to receive at least $\[amount\], the forced sale value. This should result in net revenue of at least $\[amount\]. |
|  | If you agree with my recommendation, please sign the attached appointment of agent. We will inform \[PALS name\] of his appointment and advise the Department of Justice. |
|  | Attachments (2) |
|  | cc: Assistant Chief Counsel (CBS) |

**Exhibit 34.12.1-10**

### Document Executed by General Counsel Appointing the Agent (where tax lien is not senior lien)

| \[Memorandum\] |
| :-: |
| **date:** |  |
| **to:** | \[Appointed Agent\] |
| **from:** | General Counsel<br> U.S. Department of Treasury |
| **subject:** | United States v. \[name\]<br> Civil No. \[case no. and court\] |
| Pursuant to my authority to act for the Secretary of the Treasury, as granted under Treasury Order 101-05, and pursuant to 31 U.S.C. § 3715, I appoint you, \[PALS name\], Property Appraisal and Liquidation Specialist, to act as agent for the Secretary of the Treasury at the forthcoming sale of the interest of \[taxpayers\] in the \[improved\] real property located at \[address\], upon the judgment rendered in favor of the United States against \[name\], in the case of \[name of case\], Civil No. \[case no.\] in the United States District Court for the \[location\]. |
| As agent of the Secretary of the Treasury, you shall exercise the authority vested in you in accordance with 31 U.S.C. § 3715 but not to bid higher than the minimum bid (approximately $\[amount\]) for the \[improved\] real property located at \[address\]. |

**Exhibit 34.12.1-11**

### Memorandum from Chief Counsel to Commissioner of the Internal Revenue – Re: Appointing Agent (where tax lien is senior lien)

|  |
| --: |
|  | **Office of Chief Counsel**<br>**Internal Revenue Service**<br>**m e m o r a n d u m** |
| **date:** |  |
| **to:** | COMMISSIONER OF THE INTERNAL REVENUE |
| **from:** | Chief Counsel<br> Internal Revenue Service |
| **subject:** | Request for Appointment of Agent in _United States v. \[Name\]_<br> Civil No. \[case no. and citation\] |
|  | ACTION FORCING EVENT: The Department of Justice, Tax Division, has requested appointment of an agent to purchase \[#\] properties at a judicial foreclosure sale in the event no purchasers offer the required minimum bid. \[#\] of the properties are encumbered only by federal tax liens. You may authorize the purchase of these properties or the appointment of the agent where the United States has a first lien. \[However, on the third property, the federal tax liens are junior to a mortgage. In such cases the General Counsel (through delegation from the Secretary) has the authority to authorize the purchase of the property and appointment of the agent. Thus, we are simultaneously requesting that the General Counsel authorize our agent to purchase this third property\] |
|  | RECOMMENDATION: I recommend that you appoint an agent to purchase the subject property. |
|  | BACKGROUND AND ANALYSIS: This action was commenced by the United States to reduce to judgment assessments of outstanding income tax, penalties, and interest against \[name(s)\] (taxpayers) and to foreclose federal tax liens against \[#\] properties equitably owned by the taxpayers, \[but held by \[name\] as nominee\]. The properties are: \[property addresses\]. \[Describe properties, _e.g._, the properties are rental apartment residences; are vacant, the tenants having been evicted by the United States Marshals Service; is subject to a mortgage, which has priority over the filed federal tax liens\]. |
|  | On \[date\], the District Court found the taxpayers liable for numerous assessments and that the Government was entitled to foreclose upon the \[#\] subject properties, because the taxpayers’ transfer of the \[#\] properties to \[name\] was a fraudulent conveyance under \[State\] law. On appeal, the \[#\] Circuit upheld the foreclosure, but reversed the District Court’s finding that the taxpayers were liable for civil penalties under I.R.C. § 6702 for certain tax years. The District Court amended final judgment, dated \[date\], indicates that \[name\] is liable for penalties and taxes totaling $ \[amount\] and \[name 2\] is liable for taxes totaling $ \[amount\] (copy attached). The amended judgment decrees that the tax liens of the United States are foreclosed and the property sold with the proceeds of the sale to be paid over to the United States, after the loan amount secured by a mortgage on the \[property\] is paid in full. As of \[date\], the loan balance owed is $ \[amount\]. |
|  | A judicial sale of the \[properties\] was conducted by the Marshals Service on \[date\]. At that sale, \[describe particular incidents of the sale, and also why the United States should purchase the property ( _e.g._, disruptive taxpayers, refusal of court to grant other relief, lack of other collection alternatives)\]. |
|  | The statutes and delegations provide that under 31 U.S.C. § 3715, the Secretary is authorized to purchase real property upon which the United States has a lien at a judicial foreclosure sale. Section 7403(c) of the Internal Revenue Code grants similar authority, limited to purchase of property upon which the United States has a first lien. You have been delegated authority under 31 U.S.C. § 3715. Treasury Order 101-05 (January 7, 1999), paragraph 9 (delegating authority to General Counsel to perform any function the Secretary of the Treasury is authorized to perform). Similarly, the Commissioner has been delegated authority under I.R.C. § 7403(c). Treasury Order 150-10 (delegating to Commissioner the Secretary’s authority to enforce and administer the internal revenue laws). The Commissioner has further delegated that authority to the Deputy Commissioner. Delegation Order 193 (Rev. 6). Appointment of an agent is necessary because currently there is no delegation of authority from the General Counsel or the Deputy Commissioner to any Service officer or employee to purchase property at a judicial foreclosure sale pursuant to I.R.C. § 7403(c) or 31 U.S.C. § 3715. |
|  | Because the Secretary’s delegation to the Commissioner is limited to the authority found in I.R.C. § 7403(c), to purchase property on which the United States has a first lien, appointment of an agent by the General Counsel under 31 U.S.C. § 3715 is necessary to purchase the \[property\], on which the United States is a junior lienor. A request for appointment of an agent to purchase the \[property\] is being submitted to the General Counsel. Since the United States has first liens on the \[properties\], you are authorized to appoint an agent under section 7403(c) to purchase these properties, pursuant to the Commissioner’s delegation of authority to you under Delegation Order 193 (Rev. 6). |
|  | Agent \[name\], Property Appraisal and Liquidation Specialist (PALS), who is familiar with the properties and with the proceedings, has agreed to act as agent on behalf of the United States. \[PALS name\] estimates the fair market values and the minimum bids for the \[properties\] as follows: |
|  | \[property\]: fair market value $ \[amount\]; minimum bid $ \[amount\].<br> \[property\]: fair market value $\[amount\]; minimum bid $ \[amount\]. |
|  | In view of the request of the Department of Justice, it is recommended that, pursuant to I.R.C. § 7403(c), you appoint Agent \[name\], IRS PALS to act as agent of the United States with authority to bid on the interests of the taxpayers in the \[properties\], but not to bid higher than the minimum bid amounts. |
|  | If you agree with my recommendation, please sign the attached appointment of agent. We will inform \[PALS name\] of \[his/her\] appointment and advise DOJ. |
|  | Attachments (2) |
|  | cc: Assistant Chief Counsel (CBS) |

**Exhibit 34.12.1-12**

### Document Executed by Commissioner of the Internal Revenue Appointing Agent (where tax lien is senior lien)

| \[Memorandum\] |
| :-: |
| **date:** |  |
| **to:** | \[Appointed Agent\] |
| **from:** | General Counsel<br> U.S. Department of Treasury |
| **subject:** | United States v. \[name\]<br> Civil No. \[case no. and court\] |
| Pursuant to my authority to act for the Secretary of the Treasury, as granted under Treasury Order 150-10, and Delegation Order 193 (Rev. 6), and pursuant to I.R.C. § 7403(c), I appoint you, \[PALS name\], Property Appraisal and Liquidation Specialist, to act as agent for the Secretary of the Treasury at the forthcoming sale of the interest of \[taxpayers\] in the \[improved\] real property located at \[address\], upon the judgment rendered in favor of the United States against \[name\], in the case of \[name of case\], Civil No. \[case no.\] in the United States District Court for the \[location\]. |
| As agent of the Secretary of the Treasury, you shall exercise the authority vested in you in accordance with I.R.C. § 7403(c) but not to bid higher than the minimum bid (approximately $ \[amount\]) for the \[improved\] real property located at \[address\]. |

**Exhibit 34.12.1-13**

### Letter to Agent Advising of Appointment

| \[Letterhead\] |
| :-: |
| Agent \[name\]<br> Property Appraisal and Liquidation Specialist<br> Internal Revenue Service<br> \[address\] |  |
|  |  |  | United States v. \[name\]<br> Civil No. \[case no. and court\] |  |
|  |  |  | Taxpayer: \[name(s)\] |  |
|  |
| Dear \[PALS name\]: |  |
| You are hereby advised that pursuant to the provisions of section 3715 of Title 31 of the United States Code, you have been appointed by the General Counsel, Treasury Department, as agent of the United States with authority to act for the United States in the purchase of property of \[name\] at any forthcoming sale thereof in the above-described proceeding in satisfaction or partial satisfaction of the item of Federal tax claimed and allowed therein. However, in no case shall you bid in behalf of the United States a greater amount than $ \[amount\]. Enclosed herewith are the appointment, together with a copy thereof, which has been executed by the General Counsel and a copy of our memorandum to the General Counsel. |
|  |  |  |  |  |
|  |  |  |  | Sincerely yours, |
|  |
|  |  |  |  | \[name\]<br> Chief Counsel |
|  |  |  |  |  |
| Enclosures |
|  | \[ _Note_: distribution as follows:\] |
|  |  | 2 cc: Assistant Chief Counsel (CBS)<br> 1 cc: Area Counsel (office where case is located)<br> 1 cc: Department of Justice, Tax Division, Civil Trial Section, \[Region\]. |

**Exhibit 34.12.1-14**

### Letter to Tax Division of Department of Justice Advising It of Appointment of Agent

| \[Letterhead\] |
| :-: |
| Honorable \[name\]<br> Assistant Attorney General<br> Tax Division<br> Department of Justice<br> Washington, D.C. 20530 |
|  |  | Attn: Chief, Civil Trial Section, \[Region\] |
|  |  | In re: | United States v. \[name\]<br> Civil No. \[case no. and court\] |  |
|  |  | Taxpayer: \[name\] |
|  |  |  |  |  |
| Dear \[Assistant Attorney General\]: |  |
| This is in reply to your letter to this office dated \[date\], relative to the appointment of an agent with authority to act for the United States at the forthcoming sale of certain property of the above-named taxpayer. |
| Please be advised that Agent \[name\], Property Appraisal and Liquidation Specialist, IRS, \[location\], has been appointed in accordance with section 3715 of Title 31 of the United States Code, as agent of the United States with authority to act for the United States in the purchase of the property. A copy of the appointment is enclosed. Title should be executed by the Marshall in the name of the United States, if \[PALS name\] is the successful bidder. Sale or other appropriate disposition will then be made pursuant to section 7506 of the Internal Revenue Code. |
|  |
|  |  |  |  | Sincerely yours, |
|  |
|  |  |  |  | \[name\]<br> Chief Counsel |
|  |
| Enclosures |
|  | \[ _Note_: cc distribution as follows:\] |
|  |  | 2 cc: Assistant Chief Counsel (CBS)<br> 1 cc: Area Counsel (office where case is located) |

**Exhibit 34.12.1-15**

### Motion for Writ of Ne Exeat

|  |
| --- |
| United States Attorney<br> Assistant United States Attorney Division<br> \[address and phone no.\]<br> Attorneys for Plaintiff |
|  |
| IN THE UNITED STATES DISTRICT COURT FOR THE \[LOCATION\] |
|  |
| UNITED STATES OF AMERICA, | ) |  |
|  | Plaintiff, | ) |  |
|  |  | ) | CASE NO. |
| v. |  | ) |  |
|  |  | ) | MOTION FOR WRIT OF NE EXEAT |
|  | Defendant. | ) |  |  |
|  |  | ) |  |  |
|  |
| The United States of America, by its attorney, the United States Attorney, moves this Court issue a writ of ne exeat directed against defendant on the ground that such defendant intends quickly to depart from the continental limits of the United States, as more particularly appears from the affidavit of Area Director, \[organization\] of the Internal Revenue Service, duly authorized agent of the United States of America, which affidavit is attached pursuant to the provisions of section 1651, Title 28 of the United States Code, and section 7402(a), Title 26 of the United States Code. |
|  |
| WHEREFORE, it is prayed that this motion be granted. |
|  | DATED:<br> United States Attorney |
|  |  |
|  | By:<br> \[name\]<br> Assistant United States Attorney<br> Tax Division |

**Exhibit 34.12.1-16**

### Affidavit with Motion in the United States District Court

|  |
| --- |
| UNITED STATES OF AMERICA, | ) |  |
|  |  | Plaintiff | ) |  |
|  | ) | CASE NO. |
| v. |  | ) |  |
| \[NAME\] |  | ) |  |
|  |  | Defendant | ) |  |
|  |  |  | ) |  |
| STATE OF | ) |  |
|  | ) SS.: |  |
| COUNTY OF | ) |  |
|  |
| I, Area Director \[organization\]. a duly authorized and designated agent of the United States of America, plaintiff in the above-entitled action, being first duly sworn, depose and say: |
| 1\. That the above-entitled action is for the collection, in whole or in part, of delinquent and unpaid federal income taxes, penalties and interest for the taxable years \[year\] to \[year\], inclusive, in the amount of $\[amount\]; that the defendant \[name\] is as affiant is informed and believes, about to depart from the United States taking with him considerable sums of money or its equivalent, either in the form of cash, travelers checks, letters of credit, or some other form of negotiability, with the intent of defeating the plaintiffs claim. |
| 2\. That this action was filed on \[date\], and the summons and complaint served on the defendant at \[location\], on \[date\], as more fully appears from the return of the Marshall to the summons and complaint. |
| 3\. That your affiant is informed and believes that the said has recently made application for passports for himself, as well as for members of his family, so that he may depart from the limits of the United States and the jurisdiction of this Court; and your affiant verily believes and says that if said defendant is allowed to depart from the limits of this area and the jurisdiction of this Court, as aforesaid, the plaintiffs claim will be partly or wholly lost. |
|  |
| Area Director \[organization\]<br> Internal Revenue Service |
|  |  |
| STATE OF | ) |
|  | ) SS.: |
| COUNTY OF | ) |
|  |
| Subscribed and sworn to before me this day of \[date\], |
|  |
| Notary Public |
|  |
| My Commission Expires \[date\] |
| (SEAL) |

**Exhibit 34.12.1-17**

### Writ of Ne Exeat

|  |
| --- |
| United States Attorney<br> Assistant United States Attorney Division<br> \[address and phone no.\]<br> Attorneys for Plaintiff |
|  |
| IN THE UNITED STATES DISTRICT COURT FOR THE \[LOCATION\] |
|  |
| UNITED STATES OF AMERICA, | ) |  |
|  | Plaintiff, | ) |  |
|  |  | ) | CASE NO. |
| v. |  | ) |  |
|  |  | ) | WRIT OF NE EXEAT |
|  | Defendant. | ) |  |  |
|  |  | ) |  |  |
|  |
| THE PRESIDENT OF THE UNITED STATES OF AMERICA TO THE MARSHAL OF THE \[LOCATION\], GREETINGS: |
| WHEREAS, among other things, it is represented to this Court, on the part of the United States of America, plaintiff, against \[name\], defendant, that the above-entitled action is for the collection of delinquent and unpaid federal income taxes, penalties and interest for the taxable years \[year\] to \[year\], inclusive. due from the said \[name\], defendant; that said \[name\]. defendant, is greatly indebted to the said plaintiff for the delinquent taxes, penalties and interest as aforesaid, and that \[he/she\] designs quickly to go into parts beyond the limits of the United States (as by oath made in that behalf appears), which tends to the great prejudice and damage of the said plaintiff; |
| THEREFORE, in order to prevent this injustice, we hereby command you that you do, without delay, cause the said \[name\]. defendant, to come before you and give sufficient bailor security. in the sum of$ \[amount\], that \[he/she\] will not go or attempt to go, beyond the jurisdiction of this Court, without the leave of this Court; and in case the said \[name\] shall refuse to give such bailor security, then you are to commit the said \[name\], to jail, there to be kept in safe custody until \[he/she\] shall do it of \[his/her\] own accord; and when you shall have taken such security you are forthwith to make and return a certificate thereof to this Court distinctly and plainly, under your hand, together with this writ. |
|  |  |
|  | Clerk of the United States<br> District Court for the \[location\] |

**Exhibit 34.12.1-18**

### Order for Writ of Ne Exeat

|  |
| --- |
| United States Attorney<br> Assistant United States Attorney Division<br> \[address and phone no.\]<br> Attorneys for Plaintiff |
|  |
| IN THE UNITED STATES DISTRICT COURT FOR THE \[LOCATION\] |
|  |
| UNITED STATES OF AMERICA, | ) |  |
|  | Plaintiff, | ) |  |
|  |  | ) | CASE NO. |
| v. |  | ) |  |
|  |  | ) | ORDER FOR WRIT OF NE EXEAT |
|  | Defendant. | ) |  |  |
|  |  | ) |  |  |
|  |
| Upon the motion of the plaintiff in the above-entitled case, as represented by the United States Attorney for the \[court\], this cause came on to be heard for the issuance of a writ of ne exeat against the defendant, \[name\], and upon consideration of the affidavits annexed to such motion, and it appearing to the Court that the action is one for equitable relief and that the aforesaid defendant designs quickly to depart from the United States. |
| IT IS ORDERED that a writ of ne exeat republica issue out of an order under the seal of this Court to restrain the said from departing out of the jurisdiction of this Court until further order of the Court, and requiring him to give security in the amount of $ _\[amount\]_, plus interest according to law, to the date of this order. |
| Dated this day of \[month and year\]. |
|  |  |
| UNITED STATES DISTRICT JUDGE |

**Exhibit 34.12.1-19**

### Bond With Writ

|  |
| --- |
| United States Attorney<br> Assistant United States Attorney Division<br> \[address and phone no.\]<br> Attorneys for Plaintiff |
|  |
| IN THE UNITED STATES DISTRICT COURT FOR THE \[LOCATION\] |
|  |
| UNITED STATES OF AMERICA, | ) |  |
|  | Plaintiff, | ) |  |
|  |  | ) | CASE NO. |
| v. |  | ) |  |
|  |  | ) | BOND |
|  | Defendant. | ) |  |  |
|  |  | ) |  |  |
|  |
| We, the undersigned, jointly and severally acknowledge that we and our personal representatives are bound to pay to the United States of America the sum of $ \[amount\], plus interest as provided by law to the date of this bond. The conditions of this bond arc that \[name\], defendant in the above-captioned action, is not to go, nor to attempt to go, beyond the jurisdiction of this Court without leave of this Court. If the said defendant, \[name\], shall remain within the jurisdiction of this Court, and shall not go beyond nor attempt to go beyond such jurisdiction without leave of this Court, then this bond shall be wholly void and of no effect; but if said defendant fails faithfully to obey or perform any of these conditions, payment of the amount of this bond shall become due forthwith, and judgment for such amount may be entered against the said and the undersigned sureties without notice. It is agreed and understood that this bond shall remain in full force and effect until such time as the undersigned are duly exonerated by this Court. |
| This bond signed at this day of \[date\]. |
|  |
| \[Taxpayer\] |  |
|  |
| \[Surety\] | \[Surety\] |
| Signed and acknowledged before me this day of \[date\] |
|  |  |  |  |  |
| (NOTARY PUBLIC)<br> My commission expires: |

**Exhibit 34.12.1-20**

### Certificate for Appointment of Receiver

| \[TREASURY DEPARTMENT\] |
| :-: |
| IN THE MATTER OF: |
| Pursuant to the provisions of I.R.C. § 7403 and Treas. Reg. § 301.7403-1(a), I certify that it is in the public interest that a receiver, with all the powers of a receiver in equity, be appointed in the above-entitled suit. This authority has been delegated to me by the Chief Counsel in the Chief Counsel Directives Manual. |
| Signed and dated at Washington, DC, this \[day\] of \[month and year\]. |
|  |
|  |
|  | \[NAME\]<br> Chief Counsel<br> for the Internal Revenue Service |
|  |
|  | By: |
|  | \[NAME \]<br> Division Counsel<br> (Small Business/Self-Employed) |

**Exhibit 34.12.1-21**

### Petition

|  |
| --- |
| IN THE UNITED STATES DISTRICT COURT FOR THE \[DISTRICT\] |
|  |
| UNITED STATES OF AMERICA, | ) |  |
|  |  | ) |  |
|  | Petitioner | ) |  |
| v. |  | ) |  |
|  |  | ) | CIVIL ACTION NO. \[case no.\] |
|  |  | ) |  |  |
| \[NAME\] |  | ) |  |  |
|  | Respondent(s) | ) |  |  |
|  |
| PETITION TO ENFORCE INTERNAL REVENUE SERVICE SUMMONS |
|  |
| The United States of America, on behalf of its agency, the Internal Revenue Service, and by its attorney, \[name\], United States Attorney for the \[District\], avers to this Court as follows: |
| I. |
| This is a proceeding brought pursuant to the provisions of sections 7402(b) and 7604(a) of Title 26, U.S.C., to judicially enforce an Internal Revenue Service summons. |
| II. |
| \[Name of the person seeking enforcement\] is a \[title\] of the Internal Revenue Service, employed in the \[Division\], and is authorized to issue an Internal Revenue Service summons pursuant to the authority contained in section 7602 of Title 26, U.S.C., and 26 C.F.R. § 301.7602-1. |
| III. |
| The respondent, \[name\], resides or is found at \[address\] within the jurisdiction of this court. |
| IV. |
| \[Name of person conducting investigation and title\] is conducting an investigation \[into the tax liability of/for the collection of the tax liability of\] \[name of taxpayer\] for the \[year(s) or taxable period(s)\] as is set forth in the Declaration of \[name and title\] attached hereto as Exhibit \[#\]. |
| V. |
| The respondent, \[name\], is in possession and control of testimony and documents concerning the above-described investigation. |
| VI. |
| On (date) an Internal Revenue Service summons was issued by \[name of person issuing summons and title\], directing the respondent, \[name\], to appear before \[name and title of person before whom respondent is to appear\], on \[date\], at \[time\], at \[location\], \[to testify and/or to produce for examination, books, papers, records, or other data described in the summons\]. An attested copy of the summons was \[personally served on or left at last and usual place of abode of or mailed by registered or certified mail\] to (If the summoned party is a third party record-keeper as defined in section 7603) the respondent, \[name of summoned person\], by \[name of person who served summons and title\], on \[date\]. The summons is attached and incorporated as Exhibit \[#\]. |

|  |
| --- |
| VII. |
| On \[date\], \[name and title\] served the notice required by section 7609(a) of Title 26, U.S.C., on \[person(s) entitled to notice\], by \[show manner of service, i.e., personal, left at last and usual place of abode, sent by registered or certified mail, or left with the person summoned\]. |
| VIII. |
| On \[date\] the respondent, \[name of summoned person\], \[did not appear in response to the summons/appeared but refused to comply with the summons by testifying or by producing the books, records, and other documents demanded in the summons\]. The respondent's refusal to comply with the summons continues to date as is set forth in the declaration of \[name\], attached as Exhibit \[#\]. |
| IX. |
| The books, papers, records. or other data sought by the summons are not already in possession of the Internal Revenue Service \[except as follows: specify any summoned materials that have been obtained since the summons was served\]. |
| X. |
| All administrative steps required by the Internal Revenue Code for the issuance of a summons have been taken. |
| XI. |
| It is necessary \[to obtain the testimony and/or to examine the books, papers, records, or other data\] sought by the summons in order \[to properly investigate/to collect\] the Federal tax liability of \[name of taxpayer\] for the \[year(s) or taxable period(s)\], as is evidenced by the declaration of \[name of person executing appropriate declaration and title\], attached and incorporated as part of this petition. |
| WHEREFORE. the petitioner respectfully prays: |
| 1\. That this court enter an order directing the respondent, \[name of summoned person\], to show cause, if any, why \[he/she/it\] should not comply with and obey the aforementioned summons and each and every requirement thereof. |
| 2\. That the court enter an order directing the respondent, \[name of summoned person\], to obey the aforementioned summons and each and every requirement thereof by ordering the attendance, testimony, and production of the books, papers, records, or other data as is required and called for by the terms of the summons before \[name and title of person before whom respondent is to appear\], or any other proper officer or employee of the Internal Revenue Service, at such time and place as may be fixed by \[name of person to issue such direction and title\], or any other proper officer or employee of the Internal Revenue Service. |
| 3\. That the United States recover its costs in maintaining this action. |
| 4\. That the court grant such other and further relief as is just and proper. |
|  |  |  | \_ |
|  |  |  | UNITED STATES ATTORNEY |

|  |
| --- |
| INSTRUCTIONS TO PETITION TO<br> ENFORCE INTERNAL REVENUE SERVICE SUMMONS |
| The following numbers correspond to the numbered paragraphs in the petition. Those paragraphs not referred to in the instructions should be self-explanatory. |
| II. |
| An officer or employee of the Assistant Commissioner (International) should substitute Office of the Assistant Commissioner (International) for Office of the District Director. |
| If the petitioner is not the same Internal Revenue Service officer or employee who issued the summons, then this paragraph should be modified to reflect this fact. |
| VII. |
| This paragraph should be used only when the summons is directed to a third-party. |
| IX. |
| This is a general provision. However, in the event the Service does have some of the summoned materials at the time of the enforcement proceeding, those materials should be excepted. |

**Exhibit 34.12.1-22**

### Declaration

|  |
| --- |
| IN THE UNITED STATES DISTRICT COURT FOR THE \[DISTRICT\] |
|  |
| UNITED STATES OF AMERICA, | ) |  |
|  |  | ) |  |
|  | Petitioner | ) |  |
| v. |  | ) |  |
|  |  | ) | CIVIL ACTION NO. \[case no.\] |
|  |  | ) |  |  |
| \[NAME\] |  | ) |  |  |
|  | Respondent(s) | ) |  |  |
|  |
| DECLARATION |
| \[Name\] declares: |
| 1\. I am a duly commissioned \[title\] employed in the \[Division\] of the office of the \[office\] at \[location\]. |
| 2\. In my capacity as a \[title\], I am conducting an investigation \[into the tax liability of/for the collection of the tax liability of\] \[name of taxpayer\] for the \[years(s) or taxable period(s)\]. |
| 3\. In furtherance of the above investigation and in accordance with section 7602 of Title 26, U.S.C., I issued on \[date\] an administrative summons, Internal Revenue Service Form \[number\], to \[name of summoned person\], \[to give testimony and/or to produce for examination books, papers, records, or other data as described in said summons\]. |
| The summons is attached to the petition as Exhibit \[#\]. |
| \[To be used when the Service employee executing the declaration did not perform the relevant activity\]<br> 4\. I have been advised by \[specify title and name of person serving summons\], that on \[date\], in accordance with section 7603 of Title 26, U.S.C., \[he/she\] served an attested copy of the Internal Revenue Service summons described in paragraph 3 above on the respondent, \[name of summoned person\] by \[specify manner of service\]. This is further evidenced in the certificate of service on the reverse side of the summons. |  | \[To be used when the Service employee executing the declaration did perform the relevant activity\]<br> 4\. In accordance with section 7603 of Title 26, U.S.C., on \[date\], I served an attested copy of the Internal Revenue Service summons described in paragraph 3 above on the respondent, \[name of summoned person\], by \[specify manner of service\], as evidenced in the certificate of service on the reverse side of the summons. |
| 5\. On \[date\], the notice required by section 7609(a) of Title 26, U.S.C., was served by \[specify title and name of person serving notice\], on \[specify persons entitled to notice\], by \[specify manner of service, _i.e._, persona!, left at last and usual place of abode, sent by registered or of abode, sent by registered or certified mail, or left with the person summoned\]. I have been apprized of this by \[specify titles and names of person serving notice\] and it is further evidenced in the certificate of service of notice on the reverse side of the summons. |  | 5\. On \[date\], I served the notice required by section 7609(a) of Title 26, U. S.C., on \[specify manner of service, _i.e._, personal, left at last and usual place of abode, sent by registered or certified mail, or left with the person summoned\], as evidenced in the certificate of service of notice on the certificate of service of notice on the reverse side of the summons. |
| 6\. I have been informed by \[specify title and name of person designated as the individual before whom the summoned party was to appear\], that on \[date\] the respondent, \[name of summoned person\], \[did not appear in response to the summons/appeared but refused to comply with the summons by producing the books, records, and other documents demanded in the summons or by giving testimony as to the matters requested in said summons\]. The respondent's refusal to comply with the summons continues to the date of this declaration. |  | 6\. On \[date\], the respondent, \[name of summoned person\], did not appear in response to the summons \[appeared but refused to comply with the summons by producing the books, records, and other documents demanded in the summons or by giving testimony as to matters requested in said summons\]. The respondent's refusal to comply with the summons continues to the date of this declaration. |
| 7\. The books, papers, records, or other data sought by the summons are not already in the possession of the Internal Revenue Service \[except as follows: specify any summoned materials that have been obtained since the summons was served\]. |
| 8\. All administrative steps required by the Internal Revenue Code for issuance of a summons have been taken. |
| 9\. It is necessary \[to obtain the testimony and/or to examine the books, papers, records, or other data\] sought by the summons in order \[to properly investigate/to collect\] the Federal tax liability of \[name of taxpayer\] for the \[year(s) or taxable period(s)\]. \[The Internal Revenue Service has not made any recommendation for criminal prosecution to the Department of Justice.\] |
| I declare under penalty of perjury that the foregoing is true and correct. |
| Executed this \[day\] of \[month & year\]. |
|  |  |  | \_\_ |
|  |  |  | \[name and title of person seeking endorsement\] |

|  |
| --- |
| INSTRUCTIONS TO DECLARATION |
| DOJ has the option to request separate declarations where more than one Service employee is involved in issuance, service, or designation as the party before whom the summoned party is to appear. Paragraphs 4, 5, and 6 should be modified as appropriate when separate declarations are required. |
| Paragraph 5 should be used only when a summons is directed to a third-party. |
| Paragraph 7 is a general provision. However, in the event the Service does have some of the summoned material at the time of the enforcement proceeding, those materials shonld be excepted. Moreover, where the summons seeks Wage Tax Statements (W-2), Forms 1099, or other items which the Service technically may have in its possession but which are not available, the paragraph should be modified to include a statement to the effect that these items are not readily accessible or retrievable without undue administrative burden or expense, together with an explanation thereof. Field Connsel may be contacted for assistance in drafting this paragraph. However, before making this statement, the Service employee should attempt to obtain this information from the service centers. |
| Paragraph 9 is a general provision. The sentence in parenthesis need be used only by Special Agents. |

**Exhibit 34.12.1-23**

### Order

|  |
| --- |
| IN THE UNITED STATES DISTRICT COURT FOR THE \[DISTRICT\] |
|  |
| UNITED STATES OF AMERICA, | ) |  |
|  |  | ) |  |
|  | Petitioner | ) |  |
| v. |  | ) |  |
|  |  | ) | CIVIL ACTION NO. \[case no.\] |
|  |  | ) |  |  |
| \[NAME\] |  | ) |  |  |
|  | Respondent(s) | ) |  |  |
|  |
| ORDER TO SHOW CAUSE |
| Upon the petition, the Exhibit(s) attached thereto, the declaration of \[enter name of person seeking enforcement and title\] of the Internal Revenue Service, and upon the motion of \[name), United States Attorney for the \[District\], it is |\
| ORDERED that \[respondent\] appear before the United States District Court for the \[District\], presided over by the undersigned in \[his/her\] courtroom in the United States Courthouse in \[location\], on the \[date\], at \[time\] to show cause why \[he/she/it\] should not be compelled to obey the Internal Revenue Service summons served upon \[him/her/it\] on \[date\]. It is further |\
| ORDERED that a copy of this Order, together with the petition and Exhibit(s) thereto, be personally served upon \[respondent\] on or before \[date\]. It is further |\
| ORDERED within \[#\] days of service of copies of this Order, the petition and Exhibit(s), the respondent shall file and serve a written response to the petition \[supported by appropriate affidavits, as well as any motions the respondent desires to make. All motions and issues raised by the pleadings will be considered on the return date of this Order. Only those issues raised by motion or brought into controversy by the responsive pleadings and supported by affidavit will be considered at the return of this order. Any uncontested allegation(s) in the petition will be considered admitted\]. |\
| DATED at \[location\], this \[date\]. |\
|  |  |  | \_ |\
|  |  |  | UNITED STATES DISTRICT JUDGE |\
\
**Exhibit 34.12.1-24**\
\
### Approval of Settlements by Associate Chief Counsel and Division Commissioner When Required — Closing Agreement\
\
|  |\
| :-: |\
| Department of Justice<br> Tax Division |\
| Memorandum No. 81-51<br> July 28, 1981 |\
| Compromise Procedures |\
| The following procedures have been agreed to by the Internal Revenue Service and the Tax Division: |\
| (1) A proposed settlement including a taxpayer or period not in the pending litigation requires the recommendation of the Assistant Commissioner (Compliance), except in the following situations: |\
|  | (a) A decision by the court could resolve the issue as to the taxpayer or period not in suit; |\
|  | (b) The taxpayer not in suit is conceding the issue, or the taxpayer in litigation is conceding the issue for the subsequent period; or |\
|  | (c) The District Director’s office or the Appeals Division has under consideration the matter as to the taxpayer or period not in suit, and the recommendation of the District Director’s office or the Appeals Division is obtained. |\
| (2) Where a proposed settlement provides for the execution of a closing agreement as part of the settlement, the closing agreement must be reviewed on behalf of the Assistant Commissioner (Compliance) or by the Appeals Division prior to the Government’s acceptance of the offer. |\
|  |  |  |\
|  |  | \[signed\] JOHN F. MURRAY<br> Acting Assistant Attorney General Tax Division |\
|  |  |  |\
\
|     |\
| --- |\
| _Note to Exhibit 34.12.1-24_: In consequence of the reorganization of the Service on March 21, 1982, and again in the year 2000, the title of Assistant Commissioner (Compliance) was abolished. Reference to that title should be construed as though it read Chief Counsel or Associate Chief Counsel in paragraph 1 and Division Commissioner in paragraph 2. However, even when the period or taxpayer not in suit is not being considered by Examination or the local Appeals office, it is not normally necessary to refer the case to an Associate office and have the recommendation approved by the Chief Counsel or the appropriate Associate Chief Counsel. Reference to the Appeals Division in the agreement should be construed as though it read local Appeals office (where a Field case) except that a closing agreement in an Associate office case must only be reviewed on behalf of the appropriate Division Commissioner. |\
\
**Exhibit 34.12.1-25**\
\
### Settlement Letter for Branch Chief’s Signature or Associate Area Counsel Signature\
\
|  |  |  |  |  |  |  |\
| :-: | :-: | :-: | :-: | :-: | :-: | :-: |\
| \[Letterhead\] |\
| \[Name\]<br> Assistant Attorney General<br> Tax Division<br> Department of Justice<br> Washington, D.C. 20530 |  |  |\
|  | Subject: | \[Name\] v. United States<br> \[citation\]<br> Your ref: \[DOJ reference no.\] |  |  |  |\
| Dear \[name\]: |  |  |  |\
| By letter of \[date\], you forwarded three copies of an offer in compromise of the subject case which had been submitted by counsel on behalf of the plaintiff under date of \[date\]. This proposal is supplemented by a letter from counsel of \[date\]. |\
| The suit was instituted on \[date\], in the United States District Court for the \[District\] for the recovery of $ \[amount\], allegedly representing the total overpayment in income taxes and assessed interest for the calendar years \[years\], together with interest and costs. The plaintiff claims refunds of taxes in the respective amounts of $ \[amount\] and $ \[amount\], and of assessed interest in the respective amounts of $ \[amount\]; and $ \[amount\]. |\
| ISSUES |  |  |\
| (1) Were certain expenses properly attributable in each of the taxable years to the mineral property in computing taxable income from the property for purposes of the limitation on the percentage depletion deduction? 0613.03-01; 0613.03-04; 0613.03-05. |\
| (2) Did the taxpayer sustain an abandonment loss in \[year\] resulting from the abandonment of a mine. 0165.10-01; 0165.23-00? |\
| (3) Did the taxpayer sustain net operating losses in \[years\] which resulted in an allowable net operating loss carryover deduction in \[year\]? 0172.02-01; 0172.04-00. |\
| (4) Were expenditures of $ \[amounts\] in \[year\] capital expenditures or rental expenses? 0162.09-07; 0163.13-00. |\
| (5) Is the taxpayer entitled to an additional carryover of unused investment credit to \[year\]? 0046.02-00. |\
| (6) Were expenditures in \[years\] in connection with the ABCD Power and Light Company contract capital expenditures to acquire the contract or development expenses currently deductible? 0263.13-06; 0616.00-00. |\
| OFFER |\
| Counsel proposes that the case be settled on the following basis: |\
| (1) This issue would be conceded by the taxpayer except: |\
|  | a. The expenses charged or allocated to other companies in \[years\] which are treated as reductions from direct mining expenses in the exhibits to the 90-day letter will be treated instead as reductions from indirect expenses; and |\
|  | b. The allocation of the indirect expenses to mining and nonmining activities will be based on the ratio of direct mining costs to total direct costs. |\
| (2) This issue would be conceded by the Government except the amount of the abandonment loss allowable in \[years\] would be limited to $ \[amount\]. |\
| (3) This issue would be automatically adjusted. |\
| (4) This issue would be conceded by the taxpayer. |\
| (5) This issue would be automatically adjusted. |\
| (6) This issue would be conceded by the taxpayer. |\
| RECOMPUTATION |\
| We have had computations prepared pursuant to the terms of the proposal to ascertain the overpayment which would result for the years \[years\] if the proposal were to be accepted. They disclose overpayment of tax in the respective amounts of $ \[amounts\] and overpayments of assessed interest in the respective amounts of $ \[amounts 2\]. The total overpayment of tax would be $ \[total amount\], and of assessed interest would be $ \[interest amount\], a grand total of $ \[grand total amount\]. |\
| DISCUSSION |\
| Issue 1. Depletion |\
| An examination of the computations shows that with respect to the depletion issue there would be under the proposal a reduction in depletion for \[year\] in the amount of $ \[amount\]; an increase in depletion for \[year\] in the amount of $ \[amount\]; a reduction in depletion for \[year\] in the amount of $ \[amount\]; an increase in depletion for \[year\] in the amount of $ \[amount\]; an increase in depletion for \[year\] in the amount of $ \[amount\]; and, a decrease in depletion for \[year\] in the amount of $ \[amount\]. Thus, under the settlement proposal there would be a net decrease in the depletion deductions in the amount of $ \[amount\]. |\
| The depletion issue is thoroughly discussed in a Valuation Report submitted by Internal Revenue Service geologist \[name\] under date of \[date\]. The content of this report is incorporated herein by reference and need not be repeated. The proposed settlement of this issue follows the recommendations and computations of \[name\]. |\
| Issue 2. Abandonment Loss |\
| Essentially, the only concession the Government would be making under the proposal is with respect to the abandonment loss claimed in issue two. |\
| Facts |\
| The following facts support plaintiff’s contention that its \[name of mine\] was not actually abandoned until \[year\] even though regular operations ceased in \[year\]. |\
| \[Balance of discussion of facts omitted.\] |\
| Legal Analysis |\
| Section 165(a) of the Internal Revenue Code of 1954 provides . . . . |\
| \[Balance of legal analysis omitted.\] |\
| RECOMMENDATION |\
| Inasmuch as the geologist has determined the loss which results in the overpayments under the offer in settlement was sustained by the taxpayer in the year \[year\] and our auditor has verified the amount thereof, we recommend that the proposal be accepted. |\
| Three copies of the recomputations dated \[date\], and the original and one copy of the valuation report dated \[date 2\], are enclosed in the administrative files. |\
|  |  |  |  | Sincerely yours, |\
|  |  |  |  |  |  |  |\
|  |  |  |  | \[NAME\]<br> Chief Counsel |\
|  |  |  |  |  |  |  |\
|  |  |  |  | By: | \\_\\_\\_\_\_\_\_\_\_\_\_\_<br> \[NAME\]<br> \[Title\] |\
|  |  |  |  |  |  |\
| Enclosures |  |  |\
|  | Administrative files (2) |  |  |\
\
**Exhibit 34.12.1-26**\
\
### Letter to Joint Committee\
\
|  |\
| --- |\
|  | U.S. DEPARTMENT OF JUSTICE<br> TAX DIVISION |\
|  | \[date\] |\
\
|  |\
| --- |\
| The Honorable \[name\]<br> Chairman Joint Committee on Taxation<br> Room 1015<br> Longworth House Office Bldg.<br> Washington, D.C. 20515 |\
|  |  | Re: \[name\] v. United States<br> Civil Action No. \[citation\] |\
| Dear Mr. Chairman: |  |\
| In accordance with the provisions of section 6405 of the Internal Revenue Code of 1986, and the letter dated \[date\], from \[name\], Chief Counsel, Internal Revenue Service, there is transmitted herewith a copy of our letter of this date to Chief Counsel, Internal Revenue Service, and a copy of a Memorandum dated \[date\], in support of the proposed settlement, under the authority vested in the Attorney General under section 7122 of the Code and Executive Order 6166, in full settlement of all issues involved in the case of \[name\] v. United States, now pending in the United States District Court for the \[District\], Civil Action No. \[case no.\]. The proposed settlement would result in the refund of approximately $ \[amount over $ 2 million\] in tax plus assessed interest paid, and statutory interest, for the years \[years\]. |\
| The period of 30 days during which the overassessment will be withheld from final settlement expires on \[date\]. |\
|  |  |  |  | Sincerely yours, |\
|  |\
|  |  |  |  | \[Name\]<br> Assistant Attorney General<br> Tax Division |\
|  |\
|  |  |  |  | By:<br> \[Name\]<br> Chief, Office of Review |\
| Enclosures |\
|  | 1 cc letter to Chief Counsel of even date<br> 1 cc Supporting Memorandum dated \[date\] |\
\
**Exhibit 34.12.1-27**\
\
### Adjudication by Another Court Having Concurrent Jurisdiction With Tax Court\
\
| Form 2(a) — Another Court Disposed of All Issues Pending in Tax Court |\
| --- |\
| (1) Stipulation |\
| STIPULATION |\
| It is hereby stipulated that the petitioner's liability for income tax and additions to the tax for the taxable year ended \[date\], was adjudicated by the United States District Court for the \[District\], which Court entered a judgment on \[date\], in the case of United States v. \[name\], (Docket No./Civil Action No. \[case no.\]), \[citation if reported\], \[affirmed on appeal by the United States Court of Appeals for the \[Circuit\], \[citation\]\]. |\
| It is further stipulated that said judgment of the United States District Court became final on \[date\] and that said liability has been assessed and paid. It is further stipulated that by reason of the aforesaid adjudication by the said United States District Court, which court had concurrent jurisdiction with the Tax Court, and that by reason of the assessment and payment of said liability there are now no deficiencies in income tax and additions to the tax, under the provisions of I.R.C. §§ 6651(a) (1) and 6653(a) due from the petitioner for the taxable year ended \[date\]. |\
| (2) Decision |\
| DECISION |\
| Pursuant to the agreement of the parties in this case, and incorporating herein the facts stipulated by the parties as the findings of the Court, it is: |\
| ORDERED and DECIDED: That there are now no deficiencies in income tax and additions to the tax, under the provisions of I.R.C. §§ 6651(a) (1) and 6653(a), due from nor overpayment due to the petitioner for the taxable year ended \[date\]. |\
|  |  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. |\
\
| Form 2(b) — All Issues Before the Tax Court Not Disposed of by Another Court |\
| --- |\
| (1) Stipulation |\
| It is hereby stipulated that the petitioner's income tax liability for the taxable year \[year\] was adjudicated by the United States District Court for the Middle District of North Carolina, which Court. entered a judgment on \[date\] in the case of United States v. \[name\], (Docket No./Civil Action No. \[case no.\], \[unreported or, if reported, citation\], which judgment became final on \[date\], and that said liability has been assessed and paid. |\
| It is further stipulated that, by reason of the aforesaid adjudication of the United States District Court, which Court had concurrent jurisdiction with the Tax Court, and by reason of the assessment and payment of said liability, there is now no deficiency in income tax due from the petitioner for the taxable year \[year\]. |\
| It is further stipulated that said United States District Court did not adjudicate or otherwise determine the petitioner's income tax liability for the taxable year \[year\]. |\
| It is further stipulated that there is a deficiency in income tax due from the petitioner for the taxable year \[year\] in the amount of $ \[amount\]. |\
| (2) Decision |\
| DECISION |\
| Pursuant to the agreement of the parties in this case, and incorporating herein the facts stipulated by the parties as the findings of the Court, it is |\
| ORDERED and DECIDED: That there is now no deficiency in income tax due from the petitioner for the taxable year \[year\]; and |\
| That there is a deficiency due from the petitioner for the taxable year \[year\] in the amount of $ \[amount\]. |\
|  | Judge. |\
| Entered: |\
| \\* \\* \\* \* \* |\
| It is stipulated that the Court may enter the foregoing decision. |\
| It is further stipulated that, effective upon the entry of the decision by the Court, petitioner waives the restriction contained in I.R.C. § 6213(a) prohibiting assessment and collection of the deficiency (plus statutory interest) until the decision of the Tax court has become final. |\
|  |\
\
**_Note to Exhibit 34.12.1-27:_** This Form may be applicable where the related case was a bankruptcy or receivership.\
\
**Exhibit 34.12.1-28**\
\
### Dismissal of Related Refund Suit\
\
|  |\
| --- |\
| UNITED STATES DISTRICT COURT FOR THE DISTRICT OF \[LOCATION\] |\
|  |\
| \[NAMES\], | ) |  |\
|  |  | ) |  |\
|  | Plaintiffs, | ) |  |\
|  |  | ) |  |\
| v. | ) | Civil Action No. \[CASE NO.\] |\
|  | ) |  |\
| UNITED STATES OF AMERICA, | ) |  |\
|  | ) |  |\
|  | Defendant. | ) |  |\
|  |\
| STIPULATION FOR DISMISSAL |\
|  |\
| The parties by their respective attorneys, hereby stipulate and agree that this case shall be dismissed with prejudice, the parties to bear their own costs. |\
| \[name\]<br> Attorney for Plaintiffs<br> \[address\] |\
|  |\
| \[name\]<br> United States Attorney<br> \[address\] |\
\
**Exhibit 34.12.1-29**\
\
### Compromise by the Attorney General\
\
|  |\
| --- |\
| DECISION |\
| Pursuant to agreement of the parties in this case, it is |\
| ORDERED and DECIDED: That the deficiencies in income taxes due from the petitioner for the taxable years \[years\] have been discharged by the acceptance by the Attorney General of the United States of a sum offered in settlement thereof, and |\
| That by reason of the aforesaid settlement there are now no deficiencies in income taxes due from the petitioner for the taxable years \[years\]. |\
| Judge. |\
|  |\
| Entered. |\
|  | \\* \\* \\* \* \* |\
| It is stipulated that the court may enter the foregoing decision. |\
\
**Exhibit 34.12.1-30**\
\
### Stipulation for Entry of Judgment in a U.S. District Court\
\
|  |\
| :-: |\
| \[Case Caption\] |\
|  |\
| Stipulation for Entry of Judgment |\
|  |\
| It is hereby stipulated and agreed that judgment may be entered in favor of the plaintiff(s), \[name(s)\], and against the defendant, the United States of America, in the amount of $ \[amount\] in tax, \[and $ \[amount\] in interest paid,\] plus interest thereon according to law. Execution of this stipulation does not preclude the plaintiff(s) from claiming costs, fees, or other expenses under 28 U.S.C., section 2412. |\
|  |\
| \[Name of plaintiff(s) or counsel\]<br> \[Address\] |  | \[Name of Assistant Attorney General\]<br> \[Acting\] Assistant Attorney General<br> Tax Division<br> Washington, D.C. 20530 |\
|  |\
| \[Name\]<br> \[Counsel for\] Plaintiff(s) |  | \[Name\]<br> Counsel for Defendant,<br> United States of America |\
|  |\
| ORDER |\
|  |\
| IT IS SO ORDERED, this \[date\]. |\
|  |\
|  | United States District Judge |\
|  |\
| **_Note to Exhibit 34.12.1–30:_**If required by local civil rule, the attorney's bar identification number of each signer must be shown. |\
\
**Exhibit 34.12.1-31**\
\
### Stipulation for Entry of Judgment in the Court of Federal Claims\
\
| \[Case Caption\]1,2 |\
| :-: |\
|  |\
| STIPULATION FOR ENTRY OF JUDGMENT |\
|  |\
| It is hereby stipulated and agreed that judgment should be entered in favor of the plaintiff(s) and against the defendant, the United States, in the amount of $ \[amount\] in tax, \[and $ \[amount\] in interest paid,\] plus interest thereon according to law. Execution of this stipulation does not preclude the plaintiff(s) from claiming costs, fees, or other expenses under 28 U.S.C. section 2412. |\
|  |\
| \[Name of plaintiff(s) or counsel\]<br> \[Address\] |  | \[Name of Assistant Attorney General\]<br> \[Acting\] Assistant Attorney General<br> Tax Division<br> Washington, D.C. 20530 |\
|  |\
| \[Name\]2<br> \[Counsel for\] Plaintiff(s) |  | \[Name\]2<br> Counsel for Defendant,<br> United States of America |\
|  |\
|  |\
| 1/ If the docket number has a T use it here; if it does not, do not add one. |\
| 2/ The case name and names under the signature lines should be typed in all capital letters. The Court of Federal Claims does not require the attorney's bar identification number to be shown on pleadings, motions and papers filed. |\
\
**Exhibit 34.12.1-32**\
\
### IRS Employee Testimony Authorization\
\
**\[ _Note:_ If the authorization is for a former officer, employee, or contractor, use a letter format, rather than a memorandum.\]**\
\
|  |\
| --- |\
|  | **Office of Chief Counsel**<br>**Internal Revenue Service**<br>**m e m o r a n d u m**<br> CC:PA:<br> \[CASEMIS Number\] |\
| date: |  |\
| to: | XXXXXXXXXX<br> Revenue Agent<br> IRS<br> \[provide function/post of duty information\] |\
| from: | \[appropriate delegated authority as provided for in Delegation Order 11-2 and its Exhibit table\] |\
| subject: | Testimony Authorization in re:<br>_XXXXXXXX. v. Internal Revenue Service_, Civil No. XXXXXXXXXXXXXX |\
|  | In connection with the above-captioned matter, Counsel for the Plaintiffs has served XXXXXXXXXXXXXXXXXXX with a Notice (or subpoena) to appear at a \[insert appropriate information here—for example: deposition scheduled to begin March 11, 2011, at 1:30 p.m. and continue to March 14, 2011 at 10:00 a.m. at the offices of \[name, address of site of deposition or place of trial\]. |\
|  | You are to testify in your official capacity as an Internal Revenue Service employee, specifically with respect to your involvement in, or knowledge of \[provide a description of the matter employee was involved with that gave rise to the testimony\]. |\
|  | Pursuant to Delegation Order 11-2 and 26 C.F.R. 301.9000-1, you are authorized to appear and give testimony, under the guidance of government counsel, subject to the limitations listed below. |\
|  | **Unless prohibited in the next section, you may:**<br>- Testify as to facts of which you have personal knowledge in your official capacity during the period of time that you were employed in \[insert appropriate information here—for example: the Houston office of IRS, LB&I regarding the examination of the Plaintiffs’ income tax returns\]. |\
|  | **You may not:**<br>- Produce any privileged documents or records of the Internal Revenue Service;<br>  <br>- Testify as to facts of which you have no personal knowledge;<br>  <br>- Testify regarding the thought processes of agency personnel or answer hypothetical questions;<br>  <br>- Speculate as to matters of which you have no sure knowledge;<br>  <br>- Testify in response to general questions concerning the positions, policies, procedures, or records of the Internal Revenue Service that are not relevant to the proceeding or not proportional to the needs of the case;<br>  <br>- Testify as to other cases or other matters of official business not relevant to the proceeding or not proportional to the needs of the case;<br>  <br>- Disclose any information that is protected by the attorney-client privilege, the attorney work product doctrine or the deliberative process privilege, except, and only to the extent, these protections are waived by this authorization;<br>  <br>- Disclose returns or return information of any unrelated third party taxpayer (i.e., a taxpayer not a party to this proceeding) except as may be authorized by I.R.C. § 6103(h)(4);<br>  <br>- Disclose information that may tend to identify a confidential informant, if any;<br>  <br>- Disclose tax convention information subject to I.R.C. § 6105, if any;<br>  <br>- Disclose information that is secret pursuant to Fed. Crim. P. 6(e), if any. |\
|  | If for any reason the dates and/or times of this testimony are changed, this authorization shall remain valid until the testimony is cancelled or completed, provided there is no material change as to the nature of your testimony. |\
|  | Inquiries concerning the matter should be directed to Department of Justice, Tax Division Attorney XXXX at 202-XXX-XXXX. You may also contact Procedure and Administration, Attorney XXXXX at (202) XXX-XXXX if you have further questions. |\
\
**Exhibit 34.12.1-33**\
\
### Chart for Determining Campus to Process Refund\
\
| **If the payment is a refund from ...** | **And the lawsuit was filed in ...** | **Then send the payment memorandum to ...** |\
| --- | --- | --- |\
| Form 1040NR<br> Form 1040-C<br> Form 1040-PR<br> Form 1040-SS | any refund court | Austin |\
| Trust fund recovery penalty (IRC § 6672) | any refund court | The general payment memorandum procedures do not apply; see CCDM 34.10.1.2.2(2) for additional information. |\
| Innocent spouse cases | any refund court | Innocent Spouse Operation |\
| Form 1040<br> Form 1040A<br> Form 1040EZ<br> Penalties against individuals other than the trust fund recovery penalty | Alabama, Connecticut, Delaware, District of Colombia, Georgia, Kentucky, Maine, Maryland, Massachusetts, New Hampshire, New Jersey, New York, North Carolina, Pennsylvania, Rhode Island, South Carolina, Tennessee, Vermont, Virginia, or West Virginia | Kansas City |\
| Alaska, Arizona, Arkansas, California, Colorado, Hawaii, Idaho, Illinois, Indiana, Iowa, Kansas, Michigan, Minnesota, Missouri, Montana, Nebraska, Nevada, New Mexico, North Dakota, Ohio, Oklahoma, Oregon, South Dakota, Utah, Washington, Wisconsin, or Wyoming | Fresno |\
| Florida, Louisiana, Mississippi, Texas, or a U.S. possession or territory | Austin |\
| Estate and gift tax returns<br> Form 2290<br> Form CT-1<br> Any other form that is currently filed only at the Cincinnati Campus | any refund court | Cincinnati |\
| Tax-exempt organizations<br> Governmental entities<br> Indian tribal governments<br> Interest-netting<br> Any other form that is currently filed only at the Ogden Campus | any refund court | Ogden |\
| Form 940<br> Form 941<br> Form 945<br> Form 1041<br> Form 1120<br> Penalties against entities<br> Any other form that is currently filed at both the Cincinnati and Ogden Campuses | Connecticut, Delaware, District of Columbia, Georgia, Illinois, Indiana, Kentucky, Maine, Maryland, Massachusetts, Michigan, New Hampshire, New Jersey, New York, North Carolina, Ohio, Pennsylvania, Rhode Island, South Carolina, Tennessee, Vermont, Virginia, West Virginia, or Wisconsin | Cincinnati |\
| Alabama, Alaska, Arizona, Arkansas, California, Colorado, Florida, Hawaii, Idaho, Iowa, Kansas, Louisiana, Minnesota, Mississippi, Missouri, Montana, Nebraska, Nevada, New Mexico, North Dakota, Oklahoma, Oregon, South Dakota, Texas, Utah, Washington, Wyoming, or a U.S. possession or territory | Ogden |\
\
**Exhibit 34.12.1-34**\
\
### Questions and Answers Regarding Prohibition Against Requesting Taxpayers to Waive Right to Bring Civil Actions Against the United States\
\
**Q1**. _May a Counsel employee request a taxpayer to waive any rights under the Code?_\
\
**A1**. In many circumstances, yes. The restrictions of IRC 3468 only pertain to requesting a taxpayer to waive "a right to bring a civil action . . . for any action taken in connection with the internal revenue laws." Consequently, the restrictions of the law pertain to waivers of right to bring suit. Waivers of other rights or privileges are not addressed by the statute.\
\
**Q2**. _Should Counsel employees ever propose that an unrepresented taxpayer waive their rights to bring a civil action for any action taken in connection with the internal revenue laws?_\
\
**A2**. No. The prohibition against requesting a taxpayer to waive the taxpayer’s right to bring a civil action applies unless the taxpayer waives the right "knowingly and voluntarily," or unless the taxpayer is represented by an attorney or other federally authorized tax practitioner and the request is made in the presence of the practitioner or is made to the practitioner in writing. The first exception would presumptively be met if an unrepresented taxpayer initiated the discussion regarding the waiver of rights and the Government employee could assess that the taxpayer made the waiver knowingly and voluntarily. If the unrepresented taxpayer did not initiate the discussion, a Government employee would risk a violation of the section by raising the subject in any way reasonably construed as a request for waiver. The propriety of the Government employee's conduct does not hinge on whether the taxpayer actually waives any right to bring suit. Even if an unrepresented taxpayer decides against a waiver suggested by a Counsel employee, the employee could be found to have violated the provision, since the prohibition applies to making a request (not a successful request). Because of these difficulties, Counsel's policy is that it will not propose to an unrepresented taxpayer a waiver of the taxpayer’s right to bring a civil action as covered by IRC 3468.\
\
**Q3**. _If an unrepresented taxpayer undertakes to make such a waiver on the taxpayer’s own initiative, can a Counsel employee assume the waiver is made "knowingly and voluntarily" and accept it?_\
\
**A3**. Yes, in the absence of conduct or statements by the taxpayer that would imply to a reasonable person that the waiver is being made under misapprehended facts or law or under circumstances of duress. For example, a Counsel employee should question the unsolicited proffer of any waiver made by an unrepresented taxpayer that appears mentally incompetent or emotionally strained. Similarly, a Counsel employee should question the proffer of any waiver made by an unrepresented taxpayer if it appears that the taxpayer is making the offer to placate what the taxpayer incorrectly perceives as a request from Counsel for a waiver. Finally, a Counsel employee should question the proffer of any waiver made by an unrepresented taxpayer who demonstrates an obviously incorrect view of the law or facts.\
\
**Q4**. _May a Department of Justice (DOJ) attorney request an unrepresented taxpayer to waive the taxpayer’s right to bring a civil action against IRS for an action taken in connection with the internal revenue laws?_\
\
**A4**. A Department of Justice employee, being an "officer or employee of the United States," is covered by the restrictions of IRC 3468. Prohibited conduct covers not only requests to waive the right to bring a civil action against the Service or Counsel or its employees – but against the United States or any officer or employee of the United States – including the Department of Justice and other organs, officers, and employees of the United States for any action taken in connection with the internal revenue laws.\
\
**Q5**. _How will IRC 3468 impact settlement of tax liabilities or settlement of claims for attorneys fees or other costs?_\
\
**A5**. The RRA Conference Report explains that the prohibition against requesting waivers of civil actions is not meant to apply to "\[t\]he waiver of claims for attorneys' fees or costs or to the waiver of one or more claims brought in the same administrative or judicial proceeding with other claims that are being settled." H.R. Conf. Rep. No. 599, 105th Cong., 2d Sess. 293 (1998). Nevertheless, it is generally Chief Counsel policy that the tax liability of a taxpayer will be litigated, settled, or conceded solely on the merits of that tax liability, i.e., the correct tax liability should be determined. This is customarily done without regard to whether the resolution of the tax liability would indicate that the taxpayer "substantially prevailed" in the proceeding which would potentially qualify the taxpayer for administrative or litigation costs. The issue of administrative or litigation costs would then be litigated, settled, or stipulated on its own merits.\
\
**Q6**. _The Chief Counsel Notice on IRC 3468 encourages Counsel employees to remind AUSAs (or other DOJ attorneys) of the requirements, when necessary and appropriate. What is the reasoning behind this statement and what are we to do?_\
\
**A6**. It is expected that Counsel employees will sometimes have a greater familiarity with RRA provisions than certain DOJ employees. If a Counsel employee learns that a DOJ employee appears disposed towards taking action that would risk violating the provision, the attorney should remind the DOJ employee of the requirements. The Counsel employee should also notify the Counsel employee’s supervisor of any situation threatening a potential violation. Counsel management will escalate the issue as appropriate.\
\
**Q.7**. _May a Counsel employee request a taxpayer to waive rights to bring a civil action for actions taken by the agency under a provision of law not contained in the Internal Revenue Code?_\
\
**A.7**. The restrictions of IRC 3468 pertain to requesting a taxpayer to waive "a right to bring a civil action . . . for any action taken in connection with the internal revenue laws." Legislative history suggests that the provision was enacted to prevent the agency and its employees from taking advantage of taxpayers by conditioning resolution of a disputed tax matter on a waiver of right to sue the agency over actions or injuries argued to be sustained though improper assessment or enforcement action taken under the internal revenue laws. While the quoted expression can be expected to include actions beyond those taken "under authority of the Internal Revenue Code," given the history of the provision, it is likely that the covered actions were only intended to include actions taken on or with respect to a tax matter. It is unlikely that the prohibition would be applied to waivers of right to bring suit over actions taken by the agency in connection with general governmental activities (e.g., internal labor matters, government contract matters, FOIA disputes), unless those activities were somehow intertwined with a tax case or cases. These situations must be assessed on a case by case basis.\
\
**Exhibit 34.12.1-35**\
\
### IRS Employee Testimony Authorization for FRCP 30(b)(6) Deposition\
\
|  |\
| --- |\
|  | **Office of Chief Counsel**<br>**Internal Revenue Service**<br>**m e m o r a n d u m**<br> CC:PA:<br> \[CASEMIS Number\] |\
| date: |  |\
| to: | \[designee name, title, POD\] |\
| from: | \[appropriate delegated authority as provided for in Delegation Order 11-2 and its Exhibit table\] |\
| subject: | Testimony Authorization in re: \[Case name and docket number\] |\
|  | Plaintiff’s counsel in the above-captioned civil matter has served a notice of deposition pursuant to Fed. R. Civ. Pro. 30(b)(6) requiring the government to designate a witness to testify as to XX specified topics. The government has designated you for this deposition. The deposition is scheduled to take place on \[date\], beginning at \[time\] at \[location\]. |\
|  | Pursuant to Delegation Order 11-2 and 26 C.F.R. 301.9000-1, you are authorized to appear and give testimony, under the guidance of government counsel, subject to the limitations listed below. |\
|  | **With respect to the deposition on oral examination, unless prohibited in the next section, as the representative of the Internal Revenue Service, you may testify as to the information you have gathered with respect to:**<br>- \[Recite the topic(s) stated in the notice of deposition; verbatim or revised to reflect the authorization being granted.\] |\
|  | You may not:<br> <br>- \[List topics/issues/matters sought in the 30(b)(6) deposition with respect to which this deponent is not authorized to testify;\]<br>  <br>- \[List any other topics/issues/matters that opposing counsel might raise with respect to which this deponent is not authorized to testify;\]<br>  <br>- Testify as to any matter not included within the XX topics listed above;<br>  <br>- Testify as to facts of which you have no personal knowledge;<br>  <br>- Testify as to your mental impressions, perceptions, or opinions with respect to any matter at issue in this proceeding;<br>  <br>- Disclose returns or return information of any unrelated third party taxpayer ( _i.e._, a taxpayer not a party to this proceeding) except as may be authorized by I.R.C. § 6103(h)(4);<br>  <br>- Disclose individually identifiable information ( _i.e._, information subject to the Privacy Act of 1974), other than returns or return information, of any individual;<br>  <br>- Testify regarding the thought processes of agency personnel or answer hypothetical questions;<br>  <br>- Testify in response to general questions concerning the positions, policies, procedures, or records of the Internal Revenue Service that are not relevant to the proceeding or not proportional to the needs of the case;<br>  <br>- Testify as to other cases or other matters of official business not relevant to the proceeding or not proportional to the needs of the case;<br>  <br>- Disclose any information that is protected by the attorney-client privilege, the attorney work product doctrine or the deliberative process privilege, except, and only to the extent, these protections are waived by this authorization;<br>  <br>- Disclose information that may tend to identify a confidential informant, if any;<br>  <br>- Disclose tax convention information subject to I.R.C. § 6105, if any;<br>  <br>- Disclose information that is secret pursuant to Fed. Crim. P. 6(e), if any;<br>  <br>- Produce any privileged documents or records of the Internal Revenue Service. |\
|  | If for any reason the dates and/or times of this testimony are changed, this authorization shall remain valid until the testimony is cancelled or completed, provided there is no material change as to the nature of your testimony. |\
|  | Inquiries concerning the matter should be directed to Department of Justice, Tax Division Attorney XXXX at 202-XXX-XXXX. You may also contact Procedure and Administration, Attorney XXXXX at (202) XXX-XXXX if you have further questions. |\
\
**Exhibit 34.12.1-36**\
\
### Campus Addresses and Contacts (For Payment Memoranda Purposes Only)\
\
_**Note:**_ This list will be regularly updated and posted online at Civil Cases (Department of Justice Cases). To ensure the most current Campus mailing information, field attorneys should refer to this website.\
\
|  |\
| --- |\
|  | _Mail to:_ | **OR** — _If using a Private Delivery Service:_ |\
| **AUSTIN CAMPUS**<br> Contact: (512) 460-1882 |\
|  | Director, Austin Campus<br> Internal Revenue Service<br> Post Office Box 934<br> Austin, TX 78767<br> Attention: Technical Unit, Stop 6561 AUSC | Director, Austin Campus<br> Internal Revenue Service<br> 3651 South Interregional Highway 35<br> Austin, TX 78741<br> Attention: Technical Unit, Stop 6561 AUSC |\
| **CINCINNATI CAMPUS**<br> Contact: (859) 669-2134 |\
|  | Director, Cincinnati Campus<br> Internal Revenue Service<br> Post Office Box 12267<br> Covington, KY 41012-0267<br> Attention: Team 101, Technical/Large Corp, Stop 537G | Director, Cincinnati Campus<br> Internal Revenue Service<br> 201 West Rivercenter Blvd.<br> Covington, KY 41011<br> Attention: Team 101, Technical/Large Corp, Stop 537G |\
| **FRESNO CAMPUS**<br> Contact: (559) 454-6754 |\
|  | Director, Fresno Campus<br> Internal Revenue Service<br> 5045 E Butler Ave.<br> Fresno, CA 93888<br> Attention: Accounts Management, Stop AY001 |  |\
| **KANSAS CITY CAMPUS**<br> Contact: (816) 325-2335 |\
|  | Director, Accounts Management Kansas City Campus<br> Internal Revenue Service<br> Post Office Box 24551<br> Kansas City, MO 64131<br> Attention: OP 1 Dpt. 3, Stop 6800 N-2, Team 301, Unit 332 | Director, Accounts Management Kansas City Campus<br> Internal Revenue Service<br> 333 W. Pershing Rd.<br> Kansas City, MO 64108-4302<br> Attention: OP 1 Dpt. 3, Stop 6800 N-2, Team 301, Unit 332 |\
| **OGDEN CAMPUS**<br> Contact: (801) 620-4245 |\
|  | Director, Accounts Management Ogden Campus<br> Internal Revenue Service<br> 1973 Rulon White Blvd., Mail Stop 6800<br> Ogden, UT 84404<br> Attention: Complex Interest Team, Stop 6800 |  |\
| **INNOCENT SPOUSE OPERATION**<br> Contact: (859) 669-7131 |\
|  | Internal Revenue Service<br> Innocent Spouse Operation, Stop 840F<br> Post Office Box 120053<br> Covington, KY 41012<br> Attention: Department Manager (DOJ Cases) |  |\
\
**Exhibit 34.12.1-37**\
\
### Sample Payment Memorandum (Refund Pursuant to Judgment, Form 8690)\
\
|  | **Office of Chief Counsel**<br>**Internal Revenue Service**<br>**m e m o r a n d u m** |\
| --- | --- |\
| date: | \[Date\] |\
| to: | Director, \[Campus\]<br> \[Campus’s Address\]<br> Attn: \[Name\] |\
| from: | \[Name\]<br> \[Title and Office\] |\
| subject: | Refund or Credit Pursuant to Judgment<br> \[Case Caption\]<br> \[Docket Number\]<br> Amount of Judgment: \[Dollar Amount of Judgment\], plus statutory interest<br> \[Taxpayer’s Name\]<br> \[TIN\] |\
|  | In the case described above, the taxpayer filed a lawsuit to recover a refund of certain \[Type of Tax Liability\] tax liabilities for the tax year(s) \[Year(s)\]. The taxpayer won the lawsuit in whole or in part, causing the court to enter a judgment against the Government in the case. The Department of Justice has advised this office that the Solicitor General has decided not to appeal from the judgment (or from that portion of the judgment adverse to the Government). This office recommends payment of the judgment in the amount of \[Dollar Amount of Judgment\] for \[Tax Year(s)\], which is verified by the recomputation that is attached hereto. Please contact our office immediately if you are not the correct Campus to process this payment memorandum. |\
|  | Under section 6402 of the Internal Revenue Code of 1986, any overpayment may be credited against any other tax liability of the person who made the overpayment. Please make the check in the name of \[Taxpayer’s Name\] and mail the check or a notice of credit to: |\
|  |  | \[Taxpayer’s Name\]<br> c/o Assistant Attorney General<br> Tax Division, Department of Justice<br> P.O. Box 310 – Ben Franklin Station<br> Washington, DC 20044-0310 |\
|  | Please notify this office when a check or notice of credit has been issued. We will then follow up to ensure that the litigation-freeze codes are removed. |\
|  | The notice of adjustment should contain the following statement: |\
|  |  | This Notice of Adjustment is issued pursuant to directions from the Department of Justice relative to overpayments of federal income taxes in the sum of \[Total Amount of Judgment\], plus interest as provided by law. Payment of the sums mentioned herein is made and accepted in accordance with the judgment entered on \[Date Judgment Entered\], in the \[Name of Court\], in the case of \[Case Caption and Docket Number\], instituted for the recovery of federal \[Type of Tax Liability\] taxes in the amount(s) of \[Amount(s)\] for the year(s) \[Tax Years\]. |\
|  | We enclose the materials identified below that contain the information necessary to process the refund check or letter of credit. |\
|  | Please forward both to this office and that of the Assistant Attorney General three copies of the completed Notice of Adjustment noting the date of issuance of the refund check or notice of credit, and three copies of the statutory interest computation. |\
|  |  | \[Name\]<br> Associate Area Counsel<br> \[Office\] |\
|  | By | \\_\\_\\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_<br> \[Name\]<br> \[Title and Office\] |\
|  | Enclosures: |\
|  | Recomputation dated \[Date\] (1 copy)<br> DOJ Closing Letter dated \[Date\] (1 copy)<br> Certified Judgment dated \[Date\] (original and 1 copy)<br> Taxpayer’s Complaint, filed \[Date\] (1 copy) |\
\
**Exhibit 34.12.1-38**\
\
### Glossary of Terms and Legal References for Electronic Discovery\
\
### Note:\
\
Because e-discovery is an emerging field, these definitions and references will be subject to ongoing discussion and, in some cases, revision by courts and practitioners.\
\
01. **Collection:** The process of gathering data (paper, electronically stored information (ESI), and other tangible things) that occurs after a litigation hold notice has been sent to custodians and these individuals have responded with the type and location of information in their possession. In the e-discovery process, collection occurs in two phases performed by IRS-IT. In Phase 1, the ESI is copied and saved to a secured server, but the ESI is not searched. Phase 2 involves culling through the ESI, via key word or Boolean searches, to process and review the data to retrieve ESI responsive to a discovery request or court order to produce relevant ESI. Collection and preservation are interdependent steps in the litigation hold process, but often the responsible attorney does not collect from every person to whom a litigation hold to preserve is issued.\
\
02. **Court/courts:**Refers to District Court, Tax Court, Bankruptcy Court, Court of Federal Claims, and may include administrative forums, such as the Merit Systems Protection Board (MSPB), Federal Labor Relations Authority (FLRA), and Equal Employment Opportunity Commission (EEOC). As used in CCDM 34.7.1.1.4, this term may include Congress or other oversight bodies where inquiries from those bodies are determined to require application of the procedures in that section.\
\
03. **Custodian:**A person having possession or control over relevant paper or electronic evidence subject to discovery. The custodian is required to preserve relevant evidence in their custody or control and respond to litigation hold notices. The responsible attorney must take reasonable steps to ensure that custodians do not alter or destroy relevant evidence in a custodian’s possession.\
\
04. **De-duplication:** The process of searching for and deleting duplicate information. In email chains, for example, multiple copies of the same email would be eliminated.\
\
05. **E-discovery:** The process of searching for relevant electronic data in response to a discovery request. The steps include finding, collecting, and producing relevant electronic information wherever stored, subject to applicable privileges.\
\
06. **Electronic Discovery Request (EDR):**A written communication prepared by the responsible attorney and submitted to PA Branch 8 for assistance in directing IRS-IT to start the process of searching, preserving, and collecting ESI of custodians. An EDR must be specific and include custodian information, search terms, priority level of the request with justification (e.g., high priority retiring employee or computer issues), and timeframes.\
\
07. **Electronically Stored Information (ESI):** Any data, whether stored on a computer, network servers, or any peripheral storage device, that is in electronic form. ESI may include but is not limited to: electronic files, communications, including email, instant messages, and voicemail (sent or received), data produced by calendar software, and information management software. In addition to specific data that are electronically stored and readily retrievable, ESI includes data that may not be visible that is generated by a computer hard-drive, email and instant messaging, information management software, handheld computer devices (e.g., Blackberry), telecommunications devices, and back-up storage devices. ESI may be stored on different electronic devices and removable devices (e.g., internal and external drives, smart phones, servers, laptops, backup tapes, thumb drives, CDs, and DVDs).\
\
08. **Evidence:** Includes all tangible things and records, whether electronic or paper form, created, received, or maintained by on behalf of the Service, or utilized by the Service in the transaction of official business.\
\
09. **IRS Information Technology (IRS-IT):** IRS-IT is responsible for initiating and managing the EDR collection process, conducting initial searches using EDR search terms and date parameters, and engaging in a multi-step process to reduce ESI data from a large data set to a manageable one for review. This group is also responsible for removing all ESI encryptions and password protections and delivering the collected documents, emails, and spreadsheets to a results folder.\
\
10. **Litigation hold:** The temporary suspension of the normal record retention policies to ensure relevant evidence is preserved for use in litigation. This process requires searching for, identifying, isolating, and preserving such evidence (whether in paper, electronic, or other tangible form) when litigation is reasonably anticipated or has already commenced.\
\
11. **Litigation hold notice:** A written notice to custodians alerting them of existing or reasonably anticipated litigation, directing them to preserve relevant evidence, and requiring them to provide information in response to the notice. A litigation hold notice notifies the custodians receiving it of their obligation not to destroy or alter relevant documents. See Exhibits 34.12.1-40 and 34.12.1-41.\
\
12. **Metadata:** Information about a particular data set or document that describes how, when, and by whom it was created, accessed, and modified, as well as how it was formatted.\
\
13. **Native format:**The preservation of a document in its original format. For example, a Microsoft Word file will be preserved as a Microsoft Word file with a file extension such as .doc, .docx, or .rtf.\
\
14. **Predictive coding:**A form of computer-assisted review that allows parties in litigation to reduce the time and cost associated with traditional, manual review of large volumes of documents. Computers are programmed to predict the relevance of documents to a discovery request and identify the documents that are responsive. The parties apply search criteria such as keywords, dates, custodians, and document types to a sample of documents and utilize programs to recognize patterns of relevance and identify relevant documents. The parties then further review the identified relevant documents, instead of the entire universe of documents, for issues such as privilege and relevance. SeeDynamo Holdings Ltd. Partnership v. Commissioner, 143 T.C. 183 (2014).\
\
15. **Preservation:** The process of locating, isolating, and maintaining relevant information (paper, ESI, and other tangible evidence) and ensuring that the information is not destroyed or altered. The duty to preserve is generally triggered when litigation is reasonably anticipated or has actually commenced. The litigation hold and issuance of the litigation hold notice are the initial steps in the preservation process. The preservation process is initially accomplished by the custodians, and collection of relevant evidence may occur later during the litigation hold process. Preservation and collection are interdependent steps in the litigation hold process.\
\
16. **Production:** The process of delivering to another party, or making available for that party’s review, documents deemed responsive to a discovery request or court order.\
\
17. **Proportionality:** An emerging recognition of the practical reality in the world of electronic discovery that one size does not fit all. The mandate to preserve does not necessarily translate into a mandate to collect and process everything. It allows for consideration of reasonable costs and burdens to one party relative to the needs of the other in making decisions regarding ESI searches, preservation, collection, and production. It requires acting reasonably and in good faith. See FRCP 26(b)(1).\
\
18. **Removable media:** CDs, DVDs, thumb drives, floppy disks, and other portable data storage devices, including government cell phones.\
\
19. **Repositories:**The type of equipment on which ESI may be stored. Examples include computers, network drives, email servers, external storage devices, CD ROMs, DVD ROMs, external hard drives, thumb drives, and cell phones.\
\
20. **Responsible attorney:** The Counsel attorney assigned as the lead attorney in a case where litigation is reasonably anticipated or has already commenced. In district court and Court of Federal Claims cases involving the Service, an attorney from the Department of Justice or the Office of United States Attorney represents the government, but for purposes of litigation hold procedures, the assigned Counsel attorney remains the responsible attorney.\
\
21. **Sanctions:** Punishment imposed by the court to deter future improper behavior. Examples of potential sanctions which may result from spoliation include monetary sanctions in an amount to cover reasonable expenses, the drawing of an adverse evidentiary inference against the Service concerning the material it failed to preserve, evidence or claim preclusion, adverse determination, and charges of contempt. SeeZubulake v. UBS Warburg LLC, 220 F.R.D. 212 (S.D.N.Y. 2003).\
\
22. **Service Point of Contact:**The Service employee who is most familiar with the case, and who would have knowledge of other Service employees who may also possess relevant paper records, ESI, and other tangible evidence. This person may also provide information about relevant Service electronic repositories that need to be accessed to preserve relevant ESI.\
\
23. **Spoliation:**The destruction, alteration, or suppression of relevant evidence where the party in possession had an obligation to preserve the evidence at the time it was destroyed, altered, or suppressed. Spoliation may result in a negative evidentiary inference imposed by a third party adjudicator and may support the imposition of sanctions.\
\
24. **Triggering event:**An event that gives rise to the obligation to preserve relevant evidence. Federal rules look to when a party should reasonably anticipate litigation as the triggering event. The commencement of litigation through court filings is always a triggering event, but the duty to preserve may arise before that time.\
\
\
**Exhibit 34.12.1-39**\
\
### Litigation Hold Checklist\
\
1. **Issuance** (CCDM 34.7.1.1.4.3.1)\
\
\
    □ Discuss with your manager and, where appropriate, DOJ, whether a litigation hold should be issued to fulfill the evidence preservation obligation in the case at hand.\
\
\
    □ In DOJ cases, promptly consult with the DOJ attorney about the need for and proper scope of any litigation hold requested by DOJ.\
\
\
    □ Consider whether ESI should be discussed with the opposing party at the Branerton conference (Tax Court only).\
\
\
    □ Document decisions regarding determination of whether to issue a litigation hold in the legal file, and, if necessary, in a letter to DOJ.\
\
\
    □ Identify Service Point of Contact.\
\
\
    □ Send initial litigation hold notice email to Service Point of Contact using the template found on the Litigation Hold Database intranet site. Follow-up as necessary to obtain any needed additional information.\
\
\
    □ Identify custodians.\
\
\
    □ Enter custodian information into the Litigation Hold Database using the online entry form found on the Litigation Hold Database intranet site.\
\
\
    □ Send the litigation hold notice email to custodians, using the template found on the Litigation Hold Database intranet site.\
\
\
    □ Confirm receipt of litigation hold notice email by the Service Point of Contact and the custodians within 7 days. Follow-up as necessary to obtain any needed information.\
\
\
    □ Place copies of notice emails and responses in the legal file.\
\
\
    □ Determine likely sources of evidence based on custodian responses.\
\
\
    □ Work with manager to ensure all case-tracking systems are updated.\
\
2. **Maintenance** (CCDM 34.7.1.1.4.3.2)\
\
\
    □ Discuss discovery needs (including possible search terms) in Branerton conference or with DOJ attorney.\
\
\
    □ Send reminder emails every six months, using the template found on the Litigation Hold Database intranet site. Schedule reminder ticklers in the case tracking system.\
\
\
    □ Confirm receipt of reminder emails by custodians. List date of receipt confirmed for all custodians below. Place copies of reminder emails and responses in legal file.\
\
\
    □ Notify PA Branch 8 through assigned Branch 8 point of contact or the Litigation Hold Mailbox of any changes to responsible attorney case assignments.\
\
\
    □ Periodically check status of litigation holds using the Litigation Hold Database Query Form.\
\
3. **Collection** (CCDM 34.7.1.1.4.3.3)\
\
\
    □ Instruct custodians to send all records to attorney.\
\
\
    □ Fill out Electronic Discovery Request form for PA Branch 8 and send TSS.assignments request for assistance.\
\
\
    □ Notify PA Branch 8 through assigned Branch 8 point of contact of any changes to case collection priorities or deadlines.\
\
4. **Processing and Review** (CCDM 34.7.1.1.4.3.4)\
\
\
    □ Work with PA Branch 8 on first level review (if applicable).\
\
\
    □ Review potential evidence for relevance, privileges, and IRC § 6103 information.\
\
\
    □ Produce evidence to opposing party or DOJ.\
\
5. **Release and EDR Termination** (CCDM 34.7.1.1.4.3.5)\
\
\
    □ Determine that litigation hold may be released based on final decision/judgment or notification from DOJ.\
\
\
    □ Notify custodians by email that the litigation hold may be released.\
\
\
    □ Notify PA Branch 8 that litigation hold may be released.\
\
\
    □ Work with manager to ensure relevant case-tracking systems are updated.\
\
\
[More Internal Revenue Manual](https://www.irs.gov/irm)\
\
Copy link\
\
✓\
\
Thanks for sharing!\
\
Find any service\
\
[AddToAny](https://www.addtoany.com/ "Share Buttons")\
\
[More…](https://www.irs.gov/irm/part34/irm_34-012-001#addtoany "Show all")\
\
A2A