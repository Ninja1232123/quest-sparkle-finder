---
url: "https://www.irs.gov/irm/part34/irm_34-008-002"
title: "34.8.2 Settlement Procedures | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part34/irm_34-008-002#main-content)

- 34.8.2  [Settlement Procedures](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074817824)
  - 34.8.2.1  [Settlements Including Taxpayer or Period Not in Suit — Closing Agreements](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074478720)
    - 34.8.2.1.1  [Scope.](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635073895296)
    - 34.8.2.1.2  [Precautions](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074345248)
    - 34.8.2.1.3  [Solicitation of Views and Comments from the Field](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074664832)
    - 34.8.2.1.4  [Computation](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635073891376)
    - 34.8.2.1.5  [Side Memorandum](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635073888000)
    - 34.8.2.1.6  [Approval](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074475680)
  - 34.8.2.2  [Settlement Conferences](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074473952)
    - 34.8.2.2.1  [Limitations](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074471312)
    - 34.8.2.2.2  [Conference Memoranda](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074468672)
  - 34.8.2.3  [Recommendation on Offer](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074836048)
  - 34.8.2.4  [Settlement Letters Content](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074830896)
    - 34.8.2.4.1  [Scope](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074827952)
    - 34.8.2.4.2  [Types of Settlements](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635073964736)
  - 34.8.2.5  [Form and Contents](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635073957232)
    - 34.8.2.5.1  [Format](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635103287344)
  - 34.8.2.6  [Application of Executive Order 12988 on Civil Justice Reform](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635103259344)
  - 34.8.2.7  [Conflicting Recommendations](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635103255632)
    - 34.8.2.7.1  [The Service Recommends Acceptance](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635103252400)
  - 34.8.2.8  [Joint Committee Cases](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635103250464)
    - 34.8.2.8.1  [Determination of Amounts](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074579824)
    - 34.8.2.8.2  [Computation](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074575520)
    - 34.8.2.8.3  [Guidelines and Procedures](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074570800)
    - 34.8.2.8.4  [Attorney’s Responsibility](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074566192)
    - 34.8.2.8.5  [Procedures in Refund Joint Committee Cases](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074561248)
    - 34.8.2.8.6  [Processing Court of Appeals and Supreme Court Joint Committee Cases](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074554416)
    - 34.8.2.8.7  [Procedure to be Followed for Joint Committee Settlements Which Must be Approved by DOJ](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074552688)
  - 34.8.2.9  [Court of Federal Claims Rules Governing TEFRA Partnership Settlements](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074548752)
  - 34.8.2.10  [Qualified Offers Under I.R.C. § 7430](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074545408)
    - 34.8.2.10.1  [Qualified Offer Defined](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074542800)
    - 34.8.2.10.2  [Qualified Offer Rule](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074540272)
    - 34.8.2.10.3  [Additional Requirements for Qualifying as a Prevailing Party](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074537392)
    - 34.8.2.10.4  [Comparison of Liability under the Offer to Liability Under the Judgment](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074531312)
    - 34.8.2.10.5  [Fees Recoverable](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074527824)
    - 34.8.2.10.6  [Qualified Offer Period](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074040992)
  - 34.8.2.11  [Coordination of Refund Cases and Collection Cases with Tax Court Cases](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074036592)
    - 34.8.2.11.1  [Attorney General’s Settlement Authority in Related Tax Court Cases](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074033808)
    - 34.8.2.11.2  [Settlement Offers in Tax Cases](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074017840)
    - 34.8.2.11.3  [Settlement of Tax Court Case with Dismissal of Refund Suit](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635073999312)
    - 34.8.2.11.4  [Settlement Offer to Settle Only the Refund Suit](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635073992336)
    - 34.8.2.11.5  [Offer Submitted to Field Office](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635073987392)
    - 34.8.2.11.6  [Offer Submitted to DOJ](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635073983152)
    - 34.8.2.11.7  [Direct Mailing vs. Associate Chief Counsel Review of Settlement Letters](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635073977648)
    - 34.8.2.11.8  [Coordination of Tax Court Cases and Collection Cases](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635073972304)
    - 34.8.2.11.9  [Tax Litigation and Collection Suits in Associate Chief Counsel Offices](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074778160)
    - 34.8.2.11.10  [Coordination of Tax Court with Receiverships or Other Insolvency Cases](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074770512)
    - 34.8.2.11.11  [Attorney General’s Offer in Compromise Refund Suits](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074756416)
    - 34.8.2.11.12  [Cases Having Concurrent Jurisdiction with Another Case](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074750000)
  - 34.8.2.12  [Reversal of Unauthorized Abatements Following Referral to the Department of Justice](https://www.irs.gov/irm/part34/irm_34-008-002#idm139635074745744)

# Part 34. Chief Counsel Directives Manual Litigation in District Court, Bankruptcy Court, Court of Federal Claims, and State Court

# Chapter 8. Settlement Procedures

# Section 2. Settlement Procedures

* * *

## 34.8.2 Settlement Procedures

#### Manual Transmittal

August 11, 2023

#### Purpose

(1) This transmits revised CCDM 34.8.2.10, Qualified Offers Under I.R.C. § 7430.

#### Material Changes

(1) 34.8.2.10(2) Qualified Offers Under I.R.C. § 7430 was revised to provide a clear cross reference to coordinate procedures outlined in CCDM 35.10.1.3.2(1) for qualified offers.

(2) 34.8.2.10.3(2) Additional Requirements for Qualifying as a Prevailing Party was revised to reflect case law addressing full concessions in qualified offers.

(3) 34.8.2.10.3(4) Additional Requirements for Qualifying as a Prevailing Party was revised to reflect our position in partnership-level TEFRA cases, including a cross reference to the discussion at CCDM 35.10.1.3.

(4) 34.8.2.10.6(4) Qualified Offer Period was revised to clarify the nature and availability of extensions of time to consider qualified offers.

#### Effect on Other Documents

This section supersedes CCDM 34.8.2.10, dated 8-5-2014.

#### Audience

Chief Counsel

#### Effective Date

(08-11-2023)

Robert T. Wearing

Deputy Associate Chief Counsel

(Procedure & Administration)

**34.8.2.1** **(08-05-2014)**

### Settlements Including Taxpayer or Period Not in Suit — Closing Agreements

1. Settlement recommendation letters that cover a taxpayer or a taxable period not in suit may be signed by the Associate Chief Counsel for matters under their respective jurisdictions.

2. DOJ has authority to settle all matters in suit, and all matters related thereto. It has never, to Counsel’s knowledge, settled matters not in suit contrary to the Service’s recommendation.


**34.8.2.1.1** **(08-11-2004)**

#### Scope.

1. Non-suit year settlements are those in which the taxpayer’s offer contemplates the disposition of years or issues not in suit, liabilities of taxpayers not in suit or both. If the scope of the settlement is restricted to the suit years, and merely has an affect on subsequent years, then Counsel would not view it as a non-suit settlement. Where the adjustments called for pursuant to the settlement do not automatically affect non-suit years, but leave the Service with no discretion as to their disposition, then a provision in the settlement disposing of non-suit years would call for a non-suit settlement.


**34.8.2.1.2** **(08-11-2004)**

#### Precautions

1. When an attorney receives a request for a recommendation on an offer, several precautions should be taken in the event a non-suit year settlement will be necessary.

2. The attorney should immediately review the settlement offer to determine whether a non-suit year settlement is necessary. Any delay in recognizing that an offer calls for non-suit year settlement will result in a delay in the processing of the settlement.

3. Once it is decided a non-suit year settlement is involved, the determination should be made whether the offer is acceptable. Counsel, without referral to Appeals, has authority to recommend rejection of any settlement involving non-suit years or taxpayers not in suit. Accordingly, if rejection is recommended, then a non-suit year settlement is not needed and normal settlement procedures may be utilized. Non-suit year settlement procedures must be followed, however, if the rejection recommendation contains a proposal as to what would be an acceptable offer.


**34.8.2.1.3** **(08-11-2004)**

#### Solicitation of Views and Comments from the Field

1. It is essential, once a determination is made that a settlement will be a non-suit year settlement, that the views of the Appeals or Exam field office be requested immediately. If there are newly discovered facts, they should be made available to these offices. The memorandum to these offices should state the issues in suit, provide a copy of the settlement proposal, and seek views and comments with respect to all of the matters involved. Appeals or Exam should also be asked to provide their views as to what they would consider an acceptable settlement if they recommend rejection.


**34.8.2.1.4** **(08-11-2004)**

#### Computation

1. A non-suit year settlement presents computational difficulties not present in a normal settlement proposal. In a regular settlement all of the files and necessary transcripts of account should be in Counsel’s possession. It would then be a simple matter to send this material to the appropriate office for a recomputation of the amount of the overpayment. _See_ CCDM 34.8.1.2.2.3.

2. With non-suit year settlements, Counsel does not usually have complete files or transcripts of account. Years before Appeals or Exam may be unaudited. If a settlement is going to present computational problems, the solicitation of such an offer should be discouraged, and if received, the difficulty in disposing of it may serve as a basis for recommending rejection.


**34.8.2.1.5** **(08-11-2004)**

#### Side Memorandum

1. Although not always necessary, it is generally desirable for an attorney to prepare a memorandum to his or her reviewer when forwarding a proposed non-suit year settlement letter. The memorandum should point out why a non-suit year settlement is necessary, contain a brief discussion as to the acceptability of the offer, and include the views of Appeals.


**34.8.2.1.6** **(08-05-2014)**

#### Approval

1. Non-suit year settlement letters may be signed by the Associate Chief Counsel for matters under their respective jurisdictions.


**34.8.2.2** **(08-11-2004)**

### Settlement Conferences

1. Settlement conferences between Associate Chief Counsel attorneys and DOJ attorneys are infrequent. They are held in Washington, D.C. when a case has been referred to an Associate Chief Counsel office for review. Taxpayer’s counsel may also be present at these conferences. Often a preliminary conference is held so the government attorneys may formulate a unified position to present at the settlement conference. Settlement conferences are held to determine whether a mutually acceptable basis for settlement exists and, if so, the precise terms of such a settlement. Due to the significance a settlement conference may have on the outcome of a case, it is important for attorneys in an Associate office to notify their branch chiefs when they have been invited to attend a settlement conference. Conferences to which Associate office attorneys are invited may also be held in Court of Federal Claims cases.


**34.8.2.2.1** **(08-11-2004)**

#### Limitations

1. Attorneys in Associate offices must keep in mind the final authority to settle cases pending in litigation rests with DOJ. Furthermore, any recommendation believed acceptable by an attorney must be approved by the attorney’s reviewer. Accordingly, Associate office attorneys should be careful at settlement conferences not to make any statements indicating the Office of Chief Counsel will recommend acceptance or the Government will ultimately accept the offer. If necessary, an attorney may indicate that he or she is inclined to favorably (or unfavorably) recommend the offer, with a caution that this is only the attorney’s present view, and that upon further consideration, a different formal recommendation may be made.


**34.8.2.2.2** **(08-11-2004)**

#### Conference Memoranda

1. A conference memorandum is usually prepared, signed by the attorney and approved by the reviewer.


**34.8.2.3** **(08-05-2014)**

### Recommendation on Offer

1. When Recommendation Furnished. When DOJ submits a settlement offer to Field Counsel or an Associate Chief Counsel office for the Service’s recommendation, the best settlement letter possible should be prepared within the prescribed time limits. The normal deadline for the preparation of the settlement letter is 30 days from the receipt of the request from DOJ unless some reason for a shorter period is given. If DOJ proposes a longer or shorter deadline, this will be set forth in the letter. Generally, DOJ will not request Counsel’s views on settlement offers submitted in cases classified settlement option procedures (S.O.P.). See CCDM 34.8.1.2.1, _Submission of Offers by Tax Division_ for exceptions to the rule.

2. When Recommendation Not Furnished. Even when a case is classified Standard, DOJ, in connection with the consideration of a settlement offer, may request Counsel to reclassify a case from Standard to the S.O.P. category. This may occur in a situation where the facts or issues that led to classification of the case as Standard are no longer present. An example of this would be a jurisdictional defense recommended in the defense letter but unsuccessfully pursued or dropped by DOJ.

3. Even though a case is classified Standard and the settlement offer has been referred for the Service’s recommendation, Counsel may conclude that the case should be reclassified S.O.P. and respond to DOJ by stating that we have reclassified the case in the S.O.P. category, giving the reason for such reclassification (such as the dropping of a jurisdictional defense).


**34.8.2.4** **(08-11-2004)**

### Settlement Letters Content

1. The objective of Counsel in providing a recommendation to DOJ with respect to a settlement offer or a proposed concession by DOJ should be to produce the best possible letter within the applicable time limits. Obviously, if the settlement involves a very clear and simple issue, we should be able to provide our recommendations well within the applicable time limit.

2. It should be kept in mind that unlike most of the other deadlines imposed on attorneys, the 30-day time limit is merely imposed by agreement with DOJ and not by the courts. In many cases the courts have permitted DOJ extensions of time for discovery, brief, trial, etc., for purposes of having a settlement offer approved. If a case is complicated and the 30-day time limit appears to be insufficient, the attorney should check with the DOJ trial attorney to ascertain the precise time problems involved. Notwithstanding, an attorney should make every reasonable effort to provide the recommendation within 30 days.


**34.8.2.4.1** **(08-11-2004)**

#### Scope

1. It is the attorney’s responsibility to carefully evaluate the merits of the offer based on the pertinent facts and applicable case law and formulate a specific recommendation with respect to the offer. In so doing, it is important for the attorney to have available the full factual elements of the issue or issues encompassed by the settlement proposal. Often the defense letter will indicate what, if any, additional factual development is deemed to be necessary.

2. When DOJ seeks a recommendation on a factual issue, DOJ’s letter should be accompanied by the appropriate factual development. For example, if significant facts were unknown at the defense letter stage, DOJ’s letter seeking the Service’s recommendation, aside from being accompanied by the settlement offer itself, should also be accompanied by material shedding further light upon the facts, such as answers to interrogatories, depositions, appraisal reports, stipulations of fact, etc.

3. Whether further factual development of the case was required but is not forthcoming, a check should be made with DOJ attorney to determine whether such material is available. Where necessary further factual development has not been undertaken and the settlement offer does not resolve all questionable factual issues in favor of the Government, then it would generally be appropriate not to consider the settlement offer until further factual development is undertaken. In this instance, we would advise DOJ that Counsel is recommending rejection until additional factual development is available.


**34.8.2.4.2** **(08-05-2014)**

#### Types of Settlements

1. Regular. The typical settlement offer referred to Counsel encompasses a single case with a single taxpayer and covers the years and issues in suit. Generally, in these situations the referral letter should have covered issues raised by the settlement offer and may have provided a suggestion as to whether the case was susceptible of settlement and if so, on what basis. The referral letter may also have pointed out whether further factual development was necessary.

2. Non-suit Year Settlement. See the discussion in _CCDM 34.8.2.1.2_, _Precautions_.

3. Joint Committee Settlement. See the discussion in _CCDM 34.8.2.8_, _Joint Committee Cases_.

4. Related Refund And Tax Court Case Settlement. See the discussion in CCDM 34.8.1.3.2, http://core.publish.no.irs.gov/irm/p34/pdf/irm34-008-001--2004-08-11.pdf, _Coordination of Settlement of Related Tax Court and Refund Litigation Cases_.

5. Multiple Issues and Parties Settlement. Frequently, litigation will involve multiple issues and multiple parties. In most cases where multiple issues are pending, the settlement offer will encompass all of the issues in suit. However, in some cases only some of the issues are settled and the balance is left to be resolved by litigation or later settlement. Furthermore, as with defense letters, only one letter is prepared with respect to related cases which contain common issues. The format of a settlement letter involving multiple issues and/or multiple parties will not be different from a regular settlement letter with the exception that each issue, to the extent it is separable from the other issues, is discussed separately and separate conclusions are reached as to the appropriateness of the settlement as to each issue or party.


**34.8.2.5** **(08-11-2004)**

### Form and Contents

1. The form of a settlement letter is very similar to that of a suit or referral letter. The most significant differences between a settlement letter and a referral letter are that the settlement letter does not have a discussion of jurisdiction as that aspect of the case was disposed of at the referral letter stage.



1. The settlement letter should contain a recitation of the taxpayer’s settlement proposal.

2. The settlement letter should focus on those matters with respect to the issue or issues involved, forming the basis for determining the acceptability of the offer.

3. The letter should then come to a conclusion as to whether or not the settlement recommendation is acceptable.

4. A settlement letter should contain a discussion of the applicable facts and law sufficient to permit an understanding of the analysis of the taxpayer’s offer.


**34.8.2.5.1** **(08-05-2014)**

#### Format

01. Letterhead. Settlement letters should be prepared on the same letterhead used for defense letters. Exhibit 34.12.1-25, _Settlement Letter for Branch Chief's Signature or Associate Area Counsel Signature_, depicts a sample settlement letter.

02. Symbols, Address, Caption, and Salutation. The instructions for symbols, address, caption, and salutation are the same as those for a defense letter.

03. Opening Statement. The opening statement of a settlement letter should refer to the DOJ letter asking for the Service’s recommendation. In the next paragraph, it is helpful to point out the years, the amount of tax and the type of tax in suit. When several taxpayers are involved, the same information should be set forth for each taxpayer.

04. Statement of Issues. Following the opening statement, the issues that are stated in the referral letter should be set forth in the settlement letter. If new issues have arisen since the preparation of the referral letter, or one or more of the issues have been inappropriately set forth in the referral letter, the list of issues should be revised. Even though an issue has already been disposed of it is helpful to list it and its disposition can later be explained.

05. Statement of Offer. Following the statement of the issues, the terms of the offer should be set forth under a separate heading. If practical, the description of the offer should use a numbering system paralleling the number assigned to each issue. If there are four issues and the offer disposes of them on an issue by issue basis, disposition of each issue pursuant to the offer would be also set forth in four numbered paragraphs. If the offer reserves certain issues for litigation, or certain issues have already been disposed of, the particular status of the issue(s) should be described under the offer heading even though the pending offer does not dispose of the issue. For example, the description "This issue has been previously conceded by the Government," would be sufficient. Naturally, if the case is not being disposed of on an issue by issue basis, but instead is being disposed of on the basis of a 50 percent concession by the taxpayer and a 50 percent concession by the Government, a statement under the offer heading would be appropriate. If the terms of the offer are unclear, the attorney should first look to DOJ’s letter acknowledging the offer for clarification. If the attorney is still unclear as to the terms of the offer, the DOJ trial attorney should be contacted. Typically, the DOJ trial attorney can obtain an immediate clarification from taxpayer’s attorney, either informally or by formal supplemental offer letter, enabling Counsel to continue working on the offer. However, if the ambiguity cannot be clarified in a reasonable period, it is best to reject the offer pending further clarification.

06. Recomputation. Following the description of the taxpayer’s offer, it is necessary to make some comment with respect to a recomputation. Generally, such comment will be necessary either where DOJ has specifically requested a recomputation, if the case involves a refund that will be reported to the Joint Committee on Taxation, or if a recomputation is necessary to properly evaluate the offer and secure an allocation between tax and interest. Where a recomputation is necessary, it should be immediately requested from Appeals. _See_ CCDM 34.7.1.4.1, http://core.publish.no.irs.gov/irm/p34/pdf/irm34-007-001--2004-08-11.pdf _Recomputation of Tax Liability_.



    1. Where DOJ specifically requests a recomputation, it should generally be prepared regardless of whether Counsel recommends acceptance or rejection of the offer. If it is decided the offer will ultimately be accepted and the recomputation will eventually be necessary, its early preparation would be desirable. Where a recomputation is necessary, consideration of the case should not be suspended while the recomputation is being prepared unless absolutely necessary.

    2. An attorney may select those documents, e.g., revenue agent’s report, statutory notice of deficiency, transcripts of account, etc., that can be sent to the appropriate office for purposes of a recomputation without hindering the consideration of the offer. If documents are necessary for both purposes, sufficient photocopies are normally available in the retained file, and, if not, duplicates may be prepared. Where a recomputation would be helpful in the evaluation of the case, the attorney should obtain an estimate from Appeals of the date the recomputation will be completed. If possible, prepare the recommendation, and delay its approval until the recomputation is received. In the recomputation part of the settlement letter, the results of the recomputation should be noted. If the recomputation has been requested but not yet completed, this fact should also be noted. If a recomputation has not been requested, this fact may be noted, or the recomputation part may be omitted.


07. Discussion. The discussion part of an offer letter should be prepared in the same manner as the discussion part of a defense letter. Each issue being disposed of by the offer should be numbered and described under a separate heading; for example: Issue One. Abandonment Loss. Under this heading the facts and the legal analysis should be discussed under separate subheadings where appropriate. Obviously, if the legal issue is fact bound, or if the facts are merely incorporated by reference from the defense letter or some other document, it is permissible to discuss the facts and law together. Good judgment should be used in determining whether it would be helpful for the reader to have a separate discussion of the facts and law.



    1. At the conclusion of the discussion of the facts and law related to each particular issue, a recommendation should be made as to whether the issue may be disposed of in accordance with the offer.

    2. If possible, it is helpful to point out to what extent, if any, the offer is generous to the Government or falls short of an appropriate disposition, in order to make a better overall evaluation of the case. Where the case is being settled on the basis of an overall percentage figure, or an overall dollar figure, the attorney should attempt to place a value on the Government’s case with respect to each issue, so an eventual overall evaluation may be made.


08. Conclusion and Recommendation. A settlement letter should be concluded with a separate heading entitled Conclusion and Recommendation. If an offer disposes of a case on an issue-by-issue basis, and an attorney has concluded it is acceptable with respect to each issue, then a recommendation for acceptance may be made merely on the basis of the foregoing evaluation.



    1. If on the other hand, the attorney finds the disposition of some issues acceptable and others unacceptable, a careful evaluation would have to be made as to whether there are sufficient advantages in the proposed dispositions in favor of the Government to overcome any deficiencies with respect to the proposed unfavorable issue dispositions.

    2. Even though the offer may be acceptable, where significant issues are present the Service may wish to have the terms of the offer readjusted to accord with Counsel’s evaluation of each issue. Where the offer is based merely on a percentage of the amount in suit, or a specific dollar figure, a recomputation is generally necessary to determine whether the offer is acceptable.


09. Counterproposals. If rejection of the offer is recommended, DOJ should be advised of whether the Service still regards the case to be susceptible to settlement and the appropriate basis of an acceptable settlement. DOJ also may be advised that the case is susceptible to settlement even though no specific basis is suggested. If a specific proposal for settlement is recommended and DOJ solicits an offer consistent with the terms of the counterproposal, DOJ generally will not refer the subsequent offer to the Service for its views or recommendation. Where an offer closely approximates an attorney’s evaluation of a case, acceptance should be recommended even though it may fall slightly below what the attorney considers to be the value of the case. Naturally, determining whether a proposed settlement is within the acceptable range involves good judgment and must be applied on a case-by-case basis.

10. Nuisance Settlements. If the Government’s case is extremely strong, Counsel will occasionally receive settlement proposals asking the Government to concede five or ten percent of the case. Nuisance settlements are disfavored and should be rejected. The practice of conceding a very small percentage of a case without regard to the merits is to be thoroughly discouraged. If the Government’s chances of success in litigation are extremely small (for example, less than ten percent) the Government should not attempt to elicit a settlement from the taxpayer because of the cost of litigation to the taxpayer. Where the Government’s case is extremely weak, serious consideration should be given to recommending concession of the case.



    1. No fixed percentage is used to determine whether a nuisance settlement is present. If, for example, taxpayer’s chances of success with respect to a particular issue are extremely strong, and the issue represents only five percent of the amount in suit, it would be appropriate to consider a five percent concession based on the issue. Do not attempt to secure an advantage based on the costs of litigation.


11. Transmittal. The settlement letter should transmit to DOJ copies of any recomputations, the administrative files, if they are no longer needed by the attorney, and any other files forwarded by DOJ.

12. Signature. All settlement letters are prepared for signature on behalf of the Chief Counsel by the Field Counsel or an Associate Chief Counsel attorney. While many settlement letters must be coordinated with the appropriate Associate Chief Counsel office, they are nevertheless prepared for and signed by the Associate Area Counsel.


**34.8.2.6** **(08-11-2004)**

### Application of Executive Order 12988 on Civil Justice Reform

1. Pursuant to the Civil Justice Reform guidelines, litigation counsel are required to evaluate each case to determine whether Alternative Dispute Resolution (ADR) would assist to expedite the matter.

2. If litigation counsel is with DOJ, Service attorneys must be prepared to discuss ADR with DOJ.



1. Specifically, attorneys shall advise DOJ in the settlement letter as to what method of ADR may be most appropriate in the specific litigation.

2. Service attorneys should also render advice to DOJ on the status of settlements and roadblocks encountered.


**34.8.2.7** **(08-11-2004)**

### Conflicting Recommendations

1. On occasion the Tax Division will not agree with the Service’s recommendation. If the Review Section of the Tax Division wishes to accept an offer and the Service recommends rejection, the offer must be considered at a higher level.

2. If the Service opposes a settlement which DOJ wishes to accept, DOJ will request that the Service’s recommendation be reconsidered. At that point conferences (telephone or otherwise) may be held to reconcile the differing points of view. Generally, agreement can be reached regarding whether or not the offer should be accepted. If agreement cannot be reached, the matter should be referred to the appropriate Associate Chief Counsel office, if it is not already under such review.


**34.8.2.7.1** **(08-11-2004)**

#### The Service Recommends Acceptance

1. Where the Service recommends acceptance of an offer but DOJ wishes to reject it, the further views of the Service will be solicited either formally or informally before an ultimate decision is made. Again, if the views cannot be reconciled, the matter should be referred to the appropriate Associate Chief Counsel office, if it is not already under such review.


**34.8.2.8** **(08-11-2004)**

### Joint Committee Cases

1. Objective. Pursuant to section 6405, a refund in excess of $2,000,000 must be referred to the Joint Committee on Taxation. Congress, in instituting this requirement, intended to create a means whereby it could monitor the effectiveness of the Internal Revenue Code by examining the reasons for large refunds. Accordingly, the reports to the Joint Committee on Taxation must state in a reasonably comprehensive manner why the refunds are being made.

2. Scope. The only cases considered Joint Committee cases are those where a settlement or a concession by the Government results in a refund or credit over $2,000,000, exclusive of statutory interest. Where a refund in excess of $2,000,000 is made pursuant to an adverse judgment, rather than a settlement or concession, the refund does not have to be referred to the Joint Committee on Taxation. Furthermore, pursuant to section 6405, not all types of tax refunds must be reported to the Joint Committee. This is apparent from the language of section 6405(a) which provides as follows: "No refund or credit of any income, war profits, excess profits, estate, or gift tax, or any tax imposed with respect to public charities, private foundations, operators’ trust funds, pension plans, or real estate investment trusts under chapter 41, 42, 43, or 44, in excess of $2,000,000 shall be made until after the expiration of the 30 days from the date upon which a report giving the name of the person to whom the refund or credit is to be made, the amount of such refund or credit, and a summary of the facts and the decision of the Secretary, is submitted to the Joint Committee on Taxation."

3. Thus, if a refund is made of employment tax, 100-percent penalty, or most excise taxes, no report need be made to the Joint Committee on Taxation.


**34.8.2.8.1** **(07-27-2021)**

#### Determination of Amounts

1. In order to determine whether a settlement is a Joint Committee settlement a determination must be made as to whether the refund in question will exceed $2,000,000 ($5,000,000 in the case of C corporations). The initial determination as to whether the settlement must be referred to the Joint Committee is the responsibility of the Service. Accordingly, if an attorney receives an offer that is being settled on a percentage or an issue by issue basis, it is important to review the offer immediately to determine the type and amount of tax involved.

2. In determining whether the $2,000,000 limit ($5,000,000 in the case C corporations) has been exceeded, the amount of tax, penalty, and assessed interest paid by the taxpayer must be taken into account. Statutory interest is not taken into account. If a C corporation taxpayer has sued for the recovery of $4,450,000 tax, $335,000 penalty and $180,000 assessed interest, and the Government concedes the case, the total refund of tax, penalty, and assessed interest would be $4,965,000. Even though the Government would be required to pay an additional $248,500 interest on those amounts to the taxpayer, for a total of $5,213,500, referral to the Joint Committee would not be required. Furthermore, if three non-C corporation taxpayers are in suit and $750,000 in tax, penalty, and assessed interest is refunded to each one of them for a total of $2,250,000, this settlement would not be referred to the Joint Committee since no one taxpayer receives a refund in excess of $2,000,000.

3. Finally, if, as part of the settlement a taxpayer agrees to certain deficiencies and overpayments, the refunds will be considered diminished in amount. If pursuant to the settlement the Government and the non-C corporation taxpayer agree upon a $2,300,000 overpayment and a $1,250,000 deficiency, the net refund will be deemed to be $1,050,000, and the case will not be referred to the Joint Committee.


**34.8.2.8.2** **(07-27-2021)**

#### Computation

1. If a settlement or concession on the part of the Government is reported to the Joint Committee as required by section 6405, the amount of such refund, including tax, penalties and assessed interest, must be set forth in the report. Accordingly, it is necessary to immediately request a recomputation of the amount of tax, penalty, and assessed interest to be refunded so the appropriate figures may be submitted to the Joint Committee.

2. Normally the request for a recomputation should be made as soon as DOJ transmits the offer letter requesting the Service’s recommendation. In requesting the recomputation, normal procedures should be followed except that the person preparing the recomputation should be asked to examine the years in question for offsetting adjustments. Since offsetting adjustments could normally be utilized to reduce the amount of the refund, it is crucial to determine whether there are offsetting adjustments in order to verify the refund in question will exceed $2,000,000 ($5,000,000 in the case of C corporations). While the person preparing the recomputation is asked to review the case for offsetting adjustments, the ultimate responsibility for reviewing the case for such adjustments is with the attorney. This review is generally not de novo review, but the entire administrative file should be surveyed, and at a minimum, the attorney should be aware of those proposed adjustments in the file considered and resolved by the Service at the administrative level.


**34.8.2.8.3** **(07-27-2021)**

#### Guidelines and Procedures

1. Letter to Tax Division. The format of a letter recommending acceptance of an offer in a Joint Committee case is identical with the format of a letter recommending acceptance of an offer in a case where a report to the Joint Committee is not required. At the conclusion of the letter DOJ should be advised that, since the refund called for under the terms of the offer exceeds $2,000,000 ($5,000,000 in the case of a C corporation), we have examined the case for offsetting adjustments. If none has been found, the following statement should be used: "Our review discloses no offsetting adjustments which would serve to reduce the amount of the refund." If there are offsetting adjustments, they should be set forth and fully explained.

2. Tax Division Memorandum in Support of Settlement. Section 6405 requires a referral be made to the Joint Committee giving the name of the person to whom the refund or credit is to be made, the amount of such refund or credit, and the summary of the facts and the decision of the Secretary. At one time this report was prepared by the Office of the Chief Counsel. The substantive portion of the report is now prepared by the appropriate civil trial section attorney with an accompanying summary memorandum prepared by the Office of Review. The report is used to advise the Joint Committee of the proposed refund.

3. Transmittals. If the Assistant Attorney General, Tax Division, is in favor of the proposed settlement or concession, the Office of Review will transmit to the Joint Committee the memorandum in support of the settlement or concession. On the same date, the Office of Review also will notify Field Counsel or the responsible Associate Chief Counsel office of the submission of the proposed settlement or concession to the Joint Committee. Final action by DOJ on the proposed settlement or concession will not be taken until the 30-day review period has expired. If the offer is ultimately accepted or concession approved, the Office of Review will authorize the Service Center to issue the refund and also will advise Field Counsel or the responsible Associate Chief Counsel office of the acceptance of the offer or approval of the concession and also of the authorization of the issuance of the refund.


**34.8.2.8.4** **(07-27-2021)**

#### Attorney’s Responsibility

1. Before proposing any settlement or concession, in whatever form, in any of such cases, the attorney to whom a case is assigned, whether in the Field or an Associate office, has the responsibility of ascertaining whether such settlement or concession would result in the case having to be first reported to the Joint Committee. Any partial settlement that could potentially result in a refund in excess of $2,000,000 ($5,000,000 in the case of a C corporation) should only be negotiated with the express understanding that it is subject to Joint Committee review if the disposition of the remaining issues by way of settlement or concession results in a net refund in excess of $2,000,000 ($5,000,000 in the case of a C corporation).

2. In cases pending in a field office in which there is a substantial doubt as to whether the net overpayment resulting from the proposed settlement or concession would make it a Joint Committee case, the field office should request a tentative computation from Appeals. In borderline cases, where there is a substantial doubt as to the interpretation of the guidelines to be applied in determining whether it is a Joint Committee case, the field office should refer the matter to the Office of the Associate Chief Counsel (Procedure & Administration) before proceeding further with the settlement or concession.

3. With respect to concessions or settlement offers in refund cases pending in the courts of appeals or the Supreme Court, the Field or Associate office attorney has the same responsibility to ascertain whether the proposed concession or settlement would result in a Joint Committee case as with respect to Tax Court cases. Whenever a proposed settlement requires a report to the Joint Committee, the letter to DOJ recommending acceptance of the offer shall include the following statement: "An examination of the case has satisfied us that there are no offsetting adjustment that would have the effect of reducing the proposed overassessment below $2,000,000 ($5,000,000 in the case of a C corporation)."


**34.8.2.8.5** **(07-27-2021)**

#### Procedures in Refund Joint Committee Cases

1. When DOJ forwards a settlement offer for consideration by the Office, the Field Counsel office will promptly review the substantive and computational matters, whether the computation has been prepared by Justice, the taxpayer’s counsel, or the Service. If Field Counsel recommends acceptance, the Field Counsel attorney will prepare a settlement letter recommending acceptance of the offer. This letter is to be dated and signed on behalf of the Chief Counsel by the Associate Area Counsel.

2. To speed up the settlement process in refund Joint Committee cases, counsel and DOJ have agreed that DOJ is authorized to submit to the Joint Committee a report as to each compromise or government concession involving a refund of tax, penalty, and interest paid in excess of $2,000,000 ($5,000,000 in the case of a C corporation) that the Office of Chief Counsel has affirmatively recommended or as to each compromise involving a refund of tax, penalty, and interest paid in excess of $2,000,000 ($5,000,000 in the case of a C corporation) in a case that has been classified S.O.P.

3. In refund cases, the report to the Joint Committee is prepared by the appropriate civil trial section attorney in DOJ and the accompanying summary memorandum is prepared by the Office of Review.

4. If the Assistant Attorney General, Tax Division, is in favor of the proposed settlement, the Office of Review will transmit to the Joint Committee the memorandum in support of the settlement. On the same date, the Office of Review also will notify Field Counsel or Chief Counsel of the submission of the proposed settlement to the Joint Committee. Final action by DOJ on the proposed settlement will be taken after the period for review by the Joint Committee has expired.

5. Exhibit 34.12.1-26, _Letter to Joint Committee_ is an example of the letter DOJ will use in reporting the overpayments and transmitting the supporting memorandum to the Joint Committee.

6. It should also be noted that in accordance with present procedures, if DOJ obtains a better settlement than what Counsel has recommended, the case will not be returned to Counsel for consideration.


**34.8.2.8.6** **(08-11-2004)**

#### Processing Court of Appeals and Supreme Court Joint Committee Cases

1. In court of appeals and Supreme Court cases requiring a report to the Joint Committee, DOJ prepares the report and transmits it directly to the Joint Committee.


**34.8.2.8.7** **(08-05-2014)**

#### Procedure to be Followed for Joint Committee Settlements Which Must be Approved by DOJ

1. Pursuant to IRC-7122, the Attorney General has the authority to compromise any civil or criminal tax case which has been referred to DOJ for prosecution or defense. Therefore, DOJ must approve any settlement which encompasses a Tax Court case for one year and a pending refund suit for another year. _See_ CCDM 34.5.2.5, http://core.publish.no.irs.gov/irm/p34/pdf/irm34-005-002--2012-12-21.pdf, _Case Coordination/Coordination of Tax Court and Refund Cases_.

2. The coordination procedures to be followed when the settlement produces an overpayment that must be reported to the Joint Committee are the same as the coordination procedures that are followed when a report to the Joint Committee is not required.


**34.8.2.9** **(08-11-2004)**

### Court of Federal Claims Rules Governing TEFRA Partnership Settlements

1. The Court of Federal Claims has adopted special rules governing settlements by partners in partnership cases brought under section 6226 or 6228. _See_ Rule 7, Appendix F, _Rules Of The United States Court Of Federal Claims_. These rules mirror Tax Court Rule 248. Consequently, DOJ will be required to follow these rules in the same manner as the Office of Chief Counsel is required to follow Tax Court Rule 248.


**34.8.2.10** **(08-11-2023)**

### Qualified Offers Under I.R.C. § 7430

1. Section 7430 provides a qualified offer rule effective for costs incurred . This section addresses the positions to be taken in responding to assertions by taxpayers that they are entitled to an award of costs based upon the qualified offer rule. Treasury Regulation section 301.7430-7 implements this rule.

2. Upon receipt of a settlement offer that references qualified offers or sections 7430(c)(4)(E) or (g), the attorney assigned to the case should promptly notify Procedure & Administration, Branch 5. Follow the directions in CCDM 35.10.1.3.2(1).


**34.8.2.10.1** **(08-11-2004)**

#### Qualified Offer Defined

1. A qualified offer is a written offer that: (1) is made by the taxpayer to the United States during the qualified offer period; (2) specifies the amount of the taxpayer’s liability (determined without regard to interest); (3) is designated as a qualified offer at the time it is made; and (4) remains open until the earliest of the date the offer is rejected, the date the trial begins or the 90th day after the date the offer is made. It is the Service’s position that, in order to meet the requirement that the offer specifies the amount of the taxpayer’s liability, the offer must establish the taxpayer’s liability (determined without regard to interest) by setting forth the dollar amount of the taxpayer’s offer, as stated above, on all of the adjustments at issue in the proceeding at the time the qualified offer is made.


**34.8.2.10.2** **(08-11-2004)**

#### Qualified Offer Rule

1. In general, a prevailing party may recover the reasonable administrative and litigation costs incurred in administrative and court proceedings if the proceedings relate to the determination or refund of any tax, interest or penalty under the Internal Revenue Code. Under the statute, the making of a qualified offer may result in the taxpayer being a prevailing party for purposes of a recovery of costs. A taxpayer is a prevailing party by reason of making a qualified offer if the taxpayer’s liability under the last qualified offer would equal or exceed the amount of the taxpayer’s liability under the judgment entered by the court.


**34.8.2.10.3** **(08-11-2023)**

#### Additional Requirements for Qualifying as a Prevailing Party

1. To qualify as a prevailing party under the statute, taxpayers must meet the net worth requirements of section 7430(c)(4)(A)(ii). Furthermore, to qualify for an award, taxpayers must meet the remaining requirements of section 7430, such as not unreasonably protracting the proceedings and, for purposes of an award of litigation costs, exhausting their administrative remedies. On the other hand, a taxpayer qualifying as a prevailing party by reason of having made a qualified offer need not substantially prevail on either the amount in controversy or the most significant issue or set of issues presented. Similarly, whether the positions of the United States in the administrative and litigation proceedings were substantially justified is not relevant for an award under the qualified offer rule.

2. A taxpayer cannot qualify as a prevailing party under this rule if the determination of the court with respect to the adjustments included in the last qualified offer is entered exclusively pursuant to a settlement. For a discussion of the issue in the context of full concessions on the part of the United States after rejection of a valid qualified offer, refer to CCDM 35.10.1.3(3).

3. Neither can a taxpayer qualify as a prevailing party under this rule in any proceeding in which the amount of tax liability is not in issue, including any declaratory judgment proceeding, any proceeding to enforce or quash any summons issued pursuant to the Internal Revenue Code of 1986, and any action to restrain disclosure under section 6110(f).

4. A partnership cannot make a qualified offer in a TEFRA partnership-level proceeding because the qualified offer rule requires that the judgment of the court address the "liability of the taxpayer." I.R.C. § 7430(c)(4)(E)(i). A partnership is not a taxpayer. Although tax liabilities flow through the partnership to the partners, the partners’ liabilities are not at issue in the TEFRA partnership-level proceeding. But see, BASR Partnership v. United States, 915 F.3d 771, FN 10 (Fed. Cir. 2019) (leaving open the question of whether a partnership could be considered a taxpayer under the qualified offer rule).


**34.8.2.10.4** **(08-11-2004)**

#### Comparison of Liability under the Offer to Liability Under the Judgment

1. The comparison of the taxpayer’s liability under the qualified offer with the liability under the judgment is central to the operation of the qualified offer rule. Other than the statement in section 7430(c)(4)(E)(ii)(I) to the effect that the qualified offer rule does not apply to any judgment issued pursuant to a settlement, the statute is silent regarding how the liability under the judgment is determined.

2. The attorney, nevertheless, should ensure that a qualified offer encompasses all of the adjustments at issue at the time the offer is made, and that it be compared to the outcome at the end of the litigation on all of those adjustments and only those adjustments. Thus, the liability under the judgment entered by the court is that liability attributable to the adjustments included in the last qualified offer that were actually determined by the court through litigation, plus the amount of any additional adjustments subject to the last qualified offer that were determined by settlements entered into after the making of the last qualified offer. Adjustments raised subsequent to the making of the last qualified offer by any party are ignored in determining the liability of the taxpayer to be compared with the liability under the last qualified offer.


**34.8.2.10.5** **(08-11-2004)**

#### Fees Recoverable

1. An award based upon the taxpayer’s having made a qualified offer is limited to those reasonable administrative and litigation costs incurred on or after the date of the last qualified offer. If the taxpayer is a prevailing party without regard to the qualified offer rule, the reasonable administrative and litigation costs to which the taxpayer is thus entitled may not be awarded again by reason of the taxpayer having made a qualified offer.

2. On the other hand, even though some costs in a proceeding may be awarded without regard to the qualified offer rule, it is possible for other costs in the same proceeding to be awarded under the qualified offer rule. For instance, costs incurred in different portions of the proceedings or with regard to different adjustments at issue may be awarded under the qualified offer rule despite the awarding of other costs without regard to the qualified offer rule.


**34.8.2.10.6** **(08-11-2023)**

#### Qualified Offer Period

1. Aside from the minimum period during which a qualified offer must remain open, a qualified offer must be made during the qualified offer period. That period begins on the date the first letter of proposed deficiency that allows the taxpayer an opportunity for administrative review in the Internal Revenue Service Office of Appeals is sent.

2. The qualified offer period ends on the date that is thirty days before the date the case is first set for trial. In the Tax Court, cases are placed upon a calendar for trial and at the calendar call cases are scheduled for a specified day for trial during that trial calendar. Consequently, in determining when the qualified offer period ends for cases in the Tax Court and other courts of the United States using calendars for trial, we will consider a case to be set for trial on the date scheduled for the calendar call.

3. Cases may be removed from a trial calendar at any time. Thus, a case may be removed from a calendar before the date that is thirty days before the date scheduled for that calendar. In order to promote the settlement of such cases, we will consider the qualified offer period to remain open until the case remains on a calendar for trial on the date that is thirty days before the scheduled date of the calendar call for that trial session.

4. The qualified offer period may not be extended, although the period during which a qualified offer remains open may extend beyond the statutory ninety-day period. Extensions are at the discretion of the taxpayer and must be made in writing before the ninety days expire. See Treas. Reg. 301.7430-7(c)(5).


**34.8.2.11** **(08-11-2004)**

### Coordination of Refund Cases and Collection Cases with Tax Court Cases

1. The handling and processing of Tax Court cases related to cases referred to DOJ for litigation must be closely coordinated so as to establish a consistent litigation position in all courts.

2. Under some circumstances, even though the Tax Court case is to be tried, it may be advisable for the field office to submit to DOJ a statement of the facts proposed to be stipulated or proposed to be introduced into evidence in the trial of the Tax Court case. Likewise, if a refund suit is to be tried prior to a Tax Court case, it may be advisable for the field office to forward to DOJ a letter setting forth factors involved in the related Tax Court case which should be considered by the DOJ attorney in litigating the refund suit.


**34.8.2.11.1** **(08-05-2014)**

#### Attorney General’s Settlement Authority in Related Tax Court Cases

1. The basic authority of the Attorney General to settle tax cases within the jurisdiction of DOJ and related cases pending with the Internal Revenue Service is contained in IRC-7122(a) and Executive Order No. 6166, dated June 10, 1933. _See_ C.B. X111-2, 449. Section 5 of that Order provides, in part, as follows: "As to any case referred to Department of Justice for prosecution or defense in the courts, the function of decision whether and in what manner to prosecute, or to defend, or to compromise, or to appeal, or to abandon prosecution or defense, now exercised by any agency or officer, is transferred to Department of Justice."



### Note:



See CCDM 35.5.3.2, http://core.publish.no.irs.gov/irm/p35/pdf/irm35-005-003--2004-08-11.pdf, _Coordination of Settlement in Related Tax Court Cases with the Attorney General_, and CCDM 34.8.1.1.2, http://core.publish.no.irs.gov/irm/p34/pdf/irm34-008-001--2004-08-11.pdf _, Settlement Authority_, for a discussion of the Attorney General’s authority.

2. In the Attorney General’s opinion to the Secretary of the Treasury (Op. A.G. 7, C.B. XIII-2, 445, 38 Op. Atty. Gen. 94) the Attorney General concluded that DOJ has the authority to compromise not only the case pending before it, but "\*\*\* any other matter germane to the case which the Attorney General may find it necessary or proper to consider before he invokes the aid of the courts; \*\*\*." Once the authority of DOJ has been invoked in a case pending in any court, the Attorney General has the authority to settle not only such case, but also to settle any related pending Tax Court case, or case involving related years of the same taxpayer, which is pending administrative determination in the Internal Revenue Service if such related matters are germane to the court case referred to DOJ.

3. The authority of the Tax Division to settle related cases should be reflected in the original suit or defense letter. If not so reflected, another suit authorization letter to the Tax Division may be required concerning the tax liability in the event that the settlement authority of the Attorney General over a particular tax liability comes into question.

4. In actual practice, the Attorney General’s authority is exercised when there is a pending refund or collection suit with DOJ, and the taxpayer’s offer of settlement includes not only disposition of the refund or collection suit, but also disposition of a related Tax Court case or a related nondocketed case. It is after DOJ has received the recommendation of the Chief Counsel that a final determination on the acceptance or rejection of the offer is made. The authority of the Attorney General also attaches in instances in which an offer of settlement is made to the Service to dispose of not only the Tax Court and/or nondocketed case, but also a pending refund or collection suit.

5. Often the taxpayer will submit an offer of settlement in the Tax Court case without including a proposal to dispose of the related refund suit. After coordination and clearance, the Service is free to take final action solely with respect to the Tax Court case.

6. For the settlement of a Tax Court case with dismissal of a related refund suit see CCDM 34.8.1.3, http://core.publish.no.irs.gov/irm/p34/pdf/irm34-008-001--2004-08-11.pdf, _Coordination_.

7. Settlement procedure agreements approved by the Chief Counsel and the Tax Division provide procedures for the processing of settlement offers in refund suits. The purpose of these agreements is to expedite the consideration and final action to be taken on all offers in settlement in which DOJ makes the final determination. These agreements provide for the classification of refund suits as either S.O.P. (settlement option procedure) or Standard. The procedures under the agreements with DOJ, insofar as applicable, are to be followed in Tax Court cases having related refund suits and for cases on appeal from the Tax Court. See CCDM 34.8.1.2, _Settlement Recommendations_, for procedures to be followed by field offices submitting recommendations on offers to settle refund suits.

8. For collection suits or other collection action involving the same liability as that pending in a Tax Court case, DOJ usually does not provide advice concerning the merits of the settlements of the tax liability, but in some instances it may do so. Thus, if a related collection suit is pending in a United States District Court, the Attorney General has the same authority over the settlement of the two cases as it does over related Tax Court cases and refund suits.

9. If the Tax Court case is settled after the refund or collection matter, the Stipulation and Decision filed with the Tax Court must reflect that all or a portion of the related case has been settled by another court. Exhibit 34.12.1-27, _Adjudication by Another Court Having Concurrent Jurisdiction with Tax Court_, contains samples of stipulations and decisions to be filed in the Tax Court case.


**34.8.2.11.2** **(08-05-2014)**

#### Settlement Offers in Tax Cases

1. A settlement or concession of a Tax Court case may not be made when there is a related refund suit pending in a United States District Court, the Court of Federal Claims, a court of appeals, or the Supreme Court, without prior coordination through the appropriate Associate Chief Counsel Office and with DOJ. Likewise, a proposed settlement or concession of a refund suit will be coordinated with the related Tax Court case prior to the Chief Counsel’s recommendation to DOJ. See CCDM 34.8.1.2, _Settlement Recommendations_, for Refund Litigation Settlements and CCDM 35.5.1.4.1, http://core.publish.no.irs.gov/irm/p35/pdf/irm35-005-001--2004-08-11.pdf, _Settlement Procedures_, for Tax Court cases. The requirements set forth in this section are applicable in the following situations:



   - The Attorney General has the final authority in the settlement of the Tax Court case

   - The settlement of the Tax Court case is to be effectuated without a corresponding settlement of the refund suit

   - The offer is to settle only the Tax Court case with the simultaneous dismissal of the refund suit in which there are counterclaims on behalf of the Government in the refund suit

   - The Tax Court settlement allots monetary value or consideration for the dismissal of the refund suit



     ### Note:



     These offers may be submitted by the taxpayer either directly to DOJ or to Field Counsel.


2. If the taxpayer submits an offer to settle only the Tax Court case, such offer shall be processed in the field office in the same manner as any other offer. However, before the Service accepts an offer, it shall be coordinated with DJ. A rejection need not be coordinated.

3. If the offer to settle only the Tax Court case is acceptable, Field Counsel should prepare a letter to DOJ including:



   - The issues involved in the taxpayer’s case

   - The taxpayer’s offer to settle those issues

   - The reasons why the offer is viewed as being acceptable

   - An inquiry as to whether DOJ has an objection to the settlement

   - A statement as to why the Service views the settlement as not adversely affecting the refund case

   - The extent to which a deficiency or overpayment will be stipulated in the Tax Court case



     ### Note:



     The letter should, In its caption, reflect the name and the docket number of the refund case.


4. In the settlement of a Tax Court case requiring approval of the Attorney General, it is essential to determine the extent to which a deficiency or overpayment will be stipulated in the Tax Court case. The letter to DOJ recommending action on the offer should clarify or seek clarification on that point.

5. For last-minute settlement offers received at or about the time of trial, move to continue the case at least 90 days in the future. Doing so should allow sufficient time to complete coordination of the settlement with DOJ.

6. Offers submitted by the taxpayer to settle both the refund suit and the Tax Court case must be finally accepted or rejected by or on behalf of the Attorney General. The petitioner, or representative, should be informed of this fact at the settlement conference. Even if the conference is attended by a DOJ attorney, and the DOJ attorney and the field office attorney are in agreement, the taxpayer should not be led to believe that an offer has been accepted. The taxpayer may be informed, however, that the offer will or will not be recommended for acceptance by those attending the conference. Also coming within this category are offers to settle solely the Tax Court case and the simultaneous dismissal of the refund suit if there are counterclaims on behalf of the Government in the refund suit, or if in the Tax Court settlement monetary value or consideration for the acceptance is to be given to the dismissal of the refund suit. These offers may be submitted by the taxpayer either directly to DOJ or to Counsel.

7. For offers submitted to settle both a Tax Court case and a related refund suit, the following procedures should be followed:



1. If Chief Counsel recommends acceptance of the offer, but DOJ rejects the offer, DOJ will be free to accept an offer in a more substantial amount without the resubmission of the new offer for Counsel’s views.

2. If Chief Counsel recommends rejection of the offer, the letter, when feasible, should set forth the minimum offer which Chief Counsel believes should be recommended for acceptance in the overall settlement of the Tax Court case and the refund suit.

3. When feasible, a recomputation of the dollar results of the settlement proposal as it affects both cases should be forwarded with Chief Counsel’s recommendation of the offer. However, the recommendation must not be unduly delayed to obtain such recomputation.


**34.8.2.11.3** **(08-05-2014)**

#### Settlement of Tax Court Case with Dismissal of Refund Suit

1. If a counterclaim is pending for a related refund suit, or if any monetary value is to be assigned to the taxpayer’s willingness to dismiss the refund suit, the offer may not be accepted without prior coordination with DOJ.

2. In some cases when the principal controversy is pending in the Tax Court, the taxpayer will dismiss the refund suit with prejudice if he obtains an agreeable settlement of the Tax Court case. DOJ has agreed that in such situation the Chief Counsel may, without prior clearance from DOJ, obtain an appropriate agreement from the taxpayer for dismissal of the refund suit, with prejudice, and send it to the Tax Division of DOJ for filing with the United States district court or Court of Federal Claims, as appropriate. This procedure is applicable only if there is no counterclaim in the refund suit, and only if no monetary value is assigned to the dismissal of the refund suit in the Tax Court settlement. The Field Counsel office, in settling the Tax Court case with provision for the dismissal of the refund suit, must be careful to determine that the settlement offer is acceptable on its own merits without regard to dismissal of the refund suit, and that the concession of the refund suit plays no part in the acceptance on the merits of the offer in the Tax Court case. This provision is necessary and must be strictly followed by Field Counsel, due to the statutory responsibility placed upon the Attorney General for the compromise of tax cases pending in the United States district court or Court of Federal Claims.

3. In effecting the settlement, Field Counsel must obtain from the taxpayer’s attorney of record in the district court or Court of Federal Claims, a stipulation to dismiss with prejudice the refund suit. A stipulation for a dismissal of a district court case shall be prepared for the signature of the U.S. Attorney; a stipulation for dismissal of the Court of Federal Claims case shall be prepared for the signature of the Assistant Attorney General, Tax Division. Simultaneously with the filing of the Tax Court stipulation, Field Counsel should forward a letter to DOJ indicating the settlement of the Tax Court case, the willingness of the taxpayer to execute the dismissal of the refund suit, and the fact that no consideration was given to the dismissal of the refund suit in evaluating the settlement offer with respect to the Tax Court case. The stipulation of dismissal of the refund suit should be forwarded with this letter. A sample Stipulation for Dismissal may be found at Exhibit 34.12.1-28, _Dismissal of Related Refund Suit_.


**34.8.2.11.4** **(08-11-2004)**

#### Settlement Offer to Settle Only the Refund Suit

1. Generally, settlement offers in refund suits are processed in two different ways: settlement option procedure ("S.O.P." ) or Standard. For a case classified as S.O.P., DOJ may either accept or reject an offer of settlement without first obtaining Chief Counsel’s recommendation. However, Chief Counsel will be notified if the offer is accepted on behalf of the Attorney General. For cases classified as Standard, DOJ will forward to the Field Counsel for recommendation, the taxpayer’s settlement proposal of the refund suit prior to either acceptance or rejection.

2. Normally, a refund suit is not classified as an S.O.P. case if there is a related case pending in the Tax Court. If a refund suit is initially classified S.O.P. and at a later date a related case is commenced in the Tax Court, Field Counsel will inform DOJ of the related Tax Court case, and that the refund suit has been reclassified as Standard.

3. Upon receipt of an offer to settle solely the refund suit in a case which is related to a Tax Court case, the field office will prepare a letter to DOJ containing its views as to the effect of the acceptance or rejection of the settlement offer on the Tax Court case. If the same general issues, facts or fact pattern, are involved in both cases, the letter should state whether the proposed settlement of the refund suit would have a substantial effect on the disposition of the Tax Court case, either by trial or settlement, and the basis for such views.

4. If the offer in the refund suit is accepted on behalf of the Attorney General, appropriate notification will be given to the field office by DOJ.


**34.8.2.11.5** **(08-11-2004)**

#### Offer Submitted to Field Office

1. If an offer is received by Field Counsel to settle not only the Tax Court case but also the related United States District Court or Court of Federal Claims case, Field Counsel shall immediately send a copy of the offer to DOJ.

2. As soon as possible, Field Counsel should forward a letter setting forth its views regarding the acceptability of the offer.

3. For primarily legal issue cases, cases involving a question of Service position and, as appropriate, for primarily factual issue cases, the letter should analyze the issues in relation to the provisions of the Internal Revenue Code, regulations, revenue rulings, or other indicated Service position which may be involved, as well as decided cases, both supporting and against the position taken in the recommendation. In many instances, neither the Associate Chief Counsel Offices nor DOJ has all of the facts necessary for an adequate appraisal of a settlement offer. This is particularly true with regard to whether the offer is adequate for the Tax Court case or the factual relationship between the Tax Court and refund cases.

4. The disagreement procedures for Tax Court cases are not applicable to this type of offer since its final acceptance or rejection must be made by DOJ, and the views transmitted to DOJ are those of the Chief Counsel, rather than of the Commissioner. Thus, the exclusive settlement authority possessed by Appeals pursuant to Rev. Proc. 87-24 is not applicable to this type of offer.


**34.8.2.11.6** **(08-05-2014)**

#### Offer Submitted to DOJ

1. When a taxpayer submits to DOJ an offer to settle not only the United States District Court or Court of Federal Claims case, but also the Tax Court case, such offer is referred to Field Counsel for a recommendation. The procedures as to offers submitted to the field office are also applicable to these offers. _See_ CCDM 34.8.1.3.5, http://core.publish.no.irs.gov/irm/p34/pdf/irm34-008-001--2004-08-11.pdf, _Appellate Section, Tax Division, Department of Justice_.

2. In cases in which the field’s letter is submitted to an Associate Chief Counsel Office for review, unless otherwise directed the letter must be received in that office within 25 days after receipt of the offer from DOJ. In cases in which the letter recommending action on the offer is mailed directly by the field to DOJ, the letter is due in DOJ within 30 days after receipt of the offer from DOJ. In many instances, the refund suit has been scheduled for trial and the judge may not delay the trial to afford an extensive period of time for consideration of the offer. Thus, consideration of these offers should be given priority. These time limitations are applicable to any recommendation which is to be made to DOJ, whether the offer pertains solely to the refund suit or to both the Tax Court case and the refund suit.


**34.8.2.11.7** **(08-05-2014)**

#### Direct Mailing vs. Associate Chief Counsel Review of Settlement Letters

1. All letters to DOJ regarding settlement may be sent directly by Field Counsel, except the following must be submitted to an Associate Chief Counsel Office for review:



1. Letters recommending acceptance of offers covering years or parties not in suit (prepared for signature of Chief Counsel or current delegate).

2. Letters recommending acceptance of offers which must be submitted to the Joint Committee on Taxation.

3. Letters recommending acceptance of offers concerning attorneys’ fees and costs under the Equal Access to Justice Act.


2. Notwithstanding the above, Field Counsel, in their discretion, may send any letter to an Associate Chief Counsel Office for review. Two information copies of any directly mailed letter should be sent by Field Counsel to the Office of the Associate Chief Counsel (Procedure & Administration).

3. The Technical Services Support Branch (TSS4510), will receive all refund settlement letters sent for review.


**34.8.2.11.8** **(08-05-2014)**

#### Coordination of Tax Court Cases and Collection Cases

1. Attorneys handling related tax litigation and collection cases should carefully consider the effect the proposed action may have on the related case. Division Counsel should establish procedures for coordinating related matters within the division.

2. A settlement or concession of a Tax Court case may not be made when there is a related collection case pending in any court without prior coordination through the Associate Chief Counsel offices and with DOJ. Likewise, a proposed settlement or concession of a related collection case will not be made or recommended to DOJ without prior coordination with the Tax Court case.

3. Area Counsel will coordinate, or cause to be coordinated within their areas, the tax litigation and collection litigation activities of related cases. They will also keep the Offices of the Associate Chief Counsel (Procedure & Administration) advised of the status of the respective related cases. These offices will coordinate such matters and action will not be taken or recommended in one case without prior coordination. This includes all recommendations by the Chief Counsel to DOJ with respect to collection matters within the jurisdiction of DOJ, and to all recommendations to the Associate Chief Counsel (International) which may affect a Tax Court matter.


**34.8.2.11.9** **(08-05-2014)**

#### Tax Litigation and Collection Suits in Associate Chief Counsel Offices

1. Offers of settlement received by Field Counsel in Tax Court cases having collection suit aspects will be processed as follows.

2. If the offer is clearly inadequate, Field Counsel may reject the offer unless specific instructions have been issued to counsel in the case by the Associate Chief Counsel office. In this situation, DOJ normally is interested only in the collection aspects of the collection case and not in the merits determination of the tax liability.

3. If the offer is acceptable to Field Counsel, the attorney shall prepare and forward to the Office of the Associate Chief Counsel (Procedure & Administration) a proposed letter to DOJ setting forth the issues in the Tax Court case, the taxpayer’s offer of settlement of such issues, and a statement that such offer is acceptable to Chief Counsel’s Office. The proposed letter will also request the views of DOJ as to Field Counsel’s acceptance of the offer to resolve the Tax Court case.

4. For settlement offers in cases in which the trial has begun or is about to begin, Field Counsel may follow the procedures set forth with respect to offers in cases having related refund suit aspects. _See_ CCDM 34.8.1.3.2, Coordination of Settlement of Related Tax Court and Refund Litigation Cases, CCDM 34.8.1.3.3, http://core.publish.no.irs.gov/irm/p34/pdf/irm34-008-001--2004-08-11.pdf, _Criminal Tax Division_, and CCDM 34.8.1.3.4, _Other Division or Offices_.

5. For cases in which the merits of the tax liability are involved in the collection suit, or cases in which DOJ has exercised jurisdiction in the settlement of the merits determination, the procedures set forth with respect to refund suit coordination are to be followed. For offers submitted to DOJ to settle on the merits both the collection suit and the Tax Court case, the cases will be coordinated in the field office.


**34.8.2.11.10** **(08-05-2014)**

#### Coordination of Tax Court with Receiverships or Other Insolvency Cases

1. Insolvency proceedings include such proceedings as federal receiverships, state receiverships, and state probates. In non-receivership proceedings, claims for deficiencies in income, estate and gift taxes may be filed. The effect of the allowance of such claims, or whether the court has jurisdiction to consider the merits of the claims, will vary according to the type of case and the forum. Depending upon the timing of the Tax Court petition, the court in the insolvency proceeding may have concurrent jurisdiction to consider the merits of the tax.

2. The general provisions for coordination in insolvency cases are applicable with respect to decedent estate cases. As in Tax Court cases having receivership aspects, it is always preferable that the merits of the case be determined in the Tax Court, rather than in the probate court or other courts involved in the related aspects of the case.

3. Section 6871(a) generally provides that on the appointment of a receiver for the taxpayer in any federal or state receivership, any deficiency in income, estate, or gift taxes, or in taxes under chapters 41 through 44, may be immediately assessed. Also, section 6871(c), provides generally that a claim for such deficiency may be made to the receivership court despite the pendency of a related Tax Court proceeding, but that no petition may be filed with the Tax Court after the appointment of the receiver.

4. In these insolvency proceedings, questions may be raised as to the Government’s claim for taxes, either upon the merits of the tax liability or for technical reasons pertaining to the claim itself, such as the timeliness of the proof of claim, the inclusion therein of penalties, or priority of the Government’s lien.

5. In general, the field office should give consideration to the following:



1. When feasible, appropriate action should be taken to expedite the disposition of the Tax Court case prior to the conclusion of an insolvency proceeding in which both courts have concurrent jurisdiction. This may involve obtaining the approval of the fiduciary to having the Tax Court determine the tax liability prior to final action in the insolvency case on the Government’s claim. Resolving the Tax Court case first will avoid many problems which may be encountered after the insolvency case is closed.

2. In many instances, a question may arise as to who has authority to negotiate settlement or to prosecute the Tax Court case on behalf of the taxpayer. In limited receivership cases, there may be no problem because the taxpayer may be free to prosecute the Tax Court case; however, the particular law involved should be researched before making a decision on this point.

3. In instances in which it is not practical or feasible to settle the Tax Court case prior to the disposition of the related insolvency case, and the taxpayer shows little or no interest in the Tax Court case, the Tax Court case may be disposed of by taking a default judgment at trial. If fraud penalties are involved, the case will be handled in the same manner as any other default case involving issues upon which the burden of proof is on the respondent.

4. In many, if not most, insolvency cases, years or taxes are involved which are not involved in the Tax Court case. Thus, any offer of settlement in the insolvency case may encompass taxes or years not before the Tax Court. In these situations, the action taken on the offer in the insolvency case may have a direct effect upon the Tax Court case.


6. Usually, DOJ is not concerned with the amount of the settled tax liability because DOJ’s primary case relates to the allowance and collection of the taxes that are due in the insolvency proceeding. When offers to settle the Tax Court case are submitted to Field Counsel, the attorney should ascertain whether DOJ or the U.S. Attorney has any interest in the determination of the amount of the correct tax liability. If so, before Field Counsel makes a final commitment on the offer, clearance should be obtained from DOJ. To obtain clearance, Field Counsel shall prepare a proposed letter to DOJ setting forth the tax liability involved in the Tax Court case and the proposed settlement. The letter will also inquire whether DOJ has any objection to Field Counsel accepting the settlement offer. This letter will be forwarded for review by the office of the Associate Chief Counsel (Procedure & Administration).

7. If an offer is received by the Office of the Associate Chief Counsel (Procedure & Administration) in a case having Tax Court aspects, that Office will obtain the views of the field office with respect to the effect of the offer on the Tax Court case.

8. If the Tax Court petitioner dies during the pendency of the case, problems may arise necessitating coordination. A successor petitioner must be named for the Tax Court case. Each case will have to be handled according to the particular facts or circumstances involved.


**34.8.2.11.11** **(08-05-2014)**

#### Attorney General’s Offer in Compromise Refund Suits

1. Cases settled on the basis of an offer in compromise accepted by the Attorney General are situations in which there are pending cases in the U.S. District Courts and Court of Federal Claims and also in the Tax Court. While usually these are related Tax Court and refund suit cases, they may also involve Tax Court and collection suit cases.

2. The coordination instructions must be followed before the Tax Court settlement can be finalized, both in instances in which the offer is finally passed upon by the Attorney General and in those cases in which the Tax Court case is disposed of without a simultaneous disposition of the United States district court or Court of Federal Claims case. Usually, in the settlement by the Attorney General, any deficiency in tax or penalty to be collected in the Tax Court case is offset in the compromise of the refund case; therefore, the stipulation would state that there has been an acceptance of an offer in compromise by the Attorney General, and that by reason thereof there is now no deficiency in tax or penalty due in the Tax Court case. _See_ Exhibit 34.12.1-29, _Compromise by the Attorney General_. If a deficiency in tax or penalties is to be collected in the Tax Court case, however, the regular form of stipulation is to be used. _See_ Exhibit 34.12.1-28, _Dismissal of Related Refund Suit_.


**34.8.2.11.12** **(08-05-2014)**

#### Cases Having Concurrent Jurisdiction with Another Case

1. If a case is pending in the Tax Court and also in another court having concurrent jurisdiction as to the parties and subject matter, it must be handled in accordance with the facts and circumstances thereof.

2. If the Tax Court case is disposed of first, no problem arises. However, if the other court determines the tax and penalty liabilities prior to the decision of the Tax Court, the Tax Court case must nevertheless be closed by stipulation or motion. The type of stipulation to be used in this situation will be similar to that used in cases in which the related United States district court case has been compromised by the Attorney General, except that reference is made to the other court having concurrent jurisdiction and its final determination of the tax and penalty liabilities, rather than to the compromise of such tax and penalty liabilities by the Attorney General. _See_ Exhibit 34.12.1-27, _Adjudication by Another Court Having Concurrent Jurisdiction with Tax Court_.


**34.8.2.12** **(08-05-2014)**

### Reversal of Unauthorized Abatements Following Referral to the Department of Justice

1. Following referral of a case, Justice has the exclusive authority to make and approve adjustments to the referred tax liabilities. Any abatement of unpaid tax made by the Service for a liability that has been referred to Justice must be authorized by Justice or it will be void. If there is an unauthorized post-referral abatement, it is considered void and can be reversed. The original assessment would remain valid.

2. For this purpose, a referral to Justice is considered to be in effect with respect to any tax liability once a letter from the Service is sent to Justice requesting the institution of a civil action to collect or recover taxes and providing the authorization required under section 7401, or requesting Justice to defend the Service in a suit brought against the Service.

3. A referral to Justice terminates when Justice notifies the Service in writing that it is declining to file suit or otherwise terminates a suit and releases jurisdiction of the referred tax liabilities to the Service. In cases in which Justice has obtained a judgment for the tax liabilities, authority thereafter remains with Justice, even if it returns the case to the Service for collection.

4. Following the discovery of an unauthorized post-referral abatement, Counsel, in consultation with Justice, should work with Service personnel to determine the circumstances of the abatement and, if necessary, to correct the Service’s systems to reflect the unabated assessment. If the issue of the validity of the assessment comes up in litigation, Counsel should defend the assessment on the grounds stated above. Reversing the abatement may also require the Service to revoke any corresponding release of the federal tax lien and, if necessary, file a new notice of federal tax lien. Pursuant to Treas. Reg. § 6323(g)-1(a)(3)(i), a release of lien shall not alter or impair the rights of the United States to property that is the subject of a judicial proceeding commenced prior to the release of lien, at least with respect to the parties to the litigation.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part34/irm_34-008-002#addtoany "Show all")

A2A