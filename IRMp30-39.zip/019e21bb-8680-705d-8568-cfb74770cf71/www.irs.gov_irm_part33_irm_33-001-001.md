---
url: "https://www.irs.gov/irm/part33/irm_33-001-001"
title: "33.1.1 Roles and Responsibilities for Providing Legal Advice | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part33/irm_33-001-001#main-content)

- 33.1.1 [Roles and Responsibilities for Providing Legal Advice](https://www.irs.gov/irm/part33/irm_33-001-001#idm140642418039568)
  - 33.1.1.1 [Legal Advice in General](https://www.irs.gov/irm/part33/irm_33-001-001#idm140642418039184)
  - 33.1.1.2 [Role of Field Counsel in Providing Legal Advice](https://www.irs.gov/irm/part33/irm_33-001-001#idm140642418007872)
  - 33.1.1.3 [Role of Associate Chief Counsel in Providing Legal Advice](https://www.irs.gov/irm/part33/irm_33-001-001#idm140642417991440)
  - Exhibit 33.1.1-1 [Field Advice Reviewed by the Associate Office Response Form](https://www.irs.gov/irm/part33/irm_33-001-001#idm140642418001504)

# Part 33. Legal Advice

# Chapter 1. Legal Advice

# Section 1. Roles and Responsibilities for Providing Legal Advice

* * *

## 33.1.1 Roles and Responsibilities for Providing Legal Advice

**33.1.1.1** **(08-11-2004)**

### Legal Advice in General

1. Chief Counsel is the legal advisor to the Commissioner of Internal Revenue and the Service’s officers and employees on all matters pertaining to the interpretation, administration, and enforcement of the internal revenue laws and related statutes.

2. Each component of the Office of Chief Counsel, individually and collectively, must ensure that the legal advice it renders accurately reflects the position of the Office. As discussed in that section, each Chief Counsel attorney should ensure that legal advice rendered reflects a uniform application of the tax laws and a fair disposition of the matter at hand. Legal advice should be based upon a thorough development of the facts and issues, and, where there is any doubt regarding the position of the Service, advice must be sought from the office or offices responsible for developing and maintaining the Service’s position on the proper interpretation of the matter at issue. Judgment should also be exercised in determining the type of legal advice that should be provided in order to resolve a question, as well as whether the issues presented would be better resolved through the issuance of published guidance, either in addition to the legal advice or instead of the issuing legal advice. The specific procedures that govern these responsibilities are set out in this chapter.

3. Chief Counsel attorneys provide legal advice in a number of contexts to the Service and other Counsel offices. The process of rendering legal advice should be conducted as effectively and efficiently as possible. Many requests for legal advice may be received informally either through email or by telephone, and in cases where the subject matter concerns relatively routine and simple concepts, an informal response will be sufficient. Where the question posed is more complex, or where the exercise of good judgment would dictate otherwise, an inquiry may be more appropriately handled with a formal written response. When a decision is made to give written advice, attorneys and managers should exercise judgment in tailoring the response to the requestor’s needs and the context in which the question is posed.


**33.1.1.2** **(08-11-2004)**

### Role of Field Counsel in Providing Legal Advice

1. Division Counsel are responsible for providing legal advice relating to case development and other matters to their respective client organizations consistent with the Service’s position. See generally CCDM 31.1.1.2, Roles within the Office of Chief Counsel. Requests for advice may arise with respect to docketed and nondocketed cases, see, e.g., IRM 4.8.8.13.2, Agreed Transferee Liability and IRM 8.14.1.8, Appeals Request for Legal Opinion, or Service programs. Requests for legal advice may come from any number of sources including the components of the Service for which the specific office is the legal advisor, such as the Division Commissioners, Appeals, IRS Campuses, and the Taxpayer Advocate, or from taxpayers or organizations outside of the Service, such as Congress.

2. Field Counsel renders advice directly to client organizations without consultation with the Associate offices with respect to matters where the advice consists of issues that can be resolved with a high degree of certainty by the application of settled principles of law or law consistent with the Service’s position to the facts. This kind of advice may include advice to revenue agents, revenue officers, appeals officers, IRS Campuses, and the Taxpayer Advocate Service. Each Division Counsel will set out in local procedures the extent to which such advice can be rendered by the Associate Area Counsel or must be approved by Area or Division Counsel.

3. With respect to matters where the law or the Service’s position is unclear, or when the law is being applied in a setting that is significantly different from the context in which it was developed, Field Counsel must coordinate with the Associate Chief Counsel having subject matter jurisdiction over the issue before rendering the requested legal advice. Any doubts about whether an issue should be coordinated should be resolved in favor of coordination.

4. Legal advice discussing certain novel and significant issues requires closer coordination with the Associate offices. Novel and significant issues include issues relating to recently enacted legislation, issues of first impression, and issues relating to the validity of a regulation or revenue ruling. In addition, many emerging issues will present questions of first impression that should be coordinated. In general, the Associate office with subject matter jurisdiction over the issue involved in the legal advice should be consulted prior to issuing advice on any of the issues designated for pre-review. See Exhibit 31.1.1-1 and Exhibit 35.11.1-1.

5. Requests for legal advice that must be coordinated with the Associate offices include any legal advice that is material to any aspect of the tax administration functions of any Service Campus, or any related IRS activities, that is expected to guide the application of the tax laws or administrative procedures in national programs, or in any significant number of cases. This coordination should occur as early in the process as practicable and should continue, as appropriate, through case development, litigation, and resolution.

6. Attorneys in the Criminal Tax function are responsible for providing legal advice to all components of Criminal Investigation. For such matters, attorneys should also consult CCDM Part 38 Criminal Tax.


**33.1.1.3** **(08-11-2004)**

### Role of Associate Chief Counsel in Providing Legal Advice

1. Associate Chief Counsel are responsible for providing legal advice on novel and significant issues within their subject matter jurisdiction.

2. Associate Chief Counsel also provide legal advice on program issues, proposed policies, or procedures to the Operating Divisions or other components of the Service other Associate offices, and Division Counsel. In general, this advice is not case specific, but is generally focused on a specific problem or issue. The Associate Chief Counsel, after appropriate coordination with the affected Division Counsel, issues this advice.

3. Associate Chief Counsel assist Field Counsel in providing legal advice in taxpayer specific matters. Requests for case specific advice directed initially to an Associate office should be discussed with Field Counsel to determine which office would be best situated to handle the advice. This may include providing advice in connection with docketed or nondocketed cases.

4. Requests for legal advice on nontax legal matters within its jurisdiction should be referred by Field Counsel to the Associate Chief Counsel (GLS). General Legal Services is responsible for the policies and programs of the Office of Chief Counsel with respect to a broad range of nontax legal work for the agency, including:



1. Labor-management relations;

2. Public contract formation and administration;

3. Damage suits against the United States or officers or employees of the United States under the Federal Torts Claims Act, the Federal Claims Collection Act, the Debt Collection Act, and the Military and Civilian Employees’ Claims Act;

4. Certain conflict of interest and other ethics statutes in coordination with the Office of the Associate Chief Counsel (P&A); and

5. General government and legal management.



      ### Note:



      The specific matters handled by GLS are described in CCDM 30.3.2.5.4.1, Associate Chief Counsel (General Legal Services).


**Exhibit 33.1.1-1** **(08-11-2004)**

### Field Advice Reviewed by the Associate Office Response Form

![This is an Image: 39430001.gif](https://www.irs.gov/pub/xml_bc/39430001.gif)

There is currently no description available for this image. For help with this image, please call the IRS.gov Helpdesk at 1-800-876-1715.

[Please click here for the text description of the image.](https://www.irs.gov/media/157686 "")

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part33/irm_33-001-001#addtoany "Show all")

A2A