---
url: "https://www.irs.gov/irm/part33/irm_33-002-002"
title: "33.2.2 Requests for Technical Advice and Technical Expedited Advice | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part33/irm_33-002-002#main-content)

- 33.2.2 [Requests for Technical Advice and Technical Expedited Advice](https://www.irs.gov/irm/part33/irm_33-002-002#idm140642372253200)
  - 33.2.2.1 [Requesting Technical Advice or Technical Expedited Advice](https://www.irs.gov/irm/part33/irm_33-002-002#idm140642363625296)
    - 33.2.2.1.1 [Pre-Submission Conferences](https://www.irs.gov/irm/part33/irm_33-002-002#idm140642383626304)
    - 33.2.2.1.2 [Procedures for Requesting Technical Advice or Technical Expedited Advice](https://www.irs.gov/irm/part33/irm_33-002-002#idm140642375023664)
  - 33.2.2.2 [Processing Requests for Technical Advice and Technical Expedited Advice](https://www.irs.gov/irm/part33/irm_33-002-002#idm140642375013232)
    - 33.2.2.2.1 [Upon Receipt in a Branch](https://www.irs.gov/irm/part33/irm_33-002-002#idm140642390167120)
    - 33.2.2.2.2 [Preliminary Examination](https://www.irs.gov/irm/part33/irm_33-002-002#idm140642395138560)
    - 33.2.2.2.3 [Analysis](https://www.irs.gov/irm/part33/irm_33-002-002#idm140642371872400)
    - 33.2.2.2.4 [Conferences](https://www.irs.gov/irm/part33/irm_33-002-002#idm140642394819216)
    - 33.2.2.2.5 [Withdrawal of Requests](https://www.irs.gov/irm/part33/irm_33-002-002#idm140642394293280)
    - 33.2.2.2.6 [Preparation of Technical Advice Memorandum or Technical Expedited Advice and Transmittal Memorandum](https://www.irs.gov/irm/part33/irm_33-002-002#idm140642386665616)
      - 33.2.2.2.6.1 [Generating Technical Advice Memorandum or Technical Expedited Advice Memorandum](https://www.irs.gov/irm/part33/irm_33-002-002#idm140642393824336)
      - 33.2.2.2.6.2 [Preparation of Form M-6000 Transmittal Memorandum](https://www.irs.gov/irm/part33/irm_33-002-002#idm140642386617568)
  - 33.2.2.3 [Using the Technical Advice or the Technical Expedited Advice](https://www.irs.gov/irm/part33/irm_33-002-002#idm140642363603232)
  - 33.2.2.4 [Denying Taxpayers Request for Technical Advice or Technical Expedited Advice](https://www.irs.gov/irm/part33/irm_33-002-002#idm140642392601888)
  - 33.2.2.5 [Procedure for Requesting Application of Section 7805(b) in the Case of Technical Advice](https://www.irs.gov/irm/part33/irm_33-002-002#idm140642394605328)

# Part 33. Legal Advice

# Chapter 2. Technical Advice and Technical Expedited Advice

# Section 2. Requests for Technical Advice and Technical Expedited Advice

* * *

## 33.2.2 Requests for Technical Advice and Technical Expedited Advice

**33.2.2.1** **(08-11-2004)**

### Requesting Technical Advice or Technical Expedited Advice

1. This section establishes procedures for requesting technical advice and technical expedited advice and processing such requests.

2. It is the responsibility of the examining office or the Appeals office to determine whether technical advice or technical expedited advice should be requested on any issue before that office.

3. Taxpayers may initiate requests for technical advice or technical expedited advice in accordance with the following:



1. During the course of an examination or a conference in Appeals, a taxpayer may request that an issue be referred to an Associate office for technical advice or technical expedited advice on the grounds that a lack of uniformity exists as to the disposition of the issue, or that the issue is so unusual or complex as to warrant consideration by the Associate office.

2. While taxpayers are encouraged to make written requests setting forth the facts, law, and arguments with respect to the issue, and reasons for requesting advice from an Associate Chief Counsel office, a taxpayer may make the request orally to the examining agent or the appeals officer.


**33.2.2.1.1** **(08-11-2004)**

#### Pre-Submission Conferences

1. In an effort to promote expeditious processing of a request for advice, the Associate’s office must confer with the examination or appeals office and field counsel (and in some cases the taxpayer) prior to the time a request for advice is submitted to the Associate office. Pre-submission conferences are mandatory in all cases. If a request for technical advice or technical expedited advice is submitted without holding a pre-submission conference, the request for advice will be rejected by the Associate office. Generally, if a technical expedited advice memorandum will be requested, the taxpayer must participate in the pre-submission conference. (See CCDM 33.2.2.1.2(1) for exceptions when taxpayer participation in the technical expedited advice process is not required). A request for a pre-submission conference should be made only after the examination or Appeals office determines that it likely will request advice. If the request for advice will include issues requiring the involvement of more than one Associate office, representatives from each Associate office involved must participate in the pre-submission conference.

2. A pre-submission conference is intended to facilitate agreement between the parties as to the appropriate scope of the request for advice, the factual information and documents to be included in the request, any collateral issues that either should or should not be included in the request, and any other substantive or procedural considerations that will allow the Associate office to provide the parties with technical advice as expeditiously as possible.

3. The examination or appeals office must work with field counsel to submit a written request for a pre-submission conference and identify the Associate office expected to have jurisdiction over the request. The request may be transmitted by the assigned field counsel office to the Technical Services Support Branch shared email box TSS4510 or faxed to TSS4510 at (202) 622–4817. The Associate office will confirm receipt of the fax within one working day after receipt.

4. Field counsel should open a TAM-P pre-submission assignment in TECHMIS as it works to develop pre-submission materials, but the request for a pre-submission conference should be submitted shortly thereafter; a TAM-P assignment will not be allowed to remain open indefinitely in TECHMIS.

5. The assigned Associate office attorney will contact the field to schedule the pre-submission conference as follows:



1. **Technical expedited advice** – The attorney will telephone the field office, as well as field counsel, within two working days after receiving the request for a pre-submission conference; the conference must be held within 15 calendar days of the telephone call. The field office must coordinate with the taxpayer and any other Service personnel that the field office believes should be involved in the conference. All materials for the conference must be received by the Associate office at least five calendar days before the conference. Failure to timely submit materials will result in the case being processed as a request for technical advice rather than technical expedited advice.

2. **Technical advice** — The attorney will telephone the field office, as well as field counsel, within five working days after receiving the request for a pre-submission conference; the conference must be held within 30 calendar days of the telephone call. The field office must coordinate with the taxpayer and any other Service personnel that the field office believes should be involved in the conference. All materials for the conference must be received by the Associate office at least ten working days before the conference.


6. When submitting materials for the pre-submission conference:



1. Submit electronically whenever possible

2. Field counsel, rather than the field office, should submit materials electronically to protect taxpayer information

3. If materials are not available in electronic form, send by fax, express mail, or private delivery service as follows:


       Internal Revenue Service


       CC:PA:LPD:TSS, Room 5329


       1111 Constitution Avenue, N.W.


       Washington, D.C. 20224


7. During the pre-submission conference, the parties should determine whether the issue(s) are appropriate for a technical expedited advice memorandum rather than a technical advice memorandum. The parties should discuss the framing of the issue(s), what background information and documents are required and when the request for advice will be submitted to the Associate office. The parties should discuss whether the issue is what that can be resolved via the technical advice process or whether it is one that may encounter significant delay in resolution.

8. If an Appeals office submits the request for a pre-submission conference, field counsel work assignments will be subject to the _ex parte_ rules set forth in section 1001(a)(4) of the Internal Revenue Service Restructuring and Reform Act of 1998, Pub. L. No. 105-206, and Rev. Proc. 2000-43, 2000-2 C.B. 404.

9. Pre-submission conferences will generally be held by telephone, unless the parties request otherwise.


**33.2.2.1.2** **(08-11-2004)**

#### Procedures for Requesting Technical Advice or Technical Expedited Advice

1. The taxpayer is advised that technical advice or technical expedited advice is being requested, except in the instance in paragraph (7), below. For a request for technical expedited advice, the taxpayer must generally agree that the expedited procedures are appropriate; lack of agreement among the parties will result in the request being treated as a request for technical advice. The only two exceptions where taxpayer agreement is not required for a technical expedited advice memorandum are:



   - A request in which the Associate office considers whether a letter ruling should be revoked or modified because the field or area office determined that the controlling facts on which the ruling was based are materially different

   - A request that involves, as described in IRC § 6110(g)(5)(A), a matter that is the subject of, or is otherwise closely related to, a criminal or civil fraud investigation, or a jeopardy or termination assessment


2. Every effort should be made to reach agreement as to the facts and the specific points at issue before submitting the request for a technical advice memorandum or a technical expedited advice memorandum to the Associate office. Note, however, that the Associate office is not bound by the precise statement of the issue as stated by the taxpayer or exam or Appeals. See also CCDM 33.2.2.4.6.1.



1. If the Service initiates the request for technical advice or technical expedited advice, the taxpayer will be given ten calendar days, after receipt of the statement of facts and specific questions from examination or Appeals, to indicate in writing the extent, if any, to which the taxpayer may not be in complete agreement. An extension of time beyond the ten calendar days must be justified by the taxpayer in writing and approved by the Territory Manager or the Appeals area director. If agreement cannot be reached, the taxpayer may submit, within ten calendar days after receipt of notice from the Service, a statement of the taxpayer’s understanding as to the specific point or points at issue that will be forwarded to the Associate office with the request for technical advice or technical expedited advice. An extension of time beyond the ten calendar days must be justified by the taxpayer in writing and approved by the Territory Manager or the Appeals area director.

2. If a taxpayer initiates the action to request technical advice or technical expedited advice, and the taxpayer’s statement of the facts and point or points at issue are not wholly acceptable to examination or Appeals, the taxpayer will be advised in writing of the areas of disagreement. The taxpayer will be given ten calendar days after receipt of the written notice to reply to the notice. An extension of time beyond the ten calendar days must be justified by the taxpayer in writing and approved by the Territory Manager or the Appeals area director.


3. If agreement cannot be reached, both the statements of the taxpayer and the examination or Appeals will be forwarded to the Associate office with the request for technical advice or technical expedited advice. The taxpayer’s set of facts must include a penalties of perjury statement. When the disagreement involves material facts essential to the preliminary assessment of the case, examination or Appeals may refuse to refer a taxpayer initiated request for technical advice or technical expedited advice. Similarly, when examination or Appeals and the taxpayer cannot agree on material facts, the Associate office, at its discretion, may refuse to provide technical advice or technical expedited advice. Alternatively, if the Associate office chooses to issue technical advice or technical expedited advice and the Associate office would rule the same way on either set of facts, the technical advice or the technical expedited advice will be issued and will note the factual dispute is immaterial. If the Associate office would rule differently based on which specific set of facts is considered, the technical advice or the technical expedited advice will be issued describing the resolution based on each set of facts. If, however, the technical advice or the technical expedited advice provides alternative responses based on separate sets of facts, the field is required to process the case consistently with the legal analysis in the advice as applied to the facts as they are ultimately determined by the field office.

4. If the taxpayer has not already done so, the taxpayer may submit a statement explaining the taxpayer’s position on the issues and citing precedents that the taxpayer believes will bear on the case. This statement will be forwarded to the Associate office with the request for technical advice or technical expedited advice. If the taxpayer’s statement is received after the request for technical advice or technical expedited advice has been forwarded to the Associate office, it will be forwarded to the Associate office for association with the request for advice. If the taxpayer is aware of any legislation, tax treaties, regulations, revenue rulings, revenue procedures, or court decisions contrary to the taxpayer’s position, they should be commented upon.

5. At the time the taxpayer is informed that the matter is being referred to the Associate office, the taxpayer will also be informed of the right to a conference in the Associate office in the event an adverse decision is indicated, and will be asked to indicate whether such a conference is desired.

6. Form 4463, Request for Technical Advice or Technical Expedited Advice, must be used to request advice and to transmit the various statements relating thereto to the Associate office. Field counsel must submit Form 4463 (and accompanying documents if available in electronic form) for a technical advice or technical expedited request to the "TSS4510" mailbox and must use normal sensitivity. All email requests must be sent through a Field counsel office to provide firewall protection to taxpayer information. If it is not feasible to send the entire submission via email, field counsel should send the supporting documents that are not available in electronic form by fax, express mail, or private delivery service as follows:


    Internal Revenue Service


    CC:PA:LPD:TSS, Room 5329


    1111 Constitution Avenue, N.W.


    Washington, D.C. 20224

7. A taxpayer will not be advised when a request for technical advice or technical expedited advice is submitted to the Associate office or advised of conference rights when that information would be prejudicial to the Government’s interests (as, for example, in cases involving criminal or civil fraud investigations or jeopardy or termination assessments).

8. When a request for technical advice or technical expedited advice is based on the proposed revocation of an exemption ruling or determination letter, a notice of the proposed revocation will be considered notice to the taxpayer that technical advice or technical expedited advice will be requested from the Associate office.


**33.2.2.2** **(08-11-2004)**

### Processing Requests for Technical Advice and Technical Expedited Advice

1. When a request for a technical advice memorandum or a technical expedited advice memorandum is received by The Technical Services Support Branch, Legal Processing Division Procedure & Administration but no pre-submission conference was held, the request for advice will be returned to the requesting party.

2. Procedures as to the control and referral of mail to the Associate having subject matter jurisdiction are set forth in CCDM 30.3.2.3.8.5.1. The Technical Services Support Branch, Legal Processing Division (Procedure & Administration) sends the requesting office a Form M-6117, Acknowledgement Form, acknowledging the receipt of requests for technical advice on behalf of the appropriate Associate office.

3. Form M-3514 (Publication and Case File Classification Recommendations) is completed in accordance with the provisions of CCDM 32.3.


**33.2.2.2.1** **(08-11-2004)**

#### Upon Receipt in a Branch

1. Upon receipt in a Branch, a request for technical advice or technical expedited advice is processed and assigned as follows: within one working day after receipt in the Branch, each request for technical advice or technical expedited advice is referred to the assignment officer, i.e., the Branch Chief, Senior Technician Reviewer, or Assistant to the Branch Chief (or Assistant Branch Chief) who assigns the requests to an Associate office attorney.

2. The assignment officer ensures that Form M-4114 (Case History) is attached to each request and completed in accordance with the provisions of CCDM 30.9.2, Guidelines for Specific Categories of Case Files.

3. Within two workdays after receipt in the Branch, the request for technical advice or technical expedited advice is assigned to an Associate office attorney who analyzes the file to see that it meets all the requirements for requesting technical advice or technical expedited advice. If the request does not comply with CCDM 33.2.1.10.2, Section 6110 Procedures Applicable to Issuing Technical Advice and Technical Expedited Advice Issuance, relating to the statement of proposed deletions, the Associate office will make the deletions from the technical advice memorandum or the technical expedited advice memorandum required by IRC § 6110(c).

4. The principal Associate Chief Counsel attorney assigned to the technical advice will prepare a work plan that sets forth a time table explaining when and how the technical advice will be completed. In so doing, the attorney should consult with the examining agent or appeals officer who submitted the technical advice request, attorneys from other Associate Chief Counsel offices who will likely assist in drafting the technical advice, and the field counsel attorney assigned to the technical advice request. The parties should agree to the work plan within five business days after the technical advice request is submitted. Proposed departures from the time table are subject to review by the Associate Chief Counsel office’s responsible official.

5. Each request for technical advice or technical expedited advice is monitored closely at each level of consideration and review to avoid unnecessary delays.

6. For any technical advice expected to be pending over 120 days during each month, the principal Associate Chief Counsel attorney assigned to the technical advice must provide a status update by email within the first five calendar days of the month to the examining agent or appeals officer, including an explanation for any delay, the steps being taken to overcome the delay, and the estimated completion date. The email will also be sent to the field counsel attorney assigned to the technical advice request, the Associate Chief Counsel office’s responsible official, the Division Counsel Headquarters technical advice contact, and TSS4510.


**33.2.2.2.2** **(08-11-2004)**

#### Preliminary Examination

1. Within five calendar days after the Branch office receives the request for technical advice or technical expedited advice, a representative of the Branch telephones the requesting office and field counsel to confirm the receipt of the request for advice and to discuss the procedural and substantive issues in the request that come within the Branch’s jurisdiction. The Associate office attorney gives his or her name and office telephone number for future reference and then informs the requesting office that:



1. The case is being returned because substantial additional information is required to resolve an issue, because significant unresolved factual variances exist between the statement of facts submitted by the requesting office and the taxpayer, or because major procedural problems cannot be resolved by telephone.



      ### Note:



      A request for technical advice will not be returned or reply delayed merely because additional information not essential to the preliminary assessment of the case is needed.

2. The case is not being returned but more information is needed or minor procedural deficiencies exist; or

3. The case does not come within the purview of CCDM 33.2 and the taxpayer should be informed.


2. The Associate office attorney should prepare a memorandum of the communication for the file showing the:



   - Date of the call

   - Name of the person spoken to in the requesting office

   - Reason for the call

   - Information received during the conversation

   - Nature of any additional information that is to be submitted


3. When additional information is obtained through email, copies of the email correspondence should be placed in the file.

4. If the case contains an original return filed by the taxpayer, the return should be examined and pertinent portions necessary to the determination should be copied and retained. The original return should be returned immediately to the requesting office and the file noted with respect to the date on which the statutory period of limitations will expire.

5. When the technical advice or technical expedited advice request involves matters within the jurisdiction of more than one Branch or Associate office, a representative of the Branch that received the original technical advice or technical expedited advice request will inform the requesting office at the time of the initial contact described in CCDM 33.2.2.2.2(1) that:



1. The matters within the jurisdiction of another Branch or another Associate office have been referred to that Branch or Office for consideration; and

2. A representative of the Branch will contact the requesting office within five calendar days of the receipt by that Branch of the referral of the technical advice or technical expedited advice request to discuss it as provided in CCDM 33.2.2.2.2(1).


6. The assigned Associate office attorney and reviewer should evaluate the issue in a technical advice or technical expedited advice request to determine whether published guidance is appropriate. For each case, the attorney and reviewer must forward a memorandum to the Associate Chief Counsel discussing whether published guidance is appropriate on the issues in the technical advice. See CCDM 33.2.1.5, Deferral of Technical Advice Memorandum or Technical Expedited Advice Memorandum Pending Publication of a Revenue Ruling, for guidelines in determining the need for general guidance.


**33.2.2.2.3** **(08-11-2004)**

#### Analysis

1. The Associate office attorney to whom the case is assigned analyzes the case thoroughly and performs the research necessary to reach a tentative conclusion. Research should be sufficiently thorough and extensive to assure that the holding is well-reasoned and supportable by the law, regulations, court decisions, or prior published precedents. In accordance with the Statement of Principles of Internal Revenue Tax Administration, it is the representative’s responsibility to try to find the true meaning of the statutory provision and not to reach a strained construction in the belief that he or she is protecting the revenue.

2. If during analysis and development of the case additional information is necessary, the Associate office attorney obtains it in the most expeditious manner from the taxpayer, or the agents or Appeals officer assigned to the case. In the interest of promptness, the telephone should be used whenever appropriate; however, when material facts are provided orally by the taxpayer, written confirmation should be requested, along with a penalty of perjury statement. A record of the substance of every telephone conversation is placed in the file.

3. When a taxpayer is requested to submit additional information in writing, it should be submitted to the Associate office. Also, the taxpayer must send a copy to the requesting office for prompt attention and must call the Associate office attorney or reviewer assigned to the case if there are no comments. If the requesting office has not called or furnished comments within 15 calendar days, the Associate office attorney or reviewer assigned to the case should contact them to determine the status of the comments on the additional facts and data.

4. If a taxpayer was not advised of a request for technical advice or technical expedited advice, as provided in CCDM 33.2.2.1.2(7), the taxpayer should not be contacted. Any additional information is obtained from the requesting office.

5. If contrary authority is not furnished with the request for technical advice or technical expedited advice and there is no accompanying statement that none exists, the Service in complex cases or those presenting difficult or novel issues may request submission of contrary authorities or a statement that none exist.

6. Once the taxpayer provides all additional information requested, the Associate office attorney informs the field or area office within 21 calendar days after receiving the information for a technical advice memorandum and within five calendar days for a technical expedited advice memorandum:



1. What the Associate office attorney’s tentative conclusion is and the estimated date that the technical advice memorandum will be mailed; or

2. That a tentative conclusion has not been reached because of the complexity of the issue and the estimated date that the tentative conclusion will be made.


7. Because the Associate office attorney’s tentative conclusion may change during the preparation and levels of review of the technical advice memorandum or the technical expedited advice memorandum, it is not, under any circumstances, considered final. The requesting office may not tell the taxpayer what the tentative conclusion is.


**33.2.2.2.4** **(08-11-2004)**

#### Conferences

01. When technical advice or technical expedited advice adverse to a taxpayer is proposed and a conference has been requested, the taxpayer will be notified, by telephone if possible, of the time and place of the conference. A taxpayer is entitled by right to only one conference in the Associate office. For situations when more than one conference may be held, see paragraph (13) following.

02. **Technical expedited advice** — Within 20 calendar days after receiving a request for advice, the Associate office attorney and reviewer will offer a taxpayer a conference, which will be held within ten calendar days of the date of the offer for the conference. A taxpayer cannot request an extension of this ten-day period.

03. **Technical advice** — The conference must be held within 21 calendar days after the Associate office attorney and reviewer notify a taxpayer that an adverse technical advice memorandum is proposed. An extension of the 21-day period will be granted only if justified in writing by the taxpayer and approved by the Associate Chief Counsel. Requests for extensions should be justified by compelling facts and circumstances. The request for extension should be submitted before the end of the 21-day period. If unusual circumstances near the end of the 21-day period make a written request impractical, the Associate office should be told orally within the 21-day period about the problem and of the forthcoming written request for extension. These written requests must be promptly submitted. The Associate Chief Counsel (or delegate) will promptly notify the taxpayer by telephone and later in writing of the approval or denial of the requested extension. There is no right to appeal the denial of an extension request. If the Associate office is not advised of problems with meeting the 21-day period, or if the request is not sent promptly after the Associate office is notified of problems with meeting the 21-day period, the Service will process the case on the assumption that no further submission will be received.

04. In the event of a tentatively adverse determination, the Associate office attorneys may offer a taxpayer the option of delaying the conference so that the taxpayer can prepare and submit a brief requesting relief under IRC § 7805(b). In these cases, the Service will schedule a conference on the tentatively adverse decision and the section 7805(b) relief request within ten calendar days of receiving the taxpayer’s section 7805(b) request.

05. If conferences are being arranged for more than one request for technical advice or technical expedited advice for the same taxpayer, the conferences will be scheduled to cause the least inconvenience to the taxpayer.

06. Conferences usually are held at the Branch level. They usually are attended by a person who has authority to sign the name of the Branch Chief on the transmittal memorandum. When more than one Branch has taken an adverse position on an issue within its jurisdiction, or when the position ultimately adopted by one Branch will affect another Branch’s determination, a representative from each Branch with authority to sign for the Branch Chief will attend the conference. The Associate office determines the Branch personnel who will attend the conference. That office is responsible for compliance with the Conference and Practice Requirements by taxpayers’ representatives. The Associate office will notify the Examining agent or the Appeals Officer of the scheduled conference. The Examining agent or the Appeals Officer may ask or be requested to attend the conference. The Operating Division or Appeals may designate other Service representatives to attend the conference in lieu of, or in addition to, the Examining agent or the Appeals Officer.

07. If more than one subject is discussed at the conference, the discussion constitutes a conference for each subject.

08. To have a thorough and informed discussion of the issues, the conference usually is held after the Branch has had an opportunity to study the case; however, the taxpayer may request that the conference of right be held earlier in the consideration of the case than the Service would ordinarily designate. The taxpayer has no right to appeal the action of a Branch to an Associate Chief Counsel or to any other official of the Service. But see paragraph (15) below for situations in which the Service may offer additional conferences.

09. Conference procedures are informal. The senior Service representative controls the form and structure of the conference. That representative sees that the taxpayer has full opportunity to present the taxpayer’s views on all of the issues in question and that the taxpayer understands, as far as possible, the nature of the Service’s tentative holding and the reasons for such holding. The requesting office should be told the tentative conclusion before the taxpayer is told. The taxpayer should be told the tentative conclusion only when scheduling the adverse conference, at the adverse conference, or in any discussion between the scheduling and commencement of the adverse conference; however, all discussions with the taxpayer should be undertaken with the understanding that if the final technical advice memorandum or technical expedited advice memorandum issued to the taxpayer is adverse, it may lead to litigation. Therefore, discussions by Service representatives should be limited to what is necessary to process the case properly and efficiently. If prospective application under IRC § 7805(b) is advanced by the taxpayer, the Service representative will discuss the tentative recommendation with respect to such relief and the reason for such tentative recommendation. In exploring the conflicting arguments, no commitment is made as to the holding that the Service finally will adopt.

10. It is the responsibility of the taxpayer to furnish in writing to the Associate office after the conference any additional data, lines of reasoning, precedents, etc., that the taxpayer proposed and discussed at the conference but did not previously or adequately present in writing. The senior representative from the Associate office should be certain that there is a clear understanding by the taxpayer as to the nature of any further factual material or written statements to be submitted and that they must be submitted timely, along with a penalties of perjury statement.

11. For a technical advice memorandum, any additional information must be submitted within 21 calendar days after the conference. An extension of the 21-day period will be granted only if justified in writing by the taxpayer and approved by the Associate Chief Counsel. Although taxpayer participation during all stages of the process is preferred, it is not required for a technical advice request. If, however, the taxpayer had not participated in the steps of the process leading up to the adverse conference, the taxpayer is not permitted to submit additional data, lines of reasoning, precedents, etc. after the conference.

12. For a technical expedited advice memorandum, any additional information must be submitted within 15 calendar days after the conference. No extension of the 15-day period is allowed.

13. Any additional material should be submitted to the Associate office for the attention of the Associate office attorney or reviewer assigned to the case. The taxpayer must also send a copy to the requesting office for comment. The requesting office must provide a copy to the field counsel involved in the case. The requesting office should give the matter prompt attention and call the Associate office attorney or reviewer assigned to the case if there are no comments. If the requesting office has not called or furnished comments within 15 calendar days, the Associate office attorney or reviewer assigned to the case should call the requesting office contact to determine the status of the comments on the additional facts and data.

14. Once the conference of right for a technical expedited advice memorandum is held, no additional conferences will be offered. The Service will, however, offer a taxpayer an additional conference under the following situations:



    1. An additional conference will be offered if, after the conference of right, an adverse holding is proposed but on a new issue or on the same issue but on different grounds from those discussed at the first conference. There is no right to another conference when a proposed holding is reversed at a higher level with a result less favorable to the taxpayer, if the grounds or arguments on which the reversal is based were discussed at the conference of right.

    2. The limit on the number of conferences to which a taxpayer is entitled does not prevent the Service from offering additional conferences, including conferences with an official higher than the Branch level, if the Associate office decides they are needed. These conferences are not offered as a matter of course simply because the Branch has reached an adverse decision. In general, conferences with higher level officials are offered only if the Associate office determines that the case presents significant issues of tax policy or tax administration and that the consideration of these issues would be enhanced by additional conferences with the taxpayer. A taxpayer seeking an additional conference should generally be asked to submit the request in writing; however, a request by telephone may be acceptable if there are unusual or exigent circumstances. A request for an additional conference should state the reasons the taxpayer believes the case presents significant issues of tax policy or tax administration and should explain why an additional conference would enhance consideration of the issues in dispute. A written request should be addressed to the Branch handling the case and a copy sent to the Associate Chief Counsel with supervisory responsibility for that Branch.



       ### Note:



       All additional conferences of the type discussed in this paragraph are held only at the invitation of the Service.


15. The conference of right will be held by telephone unless the taxpayer or the field requests an in-person conference. If a taxpayer or the field makes this request, the Associate office reviewer will decide if it is appropriate in the particular case to hold the conference of right in person. The taxpayer will be advised when to call the Service representatives (this is not a toll-free call). The Examining agent or the Appeals Officer, as well as field counsel, will be offered the opportunity to participate in the conference. Also, other Service representatives are allowed to participate in the conference. See CCDM 33.2.2.2.4(6).

16. After each conference, the Associate office attorney prepares a conference report . After approval by the case reviewer attending the conference, the original of the report is associated with the case file and copies are distributed to Service personnel who attended.

17. Because conference procedures are informal, no tape, stenographic, or other verbatim recording of a conference may be made by any party.

18. In all cases, the Associate office attorney will inform the Examining agent or the Appeals Officer of the Associate Chief Counsel’s final conclusion(s). Before the technical advice memorandum or the technical expedited advice memorandum is issued, the Examining agent or the Appeals Officer will be offered the opportunity to discuss the issue(s) and the Associate Chief Counsel’s final conclusion(s), whether by telephone or at a conference, whichever the Examining agent or the Appeals Officer prefers.


**33.2.2.2.5** **(08-11-2004)**

#### Withdrawal of Requests

1. The requesting office may withdraw a request for technical advice or technical expedited advice at any time before the responding transmittal memorandum is signed. The requesting office must notify the taxpayer in writing of the intent to withdraw the request for technical advice or technical expedited advice except when:



1. The period of limitations on assessment is about to expire and the taxpayer has declined to sign a consent to extend the period; or

2. Such notification would be prejudicial to the best interests of the government.


2. If the taxpayer does not agree that the request for technical advice or technical expedited advice should be withdrawn, the procedures in CCDM 33.2.2.2.3 must be followed.

3. When a request for technical advice or technical expedited advice is withdrawn, the Associate office may send its views to the requesting office when acknowledging the withdrawal request. A memorandum to the requesting office may constitute Chief Counsel Advice that is subject to IRC § 6110. In an Appeals case, acknowledgment of the withdrawal request should be sent to the appropriate Appeals Office, through the Director, Technical Services, C:AP. In appropriate cases, the subject matter may be published as a revenue ruling or revenue procedure.


**33.2.2.2.6** **(08-11-2004)**

#### Preparation of Technical Advice Memorandum or Technical Expedited Advice and Transmittal Memorandum

1. The reply to a request for technical advice or technical expedited advice is prepared in two parts:



1. A technical advice memorandum or a technical expedited advice memorandum; and

2. A transmittal memorandum (Form M-6000).


2. Both memoranda are addressed to the examination office or Appeals office, as appropriate, and identify the taxpayer by name, address, identification number, and year or years involved.

3. The identification of the person preparing the technical advice or technical expedited advice and transmittal memoranda is deleted from copies furnished offices outside of the Associate office.

4. It is the general practice of the Service to furnish copies of the technical advice memorandum or the technical expedited advice memorandum to the taxpayer involved upon request, after they have been adopted by the requesting office; however, where no definitive answer is given to a specific question presented, where the factual submission is such as to indicate that an issue should be decided by the field or area office, where it would not be in the interest of a wise administration of the tax laws, or where a taxpayer was not advised of a request for technical advice or technical expedited advice, a copy of a technical advice memorandum or a technical expedited advice memorandum will not be furnished to the taxpayer. In these situations the technical advice memorandum or the technical expedited advice memorandum contains a statement indicating that a copy of the memorandum will not be made available to the taxpayer. A distribution copy of the reply to a request from the operating divisions should be mailed simultaneously to the field personnel who requested it under the signature authority of the director. Replies to requests from Appeals should be routed to the appropriate area office through the Chief Appeals. The Office of Chief Counsel will send a copy of the reply to the request for technical advice or technical expedited advice to the Division Counsel of the operating division that has jurisdiction of the taxpayer’s tax return.

5. The transmittal memorandum is not made available to the taxpayer or representative.

6. The Office of Chief Counsel will not discuss the contents of the technical advice memorandum or the technical expedited advice memorandum with the taxpayer until the taxpayer has been given a copy of the technical advice memorandum or the technical expedited advice memorandum by the field or area office.


**33.2.2.2.6.1** **(08-11-2004)**

##### Generating Technical Advice Memorandum or Technical Expedited Advice Memorandum

1. Technical advice memoranda and technical expedited advice memoranda are generated by using the macro available under the appropriate word-processing program. The technical advice memorandum or the technical expedited advice memorandum is printed on plain white paper. The name of the individual who prepared the document, and the date, is typed below the last line of the final page of the official file copy (Form 1937A) and any other copies retained in the Branch or in the Associate’s office. Form 1937A is generated by using the macro available under the appropriate word-processing program. The technical advice or the technical expedited advice is addressed to the requesting office.

2. The memorandum will not be signed and will in no manner disclose the degree of consideration or review afforded the case in the Office of Chief Counsel.

3. The format and guidelines for preparing a technical advice memorandum or a technical expedited advice memorandum are shown in the CC Macros. This format may be modified, as appropriate, for cases that involve multiple issues.

4. See CCDM 32.3.2.3.2.2(1) for caveats to be included in technical advice memoranda and technical expedited advice memoranda where temporary or final regulations have been adopted.

5. See CCDM 32.3.2.3.2.2(2) for caveats to be included in technical advice memoranda or technical expedited advice memoranda in cases prior to adoption of temporary or final regulations.

6. The conclusions in a technical advice memorandum or a technical expedited advice memorandum give direct answers, whenever possible, to the specific questions of the Field or Area Office; however, the Office of Chief Counsel is not bound by the framing of the issues submitted by the taxpayer or the Field or Area Office and may reframe the issues to be answered in the technical advice memorandum or the technical expedited advice memorandum. The discussion of the issues is in enough detail so the Field or Area officials will understand the reasoning underlying the conclusion.

7. When technical assistance is necessary from another Associate office, the provisions of CCDM 31.1.4.2.2, Coordination Among Associate Chief Counsel, are followed.

8. See CCDM 33.2.2.5 for procedures to be followed whenever, in connection with the preparation of technical advice memoranda and technical expedited advice memoranda, the question of nonretroactive application under IRC § 7805(b) is considered.


**33.2.2.2.6.2** **(10-28-2010)**

##### Preparation of Form M-6000 Transmittal Memorandum

1. The technical advice or technical expedited advice transmittal memorandum, Form M-6000 (Transmittal Memorandum), is generated by using the macro available under the appropriate word-processing program and is prepared in sufficient numbers to meet distribution requirements and is completed as follows:



1. Enter the appropriate information on the "memorandum for " , "from" , and "subject" lines.

2. Enter a check mark in (1) the first box when transmitting a technical advice memorandum or technical expedited advice memorandum, and (2) the second box when a case is being returned for either of the reasons set forth in CCDM 33.2.2.2.2 (1)(a) or (b).


2. Additional information can be added below the second check-box or on a separate sheet of paper if:



1. In unusual circumstances, the Office of Chief Counsel wishes to provide the requesting office with strategic advice, administrative information, or other information that, need not be discussed with the taxpayer.

2. The case is being returned for either of the reasons set forth in CCDM 33.2.2.2.2(1)(a) or (b). In this event, a brief explanation of the additional information required or the factual variance will be included.


### Note:

If the transmittal memorandum provides more than the fact that the technical advice memorandum or the technical expedited advice memorandum is attached or the case is returned for further development, the transmittal memorandum may constitute Chief Counsel Advice, as defined in IRC § 6110(i)(1), subject to disclosure under section 6110.

3. The memorandum usually is signed by or for the Branch Chief with primary jurisdiction over the issues raised in the technical advice memorandum or the technical expedited advice memorandum.

4. The transmittal memorandum will not contain a reference to whether a taxpayer conference was held in the Office of Chief Counsel, and will not contain a statement that a copy of the technical advice memorandum or the technical expedited advice memorandum is not to be made available to the taxpayer, since this information is contained in the technical advice memorandum or the technical expedited advice memorandum.

5. Checksheet for Processing Technical Advice Memoranda and Technical Expedited Advice Memoranda. A checksheet for processing technical advice memoranda and technical expedited advice memoranda is available on the Office of Chief Counsel intranet atCheck Sheets and Other Resources on the Procedure and Administration page. . This completed checksheet should be forwarded with the technical advice or technical expedited advice, along with the transmittal memorandum. For the most current version of this document, refer to the Office of Chief Counsel Intranet.


**33.2.2.3** **(10-28-2010)**

### Using the Technical Advice or the Technical Expedited Advice

1. Examination or Appeals must process the taxpayer’s case on the basis of the conclusions in the technical advice memorandum or the technical expedited advice memorandum unless:



1. The requesting office thinks that the conclusions reached by the Office of Chief Counsel in a technical advice memorandum or a technical expedited advice memorandum should be reconsidered and requests reconsideration.

2. Appeals, in the case of technical advice or technical expedited advice unfavorable to the taxpayer (except for IRC § 521 cases), decides to settle the issue under existing authority. See CCDM 33.2.1.9(7), Standards for Requesting Advice and Legal Effect of Advice, for treatment of section 521 cases.

3. In the case of technical advice or technical expedited advice unfavorable to a Coordinated Industry Case (formerly Coordinated Examination Program) taxpayer on a coordinated issue within the Office of Pre-Filing and Technical Guidance, Large Business & International (LB&I), on which Appeals has coordinated issue papers containing settlement guidelines or positions, the team manager decides to settle the issue under the settlement authority delegated in Delegation Order No. 4-25 (or its successor).

4. The technical advice memorandum or technical expedited advice memorandum provides alternate responses based on separate sets of facts, in which case the field must process the cases consistently with the legal analysis in the advice as applied to the facts ultimately determined by the field or area office.


2. If a requesting office disagrees with the conclusions in a technical advice memorandum or a technical expedited advice memorandum, they should consult field counsel and then promptly request reconsideration by the appropriate Office of Associate Chief Counsel. The requesting office must request reconsideration within 30 calendar days after receiving the technical advice memorandum or technical expedited advice memorandum and before contacting the taxpayer. The Associate office will assign the request for reconsideration to a different attorney and reviewer than those who drafted the original technical advice memorandum or technical expedited advice memorandum. If, after thorough consideration of the views of the requesting office any modification is made in the technical advice or technical expedited advice, a new technical advice memorandum or technical expedited advice memorandum is prepared that includes a full discussion of the new material submitted by the requesting office. When no change is to be made, a brief memorandum is prepared reaffirming the original advice. The reconsideration process may include a meeting held by the field participants who requested the advice, the Associate office participants who prepared the original memorandum, and the Associate office participants assigned to the request for reconsideration.

3. Only after adopting the technical advice memorandum or the technical expedited advice memorandum, examination or Appeals gives the taxpayer:



   - A copy of the technical advice memorandum or the technical expedited advice memorandum.

   - The notice under IRC § 6110(f)(1) of intention to disclose the technical advice memorandum or the technical expedited advice memorandum (including a copy of the version proposed to be open to public inspection and notations of third party communications under section 6110(d)).



     ### Note:



     This requirement does not apply to technical advice memoranda or technical expedited advice memoranda involving civil fraud or criminal investigations, jeopardy or termination assessments, or documents to which section IRC § 6104 applies.


4. When the technical advice memorandum or the technical expedited advice memorandum advises the requesting office that a copy should not be furnished to the taxpayer, the requesting office will inform the taxpayer that no copy will be provided to the taxpayer if the taxpayer requests a copy.


**33.2.2.4** **(10-28-2010)**

### Denying Taxpayer’s Request for Technical Advice or Technical Expedited Advice

1. If the examining agent or Appeals Officer concludes that a taxpayer’s request for referral of an issue to the Office of Chief Counsel for technical advice does not warrant referral, the examining agent or Appeals Officer will notify the taxpayer. A taxpayer’s request for a referral will not be denied merely because Office of Chief Counsel provided advice other than advice furnished pursuant to these provisions, to the field or area office on the matter.

2. A taxpayer may appeal the decision of the examining agent or Appeals Officer not to request technical advice or technical expedited advice by submitting to that official, within ten calendar days after being notified of the decision, a written statement of the facts, law, and arguments with respect to the issue, and the reasons why the taxpayer believes the matter should be referred to the Office of Chief Counsel for advice. An extension of time beyond ten calendar days must be justified in writing and approved by the Territory Manager or the Appeals area director.

3. The examining agent or Appeals Officer submits the taxpayer’s statement through channels to the Territory Manager or Appeals area director with a statement of the reasons why the issue should not be referred to the Office of Chief Counsel. The Territory Manager or Appeals area director determines on the basis of the statements submitted, whether technical advice or technical expedited advice will be requested.

4. If the Territory Manager or Appeals area director determines that technical advice or technical expedited advice is not warranted, the taxpayer is informed in writing. The letter to the taxpayer (except in unusual situations where the action would be prejudicial to the best interests of the Government) states the reasons for the proposed denial. The letter also specifies a response date, giving the taxpayer ten calendar days in which to notify the Territory Manager or Appeals area director of agreement or disagreement with the proposed denial. A taxpayer may not appeal the decision of the Territory Manager or Appeals area director not to request technical advice or technical expedited advice; however, if the taxpayer does not agree with the proposed denial, all data relating to the issue for which technical advice or technical expedited advice has been sought, including the taxpayer’s written request and statements, is submitted to the Industry Director, LB&I; the Area Director, SB/SE; the Director, Compliance, W&I the Director, International, LB&I; the Director, Federal, State & Local Governments; the Director, Tax Exempt Bonds; the Director, Indian Tribal Governments; or the Appeals Director, Technical Services, as appropriate.

5. The Industry Director, LB&I; the Area Director, SB/SE; the Director, Compliance, W&I the Director, International, LB&I; the Director, Federal, State & Local Governments; the Director, Tax Exempt Bonds; the Director, Indian Tribal Governments; or the Appeals Director, Technical Services, as appropriate, will review the proposed denial solely on the basis of the written record, and no conference will be held with the taxpayer. A decision on whether the proposed denial is approved or disapproved must be made within 45 calendar days of receiving all the data regarding the request for advice.

6. While the matter is being reviewed, the Field or Area Office will suspend action on the issue (except where the delay would prejudice the Government’s interests).

7. Expedited procedures (15 calendar days rather than 45 calendar days to make a decision on approving or disapproving the proposed denial, and the Field or Area Office will not suspend action on the issue) apply to the denial of technical advice or technical expedited advice requested on frivolous issues. See CCDM 32.3.1.4.9, Not on Frivolous Issues, for examples of frivolous issues. Also, further information on frivolous tax arguments can be found at [www.irs.gov/pub/irs-utl/friv\_tax.pdf PDF](https://www.irs.gov/pub/irs-utl/friv_tax.pdf).


**33.2.2.5** **(08-11-2004)**

### Procedure for Requesting Application of Section 7805(b) in the Case of Technical Advice

1. Under IRC § 7805(b), an Associate Chief Counsel, as the Commissioner’s delegate, may prescribe the extent, if any, to which a technical advice memorandum or a technical expedited advice memorandum will be applied without retroactive effect.

2. A taxpayer for whom a technical advice memorandum or a technical expedited advice memorandum was issued or for whom an advice request is pending may request that the appropriate Associate Chief Counsel, limit the retroactive effect of any holding in the technical advice memorandum or the technical expedited advice memorandum or of any subsequent modification or revocation of the technical advice memorandum or the technical expedited advice memorandum. The taxpayer should make the IRC § 7805(b) request initially as part of the pending technical advice or technical expedited advice request; if the taxpayer makes the section 7805(b) request at a later time, the Associate office will consider the section 7805(b) request if the Service determines there is justification for having delayed the request.

3. When a technical advice memorandum or a technical expedited advice memorandum that concerns a continuing transaction is modified or revoked by, for example, issuance of a subsequent revenue ruling or temporary or final regulations, a request to limit the retroactive effect of the modification or revocation of the technical advice memorandum or the technical expedited advice memorandum must be made in the form of a request for a letter ruling if the request is submitted before examination of the return pertaining to the transaction that is the subject of the request of the letter ruling.

4. When a taxpayer is informed of the modification or revocation of a technical advice memorandum, technical expedited advice memorandum, letter ruling, or determination letter during the course of an examination of the taxpayer’s return or during consideration by Appeals, a request to limit the retroactive application of the modification or revocation of the technical advice memorandum, technical expedited advice memorandum, letter ruling, or determination letter must itself be made in the form of a request for technical advice or technical expedited advice. The taxpayer must also submit through examination or Appeals a statement that the request is being made pursuant to IRC § 7805(b). The statement will be forwarded with the request for technical advice or technical expedited advice. This statement must also set forth the relief sought and an explanation of the reasons and arguments in support of the relief sought, and it must be accompanied by any documents bearing on the request.

5. A request to limit the retroactive effect of a holding in a technical advice memorandum or a technical expedited advice memorandum that does not modify or revoke a prior technical advice memorandum or technical expedited advice memorandum may be made as part of that advice request either initially or at any time before the technical advice memorandum or technical expedited advice memorandum is issued. If a request to limit the retroactive effect of the holding is not made before the technical advice memorandum or technical expedited advice memorandum is issued, the Associate office will consider such a request after the technical advice memorandum or technical expedited advice memorandum is issued. In such cases, the taxpayer must also submit a statement in support of the application of section 7805(b), as described in paragraph (4) above.

6. When a request for technical advice or technical expedited advice concerns only the application of IRC § 7805(b), the taxpayer has the right to a conference in the Associate office in accordance with the provisions of CCDM 33.2.2.2.4. If the request for application of section 7805(b) is included in the request for technical advice or technical expedited advice on the substantive issues or is made before the conference of right on the substantive issues, the IRC § 7805(b) issue will be discussed at the taxpayer’s one conference of right. If the request for the application of section 7805(b) is made as part of a pending technical advice or technical expedited advice request after a conference has been held on the substantive issue, and the Service determines that there is justification for having delayed the request, then the taxpayer will have the right to one conference of right concerning the application of section 7805(b) with the conference limited to discussion of that issue only. The Examining agent or Appeals Officer will be offered the opportunity to attend the conference on the section 7805(b) issue.

7. Whenever, in connection with the preparation of a technical advice memorandum or a technical expedited advice memorandum, the question of non-retroactive application under IRC § 7805(b) is considered, the Associate office attorney to whom the technical advice or technical expedited advice request is assigned shall prepare a memorandum in accordance with the procedures set forth in CCDM 32.3.2.3.5.1(4). See also Rev. Proc. 2004-2, or its successors, for additional procedures applicable to a request for the application of section 7805(b).


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part33/irm_33-002-002#addtoany "Show all")

A2A