---
url: "https://www.irs.gov/irm/part30/irm_30-007-003"
title: "30.7.3 Technology Services | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part30/irm_30-007-003#main-content)

- 30.7.3 [Technology Services](https://www.irs.gov/irm/part30/irm_30-007-003#idm140203704420928)
  - 30.7.3.1 [Information Technology Services in the Office of Chief Counsel](https://www.irs.gov/irm/part30/irm_30-007-003#idm140203704420512)
  - 30.7.3.2 [CC Modernization and Vision Strategy Executive Steering Committee](https://www.irs.gov/irm/part30/irm_30-007-003#idm140203704414816)
  - 30.7.3.3 [Chief Counsel Intranet](https://www.irs.gov/irm/part30/irm_30-007-003#idm140203704396400)
  - 30.7.3.4 [Application Standards](https://www.irs.gov/irm/part30/irm_30-007-003#idm140203704373664)
  - 30.7.3.5 [Electronic Mail](https://www.irs.gov/irm/part30/irm_30-007-003#idm140203704370656)
  - 30.7.3.6 [Personal Use of Government IT Resources](https://www.irs.gov/irm/part30/irm_30-007-003#idm140203704363936)
  - 30.7.3.7 [Streaming Media in the Office of Chief Counsel](https://www.irs.gov/irm/part30/irm_30-007-003#idm140203704360752)

    - 30.7.3.7.1 [Streaming Media Control Board](https://www.irs.gov/irm/part30/irm_30-007-003#idm140203704349808)
    - 30.7.3.7.2 [Section 508 Compliance](https://www.irs.gov/irm/part30/irm_30-007-003#idm140203704341552)
    - 30.7.3.7.3 [Content Owner Procedures and Responsibilities](https://www.irs.gov/irm/part30/irm_30-007-003#idm140203704337280)
    - 30.7.3.7.4 [Other Procedures and Responsibilities](https://www.irs.gov/irm/part30/irm_30-007-003#idm140203704323776)

# Part 30. Administrative

# Chapter 7. Management Systems

# Section 3. Technology Services

* * *

## 30.7.3 Technology Services

**30.7.3.1** **(05-02-2007)**

### Information Technology Services in the Office of Chief Counsel

1. This section describes the policies and procedures governing information technology services throughout the Office of Chief Counsel.

2. The Associate Chief Counsel (Finance and Management) is responsible for the oversight of the Counsel information systems program as described in CCDM 30.3.2.3.2.2 , Functions of the Office of the Associate Chief Counsel (F&M).


**30.7.3.2** **(05-02-2007)**

### CC Modernization and Vision Strategy Executive Steering Committee

1. The Chief Counsel Modernization and Vision Strategy Executive Steering Committee (CC ESC) was established to meet the IRS and Office of Management and Budget (OMB) governance requirements for the Counsel Automated System Environment (CASE).

2. The CC ESC is chartered by the Modernization and Information Technology Services Enterprise Governance (MEG) Committee and governs projects within the CC portfolio.



1. The CC ESC charter is approved by the MEG Committee Co-Chairs. The Program Governance Office is responsible for maintaining and updating the charter as necessary.

2. The CC ESC is responsible for establishing operating protocols consistent with the charter.


3. The primary objective of the CC ESC is to ensure project objectives are met, risks are managed appropriately, and the expenditure of enterprise’s resources is fiscally sound. The CC ESC provides governance for all Major and Non-Major CC projects. For the Non-Major projects, governance is on an exception basis — either the project is deemed as high visibility or the project has exceeded defined variance thresholds. Governance includes, but is not limited to, the following:



   - Adhere to the Enterprise Life Cycle (ELC) Framework’s principles

   - Resolve enterprise-wide issues for CC ESC projects

   - Coordinate issues with organizations having external expertise to assist with decision making, such as policy exceptions

   - Develop a measure of the customer satisfaction with the projects supporting litigation, regulatory compliance, judicial activities, and other enforcement guidance

   - Address matters as assigned by the MEG Committee

   - Escalate disputes not resolved to the MEG Committee and Service, Support & Modernization Committee


4. The ESC is co-chaired by the Associate Chief Counsel (F&M) and the Associate Chief Information Officer (ES).



1. The Chief, Mission Assurance is a voting member of the CC ESC; the Co-Chairs appoint the other voting and non-voting members. In general, voting membership ranges from 9–13.

2. It is the responsibility of the voting member to notify the co-chairs if a proxy will be in attendance. Proxies have full participatory rights and are empowered to vote on behalf of the absent member.


5. The CC ESC replaced the former Information Management Policy Board (IMPB).


**30.7.3.3** **(05-02-2007)**

### Chief Counsel Intranet

1. Each Chief Counsel office is responsible for providing information and submissions for its individual page(s) on the Chief Counsel (CC) Intranet. Each Chief Counsel office will designate an individual to review the information on its page(s) of the CC Intranet to ensure correctness and continued applicability at least once every month.

2. The Associate Chief Counsel (F&M) has overall responsibility for the CC Intranet, with final decision authority over its content and style. The Associate Chief Counsel (F&M) provides guidance and coordination to each Chief Counsel Office on CC Intranet issues as needed.

3. The actual operation and maintenance of the CC Intranet is assigned to the Technical Support Branch of the Counsel Information System Office (CISO).


**30.7.3.4** **(05-02-2007)**

### Application Standards

1. As of October 1, 2003, Microsoft Word is the standard word processing application for the Office of Chief Counsel.


**30.7.3.5** **(05-02-2007)**

### Electronic Mail

1. Electronic mail (email) is provided for official business purposes. Employees should evaluate the propriety of email as the communication vehicle for particular information or work products. Guidance on the use of email and security protocols may be found in:



   - CCDM 30.6.1.2.3 , Security of Confidential Information, Official Documents, and Tax Data

   - IRM 1.10.3 , Standards for Using E-Mail


2. "Broadcast/All User" e-mail messages should receive pre-authorization in the headquarters office by an Associate Chief Counsel. In field offices, "All User" messages should be approved by the Area Counsel; cross-functional messages should be approved by the F&M Area Manager. "All User" e-mail messages should include the name and title of the authorizing official.


**30.7.3.6** **(05-02-2007)**

### Personal Use of Government IT Resources

1. Guidance on the personal use of Government IT resources can be found in CCDM 30.4.5 , Labor and Employee Relations.


**30.7.3.7** **(12-14-2009)**

### Streaming Media in the Office of Chief Counsel

1. This subsection establishes policy and procedures for streaming media in the office of Chief Counsel. These policies and procedures are meant to maximize the resources available to both developers and consumers of streaming media while at the same time minimizing the impact on other Chief Counsel network traffic.

2. Streaming media are efficient and economical methods for Office employees nationwide to access live ( _synchronous_) or archived ( _asynchronous or on-demand_) information from a single source.

3. The primary purposes of streaming media are training and communications associated with the mission of the Office of Chief Counsel. Counsel’s goal is to provide content that is meaningful, relevant, and timely, and which helps employees perform their jobs to their maximum potential.

4. Selection and encoding of events into streaming file formats is the responsibility of the Office of Training and Communications.

5. Streaming media include streaming video (including audio) or streaming audio alone.

6. Making streaming media available requires cooperation among content owners, the Chief Counsel intranet Webmaster, and IT Operations.

7. Until such time as bandwidth between the Chief Counsel domain and IRS or Treasury or other agencies’ domains is adequate, streaming video from the Counsel servers is intended for Chief Counsel intranet access only.


**30.7.3.7.1** **(12-14-2009)**

#### Streaming Media Control Board

1. A Control Board consisting of, but not limited to, a representative from the Business Systems Planning (BSP) Office, the Training and Communications Office, IT Operations, and the Webmaster will set acceptable parameters and formats for source media files and for streaming files.

2. The Control Board will also review policies governing streaming media and its use within Counsel and make recommendations for best business and technical policies to the BSP and/or Counsel’s IT departments.

3. The Control Board will establish the back-end protocols and procedures in order to meet the needs of the Office and to comply with appropriate security, operations, and network guidelines.

4. The Control Board will analyze network data in order to be able to report on utilization and effectiveness of various streaming media.

5. The Control Board will review customer and executive feedback in an effort to best meet the goals associated with streaming media.

6. The Control Board may recommend modifications to existing hardware and/or software and/or procedures and logistics as the program and technology evolve.


**30.7.3.7.2** **(12-14-2009)**

#### Section 508 Compliance

1. In accordance with Section 508 Electronic and Information Technology Accessibility Standards, posted media shall have "a text equivalent for every no-text element" , and that equivalent should be " synchronized with the presentation" . In the case of streaming audio and video, Chief Counsel will meet that requirement with captioning presented in the video player.

2. Financial responsibility for producing the captioning files lies with the content owner or submitting party.


**30.7.3.7.3** **(12-14-2009)**

#### Content Owner Procedures and Responsibilities

1. **Content** — All content is the responsibility of the content owner or submitting party. Considerations include disclosure, consent, copyright, legal discovery, and other legal issues.



1. In the case of content contributed by other business units or divisions, the Office of Training and Communications has discretion over the encoding and posting of that content.


2. **Metadata** — Effort should be made by the content owner to identify appropriate terms or other classifying data that will assist Counsel users to locate the streaming content through an intranet search.

3. **Materials** — Effort should be made by the content owner to provide handouts, PowerPoint files, or other materials utilized in the video to viewers through Materials links in the Media Player.

4. **Lifespan** — Effort should be made by the content owner to identify the lifespan of each piece of streaming content. This ensures that all available content is timely and relevant. In addition, it will facilitate maintenance of the launch page(s) and keep server storage space available for newer content.

5. **Audience** — It may be possible to limit access to streaming content to one or more appropriate audiences. If this is necessary, it will be the responsibility of the content owner to provide this information to the Office of Training and Communications on submission of the streaming content.


**30.7.3.7.4** **(12-14-2009)**

#### Other Procedures and Responsibilities

1. The Office of Training and Communications will be responsible for producing streaming files in accordance with parameters set by the Streaming Media Control Board.

2. The Webmaster will be responsible for:



1. Any additional coding or repackaging of those streaming files to match network protocols or standards

2. Modifying the web page(s) used to launch the streaming files

3. Limiting access to content based on audience specifications from the content owner or The Office of Training and Communications

4. Removing links and/or content at the end of their lifespan


3. IT Operations will be responsible for:



1. Positioning necessary files on appropriate server(s)

2. Archiving streaming files in accordance with the usual standards for backup and archiving


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part30/irm_30-007-003#addtoany "Show all")

A2A