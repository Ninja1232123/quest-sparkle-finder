---
url: "https://www.irs.gov/irm/part35/irm_35-009-002"
title: "35.9.2 Procedures for Assessment of Tax | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-009-002#main-content)

- 35.9.2 [Procedures for Assessment of Tax](https://www.irs.gov/irm/part35/irm_35-009-002#idm140379473664704)
  - 35.9.2.1 [Assessment](https://www.irs.gov/irm/part35/irm_35-009-002#idm140379462480016)
  - 35.9.2.2 [Time Limitation on Assessment](https://www.irs.gov/irm/part35/irm_35-009-002#idm140379450003680)
  - 35.9.2.3 [Assessment in Non-Appealed Cases](https://www.irs.gov/irm/part35/irm_35-009-002#idm140379464981200)
  - 35.9.2.4 [Assessment in Cases Wherein not all Liabilities Determined by theTax Court are Appealed](https://www.irs.gov/irm/part35/irm_35-009-002#idm140379495022080)
  - 35.9.2.5 [Assessment in Untimely Taxpayer Appeal Cases](https://www.irs.gov/irm/part35/irm_35-009-002#idm140379452571216)
  - 35.9.2.6 [Assessment during Bankruptcy Proceedings](https://www.irs.gov/irm/part35/irm_35-009-002#idm140379479916528)
  - 35.9.2.7 [Verification of Assessment](https://www.irs.gov/irm/part35/irm_35-009-002#idm140379464011600)

    - 35.9.2.7.1 [Remanded Cases](https://www.irs.gov/irm/part35/irm_35-009-002#idm140379466649504)

# Part 35. Tax Court Litigation

# Chapter 9. Post Opinion Activities

# Section 2. Procedures for Assessment of Tax

* * *

## 35.9.2 Procedures for Assessment of Tax

**35.9.2.1** **(08-11-2004)**

### Assessment

1. Assessment is the statutorily required recording of the tax liability. Section 6203. Assessment is made by recording the taxpayer’s name, address, and tax liability. The assessment date is the 23C date. The 23C date is the Monday on which the recording of assessment and other adjustments are made in summary manner on Form 23C and signed by a Service Center officer. In non-TEFRA cases, the taxpayer is mailed a notification that a tax (plus interest, and additions and penalties, if any) is due and a demand for payment. For TEFRA cases, _see_ CCDM 35.9.3.5.2.

2. The timing of an assessment after a decision is entered depends on whether an appeal is filed. For a detailed discussion of appeals, _see_ CCDM Part 36. Moreover, even if the taxpayer files an appeal, the timing of assessment also depends on whether the taxpayer posts a bond. Bonded taxpayer appeals require special attention because when an adequate bond is posted, assessment cannot be made as to any deficiencies, additional amounts, and interest covered by the bond until the decision of the Tax Court becomes final. Section 7485. Once the decision of the Tax Court becomes final, the Service has only 60 days in non-TEFRA cases in which to assess the tax, plus any additional time obtained through "tacking." For time limitation on assessment in TEFRA cases, _see_ CCDM 35.9.3.5.2.

3. When the Field attorney receives notification by TLCATS message of a nonbonded taxpayer appeal, however, assessment activity should be initiated promptly. The attorney should insure delivery of the administrative file to the Appeals office, Records Section, requesting by transmittal that the assessment be made.

4. If a notice of appeal of a Tax Court decision is filed, the Service may refund or credit any overpayment found by the court to the extent the overpayment is not contested on appeal. _See_ sections 6512(a)(6)and (b)(1).


**35.9.2.2** **(08-11-2004)**

### Time Limitation on Assessment

1. In all non-TEFRA cases decided by the Tax Court, assessment must be made within the 60-day period after the decision of the Tax Court becomes final. As discussed above, in general, the decision becomes final 90 days after the decision is entered in cases in which no appeal is filed. _See_ section 7481.

2. In some cases, the time period for making an assessment may be extended. In that regard, _see_ sections 6501, 6229, 6213(a), and 6503 with respect to limitations on assessment, and the manner in which the time for making an assessment may be extended.

3. Tacking refers to the additional period of time provided by the unexpired portion of the three-year limitation period at the time the notice of deficiency was issued. For example, if the three-year limitation period on assessment would expire on July 31, 2000, and the notice of deficiency is issued on June 30, 2000, the unexpired portion of the limitations period is 31 days. This 31-day period may be tacked on to the 60-day period for assessment following the finality of the Tax Court’s decision. The attorney should keep in mind, however, that assessment should never be delayed in reliance on tacking, despite its potential application. It is the position of this office to have the deficiency assessed at the earliest opportunity.


**35.9.2.3** **(08-11-2004)**

### Assessment in Non-Appealed Cases

1. Responsibility for Assessment. If a decision of the Tax Court is not appealed by either party during the 90-day appeal period, assessment responsibility remains with Field Counsel. This is true even though dockets which are not appealed are related to dockets which have been appealed, and even though the nonappealed docket legal files had previously been transmitted to an Associate office for appeal consideration. For this reason it is important that Field Counsel and the Associate attorney closely coordinate as to the status of any docket being considered for appeal.

2. Initiation of Assessment Activity. TLCATS will remind the Field attorney of the due date for assessment 100 days after the decision has been entered. The additional ten-day period for initiation of assessment activity is provided in case the taxpayer should appeal but the notice of appeal is received by the Tax Court after the expiration of the 90-day appeal period. Since the timely mailing is timely filing rule applies to notices of appeal, the taxpayer’s appeal notice may fall within the jurisdictional requirement for appeal.


**35.9.2.4** **(08-11-2004)**

### Assessment in Cases Wherein not all Liabilities Determined by the Tax Court are Appealed

1. The petitioner may have had more than one docketed case before the Tax Court, and the dockets may have been consolidated for purposes of trial, briefing, and opinion. A separate decision will be entered for each docket number. The petitioner may appeal one or more of the decisions and may post a bond for one or more of the appeals. If any one of the decisions is not appealed, the deficiencies as determined by the Tax Court in that decision will be assessed in the same manner as nonappealed cases. If any one of the decisions is appealed without the posting of a bond, the deficiencies determined by the Tax Court in that decision will be assessed in the same manner as nonbonded petitioner appeals.


**35.9.2.5** **(08-11-2004)**

### Assessment in Untimely Taxpayer Appeal Cases

1. If the petitioner files an untimely notice of appeal, the decision of the Tax Court will become final in the regular manner as if there had been no appeal. Therefore, assessment must be made within the 60-day period (in non-TEFRA cases) following the 90-day appeal period or 120-day period if there is a cross-appeal. If there is a question as to timeliness and the petitioner has posted a bond, the assessment should be made. If the court of appeals determines the appeal to be timely, the assessment should be abated as erroneous.


**35.9.2.6** **(08-11-2004)**

### Assessment during Bankruptcy Proceedings

1. Due to the automatic stay which commences when a bankruptcy petition is filed, the attorney should carefully monitor the bankruptcy case to ensure that the statute of limitations on assessment is protected.

2. The attorney should consult CCDM 35.2.1.1.8 for the discussion of bankruptcy cases.

3. As indicated in CCDM 35.2.1.1.8, section 6213(f)(1) coordinates the provision in the Bankruptcy Code (11 U.S.C. § 362(a)(8)) that prevents the filing of a petition in the Tax Court during the pendency of a bankruptcy proceeding with the section of the Internal Revenue Code that provides the procedures for the filing of a petition with the United States Tax Court. There is no similar provision in the Internal Revenue Code suspending the 90-day period for filing an appeal from a Tax Court decision when a petitioner in the Tax Court files a petition in bankruptcy. When the Service wishes to appeal from an adverse decision, it is necessary to examine the case law in the circuit to determine whether the filing of a bankruptcy petition stays the filing of a notice of appeal. For example, arguably, the provisions of 11 U.S.C. § 362(a)(1) operate automatically to stay the continuation of any judicial proceeding against the debtor, and this could include the filing of a notice of appeal.



1. In other contexts, courts have ordered the stay of an appeal without prejudice to the rights of the parties to apply to the bankruptcy court for an order lifting the automatic stay.

2. To protect the Commissioner’s right of appeal, a motion for an order lifting the automatic stay must be filed in the bankruptcy court. If that motion is granted, the stay is lifted for that specific purpose and the Commissioner has until the end of the regular 90-day period to file a notice of appeal. If the motion is pending with or is not granted by the bankruptcy court as the end of the 90-day period approaches, a notice of appeal should be filed with the Tax Court for protective purposes in any event, and the permission of the bankruptcy court sought to lift the stay retroactively to the date of the notice of appeal.

3. If an appeal from a Tax Court decision is sought by the taxpayer-debtor rather than against the taxpayer-debtor, it is not clear whether the automatic stay provisions apply. Section 362(a)(8) of the Bankruptcy Code by its terms only applies to stay proceedings in the Tax Court, not a court of appeals. An appeal to a court of appeals, however, is made by filing a notice of appeal with the Tax Court. There should be no need to apply for a lifting of the automatic stay since the proceeding is not against the debtor. It is necessary, however, to move to lift the stay in the bankruptcy court before a notice of appeal is filed with the Tax Court. The position of the Service continues to be that subsections (a)(1) and (a)(8) of section 362 of the Bankruptcy Code should be read together and construed together as staying the proceedings until the circuit rules otherwise. Accordingly, in any case where the Commissioner must timely appeal a Tax Court decision and the taxpayer-debtor has filed a petition in bankruptcy during the appeal period, the Commissioner should move the bankruptcy court to lift the stay even _nunc pro tunc_ if it is not possible to have the stay lifted before the appeal period expired to permit filing a notice of appeal. The purpose of so moving is to prevent the possible imposition of a contempt sanction for appealing before the stay was lifted.

4. With respect to a taxpayer appeal by a debtor-in-possession, it is arguable whether section 108(b) of the Bankruptcy Code operates to suspend the period for filing an appeal for 60 days after relief from the stay is granted. Although the language of section 108(b) refers only to a trustee, it is generally agreed that the statutory language applies equally to a debtor-in-possession.


4. If a bankruptcy petition is filed by or against a taxpayer-debtor after a notice of appeal from a Tax Court decision has been filed, that petition would likewise operate to prevent continuation of the prosecution of the appeal. In these circumstances, the Field attorney should fully advise DJ and CBS, Branch 2 of the date of the filing of the bankruptcy petition, the location of the bankruptcy court, and the name and address of the trustee, if any, so that the DJ Tax Division can notify the court of appeals of the pendency of the automatic stay.

5. Ordinarily in non-TEFRA cases, pursuant to section 6503(a)(1), an assessment with respect to a deficiency must be made within 60 days after the decision of the Tax Court becomes final. Under sections 6213(a) and 6503(a)(1), the period of limitations on assessment or collection is suspended for the period during which the Service is prohibited from making an assessment and for 60 additional days. The period of limitations on assessment or collection is further suspended pursuant to section 6503(h), for the period during which the Service is prohibited from taking action to assess or collect by reason of the automatic stay provisions. _See_ Bankruptcy Code §§ 362(a)(6) and (8), and 362(b)(9)(D). It is imperative that Field Counsel monitor any case on appeal that is involved in a bankruptcy proceeding in order to make the assessment as soon as possible under the provisions of section 362(c)(2) of the Bankruptcy Code, which provides that the stay is lifted upon the earliest of (1) the time that the case is closed, (2) the time that the case is dismissed, or (3) with respect to a Chapter 7 case involving an individual, or a Chapter 9, 11, 12, or 13 case, the time that a discharge is either granted or denied. This monitoring should take place at least once every 30 days. With respect to TEFRA cases, the attorney should coordinate with the Associate Chief Counsel (P&A) so that the statute of limitations can be protected. On the other hand, if a decision becomes final prior to the filing of a bankruptcy petition, the Service is not prohibited from assessing the tax, and the statute is not suspended. _See_ section 362(b)(9)(D) of the Bankruptcy Code.

6. Bonded cases require additional care. If the decision of the Tax Court becomes final while the stay on assessments and collections due to the bankruptcy petition remains in effect, the case should be monitored and the deficiency assessed as soon as the case is dismissed or closed, or, with respect to a Chapter 7 case involving an individual, or a Chapter 9, 11, 12, or 13 case, when a discharge is either granted or denied. _See_ section 362(c)(2) of the Bankruptcy Code. If, however, the stay imposed by the bankruptcy proceedings has already ended because one of the three has occurred, the case must continue to be monitored so that the deficiency may be assessed as soon as the decision of the Tax Court becomes final.


**35.9.2.7** **(08-11-2004)**

### Verification of Assessment

1. In order to ensure that the statute of limitations on assessment is protected, the attorney should carefully monitor cases which have been remanded after appeal.

2. In nonappealed cases, verification that the assessment has been made is neither requested by nor forwarded to an Associate office. Verification of ordinary Tax Court assessments is generally not undertaken by Field Counsel, who should nonetheless verify that the Appeals office received the request for assessment and the administrative file.


**35.9.2.7.1** **(08-11-2004)**

#### Remanded Cases

1. This sub-section applies to appealed Tax Court cases in which the Tax Court decision is reversed or modified by a court of appeals or the Supreme Court. When the Tax Court decision is reversed or modified, in whole or in part, the case is usually remanded to the Tax Court for appropriate action in accord with the mandate of the appellate court. It should be noted that the absence of the word "remand" is not determinative. If the Tax Court decision has been modified in any way, the case will be returned to the Tax Court for entry of a new decision.

2. Actions Following Remand. In most instances, the appropriate action falls into two categories: (1) entry of a new decision or (2) further proceedings, which may or may not encompass a second trial, followed by the entry of a new decision. The two categories are referred to as (1) remand for entry of new decision and (2) remand for rehearing (which will be followed by the entry of a new decision).

3. Finality of Decision Following Remand. A Tax Court decision entered after remand for entry of decision will become final 30 days after entry, and a decision entered after remand for rehearing will become final after the expiration of the 90-day appeal period. _See_ section 7481; for appellate procedures, _see_ CCDM Part 36.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-009-002#addtoany "Show all")

A2A