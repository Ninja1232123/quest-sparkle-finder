---
url: "https://www.irs.gov/irm/part38/irm_38-001-001"
title: "38.1.1 Prereferral Assistance, Visitations and Investigative Tools | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part38/irm_38-001-001#main-content)

- 38.1.1  [Prereferral Assistance, Visitations and Investigative Tools](https://www.irs.gov/irm/part38/irm_38-001-001#idm140321798416272)
  - 38.1.1.1  [Prereferral Assistance](https://www.irs.gov/irm/part38/irm_38-001-001#idm140321798579712)
  - 38.1.1.2  [Criminal Investigation Group Reviews and Visitations](https://www.irs.gov/irm/part38/irm_38-001-001#idm140321798575712)
  - 38.1.1.3  [Search Warrant Procedures](https://www.irs.gov/irm/part38/irm_38-001-001#idm140321799141696)
    - 38.1.1.3.1  [Search Warrant Authorization](https://www.irs.gov/irm/part38/irm_38-001-001#idm140321798993424)
    - 38.1.1.3.2  [Counsel Review and Advice](https://www.irs.gov/irm/part38/irm_38-001-001#idm140321799156544)
      - 38.1.1.3.2.1  [Content and Style](https://www.irs.gov/irm/part38/irm_38-001-001#idm140321799148608)
      - 38.1.1.3.2.2  [Non-Sensitive Search Warrants](https://www.irs.gov/irm/part38/irm_38-001-001#idm140321826054192)
      - 38.1.1.3.2.3  [Sensitive Search Warrants](https://www.irs.gov/irm/part38/irm_38-001-001#idm140321826051632)
    - 38.1.1.3.3  [Search Warrant Inventory Review for Tax and Tax-Related Search Warrants](https://www.irs.gov/irm/part38/irm_38-001-001#idm140321799130176)
    - 38.1.1.3.4  [General Legal Guidance and Issues](https://www.irs.gov/irm/part38/irm_38-001-001#idm140321799126576)
  - 38.1.1.4  [Undercover Assistance](https://www.irs.gov/irm/part38/irm_38-001-001#idm140321799114336)
    - 38.1.1.4.1  [Content and Style of Undercover Evaluation Memorandum](https://www.irs.gov/irm/part38/irm_38-001-001#idm140321825923264)
  - 38.1.1.5  [Electronic Surveillance](https://www.irs.gov/irm/part38/irm_38-001-001#idm140321825896368)
    - 38.1.1.5.1  [Non-Consensual Monitoring of Wire/Oral Interception](https://www.irs.gov/irm/part38/irm_38-001-001#idm140321825895472)
    - 38.1.1.5.2  [Electronic Communications](https://www.irs.gov/irm/part38/irm_38-001-001#idm140321826046656)
      - 38.1.1.5.2.1  [Stored Electronic Communications](https://www.irs.gov/irm/part38/irm_38-001-001#idm140321826041168)
      - 38.1.1.5.2.2  [Obtaining Content of Email Communications from Service Providers](https://www.irs.gov/irm/part38/irm_38-001-001#idm140321826036608)
    - 38.1.1.5.3  [Consensual Monitoring](https://www.irs.gov/irm/part38/irm_38-001-001#idm140321826031680)
      - 38.1.1.5.3.1  [Use of Electronic Tracking Devices](https://www.irs.gov/irm/part38/irm_38-001-001#idm140321826023328)
      - 38.1.1.5.3.2  [Pen Registers and Trap and Trace Devices (Grabbers)](https://www.irs.gov/irm/part38/irm_38-001-001#idm140321826014864)
  - 38.1.1.6  [Summonses](https://www.irs.gov/irm/part38/irm_38-001-001#idm140321826010496)

# Part 38. Criminal Tax

# Chapter 1. Assistance to Criminal Investigation During Investigatory Stage

# Section 1. Prereferral Assistance, Visitations and Investigative Tools

* * *

## 38.1.1 Prereferral Assistance, Visitations and Investigative Tools

#### Manual Transmittal

April 09, 2020

#### Purpose

(1) This transmits revised CCDM 38.1.1, Assistance to Criminal Investigation During Investigatory Stage; Prereferral Assistance, Visitations and Investigative Tools.

#### Material Changes

(1) CCDM 38.1.1.4 has been edited to add a reference to Exhibit 38.3.1-12, Sample Undercover Evaluation Memorandum.

(2) CCDM 38.1.1.4.1 has been added to add sections (1) through (12) that provide detailed guidance on the drafting of Counsel’s Undercover Evaluation Memorandum. The highlighted sections include the: criminal subject(s); scope of Counsel’s review; standard of review; executive summary; facts; targeting criteria; proposed operations; objective(s); analysis; _Brady/Giglio/_ evidentiary issues; and conclusion.

(3) Updated link references throughout the document.

#### Effect on Other Documents

CCDM 38.1.1, dated May 8, 2018, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(04-09-2020)

Edward F. Cronin

Division Counsel/Associate Chief Counsel

(Criminal Tax)

**38.1.1.1** **(06-27-2013)**

### Prereferral Assistance

1. Criminal Tax attorneys will be available, upon request, at any stage of an investigation for discussions with Criminal Investigation personnel for the purpose of rendering legal advice. Prereferral legal assistance is solely advisory in nature and its purpose is to provide guidance regarding legal issues that surface during an investigation.

2. Prereferral advice will generally be provided in the same form as the request: if the request is oral, the response may be oral; if the request is in writing, the response will be in writing. If an oral response is provided, a follow-up memorandum to the file will be prepared.

3. If a written response is prepared, a copy of the written response will be forwarded to the Area Counsel for review, approval, and signature before transmission to Criminal Investigation. If the Area Counsel has delegated signature authority, then the Area Counsel will post review the written response. If written prereferral advice is provided to Criminal Investigation by the office of Associate Chief Counsel (CT), the written response will be reviewed, approved, and signed by the Associate Chief Counsel (CT).

4. If an investigation involves an individual or entity within the purview of another Associate office or raises issues requiring technical assistance, Criminal Tax attorneys are encouraged to contact the office of Associate Chief Counsel (CT) for coordination.


**38.1.1.2** **(08-11-2004)**

### Criminal Investigation Group Reviews and Visitations

1. Criminal Tax attorneys should visit Criminal Investigation personnel to conduct group reviews and visitations. The purpose of the reviews and visitations is to discuss and to address legal issues and concerns present in the cases in Criminal Investigation’s inventory. Specifically, the Criminal Tax attorney and Criminal Investigation personnel should discuss any legal problems associated with the investigation, as well as Criminal Investigation’s theory of prosecution. Legal impediments should be raised and discussed.

2. Where reasonably possible, these group reviews and visitations should be conducted once per quarter.


**38.1.1.3** **(06-27-2013)**

### Search Warrant Procedures

01. The Fourth Amendment provides that "\[t\]he right of the people to be secure in their persons, houses, papers, and effects, against unreasonable searches and seizures, shall not be violated, and no warrants shall issue, but upon probable cause, supported by oath or affirmation, and particularly describing the place to be searched, and the persons or things to be seized." The scope of Fourth Amendment protection extends to any government search of private property, as well as any other area in which an individual has a reasonable expectation of privacy.

02. Pursuant to the Fourth Amendment, a warrant may only be issued if there is probable cause to believe a crime has been committed and evidence of the crime will be found in the location to be searched. The place to be searched and the items to be seized must be described in sufficient detail to enable the executing officers to identify the place and the items with reasonable effort.

03. Rule 41 of the Federal Rules of Criminal Procedure contains the procedures for obtaining a warrant. Briefly, Rule 41 provides for the issuance of a warrant by a federal magistrate or a judge of a state court of record within the district where the property or person sought is located, upon request by a federal law enforcement officer or an attorney for the Government.

04. A warrant may be issued to seize:



    - Property that constitutes evidence of the commission of a crime

    - Contraband, the fruits of a crime, or things otherwise criminally possessed

    - Property designed or intended to be used as an instrumentality of a crime

    - People, when there is probable cause for their arrest


05. To request a warrant, the law enforcement officer or government attorney typically presents the magistrate with a sworn affidavit that establishes probable cause for the proposed search and seizure (or for installation and use of a tracking device). If the magistrate issues the warrant, the officer has ten days to execute the warrant. The search should be performed during the daytime (between 6:00 a.m. and 10:00 p.m.) unless the issuing authority has authorized execution at other times. The officer executing the warrant is required to provide a copy of the warrant and a receipt for any property seized to the person from whom, or from whose premises, the property was taken. The officer must also promptly return the warrant, together with a written inventory of the property seized, to the magistrate judge.

06. Congress has authorized special agents to seek and execute search warrants in criminal tax investigations and any other criminal investigation within the law enforcement jurisdiction of the Service. In deciding whether to use a search warrant, special agents are required by the IRM "to execute their law enforcement responsibilities by continually assessing … the probable impact of their enforcement activities on the image of the IRS." IRM 9.1.4.3(1), Directive No. 1— Enforcement Operations. This directive has been interpreted as requiring Criminal Investigation to employ the least intrusive means needed in their investigations. Further, the IRM provides that search warrants for tax and tax-related offenses will be used "with restraint and only in significant tax investigations." IRM 9.4.9.2(5), General Search Warrant Procedures. Accordingly, Criminal Investigation requires special agents to analyze whether less intrusive means are reasonably available to acquire evidence sought in all tax and tax-related investigations.



    ### Note:



    Pursuant to IRS Policy Statement 4-120, Criminal Investigation must obtain a search warrant in all cases when seeking from an internet service provider (ISP) the content of email communications stored by the ISP.

07. Criminal Investigation’s policy regarding Counsel review of search warrant applications is as follows:



    1. Prior to the approval of a search warrant enforcement action, Counsel will review all search warrant applications where a special agent is the affiant.

    2. This review will be conducted for warrants in both tax and nontax investigations . Counsel’s review is required for search warrant applications obtained in both administrative and grand jury investigations.

    3. Counsel will review both the affidavit and Form 13739, Enforcement Action Review Form. Subsequent to this review, Counsel will provide written advice to the Special Agent in Charge (SAC) (or to the Director of Field Operations (DFO) for sensitive search warrants; _see_ _CCDM 38.1.1.3.1(5)_) for consideration in the search warrant approval process.


08. In reviewing a search warrant application, Counsel must advise Criminal Investigation whether the affidavit establishes sufficient probable cause to support the warrant, and, if not, what additional information is needed. In addition, Counsel must evaluate whether the location to be searched and the items to be seized are described with sufficient particularity. In tax and tax-related investigations, Counsel must also advise Criminal Investigation whether less intrusive investigative methods are reasonably available to acquire the evidence sought. If Criminal Investigation seeks to obtain the content of email communications from an ISP, Counsel’s analysis of whether a warrant is the least intrusive means available must reference IRS Policy Statement 4-120, which requires a warrant in such cases.

09. Time is of the essence in all search warrant matters; therefore, Counsel should complete its review and advice as expeditiously as possible. Specific time requirements for completion, review, and rendering of advice should be determined on a case-by-case basis. In the event written advice cannot be provided within the time frame required, Counsel may provide oral advice to Criminal Investigation with the approval of the Area Counsel or Associate Chief Counsel (CT). All such advice must be memorialized in a written memorandum to Criminal Investigation as soon as possible. A detailed explanation of the exigencies warranting the rendition of oral advice must be set forth in the memorandum.

10. If a search warrant involves an individual or entity within the purview of another Associate office or raises issues requiring technical assistance, Criminal Tax attorneys are encouraged to contact the office of Associate Chief Counsel (CT) for coordination.

11. Criminal Tax attorneys do not attend or participate in the actual execution of the search, but they should be available to answer questions that may arise during the search.

12. For all tax and tax-related search warrants, Criminal Tax attorneys must conduct a review of the seized property inventory prepared by Criminal Investigation to ensure the items seized are within the scope of the warrant and to identify any inconsistencies.


**38.1.1.3.1** **(06-27-2013)**

#### Search Warrant Authorization

1. **Authorization**. All search warrants where a special agent is the affiant must be approved by the respective SAC or DFO prior to execution. The SAC or DFO is required to obtain the advice and assistance of Counsel in the preparation and review of all search warrant applications prior to referring them to the appropriate Department of Justice (DOJ) official for authorization.

2. **DOJ authorization**. Pursuant to [Tax Division Directive No. 52 PDF](http://www.justice.gov/tax/readingroom/2008ctm/CTM%20Chapter%203.pdf) (revised March 17, 2008), the Tax Division has delegated to U.S. Attorneys the authority to approve certain Title 26 or tax-related Title 18 search warrants directed at the offices, structures, premises, etc. owned, controlled, or under the dominion of the subject or target of a criminal investigation. The Tax Division retains _exclusive authority_, however, to approve search warrants directed at the offices, structures, or premises owned, controlled or under the dominion of a subject or target of an investigation who is:



   - An accountant;

   - A lawyer;

   - A physician;

   - A local, state, federal, or foreign public official or political candidate;

   - A member of the clergy;

   - A representative of the electronic or printed news media;

   - An official of a labor union; or

   - An official of an organization deemed to be exempt under IRC § 501(c)(3).


3. **Investigations involving third parties**. The Tax Division also retains _exclusive authority_ to approve the use of search warrants in criminal investigations involving disinterested third parties, **with the exception of**:



1. Search warrants directed to providers of electronic communication services or remote computing services and relating to a subject or target of a criminal investigation; and

2. Search warrants directed to disinterested third parties owning storage space businesses or similar businesses and relating to a subject or target of a criminal investigation.


### Note:

Such search warrants no longer require Tax Division approval, unless they relate to a person reasonably believed to be one of the individuals listed in _CCDM 38.1.1.3.1(2)_. ( _See_ Tax Division Directive No. 52, revised March 17, 2008.)

4. **Significant case policy**. It is the policy of the IRS and the Tax Division that search warrants will be utilized with restraint and only in significant criminal tax cases. The significance of a criminal tax case may be determined by considering such factors as:



   - The amount of tax due;

   - The nature of the fraud;

   - The need for the evidence to be seized; or

   - The impact of the potential criminal tax case on voluntary compliance with the revenue laws.


5. **Sensitive Search Warrants**. The SAC is required to obtain the concurrence of the respective DFO for the execution of a search warrant directed at offices, structures or premises owned or controlled by one of the following:



   - An accountant;

   - A lawyer;

   - A physician;

   - A local, state, federal, or foreign public official or political candidate;

   - A member of the clergy;

   - A representative of the electronic or printed news media;

   - An official of a labor union;

   - An official of an organization deemed to be exempt under IRC § 501(c)(3); or

   - With certain exceptions, a disinterested third party, _see_ _CCDM 38.1.1.3.1(3)_.


6. Sensitive search warrant applications must be forwarded to the office of Associate Chief Counsel (CT) for review prior to being forwarded to the DFO. All other search warrant applications are reviewed by field Criminal Tax attorneys and/or Area Counsel prior to being forwarded to the SAC.


**38.1.1.3.2** **(05-25-2018)**

#### Counsel Review and Advice

1. Upon receipt of a search warrant application, Counsel must review the warrant and supporting documentation and prepare a memorandum for the SAC or DFO, evaluating investigative necessity, legal sufficiency, and policy compliance. See Exhibit 38.3.1-10.

2. In all cases, Counsel's memorandum must evaluate whether the three-pronged probable cause test is met. The facts enumerated in the affidavit should clearly establish there is probable cause to believe:



1. A crime has been committed,

2. The items sought may be seized by virtue of their connection with the crime, and

3. The items sought are at the location to be searched.


3. Counsel’s memorandum must also evaluate whether the warrant and supporting documentation describe the location to be searched and the items to be seized with sufficient particularity.

4. In tax and tax-related investigations, Counsel must review Criminal Investigation’s explanation in Form 13739, Enforcement Action Review Form, of why a search warrant is the least intrusive means available for obtaining the evidence sought. To assist the SAC or DFO in determining whether the "least intrusive means" requirement has been met, Counsel’s memorandum should address whether there are other means available to obtain the records, _e.g._, whether the taxpayer would provide the records upon request, whether a summons or subpoena could be used to obtain the records, and whether the records could be obtained from a third party.



### Note:



If Criminal Investigation seeks to obtain the content of email communications from an ISP, Counsel’s analysis must reference IRS Policy Statement 4-120, which requires a warrant in such cases.


**38.1.1.3.2.1** **(05-25-2018)**

##### Content and Style

01. Although the content and even the style of the memorandum must be tailored to the case, it should contain the information discussed in this subsection.

02. Targets of Investigation/Premises to be Searched. This section contains the name and title of the target(s) of the investigation. Each of the premises to be searched should also be identified by street address. A separate CT CASE number should be listed for each location.

03. Counsel’s Recommendation. This section contains Counsel’s recommendation as to whether the affidavit and attachments establish probable cause to believe: (1) violations of federal law have been committed; (2) evidence of those violations will be found at the location(s) to be searched; (3) the location(s) and evidence to be seized are described with sufficient particularity; and (4) in tax and tax related investigations, the search warrant is the least intrusive means of obtaining the evidence sought.

04. Executive Summary. In a nutshell, summarize the target’s identity and alleged criminal conduct that gives rise to the anticipated criminal violations and the years involved. The Summary should also mention whether the investigation is administrative or grand jury and in the case of the sensitive search warrant, note that the search warrant package has been centralized with the Office of Division Counsel/ Associate Chief Counsel (Criminal Tax) per _CCDM 38.1.1.3.1(5)_.

05. Facts. Provide a brief description of the investigation to date, including the source of the investigation, background of the target, and alleged criminal conduct. The facts should tell a story and not be a verbatim copy of the affidavit. Discuss the principal evidence available to establish the criminal offense(s) and the nexus to the evidence sought.

06. Law and Analysis. Discuss the Fourth Amendment and relevant legal precedent surrounding the required probable cause determination and particularity requirement to support the execution of a search warrant. The discussion should include a detailed analysis of the following factors:



    1. Probable cause to believe a crime has been committed

    2. Probable cause to believe evidence of crimes will be found at the location(s) to be searched

    3. Staleness

    4. Particularity requirement as to the location(s) to be searched

    5. Particularity requirement as to the evidence to be seized


07. Electronic Evidence. Counsel’s memorandum should include a section setting forth the current law concerning the search and seizure of electronic evidence and electronic storage media, including internet storage providers (ISP). The memorandum should point out any issues with respect to the anticipated search. For example, the memorandum should include whether a multi-district search and/or seizure is appropriate. Pursuant to Rule 41(b)(6), magistrate judges may authorize warrants that allow federal agents to remotely access computers (and other devices) and to seize information stored on those computers, regardless of where the computers are physically located if either: (i) the computer user has used technology to hide the computer’s location in a computer hacking investigation; or (ii) if the affected computers are located in five or more judicial districts. In this case, federal agents may apply for a warrant in any of those districts.

08. Taint Team. If the location(s) to be search is owned or controlled by an accountant, attorney or physician, this section must address any potential privege or privacy issues and recommend the use of a taint team.

09. Notice of Search. Rule 41(f)(3) allows federal agents to request, and magistrate judges to authorize, delayed notice of the search, but only “if the delay is authorized by statute.” See 18 U.S.C. § 3103a (authorizing delayed notice in limited circumstances). The memorandum should discuss whether delayed notification is appropriate and set forth any delayed notification requests under Rule 41(f)(3).

10. Least Intrusive Means. The memorandum must set forth the IRS’ policy regarding the use of a search warrant in tax and tax-related investigations. The memorandum must then analyze the particular facts set forth in the Enforcement Action Review Form (Form 13739) to determine if the policy has been satisfied per IRM 9.4.9.2(5) and (6). If the items to be seized includes emails, include a reference to IRS Policy statement 4-120 and United States v. Warshak.

11. Conclusion. In this section note whether the probable cause, particularity, and (where appropriate) the least intrusive means standards have been satisfied.

12. Distribution of the Search Warrant Memorandum. The search warrant memorandum is distributed as follows:



    1. The original search warrant memorandum to the SAC (DFO in the case of a sensitive search warrant with copy to SAC).

    2. One copy of the search warrant memorandum to the Area Counsel (CT).


**38.1.1.3.2.2** **(06-27-2013)**

##### Non-Sensitive Search Warrants

1. For non-sensitive warrants, the field Criminal Tax attorney prepares a memorandum to the SAC discussing the merits of the warrant. Criminal Tax attorneys in the office of Associate Chief Counsel (CT) are available for consultation with field Criminal Tax attorneys, if desired.

2. A copy of the search warrant, exhibits, and memorandum is forwarded to the Area Counsel. The Area Counsel reviews, approves, and signs the advisory memorandum. (Criminal Tax attorneys who have been delegated signature authority may sign the memorandum and then forward a copy of the search warrant, exhibits, and memorandum to the Area Counsel).


**38.1.1.3.2.3** **(06-27-2013)**

##### Sensitive Search Warrants

1. For sensitive search warrants, the field Criminal Tax attorney prepares a memorandum to the Associate Chief Counsel (CT) discussing the merits of the warrant and transmits the memorandum and search warrant package to the Area Counsel .

2. The Area Counsel reviews, approves, and signs the memorandum and transmits the memorandum and complete search warrant package to the Associate Chief Counsel (CT).

3. The search warrant package consists of:



1. The field Criminal Tax attorney’s memorandum;

2. The draft search warrant and supporting affidavit (with related attachments);

3. A copy of Form 13739, Enforcement Action Review Form; and

4. A copy of the risk assessment for each specific location to be searched, if provided.


4. Once received by the office of Associate Chief Counsel (CT), the memorandum and search warrant package are reviewed, and an advisory memorandum to the appropriate DFO is prepared.

5. The Associate Chief Counsel (CT) reviews, approves and signs the advisory memorandum and transmits the memorandum and search warrant package to the appropriate DFO and Area Counsel.


**38.1.1.3.3** **(06-27-2013)**

#### Search Warrant Inventory Review for Tax and Tax-Related Search Warrants

1. After the execution of a tax or tax-related search warrant in which a special agent is the affiant, the field Criminal Tax attorney who reviewed the warrant package will review the inventory prepared by Criminal Investigation to determine whether the items seized were within the scope of the warrant and prepare a memorandum to the SAC.

2. If the Criminal Tax attorney identifies any issue with respect to the inventory or the scope of the seizure, he/she should consult with Criminal Investigation and the prosecutor involved in the investigation to discuss and resolve the issue. The Criminal Tax attorney should attempt to resolve any such issues prior to drafting the inventory review memorandum to the SAC. If any issues cannot be resolved by speaking with the case agent and the supervising prosecutor, the attorney should consult with his/her Area Counsel and the SAC prior to drafting the inventory review memorandum.

3. The Area Counsel will review, approve, and sign the inventory review memorandum. If signature authority has been delegated to the field Criminal Tax attorney who reviewed the warrant, the Area Counsel should be provided a copy of the memorandum for post review.


**38.1.1.3.4** **(06-27-2013)**

#### General Legal Guidance and Issues

1. The following is a suggested checklist for reviewing affidavits and warrants:



01. The premises to be searched should be described with specificity.

02. The items to be seized should be described as specifically as possible, and the relationship of any such items to the alleged violations should be explained in the affidavit.

03. The affidavit should be logically divided with paragraphs consecutively numbered.

04. The affidavit should incorporate by reference any diagrams, photographs or other exhibits that bear on probable cause.

05. The affidavit should set forth the affiant’s experience, describe the evidence supporting probable cause, and state that the affiant has probable cause to believe certain crimes have been committed and certain specified evidence of those crimes will be found at the location to be searched.

06. Affidavits should address the credibility and reliability of any informants.

07. If affidavits are based on undercover contacts, information relative to these activities should be made available for review.

08. The affidavit should identify all targets, the specific offenses for which there is probable cause, and the time frame of those offenses.

09. The affidavit should set forth a description of the unlawful activities in a factual (not conclusory) manner followed by a factual discussion of location of the evidence and its relationship to the crime. Permissible inferences supported by the recited facts and circumstances may be included in this discussion.

10. Information in the warrant should be corroborated with records, tax returns, and other documents to the extent appropriate.

11. If the location to be searched includes one or more computers, the affidavit should articulate a factual basis to believe that the computer was used for the creation and/or storage of evidentiary records and, if necessary, should explain why an on-site search is not possible. Appropriate safeguarding measures for computer searches should be described.

12. If the location to be searched is owned or controlled by an accountant, lawyer, or physician, the memorandum should discuss any potential privilege or privacy issues and recommend the use of a taint team.

13. The description of the place to be searched and the list of items to be seized should be physically attached to the affidavit, and the attachments should be incorporated into the affidavit by reference.



       ### Note:



       See Exhibit 38.3.1-1, Search Warrant Check Sheet


2. In some instances, evidence may be presented to the IRS by other federal agencies, or by state or local authorities that obtained the evidence through a search or arrest warrant, pen register, or wiretap. Counsel attorneys should evaluate the admissibility of such evidence before Criminal Investigation relies upon and includes the evidence in its search warrant affidavits.

3. Search warrant affidavits advancing a permeated-with-fraud theory should include a detailed discussion of the information supporting this theory.


**38.1.1.4** **(04-09-2020)**

### Undercover Assistance

1. **Approval of undercover operations**. Criminal Investigation engages in undercover operations for the purpose of securing information and/or evidence relative to an investigation. Undercover operations are classified as either Group I or Group II. All Group I undercover operations must be approved by the Chief, Criminal Investigation. Group II undercover operations are approved by the appropriate DFO.

2. **Group I Undercover Operations**. Group I undercover operations are those that exceed six months in duration and/or $50,000 in recoverable funds or involve one of the factors listed in IRM 9.4.8.3.1(2), Group I Undercover Operations. All Group I undercover requests are reviewed by the Undercover Review Committee, which sits at Criminal Investigation Headquarters in Washington, D.C. The Headquarters’ Undercover Review Committee is comprised of the Director, Operations Policy and Support (CI:OPS), the Director, Office of Special Investigative Techniques (CI:OPS:SIT), Associate Chief Counsel (CT) or delegate, and the Deputy Assistant Attorney General, Tax Division.

3. **Group II Undercover Operations**. Group II undercover operations are those that do not meet the requirements of a Group I undercover operation. The DFO is authorized to establish an Area Undercover Review Committee that includes the Area Counsel (CT), the Area Undercover Program Manager, and an Area Staff Analyst. The Area Undercover Review Committee is advisory in nature and recommends to the DFO approval or disapproval of initial undercover requests, as well as significant deviations from or extensions to ongoing undercover operations.

4. Criminal Investigation is required to consult Counsel in all undercover operations.

5. The Criminal Tax attorney’s role in an undercover operation is to render legal advice on all aspects of the operation, as well as attending all pre-operational and operational meetings. Counsel will prepare an undercover evaluation memorandum for the SAC, after reviewing and evaluating the Form 8354, Request for Undercover Operation. See Exhibit 38.3.1-12.


**38.1.1.4.1** **(04-09-2020)**

#### Content and Style of Undercover Evaluation Memorandum

01. Although the content and style of each memorandum must be tailored to the facts of the specific case, Counsel’s written undercover review should contain the information discussed in this subsection.

02. Criminal Subject(s)/Introductory Paragraph. This section should contain the name/title of the subject/target of the investigation, along with their address. When applicable, the address of where the undercover operation will occur should be listed. The undercover operation should be identified as Group I or Group II, as well as the category under which it falls. The paragraph should state whether the proposed operation meets/does not meet the requirements of IRM § 9.4.8.4(3)(a). Additionally, whether or not the operation raises an issue of entrapment should be stated. If the proposed operation raises an issue of entrapment, add an explanatory sentence, e.g. the evidence fails to establish that the target was predisposed to commit this crime as well as any other noteworthy concerns.

03. Scope of CT Review. This section should state that IRS-CI is required to consult Counsel in all undercover operations. It should also state Counsel’s role is to render legal advice on all aspects of the operation, as well as to attend all pre-operational and operational meetings. _CCDM § 38.1.1.4(4)_ and _CCDM § 38.1.1.4(5)_.

04. Standard of Review. This section should mention that Counsel must determine whether the information obtained to date would lead a reasonable person to believe the target is in violation of the law. IRM § 9.4.8.4(3).

05. Executive Summary. The Executive Summary should provide a succinct summary of the case, including the identity of the target, a description of the criminal conduct that gives rise to the anticipated criminal violations, and the years involved.

06. Facts. This section should provide a fact neutral description of the investigation to date, avoiding legal conclusions and/or verbatim copying of IRS-CI’s Undercover Memorandum. This section should specifically identify the origin/source of the case, the source of the information on which the undercover operation is to be based, and whether the target is represented by counsel. If the source of the case is a confidential informant, address the informant’s trustworthiness, past criminal history, and corroboration of information provided. Additionally, this section should include whether the informant will be compensated, the potential need for an MOU; and, if the informant has criminal exposure, whether or not those issues have been resolved, e.g., through a written cooperation agreement. Also, if applicable, discuss whether the information provided is tainted, e.g., attorney-client privilege. Provide background information of all applicable individuals/entities involved in the investigation. Insert subsections to enhance the presentation of factual details, if necessary.

07. Targeting Criteria. This section should indicate whether the proposed undercover operation meets the pre-approved Targeting Criteria for the specific type of undercover operation.

08. Proposed Operation. This section should describe the proposed undercover operation and identify a clear alignment between the crime articulated and the proposed plan of action. This is to insure IRS-CI does not engage in indiscriminate surveillance. The specific criminal code sections IRS-CI believes the target has violated should be stated. When applicable, discuss undercover equipment to be used and whether a confidential informant will be used, noting the individual’s role, if any, in the scheme. Additionally, note whether using that individual could jeopardize the operation and/or investigation.



    1. If there is a possibility the target(s) of the operation may be involved in terrorism, note that IRS-CI should run the target’s names(s) through a terrorist watch list and coordinate as necessary with other intelligence agencies to insure funds are not transacted with a known terrorist organization.

    2. If the case presents international issues, confirm that all appropriate approvals and authorizations have been obtained, to include consensual monitoring authority. If necessary, discuss caselaw on international operations. For example, does the target have U.S. status that would entitle him or her to constitutional protections? Is this a joint operation with foreign law enforcement?

    3. Identify any contracts that should be reviewed by GLS and/or CT if operationally feasible.


09. Objectives. This section should list the objective of the undercover operation provided in IRS-CI’s Undercover Memorandum. If too many objectives are listed, suggest narrowing the operation to meet fewer objectives. Make sure the plan of action aligns with the objectives of the operation.

10. Analysis. This section should address the Reasonable Person Standard of Review and Entrapment.



    1. Analyze whether or not the information presented by IRS-CI’s Undercover Memorandum would lead a reasonable person to believe that the target is in violation of the law. State this conclusion and the supporting facts. Discuss information provided by any confidential informants or cooperating witnesses. If we do not believe the evidence satisfies the reasonable person standard, our inquiry should end.

    2. Undercover operations have long been sanctioned by the courts. The entrapment defense is a judicially created doctrine. _United States v. Diaz-Maldonado_, 727 F.3d 130, 139 (1st Cir. 2013) (quoting _United States v. Teleguz_, 492 F.3d 80, 84 (1st Cir. 2007)). Therefore, the doctrine must take into account the difficulties faced by law enforcement. _Id._ Predisposition to commit the crime is primary legal issue. In entrapment cases, courts draw the line between undercover operations to ensnare criminals and undercover operations to ensnare innocent citizens.



       > • Insert circuit specific entrapment law and analyze the multi-factor test.





       > • Address whether the target was predisposed to commit the crime. Include any evidence indicating the target knows his or her conduct is illegal.


11. _Brady, Giglio_ and Other Evidentiary Issues/Suggestions. This section should analyze the undercover operation from an evidentiary perspective. Counsel should consider how likely the operation is to generate _Brady/Giglio_ material. Those considerations should be balanced with the probative value of any evidence generated by the undercover operation. This section should also address any other issues that are presented or may arise in the undercover operation. This is not to suggest that by advising against an undercover operation the intent is to deprive the target of his rights to present exculpatory material in good faith. The _Brady/Giglio_ analysis referenced here typically comes into play when there is reason to believe that a crime has been committed, but based upon the plan of action, there is a risk that the target will make false exculpatory statements.

12. Conclusion. In this section, clearly state Counsel’s opinion as to whether the proposed undercover operation is legal/not legal, whether it raises/does not raise any issues of entrapment and whether it satisfies the reasonable person standard. If the proposed operation raises an issue of entrapment, repeat the explanatory sentence from the beginning of the memo. Include a request that Counsel be notified of any pre-operational meetings.


**38.1.1.5** **(08-11-2004)**

### Electronic Surveillance

1. This subsection discusses authorization of assorted types of electronic surveillance under various statutes.


**38.1.1.5.1** **(06-27-2013)**

#### Non-Consensual Monitoring of Wire/Oral Interception

1. Under 18 U.S.C. § 2516 (Title I), courts may authorize electronic interception of the contents of wire and oral communications during the investigation of specific criminal offenses, which are listed in the statute.



### Note:



This statute does not authorize the interception of wire and oral communications for Title 26 violations.

2. Statutes and IRS policy prohibit non-consensual monitoring of oral and wire communications for Title 26 purposes; however, the Service may receive Title I information. Law enforcement officers who obtain wiretap evidence are permitted to turn such evidence over to other law enforcement officers for the latter’s use and special agents are considered investigative or law enforcement officers to whom information may be disclosed. Law enforcement officers are permitted to use wiretap evidence in their official duties, such as issuing summonses, investigating tax offenses or preparing special agent reports. 18 U.S.C. § 2517.

3. Law enforcement officers are also permitted to use the evidence in a grand jury, in court or any other proceeding, or they may disclose it via testimony. Prior to such use, however, the law enforcement officers must obtain a derivative use order that must be based upon the court’s finding that the evidence of the nonspecified crime ( _i.e._, tax offense) was otherwise (or properly) intercepted. Failure to obtain such an order can result in dismissal of the case or liability for civil damages due to unauthorized disclosure. The derivative use order should be obtained as soon as practicable.

4. The Criminal Tax attorney reviews the validity of the Title I order and so advises the SAC in a memorandum. The US Attorney’s office obtains the appropriate derivative use order for Criminal Investigation.


**38.1.1.5.2** **(06-27-2013)**

#### Electronic Communications

1. An electronic communication is any transfer of signs, signals, writing, images, sounds, data, or intelligence of any nature transmitted in whole or in part by a wire, radio, electromagnetic, photoelectronic, or photooptical system that affects foreign or interstate commerce. _See_ 18 U.S.C. § 2510(12). Electronic communications do not include wire or oral communications, communications through a tone-only paging device, communications from a tracking device, or electronic funds transfer information stored by a financial institution. Examples of electronic communications include communications through digital/display pagers, electronic mail (email), and fax transmissions.

2. Section 2516(3) of Title 18 of the United States Code allows for the interception of electronic communications when such interception may provide or has provided evidence of any federal felony, including Title 26 offenses. To intercept such communications, electronic communication intercept orders must be based upon an application and an affidavit. The Criminal Tax attorney evaluates these affidavits for factual and legal sufficiency and prepares a memorandum for review by the Area Counsel. Once the Area Counsel approves the memorandum, it must be forwarded to the Associate Chief Counsel (CT) for final approval and signature. Once signed by the Associate Chief Counsel (CT), the memorandum will be returned to the Area Counsel for dissemination to Criminal Investigation.

3. To ensure uniformity, applications for the interception of fax transmissions and pagers must be approved by the same DOJ officials who approve wire and oral interception applications and must comply with the procedures provided in 18 U.S.C. § 2518. Consequently, applications for pagers and facsimile transmissions should be coordinated through the office of Associate Chief Counsel (CT).


**38.1.1.5.2.1** **(06-27-2013)**

##### Stored Electronic Communications

1. Stored electronic communications include the content of wire or electronic communications, as well as subscriber or customer records, which are held in electronic storage by an electronic communication service provider ( _e.g._, an internet service provider or ISP). Stored electronic communications also include the contents of wire or electronic communications, as well as subscriber or customer records, which are held by a remote computing service provider for the purpose of providing storage or computer processing services.

2. Title 18 U.S.C. § 2703 provides procedures for obtaining stored electronic communications from service providers. However, when seeking to obtain the content of email communications from ISPs, IRS Policy Statement 4-120 must be followed ( _see_ _CCDM 38.1.1.5.2.2_).


**38.1.1.5.2.2** **(06-27-2013)**

##### Obtaining Content of Email Communications from Service Providers

1. Pursuant to IRS Policy Statement 4-120, the IRS will obtain a search warrant in all cases when seeking from an ISP the content of email communications stored by the ISP.

2. When Criminal Investigation is the affiant on a non-sensitive search warrant seeking the content of email communications from an ISP and/or any other form of stored electronic communication, the field Criminal Tax attorney and/or Area Counsel will review the affidavit for legal sufficiency and prepare a memorandum to the SAC discussing the merits of the warrant. _See_ _CCDM 38.1.1.3.2.1_. Any such search warrants characterized as sensitive under _CCDM 38.1.1.3.1(5)_ must be forwarded to the office of Associate Chief Counsel (CT) for review and preparation of a memorandum to the DFO. _See_ _CCDM 38.1.1.3.2.2_.


**38.1.1.5.3** **(06-27-2013)**

#### Consensual Monitoring

1. **Definition**. Consensual monitoring occurs when at least one party to a conversation agrees to have the conversation monitored using a device, such as a body bug, telephone bug (suction cup), room bug, or video bug. Because a party to the conversation consents to the recording of it, this activity does not implicate Title I. Consensual monitoring can take two forms: telephonic and non-telephonic. Neither form requires a court order, but prior DOJ or US Attorney approval is required.

2. **Full Consent**. If all participants consent to monitoring, authorization is unnecessary, regardless of whether it is telephonic or non-telephonic monitoring. See IRM 9.4.7, Consensual Monitoring.

3. **Partial Consent**. In telephonic and non-telephonic monitoring, if less than all participants consent to the monitoring, authorization must be obtained. See IRM 9.4.7, Consensual Monitoring.

4. **Telephonic Monitoring**. A Form 8041, Request for Authorization to Use Electronic Equipment and Consensual Monitoring, is used to request approval for telephonic monitoring. The request must be in writing before authorization is granted; however, if time does not permit, the request may be oral, with Form 8041 being submitted at the earliest practical time. The SAC has the authority to approve the requests and this authority may not be delegated. The Criminal Tax attorney will assist Criminal Investigation personnel when questions arise and review for legal sufficiency.

5. **Non-telephonic Monitoring**. To obtain authorization for non-telephonic monitoring, requests must be in writing on Form 8041. Oral requests are allowed if there is a bona fide emergency, but these must be confirmed in writing within two working days after the oral request is made. The form must note approval by an attorney for DOJ or the US Attorney’s office, along with his/her name and position. The Criminal Tax attorney will assist Criminal Investigation personnel when questions arise and review for legal sufficiency.


**38.1.1.5.3.1** **(06-27-2013)**

##### Use of Electronic Tracking Devices

1. Electronic tracking devices ( _e.g._, Global Positioning System or GPS devices) may be used to monitor the physical whereabouts of a person, vehicle, or other item to which the device is attached.

2. Electronic tracking devices may be used in any case where Criminal Investigation has jurisdiction, but only if:



1. The person to be monitored, or the person in lawful possession of the vehicle or other item to be monitored consents to the installation of the device; or

2. Installation of the electronic tracking device is authorized by a search warrant.


3. The SAC, with the concurrence of the local U.S. Attorney, may authorize consensual use of electronic tracking devices. The Criminal Tax attorney may assist Criminal Investigation personnel and review the request for legal sufficiency.

4. With the SAC’s approval, a special agent may apply for a search warrant authorizing the non-consensual installation of an electronic tracking device. Counsel will review the affidavit in support of the search warrant application for legal sufficiency and will prepare a memorandum to the SAC (or to the DFO for sensitive warrants) discussing the merits of the warrant. _See_ _CCDM 38.1.1.3.2_.

5. The law permits a federal court to issue a warrant for electronic tracking devices authorizing their use even outside of the jurisdiction in which the device was installed. This will permit monitoring as the subject moves from district to district inside or outside the United States without reapplying for a separate warrant for each jurisdiction. _See_ 18 U.S.C. § 3117.


**38.1.1.5.3.2** **(08-11-2004)**

##### Pen Registers and Trap and Trace Devices (Grabbers)

1. A pen register is a mechanical device that is attached at a telephone junction box and records the actual numbers called (outgoing) from a particular line. In addition to recording the numbers called, a pen register is capable of recording the date, time and duration of each call. A trap and trace device (grabber) is a technique whereby the telephone company uses a switching system or facility to identify the source (telephone number) of an incoming call. Of course, the date, time and duration of the call can also be recorded by the telephone company. _See_ 18 U.S.C. §§ 3121 through 3126.

2. Pen registers and trap and trace devices (grabbers) may be used by Criminal Investigation as investigative tools only when authorized by court order in cases involving felony violations and in wagering tax investigations. Pen registers and other types of telephone number recorders will not be used in investigations involving misdemeanor violations (other than wagering cases), such as altered documents cases under IRC § 7207 and general program cases, such as investigations of Questionable Refund Programs cases.


**38.1.1.6** **(06-27-2013)**

### Summonses

1. Special agents have been delegated authority as individuals before whom a summoned person shall appear. Pursuant to this authority, special agents may take testimony under oath of the person summoned, set the time and place of examination, and receive and examine data produced in compliance with the summons.

2. Assistance to special agents in the summons process should focus on the _Powell_ requirements. _United States v. Powell_, 379 U.S. 48 (1964). These provide that to be enforceable every summons must meet the following basic test for validity:



1. Issued for a legitimate purpose;

2. Seeks information that "may be relevant" to the investigation;



      ### Caution:



      For third party summonses, the Service must establish a nexus between the third party and the taxpayer.

3. Seeks information that is not already in the Service’s possession; and

4. All administrative steps required by the Code have been followed.


3. Counsel retains referral authority for summons enforcement matters. These matters should be coordinated as necessary with the office of Associate Chief Counsel (Procedure & Administration). See CCDM 34.6.3, Summons Enforcement Actions, and the Summons Handbook, beginning with IRM 25.5.1, Summons - Introduction, for additional assistance.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part38/irm_38-001-001#addtoany "Show all")

A2A