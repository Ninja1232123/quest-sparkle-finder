---
url: "https://www.irs.gov/irm/part30/irm_30-004-003"
title: "30.4.3 Training and Communication | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part30/irm_30-004-003#main-content)

- 30.4.3 [Training and Communication](https://www.irs.gov/irm/part30/irm_30-004-003#idm140128567329024)
  - 30.4.3.1 [Training](https://www.irs.gov/irm/part30/irm_30-004-003#idm140128556556000)

    - 30.4.3.1.1 [Core Curricula](https://www.irs.gov/irm/part30/irm_30-004-003#idm140128572651600)

      - 30.4.3.1.1.1 [Legal Curriculum](https://www.irs.gov/irm/part30/irm_30-004-003#idm140128557342336)
      - 30.4.3.1.1.2 [Management Curriculum](https://www.irs.gov/irm/part30/irm_30-004-003#idm140128552510416)
      - 30.4.3.1.1.3 [Support Staff Curriculum](https://www.irs.gov/irm/part30/irm_30-004-003#idm140128554831616)

    - 30.4.3.1.2 [Types of Training](https://www.irs.gov/irm/part30/irm_30-004-003#idm140128574949056)
    - 30.4.3.1.3 [Training Needs Assessment](https://www.irs.gov/irm/part30/irm_30-004-003#idm140128580025488)

      - 30.4.3.1.3.1 [Planning and Process](https://www.irs.gov/irm/part30/irm_30-004-003#idm140128564727904)
      - 30.4.3.1.3.2 [Evaluation of Training Programs](https://www.irs.gov/irm/part30/irm_30-004-003#idm140128587936960)
      - 30.4.3.1.3.3 [Testing](https://www.irs.gov/irm/part30/irm_30-004-003#idm140128552464944)
      - 30.4.3.1.3.4 [Nomination and Selection Process](https://www.irs.gov/irm/part30/irm_30-004-003#idm140128556703088)

    - 30.4.3.1.4 [The National Training Advisory Board](https://www.irs.gov/irm/part30/irm_30-004-003#idm140128559422320)
    - 30.4.3.1.5 [Role and Responsibilities of Managers](https://www.irs.gov/irm/part30/irm_30-004-003#idm140128556125104)

      - 30.4.3.1.5.1 [Determine the Developmental Needs of Employees](https://www.irs.gov/irm/part30/irm_30-004-003#idm140128564525328)

        - 30.4.3.1.5.1.1 [Training Plan](https://www.irs.gov/irm/part30/irm_30-004-003#idm140128552994368)

      - 30.4.3.1.5.2 [Determine the Availability and Types of Training](https://www.irs.gov/irm/part30/irm_30-004-003#idm140128587795648)
      - 30.4.3.1.5.3 [Monitor and Evaluate the Results of Training Programs](https://www.irs.gov/irm/part30/irm_30-004-003#idm140128556554624)

    - 30.4.3.1.6 [Out-Service Training](https://www.irs.gov/irm/part30/irm_30-004-003#idm140128554840208)

      - 30.4.3.1.6.1 [Approving and Processing the SF 182](https://www.irs.gov/irm/part30/irm_30-004-003#idm140128564765344)

  - 30.4.3.2 [Widely Attended Gatherings](https://www.irs.gov/irm/part30/irm_30-004-003#idm140128576256528)

    - 30.4.3.2.1 [Factors to Consider](https://www.irs.gov/irm/part30/irm_30-004-003#idm140128570650528)
    - 30.4.3.2.2 [Free Attendance](https://www.irs.gov/irm/part30/irm_30-004-003#idm140128561497024)
    - 30.4.3.2.3 [Payment of Expenses](https://www.irs.gov/irm/part30/irm_30-004-003#idm140128550818672)

# Part 30. Administrative

# Chapter 4. Personnel Administration, Training, and Equal Employment Opportunity

# Section 3. Training and Communication

* * *

## 30.4.3 Training and Communication

**30.4.3.1** **(12-09-2008)**

### Training

1. This section establishes policy and procedures for training within the Office of Chief Counsel.

2. A high quality, well trained workforce is critical to successful accomplishment of our mission. Counsel's goal is to provide training that is meaningful, relevant, timely, challenging, and provides all employees with the skills they need to perform their job to their maximum potential.

3. Managers at all levels are responsible for supporting the training program and ensuring that their employees receive the training they need. Managers are assessed on their responsibility to identify and provide training for their subordinates. Training responsibilities are included in goals and are evaluated in the management portion of the LD-2, CC/IRS Performance Appraisal Form.

4. Training in its broadest sense includes any education conducted in a variety of formats, i.e., classroom, video, technology-based, teleconference, on-the-job, web streaming, that clearly relates to and enhances an employee's skills, knowledge, and ability to perform their job.

5. The Human Resources Division, under the direction of the Associate Chief Counsel (Finance and Management), is responsible for ensuring that the training policy of the organization is adequately promoted and supported. Key responsibilities of the Division include:



1. Conducting an ongoing assessment of Counsel training needs, including providing support and guidance to the National Training Advisory Board (see CCDM 30.4.3.1.4)

2. Managing all nationally-sponsored training programs

3. Providing advice to managers on employee development

4. Using team development techniques to assist work groups to improve performance, relationships, or attempt to resolve conflicts


**30.4.3.1.1** **(02-17-2006)**

#### Core Curricula

1. The primary purpose of the core curricula is to better target our training by addressing the key skills and knowledge needed by our attorneys, and the developmental activities, skills and knowledge that are needed by managers and executives. The curriculum is designed so that each attorney, manager and executive progresses sequentially through three levels of learning.


**30.4.3.1.1.1** **(02-17-2006)**

##### Legal Curriculum

1. The three basic areas of the legal curriculum are:



   - Fundamental skills sets

   - Core skills

   - Specialized skills


2. These areas focus on basic attorney skills, expertise and knowledge required for working in a specific functional area, or specialized skills which relate to a particular area or issue in tax law. For instance, the fundamental skills sets area contains programs in advocacy and oral presentation, courtroom skills, legal and brief writing, and negotiation skills. The core skills area focuses on program areas such as tax litigation, general litigation, criminal tax, disclosure, and general legal services. The third area, specialized skills, focuses on fairly narrow areas, such as bankruptcy, employee plans, and international.

3. The basic attorney training programs currently provided to newly hired field and National Office attorneys serve a vital role in developing the attorneys' ability to perform at the full working level as early as possible in their careers in the Office of Chief Counsel. These basic programs are:



   - New Attorney Orientation

   - General Litigation Part 1 and 2 (includes bankruptcy)

   - Trial Advocacy Attorney Training

   - General Legal Services Training

   - Legal Writing


4. To ensure that these early training needs are met, and to ensure that training is relevant, effective and efficiently administered, attorneys should be trained in the basic functional area(s) where they will spend a very substantial part of their time. This training should be scheduled within the first 18 months of employment to the extent that courses are available. When an experienced attorney is assigned work in another function and needs the basic training in that area, he/she may be nominated to attend that program.


**30.4.3.1.1.2** **(02-17-2006)**

##### Management Curriculum

1. The basic areas in the Management Curriculum are:



   - Fundamental supervisory skills

   - Developmental managerial skills

   - Executive skills


2. These areas focus on basic management and supervisory skills, continuing management education, and executive and leadership development.

3. The programs included in the fundamental supervisory skills are primarily an introduction to management and leadership. Overall, new managers are exposed to such topics as evaluating employees, counseling employees, and personnel issues.

4. The developmental managerial skills area focuses on providing training in areas such as communications, coaching, change, and leadership. These courses are designed to provide managers with on-going training to enhance their skills.

5. The executive and leadership skills area primarily addresses strategic planning, executive coaching skills, systems thinking, and creating one learning organization. Although many of these seminars and programs are concerned with broad organizational issues, they are also intended to provide continuing leadership development.


**30.4.3.1.1.3** **(12-09-2008)**

##### Support Staff Curriculum

1. The basic areas in the Support Staff Curriculum are:



   - Basic administrative/technical skills for all support staff and office managers

   - Supervisory skills for office managers and administrative officers


2. Basic administrative/technical training is conducted on topics such as:



   - Legal briefs

   - File organization

   - Guidebooks

   - Teamwork

   - General operator training


3. Office managers and administrative officers receive additional training on basic supervisory and management skills on topics such as evaluating and counseling employees as well as team building and personnel issues.

4. Training is conducted through a variety of formats including traditional classroom, video, technology-based and on-the-job training.


**30.4.3.1.2** **(03-01-2011)**

#### Types of Training

1. The Office of Chief Counsel provides a variety of training opportunities. All of these opportunities are intended to enhance the skills, knowledge, and abilities of an employee in the current job.

2. Chief Counsel Sponsored-training is offered through the Training and Communications Branch. These programs are targeted for various groups of employees, including attorneys, paralegals, and managers and executives. Chief Counsel sponsored programs are announced at the beginning of each fiscal year through the Training and Communication Web site at least six to eight weeks prior to the beginning of a program. The method of delivery for Chief Counsel courses range from the traditional classroom, Interactive Video Telecast (IVT), web streaming or CD/ROM.

3. IRS Sponsored-training is offered separately by the IRS. These programs are offered on an ad hoc basis throughout the year. Specific information regarding the various programs can be obtained on the IRS Web site. The IRS also contracts for e-learning classes.

4. Continuing Professional Education (CPE) consisting of educational and substantive tax law courses are presented in the National Office and selected programs offered via satellite broadcast to all locations. The programs are available to Counsel attorneys, IRS employees, State and other Federal Agencies. A variety of courses are taught each year. Some of these specialized courses are also sometimes offered for LL.M. (Taxation) credit in a cooperative venture with various universities. Information regarding the CPE program can be obtained through the Training and Communications Branch.

5. Nationwide Continuing Legal Education (CLE) symposiums are managed and coordinated by the Training and Communications Branch. Staff members work with designated business unit employees to determine locations, develop the agenda, course materials, visual aids, etc. The Training Branch also manages the process of obtaining CLE pre-accreditation and paying any applicable fees for these nationally sponsored programs. Each attorney is still responsible for seeking and maintaining individual bar memberships by filing appropriate applications with the State bars.

6. Out-service-training is provided by outside vendors or contractors, e.g., American Bar Association, National Institute of Trial Advocacy. Topics range from substantive tax law to various procedural issues. Interest in these programs is identified through each Division Counsel office and/or Associate Chief Counsel Area.

7. On-the-Job-Training is provided through each individual office. This includes shadow assignments, developmental assignments, and other forms of training obtained through on-the-job activities.


**30.4.3.1.3** **(02-17-2006)**

#### Training Needs Assessment

1. Appropriate and periodic training is an essential and integral part of development and maintenance of a capable and qualified workforce. It is, therefore, imperative that the Office of Chief Counsel timely and accurately assess training needs to maintain short-term and long-term staffing and planning goals.


**30.4.3.1.3.1** **(02-17-2006)**

##### Planning and Process

1. The identification of training needs should first start with the identification of the knowledge, skills, and abilities (KSA) required for maximum effectiveness in all positions. Once KSAs are identified, a manager should assess what KSAs are required to reach maximum effectiveness. When identifying ways to acquire needed KSAs, it is important to examine both training and non-training approaches.

2. The Training and Communications Branch, in conjunction with the National Training Advisory Board, annually conducts an assessment of training needs. This assessment, in the form of a survey, is sent directly to all Division Counsel and Associate Chief Counsels in the July/August time frame. The survey is intended to assess the needs for training in various areas for the upcoming fiscal year. All course proposals are based on historical precedent as well as recommendations from various program managers and functional sponsors.

3. Once the survey is completed, it is then analyzed and presented to both the National Training Advisory Board and the Associate Chief Counsel (Finance & Management). A training plan is then proposed based on identified needs and budget projections. A final training plan is developed during the later part of September each year.


**30.4.3.1.3.2** **(02-17-2006)**

##### Evaluation of Training Programs

1. All Chief Counsel Training Programs are evaluated by the students, instructors, and program manager. The purpose of the evaluation is to ensure that the subject matter was effectively delivered, both substantively and in terms of good presentation techniques.

2. The first level of evaluation is conducted at the conclusion of the program through a Level I evaluation, and is designed to assess the content of the course as well as the individual performance of the instructors.

3. In addition, a Level II evaluation is conducted three months after the conclusion of a program. The primary purpose of the Level II evaluation is to assess both the student's and manager’s perspectives on how much of what was taught is actually being used on the job.


**30.4.3.1.3.3** **(12-09-2008)**

##### Testing

1. The Office of Chief Counsel has a long history of using tests in training classes. Hundreds of National Office attorneys have been tested upon completion of CPE courses. With the expanded availability of these courses through Counsel's Distance Learning Program on the IRS Satellite Network, several hundred field attorneys have also taken tests at the conclusion of CPE courses. The testing policy outlined below expands the current Counsel CPE testing policy to other Counsel courses.

2. When appropriate, all courses more than three days in length will contain a test. The decision about the feasibility of testing will be made jointly by the course developers, the functional sponsors, and the training staff. In some cases, there may be both a pre- and post-course test. This will better measure achievement in the course, given the differing levels of knowledge and experience students bring to a given course.

3. Programs in which testing would be appropriate include:



1. Basic attorney training programs such as Trial Advocacy Skills Training, General Litigation Attorney Training, and Basic Criminal Tax Training

2. Substantive intermediate training programs such as Bankruptcy Practice Seminar

3. Skills training programs such as Instructor Training


4. Programs in which testing would not be appropriate include:



1. Sessions such as Advanced Bankruptcy Practice Roundtable, Criminal Tax Symposium and International CPE

2. Classes lasting fewer than three days


5. The term "test" can refer to a variety of methods of evaluating the success of the course and the performance of the students. This may include, but is not limited to, written examination, application of case studies, presentation of written papers, or performance-based exercises such as role plays, mock trials, or practice presentations.

6. Course instructors are responsible for assessing student performance on any test. Student performance should be assessed against the objectives of the course, i.e., did the student successfully demonstrate achievement of the course objectives?

7. Training staff members are responsible for assisting course developers with the development of testing components; they are also responsible for assisting instructors with the methodology for assessing student performance.

8. Results of any test will be used in the following ways:



1. Each student will receive performance results on a pass, fail or superior scale. In general, the rating of superior should reflect outstanding performance and should be limited to no more than 10% of the total number of students in a class.

2. The testing results for all students will be compiled, without identifying information, and will be used by the instructors to assess overall accomplishment of objectives and by the training office to assess the overall effectiveness of the course.

3. Results of student performance on a test will be one aspect of employee performance that, along with others, may be taken into account in assessing employees.


9. Course announcements will indicate whether or not a test is required.


**30.4.3.1.3.4** **(02-17-2006)**

##### Nomination and Selection Process

1. All training programs sponsored by the Training and Communications Branch are advertised on the Training Web page of the Chief Counsel Intranet site during the first quarter of the fiscal year. The Web site outlines all the programs that are identified as having the highest priority through the needs assessment, and provides a description and target date for each program. Courses are displayed in a variety of formats including a calendar format that lists training opportunities for each month.

2. Individual programs are announced on the Web site six to eight weeks prior to the program and an e-mail notification of the announcement is sent to all employees. The course announcement contains a general description of the program, the target audience, dates, and location of the training.

3. Registration for all training programs is done on-line through the Training web site. Manager’s approval is required. The employee and manager receive confirmation via e-mail of their registration (request to take the training). The registrants’ names are provided to the training contacts and final selections for attendance are made by the business unit.

4. Employees not selected for the training are notified by the business unit. Selected employees are notified by the Training Office through written reporting instructions. The reporting instructions contain administrative information regarding the program, an agenda, and participant roster.

5. Any specific concerns regarding a program, as well as any changes in the participant roster should be directed to the program manager.


**30.4.3.1.4** **(03-01-2011)**

#### The National Training Advisory Board

1. The National Training Advisory Board (NTAB) is an executive group which meets one or two times per year to:



1. Ensure that training efforts move the organization towards its mission and its goals

2. Review the results of the annual needs assessment survey to make recommendations on the relative priority of Counsel training classes, both in terms of balancing priorities among functions and among categories of employees within the organizations

3. Consider and make recommendations on many of the difficult issues encountered in the training arena, such as how to select the best faculty, the successful accomplishment of employee development goals, and the effectiveness of testing

4. Provide periodic assessment of the overall effectiveness of Counsel’s training program


2. The NTAB serves in an advisory capacity to the Deputy Chief Counsels for Operations and Technical. It is chaired by the Associate Chief Counsel (Finance and Management).

3. Permanent members of the Board include the Chairman and representatives from:



   - Division Counsel (Small Business/Self-Employed)

   - Division Counsel (Large Business and International)

   - Associate Chief Counsel (Procedure and Administration)

   - Associate Chief Counsel (International) (who also represents Passthroughs and Special Industries, Income Tax and Accounting, Corporate, and Financial Institutions and Products)

   - Associate Chief Counsel position that is rotated annually among Criminal Tax, General Legal Services and Tax Exempt and Government Entities


**30.4.3.1.5** **(02-17-2006)**

#### Role and Responsibilities of Managers

1. The development of employees to their maximum potential is one of the prime responsibilities of a manager. This includes providing the means for employees to develop the skills necessary to perform their job and provide an opportunity for employees to advance within the organization. The manager is responsible for identifying training needs of employees and providing direction and guidance for new employees. The manager should initiate training programs in the office, include employees in training provided by the Training and Communications Branch, as well as appropriate IRS Training Programs.

2. Key responsibilities of managers include:



1. Determining the developmental needs of new and experienced employees

2. Determining availability and types of training to meet the needs of the individual employee

3. Monitoring and evaluating the results of training programs that employees have attended. This includes the completion of a Level II evaluation for Chief Counsel sponsored programs.


**30.4.3.1.5.1** **(12-09-2008)**

##### Determine the Developmental Needs of Employees

1. The process of determining the developmental needs of employees includes:



   - Making a list of essential knowledge, skills, and abilities (KSAs) for each type of position in the office

   - Identifying individual training needs of each employee on the basis of performance evaluations and interviews

   - Planning specific training to meet the needs of each employee


2. It is important for managers to differentiate between the needs of new employees and experienced employees. The new employee and the experienced employee have different training needs and require different levels of supervisory controls.

3. With the new employee, the focus should be on orienting the employee to the Office of Chief Counsel, including the mission of the Office, the relationship with Treasury, IRS, Department of Justice, and the U.S. Tax Court, the organizational structure of the Office (including who's who), and office procedures. In addition to new employee orientation sessions, it is important to provide every opportunity for success for new employees and to develop the skills required in the employee's KSAs. These training opportunities can include the following:



   - Developmental assignments

   - Appointing a senior employee as a mentor to the new employee

   - Attending conferences and/or court appearances with employees

   - Providing input on their performance


4. For the experienced employee, the training emphasis should be on developing advanced and specialized skills as well as career advancement. It is also important that experienced employees be encouraged to develop independence and autonomy. In addition to the advanced training programs offered by the Training and Communications Branch, opportunities for researching and presenting in-house seminars on topics of special interest to the office and acting assignments should be considered as enhancement opportunities.


**30.4.3.1.5.1.1** **(12-09-2008)**

###### Training Plan

1. Managers should consider having each employee prepare a training plan as a guide to use in meeting the employee's training needs. It is important that both the manager and the employee work together on designing and implementing the elements of the training plan and that the training plan is reviewed annually. A training plan contains the following elements:



   - Long term goal(s)

   - Short term goal(s)

   - Objectives

   - Activities to meet the goals and objectives


### Note:

Activities include on-the-job training (OJT), developmental activities, and formal training.

**30.4.3.1.5.2** **(02-17-2006)**

##### Determine the Availability and Types of Training

1. There are a variety of training opportunities available to employees of the Office of Chief Counsel. This information is outlined under CCDM 30.4.3.1.2, Types of Training.

2. It is the manager's responsibility to ensure that not only do employees receive training in order to effectively perform their job assignment, but also that the proper employees attend particular training programs. CASE (Counsel Automated Systems Environment), reviewing employee caseloads, and new work assignments can all be used to determine which employee(s) to send to training. CASE is particularly useful in determining how much time an employee is spending on the subject matter of available training programs.


**30.4.3.1.5.3** **(02-17-2006)**

##### Monitor and Evaluate the Results of Training Programs

1. It is important for the manager to discuss expectations before the employee attends a training program. This would include any new job assignments or responsibilities that the employee would receive after the training.

2. The manager should meet with the employee after training to discuss the experience and raise any questions or concerns regarding the training. At this time the manager should provide any evaluative information and reinforce any remaining expectations.


**30.4.3.1.6** **(03-01-2011)**

#### Out-Service Training

1. This subsection specifies the general requirements for requesting training conducted by an organization other than the IRS, and applies to all employees of the Office of Chief Counsel.

2. Employees must receive prior written approval to attend any type of non-IRS-conducted training, conference, or tax institute at Government expense. This approval is obtained by submitting a separate SF 182, Request, Authorization, Agreement, and Certification of Training for each individual for whom training is desired.

3. The use of the SF 182, instead of a contract, is authorized to obtain non-IRS (non-Counsel), off-the-shelf training courses provided that the cost of a single training event does not exceed the simplified acquisition threshold of $100,000. The cost of the training must be of a fixed nature, (i.e., price per student or price per course, program, or service). The SF 182, or other authorized training form, should be used to request and approve such training, including seminars and conferences provided by either government (e.g., Treasury, Agriculture, General Services Administration, etc.) or non-government (i.e., private sector) vendors. The authority to approve SF 182s is assigned to those positions to which Delegation Order 6-10 delegates the authority to approve the selection and assignment of employees to training. _See_ IRM 1.2.45.11.

4. Out-Service training should not be requested when a Chief Counsel or IRS course (self-study or otherwise) can reasonably provide the training required.

5. Employee attendance at non-IRS training/conferences requires official approval. No enrollment arrangements may be made prior to such approval. Advance payments made by employees before proper approval are made at the employee's own risk.

6. In the event an employee who has been approved for out-Service training later becomes unavailable for such training, he/she must IMMEDIATELY notify the approving official of such fact so that a timely substitution can be made or the course vendor can be requested to cancel the nomination, whichever is appropriate.


**30.4.3.1.6.1** **(02-17-2006)**

##### Approving and Processing the SF 182

01. Responsibility for approving and processing the SF 182 has been re-delegated from the Associate Chief Counsel (Finance and Management) to each Division Counsel and Associate Chief Counsel, to give them complete control over Out-Service training funds included in their sub-financial plans. In this regard, Division Counsel and Associate Chief Counsel are authorized to approve all Out-Service training and to sign as the Training Officer in Block 29a on the SF 182.

02. Out-Service training should only be approved if comparable training is not available through courses offered by the Chief Counsel's Office or through IRS to which employees may be sent.

03. Out-Service training must be related to the current duties of the employee.

04. Out-Service training should not be approved for the sole purpose of obtaining a degree (i.e., the training should also be work-related) and, where academic degree training is obtained, must otherwise comply with 5 U.S.C. § 4107.

05. Detailed instructions can be obtained on the Training and Communications Web site.

06. Each SF 182 must be accompanied by a narrative justification for attendance at the course, the brochure announcing the course (or a duplicate of the brochure for each attendee) and a completed enrollment form for each person attending (these forms are normally found in the brochure announcing the program). Originating offices should retain a copy of this material.

07. Upon the receipt of a request for Out-Service training in the Division Counsel or Associate Chief Counsel Office, the SF 182 should be reviewed for completeness and accuracy. The exact method for tracking receipt, approval, and processing of the form will be left to the discretion of each Division Counsel or Associate Chief Counsel. After approval by the Division Counsel or Associate Chief Counsel, the form must be approved by the designated Training Officer. The Training Officer can be the Division Counsel or Associate Chief Counsel or their designee. This authority cannot be re-delegated below the Area Counsel or Deputy Associate Chief Counsel. After approval by the authorizing official, the request must be entered into the Requisition Tracking System (RTS).

08. Each Division Counsel or Associate Chief Counsel is responsible for ensuring that the approval process is completed before any employee attends Out-Service training. If the approval process has not been completed, the employee's attendance at the training represents an unauthorized procurement action for which the individual employee will be liable.

09. Employees are cautioned that the mere forwarding of the requisite training paperwork by mail or by interoffice messenger service to the approving office does not assure that such documentation has in fact been received or processed. Employees should not report to a training course on the assumption that their request has been approved until notified of such fact, nor should they assume that they have in fact been enrolled in the course unless the procedures specified in the subparagraph, below, have been met.

10. While employees should not make plans to attend training courses until they have been officially notified of the approval, such notification does NOT indicate that they have been enrolled in the course by the course sponsor. In the process of approving a training request, the course sponsor is not approached until the designated officials have approved the request and the request have been entered and approved in the Requisition Tracking System (RTS). At that point, the necessary paperwork is forwarded to the course sponsor or registration is faxed or phoned in to enroll the nominee. If a nominee has not heard from the course sponsor within two days of the course, he/she should contact the approving official so that steps can be taken to verify the enrollment. It is particularly important to follow this procedure where out-of-town travel is involved.


**30.4.3.2** **(02-17-2006)**

### Widely Attended Gatherings

1. This provision is intended to advise Counsel employees of the requirements of the Office of Government Ethics regulations at 5 CFR. § 2635.204(g), and the related Office of Chief Counsel policies and procedures pertaining to an employee's acceptance of free attendance at seminars, conferences, receptions, dinners, or similar events, when attendance would benefit the Service. Inquiries concerning this provision should be addressed to Chief, Ethics and General Government Law Branch, Office of Associate Chief Counsel (General Legal Services).

2. The general rule in the Standards of Ethical Conduct for Employees of the Executive Branch is that an employee may not accept a gift from a prohibited source or that is given because of the employee's position. However, the Standards contain exceptions permitting an employee to accept some gifts. An employee may accept an unsolicited gift having a market value of $20 or less per source per occasion, provided that the aggregate market value of gifts received from any one person shall not exceed $50 in a calendar year. When an employee is assigned to participate as a speaker or panel participant or otherwise present information on behalf of the agency at a conference or other event, the acceptance of an offer of free attendance at the event on the day of the presentation is permissible when provided by the sponsor of the event.

3. Additionally, when there has been a determination that an employee's attendance is in the interest of the agency because it will further agency programs and operations, an employee may accept a sponsor's unsolicited gift of free attendance at all or appropriate parts of a widely attended gathering of mutual interest to a number of parties.

4. A gathering is widely attended if it is expected that a large number of persons will attend and that persons with a diversity of views and interests will be present, for example, if the event is open to members from throughout the interested industry or if those in attendance will represent a range of persons interested in a given matter. The decision as to whether an employee's attendance at a widely attended gathering would be in the agency's interest is required to be made by an employee's supervisor or other appropriate official in the employee's chain of management.


**30.4.3.2.1** **(12-09-2008)**

#### Factors to Consider

1. Where an invitation to attend a widely attended gathering is extended by an organization the majority of whose members have interests that may be affected by the performance or nonperformance of the employee's duties, a written determination must be made by the employee's supervisor or other appropriate official in the employee's chain of command, that the agency's interest in the employee's attendance outweighs any potential that acceptance could result in an appearance of favoritism or undue influence on his official activities.

2. Factors that should be considered include:



   - The importance of the event to the agency

   - The purpose of the event

   - The nature and sensitivity of any pending matter affecting the interest of the person who has extended the invitation

   - The significance of the employee's role in any such matter

   - The identity of other expected participants

   - The market value of the gift of free attendance


3. The possibility of conflicts of interest must be considered when the approving authority ratifies the acceptance of free attendance. Examples of impermissible conflicts of interest include employees accepting free attendance from an organization with a pending question before the Service regarding its tax-exempt status or employees being involved in any question or controversy with such an organization.


**30.4.3.2.2** **(12-09-2008)**

#### Free Attendance

1. When there has been a determination that an employee's attendance is in the interest of the agency because it will further agency programs and operations, an employee may accept, from a person other than the sponsor of the event, an unsolicited gift of free attendance at all or appropriate parts of a widely attended gathering of mutual interest to a number of parties if more than 100 persons are expected to attend the event and the gift of free attendance has a market value of $305 or less.

2. Free attendance includes waiver of all or part of a conference or other fee, the provision of food, refreshments, entertainment, instruction, and materials provided to all attendees as an integral part of the event.

3. Free attendance does not include travel expenses, lodging, entertainment collateral to the event, or meals taken other than in a group setting with all other attendees. However, the Government Employees Training Act, 5 U.S.C. § 4111, allows employees to accept contributions and payment of travel, subsistence, and other expenses incident to attendance at non-Government training or meetings if such contributions or payments are offered by a tax exempt organization under IRC 501(c)(3). Such acceptance is permissible only where attendance at a function is part of an employee's official duties. The acceptance of expenses pursuant to 5 U.S.C. § 4111 must be authorized in writing by the Associate Chief Counsel (Finance & Management).


**30.4.3.2.3** **(02-17-2006)**

#### Payment of Expenses

1. The payment of expenses pursuant to 5 U.S.C. § 4111 may not be a reward for services to the organization prior to the meeting, and a determination has to be made that acceptance of payment:



1. Would not reflect unfavorably on the employee’s ability to carry out official duties in a fair and objective manner

2. Would not compromise the honesty and integrity of Government programs or Government employees and their official actions or decisions

3. Would otherwise be compatible with the Standards of Ethical Conduct for Employees of the Executive Branch

4. Would otherwise be proper and ethical for the employee concerned given the circumstances of the particular case


2. Employees may not accept reimbursement for travel expenses from an organization that has open issues facing litigation.

3. Records must be maintained by the approving authority on any travel expenses accepted under the authority of 5 U.S.C. § 4111. The records will include:



1. The name of the recipient (and spouse if applicable) who has traveled

2. The amount and method of payment

3. The name of the organization providing the payment

4. The nature of the meeting or similar function

5. The time and place of travel, the nature of the expenses

6. Copies of the travel authorizations

7. A copy of the required written authorization for the acceptance of the expenses


4. These records should be maintained as official records for a period of six years. Upon completion of the travel, a report of the acceptance of travel expenses, containing the above information and copies of documents, will be forwarded to the IRS' Office of Travel Management and Relocation.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part30/irm_30-004-003#addtoany "Show all")

A2A