---
url: "https://www.irs.gov/irm/part35/irm_35-003-006"
title: "35.3.6 Motions Pertaining to Opinions and Decisions | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-003-006#main-content)

- 35.3.6 [Motions Pertaining to Opinions and Decisions](https://www.irs.gov/irm/part35/irm_35-003-006#idm140407471301824)
  - 35.3.6.1 [Motion for Reconsideration of Findings or Opinions](https://www.irs.gov/irm/part35/irm_35-003-006#idm140407468248016)
  - 35.3.6.2 [Motion to Vacate or Revise Decisions](https://www.irs.gov/irm/part35/irm_35-003-006#idm140407468637056)
  - 35.3.6.3 [Motions for Leave to File Motions for Reconsideration or to VacateOut of Time](https://www.irs.gov/irm/part35/irm_35-003-006#idm140407468080496)
  - 35.3.6.4 [Motion Not Timely After Appeal Filed or Decision Becomes Final](https://www.irs.gov/irm/part35/irm_35-003-006#idm140407450922848)
  - 35.3.6.5 [Appeal Period Extended by Motion](https://www.irs.gov/irm/part35/irm_35-003-006#idm140407459191424)
  - 35.3.6.6 [Modification of Decision in I.R.C. 6166 Estate Tax Cases](https://www.irs.gov/irm/part35/irm_35-003-006#idm140407497310688)

# Part 35. Tax Court Litigation

# Chapter 3. Motions

# Section 6. Motions Pertaining to Opinions and Decisions

* * *

## 35.3.6 Motions Pertaining to Opinions and Decisions

**35.3.6.1** **(08-11-2004)**

### Motion for Reconsideration of Findings or Opinions

1. _See_ CCDM 35.9.1.2.4 for a discussion of motions for reconsideration.


**35.3.6.2** **(08-11-2004)**

### Motion to Vacate or Revise Decisions

1. _See_ CCDM 35.9.1.3.2.1 for a discussion of motions to vacate.

2. _See_ Exhibit 35.11.1–60 for a sample motion to vacate decision.


**35.3.6.3** **(08-11-2004)**

### Motions for Leave to File Motions for Reconsideration or to Vacate Out of Time

1. No motion for reconsideration of findings or opinion, or to vacate or revise a decision may be filed more than 30 days after the opinion or decision, respectively, has been served or entered except by leave of the court. _See_ T.C. Rules 161 and 162. In every case in which a motion with respect to the opinion or decision is filed more than 30 days after the opinion is served or the decision is entered (but before the decision becomes final), it must be accompanied by a motion for leave to file. The motion for leave to file should set forth the basis for filing the motion and the reasons why such motion was not filed within the permissible 30-day period after service of the opinion or entry of decision. If the motions pertain to both the opinion and the decision, a separate motion for leave must be filed with respect to each. In such instances, four separate motions are required:



   - A motion for leave to file out of time a motion for reconsideration of the opinion

   - A motion for reconsideration of the opinion

   - A motion for leave to file out of time a motion to vacate the decision

   - A motion to vacate the decision


2. In cases in which a motion for reconsideration is anticipated but cannot be completed within the 30-day period described above, a motion to extend time within which to file a motion for reconsideration may be filed. The court cannot, however, extend the time within which a motion to vacate a decision may be filed beyond the time the decision otherwise becomes final. Motions to reconsider orders other than opinions may not be technically subject to the 30-day time frame specified in T.C. Rule 161, but the best practice is to file such motions within such 30-day period. Guidance should be sought from APJP, Branch 3, on the extent to which a motion for leave may be necessary if moving for reconsideration of an order other than an opinion beyond the 30-day period. Motions for reconsideration are subject to approval at a high level and any necessary motion for leave to file out of time should accompany the underlying motion when submitted for review and approval.


**35.3.6.4** **(08-11-2004)**

### Motion Not Timely After Appeal Filed or Decision Becomes Final

1. General. As a general rule, no motion pertaining to an opinion or decision of the Tax Court should be filed with that court after the decision of that court has become final under the provisions of section 7481, or after a notice of appeal to a court of appeals has been filed by either party. Upon filing of a notice of appeal by either party, the Tax Court gives up its claim to jurisdiction of the case even though the appeal period has not expired. As a general rule, after the decision of the Tax Court has become final, that court may not take further action absent fraud on the court or other recognized exception to the finality rule.

2. Interlocutory Appeals. Some petitioners, including in particular those who make frivolous legal arguments and appear pro se, may file a notice of appeal from any interlocutory ruling or order of the court that is neither a final decision nor order of dismissal of the case for lack of jurisdiction. If an interlocutory notice of appeal is filed for purposes of delay, it may be appropriate to file a motion for an order directing the clerk to retain the original record to enable the court to promptly try the case once the appeal is dismissed and thereby preclude further delay. The Field attorney and reviewer should consult with APJP, Branch 3 before taking any action on an interlocutory appeal.

3. Jurisdictional Questions. The Tax Court has ruled that a question concerning its jurisdiction in any case may be raised after a decision in the case has become final under section 7481.


**35.3.6.5** **(08-11-2004)**

### Appeal Period Extended by Motion

1. If a timely motion to vacate or revise a decision is filed and denied, a new statutory period for filing an appeal begins to run from the date of the denial of the motion. If the court grants the motion to vacate or revise a decision, a new appeal period begins to run upon the entry of the new or revised decision by the court.

2. A motion filed with the Tax Court solely for the purpose of reconsideration of its opinion and not to vacate or revise the court’s decision, will not extend the normal statutory period for filing a notice of appeal. Tax Court Rule 162 provides that any motion to vacate or revise a decision, with or without a new or further trial, shall be filed within 30 days after the decision has been entered, unless the court shall otherwise permit. Therefore, a motion to vacate a decision more than 30 days after entry of the decision is not filed until the motion for leave to file the motion to vacate is granted by the court. In this instance the motion to vacate is ‘lodged’ with the Court until the motion for leave is granted. Thus, until a motion to vacate a decision is filed with the court, either within the 30-day period after the entry of the decision or upon the granting of a motion for leave to file, the normal statutory period for filing an appeal is not extended.

3. If the court denies a motion for leave to file a motion to vacate a decision, the appeal period is not extended. In government appeals, the notice of appeal should be filed within 90 days after the entry of the court’s decision in accordance with the provisions of the CCDM. In taxpayer appeals, if the notice of appeal was not filed or postmarked within 90 days after the entry of the decision, that fact should be set forth in the taxpayer appeal notification letter to the Department of Justice with a recommendation that there be raised an issue as to the jurisdiction of the court of appeals. For government appeals, any doubt as to the time limitations for the timely filing of an appeal should be resolved in favor of filing the notice of appeal prior to the earliest possible date which, under the circumstances of the case, appears to be the termination of the appeal period.


**35.3.6.6** **(08-11-2004)**

### Modification of Decision in I.R.C. § 6166 Estate Tax Cases

1. _See_ CCDM 35.9.1.3.2.3 for a discussion of modification of decisions in estate tax cases.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-003-006#addtoany "Show all")

A2A