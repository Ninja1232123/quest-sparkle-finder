---
url: "https://www.irs.gov/irm/part34/irm_34-005-007"
title: "34.5.7 Damages Litigation | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part34/irm_34-005-007#main-content)

- 34.5.7  [Damages Litigation](https://www.irs.gov/irm/part34/irm_34-005-007#idm140316041964576)
  - 34.5.7.1  [Damages Litigation](https://www.irs.gov/irm/part34/irm_34-005-007#idm140316014950864)
  - 34.5.7.2  [Examples of Damages Litigation](https://www.irs.gov/irm/part34/irm_34-005-007#idm140316014948560)
  - 34.5.7.3  [Processing Damage Litigation Suits](https://www.irs.gov/irm/part34/irm_34-005-007#idm140316014943264)
  - 34.5.7.4  [Handling Pending Damages Litigation](https://www.irs.gov/irm/part34/irm_34-005-007#idm140316041971184)
  - 34.5.7.5  [Outcomes of Damages Litigation](https://www.irs.gov/irm/part34/irm_34-005-007#idm140316014817104)

# Part 34. Chief Counsel Directives Manual Litigation in District Court, Bankruptcy Court, Court of Federal Claims, and State Court

# Chapter 5. Suits Brought Against the United States

# Section 7. Damages Litigation

* * *

## 34.5.7 Damages Litigation

#### Manual Transmittal

August 03, 2023

#### Purpose

(1) This transmits revised CCDM 34.5.7, Suits Brought Against the United States, Damages Litigation.

#### Material Changes

(1) CCDM 34.5.7 is revised to remove outdated coordination requirements in damages litigation suits.

#### Effect on Other Documents

This section supersedes CCDM 34.5.7 dated August 11, 2004.

#### Audience

Chief Counsel

#### Effective Date

(08-03-2023)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**34.5.7.1** **(08-11-2004)**

### Damages Litigation

1. Damages litigation includes all suits for money damages against the United States, federal agencies, or federal employees (but not Tax Court or refund suits), including those under sections 7431, 7432, 7433, and 7435. The Department of Justice has primary responsibility for litigation of these types of cases and Field Counsel generally support it with litigation reports and defense letters, analysis and assistance.


**34.5.7.2** **(08-03-2023)**

### Examples of Damages Litigation

1. Section 7435. Taxpayers may bring suit for damages if any officer or employee of the United States intentionally compromises the determination or collection of any tax due from an attorney, certified public accountant, or enrolled agent representing the taxpayer in exchange for information concerning the taxpayer’s tax liability.



1. This does not apply to information conveyed to a tax professional for the purpose of perpetrating a fraud or crime.

2. The United States’ liability is limited to an amount equal to the lesser of $500,000 or the sum of (1) actual, direct economic damages sustained by the plaintiff as a proximate result of the information disclosure, and (2) the costs of the action. Damages do not include a taxpayer’s liability for any civil or criminal penalties, or other losses attributable to incarceration or the imposition of other criminal sanctions.

3. The action must be brought within two years after the date the actions creating the liability would have been discovered by exercise of reasonable care.

4. If a taxpayer files suit, and the Service certifies that there is an ongoing investigation or prosecution of the taxpayer, the court is required to stay all proceedings with regard to such action until the conclusion of the investigation or prosecution.


2. Suits for Damages for Failure to Release a Lien under Section 7432. Taxpayers may bring suit, after exhaustion of administrative remedies, if any officer or employee of the Service, "knowingly or by reason of negligence" fails to release a lien under Section 6325 on property of the taxpayer.



1. Damages are limited to actual, direct economic damages, plus the cost of the action. There is no cap on damages, but the taxpayer must mitigate.

2. The statute of limitations is two years after accrual of the right of action.


3. Suits for Damages for Certain Unauthorized Collection Actions under Section 7433. Pursuant to section 7433(a) a taxpayer may bring a suit against the United States if in connection with any collection action, an officer or employee of the Service "recklessly or intentionally, or by reason of negligence, disregards" any law or regulation. Section 7433(e), added by the Restructuring and Reform Act of 1998, provides that the Service may be held liable for actual, economic damages if, in connection with any collection of tax, any employee willfully violates the automatic stay or discharge provisions of the Bankruptcy Code. .

4. Section 7431 provides a civil remedy for taxpayers damaged by unlawful disclosures or inspections of tax information by federal employees. The statute provides for no less than liquidated damages of $1,000 for each unauthorized disclosure or inspection. In the alternative, liability extends to actual damages plus court costs. The statute also provides for punitive damages in addition to actual damages in situations where the unlawful disclosure or inspection is willful or the result of gross negligence.



1. Congress did not intend to provide a remedy for a disclosure or inspection of tax information made at the request of the taxpayer or pursuant to a good faith, but erroneous, interpretation of the confidentiality rules. Instead, a disclosure or inspection giving rise to civil liability is limited to situations where the unauthorized disclosure or inspection results from a willful or negligent failure of the person to comply with the law.


5. Suits for damages filed under the Privacy Act of 1974, 5 U.S.C. 552a.

6. Suits filed against Service employees on the basis of _Bivens v. Six Unknown Named Agents of Federal Bureau of Narcotics_, 403 U.S. 388 (1971).

7. Suits filed under the Federal Tort Claims Act, 28 U.S.C. 2671-2680, if they allege damages based on actions of a Service employee.

8. Other kinds of suits for damages naming IRS or Counsel employees (including former employees) as defendants, if the plaintiff or petitioner is not a Service employee.

9. Generally, the General Legal Services division has primary responsibility for suits in categories (6), (7), and (8). For the procedures to be followed in _Bivens_ litigation see CCDM 39.3.2. For the procedures to be followed in Federal Tort Claims Act litigation, see CCDM 39.3.1.


**34.5.7.3** **(08-11-2004)**

### Processing Damage Litigation Suits

1. It has been decided that most of these suits should be processed the same as the ordinary collection cases, i.e., a defense letter. CCDM 34.5.1.1.

2. In addition to the requirements of a regular defense letter, in those cases where an employee (or a retired or previous employee) is named individually as a defendant, the defense letter should include whether the alleged actions of the defendant employee were actually taken by the employee and, if so, whether those actions were in the due performance of his or her official duties. For obvious reasons, care must be exercised in this portion of handling the case.

3. Prior to discussing a case with an individual defendant employee, the employee must be advised of the limited attorney/client relationship that will be established pursuant to CCDM 30.4.6, and the employee must request representation as provided by that section.

4. In those cases where the United States, the Treasury Department or the Service is joined as a party defendant with an individual employee or employees, or in cases where two or more employees are named as defendants, the attorney handling the case must exercise extreme caution to avoid placing himself/herself in a conflict-of-interest situation. In these cases, the attorney should take the steps necessary to disqualify himself/herself, the Area Counsel’s office and/or the Associate office when a conflict of interest arises.

5. If a damages claim is based on multiple legal theories, and several Counsel functions are involved, the attorney with primary responsibility for the damages litigation must ensure coordination with the other Counsel offices.

6. Once a decision has been made to recommend to DJ that the employee be represented by the Department, then the U.S. Attorney for the district where the civil suit was brought will be advised of the suit and informed that representation for the Service employee or former employee has been or will be requested by the Agency from DJ.

7. In district court cases having a 20-day answer date in which Service employees are sued in their individual capacities some U.S. Attorneys will resist filing the motion for an extension of time on the theory the suit is against the United States and, therefore, the statute automatically grants sixty days to answer. Field Counsel should urge the U.S. Attorney to file this motion.

8. If an employee who is individually served a summons and complaint is not prompt in notifying Field Counsel of the pending litigation, it can complicate the case and cause unnecessary problems for Field Counsel and DJ. To avoid these delays, Field Counsel should take steps to communicate to Service employees the importance of notifying the function, through appropriate channels, as quickly as possible of receipt of service of process. Prompt notification is particularly important in those cases filed in a state court and federal district court cases in which the defendant(s) is given only twenty days to answer.


**34.5.7.4** **(08-11-2004)**

### Handling Pending Damages Litigation

1. In damage actions filed in state court against Service employees acting within the scope of their employment, the General Legal Services function takes the necessary action to request the U.S. Attorney in the judicial district in which the suit was filed to remove the case to federal court pursuant to 28 U.S.C. §1442. Field Counsel will also be responsible for providing any assistance requested by the U.S. Attorney with regard to the removals.

2. When a damages litigation case is opened in CASE-MIS the dollar amount of damages claimed should be entered in the appropriate Counsel database.

3. When a Service employee is sued for actions taken in connection with official duties and desires representation by DJ, such employee should submit a written request for such representation as provided by CCDM 30.4.6. Additionally, to allow for the proper defense of such an action, the employee should furnish an affidavit, which would likewise demonstrate that, with respect to the actions challenged, they were authorized and were performed within the line of official duties.

4. The Counsel attorney with primary responsibility for the case must obtain a status report from the DJ attorney assigned to the case at least once each quarter, until the case is resolved. A note of the information obtained with each status report should be made in the case file.


**34.5.7.5** **(08-11-2004)**

### Outcomes of Damages Litigation

1. When a damages case is settled or a final decision rendered, Counsel for the case must:



1. Obtain a copy of the decision, order and/or settlement document;

2. Obtain documentation of the exact dollar amount awarded or agreed to, if damages are to be paid by the Government or Government employee; and

3. Take steps to ensure that relevant outcome data, including win/loss information and the total dollar amount of damages, if any, are entered into CASE-MIS.


2. The responsible Area Counsel, Assistant Chief Counsel, or Associate Chief Counsel must ensure that the following steps are taken with regard to giving notice to affected IRS or Counsel offices:



1. Notify appropriate IRS functional management of the outcome, whether the Government wins or settles on a favorable basis, or whether the result is a loss or settlement adverse to the Government’s position;

2. Include in the notice a statement of the dollar amount of damages awarded or agreed to, when the result is a loss or settlement adverse to the Government’s position.

3. Advise appropriate IRS management of the Treasury Department standards governing referral to TIGTA;

4. Provide a recommendation as to whether, if the case has not previously been referred to TIGTA, a referral is appropriate in light of the outcome of the case; and

5. If a Chief Counsel employee has been named as a defendant in the case, prepare notification to the Deputy Chief Counsel (Operations) of the background and outcome of the damages litigation.


3. The settlement of cases is discussed in general in CCDM 34.8.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part34/irm_34-005-007#addtoany "Show all")

A2A