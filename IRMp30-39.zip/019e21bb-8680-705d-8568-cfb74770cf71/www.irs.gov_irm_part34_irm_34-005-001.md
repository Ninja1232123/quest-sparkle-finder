---
url: "https://www.irs.gov/irm/part34/irm_34-005-001"
title: "34.5.1 Defense Letters | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part34/irm_34-005-001#main-content)

- 34.5.1  [Defense Letters](https://www.irs.gov/irm/part34/irm_34-005-001#idm140062018991296)
  - 34.5.1.1  [General Procedures for Defense Letters](https://www.irs.gov/irm/part34/irm_34-005-001#idm140062019024768)
    - 34.5.1.1.1  [Case Classification](https://www.irs.gov/irm/part34/irm_34-005-001#idm140062019023088)
      - 34.5.1.1.1.1  [S.O.P. Cases](https://www.irs.gov/irm/part34/irm_34-005-001#idm140062019017568)
      - 34.5.1.1.1.2  [Standard Cases](https://www.irs.gov/irm/part34/irm_34-005-001#idm140062019013568)
      - 34.5.1.1.1.3  [Effect of Classification](https://www.irs.gov/irm/part34/irm_34-005-001#idm140062018980736)
    - 34.5.1.1.2  [Defense Letters](https://www.irs.gov/irm/part34/irm_34-005-001#idm140062018974736)
      - 34.5.1.1.2.1  [Essential Elements of a Defense Letter](https://www.irs.gov/irm/part34/irm_34-005-001#idm140062018956688)
      - 34.5.1.1.2.2  [Defenses](https://www.irs.gov/irm/part34/irm_34-005-001#idm140062018925072)
        - 34.5.1.1.2.2.1  [Equitable Recoupment](https://www.irs.gov/irm/part34/irm_34-005-001#idm140062018923376)
        - 34.5.1.1.2.2.2  [Equitable Estoppel](https://www.irs.gov/irm/part34/irm_34-005-001#idm140062018918880)
        - 34.5.1.1.2.2.3  [Affirmative Defenses](https://www.irs.gov/irm/part34/irm_34-005-001#idm140062018912768)
        - 34.5.1.1.2.2.4  [Res Judicata and Collateral Estoppel](https://www.irs.gov/irm/part34/irm_34-005-001#idm140062018900592)
        - 34.5.1.1.2.2.5  [Jurisdiction](https://www.irs.gov/irm/part34/irm_34-005-001#idm140062018331312)
      - 34.5.1.1.2.3  [Due Date](https://www.irs.gov/irm/part34/irm_34-005-001#idm140062018321856)
      - 34.5.1.1.2.4  [Review of Defense Letters and Coordination with Field Counsel](https://www.irs.gov/irm/part34/irm_34-005-001#idm140062018312656)
      - 34.5.1.1.2.5  [Counterclaims and Third-Party Complaint Authorization](https://www.irs.gov/irm/part34/irm_34-005-001#idm140062018302640)
      - 34.5.1.1.2.6  [Reporting of a Tax Case involving a Member of an Indian Tribal Government](https://www.irs.gov/irm/part34/irm_34-005-001#idm140062018278960)

# Part 34. Chief Counsel Directives Manual Litigation in District Court, Bankruptcy Court, Court of Federal Claims, and State Court

# Chapter 5. Suits Brought Against the United States

# Section 1. Defense Letters

* * *

## 34.5.1 Defense Letters

#### Manual Transmittal

July 27, 2021

#### Purpose

(1) This transmits revised CCDM 34.5.1, Defense Letters.

#### Background

This section incorporates the statutory threshold amounts for refunds that require review by the Joint Committee under IRC 6405.

#### Material Changes

(1) CCDM 34.5.1.1 is revised to reflect the current statutory threshold amount for refunds that require review by the Joint Committee under IRC 6405.

#### Effect on Other Documents

This section supersedes CCDM 34.5.1, dated April 22, 2021.

#### Audience

Chief Counsel

#### Effective Date

(07-27-2021)

Robert T. Wearing

Deputy Associate Chief Counsel

(Procedure & Administration)

**34.5.1.1** **(08-11-2004)**

### General Procedures for Defense Letters

1. This section deals with the handling of all suits brought against the United States in which defense letters must be prepared and sent to the Department of Justice (DJ), setting forth the facts and legal grounds for defending the suits.

2. This first subsection explains general procedures for considering and preparing all defense letters. The following subsections deal with specific requirements for defense letters in particular types of suits.


**34.5.1.1.1** **(08-11-2004)**

#### Case Classification

1. Many suits present commonplace issues of fact, legal issues that do not substantially affect the collection of revenue, or the application of legal principles that have already been established through prior litigation. Other cases, in contrast, involve legal and factual issues that are of greater importance to the fair and efficient administration of the internal revenue laws. While all of these cases require careful preparation for trial, it is recognized that the cases of greater importance demand the closest coordination and supervision by an Associate office and by DJ. Contrary to past practice, however, not all cases classified as Standard require Associate office review. To assure the proper degree of attention, all cases litigated by DJ for which this office prepares either a defense or suit letter are classified in one of the following categories:



   - Settlement Option Procedure (S.O.P.). Cases that involve commonplace issues of fact, legal issues of no great importance to the revenue, or the application of legal principles that have already been substantially resolved through prior litigation.

   - Standard. All cases that cannot be identified as falling into the S.O.P. category.


2. Each case is classified at the time the defense or suit letter is written, and each case should be classified according to the issue with the highest classification. Thus, if any of the issues would require Standard classification, the entire case should be classified Standard. The case classification is shown in capital letters on the bottom of the first page of the defense letter.

3. The case classification is significant because it determines whether DJ may settle the case without obtaining the views of the field counsel. In addition, in some (but not all) district court S.O.P. cases involving routine issues described in _CCDM 34.5.1.1.2_, complete defense letters will not be prepared.


**34.5.1.1.1.1** **(08-11-2004)**

##### S.O.P. Cases

1. The S.O.P. category includes cases that involve commonplace issues of fact, legal issues of no great importance to the revenue, or the application of legal principles that have already been substantially resolved through prior litigation. The following principles will govern the classification of S.O.P. cases.

2. The amount in controversy will not be a substantial factor in classification of S.O.P. cases.

3. A case should not be excluded from the S.O.P. category merely because further factual investigation might be necessary in the preparation of the case for trial.

4. A case should not be excluded from the S.O.P. category on the ground that there appear to be jurisdictional defenses, unless there is a fatal jurisdictional defect. Cases with fatal jurisdictional defects should not be settled under any circumstances.

5. As with the case of apparent jurisdictional defects, the relative strength or weakness of a particular case is not controlling in determining whether it should be classified S.O.P. The S.O.P. classification permits defense or settlement. It is not a procedure whereby a case is referred to DJ for settlement on any basis obtainable. If a case is a particularly strong one, it is presumed that DJ will so view it and either force the case to trial or will settle, if desirable, only on a basis consistent with the strength of the Government’s position.


**34.5.1.1.1.2** **(08-11-2004)**

##### Standard Cases

01. Those cases that should be classified Standard are, simply, those that do not fit into the S.O.P. classification. The following are guidelines for excluding cases from the S.O.P. classification.

02. The case contains an issue or issues of a continuing nature. Continuing issues should be distinguished from issues that may merely recur from year to year because of the nature of the taxpayer’s business or pattern of operation. A good example of a continuing issue is whether a certain expenditure must be capitalized or whether it may be depreciated or amortized. The resolution of the issue will affect all open and future years in which depreciation has been or will be claimed. In cases that merely recur from year to year, the resolution of any one year will not dispose of the issue for any other year. Cases containing recurring issues should not be classified Standard unless the factual variations from year to year are so slight that the disposition of one year would establish a compelling precedent for the disposition of the similar issues for years not in suit.

03. The case contains an issue that is identical to that pending administratively in the case of a related taxpayer.

04. The case contains an issue identical with or very similar to that pending before the Tax Court in the case of the same taxpayer or a related taxpayer.

05. An administrative refund is recommended.

06. The taxpayer involved (e.g., a public figure) makes the case sensitive in nature.

07. The case contains a clearly dispositive jurisdictional issue giving rise to an appropriate motion to dismiss.

08. The nature of the issue would make the case a significant test case. The issue involves an important legal question that needs to be litigated for administrative or other reasons.

09. The litigation or settlement of the issue may establish a pattern for an entire industry or a large group of taxpayers similarly situated.

10. The case involves an issue that is on the list of issues requiring Associate office review (Exhibit 35.11.1-1).

11. The case involves an injunction, summons or frivolous return.

12. Standard classification has been requested by the Service client.


**34.5.1.1.1.3** **(07-27-2021)**

##### Effect of Classification

1. The case classification generally determines whether DJ can settle the case without obtaining the views of the Associate Area Counsel.

2. If a case is classified Standard and contains an issue on the list of issues requiring Associate office review, the defense letter will be sent to the Technical Services Support Branch (TSS4510) for assignment to an Associate office for review prior to being forwarded to DJ. Field counsel offices may send S.O.P. defense letters (including abbreviated letters) and Standard defense letters that do not contain issues requiring Associate office review directly to the DJ.

3. If a case is classified Standard, DJ will refer all settlement offers to the Field Counsel office prior to acceptance of the offer. In some cases where the offer is deemed to be clearly inappropriate, DJ will reject it summarily and not refer the offer to Counsel. Normally, if a case is classified S.O.P. (including S.O.P. cases in which an abbreviated defense letter has been written), a settlement offer does not have to be referred to Counsel. However, if the settlement encompasses years or taxpayers not in suit, and requires the approval of the Field Counsel office with jurisdiction over the subject matter, it must be referred to Counsel regardless of classification.

4. Additionally, all cases requiring submission to the Joint Committee on Taxation (refunds in excess of $2,000,000 or $5,000,000 in the case of C corporations) must be referred to the Field Counsel office.

5. Finally, even where a case is classified S.O.P., DJ must seek the views of the Field Counsel office concerning a complete concession in a settlement proposal. A recommendation must be received from Counsel within 30 days from the date of the letter requesting the recommendation. If no such recommendation is received within that time, DJ may process the case on the assumption that Counsel has no objection to the concession. If the Field Counsel office agrees to the concession then a short concurring letter to DJ will be adequate.


**34.5.1.1.2** **(07-27-2021)**

#### Defense Letters

1. Within 50 days after a taxpayer files a suit against the United States or 40 days after the attorney receives the case, whichever is later, the attorney must send a defense letter to the Tax Division. This letter will help the Tax Division file a responsive pleading to the taxpayer’s complaint. The letter will classify each case as either Standard or S.O.P. The case classification is significant because it determines whether DJ may settle the case without obtaining the views of Counsel.

2. An attorney should classify each case at the time he writes the defense letter and should classify each case according to the issue with the highest classification. If an attorney classifies any issue as Standard, an attorney should classify the entire case as Standard.

3. Occasionally, an attorney will need to reclassify a case after he initially classifies it in the defense letter. For example, if a case has a Standard issue that has been fully disposed of through litigation or settlement and only S.O.P. issues remain, the attorney should reclassify the cases as S.O.P. Similarly, if the attorney initially classifies a case as S.O.P., and a related case is later brought, the attorney may need to reclassify the case as Standard. Another example would be where the attorney initially classifies a case as Standard because the facts in the file indicate that the issue is of substantial administrative importance. If later developments indicate the case to be of little importance, the attorney may reclassify it as S.O.P. When an attorney reclassifies a case, he should send a letter to DJ and a copy of the letter to APJP. The attorney should state in the letter the reason or reasons for the change in classification.

4. Generally an attorney should include the following in all Standard cases and in some S.O.P. cases:



   - A statement of the legal issues presented

   - A discussion of the relevant facts

   - A discussion of each issue, including citations to any applicable statutes, regulations, rulings and cases

   - A recommendation as to defense, concession, or settlement

   - A discussion of any offsets or any obvious jurisdictional defenses

   - A discussion of any counterclaim or third-party complaint and any ongoing supplemental audit examination


5. An attorney can prepare an abbreviated defense letter in some S.O.P. cases. Abbreviated defense letters do not have to include a statement of facts nor an analysis of substantive issues. Abbreviated defense letters will merely state the issues involved, indicate the presence or absence of any obvious jurisdictional defects, and transmit the administrative files. An attorney can prepare an abbreviated defense letter in the following cases:



1. Case including issues as to which the field offices are permitted to file briefs directly with the Tax Court, but only if the administrative file or some other available sources contains some basic discussion of the Government’s position on the issue such as an Appeals Supporting Statement or a memorandum from Field Counsel.

2. Cases where the taxpayer’s liability for the trust fund recovery penalty provided by section 6672 is a question of fact.

3. Cases involving an accuracy-related penalty under section 6662 (or negligence penalty under former section 6653(a) for returns before December 31, 1989).


6. Despite the general rule above, an attorney must prepare a complete defense letter in the following cases:



   - If any of the issues involve a substantial legal question or an interpretation of law

   - If the case involves assertion of the fraud penalty under section 6663 (or under former section 6653(b) for returns due before December 31, 1989) or the fraud delinquency penalty under section 6651(f).

   - If the case is classified Standard under the criteria discussed in _CCDM 34.5.1.1.1.2_.

   - If the amount of a refund sought by any one taxpayer is in excess of $2,000,000 ($5,000,000 in the case of C corporations), such that settlement of the case may require review by the Joint Committee on Taxation pursuant to section 6405.

   - If the case involves a continuing issue

   - If there are related taxpayers not in suit

   - If there is a jurisdictional defense


7. An attorney who prepares an abbreviated defense letter should promptly transmit the files to DJ and classify the case as S.O.P. An attorney should also include, if necessary, any authorization for counterclaims or third-party complaints.

8. Generally, one defense letter should be drafted for each case. If a group of related cases involves common and uncommon issues, the attorney should prepare more than one defense letter as to the uncommon issues, but can incorporate a common legal argument. An attorney should prepare only one defense letter in related cases _only_ if the cases meet the item or transaction tests of section 6103(h)(2)(B) or (C).


**34.5.1.1.2.1** **(02-29-2016)**

##### Essential Elements of a Defense Letter

01. Tax Data. In order to assist, an attorney should include the following information in the defense letter in a way that allows for easy identification of the data:



    - Full name of the taxpayer and any other party to the action

    - Identity of the taxpayer where the party bringing suit is not the taxpayer

    - TIN for the taxpayer and any other party to the action

    - Type of tax (income, employment, excise)and Form number of return

    - Tax period

    - Information about any pending qualified offer pursuant to section 7430(g)

    - Service point of contact for files and updated tax information, including a name, business address, and telephone number

    - Amounts of tax assessed (include current information and state date an attorney obtained information)

    - Date of assessments for each period (include current information and state date an attorney obtained information)

    - Amount of assessment that is unpaid, including accrued interest and penalties (include current information and state date an attorney obtained information)

    - Any applicable statute of limitations


02. An attorney can include the tax data in narrative form in the fact section of the letter, in table form in an appendix enclosed with the letter (preferable) or by attaching a Form 4340. If an attorney uses a Form 4340, an attorney should include the accruals of interest and penalties as of a date as close as possible to the date when an attorney sends the defense letter to DJ.

03. Opening Statement. In the Opening Statement, an attorney should refer to the court in which the case was filed; the date of the complaint (or petition); the amount of tax, penalty and interest the plaintiff seeks to recover; the type of tax involved; and the years or periods in suit.

04. Statement of Issues. An attorney should state the specific issue or issues involved, citing the applicable Code section or Regulation to which it relates and consolidating issues where possible. An attorney can generally find the issues in the taxpayer’s complaint, the claim for refund, the revenue agent’s or appeals officer’s report, if any. An attorney should include any new issues raised by Field Counsel such as jurisdictional defenses and setoffs.

05. Operative Facts. Except for abbreviated defense letters, an attorney should always discuss the facts that are pertinent to the substantive issues in the case. If the case involves multiple issues but some facts relate to more than one issue, an attorney should first discuss general facts such as general information about a corporate or individual taxpayer, e.g., date and state of incorporation. An attorney should also include facts pertinent to the burden of proof issue under section 7491.

06. Discussion. An attorney should discuss the specific facts after discussing the general facts or, if there are no general facts, after stating the issue or issues. While discussing the facts pertinent to a particular issue, an attorney can incorporate by reference any documents in the file that contain a full recitation of the facts, such as an appeals officer’s report or earlier defense letter. If the administrative file contains an adequate description of the facts, an attorney only has to include a brief summary of these facts and cite the relevant document. An attorney should not postpone writing the defense letter if certain critical facts are missing or otherwise unavailable. He should note, however, the absence of such facts in the letter and recommend that DJ secure the missing facts through discovery or by requesting a supplemental investigation. _See_ CCDM 34.7. If the issues in a suit are purely legal in nature, an attorney only has to minimally discuss the facts and can combine the factual and legal discussions. For example, if a taxpayer claims that he or she is not liable for income taxes because the Federal Reserve Notes that she received in salary did not constitute money, an attorney only has to include a minimal amount of facts.

07. Legal Analysis. An attorney should also include a legal analysis of the issues, except in abbreviated defense letters. This will include pertinent Code sections, regulations, rulings, and case law in conjunction with a discussion of the operative facts. An attorney should include the Service’s position as to the legal authorities and a conclusion as to the manner in which DJ should dispose of the issue (i.e., defend, concede or settle). An attorney should not write defense letters as if they were briefs and therefore should include the strengths and weaknesses of the Government’s case. If another defense letter contains an adequate legal discussion, an attorney may incorporate (i.e., cut and paste) the argument into the defense letter, or refer the DJ attorney to the DJ colleague who worked on a similar case. Attorneys must be mindful of including third party return information in defense letters only when the third party return information meets the item or transaction tests of section 6103(h)(2)(B) or (C).



    1. An attorney should not withhold his recommendation concerning defense, settlement, or concession even if some facts are not available. In some instances, an attorney can make reasonable assumptions about the facts and recommend defense, settlement, or concession subject to verification of such facts. Normally, however, if concession appears likely, an attorney should tentatively recommend defense until the facts warranting the concession can be verified. Unlike a defense recommendation, an attorney may not be able to reverse a concession recommendation. Accordingly, an attorney should recommend concession in only the most clear-cut situations. An attorney can always recommend concession in a supplemental defense letter after verifying all of the facts.

    2. It may be appropriate to recommend settlement in factual cases that are not continuing in nature and recommend a percentage basis for settlement if the facts have been particularly well developed. If the facts have not been well developed, an attorney may recommend settlement noting the absence of any particular basis for settlement.

    3. A case may involve an issue that requires coordination with other Associate Chief/Division Counsel offices. In the legal analysis, the attorney can either state the current Service position on the particular issue and explain that the Service is reconsidering the current position or explain why Field Counsel cannot render a current legal opinion. The attorney should then advise DJ that Field Counsel will recommend defense, settlement, or concession of the issue in the near future.


08. Miscellaneous. Counterclaim and Third-Party Complaint Authorization. An attorney may include in the defense letter an authorization for a counterclaim or third-party complaint authorization. _CCDM 34.5.1.1.2.6_.

09. Conclusion and Recommendation. The final section of the defense letter is the conclusion and recommendation. Generally, an attorney who has comprehensively discussed the issue or issues will not have to summarize the conclusions or recommendations as to each issue. For example, if an attorney has discussed two issues and has concluded that DJ should defend both issues (or settle both issues), the conclusion can state: "In view of the foregoing discussion, we recommend that this case be defended/settled." An attorney who recommends settlement for each issue, however, can suggest an overall basis for settlement. For example, in some cases where the Service has fully developed the facts, an attorney can recommend that the Government concede Issue No. 1 if the taxpayer would concede Issue No. 2. This specific recommendation would be unusual at the defense letter stage since normally the Government would need to develop more facts. In multiple-issue cases where Counsel has recommended defense for some issues, settlement as to some issues, and concession as to others, an attorney should summarize these positions by issue number but does not have to repeat the reasons for such recommendations.



    1. While an attorney should be cautious in recommending the concession of an issue, he should be more cautious in recommending the concession of an entire case. An attorney should recommend concession for issues at the defense letter stage only in the most clear-cut situations where the Government does not need additional factual development or legal analysis. Merely because we recommend concession of an issue, even in a single issue case, does not necessarily mean that the Government should concede the entire case. It is possible that valid setoffs would reduce or eliminate the amount of the refund. For example, if the period of limitations for assessment is open, new issues could result in a judgment in favor of the Government. Accordingly, before recommending concession of a case, an attorney should consider other factors in addition to the disposition of the issue or issues in suit.

    2. An attorney should include the classification of a case in the conclusion and recommendation section of the defense letter. _See_ _CCDM 34.5.1.1.1_.

    3. At the end of the conclusion and recommendation section, an attorney should generally describe the documents being enclosed. Normally, an attorney will forward the original administrative files received from the IRS Campus (or Area Director/Director of Field Operations in a trust fund recovery penalty case). Prior to forwarding the original file, a duplicate file should be created to keep with the Field Counsel’s legal file.


10. Since the Tax Division is responsible for analyzing jurisdiction in all cases, an attorney generally does not have to discuss jurisdictional facts in a defense letter. The Field Counsel attorney should determine whether there are obvious jurisdictional defects by carefully reading the complaint and other documents in the administrative file. An attorney should note any obvious jurisdictional defects or note that, after preliminary examination, an attorney has not discovered any obvious jurisdictional defects. If an attorney discovers a jurisdictional defect that will clearly dispose of the plaintiff’s claim, he should fully discuss the issue and generally need not discuss the substantive issues. For example, if the taxpayer did not bring suit within the applicable period of limitations, an attorney should generally discuss only this issue and recommend that DJ file a motion to dismiss. Similarly, the attorney may discover that the Service untimely assessed the tax. The attorney should recommend that DJ concede the case regardless of whether the taxpayer has properly raised this issue, or still has time within which to properly raise it.

11. An attorney does not have to discuss attorney’s fees if the taxpayer seeks attorney’s fees in the complaint or petition. In recommending defense of a case, or in authorizing a counterclaim or third-party complaint, attorneys should consider whether the Government’s position may lead to the award of attorney’s fees should the taxpayer prevail.

12. If a suit against the United States is brought in a state court, the attorney should make an initial determination concerning removal of the case to federal district court. _See_ CCDM 34.5.6.6.

13. The attorney should discuss the scope of any litigation hold in the case with the Tax Division and issue any litigation hold prior to drafting the defense letter. The attorney should memorialize the scope of the litigation hold in the defense letter. _See_ CCDM 34.7.1.1.4 for additional information regarding litigation holds.


**34.5.1.1.2.2** **(08-11-2004)**

##### Defenses

1. The following are some of the defenses that an attorney may raise in the defense letter.


**34.5.1.1.2.2.1** **(08-11-2004)**

###### Equitable Recoupment

1. Equitable recoupment is a defense in the nature of a setoff and is available in limited circumstances both to a taxpayer to defeat an assessment and to the Government to defeat a claim for refund. For example, a party litigating a tax claim in a timely proceeding may, in that proceeding, seek recoupment of a related and inconsistent, but now time-barred, tax claim relating to the same transaction. _United States v. Dalm_, 494 U.S. 596 (1990). This rule is very limited. If the overpayment and underpayment are for separate and distinct tax years and no single transaction or event was subject to inconsistent theories of taxation, there is no basis for recoupment. _United States v. Szopa_, 2000-1 U.S. Tax Cas. (CCH) 50,284 (7th Cir. 2000). It is not available where the mitigation provisions of section 1311 _et seq._ apply.


**34.5.1.1.2.2.2** **(08-11-2004)**

###### Equitable Estoppel

1. The taxpayer can assert equitable estoppel to prevent the Government from raising certain defenses to an action. Likewise the Government may sometimes assert equitable estoppel to prevent the taxpayer from asserting a claim even though the taxpayer has no other defense. Generally, equitable estoppel will prevent a party from asserting a claim or a defense when it would be grossly unfair to the opposing party.

2. The following elements must be present before a party can assert equitable estoppel:



   - There must be a representation or concealment of material facts.

   - These facts must be known at the time of the representation to the party being estopped.

   - The party claiming the benefit of the estoppel must not know the truth concerning these facts at the time of the representation.

   - The representation must be made with the intention or the expectation that it will be acted upon.

   - The representation must be relied upon and acted upon.

   - The party acting upon the representation must do so to his or her detriment.


3. Pursuant to the Federal Rules of Civil Procedure and the Rules of the Claims Court, estoppel is an affirmative defense and, accordingly, must be pleaded by the party relying on it. Fed. R. Civ. P. 8(c); Cls. Ct. R. 8(c). Therefore, an attorney should advise DJ of the defense of estoppel at the earliest possible time. The party asserting estoppel bears the burden of proof.


**34.5.1.1.2.2.3** **(08-11-2004)**

###### Affirmative Defenses

1. A party who does not timely assert affirmative defenses in the pleadings will be deemed to have waived such defenses and must subsequently request leave of the court and/or consent of counsel to assert them. _Zenith Radio Corp. v. Hazeltine_, 401 U.S. 321 (1971). The following is a list of some affirmative defenses (see Fed. R. Civ. P. 8(c); Cls. Ct. R. 8(c)):



   - Accord and satisfaction

   - Arbitration and award

   - Assumption of risk

   - Contributory negligence

   - Discharge in bankruptcy

   - Duress

   - Estoppel

   - Failure of consideration

   - Fraud

   - Illegality

   - Injury by fellow servant

   - Laches

   - License

   - Payment

   - Release

   - Res judicata

   - Statute of Frauds

   - Statute of limitations

   - Waiver

   - Any other matter constituting an avoidance or affirmative defense


2. The Field Counsel should advise DJ in the defense letter of all affirmative defenses. If Field Counsel discovers an affirmative defense after DJ answers the complaint, he should advise DJ as quickly as possible.

3. Generally, the party pleading an affirmative defense bears the burden of proof.


**34.5.1.1.2.2.4** **(08-11-2004)**

###### Res Judicata and Collateral Estoppel

1. Res Judicata. Under the doctrine of res judicata, when an issue is determined by a judgment on the merits, the litigating parties or anyone in privity with them cannot relitigate the case. In order for the doctrine to apply, the following requirements must be met:



1. The same cause of action (or question) must have been previously litigated. In income tax cases, each taxable year or period for each taxpayer is a separate cause of action. The question being presented is the tax liability for that year or period.

2. The previous litigation must have been before a court of competent jurisdiction, otherwise the earlier litigation would have been a nullity.

3. A final judgment on the merits must be entered. The judgment may, however be on appeal.

4. The parties to the earlier litigation must be identical or in privity with the parties to the later litigation.


2. If res judicata applies, it will foreclose the taxpayer from relitigating all matters that he presented and could have presented in the first cause of action. Thus in tax cases, once a taxpayer has litigated a particular year (or period), he cannot relitigate that particular year even as to issues that he did not raise in the litigation. Fraud upon the court or some other factor invalidating the judgment is an exception to this general rule. _Commissioner v. Sunnen_, 333 U.S. 591 (1948).

3. Collateral Estoppel. Collateral estoppel or estoppel by judgment prevents a party from relitigating, in a different cause of action, matters previously controverted and decided in a prior cause of action. One of the requirements of collateral estoppel in a tax case is that the controlling facts and applicable legal rules remain unchanged. _Commissioner v. Sunnen_, 333 U.S. 591 (1948).


**34.5.1.1.2.2.5** **(04-22-2021)**

###### Jurisdiction

1. For a discussion of federal district court and Court of Federal Claims jurisdiction, _see_ CCDM 34.1 and CCDM 34.2.

2. State Court Actions Affecting Substantive Tax Issues. When the United States is named as a party defendant in a state court proceeding for determination of a tax liability or the outcome of the proceeding could affect a substantive tax issue, the United States should move to have itself dismissed as a party.



1. If the Government is merely given notice of the proceeding, as opposed to being served with judicial process, no action need to be taken on behalf of the United States.

2. If no notice or process is served upon the Government but a request is made by an estate representative to the effect that the United States should intervene, no action need be taken on behalf of the United States since such action is not in the Government’s best interest and there is no waiver of sovereign immunity. _See_ CCDM 34.6.2.6, Intervention.

3. If the complaint is properly or improperly served upon the Government, Field Counsel should immediately refer the action to DOJ and recommend that DOJ remove the action to federal district court (if notice of removal may be timely filed), move to have itself dismissed as a party, and request that the case be remanded back to state court. This referral should be made at least 10 days prior to the 30-day deadline to remove, so that DOJ has sufficient time to consider and, when appropriate, to effectuate removal. Because the state court proceeding raises a federal question (affects a federal tax liability), removal is proper under 28 U.S.C. § 1441. Section 1446 of title 28 provides removal procedures, including the time period for filing notice of removal. _See_ CCDM 34.5.6.6, Removal to Federal Court.


3. State Court Actions Affecting Property to Which the Tax Lien is Attached. When the United States is named as a party defendant in a state court proceeding affecting property to which the tax lien is attached, 28 U.S.C. § 2410 waives the Government’s sovereign immunity. Section 1444 of title 28 authorizes the United Sates to remove an action brought pursuant to 28 U.S.C. § 2410 to federal district court. Field Counsel should immediately refer the action to DOJ and recommend that DOJ remove the action to federal district court, if notice of removal may be timely filed. This referral should be made at least 10 days prior to the 30-day deadline to remove provided in 28 U.S.C. § 1446, so that DOJ has sufficient time to consider and, when appropriate, effectuate removal.


**34.5.1.1.2.3** **(08-11-2004)**

##### Due Date

1. The due dates for refund defense letters are as follows:



|     |     |
| --- | --- |
| **_Due with DJ_** | **_Due with Reviewing Division_** |
| Later of 50 days after taxpayer files complaint or 40 days after Field Counsel receives complaint | If requires review, 10 days before DJ due date |

2. If a defense letter and administrative file to DJ cannot be timely sent to DJ, the attorney should call or write his counterpart in DJ to provide estimates of when the attorney can complete the letter.

3. In the meantime, the Field Counsel attorney should offer to assist the DJ attorney in preparing an answer to the complaint. For example, the Field Counsel attorney can review the administrative file to verify dates and payments that the taxpayer alleged in the complaint, or can make copies of documents in the administrative file if DJ did not receive a complete duplicate file. If it is practical to do so, an attorney may give the DJ attorney access to the administrative files. An attorney should avoid sending DJ the original files and suspending work on the case until the files are returned. If DJ needs the original files, the attorney should retain an entire duplicate administrative file in order to complete the defense letter.

4. The due date of non-refund defense letters is based on coordination with DJ with respect to the answer due date.


**34.5.1.1.2.4** **(08-11-2004)**

##### Review of Defense Letters and Coordination with Field Counsel

1. Associate Chief Counsel offices must review all defense letters containing issues listed in Exhibit 35.11.1-1. Defense letters requiring review should be sent to the Technical Services Support Branch (TSS4510) for assignment to the appropriate Associate office. The Field Counsel attorney should, for information purposes, send a copy of all S.O.P. defense letters to the Associate office charged with the responsibility of the subject matter of the action involved.

2. The Associate office will ensure that the Field Counsel attorney’s position in a defense letter agrees with the Service’s position, or Chief Counsel’s interpretation of applicable statutes, regulations, rulings, and decided cases.

3. To the extent feasible and within the time limitations, the Associate office attorney will generally call the field office and discuss all substantial changes it proposes to make. Within guidelines established in each office, the Field Counsel attorney should inform the reviewer of all proposed changes. The Associate office attorney will advise the field by memorandum, as appropriate, of the basis for its substantial changes.

4. The Associate office attorney may also make minor changes in a defense letter such as citing additional case authority or eliminating cited cases; clarifying the factual or legal discussion; and correcting erroneous citations, misspelled words, or poor grammar. The Associate office attorney determines whether a change is substantial or minor, whether it is feasible to coordinate the proposed changes with Field Counsel and makes the final decision on all changes.

5. The Associate office attorney must do the following:



1. Ascertain the facts of the case and research the applicable statutes, regulations, rulings, case law and office positions.

2. Verify that the legal arguments are consistent with the facts in the case.

3. Determine whether the Field Counsel’s position agrees with the current Service position; whether the Service is currently considering another position that may affect or be affected by the position in the defense letter; and whether the proposed position is consistent with the position Counsel has taken in other cases pending in Tax Court, district courts, Court of Federal Claims, appellate courts, or the Supreme Court.

4. Ascertain whether there are any technical problems involved which necessitate coordination with other divisions of the Chief Counsel’s office or with the Commissioner’s office.

5. Analyze whether Field Counsel’s argument is logical and sound and analyze the overall effectiveness of the letter.

6. Inform his or her supervisor of any problem or potential problem in submitting the defense letter to DJ or presenting the recommended legal argument to the court.


6. The reviewing attorney should not propose changes that merely reflect different writing styles. The reviewing attorney’s supervisor must approve all proposed changes.


**34.5.1.1.2.5** **(08-11-2004)**

##### Counterclaims and Third-Party Complaint Authorization

01. Counterclaim. Under section 7401, the Secretary can authorize the filing of a counterclaim or third party complaint. Field Counsel should authorize counterclaims only under the following circumstances:



    1. There must be an unpaid assessment against the plaintiff for tax, penalty, or interest. The only exceptions to this rule are cases involving erroneous refunds and the liability of lenders for withheld taxes.

    2. The unpaid liability must relate to the same type of tax that is in suit. If the plaintiff owes a different type of tax, the Service would pursue normal collection procedures.

    3. Where the counterclaim relates to the periods in suit, the Service does not have to raise the same issue, as long as the same type of tax is involved. Where a period not in suit is involved, however, the counterclaim should involve the same or similar issue.

    4. The Government’s ability to collect must not be placed in jeopardy. Where deferring collection may jeopardize the Government’s ability to collect the unpaid assessment, then instead of authorizing a counterclaim, Field Counsel should initiate collection action. The appropriate Area Director/Director of Field Operations will normally determine if jeopardy exists.


02. Compulsory Counterclaim. A compulsory counterclaim is defined in the Federal Rules as a claim that the pleader has against any opposing party, if it arises out of the transaction or occurrence that is the subject matter of the opposing party’s claim. Fed. R. Civ. P. 13(a). The Claims Court Rules define a compulsory counterclaim as any claim, which at the time of serving the answer, the defendant has against any plaintiff, if it arises out of the transaction or occurrence that is the subject matter of the opposing party’s claim and does not require for its adjudication the presence of third parties of whom the court cannot acquire jurisdiction. But the answer need not state the claim if at the time the action was commenced the claim was the subject of another pending action. Cls. Ct. R. 13(a).



    1. Where the Government fails to make a compulsory counterclaim, such claim will be barred by the doctrine of res judicata after the court decision becomes final. If the claim is the subject of another pending action, the counterclaim will not be considered compulsory. The Field Counsel attorney should review Federal Rule of Civil Procedure 13 to determine whether the subject counterclaim is permissive or compulsory. If the Government fails to make a compulsory counterclaim, res judicata will prevent the Government from making such counterclaim after the court decision becomes final. Where the potential counterclaim relates to a taxable period or a type of tax not in suit, the counterclaim is permissive rather than compulsory.


03. Third-Party Complaint. The Field Counsel attorney should review Federal Rule of Civil Procedure 14 for rules about third-party complaints. In most federal courts, the third-party complaint need not be limited to the relief sought by plaintiff, but may seek additional affirmative relief. Fed. R. Civ. P. 14. The Rules of the Claims Court permit third-party practice in tax cases. Cls. Ct. R. 14. Field Counsel should authorize third-party complaints only under the following circumstances:



    1. There must be an outstanding assessment against the third party. A single exception involves the liability of lenders for withheld taxes imposed under section 3505.

    2. The unpaid liability must relate to the same type of tax that is in the suit.

    3. The unpaid liability must relate to the same or a similar issue in suit.

    4. The Government’s ability to collect must not be in jeopardy. Where deferring collection may jeopardize the Government’s ability to collect the unpaid assessment, then instead of authorizing a third-party complaint, Field Counsel should initiate collection action. The appropriate Area Director/Director of Field Operations will normally determine if jeopardy exists.

    5. Generally, if the preceding conditions are met, the periods involved in the Government’s third-party complaint need not be identical to those already in suit.


04. Because counterclaims and third-party complaints are in the nature of collection actions, the general ten year period of limitations for bringing a collection action under section 6502(a) is applicable, absent a waiver or an exception to the general rule. The running of the ten year period is not suspended when the taxpayer files a complaint for refund. It is possible that the period of limitations for bringing a counterclaim or third-party complaint will expire before the Government is required to file its Answer in the refund suit. In these situations, attorneys should immediately authorize a counterclaim or third-party complaint, and alert DJ to the statute of limitations problem.

05. Section 6331(i), with certain exceptions, prohibits levy to collect the unpaid portion of a divisible tax that is the subject of a refund suit from the plaintiff or plaintiffs in that suit. The section also prohibits the commencement of a proceeding in court to collect the unpaid tax. Consequently, in refund litigation cases involving divisible taxes, the appropriate Area Director/Director of Field Operations must suspend collection unless jeopardy is found or another exception applies. The field attorney should contact the appropriate Area Director/Director of Field Operations to suspend collection. If jeopardy is identified, Field Counsel should be contacted prior to any collection action being taken to assure that section 6331(i) is not violated.

06. In cases involving counterclaims pursuant to section 7422(e), the Field Counsel attorney will generally ask the appropriate Area Director/Director of Field Operations to suspend collection if the interests of the Government are adequately protected and the revenue is not in jeopardy. Even though the Service has suspended collection activity, it would generally credit any overpayments due the taxpayer against unpaid liabilities pursuant to section 6402.

07. Field Counsel should authorize counterclaim and third-party complaints as expeditiously as possible and, under normal circumstances, at the same time the attorney writes the defense letter.

08. Field Counsel can authorize counterclaims and third-party complaints in the Conclusion portion of the defense letter or by a separate letter to DJ. Field Counsel can authorize both a counterclaim and one or more third-party complaints in the same defense letter. This authorization should include the following information:



    - A citation to section 7401

    - The taxpayer’s identifying number (social security number or employer identification number) in parentheses after the name of each person for whom a counterclaim or third-party complaint is authorized

    - Current transcripts of account


09. Aside from the legal proceeding that Field Counsel is specifically authorizing, whether for a counterclaim or third-party complaint, Field Counsel should also authorize any other legal proceedings for the collection of the outstanding assessment. This authorization should include the following information:



    - The type of tax, penalty or interest involved,

    - The total amount outstanding,

    - The periods covered by the assessments.


10. Field Counsel should also do the following:



    1. Authorize a counterclaim for the amount that the plaintiff has failed to pay, without taking into account assessed payments by third parties.

    2. Authorize third-party complaints for the amounts that the particular third party has failed to pay, without taking into account payments that the plaintiff or other third parties have paid.

    3. Inform DJ about any previously stated incorrect amounts but need not write a second authorization.

    4. Write a second authorization for an additional period for the counterclaim or third-party complaint.

    5. Request that DJ inform them of any action taken pursuant to the authorization.


**34.5.1.1.2.6** **(08-11-2004)**

##### Reporting of a Tax Case involving a Member of an Indian Tribal Government

1. Generally, Field Counsel should contact Assistant Chief Counsel (APJP) and Area Counsel (TEGE) when working on any case involving taxation of an member of an Indian Tribal Government, in which the member of an Indian Tribal Government claims exemption on account of his status as a member of an Indian Tribal Government. An attorney should state in the defense letter that DJ should inform the Solicitor, Department of the Interior, about this case pursuant to the 1972 agreement between the Attorney General and the Secretary of the Interior.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part34/irm_34-005-001#addtoany "Show all")

A2A