---
url: "https://www.irs.gov/irm/part35/irm_35-006-002"
title: "35.6.2 Trial of the Case | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-006-002#main-content)

- 35.6.2  [Trial of the Case](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825154069680)
  - 35.6.2.1  [Tax Court Trials in General](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825126763360)
  - 35.6.2.2  [Entry of Appearance](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825126761328)
  - 35.6.2.3  [Etiquette in Addressing the Court and Courtroom Decorum](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825154096384)
  - 35.6.2.4  [Preliminary Matters](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825154250480)
    - 35.6.2.4.1  [Motions at Trial](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825126757216)
    - 35.6.2.4.2  [Filing Stipulation of Facts and Stipulated Exhibits](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825126755520)
    - 35.6.2.4.3  [Excluding Witnesses](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825154546144)
  - 35.6.2.5  [Petitioner’s Opening Statement](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825158783632)
  - 35.6.2.6  [Abandoned or New Issues, Clarifying the Record](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825158780784)
  - 35.6.2.7  [Respondent’s Opening Statement](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825154247888)
  - 35.6.2.8  [Party with Burden of Proof to Proceed First](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825154244432)
  - 35.6.2.9  [Reliance on Presumption of Correctness](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825154241328)
  - 35.6.2.10  [Documentary Evidence](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825126333360)
    - 35.6.2.10.1  [Numbering of Exhibits for Identification Purposes and Offering Exhibits](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825126326416)
    - 35.6.2.10.2  [Keeping Track of Exhibits](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825126324080)
    - 35.6.2.10.3  [Objections to Exhibits Offered by Petitioner](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825126321344)
    - 35.6.2.10.4  [Withdrawal of Exhibits for Photocopying](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825126319072)
  - 35.6.2.11  [Direct Examination and Cross-Examination of Witnesses](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825126311328)
    - 35.6.2.11.1  [Objections to Testimony](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825126304496)
  - 35.6.2.12  [Trial of "S" Cases](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825126301696)
  - 35.6.2.13  [Motion to Conform Pleadings to Proof](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825126296272)
  - 35.6.2.14  [Briefs](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825126294176)
  - 35.6.2.15  [Transcripts](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825126288240)
  - 35.6.2.16  [Bench Opinions](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825126527984)
  - 35.6.2.17  [Post-Trial Calendar Report](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825126523024)
    - 35.6.2.17.1  [Post-Trial Calendar Report Narrative](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825126518816)
  - 35.6.2.18  [Trial in Collection Due Process (CDP) Cases](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825126512800)
    - 35.6.2.18.1  [Objections to Evidence Not in the Administrative Record](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825126511104)
    - 35.6.2.18.2  [Appeals Testimony](https://www.irs.gov/irm/part35/irm_35-006-002#idm139825126496800)

# Part 35. Chief Counsel Directives Manual Tax Court Litigation

# Chapter 6. Trial

# Section 2. Trial of the Case

* * *

## 35.6.2 Trial of the Case

#### Manual Transmittal

December 26, 2023

#### Purpose

(1) This transmits revised CCDM 35.6.2, Trial of the Case.

#### Background

CCDM 35.6.2 is revised to update procedures relating to the conduct of trials before the United States Tax Court, including courtroom decorum, entries of appearance, and ordering of transcripts. Certain organizational and cross references are updated.

#### Material Changes

(1) CCDM 35.6.2.2(1) is revised to update procedures on making entries of appearance at Tax Court trials.

(2) CCDM 35.6.2.3(2) is added to describe the creation and use of audio recordings by the Tax Court’s court reporters for the purpose of confirming the accuracy of a final, written transcript, and to set forth best practices for attorneys appearing before the court to assist in ensuring the accuracy of the audio recordings produced by the court reporters.

#### Effect on Other Documents

CCDM 35.6.2, dated July 20, 2018, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(12-26-2023)

Richard G. Goldman

Deputy Associate Chief Counsel

(Procedure & Administration)

**35.6.2.1** **(08-11-2004)**

### Tax Court Trials in General

1. The time for the trial of a case is usually established at the end of the calendar call, following a short recess of the court. The issues concerning how trials are conducted are discussed in more detail below. In general, trials in the Tax Court are relatively short, and most of the documentary evidence is stipulated by the parties. In addition, the post-trial briefs give the parties an opportunity to tie the evidence together, and to argue the strengths of their respective positions, under the facts and the law.


**35.6.2.2** **(12-26-2023)**

### Entry of Appearance

1. When the case is called for trial, verbal entries of appearance must again be made by the attorneys for the respective parties, even though they appeared at the calendar call. An appearance on behalf of the petitioner is usually entered first, followed by the entry of appearance by the Field attorney.

2. The court’s opinion will show, as counsel for respondent, the name of the Field attorney who entered an appearance at the trial of the case. Other attorneys may enter an appearance after the trial, or in fully stipulated cases submitted under T.C. Rule 122(a) without a trial. The court’s opinions generally include the names of any attorneys who signed the briefs.

3. Only attorneys who actually try a case, prepare a case for submission under T.C. Rule 122(a), write the brief, or otherwise perform important and substantial work on the submission of the case to the court should enter their appearances as attorneys of record for the respondent. For example, the Associate Area Counsel normally will not enter an appearance or be listed as Counsel of Record for the respondent unless he or she actually participated in the trial or briefing of the case. There may also be instances in which an attorney other than the Field attorney performs such important and extensive work on a case for submission to the court that he or she should be listed as one of the Counsel of Record, such as an Associate Chief Counsel office attorney who substantially participated in the preparation of the brief. The Associate Area Counsel should carefully consider who to include in listing respondent’s Counsel of Record. If there appears to be an error in the court’s opinion on the listing of respondent’s attorneys’ names, Procedure and Administration (P&A) Branch 6 or 7 should be contacted immediately, as a correction usually can be made by the court before the opinion is permanently published.

4. If a brief or other memorandum is submitted in connection with an argument on a motion, the name of the attorney who makes the oral argument should be listed on that brief or memorandum in addition to the name of the author of the document, and both names may appear on a written opinion on the motion.


**35.6.2.3** **(12-26-2023)**

### Etiquette in Addressing the Court and Courtroom Decorum

1. The Field attorney should always stand to address the court. The attorney should not approach the bench unless the court has granted permission or has requested him/her to do so. Neither counsel nor a witness should read newspapers or other materials while the court is in session, and must refrain from eating, drinking, chewing gum, or carrying on private conversations during the session. Proper attire should be worn at all times while the court is in session. Cell phones must be silenced or disabled while in the courtroom. Some judges have specific decorum rules that may be provided at the beginning of a trial session and must be respected.

2. The Tax Court’s court reporters typically create and use reference audio recordings to ensure that written transcripts are accurate, including but not limited to trial transcripts, pretrial hearing transcripts, and deposition transcripts. Section 7521, which governs IRS procedures for recordings of taxpayer interviews, does not apply to the creation and use of a reference audio recording by the Tax Court’s court reporters. Since the Tax Court’s court reporters utilize audio recordings to create transcripts, the attorney must remember to speak distinctly and slowly enough to be understood for the recording, stay near the microphone, and avoid making any external noises that may interfere with the recording. The attorney should also remain available to assist the court reporter with the spelling of any unusual names or phrases.


**35.6.2.4** **(08-11-2004)**

### Preliminary Matters

1. When the case is called for the trial, the parties have an opportunity to address any preliminary concerns with the court, and may ask the court to clarify a matter.


**35.6.2.4.1** **(08-11-2004)**

#### Motions at Trial

1. Motions pertaining to the pleadings, jurisdiction, etc., which were previously overlooked, must be presented and disposed of when the case is called for trial.


**35.6.2.4.2** **(08-11-2004)**

#### Filing Stipulation of Facts and Stipulated Exhibits

1. When the case is called for trial, the stipulation of facts and other stipulations are offered into evidence, even if they were lodged with the court at the calendar call. The letters and numbers of any exhibits attached to the stipulation of facts are read into the record (e.g., "The Stipulation of Facts consists of paragraphs one through fifteen and includes Exhibits 1-J through 15-R." ). If there is no stipulation of facts, the Field attorney must be prepared to explain its absence to the court. The Field attorney should bear in mind that the record must contain a copy of the notice of deficiency or other determination letter and a clearly legible copy of all relevant tax returns, or a printout of electronically filed returns.

2. If possible, the attorney should avoid the oral stipulation of new material at trial. The court should be asked to allow an oral stipulation to be reduced to writing if it covers an important subject or is lengthy. That is particularly necessary because it is usually not practical to have the court reporter read back the stipulated matter. An oral or a written stipulation should be approved by the trial reviewer, even if that requires asking for a short recess.

3. Any admissible depositions may be offered into evidence at that time, or at a more appropriate time during the course of the trial. At the time of the offer, the clerk’s attention should be directed to the numbers and letters of any attached exhibits. Where possible, the parties should stipulate to the admissibility of the depositions.

4. If respondent has incorporated any reservations or objections in the stipulation of facts, they should be explained and supported when the stipulation of facts is submitted, to allow the court to rule on the admissibility of the evidence in question.


**35.6.2.4.3** **(08-11-2004)**

#### Excluding Witnesses

1. Where appropriate, an oral motion to exclude witnesses from the courtroom should be made when the case is called, before the trial begins. Generally, the court will order the exclusion of proposed witnesses. The petitioner, however, cannot be excluded. In addition, an officer or employee designated as the representative of a non–natural party, such as a corporation, may not be excluded. _See_ T.C. Rule 145(a); _Griffith v. Commissioner_, T.C. Memo. 1988–123. Furthermore, the court may also exempt other prospective witnesses from exclusion if they are shown to be essential to the presentation of a party’s case, such as expert witnesses. Because the court may, however, exclude respondent’s expert witness under the rule, consideration should be given to having a non–testifying consultant available to provide assistance to the Field attorney during the trial of a large, complex case. _See Stotler v. Commissioner_, T.C. Memo. 1987–275. When preparing the case for trial, the attorney should consider the impact of the exclusion of witnesses on his or her trial strategy.


**35.6.2.5** **(08-11-2004)**

### Petitioner’s Opening Statement

1. Generally, the court will ask the party bearing the most significant burden of proof (usually the petitioner) to make the first opening statement. In small cases, however, the court frequently asks the Field attorney to make the first opening statement. The Field attorney should listen carefully to the petitioner’s opening statement, and may wish to take notes. Any issues not discussed by petitioner should be noted. Any new issues or matters raised by petitioner should also be noted. Although the court may interrupt a party’s opening statement, the opposing party should never do so.


**35.6.2.6** **(08-11-2004)**

### Abandoned or New Issues, Clarifying the Record

1. At the conclusion of petitioner’s opening statement, the court will inquire whether respondent chooses to make an opening statement. Prior to making the opening statement, if any of the following questions have arisen, they must be clarified by the Field attorney:



1. If petitioner makes no mention of an issue and it is unclear whether the issue is being conceded, the Field attorney should normally state to the court that respondent assumes that petitioner is conceding the issue and request confirmation.

2. If petitioner raises an unexpected new issue without having amended his or her pleading, and respondent is prejudiced by surprise and inability to develop and defend against the new issue, the Field attorney should state respondent’s position that such issue is not properly before the court. Any motions to amend the pleadings to raise any new issues made by petitioner at any time during trial should be opposed if prejudicial to the respondent. When the Field attorney is either uncertain of the nature of the motion or is not prepared immediately to oppose the motion with all relevant arguments, the attorney should request the court to require petitioner to put the motion in writing, and ask the court for sufficient time to respond.

3. With discovery available in the Tax Court, it is rare for the court to allow either party to amend the pleadings to raise a new issue at trial. When the court grants petitioner’s motion, the Field attorney may need to move for a continuance in order to properly develop and defend against the new issue.


**35.6.2.7** **(08-11-2004)**

### Respondent’s Opening Statement

1. Respondent’s opening statement must be carefully prepared. It should be based upon a well developed outline, rather than a prepared statement to be read in court. The advantage of the outline is that it lists the points to be covered, while allowing for flexibility and responsiveness with respect to petitioner’s opening statement. The statement should be concise and to the point, and should inform the court of each basis upon which the respondent relies as to each issue or defense. It should set forth the significance of any facts which may help the court to understand respondent’s theory of the case, and to make evidentiary and other rulings during the trial. As such, the Field attorney should view his or her opening statement as an important opportunity to convince the judge that respondent has a strong case. It is unnecessary to restate the facts in cases with uncomplicated facts which have been fairly stated by petitioner. The Field attorney should point out the important facts and their relationship to respondent’s theory of the case. The presentation of respondent’s theory on each issue should be based upon a specific office position and should be supported by research and the theory to be presented on brief. The attorney should avoid making any statements which could prevent the presentation of legal arguments or positions in the brief. Generally, the attorney should avoid stating whether respondent does or does not rely upon any particular facts.


**35.6.2.8** **(08-11-2004)**

### Party with Burden of Proof to Proceed First

1. In most cases, the burden of proof (persuasion and production) is on petitioner. The court usually requires petitioner to present his case first on those issues upon which he has the burden of proof. Where each party has the burden of proof as to one or more issues and each party has out-of-town witnesses, it may be appropriate to request the court to rule on the order of the trial at the calendar call or earlier. Respondent’s position is that petitioner is always to proceed first on any issue for any year upon which petitioner has either the burden of proof or the burden of going forward. If the court rules otherwise over respondent’s objection, respondent must be prepared to proceed. If the respondent is directed to proceed first in any civil fraud case or any case in which conflicting testimony is anticipated, respondent should consider calling petitioner as his first witness. That gives respondent the advantage of having locked in petitioner’s version of the facts before the other evidence is presented.


**35.6.2.9** **(08-11-2004)**

### Reliance on Presumption of Correctness

1. The court tries not to decide issues adversely to petitioner solely on the basis of the statutory presumption of correctness. To assist the court and to represent the client, the Field attorney should offer all available evidence of material facts which support respondent’s determination, rebut petitioner’s position, or may help the court to make a proper ruling. Respondent’s counsel’s obligation as a public servant is to assist the court to reach the correct result, even if it is adverse to respondent’s original determination.


**35.6.2.10** **(12-26-2023)**

### Documentary Evidence

1. Tax returns are usually included as exhibits attached to the stipulation of facts. Exhibits attached to a stipulation of facts are introduced into evidence upon the court’s acceptance of the stipulation. Exhibits introduced into evidence at trial must first be identified by a witness, unless such identification is waived by opposing counsel or the document is self-authenticating. The common practice is to hand an exhibit to the clerk and to ask that it be marked for identification purposes. The witness may then be asked to identify it. If there are a number of exhibits to be offered into evidence at trial, these exhibits may be marked by the clerk before the trial. Copies of exhibits should be given to petitioner’s counsel before trial as required by the court’s Standing Pretrial Order. All exhibits which are not admitted into evidence should have been marked for identification purposes for a complete record. That is necessary for an offer of proof and an appeal of an evidentiary ruling.

2. Exhibits are marked for identification purposes by the clerk, and not by the Field attorney. The court’s rules provide for the numbering of the exhibits, according to whether they are joint exhibits, or are offered by either petitioner or respondent. The exhibits introduced at the trial are numbered sequentially after the exhibits in the stipulation of facts, and are designated as offered by petitioner or respondent.

3. The court generally only admits into evidence copies of exhibits which are legible and accurate. If possible, the original exhibit should be in the courtroom for examination when a copy is offered into evidence. Only exhibits which are offered into evidence and retained by the court are stamped by the court. If the witness is unable to identify the copy, it may be necessary to show him the original, and to ask if the copy is an accurate photocopy of the original. If the record has been left open, for example, so that an uncertified copy of a document may later to be substituted with a certified copy, an appropriate motion for substitution may be filed. See Exhibit 35.11.1–119, Motion for Substitution of Exhibits.


**35.6.2.10.1** **(08-11-2004)**

#### Numbering of Exhibits for Identification Purposes and Offering Exhibits

1. The identification of the exhibit in the record should be complete and accurate in the Field attorney’s statement offering it. If an original is offered, the identification should so state. A request may be made, when the exhibit is offered, to substitute a photocopy. When it is necessary to introduce waivers of the statute of limitations, each waiver should be introduced separately and not as part of the return, for a clear identification in the record. When offering an exhibit into evidence, the proper procedure is to refer to it by number as the exhibit previously marked for identification and to offer it into evidence.


**35.6.2.10.2** **(08-11-2004)**

#### Keeping Track of Exhibits

1. Where the Field attorney has a number of exhibits to offer into evidence at the trial, a check list should be prepared beforehand. When an exhibit is admitted into evidence, it can be noted on the list. During the course of the trial, a record should be made of petitioner’s exhibits as they are offered into evidence, identifying them by exhibit number and a brief description. It is advisable to confirm that all documents marked for identification were received in evidence. If a witness used the court’s copy of a document during his testimony, the Field attorney should confirm that the document was returned to the clerk, and made a part of the court’s record.


**35.6.2.10.3** **(08-11-2004)**

#### Objections to Exhibits Offered by Petitioner

1. Thirty-day letters and revenue agent’s reports not incorporated by reference or referred to in the notice of deficiency are generally not admissible into evidence when offered by petitioner because they are not relevant. Respondent’s determination is set forth in the notice of deficiency or other determination letter and in any pleadings filed by respondent. Depending on the type of case and the burden of proof, however, the court may rule otherwise. While preparing for trial, the Field attorney must determine whether the revenue agent’s report is admissible, and be prepared to object if it is not relevant.


**35.6.2.10.4** **(12-26-2023)**

#### Withdrawal of Exhibits for Photocopying

1. Before the trial, the parties should have exchanged all documents to be marked for identification purposes, except for those to be used to impeach a witness’s testimony. _Barger v. Commissioner_, 65 T.C. 925 (1976). If respondent needs a copy of an exhibit offered by petitioner, a motion should be made at the end of the trial to withdraw petitioner’s exhibit to copy it. See Exhibit 35.11.1–120, Motion to Withdraw Exhibit for Purposes of Copying. When a Tax Court decision is appealed, the exhibits are sent to the court of appeals by the Clerk of the Tax Court. The Field attorney must send the Chief Counsel’s legal and miscellaneous files, containing a complete copy of the record including all exhibits, to the Department of Justice (DOJ) for the appeal.

2. The attorney who withdrew the exhibits for photocopying is responsible for returning them to the court as soon as possible. The exhibits must not be retained by the field any longer than necessary to photocopy them. In instances in which original documents are introduced, but the court allows the substitution of photocopies, it is advisable to have photocopies of the originals made during the court session and provided to the court at that time. In instances in which the original exhibit is to be retained by the court, but a copy is needed, a request should be made of the court at the trial for permission to withdraw the original for the purposes of making a photocopy. In this latter instance, the original exhibit must be returned to the court promptly after the photocopy is made. After the session, if respondent is missing any exhibits, arrangements should be made either with petitioner or through Procedure & Administration to obtain copies from the court.

3. In some instances, exhibits of either party may not be susceptible of photocopying, such as exhibits contained in bound volumes, etc. If the exhibits are needed to prepare the respondent’s brief, a motion should be made at the close of the trial to retain the exhibits for that purpose. Those exhibits may be returned to the court after coordinating with the attorney assigned to review the brief, or when the brief is submitted to the court for filing.

4. Before the close of the trial session, the calendar administrator should check with the clerk of the court to confirm that the Field attorneys provided sufficient copies of all documents filed, including motions and settlement stipulations.


**35.6.2.11** **(08-11-2004)**

### Direct Examination and Cross-Examination of Witnesses

1. If the Field attorney wishes to remain seated at the counsel table while examining witnesses, he should request the court’s permission to do so. The attorney should always stand when addressing or being addressed by the court. If the attorney cannot clearly and distinctly hear the witness’s answer, the judge should be requested to instruct the witness to speak louder and more distinctly. If any question arises as to the witness’s answer, the attorney should request the court to ask the reporter to replay it. If there is any doubt as to whether the witness heard or understood the question, it should be repeated or withdrawn and rephrased.

2. The Field attorney should avoid going to the witness stand except when it is necessary to hand something to the witness, to point out something in a document, or to help the witness find a particular paper. The attorney should ask for the court’s permission to approach the witness, and should return to the counsel table as soon as possible. When it is essential to examine a witness at the stand due to the necessity of pointing out certain items in an exhibit in connection with the examination, the attorney should avoid standing between the witness and the judge, the reporter, or opposing counsel. The attorney must remember to speak only when near a microphone.

3. A Tax Court trial is different from a jury trial. Although inexperienced attorneys should seek training and read literature on the subject of cross-examination, they should also discuss the case and the handling of prospective witnesses with a reviewer or other experienced attorneys. Good cross-examination is not possible without good preparation, including a complete mastery of the facts. While it is usually not possible to prepare specific questions to be asked on cross-examination, an outline of the matters to be covered should always be made. Good cross-examination is not possible unless the attorney has paid close attention to the direct examination and made notes of areas to be covered. Two general rules to keep in mind for cross-examination are to phrase the questions narrowly to require specific answers, and to ask the questions in an order which prevents the witness from anticipating crucial questions. Never ask questions on cross-examination to which the answers are unknown or may not be reasonably anticipated, although surprises are sometimes unavoidable. With both direct and cross-examination, it is critical to listen to the witness’s responses, and to react accordingly, and not to read from a script.


**35.6.2.11.1** **(08-11-2004)**

#### Objections to Testimony

1. To object to a question asked by petitioner, the Field attorney should state all the grounds on which the objection is based. The attorney should not object to leading questions on preliminary matters, but should object to leading questions on matters of substance. The record should reflect the witness’ testimony, and not that of his counsel. The attorney should object to any evidence offered which contradicts a fact stated in the stipulation of facts. The Field attorney should object to compound questions or questions which are not stated clearly. If the Field attorney did not understand a question, the witness probably also did not understand it either. Immediate consideration should be given to moving to strike nonresponsive answers to the Field attorney’s own questions. To the extent possible, respondent’s counsel should anticipate any evidentiary problems with respect to either petitioner’s case or respondent’s case. Due to the infrequency of Tax Court trials, a brief review of the rules of evidence before every session is advisable.


**35.6.2.12** **(12-26-2023)**

### Trial of "S" Cases

1. T.C. Rule 174(b) provides that trials of small tax cases will be conducted as informally as possible, consistent with orderly procedure, and any evidence deemed by the court to have probative value will be admissible. Where a **pro se** petitioner is doing their best to present their case to the court, technical evidentiary or procedural objections should not be made. The Field attorney should assist the pro se petitioner to bring out all the facts, and the cross-examination should be for the purpose of presenting to the court all pertinent and competent evidence. The objective of the "S" case procedure is to provide a forum where the taxpayer can have a day in court at an early time and at a reasonable cost. There may be cases in which, due to the particular circumstances involved, strict application of evidentiary or procedural rules should be insisted upon, but such objections should be for the purpose of enabling the court to dispose of the case in an orderly manner based on the relevant evidence.

2. Small case calendars are normally issued at least two months before the session. If the petitioner did not attach a copy of the notice of deficiency or other determination letter to the petition, the Field attorney should provide a copy to the court for its file at the calendar call.

3. In a deficiency case, the Field attorney must make no commitments as to what collection, audit, or other activity the Service will take with respect to the case being tried, any later years, or a related taxpayer. The Field attorney is not authorized to bind the Service in that regard. The Field attorney may assist the petitioner in the initial contact with collection, however.


**35.6.2.13** **(09-18-2012)**

### Motion to Conform Pleadings to Proof

1. Before the trial record is closed, it may be necessary to move for leave to file an amendment to the answer to conform the pleadings to the proof. The court is liberal in granting such motions unless a party can show prejudice. Such a motion may be made where the facts established at trial would support an increased deficiency or a penalty not asserted in the notice of deficiency or raised in the pleadings. See CCDM 35.3.3.7, Motion to Amend to Conform Pleadings to Proof.


**35.6.2.14** **(09-18-2012)**

### Briefs

1. At the close of the trial, the judge usually orders the parties to file either seriatim or simultaneous briefs. The Field attorney should anticipate potential time limitation problems which could delay the timely preparation and filing of the brief, including the time required for review.

2. T.C. Rule 151(b) provides the standard times for filing briefs, which are 75 days after the conclusion of the trial for the opening brief, and 45 days thereafter for a reply brief or an answering brief. If the attorney anticipates that additional time beyond that provided in the rules will be needed for the preparation or the review of the brief, such problems should be pointed out to the court in the request for additional time, and the Field attorney should solicit petitioner’s agreement.

3. The attorney should provide the brief due dates to the calendar administrator for the Post-Trial Calendar Report.

4. Many of the judges impose page limitations for briefs. Attorneys must strictly comply with any such limitations, and with the format and the spacing provisions of T.C. Rule 23(d). If the judge establishes a page limitation, the Field attorney must clarify, on the record, any ambiguities as to what is intended, before the court goes into recess and the parties leave the courtroom. For example, it may not be clear whether the court intends for the page limitation to apply to the entire brief, including the cover page, the table of contents, and the citations page, or only to the narrative sections of the brief. See CCDM 35.7.2.1(3), Form and Contents of Brief, concerning page limitations.

5. The Field attorney should avoid making any kind of an agreement with the court to submit the briefs in a CD-ROM format, with hyperlinks, due to present budgetary and technical uncertainties and limitations. If the judge instructs the parties to file their briefs in that format, the attorney should immediately contact Procedure & Administration Branch 6 or 7. See CCDM 35.7.2.1(4), Form and Contents of Brief, for a discussion of hyperlinked briefs.


**35.6.2.15** **(12-26-2023)**

### Transcripts

1. Four types of transcripts can be ordered: Standard (30 calendar days); Expedited (seven calendar days); Daily (24 hours); and Motions (three business days). The cost of each type is different. The standard transcript is the least expensive and is usually ordered. Motions transcripts are ordered from motions sessions conducted weekly in Washington, D.C.

2. Transcripts are available for a nominal charge in electronic form on a diskette if a paper version is purchased.

3. For budgetary reasons, permission must be obtained in advance from the Counsel to the Associate Chief Counsel (P&A), to order any type other than standard. (Respondent has a blanket purchase order for motions transcripts from Washington, D.C. motions sessions.) These requests should be made as far in advance of the trial as possible. Prior approval can be requested by email or fax, and once approval is obtained, it should be memorialized. The request for a nonstandard transcript purchase must contain the name and docket number of the case, the trial date(s) and location, and a narrative justification explaining the need for an expedited or a daily transcript. Attorneys are not authorized to negotiate a delivery schedule other than the delivery schedule contained in the vendor’s contract. For example, an attorney may not negotiate a five-day turnaround. Also, special arrangements must be made in advance with the Tax Court’s contracting court reporting company for daily transcripts. Ordinarily, the arrangements for daily transcripts should be made seven calendar days (excluding legal holidays) before the trial session.

4. Either at the beginning of the trial or at its conclusion, a written request on the form supplied by the reporter should be made for a copy of the transcript. Standard transcripts are to be ordered. As a routine matter, one copy of the transcript may be ordered. With the approval of the reviewer, however, the Field attorney may order additional copies of the transcript, or an electronic copy on disk. Approval for additional copies of the transcript must also be given by the Counsel to the Associate Chief Counsel (P&A). If the case is settled after the request for a transcript has been given to the reporter but before the typewritten transcript has been prepared, the request should be secured from the reporter by the attorney and destroyed. If the reporter cannot return the request, a handwritten memorandum canceling the request should be given at that time to the reporter by the attorney, the reporter asked to acknowledge receipt of a copy of the cancellation memorandum, and this copy placed in the legal file. If the reporting company later prepares a copy of the transcript and bills the Service, the receipted copy of the cancellation memorandum should be forwarded to the Counsel to the Associate Chief Counsel (P&A).

5. Upon receipt of a transcript from the court reporting company, the receiving office will complete the TLCATS Trial Data Screen or the CTRI screen, including the fields for entering transcript expenses. It is important that the transcript verification be prompt. Notification must also be sent to the Counsel to the Associate Chief Counsel (P&A), since billing is handled in the National Office. This notification should include the name of the case and docket number, the date of the hearing or trial, the name of the reporting company, the number of pages in the transcript, and the date it was received. Until notification is received, the reporting company’s invoice will not be paid. If a daily or expedited transcript has been ordered, but not delivered within the prescribed time frame, the Counsel to the Associate Chief Counsel (P&A) should be notified immediately by email, so that the invoice can be disputed.

6. The trial transcript is an essential part of the record of a Tax Court case that has been appealed. A transcript _must_ be ordered in _every case that is appealable_ and placed in the legal file; and it is important that the transcript be forwarded with the legal files if the case is appealed.

7. At all calendar calls, transcripts must be ordered for cases reported as settled, or for which a basis for settlement has been reached, as well as for cases heard on motion. It may become important to have a record of the exact representations made to the court, particularly with regard to the terms of settlement. When a motion is heard by the trial judge, the transcript is important if the motion is dispositive, or subsequent developments in the case may relate to statements made at the hearing.


**35.6.2.16** **(09-18-2012)**

### Bench Opinions

1. Sometimes judges decide to issue bench opinions after the trial. Situations in which the court may render a bench opinion include cases presenting issues for which a brief may be direct filed, _e.g._, substantiation, valuation, and fraud cases; cases in which the law to be applied is clear and the issue to be decided is highly factual; and where the court has decided the same issue for similarly situated taxpayers.

2. In rare and unusual circumstances, respondent may request that the court render a written opinion in lieu of a bench opinion. Situations in which this may be appropriate include those where similarly situated taxpayers would be affected, or where the government might wish to appeal any adverse decision on a significant legal issue. Such a request may be expressed orally or by a motion for reconsideration of opinion following approval of the Associate Chief Counsel office with subject matter jurisdiction over the substantive issues presented in the case and careful coordination with Procedure & Administration, Branch 6 or 7.

3. Where an oral opinion has been rendered, the appeal period runs from the date of entry of decision, as with all cases. If a bench opinion is issued, the court serves a copy of the transcript of the opinion on the parties without charge.


**35.6.2.17** **(07-20-2018)**

### Post-Trial Calendar Report

1. The Post-Trial Calendar Report is a report on cases set for trial at a designated trial session of the Tax Court. The report, which provides a detailed summary account of the disposition of all cases docketed on a calendar, is available on TL-CATS (CATS Report TL-840).

2. Instructions for the entry of information for the report and for the retrieval of the report are contained in section 12.25 of the TL-CATS User Handbook, which is available under the “Manuals & Guides” tab on the Chief Counsel intranet home page. Information for the report should be entered within ten working days of the end of the session. Each office with cases on a calendar is responsible for ensuring that the calendar status and case remarks for their cases are timely entered on TL-CATS. The calendar administrator is responsible for ensuring that the report is completed.

3. The narrative comments to be included in the Post-Trial Calendar Report are described below.


**35.6.2.17.1** **(07-20-2018)**

#### Post-Trial Calendar Report Narrative

1. The Post-Trial Calendar Narrative is a collection of post-calendar comments pertaining to the trial session. These comments are prepared by the calendar administrator and maintained electronically on the Chief Counsel intranet and on TL-CATS. Post-calendar comments should reflect information from the trial session that would be of interest to others in preparation for subsequent trial sessions, such as:



1. Occasions of significant deviations from the Standing Pretrial Order;

2. Any pressure put on respondent’s counsel concerning the settlement of cases, the stipulation of facts, or a course of action that would not normally be taken;

3. Important pretrial contacts by the court and the results thereof;

4. The handling and the results of motions of interest;

5. Comments of note by the trial judge on respondent’s processing and handling of cases;

6. The trial judge’s handling of expert witnesses; and

7. The handling of electronic discovery and electronic courtroom issues.


**35.6.2.18** **(09-18-2012)**

### Trial in Collection Due Process (CDP) Cases

1. This subsection provides specific procedures for trials of CDP cases.


**35.6.2.18.1** **(12-26-2023)**

#### Objections to Evidence Not in the Administrative Record

1. The Eighth Circuit in _Robinette v. Commissioner_, 439 F.3d 455 (8th Cir. 2006), rev’g 123 T.C. 85 (2004), the First Circuit in _Murphy v. Commissioner_, 469 F.3d 27 (1st Cir. 2006), aff’g on different grounds, 125 T.C. 301 (2005), and the Ninth Circuit in _Keller v. Commissioner_, 568 F.3d 710, 718 (9th Cir. 2009), held that when reviewing issues in a CDP case for an abuse of discretion, the Tax Court must limit its review to the administrative record. The Tax Court does not follow _Murphy_ and _Robinette_ outside the First, Eighth and Ninth Circuits.

2. In those cases in which a trial of nonliability issues cannot be avoided by a motion for summary judgment, the trial attorney should, based on the record rule, argue that the court should not consider either an issue or evidence that was not presented to Appeals during the administrative hearing. In the alternative, the trial attorney should argue that evidence not in the administrative record is not relevant to the issue of whether Appeals abused its discretion because such evidence could not have had any bearing on Appeals’ determination. See _Murphy v. Commissioner_, 125 T.C. 301 (2005), aff’d, 469 F.3d 27 (1st Cir. 2006); Fed. R. Evid. 401, 402.

3. Limited exceptions to the record rule permit the submission of evidence outside of the administrative record: (1) if the record does not adequately describe the basis for the determination, or (2) if there is a dispute over what happened during the hearing process, the reviewing court is permitted to supplement the administrative record with testimony or other evidence outside the record. In cases where the reasoning in the determination is unclear or incomplete, the remedy should ordinarily be to remand rather than to take new evidence into the record. See CCDM 35.3.23.7, Motion to Remand. The exception to the record rule should generally apply only to a situation where the court needs to hear evidence regarding what happened during the hearing process.

4. The trial attorney should make an evidentiary objection if the taxpayer attempts to testify as to matters not in the administrative record or otherwise offers evidence that was not made available to Appeals.

5. Attorneys should also consider filing a motion in limine objecting to the admission of the testimony or evidence. If the taxpayer will not stipulate to the administrative record, the motion in limine can be accompanied by a declaration of the appeals officer so as to place the administrative record before the court without calling the appeals officer to testify. The motion can seek to both affirmatively place the administrative record before the court and to prohibit admission of any evidence not presented to the appeals officer. A sample motion in limine may be found in Exhibit 35.11.1-230, Motion in Limine in Collection Due Process Case.

6. If the court denies the evidentiary objection or motion, or if the court reserves ruling on the objection or motion until after the trial, only then would it be appropriate to present any additional evidence not reviewed by the Appeals officer that strengthens the respondent’s case. With this evidence an alternative argument on brief can be made that the Appeals officer’s determination is not an abuse of discretion, even if the court allows evidence not available to Appeals during the administrative proceeding.


**35.6.2.18.2** **(09-18-2012)**

#### Appeals Testimony

1. Appeals testimony should be kept at a minimum. On issues subject to abuse of discretion review, the general rule is that an Appeals officer’s live testimony is unnecessary because the court’s review is limited to the administrative record. If the taxpayer will not stipulate to the administrative record, the record can be authenticated and admitted by declaration as described in CCDM 35.3.23.8.4, Declaration. In _Murphy v. Commissioner_, 125 T.C. 301 (2005), aff’d on different grounds, 469 F.3d 27 (1st Cir. 2006), the Tax Court excluded the Appeals officer’s testimony that was not relevant to the Appeals officer’s determination. The Tax Court also excluded testimony with respect to the Appeals officer’s rejection of the taxpayer’s offer-in-compromise, when the testimony was unnecessary as the record evidence provided adequate basis for the rejection.

2. In some cases an issue may arise involving the accuracy of the administrative record or whether the Appeals officer conducted the hearing correctly. When these types of issues are present, the administrative record may be detailed enough so that Appeals testimony is unnecessary. For example, the notice of determination and supporting Case Activity Records may contain detailed summaries of the Appeals officer’s attempts to schedule a face-to-face conference. However, if the record is inaccurate, unclear or incomplete, the trial attorney may determine that the Appeals officer’s testimony is necessary. See _Murphy v. Commissioner_, 125 T.C. 301 (2005), aff’d on different grounds, 469 F.3d 27 (1st Cir. 2006) (Appeals officer’s testimony is necessary and admissible to explain notations and abbreviations in case activity report). The record rule does not generally apply to issues involving the accuracy of the administrative record or the conduct of the hearing. Appeals testimony may also occasionally be necessary to rebut the taxpayer’s evidence when the court permits the taxpayer to introduce evidence outside the administrative record over respondent’s objection.

3. Appeals has agreed to permit Appeals employee testimony in these limited situations, but not on a routine basis. A joint memorandum from the Director, Technical Services and the Division Counsel SBSE dated March 23, 2005, details the circumstances under which Appeals employees will testify. All decisions to allow an Appeals employee to testify are made by the Appeals Area Director. Counsel should make requests for Appeals personnel to testify well in advance of the trial date, _i.e._, soon after the first calendar call status report meeting or as soon as the taxpayer raises an issue necessitating the testimony. Pursuant to the March 23, 2005, memorandum, Appeals will pay for its personnel to testify at trial in those few cases where the testimony is necessary.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-006-002#addtoany "Show all")

A2A