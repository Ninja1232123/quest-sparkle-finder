---
url: "https://www.irs.gov/irm/part34/irm_34-006-002"
title: "34.6.2 Types of Suits | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part34/irm_34-006-002#main-content)

- 34.6.2  [Types of Suits](https://www.irs.gov/irm/part34/irm_34-006-002#idm140336983305840)
  - 34.6.2.1  [Reducing the Tax Claim to Judgment](https://www.irs.gov/irm/part34/irm_34-006-002#idm140336984294384)
  - 34.6.2.2  [Judicial Enforcement of the Tax Lien](https://www.irs.gov/irm/part34/irm_34-006-002#idm140337011091664)
    - 34.6.2.2.1  [Appointment of Receiver](https://www.irs.gov/irm/part34/irm_34-006-002#idm140336982880608)
  - 34.6.2.3  [Setting Aside Fraudulent Conveyance and Establishing Transferee Liability](https://www.irs.gov/irm/part34/irm_34-006-002#idm140336982870560)
    - 34.6.2.3.1  [Setting Aside a Fraudulent Conveyance](https://www.irs.gov/irm/part34/irm_34-006-002#idm140337015726640)
    - 34.6.2.3.2  [Establishing Transferee Liability](https://www.irs.gov/irm/part34/irm_34-006-002#idm140337015716208)
  - 34.6.2.4  [Enforcing the Levy](https://www.irs.gov/irm/part34/irm_34-006-002#idm140337015710848)
    - 34.6.2.4.1  [Personal Liability for Failure to Honor Levy](https://www.irs.gov/irm/part34/irm_34-006-002#idm140336982670688)
    - 34.6.2.4.2  [Failure to Honor Levy Suit Referral](https://www.irs.gov/irm/part34/irm_34-006-002#idm140336982663696)
    - 34.6.2.4.3  [50% Penalty for Failure to Honor Levy](https://www.irs.gov/irm/part34/irm_34-006-002#idm140337011383984)
    - 34.6.2.4.4  [Writs of Entry](https://www.irs.gov/irm/part34/irm_34-006-002#idm140337011371856)
  - 34.6.2.5  [Judicial Approval of Principal Residence Seizures](https://www.irs.gov/irm/part34/irm_34-006-002#idm140337015801360)
    - 34.6.2.5.1  [Procedures for Instituting a 6334(e)(1) Proceeding](https://www.irs.gov/irm/part34/irm_34-006-002#idm140337015795776)
  - 34.6.2.6  [Intervention](https://www.irs.gov/irm/part34/irm_34-006-002#idm140337015784320)
  - 34.6.2.7  [Erroneous Refunds](https://www.irs.gov/irm/part34/irm_34-006-002#idm140336983406384)
  - 34.6.2.8  [Establishing Fiduciary Liability under 31 U.S.C. § 3713](https://www.irs.gov/irm/part34/irm_34-006-002#idm140336983394128)
  - 34.6.2.9  [Section 3505 Third Party Liability](https://www.irs.gov/irm/part34/irm_34-006-002#idm140337011311504)
  - 34.6.2.10  [Miscellaneous Actions Brought by the United States](https://www.irs.gov/irm/part34/irm_34-006-002#idm140337011292784)
    - 34.6.2.10.1  [Action on Bonds](https://www.irs.gov/irm/part34/irm_34-006-002#idm140337011291072)
    - 34.6.2.10.2  [Action to Open Safe Deposit Box](https://www.irs.gov/irm/part34/irm_34-006-002#idm140337011362416)
    - 34.6.2.10.3  [Action by United States to Quiet Title](https://www.irs.gov/irm/part34/irm_34-006-002#idm140337011353776)
    - 34.6.2.10.4  [Liability of Banks on Checks](https://www.irs.gov/irm/part34/irm_34-006-002#idm140337011351328)
    - 34.6.2.10.5  [Forfeiture Cases](https://www.irs.gov/irm/part34/irm_34-006-002#idm140337011349232)

# Part 34. Chief Counsel Directives Manual Litigation in District Court, Bankruptcy Court, Court of Federal Claims, and State Court

# Chapter 6. Suits Brought by the United States

# Section 2. Types of Suits

* * *

## 34.6.2 Types of Suits

#### Manual Transmittal

August 08, 2023

#### Purpose

(1) This transmits revised CCDM 34.6.2, Suits Brought by the United States -Types of Suits.

#### Background

28 U.S.C. section 2410 allows a complaint to name the United States as a party in a civil action or suit in any district court, or in any State court having jurisdiction of the subject matter to, _inter alia_, quiet title to or foreclose a lien on real or personal property in which the government has a federal tax lien.

#### Material Changes

(1) CCDM 34.6.2 is revised to address direct counterclaim referral authority in section 2410 and other lien enforcement actions.

#### Effect on Other Documents

This section supersedes CCDM 34.6.2.2 dated 06-12-2012.

#### Audience

Chief Counsel

#### Effective Date

(08-08-2023)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**34.6.2.1** **(06-12-2012)**

### Reducing the Tax Claim to Judgment

1. The principal purpose for instituting a suit to reduce tax claims to judgment is to extend the statute of limitations for collection. The ordinary statute of limitations for administrative collection is ten years from the date of assessment. The suit will be brought if the collection statute will shortly expire, all administrative remedies have been exhausted, and there is a reason to believe that collection can be effected in the future, (after acquired assets, good earning capability, inheritance). Such a suit would be authorized so that the liability would remain enforceable. The period for collection by levy does not expire until the liability for the tax (or a judgment against the taxpayer arising from such liability) is satisfied or becomes unenforceable, if a timely proceeding in court for the collection of a tax is commenced within the ten-year period. See section 6322.

2. The responsibility for collection of judgments rests with the Department of Justice (DOJ) or the U.S. Attorney. The Area Director will be requested to conduct an immediate investigation to ascertain whether the judgment debtor has property from which to satisfy the judgment. Thereafter, procedures require Directors to repeat such investigation at stated intervals.

3. The expense and time consumed in processing a suit to reduce a tax claim to judgment is a factor to be considered. In addition to a sizeable tax liability, a potential source of collection should exist after the suit has been successfully prosecuted. There are, of course, exceptions such as a case where such suit might be helpful in the handling of other taxpayers similarly situated.

4. DOJ generally also asks for a money judgment in conjunction with a suit to enforce the tax lien. Therefore, in most instances a suit to foreclose the lien is combined with a suit to reduce the tax claim to judgment.

5. **Specific Requirements of the Reduction to Judgment Suit Letter**. The letter must point out what beneficial effects are expected from the filing of a suit, including assets from which collection might be effected, such as property that may come into the hands of the taxpayer or may be uncovered upon further search.

6. Reference should be made to CCDM 34.6.1.3 http://publish.no.irs.gov/getpdf.cgi?catnum=38021, _Preparation of Suit Letters_, and Exhibit 34.12.1–8 http://publish.no.irs.gov/getpdf.cgi?catnum=29689, _Preparation of Suit Letters — Checklist_, for discussion on the preparation of a collection suit.


**34.6.2.2** **(08-08-2023)**

### Judicial Enforcement of the Tax Lien

1. **Purpose of Suit**. The purpose of a lien enforcement suit is to obtain a judicial sale of the property subject to the federal tax lien under section 7403, whenever it becomes impossible or inadvisable to use the statutory methods of administrative enforcement. Generally, this situation exists when there are questions concerning title to the particular property or priorities of liens that create an unfavorable or impossible market for administrative sale. This is also true when it may be difficult to obtain the property or to preserve its value, and the aid of the court is necessary through specific order or the appointment of a receiver. In most cases, a money judgment should also be requested. Suits for collection of estate tax under section 7404 similarly require a suit letter.

2. **Difference between Suit to Enforce the Tax Lien and Suit to Reduce a Tax Claim to Judgment**. A suit to enforce a federal tax lien is used when there is specific property in existence subject to the lien. A suit to reduce a tax claim to judgment may be used to extend the collection period when administrative collection has been unsuccessful and judicial remedies may aid in collection. If there is a potential source of collection and the tax is sufficient to justify recommending suit to reduce the Government’s claim to judgment, a suit to reduce to judgment may be combined with a suit to enforce the lien on specific property. In most cases where suit is brought to enforce a tax lien, DOJ includes in its complaint a request for a judgment. In effect, the judgment also confirms the validity of the lien arising out of the tax assessment. The Government’s right to levy or to judicially enforce the tax lien is not curtailed as the result of reducing the assessment to judgment and may be enhanced.

3. **Authority for Government to Bid at Lien Enforcement Sale**. Section 7403(c) provides that when the Government brings a judicial lien enforcement action, the Government may bid on the property where it holds a first lien. Whether the Government exercises this authority to bid is a matter within the discretion of the appropriate Area Director. The amount that may be bid is limited to the amount of the tax lien, plus selling expenses. The Government may bid in property to prevent its sale at distress prices to assure that the full value of the property sold, or the amount of the tax claims, is realized by the Government. It also protects the interest of the taxpayer whose property is being sold. The authority now granted under section 7403(c), for sale bids, is like the authority contained in 31 U.S.C. § 3715 (relating to buying real property of a debtor).

4. **Considerations of Amount of Tax and Property Value**. The expense and time involved in a suit to enforce a Federal tax lien should be considered particularly where the property value is negligible or the unpaid tax is small. Whether there is sufficient value to justify judicial lien enforcement should account for the ability of DOJ to appoint a receiver pursuant to section 7403(d), which often may mitigate a forced sale discount. A certification for a receiver in equity is not required if a receiver is appointed only to sell property.

5. **Effects of Taxpayer’s Interest in Property upon the Purchase**. A court proceeding under section 7403 may be necessary where, as an incident to enforcing the federal tax lien, some action by the taxpayer must be compelled by the court, such as surrender of securities.

6. **Specific Requirements of a Lien Enforcement Suit Letter**. To adjudicate all claims against the property, the United States must name as party defendants all known persons who have unreleased liens upon or claim any interest in the property or rights to property sought to be subjected to payment of the tax. It is essential that a title search be conducted and that it be as recent as possible. Even if it is known that the encumbrance has in fact been satisfied, the lienor should be named if the lien has not been officially released. Such persons must be named as parties to the suit and served with process. Therefore, it is important to furnish their addresses and to give their correct legal names. If a party to be named is an individual doing business under another name, both names should be provided, along with the home address of the individual as well as the business address. If the party is a partnership, the complete name and address of the partnership should be shown, with the individual partners’ name and addresses.



1. The suit letter should analyze the relative priorities and indicate the value of the property involved.

2. The Area Director’s approval should be included along with a suit letter requesting lien foreclosure on a principal residence. Area Director approval is not required, however, when authorizing a counterclaim to enforce the tax lien in an already pending suit, including a counterclaim as a defendant-intervenor pursuant to section 7424. **See**IRM 25.3.1.4(5).

3. Reference should be made to CCDM 34.6.1.3 http://publish.no.irs.gov/getpdf.cgi?catnum=38021, _Preparation of Suit Letters_, and Exhibit 34.12.1–8 http://publish.no.irs.gov/getpdf.cgi?catnum=29689, _Preparation of Suit Letters — Checklist_, for additional discussion of the preparation of a collection suit.


**34.6.2.2.1** **(03-24-2016)**

#### Appointment of Receiver

1. In a pending suit the court may, under section 7403(d) at the instance of the United States, appoint a receiver to enforce the tax lien; or during the pendency of the proceeding, upon certification of the Chief Counsel that it is in the public interest, a receiver may be appointed with all the powers of a receiver in equity. This latter certificate, which is executed by the Chief Counsel, would only be used after the suit has been commenced. An example of circumstances where a receiver might be requested is where the purpose of the suit is to foreclose a tax lien against an ongoing business. A receiver could conduct the business, safeguard the assets, prevent waste or fraud by the taxpayer or others, and liquidate the assets of the business to pay off creditors.

2. For situations requiring the appointment of a receiver, and the duties and costs associated, see Legal Reference Guide for Revenue Officers: IRM 5.17.4.10 http://publish.no.irs.gov/getpdf.cgi?catnum=30752, _Court Appointed Receiver_, IRM 5.17.4.10.2 http://publish.no.irs.gov/getpdf.cgi?catnum=30752, _Duties of a Receiver_, and IRM 5.17.4.10.3 http://publish.no.irs.gov/getpdf.cgi?catnum=30752, _Cost and Expense of Receivership_.

3. **Procedures to Appoint Receiver**. If the appointment of a receiver would best serve the interests of all parties, a Certificate should be prepared (original and eight copies) for the signature of the Chief Counsel and in the form set forth in Exhibit 34.12.1–20 http://publish.no.irs.gov/getpdf.cgi?catnum=29689, _Certificate for Appointment of Receiver_. Certificates are signed on behalf of the Chief Counsel by the Division Counsel (Small Business/Self-Employed).



1. The original suit letter is not to be used to transmit the Certificate to DOJ (although such Certificate will be transmitted to Division Counsel (Small Business/Self-Employed) with the suit letter). Accordingly, a statement should be made in the letter that a receiver is deemed necessary and reasons therefor, and further, that the Certificate will be furnished upon receipt of information that the suit has been commenced and upon request from DOJ.

2. If DOJ agrees that a receiver is necessary and requests the Certificate, Division Counsel (Small Business/Self-Employed) will handle the matter and advise Field Counsel accordingly.


4. All suit letters recommending the appointment of a receiver must be reviewed by Division Counsel (Small Business/Self-Employed) before being sent to DOJ.


**34.6.2.3** **(08-11-2004)**

### Setting Aside Fraudulent Conveyance and Establishing Transferee Liability

1. There are three methods by which the United States may proceed where assets have been transferred in fraud of creditors. The first method involves a reinstatement of the transferor’s ownership and foreclosure of the federal tax lien against the transferor’s property. The other two methods do not result in bringing back the transferred assets. Rather, they provide a means of making the transferee primarily liable for the debt, which may then be collected from any of the assets. The transferee is secondarily liable for the transferor’s tax but by a judgment the transferee becomes primarily liable.

2. The first method is to have the transfer set aside and the asset subjected to the collection of the transferor’s debt in the United States District Court.

3. The second method is to assert transferee liability by institution of a civil lawsuit against the transferee in the United States District Court.

4. The third method is to issue a Statutory Notice of Transferee Liability, which may lead to a hearing in the Tax Court and ultimate assessment of the liability (income, estate, and gift tax) against the transferee.



1. This is a more summary method than the methods set forth above and involves procedures similar to those employed in determining a deficiency in income, estate or gift taxes.

2. Section 6901 is strictly a procedural statute and has no bearing on the substantive liability of the transferee for the transferor’s debts. The right of the Government to assert a liability on the part of the transferee depends on state law.

3. The statutory procedure is simpler and less expensive than instituting a suit for the collection of taxes. There are instances in which the administrative remedy cannot be used. These include: when the statute of limitations has expired for the statutory procedure; when the taxes involved are not within the purview of section 6901; and when a party assumed the tax obligations of the taxpayer, or guaranteed payment of another’s taxes, and no property was transferred from the taxpayer.


5. **Suits**. A suit to establish transferee liability is primarily an in personal action, i.e., one in which a personal judgment is demanded against the transferee to the extent of the value of the assets transferred. Following a successful court action, the United States can then execute against the transferee’s property on the basis of the judgment lien. Until judgment is obtained, the Government has no lien on the transferee’s property as it has in the case where assessment ultimately results either from the transferee’s failure to file a petition with the Tax Court or upon the Government’s winning the case if a petition is filed.


**34.6.2.3.1** **(06-12-2012)**

#### Setting Aside a Fraudulent Conveyance

1. For general information see IRM 5.17.14 http://publish.no.irs.gov/getpdf.cgi?catnum=57352, _Fraudulent Transfers and Transferee and Other Third Party Liability_.

2. See CCDM 34.6.1.3 http://publish.no.irs.gov/getpdf.cgi?catnum=38021, _Preparation of Suit Letters_, and Exhibit 34.12.1–8 http://publish.no.irs.gov/getpdf.cgi?catnum=29689, _Preparation of Suit Letters — Checklist_, regarding preparation of suit letters.

3. The right of the United States to set aside a fraudulent conveyance is found in federal law and in state law. There are two kinds of fraudulent conveyance: those effected through actual fraud and those effected through constructive fraud. Depending on the facts and the law, the remedy may be to either set aside the transfer or obtain a personal judgment against the transferee.



1. The Federal Debt Collections Procedure Act (FDCPA), 28 U.S.C.§ 3001 et seq., became effective in 1991. It gives the United States a uniform federal procedure for setting aside a fraudulent conveyance to aid in the collection of federal debts including tax debts. The United States is not bound to use the FDCPA to collect its debts. It can proceed under any cause of action provided by state or federal law.

2. The United States may also use the remedies available to a private creditor under applicable state law. Generally, the law of the state where the transfer occurs will govern. The Uniform Fraudulent Conveyance Act (UFCA) is in effect in five states and its successor, the Uniform Fraudulent Transfer Act (UFTA), has been adopted in forty states. The Government is not required to rely on the varying state causes of action to reach fraudulent conveyances. Because of differing applicable statute of limitations, it may nevertheless be beneficial in certain instances for the Government to bring a suit under state law.


4. In a suit to set aside a fraudulent conveyance under the FDCPA, the burden of proof is on the Government to prove that the transfer of the property was fraudulent as to a debt owed to the United States. In a suit to set aside a fraudulent conveyance under state law, one should look at the UFCA or UFTA to determine what elements the Government must prove to establish constructive or actual fraud.

5. **Suit to Foreclose Lien**. Generally, a suit to set aside a fraudulent conveyance is combined with a suit to foreclose any liens for the transferor’s taxes that attach to the transferred property once the transferor’s ownership in the property has been reinstated. If the Government had a lien on the property involved prior to the time it was transferred, however, a suit to foreclose such lien ordinarily would be the appropriate remedy. This suit would have to be initiated within the statutory period for collection under section 6502. The period for collecting the taxes of the transferor must be open in order to foreclose a tax lien based on that liability.


**34.6.2.3.2** **(06-12-2012)**

#### Establishing Transferee Liability

1. For general information, see IRM 5.17.4 http://publish.no.irs.gov/getpdf.cgi?catnum=30752, _Suits by the United States_.

2. **Specific Requirements of Transferee Liability Suit Letter**. In addition to all necessary tax data to prove the tax liability, these cases require complete documentation because the ultimate burden of proof in establishing transferee liability is on the United States. The suit letter should contain:



1. A complete statement of the facts including the circumstances of the transfer and a complete description of the property transferred; the assets in possession of the taxpayer at the time of the transfer; the worth of the taxpayer before and after the transfer; the name and address of the transferee; and the financial ability of the transferee to respond to judgment; and

2. A discussion of the evidence to establish the essential elements of transferee liability or that the transfer was fraudulent.


**34.6.2.4** **(01-18-2017)**

### Enforcing the Levy

1. In general, any person who possesses property or rights to property subject to levy, who is served with a notice of levy, is obligated to surrender the property to the Service.

2. Any person who fails or refuses to surrender property subject to levy on demand is personally liable under section 6332 to the Service for an amount equal to the value of the property or the tax liability for which the levy was made, whichever is less.

3. A penalty equal to 50% of the amount recoverable for failure to honor the levy may be imposed if there is no reasonable cause for the levied-upon person’s failure to honor the levy.

4. The government imposes personal liability for failure to honor a levy or the 50% penalty through an affirmative collection suit. This means that after a case is fully developed by the Service, Counsel may then, if appropriate, refer the case to the Department of Justice with a suit letter requesting that DOJ take affirmative action on the case.

5. A writ of entry should be obtained when the Service intends to seize and sell property that is located in a place in which the taxpayer has a reasonable expectation of privacy and the taxpayer does not consent to the Service’s entry for purposes of the seizure.

6. For more information and detailed instructions, refer to CCDM 34.6.2.4.1, _Personal Liability for Failure to Honor Levy_; CCDM 34.6.2.4.2, _Failure to Honor Levy Suit Referral_; CCDM 34.6.2.4.3, _50% Penalty for Failure to Honor Levy_; CCDM 34.6.2.4.4, _Writs of Entry_.


**34.6.2.4.1** **(07-16-2014)**

#### Personal Liability for Failure to Honor Levy

1. A person served with a notice of levy must generally comply with the levy. A person who fails or refuses to honor the levy is personally liable for an amount equal to the value of the property or the tax liability for which the levy was made, whichever is less. This liability bears interest from the date of levy, and includes costs. Any amount recovered is credited against the tax liability upon which the levy was based.

2. A person served with a levy has only two defenses for noncompliance: (1) the person levied upon is not in possession of property of the taxpayer; or (2) the property levied upon is subject to prior judicial attachment or execution. United States v. National Bank of Commerce, 472 U.S. 713, 721-22 (1985).



1. The levied-upon person cannot raise defenses that would typically be available to the taxpayer, such as issues relating to the amount and validity of the assessment or questions regarding the statute of limitations.

2. A lien priority argument is not a valid defense to a levy.

3. Fear of liability is not a defense to failure to honor a levy. Section 6332(e) protects a person who honors the levy from any obligation or liability to the taxpayer or any other person.


### Note:

There are special rules for levies served on insurers under life insurance and endowment contracts (section 6332(b) and Treas. Reg. § 301.6332-1(a)(1)) and banks (section 6332(c)). With a levy on a life insurance or endowment contract, payment is due 90 days after demand is made. With a levy on a bank, the bank shall honor the levy only after 21 days after service of the levy.

**34.6.2.4.2** **(07-16-2014)**

#### Failure to Honor Levy Suit Referral

1. The Service can recommend that DOJ pursue a suit to enforce the personal liability of a person for failure to comply with a levy. If Counsel agrees with the Service’s suit recommendation, Counsel prepares a suit referral letter for DOJ. Before making any recommendation to DOJ, the following points should be considered:



1. Whether administrative remedies for collection of the underlying liability have been exhausted. (A suit for failure to honor a levy should not be recommended if use of an administrative process to collect the tax would be adequate.)



      ### Note:



      If the notice of levy was duly and timely served before the expiration of the period of limitations on collection under section 6502(a), the personal liability of the levied-upon person arising for failure to honor the levy may be enforced at any time notwithstanding the subsequent expiration of the statute of limitations on collection against the taxpayer.

2. Whether the levied-upon person has a valid (or arguable) defense for noncompliance. (The Service should consider the merits of any arguments raised by the person levied upon as a reason for failure to honor the levy.)

3. Whether a failure to enforce the levy could cause future difficulties in effecting collection from other taxpayers in a community.

4. Whether the person served with the levy is still in possession of the taxpayer’s property. (As a general rule, a failure to honor levy suit will be required when the person in possession of the taxpayer’s property disposes of it subsequent to the levy. If the property is still in possession of the person, consideration should also be given to a suit to enforce the Government’s lien against the property under section 7403. Questions of title are best resolved by a foreclosure suit under section 7403. The Service can recommend both a failure to honor levy suit and a foreclosure suit in the referral letter to DOJ.)


2. A failure to honor levy suit letter must include the same basic components of any suit letter sent to DOJ: an authorization to take affirmative legal action on the Service’s behalf, a statement regarding jurisdiction and venue, a summary of the relevant facts, a statement regarding the applicable law, and a closing recommendation. See CCDM 34.6.1.3 and Exhibit 34.12.1-8 for requirements of a suit letter.

3. There are also specific requirements for a failure to honor levy suit letter. The following points should be discussed and incorporated into the basic components of the suit letter:



1. The nature of the taxpayer’s interest that was attempted to be seized by the levy;

2. The circumstances of the service of the notice of levy;

3. The name and address of the person levied upon, as well as the names of any other claimants to the property;

4. The reason or reasons given by the person levied upon for non-compliance;

5. Any other defenses that might be argued and why the defenses are not proper in response to the levy;

6. Whether the 50% penalty under section 6332(d)(2) is being recommended.


4. The suit letter should address the applicability (or nonapplicability) of the defenses noted in CCDM 34.6.2.4.1(2), above, and include any facts and law that support the position that a debt was owing from the person levied upon or that the property was held in possession of the levied-upon person.

5. The 50% penalty should not be routinely requested in all cases when enforcement action for failure to honor a levy is being sought, but should only be requested in egregious cases of failure to comply without reasonable cause. See CCDM 34.6.2.4.3, _50% Penalty for Failure to Honor Levy_. All failure to honor levy suit letters must affirmatively state whether the 50% penalty is being recommended. In cases when the 50% penalty is not being recommended, the suit letter may be sent directly to DOJ. In cases when the penalty is being recommended, suit letters should be sent to Procedure and Administration, Branches 3 and 4 for pre-review and approval before they can be sent to the Department of Justice.


**34.6.2.4.3** **(07-16-2014)**

#### 50% Penalty for Failure to Honor Levy

1. If a levied-upon person’s failure or refusal to surrender property was without reasonable cause, the person may be liable for a penalty equal to 50% of the amount recoverable under section 6332(d)(1). Unlike the amount imposed as personal liability for failure to honor a levy, the amount imposed under the 50% penalty is not applied against the tax liability of the taxpayer.

2. The 50% penalty should only be imposed in egregious cases of failure to comply without reasonable cause.



1. It may be appropriate to impose the 50% penalty when the legal justification for refusing to comply with the levy is clearly erroneous and contrary to the weight of legal authority. In contrast, the 50% penalty should not be imposed in cases when there is a bona fide dispute about the amount of the property to be surrendered or the legal effectiveness of the levy. Treas. Reg. §301.6332-1(b)(2); see, e.g., United States v. Sterling National Bank and Trust Co. of New York, 494 F.2d 919, 923 (2d Cir. 1974); United States v. Citizens and Southern National Bank, 538 F.2d 1101, 1107 (5th Cir. 1976). Whether there is a bona fide dispute sufficient to constitute reasonable cause will usually turn on how clear the legal authority is regarding the matter in dispute. Similarly, when the levied-upon person raises a valid, non-frivolous factual dispute as to whether the person is holding property or rights to property of the taxpayer, the 50% penalty should not be imposed.



      ### Example:



      The Service serves a levy on Bank A for T’s unpaid tax liability. Unlike the majority of jurisdictions that require a bank to affirmatively exercise a right to setoff, the state in which Bank A is located recognizes a pre-levy right to automatic setoff. Bank A, asserting that right, does not honor the Service’s levy. Although Counsel may challenge Bank A’s assertion of a pre-levy right to automatic setoff, imposition of the 50% penalty would not be appropriate given the presence of legal authority supporting the position taken by Bank A.

2. When the levied-upon person acts in bad faith in failing to honor the levy, any indicia of bad faith will support imposition of the 50% penalty. Examples of bad faith include situations when the levied -upon person simply ignores the levy and presents no justification for noncompliance, engages in behavior indicating subterfuge such as secretly attempting to dispose of the levied-upon property after the levy, or otherwise acts in a way to indicate that the person is knowingly evading its legal responsibilities.

3. Fear of liability to the taxpayer or any other person, does not constitute reasonable cause and should not militate against or prevent imposition of the 50% penalty.


3. In any case in which the 50% penalty may be recommended, the attorney should establish a proper foundation for the penalty by sending a preenforcement letter to the levied-upon person (prior to referral to DOJ) that explains the person’s duty to comply with the levy. The letter should detail the specific legal grounds for the levy and cite to the relevant statutes and case law establishing the Service’s authority to levy. The letter should also mention that the Service will consider imposition of the 50% penalty if an enforcement suit for failure to honor the levy becomes necessary.

4. If the 50% penalty is recommended, in addition to the requirements set forth in CCDM 34.6.1.3 and CCDM 34.6.2.4.2, the suit letter to DOJ should specifically state why the penalty is recommended, contain as much information as possible to support the penalty, and include a specific discussion of any of the factors mentioned above that would suggest that the levied-upon person lacked reasonable cause in failing to honor the levy. The suit letter should also include information about the amount and timing of any payments made to the taxpayer in disregard of the levy.

5. In all cases in which the penalty is being recommended, suit letters should be sent to Procedure and Administration, Branches 3 and 4 for pre-review and approval.


**34.6.2.4.4** **(07-16-2014)**

#### Writs of Entry

01. As a result of the holding in G.M. Leasing v. United States, 429 U.S. 338 (1977), the Service adopted procedures and guidelines for levies or seizures of property located on private property. If a proposed target of a search for distrainable assets exhibits a reasonable, objective expectation of privacy that society is willing to recognize, the Fourth Amendment will be implicated and the revenue officer must either obtain consent or obtain a court order permitting entry, i.e., a writ of entry, before entering the premises or object. A writ should only be used to seize property belonging to the taxpayer that the Service intends to sell. A writ enables the Service to enter premises or property in order to carry out its administrative collection powers. When the revenue officer determines that a court order is needed, he will forward the matter to Field Counsel.

02. A writ is required where there is a reasonable expectation of privacy — i.e., entry into the home, private portions of commercial offices and buildings. See IRM 5.10.3.5 http://publish.no.irs.gov/getpdf.cgi?catnum=35403, _Writ Procedures_. Seizure of assets located outside of taxpayer’s personal and business premises may in certain limited circumstances require a writ because of the expectation of privacy. Seizure of a motor vehicle parked in an unobstructed driveway or front yard is permissible without consent or writ. IRM 5.10.3.4.

03. To obtain a writ of entry from a court, the Service must establish probable cause. While the law in different jurisdictions varies, the standard of probable cause for obtaining a writ of entry is generally not the same as the standard of probable cause for conducting a search or obtaining a search warrant in a criminal case. Matter of Carlson, 580 F. 2d 1365 (10th Cir. 1978). To establish probable cause, the revenue officer generally must show in his affidavit/declaration (depending on the jurisdiction) that the Service has complied with the Code provisions for levy and distraint (i.e., a liability for tax, the issuance of notice and demand, and that there is reason to believe assets of the taxpayer are located in or on the property for which the revenue officer is seeking the writ of entry).

04. Keep in mind that before any type of seizure can take place the legal requirements of Collection Due Process (CDP) included under section 6330 must be met. Absent a finding of jeopardy or other statutory exception, the taxpayer must receive notice under section 6330 and the opportunity for a hearing for all the periods that are the subject of the writ. Accordingly, the affidavit/declaration should include a specific statement that the notice requirements of both section 6330 and section 6331(d) have been met.

05. Upon receipt of a request for a writ, Field Counsel should review the documents to ensure that the facts support a writ of entry and the submitted affidavits/declarations meet the requirements imposed by the local district courts. The pleadings and affidavit/declaration must provide the court with sufficient information to support the issuance of a writ. Although jurisdictions vary in the degree of specificity concerning the facts that must be in the application for a writ, each jurisdiction requires essentially the same information to issue a writ. Exhibit 5.10.3-2 http://publish.no.irs.gov/getpdf.cgi?catnum=35403, P–577, _Declaration of Revenue Officer Reference: 5.10.3.5_, contains a sample affidavit. Field Counsel should closely review the affidavit/declaration of the revenue officer to insure that it includes all the following information. See IRM 5.10.3 http://publish.no.irs.gov/getpdf.cgi?catnum=35403, _Conducting the Seizure_.

06. The affidavit/declaration should contain specific information concerning:



    1. The amount and taxable periods of the liability; the dates of assessment and notice and demand; the date notice of intent to levy was given.

    2. A statement regarding the notice and hearing before seizure required by CDP procedures found under sections 6320 and 6330.

    3. A description of the taxpayer’s business, a description of the taxpayer’s interest in and the address or location of the premises to be searched, and a description of the assets expected to be found on the premises.


07. After review, Field Counsel should refer the case to the U.S. Attorney for handling (within 24 hours if practicable). The letter to the U.S. Attorney should include the following documents: revenue officer’s data sheet; the affidavits/declarations of the revenue officer; a proposed order; where required under local rules, a proposed application for such order; and any other items required under local procedures. Field Counsel should monitor the case to make sure the order is quickly presented to the court and signed.

08. The court’s authorization governs the revenue officer’s authority to search for and seize distrainable assets once he/she is lawfully on the premises pursuant to a writ of entry. This includes both the explicit language of the writ and what the court, based on the application and the Government’s communication with the court, understood was the authorized scope of the search. Once the revenue officer is lawfully on the premises, the authority to seize assets is governed by section 6331.

09. After the order is granted and the revenue officer has completed his search, Field Counsel should close the case. If the order is denied, Field Counsel should review the matter to determine whether an appeal is warranted or whether a writ of mandamus should be sought.

10. Writ of entry procedures may be used to obtain access to safe deposit boxes. See CCDM 34.6.2.10.2, _Action to Open Safe Deposit Box_.


**34.6.2.5** **(08-11-2004)**

### Judicial Approval of Principal Residence Seizures

1. Under prior law, the principal residence of the taxpayer was generally exempt from levy, unless such levy was personally approved in writing by a District Director or Assistant District Director or if there was a jeopardy determination. The Restructuring and Reform Act of 1998,(RRA 98), set forth new procedures for seizure of residences and businesses. Section 6334(e)(1) requires judicial approval for seizures of certain principal residences. The approval requirements are effective for principal residence seizures made on or after the date of enactment of RRA 98, which was July 22, 1998. Written approval by the Compliance Area Director is no longer legally required prior to seizure of a taxpayer’s principal residence; however, such approval will still be required procedurally. In addition, there is no longer a jeopardy exception to the approval requirements for principal residence seizures.

2. A court order is now required prior to administrative seizure of certain principal residences.

3. Section 6334(a)(13)(A) exempts from levy any real property used as a residence by any individual (except for real property that is rented) if the levy amount does not exceed $5,000.

4. Judicial approval is specifically required prior to seizure of the principal residence of the taxpayer, taxpayer’s spouse, former spouse or minor child. A section 6334(e)(1) proceeding is a plenary hearing involving the participation of the taxpayer. It is conducted in the district court of the United States.


**34.6.2.5.1** **(06-12-2012)**

#### Procedures for Instituting a 6334(e)(1) Proceeding

1. A section 6334(e)(1) proceeding should be commenced in accordance with the general procedures for suits to collect found in CCDM 34.6.1.3 http://publish.no.irs.gov/getpdf.cgi?catnum=38021, _Preparation of Suit Letters_.

2. See CCDM 34.6.2.2 and Exhibit 34.12.1–8 http://publish.no.irs.gov/getpdf.cgi?catnum=29689, _Preparation of Suit Letters — Checklist_, for the requirements of a suit letter. The letter should be written requesting and authorizing the institution of a civil action for judicial approval of a seizure of a principal residence, pursuant to section 6334(e)(1). As with a lien foreclosure suit letter, the section 6334(e)(1) suit letter should establish that the tax liability is owed by setting forth the specifics of the tax liability — i.e., that the assessment was proper, date of assessment, demand for payment, lien information, etc. In all cases, the liability owed by the taxpayer must exceed $5,000.

3. If the property being seized is the principal residence of the taxpayer’s spouse, former spouse or minor child, the suit letter should provide the name of that person or persons. Upon commencement of a section 6334(a)(1) proceeding, that person or persons, along with the taxpayer, will receive notice.

4. **Specific Requirements of the Suit Letter**. The Service has determined that the personal written approval of the Area Director will continue to be required prior to seizing any property used by any person as a principal residence. This approval should accompany the suit recommendation and should establish that the Service has verified that the tax liability is owed, complied with all legal and procedural requirements with respect to the proposed seizure, and considered all viable alternative collection methods. The approval is also required in the case of a lien foreclosure of a personal residence.



1. The Tax Division handles and coordinates all section 6334(e)(1) proceedings.

2. A proceeding should ordinarily be brought under section 6334(e)(1) whenever the Service would have otherwise sought administrative seizure of a principal residence under prior law. Suits should still be brought to foreclose the federal tax lien and reduce the tax liability to judgment in lieu of bringing a section 6334(e)(1) proceeding whenever it is determined that such suits would be optimal. A lien foreclosure suit may be preferable to a section 6334(e)(1) proceeding when there are questions regarding title or lien priority that create an unfavorable market for administrative sale. See 35.6.3.2 for discussion of lien foreclosure suits. A lien foreclosure suit may also be a specific option when the collection statute of limitations is about to run. Bringing a lien foreclosure suit is consistent with the policy underlying section 6334(e)(1) of assuring that the disposition of principal residence property is sanctioned by a court.


5. Taxpayers whose residences are subject to a section 6334(e)(1) proceeding after January 18, 1999, will, in most instances, have received an section 6330 notice, a section 6320 notice, or both with respect to the tax periods for which the Service seeks to effectuate collection via seizure of a principal residence. In these cases, where a taxpayer sought judicial review of Appeals’ determination in a section 6320 or section 6330 hearing, that taxpayer may be precluded from raising issues in a subsequent section 6334(e)(1) proceeding that were raised or could have been raised in the earlier court proceeding.


**34.6.2.6** **(06-12-2012)**

### Intervention

1. The usual purpose of intervention is to make the United States a participant in pending litigation that affects the taxpayer’s property, and in which a decision may adversely affect the interests of the United States. Intervention is necessary when the United States is named a party to the action but there was no authority for the United States to be joined. In addition, there are cases in which the United States is named in a state court proceeding in an attempt to resolve a substantive tax issue against the Government. These cases usually involve decedent’s estates. Ordinarily, a motion to dismiss is filed, but consideration must be given to intervention.



1. Section 7424 does not confer authority on the United States to intervene. The procedure for intervention is controlled by the state or federal rules of practice applicable to the court in which intervention is sought.


2. **How to Intervene**. Intervention is generally accomplished by filing a motion with the court asking for leave to intervene. If granted, a petition of intervention is filed asking for a determination of the conflicting claims and liens together with an order decreeing the sale of the property, if necessary. Intervention must be authorized or sanctioned by Field Counsel under sections 7401 and 7403.



1. Whether an application to intervene is timely is within the sound discretion of the court. When it is considered advisable for the United States to intervene, time is of the essence. The failure to intervene could mean that property or rights to property of the delinquent taxpayer might be distributed to claimants whose rights are inferior to those of the United States. While the United States would have a right of action against these distributes, or at least the property distributed to them, as a practical matter the chances of successfully pursuing such a legal course of action are not good.


3. **Effect of Intervention**. In any case in which the United States intervenes, the same procedural rules as provided in 28 U.S.C. § 2410 (other than subsection (b)) apply as if the United States had been initially joined properly as a party. In any case where the United States moves to intervene, and the motion is denied, the proceedings have no effect on the Government’s tax lien. Thus, such lien may be enforced against the property by levy or foreclosure. This is consistent with the result where the Government is not joined as a party.

4. **State Court and Substantive Tax Issues**. The Service ordinarily will not intervene in litigation in state courts between private litigants, even though the purpose of the parties is to obtain a judgment affecting federal tax liability of one of the other of the parties to the litigation.



1. Where an action in state court may have direct bearing on an internal revenue statute or federal tax lien, and the Service has not been made a party, Field Counsel will have to determine whether the Service should intervene or take other appropriate steps in connection with the proceeding. See Policy Statement 4-10 http://publish.no.irs.gov/getpdf.cgi?catnum=48027 .


5. Certain guidelines have been established to determine what course of action the United States should take when the Service is erroneously named as a party defendant in a state court proceeding concerning a tax issue, and when intervention in the proceeding by the United States is unnecessary or undesirable. In a case similar to _Bosch v. Commissioner_, 387 U.S. 456 (1967), the following guidelines apply:



1. If the Government is merely given notice of the proceeding, as opposed to being served with judicial process, no action need be taken on behalf of the United States.

2. If no notice or process is served upon the Government but a request is made by an estate representative to the effect that the United States should intervene, no action need be taken on behalf of the United States since such action is generally not in the Government’s best interest.

3. If an attempt is made to serve the United States in such estate proceeding, such service should be declined.

4. If judicial service is effectively made upon a Service representative or the Government, a recommendation should be made to DOJ that the Government move to have itself dismissed as a party and to file a notice of disclaimer.

5. If the Government is improperly served, a recommendation should be made to DOJ to move for dismissal on the basis of improper jurisdiction, and to file a disclaimer at the same time. If the Government does have an interest in the proceedings it may move to intervene, notwithstanding the filing of its motion to dismiss.


6. **Specific Requirements of a Suit Letter**. This letter is similar to the collection suit letter and recommendations for foreclosure of the federal tax lien. See CCDM 34.6.1.3 http://publish.no.irs.gov/getpdf.cgi?catnum=38021, _Preparation of Suit Letters_, CCDM 34.6.2.2 and Exhibit 34.12.1–8 http://publish.no.irs.gov/getpdf.cgi?catnum=29689, _Preparation of Suit Letters — Checklist_.



1. The purpose of the intervention is to assert the tax lien against property. These cases generally involve questions of lien priorities. If there has not been a waiver of sovereign immunity, a motion to dismiss should be discussed. If there has been an attempt to name the United States under 28 U.S.C. § 2410, but the service was improper or the complaint was lacking in required particularity, there should be a discussion of whether the United States should intervene.

2. In addition, the following points should be noted: the nature of the property involved; the relative rights of the United States against the other participants; the reason why it is necessary that the United States intervene in such proceeding rather than pursue other avenues of collection; and whether the case should be removed to federal court if instituted in state court.


7. **Timeliness**. When considering intervention, Field Counsel must gauge whether intervention will be timely. Ordinarily, if the case has progressed to trial, the state court or the federal court may not wish to burden the litigation with the intervention of a new party. Keep in mind that intervention is generally allowed only with the permission of the court. Where the application to intervene is denied, see section 7424. Timeliness for removal of the case to federal court must also be considered.

8. **Choice of Forum**. By intervening, the United States subjects itself to the forum of the pending suit. Accordingly, if that forum would not be the best place for the United States to litigate its rights to the property, consider alternative action, such as allowing the litigation to continue and then asserting the Government’s rights, either administratively or by suit, against the successful person in the action when the property has been obtained.



1. The United States can remove a suit brought in state court to a federal court if it is named as a party defendant, in spite of the fact that such joinder of the United States is improper, because a suit against the United States raises federal questions (28 U.S.C. § 1451). Section 7424 now expressly provides that in any case where the United States intervenes, the provisions of 28 U.S.C. § 1444 (relating to removal of foreclosure actions) shall apply as if the United States had originally been named a party defendant in such action or suit. Thus, the United States has the same right of removal when it intervenes as a party plaintiff in a state court proceeding as the United States enjoys in any action brought against it under 28 U.S.C. § 2410.


**34.6.2.7** **(06-12-2012)**

### Erroneous Refunds

1. **General Information**. The Internal Revenue Code provides statutory authority for bringing suit against a taxpayer or any third party who has erroneously recovered a payment of money in the form of a tax refund. Such a suit may be brought regardless of whether an erroneous refund had been made under a mistake of fact or a mistake of law. Misrepresentation by the taxpayer is not a required element of the action.

2. **Authority for Action**. The statutory authority for this proceeding is found under section 7405.



1. Section 7405 does not provide that the method of recovery by suit is exclusive. Assessable erroneous refunds may also be recovered by administrative action within the applicable period of limitation upon assessment and collection. The type of tax involved is determinative of the type of administrative action available. Ordinarily, recovery by suit is used because administrative recovery is barred by the statute of limitations on assessment. Any contemplated collection activity based on administrative recovery should be coordinated. See IRM 21.4.5 http://publish.no.irs.gov/getpdf.cgi?catnum=36819, _Erroneous Refunds_.

2. Section 6532(b) provides the period of limitations on actions under section 7405. The two-year period for bringing suit begins from the date of delivery of the check in payment of the refund. Preliminary steps are considered as merely interdepartmental. Suit may be brought at any time within five years from the making of a refund if it appears that any part of the making of the refund was induced by fraud or misrepresentation of a material fact.


3. **Specific Requirements of Suit Letter**. The format and requirements of an erroneous refund suit letter will generally be the same as those of a collection suit letter. See CCDM 34.6.1.3 http://publish.no.irs.gov/getpdf.cgi?catnum=38021, _Preparation of Suit Letters_, and Exhibit 34.12.1–8 http://publish.no.irs.gov/getpdf.cgi?catnum=29689, _Preparation of Suit Letters — Checklist_. The letter will request and authorize action under section 7401 to commence a suit pursuant to section 7405(a). The letter should state why assessment procedures are not available.

4. The Service has the burden of proof on all elements of an erroneous refund suit. The Service must show:



1. That an erroneous refund was made;

2. The amount of the erroneous refund;

3. The taxpayer received or benefited from the refund; and

4. That the limitations period has not expired.


**34.6.2.8** **(08-11-2004)**

### Establishing Fiduciary Liability under 31 U.S.C. § 3713

1. Section 3713 of Title 31 provides an alternative method to collect a tax liability when the United States does not have a lien. Under section 3713, the United States may file an action to collect a taxpayer’s liability from fiduciary who voluntarily elects to satisfy other debts in preference to those due the United States.

2. **Methods of Asserting Liability**. The Government may bring suit in district court to enforce this fiduciary liability. Congress has also provided an easier summary method for asserting liability against a fiduciary.



1. I.R.C. § 6901(a)(1)(B) permits the Commissioner to proceed against a fiduciary for liability under section 3713 in the same manner as in all income, estate, and gift tax cases. The Service must send a 90-day letter, which affords the fiduciary an opportunity to take an appeal to the Tax Court. If the fiduciary does not choose to do so, the Service may make an assessment and administratively collect the liability.

2. The Service must assess the fiduciary liability within one year after the fiduciary liability arises or within the ten year statutory period for collection of the tax in respect of which such fiduciary’s liability arose, whichever is later. The fiduciary may execute a waiver to extend the period of limitations for assessment and may also execute an agreement to extend the period for collection. When income, estate, and gift taxes are involved, the fiduciary may appeal to the Tax Court for a redetermination of the liability asserted.

3. A court proceeding pursuant to this section is a suit in equity to collect the tax of the taxpayer from the personal estate of a fiduciary who has voluntarily, and in the exercise of a free option, elected to pay other debts of an estate for which he or she is acting or has acted, in preference to debts that he or she is aware are due the United States.

4. If the liability of the fiduciary has been finally established in the Tax Court, such decision is res judicata. Accordingly, the merits of that liability cannot be raised in any suit subsequently instituted to collect the amount thereof.

5. On the other hand, if the type of tax involved is one not within the scope of section 6901, the fiduciary has the right to litigate the merits of the liability.


3. **Specific Requirements of Suit Letter**. The usual suit letter is required in these matters, and the following issues should be considered.



1. While this type of suit is against the fiduciary personally, it is, nevertheless, a proceeding in court to collect the tax that was assessed against the taxpayer. Therefore, suit must be brought within the normal 10-year period of limitation for collection.

2. Fiduciary’s knowledge of taxpayer’s indebtedness to the United States is necessary. Actual knowledge, however, is not always necessary. It has been held that the fiduciary has sufficient knowledge if the facts establish that information was available that would put a reasonably prudent person on notice that an obligation was due the United States. It is enough if the fiduciary is in possession of such facts so that a faithful and fair discharge of duty would require an inquiry.

3. The liability of a fiduciary does not depend upon any benefit to the fiduciary from the administration of the estate. The fiduciary is liable for the amount the fiduciary used to pay off another debt instead of the United States’ priority under 31 U.S.C. § 3713, or for the amount remaining due and owing the United States on its claim, whichever is the lesser. The priority given federal taxes (among other debts) under 31 U.S.C. § 3713 does not extend to debts created in preserving or collecting the assets nor to administration expenses. The priority extends to only those assets or funds available for the payment of debts.


**34.6.2.9** **(06-12-2012)**

### Section 3505 Third Party Liability

1. **Provisions of section 3505**. Section 3505(a) makes third parties personally liable for the payment of withholding taxes when they pay wages directly to employees of another. This applies to lenders, sureties, or other persons ("other persons" include anyone similar to a lender or surety who pays the wages of employees of another out of his or her own funds). The liability extends to income tax withholding and withholding under social security and railroad retirement laws. It does not include the employers share because the person liable under this section is not an employer.

2. This provision does not relieve an employer from responsibilities with respect to withholding taxes. The employer’s responsibilities continue even though a lender, etc., may be paying the employees’ wages. Section 3505 renders the lender liable only when the employer does not pay the withholding taxes. Moreover, the employer must file an employer’s tax return and comply with other requirements imposed on employers generally. The lender’s liability is a sum equal to the taxes (together with interest) required to be deducted and withheld from the wages by the employer.

3. In addition, section 3505(b) provides that a lender, surety, or other person who advances funds to an employer for the payment of wages may be personally liable for any unpaid withholding taxes (trust funds) even though this person does not directly pay wages to the employees. To be personally liable, the lender, etc., must know that the funds advanced are to be used specifically for the payment of wages. This does not include an ordinary working capital loan even though the lender, etc., knows that part of the funds may be used to make wage payments in the ordinary course of business. The lender, etc., also must have actual knowledge that the employer does not intend, nor will not be able, to make timely payment or deposit of the withholding taxes. The Government has the burden of establishing actual notice or knowledge in such cases.



1. The main difference between the liability of this lender and the lender who pays wages directly is that liability in this case may not exceed 25% of the amount supplied to the employer for the specific purpose of paying wages. The employer is responsible for filing returns.


4. Payments by the lender of withholding taxes reduce the liability of an employer by the amount paid. Similarly, payments by an employer of the withholding taxes reduce the liability of the lender.

5. If the liable party under section 3505 does not voluntarily satisfy the liability, the Government may collect such liability by a court proceeding.

6. In _Jersey Shore State Bank v. United States_, 479 U.S. 442 (1987), the Supreme Court held that section 6303(a) does not require the Government to provide notice and demand for payment to a lender before bringing a civil suit against the lender to collect sums for which it is liable under section 3505. The court drew a distinction between the employer, who is liable for the unpaid taxes, and the lender, who has a separate liability under section 3505, but is not liable for the taxes.

7. Do not overlook the possibility that alternative remedies exist, particularly the assertion of the penalty provided by section 6672, the trust fund recovery penalty against responsible persons. Both remedies may be available to the Government. The trust fund recovery penalty remedy has advantages over the section 3505 remedy. The significant advantages are:



1. The ability to assess the trust fund recovery penalty liability;

2. The ability to collect the trust fund recovery penalty without the resort to court action;

3. That the taxpayer has the burden of proof in a suit commenced to challenge the validity of the trust fund recovery penalty, as distinguished from the fact that the Government has the burden of proving the suppliers’ liability in a section 3505 case; and

4. That it is much easier generally to establish the liability of a responsible person under section 6672 than it is to establish the liability of a supplier under section 3505.


8. The Miller Act (Act of August 26, 1935 (49 Stat. 793;) 40 U.S.C. § 270(a)) provides that every performance bond on federal construction projects shall specifically guarantee payment of the federal payroll taxes. The surety on the performance bond must guarantee the payment of taxes required to be collected, deducted, or withheld from wages by the contractor, whether or not the contractor does in fact collect, deduct, or withhold such taxes.



1. The Government must give notice to the surety, with respect to the unpaid taxes attributable to any period, within 90 days after the date when the contractor in fact files a return for such period. This period would normally be a calendar quarter. Notice to a surety must be given no later than 180 days from the date when such return was required to be filed, whether or not such return was filed. The notice requirements apply to each calendar quarter or other taxable period.

2. The Government may enforce the obligation of the bond by bringing suit against the surety within one year after the day on which the Service gave timely notice of the unpaid tax liability to the surety. Thus, if the Service gives the surety timely notice on July 1, 1998, that the contractor failed to pay over the taxes applicable to a taxable period, the Government must commence suit on or before July 1, 1999, to enforce the obligation under the performance bond.


9. **Specific Requirements of Suit Letters**. The usual suit authorization letter is required. See CCDM 34.6.1.3 http://publish.no.irs.gov/getpdf.cgi?catnum=38021, _Preparation of Suit Letters_, and Exhibit 34.12.1–8 http://publish.no.irs.gov/getpdf.cgi?catnum=29689, _Preparation of Suit Letters — Checklist_.


**34.6.2.10** **(08-11-2004)**

### Miscellaneous Actions Brought by the United States

1. The follow subsections describe other actions that may be brought by the United States.


**34.6.2.10.1** **(06-12-2012)**

#### Action on Bonds

1. The Area Director may accept a bond to stay the collection of taxes or to release a federal tax lien. In the event the taxpayer does not comply with the terms of the obligation that the bond secures, the Government may bring an action against the surety or sureties on the bond. Suit should be recommended when the taxpayer refuses to pay the tax, and it cannot be collected administratively. Any recommendation should provide the data relative to the tax liability, the circumstances under which the Service obtained the bond, a copy of the bond, the nature of the default under the terms of the bond, and the address of the surety.

2. The Government may also be able to take action on a bond as a means of collection in connection with other proceedings. For example, it may be possible to pursue the bond of an executor or administrator or other fiduciary, including those in bankruptcy cases.

3. The usual suit letter authorizing and requesting suit is required. CCDM 34.6.1.3 http://publish.no.irs.gov/getpdf.cgi?catnum=38021, _Preparation of Suit Letters_, and Exhibit 34.12.1–8 http://publish.no.irs.gov/getpdf.cgi?catnum=29689, _Preparation of Suit Letters — Checklist_.


**34.6.2.10.2** **(06-12-2012)**

#### Action to Open Safe Deposit Box

1. The Area Director has the authority to seize a safe deposit box by affixing a sticker and sealing the box. If the taxpayer refuses to open the safe deposit box, and the bank is unwilling or unable to open the box, the United States may seek a writ of entry or file an action in the local United States district court for a court order directing the keeper of the box to open it for inspection or seizure of the contents thereof by the Government. Section 7402.

2. Counsel must authorize an action to open a safe deposit box by suit letter. CCDM 34.6.1.3 http://publish.no.irs.gov/getpdf.cgi?catnum=38021, _Preparation of Suit Letters_. The letter should mention the terms of the contract or lease with the bank or other type of institution. If the contract is in default, a court order on the bank may not be necessary. The bank may be able and willing to open the box without court decree.

3. Field Counsel should request a suit to obtain a court order to open a safe deposit box in situations when:



1. The taxpayer’s assets are located in the spouse’s deposit box (individual assessment);

2. A nominee case is involved;

3. Prior court objections exist; or

4. Any other unusual factors are present.


4. The Service may obtain a writ of entry as an alternative to filing suit to gain access to the contents of safe deposit boxes in cases in which there are no unusual factors. In order to get a writ of entry, the revenue officer will have to submit an affidavit stating the need to enter the safe deposit box for the purpose of seizing the contents belonging to the taxpayer. A copy of the writ should be given to both the taxpayer and a representative of the financial institution where the deposit box is located. See IRM 5.10.3.5 http://publish.no.irs.gov/getpdf.cgi?catnum=35403, _Writ Procedures_.

5. The Area Director must pay the expense of drilling the box and the cost of repairing damages to the box caused by the forced entry. Accordingly, the letter should cover the matter of expenses.


**34.6.2.10.3** **(08-11-2004)**

#### Action by United States to Quiet Title

1. The Government may acquire title to property through the enforcement of a tax lien. This usually occurs when the Service sells property at a distraint sale and the highest bidder fails to meet the minimum price.

2. The Government may bring an action to quiet title to property it has acquired through the enforcement of a tax lien. See section 7402(e) for jurisdiction. This will maximize the amount that property will bring at sale.


**34.6.2.10.4** **(08-11-2004)**

#### Liability of Banks on Checks

1. Section 6311(c) holds a bank liable if the bank fails to pay a certified, treasurer’s or cashier’s check, or money order submitted in payment of a tax liability. The taxpayer who tendered the check or money order also shall remain liable.


**34.6.2.10.5** **(06-12-2012)**

#### Forfeiture Cases

1. Most states have laws that provide for the seizure of property used in connection with the commission of a crime and, if the accused is convicted of the criminal charge, for the forfeiture of the property to the state or a political subdivision thereof. For purposes of lien priority under section 6323(i)(3), a forfeiture under local law of property seized by a law enforcement agency of a state, county, or other local governmental subdivision does not relate back to the time of seizure if under local law the holder of an intervening claim or interest would have priority over the interest of the state, county, or other local governmental subdivision in the property.

2. It is often difficult to determine whether property seized belonged to the person in possession immediately prior to the seizure. This is especially true in the case of cash seized by local police in a gambling raid. The state or local political subdivision may maintain that the cash or other property is not subject to a lien against the taxpayer because it was acquired in the commission of a crime and a wrongdoer acquires no property interest in property unlawfully acquired.

3. In any forfeiture case, Field Counsel must determine whether the state or local authorities did in fact seize the subject property and, if they did, whether the taxpayer owned the property and whether the Service assessed the federal tax before or after the earliest date the property could have passed from the taxpayer to the state or local authorities.

4. Some cases present the question of whether the federal tax lien applies to property that was improperly seized by the local police. Most cases in this area are sensitive. Accordingly, it is important that the factual and legal development of each case be thorough and complete.

5. These cases may require a suit letter authorizing suit to enforce the tax lien, or one authorizing intervention to assert the lien. The property also may be the subject of an interpleader action. See CCDM 34.6.2.2, CCDM 34.6.2.6 and CCDM 34.5.6.7 http://publish.no.irs.gov/getpdf.cgi?catnum=39026, _Specific Requirements of Defense Letter in Interpleader Suits_.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part34/irm_34-006-002#addtoany "Show all")

A2A