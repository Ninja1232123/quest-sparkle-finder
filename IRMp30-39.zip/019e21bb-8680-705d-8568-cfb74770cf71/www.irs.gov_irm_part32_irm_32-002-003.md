---
url: "https://www.irs.gov/irm/part32/irm_32-002-003"
title: "32.2.3 Drafting Published Guidance | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part32/irm_32-002-003#main-content)

- 32.2.3  [Drafting Published Guidance](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271589082736)
  - 32.2.3.1  [Drafting Instructions](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271589066368)
  - 32.2.3.2  [Research](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271589116112)
  - 32.2.3.3  [General Formatting Guidelines](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271589092000)
    - 32.2.3.3.1  [CASE-MIS Number](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560533888)
    - 32.2.3.3.2  [Draft Date](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271589119520)
  - 32.2.3.4  [Identification System — General](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560506160)
    - 32.2.3.4.1  [Part Number](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560504480)
    - 32.2.3.4.2  [Coding — General](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271594023232)
      - 32.2.3.4.2.1  [Primary Coding](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560485296)
        - 32.2.3.4.2.1.1  [Revenue Rulings under the Code](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271594028016)
        - 32.2.3.4.2.1.2  [Revenue Rulings Under Tax Conventions](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271588998080)
        - 32.2.3.4.2.1.3  [Revenue Procedures](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271588995728)
        - 32.2.3.4.2.1.4  [Notices, Announcements, and News Releases](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560500544)
      - 32.2.3.4.2.2  [Secondary Coding](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560498992)
        - 32.2.3.4.2.2.1  [Revenue Rulings under the Code](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560537536)
        - 32.2.3.4.2.2.2  [Revenue Rulings under Tax Conventions](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560467568)
        - 32.2.3.4.2.2.3  [Revenue Procedures](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560527792)
    - 32.2.3.4.3  [Publication Number and Headings](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560524288)
    - 32.2.3.4.4  [Cross References](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271589087760)
  - 32.2.3.5  [Components of Revenue Rulings, Revenue Procedures, Notices, Announcements, and News Releases](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560546960)
    - 32.2.3.5.1  [Revenue Rulings](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560545232)
      - 32.2.3.5.1.1  [Components of Revenue Rulings](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560543712)
      - 32.2.3.5.1.2  [Headings](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271593985024)
        - 32.2.3.5.1.2.1  [Issue](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271593978592)
        - 32.2.3.5.1.2.2  [Facts](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271589108096)
        - 32.2.3.5.1.2.3  [Law](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560441504)
          - 32.2.3.5.1.2.3.1  [Code and Regulations](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560439760)
          - 32.2.3.5.1.2.3.2  [Court Opinions](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560437568)
          - 32.2.3.5.1.2.3.3  [Other Authorities](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560493296)
        - 32.2.3.5.1.2.4  [Analysis](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560488688)
        - 32.2.3.5.1.2.5  [Holding](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560481312)
        - 32.2.3.5.1.2.6  [Effect on Other Revenue Rulings (or Documents)](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560478336)
        - 32.2.3.5.1.2.7  [Prospective Application](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560473504)
        - 32.2.3.5.1.2.8  [Public Comments](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271589103616)
        - 32.2.3.5.1.2.9  [Drafting Information](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271589076480)
    - 32.2.3.5.2  [Revenue Procedures](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271589073744)
      - 32.2.3.5.2.1  [Headings](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271589070544)
        - 32.2.3.5.2.1.1  [Purpose](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560819616)
        - 32.2.3.5.2.1.2  [Changes](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560817888)
        - 32.2.3.5.2.1.3  [Background](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560815968)
        - 32.2.3.5.2.1.4  [Scope](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560814064)
        - 32.2.3.5.2.1.5  [Procedure (or Application)](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560812272)
        - 32.2.3.5.2.1.6  [Effect on Other Revenue Procedures (or Documents)](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560810368)
        - 32.2.3.5.2.1.7  [Effective Date](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560806176)
        - 32.2.3.5.2.1.8  [Paperwork Reduction Act](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560802288)
        - 32.2.3.5.2.1.9  [Public Comments](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560618544)
        - 32.2.3.5.2.1.10  [Drafting Information](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560616400)
        - 32.2.3.5.2.1.11  [Table of Contents and Appendices](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560614256)
    - 32.2.3.5.3  [Notices](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560612480)
      - 32.2.3.5.3.1  [Components of Notices](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560610688)
      - 32.2.3.5.3.2  [Paperwork Reduction Act](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560799424)
      - 32.2.3.5.3.3  [Public Comments](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560797280)
    - 32.2.3.5.4  [Announcements](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560795136)
      - 32.2.3.5.4.1  [Components of Announcements](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560793344)
      - 32.2.3.5.4.2  [Paperwork Reduction Act](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560788096)
      - 32.2.3.5.4.3  [Public Comments](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560785952)
    - 32.2.3.5.5  [News Releases](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560783808)
  - Exhibit  32.2.3-1  [Explanation of the Parts of the Internal Revenue Bulletin](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560779008)
  - Exhibit  32.2.3-2  [Format for Typed Draft of Proposed Revenue Ruling Under the Code](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271594011072)
  - Exhibit  32.2.3-3  [Format for Typed Draft of Proposed Revenue Ruling Under Tax Convention](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271593996880)
  - Exhibit  32.2.3-4  [Format for Typed Draft of Proposed Revenue Procedure](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560668864)
  - Exhibit  32.2.3-5  [Format for Typed Draft of Proposed Notice](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560652144)
  - Exhibit  32.2.3-6  [Format for Typed Draft of Proposed Announcement](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560640016)
  - Exhibit  32.2.3-7  [Format for Typed Draft of Proposed News Release](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560861584)
  - Exhibit  32.2.3-8  [Format for Typed Draft Cross-Reference Sheet](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560852880)
  - Exhibit  32.2.3-9  [Sample Effective Date Provisions](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560847216)
  - Exhibit  32.2.3-10  [Model Language for the Paperwork Reduction Act — Model 1](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271561016544)
  - Exhibit  32.2.3-11  [Model Language for the Paperwork Reduction Act — Model 2](https://www.irs.gov/irm/part32/irm_32-002-003#idm140271560590064)

# Part 32. Chief Counsel Directives Manual Published Guidance and Other Guidance to Taxpayers

# Chapter 2. Chief Counsel Publication Handbook

# Section 3. Drafting Published Guidance

* * *

## 32.2.3 Drafting Published Guidance

#### Manual Transmittal

February 04, 2025

#### Purpose

(1) This transmits revised CCDM 32.2.3, Drafting Published Guidance.

#### Background

CCDM 32.2.3.5.1.2.8, Revenue Rulings, Public Comments, is amended to provide instructions pertaining to soliciting public comments with respect to revenue rulings. The instructions include procedures commenters should use to submit comments using the Federal eRulemaking Portal at www.regulations.gov or by mail. In addition, the revisions provide instructions regarding coordination with Publications and Regulations (Procedure & Administration Branch 1) when a Revenue Ruling will solicit public comments. The procedures are intended to ensure Counsel’s readiness to receive and process public comments.

While only CCDM 32.2.3.5.1.2.8 is amended, existing CCDM provisions pertaining to public comments solicited by revenue procedures (CCDM 32.2.3.5.2.1.9), notices (CCDM 32.2.3.5.3.3), and announcements (CCDM 32.2.3.5.4) refer the user to CCDM 32.2.3.5.1.2.8 for guidance.

#### Material Changes

(1) CCDM 32.2.3 is amended to add detailed instructions pertaining to soliciting public comments with respect to IRB published guidance including revenue rulings (CCDM 32.2.3.5.1.2.8), revenue procedures (CCDM 32.2.3.5.2.1.9), notices (CCDM 32.2.3.5.3.3), and announcements (CCDM 32.2.3.5.4). Instructions are added to CCDM 32.2.3.5.1.2.8, Revenue Rulings, Public Comments. Public Comment provisions for revenue procedures, notices, and announcements refer the user to CCDM 32.2.3.5.1.2.8.

(2) Amended CCDM 32.2.3.5.1.2.8 provides the instructions drafters should include in the guidance to inform commenters about the procedures for submitting comments to the IRS. In addition, procedures are provided to drafters for coordinating with Publications and Regulations to prepare to receive and process comments.

#### Effect on Other Documents

CCDM 32.2.3, dated October 28, 2011, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(02-04-2025)

Paul T. Butler

Associate Chief Counsel

(Procedure & Administration)

**32.2.3.1** **(08-11-2004)**

### Drafting Instructions

1. This section provides basic information concerning the components and formatting requirements of a publication and on how to research and develop a publication.

2. Macros can assist in drafting publication items. The drafting attorney should use the eWord Macros under the CC Macros heading on the Menu toolbar in Microsoft Word to begin drafting revenue rulings, revenue procedures, notices, and announcements.


**32.2.3.2** **(08-11-2004)**

### Research

1. When a drafting attorney begins the research process for a proposed publication item, the drafting attorney should begin by reading the relevant authorities, checking internal sources for previously addressed publication items, and doing a comprehensive electronic database search.

2. If a proposed publication is based on a letter ruling or technical advice, the drafting attorney should read all of the authorities cited in the ruling or technical advice to become familiar with the authorities to make sure they are on point and that they stand for the propositions cited.

3. The drafting attorney should make certain that all citations are accurate and current and check court cases in a citator to make certain that the case is still good authority.

4. The Bulletin Index-Digest System (BIDS), which is current through 1994, is an historic source for the drafting attorney to check to make certain that the issue has not been published. The BIDS consists of digests of revenue rulings, revenue procedures, certain court opinions, notices, and other miscellaneous items giving citations to the full documents, and contains extensive finding lists and summaries arranged by subject matter. See Exhibit 32.2.3-1, Item B.

5. The drafting attorney should also conduct a general search in an electronic database for any publications, including publications that are not in the same series, that may have modified the Service’s position on the subject matter of the proposed publication. Since publications that are not in the same series may have modified the Service’s position on the issue, the drafting attorney should not rely solely on _Shepard’s Citations_.

6. Additional research. If appropriate, the drafting attorney should read treatises and articles in the area involved and consult informally with experts. The drafting attorney should conduct any other research needed in the analysis of the matter.


**32.2.3.3** **(10-28-2011)**

### General Formatting Guidelines

1. The proposed publication is typed by using the eWord Macros in Microsoft Word. Exhibits 32.2.3-2 through 32.2.3-7 illustrate the formats for revenue rulings, revenue procedures, notices, announcements, and news releases.

2. The left and right margins are always 1 inch, the bottom margin of the first page is not less than 11/1 inches, and the top margin is 1 inch from the top of the page.

3. In the body of all proposed publications, the first line of each main paragraph is indented five spaces. All material in the body of a proposed publication is typed double spaced except for long quotations and certain other indented material.

4. Although not required for publication in the IRB, the drafting attorney should include page numbering in proposed publication items. This will assist reviewers in keeping track of publications submitted for review. As there is no IRB requirement for page numbering, there is no specified format for page numbering.

5. The formats for typical revenue rulings under the Internal Revenue Code and under tax conventions are set forth in Exhibit 32.2.3-2 and Exhibit 32.2.3-3, respectively. The formats for a typical revenue procedure, notice, announcement, and news release are set forth in Exhibits 32.2.3-4 through 32.2.3-7.

6. Manuscript of publications for the IRB must conform to the procedures set forth in this Handbook and be error free. Assigned reviewers must ensure that the hard copies and electronic copy forwarded for publication are exactly the same. The Bulletin Unit is authorized to return any manuscript to the drafting attorney for correction if the material does not meet the standards of acceptability for submission to the printer.


**32.2.3.3.1** **(08-11-2004)**

#### CASE-MIS Number

1. Each proposed publication is identified by its CASE-MIS number in the upper right corner of the first page (one inch from the top of the page) on the same line as the draft date.


**32.2.3.3.2** **(08-11-2004)**

#### Draft Date

1. The date of the latest changes made to the proposed publication (for example Draft Date: 9/1/03) must be typed on the first page of each proposed publication in the upper left corner on the line opposite the control number, one inch from the top of the page. This date reflects changes made to any page since the last dated draft. This draft date appears only on the first page of the proposed publication. See Exhibits 32.2.3-2 through 32.2.3-7.


**32.2.3.4** **(08-11-2004)**

### Identification System — General

1. Revenue rulings and revenue procedures are printed within an identification system of IRB "Parts" and coding references for purposes of indexing them in the IRB. Announcements and notices are printed within an identification system of IRB "Parts" but with no coding references. News releases are not printed in the IRB. The text of a revenue ruling or revenue procedure is published at the place indicated by its primary coding, and a cross-reference is included at every point indicated by a secondary coding. The drafting attorney of the proposed publication has responsibility for assigning the correct Part Number in accordance with the outline shown in the Introduction printed in each IRB. See Exhibit 32.2.3-1. The current placement of publications and cross-references in these Parts is discussed below.


**32.2.3.4.1** **(08-11-2004)**

#### Part Number

1. Part I of the IRB includes revenue rulings, Supreme Court opinions and Treasury Decisions based on the provisions of the Internal Revenue Code of 1986.

2. Part II of the IRB includes revenue rulings that state a Service position under a tax convention and related Treasury Decision, cross-references for revenue rulings and revenue procedures, as appropriate, and legislation and related committee reports.

3. Part III of the IRB includes revenue procedures, notices, and other miscellaneous material.

4. Part IV of the IRB includes notices of proposed rulemaking, disbarment and suspension lists, and announcements.

5. The Part of the IRB in which the publication will appear is typed two lines below the CASE-MIS number beginning at the left margin for revenue rulings and revenue procedures and four lines below the control number for notices and announcements. "Part" is typed with the initial letter capitalized . The part number is designated by a roman numeral. See Exhibits 32.2.3-2 through 32.2.3-7.


**32.2.3.4.2** **(08-11-2004)**

#### Coding — General

1. The term "coding" refers to the identification of the provisions of:



   - The Internal Revenue Code and the regulations under which each revenue ruling is published

   - The tax convention and related Treasury Decision under which each revenue ruling is published

   - The Statement of Procedural Rules under which each revenue procedure is published


2. The attorney drafting the proposed publication is responsible for selecting the correct primary and secondary coding and for preparing a Cross-Reference Sheet for each secondary coding provision. See CCDM 32.2.3.4.4.

3. References to both the Code and the regulations, whether in the primary or the secondary coding, should include only the Code or regulation section number.



> _Correct:_ 421; 1.421-6.
>
> _Incorrect:_ 421(a); 1.421- 6(a)

4. Temporary regulations may be used in coding if final regulations have not been adopted.



### Example:



Rev. Rul. 78-193, 1978-1 C.B. 12

5. Proposed regulations are never used in coding. If neither final nor temporary regulations have been issued, or if the regulations do not reflect recent legislation that is the subject of the proposed publication, the regulations reference is omitted.



### Example:



Rev. Ruls. 78-191 and 78-192, 1978-1 C.B. 8


**32.2.3.4.2.1** **(08-11-2004)**

##### Primary Coding

1. Preceding the text of each revenue ruling certain identification, referred to as primary coding, must be shown. This includes either the number and title of the Code and regulations (including temporary regulations) sections principally involved in the revenue ruling or the name of the tax convention principally involved and a citation to the tax convention.

2. Preceding the text of each revenue procedure the section number and title of the Statement of Procedural Rules under which the revenue procedure is published must be shown.


**32.2.3.4.2.1.1** **(08-11-2004)**

###### Revenue Rulings under the Code

1. The word "Section" followed by the number and title of the Code section principally involved (not including a subsection identification or title) is typed at the left margin beginning two lines below the Part number. This entry is typed with the initial letter of each principal word capitalized (no period at the end of the title) and with the section number separated from the title by a period and two hyphens (without spaces). This entry is typed across the page to the right margin; if a second line is required, it is typed beginning at the left margin. See Exhibit 32.2.3-2.

2. "26 CFR" is typed at the left margin beginning three lines below the primary Code section number followed in order by the number of the primary regulations section, colon, two spaces, and the exact title of the regulations section (period at the end of the title). In practically all cases, only the first word in the regulations title begins with a capital letter. This entry is typed across the page to the right margin; if a second line is required, it is typed beginning at the left margin. If there are no final or temporary regulations under the primary Code section, this entry is omitted. See Exhibit 32.2.3-2..



### Example:



Rev. Ruls. 78-191 and 78-192, 1978-1 C.B. 8


**32.2.3.4.2.1.2** **(08-11-2004)**

###### Revenue Rulings Under Tax Conventions

1. The name of the tax convention is typed at the left margin beginning two lines below the designation "Part." This entry is typed with the initial letter of each principal word capitalized (no period at the end of the title). It is typed across the page to the right margin; if a second line is required, it is typed beginning at the left margin.

2. The citation to the tax convention is typed three lines below the name of the tax convention (period at the end of the citation). See Exhibit 32.2.3-3.


**32.2.3.4.2.1.3** **(08-11-2004)**

###### Revenue Procedures

1. The Part III title, "Administrative, Procedural, and Miscellaneous" (with the initial letters of the principal words capitalized), is typed at the left margin two lines below the Part number (no period at the end of the title).

2. "26 CFR" is typed three lines below the Part title, followed in order by the number of the Statement of Procedural Rules section involved, colon, two spaces, and the exact title of that section. In practically all cases, only the first word of the title of the section begins with a capital letter (period at the end of the title). This entry is typed across the page to the right margin; if a second line is required, it is typed beginning at the left margin. See Exhibit 32.2.3-4.


**32.2.3.4.2.1.4** **(08-11-2004)**

###### Notices, Announcements, and News Releases

1. Notices, announcements, and news releases do not contain primary or secondary coding.


**32.2.3.4.2.2** **(08-11-2004)**

##### Secondary Coding

1. When more than one section of the Code, tax convention, or Statement of Procedural Rules is significantly involved in the conclusion stated, the coding is expanded to include reference to the numbers of the additional sections that are significantly involved. This identification is referred to as secondary coding.

2. A section of the Code, tax convention, or Statement of Procedural Rules is significantly involved if a person might reasonably research the matter under that section.

3. Mere mention of a Code or regulations section in the body of a publication does not necessitate its inclusion in the coding.

4. When a revenue ruling applies section 7805(b)(8) to make a holding nonretroactive, the secondary coding must include reference to section 7805 and section 301.7805-1 of the regulations.



### Example:



Rev. Rul. 78-94, 1978-1 C.B. 58





    Also see Rev. Rul. 64-132, 1964-1 (Part I) C.B. 501, for an illustration of coding for a revenue ruling written solely to make a prior revenue ruling nonretroactive.) On the other hand, prospective application of a revenue procedure should not be coded or cross-referenced to section 7805.


5. If more than one section of the regulations under a single section of the Code is significantly involved in the conclusion stated, the secondary coding should make reference to all of these sections.



### Example:



Rev. Rul. 78-37, 1978-1 C.B. 54

6. A Cross-Reference Sheet must be prepared for each secondary coding reference. See CCDM 32.2.3.4.4.


**32.2.3.4.2.2.1** **(08-11-2004)**

###### Revenue Rulings under the Code

1. Citations to any cross-reference needed are shown in the secondary coding line. The secondary coding entry generally begins with an opening parenthesis followed by "Also Section(s)" followed in order by the numbers of all Code sections cross-referenced, semicolon, and the numbers of the pertinent sections of the related regulations, followed by a closing parenthesis, and ending with a period.

2. All of the secondary coding information is typed, in parentheses, beginning at the left margin on the first line below the line beginning "26 CFR." If "26 CFR" is not typed in the primary coding entry because there are no regulations under the primary Code section, the cross-reference citation is typed three lines below the primary Code section number with "26 CFR" typed ahead of the cross-reference regulations section designation.

3. The secondary coding entry is typed across the page to the right margin; if a second line is required, it is typed beginning at the left margin.


**32.2.3.4.2.2.2** **(08-11-2004)**

###### Revenue Rulings under Tax Conventions

1. Citations to cross-references needed under any provision of the Code (or the Statement of Procedural Rules) are shown in the secondary coding line. The secondary coding entry generally begins with an opening parenthesis followed by "Also Part I, Section(s)" , followed by the numbers of all Code sections cross-referenced, semicolon, and the numbers of the pertinent sections of the related regulations, followed by a closing parenthesis, and ending with a period.

2. All of the secondary coding information is typed, in parentheses, beginning at the left margin on the first line below the citation to the tax convention.

3. The secondary coding entry is typed across the page to the right margin; if a second line is required, it is typed beginning at the left margin.


**32.2.3.4.2.2.3** **(08-11-2004)**

###### Revenue Procedures

1. Citations to cross-references needed under any other provision of the Statement of Procedural Rules are shown in a separate secondary coding line that begins with "Also Section," is enclosed in parentheses, and is typed at the left margin on the first line below the line that begins "26 CFR." Citations to cross-references needed under any provision of the Code are shown on a separate secondary coding line, which begins with an opening parenthesis followed by "Also Part I, Section(s)," followed by the numbers of all Code sections cross-referenced, semi-colon, and the numbers of the pertinent sections of the related regulations, followed by a closing parenthesis, ending with a period.

2. This secondary coding line is also enclosed in parentheses and is typed at the left margin on the first line below any secondary coding to the Statement of Procedural Rules or, if there is none, on the first line below the line that begins "26 CFR."

3. The secondary coding entry is typed across the page to the right margin; if a second line is required, it is typed beginning at the left margin.


**32.2.3.4.3** **(08-11-2004)**

#### Publication Number and Headings

1. A blank space of 10 lines following the primary and secondary coding is left in the revenue ruling or revenue procedure to allow the Bulletin Unit to insert the highlight. No space is needed for a notice, announcement, or news release.

2. The abbreviation "Rev. Rul." or "Rev. Proc." is typed following the blank space and starting at the left margin. The words "notice" , "announcement," and "news release" are not abbreviated and are prepared pursuant to _Exhibit 32.2.3-5_, _Exhibit 32.2.3-6_, and _Exhibit 32.2.3-7_, respectively.

3. Headings identifying the various parts of a revenue ruling or revenue procedure are typed in all upper case letters. The first heading is typed three lines below "Rev. Rul." or "Rev. Proc." For revenue rulings, the headings are typed flush with the left margin and are not followed by a period. For revenue procedures, the headings are assigned section numbers and are typed flush with the margin. The word "SECTION" is typed using all capital letters. Headings are not always needed in notices and announcements, and typically, are not used in news releases. If headings are used, follow the guidelines provided for revenue rulings or revenue procedures above.


**32.2.3.4.4** **(08-11-2004)**

#### Cross References

1. A Cross-Reference Sheet is prepared for each secondary coding reference for insertion in the proper place in the IRB.

2. The Cross-Reference Sheets carry secondary coding and use as their primary coding those sections of the Code and regulations (or tax conventions and related Treasury Decisions or Statement of Procedural Rules) shown in the secondary coding of the revenue ruling or revenue procedure.

3. The Cross-Reference Sheet does not state a holding. It is usually cast in the form of a question. This statement ends with appropriate final punctuation and is followed by the words, "See Rev. Rul.\_\_\_ page\_\_." or "See Rev. Proc.\_, page \_\_\_."

4. When the project is being forwarded for publication, a separate Cross-Reference Sheet is prepared for each cross-referenced section of the Code, or of a tax convention, or of the Statement of Procedural Rules, in accordance with the format illustrated in Exhibit 32.2.3-8.


**32.2.3.5** **(08-11-2004)**

### Components of Revenue Rulings, Revenue Procedures, Notices, Announcements, and News Releases

1. The body of a revenue ruling or revenue procedure generally is organized into certain components. Headings are usually used for each component of these publications.


**32.2.3.5.1** **(08-11-2004)**

#### Revenue Rulings

1. Revenue rulings are current authority and should be written in the present tense. For example: "Rev. Rul. 2002-50, 2002-32 I.R.B. 292, holds ... ." They speak from the perspective of the Service. Thus, revenue rulings should not contain language such as "The IRS today announced " —this language speaks from the perspective of a newspaper.


**32.2.3.5.1.1** **(08-11-2004)**

##### Components of Revenue Rulings

1. Most revenue rulings interpret the law with respect to a particular set of facts. They should be written so that the principles covered are clearly understood. Revenue rulings that interpret tax conventions are unique to the office of the Associate Chief Counsel (International). Most of the components of each type of revenue ruling are the same.

2. The body of a revenue ruling may include some or all of the following components: issue, facts, law, analysis, holding, effect on other revenue rulings (or documents), prospective application, and drafting information. See Exhibit 32.2.3-2 for the format of a proposed revenue ruling under the Internal Revenue Code and Exhibit 32.2.3-3 for the format of a proposed revenue ruling under a Tax Convention.


**32.2.3.5.1.2** **(08-11-2004)**

##### Headings

1. Headings are used to identify the following components, as needed. They are presented in uppercase letters and are typically in the following order:



   - ISSUE(S)

   - FACTS

   - LAW

   - ANALYSIS

   - HOLDING(S)

   - EFFECT ON OTHER REVENUE RULINGS (or DOCUMENTS)

   - PROSPECTIVE APPLICATION

   - DRAFTING INFORMATION


2. Two headings may be combined when appropriate.



### Example:



ISSUE AND FACTS;


LAW AND ANALYSIS

3. If a particular revenue ruling does not lend itself to this format, the headings may be omitted altogether. For an example see Rev. Rul. 2001-1, 2001-1 C.B. 726.


**32.2.3.5.1.2.1** **(08-11-2004)**

###### Issue

1. The issue is the question to be answered by the revenue ruling. The issue should be drafted with the holding of the revenue ruling clearly in mind because the holding must be directly responsive to, and ordinarily must parallel the language of, the issue. The issue should be stated in ordinary question format.



> **_Example 1:_** Is the Irish wealth tax deductible under section 164 ... ?





> **_Example 2:_** Does a leasehold interest qualify under section 1033(f) ... ?





> **_Example 3:_** If the income of X corporation is diverted to Y corporation, is that income ... ?

2. If more than one issue is discussed in a revenue ruling, the issues should be numbered for easy reference. See Exhibit 32.2.3-2.


**32.2.3.5.1.2.2** **(08-11-2004)**

###### Facts

1. Clearly state the specific facts on which the holding is based. Include all facts that are relevant to a proper understanding of the holding. Do not introduce a fact for the first time in another section of the revenue ruling.

2. Eliminate extraneous facts because their presence in a revenue ruling may cloud the message of the holding.

3. Present two or more factual situations in the same revenue ruling as "Situation 1. ... ." and "Situation 2. ... ." or in some similar manner. See Exhibit 32.2.3-2.

4. Tailor the facts, particularly the dates, to fit the period to which a particular statutory provision applies.

5. Words of limitation in the fact statement may help narrow the focus of a reader of the revenue ruling to the precise issue being addressed. For example, a sentence such as "Apart from the lack of a private foundation, the plan satisfies the guidelines of Rev. Proc. 76-47, 1976-2 C.B. 670," helps the reader understand what is and is not being decided in the revenue ruling. Similarly, a sentence could be included after relevant facts are described such as, "Except for the question at issue, the transaction meets the requirements of section xxx of the Code."

6. Alter facts taken from actual cases to conceal the identity of the taxpayer, and other confidential personal or business information, such as the names and addresses of persons involved in the transaction described, including secret processes. For example, dollar amounts should be reduced proportionately or changed to x dollars. The omission of confidential information and identifying details is necessary to prevent unwarranted invasion of personal privacy and to comply with the statutory provisions, such as section 7213 and 18 U.S.C. section 1905, dealing with disclosure of trade secrets and other confidential information obtained from members of the public and return information under sections 6103 and 6110(c).


**32.2.3.5.1.2.3** **(08-11-2004)**

###### Law

1. The LAW section includes discussions of relevant provisions of the Internal Revenue Code, regulations, court opinions, and other authorities, including other publication items.


**32.2.3.5.1.2.3.1** **(08-11-2004)**

###### Code and Regulations

1. The most directly applicable provisions of the Internal Revenue Code and regulations are paraphrased. If, however, the holding rests upon specific language in the Internal Revenue Code or regulations, that language may be quoted. When quoting or paraphrasing a section of the Internal Revenue Code or regulations, it is sufficient to say that the section "provides" rather than that it "provides, in part, ... ," unless the material presented would be misleading without an affirmative statement that only part of the Internal Revenue Code or regulations was quoted or paraphrased.


**32.2.3.5.1.2.3.2** **(08-11-2004)**

###### Court Opinions

1. A relevant court opinion that bears directly upon an issue addressed in the revenue ruling may be used in the LAW or LAW AND ANALYSIS section with some indication of what the opinion means. When specific language of a court opinion is quoted or paraphrased, it is correct to say that the court "stated."

2. A court opinion that is adverse to the Service position will not be cited as authority in revenue rulings if the Service has decided not to follow that case, either by a published nonacquiescence (in Tax Court cases) or by an unpublished Action on Decision (in other federal court cases). Opinions of the Supreme Court of the United States, however, are always followed. Generally, it is not advisable to cite an adverse opinion in which the Commissioner has acquiesced in result only. An adverse opinion may, however, be cited in order to distinguish it from the facts stated in or the law applicable to the present revenue ruling, or when a revenue ruling is being used to announce that the Service will follow an adverse opinion in a particular case. An opinion that supports the Service’s position in a matter may nevertheless be unacceptable for use in a revenue ruling if it would adversely affect another Service position.

3. An unreported opinion of any court, including a memorandum opinion of the Tax Court or the Board of Tax Appeals, is cited only if better authority is not available. When an unreported opinion is used in a revenue ruling, it is not cited to an unofficial private commercial reporter.


**32.2.3.5.1.2.3.3** **(08-11-2004)**

###### Other Authorities

1. Other publication items that bear directly upon the issue may be used in the LAW or LAW AND ANALYSIS section with some indication of what they mean. When the holding of an existing ruling is referred to in a new revenue ruling, it is correct to refer to that holding in the present tense because it is current authority. THUS: "Rev. Rul. 92-69, 1992-2 C.B. 51, holds ... ."

2. Relevant federal tax statutes other than the Internal Revenue Code may be cited, paraphrased, or quoted, as appropriate.

3. Congressional material should be used with care. Committee reports may be cited, paraphrased, or quoted. A Joint Committee General Explanation of a revenue act (commonly referred to as the "Bluebook" ), however, should not be cited as authority. These explanations reflect only the views of the staff of the Joint Committee as to the intent of Congress and are not part of the legislative history of the act. Extracts from congressional debate or hearings generally are used only if better authority is not available and only if the speaker had significant official authority, such as chairperson of a committee.

4. Treatises (such as Fletcher on Corporations or Scott on Trusts) may be cited on a selective basis only when better authority is not available.

5. Articles in professional journals and legal encyclopedias, editorial comments in commercial tax services, and similar items should not be cited.


**32.2.3.5.1.2.4** **(08-11-2004)**

###### Analysis

1. The analysis is the explanation of how the cited authorities apply to the issue(s) and facts presented in order to reach the conclusion(s) of the revenue ruling. Because a revenue ruling serves as research material for taxpayers and Service personnel, it should contain sufficient analysis to permit some degree of analogy in similar factual situations. Only in rare situations may the position of the Service be stated without analysis or explanation.

2. When more than one issue or situation is presented, the analysis of each may be presented separately, if desired, under headings such as "Analysis – Issue (1)" or "Analysis – Situation 1."


**32.2.3.5.1.2.5** **(08-11-2004)**

###### Holding

1. The holding must be directly responsive to, and ordinarily must parallel the language of, the issue. It should be stated clearly and definitively. Normally, it is stated without introductory words, such as "Accordingly."

2. The holding should not be drafted with reference to the particular taxpayer identified in the facts. For example, the holding should not state, "Under the facts of this ruling, X may deduct advertising expenditures as an ordinary and necessary business expense under section 162."

3. If more than one issue or more than one factual situation is discussed in the revenue ruling, the holdings should be clearly labeled to show which issue relates to which holding.


**32.2.3.5.1.2.6** **(08-11-2004)**

###### Effect on Other Revenue Rulings (or Documents)

1. If another revenue ruling (or another document) is affected (that is, amplified, clarified, distinguished, modified, obsoleted, revoked, superseded, supplemented, or suspended, as those terms are described in CCDM 32.2.2.8.1, Use of Terms) by the new revenue ruling, that fact must be stated. The extent of the change should be described precisely; it is not sufficient to state that a prior revenue ruling is modified "to the extent that it is inconsistent herewith."

2. Generally, it is helpful to discuss the effect on another publication and the extent of the change in the ANALYSIS or LAW AND ANALYSIS section of the new revenue ruling. Nevertheless, the EFFECT ON OTHER REVENUE RULINGS (or DOCUMENTS) heading must be retained and be followed by a statement that "Rev. Rul. xx-xxx is how affected." This statement in the EFFECT ON OTHER REVENUE RULINGS (or DOCUMENTS) section is necessary both to ensure clarity and to aid in updating finding lists and citators.

3. When significant changes are made by a new revenue ruling to a prior revenue ruling, it is usually desirable to incorporate into the new revenue ruling the remaining current provisions of the previous revenue ruling so that the previous ruling may be modified and superseded.

4. A new revenue ruling may affect a prior publication in more than one way. For example, the new revenue ruling may amplify and supersede, clarify and supersede, or modify and supersede the prior publication. In these cases, all relevant terms are used in the EFFECT ON OTHER REVENUE RULINGS (or DOCUMENTS) section. (Illustration: "Rev. Rul. xx–xxx is amplified and superseded." )


**32.2.3.5.1.2.7** **(08-11-2004)**

###### Prospective Application

1. Revenue rulings apply retroactively unless they include a specific statement indicating, under the authority of section 7805(b)(8), the extent to which they are to be applied without retroactive effect (that is, prospectively). If a position taken in a revenue ruling is to be applied only prospectively it must be stated clearly and section 7805(b)(8) cited as the authority. See Exhibit 32.2.3-9 for a sample statement.

2. Section 7805(b)(8) provides the Secretary with the authority to prescribe the extent to which any ruling is to be applied prospectively only. This authority has been redelegated to the Deputy Associate Chief Counsel level. The exercise of this authority requires an affirmative action. Approval by an Associate or Deputy Associate Chief Counsel of a revenue ruling containing a clear statement that a position taken in the ruling is to be applied only prospectively is sufficient.

3. Revocation or modification of a previous revenue ruling is usually made nonretroactive to the extent that the new revenue ruling has adverse tax consequences to taxpayers.

4. When a revenue ruling applies only prospectively pursuant to section 7805(b)(8), the secondary coding must include reference to section 7805(b)(8) and section 301.7805–1 of the Regulations on Procedure and Administration .

5. If a proposed revenue ruling is to be applied only prospectively, the Background Information Note (BIN), using the caption Prospective Application Considerations (see CCDM 32.2.4.2.1.8 , Prospective Application), should state and discuss the reasons for and against the prospective application. The BIN should also include background information necessary to an understanding of the section 7805(b)(8) considerations as well as supporting facts and reasons for the application of section 7805(b)(8). If desired, the information may be summarized and organized under the following headings:



   - Reasons for applying section 7805(b)(8)

   - Reasons for rejecting the application of section 7805(b)(8)

   - Recommendation of whether section 7805(b)(8)’s nonretroactivity rule should apply


**32.2.3.5.1.2.8** **(02-04-2025)**

###### Public Comments

1. If the revenue ruling solicits public comments, include a section entitled **Comments** with instructions for submitting comments to the IRS.

2. Instruct the public to submit comments as follows:



> Commenters are strongly encouraged to submit public comments electronically. Submit electronic submissions via the Federal eRulemaking Portal at **www.regulations.gov** by following the online instructions for submitting comments (type IRS-\[year\]-\[FDMS docket number received from PR\]). Once submitted to the Federal eRulemaking Portal, comments cannot be edited or withdrawn.





> Send paper submissions to:





> Internal Revenue Service





> Attn: CC:PA:01:PR (\[guidance type and number\]), Room 5203





> P.O. Box 7604, Ben Franklin Station





> Washington, D.C. 20044.





> The IRS will publish any paper comments to the public docket on the Federal eRulemaking Portal.

3. While drafting the guidance, coordinate the receipt of comments with the Publications and Regulations section (Procedure & Administration Branch 1) by taking the following actions. Direct all communications to the Publications and Regulations section Legal Assistant with a copy to the Section Chief. Contact information may be found in the Procedure & Administration directory.



1. On the date the pink circulation begins, the drafting attorney should request that the Publications and Regulations section open a docket on regulations.gov to receive comments by providing the following information by email.



      > - Subject line: "\[Guidance type\] soliciting comments – Request to open docket"
      >
      >       - In the body of the email: Request to open a docket on regulations.gov to receive comments
      >
      >       - The guidance title and CaseMIS number
      >
      >       - Contact information for the Chief Counsel attorney drafting the guidence

2. After the guidance is cleared by Treasury for release and the final version of the guidance is available, provide the following information to Publications and Regulations by email:



      > - Subject line: "Revenue Ruling 20XX-XX cleared for release"
      >
      >       - Attach a copy of the final version of the revenue ruling cleared for release
      >
      >       - State the attached document is the final version of the revenue ruling, the date and time of release, and how the revenue ruling is being released. If the revenue ruling is published in the Federal Register, the Federal Register published version will be used as the final version of the document.

3. The docket on regulations.gov must be ready to receive public comments on the day guidance is released to the public.


**32.2.3.5.1.2.9** **(08-11-2004)**

###### Drafting Information

1. A paragraph relating to drafting information, including the name of the drafting attorney, is included in drafts of proposed revenue rulings. The name of the drafting office may be substituted for the drafting attorney if appropriate. This section must contain some point of contact for further inquiries.


**32.2.3.5.2** **(08-11-2004)**

#### Revenue Procedures

1. The body of a revenue procedure may include a table of contents, an appendix, and some of the components listed below (or others) as needed.

2. A revenue procedure that discusses the contents of an internal management document should include only as much of the internal management document or communication as is necessary for an understanding of the procedure.

3. Certain revenue procedures, such as those providing instructions concerning the requirements for obtaining a letter ruling or technical advice, are updated annually. See Rev. Proc. 2003-1, 2003-1 I.R.B. 1, and Rev. Proc. 2003-2, 2003-1 I.R.B. 76, (or any successors).

4. Certain procedures pertaining to particular taxes are set forth in the substantive provisions of the statutes and regulations. Other procedural rules with respect to taxes administered by the Service are set forth in the Statement of Procedural Rules, 26 C.F.R. § 601.


**32.2.3.5.2.1** **(08-11-2004)**

##### Headings

1. HEADINGS are used in revenue procedures to identify the following components, as needed.



   - PURPOSE

   - CHANGES

   - BACKGROUND

   - SCOPE

   - PROCEDURE (or APPLICATION)

   - EFFECT ON OTHER REVENUE PROCEDURES (or DOCUMENTS)

   - EFFECTIVE DATE

   - PAPERWORK REDUCTION ACT

   - DRAFTING INFORMATION


2. A numbering system is used in combination with the headings in revenue procedures. The word "SECTION" is typed in capital letters beginning at the left margin for the heading of the first section, followed in order by a space, the figure 1, a period, a space and the heading typed in capitals (no period at the end of the heading). The word "SECTION" is used for all subsequent sections (and in the table of contents, if applicable). If a section contains more than one paragraph, it may be divided further into subsections, paragraphs, subparagraphs, Divisions, and subdivisions, which are assigned numerical or alphabetical designations (and may be assigned subheadings), as illustrated in Exhibit 32.2.3-4. The subsection designation is indented five spaces from the margin, and each successive division is indented three spaces further, as shown below:



### Example:










|  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
| (Left margin) |
|  | SECTION 1, 2, 3, etc.; |
|  |  | .01, .02, etc. (subsections); |
|  |  |  | (1), (2), etc. (paragraphs); |
|  |  |  |  | (a), (b), etc. (subparagraphs); |
|  |  |  |  |  | (i), (ii), etc. (divisions); |
|  |  |  |  |  |  | and (A), (B), etc. (subdivisions). |

3. If a particular revenue procedure does not lend itself to this format, the headings may be omitted altogether and the text presented in narrative form.



### Example:



Rev. Proc. 77–27, 1977–2 C.B. 537


**32.2.3.5.2.1.1** **(08-11-2004)**

###### Purpose

1. The purpose of the revenue procedure should be clearly and directly stated. For example, "This revenue procedure provides ... . "


**32.2.3.5.2.1.2** **(08-11-2004)**

###### Changes

1. When a revenue procedure changes a prior revenue procedure, a clear explanation of the significant change(s) must be stated in the CHANGES section of the new revenue procedure. Reference should be made to each affected section of the earlier revenue procedure describing each significant change and the reason for it.


**32.2.3.5.2.1.3** **(08-11-2004)**

###### Background

1. The BACKGROUND section explains the need for the revenue procedure. In addition, a discussion of the relevant Internal Revenue Code sections, regulations, and prior revenue procedures and revenue rulings that helped form a basis for the revenue procedure should be included in the BACKGROUND section.


**32.2.3.5.2.1.4** **(08-11-2004)**

###### Scope

1. The SCOPE section sets forth the extent of the application of the revenue procedure. If the revenue procedure does not apply to a particular situation the SCOPE section should so state.


**32.2.3.5.2.1.5** **(08-11-2004)**

###### Procedure (or Application)

1. The PROCEDURE (OR APPLICATION) section sets forth in concise language the various steps or requirements that are necessary to accomplish the purpose of the revenue procedure. It may be advantageous to use more than one section with appropriate subheadings that describe the different situations covered by the revenue procedure.


**32.2.3.5.2.1.6** **(08-11-2004)**

###### Effect on Other Revenue Procedures (or Documents)

1. The same rules apply to revenue procedures as to revenue rulings.

2. If another publication is affected (that is, amplified, clarified, distinguished, modified, obsoleted, revoked, superseded, supplemented, or suspended, as those terms are described in CCDM 32.2.2.8.1, Use of Terms) by the new revenue procedure, that fact must be stated. The extent of the change should be stated precisely; it is not sufficient to state that a prior revenue procedure is modified "to the extent that it is inconsistent herewith."

3. If the effect on a prior publication is described in another section of the new revenue procedure (for example, when a prior revenue procedure is superseded and the significant changes are described in the CHANGES section of the new revenue procedure), a statement that "Rev. Proc. xx-xxx is superseded" must also be included in the EFFECT ON OTHER REVENUE PROCEDURES (or DOCUMENTS) section of the new procedure. This statement in the EFFECT ON OTHER REVENUE PROCEDURES (or DOCUMENTS) section is necessary both to ensure clarity and to aid in updating finding lists and citators.

4. A revenue procedure may affect a prior publication in more than one way. For example, it may amplify and supersede, clarify and supersede, or modify and supersede, etc. (In such cases both terms are used in the EFFECT ON OTHER REVENUE PROCEDURES (or DOCUMENTS) section. (Illustration: "Rev. Proc. xx-xxx is modified and superseded." )


**32.2.3.5.2.1.7** **(08-11-2004)**

###### Effective Date

1. Revenue procedures usually contain an EFFECTIVE DATE heading and provision.

2. Ordinarily, the effective date of a revenue procedure is either the date of publication or a later date when appropriate. In some cases, however, it is appropriate to state the effective date of a revenue procedure in other terms, including in terms of periods beginning before publication of the revenue procedure, events occurring after the beginning of the year in which a revenue procedure is published, or requests submitted after the beginning of the calendar year in which a revenue procedure is published. See Exhibit 32.2.3-9 for sample effective date provisions.

3. When the effective date is intended to be concurrent with publication, the effective date should be the date of the IRB in which the revenue procedure is published, or if the revenue procedure is released to the tax services in advance of its publication in the IRB, the effective date should be the date of the release. See Exhibit 32.2.3-9. Do not state that the revenue procedure is effective "immediately."

4. Prospective application of revenue procedures does not require coding and cross-referencing to section 7805(b)(8).


**32.2.3.5.2.1.8** **(08-11-2004)**

###### Paperwork Reduction Act

1. The Paperwork Reduction Act (PRA) requires federal agencies to obtain OMB approval before any collection of information may be enforced. The Paperwork Reduction Act potentially applies to revenue rulings, revenue procedures, notices, and announcements.

2. In general, the term "collection of information" means a reporting, recordkeeping, or disclosure requirement that is imposed on ten or more persons. It does not matter whether the requirement is voluntary or mandatory or if the requirement is imposed by statute. See 5 C.F.R. § 1320.3(c).

3. The term "reporting requirement" means a requirement that persons provide information to an entity of the Federal government. For example, a publication that requires a separate statement to be attached to a tax return imposes a paperwork burden subject to the PRA. However, a publication that requires a form to be filed does not impose a paperwork requirement subject to the PRA because the form, and not the publication, is the "instrument of collection" that is subject to the PRA.

4. The term "recordkeeping requirement" means that persons must maintain _specified_ records, whether or not an entity of the federal government or any other person actually seeks access to the records or is provided such records. See 5 C.F.R. § 1320.3(m). (This mandate to maintain specified records is a requirement in addition to the general books and records requirement of section 6001.) Thus, because a recordkeeping requirement is one that requires _specified_ records, a publication that does not require that particular records be maintained, but nonetheless prompts some taxpayer to maintain records consistent with the provisions of section 6001, does not impose a recordkeeping requirement.

5. The term "disclosure requirement" means that a person must disclose information to third parties, the Federal government, or to the public at large.

6. See Exhibit 32.2.3-10 and Exhibit 32.2.3-11 for model language to use in proposed publications concerning the Paperwork Reduction Act.

7. If a revenue procedure contains a collection of information requirement, the drafting attorney must complete [OMB Form 83-I](http://www.dtic.mil/whs/directives/infomgt/forms/eforms/omb83-i.pdf), Paperwork Reduction Act Submission, and a Supporting Statement. See Exhibit 32.1.2–4, OMB Form 83-I, Paperwork Reduction Act Submission, and Exhibit 32.1.2–6, Supporting Statement for Paperwork Reduction Act Submissions. As soon as a final decision is made with respect to a revenue procedure’s collection of information requirements, the drafting attorney must provide the Paperwork Reduction Act contact person with:



   - OMB Form 83-I,

   - Supporting Statement,

   - Copy of the revenue procedure, and

   - Copy of the underlying statute.


8. For instructions for completing OMB Form 83-I see Exhibit 32.1.2–5. The drafting attorney should submit hard copies of these documents and send an email attaching any electronic versions. The drafting attorney should contact the Paperwork Reduction Act contact person for questions regarding OMB Form 83-I or Supporting Statement.


**32.2.3.5.2.1.9** **(08-11-2004)**

###### Public Comments

1. _See_ CCDM 32.2.3.5.1.2.8.


**32.2.3.5.2.1.10** **(08-11-2004)**

###### Drafting Information

1. _See_ CCDM 32.2.3.5.1.2.9.


**32.2.3.5.2.1.11** **(08-11-2004)**

###### Table of Contents and Appendices

1. A table of contents and appendices can be used to organize a very lengthy revenue procedure or revenue ruling. For examples of table of contents and appendices see Rev. Proc. 2003-1 (or any successors).


**32.2.3.5.3** **(08-11-2004)**

#### Notices

1. Notices are used to publicly announce guidance that may involve substantive interpretations of the Internal Revenue Code or other provisions of the law. See CCDM 32.2.2.3.3 , Notice Defined.


**32.2.3.5.3.1** **(08-11-2004)**

##### Components of Notices

1. The components for a notice are reflected in Exhibit 32.2.3-5. Note the following points:



1. A brief title, describing the subject matter of the notice, is typed below "Part III — Administrative, Procedural, and Miscellaneous."

2. The word "Notice" followed by the current year designation, is typed below the descriptive title.

3. Headings should be used in notices when helpful.


2. Notices have effective dates similar to revenue procedures. See Exhibit 32.2.3-9 for sample effective date provisions.


**32.2.3.5.3.2** **(08-11-2004)**

##### Paperwork Reduction Act

1. _See_ CCDM 32.2.3.5.2.1.8.


**32.2.3.5.3.3** **(08-11-2004)**

##### Public Comments

1. _See_ CCDM 32.2.3.5.1.2.8.


**32.2.3.5.4** **(08-11-2004)**

#### Announcements

1. Announcements are used to publicly announce guidance of an immediate or short-term value and to publish advance notices of proposed rulemaking in the IRB. See CCDM 32.2.2.3.4, Announcement Defined.


**32.2.3.5.4.1** **(08-11-2004)**

##### Components of Announcements

1. The components for an announcement are reflected in Exhibit 32.2.3-6. Note the following points:



1. A brief title, describing the subject matter of the announcement, is typed below "Part IV – Items of General Interest."

2. The word "Announcement" followed by the current year designation, is typed below the descriptive heading.

3. Announcements that originate from identifiable printed matter should be footnoted to indicate their source.

4. Like revenue rulings (and unlike news releases), announcements speak from the perspective of the Service (that is, in the first person). Therefore, announcements should not contain language like "The IRS today announced" — this language speaks from the perspective of a third party.


2. Announcements have effective dates similar to revenue procedures. See Exhibit 32.2.3-9 for sample effective date provisions.


**32.2.3.5.4.2** **(08-11-2004)**

##### Paperwork Reduction Act

1. _See_ CCDM 32.2.3.5.2.1.8.


**32.2.3.5.4.3** **(08-11-2004)**

##### Public Comments

1. _See_ CCDM 32.2.3.5.1.2.8.


**32.2.3.5.5** **(08-11-2004)**

#### News Releases

1. Unlike other publications, news releases speak from the perspective of a third party. News releases are used to:



   - Announce hearings

   - Solicit comments

   - Inform the public of a change in procedures

   - Inform the public of a change in address


2. News releases are nontechnical publications targeted at the nonpractitioner taxpayer public. Technical discussions must be kept to a minimum and material such as Internal Revenue Code section numbers should be avoided if possible and, when used, relegated to the end of the release.

3. The components for a news release are shown in Exhibit 32.2.3-7. A news release does not contain a paragraph relating to drafting information.


**Exhibit 32.2.3-1**

### Explanation of the Parts of the Internal Revenue Bulletin

A. The Bulletin is divided into four parts as follows:

| **Part I.- 1986 Code** |
| --- |
|  | This part includes rulings and decisions based on provisions of the Internal Revenue Code of 1986. |
| **Part II.- Treaties and Tax Legislation** |
|  | This part is divided into two subparts as follows:<br> Subpart A, Tax Conventions and Other Related Items, and<br> Subpart B, Legislation and Related Committee Reports. |
| **Part Ill.- Administrative, Procedural, and Miscellaneous** |
|  | To the extent practicable, pertinent cross references to these subjects are contained in the other Parts and Subparts. Also included in this part are Bankruptcy Secrecy Act Administrative Rulings, which are issued by the department of the Treasury’s Office of the Assistant Secretary (Enforcement). |
| **Part IV.- Items of General Interest** |
|  | This part includes notices of proposed rulemaking, disbarment and suspension lists, and announcements. |

The first Bulletin for each month includes a cumulative index for the matters published during the preceding months. These monthly indexes are cumulated on a semi-annual basis, and are published in the first Bulletin of the succeeding semiannual period respectively.

B. The Bulletin Index-Digest System (BIDS), a research and reference service supplementing the Bulletin, consists of four services: Service No. 1, Income Tax; Service No. 2, Estate and Gift Tax; Service No. 3, Employment Taxes; and Service No. 4, Excise Taxes. Each service consists of a basic volume and a cumulative supplement that provides (1) finding lists of items published in the Bulletin, (2) digests of revenue rulings, revenue procedures, and other published items, and (3) indexes of Public Laws, Treasury Decisions, and tax Conventions.

### Caution:

Although the BIDS is an excellent starting point for researching historical publications, it is no longer published by the IRS. Therefore, publications and the referenced materials since approximately 1994 will not be included.

**Exhibit 32.2.3-2**

### Format for Typed Draft of Proposed Revenue Ruling Under the Code

![This is an Image: 29175001.gif](https://www.irs.gov/pub/xml_bc/29175001.gif)

> This is page 1 of the format demonstrating the typed draft of a proposed revenue ruling under the Code. It shows the size and number of margins, spaces, and blank lines required.

[Please click here for the text description of the image.](https://www.irs.gov/media/157571 "")

![This is an Image: 29175002.gif](https://www.irs.gov/pub/xml_bc/29175002.gif)

> This is page 2 of the format demonstrating the typed draft of a proposed revenue ruling under the Code. It shows the size and number of margins and indents required. It also indicates the wording and capitalization of required headings.

[Please click here for the text description of the image.](https://www.irs.gov/media/157576 "")

**Margins:**

First page:

- Top margin = 1 inch from top of page to Draft Date line

- Bottom margin = at least 1.5 inches to bottom margin of first page (not required for other pages)

- Left and Right Margins = 1 inch each


Subsequent pages:

- Top margin = 1 inch from top of page to the page number

- Bottom margin = 1 inch to bottom of page

- Left and Right Margins = 1 inch each


**Spacing:**

- 2 lines between Draft Date and Part II line

- 2 lines between Part II line and Tax Convention line

- 3 lines between Tax Convention line and T.D. line

- 10 lines between end of T.D. line and Rev. Rul. line

- 3 lines between Rev. Rul. section and ISSUE line

- 2 lines between end line of ISSUE text

- 2 lines between end line of ISSUES text and FACTS line

- 2 lines between end of FACTS text and LAW and ANALYSIS line

- Remainder of lines should be double-spaced

- 2 spaces between Draft Date: and the date

- 2 spaces between CASE-MIS No.: and RR number

- 5 spaces indent to start of text under ISSUE

- 5 spaces indent on subsequent text paragraph


**Exhibit 32.2.3-3**

### Format for Typed Draft of Proposed Revenue Ruling Under Tax Convention

![This is an Image: 29175004.gif](https://www.irs.gov/pub/xml_bc/29175004.gif)

> This is page 1 of the format demonstrating the typed draft of a proposed revenue ruling under tax convention. It shows the size and number of margins, spaces, and blank lines required.

[Please click here for the text description of the image.](https://www.irs.gov/media/157581 "")

![This is an Image: 29175005.gif](https://www.irs.gov/pub/xml_bc/29175005.gif)

> This is page 2 of the format demonstrating the typed draft of a proposed revenue ruling under tax convention. It shows the size and number of margins and indents required. It also indicates the wording and capitalization of required headings.

[Please click here for the text description of the image.](https://www.irs.gov/media/157586 "")

**Margins:**

First page:

- Top margin = 1 inch from top of page to Draft Date line

- Bottom margin = at least 1.5 inches to bottom margin of first page (not required for other pages)

- Left and Right Margins = 1 inch each


Subsequent pages:

- Top margin = 1 inch from top of page to the page number

- Bottom margin = 1 inch to bottom of page

- Left and Right Margins = 1 inch each


**Spacing:**

- 2 lines between Draft Date and Part II line

- 2 lines between Part II line and Tax Convention line

- 3 lines between Tax Convention line and T.D. line

- 10 lines between end of T.D. line and Rev. Rul. line

- 3 lines between Rev. Rul. section and ISSUE line

- 2 lines between end line of ISSUE text

- 2 lines between end line of ISSUES text and FACTS line

- 2 lines between end of FACTS text and LAW and ANALYSIS line

- Remainder of lines should be double-spaced

- 2 spaces between Draft Date: and the date

- 2 spaces between CASE-MIS No.: and RR number

- 5 spaces indent to start of text under ISSUE

- 5 spaces indent on subsequent text paragraph


**Exhibit 32.2.3-4**

### Format for Typed Draft of Proposed Revenue Procedure

![This is an Image: 29175007.gif](https://www.irs.gov/pub/xml_bc/29175007.gif)

> This is page 1 of the format demonstrating the typed draft of a proposed revenue procedure. It shows the size and number of margins, spaces, and blank lines required.

[Please click here for the text description of the image.](https://www.irs.gov/media/157591 "")

![This is an Image: 29175008.gif](https://www.irs.gov/pub/xml_bc/29175008.gif)

> This is page 2 of the format demonstrating the typed draft of a proposed revenue procedure. It shows the size and number of margins and indents required. It also indicates the wording and capitalization of required headings and standard text.

[Please click here for the text description of the image.](https://www.irs.gov/media/157596 "")

![This is an Image: 29175009.gif](https://www.irs.gov/pub/xml_bc/29175009.gif)

> This is page 3 of the format demonstrating the typed draft of a proposed revenue procedure. It shows the size and number of margins and indents required. It also indicates the wording and capitalization of required headings and standard text.

[Please click here for the text description of the image.](https://www.irs.gov/media/157601 "")

**Margins:**

First page:

- Top margin = 1 inch from top of page to Draft Date line

- Bottom margin = at least 1.5 inches to bottom margin of first page (not required for other pages)

- Left and Right Margins = 1 inch each


Subsequent pages:

- Top margin = 1 inch from top of page to the page number

- Bottom margin = 1 inch to bottom of page

- Left and Right Margins = 1 inch each


**Spacing:**

- 2 lines between Draft Date and Part III line

- 2 lines between Part III line and Administrative, ... line

- 3 lines between Administrative, ... line and CFR line

- 10 lines between end CFR text and Rev. Proc. line

- 3 lines between Rev. Proc. line and PURPOSE line

- 2 lines between PURPOSE line and text

- 2 lines between end of PURPOSE text and BACKGROUND line

- 2 lines between end of BACKGROUND line and text

- Remainder of lines should be double-spaced

- 2 spaces between Draft Date: and the date

- 2 spaces between CASE-MIS No.: and RP number

- 2 spaces between CFR cite: and beginning of title

- 1 space between Section and HEADING

- 5 spaces indent to start of text under PURPOSE

- 3 additional spaces indent for subsequent subsections


:

**Exhibit 32.2.3-5**

### Format for Typed Draft of Proposed Notice

![This is an Image: 29175011.gif](https://www.irs.gov/pub/xml_bc/29175011.gif)

> This is page 1 of the format demonstrating the typed draft of a proposed notice. It shows the size and number of margins, spaces, and blank lines required.

[Please click here for the text description of the image.](https://www.irs.gov/media/157606 "")

![This is an Image: 29175012.gif](https://www.irs.gov/pub/xml_bc/29175012.gif)

> This is page 2 of the format demonstrating the typed draft of a proposed notice. It shows the size and number of margins and indents required. It also indicates the wording and capitalization of required headings and standard text.

[Please click here for the text description of the image.](https://www.irs.gov/media/157611 "")

**Margins:**

First page:

- Top margin = 1 inch from top of page to Draft Date line

- Bottom margin = at least 1.5 inches to bottom margin of first page (not required for other pages)

- Left and Right Margins = 1 inch each


Subsequent pages:

- Top margin = 1 inch from top of page to the page number

- Bottom margin = 1 inch to bottom of page

- Left and Right Margins = 1 inch each


**Spacing:**

- 4 lines between Draft Date and Part III line

- 4 lines between Part III line and title (Brief Description) line

- 4 lines between Brief Description line and Notice line

- 2 lines between Notice line and PURPOSE line

- Remainder of lines should be double-spaced

- 2 spaces between Draft Date: and the date

- 2 spaces between CASE-MIS No.: and NOT No.

- 5 spaces indent to start of each paragraph of text


**Exhibit 32.2.3-6**

### Format for Typed Draft of Proposed Announcement

![This is an Image: 29175014.gif](https://www.irs.gov/pub/xml_bc/29175014.gif)

> This is page 1 of the format demonstrating the typed draft of a proposed announcement. It shows the size and number of margins, spaces, and blank lines required.

[Please click here for the text description of the image.](https://www.irs.gov/media/157616 "")

**Margins:**

First page:

- Top margin = 1 inch from top of page to Draft Date line

- Bottom margin = at least 1.5 inches to bottom margin of first page (not required for other pages)

- Left and Right Margins = 1 inch each


Subsequent pages:

- Top margin = 1 inch from top of page to the page number

- Bottom margin = 1 inch to bottom of page

- Left and Right Margins = 1 inch each


**Spacing:**

- 4 lines between Draft Date and Part IV line

- 4 lines between Part IV line and Summary Announcement line

- 4 lines between Summary Announcement line and Announcement line

- 2 lines between Announcement line and text (or heading if appropriate)

- The remainder of the lines should be double-spaced

- 2 spaces between Draft Date: and the date

- 2 spaces between CASE-MIS No.: and NOT No.

- 5 spaces to start of end of paragraph of text


**Exhibit 32.2.3-7**

### Format for Typed Draft of Proposed News Release

![This is an Image: 29175016.gif](https://www.irs.gov/pub/xml_bc/29175016.gif)

> This is page 1 of the format demonstrating the typed draft of a proposed news release. It shows the size and number of margins, spaces, blank lines and centered letters required.

[Please click here for the text description of the image.](https://www.irs.gov/media/157621 "")

**Margins:**

- Top margin = 1 inch from top of page to Draft Date line

- Left and Right Margins = 1 inch each


**Spacing:**

- 4 lines between Draft Date and DRAFT NEWS RELEASE line

- 4 lines between last line of text and "X X X"


**Other Instructions:**

1. Plain bond should be used for the first and succeeding pages. The last page should end with "X X X" centered four lines below the last line of text.

2. Do not date news releases.

3. The first paragraph of a release should begin with the dateline, indented, as follows: "Washington" (or other location as appropriate) with text immediately following.

4. Release is double-spaced with approximately 22 lines per page.


**Exhibit 32.2.3-8**

### Format for Typed Draft Cross-Reference Sheet

![This is an Image: 29175018.gif](https://www.irs.gov/pub/xml_bc/29175018.gif)

> This is page 1 of the format demonstrating the typed draft of a cross-reference sheet. It shows the size and number of margins, spaces, and blank lines required.

[Please click here for the text description of the image.](https://www.irs.gov/media/157626 "")

**Margins and spacing convention**

- Top, left, and right margins are 1 inch

- 3 lines between Section line and CFR line

- 3 lines between CFR line and the text

- 5 spaces indent from left margin to beginning of text

- Text is double-spaced

- At least 7 spaces between Rev. Rul. and page


**Exhibit 32.2.3-9**

### Sample Effective Date Provisions

| **Sample Effective Date Provisions** |
| :-: |
| **A. Revenue Rulings** |
|  | 1\. _With respect to a tax convention_ (from Rev. Rul. 2002-16, 2002-15 l.R.B. 740): |
|  |  | This revenue ruling is effective with respect to taxable years beginning on or after January 1, 2001. This revenue ruling will cease to be effective if the Netherlands Individual Income Tax Act of 2001 is modified in any material respect for tax years that are affected by such change. Taxpayers are responsible for determining whether any such modifications have occurred. |
|  | 2\. _From a date certain_ (from Rev. Rul. 96-7, 1996-1 C.B. 59): |
|  |  | This revenue ruling is effective for plan years beginning after December 31, 1995. |
|  | 3\. _From a date certain with exceptions_ (from Rev. Rul. 2002-55, 2002-37 I.R.B. 1): |
|  |  | This revenue ruling is effective for taxable years beginning after December 31, 2002. However, taxpayers may rely on this revenue ruling for prior periods. |
|  | 4\. _From a specified event_ (from Rev. Rul. 2002-35, 2002-23 I.R.B. 1067): |
|  |  | This revenue ruling is effective for payments to employees after October 13,1988 (the date of enactment for § 62(c), as part of the Family Support Act of 1988). |
|  | 5\. _With prospective application_ (from Rev. Rul. 99-40, 1999-2 C.B. 441): |
|  |  | Pursuant to § 7805(b), this ruling will not be applied adversely to a taxpayer that designated an overpayment to apply to an installment of estimated tax in accordance with Rev. Rul. 84-58 prior to October 4, 1999. |
| **B. Revenue Procedures** |
|  | 1\. _Stated in terms of a specific date_ (from Rev. Proc. 98-39, 1998-1 C.B. 1320): |
|  |  | This revenue procedure is effective on August 18, 1997. |
|  | 2\. _Stated in terms of taxable years beginning before the date of publication_ (from Rev. Proc. 2001-9, 2001-1 C.B. 328): |
|  |  | This revenue procedure is effective for taxable years commencing after December 31, 1999. |
|  | 3\. _Stated in terms of events occurring after the beginning of the current calendar year_ (from Rev. Proc. 79-26, 1979-1 C.B. 566): |
|  |  | The revisions set forth in this revenue procedure are effective for property first placed in service in taxable years beginning after December 31, 1978. |
|  | 4\. _Stated in terms of requests submitted after the beginning of the calendar year_ (from Rev. Proc. 79-4, 1979-1 C.B. 483): |
|  |  | This revenue procedure is effective for all requests submitted after December 31, 1978. |
|  | 5\. _Until a date specified in future guidance_ (from Rev. Proc. 2002-12, 2001-3 I.R.B. 335): |
|  |  | This revenue procedure applies to all transfers of noneconomic residual interests in REMICs and all transfers of FASIT ownership interests occurring on or after February 4, 2000, until the date specified in future published guidance. |
|  | 6\. _For a limited audience_ (from Rev. Proc. 99-43, 1999-2 C.B. 579): |
|  |  | This revenue procedure is effective for taxpayer requests made for the application of the net interest rate of zero in § 6621(d) to interest accruing before October 1, 1998. |
|  | 7\. _Stated in terms of a general effective date, transition rules, and special rules_ (from Rev. Proc. 2002-9, 2002-3 l.R.B. 1): |
|  |  | a) In general. Except as provided in sections 13.02 and 13.03 of this revenue procedure, this revenue procedure is effective for taxable years ending on or after December 31, 2001. The Service will return any application that is filed on or after December 31, 2001, if.... |
|  |  | b) Transition rules. If a taxpayer filed an application or ruling request with the national office to make a change in method of accounting described in the APPENDIX of this revenue procedure for a year of change for which this revenue procedure is effective (see section 13.01 of this revenue procedure), and the application or ruling request is pending with the national office on December 31, 2001, the taxpayer may make the change under this revenue procedure. However, ... |
|  |  | c) Special rules. ... |
| **C. Notices** |
|  | 1. _For events occurring after a certain date_ (from Notice 2000-38, 2000-2 C.B. 174): |
|  |  | This notice is applicable with respect to deferrals and distributions made after December 31, 2001. Plan sponsors, plan administrators, and taxpayers may rely on this notice for distributions and deferrals before January 1, 2002. |
|  | 2\. _As of a date certain_(from Notice 2001-62, 2001-2 C.B. 307): |
|  |  | This notice is effective on September 1, 2001. |
|  | 3\. _To apply to certain elections_ (from Notice 98-25, 1998-1 C.B. 979): |
|  |  | This notice applies to an election made for the first taxable year of a trust beginning after December 31, 1996. The provisions of this notice will be incorporated into regulations that will be effective for taxable years beginning after December 31, 1996. |
|  | 4\. _To alert taxpayers to the effect of a new regulations on existing revenue rulings and revenue procedures_ (from Notice 97-1, 1997-1 C.B. 348): |
|  |  | ... effective January 1, 1997, such revenue rulings and revenue procedures are obsolete to the extent that they use the prior classification regulations to differentiate between partnerships and associations. |
| **D. Announcements** |
|  | 1\. _For announcing test procedures for an arbitration program_ (from Announcement 2000-4, 2000-1 C.B. 317): |
|  |  | These procedures are effective for requests for arbitration made during the two-year test period beginning on January 18, 2000, the date this announcement is published in the Internal Revenue Bulletin. |
|  | 2\. _For announcing a change in an address previously provided in a revenue procedure_ (from Announcement 2001-22, 2001-1 C.B. 895): |
|  |  | The address has been changed, and the new address, effective immediately, is as follows... |
|  | 3\. _To announce a correction made in the Federal Register to final regulations_ (from Announcement 2001-40, 2001-1 C.B. 1141): |
|  |  | This correction is effective December 20, 2000. |

**Exhibit 32.2.3-10**

### Model Language for the Paperwork Reduction Act — Model 1

### Note:

The model below should be used for other publications by substituting the name of the guidance as appropriate.

|  |
| --- |
| _**Model 1** — For a revenue procedure for which approval is sought under 44 U.S.C. 3507(c)_<br> \[to be used when the revenue procedure is issued in proposed form\] |

SECTION \[ \]. PAPERWORK REDUCTION ACT

The collection**\[s\]** of information contained in this revenue procedure will be submitted to the Office of Management and Budget for review in accordance with the Paperwork Reduction Act (44 U.S.C. 3507(c)).

An agency may not conduct or sponsor, and a person is not required to respond to, a collection of information unless the collection of information displays a valid OMB control number.

The collections**\[s\]** of information in this revenue procedure **\[is/are\]** in section**\[s\]**. This information is required to **\[brief description of purpose of reporting/recordkeeping requirement\]**. This information will be used to **\[brief description of how the collected information will be used\]**. The collection**\[s\]** of information **\[is/are\]****\[voluntary/required to obtain a benefit/mandatory\]**. The likely respondents are **\[use one or more of the following: individuals, state or local governments, farms, business or other for-profit institutions, nonprofit institutions, and small businesses or organizations\]**.

The estimated total annual reporting and/or recordkeeping burden is **\[enter hours\]**.

The estimated annual burden per respondent/recordkeeper varies from **\[enter hours\]** to **\[enter hours\]**, depending on individual circumstances, with an estimated average of **\[enter hours\]**. The estimated number of respondents and/or recordkeepers is **\[enter number\]**.

The estimated annual frequency of responses (used for reporting requirements only) is **\[enter frequency\]**.

Books or records relating to a collection of information must be retained as long as their contents may become material in the administration of any internal revenue law. Generally, tax returns and tax return information are confidential, as required by 26 U.S.C. 6103.

**Exhibit 32.2.3-11**

### Model Language for the Paperwork Reduction Act — Model 2

### Note:

The model below should be used for other publications by substituting the name of the guidance as appropriate.

|  |
| --- |
| _**Model 2** — For a revenue procedure that is not issued in proposed form and for a final revenue procedure that was issued in proposed form_ |

SECTION \[ \]. PAPERWORK REDUCTION ACT

The collection\[s\] of information contained in this revenue procedure **\[has/have\]** been reviewed and approved by the Office of Management and Budget in accordance with the paperwork Reduction Act (44 U.S.C. 3507) under control number 1545–.

An agency may not conduct or sponsor, and a person is not required to respond to, a collection of information unless the collection of information displays a valid OMB control number.

The collections**\[s\]** of information in this revenue procedure **\[is/are\]** in section**\[s\]** \[insert sections\]. This information is required to **\[brief description of purpose of reporting/recordkeeping requirement\]**. This information will be used to **\[brief description of how the collected information will be used\]**. The collection**\[s\]** of information **\[is/are\]****\[voluntary/required to obtain a benefit/mandatory\]**. The likely respondents are **\[use one or more of the following: individuals, state or local governments, farms, business or other for-profit institutions, nonprofit institutions, and small businesses or organizations\]**.

The estimated total annual reporting and/or recordkeeping burden is **\[enter hours\]**.

The estimated annual burden per respondent/recordkeeper varies from **\[enter hours\]** to **\[enter hours\]**, depending on individual circumstances, with an estimated average of **\[enter hours\]**. The estimated number of respondents and/or recordkeepers is **\[enter number\]**.

The estimated annual frequency of responses (used for reporting requirements only) is **\[enter frequency\]**.

Books or records relating to a collection of information must be retained as long as their contents may become material in the administration of any internal revenue law. Generally, tax returns and tax return information are confidential, as required by 26 U.S.C. 6103.

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part32/irm_32-002-003#addtoany "Show all")

A2A