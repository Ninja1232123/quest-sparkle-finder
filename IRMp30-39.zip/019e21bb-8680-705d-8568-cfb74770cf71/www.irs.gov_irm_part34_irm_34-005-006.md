---
url: "https://www.irs.gov/irm/part34/irm_34-005-006"
title: "34.5.6 Procedures in 28 U.S.C. § 2410 Actions | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part34/irm_34-005-006#main-content)

- 34.5.6  [Procedures in 28 U.S.C. § 2410 Actions](https://www.irs.gov/irm/part34/irm_34-005-006#idm140316014819744)
  - 34.5.6.1  [Suit Filed and United States Named](https://www.irs.gov/irm/part34/irm_34-005-006#idm140316041968032)
  - 34.5.6.2  [Field Counsel Responsibilities in Cases Under 28 U.S.C. § 2410](https://www.irs.gov/irm/part34/irm_34-005-006#idm140316006108240)
  - 34.5.6.3  [Purchase of Property by the United States](https://www.irs.gov/irm/part34/irm_34-005-006#idm140316006098896)
  - 34.5.6.4  [Application for Discharge of Lien During Proceeding](https://www.irs.gov/irm/part34/irm_34-005-006#idm140316006097344)
  - 34.5.6.5  [The United States’ Right of Redemption](https://www.irs.gov/irm/part34/irm_34-005-006#idm140316041962208)
    - 34.5.6.5.1  [Release of Right of Redemption](https://www.irs.gov/irm/part34/irm_34-005-006#idm140316041955808)
  - 34.5.6.6  [Removal to Federal Court](https://www.irs.gov/irm/part34/irm_34-005-006#idm140316041948784)
  - 34.5.6.7  [Specific Requirements of Defense Letter in Interpleader Suits](https://www.irs.gov/irm/part34/irm_34-005-006#idm140316006169264)
    - 34.5.6.7.1  [Specific Procedures for Handling Interpleader Suits](https://www.irs.gov/irm/part34/irm_34-005-006#idm140316006165536)
      - 34.5.6.7.1.1  [Interpleader Suits in Response to Administrative Levies](https://www.irs.gov/irm/part34/irm_34-005-006#idm140316006157152)
  - 34.5.6.8  [Disclaimers](https://www.irs.gov/irm/part34/irm_34-005-006#idm140316041946384)

# Part 34. Chief Counsel Directives Manual Litigation in District Court, Bankruptcy Court, Court of Federal Claims, and State Court

# Chapter 5. Suits Brought Against the United States

# Section 6. Procedures in 28 U.S.C. 2410 Actions

* * *

## 34.5.6 Procedures in 28 U.S.C. § 2410 Actions

#### Manual Transmittal

August 03, 2023

#### Purpose

(1) This transmits revised CCDM Part 34.5.6, Suits Brought Against the United States - Procedures in 28 U.S.C. § 2410 Actions.

#### Background

28 U.S.C. section 2410 allows a complaint to name the United States as a party in a civil action or suit in any district court, or in any State court having jurisdiction of the subject matter to, _inter alia_, quiet title to or foreclose a lien on real or personal property in which the government has a federal tax lien.

#### Material Changes

(1) CCDM 34.5.6 is revised to address direct counterclaim referral authority in section 2410 and other lien enforcement actions.

#### Effect on Other Documents

This section supersedes 34.5.6.1 dated 02-12-2013 and 34.5.6.2 dated 08-11-2004.

#### Audience

Chief Counsel

#### Effective Date

(08-03-2023)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**34.5.6.1** **(08-03-2023)**

### Suit Filed and United States Named

1. For a discussion of the types of actions against the United States authorized under 28 U.S.C. § 2410, see CCDM 34.1.1.8, Interpleader/Quiet Title/Foreclosure or Other Actions Involving Property in Which IRS May Claim an Interest.

2. Title 28 U.S.C. § 2410(b) sets forth the matters required to be alleged in a complaint, the procedures for the service of process on the United States, and the time available to file an answer or other pleading.

3. Except in interpleader suits, or those quiet title suits involving special condition Notices of Federal Tax Lien (nominee, alter ego, transferee, or successor in interest), the U.S. Attorney should forward a copy of the complaint to, and contact the Territory Manager, Technical Services and request information concerning the assessment, the property involved, and the claims of all lien holders.



1. This information is necessary in order that an answer or other pleading may be filed within 60 days after service or other further time as the court may allow.

2. The answer contains any defense or position that the Government might have in the case and may request the court to take affirmative measures to foreclose the tax lien.

3. A copy of the Territory Manager, Technical Services’ reply to the U.S. Attorney, together with copies of all furnished data, may be sent to Field Counsel for purposes of review in cases involving disputed issues, so counsel can advise the U.S. Attorney of the Service’s litigating position on the issues involved.

4. In cases in which the records of the IRS disclose no outstanding tax lien, the United States will file a disclaimer on behalf of the United States.


**34.5.6.2** **(08-03-2023)**

### Field Counsel Responsibilities in Cases Under 28 U.S.C. § 2410

1. The statute permits the United States to be joined as a party defendant in state or federal courts having jurisdiction of the subject matter. Most section 2410 cases are handled by Assistant U.S. Attorneys, but the Tax Division handles all interpleader suits and those quiet title suits that involve nominee, alter ego, transferee, or successor in interest issues. Field Counsel will open a case only for cases referred to the Tax Division, or in other cases where:



1. The Tax Division or the U.S. Attorney requests advice concerning a settlement proposal

2. Tax Division or the U.S. Attorney requests assistance in connection with the trial of a case

3. It becomes necessary to consider whether real property sold should be redeemed on behalf of the United States

4. A monetary offer is made in consideration of the release of the Government’s right of redemption

5. Tax Division or the U.S. Attorney recommends that a counterclaim be authorized to enforce the tax lien or if a counterclaim may enhance collection or be necessary to prevent the expiration of the CSED during the suit. _See_ CCDM 34.6.2.2(6)(b) (independent authority for Counsel to refer counterclaims). If the U.S. Attorney recommends a counterclaim, it is necessary to coordinate with the Tax Division.


2. The U.S. Attorney may, depending on local procedures, send copies of the summons and complaint to Field Counsel and request assistance. The Tax Division may also request assistance in some cases.

3. The complaint should be examined to determine whether the case is a proper 2410 action. If the action does not come within section 2410, the Tax Division or U.S. Attorney should be notified together with an explanation as to the appropriate action that should be taken.

4. The U.S. Attorney’s office should be advised as to the position of the Service. If additional information is necessary, the Area Director should furnish it directly to the U.S. Attorney with copies to Field Counsel.

5. Expedited consideration of whether to authorize counterclaims is required to enable the Department of Justice to remove the case from state to federal court within the 30-day removal period. There is no requirement that Collection provide a Form 4477, Civil Suit Recommendation, or other authorization for counterclaims, although such authorization may be sought in individual cases. _See_ IRM 25.3.1.4(5).


**34.5.6.3** **(02-12-2013)**

### Purchase of Property by the United States

1. If a debt owing the United States is due, and a federal tax lien is involved, the United States may ask by way of affirmative relief for a foreclosure of its own lien. If it is a first lien, the Government may bid at the sale in an amount equal to its claim plus the expense of sale. For delegation of authority to bid on property in IRC § 7403 sales, see CCDM 34.6.1.2.3, Appointment of Agent to Bid at Execution Sale.


**34.5.6.4** **(08-11-2004)**

### Application for Discharge of Lien During Proceeding

1. During the pendency of a proceeding to which the United States has been joined as a party, any application for administrative discharge of property from the federal tax lien must be submitted to Field Counsel who will determine whether it will be necessary to obtain the views of DOJ concerning the application.


**34.5.6.5** **(02-12-2013)**

### The United States’ Right of Redemption

1. While the sale of property under 28 U.S.C. § 2410 has the effect of discharging the property from the federal tax lien, the Government’s rights do not end. In many cases the property will be sold for an amount more than sufficient to satisfy the mortgage or other liens that are prior to those of the United States. In such cases, action is taken to obtain the surplus proceeds for application to the taxpayer’s account.

2. This still does not terminate the Government’s rights. Section 2410(c) provides that the United States shall have one year from the date of sale within which to redeem, except that with respect to a lien arising under the internal revenue laws, the redemption period shall be 120 days, or the period allowable for redemption under state law, whichever is longer. This gives the Service time to investigate and determine whether it would be to the advantage of the United States to redeem the property so that it might be resold for more than the cost of redemption with the resulting benefit to the Government. A principal determination in such an investigation is whether the value of the property sold in the foreclosure proceeding is substantially in excess of the amount required to effect the redemption.

3. Section 2410(d) provides a uniform method for determining the amount to be paid by the United States when it redeems real property, whether the redemption is made under the authority of section 2410(c) or IRC § 7425(d)(1) (relating to real property sold at nonjudicial sales).

4. IRC § 7810 establishes a revolving fund of $10,000,000 under the control of the Treasury Department that is available without fiscal year limitation for all expenses necessary for the redemption of real property as provided in IRC § 7425(d) and 28 U.S.C. § 2410.


**34.5.6.5.1** **(02-12-2013)**

#### Release of Right of Redemption

1. Even if the Government does not exercise its right to redeem, the right nevertheless clouds the title to the property for 120 days or, longer depending on the period allowable for redemption under applicable State law. For this reason, there are many cases in which the Government is requested to release its redemption right.

2. Any person who desires to apply for a release of the Government’s right of redemption should submit an application to the U.S. Attorney in the jurisdiction where the foreclosure action was held.

3. Upon receipt, the U.S. Attorney will forward the application directly to the Area Director for investigation and a recommendation as to whether the release should be granted and, if so, the amount that should be demanded for the release. The investigation will usually require a determination of the fair market value of the property, the amount of the prior encumbrances, the amount required to redeem, etc. Upon completion of the investigation, the Area Director transmits the recommendation to the U.S. Attorney or the Tax Division. The Director is not required to notify the Field Counsel of his determination before transmitting the recommendation to the U.S. Attorney. _See_ Tax Division Directive No. 83. Appendix to Subpart Y, 28 C.F.R. Part O.

4. In cases in which the U.S. Attorney has not been delegated authority to release the right of redemption on behalf of the United States, the original application and all accompanying documents are sent directly to the Tax Division. The application and the accompanying appraisals will be referred to the Area Director for verification, determination as to the qualification of the appraisers, and for a Revenue Officer’s report. Advice can be requested from Field Counsel who will open a file. After this has been accomplished, a separate letter of recommendation should be sent directly to Tax Division.

5. In the case of applications for release of redemption made by the Veterans Administration or any other federal agency, see IRM 5.12.5.8.2, Referral of Applications.

6. DOJ generally will not release a right of redemption, even if the right is apparently valueless, without some consideration.


**34.5.6.6** **(08-11-2004)**

### Removal to Federal Court

1. Many of the 28 U.S.C. § 2410 cases and other cases in which the United States is named a party are brought in state courts. In general Field Counsel should recommend to DOJ to have the case removed to a federal district court. Consult 28 U.S.C. §§ 1441-1446 for the rules governing removal of a case to federal district court.


**34.5.6.7** **(04-22-2021)**

### Specific Requirements of Defense Letter in Interpleader Suits

1. See CCDM 34.5.1.1, General Procedures for Defense Letters, for requirements of defense letters. The letter to DOJ in these cases is a defense letter signed for Chief Counsel by the Field Counsel.

2. Field Counsel must consider whether there has been proper service, and whether the particularity requirements of 28 U.S.C. § 2410 have been met.

3. The question of removal should always be discussed when the case is in a state court. The case should be immediately referred to DOJ to allow sufficient time to consider and, when appropriate, effectuate removal. This referral should be made at least 10 days prior to the 30-day deadline to remove provided in 28 U.S.C § 1446.

4. If the interpleader suit is brought in response to an administrative levy, see the additional instructions in _CCDM 34.5.6.7.1.1_, Interpleader Suits in Response to Administrative Levies.


**34.5.6.7.1** **(08-11-2004)**

#### Specific Procedures for Handling Interpleader Suits

1. Following receipt of a copy of a complaint involving an interpleader action, Field Counsel should immediately request that the Area Director’s office investigate all the claims of all competing claimants.

2. The information requested should be specific and include tax data as well as claimant information. The request should also set a deadline by which the information is needed. The same applies to requests of the Service Center.

3. Periodically request status reports from the Area Director regarding progress of the investigation. It is the responsibility of Field Counsel to be specific in requesting information and to periodically follow-up on the request.

4. When time is a factor, Field Counsel attorneys, to the extent practical, should make their own investigation of competing claimants including the following:



1. Since most responsive pleadings are required to be filed within 20 days of service (except for the United States) Field Counsel could obtain data on competing claimants by checking court records after the 20th day.

2. Field Counsel may contact the plaintiff-interpleader and determine if she has any additional information regarding the claimants and where she obtained the information.

3. Field Counsel can make direct contact with the competing claimants and ascertain the basis and amount of their claims.

4. Field Counsel should check with the revenue officer who may have personal knowledge of the claims of certain creditors.

5. If Field Counsel is aware of a suit in which the United States is named a party, do not wait until formal notification by DOJ before initiating request for data and investigation of claimants. Even though service has not been perfected, it is important that Counsel advise DOJ in the matter.


5. If Field Counsel cannot provide full information to DOJ in time, the Tax Division will use the information furnished and file a general denial as necessary.

6. The Tax Division will immediately advise Field Counsel if parties joined by the interpleading plaintiff either fail to file an answer or file a disclaimer. If answers have been filed by other defendants, the Tax Division will furnish Field Counsel with copies of the answers so that an investigative check can be made of the allegations.


**34.5.6.7.1.1** **(04-22-2021)**

##### Interpleader Suits in Response to Administrative Levies

1. In some cases, persons served with notices of levy commence interpleader suits instead of complying with the levies. Frequently, the only claimants to the property are the taxpayer and the Service.

2. Interpleader actions are not appropriate when the interpleader-plaintiff claims no interest in the property and the only interpleader defendant is the Government. The taxpayer and the Government do not have adverse claims to the property subject to the levy. This is because after the Service places a levy on the property, it acquires whatever rights the taxpayer possesses. Thus, the Government steps into the shoes of the taxpayer.

3. Additionally, the interpleader action is also inappropriate because the person bringing the interpleader action is not exposed to multiple liability. Under section 6332(e), a person who honors a levy is discharged from any liability to the taxpayer or third parties with respect to such property. Therefore, the person is not liable to the taxpayer if the person complies with the levy.

4. In the defense letter, Field Counsel should include the following in interpleader cases involving administrative levies.



1. If the case was initiated in state court, the case should be immediately referred to DOJ, and Field Counsel should recommend that the case be removed to federal district court under 28 U.S.C. § 1444 (if notice of removal may be timely filed). _See_ _CCDM 34.5.6.6_, Removal to Federal Court. This referral should be made at least 10 days prior to the 30-day deadline to remove provided in 28 U.S.C § 1446, so that DOJ has sufficient time to consider and, when appropriate, to effectuate removal.

2. Field Counsel should also recommend that DOJ file a motion to dismiss unless it is unclear the levy is effective to reach the property. The motion should argue that interpleader is inappropriate for the reasons explained in paragraphs (2) and (3), above:


       the taxpayer and the Government do not have adverse claims to the property; and


       the interpleader-plaintiff is not subject to multiple liability.

3. The defense letter should recommend that DOJ file a counterclaim to enforce the levy against the interpleader-plaintiff and to seek costs and interest under section 6332(d).


**34.5.6.8** **(02-12-2013)**

### Disclaimers

1. When the taxpayer has no interest in the property — that is, the taxpayer never had any title, claims, etc., to the property — a disclaimer will be filed. This does not cover the situation in which the taxpayer has an interest in the property but there are claimants with a superior right to that of the United States. DOJ will file an answer and put the priority claimant to his/her proof. Examples of when DOJ will disclaim are:



1. Taxpayer is John E. Smith and the United States is named a party to a section 2410 proceeding involving John R. Smith.

2. Taxpayer is the beneficiary of a trust or shareholder in a corporation. The section 2410 action involves the property of the trust or the corporation.


2. In addition to situations in which the taxpayer never had any title, claims, etc., to the property, when the taxpayer has conveyed property before assessment — divesting the taxpayer of all interest in the property — and the conveyance was not recorded until after assessment, a disclaimer will be filed, despite applicable State law that provides specified creditors and other parties recourse against the property because the conveyance was unrecorded.

3. A disclaimer will also be filed:



1. When the tax liens against the particular property have previously been discharged under section 6325

2. When the amount involved is too small to justify litigation

3. To avoid jeopardizing the Government position in another case

4. When the tax is paid or otherwise satisfied


4. A disclaimer will not be filed if the taxpayer has an interest in, lien on, or claim to the property involved in the proceeding. The fact that there may be senior encumbrances exceeding the value of the property is not a basis for disclaimer. The senior lienor will be put to proof.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part34/irm_34-005-006#addtoany "Show all")

A2A