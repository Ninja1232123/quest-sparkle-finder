---
url: "https://www.irs.gov/irm/part35/irm_35-004-008"
title: "35.4.8 Preparing for Examination and Cross-Examination of Witnesses | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-004-008#main-content)

- 35.4.8 [Preparing for Examination and Cross-Examination of Witnesses](https://www.irs.gov/irm/part35/irm_35-004-008#idm140295823539424)
  - 35.4.8.1 [Identifying and Locating Witnesses](https://www.irs.gov/irm/part35/irm_35-004-008#idm140295815405328)
  - 35.4.8.2 [Interviewing Witnesses](https://www.irs.gov/irm/part35/irm_35-004-008#idm140295816284864)
  - 35.4.8.3 [Preparing Witnesses](https://www.irs.gov/irm/part35/irm_35-004-008#idm140295802145936)
  - 35.4.8.4 [Preparing for Petitioners Witness](https://www.irs.gov/irm/part35/irm_35-004-008#idm140295816122496)
  - 35.4.8.5 [Expert Witnesses](https://www.irs.gov/irm/part35/irm_35-004-008#idm140295806145904)

# Part 35. Tax Court Litigation

# Chapter 4. Pre-Trial Activities

# Section 8. Preparing for Examination and Cross-Examination of Witnesses

* * *

## 35.4.8 Preparing for Examination and Cross-Examination of Witnesses

**35.4.8.1** **(08-11-2004)**

### Identifying and Locating Witnesses

1. Where Service agents are proposed witnesses for respondent, the Field attorney should obviously talk to the agents about their role and review their testimony well in advance of trial. This refreshes their recollection of the facts of the case, helps assure composed and complete testimony and avoids surprises. Such preparation also gives the attorney an opportunity to better understand the theory and facts which the agents followed in making the determination. The attorney will be in a better position to develop additional necessary facts, to strengthen weaknesses in agent testimony or theories, and to suggest the points in their testimony on which they are likely to be cross-examined by petitioner’s counsel. For steps to take to obtain the assistance of Service agents _see_ CCDM 35.4.2.2.

2. Situations may arise where the Field attorney is considering listing or calling petitioner’s counsel as a witness. Before doing so, follow the coordination instructions of CCDM 35.4.1.8.1.3.


**35.4.8.2** **(08-11-2004)**

### Interviewing Witnesses

1. Prior to the interview of a prospective witness, the Field attorney should discuss with the agent the prior evidence submitted or statements made by the witness and the competency of the witness to testify on the matter in dispute. It is often useful to interview witnesses in the presence of the Service agent or third party who can testify to statements made by the witness during the interview should the witness change his story at trial.

2. Audio Recording of Conferences. The audio recording of taxpayer conferences is generally permitted for docketed and nondocketed cases if the taxpayer, or the taxpayer’s authorized representative, requests it and supplies the recording equipment. In such cases, the Service representative should also make an audio recording of the conference with Service equipment.



1. Section 7521 provides that taxpayers may make audio recordings of interviews with the Service that determine liability or collectibility. The Service has described its procedures for making such recordings in Notice 89–15, 1989–1 C.B. 691. Although it is unclear whether section 7521 applies to conferences between Field attorneys and petitioners, and while Notice 89–51 does not directly address such conferences, Field attorneys should generally follow the provisions of the Notice when a taxpayer elects to record a conference.

2. If the taxpayer does not give advance notice of an intention to record a conference, the attorney handling the conference has the option of conducting the conference, subject to the availability of Service recording equipment, as scheduled or setting a new date.


3. Procedures for Audio Recordings. At the outset of the conference, the attorney or other Service representative conducting the conference that is to be recorded should identify herself, the date, the time, the place, and the purpose of the proceeding. All participants, including the attorney or other Service representative, must personally identify themselves and consent to the making of an audio recording.



1. If an additional participant arrives or a person leaves, these facts must be noted on the tape.

2. When written records are presented or discussed during the proceeding, they must be described in sufficient detail to permit identification when compared to other documents in the case file.

3. If more than one tape is necessary to record the conference, each subsequent tape must be identified by giving the case name and date. When the conference or recording session is ended it should be so stated on the tape. All conference tapes should be marked and retained with the legal file.

4. Any payment or costs for copies of tapes given to taxpayers, as provided in Notice 89–51, should be processed according to the instructions provided in IRM 4245.


**35.4.8.3** **(08-11-2004)**

### Preparing Witnesses

1. It is essential that the Field attorney discuss with each witness, prior to trial, the oral and documentary evidence which is to be introduced through such witness. Preliminary discussions with prospective witnesses should be conducted prior to the issuance of subpoenas. The witness’ direct testimony should be thoroughly reviewed to ensure that the witness understands the questions, the role as a witness, and the potential cross-examination.

2. All of the necessary facts pertinent to establishing venue on appeal which have not been established in the petition, answer or stipulation should be established by oral evidence during the course of the trial.


**35.4.8.4** **(08-11-2004)**

### Preparing for Petitioner’s Witness

1. It is important to know the names of petitioner’s prospective witnesses as early as possible. The witnesses will be listed in petitioner’s pretrial memorandum where one is required to be submitted. However, even before the receipt of the pretrial memorandum, the Field attorney should ask petitioner’s counsel for the names of petitioner’s prospective witnesses, anticipating who they will be if the information is refused, and anticipating the scope of the testimony and potential evidentiary questions. If cross-examination is necessary, the theory of the cross-examination should be developed in advance of trial.

2. The Assistant Chief Counsel (APJP) is to be notified immediately where the taxpayer alleges respondent’s evidence was obtained illegally or petitioner files a motion in any Court to suppress or strike respondent’s evidence. Provide a complete statement of the circumstances of the allegation and the alleged basis for the motion. If the basis or circumstances for the motion to suppress are not immediately available, a copy of such motion should be forwarded and a complete report submitted as soon as possible thereafter.

3. If the taxpayer informally alleges respondent’s evidence was illegally obtained, the taxpayer should be requested to put his contentions in writing for the purpose of verifying their accuracy. A copy of such statement should be forwarded to APJP. No stipulation or any other agreement should be entered into with the taxpayer reciting whether or not any of the Government’s case is based upon illegally obtained evidence without prior approval by APJP. Specific contentions or allegations of the taxpayer should be investigated. Refer the matter to the appropriate Service field officials for verification and report. The results of the investigation should be submitted to APJP.

4. Pursuant to Tax Court Rule 143(a), evidence which is relevant only to the issue of a party’s entitlement to reasonable litigation or administrative costs shall not be introduced during the trial of the case, except for a case commenced under Title XXVI of the Tax Court Rules, relating to actions for administrative costs.


**35.4.8.5** **(08-11-2004)**

### Expert Witnesses

1. Perhaps no aspect of trial preparation is more important than locating and working effectively with expert witnesses. If an expert is employed on behalf of the respondent, or if it is known that the petitioner will employ an expert, it is absolutely essential that a thorough preparation be made for the direct testimony of the respondent’s expert and for the cross-examination of the petitioner’s expert. Without such preparation, the Field attorney may be in an intolerable position at the trial. To buttress the expert’s opinion, as many of the facts as possible supporting the opinion should be offered in evidence.

2. After employment, an expert witness is considered in the same status as a Service employee for the purpose of disclosing necessary matters in connection with testimony. The expert is subject to the same restrictions on disclosure as any other employee of the Service. Thus, the attorney may discuss with the employed expert confidential matters which are necessary for preparation as an expert witness. Prior to employment, the attorney may disclose only the information necessary to determine whether the potential witness can qualify as an expert with regard to the subject matter under consideration and whether the potential witness has a conflict of interest with respect to the taxpayer.

3. The expert should assist the Field attorney in the preparation of questions or subject matter to be covered on direct examination of the respondent’s expert and on cross-examination of the petitioner’s expert. While the attorney should not request the expert to prepare the proposed specific questions to be asked, an outline of the questions prepared by the expert would in some cases be beneficial to the attorney’s preparation of the specific questions. It is essential that the attorney obtain from the expert complete information as to the expert’s background, education, training, experience, previous Court appearances, etc., which will form the basis of qualifying the witness as an expert and which will give weight to the opinions expressed.

4. If the expert is to testify on the basis of a hypothetical question, care should be taken in drafting such hypothetical question to be sure that only those facts established in the record by stipulation, testimony, etc., as to which there can be no reasonable dispute should be incorporated in the question. Also, care should be exercised to ensure that no essential fact is omitted from the question.

5. For cases involving the valuation of physical properties, it is advisable, when feasible, for the Field attorney to examine such properties. This would be particularly applicable in real estate valuation cases. With a personal knowledge of the properties, the attorney is in a better position for examination of the witnesses who testify with respect thereto.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-004-008#addtoany "Show all")

A2A