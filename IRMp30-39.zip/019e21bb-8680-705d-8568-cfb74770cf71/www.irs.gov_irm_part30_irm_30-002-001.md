---
url: "https://www.irs.gov/irm/part30/irm_30-002-001"
title: "30.2.1 Office of Chief Counsel Directives System | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part30/irm_30-002-001#main-content)

- 30.2.1  [Office of Chief Counsel Directives System](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728236518048)
  - 30.2.1.1  [Introduction to the Directives System](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728209335696)
    - 30.2.1.1.1  [Objectives of the Directives System](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728236262384)
    - 30.2.1.1.2  [Directives System Responsibilities](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728236213584)
  - 30.2.1.2  [Distribution and Availability of Directives](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728208791200)
  - 30.2.1.3  [Preparation of Directives](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728236252688)
    - 30.2.1.3.1  [Approval Authority for Directives](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728236247408)
    - 30.2.1.3.2  [Revisions to Directives](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728207926032)
    - 30.2.1.3.3  [Writing Standards for Directives](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728207919520)
  - 30.2.1.4  [Chief Counsel Notices](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728208191408)
    - 30.2.1.4.1  [Preparing Notices](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728208180592)
    - 30.2.1.4.2  [Review and Clearance of CC Notices](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728236410896)
    - 30.2.1.4.3  [Final Review and Distribution of Notices](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728236498464)
    - 30.2.1.4.4  [Continuing Review of Active Notices](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728236491744)
  - 30.2.1.5  [The Chief Counsel Directives Manual (CCDM)](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728236487024)
    - 30.2.1.5.1  [Structure of the CCDM](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728236482752)
    - 30.2.1.5.2  [CCDM Preparation](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728236461072)
      - 30.2.1.5.2.1  [Manual Transmittal](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728208894928)
      - 30.2.1.5.2.2  [Text](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728209425680)
      - 30.2.1.5.2.3  [Lists, Notes, Tables, and Figures](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728209416688)
      - 30.2.1.5.2.4  [Exhibits and Forms](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728209396448)
    - 30.2.1.5.3  [Review and Clearance of CCDM Sections](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728208163200)
    - 30.2.1.5.4  [Editorial Update Process](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728208152496)
    - 30.2.1.5.5  [Final Review and Publication](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728208137808)
    - 30.2.1.5.6  [Continuing Review of Published CCDM Sections; Certification of Content](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728208122208)
    - 30.2.1.5.7  [Requesting CCDM Changes or Deviations](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728236373968)
  - Exhibit  30.2.1-1  [Notice Template](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728236368208)
  - Exhibit  30.2.1-2  [Form 178, Clearance Record](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728236365712)
  - Exhibit  30.2.1-3  [Model Language for CCDM Manual Transmittals](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728236362432)
  - Exhibit  30.2.1-4  [Preparation of Form 2061, Document Clearance Record](https://www.irs.gov/irm/part30/irm_30-002-001#idm139728236318016)

# Part 30. Chief Counsel Directives Manual Administrative

# Chapter 2. Chief Counsel Directives

# Section 1. Office of Chief Counsel Directives System

* * *

## 30.2.1 Office of Chief Counsel Directives System

#### Manual Transmittal

July 15, 2021

#### Purpose

(1) This transmits revised CCDM 30.2.1, Chief Counsel Directives, Office of Chief Counsel Directives System.

#### Material Changes

(1) Exhibit 30.2.1-4 was revised to provide updated instructions for the preparation of Form 2061, Document Clearance Record since the form’s revision.

(2) Planning and Finance Division name updated throughout the CCDM section.

#### Effect on Other Documents

CCDM 30.2.1 dated April 4, 2014 is superseded.

#### Audience

Chief Counsel

#### Effective Date

(07-15-2021)

Thomas Travers

Associate Chief Counsel (Finance and Management)

Finance and Management

**30.2.1.1** **(11-27-2006)**

### Introduction to the Directives System

1. The Office of Chief Counsel Directives System is the official compilation of policies, procedures, guidelines, and/or delegations of authority to employees relating to the organization, administration and operations of the Office of Chief Counsel. The directives system consists of the Chief Counsel Directives Manual (CCDM), Chief Counsel Notices (Notices), and other internal directives.

2. Communications that do one or more of the following should be formally published in the directives system as CCDM sections or Notices:



1. Establish policy, guidelines or procedures

2. Delegate authority or assigns responsibility on a permanent basis

3. Guide employees in determining a course of action

4. Establish or change an organizational structure

5. Supersede, supplement, amend, or revoke another directive


3. This section defines the directives system, identifies responsibilities, and provides guidelines for developing, revising, clearing and issuing the CCDM and Notices.



### Note:



Prior Chief Counsel directives systems included Orders. Orders will be issued under the current directives system only in exceptional circumstances.

4. The Planning and Finance Division (CC:FM:PFD) in the office of the Associate Chief Counsel (Finance and Management) is responsible for managing and coordinating the CCDM and Notices, and serves as the central point for publication. CC:FM:PFD may be contacted for assistance in developing and revising the CCDM and Notices.

5. For a discussion of the relationship between the CCDM and IRS policy, see CCDM 30.1.1.2 The Chief Counsel Directives Manual.


**30.2.1.1.1** **(04-04-2014)**

#### Objectives of the Directives System

1. The directives system ensures effective communication by:



1. Providing current, authoritative direction to employees

2. Providing instructions that are easily understood, readily accessible, and revisable

3. Grouping information on a specific subject in a single source


2. Offices have periodically issued guidelines and instructions establishing policies, delegating authority, etc., in a variety of formats or through web pages rather than publishing such information in the directives system. This practice is an ineffective and cumbersome way by which to issue important information. All information of the nature described in _CCDM 30.2.1.1(2)_ must be issued in the formal directives system.

3. All Chief Counsel directives that impact the entire Office of Chief Counsel should be included in the CCDM and/or issued as a Notice as appropriate. Exceptions are publications issued primarily to and for the public.

4. Publication of Chief Counsel guidelines and "instructions to staff" in the CCDM and Notices, which are available to the public on [www.irs.gov](https://www.irs.gov/ "Internal Revenue Service"), complies with the requirements of the Electronic Freedom of Information Act (E-FOIA).


**30.2.1.1.2** **(08-18-2006)**

#### Directives System Responsibilities

1. Officials are responsible for the information contained in the directives that they initiate and issue. It is critical that this information is accurate and up-to-date. Annual reviews of existing directives should be conducted to ensure they contain current policy and procedures.

2. The Planning and Finance Division (CC:FM:PFD) is responsible for:



1. Establishing directives system requirements and standards, and interpreting their application

2. Managing and coordinating directives activities

3. Providing technical leadership and assistance in the development, clearance, issuance and publication of directives

4. Reviewing each directive for compliance with directives requirements and standards

5. Establishing and maintaining historical files for Notices and the CCDM

6. Serving on the IRS Internal Management Document Oversight Council led by the Office of Servicewide Policy, Directives and Electronic Research (SPDER)


3. The Deputies Chief Counsel, Division Counsels, and Associates Chief Counsel are responsible for ensuring:



1. That their office/function complies with the directives system

2. That directives are issued to adequately document the organization, functions, policies, and procedures for which they are responsible, and that their directives do not conflict with other directives issued by the Office of Chief Counsel

3. That directives originated by their office/function conform to pertinent laws, Executive Orders, regulations, and Department of the Treasury policies

4. That directives originated by their office/function are regularly reviewed to determine the need for updating, consolidating, or revoking them


4. Division Counsels and Associates Chief Counsel may appoint a Directives Management Officer (DMO) who would coordinate all directives activities within their office/function after considering the volume and frequency of directives it expects to publish and the utility of concentrating the role in a single individual. CC:FM:PFD should be notified when a DMO is appointed. DMO responsibilities include:



1. Assisting authors in developing and clearing directives

2. Reviewing each directive for compliance with directives standards prior to submission to CC:FM:PFD

3. Reviewing directives issued by their office periodically to ensure that the content is current

4. Serving as a liaison with CC:FM:PFD and with other DMOs


5. The Labor and Employee Relations Division is responsible for:



1. Reviewing the content of proposed directives forwarded by the issuing function/author (or CC:FM:PFD) to determine whether the directive requires notification of, or negotiation with, NTEU

2. Coordinating with all appropriate offices to notify NTEU and negotiate any required issues

3. Coordinating with the appropriate originating offices if changes to the directive are needed


**30.2.1.2** **(04-04-2014)**

### Distribution and Availability of Directives

1. It is the policy of the Office of Chief Counsel to distribute directives electronically, rather than publishing them in traditional paper formats.

2. **Notices** are posted on the CC Notice webpage, on the Chief Counsel Home Page and on [www.irs.gov](https://www.irs.gov/ "Internal Revenue Service"). Notices will also be emailed to the list of employees specified on the clearance record. Historical files will be maintained by CC:FM:PFD until they are sent to the Federal Records Center.

3. **The CCDM** is published in the Internal Revenue Manual (IRM) Numerical Index maintained by the Media and Publications Division. The CCDM is also available through other sources:



   - CCDM Online

   - _www.irs.gov_, available within two weeks of publication

   - Commercial sources such as Westlaw and Lexis, available within one month


1. The Media and Publications Division and the Office of Chief Counsel agree that the CCDM would not be available in a printed format through the Internal Management Documents Distribution System (IMDDS). The only exceptions are the consolidated Litigation Exhibit sections: CCDM 34.12.1, CCDM 35.11.1 and CCDM 36.4.1. These exceptions will be periodically reviewed.

2. If a small number of paper copies of a CCDM section are needed, the PDF files on the Numerical Index should be printed directly to an office printer.

3. If a large number of paper copies of a CCDM section are needed on a one-time basis, _e.g_. to conduct a class, a request can be submitted through the Media and Publications Digital Copy Center.


4. The Freedom of Information Act (5 U.S.C. § 552) (FOIA) stipulates that federal agencies will provide public access to agency records unless they are protected from disclosure by exemption or exclusion. It also requires that instructions to staff be made available to the public in electronic format. The CCDM and active Notices that meet the definition of "instructions to staff" fulfill FOIA requirements by posting them to the IRS.gov [Electronic Reading Room](http://www.irs.gov/uac/Electronic-Reading-Room) .



1. Material classified as Official Use Only (OUO) is excluded from the FOIA provisions.

2. For assistance in preparing OUO directives, see CCDM 30.6.1.2.1 Documents Classified as "Official Use Only" , and IRM 1.11.2.10, Official Use Only (OUO) Information in the IRM.

3. Authors must contact CC:FM:PFD prior to clearing directives containing OUO material.


**30.2.1.3** **(08-18-2006)**

### Preparation of Directives

1. Associates Chief Counsel and Division Counsels are responsible for the initiation, clearance, approval and maintenance of directives affecting their respective functional areas.

2. CC:FM:PM will review all directives to determine that:



   - Applicable directives guidelines have been followed

   - The appropriate format and numbering schema is used

   - The appropriate approval authority level is designated

   - Clearance protocols have been followed

   - Appropriate cancellation dates for Notices are used


3. CC:FM:PM will contact the author if it determines that changes need to be made. CC:FM:PFD does not review directives for technical content; that responsibility is borne by the issuing office. However, if a potential technical discrepancy is recognized, the author will be contacted.


**30.2.1.3.1** **(08-18-2006)**

#### Approval Authority for Directives

1. The Chief Counsel approves all directives relating to the organization of the Office of Chief Counsel; the assignment, transfer, or delegation of the Chief Counsel's authority, functions, or duties; or general Office policy.

2. The Deputies Chief Counsel, Division Counsels, and Associates Chief Counsel approve directives within the authority delegated in CCDM 30.3.2, Delegation of Authority and Designations.

3. The Deputies Chief Counsel, Division Counsels, and Associates Chief Counsel may re-delegate this approval authority in full or in part to an official(s) under his or her supervision for matters under the jurisdiction of that subordinate official.



### Note:



CC:FM:PFD must be notified when approval authority for Notices or the CCDM are re-delegated.

4. All internal directives containing delegations of authority to subordinates must be signed by an approving official that possesses the authority to re-delegate that authority.

5. **Clearance**. At a minimum, directives will be cleared by all management levels between the author and the approving official. CC:FM:PFD will assist authors in determining clearance protocols.



1. Directives which may require notification of, or negotiation with, NTEU will be cleared by the Labor and Employee Relations Division.

2. Directives which impact organizations outside of the functional authority of the approving official will be cleared by the impacted organizations.

3. CC:FM:PM will be the final point of clearance for all CCDM sections.


**30.2.1.3.2** **(04-04-2014)**

#### Revisions to Directives

1. Revisions and/or cancellations to directives will generally be approved by the original approving level, unless approval authority has been re-delegated as described above.



### Note:



Depending on the content of the material to be changed, revisions to sections may be issued by an Associate Chief Counsel other than the previous approving Associate Chief Counsel. CC:FM:PFD will assist authors in determining approval authority in these cases.

2. On a case-by-case basis, directives originally approved by a Deputy Chief Counsel, Division Counsel, or an Associate Chief Counsel may be revised or cancelled by a directly reporting subordinate official provided some form of written communication from the original approving official is submitted with the clearance record.



### Exception:



Revisions to the CCDM may be revised or cancelled by either a directly reporting subordinate official or CC:FM:PFD without the above documentation when they meet the criteria for the "Editorial Update Process" (see _CCDM 30.2.1.5.4_).

3. Revisions to directives should follow the same clearance protocols as the original directives.



### Exception:



Revisions to the CCDM that meet the criteria for the "Editorial Update Process" (see _CCDM 30.2.1.5.4_).


**30.2.1.3.3** **(04-04-2014)**

#### Writing Standards for Directives

01. Directives should be accurate, complete, and clear. Use understandable, direct language and avoid ambiguity.

02. Organize information in logical sequences. Cover one subject in one place ( _i.e._, in one paragraph, section, or chapter, depending on the scope of the subject).

03. Write directives for a specific audience, and consider the audience’s needs, resources, and knowledge.

04. Choose descriptive titles and headings with terms that would facilitate on-line searches.

05. Break up long sections and paragraphs into multiple sentences or paragraphs. However, do not subdivide so minutely that the text becomes fragmented or loses continuity, or in the case of the CCDM unduly increases the number of subsections.

06. Do not enclose directives headings or titles in quotation marks. Use the number followed by a comma, then the full title.

07. When referring to the CCDM, use **CCDM** followed by the section/sub-section identification numbers (e.g., _CCDM 30.2.1.3.2_). If applicable, cite the paragraph number (e.g., see __CCDM 30.2.1.3.2(1)__).



    ### Note:



    Within the CCDM, references to the IRM and to other CCDM sections will generally be hyperlinked. Due to current limitations, the hyperlink will be to the section level only. References, however, can be shown below the section level; it is recommended that the title of the subsection be included to ensure the reader finds the appropriate reference.

08. When referring to CC Notices, use **Notice** followed by the identification number (e.g., Notice CC-2006-016, or Notice N(30)6(12)-0).

09. When referring to laws, the Code of Federal Regulations, or other official materials, be specific. When citing codified materials, include the Code title number or common use equivalent and include the section number. For example:




    | **_Use_** | **_Not_** |
    | --- | --- |
    | IRC section 6103(h) _or_<br> IRC § 6103(h) | Section 6103(h) |
    | Treas. Reg. section 1.61-1 | Section 1.61-1 of the regulations |

10. When referring to forms and publications, use the number and complete title the first time the form/publication is referenced; thereafter, use only the form/publication number. Include hyperlinks to forms, publications and other documents contained in the Product Catalog, available at http://publish.no.irs.gov/catlg.html.

11. Use official titles rather than employee names.

12. _Use of the term "Policy" ._ The Commissioner confines the use of the word "policy" within the Service to those matters in which discretion is exercised by the Service. The practice of substituting phrases such as the position of the Service instead of policy, when referring to technical and litigation matters, has been adopted by the Office of Chief Counsel and is used by the directives system.

13. _Notes_ may be inserted in the CCDM text for explanatory insertions that do not fit text continuity. For an example, see CCDM 30.2.1.3.3(7).

14. _Footnotes_ may be used in Notices. The production software used for the CCDM does not allow the use of footnotes.

15. Document 12835, IRM Style Guide, was developed to establish standards and promote consistency. The guide conforms to the Plain Writing Act of 2010.


**30.2.1.4** **(04-04-2014)**

### Chief Counsel Notices

1. CC Notices are directives that provide interim guidance, furnish temporary procedures, describe changes in litigating positions, or convey administrative information.



1. Notices which provide interim guidance or instructions to staff are designed to be incorporated into the CCDM, but are issued as Notices in order to provide immediate notification of important policy or procedural changes.

2. When Notices providing advance information of material to be incorporated in the CCDM are issued, the author should begin preparing the CCDM section/revision as soon as the Notice is issued. In general, the CCDM section should be published within twelve months of the Notice being issued.


### Note:

Questions concerning conflicts between procedures in a Notice and in the CCDM should be directed to the Part Manager (see _CCDM 30.2.1.5.1_).

2. Notices are issued as needed. All Notices issued since 1998 are accessible on the CC Intranet Notice website, whether they are currently active or have been archived. In addition, many Notices issued prior to 1998 are also available on the site. Notices are considered "archived" when they have:



   - Lapsed due to their cancellation date

   - Been revoked or replaced by another Notice

   - Been superseded by the CCDM

   - Been superseded by another type of directive or ruling


### Note:

IRS.gov contains only currently active Notices.

3. Notices are numbered sequentially by fiscal year, without regard to content or originating organization, and are formatted as **CC-YYYY-NNN**, e.g. CC-2013-004. Notices are numbered by CC:FM:PFD after clearance by the approving official.



### Note:



Notices issued prior to 2001 were numbered in relation to the CCDM structure replaced in 2004; they may also contain cross-reference numbers preceded by CR to indicate procedures affecting more than one function.

4. The date of the Notice will be the date the clearance record was signed by the approving official, unless CC:FM:PFD is notified that the Notice should be issued on a future date.


**30.2.1.4.1** **(04-04-2014)**

#### Preparing Notices

1. Notices are prepared using the template shown in _Exhibit 30.2.1-1_. The template can be obtained from CC:FM:PFD as a Word file.

2. Leave the Notice number, issue date, and information in the footer **blank**. These fields will be completed by CC:FM:PFD after the Notice is approved.

3. Titles on Notices (termed "subject" on the template) should be both descriptive and concise. Notices concerning uniformity in litigation positions will include the abbreviation CLP in the title to indicate a Service litigating position. "Change in Litigating Position" or "CLP" is not sufficient as a title for the Notice, however, because titles are used as search parameters in the online databases.

4. There is no prescribed format for the content of Notices. The format should be chosen to best convey the information to be presented. As a guide, many Notices have been structured as follows:



   - Purpose/Background/Scope

   - Content

   - Summary

   - Contact Information


5. A Chief Counsel Uniform Issue List number (UIL) should be included in the text of a Notice when applicable to facilitate research.

6. Notices should be prepared for the signature of an Associate Chief Counsel, Division Counsel or above, unless the authority has been re-delegated (see CCDM 30.2.1.3.1, Approval Authority for Directives).

7. All Notices must specify a cancellation date based on their purpose and/or content. In general, one of the cancellation dates listed below will be selected.




| **Cancellation Date** | **Content** |
| --- | --- |
| _One month after issuance_ | Announcements |
| _One year after issuance_ | Announcements which are anticipated to be replaced on an annual basis |
| _Upon incorporation into the CCDM_ | Procedures and guidelines that will be published in the CCDM, including new material and material that supersedes existing CCDM content |
| _Effective until further notice/Indefinite_ | Material that will not be published in the CCDM, such as a litigating position, or information that is subject to frequent change |

8. When CC:FM:PFD receives approved Notices with cancellation dates of "one month after issuance" or "one year after issuance" , **they will insert the actual date before issuing the Notice** . The Notice will be archived as of the date specified.



### Note:



The issuing function may choose to specify a future date which corresponds to a planned event, such as a reorganization. The date must be within a one-year time-frame.


**30.2.1.4.2** **(04-04-2014)**

#### Review and Clearance of CC Notices

1. Form 178, Clearance Record, is used to record the review and clearance process for CC Notices. The form is shown in _Exhibit 30.2.1-2_.The form indicates that the document is a Notice, and provides the subject of the Notice, distribution instructions, and any other pertinent information. Paragraphs (2) through (6), below, provide instructions for completing Form 178.



### Caution:



Form 178 is **not** to be used for CCDM sections.

2. _Type of Document_ — Place an X next to "Notice" .

3. _Explanation of Issuance_ — Use this space to summarize the purpose of the Notice. When composing the summary, be sure to capture the essence of the Notice. Including "key words" will facilitate word search requests, enabling those who are using this feature to retrieve applicable Notice(s) from the CC Intranet Notice website.

4. _Proposed Distribution_ — All Notices will be posted to the Electronic Reading Room on IRS.gov. In addition, indicate the Notice should be distributed to one of the following:



   - Tax Litigation staff,

   - Tax Litigation staff and Support personnel, or

   - All Personnel.


5. _Title_ — This block should have the same title as the approving official who will sign the Notice.

6. _Reviewers_ —List the office symbols and names of all reviewers in the spaces below "Route in Turn to" . Notices which contain material that affect employee working conditions or items covered in the negotiated contract must be cleared by the Labor and Employee Relations Division before they can be distributed to ensure that the Notice does not have potential labor relations implications. The Notice should be cleared by all the reviewers listed prior to sending the Notice to the approving official for signature.



### Note:



Although Form 178 states that the draft Notice should be routed in turn to the reviewers listed, the Notice may be sent to all reviewers for simultaneous clearance. Individually signed clearance records would then be attached to the Form 178 to be signed by the approving official.


**30.2.1.4.3** **(04-04-2014)**

#### Final Review and Distribution of Notices

1. After the Notice has been cleared by all reviewers and signed by the approving official, the point of contact (POC) should fax the signed Notice and the Form(s) 178, Clearance Record, to CC:FM:PFD and email the Word file.

2. Because CC:FM:PFD will be working from faxed copies of the Notice and clearance record(s), the originating office should retain the original signed Notice and clearance record(s) until the Notice is archived. If the originating office does not wish to do so, the originals and associated documentation must be provided to CC:FM:PFD.



1. Once a Notice is archived, the originating office should give the original signed Notice and clearance record(s) and associated documents to CC:FM:PFD.

2. CC:FM:PM will dispose of the records according to the applicable Records Control Schedule.


3. Once CC:FM:PFD has reviewed the Notice to ensure the Notice is correctly formatted prior to distribution, the Notice will be dated and assigned a number. The Notice in a pdf file format will be returned to the POC. The POC will indicate whether any additional information needs to be included.

4. CC:FM:PM will upload the Notice to the CC Intranet Notice website, the Chief Counsel Home Page, and IRS.gov. CC:FM:PFD will email the Notice to the distribution list identified on the clearance record.



### Caution:



POCs must inform CC:FM:PFD that approved Notices contain OUO material; see CCDM 30.2.1.2(4).


**30.2.1.4.4** **(04-04-2014)**

#### Continuing Review of Active Notices

1. On a bi-annual basis, CC:FM:PFD will coordinate the review of active Notices with cancellation dates of _Upon incorporation into the CCDM_. The issuing office will take the necessary action to publish the contents in the CCDM or revoke the Notice.

2. On a bi-annual basis, the issuing office will review Notices issued with cancellation dates of _Effective until further notice/Indefinite_ and determine whether the Notice should remain active, be archived, or published in the CCDM.


**30.2.1.5** **(08-18-2006)**

### The Chief Counsel Directives Manual (CCDM)

1. The Chief Counsel Directives Manual Is the primary compilation of the policy and guidelines needed for the effective operation of the Office of Chief Counsel. Although the CCDM contains specific procedures, it is not intended to be a comprehensive checklist or "how to" guide for every action or process.

2. All Associate Chief Counsel and Division Counsel offices are responsible for ensuring that the CCDM reflects the current policies, guidance, and procedures of the Office of Chief Counsel, particularly those functions designated as responsible for assigned CCDM parts. Because provisions of the CCDM affect many different organizations, the "Part Manager" will not have exclusive control of all substantive elements of its assigned part. The role of the Part Manager will be to identify the need for changes, coordinate the changes with the affected or interested organizations, and forward them to CC:FM:PFD for the purpose of revising the CCDM.

3. Material will be written or revised by the appropriate author. The author or lead author will be identified as the originator when the CCDM is submitted for publication. His/her name, organizational symbols and telephone number will be displayed on the catalog page in the IRM Numerical Index.

4. CC:FM:PM is responsible for the administrative maintenance of the CCDM. This includes developing procedures and ensuring that the CCDM is published in accordance with IRM procedures. Information on the IRM publication process can be found in IRM 1.11.2.

5. New or revised CCDM sections may be preceded by the issuance of a Notice, but it is not required. The issuance of a Notice is not a substitute for the publication or revision of the CCDM.


**30.2.1.5.1** **(04-04-2014)**

#### Structure of the CCDM

1. In 2004, the CCDM was extensively revised both in terms of content and structure. The CCDM is published as Parts 30-39 of the IRM, described below, and can be found electronically in the IRM Numerical Index and in CCDM Online.




| **_Part_** | **_Title_** | **_Part Manager_** |
| --- | --- | --- |
| 30 | Administrative | Associate Chief Counsel (FM) |
| 31 | Guiding Principles | Associate Chief Counsel (PA) |
| 32 | Published Guidance and Other Guidance to Taxpayers | Associate Chief Counsel (PA) |
| 33 | Legal Advice | Associate Chief Counsel (PA) |
| 34 | Litigation in District Court, Bankruptcy Court, Court of Federal Claims, and State Court | Associate Chief Counsel (PA) |
| 35 | Tax Court Litigation | Associate Chief Counsel (PA) |
| 36 | Appellate Litigation and Actions on Decision | Associate Chief Counsel (PA) |
| 37 | Disclosure | Associate Chief Counsel (PA) |
| 38 | Criminal Tax | Associate Chief Counsel (CT) |
| 39 | General Legal Services | Associate Chief Counsel (GLS) |

2. Within each part, the CCDM is organized by chapter and section. Chapter and section titles are standardized; deviations, whether changes to existing titles or additional titles, must be coordinated with CC:FM:PFD prior to clearance of the CCDM. Current approved chapter and section titles may be found at http://spder.web.irs.gov/imd/resources/IRMPartChap.asp. Once a CCDM section has become obsolete, the section number cannot be reused.

3. A section is the smallest unit of issue for publication purposes; in this case it would be CCDM 30.2.1. Revisions to any text or exhibit within a section requires publication of the entire section.

4. A section consists of a Manual Transmittal, text (including tables and figures) which is presented in numbered subsections, and optional exhibits.


**30.2.1.5.2** **(04-04-2014)**

#### CCDM Preparation

1. The first step in preparing a new or revised CCDM section is to organize the material to be included. Existing guidance that was issued as Notices, memoranda or e-mails, and procedures derived from re-engineered processes should be incorporated. Text and exhibits may incorporate or reference information found on organizational webpages and in "desk" and user guides.

2. To revise the content of an existing CCDM section, obtain an electronic copy of the current section from the Numerical index site. XML editor software is used to publish the CCDM. Among other purposes, the software enforces the standard CCDM format and numbering system.



### Note:



Arbortext Editor software (the current IRM standard) can be obtained for any author. To acquire the software and training, contact CC:FM:PFD.

3. Authors with access to Arbortext Editor software should download the XML file to their personal computer and revise the file directly.



1. The author should revise the Manual Transmittal as described below. Change the transmittal date to _Month DD, YYYY_. The date will be inserted by Media and Publications.

2. For each subsection that is revised, change the subsection date to the symbols _(MM-DD-YYYY)_.


4. Authors without access to Arbortext Editor software may prepare CCDM material in Microsoft Word. To obtain an electronic copy of the current section from the Numerical index site, copy the current PDF file to a personal computer by saving the file as a rich text format file (not as a Word document). Then open the .rtf file in Word, convert the file from the rich text format, and make the necessary changes.



1. The conversion process from the .rtf file format to a Word document may result in there being no spaces between words and sentences.

2. To make this process more manageable, authors can delete from the Word document any subsections that are not being changed.

3. Change the transmittal date to _Month DD, YYYY_ and change the date of any subsections being revised to the symbols _(MM-DD-YYYY)_.


5. New CCDM sections may be written in either Arbortext Editor software or Microsoft Word. CC:FM:PFD will provide assistance for either process.


**30.2.1.5.2.1** **(04-04-2014)**

##### Manual Transmittal

01. Manual Transmittals are required for all CCDM material that is created, revised or made obsolete. Manual Transmittals are prepared at the section level by the author and must provide the information shown in the following table.




    | **Element** | **Required or Optional** |
    | --- | --- |
    | _Purpose_ | required |
    | _Background_ | optional |
    |  |  |
    | _Material Changes_ | required |
    | _Effective Date_ | required |
    | _Effect on Other Documents_ | required |
    | _Audience_ | required |
    | _Signature_ | required |

02. In the **Purpose** element, succinctly state why the section is being issued. For example, "This transmits revised CCDM 30.2.1, Chief Counsel Directives, Office of Chief Counsel Directives System." CCDMs must be identified by their number, their chapter title, and their section title.

03. Use the **Background** element to explain the reasons for the development of the CCDM material, _e.g._, legislative changes or systems implementation.

04. In **Material Changes**, describe the substantive changes being made or text being issued. This element can also be used to describe the underlying basis for the change if the _Background_ element is not used. If the CCDM section incorporates text from a published Notice, then the Notice number must be included in this element. Because there are no restrictions on the length of the element nor the number of paragraphs, changes may be listed and identified by subsection. If any section is being obsoleted, then the manual transmittal needs to cite the reason why.

05. For the **Effective Date**, identify either a specific implementation date or (MM-DD-YYYY). If (MM-DD-YYYY) is used, the effective date of the section will be the publication date of the Manual Transmittal. The effective date can not be a prior date.

06. After **Effect on Other Documents**, state the number and date of the CCDM or Notice that is being replaced, superseded or obsoleted (even when stated in the _Material Changes_ element). Revisions with the same section number will supersede the previous CCDM, which must be listed in this element. (For an example, see the Manual Transmittal for this section.) Use "none" only when issuing new material that has never been issued in any directive.



    ### Example:



    "CCDM 31.3.9 dated 3/21/2000 is obsolete; the content was superseded by CCDM 38.3.1 dated 8/11/2004."

07. Under **Audience**, specify Chief Counsel at a minimum.

08. In the **Signature** element, insert the name and title of the Approving Official on Form 2061.

09. The issue date for the Manual Transmittal and all changed subsections and exhibits will be the date assigned by Media and Publications. Revisions to previously issued CCDMs will continue to indicate the previous dates for all subsections and exhibits that were not changed by the Manual Transmittal.

10. _Exhibit 30.2.1-3_, Model Language for CCDM Manual Transmittals, provides sample language that can be used as a starting point.


**30.2.1.5.2.2** **(04-04-2014)**

##### Text

1. Text within sections is presented within segments, and is identified by numbers separated by decimal points. Reading from left to right, each number represents a different segment. For example in the boldface heading above, 30.2.1.5.2.2 indicates _Part_ 30, _Chapter_ 2, _Section_ 1, subsection 5, sub-subsection 2, sub-sub-subsection 2. Segments are limited to a total of 8 placeholders.

2. The smallest unit of text in the CCDM that can be added or revised is a subsection, which consists of a title, a number (consisting of no more than 8 placeholders), a minimum of one paragraph of associated text, and an effective date (generally the date of the Manual Transmittal, although a future effective date may be specified).

3. The first subsection in a section should describe the purpose and content of the section on a broad level. See CCDM 30.2.1.1 for an example. In general, the subsection should not be entitled "Background" , "General" or "Overview" , but rather something more descriptive for conducting electronic research.



### Note:



This is where a discussion of the background for the development of the section could be located if the information needs to continue to remain in the section. Future revisions of the section will not include the previous Manual Transmittal content.

4. A change to only one subsection requires the re-issuance of the entire section. However, the only dates that would change would be the date of the Manual Transmittal and the date of the changed subsection(s).

5. Paragraphs are numbered sequentially within parentheses. Due to the limited number of placeholders available, authors are urged not to establish subsections containing only one paragraph. Exceptions are subsections with multiple subdivisions; for an example see CCDM 30.4.2.2, Trial Periods and Probationary Periods, with sub-subsections CCDM 30.4.2.2.1, CCDM 30.4.2.2.2, and CCDM 30.4.2.2.3.

6. In general, a section that has less than four pages should be combined with another related section.

7. When revising CCDM sections, be cautious when relocating and/or renumbering existing subsections or inserting new subsections, because other CCDM or IRM material may reference these subsections.


**30.2.1.5.2.3** **(04-04-2014)**

##### Lists, Notes, Tables, and Figures

1. Material below the paragraph level can be presented in lists, tables, figures, or notes.

2. **_Lists_** elaborate on the material at the paragraph level. Use lists for information that would detract from the flow of the narrative, that would be more cumbersome to convey within a single paragraph, or which should be highlighted. The three types of lists described below may be used. Lists may not have further embedded lists ("lists-within-lists" ).



1. _Alphabetical lists_ are used to present material that would likely be referenced in other materials or CCDM sections. For an example see _CCDM 30.2.1.1(2)_.

2. _Numerical lists_ are used to indicate a specific order of processes, steps, etc. For an example see CCDM 30.3.2.3.3, Associate Chief Counsel (Financial Institutions & Products).

3. _Bullet lists_ are used to display items which do not need to be in any particular order. For an example see _CCDM 30.2.1.3(2)_


### Note:

In general, lists should be limited to no more than a dozen items. If more material is present, the author should consider adding paragraphs or providing the information in an exhibit.

3. **_Notes_** may be used in the text for material that does not fit text continuity. They are offset from the text and presented in **_bold, italic_** font. An example is provided below. Footnotes may not be used.



### Note:



Acceptable expressions include _Note, Exception, Example_, and _Caution_.

4. **_Tables_** are inserted immediately below the paragraph they relate to. Use tables to simplify complicated information or streamline extensive step-by-step procedures. Tables consist of a header row and subsequent rows; for an example see _CCDM 30.2.1.4.1(7)_. Tables within the text are the width of the column of text. Tables within exhibits span the width of the page.



### Note:



Due to software limitations, tables that must be presented in landscape format because of their size are restricted to exhibits.

5. **_Figures_** are embedded within the body of the related text to illustrate or explain a procedure. Titles are required for each figure and they are numbered consecutively throughout the CCDM section in the order in which they appear, _e.g_. _Figure 30.2.1-1_, _Figure 30.2.1-2_, etc. Verbal Descriptive Narratives must be written for any figures that are graphic (see _CCDM 30.2.1.5.2.4(1)e_).


**30.2.1.5.2.4** **(04-04-2014)**

##### Exhibits and Forms

1. **_Exhibits_** are used to supplement text, to display items that are mentioned more than once, or as a reference for further information. Exhibits may consist of text or tables, or may include graphic material, such as diagrams, illustrations and flowcharts.



1. Exhibits are placed and numbered consecutively at the end of the section in the order in which they are referenced in the text, _e.g._ Exhibit 30.2.1-1, Exhibit 30.2.1-2, etc. Exhibits must be discussed in the section text.

2. Exhibits may be submitted as Word, Excel or PDF (Portable Document Format) files. There are no restrictions on the format of exhibits; however multiple-page exhibits should be limited to a maximum of five pages.

3. PDF files are the only types of graphic files accepted for CCDM publication. PDF files that consist solely of narrative content ( _e.g._, scanned documents) should be converted from graphics to Word.



      ### Note:



      All PDF files are graphics, including those converted from Word or Excel. Authors should provide such files to CC:FM:PFD in their original format.

4. Exhibits submitted as graphic PDF files, such as flow charts or organization charts, should **not** contain the title and exhibit number.

5. In order to comply with Section 508 of the Rehabilitation Act (29 U.S.C. 794d), which requires that graphic content be accessible to users of adaptive equipment, Verbal Descriptive Narratives (VDN) must accompany all graphics and PDF files. For assistance in preparing VDNs, contact CC:FM:PFD or see http://spder.web.irs.gov/imd/.


2. **_Forms_** are frequently referenced throughout the CCDM. When referring to forms, identify the form by number followed by title, e.g., Form 2061, Document Clearance Record. When referring to an official form that is available electronically through the IRS Product Catalog or from other Federal government sources, include a hyperlink to the form in the text rather than creating a figure or exhibit. This will ensure that the current version of the form is cited.



### Exception:



Examples of completed forms can be provided as exhibits in lieu of hyperlinks where needed for explanatory purposes. They should be submitted to CC:FM:PFD as an electronic PDF file, with an accompanying VDN.

3. "Forms" that have not been officially numbered and published by the Media and Publication Division can be provided as exhibits when submitted as a graphic PDF file. Because their use is being prescribed by the CCDM, such "forms" should be made official; CC:FM:PFD will assist in this process.


**30.2.1.5.3** **(04-04-2014)**

#### Review and Clearance of CCDM Sections

1. The review and clearance of new or revised CCDM sections is a major component of the CCDM publication process. Each CCDM must be reviewed and approved by the appropriate offices and levels of authority. Authors and originating offices need to plan for formal clearance so that impacted organizations have sufficient review time before the CCDM can be finalized. In addition to the revised text and the Form 2061, Document Clearance Record (described below), the review package should include background information concerning the changes, such as CC Notices or revised regulations. The use of Form 13839, Note to Reviewers, or a similar format is encouraged but not required.



1. CCDM sections must be cleared through the organizations that the procedures or policies affect.

2. The standard review period for new or revised CCDM sections is 30 calendar days, which encompasses all reviewers.

3. To expedite the clearance time frame, it is good business practice to inform impacted offices about unsettled issues prior to submitting the official clearance package. To do this, authors may send the file(s) to the point of contact along with an explanation of the applicable or outstanding issues.


2. Form 2061, Document Clearance Record, serves as the official record of the review and approval of Chief Counsel policy and procedures. This document, along with substantive comments received from reviewers, is part of the permanent record and is stored in the IRM Historical Library.



1. Form 2061 should be prepared by the author as described in _Exhibit 30.2.1-4_. For assistance, contact CC:FM:PFD.

2. Although the layout of Form 2061 suggests that the draft CCDM section should be routed in turn to the reviewers listed, the section may be sent to all reviewers for simultaneous clearance.

3. Individually signed clearance records must be attached to the Form 2061 to be signed by the approving official.

4. Form 2061 is designed to be processed and signed electronically. However, it is acceptable to print the form and sign it in ink. When manually signed, forms with the original signature(s) must be provided to CC:FM:PFD.


3. CCDM sections containing information relating to the disclosure of official information or "official use only" (OUO) information, must be cleared through the Office of Associate Chief Counsel, Procedure & Administration. For further information, see:



   - CCDM 30.6.1, Security and Emergency Preparedness; Security of Confidential Information, Official Documents, Tax Data, Personnel and Property

   - CCDM 37.1.2, Disclosure of Information


4. CCDM sections containing procedures that change working conditions of Bargaining Unit employees are subject to NTEU notification and negotiation and must be cleared through the Director, Labor and Employee Relations Division CC:FM:LER.


**30.2.1.5.4** **(04-04-2014)**

#### Editorial Update Process

1. The "editorial update process" provides a stream-lined method for revising CCDM sections to change information of a non-technical or non-legal nature. The editorial update process is also used for formal certification that the CCDM section has been reviewed and is technically and procedurally up-to-date.

2. CCDM sections eligible for the editorial update process are those which contain current procedures and guidelines, but which require minor changes such as the following (this list is not all-inclusive):



   - Inserting or updating references to other CCDM or IRM section content, forms, documents, or publications

   - Inserting or updating legal citations and other references

   - Clarifying existing content

   - Correcting errors

   - Updating information that changes often ( _e.g._, organizational terms, titles and symbols; website addresses; street addresses and post office box numbers; telephone numbers)

   - Reorganizing the same content on a limited basis for better flow or clarification

   - Improving the format of the CCDM ( _e.g._, moving text to exhibits; reducing subsection levels)

   - Inserting hyperlinks in lieu of exhibits

   - Improving the quality of graphics used in CCDM figures and exhibits; converting graphics to text


3. CCDM revisions that are **not** eligible for the editorial update process include:



   - Any type of change relating to policy matters and delegations of authority

   - Matters requiring clearance outside the CCDM owner’s office

   - Matters requiring clearance due to disclosure issues or "official use only" content

   - Matters requiring clearance from Labor and Employee Relations

   - Incorporation of material from CC Notices


### Exception:

If the material in the Notice was presented as CCDM text, complete with subsection titles and numbers, the CCDM revision can be processed as a "editorial update" . If Form 2061 was not sent by the originating office with Form 178 when the Notice was cleared, or sent separately shortly thereafter, CC:FM:PFD will process the CCDM revision. The Manual Transmittal will then be signed by the Director, Planning and Finance Division.

4. CCDM sections eligible for the editorial update process may be revised by either the original approval level's subordinate official or CC:FM:PFD. Clearance levels on Form 2061 for editorial updates are limited to the management chain between the author and the subordinate official.

5. Division Counsels and Associates Chief Counsel may delegate this approval authority for editorial updates to a specific individual or organizational level on a permanent basis by notifying CC:FM:PFD.

6. Use of the editorial update process does not eliminate the requirement for a Manual Transmittal, Form 2061 and background information.


**30.2.1.5.5** **(04-04-2014)**

#### Final Review and Publication

1. CCDM sections, whether new, revised, or being made obsolete, are issued as needed; there is no schedule established. Publication dates will depend on the amount of time required for clearance, administrative review of the package, and conversion of the material to the software used for publishing. Projected publication time frames in the first quarter of the fiscal year may be impacted by the publication of filing season IRM sections, which take precedence over all other IRM or CCDM materials.

2. After the approving official has signed the Form 2061, the complete review package should be submitted to CC:FM:PFD. The CCDM package consists of the new and/or revised CCDM material, the Manual Transmittal and the accompanying supporting documents described in paragraphs (3) through (7). These items become part of the permanent record maintained by the IRS Historical Library, and are available for future research. Authors may contact CC:FM:PFD for assistance.

3. **_Form 2061, Document Clearance Record_**. ensures that the material is seen and approved by the appropriate organizations and officials. See Exhibit 30.2.1-4.



1. If a paper form is signed, the **original** signed Form 2061 must be submitted to CC:FM:PFD.



      ### Note:



      If the section was distributed for simultaneous clearance, the **original** of each Individually signed clearance record must be attached to the Form 2061 signed by the approving official.

2. If Form 2061 is prepared electronically, digital signatures on the PDF document are acceptable.


4. **_Background Information_** describes the impetus for the change(s). Law, regulations, or Treasury/federal department directives (if any) should be cited or copies provided. Form 13839 is available for use.

5. **_Substantive comments received_** during the final clearance process from the reviewers listed on the Form 2061 and a **_record of the action(s) taken_** to address the comments should be included with the Form(s) 2061.

6. Any e-mails, faxed material or other documentation that constitute an organization's determination that it does not need to clear the CCDM section before publication must be included with the Form(s) 2061.

7. Copies of official guidance or CC Notices that are being incorporated into the CCDM section, but which are not available on the CCDM Notice website when the section is being cleared, must be included with the Form(s) 2061.

8. CC:FM:PM will do a final review of the CCDM section for conformance to CCDM and IRM requirements and will contact the author if any modifications are needed. CC:FM:PFD will convert CCDM sections submitted in Word, Excel or PDF files to to the CCDM publication software, and provide a formatted copy to the authoring organization for a final review.

9. CC:FM:PM will prepare Form 1767, Publishing Services Requisition, and submit the final package to Media and Publications for publication. The issuance date of the CCDM section will be the date the package is officially published.



### Note:



Form 1767 is the only requisition format/process that can be used when submitting CCDM sections for publishing.


**30.2.1.5.6** **(04-04-2014)**

#### Continuing Review of Published CCDM Sections; Certification of Content

1. Periodically, issuing offices will review CCDM sections they have published to determine whether the CCDM section continues to remain current, existing information needs to be revised or deleted, or new information added.

2. On an annual basis, CC:FM:PFD will coordinate a formal review of CCDM sections that have Manual Transmittal dates three or more years older than the current year. The issuing office will take the necessary action to review the contents in the CCDM.

3. If the formal review determines the existing content in a CCDM section is still current and requires no changes, the issuing office will follow the Editorial Update process in _CCDM 30.2.1.5.4_ for certification.



1. The _Material Changes_ element in the Manual Transmittal must contain the statement:


       "The text in this section has been reviewed and the technical and procedural content remains current."

2. When CC:FM:PFD submits the CCDM section to Media and Publications, the date of the first subsection will be changed to the publication date.


4. If changes are required, the issuing office will follow either the normal revision process or the Editorial Update process to revise the section.


**30.2.1.5.7** **(04-04-2014)**

#### Requesting CCDM Changes or Deviations

1. Any request for changes to a CCDM section, _e.g_. procedural modifications or error corrections, should be submitted to the contact identified on the section's catalog page in the numerical index.



### Note:



Requests for new CCDM sections should be submitted to the Associate Chief Counsel/Division Counsel responsible for the program.

2. Sometimes national program guidance may not work for all offices in all areas of the country because of special needs or other considerations. If this is the case, the head of that office or organization may request permission to deviate from the official procedures set forth in the CCDM.

3. Any request for a deviation from the CCDM must be approved by the organization who "owns" the CCDM process (either the issuing organization or the Part Manager, see _CCDM 30.2.1.5.1_). A written request must be submitted from the appropriate organizational level to the Associate Chief Counsel/Division Counsel responsible for the program.


**Exhibit 30.2.1-1**

### Notice Template

![This is an Image: 29706001.gif](https://www.irs.gov/pub/xml_bc/29706001.gif)

> The banner for the Notice template contains the following: Department of the TreasuryInternal Revenue ServiceOffice of Chief CounselNoticeThe Notice identifiers consist of: CC-YYYY-NNNMonth DD, YYYYSubjectCancellation dateLocation of CCDM subsection guidanceAt the end of the text for the Notice is the signature block containing the following: NameTitleOn the bottom of the first page of the Notice is the following information: Distribution optionsFilename:File copy in: CC:FM:PFD

[Please click here for the text description of the image.](https://www.irs.gov/media/157166 "")

**Exhibit 30.2.1-2**

### Form 178, Clearance Record

![This is an Image: 29706002.gif](https://www.irs.gov/pub/xml_bc/29706002.gif)

> Clearance RecordA blank Form 178 is provided, with the following blocks to be filled in: Type of Document = NoticeDeadline Date for ClearanceDocument NumberSubjectOriginator's name, initial, office symbols and telephone numberExplanation of IssuanceProposed DistributionRouting information consisting of office symbols, name, signature, date, and commentsApprover information consisting of title, signature and dateAdministrative information consisting of date printed, date distributed, and initialsAt the bottom of the form are the following: CC Form 178 (Rev. 9-84)Department of the Treasury – Internal Revenue Service

[Please click here for the text description of the image.](https://www.irs.gov/media/157171 "")

**Exhibit 30.2.1-3**

### Model Language for CCDM Manual Transmittals

| **MANUAL TRANSMITTAL** | **3X.XX.XX**<br>**Month DD, YYYY** |
| --- | --- |
|  |  |  |  |  |
| **PURPOSE** |  |
|  | (1) | This transmits new/revised CCDM 3X.XX.XX, Chapter Title; Section Title. |
| **BACKGROUND** (optional) |  |
|  | (1) | This material is being issued/revised as a result of ( _law, regulation, organizational changes_). |
| **MATERIAL CHANGES** |
|  | (1) | CCDM 3X.XX.X is being issued/ revised to provide current policy on \_\_\_\_\_\_\_\_\_\_\_ for the Office of Chief Counsel as a result of \_\_\_\_\_\_\_\_\_. |
|  | (2) | CCDM 3X.XX.X.1.2.3 is being issued/ revised to incorporate procedures that were \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_. |
|  | _(Highlight important features of the procedures being issued; identify significant changes in organizations and procedures; provide authority for issuing/changing procedures; provide audit trail for CC Notices or other official guidance being incorporated)_<br>_(Use as much specificity as needed to alert the reader to the changes made)_ |
| **EFFECT ON OTHER DOCUMENTS** |
|  | (1) | CCDM 3X.X.X, dated MM-DD-YYYY, is superseded. _(When this section is revised)_ |
|  | (2) | CCDM 3Y.Y.Y, dated MM-DD-YYYY, is superseded. _(When this section replaces material currently found in another section)_ |
|  | (3) | This section incorporates procedures found in/supersedes Chief Counsel Notice \_\_\_\_\_\_, dated MM-DD-YYYY. _(If applicable)_ |
|  | (4) | This section obsoletes CCDM 3X.X.X, dated MM-DD-YYYY. _(When this or another section is made obsolete)_ |
|  | (5) | This obsoletes CCDM 3X.X.X, dated MM-DD-YYYY. The content was superseded by CCDM 3X.X.X, dated MM-DD-YYYY. _(When this section is made obsolete by another section; both Manual Transmittals must contain this information.)_ |
| **AUDIENCE** |  |
|  | Chief Counsel |
|  |  |  |  |  |
|  |  |  | Title<br> Organization |
|  |  |  |  |  |
| \\_\\_\\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |  |  |
| Note: **_Supersede_** and **_obsolete_** are specific CCDM/IRM terms; they are not inter-changeable. Contact CC:FM:PFD for assistance. |

**Exhibit 30.2.1-4**

### Preparation of Form 2061, Document Clearance Record

_The parts and item numbers shown below refer to the 05-2021 revision of Form 2061._

**Part I: IMD and Originating Office** (completed by the author)

| **_Item_** | **_Description/Instructions_** |
| --- | --- |
| 1\. _Clearance Start Date_ | The date the clearance process begins<br> Select from the drop-down calendar |
| 2\. _Clearance Response Due Date_ | 30 days after the _Clearance Start Date_<br> Select from the drop-down calendar |
| 3\. _IMD Type_ | The type of document you are submitting the form for<br> Select “Other” from the drop-down calendar |
| 4\. _IMD Number_ | The CCDM number to the section level, _e.g._, 30.2.1 |
| 5\. _Title_ | The title of the whole CCDM section, not that of a revised sub-section |
| 6\. _Expedite Clearance_ | This item should generally be left blank. Clearance in less than 30 days requires approval of an executive in the originating CC organization |
| 7\. _IMD Contains New, Changed, or Re-designed Official Use Only (OUO) Content_ | Select "No" from the two options. Usually CCDMs will not have OUO content |
| 8\. _Author Information_ | The author/lead author’s name, office symbols and phone number, including area code |
| 9\. _IMD Coordinator Information_ | The IMD Coordinator’s name, office symbol and phone number, including area code |

**Part II: Reviewer Information** (completed by the author)

| **_Item_** | **_Description/Instructions_** |
| --- | --- |
| 10\. _Specialized Reviewers_ | Use only if the new/revised section contains specific program material that needs to be reviewed by any of the IRS organizations listed. Check all boxes that apply |
| 11\. _External Reviewers_ and 11a. _Specific External Reviewers_ | Use the "Chief Counsel" box and the field under item 11a. to indicate required review by CC organizations listed in CCDM 30.2.1.5.3 (3) and (4)<br> Also indicate any organization outside of Chief Counsel affected by the changes in the document; affected organizations will need to review the section<br> To add more rows in order to list more than one reviewer, please click on the plus sign to the right of the "Office Symbols" field |
| 12\. _Internal Reviewers_ | Use the fields under item 12 to identify specific individuals or groups within the internal/originating organization that are required to review the document |

**Part III: Review Assessment, Comments, and Signature** (completed by each of the reviewers identified in items 10, 11 and 12)

### Note:

A separate Form 2061 should be provided to each of the reviewers. Contact CC:FM:PFD for assistance.

| **_Item_** | **_Description/Instructions_** |
| --- | --- |
| 13\. _Review Assessment, Comments, and Signature_ | Select one of the review assessment choices under 13b.<br> Any comments provided may either be noted under 13b (a comment field will appear once "I concur with comments" is selected in the drop-down) of the form or attached in a separate document. |
| Insert the name, title and office symbols of the reviewer. The reviewer signs electronically in the signature box.<br> <br>### Note:<br>Form 2061 can be printed and signed and dated in ink. |

**Part IV: Final Clearance Package Dates**

### Note:

Documents final package creation and requested due dates.

| **_Item_** | **_Description/Instructions_** |
| --- | --- |
| 14\. _Final Package Start Date_ | Enter the date you created the final clearance package and sent for final review<br> <br>### Note:<br>This date can be the same as the date when the package was forwarded for final review to CC:FM:PFD. |
| 15\. _Final Package Requested Due Date_ | Enter the requested approval due date<br> <br>### Note:<br>This date can be left blank to be filled out by CC:FM:PFD. |

**Part V: Final Management Review and Assessment**

| **_Item_** | **_Description/Instructions_** |
| --- | --- |
| 16\. _Reviewer's Management Official_ | If a reviewing organization requires a management official's signature that is not otherwise listed, enter the name, title and office symbols of that individual in this section. The official signs electronically in the signature box.<br> <br>### Note:<br>Form 2061 can be printed and signed in ink. |

**Part VI: Approving Official's Signature**

### Note:

This is the individual whose signature will appear on the published CCDM, and should be listed on the Manual Transmittal.

| **_Item_** | **_Description/Instructions_** |
| --- | --- |
| 19\. _Approving Official’s Signature_ | Enter the name, title and office symbols of the appropriate approving official. The approving official electronically signs in the signature box.<br> <br>### Note:<br>Form 2061 can be printed and signed in ink. |

**Part VII: Final Review by IMD/IRM Coordinator**

| **_Item_** | **_Description/Instructions_** |
| --- | --- |
| 20\. _IMD/IRM Coordinator Information_ | Enter the name, title and office symbols of the IMD/IRM Coordinator. The coordinator electronically signs in the signature box<br> <br>### Note:<br>This section can be left blank before sending to CC:FM:PFD. |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part30/irm_30-002-001#addtoany "Show all")

A2A