---
url: "https://www.irs.gov/irm/part34/irm_34-003-001"
title: "34.3.1 Procedures in Bankruptcy Cases | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part34/irm_34-003-001#main-content)

- 34.3.1 [Procedures in Bankruptcy Cases](https://www.irs.gov/irm/part34/irm_34-003-001#idm140483791981248)
  - 34.3.1.1 [General Procedures in Bankruptcy Cases](https://www.irs.gov/irm/part34/irm_34-003-001#idm140483765545392)

    - 34.3.1.1.1 [Initial Service Involvement in Bankruptcy Cases](https://www.irs.gov/irm/part34/irm_34-003-001#idm140483755103344)
    - 34.3.1.1.2 [Counsels Role in Bankruptcy Cases](https://www.irs.gov/irm/part34/irm_34-003-001#idm140483763661024)
    - 34.3.1.1.3 [Chapter 7 Case Procedures](https://www.irs.gov/irm/part34/irm_34-003-001#idm140483753365952)
    - 34.3.1.1.4 [Chapter 11 Case Procedures](https://www.irs.gov/irm/part34/irm_34-003-001#idm140483761204528)
    - 34.3.1.1.5 [Chapter 13 Case Procedures](https://www.irs.gov/irm/part34/irm_34-003-001#idm140483771254768)
    - 34.3.1.1.6 [Tax Claims in Bankruptcy](https://www.irs.gov/irm/part34/irm_34-003-001#idm140483747852112)
    - 34.3.1.1.7 [Referral to the Department of Justice in Bankruptcy Code Cases](https://www.irs.gov/irm/part34/irm_34-003-001#idm140483743136048)
    - 34.3.1.1.8 [Adverse Decisions from Bankruptcy Judges](https://www.irs.gov/irm/part34/irm_34-003-001#idm140483763849984)
    - 34.3.1.1.9 [Offers in Compromise in Bankruptcy](https://www.irs.gov/irm/part34/irm_34-003-001#idm140483752271536)

  - 34.3.1.2 [Procedures Relating to Determination of Tax Liability](https://www.irs.gov/irm/part34/irm_34-003-001#idm140483763541552)

    - 34.3.1.2.1 [Lifting the Automatic Stay for Tax Court Litigation](https://www.irs.gov/irm/part34/irm_34-003-001#idm140483760526608)
    - 34.3.1.2.2 [Processing of Bankruptcy Cases Examination and Appeals](https://www.irs.gov/irm/part34/irm_34-003-001#idm140483753303984)
    - 34.3.1.2.3 [Notices of Deficiency](https://www.irs.gov/irm/part34/irm_34-003-001#idm140483768959632)
    - 34.3.1.2.4 [Seeking Relief from the Stay to Take Collection Action](https://www.irs.gov/irm/part34/irm_34-003-001#idm140483751456752)
    - 34.3.1.2.5 [Trustees Responsibilities for Filing Returns and Paying Taxes](https://www.irs.gov/irm/part34/irm_34-003-001#idm140483753392464)
    - 34.3.1.2.6 [Reversal of Abatement Due to Bankruptcy Discharge](https://www.irs.gov/irm/part34/irm_34-003-001#idm140483760004736)

  - 34.3.1.3 [Significant Bankruptcy Case Program](https://www.irs.gov/irm/part34/irm_34-003-001#idm140483769893840)

    - 34.3.1.3.1 [Case Initiation and Referral Criteria](https://www.irs.gov/irm/part34/irm_34-003-001#idm140483757243136)
    - 34.3.1.3.2 [Primary Responsibility](https://www.irs.gov/irm/part34/irm_34-003-001#idm140483766161584)
    - 34.3.1.3.3 [Coordination](https://www.irs.gov/irm/part34/irm_34-003-001#idm140483771753264)
    - 34.3.1.3.4 [Proof of Claim](https://www.irs.gov/irm/part34/irm_34-003-001#idm140483759996544)
    - 34.3.1.3.5 [Disclosure Statement and Plan Review](https://www.irs.gov/irm/part34/irm_34-003-001#idm140483745780096)

# Part 34. Litigation in District Court, Bankruptcy Court, Court of Federal Claims, and State Court

# Chapter 3. Procedures in Bankruptcy Cases

# Section 1. Procedures in Bankruptcy Cases

* * *

## 34.3.1 Procedures in Bankruptcy Cases

#### Manual Transmittal

January 20, 2015

#### Purpose

(1) This transmits revised CCDM 34.3.1, Procedures in Bankruptcy Cases.

#### Material Changes

(1) References to changes in the law under the Bankruptcy Abuse Prevention and Consumer Protection Act of 2005 (the BAPCPA) are added throughout this section where appropriate. See CCDM 34.3.1.1.5(2) and (3), CCDM 34.3.1.2(5)(a), CCDM 34.3.1.2.1(1), CCDM 34.3.1.2.4(1) and (6), and CCDM 34.3.1.2.5(3).

(2) A new description of Insolvency Groups is provided to reflect the centralization of some Insolvency functions in the Centralized Insolvency Operation (CIO) in Philadelphia. See CCDM 34.3.1.1.1.

(3) The responsibilities and authorities for Chapter 11 Case Procedures are revised to reflect the fact that some clerical processing and monitoring will take place in the CIO. See CCDM 34.3.1.1.4(1).

(4) Procedures to be followed for deficient Chapter 11 plans are revised to clarify that the Service may accept a deficient plan if it is in the best interests of the Government to do so. See CCDM 34.3.1.1.4(5)(b).

(5) Procedures are revised to clarify that the document provided in Exhibit 34.12.1-1 for accepting or rejecting a plan is not required but may be used, as appropriate, in lieu of the official form. The bankruptcy rules require the use of official forms but also allow the forms to be modified, as appropriate. The use of Exhibit 34.12.1-1 might not be appropriate when electronic balloting is used. See CCDM 34.1.1.4(5)(h).

(6) Procedures to be followed for deficient Chapter 13 plans are revised to clarify that the Service may accept a deficient plan if it is in the best interests of the Government to do so. See CCDM 34.3.1.1.5(4)(d).

(7) Procedures for preparing and filing proofs of claim are revised to reflect the centralization of some Insolvency functions and use of the Automated Proof of Claim system. See CCDM 34.3.1.1.6(1).

(8) Procedures are added directing coordination with the Office of the Associate Chief Counsel (Procedure & Administration), Branch 5 of any bankruptcy case with I.R.C. § 4971 issues, as required by Chief Counsel Notice CC-2006-007. See CCDM 34.3.1.1.6(3) and CCDM 34.3.1.3.3(6).

(9) New CCDM 34.3.1.1.9, Offers in Compromise in Bankruptcy, is added to incorporate Chief Counsel Notice CC-2004-025, which explains the Service’s policy of returning administrative offers in compromise as nonprocessable to taxpayers in bankruptcy.

(10) CCDM 34.3.1.2.1(1) is amended to highlight the distinction between the procedures to follow when a Tax Court case is filed before bankruptcy and when it is filed after bankruptcy.

(11) New section 34.3.1.2.5(3) is added to describe the tax compliance requirements for cases filed after the effective date of BAPCPA.

(12) New CCDM 34.3.1.2.6, Reversal of Abatement Due to Bankruptcy Discharge, is added to incorporate Chief Counsel Notice CC-2001-014, which explains that Bankruptcy discharges do not extinguish discharged tax liabilities and that the Service may reverse the abatement made after a bankruptcy discharge if the Service determines that collection of the discharged tax is feasible.

(13) Revisions are made to the introductory paragraph of the Significant Bankruptcy Case Program procedures to explain the purposes of the program. Stylistic changes are also made to these procedures. See CCDM 34.3.1.3.

(14) A provision is added in CCDM 34.3.1.3.3(2) so that TEGE will be included in Counsel's initial memorandum under the Significant Bankruptcy Case Program.

(15) CCDM 34.3.1.3.3(7) is added to require National Office coordination when the debtor files certain motions to sell, as required by Chief Counsel Notice CC-2005-004. A reference is again made in CCDM 34.3.1.3.5(4).

(16) CCDM 34.3.1.3.5 is updated to provide for the referral of plan documents to the National Office in certain cases, as required by Chief Counsel Notice CC-2005-004, and to clarify the plan review procedures. A note is added to watch for plan transactions where an entity may be left with no assets to pay its tax liabilities.

#### Effect on Other Documents

CCDM 34.3.1 dated 11/30/2012, and Chief Counsel Notices CC-2001-014 dated 02/23/2001, CC-2004-025 dated 07/12/2004, CC-2005-004 dated 02/04/2005, and CC-2006-007 dated 12/22/2005 are superseded.

#### Audience

Chief Counsel

#### Effective Date

(01-20-2015)

Frederick W. Schindler

Deputy Associate Chief Counsel

(Procedure & Administration)

**34.3.1.1** **(01-20-2015)**

### General Procedures in Bankruptcy Cases

1. This section describes the procedures to be followed in bankruptcy cases.


**34.3.1.1.1** **(01-20-2015)**

#### Initial Service Involvement in Bankruptcy Cases

1. **Service Responsibilities**. Insolvency, which is a part of the Compliance function for the Small Business/Self Employed Operating Division of the Service, handles all bankruptcy cases and is primarily responsible for the Service’s bankruptcy program. See IRM 5.9.1.4 http://publish.no.irs.gov/getpdf.cgi?catnum=39955, Overview of Bankruptcy; The Role of Insolvency.

2. **Insolvency**. Insolvency is divided into a Field function consisting of more than 80 posts of duty geographically distributed throughout the country and a single Centralized Insolvency Operation (CIO) in Philadelphia. How work is allocated between Field Insolvency and the CIO is set forth in IRM 5.9.1.4(2), Overview of Bankruptcy; The Role of Insolvency; Insolvency Organizations.



1. Generally, the CIO works all Chapter 7 No Asset cases, Chapter 7 Asset cases with tax claims under $250,000, and monitors, processes payments, and closes Chapter 13 cases. The Field Insolvency function works Chapter 13 cases until confirmation, Chapter 11 cases, and complex issues. See IRM 5.9.1.4(3), Overview of Bankruptcy; The Role of Insolvency; Complex Issues, for a list of complex issues.

2. Together the two Insolvency functions have the responsibility to protect the interests of the Government in all bankruptcy cases, but may request assistance or refer cases to Field Counsel in various circumstances. The CIO will transfer cases to the appropriate Field Insolvency office when a referral to Counsel is needed, and Field Insolvency is responsible for all referrals. See IRM 5.9.4.14, Common Bankruptcy Issues, Referrals — Representing IRS in Bankruptcy Court, for specific referral procedures.


3. **Information as to Commencement of Cases**. The Service may learn of the commencement of a bankruptcy case from four principal sources:



   - Copies of petitions, notices, or other documents furnished to the CIO or the Field Insolvency office covering the judicial district in which the case is pending

   - Reports from revenue officers or other field personnel

   - Public notices required by law, such as published notices of proceedings contained in local journals, newspapers, or legal publications in each locality

   - Electronic communications from the bankruptcy court docket database (such as WebPACER or PACER).


4. Notice of an order for relief in a bankruptcy case is required under Bankruptcy Code section 342. Federal Rule of Bankruptcy Procedure 2002 prescribes to whom the notice is given and in what manner.


**34.3.1.1.2** **(01-20-2015)**

#### Counsel’s Role in Bankruptcy Cases

1. **Case Referrals to Counsel**. When a case is referred to Field Counsel, a file should be opened. This case file should be closed after legal advice has been given on the referred issue or problem. If the case is referred to DJ, the file will remain open until the case is closed in DJ. Absent special circumstances, the case file should not be kept open until the conclusion of the bankruptcy proceeding.

2. **Advisory Function**. Legal questions may arise concerning matters in connection with which there is no immediate controversy, in the sense that there is no pending adversarial action in court. Instead, Insolvency personnel may have certain bankruptcy procedural questions such as whether:



   - Proof of claim should be filed in the case

   - Certain items should be included in a proof of claim

   - A proof of claim constitutes an amendment to a proof of claim filed at an earlier time

   - A notice of lien should be filed during the pendency of the case

   - An overpayment should be frozen or setoff

   - Seizure of certain property is permissible.


3. Questions may also arise concerning what action, if any, should be taken to collect federal taxes from persons who are not parties to the bankruptcy case, such as whether to assert that any person may be liable under the provisions of I.R.C. § 6672.

4. **Affirmative Action Required**. Where federal taxes are involved in a bankruptcy case, many controversies may arise affecting the interests of the United States. Some controversies relate to the merits of claimed federal taxes.



1. Objections to the merits of claimed federal taxes and other "non-merits" issues may be litigated before the bankruptcy court.

2. Field Counsel should determine the question at issue, examine the pertinent statutes and court decisions and so inform the Tax Division or the U.S. Attorney’s Office, depending upon the appropriate referral procedures for the issue in question.

3. If Field Counsel determines that affirmative action requiring authorization under section 7401 or 7403 is warranted, Field Counsel should prepare a suit letter to the Assistant Attorney General, Tax Division, to authorize such action.


**34.3.1.1.3** **(01-20-2015)**

#### Chapter 7 Case Procedures

1. **United States as a Petitioning Creditor**. While legally permissible, it is highly unusual for the United States as a creditor to join with other creditors in commencing an involuntary case against an individual, partnership, or corporation.



1. If such action is contemplated, Field Counsel will send the letter to the Office of the Associate Chief Counsel (Procedure & Administration), Branch 5 for review as a sensitive matter prior to transmittal to the Tax Division.


2. **Notice of the Case**. Under Federal Rule of Bankruptcy Procedure 2002(e), if it appears that there are no assets in a Chapter 7 liquidation case from which a dividend can be paid, the notice of the meeting of creditors may state that it is unnecessary to file claims and that if sufficient assets become available, further notice will be given for the filing of claims.

3. For procedures relating to processing Chapter 7 Cases, see IRM 5.9.6 http://publish.no.irs.gov/getpdf.cgi?catnum=39962, Processing Chapter 7 Bankruptcy Cases.


**34.3.1.1.4** **(01-20-2015)**

#### Chapter 11 Case Procedures

1. **Responsibilities and Authority**. With the exception of initial clerical processing and some other clerical monitoring, Chapter 11 case work remains the responsibility of Field Insolvency units. See IRM 5.9.8 http://publish.no.irs.gov/getpdf.cgi?catnum=39964, Processing Chapter 11 Bankruptcy Cases.

2. **Report from Insolvency Group**. When a case is referred, Field Counsel should consider what information and data may be required in order for Field Counsel to properly perform its function. Any required information and/or data should be requested from the Field Insolvency unit.

3. **Immediate Examination of Court Papers**. After a file is opened, copies of court papers should be examined immediately upon receipt. In many cases, hearings are set with very short notice for the Government to act on proposed orders that affect its rights.



1. Schedules attached to the petitions should be examined to see whether taxes are shown to be due and to determine the financial condition of the debtor.

2. Schedules attached to the petitions should be examined to determine whether the Service should request adequate protection because a tax lien has attached to property that is depreciating or deteriorating.


4. **Property Sold Free of Lien**. If property is authorized by the court to be sold free and clear of liens, it is advisable to have the order of sale provide that the liens of the United States shall attach to the proceeds of sale in the same order and priority as they attached to the property.

5. **Satisfactory Payment of Taxes under Plans of Reorganization**. Insolvency should decide whether a plan is acceptable, but Field Counsel should advise the Insolvency staff to ensure that all relevant factors are considered. Generally, a plan of reorganization is referred for review by Field Counsel only after a defect has been identified with the plan. Local procedures may affect the nature and timing of referrals of reorganization plans for review.



1. Many of the plans submitted in reorganization cases fail to provide satisfactorily for the payment of federal taxes. If the proposed plan is unsatisfactory, consider notifying the attorney representing the trustee or debtor in possession that the proposed plan fails to comply with the provisions of Bankruptcy Code section 1129.

2. If the trustee or debtor can demonstrate that acceptance of a deficient plan is in the best interests of the Government, a determination may be made to accept the plan in lieu of filing an objection. See IRM 5.9.8.14.2(7), Processing Chapter 11 Bankruptcy Cases; Disclosure Statements and Plans of Reorganization; The Plan of Reorganization; Deficient Plans – Exceptions, and IRM 5.9.4.10, Common Bankruptcy Issues; Offers in Compromise and Bankruptcy. See CCDM 34.3.1.1.9, Procedures in Bankruptcy Cases; General Procedures in Bankruptcy Cases; Offers in Compromise in Bankruptcy. If compliance with the requirements of the Bankruptcy Code cannot be obtained and the trustee or debtor cannot demonstrate that acceptance of a deficient plan is in the best interests of the Government, Field Counsel should ensure that an objection to confirmation of the plan is timely filed.

3. Where the federal taxes at issue are secured or general unsecured taxes, and the proposed plan does not meet the minimum "cram-down" criteria of section 1129(b)(2)(A) and/or (B), a notice of rejection signed by the Associate Area Counsel should be filed by the U.S. Attorney pursuant to section 1126(a).

4. The notice of rejection should be filed before the hearing on confirmation under section 1128(a).

5. Associate Area Counsel in each POD can accept or reject plans where the claims of the United States are solely for Internal Revenue taxes. In "mixed" claims cases (i.e., claims of other federal agencies have been filed in addition to those of the Service), Field Counsel should contact the other government agency having a claim to determine the position of that agency. If agreement can be reached between the Chief Counsel, the Service, and the holder of a non-Treasury claim of the United States, the Field Counsel will review and sign an acceptance or rejection for all federal claimants. If no agreement can be reached between the Chief Counsel, the Service and the holder of a non-Treasury claim of the United States, Field Counsel should orally notify the Office of the Associate Chief Counsel (Procedure & Administration), Branch 5 immediately. Branch 5 will send a transmittal and the proposed acceptance or rejection to General Counsel of the Department of the Treasury for signature. In order to allow sufficient time in which to obtain the signature and review of the General Counsel, the proposed documents must be forwarded to the Office of the Associate Chief Counsel (Procedure & Administration), Branch 5 at least 10 working days prior to the last day for filing such notices.

6. The filing of a notice of rejection under section 1126(a) is permissive rather than mandatory. It is in the best interest of the Service that the Government file both an objection to the confirmation of the proposed plan of reorganization and a notice of rejection of the plan in every case where the secured and/or general unsecured tax claims are not properly provided for in the plan. The Service is not entitled to vote on a plan where there are only priority tax claims. See 11 U.S.C. §§ 1123(a)(1), 1124, & 1126(f).

7. The filing of the notice of rejection should prevent the confirmation of a plan that does not meet the minimum "cram-down" criteria of section 1129(b)(2)(A) and/or (B). Thus, such notice should provide the Government with a more substantial safeguard than merely the right to appeal an order of the bankruptcy court that overrules the Government’s objection to the plan. This is especially so when the plan is confirmed despite its failure to properly provide for the tax claims of the Service.

8. A sample copy of the document that may be used under section 1126(a) to accept or reject a plan of reorganization on behalf of the United States is provided in Exhibit 34.12.1-1http://publish.no.irs.gov/getpdf.cgi?catnum=29689. If some other document is used, the language in the exhibit showing the authority for filing the ballot on behalf of the United States should be added if possible.

9. In negotiating for the satisfactory payment of federal taxes, Field Counsel may be able to have certain supplemental provisions included in the plan of reorganization. Although these provisions are not mandatory, they are additional safeguards to protect the Service’s interest. Examples of these supplemental provisions can be found in Exhibit 34.12.1-2http://publish.no.irs.gov/getpdf.cgi?catnum=29689


6. **Plan Seeking to Avoid Taxes**. A special ground for objecting to the confirmation of a reorganization plan is that its principal purpose is the avoidance of taxes. See 11 U.S.C. § 1129(d).



1. Avoidance of taxes normally would occur through improper or fraudulent use of the Internal Revenue Code substantive tax provisions created or amended by the Bankruptcy Tax Act of 1980.

2. If information concerning such avoidance of taxes comes to the attention of Field Counsel, the U.S. Attorney should be requested to file an objection to the confirmation of the plan under section 1128(b). A request to file an objection under section 1129(d) must be pre-reviewed by the Office of the Associate Chief Counsel (Procedure & Administration), Branch 5.


**34.3.1.1.5** **(01-20-2015)**

#### Chapter 13 Case Procedures

1. **Processing Case**. Procedures relating to the processing of Chapter 13 cases by local Insolvency Groups can be found at IRM 5.9.10http://publish.no.irs.gov/getpdf.cgi?catnum=39967, Processing Chapter 13 Bankruptcy Cases.

2. **Unfiled Returns**. An objection to the confirmation of debtor’s plan and/or an order to compel the filing of a return should be filed where the debtor has failed to file return(s) for pre-petition year(s). For cases commenced on or after October 17, 2005, 11 U.S.C. § 1308(a) provides that before the 341 meeting, the debtor must file all returns due in the four years preceding the petition. The trustee may hold open the first meeting of creditors for a period of time to allow the debtor additional time to file any unfiled returns. The Service may object to confirmation, or seek dismissal or conversion of the case, if the debtor fails to comply with section 1308. 11 U.S.C. §§ 1307(e), 1325(a)(9).

3. **Current Liabilities**. A common cause of regular income earners’ tax liabilities is insufficient withholding of tax from wages, with the result that an unpaid amount for the most recent year becomes apparent eight or nine months after commencement of a Chapter 13 case. Field Counsel may wish to contact the debtor’s attorney regarding this matter. Note also for cases filed on or after October 17, 2005, Bankruptcy Code section 521(j) provides that if a debtor under any chapter fails to file a tax return that becomes due after the commencement of the case, or to properly obtain an extension, the Service may request that the court convert or dismiss the case and the court must do so unless the debtor files the return within 90 days of the request.

4. **Satisfactory Payment of Taxes Under Regular Income Plans**. Many of the plans submitted in Chapter 13 cases fail to provide for satisfactory payment of federal taxes required to be paid under Bankruptcy Code sections 1322(a)(2) (priority taxes), 1325(a)(4) (general unsecured taxes), and 1325(a)(5) (secured taxes).



1. If the proposed plan is unsatisfactory, Field Counsel should consider notifying the trustee or debtor’s attorney of the fact that the proposed plan fails to comply with the provisions of section 1322 or 1325.

2. This may be done by a letter calling attention to the necessity of complying with the provisions of section 1322 or 1325, and stating that the United States does not waive these requirements of the Bankruptcy Code insofar as federal taxes are involved.

3. If compliance is not obtained, Field Counsel should request the U.S. Attorney to file an objection to the confirmation of the plan under section 1324.

4. In exceptional cases, the Chapter 13 debtor may be unable to pay the Service’s claims as required under the Bankruptcy Code and it is in the taxpayer’s and the Government’s best interests not to have the case converted or dismissed. See IRM 5.9.10.5.5(4), Processing Chapter 13 Cases; The Chapter 13 Plan; Reasons to Object, Deficient Plans – Exceptions, and IRM 5.9.4.10, Common Bankruptcy Issues; Offers in Compromise and Bankruptcy. See CCDM 34.3.1.1.9, Procedures in Bankruptcy Cases; General Procedures in Bankruptcy Cases; Offers in Compromise in Bankruptcy, below.


**34.3.1.1.6** **(01-20-2015)**

#### Tax Claims in Bankruptcy

1. Responsibility for the timely filing of the Service’s proof of claim rests with Insolvency. See IRM 5.9.1.4(14), Overview of Bankruptcy; The Role of Insolvency; Overall Responsibilities. Proofs of claims are either prepared at the Centralized Insolvency Operation through the Automated Proof of Claim (APOC) system or manually prepared by Insolvency caseworkers. See IRM 5.9.13.2(2), Manual Proofs of Claim and Common Claim Issues; Claim Systems; Manual Reviews and Calculations.

2. Information regarding forms to file, types of claims, classification of priorities of claims, criteria for filing amended claims, and additional guidance regarding the proof of claim filing process can be found at IRM 5.9.13 http://publish.no.irs.gov/getpdf.cgi?catnum=39970, Manual Proofs of Claim and Common Claim Issues.

3. **Pension Underfunding Penalties**. Any bankruptcy case with I.R.C. § 4971 tax issues must be coordinated with the Significant Bankruptcy Case Coordinator in the Office of the Associate Chief Counsel (Procedure & Administration), Branch 5. The Service will argue in appropriate cases that the pension underfunding penalties arising under section 4971 that relate to post-petition pension obligations are entitled to administrative expense priority under Bankruptcy Code section 503(b)(1)(A).


**34.3.1.1.7** **(01-20-2015)**

#### Referral to the Department of Justice in Bankruptcy Code Cases

1. **Sensitive and Important Cases**. Matters that must be pre-reviewed by the Office of the Associate Chief Counsel (Procedure & Administration), Branch 5 will be referred to the Tax Division.



1. Matters involving a debtor that is a prominent individual or a major corporation will be referred to the Tax Division, except as provided below with respect to filing an acceptance or rejection of a plan.


2. **Direct Referral from Insolvency**. In certain bankruptcy matters that require virtually no legal determinations or where the law is clear, Insolvency will directly contact and refer cases to the U.S. Attorney. The types of cases that fall within the direct referral program are listed in IRM 5.9.4.14.1, Common Bankruptcy Issues; Referrals – Representing IRS in Bankruptcy Court; Direct Referrals.



1. In some posts-of-duty, Field Counsel has prepared templates for motions, objections, and similar documents that will be completed by the Insolvency staff. In others, the Insolvency unit will merely submit the necessary factual information to the U.S. Attorney. See IRM 5.9.4.14.1 http://publish.no.irs.gov/getpdf.cgi?catnum=39959 Common Bankruptcy Issues; Referrals - Representing IRS in Bankruptcy Court; Direct Referrals, for authorizing language that must be included in all referrals.

2. If upon review by the U.S. Attorney, a case is found to be more complex than originally thought, the U.S. Attorney will seek assistance from Field Counsel.


3. **Referrals Made by Field Counsel** Matters that do not meet the direct referral criteria should be referred from Insolvency to Field Counsel who in turn will refer the matters to the Tax Division or U.S. Attorney’s Office via a referral letter or litigation report.



1. A full referral letter will be prepared for matters referred to the Tax Division or to a U.S. Attorney’s Office that either has its own specialized tax unit or prepares and files its own pleadings; for all other referrals, a shorter referral letter is sufficient discussing only those matters not addressed by enclosed pleadings. Copies of all referral letters and pleadings will be provided to the appropriate Section Chief of the Tax Division.

2. Field Counsel will immediately notify the Tax Division by telephone of adverse orders in any matters directly referred to the U.S. Attorney.


4. **Matters to be Referred to the Tax Division**. The following matters must be referred to the Tax Division by all Field Counsel offices:



   - Objection to attorney fees;

   - Any matters upon request by a Tax Division Section Chief to a particular Field Counsel office;

   - All other Bankruptcy Code matters except those that may be handled by the U.S. Attorney by direct referral or otherwise.


5. **Acceptance or Rejection of Plans**. Field Counsel may directly file an acceptance or rejection of a plan so long as the U.S. Attorney concurs, and subject to the following conditions:



1. The Tax Division will first be alerted if a prominent individual or a major corporation is the debtor.

2. If the Tax Division is involved in litigation that would be affected by the plan, the Tax Division will first be consulted.


6. **Settlement Authority**. The Service’s settlement authority with regard to an objection to the Service's claim depends upon whether an objection to claim has already been filed by the trustee or the debtor.



1. If an objection to claim has not been filed, the Service may settle or reduce the proof of claim. If settlement is based to any extent on litigating hazards, the Service must obtain a closing agreement binding the debtor and the trustee.

2. If a settlement based on litigating hazards for an unassessed tax subject to the deficiency procedures cannot be effectuated within six months of the filing of the petition in bankruptcy, settlement may only be effectuated by the Service in accordance with IRM 8.7.6.1.7.2 http://publish.no.irs.gov/getpdf.cgi?catnum=50792, Appeals Bankruptcy Cases; Overview of Bankruptcy; Case Jurisdiction; Time Limitations on Bankruptcy Cases with Department of Justice Involvement.

3. If the case is in the IRS Office of Appeals when an objection is filed, the matter must be immediately referred to the Tax Division, and Appeals will issue a notice of deficiency (if the Service has not issued one and it is appropriate).

4. In all other cases, if the trustee agrees to an extension so that the matter will in any event not be brought on for hearing earlier than 30 days after termination of negotiations, the matter may be determined by Service personnel based on criteria ordinarily used by revenue agents or revenue officers in settling cases. If it appears that the matter cannot be resolved without consideration of litigating hazards, the matter must be immediately referred to the Tax Division.

5. In cases where there is no need to determine the tax liability for purposes of administering the estate, such as in a no-asset Chapter 7 case, the Service should argue that the bankruptcy court does not have jurisdiction to determine a chapter 7 debtor's taxes and, in the alternative, that the bankruptcy court should abstain from making a merits determination. A motion for abstention may be made pursuant to Federal Rule of Bankruptcy Procedure 5011 and 28 U.S.C. § 1334(c).


**34.3.1.1.8** **(01-20-2015)**

#### Adverse Decisions from Bankruptcy Judges

1. See CCDM 36.2.1.1.5.5 http://publish.no.irs.gov/getpdf.cgi?catnum=39015, Appeal Recommendations in General; Preparation of Appeal Letters; Transmittal of Appeal Letter; Bankruptcy Court Cases, for procedures to follow when an adverse decision is entered in the bankruptcy court.


**34.3.1.1.9** **(01-20-2015)**

#### Offers in Compromise in Bankruptcy

1. **General Rule**. The Service will not consider an administrative offer in compromise from a taxpayer in bankruptcy. If a taxpayer in bankruptcy submits such an offer in compromise to the Service, the offer will be returned as “nonprocessable.” See Rev. Proc. 2003-71, 2003-36 I.R.B. 517.



1. When a taxpayer is in bankruptcy, the resolution of a taxpayer’s Federal tax liabilities is best accomplished in the context of the bankruptcy proceeding and in accordance with applicable bankruptcy law and procedure.

2. Time frames for the consideration of claims and payment proposals in a bankruptcy case do not mesh with the bulk processing operations established for the high volume of administrative offers in compromise received by the Service.


2. **Consideration of Payment Proposals**. The Service will consider payment proposals submitted by taxpayers in bankruptcy through the plan confirmation process. Consistent with its responsibility to protect the Government’s interests, the Service will not, however, accept less than what is statutorily required to be paid under the Bankruptcy Code unless the taxpayer demonstrates that agreeing to receive less under a bankruptcy plan is in the Government’s best interests. This is a discretionary determination to be made in the context of a particular bankruptcy case.



1. In order to be considered for acceptance, a deficient plan may not provide for the payment of claims with lower priority than those of the Service, and all income that is not necessary for the health and welfare of the debtor’s family or the production of income must be committed to the plan.

2. In addition, other factors that may be considered in determining whether it is in the Government’s best interest to accept less favorable treatment than is statutorily required under the Bankruptcy Code include, but are not limited to:


   - Whether the taxpayer has the ability to pay the Service’s claims as required under the Bankruptcy Code

   - Whether the taxpayer is in compliance with tax return filing requirements

   - The extent of the taxpayer’s previous noncompliance with filing and payment requirements

   - Whether creditors with the same priority, such as state taxing authorities, are accepting less than full payment of their claims

   - Whether the Service would receive more if the bankruptcy case is dismissed or converted to a Chapter 7 liquidation

   - The amount of time remaining on the collection statute of limitations

   - Whether there is anything precluding the debtor from dismissing the bankruptcy case and submitting an administrative offer in compromise (e.g., is the Service the only creditor in the case)

   - Whether the tax liabilities are nondischargeable, and

   - Whether the Service could collect additional liabilities outside of bankruptcy from exempt, excluded, or abandoned assets.


3. **Burden on Taxpayer**. The taxpayer has the burden of demonstrating that it is in the Government’s best interest to accept less favorable treatment than is statutorily required in a bankruptcy case.

4. **Specific Bankruptcy Chapters**. The Service’s policy and general rules regarding offers in compromise in bankruptcy can be found in IRM 5.9.4.10, Common Bankruptcy Issues; Offers in Compromise and Bankruptcy. Guidelines for the consideration of payment proposals for bankruptcy cases filed under Chapters 11,12, and 13 can be found in IRM 5.9.8.5, IRM 5.9.9.4.2(5), and IRM 5.9.10.5.5(4), respectively.


**34.3.1.2** **(01-20-2015)**

### Procedures Relating to Determination of Tax Liability

1. **Bankruptcy Court Jurisdiction over Tax Litigation**. Under Bankruptcy Code section 505, a bankruptcy court may determine the amount or legality of any tax, including any fine or penalty relating to any tax, whether or not previously assessed or paid.

2. **Concurrent Jurisdiction for Tax Court Cases**. The Tax Court and the bankruptcy court may have concurrent jurisdiction with respect to a tax liability.

3. **Concurrent Jurisdiction for Refund Cases**. By virtue of the Bankruptcy Code, there is a possibility of concurrent jurisdiction with respect to a refund case. As to tax refund suits pending in the district court or Court of Federal Claims at the time a bankruptcy proceeding is commenced, the trustee may thereafter file an action in bankruptcy court to recover the same refund. In such a case, concurrent jurisdiction will arise and procedures described below should be followed.



1. When there is concurrent jurisdiction, the Government should determine which court constitutes the best forum for litigating the merits of a tax liability. If the bankruptcy court is not the most favorable forum, the Government should file a motion to lift the automatic stay to allow the case to proceed outside of the bankruptcy court’s jurisdiction. These procedures are discussed in detail below.

2. As a general matter, bankruptcy court judges are less familiar with adjudicating tax matters than Tax Court or district court judges and, therefore, the bankruptcy court may be a less advantageous forum.

3. In any case where concurrent jurisdiction exists, it may be advisable to assign the case to the same attorney who would handle both the tax litigation and general litigation aspects of the case.


4. **Procedures Governing Refund Litigation when Bankruptcy is Filed**. The following procedures apply to a suit involving a claimed overpayment of tax filed in a district court or the Court of Federal Claims.



1. If a bankruptcy case is commenced by or against the taxpayer during the pendency of the taxpayer’s refund suit in a district court or the Court of Federal Claims, either the Government or the bankruptcy trustee (or debtor in possession) may remove the action to the bankruptcy court pursuant to 28 U.S.C. §§ 1452(a) and 157(a).

2. If the trustee files an application for removal, the application and notice thereof will be forwarded by the local IRS Insolvency Unit to the local Field Counsel (SB/SE), which will then open a general litigation file (if none is then open). Field Counsel will also advise the appropriate branch of the Office of the Associate Chief Counsel (Procedure & Administration) of the trustee’s action.

3. If removal is granted, the litigation should be handled by the local SB/SE office as a general litigation case and that office should request that the P&A branch close its file.

4. If removal is not granted, or if following removal the refund action is remanded under 28 U.S.C. § 1452(b), the litigation will generally be handled by the local SB/SE office as a refund case. Refund suits by (LB&I) taxpayers should be handled by LB&I Field Counsel, but should be closely coordinated with SB/SE and DJ.

5. If tax refund litigation is commenced outside bankruptcy court after the date of bankruptcy, such suit will be handled as a tax litigation case without regard to the pendency of the bankruptcy proceeding. In such cases, under Bankruptcy Code section 362(a)(1), the Government is automatically stayed from filing a counterclaim.

6. In the case of settlements in which refunds will exceed $2,000,000, the case must be reported to the Joint Committee on Taxation for review. See CCDM 34.8.2.8 http://publish.no.irs.gov/getpdf.cgi?catnum=39031, Settlement Procedures; Joint Committee Cases, for a discussion of Joint Committee review of refunds.


5. **Procedures Governing Tax Court Litigation when Bankruptcy is Filed**. The following procedures apply to a case that is pending in Tax Court when a bankruptcy case involving the taxpayer is commenced.



1. Field Counsel should determine whether continuation of the Tax Court case is subject to the automatic stay of Bankruptcy Code section 362(a)(8). If the automatic stay is not in effect, the office need not take any action other than to defend the case according to established procedures. For cases filed on or after October, 17, 2005, the automatic stay applies only to Tax Court cases concerning tax periods that ended before the petition date when the debtor is an individual. When the debtor is a corporation, the stay applies to any debt that can be determined by the bankruptcy court.

2. If the Tax Court is allowed to determine the amount of tax liability, the litigation will be handled by Field Counsel as a tax litigation case. If the bankruptcy judge decides that the bankruptcy court, rather than the Tax Court, should determine the tax liability, or if the litigation is initially commenced in the bankruptcy court, the litigation will be handled by Field Counsel as a general litigation case. Regardless of whether the bankruptcy court retains jurisdiction to determine the tax liability, Field Counsel will, where appropriate, coordinate the substantive tax issues with the appropriate Associate Chief Counsel office.

3. If Tax Court litigation had commenced and, in that action, the merits of any tax liability had been tried prior to the date of bankruptcy, Field Counsel may wish to seek a lifting of the stay so that the Tax Court may proceed to render an opinion. If the stay is lifted, such litigation will continue to be handled by Field Counsel as a tax litigation case.


6. **Coordination of Bankruptcy Cases with Tax Shelter Aspects**. To ensure proper coordination in bankruptcy cases where the debtor is an abusive tax shelter vehicle, a promoter of, or an investor in, an abusive tax shelter, the following procedures will apply.



1. As soon as it is learned that the bankruptcy case involves an abusive tax shelter vehicle, the Office of the Associate Chief Counsel (Procedure & Administration), Branch 5 and the Tax Division should be alerted.

2. A defense letter will be prepared by the Field Counsel handling the case and forwarded to the Tax Division.

3. If the letter requires prior review by an Associate Office, Field Counsel shall forward a draft of the letter to the appropriate office for approval prior to issuing it.

4. The reference to the caption of the case on page 1 of the letter should clearly state that it involves an abusive tax shelter vehicle.

5. Copies of the defense letter should be sent to the Office of the Associate Chief Counsel (Procedure & Administration), Branch 5. Copies of exhibits, to the extent they pertain to the tax shelter aspects, should be included.


**34.3.1.2.1** **(01-20-2015)**

#### Lifting the Automatic Stay for Tax Court Litigation

1. **Stay of Tax Court Proceedings**. For cases filed before October 17, 2005, the commencement or continuation of a proceeding before the Tax Court concerning the debtor is prohibited under Bankruptcy Code section 362(a)(8). For cases filed on or after October, 17, 2005, however, the automatic stay applies only to Tax Court cases concerning tax periods that ended before the petition date when the debtor is an individual. When the debtor is a corporation, the stay applies to any debt that can be determined by the bankruptcy court.



1. For Tax Court cases filed before the automatic stay went into effect, the Government should file a motion to lift the stay with the bankruptcy court in order to continue the Tax Court case. Follow CCDM 35.2.1.1.8(7), Tax Court Petitions; Analysis of New Tax Court Petitions; Effect of Bankruptcy. To avoid violating the stay, the attorney handling the Tax Court litigation should refrain from taking any action to litigate the Tax Court case until the automatic stay is lifted.

2. For Tax Court cases commenced after the automatic stay against Tax Court proceedings went into effect, a motion to dismiss the Tax Court case is appropriate. Follow CCDM 35.2.1.1.8(9), Tax Court Petitions; Analysis of New Tax Court Petitions; Effect of Bankruptcy.

3. Field Counsel handling the case should be sensitive to the local bankruptcy judge’s attitude toward resolving tax issues as this may be significant for persuading the Tax Division or the U.S. Attorney to seek a lifting of the stay.

4. It is unlikely that the bankruptcy court will lift the stay if the trustee, the debtor in possession, or the debtor objects. The local SB/SE office should determine whether there might be any objections to lifting the stay by these parties before seeking to lift the stay.


2. **Circumstances for Lifting the Stay**. The circumstances under which the attorney handling the Tax Court case may wish to have the stay lifted to allow for the Tax Court litigation to proceed include:



1. It is generally known that the particular bankruptcy judge handling the taxpayer’s case does not favor hearing tax litigation cases.

2. The request will not be opposed by the trustee, the debtor, or the debtor in possession. Any request that the stay be lifted in order to continue litigation in the Tax Court should specify whether the trustee or the debtor is opposed to litigation in the Tax Court.

3. Where only one spouse who filed a joint tax return has gone into bankruptcy, and where both spouses had filed a petition(s) to the Tax Court, the Government may argue that, in the interest of economy of litigation, and to avoid a "whipsaw" situation, the stay should be lifted in order to allow continued litigation in the Tax Court.

4. Where one or more tax issues raised in the Tax Court proceeding involving the debtor are common in law and fact to those raised in the Tax Court proceeding of another taxpayer. This category would include, for example, cases that would be subject to consolidation under the Tax Court’s Rules of Practice and Procedure. As discussed previously, it is in the interests of economy of litigation and avoiding "whipsaw" situations that the stay be lifted in such cases.

5. Where, as of the bankruptcy commencement date, the case before the Tax Court is ready for trial, or has been tried but a decision has not yet been rendered.

6. Where, in a nominal or no asset case, the trustee does not wish to litigate the merits of a tax issue, but the debtor wishes to do so. In such a case the bankruptcy court should be favorably disposed to having the litigation prosecuted elsewhere in order to avoid expenses of administration. As a practical matter, absent special circumstances, a request to lift the stay need not be made in a nominal or no asset case involving an individual because, ordinarily, an order of discharge of the debtor should be issued early in the proceeding, which will automatically cause the stay to be lifted. See 11 U.S.C. § 362(c)(2)(C).

7. Any other circumstances that, in the judgment of Field Counsel handling the case, make it appropriate to litigate in the Tax Court rather than the bankruptcy court.

8. Field Counsel should set forth in its referral letter to the Tax Division or U.S. Attorney's Office all of the facts and circumstances supporting its recommendation that the stay be lifted to allow the Tax Court litigation to continue.


**34.3.1.2.2** **(11-30-2012)**

#### Processing of Bankruptcy Cases Examination and Appeals

1. See IRM 8.7.6 http://publish.no.irs.gov/getpdf.cgi?catnum=50792, Appeals Bankruptcy Cases, for Appeals procedures.

2. See IRM 4.27.3 http://publish.no.irs.gov/getpdf.cgi?catnum=27752, Review and Processing Procedures, for Examination procedures.


**34.3.1.2.3** **(01-20-2015)**

#### Notices of Deficiency

1. **Issuance of Notice of Deficiency to Debtor**. Bankruptcy Code section 362(b)(9)(B) clarifies that the Service may issue a notice of deficiency to a bankrupt taxpayer and not violate the automatic stay.



1. IRM 4.8.9.17.4 http://publish.no.irs.gov/getpdf.cgi?catnum=50713 , Statutory Notices of Deficiency, Special Cases; Bankruptcy Cases, and IRM 4.27.3.4 http://publish.no.irs.gov/getpdf.cgi?catnum=27752 ,Review and Processing Procedures; Corresponding with Taxpayers; Unagreed Cases Held by the Area Where a Notice of Deficiency Has Not Been Issued, discuss the preparation, review, and issuance of notices of deficiency in bankruptcy cases.

2. A copy of the notice of deficiency pertaining to pre-petition tax liabilities is sent by the Service to the trustee in bankruptcy. Where an individual debtor has not elected to terminate his/her taxable year under Internal Revenue Code section 1398(d), the liability for the year of bankruptcy is not claimed in the case as a pre-petition debt. Thus, a copy of the notice of deficiency relating to that taxable year is not sent to the trustee except in Chapter 13 cases.

3. Whether the merits of a tax are litigated in the Tax Court or in the bankruptcy court, the Government must timely file a proof of claim to participate as a creditor in the bankruptcy case with respect to that tax (there may not be an absolute requirement in Chapter 11 cases but even there it should be done).

4. Such procedures shall include forwarding a copy of the notice of deficiency to the local IRS Insolvency Unit.

5. After issuance of a notice of deficiency to the bankrupt debtor, the case will be held by the Service until the taxpayer contests the liability in bankruptcy court or attempts to file a petition with the Tax Court. If this occurs, the Service should immediately provide the administrative case file to Field Counsel for defense.

6. Pursuant to I.R.C § 6213(f), the 90 day period for filing a petition with the Tax Court contesting a notice of deficiency issued to a taxpayer in bankruptcy is suspended for the period of time that the automatic stay prevents the filing of said petition, plus 60 days thereafter. Accordingly, unless the stay is lifted to allow for the filing of a Tax Court petition, the Service may be prevented from assessing the liability proposed by the notice of deficiency until the 90 day period, as extended by this rule, expires. The Service may also assess the tax if it is determined by the bankruptcy court. See I.R.C. § 6871(b). Attorneys must be aware of the applicability of these provisions in bankruptcy cases.


**34.3.1.2.4** **(01-20-2015)**

#### Seeking Relief from the Stay to Take Collection Action

1. General Provisions. Collection actions against the debtor or property of the estate are generally prohibited by the provisions of the automatic stay. See 11 U.S.C. § 362(a). Relief from the stay may be sought by a party in interest under section 362(d), or the stay may terminate by operation of law under section 362(c). The automatic stay is curtailed in certain cases concerning repeat bankruptcy filers who file again after October 17, 2005; sections 362(c)(3), 362(c)(4) and 362(n) provide that the automatic stay either terminates within 30 days, or does not go into effect at all, in certain cases concerning repeat filers.

2. In determining whether to seek relief from the stay, the attorney handling the case should ascertain whether the granting of a bankruptcy discharge in the case is imminent. This may eliminate the need to request a lifting of the stay as, in most cases, a discharge would lift the stay pursuant to section 362(c)(2). This factor should be specifically discussed in any recommendation to the Tax Division or U.S. Attorney’s Office. Note that a discharge does not lift the stay of acts against property of the estate, which continues until such property is no longer property of the estate. See 11 U.S.C. § 362(c)(1).

3. If lifting of the stay appears to be imminent, Field Counsel should advise the Service that no request to lift the stay will be filed unless the Service has special reasons for it to be lifted.

4. As a practical matter, the discharge should be granted in Chapter 7 cases involving individuals within six months of the date that the bankruptcy petition is filed or the case is commenced.

5. In Chapter 13 cases, unless the debtor is granted a hardship discharge under section 1328(b), a discharge will be granted only after the debtor has made the payments provided for under the plan. 11 U.S.C. § 1328 A plan may be up to five years long. 11 U.S.C. § 1322(d).

6. In Chapter 11 cases, discharge will generally occur upon confirmation of the plan. 11 U.S.C. § 1141(d). Confirmation may occur at any time up to several years after the bankruptcy petition is filed. For Chapter 11 cases of individuals filed on or after October 17, 2005, the discharge is not granted until completion of all payments under the plan.

7. Service employees are to exercise due diligence in ensuring that the stay is not violated, and actions taken in violation of the stay are corrected expeditiously. See IRM 5.9.3.6http://publish.no.irs.gov/getpdf.cgi?catnum=39958, Debtor's Delinquent Accounts; Automatic Stay.


**34.3.1.2.5** **(01-20-2015)**

#### Trustee’s Responsibilities for Filing Returns and Paying Taxes

1. **Trustee’s Failure to Pay Taxes**. If the trustee (or debtor in possession) has funds on hand sufficient to pay the taxes that accrue during the estate’s administration, and fails to make payment within a reasonable time after receipt of a claim, the local IRS Insolvency Unit may refer the matter to the local SB/SE Field Counsel office. If the trustee or debtor in possession fails to file federal tax returns with respect to federal tax liabilities incurred after the proceeding has begun, or to pay the federal taxes in question when due, the Government may seek relief by filing either a motion to dismiss the case or a motion to obtain an order requiring the trustee (or debtor) to comply with the applicable federal tax statutes.

2. **Action to Ensure Payment of Current Trust Fund Taxes**. In some jurisdictions, local bankruptcy rules or a standing order issued by the bankruptcy court mandate that the debtor or trustee timely file and pay all taxes, including withholding taxes.



1. In jurisdictions where this does not occur, or where any order or local rule is insufficient, the attorney handling the case should, when requested, take action to have the bankruptcy court order the trustee or a debtor in possession to: segregate trust fund taxes from all other funds and deposit the withholdings in separate bank account; make Federal Tax Deposits at such times and intervals as to best protect the interest of the United States; or pay trust fund taxes to the IRS Insolvency Unit when (or shortly after) the wages are paid.

2. The preferred method is to have the local bankruptcy court rules or a general standing order provide for the incorporation of such provisions. Where this is not occurring, the local SB/SE office should take necessary steps to achieve this end.

3. If the debtor or trustee fails to timely file or pay withholding taxes, the Service should contact the debtor or trustee and request immediate compliance. If noncompliance continues, the attorney handling the case should immediately ensure that either a motion to dismiss or motion to convert the case to Chapter 7 is filed with the court, whichever is in the best interests of the Service.


3. For bankruptcy cases filed after October 17, 2005, 28 U.S.C. § 960 expressly requires that a tax arising from post-petition business operations shall be paid on or before the due date of the tax under applicable nonbankruptcy law in most cases. Also effective for cases filed after October 17, 2005, failure to timely file post-petition tax returns and pay post-petition taxes is an express ground for conversion or dismissal of a Chapter 11 case pursuant to 11 U.S.C. § 1112(b)(4)(I), and 11 U.S.C. § 503(b)(1)(D) provides that a governmental unit shall not be required to file a request for payment of administrative expense taxes.


**34.3.1.2.6** **(01-20-2015)**

#### Reversal of Abatement Due to Bankruptcy Discharge

1. Bankruptcy discharges do not extinguish discharged tax liabilities. The Service may, however, abate otherwise proper assessments against a taxpayer following a bankruptcy discharge if the Service determines that collection of the discharged tax is unlikely. This abatement is generally based on the determination that the taxpayer has no assets from which the Service can collect. The discharged liability is abated pursuant to the authority of section 6404(c), which permits the Service to abate the unpaid portion of an assessment when the Service determines that the administration and collection costs would not warrant collection of the amount due.

2. If it is later determined that collection is feasible before the collection limitations period has expired (e.g. previously unknown assets are discovered), the abatement may be reversed in order to properly reflect the taxpayer’s unpaid assessment in the Service’s records. Unlike an abatement under section 6404(a), an abatement under section 6404(c) is not a determination of the amount of the tax liability. A section 6404(c) determination is a collection determination and therefore reversible without having to make a new assessment.


**34.3.1.3** **(01-20-2015)**

### Significant Bankruptcy Case Program

1. This section outlines additional procedures for large or otherwise significant bankruptcy cases. These procedures are designed to facilitate coordination among the various Service functions and to provide for a detailed review of Chapter 11 plan documents with regard to substantive tax issues arising from the transactions contemplated in the Chapter 11 plan.


**34.3.1.3.1** **(01-20-2015)**

#### Case Initiation and Referral Criteria

1. **Referrals to Counsel** Service personnel in Insolvency, Compliance, LB&I, Appeals and TEGE should identify and refer to SB/SE Field Counsel offices Chapter 11 bankruptcy cases in which the corporate taxpayer has major tax liabilities or significant audit impact to items claimed on returns or which may involve significant or sensitive issues for the Service, for handling as part of the Significant Bankruptcy Case Program. See IRM 5.9.8.4.2(15), Processing Chapter 11 Bankruptcy Cases; Initial Case Review for Chapter 11; Aspects of the Initial Case Review in the Chapter 11 Case; Significant Cases and Referrals to Area Counsel, and IRM 5.9.4.14.3, Common Bankruptcy Issues; Referrals – Representing IRS in Bankruptcy Court; Referrals on Significant Bankruptcy Case Issues.

2. **Cases Without Referral**. In addition to notification from Service personnel, Field Counsel may learn of a new significant bankruptcy filing on its own through the news media. Moreover, in jurisdictions where numerous large bankruptcies are historically filed, (such as the Southern District of New York and the District of Delaware), local Insolvency groups (or local SB/SE Counsel) are responsible for checking PACER (the bankruptcy court system’s electronic database) on a frequent, periodic basis to determine if any new Chapter 11 filings qualify as significant.

3. **Coordination**. Early identification/referral allows for the required coordination of examination issues with bankruptcy procedural questions on an expedited basis. The coordination is to be achieved through a team approach with all of the Service personnel involved in the case, including Counsel. SB/SE and LB&I Field Counsel will be the principal participants in large bankruptcy coordination, because all bankruptcy cases are handled by SB/SE, but the taxpayers are most often LB&I taxpayers. Associate Chief Counsel offices will also be involved where technical issues require coordination. To facilitate coordination with and among Associate offices, a Significant Bankruptcy Case Coordinator has been designated in the Office of the Associate Chief Counsel (Procedure & Administration), Branch 5.

4. **Significant Bankruptcy Case Program Criteria**. The criteria for referral include the following:



   - Coordinated Industry Cases (CIC)

   - Taxpayers for which a coordinated Industry Specialization Program issue is present

   - Cases in which technical advice or ruling requests are pending

   - Cases involving taxpayers with assets of $50 million or more

   - All cases for which the unassessed proposed tax liability, taking into account all open tax years and pre-petition interest, may exceed $1 million or for which the outstanding assessed liability with pre-petition interest exceeds $10 million

   - All cases with potential tax liabilities for which there may be significant publicity regarding the Service

   - All cases in which a criminal tax prosecution is being considered or is pending

   - Cases that do not fall within any of the above specific criteria, but are deemed to deserve special significant case treatment and coordination by Counsel or the Service


5. **Handling by Counsel on Referral**. Immediately upon identification by Service personnel of a case that meets the significant case criteria, the responsible person must prepare a "Significant Corporate Bankruptcy Referral" form and forward it to Field Counsel. (Because of the very expedited nature of this litigation, Insolvency personnel should also notify Field Counsel of the upcoming referral by phone as well.) The bankruptcy case is to be opened as a Chapter 11 referral on receipt by Field Counsel, who should review the case to determine whether the criteria described above are present. Field Counsel should also determine if a referral concerning the debtor or a related entity has been made to another Counsel office and if so, the nature of the referral. Primarily, Field Counsel will determine if LB&I Counsel in the location where an audit may be ongoing has been involved in the substantive tax issues.

6. **Expedited Exam Determination**. Within three days of the referral, SB/SE Field Counsel should determine whether the tax issues warrant expedited examination procedures by analysis of all the facts and circumstances, including:



1. The likelihood the Service will have a significant claim in the bankruptcy case that could affect the ability of the debtor to formulate a plan of reorganization.

2. The likelihood that the majority or all of the tax issues will be agreed.

3. The state of factual development of the issues for all prepetition years.

4. The probability the debtor will end up liquidating and/or selling its assets as a going concern.

5. The existence of an Internal Revenue Code section 6402 or 6411(b) refund claim that may be subject to setoff.

6. The state of factual development of the issues for all post-confirmation tax years.

7. The existence of bankruptcy court orders limiting the examination period or bar date.

8. The likelihood of a request under Bankruptcy Code section 505(b) for determination of the tax liability of the estate.


**34.3.1.3.2** **(01-20-2015)**

#### Primary Responsibility

1. **Primary Field Counsel**. SB/SE Field Counsel with jurisdiction over cases pending in that bankruptcy court has primary responsibility for all aspects of the case. In special circumstances, SB/SE or LB&I Field Counsel in another city may request to be the primary office. Special reasons for remote bankruptcy responsibility should be compelling and can include:



1. Prior significant Field Counsel involvement in income tax issues of the taxpayer that are related to current issues.

2. The location of Examination and Appeals Office personnel with current jurisdiction over income tax issues of the taxpayer or with particularized knowledge of prior related tax examinations.

3. Where industry specialization issues are present, the location of an industry specialization team member.

4. The location of the principal place of business and/or the books and records of the taxpayer.


2. **Request for Remote Responsibility**. Within one week of Field Counsel opening a case, a memorandum designating another Counsel office as the primary office for special issues must be sent to the Area Counsel (SB/SE) for that area. If a dispute exists as to which Counsel office will act as the primary office, the memorandum must state the reasons for the dispute and the Area Counsel of the two offices will confer and decide on the primary office.


**34.3.1.3.3** **(01-20-2015)**

#### Coordination

1. **Coordination with LB&I Field Counsel**. If expedited examination procedures are warranted and an LB&I attorney is not already assigned, SB/SE Field Counsel will first contact the LB&I Associate Area Counsel for the geographic office responsible for the taxpayer who will immediately assign an LB&I attorney to work with the audit team.

2. **Counsel Memorandum**. Within three working days of receipt of the Integrated Data Retrieval System (IDRS) information, the SB/SE Field Counsel prepares a standard memorandum to be issued to the LB&I agents in the field, as well as to all other potentially interested functions within the Service. Large, corporate taxpayers often have significant pension liabilities, so TEGE should be included. In some circumstances, it may be more appropriate for this memorandum to be drafted by Counsel but issued by an LB&I manager to the audit team. In either event, this memorandum will discuss the facts and circumstances and whether they warrant expedited examination procedures. Field Counsel must conclude that expedited procedures are warranted in all corporate Chapter 11 proceedings where the unassessed proposed tax liability, taking into account all open tax years and prepetition interest, will exceed $1 million, and where the outstanding assessed liability with prepetition interest exceeds $10 million. If expedited examination procedures are not warranted, assistance by LB&I Field Counsel as to any specified issues should be offered. A copy of the memo should be forwarded to the Field Insolvency office. It should indicate that the SB/SE Field Counsel should be kept advised of the audit’s progress and any other issues that might affect the conduct of the bankruptcy. See Exhibit 34.12.1-3http://publish.no.irs.gov/getpdf.cgi?catnum=29689for a sample of the notification memorandum.

3. **Additional Content of Memorandum**. If the expedited procedures are warranted, the memorandum should also advise the audit team of the following items.



01. A coordinated team of Service personnel involved in the case must be appointed and meet (within a suggested time frame) to discuss the case, review the memorandum, and establish a plan for proceeding in the case.

02. At the meeting, an action plan detailing what is to be done, by whom, and when, will be established. The participants will create a report detailing the action to be taken and will update this report on at least a monthly basis to determine if the goals and deadlines are being met and to provide a current status of the case.

03. The audit team should be advised that other Service groups and functions should continue to handle specified appropriate issues assigned to them.

04. The audit team should be advised that in order to keep abreast of information available from the court and other creditors, bankruptcy counsel may enter an appearance in the case, where appropriate.

05. Expedited procedures for communicating with Field Counsel and the Associate offices will need to be used. In this regard, all Technical Advice Requests must notify the appropriate office that the taxpayer has filed for bankruptcy/insolvency and that the expedited examination procedures have been instituted for the taxpayer.

06. All Service personnel involved in the case should carefully document all contacts with the taxpayer in the event it becomes necessary to establish that the Service’s inability to complete its examination of the taxpayer prior to any proof of claim deadlines or hearings was due to the debtor’s inability or failure to provide information or documentation.

07. The memorandum must explain that there must be a relaxation of the procedural rules regarding appeals from 30 day letters.

08. The taxpayer must be notified in writing, with an acknowledged copy of notification included in the audit file, that the expedited procedures are in effect, that all open tax years are under audit and that the taxpayer can expect to see deviations from the normal audit procedures.

09. Field Counsel will review all proposed notices of deficiency to the taxpayer and related entities.

10. All settlements of tax years or specific issues must be reviewed by Field Counsel to evaluate the impact of the settlement on all open tax years. In this regard, the scope of Field Counsel’s review of proposed settlements by the Appeals Division is not greater than for docketed work.

11. In order to properly file proofs of claim, control potential litigation, and coordinate with the Department of Justice, Field Counsel must be kept advised of all matters affecting the debtor by whatever part of the organization is taking action with respect to the taxpayer.


4. **Coordination with Associate Chief Counsel Offices**. Because of the complexity of the issues involved in many large bankruptcy cases, Field Counsel may require formal or informal legal advice from the various Associate Chief Counsel Offices. To facilitate coordination with these offices, Field Counsel may contact the Significant Bankruptcy Case Coordinator in the Office of the Associate Chief Counsel (Procedure & Administration), Branch 5, who will direct Field Counsel to technical experts in the National Office and coordinate the response of several offices as necessary.

5. **New or Novel Issues**. Field Counsel will refer any novel or significant questions of the interpretation of the Bankruptcy Code to the Office of the Associate Chief Counsel (Procedure & Administration), Branch 5 through the Significant Bankruptcy Case Coordinator.

6. **Pension Underfunding Penalties**. Any bankruptcy case with I.R.C. § 4971 tax issues must be coordinated with the Significant Bankruptcy Case Coordinator. The Service will argue in appropriate cases that the pension underfunding penalties arising under section 4971 that relate to post-petition pension obligations are entitled to administrative expense priority under 11 U.S.C. § 503(b)(1)(A).

7. **Certain Motions to Sell**. Motions to sell or otherwise dispose of a significant or material portion of the debtor’s assets for consideration other than cash should be forwarded to the Significant Bankruptcy Case Coordinator for coordination with the Office of Associate Chief Counsel (Corporate). Such transactions create complex substantive tax issues.


**34.3.1.3.4** **(08-11-2004)**

#### Proof of Claim

1. **Request for Extension of the Bar Date**. Before a request to extend the bar date is made, Field Counsel should make a realistic assessment of how much time is needed as well as an assessment of any negative consequences that might flow from the failure to make such a request or the failure to meet the extended deadline if granted. A decision should be made as soon as possible as to whether the court should be approached to discuss the complexities of the tax examination and the time frames necessary for the filing of an accurate claim. The decision should be based on several factors, such as:



   - The willingness of debtor’s counsel, and possibly other creditors, to concur with the Government’s request

   - The current and historical record of cooperation from the debtor

   - The disposition of the bankruptcy judge toward the Service

   - The significance of tax claims in the case vis-a-vis other creditors

   - The complexity of the tax issues

   - Any other relevant considerations


2. If the decision is made to seek an extension, Counsel should be candid with the court about the problems involved in finalizing the tax claim.

3. **Liabilities Listed on the Proof of Claim**. To the extent possible the proof of claim should be specific with respect to the types of tax, the amounts owed, and the periods to which those amounts relate.



1. Every effort should be made to ensure that the initial claims filed are as accurate and complete as possible even if estimates are necessary. To the extent that estimates are made, they should be based on historical amounts or partial development of the issue under audit.

2. In order to avoid the potential of misleading the bankruptcy court, any claim that is still under audit should be so labeled.


**34.3.1.3.5** **(01-20-2015)**

#### Disclosure Statement and Plan Review

1. **Substantive Tax Issues**. The transactions contemplated in Chapter 11 plans in large bankruptcy cases often create complex substantive tax issues involving the use of certain tax attributes, such as net operating losses, after the reorganization. Whether and in what amount or form the tax attributes survive may have significant tax effects. Examples of these issues include certain acquisitions under I.R.C. § 269, limitations on net operating loss carry forwards under I.R.C. § 382, and income from discharge of indebtedness under I.R.C. § 108. These issues are difficult to identify without a detailed knowledge of the substantive tax law and the proposed bankruptcy transactions. The following procedures provide a mechanism whereby substantive tax issues can be identified during the plan review process and archived for use by examiners in future audits of the taxpayer. If the principal purpose of the plan is the avoidance of taxes, the Service could object to the plan under 11 U.S.C. § 1129(d). See CCDM 34.3.1.1.4(6), Procedures in Bankruptcy Cases; General Procedures in Bankruptcy Cases; Chapter 11 Case Procedures; Plan Seeking to Avoid Taxes. See also CCDM Exhibit 35.11.1-1, Issues Requiring Associate Office Review

2. **Field Counsel Review and Coordination of Plan Documents**. Field Counsel assigned to the bankruptcy case will initially review the disclosure statement and plan and identify any potential issues, including substantive tax issues raised by the transactions contemplated in the plan. If issues are found that require the assistance of an Associate Chief Counsel office, Field Counsel will contact the Significant Bankruptcy Case Coordinator in the Office of the Associate Chief Counsel (Procedure & Administration), Branch 5, who will coordinate the issue with the appropriate technical subject matter experts within the various Associate Chief Counsel offices. LB&I Field Counsel will be invited to review the plan if there are issues related to audit issues on which LB&I Field Counsel has previously provided assistance.



### Note:



Some plans ostensibly provide for payment of the Service’s claims but, as a result of the transactions contemplated in the plan, result in a situation where the entity that owes the tax (past or future) has no assets to pay the liabilities. Counsel should review the plan to ensure that liabilities that should be paid under the plan will in fact be paid.

3. **Referral of Plan Documents in Certain Cases**. To assist Field Counsel in identifying and evaluating significant substantive tax issues, plan and disclosure statements meeting the case criteria described below should be immediately referred to the Significant Bankruptcy Case Coordinator for expedited review by technical subject matter experts in the Associate Chief Counsel offices. Bankruptcy cases with these criteria are likely to involve significant tax issues and immediate referral of these plans and disclosure statements will give technical subject matter experts additional time to evaluate these voluminous documents. Therefore, disclosure statements and plans worked under the Significant Bankruptcy Case Program should be forwarded to the Significant Bankruptcy Case Coordinator in all cases in which:



   - The debtor has a $100 million or more in gross assets

   - The debtor filed a motion to restrict or prohibit the sale or other disposition of its stock

   - The debtor filed a motion to sell or otherwise dispose of a significant or material portion of its assets for consideration other than cash

   - The plan provides for a significant delay between plan confirmation and debt discharge (for example, debts are discharged after the close of the tax year when plan confirmation occurs)

   - The debtor filed a prepackaged plan

   - The plan provides for the creation of a liquidating trust and the terms of the plan do not conform to the requirements for a liquidating trust in Revenue Procedure 94-45 (for example, the plan and disclosure statement do not explain whether any tax liability to the bankruptcy estate will result from the transfer to the trust and how the liability will be paid, or how any income later earned by the trust will be allocated and paid)

   - The disclosure statement or plan indicates that there are foreign tax claims against the debtor

   - The plan provides for the termination of a qualified pension plan

   - The disclosure statement or plan indicates that the debtor has experienced a 20% or greater workforce reduction after one year before the bankruptcy petition was filed

   - The debtor proposes to pay off a previously unpaid pension contribution

   - The debtor failed to meet minimum funding obligations for its pension plans or proposes that minimum pension funding obligations will not be met, or

   - The plan anticipates a reduction of employment taxes based upon a substantial recharacterization of workforce relationships, or wage compensation, with no indication of a sufficient change in the underlying facts to support such recharacterization.


4. **Pension Penalties and Certain Motions to Sell**. As indicated in CCDM 34.3.1.3.3(6) and (7), Procedures in Bankruptcy Cases; Significant Bankruptcy Case Program; Coordination; Pension Underfunding Penalties; Certain Motions to Sell, cases with pension underfunding penalties under I.R.C. § 4971, and motions to sell or otherwise dispose of a significant or material portion of the debtor’s assets for consideration other than cash, should also be referred to the Significant Bankruptcy Case Coordinator.

5. **Send Plan by E-mail**. Whenever possible, the disclosure statements, plans, and motions should be downloaded from PACER and sent to the Significant Bankruptcy Case Coordinator via e-mail. The e-mail should indicate the basis for the referral to the National Office and the relevant deadlines in the bankruptcy case.

6. **Plan Review Memoranda**. If an Associate Chief Counsel office has identified issues that should be addressed in future audits, it will issue a memorandum to the LB&I bankruptcy contact in Ogden with a copy to the SB/SE Field Counsel. Both memoranda will be characterized as an “information report,” which will be reflected on the Service’s database and used during future audits.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part34/irm_34-003-001#addtoany "Show all")

A2A