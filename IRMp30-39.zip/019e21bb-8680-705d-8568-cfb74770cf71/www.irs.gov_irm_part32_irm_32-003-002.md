---
url: "https://www.irs.gov/irm/part32/irm_32-003-002"
title: "32.3.2 Letter Rulings | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part32/irm_32-003-002#main-content)

- 32.3.2  [Letter Rulings](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414976153872)
  - 32.3.2.1  [Authority to Issue Letter Rulings](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414976152512)
  - 32.3.2.2  [Refusal to Rule or Deferral of Letter Ruling Pending Issuance of Published Guidance](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414976158848)
  - 32.3.2.3  [General Procedures for Handling Requests for Letter Rulings](https://www.irs.gov/irm/part32/irm_32-003-002#idm140415003062608)
    - 32.3.2.3.1  [Acknowledgment and Assignment](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414976148176)
    - 32.3.2.3.2  [Processing Letter Rulings](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414975589152)
      - 32.3.2.3.2.1  [Processing Accounting Method and Accounting Period Change Letters](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414976164272)
      - 32.3.2.3.2.2  [Caveats to be Included in Letter Rulings, Technical Advice Memoranda, and Accounting Method and Period Change Letters](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414976162672)
        - 32.3.2.3.2.2.1  [Other Potential Caveats](https://www.irs.gov/irm/part32/irm_32-003-002#idm140415003072032)
    - 32.3.2.3.3  [Use of Citations](https://www.irs.gov/irm/part32/irm_32-003-002#idm140415003067488)
    - 32.3.2.3.4  [Changes in Position](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414976013856)
    - 32.3.2.3.5  [Nonretroactivity under Section 7805(b)(8)](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414976010800)
      - 32.3.2.3.5.1  [General](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414976002432)
      - 32.3.2.3.5.2  [Means of Revoking or Modifying a Previously Issued Letter Ruling](https://www.irs.gov/irm/part32/irm_32-003-002#idm140415002909504)
      - 32.3.2.3.5.3  [Processing Section 7805(b)(8) Requests Involving Determination Letters](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414975150144)
    - 32.3.2.3.6  [File Memoranda](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414975142288)
    - 32.3.2.3.7  [Case History, Form 9718](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414975136816)
  - 32.3.2.4  [Conferences](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414975132240)
    - 32.3.2.4.1  [Scheduling and Conducting a Conference](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414975127936)
    - 32.3.2.4.2  [Pre-Submission Conferences](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414975120816)
    - 32.3.2.4.3  [Conference Procedures](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414975113392)
  - 32.3.2.5  [Coordination with Other Offices](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414975105120)
    - 32.3.2.5.1  [Processing Requests Containing Two or More Issues (Multi-Issue Requests)](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414975098560)
      - 32.3.2.5.1.1  [Processing Multi-Issue Requests in One Office](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414975092016)
      - 32.3.2.5.1.2  [Severance of Issues](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414975089424)
    - 32.3.2.5.2  [Resolving Differences](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414973250384)
  - 32.3.2.6  [Coordination with Other Federal Departments and Agencies](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414973244896)
    - 32.3.2.6.1  [Employment Tax Coordination with Social Security Administration](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414973240912)
    - 32.3.2.6.2  [Employment Tax Coordination with Railroad Retirement Board](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414973234800)
  - 32.3.2.7  [Referral of Copies of Letter Rulings to the Appropriate Service Official](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414973228240)
    - 32.3.2.7.1  [Notifying the Service to Update Taxpayer’s Account Regarding Consent to Extend Time to Assess Tax in Conjunction with the Issuance of a Letter Ruling](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414973221616)
  - 32.3.2.8  [Representation of Taxpayers](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414973209552)
    - 32.3.2.8.1  [Authority](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414973192832)
    - 32.3.2.8.2  [Authorized Representatives](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414973190992)
    - 32.3.2.8.3  [Power of Attorney and Declaration of Representative (Form 2848) or Tax Information Authorization (Form 8821)](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414973184432)
      - 32.3.2.8.3.1  [General Guidelines](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414973176592)
      - 32.3.2.8.3.2  [Specific Requirements](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414973167120)
      - 32.3.2.8.3.3  [Examples](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414973156208)
    - 32.3.2.8.4  [Acceptable Power of Attorney or Other Third Party Authorizations](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414973150512)
    - 32.3.2.8.5  [Deficient Power of Attorney or Other Authorization](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414973146672)
    - 32.3.2.8.6  [Signature on Letters Concerning Powers of Attorney](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414973144672)
    - 32.3.2.8.7  [Copy of a Power of Attorney or a Tax Information Authorization](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414975084112)
  - Exhibit  32.3.2-1  [Letter 1690](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414975082304)
  - Exhibit  32.3.2-2  [Letter 1690 (Version 2): Accounting Method Change Letter](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414975080208)
  - Exhibit  32.3.2-3  [Letter Ruling to Taxpayer](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414975078080)
  - Exhibit  32.3.2-4  [Letter Ruling to Taxpayer’s Representative](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414975075616)
  - Exhibit  32.3.2-5  [Sample Format for Recommendation of Application or Rejection of Section 7805(b)(8) Relief](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414975073040)
  - Exhibit  32.3.2-6  [Conference Report](https://www.irs.gov/irm/part32/irm_32-003-002#idm140414975040272)

# Part 32. Chief Counsel Directives Manual Published Guidance and Other Guidance to Taxpayers

# Chapter 3. Letter Rulings, Information Letters, and Closing Agreements

# Section 2. Letter Rulings

* * *

## 32.3.2 Letter Rulings

#### Manual Transmittal

August 02, 2022

#### Purpose

(1) This transmits revised CCDM 32.3.2, Letter Rulings, Information Letters, and Closing Agreements; Letter Rulings.

#### Background

CCDM 32.3.2 is revised as follows:

- Amended CCDM 32.3.2.7, Referrals of Copies of Letter Rulings to the Appropriate Service Official, provides updated contact information for the appropriate Service official to receive copies of issued letter rulings, including all Change in Accounting Method (CAM) correspondence, and other documents and information pertaining to any taxpayer letter ruling request.

- New CCDM 32.3.2.7.1, Notifying the Service to Update Taxpayer’s Account Regarding Consent to Extend Time to Assess Tax in Conjunction with the Issuance of a Letter Ruling, provides procedures for notifying the Service that a taxpayer consented to extend the statutory period of time to assess tax in conjunction with the issuance of a letter ruling. This will ensure the taxpayer’s IRS account is updated to reflect the extended assessment statute end date.


#### Material Changes

(1) CCDM 32.3.2.7 is amended to add electronic hyperlinked access through the CCDM to the current listing of Service officials by operating division who should receive copies of the issued letter ruling, including all Change in Accounting Method (CAM) correspondence.

(2) New CCDM 32.3.2.7.1 is added to provide procedures the Office of Chief Counsel will follow to notify the Service that a taxpayer consented to extend the statutory period of time to assess tax in conjunction with the issuance of a letter ruling. The new section identifies the W&I resource mailbox that will receive the notification as well as what information and documents Chief Counsel is required to provide to the Service.

(3) In addition to the earlier updates above, the e-mail address under CCDM 32.3.2.7.1(3) was corrected due to an earlier typo.

#### Effect on Other Documents

CCDM 32.3.2, dated October 6, 2017, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(08-02-2022)

Ashton P. Trice

Deputy Associate Chief Counsel

(Procedure & Administration)

**32.3.2.1** **(07-09-2014)**

### Authority to Issue Letter Rulings

1. The Associate Chief Counsel (Corporate), the Associate Chief Counsel (Financial Institutions & Products), the Associate Chief Counsel (Income Tax & Accounting), the Associate Chief Counsel (International), the Associate Chief Counsel (Passthroughs & Special Industries), the Associate Chief Counsel (Procedure & Administration), and Division Counsel/Associate Chief Counsel (TEGE) (collectively, the Associate Offices) generally will issue a letter ruling to a taxpayer in response to the taxpayers’ written inquiry about its status for tax purposes or the tax effects of its acts or transactions. See Revenue Procedure 2013-1 (or successor revenue procedure) for nonexclusive lists of circumstances in which a letter ruling will be issued and will not be issued.

2. Requests for letter rulings presenting two or more issues under the jurisdiction of different Associate Offices and requests presenting issues dependent on the prior or contemporaneous determination of another issue or issues not presented in the request under the jurisdiction of another office require coordination and joint action of the Associate Offices concerned. See **_CCDM 32.3.2.5_**http://publish.no.irs.gov/getpdf.cgi?catnum=39010, _Coordination with Other Offices_, for procedures for coordinating with other Associate Offices.


**32.3.2.2** **(07-09-2014)**

### Refusal to Rule or Deferral of Letter Ruling Pending Issuance of Published Guidance

1. Counsel employees should review requests for letter rulings at the earliest possible date to identify those requests containing technical issues on which the Service will not issue a revenue ruling, exercise sound judgment and identify circumstances when a letter ruling should not be issued. See Revenue Procedure 2013-1 (or successor revenue procedure) for lists of circumstances in which a letter ruling will be issued and will not be issued. These lists are nonexclusive and Counsel employees should exercise sound judgment to identify other circumstances when a letter ruling should not be issued, raising such circumstances with management.



### Note:



When developing a Service position on a particular issue, the initiating Associate Office must consider the possible effect of section 7805(b)(8), regarding retroactivity. Publication of the Service position prior to or concurrently with the issuance of an individual response may simplify the resolution of nonretroactivity questions.

2. For example, the following are situations in which it is appropriate to publish the Service position in published guidance prior to, or concurrently with, the issuance of a letter ruling.



> **_Situation 1:_** A taxpayer requests a letter ruling on a situation the tax treatment of which obviously would be a matter of concern to other taxpayers. Uniform application of the Service position will be promoted by first publishing a revenue ruling. This is especially desirable in any situation in which competitive advantages or disadvantages would result from a lack of uniform application.





> **_Situation 2:_** An inquiry is received from a person, who describes certain related situations with respect to which a statement of Service position is needed. This person, however, is not the taxpayer with respect to all of the situations involved. In this case, the initial effort should be directed toward processing a revenue ruling and issuing a response to the inquiry that simply refers to the published ruling (a copy of which could be enclosed) with any additional comments that are pertinent.





> **_Situation 3:_** A trade association requests a letter ruling on an issue in which some or all of its members are interested. Since the Service’s established procedure is to issue a letter ruling only to a taxpayer or authorized representative, it is not appropriate to issue a letter ruling to the trade association, even though a need for Service guidance is recognized. Instead, a revenue ruling should be recommended. A letter should be sent to the trade association informing the association of the Service’s refusal to rule on the matter before a position of the Service is established.


**32.3.2.3** **(07-09-2014)**

### General Procedures for Handling Requests for Letter Rulings

1. The Office of Chief Counsel generally will respond to requests for letter rulings within 180 days of the date of receipt. Branch personnel must notify the Associate Chief Counsel or Deputy Associate Chief Counsel when the branch determines that a response will not be provided within 180 days of the date of receipt. This notice generally should be provided no later than 165 days from receipt of the request for letter ruling.

2. The procedures set forth in the following paragraphs apply to all requests for letter rulings, including those submitted by collectors of collected taxes. Additionally, except as otherwise provided, requests for accounting method and accounting period change letters will be processed in the same manner and will be subject to the same procedures as letter ruling requests.

3. Requests for letter rulings are to be submitted with the applicable fee in the form required by the Revenue Procedure 2013-1 (or successor revenue procedure) to the Internal Revenue Service at the address shown in Revenue Procedure 2013-1 (or successor revenue procedure).


**32.3.2.3.1** **(07-09-2014)**

#### Acknowledgment and Assignment

1. On receipt of a request for a letter ruling, the Docket, Records & User Fee Branch, Legal Processing Division, ensures that the letter ruling request includes all required documents, including the applicable user fee. Requests that are complete are controlled by the Docket, Records & User Fee Branch on CASE-MIS and an acknowledgment letter is mailed to the taxpayer. After mailing the acknowledgment letter, the Docket, Records & User Fee Branch will forward the letter ruling request to the appropriate Associate Office for action.

2. On receipt of the request for a letter ruling from the Docket, Records & User Fee Branch, the Associate Office will review the file and confirm that the primary issue raised in the request is within the Associate Office’s jurisdiction. The Associate Office will assign the request to a branch or docket attorney and reviewer. If the Associate Office assigns the request to a branch, the branch chief, or delegate, will assign the request to a docket attorney and reviewer.

3. The assignment of letter rulings must comply with the policy provided for in this section. It is important that the public is confident that the letter ruling program is administered fairly and impartially. The policy is intended to foreclose the risk and the potential perception that practitioners can unduly influence the process for assigning a case to a specific counsel attorney. This policy also provides flexibility for each Associate Office to implement the requirements of the policy in a manner that accommodates that office’s unique needs, resources, and circumstances.

4. Requirement 1: Each Associate Office must adopt one or more safeguards on the pre-submission conference process to minimize the ability of a practitioner to use the process as a tactic to direct the resulting request for letter ruling to a particular attorney. In all cases where a pre-submission conference is granted, the practitioner must be advised that any resulting request for letter ruling will be assigned based on the needs of the office and that the attorney/reviewer team assigned to the pre-submission conference will not necessarily be the team assigned to the letter ruling.



> Example 1. Where branches have concurrent subject matter jurisdiction, a procedure under which all requests for pre-submission conferences are forwarded to the Associate Office’s front office and then assigned to the branches using a rotational (“next-in-line”) or random assignment process is an appropriate safeguard.





> Example 2. Where branches have concurrent subject matter jurisdiction, a procedure under which attorneys from more than one branch or the front office participate in each pre-submission conference is an appropriate safeguard.





> Example 3. Where branches have concurrent subject matter jurisdiction, a procedure under which an attorney’s ability to accept a request for a pre-submission conference is governed by a formula established and monitored by the Associate Office’s front office that limits assignments from a particular practitioner and/or firm is also an appropriate safeguard.





> Example 4. Where branches do not have concurrent subject matter jurisdiction, or in cases where pre-submission conference requests are received directly by a branch, a procedure under which the Branch Chief or the Associate Office’s front office management must approve the attorney assigned to the presubmission conference is an appropriate safeguard. In approving the assignment to the attorney, the Branch Chief or front office management should take into account the number of pre-submission conferences the attorney has held with the same practitioner and/or firm, along with other relevant considerations, such as the specialized expertise of the attorney and the need to balance workload among attorneys.

5. Requirement 2: The process that each Associate Office uses to assign requests for letter rulings must allow for management control and monitoring of the number of letter ruling requests from a particular practitioner that are assigned to each attorney.



1. In the case of a letter ruling request that was not preceded by a pre-submission conference, management must assure that safeguards similar to those above for pre-submission requests are followed.



      ### Example:



      A letter ruling assignment process that assigns ruling requests to branches following a rotational (“next-in-line”) process, or a process under which the Branch Chief or the Associate Office’s front office management must approve the assigned attorney, are appropriate safeguards.

2. The Associate Office’s assignment process should allow flexibility so that the mere fact that the incoming request indicates that the request was discussed with a particular attorney is not determinative as to which attorney is assigned to the letter ruling request.

3. Each Associate Office must ensure that for all letter ruling assignments, the practitioner’s name and firm have been entered into the “Filer Representative” field on TECHMIS. At the beginning of each month, CC:F&M will run a TECHMIS informational report for each Associate Office that sorts all pending letter ruling requests by name of the assigned attorney and shows the name of the practitioner.

4. When assigning letter ruling requests, the Branch Chief (or other assigning manager) must take into account prior letter ruling assignments originating from the same practitioner and/or firm. Where possible, the assigning manager should limit the number of letter ruling assignments to an attorney that originate from a single source. An office may have unique circumstances that make it unrealistic or impractical to avoid repeat assignments from a particular source (e.g., a limited number of specialized experts for a particular Code provision, or a large volume of letter ruling requests originating from a small number of practitioners or firms). This policy does not prohibit repeat assignments from the same practitioner and/or firm to a particular attorney, provided management makes such assignments based on the needs of the office.


6. Requirement 3: As an additional safeguard against the perception that a practitioner can obtain an unwarranted benefit from a particular attorney/reviewer team, each office must establish procedures for a substantive check on the holding(s) of the letter ruling to ensure that novel interpretations of the law are reviewed by others in the Associate Office prior to issuance of the letter ruling.



> Example 1. A process under which all letter rulings addressing novel issues must be shared with other branches having concurrent jurisdiction (e.g., on a 3-day review or similar process) and any disagreements handled pursuant to the office’s reconciliation procedures, is an adequate substantive check.





> Example 2. A process under which all letter rulings addressing novel issues must be briefed to one or more members of the Associate Office’s front office (e.g., through “significant item” meetings or a similar process) is an adequate substantive check.


**32.3.2.3.2** **(10-06-2017)**

#### Processing Letter Rulings

01. The following procedures apply to letter rulings, except those involving accounting method and accounting period change letters.

02. Upon receiving a request for a letter ruling, the attorney (or tax law specialist) assigned to the request should review the file for procedural and substantive completeness. The attorney should pay particular attention to whether:



    - The request has been submitted by an appropriate person

    - The requestor has properly designated a representative to handle the request

    - A conference of right is requested

    - Expeditious treatment is requested

    - Section 7805(b)(8) relief (regarding retroactivity) is requested

    - A complete statement of relevant facts and authorities is present

    - The request involves multiple issues or issues under the jurisdiction of other branches or offices



      ### Note:



      The checklist in the annual revenue procedure for letter rulings and determination letters provides a useful reference of items that must be addressed.


03. The assigned attorney should carefully analyze the request to determine whether sufficient information is furnished on which to base the ruling requested and whether the matter is one that may properly be made the subject of a letter ruling. In each case, the facts should be developed to the fullest extent necessary before preparing the letter ruling. If essential information is lacking, the attorney must request the necessary information. If the request is one in which a letter ruling will not be issued because the issue falls within a no rule area, the attorney should prepare a “no-ruling letter.” The attorney should not recite the “facts” in the “no-ruling letter.” Rather, the attorney should provide a brief statement of the issue presented in the request and cite the authority or reason for not issuing a ruling.

04. The assigned attorney or other branch representative should call the taxpayer or authorized representative if the request includes a properly executed power of attorney, within 21 calendar days after receiving the letter ruling request to discuss the procedural and, to the extent possible, substantive issues in the request. The attorney should include a notation in the file when the contact is made. If the attorney does not call the taxpayer or authorized representative within 21 days, branch personnel must notify the Associate Chief Counsel or Deputy Associate Chief Counsel that the required taxpayer contact was not made and the reason(s) that the contact was not made timely. This notification must be in writing and must be made within 5 days after the branch determines that required contact was not made timely. A copy of the notification must be placed in the legal file.

05. If the request lacks essential information, the assigned attorney will tell the taxpayer during the initial or subsequent contact that the request will be closed if the Service does not receive the information within 21 calendar days from the date of the request for additional information, unless an extension of time is granted. An extension of the 21-day period for providing additional information will be granted only if justified in writing by the taxpayer and approved by the branch reviewer. The taxpayer will be told promptly, and later in writing, of the approval or denial of the requested extension. If the extension request is denied, there is no right of appeal.

06. If the taxpayer does not submit the information requested during the initial or subsequent contact within the time provided, the letter ruling request will be closed and the taxpayer will be notified in writing. If the information is received after the request is closed, the request will be reopened and treated as a new request as of the date the information is received. The taxpayer must pay another user fee before the case can be reopened.

07. When the request for a letter ruling is accompanied by a power of attorney, the assigned attorney is responsible for determining whether the representative has complied with the Conference and Practice Requirements. See **_CCDM 32.3.2.8_**http://publish.no.irs.gov/getpdf.cgi?catnum=39010, _Representation of Taxpayers, concerning the Conference and Practice Requirements_, including the furnishing of power of attorney, tax information declaration of representative, evidence of enrollment to practice, and other matters.



    ### Note:



    Taxpayers who ask in the letter ruling request that a copy of the reply be sent to an unauthorized person should be informed that the Service will not send a copy to a person who is not an eligible representative authorized to represent the taxpayer before the IRS.

08. A letter ruling should:



    1. Fully resolve all issues presented in the request

    2. Be written in plain language to the extent that circumstances permit

    3. Be technically accurate, legally sound, and as concise as possible without sacrificing clarity

    4. Contain an appropriate explanation of the reasons for the conclusions reached

    5. Distinguish any contrary authority cited by the taxpayer if necessary to do so in support of the Service’s conclusion in the letter ruling


### Note:

This is particularly true of revenue rulings, regulations, and court decisions in which the Service has acquiesced or otherwise announced it will follow that appear to bear closely on the issue. Normally only those authorities bearing most directly on the issue need be distinguished. If helpful, any published guidance available may be enclosed.

09. Letter rulings and determination letters are addressed to the taxpayer and prepared for the signature of the official having authority to act in the matter. The closing for all letter rulings is “sincerely.”

10. After a letter ruling has been prepared and the signature package is assembled, the file is forwarded for review and signature or transmittal to the next official in the chain of review.

11. After the letter ruling is signed, the original letter ruling or determination letter is sent to the taxpayer using regular mail. The Service also will send copies of the letter ruling or determination letter to no more than two (2) authorized representatives of the taxpayer if the taxpayer checked the appropriate boxes on the Form 2848, Power of Attorney and Declaration of Representative. Copies of the letter ruling are transmitted using Letter 1690, _Exhibit 32.3.2-1_, and copies of an accounting method change letter are transmitted using Letter 1690 (Version 2), _Exhibit 32.3.2-2_.

12. A copy of the letter ruling, whether favorable or adverse, is sent to the appropriate Service official in the operating division having examination jurisdiction of the taxpayer’s return. See **_CCDM 32.3.2.7_** http://publish.no.irs.gov/getpdf.cgi?catnum=39010, _Referral of Copies of Letter Rulings to the Appropriate Service Official_.

13. After the letter ruling is sent to the taxpayer, the attorney must complete the Checksheet for Processing Private Letter Rulings, and Form 9818, Case Processing, and submit the letter ruling to the Legal Processing Division for processing. In addition, if a refund of all or part of the user fee is due, the attorney must complete the User Fee Refund Request Form and submit it to the Legal Processing Division, Docket, Records and User Fee Section, for processing.


**32.3.2.3.2.1** **(08-11-2004)**

##### Processing Accounting Method and Accounting Period Change Letters

1. \[RESERVED\]


**32.3.2.3.2.2** **(08-11-2004)**

##### Caveats to be Included in Letter Rulings, Technical Advice Memoranda, and Accounting Method and Period Change Letters

1. All letter rulings, technical advice memoranda, and accounting method and period change letters issued after the adoption of temporary or final regulations will contain one of the following caveats:



1. **Letter rulings:**"This letter ruling is directed only to the taxpayer who requested it. Section 6110(k)(3) of the Internal Revenue Code provides that it may not be used or cited as precedent."

2. **Accounting method change letters:**"The accounting method change granted in this letter ruling is directed only to the taxpayer who requested it and may not be used or cited as precedent."

3. **Accounting period approval action letters:**"The accounting period approval granted in this letter ruling is directed only to the taxpayer who requested it and may not be used or cited as precedent."


2. All letter rulings, technical advice memoranda, and accounting method and period change letters issued before the adoption of temporary or final regulations will contain one of the following caveats:



1. **Letter rulings:**"This letter ruling is directed only to the taxpayer who requested it. Section 6110(k)(3) of the Internal Revenue Code provides that it may not be used or cited as precedent. Temporary or final regulations pertaining to one or more of the issues addressed in this letter ruling have not yet been adopted. Therefore, this letter ruling will be modified or revoked by the adoption of temporary or final regulations to the extent the regulations are inconsistent with any conclusion in the letter ruling. See \[add reference to appropriate section of annual revenue procedure\]. If the taxpayer can demonstrate that the criteria in \[add appropriate section of annual revenue procedure\] are satisfied, a letter ruling is not revoked or modified retroactively except in rare or unusual circumstances."

2. **Accounting method change letters:**"The accounting method change granted in this letter is directed only to the taxpayer who requested it and may not be used or cited as precedent. Temporary or final regulations pertaining to one or more of the issues addressed in this letter have not yet been adopted. Therefore, should final or temporary regulations be adopted with positions that are inconsistent with the conclusions reached in this grant letter, the method of accounting utilized as a result of the grant letter will no longer be regarded as a proper method of accounting, and would be subject to change within the framework of sections 446 and 481 of the Code."

3. **Accounting period approval action letters for change or adoption of accounting periods:**"The accounting period approval granted in this letter is directed only to the taxpayer who requested it and may not be used or cited as precedent. Temporary or final regulations pertaining to one or more of the issues addressed in this letter have not yet been adopted. Therefore, should final or temporary regulations be adopted with positions that are inconsistent with the conclusions reached in this grant letter, the annual accounting period of utilized as a result of the grant letter will no longer be regarded as a proper period of accounting, and would be subject to change within the framework of the applicable sections of the Code, regulations, or other administrative guidance."


### Caution:

In cases in which regulations have not been adopted and for which either the answer seems reasonably certain (but not entirely free from doubt) or the answer does not seem reasonably certain, a higher level of review, which may include consultation with Treasury, may be appropriate before issuing a response. During this review, consideration will be given to whether a letter ruling is the proper form of guidance in the particular situation. For example, it could be decided that another form of guidance, such as a revenue ruling or a notice, would be more appropriate.

3. Attach copy to relevant tax returns. To remind taxpayers to attach a copy of the letter ruling to their returns, a paragraph substantially in the following language should be inserted in each letter ruling if it is anticipated that the taxpayer will receive the letter ruling before filing any return to which the transaction is relevant: "You must attach a copy of this letter ruling to any tax return to which it is relevant." See also **CCDM 32.3.1.13** http://publish.no.irs.gov/getpdf.cgi?catnum=29177, _Requirements with Respect to Submission of Requests for Letter Rulings._

4. Based on particular circumstances. It may be necessary to create a caveat to address the particular facts and circumstances of a request for letter ruling or technical advice. For example, if a letter ruling or a technical advice memorandum relies on a translation of a foreign statute to arrive at a conclusion, pertinent portions of the translation should be incorporated in the body of the ruling or technical advice or attached as an exhibit with a caveat, as follows: "This letter ruling \[technical advice memorandum\] is based on a translation of a foreign statute supplied by the taxpayer and its application is conditional on the accuracy of such translation. The Internal Revenue Service has not independently verified the accuracy of the translation supplied by the taxpayer."


**32.3.2.3.2.2.1** **(08-11-2004)**

###### Other Potential Caveats

1. The following caveats may be used as appropriate.



1. The information contained in the letter ruling is based on the information and representations submitted by the taxpayer and accompanied by a penalty of perjury statement executed by an appropriate party. While this office has not verified any of the material submitted in support of the request for ruling, it is subject to verification on examination.

2. Except as specifically set forth above, no opinion is expressed or implied concerning the federal tax consequences of the proposed transaction under any other provision of the Code or regulations.

3. Enclosed is a copy of the letter ruling showing the deletions proposed to be made when the letter is disclosed under section 6110 of the Code.

4. In accordance with the power of attorney on file with this office, a copy of this letter is being sent to the taxpayer \[taxpayer’s representative\].


**32.3.2.3.3** **(08-11-2004)**

#### Use of Citations

1. Attorneys should use citations that are consistent with the Chief Counsel style requirements.


**32.3.2.3.4** **(08-11-2004)**

#### Changes in Position

1. If in connection with the preparation of a letter ruling, a change in Service position or in a prior interpretation is involved, see the procedures set out in **CCDM 33.2.1.4** http://publish.no.irs.gov/getpdf.cgi?catnum=29146, _Change in Position_.


**32.3.2.3.5** **(08-11-2004)**

#### Nonretroactivity under Section 7805(b)(8)

1. Pursuant to section 7805(b)(8), it is within the discretion of the Commissioner or the Commissioner’s delegate to prescribe the extent, if any, to which any letter ruling (or determination letter) will be applied without retroactive effect.

2. A request for letter ruling may contain a request for relief under section 7805(b)(8) in the event the Service proposes to issue a letter ruling adverse to the taxpayer’s request. See **_CCDM 32.3.2.3.5.1_**http://publish.no.irs.gov/getpdf.cgi?catnum=39010, _General_.

3. Relief under section 7805(b)(8) may also be requested when the Service revokes or modifies a previously issued letter ruling. See **_CCDM 32.3.2.3.5.2_**, _Means of Revoking or Modifying a Previously Issued Letter Ruling_.

4. Special procedures apply when section 7805(b)(8) relief is requested in connection with the modification or revocation of a determination letter. See**_CCDM 32.3.2.3.5.3_**, _Processing Section 7805(b) Requests Involving Determination Letters_.


**32.3.2.3.5.1** **(07-09-2014)**

##### General

1. If a letter ruling is revoked or modified, the revocation or modification applies to all open years unless the Commissioner or the Commissioner’s delegate exercises the discretionary authority under section 7805(b) to limit the retroactive effect of the revocation or modification.



### Note:



In ****Delegation** Order No. 30–1**http://publish.no.irs.gov/getpdf.cgi?catnum=39625, _Application of Rulings without Retroactive Effect_, (in IRM 1.2.53.2 ), the Commissioner authorized the Associate Chief Counsel and Division Counsel/Associate Chief Counsel (TEGE) to prescribe the extent, if any, to which any letter ruling issued under their respective jurisdiction is applied without retroactive effect.

2. A request to limit the retroactive effect of a letter ruling must be in the general form of, and meet the requirements for, a letter ruling request and comply with the annual revenue procedure for letter rulings. A request for relief under section 7805(b)(8) may be made either at the time a request is submitted or at any time before the letter ruling is issued.

3. A taxpayer may request a conference on the application of section 7805(b)(8) in accordance with the provisions of the annual revenue procedure for letter rulings.

4. Whenever the question of nonretroactive application under section 7805(b)(8) is considered, the following additional procedures apply.



1. When recommending the nonretroactive application of any letter ruling, the initiating branch shall prepare a memorandum explaining the basis for the recommendation and requesting the approval of the appropriate Associate Chief Counsel or Division Counsel/Associate Chief Counsel (TEGE). If there has been any question whether the extent of the nonretroactive application should be different from that recommended, the memorandum shall identify the alternatives considered and explain the reasons for not recommending the alternatives. The memorandum includes a recommendation and date line for the branch, a concurrence and date line for the Assistant Chief Counsel (when appropriate), and an approval and date line for the appropriate Associate Chief Counsel or Division Counsel/Associate Chief Counsel (TEGE).

2. If it is recommended that section 7805(b) relief should not be granted, the initiating branch will prepare a memorandum to that effect. The memorandum includes a recommendation and date line for the branch and an approval and date line for the appropriate Associate Chief Counsel or Division Counsel/Associate Chief Counsel (TEGE).

3. These memoranda are prepared in the format shown in Exhibit 32.3.2-5 and forwarded to the appropriate Associate Chief Counsel or Division Counsel/Associate Chief Counsel (TEGE) for approval or rejection.


5. The letter rulings involving cases where the application of section 7805(b)(8) is considered are generally prepared for the signature of the initiating office.


**32.3.2.3.5.2** **(07-09-2014)**

##### Means of Revoking or Modifying a Previously Issued Letter Ruling

1. Unless it was part of a closing agreement, a letter ruling found to be in error or not in accord with the current views of the Service may be revoked or modified. If a letter ruling is revoked or modified, the revocation or modification applies to all open years unless the Commissioner or the Commissioner’s delegate exercises the discretionary authority under section 7805(b)(8) to limit the retroactive effect of the revocation or modification.

2. Revocation or modification of a letter ruling may be made by any of the events specified in **CCDM 32.3.1.6.1** http://publish.no.irs.gov/getpdf.cgi?catnum=29177, _May be Revoked or Modified if Found to be in Error_. Consistent with these provisions, if a letter ruling relates to a continuing action or a series of actions, the ruling will ordinarily be applied until one of the events described in CCDM 32.3.1.6.1 occurs or until it is specifically withdrawn. Publication of a notice of proposed rulemaking will not affect the application of any letter ruling under these procedures.



### Caution:



When a letter ruling that concerns a continuing transaction is modified or revoked by, for example, a subsequent revenue ruling, a letter ruling request to limit the retroactive effect of the modification or revocation of the letter ruling must be made before the examination of the return that contains the transaction that is the subject of the letter ruling request.

3. When the Service reconsiders a favorable letter ruling previously issued to a taxpayer that will not require a change to a revenue ruling or a temporary or final regulation, the taxpayer must be notified in writing that the letter ruling is being reconsidered and, therefore, is withdrawn. The written notification may be preceded by a telephone call to the taxpayer or the taxpayer’s representative (so long as the power of attorney is still valid), or both, to alert them to the withdrawal of the letter ruling. If the final decision is adverse, the taxpayer will be permitted to request relief under section 7805(b)(8).



### Note:



If a letter ruling is revoked by letter with retroactive effect, the letter will, except in fraud cases, state the grounds upon which the revocation is being made and the reasons why the revocation is being applied retroactively.





### Caution:



Any case containing unusual circumstances that suggest that the letter ruling is not to be withdrawn immediately is to be brought to the attention of the appropriate Associate Chief Counsel or Division Counsel/Associate Chief Counsel (TEGE). See **CCDM 32.3.1.13.3**, htp://publish.no.irs.gov/getpdf.cgi?catnum=29177, _Effect of Section 6110 on Letter Rulings_, for section 6110 considerations.

4. Except in rare or unusual circumstances, the revocation or modification of a letter ruling will not be applied retroactively to the taxpayer for whom the letter ruling was issued or to a taxpayer whose tax liability was directly involved in the letter ruling if the conditions specified in **CCDM 32.3.1.6.3** http://publish.no.irs.gov/getpdf.cgi?catnum=29177, _Not Otherwise Generally Revoked or Modified Retroactively_, are met.

5. When a revenue ruling has the effect of modifying or revoking a letter ruling previously issued to the taxpayer or when the Service notifies the taxpayer of a change in position that will have the effect of revoking or modifying a prior letter ruling, the taxpayer may request relief under section 7805(b)(8) in the form of a separate request for letter ruling. When such notice is given during the course of an examination of the taxpayer’s return or during the consideration of the return by an appeals office, a request to limit the retroactive effect of the modification or revocation of a letter ruling must be made in the form of a request for technical advice. See **CCDM 33.2.2**http://publish.no.irs.gov/getpdf.cgi?catnum=29148, _Requests for Technical Advice and Technical Expedited Advice_.

6. See **CCDM 32.3.1.6.3** http://publish.no.irs.gov/getpdf.cgi?catnum=29177, _Not Otherwise Generally Revoked or Modified Retroactively_, for the nonretroactive application of a revocation or modification of a letter ruling issued on a particular transaction.

7. See**CCDM 32.3.1.6.4** http://publish.no.irs.gov/getpdf.cgi?catnum=29177, _Retroactive Revocation to a Continuing Transaction_, for the nonretroactive application of a revocation or modification of a letter ruling covering a continuing action or a series of actions.

8. A letter ruling holding that the sale or lease of a particular article is subject to the manufacturer’s excise tax or the retailer’s excise tax may not retroactively revoke or modify an earlier letter ruling holding that the sale or lease of the article was not taxable, if the taxpayer to whom the letter ruling was issued, in reliance upon the earlier letter ruling, parted with possession or ownership of the article without passing the tax on to the customer. Section 1108(b), Revenue Act of 1926. See also **CCDM 32.3.1.6.5** http://publish.no.irs.gov/getpdf.cgi?catnum=29177, _Generally not Retroactively Revoked or Modified if Related to Sale or Lease Subject to Excise Tax_.

9. A taxpayer is not protected against the retroactive revocation or modification of a letter ruling under the circumstances described in **CCDM****32.3.1.6.6** http://publish.no.irs.gov/getpdf.cgi?catnum=29177, _May be Revoked or Modified When Transaction is Entered into Before the Issuance of the Letter Ruling_.


**32.3.2.3.5.3** **(10-25-2011)**

##### Processing Section 7805(b)(8) Requests Involving Determination Letters

1. Determination letters are written statements issued by a director that apply the previously announced principles and precedents to specific sets of facts. In the case of a determination letter that a director proposes to modify or revoke, the taxpayer to whom the determination letter has been issued may request that the appropriate Associate Chief Counsel or Division Counsel/Associate Chief Counsel (TEGE) exercise the discretionary authority under section 7805(b)(8) to limit the retroactive effect of any revocation or modification of the determination letter.



### Note:



A director has not been delegated authority under Section 7805(b)(8) to limit the modification or revocation of a determination letter. See **Delegation Order 7–1**http://publish.no.irs.gov/getpdf.cgi?catnum=39615, _Employee Plans Determination and Revocation Letters; Prohibited Transactions; Amendment of Employee Plans; and Examination Reports_, in IRM 1.2.46.2.

2. The taxpayer’s request must be in the form of, and meet the general requirements for a technical advice request.

3. The taxpayer has a right to a conference to the same extent as does any taxpayer who is the subject of a technical advice request. See **CCDM****33.2.2** http://publish.no.irs.gov/getpdf.cgi?catnum=29148, _Requests for Technical Advice and Technical Expedited Advice_.


**32.3.2.3.6** **(08-11-2004)**

#### File Memoranda

1. When a request for a letter ruling presents a particularly difficult question of law a memorandum may be prepared for reviewing officials that discusses the authorities (including court cases and previous determinations by the Service) and the reasoning supporting the initiator’s conclusion that are not included in the proposed reply to the request. These memoranda may be appropriate in borderline cases where there does not appear to be any clear precedent.

2. If a tentative conclusion is reached in a current letter ruling case that conflicts with a prior conclusion reached on the same issue, a file memorandum explaining the different interpretation should be prepared, and the conflict should be brought to the attention of the appropriate Associate Chief Counsel or Division Counsel/Associate Chief Counsel (TEGE) for resolution. A copy of the memorandum should be retained for the letter ruling file.

3. The memorandum in both (1) and (2) above should include a discussion of whether it may be more appropriate to use a different form of guidance. See Caution at **CCDM 32.3.2.3.5.2(2)**http://publish.no.irs.gov/getpdf.cgi?catnum=39010, _Means of Revoking or Modifying a Previously Issued Letter Ruling_.


**32.3.2.3.7** **(10-25-2011)**

#### Case History, Form 9718

1. See **CCDM 30.9.1.2**http://publish.no.irs.gov/getpdf.cgi?catnum=29712, _Case History Sheets_, for the use of **Form 9718**http://publish.no.irs.gov/getpdf.cgi?catnum=21154, _Case History_.


**32.3.2.4** **(08-11-2004)**

### Conferences

1. The following applies to all conferences (including pre-submission conferences) held in Chief Counsel in connection with requests for letter rulings and technical advice memoranda.

2. A taxpayer may request a conference regarding a letter ruling request. The taxpayer is entitled, as a matter of right, to only one conference except as provided.

3. The Associate Office will offer the taxpayer an additional conference if, after the conference of right, an adverse holding is proposed, but on a new issue, or on the same issue but on different grounds from those discussed at the first conference. There is no right to another conference when a proposed holding is reversed at a higher level with a result less favorable to the taxpayer, if the grounds or arguments on which the reversal is based were discussed at the conference of right.

4. The limit on the number of conferences to which a taxpayer is entitled does not prevent the Associate Office from offering additional conferences, including conferences with an official higher than the branch level, if the Associate Office decides they are needed. These conferences are not offered as a matter of course simply because the branch has reached an adverse decision. In general, conferences with higher level officials are offered only if the Associate Office determines that the case presents significant issues of tax policy or tax administration and that the consideration of these issues would be enhanced by additional conferences with the taxpayer.


**32.3.2.4.1** **(08-11-2004)**

#### Scheduling and Conducting a Conference

1. A taxpayer may request a conference regarding a letter ruling request. Normally, a conference is scheduled only when the Associate Office considers it to be helpful in deciding the case or when an adverse decision is indicated. If conferences are being arranged for more than one request for a letter ruling involving the same taxpayer, they will be scheduled so as to cause the least inconvenience to the taxpayer. A taxpayer who wants to have a conference on the issue or issues involved should indicate this in writing when, or soon after, filing the request.

2. The conference is normally held at the branch level and is attended by a person who has the authority to sign the letter ruling in his or her own name or for the branch chief. When more than one branch has taken an adverse position on an issue in a letter ruling request or when the position ultimately adopted by one branch will affect that adopted by another, a representative from each branch with the authority to sign in his or her own name or for the branch chief will attend the conference. If more than one subject is to be discussed at the conference, the discussion will constitute a conference on each subject.

3. To have a thorough and informed discussion of the issues, the conference usually will be held after the branch has had an opportunity to study the case. At the request of the taxpayer, the conference of right may be held earlier.

4. Because conference procedures are informal, no tape, stenographic, or other verbatim recording of a conference may be made by any party.

5. The senior Associate Office representative present at the conference ensures that the taxpayer has the opportunity to present views on all the issues in question. An Associate Office representative explains the Associate Office’s tentative decision on the substantive issues and the reasons for that decision. If the taxpayer asks the Associate Office to limit the retroactive effect of any letter ruling or limit the revocation or modification of a prior letter ruling, an Associate Office representative will discuss the recommendation concerning this issue and the reasons for the recommendation. The Associate Office representatives will not make a commitment regarding the conclusion that the Associate Office will finally adopt.

6. Depending on the circumstances, conferences, including conferences of right and pre-submission conferences may be held by telephone. This may occur, for example, when a taxpayer wants a conference of right but believes that the issue involved does not warrant incurring the expense of traveling to Washington, D.C., or if it is believed that scheduling an in person conference of right will substantially delay the ruling process. If a taxpayer makes such a request, the branch reviewer will decide if it is appropriate in the particular case to hold a conference by telephone. If the request is approved, the taxpayer will be advised when to call the Associate Office representatives (not a toll-free call).


**32.3.2.4.2** **(08-11-2004)**

#### Pre-Submission Conferences

1. Sometimes it will be advantageous to both the Associate Office and the taxpayer to hold a conference before the taxpayer submits the letter ruling request to discuss substantive or procedural issues relating to a proposed transaction. These conferences are held only if the identity of the taxpayer is provided to the Associate Office, only if the taxpayer actually intends to make a request, only if the request involves a matter on which a letter ruling is ordinarily issued, and only at the discretion of the Associate Office and as time permits.

2. A letter ruling request submitted following a pre-submission conference will not necessarily be assigned to the branch that held the pre-submission conference. Also, when a letter ruling request is not submitted following a pre-submission conference, the Associate Office may notify, by memorandum, the appropriate Service official in the operating division that has examination jurisdiction of the taxpayer’s tax return and may give its views on the issues raised during the pre-submission conference. This memorandum may constitute Chief Counsel Advice, as defined in section 6110(i), subject to disclosure under section 6110.

3. A taxpayer may request a pre-submission conference in writing or by telephone. The request should identify the taxpayer and include a brief explanation of the primary issue so that an assignment to the appropriate branch can be made

4. Depending on the circumstances, pre-submission conferences may be held in person at the Associate Office or may be conducted by telephone.

5. Generally, the taxpayer will be asked to provide, at least three business days before the scheduled pre-submission conference, a statement of whether the issue is an issue on which a letter ruling is ordinarily issued, a draft of the letter ruling request or other detailed written statement of the proposed transaction, issue, and legal analysis. If the taxpayer’s authorized representative will attend or participate in the pre-submission conference, a power of attorney is required. If multiple taxpayers and/or their authorized representatives will attend or participate in the pre-submission conference, cross powers of attorney (or tax information authorizations) are required.

6. Any discussion of substantive issues at a pre-submission conference is advisory only, is not binding on the Service in general or on the Office of Chief Counsel in particular, and cannot be relied upon as a basis for obtaining retroactive relief under the provisions of section 7805(b).


**32.3.2.4.3** **(08-11-2004)**

#### Conference Procedures

1. If the taxpayer designates a representative to handle the request for a letter ruling, the initiator must be sure that the person representing the taxpayer has met all necessary conference and practice requirements. See **_CCDM 32.3.2.8_** http://publish.no.irs.gov/getpdf.cgi?catnum=39010, _Representation of Taxpayers_.

2. Conferences are generally conducted in an informal manner for the purpose of discussing the issue, the background, and the arguments for and against the proposed ruling.

3. All pertinent facts should be stated in the original request for a letter ruling (or in information subsequently submitted). Occasionally, however, some fact is identified or developed in the conference or an authority is cited that was not mentioned or fully presented in the request for letter ruling. In these cases, the taxpayer is responsible for furnishing in writing any additional data, lines of reasoning, or precedents that were discussed at the conference in accordance with the requirements to submit additional information in **CCDM 32.3.1.13**http://publish.no.irs.gov/getpdf.cgi?catnum=29177, _Requirements with Respect to Submission of Requests for Letter Rulings_.

4. A conference report should be prepared. See _Exhibit 32.3.2-6_. After approval by the conference leader attending the conference, the original of the report is associated with the case file and copies are distributed to Service personnel who attended.


**32.3.2.5** **(08-11-2004)**

### Coordination with Other Offices

1. The general procedures for coordination are set out in **CCDM 31.1.4** http://publish.no.irs.gov/getpdf.cgi?catnum=29650, _Coordination and Reconciliation of Disputes_.

2. A request for a letter ruling may contain issues coming under the jurisdiction of two or more offices in Chief Counsel. The preparation of a reply in these cases requires coordination between the offices involved. The coordination should be done early and at the lowest supervisory level in order to ensure timely and adequate responses.

3. A single reply ordinarily should be made to each request for a letter ruling that presents two or more issues. If the reply is to be for signature above the branch level, a single reply is preferable and should be made whenever feasible.

4. In some cases it may be preferable to reply to each issue separately if the issues are under the jurisdiction of different offices, and those offices agree that separate replies are in the best interests of the Service. Disagreements concerning whether separate replies are preferred will be referred promptly to succeeding levels of authority until resolved. See **CCDM 32.3.2.5.2** http://publish.no.irs.gov/getpdf.cgi?catnum=39010, _Resolving Differences_.

5. If more than one branch or office is involved, the branch chief having responsibility for the principal issue in a request is responsible for recognizing the need for coordination and for instituting appropriate action.


**32.3.2.5.1** **(08-11-2004)**

#### Processing Requests Containing Two or More Issues (Multi-Issue Requests)

1. On initial receipt of a multi-issue request for a letter ruling, the Docket, Record & User Fee Branch refers the request to the branch having jurisdiction over the principal issue.

2. If the need for assistance is apparent, it should generally be requested within the first 15 days after receipt in the branch having jurisdiction over the principal issue. If the need for assistance is not apparent upon receipt of the case, assistance should be requested as soon as the need is recognized.

3. The assistance request should state whether the issues are interdependent or capable of concurrent consideration; if interdependent, the request should state how the requesting branch proposes to rule on its issue.

4. The assistance request should clearly identify the issue that is the subject of the request either by stating the issue or by clear reference to the issue number, page number, etc., in the underlying request for letter ruling.

5. The assistance should be written in such form that it can be used in the letter ruling without rewording.

6. The office receiving assistance should prepare the letter ruling using the signature principles that would be appropriate if no other office were concerned. See **CCDM 31.1.3** http://publish.no.irs.gov/getpdf.cgi?catnum=29649, _Signature Principles_.


**32.3.2.5.1.1** **(08-11-2004)**

##### Processing Multi-Issue Requests in One Office

1. When a subsidiary issue is repetitious or routine, the state of the law on that issue is well established, and there is no risk of inconsistent positions, the office that has jurisdiction over the primary issue should also answer the subsidiary issue.

2. The offices involved will agree on whether the subsidiary issue should be handled by the office having jurisdiction over the primary issue and on the extent to which the office with jurisdiction over the subsidiary issue should review, or be informed of, the proposed reply to the subsidiary issue.


**32.3.2.5.1.2** **(08-11-2004)**

##### Severance of Issues

1. Severance of issues is never done unilaterally. The reviewers in the offices involved must agree that severance is the most appropriate way of processing a case, within the context of providing the best service possible and making the most efficient use of available resources.

2. Taxpayers will not be invited to sever the issues in a case. If a taxpayer asks that the issues in the case be severed, or submits multiple requests for the purpose of separating the issues, and the issues are interrelated, the offices concerned will consult to determine whether assistance or severance is the best method of processing the request. If the issues are so interrelated that they are most efficiently considered in tandem, the issues should not be severed and assistance should be requested by the office with the primary issue.

3. If a determination is made to sever the issues, the severance should be made as early as possible; i.e., as soon as it is mutually determined that the issues are not interdependent and that severance is in the best interests of the taxpayer and of the Service.

4. In any case that the supervisors decide to sever an issue, the initiator of the original request should provide a copy of the request and any relevant material to the other office using a buck slip or short memorandum signed by the branch chief or other reviewer stating that the case is being severed and the response to the issue is to be prepared separately.

5. The receiving office should ask the Docket, Record & User Fee Branch to create a new TECHMIS number for the severed issue and to cross-reference the initial request.

6. Each of the separate replies is prepared for the appropriate signature and contains a statement that the issue not answered is being considered separately.


**32.3.2.5.2** **(10-25-2011)**

#### Resolving Differences

1. When assigning, preparing, or reviewing letter rulings, whether or not more than one issue is involved, each initiator should be alert to the possibility that the issue or issues in the request may involve two or more Code sections that are under the jurisdiction of more than one office. In any case where a conflicting interpretation appears to be developing or to have occurred, every effort should be made to resolve the matter at the earliest stage of consideration and at the lowest managerial level. Matters that cannot be resolved at the lowest managerial level should be referred promptly to succeeding levels of authority until resolved. The matter is to be handled expeditiously and each level of authority will attempt to resolve the matter informally, but as a matter proceeds to higher levels of review certain memoranda may need to be prepared.

2. The resolution of a difference at any level of authority should be evidenced by endorsement of the official file copy by the offices involved.

3. In any case where appropriate, a memorandum of agreement signed by both offices, indicating the basis upon which the differences were resolved, is also made part of the case file.

4. For additional procedures to be followed in resolving disagreements between two offices see **CCDM 31.1.4** http://publish.no.irs.gov/getpdf.cgi?catnum=29650, _Coordination and Reconciliation of Disputes_.


**32.3.2.6** **(08-11-2004)**

### Coordination with Other Federal Departments and Agencies

1. The following covers coordination with other federal departments and agencies.

2. As the need arises initiators confer with members of other departments or agencies of the Government on specific matters requiring coordination.

3. The Service is responsible for the Federal Insurance Contributions Act (FICA) tax and the Self-Employment Contributions Act (SECA) tax provisions of the Code. The Social Security Administration administers the social security medicare coverage provisions under the Social Security Act. Coordination procedures were originally adopted in December 1937. A Presidential directive dated February 24, 1949, requires the two agencies to join in submitting to the Attorney General for advice any case in which the two agencies have divergent views.

4. The Service is responsible for the Railroad Retirement Tax Act provisions of the Code. The Railroad Retirement Board administers the retirement and benefit coverage provisions under the Railroad Retirement and Railroad Unemployment Insurance Acts. Coordination procedures were revised in a written agreement dated December 3, 1973, between the Service and the Board.


**32.3.2.6.1** **(08-11-2004)**

#### Employment Tax Coordination with Social Security Administration

1. The Division Counsel/Associate Chief Counsel (TEGE) has responsibility for all coordination procedures between the Service and the Social Security Administration (SSA) with respect to cases involving technical questions referred to the Associate Offices. Such procedures include the following:



1. Making available to the SSA legal opinions of Chief Counsel and of the General Counsel for the Department of the Treasury concerning tax liability under the Federal Insurance Contributions Act and the Self-Employment Contributions Act.

2. Receiving inquiries from the SSA and initiate action in novel cases of sufficient importance to justify joint consideration.

3. Receiving inquiries from the SSA in those cases in which the coverage status of the individuals involved is being considered by both agencies.

4. Exchanging views in any matter of substantial importance to the operations of the other, or if one of the respective agencies contemplates making a decision in a specific case that is contrary to a prior decision of the other agency or to the views expressed by it.

5. Affording the SSA an opportunity to express its views with respect to the publication of any letter ruling if, because of its broad scope or application, coordination is deemed desirable or there is doubt whether the SSA agrees with the views of the Service.


2. Any matter regarding the Federal Insurance Contributions Act (FICA) tax and the Self-Employment Contributions Act (SECA) tax provisions of the Code that arises directly or indirectly in a case in another Associate Office should be coordinated with the Office of the Division Counsel/Associate Chief Counsel (TEGE) as soon as the matter arises.


**32.3.2.6.2** **(08-11-2004)**

#### Employment Tax Coordination with Railroad Retirement Board

1. The Division Counsel/Associate Chief Counsel (TEGE) has responsibility for all coordination procedures between the Service and the Railroad Retirement Board with respect to cases involving technical questions. Such coordination shall be with the Chief Executive Officer and the General Counsel of the Railroad Retirement Board and shall include the following procedures:



1. Making available legal opinions of the Chief Counsel and of the General Counsel for the Department of the Treasury concerning tax liability under the Railroad Retirement Tax Act.

2. Exchanging views on technical matters before issuance of an interpretation involving provisions of the law which affect the responsibility of both agencies, to the extent deemed mutually advisable by the agencies.

3. Receiving inquiries from the Board in those cases in which the coverage status of the individuals involved is being considered.

4. Exchanging views in any other matter of substantial importance from the standpoint of the operations of the other.

5. Exchanging views if one of the respective agencies contemplates making a decision in a specific case that is contrary to a prior decision of the other agency or to the views expressed by it.

6. Affording the Board an opportunity to express its views with respect to the publication of any letter ruling if, because of its broad scope or application, coordination is deemed desirable or there is doubt whether the Board agrees with the views of the Service.


2. Any matter regarding the Railroad Retirement Tax Act provisions of the Code that arises directly or indirectly in a case in another Associate Office should be coordinated with the Office of the Division Counsel/Associate Chief Counsel (TEGE) as soon as the matter arises.


**32.3.2.7** **(06-14-2022)**

### Referral of Copies of Letter Rulings to the Appropriate Service Official

1. Send one copy of each letter ruling, which includes all Change in Accounting Method (CAM) correspondence produced by any Associate office (except ITA CAM correspondence produced for LB&I taxpayers, which has its own procedure), whether favorable or adverse, to the appropriate Service official identified in the CAMS/PLR Directory accessed from the Office of Chief Counsel intranet site \[https://employeeresources.prod.irscounsel.treas.gov/CC%20Phone%20Directory/plr\_cam\_other\_correspondence\_address\_list.pdf\]. This alerts the Service official that a taxpayer received a letter ruling and, in connection with an examination of the taxpayer’s return, the Service may verify the facts upon which the letter ruling was based.

2. Furnish documents and information obtained or developed in the course of considering a taxpayer’s letter ruling request to the Service official identified in paragraph (1). Such documents and information may be important to the Service when examining the taxpayer’s return, and must be furnished to the Service official whether or not the letter ruling is issued.

3. Notify the Service official identified in paragraph (1) when a taxpayer withdraws a letter ruling request. In addition, you may give your views on the issues in the request for the Service’s consideration during any later examination of the taxpayer’s returns. Do not return correspondence and exhibits related to a request to the taxpayer. Do not return the letter ruling user fee to the taxpayer. The Service may publish its conclusion(s) with respect to a letter ruling request in a revenue ruling or a revenue procedure.

4. Notate a “cc” on each issued letter ruling and all copies of the letter ruling, including the IRS file copy, identifying the appropriate Service official receiving the copy of the letter ruling.


**32.3.2.7.1** **(08-02-2022)**

#### Notifying the Service to Update Taxpayer’s Account Regarding Consent to Extend Time to Assess Tax in Conjunction with the Issuance of a Letter Ruling

1. In conjunction with the issuance of a letter ruling a taxpayer may consent to extend the statutory period of time to assess tax. The agreement to extend the statutory period of time to assess tax may be executed using the Service’s Form 872, Consent to Extend the Time to Assess Tax, or the agreement may be included in the content of the letter ruling itself or other document (the Consent).

2. The Consent is signed and dated by the taxpayer or the taxpayer’s authorized representative and countersigned and dated by the Deputy Associate Chief Counsel. See Delegation Order 25-2 (IRM 1.2.2.14.2(3)j) and IRM 1.11.4.5.2(1).

3. After the Consent is signed and countersigned, a Chief Counsel attorney must notify the Service regarding the extended statutory assessment period by sending an email to \*wi.plr.ased.extension@irs.gov.

4. A Chief Counsel attorney must provide the Service the following information in the email:



1. Subject line: Assessment statute extension - letter ruling.

2. Taxpayer’s name.

3. Tax year(s) for which the statutory assessment period was extended.

4. End date of the statutory assessment period as extended by the Consent.

5. Attachment description, e.g., Form 872, other signed agreement.


5. In addition, a Chief Counsel attorney must include as an attachment to the email to \*wi.plr.ased.extension@irs.gov an encrypted copy of the Consent that was signed by the taxpayer or the taxpayer’s authorized representative and countersigned by the Deputy Associate Chief Counsel. This may be a copy of the fully executed Form 872, the signed letter ruling, or other signed agreement made by the taxpayer and the Deputy Associate Chief Counsel to extend the statutory assessment period.



1. Such attachments must comply with the Service’s procedures protecting the taxpayer’s personal identifying information (PII). See IRM 10.5.1.6.2 for PII protection and attachment encryption information.

2. SEMS secure messaging also may be used to transmit the notification and Consent to the IRS. See IRM 1.10.3.2.1.


6. The Consent documents bearing the original signatures of the taxpayer or the taxpayer’s authorized representative and the Deputy Associate Chief Counsel must be retained in the letter ruling files.


**32.3.2.8** **(07-09-2014)**

### Representation of Taxpayers

1. Counsel employees must verify that a person is properly authorized to receive the taxpayer information of another person prior to discussing any tax matter or information that may be subject to the disclosure provisions of the Code.

2. These rules apply generally to any contact concerning taxpayers or taxpayer information as defined by the Code, including, but not limited to, the following:



   - Requests for letter rulings

   - Requests for technical advice

   - Congressional inquiries

   - Requests for general information concerning a specific taxpayer

   - Any other matters involving a specific taxpayer


### Caution:

Counsel employees may be liable for unauthorized disclosures to persons who are not properly authorized to receive the taxpayer information.

3. Care must be taken to ensure that any authorization, such as a power of attorney (usually **Form 2848** http://publish.no.irs.gov/getpdf.cgi?catnum=11980, _Power of Attorney and Declaration of Representative)_ or**Form 8821**http://publish.no.irs.gov/getpdf.cgi?catnum=11596, _Tax Information Authorization_, (is broad enough to cover the matter under consideration, particularly when relying on a power that is forwarded from another office or function.



### Note:



A taxpayer may execute a Form 8821, Tax Information Authorization, consenting to IRS’s disclosure of the taxpayer’s return or return information to another person.

4. A taxpayer’s written consent generally is required before Counsel may disclose tax information to a third party designee of the taxpayer. However, where the third party is assisting the taxpayer in a Federal tax matter relating to the taxpayer, Counsel may disclose tax information to the third party based upon the taxpayer’s written or nonwritten (oral) request for assistance or information. In the case of a written request, the writing must be signed and dated by the taxpayer, and it must contain the following:



1. The taxpayer’s identity information (i.e., the taxpayer’s name, mailing address, taxpayer identifying number)

2. The identity of the person or persons to whom disclosure is to be made

3. Sufficient facts to enable Counsel to determine the nature and the extent of the information or assistance requested and the tax information to be disclosed

4. In the case of a nonwritten (oral) request, Counsel may make the disclosure after accomplishing the following:

5. Obtaining sufficient facts from the taxpayer to enable Counsel to determine the nature and extent of the information or assistance requested and the tax information to be disclosed

6. Confirming the identity of the person to whom disclosure is to be made

7. Confirming the date, the nature, and the extent of information or assistance requested


### Note:

Employees making disclosures pursuant to a nonwritten (oral) request should, where possible, record in the case file the details of the request and the disclosure.

5. A letter ruling will be addressed to the taxpayer, with a copy to the first representative listed on the power of attorney, unless the Service is instructed to do otherwise. See line 7 of **Form 2848** http://publish.no.irs.gov/getpdf.cgi?catnum=11980 and the applicable instructions.


**32.3.2.8.1** **(07-09-2014)**

#### Authority

1. Treasury Department Circular 230, 31 CFR, Subtitle A, Part 10, contains rules governing the recognition of attorneys, certified public accountants, enrolled agents, and other persons representing clients before the Internal Revenue Service.


**32.3.2.8.2** **(07-09-2014)**

#### Authorized Representatives

1. A request for a letter ruling, determination letter, or closing agreement by or for a taxpayer must be signed by the taxpayer or the authorized representative. An individual can represent a taxpayer in connection with a request for a letter ruling, determination letter, or closing agreement if the individual is eligible to practice before the IRS. See 31 C.F.R. Part 10 (Circular 230) §§ 10.3 and 10.7(c).

2. Any authorized representative representing a taxpayer in connection with a request for a letter ruling, determination letter, or closing agreement must comply with the Conference and Practice requirements of the Statement of Procedural Rules (26 C.F.R. § 601.501 et seq.) and Circular 230.



### Note:



An unenrolled return preparer cannot represent a taxpayer in connection with a request for a letter ruling, determination letter, or closing agreement.





### Caution:



There are special post-employment restrictions for former Service employees who are authorized to represent others before the Service. See **CCDM 39.1.2.3.3** http://publish.no.irs.gov/getpdf.cgi?catnum=29355, _Post-Employment,_ for further guidance.


**32.3.2.8.3** **(07-09-2014)**

#### Power of Attorney and Declaration of Representative (Form 2848) or Tax Information Authorization (Form 8821)

1. A Counsel employee generally cannot discuss a letter ruling with any individual other than the taxpayer unless the taxpayer has consented to the disclosure. Taxpayers should use **Form 2848** http://publish.no.irs.gov/getpdf.cgi?catnum=11980, _Power of Attorney and Declaration of Representative_, to designate an eligible individual to represent the taxpayer before Counsel with regard to requests for letter rulings. Taxpayers can use **Form 8821** http://publish.no.irs.gov/getpdf.cgi?catnum=11596, _Tax Information Authorization_, to consent to the disclosure of the taxpayer’s tax information to a third party who is not representing a taxpayer. In addition,**Form 8655** http://publish.no.irs.gov/getpdf.cgi?catnum=10241, _Reporting Agent Authorization_ (which generally is used to appoint an individual as reporting agent with authority to sign and file Federal tax deposits for the taxpayer), may be used to authorize the reporting agent as a designee of the taxpayer to receive duplicate copies of notices, correspondence, and transcripts with respect to employment tax returns filed by the designee. See Rev. Proc. 96-17, 1996-1 C.B. 633.

2. Each Associate Chief Counsel or Division Counsel/Associate Chief Counsel (TEGE) must establish procedures consistent with this section to ensure that taxpayers are represented only by individuals eligible to practice before the IRS The procedures also must ensure that the powers of attorney authorizing the representation are valid.


**32.3.2.8.3.1** **(08-11-2004)**

##### General Guidelines

1. It is not mandatory that **Form 2848**http://publish.no.irs.gov/getpdf.cgi?catnum=11980, _Power of Attorney and Declaration of Representative_, or **Form 8821** http://publish.no.irs.gov/getpdf.cgi?catnum=11596, _Tax Information Authorization_, be used. If one of these forms is not used, the information required by the form must be included in any substitute statement.

2. A Form 2848, or substitute, must accompany each request for a letter ruling if the taxpayer desires another person to act as representative and perform any of the specific acts enumerated on Form 2848. A Form 8821, or a substitute, must accompany each request for a letter ruling if the taxpayer desires to authorize a representative to receive confidential information (such as conference participation, receipt of letter ruling, or similar action), but not to perform any of the specific acts enumerated on Form 2848. The power of attorney or the authorization for another to receive tax information may be included in a taxpayer’s letter requesting a letter ruling. The declaration as to the representative’s qualifications to practice before the Service may be contained in a letter ruling request submitted by the representative.

3. When a request for a letter ruling submitted by a person other than the taxpayer does not involve the receipt of confidential tax information, for example, filing a protest or requesting reconsideration of a letter ruling, the authority to represent a taxpayer will be satisfied by restricting the specified acts enumerated in Part I, and completing Part II, of Form 2848, filed by an attorney, certified public accountant, or an agent enrolled to practice before the Service.

4. If a power of attorney or other authorization is required and it does not accompany the request for letter ruling, either (1) Letter 2324 will be sent to the person who submitted the request for the letter ruling or (2) the taxpayer or the person who submitted the request for the letter ruling will be contacted by phone by the appropriate branch personnel.



### Note:



To expedite the receipt of a proper power of attorney, the improperly designated representative may be contacted directly only for the purpose of informing the representative that the power of attorney submitted in connection with a request for letter ruling is unacceptable. The content of the request should not be discussed.


**32.3.2.8.3.2** **(08-11-2004)**

##### Specific Requirements

1. A power of attorney or other authorization may be given only to individuals. If the individuals are members of a firm, the names of the individuals must be listed and not just the firm name.

2. A power of attorney or other authorization must clearly specify the type of tax, period, or transaction. It may apply to the tax for a specified period, for example, Income Tax 1996; Estate Tax, November 29, 1995 (Date of Death); Excise Tax, third quarter 1995. Instead of a period, the power of attorney or other authorization may be for a specified transaction or act, for example, whether a sale or use of a product is subject to excise tax. Any number of specific periods or types of taxes may be listed in a power of attorney or other authorization, for example, Income Tax, Estate Tax, Gift Tax, and Excise Tax for 1995 through 1996, but a reference to all years, all periods, or all taxes, is not acceptable.



### Note:



When a power of attorney is submitted for a letter ruling request, the power must specify that the representative is authorized to act on behalf of the taxpayer with respect to the letter ruling request. It is not sufficient to merely state the tax period to which the ruling request relates.

3. A power of attorney or other authorization must be signed by the taxpayer. If a matter concerns a joint return and both the husband and wife are represented by the same individual, both must sign the power of attorney. Either the husband or the wife may sign a**Form 8821**http://publish.no.irs.gov/getpdf.cgi?catnum=11596, _Taxpayer Information Authorization_. When the taxpayer is a corporation or association, an officer must sign. If the taxpayer is a partnership, all the partners, the partner authorized to act in the name of the partnership, or (for purposes of executing **Form 2848** http://publish.no.irs.gov/getpdf.cgi?catnum=11980, _Power of Attorney and Declaration of Representative_) the tax matters partner must sign. When the taxpayer is an estate or trust, the fiduciary must sign.

4. The representative(s) must sign and date the power of attorney, enter the designation under which the representative is authorized to practice before the IRS, and list the jurisdiction in which admitted or licensed to practice. Failure to do so invalidates the power with respect to the nonconforming party; however, the power will still be valid as to the representative who complied with these requirements.

5. Unless the taxpayer authorizes the representative to redelegate authority or to substitute another representative, only those individuals listed on the power of attorney or other authorization may represent the taxpayer.

6. A new power of attorney or other authorization revokes all prior powers of attorney or other authorization unless the new one contains a clause specifically stating that it does not revoke the prior powers of attorney or other authorization. Copies of the prior powers of attorney or other authorization must be attached to the new power of attorney or other authorization to remain in effect.



### Note:



The filing of a Form 2848 will not revoke any Form 8821 that is in effect. Similarly, the filing of a Form 8821 will not revoke any Form 2848 that is in effect.


**32.3.2.8.3.3** **(08-11-2004)**

##### Examples

1. A power of attorney or other authorization that specifies it applies to a request for a letter ruling of a particular date, rather than a specified tax period, should be accepted. The date of the letter ruling request on the power of attorney should agree with the date on the letter requesting the letter ruling.

2. A power of attorney or other authorization that states it is for a number of years but does not specify the type of tax should not be accepted.

3. A power of attorney or other authorization that the authorized representative has modified should not be accepted. A representative’s declaration cannot alter a taxpayer’s power of attorney.

4. A power of attorney or other authorization where two corporations are listed as the taxpayers must be signed by an officer of each corporation. If the ruling is requested only by one of the named corporations, and an officer of that corporation has signed the power of attorney or other authorization, it should be accepted.

5. A power of attorney or other authorization for a partnership that is signed by an individual who indicates he is a member of the firm should not be accepted. A power of attorney or other authorization for a partnership must be signed by all partners, unless one partner is authorized to act in the name of the partnership, in which case that partner must sign the power of attorney.

6. A general power of substitution is good prospectively if the language of the grant makes such intention clear. For example: On August 19, 1990, A prepared a document in which A conferred upon B full power to substitute for A before the Service in all cases where I now or may hereafter have power of attorney. On July 15, 1991, the taxpayer granted a power of attorney, on Form 2848, to A. A and B signed the reverse side of Form 2848 indicating their eligibility to serve. Both A and B should be recognized to practice before the Service.


**32.3.2.8.4** **(07-09-2014)**

#### Acceptable Power of Attorney or Other Third Party Authorizations

1. Completed powers of attorney or other third party authorizations that are valid will be stamped “Accepted” on the bottom of the first page near the form number, if **Form 2848**http://publish.no.irs.gov/getpdf.cgi?catnum=11980 or **Form 8821**http://publish.no.irs.gov/getpdf.cgi?catnum=11596 is used, or after all typed material on the first page of the authorization, if an IRS form is not used. The stamp will be initialed by the employee who stamps the power of attorney. The name of the authorized representative will be entered into TECHMIS. The case assignment will be referred for assignment or to the initiator, as appropriate.


**32.3.2.8.5** **(07-09-2014)**

#### Deficient Power of Attorney or Other Authorization

1. When the power of attorney or other third party authorization is not complete or not valid, Letter 2587 or other appropriate letter will be sent to the taxpayer. However, the taxpayer or person who submitted the request may be contacted by phone by appropriate branch personnel and advised to submit an acceptable power of attorney or other third party authorization.


**32.3.2.8.6** **(08-11-2004)**

#### Signature on Letters Concerning Powers of Attorney

1. All letters concerning powers of attorney or other authorizations will be prepared for the signature of the appropriate branch chief.


**32.3.2.8.7** **(07-09-2014)**

#### Copy of a Power of Attorney or a Tax Information Authorization

1. The original, a photocopy, or a fax copy of a power of attorney or a tax information authorization will be accepted when its authenticity is not reasonably disputed.


**Exhibit 32.3.2-1**

### Letter 1690

![This is an Image: 39010001.gif](https://www.irs.gov/pub/xml_bc/39010001.gif)

> This is an example of a Letter 1690 transmitting copies of the letter ruling.

[Please click here for the text description of the image.](https://www.irs.gov/media/157651 "")

**Exhibit 32.3.2-2**

### Letter 1690 (Version 2): Accounting Method Change Letter

![This is an Image: 39010002.gif](https://www.irs.gov/pub/xml_bc/39010002.gif)

> This is an example of a Letter 1690 transmitting copies of an accounting method change letter with instructions .

[Please click here for the text description of the image.](https://www.irs.gov/media/157656 "")

**Exhibit 32.3.2-3**

### Letter Ruling to Taxpayer

![This is an Image: 39010003.gif](https://www.irs.gov/pub/xml_bc/39010003.gif)

> This is an example of a letter ruling addressed to the taxpayer, showing the location of the identifying number. The legend should be typed below the taxpayer’s address. Also included are instructions for initiating the letter via CC Macros.

[Please click here for the text description of the image.](https://www.irs.gov/media/157661 "")

**Exhibit 32.3.2-4**

### Letter Ruling to Taxpayer’s Representative

![This is an Image: 39010004.gif](https://www.irs.gov/pub/xml_bc/39010004.gif)

> This is an example of a letter ruling addressed to the taxpayer’s representative, showing that the taxpayer's name (numbered, if two or more taxpayers), address, and identifying number should be typed below the address of the representative.

[Please click here for the text description of the image.](https://www.irs.gov/media/157666 "")

**Exhibit 32.3.2-5**

### Sample Format for Recommendation of Application or Rejection of Section 7805(b)(8) Relief

|  | **Office of Chief Counsel**<br>**Internal Revenue Service**<br>**m e m o r a n d u m**<br> CC:PSI :ABName<br> (Techmis no.) |
| --- | --- |
| date: |  |
| to: | \[name\]<br> Associate Chief Counsel<br> ( Passthroughs And Special Industries) CC:PSI |
| from: | \[name\]<br> Chief, CC:PSI:6 |
| subject: | Application (or Rejection of application) of Section 7805(b)(8) in: (Case name and TECHMIS number) |
|  | **Issue:** (Provide a brief statement of the technical issue and conclusion set forth in the attached technical advice memorandum, letter ruling, or revenue ruling.) |
|  | **Views of Taxpayer and/or field:** (Set forth taxpayer's request, if any, and the field's recommendation and supporting facts and reason for application or rejection of application of section 7805(b)(8), including specific date(s), tax involved, if known, and year(s) involved, as appropriate. If the question was first raised in the national office, so state.) |
|  | **Recommendation:** (State recommendation of branch as to whether section 7S05(b)(S) should be applied or rejected. Include specific date{s) and year(s) involved, as appropriate, and include supportive facts and reasoning to extent necessary. It is not necessary to repeat facts and reasoning to extent they are the same as the field's. Merely indicate such to be the case. |
|  |
|  | Recommended by: |  | Date: |
|  |  | Chief, Branch 6 |
|  |
|  | Approved by: |  | Date: |
|  |  | Associate Chief Counsel |

### Note:

Depending on an organization's structure and internal procedures, it may be appropriate to add a concurrence line for signature by the Assistant Chief Counsel. Use the same format (signature line, date, title, and symbols) and insert between the recommendation and approval entries.

**Exhibit 32.3.2-6**

### Conference Report

| **CONFERENCE REPORT** |
| :-: |
| Case Name: |
| TECHMIS No: |
| Subject of Conference: |
| Time Consumed: | Date: |
| Time Held: | Place: |
|  |
| Taxpayer/Representatives At Conference: |
|  |
| Service Representatives At Conference: |
|  |
| Name of Person Preparing Report: |
| Date Prepared: | Symbols: |
| Signature: \_\_\_\_\_\_\_\_ |
|  |
| Name of Person Reviewing Report: |
| Date Prepared: | Symbols: |
| Signature: \_\_\_\_\_\_\_\_ |
| BRIEF RESUME OF CONFERENCE, INCLUDING CONCLUSIONS REACHED: |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part32/irm_32-003-002#addtoany "Show all")

A2A