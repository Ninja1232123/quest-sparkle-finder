---
url: "https://www.irs.gov/irm/part34/irm_34-005-003"
title: "34.5.3 Suits Brought Against the United States | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part34/irm_34-005-003#main-content)

- 34.5.3  [Suits Brought Against the United States](https://www.irs.gov/irm/part34/irm_34-005-003#idm140242682926608)
  - 34.5.3.1  [Civil Actions Brought Against the U.S. By Persons Other Than Taxpayers](https://www.irs.gov/irm/part34/irm_34-005-003#idm140242682950208)
  - 34.5.3.2  [Wrongful Levy — Section 7426(a)(1)](https://www.irs.gov/irm/part34/irm_34-005-003#idm140242682893072)
  - 34.5.3.3  [Surplus Proceeds — Section 7426(a)(2)](https://www.irs.gov/irm/part34/irm_34-005-003#idm140242682880720)
  - 34.5.3.4  [Substituted Sales Proceeds — Section 7426(a)(3)](https://www.irs.gov/irm/part34/irm_34-005-003#idm140242682876080)
  - 34.5.3.5  [Substitution of Value Suits — Section 7426(a)(4)](https://www.irs.gov/irm/part34/irm_34-005-003#idm140242682870864)
  - 34.5.3.6  [Miscellaneous Procedural Matters](https://www.irs.gov/irm/part34/irm_34-005-003#idm140242682868400)
    - 34.5.3.6.1  [Validity of Assessment](https://www.irs.gov/irm/part34/irm_34-005-003#idm140242682866592)
    - 34.5.3.6.2  [Period of Limitations on Suits](https://www.irs.gov/irm/part34/irm_34-005-003#idm140242682864640)
    - 34.5.3.6.3  [United States as Defendant](https://www.irs.gov/irm/part34/irm_34-005-003#idm140242682861792)
    - 34.5.3.6.4  [Administrative Claims Generally Not Required](https://www.irs.gov/irm/part34/irm_34-005-003#idm140242682859520)
    - 34.5.3.6.5  [Perpetuation of Testimony](https://www.irs.gov/irm/part34/irm_34-005-003#idm140242682922192)

# Part 34. Chief Counsel Directives Manual Litigation in District Court, Bankruptcy Court, Court of Federal Claims, and State Court

# Chapter 5. Suits Brought Against the United States

# Section 3. Suits Brought Against the United States

* * *

## 34.5.3 Suits Brought Against the United States

#### Manual Transmittal

August 01, 2022

#### Purpose

(1) This transmits new CCDM 34.5.3, Suits Brought Against the United States.

#### Background

Section 11071 of Public Law 115-97, 131 Stat. 2054 (Dec. 22, 2017), extended the time in which a third party could administratively and judicially contest an IRS levy from nine months to two years.

#### Material Changes

(1) CCDM 34.5.3 is revised to reflect the amendment to Code section 6532(c) that changed the period of limitation on suits by third parties from nine months to two years.

#### Effect on Other Documents

This section supersedes CCDM 34.5.3 dated 08-11-2004.

#### Audience

Chief Counsel

#### Effective Date

(08-01-2022)

Kathryn Zuba

Associate Chief Counsel

(Procedure & Administration)

**34.5.3.1** **(08-11-2004)**

### Civil Actions Brought Against the U.S. By Persons Other Than Taxpayers

1. This section covers the types of civil actions that may be brought against the United States by persons other than taxpayers under section 7426.


**34.5.3.2** **(08-01-2022)**

### Wrongful Levy — Section 7426(a)(1)

1. Section 7426(a)(1) authorizes a suit directly against the United States by a _third_ person claiming that the Government wrongfully levied upon such person’s property to satisfy the tax liability of another. Wrongful, as used in this section, refers to a proceeding against property that is not the taxpayer’s. In general, if a levy has been made on property, or property has been sold pursuant to a levy, any person other than the taxpayer who claims an interest in or lien on such property, may bring a civil action against the United States.

2. An action under section 7426 may be brought without regard to whether the property has been surrendered to or sold by the Service. A third person may not bring a wrongful levy action before the Service has in fact levied upon the property.

3. The remedies provided by section 7426 are the exclusive means of redress for actions that may be brought under this section. A third party may not bring a 28 U.S.C § 2410 quiet title action, which may have a longer (six-year) period of limitation, to recover wrongfully levied property.

4. The injunctive relief afforded by section 7426(b)(1) is available:



   - Only in wrongful levy actions brought under section 7426(a)(1);

   - Only after the property has in fact been levied upon by the Service;

   - Only if the court determines that the levy has been wrongful

   - If the levy or a sale of property pursuant to the levy would irreparably injure the rights of a third party in such property; and

   - If the court determines that the rights of such third party in such property are superior to the rights of the United States.


5. If the court’s determination is in favor of the third party, typically the injunction is either made permanent (if, for example, the property was not yet surrendered to the Service) or is continued until the levy is released and the specific property is returned to the third person.

6. If the court determines the Service’s levy is wrongful, the court may under section 7426(b)(2):



   - Order the return of specific property if the property is identifiable and the United States is in possession of such property.

   - Grant a judgment for the amount of money levied upon.

   - Grant a judgment for an amount not exceeding the amount received by the Service from the sale of such property, or the fair market value of such property immediately before the levy.


7. Where a third party recovers a money judgment, interest at the rate set by section 6621 is allowed from the date the Service received the money wrongfully levied upon to the date of payment of such judgment. Money wrongfully levied upon is "received" at the time the Government acquired possession of such money.

8. Section 7426(h) authorizes the payment of actual, economic damages incurred by a third party in a wrongful levy suit if there is a finding that an officer or employee recklessly, intentionally, or negligently disregarded a provision of the Code. The third party must exhaust administrative remedies under the same rules set forth in section 7433(d).


**34.5.3.3** **(08-11-2004)**

### Surplus Proceeds — Section 7426(a)(2)

1. Section 7426(a)(2) provides that if surplus proceeds have been realized from the sale of property by the United States pursuant to a levy, any person (other than the taxpayer) who claims an interest in or lien upon such property junior to the lien or interest of the United States, and claims to be legally entitled to all or part of such surplus proceeds, may bring an action against the United States in a district court of the United States.

2. "Surplus proceeds" are those in excess of the amount necessary to satisfy the tax liability giving rise to the levy and the expenses of the levy sale. Once a taxpayer’s liability is satisfied, the Government’s retention of surplus proceeds is wrongful as to the person legally entitled to them.

3. Section 7426(b)(3) provides that if the court determines that the interest or lien of any party to an action under section 7426 was transferred to the proceeds of sale or property sold pursuant to a levy, the court may grant a judgment against the United States in an amount equal to all or any part of the amount of the surplus proceeds of such sale. The relief available under this section may be granted only in cases brought under section 7426(a)(2).


**34.5.3.4** **(08-11-2004)**

### Substituted Sales Proceeds — Section 7426(a)(3)

1. Section 7426(a)(3) was enacted to provide that if property has been sold pursuant to an agreement described in section 6325(b)(3), any person (including the taxpayer) who claims to be legally entitled to all or any part of the amount held as a fund pursuant to such agreement, may join the Government in a civil action to assert a claim to those proceeds.

2. Section 6325(b) permits the issuance of a certificate of discharge where property subject to a tax lien is sold and, under an agreement with the Service, the proceeds from the sale are held as a fund subject to the liens and claims of the United States in the same manner, and with the same priority, as the liens and claims on the discharged property. This provision was instituted to aid in the disposition of property where a dispute exists among competing lienors, including the United States, concerning their rights to specific property.

3. Any person _including the taxpayer_ may bring an action under this provision whether or not such person was a party to the agreement described in section 6325(b)(3).

4. Section 7426(b)(4) provides that if the court determines that a party has an interest in or a lien upon an amount held as a fund pursuant to an agreement providing for the proceeds of sale of property to be substituted for the property, the court may grant a judgment in an amount not in excess of the substituted sale proceeds.


**34.5.3.5** **(08-11-2004)**

### Substitution of Value Suits — Section 7426(a)(4)

1. If a certificate of discharge is issued to any person under section 6325(b)(4) with respect to any property, such person may, within 120 days after the day on which such certificate is issued, bring a civil action against the United States for a determination of whether the value of the interest of the United States (if any) in such property is less than the value determined by the Service. No other action may be brought by such person for such a determination.


**34.5.3.6** **(08-11-2004)**

### Miscellaneous Procedural Matters

1. The following covers the miscellaneous procedural matters related to civil actions brought against the United States by persons other than taxpayers.


**34.5.3.6.1** **(08-11-2004)**

#### Validity of Assessment

1. Section 7426(c) provides that, for purposes of an adjudication under section 7426, the assessment of tax upon which the interest or lien of the United States is based shall be conclusively presumed to be valid. Thus, the merits of the tax liability are not contestable unless the United States asks affirmatively for foreclosure of its lien in such actions.


**34.5.3.6.2** **(08-01-2022)**

#### Period of Limitations on Suits

1. Section 6532(c) provides a period of limitation on suits by persons other than taxpayers. Generally, except as provided in section 6532(c)(2), no suit or proceeding under section 7426 shall begin after two years from the date of the levy or agreement giving rise to such action.

2. If a third party makes an administrative request under section 6343(b) for the return of property that has been wrongfully levied, then the 2-year period of limitation on suits may be extended. It is extended (but not abridged) until whichever of the following two dates occurs soonest: (1) the date that is 12 months from the date on which the third party filed the section 6343(b) administrative request; or (2) the date that is 6 months from the date on which the Service mailed a notice of disallowance of such request by registered or certified mail.


**34.5.3.6.3** **(08-11-2004)**

#### United States as Defendant

1. Section 7426(d) provides for a limitation on rights of action in that no action may be maintained against any officer or employee of the United States (or former officer or employee) or his/her personal representative with respect to any action that could be maintained under section 7426. If an action that could be brought against the United States under this section is improperly brought against one of the aforementioned individuals, the pleadings may be amended to substitute the United States as a party-defendant for such individual, as of the time such action was commenced, upon proper service of process on the United States. See section 7426(e).


**34.5.3.6.4** **(08-01-2022)**

#### Administrative Claims Generally Not Required

1. Section 7426(f) provides that the provisions of section 7422(a) (relating to prohibition of suit prior to filing claim for refund) shall not apply to actions under section 7426. It is, therefore, unnecessary for a person to file an administrative claim for a refund before instituting an action under section 7426.

2. An administrative claim may be filed seeking the recovery of property wrongfully levied upon, under section 6343(b) (relating to return of property), although the filing of such claim is not a prerequisite to the commencement of an action under section 7426(a)(1).

3. Similarly, the filing of an administrative application under section 6342(b) (relating to surplus proceeds), seeking a distribution of surplus proceeds resulting from a sale of property pursuant to levy, is not a prerequisite to the commencement of an action under section 7426(a)(2).

4. This is in contrast to a finding of liability for damages under section 7426(h). A third party may not recover a liability for actual, direct economic damages above or beyond the damages suffered by the wrongful levy or other matter adjudicated under section 7426(b) unless such third party first timely exhausts all administrative remedies as would be appliable under section 7433(d).


**34.5.3.6.5** **(08-01-2022)**

#### Perpetuation of Testimony

1. On occasion the taxpayer will initiate a proceeding in the federal district court to perpetuate the testimony of some witness believed to be relevant and material to a potential tax case. The appropriate Civil Trial Section of the Tax Division handles these cases, and they are handled as suits brought against the United States and opened as collection cases in the Office of Chief Counsel.

2. Upon receipt of information that such a case has been commenced, Counsel should assemble all facts and files and then prepare a letter addressed to the Tax Division, Attn: Civil Trial Section, \_\_\_\_\_\_\_\_\_\_\_\_Region. Such letter should be in the form of a defense letter and contain a recommendation as to whether the petition should be opposed. The letter will be signed on behalf of Chief Counsel in the field office and forwarded to the Tax Division.

3. All facts and files will be made available to the Tax Division lawyer handling the case.

4. Because the results of the case and any related papers could be pertinent to any future Tax Court case or refund suit, special efforts should be made to associate the immediate information with any Service files for future use.

5. The above procedures apply only if there is no suit already commenced by the taxpayer.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part34/irm_34-005-003#addtoany "Show all")

A2A