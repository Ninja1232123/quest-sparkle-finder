---
url: "https://www.irs.gov/irm/part32/irm_32-001-008"
title: "32.1.8 Publishing the Final Regulation | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part32/irm_32-001-008#main-content)

- 32.1.8  [Publishing the Final Regulation](https://www.irs.gov/irm/part32/irm_32-001-008#idm140208784292064)
  - 32.1.8.1  [Comments and Testimony from the Public Hearing](https://www.irs.gov/irm/part32/irm_32-001-008#idm140208757635216)
  - 32.1.8.2  [Writing and Reviewing the Final Regulations](https://www.irs.gov/irm/part32/irm_32-001-008#idm140208757638336)
  - 32.1.8.3  [Preamble to the Final Regulation](https://www.irs.gov/irm/part32/irm_32-001-008#idm140208784407872)
  - 32.1.8.4  [Final Regulations — Unusual Situations](https://www.irs.gov/irm/part32/irm_32-001-008#idm140208784414608)
    - 32.1.8.4.1  [Amendment to Final Regulations by Reference to Temporary Regulations Issued in the Same Treasury Decision](https://www.irs.gov/irm/part32/irm_32-001-008#idm140208757631696)
    - 32.1.8.4.2  [Publishing Several Final Regulations](https://www.irs.gov/irm/part32/irm_32-001-008#idm140208757628960)
    - 32.1.8.4.3  [Withdrawing Part of the NPRM](https://www.irs.gov/irm/part32/irm_32-001-008#idm140208757624512)
    - 32.1.8.4.4  [Re-proposing Part of the NPRM](https://www.irs.gov/irm/part32/irm_32-001-008#idm140208757622320)
    - 32.1.8.4.5  [Re-proposing the NPRM in Its Entirety](https://www.irs.gov/irm/part32/irm_32-001-008#idm140208757618720)
  - 32.1.8.5  [Finalizing Temporary Regulations with Cross-Referencing NPRM](https://www.irs.gov/irm/part32/irm_32-001-008#idm140208757063424)
    - 32.1.8.5.1  [Withdrawing Temporary Regulations](https://www.irs.gov/irm/part32/irm_32-001-008#idm140208757061520)
    - 32.1.8.5.2  [Expired Temporary Regulations](https://www.irs.gov/irm/part32/irm_32-001-008#idm140208757059712)
  - 32.1.8.6  [Required Regulatory Documents](https://www.irs.gov/irm/part32/irm_32-001-008#idm140208757057856)

# Part 32. Published Guidance and Other Guidance to Taxpayers

# Chapter 1. Chief Counsel Regulation Handbook

# Section 8. Publishing the Final Regulation

* * *

## 32.1.8 Publishing the Final Regulation

#### Manual Transmittal

November 12, 2019

#### Purpose

(1) This transmits revised CCDM 32.1.8, Regulation Handbook, Publishing the Final Regulation.

#### Material Changes

(1) CCDM 32.1.8.4.4 is being revised regarding updating a Regulatory Identifier Number after publication of a Treasury Decision.

#### Effect on Other Documents

This section supersedes CCDM 32.1.8, dated August 1, 2018.

#### Audience

Chief Counsel

#### Effective Date

(11-12-2019)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**32.1.8.1** **(08-11-2004)**

### Comments and Testimony from the Public Hearing

1. The IRS receives written and oral comments from the public about its ANPRMs and NPRMs ( _see_ CCDM 32.1.7.2 and CCDM 32.1.7.2.1). Also, when issuing TEMPs and NPRMs, section 7805(f) requires the IRS to solicit comments from the Chief Counsel for Advocacy of the Small Business Administration ( _see_ CCDM 32.1.5.4.7.5.2).

2. The comments are analyzed to determine which, if any, comments are to be adopted in the final regulation.


**32.1.8.2** **(08-11-2004)**

### Writing and Reviewing the Final Regulations

1. After evaluating the comments, the IRS may finalize some NPRMs with little, if any, change. However, some NPRM comments may identify new technical issues, policy considerations, or technical errors. Depending on the nature and extent of the changes to be made, the drafting team may need to address new issues, conduct additional legal research, or draft a new issues or policy memorandum. Sometimes another NPRM is issued because the regulation is being re-proposed.

2. In general, the review procedures for final regulations are the same as the procedures for NPRMs. Therefore, often the final regulation project will be assigned to the attorneys and reviewers who worked on the NPRM.

3. All final regulations must go through general circulation (" green" ), even if the final regulation is a no change TD. In general, the clearance chain of the signature package ("pink" ) is the same for final regulations as for NPRMs. However, the Assistant Secretary of the Treasury signs final and temporary regulations. _See_ CCDM 32.1.5.8.


**32.1.8.3** **(08-01-2018)**

### Preamble to the Final Regulation

1. The preamble ( _see_ CCDM 32.1.5.4) of the final regulation summarizes the final regulation (without describing the entire document), describes the procedural posture of the regulation (e.g. the NPRM, and ANPRMs), discusses any differences between the rules contained in the NPRM and those adopted in the final regulations, and explains the reason for the changes. The preamble to the final regulations generally must address all comments and explain why each comment was adopted or why the comment was not adopted. The preamble also must explain any other changes that were made to the contents of the regulation proposed in the NPRM. Pursuant to Code section 7805(f), the preamble must address any comments submitted by the Chief Counsel for Advocacy of the SBA. _See_ CCDM 32.1.5.4.7.3 and CCDM 32.1.5.4.7.5.2.


**32.1.8.4** **(08-11-2004)**

### Final Regulations — Unusual Situations

1. The IRS usually publishes one final regulation with respect to the underlying NRPM. Occasionally, Counsel and Treasury decide to



1. Issue several final regulations with respect to one NPRM,

2. Finalize part of the NPRM and withdraw the rest, or

3. Finalize part of the NPRM and re-propose the rest.


**32.1.8.4.1** **(08-11-2004)**

#### Amendment to Final Regulations by Reference to Temporary Regulations Issued in the Same Treasury Decision

1. The IRS may issue amendments to final regulations by reference to temporary regulations issued in the same Treasury Decision. In this situation, the general format for the notice of proposed rulemaking by cross-reference to temporary regulations and final and temporary regulations is modified. _See_ CCDM 32.1.5.7.4.3.2 for specific instructions if amending text of final regulations by reference to temporary regulations issued in the same document.


**32.1.8.4.2** **(08-11-2004)**

#### Publishing Several Final Regulations

1. If the IRS plans to publish several final regulations with respect to one NPRM, the first final regulation project retains the original CASE-MIS ID and RIN. After publishing the first final regulation, the drafting attorney must close the original CASE-MIS ID using status code 951 (Closed - Publication). The drafting attorney should open a new CASE-MIS ID and obtain a new RIN for each subsequent final regulation project. In the CASE-MIS remarks screen for each subsequent final regulation project, the drafting attorney should note the name and original CASE-MIS ID of the underlying NPRM and all related final regulations. The drafting attorney should also enter this information in the remarks screen for the first final regulation.


**32.1.8.4.3** **(08-11-2004)**

#### Withdrawing Part of the NPRM

1. To publish final regulations with respect to part of an NPRM and withdraw the rest, the drafting team must prepare two documents — a final regulation and a notice of partial withdrawal of notice of proposed rulemaking. After publishing the final regulation, the drafting attorney must close the CASE-MIS ID number using status code 951 (Closed — Publication).


**32.1.8.4.4** **(11-12-2019)**

#### Re-proposing Part of the NPRM

1. The IRS may publish a final regulation with respect to part of an NPRM and re-propose the rest at the same or a later time. The final regulation retains the original CASE-MIS ID and RIN. After publishing the final regulation, the drafting attorney must close the original CASE-MIS ID using status code 951 (Closed — Publication). The drafting attorney must open a new CASE-MIS ID. In the CASE-MIS remarks screen for the new NPRM, the drafting attorney should note the name and original CASE-MIS ID of the first NPRM project and the TD number of the final regulations. The drafting attorney should enter the information about the new NPRM in the remarks screen for the final regulation.

2. By default, the RIN for the final regulations will be closed when the final regulations are published. If the RIN is closed, a new RIN must be obtained for the new NPRM project. Alternatively, the drafting attorney may contact the Publications and Regulations Branch in Procedure and Administration and ask that the status of the RIN for the final regulation be updated to NPRM.


**32.1.8.4.5** **(08-11-2004)**

#### Re-proposing the NPRM in Its Entirety

1. The IRS may decide to re-propose the NRRM in its entirety. The CASE-MIS ID and RIN are not closed. In this case, the re-proposed NPRM retains the CASE-MIS ID and RIN that was originally issued. The original publication of the NPRM is withdrawn. A notice of withdrawal of the NPRM that was originally published is prepared and published in the Federal Register.


**32.1.8.5** **(08-11-2004)**

### Finalizing Temporary Regulations with Cross-Referencing NPRM

1. When the IRS publishes a final regulation pursuant to a TEMP with cross-referencing NPRM, the final regulation amends the CFR by codifying the underlying NPRM (with any changes) and withdrawing the temporary regulation. Therefore, the final regulation retains the RIN assigned to the NPRM.


**32.1.8.5.1** **(08-11-2004)**

#### Withdrawing Temporary Regulations

1. To ensure that the temporary regulations are withdrawn from the CFR, the drafting team must write an amendatory instruction in the final regulation that "removes" the obsolete text of the temporary regulations from the CFR.


**32.1.8.5.2** **(08-11-2004)**

#### Expired Temporary Regulations

1. To ensure that the expired text of temporary regulations (" sunset" temporary regulations) does not remain in the CFR indefinitely, the drafting team must prepare an amendment to the CFR that " removes" the text of the expired temporary regulations from the CFR.


**32.1.8.6** **(08-01-2018)**

### Required Regulatory Documents

1. To ensure that the IRS issues the final regulation in compliance with Federal administrative and other requirements governing the regulations process, the drafting team must revise certain documents submitted for the NPRM (if applicable), or prepare new ones, for the final regulation. These documents include:



   - The 7-Point memo (E.O. 12866) ( _see_ CCDM 32.1.2.4)

   - Form 14029 (or OMB Form 83-I) or "no change" memorandum (Paperwork Reduction Act) ( _see_ CCDM 32.1.2.5.1 and CCDM 32.1.2.5.3). If the final regulation contains a collection of information requirement, amend the OMB table in CFR Part 602 ( _see_ CCDM 32.1.5.7.5),

   - The Unified Agenda update, per instructions from the Publications and Regulations Branch ( _see_ CCDM 32.1.2.6.4)

   - A final regulatory flexibility analysis or statement supporting certification that the collection of information requirement will not have a significant economic impact on a substantial number of small businesses (pursuant to the Regulatory Flexibility Act) and Regulatory Flexibility Act checklist ( _see_ CCDM 32.1.5.4.7.5.4.7)

   - Congressional Review Act reports ( _see_ CCDM 32.1.6.11.2.5)


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part32/irm_32-001-008#addtoany "Show all")

A2A