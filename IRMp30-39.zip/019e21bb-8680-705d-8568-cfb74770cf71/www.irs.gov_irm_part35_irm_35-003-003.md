---
url: "https://www.irs.gov/irm/part35/irm_35-003-003"
title: "35.3.3 Motions Pertaining to Pleadings | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-003-003#main-content)

- 35.3.3 [Motions Pertaining to Pleadings](https://www.irs.gov/irm/part35/irm_35-003-003#idm140463588149792)
  - 35.3.3.1 [Motions to Dismiss for Failure to State a Claim Upon Which Relief Can be Granted](https://www.irs.gov/irm/part35/irm_35-003-003#idm140463588080960)
  - 35.3.3.2 [Motions to Strike](https://www.irs.gov/irm/part35/irm_35-003-003#idm140463587609808)
  - 35.3.3.3 [Motion for a More Definite Statement](https://www.irs.gov/irm/part35/irm_35-003-003#idm140463587498816)
  - 35.3.3.4 [Petitioners Motion for Improved Pleadings](https://www.irs.gov/irm/part35/irm_35-003-003#idm140463591383808)
  - 35.3.3.5 [Motion to Deem Allegations in Answer Admitted](https://www.irs.gov/irm/part35/irm_35-003-003#idm140463614494080)
  - 35.3.3.6 [Motion to Amend Pleadings](https://www.irs.gov/irm/part35/irm_35-003-003#idm140463606419712)
  - 35.3.3.7 [Motion to Amend to Conform Pleadings to Proof](https://www.irs.gov/irm/part35/irm_35-003-003#idm140463588148512)
  - 35.3.3.8 [Motions Pertaining to Reply](https://www.irs.gov/irm/part35/irm_35-003-003#idm140463613081344)
  - 35.3.3.9 [Death or Other Legal Disability of Petitioner](https://www.irs.gov/irm/part35/irm_35-003-003#idm140463588150944)
  - 35.3.3.10 [Joinder of Parties and Motion to Sever](https://www.irs.gov/irm/part35/irm_35-003-003#idm140463587449360)
    - 35.3.3.10.1 [One Petition from Two or More Statutory Notices](https://www.irs.gov/irm/part35/irm_35-003-003#idm140463587443296)
    - 35.3.3.10.2 [Joint Petition - Motion as to One Party](https://www.irs.gov/irm/part35/irm_35-003-003#idm140463588023744)
  - 35.3.3.11 [Petitioners Motion to Proceed Anonymously in Whistleblower Proceedings](https://www.irs.gov/irm/part35/irm_35-003-003#idm140463598496544)

# Part 35. Tax Court Litigation

# Chapter 3. Motions

# Section 3. Motions Pertaining to Pleadings

* * *

## 35.3.3 Motions Pertaining to Pleadings

#### Manual Transmittal

August 15, 2019

#### Purpose

(1) This transmits revised CCDM 35.3.3, Motions, Motions Pertaining to Pleadings.

#### Material Changes

(1) CCDM 35.3.3.11 was added to describe the process for responding to motions to proceed anonymously in whistleblower proceedings.

#### Effect on Other Documents

This section develops uniform procedures for responding to motions to proceed anonymously.

#### Audience

Chief Counsel

#### Effective Date

(08-15-2019)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**35.3.3.1** **(08-11-2004)**

### Motions to Dismiss for Failure to State a Claim Upon Which Relief Can be Granted

1. If the allegations of the petition fail to state any type of justiciable error that the Service made in the determination of the tax deficiency in the notice of deficiency or other determination letter, the Field attorney should consider filing a motion to dismiss for failure to state a claim upon which relief can be granted. Before doing so, the Field attorney should determine whether the allegations of the petition were drafted in error or through oversight; if so, the Field attorney should solicit the filing of an amended petition. If this defense is to be asserted, it normally should be asserted through motion, rather than by answer, in order that the court is moved to provide the appropriate relief. _See_ Exhibits 35.11.1–43 and 35.11.1–44.

2. Typically a motion to dismiss is filed in cases presenting wholly frivolous arguments, such as constitutional challenges to the legality of the income tax. Other examples of some defects which may be tested by a motion to dismiss for failure to state a claim are: the petition in some manner purports to invoke jurisdiction of the court as to a taxable year included in the statutory notice but assigns no error and alleges no facts with respect thereto; or the petition contains no material allegations of fact in support of any of the errors assigned. A motion to dismiss for failure to state a claim will, if granted, dispose of the entire case. For that reason before such a motion is filed it is essential to ensure that the court’s files contain a copy of the statutory notice. If the motion is granted, the court should be requested to enter an order reciting that the deficiency of $ \[amount\] determined by respondent for the taxable year in question will be included in the decision ultimately to be entered in the case.

3. The motion should be used only rarely in"S" cases and pro se cases unless the case is making only frivolous arguments that have consistently been rejected by the Tax Court, in which event the filing of such a motion is encouraged.

4. If after the filing of a motion for failure to state a claim the petitioner files an amended petition which purportedly cures the defects complained of in the motion, the respondent’s motion will usually be denied by the court. Upon the filing of the amended petition it should be examined to determine whether the defects in the original petition have in fact been cured; if not, consideration may be given to filing another motion to dismiss with respect to the amended petition.

5. Motions to dismiss for failure to state a claim must rely solely on the pleadings. If any collateral matters must be asserted, a motion for full or partial summary judgment should be made under T.C. Rule 121, after the case is at issue and the other requirements of the rules have been satisfied.


**35.3.3.2** **(08-11-2004)**

### Motions to Strike

1. The petition may contain impertinent assignments of error or allegations of fact which do not pertain to the adjustments to the petitioner’s tax liability involved in the case. The adjustments to liability may be those set forth in the statutory notice or those raised by the petitioner in claiming an overpayment of tax. A motion to strike is used in those cases where the petition is partly good and partly defective, the defective part does not affect the case as a whole, and it is desired that the defective part be literally stricken from the petition or reply. _See_ Exhibit 35.11.1–45. Motions to strike are generally disfavored and there should be a substantial basis before motions of this type are filed. In most cases the better practice is to file an answer responding with simple denials or objections to impertinent allegations in the petition or allegations which do not affect the tax determination. This course of action gets the case at issue and ready for further disposition and is particularly applicable in those cases in which it appears upon review of the files that the case is likely to be settled. Likewise, in some cases, a petition dealing with multiple tax years fails to state a claim on which relief can be granted for some, but not all of the years at issue. The Tax Court advises that in such cases, motions to strike should not be filed. Instead, the answer should be filed and once the case is at issue, a motion for partial summary judgment for those years failing to state a claim should be considered. A simple motion to strike should never be filed if the item in question is one of jurisdiction. In this situation a combined jurisdictional motion and to strike, in the form of a Motion to Dismiss for Lack of Jurisdiction and to Strike, with respect to that part of the petition should be filed. Motions to strike other documents or matters contained therein, such as other pleadings or briefs, should be coordinated with APJP, Branch 3.


**35.3.3.3** **(08-11-2004)**

### Motion for a More Definite Statement

1. T.C. Rule 51 provides that if a pleading to which a responsive pleading is permitted or required is so vague and ambiguous that a party cannot reasonably be required to frame a responsive pleading, he or she may move for a more definite statement before interposing his or her responsive pleading. _See_ Exhibit 35.11.1–46. Generally, the court does not look favorably upon motions for a more definite statement primarily upon the ground that the rules of the court provide for notice pleading and the petitioner’s position may be more fully developed through the discovery and admission process. Accordingly, the motion for a more definite statement should only be used in rare cases and only after coordination with APJP, Branch 3. Exhibit 35.11.1–1, Tax Court Documents Requiring Associate Office Review. The exception to this standard is the situation in which respondent is served with a timely, imperfect petition that the court, on the mistaken belief that the petition is untimely, has not ordered perfected. In that event, a motion for more definite statement should be filed alleging jurisdictional facts establishing the timely filing of the petition and noting that the petition does not comply with the requirements of T.C. Rule 34.

2. If a motion is filed, T.C. Rule 51(b) provides that the court may strike the pleadings to which the motion is directed or make such other order as it deems justified if the required response is not made within the period that the court directs. Thus, the introductory paragraph of a motion for a more definite statement should include a request that the portion of pleadings complained of be stricken in the event the petitioner fails to file the required response within the period prescribed by the court. The prayer should contain a similar request. The grounds of the motion must set forth the defects complained of and the details desired for an adequate pleading. In addition to these two requirements, there should be set forth in the grounds for the motion a specific reference to the portion of the court’s rules on pleadings with which petitioner has failed to comply.

3. Since there is no responsive pleading permitted or required to a reply, a motion for more definite statement in the reply will not lie under T.C. Rule 51. T.C. Rule 37(b) requires a reply to set forth clear and concise statements of any grounds, together with the facts in support thereof, on which the petitioner relies affirmatively or in avoidance of any matter in the answer on which the Service has he reply shall be deemed to be denied, and in general, a mere admission or denial, or statements that can be construed as an admission or denial, will be sufficient under T.C. Rule 37. Accordingly, it is contemplated by the rules that in general no motion should be filed to test the sufficiency of a reply. In the rare instance where it is believed necessary to challenge the sufficiency of a reply, a motion to strike reply may be prepared and forwarded to the APJP, Branch 3 for review. The relief requested in such a motion should be to require specific admissions and denials or, in the alternative, to strike the reply and to have deemed admitted the affirmative allegations in the answer to which the reply pertains.


**35.3.3.4** **(08-11-2004)**

### Petitioners’ Motion for Improved Pleadings

1. Since it is the policy of the Office of Chief Counsel to file an adequate answer, the instances of petitioners’ motions for improved pleadings in the answer should be minimal. If the petitioner’s motion with respect to the answer has merit, an adequate amended pleading sufficient to satisfy the court’s pleadings requirements should be filed promptly. If not authorized by the court’s order, the filing of an amended answer should be accompanied by a motion for leave to the extent required under the court’s rules. A response to petitioner’s motion should also be filed within the time prescribed by the court, stating that the motion may be denied because the answer is being amended to cure any defects.

2. If the petitioner’s motion for an improved answer is to be opposed, the Field attorney should file a notice of objection as ordered by the court. If an amended answer is to be filed, such answer should be filed prior to the date set by the court in its notice of calendaring petitioner’s motion for hearing or prior to the date of the hearing on the motion, as applicable.

3. At times, petitioner’s counsel has appeared at a scheduled hearing on a motion for improved pleadings unaware that respondent has filed an amended pleading because service has not been completed, usually because of a delay in the mails. Because of this, if an amended answer requiring coordination is transmitted to the Associate office, Field Counsel should notify petitioner’s counsel that an amended answer has been sent to the Associate office for review and will probably be filed within a short time period. If, upon review of the amended answer, the Associate office believes it should not be filed, Field Counsel will promptly be notified so that it can immediately inform petitioner’s counsel of that fact. If the amended answer is served directly by the Field attorney, it should be served sufficiently early to avoid petitioner’s counsel attending the hearing. A telephone call or facsimile transmission should be made to ensure the timely receipt of this information by the opposing party.


**35.3.3.5** **(08-11-2004)**

### Motion to Deem Allegations in Answer Admitted

1. If the petitioner fails to file a reply with respect to the affirmative allegations contained in respondent’s answer, consideration should be given to the filing of a motion under T.C. Rule 37. _See_ Exhibit 35.11.1–47. Petitioner or petitioner’s counsel should be called in an attempt to secure a reply; or a letter should be sent attempting to accomplish this result, being sure to state that if Field Counsel is not informed before the requested date that a reply has been mailed to the Tax Court, a motion will be filed under this rule. This motion should be prepared and ready for filing as soon as it is reasonably certain (25 days after the due date of the reply) that a reply has not been filed, even though such motion need not be filed until 45 days after expiration of the time for filing the reply. Records should be kept which will insure the timely consideration for filing of these motions.

2. Generally, T.C. Rule 37 motions are not to be filed in Small Tax Cases. Under T.C. Rule 175(c), a reply to the answer is not to be filed unless the court, on its own motion, or upon the motion of the respondent directs that a reply be filed to affirmative allegations in the answer. Although such a motion is theoretically available under the court’s rules, the court looks with extreme disfavor upon such a motion and it will almost certainly be summarily denied. Any proposed motion to require the filing of a reply under Rule 175 must be coordinated with APJP, Branch 3 prior to filing.

3. Where a T.C. Rule 37 motion is to be filed, it is important that respondent’s motion seek to have deemed admitted all affirmative allegations including allegations of ultimate or conclusory facts. For example, it is imperative that the Field attorney seek to have admitted the allegation that petitioner fraudulently, and with intent to evade tax, understated the income tax liability on his return in the amount of the determined liability. Even if a conclusory allegation, technically, requires the application of law to fact, or is inconsistent with an allegation of error in assignments or facts in the petition, the conclusory allegation is subject to being a deemed admission under this rule. Failure to respond to the conclusory allegation may, in the appropriate circumstances, tip the scales in favor of finding fraud in a motion for summary judgment such as where the nonconclusory facts may be insufficient by themselves to carry respondent’s burden of proof.


**35.3.3.6** **(08-11-2004)**

### Motion to Amend Pleadings

1. An answer may be amended once as a matter of right prior to respondent being served with a responsive pleading, or within 30 days after it is served provided it is not upon a trial calendar and no responsive pleading is permitted. Otherwise, an amendment to an answer must normally be accompanied by a motion for leave to file an amended answer. The motion must set forth the reasons why the amendment is necessary and sufficient facts to show there has been no undue delay. A motion for leave to file is not required if the amendment to the answer is made in response to an order of the court. In arguing in support of a motion to amend an answer, particular emphasis should be placed upon T.C. Rule 41(a), which states that leave should be given freely when justice so requires.

2. A petition may be amended once as a matter of course at any time before the answer is served. Otherwise, the petition may be amended by leave of the court or by written consent of respondent and leave to amend the petition shall be freely given when justice so requires. T.C. Rule 41(a). The Tax Court has a liberal amendment policy and will only deny amendments to the petition if the amendment will unfairly surprise or unduly prejudice respondent, or if the amendment seeks to improperly invoke the court’s jurisdiction. Taking into account that respondent is rarely successful in opposing such amendments, respondent should only file an objection to a motion to amend the petition when a very substantial basis for such objection exists.

3. When issues not previously raised by the petition are tried with the express or implied consent of the parties, they shall be treated in all respects as if they had been raised in the pleading. The Tax Court, upon motion of the petitioner made at any time, e.g., at trial or after, may allow such amendment of the petition as may be necessary to conform it to the evidence and to raise these issues. T. C. Rule 41(b).


**35.3.3.7** **(08-11-2004)**

### Motion to Amend to Conform Pleadings to Proof

1. The court may at any time during the course of the trial grant a motion of either party to amend the pleadings to conform to the proof. Such amended pleading, if permitted, shall be filed with the court either at the trial or in the office of the Clerk of the Court in Washington D.C. within such time and as directed by the Court. T. C. Rule 41(b)(3). If during the course of the trial it develops that the pleadings of respondent should be amended to claim increased deficiencies or any other relief, or to frame properly or adequately within the pleadings any issues or other matters based upon evidence adduced at the trial, a motion to amend the answer to conform to proof should be made prior to the completion of the trial, if possible. It is inadvisable to delay the filing of such a motion until after the completion of the trial or until a hearing with respect to a T.C. Rule 155 computation. If an analysis of the evidence after the completion of the trial indicates that there is a basis upon which respondent should make a claim for increased deficiencies, a motion for leave to amend the answer to conform to proof and to make claim for such increased deficiencies should be filed even though the trial on the merits has been completed. This latter course of action should only be followed in unusual circumstances. Section 6214 provides that a claim for an increased deficiency may be made"at or before the hearing or a rehearing." This phrase of the statute has been interpreted broadly and may include any hearing before the Tax Court until a decision has been entered. T.C. Rule 41(b)(1) authorizes issues to be tried by express or implied consent and the motion to amend may be based thereon if appropriate.

2. If an oral motion to amend the answer to conform the pleadings to the proof is made and granted at the trial, but the amended answer is not filed with the court until after the conclusion of the trial, the following procedure is applicable: The preliminary paragraph of the amended answer thereof shall contain a statement setting forth the oral motion made at the trial which was granted (including the transcript reference, if available) as the basis for the filing of the amended answer without a motion for leave. Amended answers to conform the pleadings to the proof must in every instance be filed within the time limitations set by the court in granting the oral motion for leave to file.


**35.3.3.8** **(08-11-2004)**

### Motions Pertaining to Reply

1. Under only rare and unusual circumstances may a motion concerning the inadequacy of a reply be filed with the Tax Court. T.C. Rule 37(b) merely requires admissions or denials to the allegations in an answer. It further requires a reply to set forth clear and concise statements of any grounds, together with the facts in support thereof, on which the petitioner relies affirmatively or in avoidance of any matter in the answer on which the Service has the burden of proof. T.C. Rule 37(d) provides that any new material contained in the reply shall be deemed to be denied, and in general, a mere admission or denial, or statements that can be construed as an admission or denial, will be sufficient under T.C. Rule 37. Accordingly, it is contemplated by the rules that in general no motion should be filed to test the sufficiency of a reply. In the rare instance where it is believed to be necessary to challenge the sufficiency of a reply, a motion to strike reply may be prepared and forwarded to APJP, Branch 3 for review. The relief requested in such a motion should be to require specific admissions and denials or, in the alternative, to strike the reply and to have deemed admitted the specific affirmative allegations in the answer to which the reply pertains.


**35.3.3.9** **(08-11-2004)**

### Death or Other Legal Disability of Petitioner

1. If a petitioner dies or becomes legally incapacitated and no personal representative is substituted as a party petitioner, a motion to dismiss for lack of prosecution should be filed. _Nordstrom v. Commissioner_, 50 T.C. 30 (1968). Such a _Nordstrom_ motion should be filed, for example, when an estate will not enter probate or be administered and there is, therefore, no personal representative to substitute for the deceased petitioner. Note that where there is no substitute for petitioner there is no change in caption as the Tax Court’s order of dismissal is a decision on the merits with respect to the deceased or incapacitated petitioner. Section 7459(d). Similarly, if the surviving spouse is a joint petitioner, there should not be a severance of the surviving petitioner or a caption change as the ensuing Order of Dismissal and Decision is effective as to both petitioners. Note also that if there were a substitute for petitioner, e.g., the executor of an estate, then petitioner (or respondent) would file a motion to substitute party and change caption pursuant to T.C. Rules 63 and 23(a). The motion to dismiss for lack of prosecution should include the names and addresses of the heirs at law of the decedent under the law of the jurisdiction wherein decedent resided. The court will then take appropriate steps to notify those survivors or representatives having an interest in the case and afford them an opportunity to take whatever action may be proper to protect their interests. The motion should also include the date and place of petitioner’s demise or circumstances concerning legal incapacity, and should include the certificate of death or other legal evidence supporting that fact as an exhibit. If the case is pursuant to a joint petition, the motion to dismiss should not be filed until the case is settled with the surviving spouse or appears on a trial calendar. The motion may also be filed at the same time a dispositive motion (e.g., summary judgment) is filed against the surviving spouse. If the case is settled with the surviving spouse, the parties should enter into a stipulation of settlement as to the agreed deficiencies. A stipulated decision cannot be used in this situation because it cannot be executed by all the parties to the action. If possible, the motion should include an endorsement of no objection to the granting of the motion from some or all of decedent’s heirs. Exhibit 35.11.1–49.


**35.3.3.10** **(08-11-2004)**

### Joinder of Parties and Motion to Sever

1. T C. Rule 61(a) provides, in general, that no person to whom a deficiency notice has been issued may join with any other such person in filing a petition. The rule does not prohibit the joinder of an affiliated group of corporations in a single petition filed in respect to a notice of deficiency mailed to the common parent pursuant to Treas. Reg. § 1.1502–77(a). Further, under T.C. Rule 34(a), a single petition may be filed in response to all notices of deficiency directed to a husband and a wife individually, or in response to a notice directed to a person and one or more other persons (such as in the case of ex-spouses concerning a joint liability).

2. The court may file any single petition in which multiple parties have joined without regard to whether joinder is permissible T.C. Rule 61. The court will not permit joinder after a petition has been filed. Thus, it is up to the Field attorney to determine whether the joinder is proper under the court’s rules. The court has discretionary power to sever as to either multiple parties or multiple statutory notices addressed to the same person. For example, an executor of an estate may conceivably receive three separate statutory notices:



   - A notice of deficiency as the fiduciary for the estate

   - A notice of transferee liability as an individual transferee liable for assets received

   - A notice of deficiency as an executor whose individual estate is charged for distributions under 31 U.S.C. § 3713.


3. In some situations, the court may not be aware of circumstances which would justify a separation of parties or of statutory notices. In such cases, the Field attorney should consider filing a motion to sever. T.C. Rule 61.

4. Before filing a motion to sever under T.C. Rule 61(b) upon the basis of a misjoinder of party petitioners, the petitioners, or their counsel, should be contacted and every effort made to persuade the petitioners to correct the misjoinder by filing separate petitions.


**35.3.3.10.1** **(08-11-2004)**

#### One Petition from Two or More Statutory Notices

1. One petition may be filed by a petitioner who has received two or more statutory notices, but the date of filing must be timely with respect to all of such statutory notices. As to any statutory notice with respect to which the petition is not timely, a jurisdictional motion should be filed with respect to the years involved in the statutory notice.


**35.3.3.10.2** **(08-11-2004)**

#### Joint Petition - Motion as to One Party

1. If one petition is filed by two parties, such as a husband and wife, and if a motion to dismiss as to one of the petitioners is filed, it will suspend the filing of the answer to the petition in the case even as to the other petitioner. Under T.C. Rule 25(c), the time for respondent to answer as to both parties begins to run from the date upon which the Tax Court serves the order disposing of the motion, unless the Court directs otherwise.


**35.3.3.11** **(08-15-2019)**

### Petitioner’s Motion to Proceed Anonymously in Whistleblower Proceedings

1. T.C. Rule 345(a) requires petitioners to seek anonymity at the same time that they file their petitions. The motion to proceed anonymously must set forth a sufficient, fact-specific basis for anonymity. The Tax Court requires that all original petitions bear the petitioner’s name. Thus, a whistleblower’s petition with the Tax Court often will include the whistleblower’s name on the petition and a motion to proceed anonymously and/or permanently seal the case will be simultaneously filed. These motions should be treated distinctly and addressed separately. When a petitioner makes a motion to proceed anonymously, the Tax Court issues an order temporarily sealing the case pending its decision on the motion.



1. Field Counsel should seek to resolve issues of anonymity early in the litigation so that the Tax Court can lift the temporary seal; however, Field Counsel need not respond to petitioner's motion to proceed anonymously or to permanently seal the case until the Tax Court so orders. Field Counsel should evaluate motions to proceed anonymously to determine whether petitioner’s assertions are vague, do not meet the requirements of T.C. Rule 345(a), or suggest that additional information must be provided to the Court to support the request for anonymity.

2. To succeed on a motion for anonymity, a petitioner must present a sufficient showing of harm that outweighs counterbalancing societal interests in knowing the whistleblower’s identity. The balance of interests may shift as litigation progresses and the Tax Court may revisit its order granting anonymity at any time.

3. To decide whether to oppose the motion to proceed anonymously, Field Counsel should evaluate the following 5 factors:


   - The severity of the threatened harm,

   - The reasonableness of the anonymous party’s fears,

   - The anonymous party’s vulnerability to such retaliation,

   - The prejudice to the government, and

   - The public interest.



     ### Note:



     The first three factors capture the weight of the whistleblower’s privacy interest. Courts will analyze those three factors collectively before discussing prejudice to the government and the public interest


2. T.C. Rule 345(b) provides that identifying information of the taxpayer to whom the whistleblower claim relates must be redacted from, or not included in, all filings. The party or non-party filing a document that contains redacted information must also file under seal a reference list that identifies the redacted information. The reference list may be amended as of right and may be unsealed at the Tax Court’s discretion. _See generally_ CCDM 35.4.6.5.2, _Protective Order Procedures, Whistleblower Proceedings_.



1. While the case is under seal, Field Counsel should ensure that all filings comply with the requirements of T.C. Rules 27 and 345(b). T.C. Rule 27 applies in the same manner that it does in non-whistleblower cases. T.C. Rule 345(b) imposes additional redaction requirements pertaining to identifying information of third-party taxpayers. Field Counsel should comply with the redaction requirements of T.C. Rule 345(b) regardless of whether the case is under temporary seal and agree with petitioner as to anonymous identifiers to use in the redactions.

2. Filings in sealed cases require special handling. The Tax Court does not permit electronic filing of any sealed filings. Sealed filings must be paper filed with the Tax Court. An original and one copy must be mailed to the Clerk’s office. The caption of the filing should read "Filed Under Seal," rather than "Filed Electronically" below the docket number. The filing should be sealed in a second, internal envelope that bears the text “Filed Under Seal” and the docket number.

3. The Tax Court has broad discretionary authority to control and seal files in its possession. The Tax Court may initially conceal information, but as the case develops, the public’s interest in access to the case may eventually outweigh the factors in favor of sealing or proceeding anonymously and the Tax Court may revisit the issue.

4. The Tax Court will first consider whether allowing the petitioner to proceed anonymously is appropriate, and then consider whether to seal the record, because proceeding anonymously (without sealing the record) will in large measure preserve the public interest in judicial proceedings.

5. Common factors that will weigh in favor of proceeding anonymously include highly sensitive and personal information, physical harm, other significant harm, social or professional stigma, economic retaliatory harm, or being a confidential informant. A mere assertion of annoyance, embarrassment, or harm to a person’s personal reputation is generally insufficient to overcome the presumption in favor of public access to court records.

6. Evidence of a prior public disclosure in another forum will weigh against proceedings anonymously but does not preclude the Tax Court from sealing the record.



      ### Note:



      T.C. Rule 345 does not require that confidential taxpayer information be sealed or otherwise protected in whistleblower proceedings. The Tax Court addresses the need to protect non-party taxpayer information on a case-by-case basis. _See_ CCDM 35.4.6.5.2, _Protective Order Procedures, Whistleblower Proceedings_.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-003-003#addtoany "Show all")

A2A