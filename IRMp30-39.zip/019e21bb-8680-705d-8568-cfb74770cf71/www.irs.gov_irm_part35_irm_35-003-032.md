---
url: "https://www.irs.gov/irm/part35/irm_35-003-032"
title: "35.3.32 Motions in Passport Cases | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-003-032#main-content)

- 35.3.32  [Motions in Passport Cases](https://www.irs.gov/irm/part35/irm_35-003-032#idm140024405627552)
  - 35.3.32.1  [Motion to Change or Correct Caption](https://www.irs.gov/irm/part35/irm_35-003-032#idm140024405640112)
  - 35.3.32.2  [Motions to Dismiss on the Ground of Mootness](https://www.irs.gov/irm/part35/irm_35-003-032#idm140024405638112)
  - 35.3.32.3  [Motion to Dismiss for Lack of Jurisdiction](https://www.irs.gov/irm/part35/irm_35-003-032#idm140024405634640)
  - 35.3.32.4  [Motion to Dismiss for Failure to State a Claim](https://www.irs.gov/irm/part35/irm_35-003-032#idm140024405291552)
  - 35.3.32.5  [Motion for Summary Judgement](https://www.irs.gov/irm/part35/irm_35-003-032#idm140024405287136)

# Part 35. Chief Counsel Directives Manual Tax Court Litigation

# Chapter 3. Motions

# Section 32. Motions in Passport Cases

* * *

## 35.3.32 Motions in Passport Cases

#### Manual Transmittal

September 14, 2023

#### Purpose

(1) This transmits a new section to CCDM 35.3.32, Motions in Passport Cases.

#### Material Changes

(1) CCDM 35.3.32 describes the various motions that may be filed in response to a section 7345 passport case and when each may be appropriate.

#### Effect on Other Documents

New CCDM section 35.3.32.

#### Audience

Chief Counsel

#### Effective Date

(09-14-2023)

Robert T. Wearing

Deputy Associate Chief Counsel

(Procedure and Administration)

**35.3.32.1** **(09-14-2023)**

### Motion to Change or Correct Caption

1. The Tax Court assigns docket numbers with a "P" suffix to passport cases. If the petition seeks review of a certification but the Court did not add the suffix to the case number, attach a copy of the certification notice to the answer. If the filing of the answer does not cause the Tax Court to add the suffix "P" to the case docket number, a motion to change the caption should be filed.


**35.3.32.2** **(09-14-2023)**

### Motions to Dismiss on the Ground of Mootness

1. A motion to dismiss on the ground of mootness is filed when there is no longer a case or controversy for the Tax Court to adjudicate. In a passport case, a case is moot when the certification has been reversed and the Department of State has been notified of the reversal. If the attorney determines that the certification was erroneous, or the certification should be reversed because the debt is no longer considered seriously delinquent, the certification should be reversed prior to the filing of the motion to dismiss.

2. A motion to dismiss for mootness should be filed when the certification was reversed prior to the filing of the petition.

3. A subsequent certification may prevent a taxpayer from being decertified even when the original certification is reversed. If there is an issue regarding whether a case is moot, coordinate with Associate Chief Counsel (P&A), Branch 3 or 4.


**35.3.32.3** **(09-14-2023)**

### Motion to Dismiss for Lack of Jurisdiction

1. A motion to dismiss for lack of jurisdiction should be filed in a passport case:



1. When the Service has not certified the taxpayer as having a seriously delinquent tax debt.

2. When a challenge to the certification is brought under the APA, because judicial review is specifically and exclusively governed by section 7345.


**35.3.32.4** **(09-14-2023)**

### Motion to Dismiss for Failure to State a Claim

1. A motion to dismiss for failure to state a claim should be filed in a passport case:



1. When the taxpayer raises only a challenge to the underlying liability. A challenge to the underlying liability includes challenges to the amount or propriety of the assessment.

2. When the taxpayer raises only frivolous arguments.

3. When the taxpayer requests monetary damages or other relief not available under section 7345.


2. The motion should explain how the petition does not allege any error that is within the scope of the court’s jurisdiction under section 7345 to redress or how the petition requests relief beyond what the statute permits.


**35.3.32.5** **(09-14-2023)**

### Motion for Summary Judgement

1. The motion should demonstrate that the certification was proper, because at the time of certification each of the statutory elements of section 7345(b) were met, and none of the statutory or discretionary exceptions applied. The motion must further establish that no condition requiring reversal exists at the time of the motion.

2. The motion should attach the Form 4340 transcripts and, if necessary, declarations.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-003-032#addtoany "Show all")

A2A