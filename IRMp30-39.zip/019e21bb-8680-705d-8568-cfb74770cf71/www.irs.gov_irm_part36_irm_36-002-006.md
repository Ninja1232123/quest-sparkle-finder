---
url: "https://www.irs.gov/irm/part36/irm_36-002-006"
title: "36.2.6 Area Counsel and Associate Chief Counsel Responsibilities in Tax Court Cases on Appeal | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part36/irm_36-002-006#main-content)

- 36.2.6  [Area Counsel and Associate Chief Counsel Responsibilities in Tax Court Cases on Appeal](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064250656)
  - 36.2.6.1  [Area Counsel Responsibilities](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392065547136)
    - 36.2.6.1.1  [Review of Tax Court Opinions](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392065532416)
    - 36.2.6.1.2  [Motions for Reconsideration of Findings or Opinion](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392065500304)
    - 36.2.6.1.3  [Area Counsel Office](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392065080288)
    - 36.2.6.1.4  [Motions to Vacate or Revise Decision](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392065196048)
    - 36.2.6.1.5  [Protective Appeals and Cross-Appeals](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392065119664)
    - 36.2.6.1.6  [Follow-up Responsibilities](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392065264752)
  - 36.2.6.2  [Associate Chief Counsel Responsibilities](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064137472)
    - 36.2.6.2.1  [Taxpayer Appeals](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392063759088)
      - 36.2.6.2.1.1  [Associate Chief Counsel Attorney/Paralegal Assignment](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064134880)
        - 36.2.6.2.1.1.1  [Check Documents](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064256928)
        - 36.2.6.2.1.1.2  [Check Jurisdiction and Venue](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064277904)
      - 36.2.6.2.1.2  [Appeal Bond](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392063500224)
        - 36.2.6.2.1.2.1  [Security for Appeal Bonds](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392065322992)
        - 36.2.6.2.1.2.2  [Multiple Decisions or Tax Years](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392063676656)
        - 36.2.6.2.1.2.3  [Appeal Bonds in Settled TEFRA Cases](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392065529504)
        - 36.2.6.2.1.2.4  [Review of Appeal Bond](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392065503392)
        - 36.2.6.2.1.2.5  [Defective Appeal Bond](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064433136)
      - 36.2.6.2.1.3  [Letter to Department of Justice](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064132128)
      - 36.2.6.2.1.4  [Files](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064138288)
        - 36.2.6.2.1.4.1  [Follow-Up Letter with Transmission of Files](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392065353104)
    - 36.2.6.2.2  [Commissioner Appeals - Adverse Opinion Review](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392065357072)
      - 36.2.6.2.2.1  [Associate Chief Counsel Attorney Assignment - Commissioner Appeals](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064773856)
        - 36.2.6.2.2.1.1  [Letter to Department of Justice](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392066645296)
          - 36.2.6.2.2.1.1.1  [Optional Preliminary Letter to Department of Justice](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392065488848)
        - 36.2.6.2.2.1.2  [Preparation and Filing of the Notice of Appeal](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064484576)
        - 36.2.6.2.2.1.3  [Notification to the Field](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392065531648)
        - 36.2.6.2.2.1.4  [Files](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064905088)
        - 36.2.6.2.2.1.5  [Dismissal of Commissioner Appeals](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064748272)
        - 36.2.6.2.2.1.6  [Circuits with Special Requirements](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064905904)
    - 36.2.6.2.3  [Protective Appeals and Cross-Appeals in Tax Court Cases](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392065522320)
      - 36.2.6.2.3.1  [Examples of Situations Requiring Protective Action](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392066660448)
      - 36.2.6.2.3.2  [Other Types of Protective Actions](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064727680)
      - 36.2.6.2.3.3  [Whipsaw Cases](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064269088)
      - 36.2.6.2.3.4  [Associate Chief Counsel Attorney Assignment — Protective Appeals and Cross-Appeals in Tax Court Cases](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392063550144)
    - 36.2.6.2.4  [Assessment of Tax in Appealed Cases](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392063546624)
      - 36.2.6.2.4.1  [Control Records](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064714768)
      - 36.2.6.2.4.2  [Overview of the Assessment Process in Appealed Tax Court Cases](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392063548432)
      - 36.2.6.2.4.3  [Master File and Nonmaster File Assessments](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392063505424)
      - 36.2.6.2.4.4  [Verification of Assessment in Non-TEFRA Cases](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392066644736)
      - 36.2.6.2.4.5  [Verification of Assessment in TEFRA Cases](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064514976)
      - 36.2.6.2.4.6  [Assessment in Commissioner Appeals](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392065347456)
        - 36.2.6.2.4.6.1  [Associate Chief Counsel Attorney Responsibilities for Assessment in Commissioner Appeals](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392065130448)
        - 36.2.6.2.4.6.2  [Area Counsel Attorney Responsibilities For Assessment in Commissioner Appeals](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392063960272)
      - 36.2.6.2.4.7  [Assessment in Nonbonded Taxpayer Appeals](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064015648)
        - 36.2.6.2.4.7.1  [Associate Chief Counsel Attorney Responsibilities For Assessment in Nonbonded Taxpayer Appeals](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064052448)
          - 36.2.6.2.4.7.1.1  [Verification of Assessment](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392065362400)
        - 36.2.6.2.4.7.2  [Area Counsel Attorney Responsibilities For Assessment in Nonbonded Taxpayer Appeals](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064995744)
          - 36.2.6.2.4.7.2.1  [Contact with Chief, Records Section, Appeals Office](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064467872)
      - 36.2.6.2.4.8  [Assessment in Bonded Taxpayer Appeals](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064153968)
        - 36.2.6.2.4.8.1  [Associate Chief Counsel Attorney Responsibilities For Assessment in Bonded Taxpayer Appeals](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064107936)
          - 36.2.6.2.4.8.1.1  [Initial Assignment](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064095792)
          - 36.2.6.2.4.8.1.2  [Notification to the Field To Assess](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064082128)
          - 36.2.6.2.4.8.1.3  [Verification of Assessment](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064011888)
        - 36.2.6.2.4.8.2  [Area Counsel Attorney Responsibilities For Assessment in Bonded Taxpayer Appeals](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392063974176)
          - 36.2.6.2.4.8.2.1  [Initial Contact with Appeals Office](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392063959744)
          - 36.2.6.2.4.8.2.2  [Receipt of Notification of Need to Assess](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392063826464)
          - 36.2.6.2.4.8.2.3  [Notification to Appeals to Assess](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392063803392)
          - 36.2.6.2.4.8.2.4  [Assessment in Non-TEFRA Cases](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392063796368)
          - 36.2.6.2.4.8.2.5  [Assessment in TEFRA Cases](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392063786160)
          - 36.2.6.2.4.8.2.6  [Monitor Collection Activity and Notify Tax Court](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392063773920)
          - 36.2.6.2.4.8.2.7  [Closing Bonded Cases in the Field](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392063748592)
      - 36.2.6.2.4.9  [Assessment in Cases Remanded to the Tax Court](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392063736544)
      - 36.2.6.2.4.10  [Assessment in Cases Involving Defective Appeal Bonds](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392063722624)
    - 36.2.6.2.5  [Closing Procedures Specific to Tax Court Appeals](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392063713776)
      - 36.2.6.2.5.1  [Preparing and Transmitting Closed Files](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064001856)
      - 36.2.6.2.5.2  [Closing Memorandum for Tax Court Cases](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392066647872)
      - 36.2.6.2.5.3  [Time for Closing Tax Court Appeals](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064121408)
      - 36.2.6.2.5.4  [Closing Bonded Cases in the Associate Chief Counsel Office](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064166832)
      - 36.2.6.2.5.5  [Closing CDP Cases to the Office of Appeals After Tax Court Decision is Final](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392065289712)
        - 36.2.6.2.5.5.1  [Determining When the Court of Appeals Judgment is Final](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064290144)
        - 36.2.6.2.5.5.2  [After a Final Court of Appeals Judgment or Order is Entered](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392064504912)
        - 36.2.6.2.5.5.3  [After the Tax Court CDP Decision Is Final](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392065399328)
      - 36.2.6.2.5.6  [Closing Whitleblower Cases to the Whistleblower Office after Tax Court Decision is Final](https://www.irs.gov/irm/part36/irm_36-002-006#idm140392065514528)

# Part 36. Chief Counsel Directives Manual Appellate Litigation and Actions on Decision

# Chapter 2. Appeal/Certiorari Recommendations

# Section 6. Area Counsel and Associate Chief Counsel Responsibilities in Tax Court Cases on Appeal

* * *

## 36.2.6 Area Counsel and Associate Chief Counsel Responsibilities in Tax Court Cases on Appeal

#### Manual Transmittal

May 12, 2022

#### Purpose

(1) This transmits revised CCDM 36.2.6, Appeal/Certiorari Recommendations; Area Counsel and Associate Chief Counsel Responsibilities in Tax Court Cases on Appeal

#### Background

CCDM 36.2.6 is being revised to provide changes in procedures for the transmittal of Tax Court legal files to the Department of Justice upon appeal of a Tax Court case.

#### Material Changes

(1) CCDM 36.2.6.2.4 is revised to reflect that Tax Court legal files should only be sent to the Department of Justice if requested by the Department of Justice attorney assigned to the appeal.

(2) CCDM 36.2.6.2.2.1.4 is revised to reflect that Tax Court legal files should only be sent to the Department of Justice if requested by the Department of Justice attorney assigned to the appeal.

#### Effect on Other Documents

This section supersedes CCDM 36.2.6, dated 08-19-2019. This section incorporates procedures found in Chief Counsel Notice 2022-005, dated 05-05-2022.

#### Audience

Chief Counsel

#### Effective Date

(05-12-2022)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**36.2.6.1** **(08-11-2004)**

### Area Counsel Responsibilities

1. See CCDM 36.1.1.5, Responsibilities of Division Counsel in Appeal Cases, for responsibilities of Area Counsel in appeal cases in general.


**36.2.6.1.1** **(08-11-2004)**

#### Review of Tax Court Opinions

1. See CCDM 35.9.1.2, Review of Tax Court Opinions.


**36.2.6.1.2** **(08-11-2004)**

#### Motions for Reconsideration of Findings or Opinion

1. Motions for reconsideration of findings or opinion are discussed fully at CCDM 35.9.1.2.4, Motions for Reconsideration of Findings or Opinion. When prepared by the Area Counsel attorney, the motions must be reviewed by the appropriate Associate Chief Counsel and approved by the Chief Counsel.


**36.2.6.1.3** **(08-11-2004)**

#### Area Counsel Office

1. The Area Counsel for the field office that tried the case may recommend appeal of cases decided adversely to the Commissioner. Some Division Counsel require that the Area Counsel recommendation receive Division Counsel approval. If an appeal recommendation is made, it must be submitted by a separate memorandum explaining the basis for the recommendation in light of the considerations set forth at CCDM 36.2.1.1, Preparation of Appeal Letters.

2. Whether or not an appeal recommendation is made, the Area Counsel attorney should not advise the taxpayer or the taxpayer's counsel of the status of a Commissioner appeal until a final decision has been made by the Solicitor General. For this purpose, the form memorandum recommending no appeal (see Exhibit 36.4.1–10, "No Appeal" Memorandum) does not constitute a final decision on appeal.

3. If files have not been previously forwarded to the Associate Chief Counsel office, the Area Counsel attorney should transmit the legal and miscellaneous law files for appealed Tax Court cases to the Department of Justice. The files for an appealed case must contain the trial transcript and all exhibits. In addition, when the Area Counsel attorney is notified by the Associate Chief Counsel office of a taxpayer appeal, the Area Counsel attorney should ensure that an entered copy of the Tax Court decision (i.e., signed and dated) is in the legal file.

4. The Area Counsel office should maintain records of the assessment status of each appealed case. Area Counsel's responsibilities regarding assessment and actions on remand are discussed at CCDM 36.2.6.2.4 and CCDM 36.2.5.12, Cases Remanded to the Tax Court/Recomputations.


**36.2.6.1.4** **(08-11-2004)**

#### Motions to Vacate or Revise Decision

1. These motions are discussed fully at CCDM 35.9.1.3.2.1, Motions to Vacate or Revise Decision. When prepared by the Area Counsel attorney, such motions must be reviewed in the Associate Chief Counsel office with subject matter jurisdiction and, if the decision has become final, approved for filing by the Associate Chief Counsel (P&A).


**36.2.6.1.5** **(05-16-2012)**

#### Protective Appeals and Cross-Appeals

1. These appeals are discussed fully at _CCDM 36.2.6.2.3_, Protective Appeals and Cross-Appeals in Tax Court Cases. Because the Field attorney is more familiar with all of the nuances of the case, he or she has the primary responsibility for the initiation of protective action in a case or in a related case (whether or not the related case was consolidated and tried with the principal case). Division Counsel's recommendation should be conveyed by memorandum to the Associate Chief Counsel attorney assigned to the case.


**36.2.6.1.6** **(08-11-2004)**

#### Follow-up Responsibilities

1. Area Counsel attorneys should consult the provisions of CCDM 36.2.5.12, Cases Remanded to the Tax Court/Recomputations, and _CCDM 36.2.6.2.4_ for assessment responsibilities.


**36.2.6.2** **(08-11-2004)**

### Associate Chief Counsel Responsibilities

1. The Associate Chief Counsel office has the responsibility of referring taxpayer appeals to the Department of Justice for defense and preparing recommendations to the Department of Justice regarding the prosecution of appeals from adverse Tax Court decisions. See CCDM 35.9.1.2, Review of Tax Court Opinions, for provisions regarding the review of Tax Court opinions and decisions.

2. The Associate Chief Counsel attorney recommending appeal is responsible for the filing of the notice of appeal or protective notice of appeal. See CCDM 36.2.5.6, Notices of Appeal, and CCDM 36.2.5.6.4, Time for Filing Notice of Appeal.

3. The responsible attorney should prepare the appeal recommendation early, preferably before the decision is entered. The appeal recommendation should be made to the Associate Chief Counsel no later than 45 days after the decision is entered. If an appeal recommendation is later than 45 days after the decision is entered, the responsible attorney must explain the delay and supply an interim report to the Associate Chief Counsel. This 45-day report is in addition to the automated TLCATS tracking system.

4. On rare occasions, the Associate Chief Counsel attorney may be responsible for preparing documents relating to the record in Commissioner appeals and filing these documents with the Tax Court, or taking necessary action to obtain an adequate record in taxpayer appeals. See CCDM 36.2.5.9, Record on Appeal.


**36.2.6.2.1** **(08-11-2004)**

#### Taxpayer Appeals

1. When a taxpayer appeals, the Clerk of the Tax Court serves the notice of appeal upon the Commissioner. Service on behalf of the Government is accepted by the Docket, Records & User Fee Branch, Associate Chief Counsel (P&A).

2. The appeal package served by the Tax Court contains:



   - The notice of appeal

   - The notice of filing of the appeal

   - The docket entries

   - A copy of any appeal bond filed by the taxpayer, together with the Tax Court's handwritten notation on the appeal documents showing whether or not a bond was filed


3. The Records Unit forwards the appeal package to the Technical Services Support Branch of the Associate Chief Counsel (P&A). The appeal is recorded on an appeal card (index card file) and on TLCATS. A notation is made on the appeal card as to whether or not the appeal is bonded, and Y (bonded) or N (not bonded) is entered on the TLCATS appeal screen (CAPP).

4. A TLCATS message is transmitted to the Area Counsel office that handled the case in the Tax Court which includes the following information:



   - That the taxpayer filed a notice of appeal

   - The date of filing

   - The court of appeals to which the appeal was taken

   - Whether or not an appeal (review) bond was filed

   - Directions for assessment if no bond was filed

   - A request that verification of the assessment be sent to the Associate Chief Counsel (P&A)

   - A request that the legal files for the case be transmitted to the Department of Justice


5. The Technical Services Support Branch transmits the appeal package and the original and three copies of Form 9725, Non-TEFRA Cases Only (Memorandum), (Form 9724, TEFRA Cases Only (Memorandum)) to the responsible Associate Chief Counsel office. A TLCATS sheet is generated, which lists the attorney or paralegal responsible for preparing the notification to the Department of Justice of the taxpayer's appeal.


**36.2.6.2.1.1** **(08-11-2004)**

##### Associate Chief Counsel Attorney/Paralegal Assignment

1. The responsible attorney/paralegal assigned to the case should take the following steps.


**36.2.6.2.1.1.1** **(08-11-2004)**

###### Check Documents

1. The attorney or paralegal should have:



   - The TLCATS or other assignment sheet

   - The three notices comprising the appeal package

   - Form 9725 (Form 9724 for TEFRA cases)

   - A copy of the Tax Court opinion

   - A copy of the Tax Court decision

   - A copy of the appeal bond, if one has been filed


2. **Form 9725 (Form 9724)**. These forms are included as Exhibits 36.4.1–14 and 36.4.1–15, and instructions regarding their use can be found at _CCDM 36.2.6.2.4.7_. Form 9724 is used exclusively in TEFRA cases.



### Note:



In TEFRA cases, only the tax matters partner/person, a notice partner/shareholder, or a five percent group may seek review on behalf of a TEFRA entity of a decision by a court. Section 6226(g). The Associate Chief Counsel attorney should recommend dismissal of an appeal filed by any other person unless ratification by a proper person or group is appropriate. The recommendation of dismissal should be made in the letter notifying the Department of Justice of the taxpayer's appeal, which is discussed below.


**36.2.6.2.1.1.2** **(08-11-2004)**

###### Check Jurisdiction and Venue

1. The attorney/paralegal should verify that the taxpayer's notice of appeal was timely filed and that the court of appeals requested to review the decision is the circuit of proper venue. The Clerk of the Tax Court will ordinarily file an untimely notice of appeal or one filed for an improper venue. Therefore, the responsibility is on the Associate Chief Counsel attorney to determine whether the court of appeals has jurisdiction and venue of the case, and if not, to make recommendations (in the letter of notification to the Department of Justice) to have the appeal dismissed. See CCDM 36.2.5.8, Venue on Appeal, for a discussion of venue for appeal purposes.



### Note:



A notice of appeal that refers to the opinion or its filing date but is filed after entry of the decision should be viewed as an appeal from the decision.

2. If the notice of appeal is not timely filed, that fact should be set forth in the letter to the Department of Justice with a recommendation that an issue be raised as to the jurisdiction of the court of appeals. See CCDM 36.2.5.6.4, Time for Filing Notice of Appeal.


**36.2.6.2.1.2** **(05-16-2012)**

##### Appeal Bond

1. An appeal bond is an irrevocable, open-ended promise of the taxpayer to pay the deficiencies finally determined to be due, together with any interest, additional amounts, or additions to tax provided for by law. It continues the stay on assessment and collection until the appellate proceedings are concluded and the Tax Court decision becomes final. See section 7485 and Tax Court Rule 192.

2. The taxpayer must file the appeal bond with the Tax Court on or before filing the notice of appeal.

3. The Tax Court fixes the amount of the bond. The amount may not exceed double the amount of the deficiency that is the subject of the appeal. See section 7485.

4. Section 7485(a), which requires a taxpayer to post an appeal bond in order to stay collection, does not apply to collection due process (CDP) cases. By its terms, section 7485 applies only to the collection (and assessment) of deficiencies, not assessed liabilities that are the subject of a CDP case. In a CDP levy case, levy is suspended during the pendency of appeals, unless the IRS obtains a lifting of the suspension pursuant to section 6330(e)(2).


**36.2.6.2.1.2.1** **(08-11-2004)**

###### Security for Appeal Bonds

1. The taxpayer must provide security for a bond, which may be in any of the following forms:



   - A commercial surety (a surety bond that must be underwritten by a surety company approved by the Treasury Department -- see below).

   - Collateral in the form of U.S. bonds or notes (which must meet statutory requirements -- see below).

   - An irrevocable commercial letter of credit of a lawfully chartered and insured financial institution. See Form 9 and 10 of the Tax Court Rules of Practice and Procedure.


**36.2.6.2.1.2.2** **(08-11-2004)**

###### Multiple Decisions or Tax Years

1. The taxpayer may have had more than one docketed case before the Tax Court, and the dockets may have been consolidated for purposes of trial, briefing, and opinion. A separate decision will be entered for each docket number. In addition, the taxpayer may have had more than one year before the Tax Court under a single docket number. The taxpayer may appeal one or more of the decisions and may post a bond for one or more of the appeals.



1. If any one of the decisions is not appealed, the deficiencies as determined by the Tax Court in that decision will be assessed in the same manner as nonappealed cases. See _CCDM 36.2.6.2.4_.

2. If any one of the decisions is appealed without the posting of an appeal bond covering the liabilities in the decision, the deficiencies determined by the Tax Court in that decision will be assessed in the same manner as nonbonded taxpayer appeals. See _CCDM 36.2.6.2.4.7_.


**36.2.6.2.1.2.3** **(08-11-2004)**

###### Appeal Bonds in Settled TEFRA Cases

1. Cases settled under Tax Court Rule 248 are forwarded to appeals prior to the expiration of the appeal period with instructions to assess as soon as the appeal period expires. See CCDM 35.9.3.5.1, Annotating the TEFRA Case File. Thus, if such a case is appealed and an appeal bond is filed, the Area Counsel attorney with responsibility for the case must notify the Chief of the Records Sections in the local Appeals Office immediately that assessments should not be made.


**36.2.6.2.1.2.4** **(08-11-2004)**

###### Review of Appeal Bond

1. The Associate Chief Counsel attorney responsible for reviewing an appeal bond must coordinate with the Associate Chief Counsel (P&A) for approval of the amount and form of the bond.

2. In reviewing any proposed appeal bond or an appeal bond that has already been filed with the court, the attorney should ensure that the following requirements are satisfied:



1. In a non-TEFRA case, the bond must cover all years, taxes and penalties involved in the appeal. Furthermore, the bond is required to be in such an amount as to cover potential interest assessments relating to the deficiencies. See _Poinier v. Commissioner_, 90 T.C. 63 (1988); _Barnes Theatre Ticket Service Inc. v. Commissioner_, 50 T.C. 28 (1968). Except in rare and unusual circumstances (for example, where an overpayment has been determined but not refunded or credited to the taxpayer), respondent will not agree to an appeal bond in an amount less than double the determined deficiency, since it is likely that interest assessments will at least equal, and usually exceed, the deficiency amount.

2. In a TEFRA case, the bond must be in an amount sufficient to cover the aggregate of all the deficiencies of all partners/shareholders who are parties to the TEFRA proceeding.

3. The surety or letter of credit arrangement must be open-ended, that is, not subject to an expiration date that could occur during the pendency of the appeal or a reasonable time thereafter to effectuate collection. This requirement assures that the bond will remain in force until all liabilities, as finally determined, are satisfied. Additionally, the commercial surety must be one approved by the Department of the Treasury. _See_ Treasury Department Circular 570 for a list of acceptable sureties and the amounts of bonds for which they are approved, and _The Home Group, Inc. v. Commissioner_, 92 T.C. 940 (1989). Even if the surety company is listed in Circular 570, it is not an acceptable surety if the surety company is itself already primarily liable for the deficiency, e.g., as a member of the affiliated group of the taxpayer.

4. If collateral in the form of U.S. bonds or notes is posted as security, the collateral must meet statutory requirements. _See_ Treasury Department Circular 154. Other forms of collateral not consisting of obligations of the United States or obligations unconditionally guaranteed by the United States are not acceptable as collateral for an appeal bond. See _Estate of Kahn v. Commissioner_, 60 T.C. 964 (1973).


**36.2.6.2.1.2.5** **(08-11-2004)**

###### Defective Appeal Bond

1. If the bond fails to satisfy any or all of the requirements described above, the Service may either move the Tax Court to set aside its approval of the bond, _See The Home Group, Inc. v. Commissioner_, 92 T.C. 940 (1989), or assess any liabilities not covered by the bond.

2. Any motion to set aside approval of a bond must be approved by the Associate Chief Counsel (P&A) prior to filing.


**36.2.6.2.1.3** **(05-16-2012)**

##### Letter to Department of Justice

1. An appeal letter to the Department of Justice should be sent within five days of the filing of the taxpayer's notice of appeal.

2. Unlike Commissioner appeals, in taxpayer appeals it is usually not necessary to go into a detailed discussion of the facts or the law. It is sufficient if the letter includes the following:



1. Caption of the case;

2. The court to which the appeal is directed;

3. A statement as to whether the notice of appeal was filed timely or not, including the date the decision was entered, the date the notice of appeal was filed and, if the notice of appeal was filed more than 90 days after the decision date, the particulars of any post-decision motions that may have tolled the appeal period, or any relevant calendar facts (e.g., the 90 th day was a Sunday);

4. The locality of the taxpayer's legal residence or principal place of business at the time the Tax Court petition was filed;

5. The issues believed to be involved in the appeal; and

6. The name and address of the taxpayer's attorney or the taxpayer's address if he is not represented by counsel.


3. Any problems concerning what is appealed, timeliness, venue, or the substantive issues should be mentioned.

4. If the case involved a related issue decided adversely to the Commissioner and approval of the action on decision recommending acquiescence on such related issue has been withheld, the letter to the Department of Justice should set forth the related issue or issues on appeal. The letter will further request that the Department of Justice inform us within 30 days from the date of the letter whether it believes that release of the action on decision on the related issue will adversely affect defense of the appeal. If it appears that the release of acquiescence on the related issue will have the result of requiring administrative settlement of other cases, that information should also be set forth in the defense letter. See CCDM 36.3.1, Actions on Decision.

5. If the case involved an issue decided adversely to the Commissioner, the letter should include a statement that Chief Counsel does not intend to cross-appeal. If there is a need for cross-appeal, the attorney should consult CCDM 36.1.1.2.2, Protective Appeals and Cross-Appeals.

6. Attachments to the letter should include copies of the notice of appeal, notice of transmission of the record, the tax court's opinion and the appeal bond, if one has been posted.

7. A sample letter for taxpayer appeals is reproduced at Exhibit 36.4.1–16, Taxpayer Appeal Letter.


**36.2.6.2.1.4** **(05-12-2022)**

##### Files

1. Upon request by the Appellate Section attorney assigned to the case, Field Counsel will forward the legal and miscellaneous files to the Department of Justice. Typically, this will be an electronic copy of the legal and miscellaneous files. If the Appellate Section attorney requests an electronic copy of the legal and miscellaneous files, the attorney will provide instructions for transmittal. If the legal and miscellaneous files are maintained in paper and paper files are to be sent, the Field Counsel will forward the legal and miscellaneous files to the following address:



> Appellate Section, Tax Division
>
> Department of Justice
>
> P.O. Box 502
>
> Washington, D.C. 20044

2. If paper files are sent, the letter transmitting the files to Justice will direct that upon completion of appellate proceedings the files should be promptly returned for closing to the following address:



> Associate Chief Counsel (P&A)
>
> Attn: Technical Services Support Branch
>
> 1111 Constitution Ave., N.W.
>
> Washington, D.C. 20224.
>
> **_Note:_** See Exhibit 36.4.1–17, Sample Transmittal of Files to Justice.

3. The administrative file in taxpayer appeal cases remains in the field for assessment purposes.

4. When assigned a taxpayer appeal, the National Office attorney/paralegal should prepare and maintain an open folder, a file for a case on appeal. This file should contain copies of the three notices comprising the appeal package, the TLCATS assignment sheet, copies of both the Tax Court opinion and decision, a copy of the completed Form 9725 (Form 9724 in TEFRA cases), a copy of the letter to the Department of Justice, and a copy of the appeal bond, if one has been filed. Any further documents pertaining to the case on appeal should be placed in this temporary file until a closing letter is received from the Department of Justice. At that time, the temporary file should be merged with the legal file, regardless of the format (paper or electronic) of the legal file.


**36.2.6.2.1.4.1** **(08-11-2004)**

###### Follow-Up Letter with Transmission of Files

1. If the legal file and any miscellaneous law files are received from the field contrary to the procedure set forth in section _CCDM 36.2.6.2.1.4_, the Associate Chief Counsel attorney should prepare a one–paragraph transmittal letter and send the files to the Department of Justice. See Exhibit 36.4.1–17, Sample Transmittal of Files to Justice.


**36.2.6.2.2** **(05-16-2012)**

#### Commissioner Appeals - Adverse Opinion Review

1. When the Tax Court decides a case adversely to the Commissioner, in whole or in part, the case is assigned to an attorney in the appropriate Associate Chief Counsel office for the preparation of an adverse opinion review memorandum. The purpose of the adverse opinion review memorandum is twofold: to determine whether any or all the issues decided adversely to the Commissioner should be appealed; and to determine whether an action on decision should be prepared. For a full discussion see CCDM 36.3.1, Actions on Decision.

2. The attorney should prepare a brief memorandum setting forth the issues decided adversely to the Commissioner; the pertinent facts of the case; the Service's and taxpayer's position if it will add to the review; the court's holding and reasoning; and the attorney's analysis on why the court's decision is correct or, if not correct, why it is clearly erroneous or legally incorrect. While the attorney should briefly note any issues that the Service won, the attorney need not provide analysis on these issues. If the Associate Chief Counsel attorney's recommendation is to appeal any or all of the issues, the adverse opinion review memorandum will conclude with this recommendation.

3. Area Counsel's recommendation should be stated in the adverse opinion review memorandum. If the Area Counsel attorney disagrees with the Associate Chief Counsel attorney's recommendation, see CCDM 31.1.4.2, Coordination within the Office of Chief Counsel.

4. If no appeal is recommended, the Associate Chief Counsel attorney should complete the "No Appeal" memorandum reproduced at Exhibit 36.4.1–10. This memorandum also requires the attorney to provide a recommendation on issuing an AOD. See CCDM 36.3.1, Actions on Decision. The no appeal memorandum should be submitted to the attorney's reviewer, together with the adverse opinion review memorandum. If approved by the reviewer, the no appeal memorandum is forwarded to the Technical Services Support Branch and a copy is sent to the appropriate Area Counsel office.

5. If the recommendation is to appeal, and it is approved by the attorney's reviewer, the attorney will draft a letter to the Department of Justice requesting authority to prosecute the appeal. If the attorney's recommendation is not to appeal, and the recommendation is approved by the attorney's reviewer, the no appeal memorandum discussed in paragraph (4), above, is submitted to the Technical Services Support Branch and constitutes the appeal recommendation.

6. Occasionally, when the adverse opinion is significant in terms of Service practice or policy and the recommendation is not to appeal, the attorney should prepare a memorandum for the signature of the Associate Chief Counsel. This memorandum explains why, despite the significant loss, appeal is not warranted. This should be completed in sufficient time so that an appeal could be timely filed if deemed warranted by the responsible senior office executives.


**36.2.6.2.2.1** **(08-11-2004)**

##### Associate Chief Counsel Attorney Assignment - Commissioner Appeals

1. The Associate Chief Counsel attorney should check the legal and miscellaneous law files to be sure all exhibits and transcripts are accounted for. If not, see CCDM 36.2.5.9.1, Docketing and Filing the Record on Appeal.

2. The Associate Chief Counsel attorney should request from the Area Counsel office any documents thought necessary for processing the case in the court of appeals. Transmit these documents with the appeal letter and the files through the various stage of review and, ultimately, to the Department of Justice.


**36.2.6.2.2.1.1** **(08-11-2004)**

###### Letter to Department of Justice

1. See CCDM 36.2.1 , Appeal Recommendations in General, for general instructions for preparing an appeal letter.

2. The letter should clearly set forth the basis for appeal by showing how the Tax Court's opinion is in error and the administrative need for appeal. The letter should state the date of the Tax Court's decision and the venue on appeal. The attorney should consult CCDM 36.2.5.8, Venue on Appeal, for a general discussion of venue for appeal purposes, and CCDM 36.2.5.8.1, Stipulating to Venue, for stipulations of venue in Commissioner appeals.

3. Unless reflected on enclosed documents, provide the name and address of the taxpayer's attorney or, if the taxpayer is not represented by counsel, the name and address of the taxpayer.

4. State that in the event that the Department of Justice has not completed its consideration of the appeal request prior to the expiration of the appeal period, the Associate Chief Counsel attorney will file a protective notice of appeal on a specified date.

5. If an action on decision has been prepared or will be prepared that recommends acquiescence on an issue related to the issue on appeal, state that approval of acquiescence on the related issue is being withheld until the conclusion of the appellate proceedings. See CCDM 36.3.1, Actions on Decision.

6. Review of the letter must be completed by the functional Associate Chief Counsel no later than 45 days after entry of the Tax Court's decision. The letter must be approved and signed by the Chief Counsel, and received by the Department of Justice by the 60th day after entry of the Tax Court's decision.


**36.2.6.2.2.1.1.1** **(08-11-2004)**

###### Optional Preliminary Letter to Department of Justice

1. If the issue lost by the Commissioner is significant, and if it is anticipated both that the appeal letter will be delayed beyond the 60-day period and that there may be a possible conflict with the Department of Justice on the question of an appeal, the attorney will need to prepare a short preliminary letter to the Department of Justice as soon as possible after the filing of the Tax Court's opinion.

2. The preliminary letter may, in some cases, be sent even before the Tax Court decision has been entered.

3. Prepare the letter for the reviewer's signature.

4. The letter should be brief and state that



1. A copy of the Tax Court's opinion is attached,

2. It is anticipated that the Service will recommend an appeal, and

3. That the Department of Justice may want to begin its consideration of the case prior to the receipt of our formal recommendation.


**36.2.6.2.2.1.2** **(08-11-2004)**

###### Preparation and Filing of the Notice of Appeal

1. Prepare a notice of appeal at the same time the appeal letter is drafted. See CCDM 36.2.5.6, Notices of Appeal, for general provisions regarding the form, filing, and service of a notice of appeal.

2. Generally, the notice of appeal does not specify which issues are being appealed, enabling later selection of issues.

3. The notice of appeal should be signed in the names of the Chief Counsel and the Assistant Attorney General, Tax Division, Department of Justice, by the attorney's branch chief, who must be admitted to practice in the United States Tax Court. The branch chief must sign his or her own name and list his or her Tax Court bar number. See Exhibit 36.4.1–5, Notices of Appeal — Tax Court.

4. If the notice of appeal pertains to more than one docket number, see CCDM 36.2.5.6.1, Multiple Docket Numbers.

5. Determine the proper venue for the appeal. See CCDM 36.2.5.8, Venue on Appeal, for general provisions for determining venue. For venue stipulations in Commissioner appeals, the following procedures should be followed:



1. When time permits, attempt to obtain approval of the venue stipulation from the Department of Justice.

2. Send a letter to the Department of Justice with an appropriate recommendation for the stipulation of venue in the proposed appeal, and setting forth the basis for the recommendation prior to filing the notice of appeal.

3. If time does not permit formal clearance with the Department of Justice, file an appeal in both the court of proper venue and in the court of preferred venue and then make the venue recommendation to the Department of Justice.


6. Hand-carry the notice of appeal to the Technical Services Support Branch of the Office of Associate Chief Counsel (P&A) for filing with the Tax Court at least five days before the expiration of the 90-day appeal (or 120-day if a cross-appeal) period. Ideally, delivery should occur by the 45th day after the entry of the Tax Court's decision.

7. The time in which the notice of appeal must be filed may be shortened or extended in certain limited circumstances. See CCDM 36.2.5.6.4, Time for Filing Notice of Appeal.

8. Upon receipt of the notice of appeal from the attorney, the Technical Services Support Branch will send the notice to the Tax Court at least five days prior to the expiration of the appeal period.



1. The Tax Court will stamp and return copies of the notice to the Associate Chief Counsel office.

2. The Technical Services Support Branch will forward one stamped receipted copy to the responsible attorney and one to the Department of Justice.



      ### Note:



      The timely filing of a notice of appeal is so important that it cannot be overemphasized that the attorney has the primary responsibility for ensuring that the notice of appeal is received and processed by the Technical Services Support Branch and that the notice of appeal is filed with the Tax Court. This responsibility is not met by reliance on others, such as TLCATS operators, clericals, messengers, or those who maintain backup suspense systems. If the responsible attorney has not received written confirmation by the 87th day (117th day for cross-appeals) after entry of decision that the notice of appeal was filed with the Tax Court, the attorney should call the Technical Services Support Branch and request that the filing be checked immediately with the Tax Court. If, in fact, the notice of appeal was not filed, the attorney and reviewer must immediately prepare a replacement notice of appeal and personally deliver to the Tax Court (directly to the Appellate Section on the ground floor) the notice of appeal for filing by the 88th day (118th day for cross-appeals) after entry of decision.


9. Some circuits have a very short time for perfecting the appeal. Thus, whenever the Department of Justice is unaware at least five days before the notice of appeal is filed that a notice of appeal is to be filed, it is necessary to hand-carry the stamped notice of appeal, when received, to the Department of Justice.


**36.2.6.2.2.1.3** **(05-16-2012)**

###### Notification to the Field

1. The Area Counsel office that handled the case in the Tax Court will receive notification of a Commissioner appeal by a TLCATS message and Form 9725 (Form 9724 in TEFRA cases).

2. After filing the notice of appeal, the Associate Chief Counsel attorney should await the expiration of the 120-day cross-appeal period and then transmit Form 9725 or Form 9724 to the field. Form 9725 and 9724 are reproduced at Exhibits 36.4.1–14 and 36.4.1–15, respectively. See _CCDM 36.2.6.2.4.7.1_ for a full discussion of the purpose of these forms and instructions for completing and transmitting them. With the exception of the time for transmitting the form to Area Counsel, those instructions also pertain to Commissioner appeals. The purpose of awaiting the expiration of the cross-appeal period is explained at _CCDM 36.2.6.2.4.6_ and is based on different assessment procedures.


**36.2.6.2.2.1.4** **(05-12-2022)**

###### Files

1. Upon request by the Appellate Section attorney assigned to the case, send the legal and miscellaneous law files to the Department of Justice. Typically, this will be an electronic copy of the legal and miscellaneous files. If the Appellate Section attorney requests an electronic copy of the legal and miscellaneous law files, the attorney will provide instructions for transmittal. If necessary, contact P&A, Branch 8 to facilitate the transmittal of the electronic files to DOJ if the files are too large to send via encrypted email. The administrative file remains in the field.

2. Prepare and maintain an open folder, which is the temporary file for a Tax Court case on appeal. The file should contain the following:



   - TLCATS assignment sheet

   - Copies of the Tax Court's opinion and decision

   - A copy of the letter to the Department of Justice requesting authority to prosecute the appeal

   - The receipted copy of the notice of appeal

   - A completed Form 9724 or 9725

   - Any other documents relating to the case

   - Any further documents received by the attorney in connection with the case


3. Upon completion of the appellate litigation, the materials in the open folder will be merged into the legal file.


**36.2.6.2.2.1.5** **(08-11-2004)**

###### Dismissal of Commissioner Appeals

1. If the notice of appeal was filed before the Solicitor General authorized appeal, and the Solicitor General later decides against appeal, the appeal must be dismissed. When the Department of Justice has formally notified the Chief Counsel that the Solicitor General has declined to authorize further prosecution of an appeal and it becomes definite that the appeal will not be further prosecuted, immediately notify the Clerk of the Tax Court by letter of the Solicitor General's decision. This notification is provided so that the record on appeal can be retained in the court if it has not already been transmitted to the court of appeals. See CCDM 36.2.5.9, Record on Appeal.

2. The attorney's reviewer should sign the letter in the name of the Chief Counsel, and a copy should be placed in the attorney's open folder for the case. See a sample letter at Exhibit 36.4.1–7, Letter to Tax Court (Record on Appeal).

3. The Department of Justice usually dismisses appealed cases without any action by the Associate Chief Counsel attorney. Nevertheless, call the Department of Justice to ascertain whether any further action is necessary to effectuate dismissal of the appeal.

4. See CCDM 36.2.5.11, Dismissal of Appeals in Tax Court Cases.


**36.2.6.2.2.1.6** **(08-11-2004)**

###### Circuits with Special Requirements

1. Attorneys with appeals to the Seventh, Eighth, or Ninth Circuit should pay close attention to the circuit court rules for prosecuting appeals to be aware of special requirements.

2. Following are several exhibits illustrating some of the requirements for the three circuits mentioned above.



   - Exhibit 36.4.1–18 , Ninth Circuit Representation Statement, is a sample form that complies with the Ninth Circuit local rules

   - Exhibit 36.4.1–19, Seventh Circuit Docketing Statement, is a sample statement for the Seventh Circuit

   - Exhibit 36.4.1–20, Eighth Circuit Appellant’s Form A, Appeal Information Form, is a sample that complies with the Eighth Circuit local rules

   - Exhibit 36.4.1–21, Eighth Circuit Appellee’s Form B, Appeal Information Form, is a sample form that complies with the Eighth Circuit local rules


**36.2.6.2.3** **(08-11-2004)**

#### Protective Appeals and Cross-Appeals in Tax Court Cases

1. The difference between a protective appeal and a cross-appeal is discussed in CCDM 36.1.1.2.2, Protective Appeals and Cross-Appeals. As noted, the need for protective action is not limited to Tax Court cases. Protective appeals may also be necessary in related district court and Court of Federal Claims cases involving the same basic issues or transactions. Because Chief Counsel attorneys have different responsibilities for cases filed in Tax Court, the procedures for filing protective appeals and cross-appeals in Tax Court cases are addressed separately in this section.

2. Care must be exercised in determining whether a protective appeal or a cross-appeal should be filed, as the procedure to be followed will differ for each. A protective appeal is treated in the same manner as a regular Commissioner appeal, and the procedures for an appeal letter, etc., are required. See CCDM 36.2.1, Appeal Recommendations in General, and _CCDM 36.2.6.2.2_.

3. The Associate Chief Counsel attorney should carefully examine each case to determine whether protective action is required because the need for such action is not evident in every case. Heavy reliance will be placed on the recommendations of Area Counsel attorneys due to their greater familiarity with all aspects of the case.


**36.2.6.2.3.1** **(08-11-2004)**

##### Examples of Situations Requiring Protective Action

1. The following are examples of situations requiring protective or cross-appeals.

2. Disputes over the year in which an item should be taxed or a gift deemed to be made. If the tax years in question are included in the same docket, a cross-appeal should be recommended. If the years are in different dockets, a protective appeal will be necessary.

3. Disposition of an item for one year causes a correlative change in another tax year (either as to the petitioner or as to a related taxpayer). This is often found in cases involving the correct tax treatment of an element affecting basis (and which may not be covered by sections 1311–1314). As a general rule, even when the revenue may possibly be protected under such statutory provisions, it may be appropriate to file a notice of appeal or to take other protective action.

4. Income items or deductions may be either that of taxpayer A or taxpayer B, but not both. This includes alimony, partnerships, joint ventures, certain community property income questions, stockholder-corporation issues, dependency exemptions, and goodwill versus a covenant not to compete.

5. Determination of one tax correlatively affects the computation of a related tax. For example, with respect to income and estate taxes, and estate and gift taxes.

6. When the Service presents alternative theories to support a deficiency in a single year and the court sustains the deficiency based on one of the theories, but rejects another theory. The tax liability computed under the alternative theories may be different amounts. When the liability redetermined by the court is less than the amount contended under an alternative theory, it may be advisable to file an appeal or cross-appeal to sustain the greater tax.

7. When the alternative theories result in the same amount of tax, the proper course of action is to expand the taxpayer appeal letter to the Department of Justice by urging the department to continue the argument of the alternative theory rejected by the Tax Court or recommending a remand to the Tax Court to decide the alternative theory should the taxpayer prevail on appeal. A cross-appeal is not necessary since our alternative arguments can be raised on defense of the taxpayer's appeal notwithstanding rejection of the arguments by the Tax Court. Cross-appeals are only appropriate where the taxpayer has appealed an issue or issues and we wish to raise an issue or issues which, if successful, would increase the deficiency, not simply keep it as determined by the Tax Court.

8. When the Service has recommended to the Department of Justice that a case be appealed and the Solicitor General has not acted on the recommendation before the expiration of the time to file a notice of appeal, the Service will file a protective notice of appeal in a Tax Court case. See _CCDM 36.2.6.2.2_.


**36.2.6.2.3.2** **(08-11-2004)**

##### Other Types of Protective Actions

1. It may be necessary to consider protective action to preserve the Commissioner's interests in multiple petition cases when one taxpayer seeks an interlocutory appeal.



### Example:



Assume deficiency notices are issued to former spouses who have taken inconsistent positions, and their cases are consolidated for trial, briefing, and opinion. When the former husband files a motion for certification of a question for appeal, the Service should request that the Tax Court withhold entry of a final decision in the former wife's case pending determination of the former husband's motion for certification. See CCDM 36.2.5.4, Interlocutory Appeals from Tax Court Orders.

2. When protective action other than protective or cross-appeal is necessary, the attorney's reviewer should be consulted prior to beginning the assignment.


**36.2.6.2.3.3** **(08-11-2004)**

##### Whipsaw Cases

1. Not all cases in which a protective appeal situation could arise justify the filing of a protective appeal. Whipsaw cases are per se among those that often do not justify protective action.



### Example:



In a situation involving the characterization of divorce payments (alimony vs. property settlement), if the losing party indicates no appeal will be filed, no protective appeal need be filed against the prevailing spouse.

2. In other whipsaw situations, protective appeals need not be filed where there is no appreciable possibility that the losing party could prevail on appeal. Judgment in these situations, considering the effort of the appeal, and the amount of revenue at stake, is required.

3. In certain whipsaw situations, the Service may take a position as to which taxpayer should prevail. In some situations, the Service expresses no preference.



### Example:



In the situation where the Service determines a deficiency and penalty against both A and B, but takes the position that A is correct, care must be taken when recommending protective appeal action. If the Tax Court agrees with the Service and holds for A, the Service may nevertheless file a protective appeal of A's case in order to protect the revenue in the event of a successful appeal by B. In such a case, the Service should only appeal the deficiency and not the negligence penalty. At least one court of appeals has criticized the Service for imposing the negligence penalty in such a situation.


**36.2.6.2.3.4** **(08-11-2004)**

##### Associate Chief Counsel Attorney Assignment — Protective Appeals and Cross-Appeals in Tax Court Cases

01. While completing a favorable or adverse opinion review, or upon assignment of a taxpayer appeal, be alert to any circumstances that would indicate that the Commissioner should file a protective or cross-appeal. Consider any recommendation by Area Counsel for protective action.

02. If Area Counsel has not made a recommendation, and protective action might be necessary, contact the Area Counsel attorney who handled the case in the Tax Court and discuss the need to have the favorable decision and the adverse decision entered by the court at or very near the same time. Most appeals courts require the Government to actively prosecute a protective appeal, even where the taxpayer has not yet appealed. Simultaneous entry of decision prevents the premature prosecution of these appeals.

03. Once the decision to file a protective appeal or cross–appeal has been approved by the reviewer, prepare an appeal letter (see paragraph (6), below) and the notice of appeal for filing with the Tax Court. See CCDM 36.2.5.6, Notices of Appeal, and _CCDM 36.2.6.2.2_. Except to the extent set forth below, the procedures for filing protective notices of appeal and cross–appeals are governed by those sections. Sample notices of appeal are reproduced at Exhibit 36.4.1–5, Notices of Appeal — Tax Court. As a protective appeal generally involves multiple docket numbers, the attorney should pay particular attention to CCDM 36.2.5.6.1, Multiple Docket Numbers.

04. Filing the notice of appeal in a protective appeal:



    1. A protective notice of appeal must be filed within the 90-day period following the entry of the Tax Court's decision. See CCDM 36.2.5.6.4, Time for Filing Notice of Appeal.

    2. The notice of appeal must be hand-carried by the attorney to the Technical Services Support Branch in the Office of the Associate Chief Counsel (P&A) for filing with the Tax Court promptly after the decision to file a protective notice of appeal has been made.

    3. The Technical Services Support Branch should receive the notice of appeal at least five days before the expiration of the 90-day appeal period, since the notice should be filed on the 85th day after entry of the Tax Court decision.



       ### Caution:



       At least two circuits have, in the protective appeal situation, permitted the adverse party the benefit of the 120-day cross-appeal period. _Estate of Lang v. Commissioner_, 613 F.2d 770, 771 n.1 (9th Cir. 1980); _Estate of Lidbury v. Commissioner_, 800 F.2d 649 (7th Cir. 1986); _but see Davies v. Commissioner_, 715 F.2d 435 (9th Cir. 1983) (taxpayer could not use 120-day period since not party to the same decision). _Despite these cases, it is office policy to file all protective appeals within the 90-day period._


05. Filing the notice of appeal in a cross-appeal:



    1. The notice of appeal for a cross-appeal must be filed within 120 days following the entry of the Tax Court's decision. See CCDM 36.2.5.6.4, Time for Filing Notice of Appeal.

    2. The notice of appeal must be hand-carried by the attorney to the Technical Services Support Branch for filing with the Tax Court promptly after the decision to file a cross-appeal has been made.

    3. Ideally, the notice of appeal should be delivered to the Technical Services Support Branch at the same time the letter in the taxpayer's appeal is sent to the Department of Justice. See CCDM 36.2.1, Appeal Recommendations in General. In any event, the Technical Services Support Branch should receive the notice of appeal at least five days before the expiration of the 120-day cross-appeal period.


06. Letter to Department of Justice regarding protective appeals in whipsaw situation. Prepare a letter to the Assistant Attorney General, Tax Division, Department of Justice, requesting authorization to file and prosecute an appeal for protective purposes only, and stating that the appeal should be dismissed if the taxpayer does not file an appeal in the related case. A sample letter is reproduced at Exhibit 36.4.1–22, Protective Appeal Letter. Review and approval of a protective appeal letter is the same as a regular Commissioner appeal letter. See CCDM 36.2.1.1, Preparation of Appeal Letters, and _CCDM 36.2.6.2.2_ .

07. If the taxpayer does not file an appeal in the related case, the attorney should contact the Department of Justice to determine whether any further action is required to effect the dismissal of the appeal.

08. If the taxpayer files a notice of appeal in the related case, prepare the appeal letter to the Department of Justice. In the appeal letter, the protective appeal should be noted and, if necessary, more detail of the office's position should be provided.

09. Communication with the Department of Justice regarding cross-appeals:



    1. If a cross-appeal is recommended, generally there will be no communication with the Department of Justice unless the taxpayer files a notice of appeal. The letter to the Department of Justice in a taxpayer appeal is to be sent to the department within five days of the taxpayer's notice of appeal.

    2. If, however, the taxpayer files a notice of appeal on the 90th day and a cross-appeal is recommended, the letter should be sent to the Department of Justice within two working days after the service of the notice of the taxpayer's appeal. In drafting the letter, include the cross-appeal recommendation. See _CCDM 36.2.6.2.1.3_ for provisions regarding the letter.


10. If an appeal is filed by the Commissioner or the taxpayer strictly for protective purposes, and the other party does not file a notice of appeal, the protective appeal should be dismissed.


**36.2.6.2.4** **(08-13-2019)**

#### Assessment of Tax in Appealed Cases

1. In appealed Tax Court cases:



1. The Associate Chief Counsel attorney is responsible for ensuring that Area Counsel receives timely notification to initiate assessment.

2. Area Counsel is responsible for ensuring that the appeals office receives timely notification.

3. The Appeals office is responsible for the timely making of the assessment request to the appropriate Area Director's office.


2. If an appellate court reverses or modifies the Tax Court's decision and remands to the Tax Court for entry of a new decision or for a rehearing, the case is generally transferred from the Associate Chief Counsel office to Area Counsel for any further required action, including assessment or abatement activity. See CCDM 36.2.5.12, Cases Remanded to the Tax Court/Recomputations, for provisions regarding cases remanded to the Tax Court and _CCDM 36.2.6.2.4.9_ for assessment in remanded Tax Court cases.

3. A referral to the Department of Justice of a Tax Court case on appeal terminates upon completion of the appellate litigation and the case’s return to the Service. Once an appealed Tax Court case has been returned, the Service does not need the Department of Justice to consent before entering into a compromise. See CCDM 33.3.2.4, _Offers in Cases Handled by the Department of Justice_.


**36.2.6.2.4.1** **(08-11-2004)**

##### Control Records

1. The Associate Chief Counsel office, the Technical Services Support Branch and assigned attorneys should maintain records (including but not limited to TLCATS) showing the assessment status of all cases on appeal. The Area Counsel office should also maintain such records.


**36.2.6.2.4.2** **(05-16-2012)**

##### Overview of the Assessment Process in Appealed Tax Court Cases

1. The procedures to be followed by Associate Chief Counsel attorneys and Area Counsel attorneys in completing their assessment responsibilities will vary depending on the classification of the case on appeal; i.e., Commissioner appeals, nonbonded taxpayer appeals, or bonded taxpayer appeals. The attorney should consult the sections below that are relevant to assessment in each type of case.

2. In general, the following steps are taken:



1. The Associate Chief Counsel attorney notifies the Area Counsel attorney of the need to assess by transmitting Form 9725 in non-TEFRA cases or Form 9724 in TEFRA cases. See Exhibits 36.4.1–14, Form 9725, and 36.4.1–15, Form 9724.

2. The Area Counsel attorney then notifies the local appeals office of the need to assess by sending Form 1734, Transmittal Memorandum, and the administrative file.

3. The Appeals office then prepares Form 5403, Appeals Closing Record, and forwards it to the appropriate function in the Area Director's office. Form 5403 is a standard closing form designed to contain all of the information required to make a proper assessment.

4. In a non-TEFRA case, information from Appeals' Form 5403 is used to prepare a Form 2859, Request for Quick or Prompt Assessment.



      ### Note:



      Definitions for quick and prompt assessments may be found in IRM 3.17.243.2, Reversal of Erroneous Abatements. A quick assessment is always made when the statute of limitations on assessment is close to expiration. (See _CCDM 36.2.6.2.4.6_ for time limitations on assessment.) Requests for quick assessment are made by telephone, teletype, or facsimile when the statutory period for assessment will expire within 30 days.

5. In a TEFRA case, the appeals office will prepare a Form 3210, Document Transmittal, to be sent to the Examination Support Unit (ESU) responsible for the key case requesting computation and assessment of deficiencies and interest at the investor level within one year of the date of the notice of appeal in Commissioner appeals and non-bonded taxpayer appeals and within one year of the date the Tax Court decision becomes final in bonded taxpayer appeals.


**36.2.6.2.4.3** **(08-11-2004)**

##### Master File and Nonmaster File Assessments

1. Master file assessments are eventually posted to the master file computer in Martinsburg, West Virginia, and appear on official transcripts of account. Nonmaster file assessments are relatively uncommon and are never posted to the master file.

2. Even though quick and prompt assessments (as well as jeopardy and termination assessments) may be either master file or nonmaster file transactions, they are all made by the nonmaster file unit at each Internal Revenue Service Campus and are typically referred to as manual assessments.

3. In quick and prompt assessments (as well as jeopardy and termination assessments), the person making the assessment request determines the date by which the assessment must be made. Associate Chief Counsel and Area Counsel attorneys can thus assure performance by a date certain.

4. Absent a statute of limitations expiration date (see CCDM 35.9.2.2, Time Limitation on Assessment) or a date specified by the requester, nonmaster file units are required to make quick and prompt assessments no later than the second next regular 23C date. Note, however, that posting of the transaction on the Martinsburg computer may not occur for several weeks even though the assessment has been made.


**36.2.6.2.4.4** **(08-11-2004)**

##### Verification of Assessment in Non-TEFRA Cases

1. Preferred form of verification. When the field is notified that a non-TEFRA case has been appealed by the Commissioner or the taxpayer, the Associate Chief Counsel office requests verification that assessment has been made.



1. The preferred form of verification is a copy of the taxpayer's transcript. The Appeals Closing Record (Form 5403) is simply a request by the Appeals office that assessment be made.

2. Although it states the 23C date, Form 2859, Request for a Prompt or Quick Assessment, does not constitute verification that the assessment has been made.


2. Verifying nonmaster file assessments. To verify these assessments, the attorney should call the contact person in the nonmaster file unit at the appropriate Internal Revenue Service Campus.



1. If an assessment has been made, the contact person can provide the underlying document locator number (DLN), which in turn provides the date of assessment. See Exhibit 36.4.1–23, Interpreting a 14 or 13 Digit Document Locator Number (DLN).

2. If paper verification is desired, the attorney can send Form 4338, Information or Certified Transcript Request, to request a copy of the unit ledger card.


3. Exhibit 36.4.1–24, Contact Information for Service Centers, contains a list of contact persons for the Internal Revenue Service Campuses. The appropriate Internal Revenue Service Campus is the one at which the taxpayer filed the tax return for which a statutory notice of deficiency was issued and petitioned from, resulting in the Tax Court decision and the appeal.

4. The DLN is a 14-digit number (in some cases, 13-digit) that confirms the existence of an assessment. The DLN is generated at the time the assessment occurs. Since telephone assessment procedures are recommended in the field for non-TEFRA bonded taxpayer appeal cases, Area Counsel will generally obtain the DLN at the time of assessment and provide it to the Associate Chief Counsel attorney. See Exhibit 36.4.1–23, Interpreting a 14 or 13 Digit Document Locator Number (DLN).

5. To help the nonmaster file unit contact person locate the appropriate records, the attorney should provide the following information: taxpayers' name and address; taxpayers' social security number; type of tax; tax year or period; and approximate assessment date (such as a 23C date).

6. In non-TEFRA bonded taxpayer appeal cases, the Associate Chief Counsel attorney must verify the fact of assessment and the date of assessment. Absent a transcript this is done by interpreting the document locator number (DLN).

7. Transcripts of account showing master file assessments can be ordered through the Disclosure & Litigation Support Branch, Office of Associate Chief Counsel (P&A).


**36.2.6.2.4.5** **(08-11-2004)**

##### Verification of Assessment in TEFRA Cases

1. In Commissioner appeals and nonbonded taxpayer appeals, verification that the assessment has been made is not requested by or forwarded to the Associate Chief Counsel office. See _CCDM 36.2.6.2.4.6_ and _CCDM 36.2.6.2.4.7_.

2. For bonded taxpayer appeals, see _CCDM 36.2.6.2.4.8_.


**36.2.6.2.4.6** **(08-11-2004)**

##### Assessment in Commissioner Appeals

1. This subsection describes the procedures for assessment in commissioner appeals.


**36.2.6.2.4.6.1** **(05-16-2012)**

###### Associate Chief Counsel Attorney Responsibilities for Assessment in Commissioner Appeals

1. The Associate Chief Counsel attorneys should follow procedures set forth in _CCDM 36.2.6.2.4.7_ regarding notification to the field to assess.

2. The Associate Chief Counsel attorney is responsible for ensuring that Area Counsel receives timely notification to initiate assessment. The office practice is to assess at the earliest opportunity.

3. The general rule is that the initiation of assessment activity must await the expiration of the 120-day cross-appeal period or a taxpayer cross appeal.



1. In non-TEFRA cases, if the taxpayer does not file a cross-appeal, assessment should be made within the 60 days following the 120-day cross-appeal period.

2. In TEFRA cases, assessment should be made within one year after the date of appeal.


4. Table showing rules applicable to assessments in Commissioner appeals in non-TEFRA cases:




| _**If**_ | _**Then**_ |
| --- | --- |
| the Commissioner appeals a decision of the Tax Court in a non-TEFRA case and the taxpayer does not appeal, | the deficiency (if any) as determined by the Tax Court is to be assessed within 60 days after the expiration of the 120-day cross-appeal period. |
| the Commissioner appeals a decision of the Tax Court in a non-TEFRA case and the taxpayer files a cross appeal within the 120-day period and posts an adequate appeal (review) bond, | assessment is to be made of any amounts not covered by the bond, but the assessment of any amounts covered by the bond is barred until the decision of the Tax Court becomes final. |
| the Commissioner appeals a decision of the Tax Court in a non-TEFRA case, the taxpayer files a cross appeal within the 120-day period and posts an appeal (review) bond, but the bond does not fully cover the deficiency | a decision must be made as to whether to file a motion with the Tax Court requesting an order that the bond be remedied, or to notify the field to initiate assessment activity in the same manner as a nonbonded taxpayer appeal. See _CCDM 36.2.6.2_. |
| the taxpayer appeals only a portion of the tax liabilities determined by the Tax Court, | see CCDM 35.9.2.4, Assessment in Cases Wherein not all Liabilities Determined by the Tax Court are Appealed. |

5. In TEFRA cases, the assessment must be made within one year of the date the decision becomes final.

6. **Verification of Assessment** . Provisions regarding verification of assessment in Commissioner appeals are identical to those applicable to nonbonded taxpayer appeals. See _CCDM 36.2.6.2.4.7_for these provisions.


**36.2.6.2.4.6.2** **(08-11-2004)**

###### Area Counsel Attorney Responsibilities For Assessment in Commissioner Appeals

1. The Area Counsel attorney's responsibilities for assessment in Commissioner appeals are the same as in nonbonded taxpayer appeals. See _CCDM 36.2.6.2.4.7.2_ for these provisions.


**36.2.6.2.4.7** **(08-11-2004)**

##### Assessment in Nonbonded Taxpayer Appeals

1. This subsection describes the procedures for assessment in nonbonded taxpayer appeals for Associate Chief Counsel Attorneys and Area Counsel Attorneys respectively.


**36.2.6.2.4.7.1** **(08-11-2004)**

###### Associate Chief Counsel Attorney Responsibilities For Assessment in Nonbonded Taxpayer Appeals

1. Form 9725 and Form 9724 are memoranda from the Associate Chief Counsel (P&A) to Area Counsel and are used to:



1. Notify the field that a case has been appealed;

2. Instruct the field regarding the assessment of tax, additions to the tax and interest in non-TEFRA cases, and tax and interest in TEFRA cases; and

3. Remind the field to transmit the legal and miscellaneous law files to the Associate Chief Counsel office.



      ### Note:



      The administrative file is not to be sent to the Associate Chief Counsel office.


2. Forms 9724 and 9725 state whether the appeal was taken by the Commissioner or the taxpayer and, if by the taxpayer, whether an appeal (review) bond was filed.



1. When no bond is posted in a non-TEFRA case, Form 9725 specifically instructs the Area Counsel attorney to request the appeals office to request a quick assessment of the deficiencies and interest for the tax years on appeal.

2. When no bond was filed in TEFRA partnership and S corporation cases, Form 9724 instructs Area Counsel to request the appeals office to request that the Examination Support Unit provide assessment within one year of the date of the notice of appeal.

3. No assessment verification is required in TEFRA cases.


3. An original and three copies of Form 9725 or Form 9724 are prepared by the Technical Services Support Branch in the Office of the Associate Chief Counsel (P&A) and, after approval by the attorney and reviewer, are distributed as follows:



   - The original and one copy to Area Counsel

   - One copy for the attorney's open folder

   - One copy to the Technical Services Support Branch


4. Associate Area Counsel acknowledges receipt on and returns the copy of Form 9725 or Form 9724 to the Technical Services Support Branch, who then transmits it to the assigned attorney.



### Note:



In Commissioner appeals, the Form 9725 or Form 9724 is not transmitted to the field until the expiration of the 120-day cross-appeal period.

5. The Associate Chief Counsel attorney's responsibility to notify the field to initiate the assessment is met when the attorney transmits the original and one copy of Form 9725 (in non-TEFRA cases) or Form 9724 (in TEFRA cases) and receives an acknowledgment copy from Area Counsel.


**36.2.6.2.4.7.1.1** **(08-11-2004)**

###### Verification of Assessment

1. In non-TEFRA cases, Form 9725 requests that verification of assessment be sent to the Associate Chief Counsel (P&A). If verification has not been received in the Associate Chief Counsel office within 90 days after the form was sent to Area Counsel, a follow-up memorandum will be sent to the field, using the same procedures followed for preparing and transmitting the Form 9725.

2. In non-TEFRA cases, upon receipt of the verification of assessment, the Associate Chief Counsel attorney should compare the assessment with the Tax Court decision to verify that the correct amount of tax was assessed for the correct tax year. Any discrepancies should be pointed out to the attorney's reviewer.

3. If the Associate Chief Counsel office does not receive verification of assessment, the Associate Chief Counsel attorney is not required to request transcripts of account or otherwise attempt to seek verification that an assessment has, in fact, been made. The receipted copy of Form 9725 in non-TEFRA cases or Form 9724 in TEFRA cases is considered sufficient acknowledgment by the field that requested assessment and collection will be made by the responsible Service personnel.

4. In TEFRA cases, verification that the assessment has been made is not requested by or forwarded to the Associate Chief Counsel office.


**36.2.6.2.4.7.2** **(08-11-2004)**

###### Area Counsel Attorney Responsibilities For Assessment in Nonbonded Taxpayer Appeals

1. Area Counsel is first notified of a nonbonded taxpayer appeal and requested to initiate assessment activity by a TLCATS message transmitted by the ACC appeals clerk. The TLCATS message contains much of the same information, in abbreviated form, as the Form 9725 or Form 9724, which is sent to Area Counsel by the Associate Chief Counsel attorney shortly after the TLCATS message.

2. The Area Counsel attorney should acknowledge receipt and return the copy of the Form 9275 or Form 9724 to the Technical Services Support Branch, who will forward the receipted copy to the Associate Chief Counsel attorney.

3. As in the case of nonappealed Tax Court decisions, upon completion of the TLCATS decision data screen (CDEC) by the field TLCATS operator, TLCATS event CL0010 is generated to serve as an additional reminder to the Area Counsel attorney that assessment activity should be initiated.


**36.2.6.2.4.7.2.1** **(08-11-2004)**

###### Contact with Chief, Records Section, Appeals Office

1. Upon notification of an appeal and that assessment is required, the Area Counsel attorney should contact the Chief of the Records Section of the local Appeals Office and then hand-carry (or send by courier) the administrative file to the Records Section, using Form 1734, Transmittal Memorandum, and noting Appealed Tax Court Case Assessment Must Be Made.

2. The Records Section in Appeals is responsible for requesting assessment activity. In non-TEFRA cases, upon receipt of the administrative file and Form 1734, the Chief of the Records Section will request a quick assessment from the appropriate Area Director's office.

3. Once verification of the assessment is received from the appropriate Area Director's office, the Chief of the Records Section will prepare a Transmittal Memorandum, and return the administrative file to the Area Counsel attorney. The administrative file will then contain the transcript verifying that the assessment was completed.

4. In TEFRA cases the Chief of the Records Section will request assessment within one year of the appeal date.


**36.2.6.2.4.8** **(08-11-2004)**

##### Assessment in Bonded Taxpayer Appeals

1. When an adequate bond is posted, assessment cannot be made as to any deficiencies, additional amounts and interest covered by the bond, nor can a refund be made of any overpayment found by the Tax Court, until the decision of the Tax Court becomes final. Once the decision of the Tax Court becomes final, the Service has only 60 days in non-TEFRA cases and one year in TEFRA cases in which to assess the tax (plus any additional time obtained through tacking).

2. Tax Court has jurisdiction to order the refund of an overpayment plus interest if the Service has failed to refund or credit the overpayment within 120 days after the decision of the Tax Court has become final. Because timely assessment and timely refunds depend on knowledge of when the Tax Court's decision becomes final, and because the finality of the decision depends upon the conclusion of the appellate proceedings and the date of such conclusion, it is imperative that the appellate proceedings be closely monitored.


**36.2.6.2.4.8.1** **(08-11-2004)**

###### Associate Chief Counsel Attorney Responsibilities For Assessment in Bonded Taxpayer Appeals

1. In completing the assignments discussed in this section, the Associate Chief Counsel and Area Counsel attorneys should review the provisions of CCDM 36.2.5.3 , Finality of Tax Court Decisions and Mandamus, regarding the finality of Tax Court decisions; and CCDM 35.9.1, Tax Court Opinions and Decisions, and CCDM 36.2.1.2.1, Federal Rules of Appellate Procedure, regarding appellate court judgments, opinions, and mandates. For purposes of simplicity, in the discussion that follows the terms opinion and decision are used interchangeably as they relate to the disposition of a case in a court of appeals. As discussed in CCDM 36.2.1.2.1, however, the terms opinion, judgment, and mandate are terms of independent significance.


**36.2.6.2.4.8.1.1** **(08-11-2004)**

###### Initial Assignment

1. The Associate Chief Counsel attorney assigned to a bonded taxpayer appeal will complete the initial phase of the assignment by following the steps outlined in _CCDM 36.2.6.2.1_. In the case of a bonded appeal, the appropriate box is checked on Form 9725 or Form 9724, notifying the field that the taxpayer has appealed and posted a bond and that assessment activity must await the finality of the Tax Court's decision.


**36.2.6.2.4.8.1.2** **(05-16-2012)**

###### Notification to the Field To Assess

1. As in all appealed Tax Court cases, the Associate Chief Counsel attorney is responsible for ensuring that timely notification to initiate assessment is received by Area Counsel. Since assessment in bonded taxpayer appeals cannot be initiated before the Tax Court decision becomes final, the Associate Chief Counsel attorney will be aided by two complementary checks on the notification process: TLCATS reminders and copies of appellate court documents furnished by the Department of Justice.

2. The TLCATS reminder system generates an OP event, OP0010 (CHECK FOR APPELLATE DECISION), that will appear on an attorney's suspense/exception report 120 days after the date the taxpayer files the notice of appeal and posts an adequate bond. The Associate Chief Counsel attorney is responsible for completing the event by confirming whether the appellate decision has been entered or not (YE -- yes or NO -- no). If YE is entered, the event is permanently completed and not regenerated. If NO is entered, the event will regenerate every 75 days until the attorney enters YE.

3. When the Associate Chief Counsel office receives from the Department of Justice the appellate court opinion that disposes of the case, the date of the opinion is entered on the CAPP screen. Thereafter, TLCATS will automatically generate a reminder that will appear on the attorney's suspense/exception report 110 days after the date of the opinion.



1. The 110 days allows 90 days for a potential petition for certiorari plus a 20-day notification buffer.

2. A suspense/exception report warning will be received by the attorney two weeks before the 110-day due date.

3. At that point, unless an intervening action has occurred during the 110-day period that postpones the finality of the Tax Court decision (see (4), below), the attorney's secretary should prepare the legal and miscellaneous law files for closing. See instructions for preparing the legal files for closing at _CCDM 36.2.6.2.5.1_.

4. On the 100th day, the attorney should call the Justice Department attorney handling the case on appeal to remind the attorney to return the file(s).

5. If the Tax Court decision has become final, the attorney will complete the AP event (NOTIFICATION OF NEED TO ASSESS) by calling the Area Counsel attorney to advise of the need to assess.

6. When verification that the assessment has been made (in non-TEFRA cases) is received from the Area Counsel attorney, the Associate Chief Counsel attorney will prepare a transfer memorandum and transmit the memorandum with the legal and miscellaneous law files to Area Counsel, thereby closing the case in the Associate Chief Counsel office.


4. These procedures are discussed in detail in paragraphs (5) and (6), below. If the Tax Court decision has not become final during the 110-day period, see the following provisions.

5. Intervening actions postponing finality of Tax Court decision. It is important to remember that the finality of the appealed Tax Court decision will depend upon whether or not a rehearing in the court of appeals or a writ of certiorari is petitioned and, if so, whether the petition is denied or granted. See CCDM 36.2.5.3, Finality of Tax Court Decisions and Mandamus.

6. Table showing procedures to take when intervening actions occur:




| _**If**_ | _**Then**_ |
| --- | --- |
| a petition for rehearing has been filed, | the AP event will have to be manually extended by the branch TLCATS operator pursuant to instructions by the branch chief. The attorney should then closely monitor the case by checking with the Department of Justice attorney on the status of the petition (i.e., whether it has been granted or denied). |
| the petition for rehearing is denied, | a new 90-day certiorari period will begin to run from the date of the denial. |
| a petition for writ of certiorari is filed by either party, | the petition date is entered on the TLCATS CERT screen, and TLCATS will automatically generate an OP event, OP0011, reminding the Associate Chief Counsel attorney to check for the denial of certiorari or the Supreme Court's opinion. |





### Note:



The remainder will appear on the attorney's suspense/exception report 45 days from the date the petition was filed and will regenerate every 45 days thereafter until the attorney completes the event by confirming that the petition has been denied or that the Supreme Court has issued its opinion.

7. Once the date of denial of certiorari or the Supreme Court's opinion is entered on the CERT screen, TLCATS will generate an assessment and closing event, which will be due 30 days from the date of the denial of certiorari or the Supreme Court's opinion.

8. Once all further appellate proceedings are concluded and the Tax Court decision has become final, the attorney should notify the field of the need to assess, prepare the files for closing, await receipt of assessment verification from Area Counsel in non-TEFRA cases, prepare the transfer memorandum, and then transmit the memorandum and the files to Area Counsel, thereby closing the case in the Associate Chief Counsel office.

9. In TEFRA cases, it is the responsibility of the Associate Chief Counsel attorney to verify that appeals has been notified by Area Counsel to request assessment. These procedures are discussed in detail in _CCDM 36.2.6.2.4.8.1.3_.



### Note:



It is also important to remember that if the court of appeals reverses or modifies the Tax Court decision, the case will generally be remanded to the Tax Court for entry of a new decision (with or without a rehearing). These cases are closed in the Associate Chief Counsel office at the expiration of the certiorari period or following any Supreme Court proceedings. They are closed by transfer to the appropriate Area Counsel office. Since assessment cannot be made until the new decision entered by the Tax Court has become final, assessment responsibility will remain with Area Counsel. Thus, if a bonded taxpayer appeal case is remanded to the Tax Court, attorneys should follow the procedures set forth at CCDM 36.2.5.12, Cases Remanded to the Tax Court/Recomputations, rather than the procedures of this section. See also _CCDM 36.2.6.2.4.9_ for assessment in remanded cases.


**36.2.6.2.4.8.1.3** **(05-16-2012)**

###### Verification of Assessment

1. Unlike the situation in nonbonded taxpayer appeal cases in which assessments are made at the beginning of the appeal process, assessment cannot be made in bonded taxpayer appeals until the Tax Court's decision becomes final. Since finality may occur years after the appeal is taken, verification of the assessment is required of the Associate Chief Counsel attorneys in non-TEFRA cases to ensure that assessments in these cases do not slip through the cracks.

2. **Non-TEFRA cases**. Once the Associate Chief Counsel attorney has notified Area Counsel that the decision has become final and assessment is needed, the Associate Chief Counsel attorney must verify that assessment has been made by receipt of the document locator number (DLN) from Area Counsel. This information will be conveyed by telephone. See Exhibit 36.4.1–23, Interpreting a 14 or 13 Digit Document Locator Number (DLN).




| **_If_** | **_Then_** |
| --- | --- |
| the Associate Chief Counsel attorney does not receive a DLN from Area Counsel, | the Associate Chief Counsel attorney will have to verify the assessment by calling the nonmaster file unit at the appropriate Internal Revenue Service Campus. See _CCDM 36.2.6.2.4.4_. |
| the case has been remanded to the Tax Court, | assessment responsibility lies with Area Counsel and the Associate Chief Counsel attorney is not required to verify assessment. |

3. **TEFRA cases**. When a bonded case becomes final, the Associate Chief Counsel attorney will notify Area Counsel that the decision has become final and that assessment is needed. The Associate Chief Counsel attorney must verify that a request for assessment, i.e., a notation on Form 1734, has been forwarded to appeals by Area Counsel. Area Counsel will send a copy of the request for assessment to the Associate Chief Counsel office. It is impractical for counsel to verify assessments in TEFRA cases in light of the potentially large number of assessments that may need to be made (which is dependent upon the number of investors in the TEFRA entity) and the length of time (one year) over which assessments may be made. Thus, verification of assessments is not required.


**36.2.6.2.4.8.2** **(08-11-2004)**

###### Area Counsel Attorney Responsibilities For Assessment in Bonded Taxpayer Appeals

1. Area Counsel is first notified of a bonded taxpayer appeal by a TLCATS message. The TLCATS message contains much the same information, in abbreviated form, as the Form 9725 or Form 9724, which is sent to Area Counsel by the Associate Chief Counsel attorney shortly after the TLCATS message.

2. In a bonded taxpayer appeal, the appropriate block is checked, notifying the field that assessment must await the finality of the Tax Court's decision.

3. The Area Counsel attorney should acknowledge receipt on and return the copy of the Form 9725 or Form 9724 to the ACC appeals clerk.


**36.2.6.2.4.8.2.1** **(05-16-2012)**

###### Initial Contact with Appeals Office

1. Once notification of a bonded appeal is received, the Area Counsel attorney should send a transmittal memorandum to the Chief of the Records Section in the local Appeals Office for information purposes. The Records Section in Appeals is responsible for requesting assessments from the appropriate Area Director's office.

2. If a TEFRA case settled under Tax Court Rule 248 is subsequently appealed and an adequate bond is filed, Area Counsel should immediately notify the Chief of the Records Section of the local Appeals Office that assessment should not be made. This is necessary because cases that are settled under Tax Court Rule 248 are forwarded to Appeals prior to the expiration of the appeal period with instructions to assess as soon as the appeal period expires. See CCDM 35.9.3.5.1, Annotating the TEFRA Case File.


**36.2.6.2.4.8.2.2** **(08-11-2004)**

###### Receipt of Notification of Need to Assess

1. The Associate Chief Counsel attorney will notify the Area Counsel attorney by phone that an assessment should be made.

2. An Area Counsel attorney closing event parallels the Associate Chief Counsel office AP event. When the Associate Chief Counsel office AP event is generated by the appellate decision date on the CAPP screen, TLCATS will automatically generate an Area Counsel attorney closing event CL (ASSESS-BONDED).

3. Like the Associate Chief Counsel office AP event, the field CL event will appear on the Area Counsel attorney's weekly suspense/exception report and will also be due 110 days after the date of the appellate decision. Thus, the CL event acts as a backup to the Associate Chief Counsel office AP event.



### Note:



An additional CL event is generated for the Area Counsel attorney's reviewer to ensure that reviewers in the field receive reminders through weekly suspense reports of necessary bond assessment dates.


**36.2.6.2.4.8.2.3** **(08-11-2004)**

###### Notification to Appeals to Assess

1. Upon receipt of notification of the need to assess and in order to complete the TLCATS CL event, the Area Counsel attorney should immediately inform the Chief of the local Appeals Office of the need for an assessment. For bonded appeals, the Chief of the Appeals Office is responsible for ensuring that the Chief of the Records Section requests the assessment.

2. The Area Counsel attorney should then hand carry (or send via courier) the administrative file to the Chief of the Appeals Office, together with Form 1734, Transmittal Memorandum, noting on the form "Tax Court Case/Assessment Must Be Made Before \[date\]" .

3. For non-TEFRA cases the date will be the 60th day following the date the Tax Court decision became final.

4. For TEFRA cases the date will be one year from the date the Tax Court decision became final.


**36.2.6.2.4.8.2.4** **(08-11-2004)**

###### Assessment in Non-TEFRA Cases

1. In a non-TEFRA case, the Chief of the Records Section will send the administrative file for final closure to the appropriate Area Director's office, together with a request for a telephonic assessment and a request for verification of the assessment.

2. Once the verification of assessment is received, the Chief of the Records Section will prepare a Form 2828, Transmittal Memorandum, and send a copy of the transcript to the Area Counsel attorney, verifying that the assessment has been made.

3. The Area Counsel attorney, in turn, should inform the Associate Chief Counsel attorney, by telephone, of the DLN.


**36.2.6.2.4.8.2.5** **(08-11-2004)**

###### Assessment in TEFRA Cases

1. In a TEFRA case, the Chief of the Records Section will send the key case administrative file for final closure to ESP in the Examination Division of the Area Director's office. The Chief of Records will also prepare Form 3210 requesting computation and assessment of deficiencies and interest within one year of the date the decision becomes final.

2. In TEFRA cases, there is no requirement that the Area Counsel attorney conduct verification procedures.


**36.2.6.2.4.8.2.6** **(05-16-2012)**

###### Monitor Collection Activity and Notify Tax Court

1. Upon receipt of verification of assessment in non-TEFRA cases or verification that Area Counsel has sent a request to Appeals to make assessments in TEFRA cases, the Associate Chief Counsel attorney will close the case in the Associate Chief Counsel office by transfer to Area Counsel.

2. Area Counsel will receive a transfer memorandum, along with the legal and miscellaneous law files. The legal file will include a copy of the appeal bond.

3. Following assessment and transfer of the case, Area Counsel is responsible for monitoring collection activity. A TLCATS case status code entitled BONDED-PENDING COLLECTION automatically generates a TLCATS event, RE0025, to remind the Area Counsel attorney to check with Technical and Insolvency and ascertain the status of the collection account.

4. Area Counsel is responsible for notifying the Tax Court when an appeal bond may be released. Accordingly, Area Counsel must promptly send a letter to the Tax Court notifying the court that payment has been made and that the bond may be released.

5. Alternatively, Area Counsel should contact the Associate Chief Counsel (P&A) for assistance in moving the court to have the underlying deficiencies satisfied from the bond proceeds.

6. In cases where payment is guaranteed by a commercial surety, upon the satisfaction of the liability as finally determined, plus interest and additional amounts, Area Counsel should prepare a letter notifying the surety of the satisfaction of the liabilities. The letter should be addressed and mailed to the surety and a copy of the letter should be sent to:



> The Honorable Chief Judge
>
> United States Tax Court
>
> 400 Second Street, N.W.
>
> Washington, D.C. 20217





1. The court will then release the bond and surety.


7. In cases where payment is guaranteed by Government securities, upon the satisfaction of the liability as finally determined, plus interest and additional amounts, the Area Counsel attorney should prepare a letter notifying the Tax Court of the satisfaction of the liabilities. The letter should be addressed and mailed to the Chief Judge of the Tax Court. (See address above.) The court will then direct the release of the bonds and return the collateral posted in lieu of sureties.

8. Where the taxpayer wants to satisfy the unsatisfied portion of the liability (including interest and additional amounts) out of the collateral posted in lieu of sureties on the appeal bond, the taxpayer must submit a motion to this effect. Either attached to the motion or provided by the respondent will be a statement of account, often in the form of a certificate of assessment and payments. When appropriate, the court will enter an order for liquidation and distribution of collateral in accordance with the request of the parties. To the extent that taxpayer's request is incorrect or imprecise, the attorney must prepare a response to the taxpayer's motion to provide the court with the information needed for the order for distribution of the proceeds of the liquidation.

9. Where the taxpayer fails to satisfy the unsatisfied portion of the liability (including interest and additional amounts) and payment is guaranteed by commercial surety, the Internal Revenue Manual provides instruction for the steps to be taken by the Service in obtaining satisfaction of the liability from the commercial surety.


**36.2.6.2.4.8.2.7** **(08-11-2004)**

###### Closing Bonded Cases in the Field

1. The field's TLCATS closing event reminds the Area Counsel attorney (and reviewer) to assess, but final closing should be postponed until the bond has been released or applied towards payment.


**36.2.6.2.4.9** **(08-11-2004)**

##### Assessment in Cases Remanded to the Tax Court

1. In both Commissioner and taxpayer appeals (whether bonded or not), if there is a reversal or modification of the Tax Court's decision by the appeals court, a new decision must be entered by the Tax Court (unless the Supreme Court subsequently reverses the court of appeals and affirms the Tax Court's decision).

2. When the final appellate action in a case results in the need for the entry of a new decision, the case is transferred by the Associate Chief Counsel office to Area Counsel.

3. Area Counsel will assume jurisdiction of the case for purposes of any further Tax Court action and for assessment or abatement activity.

4. Once the Tax Court enters its new decision, assessment responsibility remains with Area Counsel as in the situation of nonappealed cases. See CCDM 36.2.5.12, Cases Remanded to the Tax Court/Recomputations.


**36.2.6.2.4.10** **(08-11-2004)**

##### Assessment in Cases Involving Defective Appeal Bonds

1. The Associate Chief Counsel attorney is responsible for reviewing the appeal bond. See _CCDM 36.2.6.2.1.2_. If the bond is defective in any manner (e.g., amount, expiration date, surety not approved) the attorney should immediately bring this to the attention of his reviewer.

2. A decision will be made in the Associate Chief Counsel office as to whether a motion should be prepared requesting the Tax Court to order that the bond be remedied, or whether to notify the field to initiate assessment activity in the same manner as a nonbonded taxpayer appeal. In either event, the Associate Chief Counsel attorney will advise the Area Counsel attorney as to the appropriate action to be taken.


**36.2.6.2.5** **(08-13-2019)**

#### Closing Procedures Specific to Tax Court Appeals

1. In general, Associate Chief Counsel attorneys are responsible for closing all appealed Tax Court cases; Area Counsel is responsible for closing nonappealed Tax Court cases.

2. While, in cases in which an appeal has been filed, the files cannot be completely prepared for closing at the time of forwarding to the Associate Chief Counsel office, the following action should be taken:



1. The Associate Chief Counsel attorney should send a letter to the Tax Court requesting the withdrawal of all necessary exhibits when the decision becomes final.

2. A list should be made of such exhibits that are not to be placed in the miscellaneous law file upon closing but which are to be returned to the source from which obtained. As to each such exhibit there should be specified the name and address of the person or office to which the document is to be returned upon its withdrawal.

3. The files should be placed in appropriate order. If there are related files or documents that may be needed in handling the case on appeal, such files and documents should be specifically listed, giving the source from which secured, so that they may be properly returned upon the closing of the case.

4. Original unaudited returns _must be_ returned to the Area Director. If needed on appeal, a copy is sufficient.


3. During the pendency of an appeal, the Chief Counsel's legal file is in the possession of the Appellate Section of the Tax Division, and the administrative file is retained in the field by either Area Counsel or appeals. During this period, the Associate Chief Counsel attorney maintains an "open folder" for all documents related to the case on appeal. After the conclusion of all appellate proceedings, the Chief Counsel's legal file is returned to the Associate Chief Counsel office by the Justice Department, with a closing letter.

4. Closing a case in the Associate Counsel office means that the case is closed on the records of the Associate Chief Counsel. Appealed Tax Court cases are closed in three ways, depending on the type of case involved.



1. Remanded cases are closed by transfer to the Area Counsel office which handled the case in the Tax Court. A transfer memorandum is prepared and sent to Area Counsel for this purpose.

2. Bonded taxpayer appeal cases are also closed by transfer to Area Counsel. Copies of the transfer memorandum in these cases are directed to the appropriate appeals and Area Director offices. Additionally, Form 9253, Appellate Court Closing Memorandum, (see _CCDM 36.2.6.2.5.2_) is sent to the appropriate Appeals office and copies of the form are direct to both Area Counsel and the appropriate Area Director.

3. All other appealed cases, except whitleblower appeals, are closed to the appropriate Appeals office by closing memorandum with copies of the memorandum directed to the appropriate Area Counsel and Area Director offices.

4. Unless the case is remanded, whistleblower appeals are closed to the IRS Whistleblower Office by closing memorandum with copies of the memorandum directed to the appropriate Area Counsel.


**36.2.6.2.5.1** **(05-16-2012)**

##### Preparing and Transmitting Closed Files

1. If the Tax Court decision has become final (i.e., the case has not been remanded to the Tax Court), a copy of the decision should be inserted at the top of the legal file, together with verification of assessment in non-TEFRA cases (a transcript of account) or, if applicable, a copy of the taxpayer's bond. In TEFRA cases, verification that Area Counsel sent a request to Appeals to make the necessary assessments should be included in the legal file.

2. Once the attorney's secretary has prepared the files for closing, they should be submitted to the attorney's reviewer, who will ensure that the files are in proper order. The files are then forwarded to the Disclosure & Litigation Support Branch of the Office of the Associate Chief Counsel (P&A). The Disclosure & Litigation Support Branch will complete Form 9253, Appellate Court Closing Memorandum, and transmit the files to the Records Section for further transmittal to the closed files area.


**36.2.6.2.5.2** **(05-16-2012)**

##### Closing Memorandum for Tax Court Cases

1. Form 9253, Appellate Court Closing Memorandum, is used by the Associate Counsel office to close cases to the appropriate Appeals office. The form is completed by the Disclosure & Litigation Support Branch, following instructions provided by the attorney with the legal and miscellaneous law files.

2. Generally, Form 9253 is directed to the chief of the Appeals office, with copies to the appropriate Area Director and Area Counsel. At the time of final closing, the Disclosure & Litigation Support Branch will distribute copies of the closing memorandum to the Technical Services Support Branch in the Office of Associate Chief Counsel (P&A), the Docket, Records & User Fee Branch of the division, and the responsible attorney. When the addressee Area Counsel office signs and returns a copy of the closing memorandum acknowledging receipt, the Technical Services Support Branch will make a record of the receipt and enter the date of closing on the records of the case. If receipt of the closing memorandum has not been acknowledged within 30 days of transmittal, the Technical Services Support Branch will follow up with a further request for acknowledgment, while forwarding a duplicate copy of the original closing memorandum.



1. When a declaratory judgment case is closed in the Associate Chief Counsel office, Form 9253 is addressed to the office from which the Office of the Associate Chief Counsel (P&A) received the case, with copies to the other offices concerned with the case.

2. If a taxpayer appeal is dismissed due to the untimely filing of the notice of appeal, the Tax Court decision will become final 90 days after entry by the Tax Court. The explanation of the reason for this date should be noted on the Form 9253.

3. If the case has been disposed of by administrative settlement pursuant to an offer-in-compromise based solely upon the inability of the taxpayer to pay the deficiency determined by the Tax Court, this fact should be noted on the closing memorandum. Copies of Justice Department documents relating to the administrative settlement should be attached to the closing memorandum.

4. Upon the Tax Court's decision becoming final after appellate review, there may be litigation problems in the collection of the deficiency as finally determined. Since the Area Counsel office has collection litigation responsibility, that office should be notified of any factors that occurred during the handling of the case on appeal which would be of assistance to the Area Counsel office. Such notification may be made by notation on the Form 9253 or by separate memorandum upon closing, if necessary.


**36.2.6.2.5.3** **(08-11-2004)**

##### Time for Closing Tax Court Appeals

1. General rule. With the exceptions listed in (2) and (3), below, all appealed Tax Court cases should be closed in the Associate Counsel office as soon as the Tax Court decision becomes final. See CCDM 36.2.5.3, Finality of Tax Court Decisions and Mandamus.

2. Cases dismissed on stipulation of the parties. Although the Tax Court's decision is technically not final until the expiration of the certiorari period, these cases should be closed immediately upon the entry of dismissal in the court of appeals.

3. Cases won completely by the taxpayer. Although the Tax Court's decision is technically not final until the expiration of the certiorari period, these cases should be closed upon notification that the Solicitor General has decided not to authorize the filing of a petition for writ of certiorari. See CCDM 36.2.2.1, Petition for Certiorari Generally.

4. **TLCATS events**. TLCATS will remind the Associate Chief Counsel attorney when to close a case. The due date to forward the files to the Disclosure & Litigation Support Branch or to Area Counsel (in remanded cases and bonded taxpayer appeals) is 110 days after the court of appeals decides the case. The 110-day period accounts for the 90-day certiorari period, plus a reasonable time for retrieving the legal file from the Department of Justice. On the 100th day, the attorney should call the Justice Department attorney who handled the case on appeal as a reminder to return the file(s). The Disclosure & Litigation Support Branch then has an additional 21 days to complete the formal closing.


**36.2.6.2.5.4** **(05-16-2012)**

##### Closing Bonded Cases in the Associate Chief Counsel Office

1. The Associate Chief Counsel attorney should immediately take steps to close the case in the Associate Chief Counsel office once the following events have occurred:



1. The Tax Court decision has become final.

2. The field has been notified of the need to assess.

3. The Associate Chief Counsel attorney has received verification of the assessment in non-TEFRA cases or verification that a request for assessment has been forwarded to appeals by Area Counsel in TEFRA cases.


2. Bonded taxpayer appeals are closed by transfer to the Counsel office that handled the case in the Tax Court. Closing is accomplished by transmitting the legal and miscellaneous law files to the office that handled the case in Tax Court, together with a transfer memorandum. Copies of the transfer memorandum should be directed to the appropriate Appeals office and Field Director's office. An Appellate Court Closing Memorandum, Form 9253, is prepared by the Disclosure & Litigation Support Branch in the Associate Chief Counsel (P&A) and sent to the appropriate appeals office, with copies directed to the appropriate Counsel office and Area Director. See _CCDM 36.2.6.2.5.2_ for provisions regarding Form 9253. When the memorandum and files are sent to Associate Area Counsel, the branch TLCATS operator will change the case status code on TLCATS to 44 (BONDED-PENDING COLLECTION).



   - See CCDM 36.2.4, Closing Appeal Cases, and _CCDM 36.2.6.2.5.1_.

   - Transfer memorandum to the field. The Associate Chief Counsel attorney should prepare a memorandum addressed to Associate Area Counsel (or to the Associate Chief Counsel ( P&A) in cases handled in the Tax Court by a P&A attorney), to the attention of the trial attorney. Copies should be directed to the local Appeals office and Area Director's office. The memorandum should be approved and signed by the attorney's reviewer for the Associate Chief Counsel (P&A). A copy of the completed memorandum should be forwarded to the Technical Services Support Branch, who will note the appeal card to reflect the transfer of the case. The wording of the memorandum reproduced at Exhibit 36.4.1–25, Transfer Memorandum (Bonded Appeal), should be followed for all transfer memoranda in non-TEFRA bonded taxpayer appeal cases. The attorney should contact Branch 6 or 7, Associate Chief Counsel (P&A) before preparing a transfer memorandum in a bonded TEFRA taxpayer appeal case.


**36.2.6.2.5.5** **(05-16-2012)**

##### Closing CDP Cases to the Office of Appeals After Tax Court Decision is Final

1. A CDP case is returned to Collection after the case is closed by the Office of Appeals, Processing Service (APS), and the Transaction Code (TC) 520 is reversed by Appeals with the entry of a TC 521.



### Note:



When the court of appeals enters a decision in favor of the Government in a CDP case, it is imperative that the case is returned to Collection as soon as possible. **The date that the Tax Court decision becomes final is the date that the section 6330(e)(1) suspension of the collection statute of limitations and the levy prohibition ends.**

2. In appealed Tax Court CDP cases the Appellate Section of the Department of Justice Tax Division is responsible for litigating the appeal. The Office of Associate Chief Counsel ( P&A) attorney monitors the taxpayer’s appeal and is responsible for ensuring that the trial attorney assigned to the case receives timely notification when the Tax Court CDP decision is final. See CCDM 36.2.5.3 , Finality of Tax Court Decisions and Mandamus, for instructions on determining when a Tax Court decision is final. The trial attorney is then responsible for ensuring that the appropriate APS office receives timely notification.

3. See _CCDM 36.2.6.2.5.5.3_ for additional instructions on what must be provided to APS upon notification that the Tax Court CDP decision is final. When APS receives notification that the Tax Court CDP decision is final, the appealed case is closed and the freeze code is reversed, allowing collection to resume.


**36.2.6.2.5.5.1** **(05-16-2012)**

###### Determining When the Court of Appeals Judgment is Final

1. The P&A attorney assigned to the appealed Tax Court CDP case should regularly check the court of appeals docket sheets (accessed by PACER) to monitor whether a judgment or order has been issued.

2. The P&A attorney should determine whether the judgment or order can be considered final for purposes of filing a petition for writ of certiorari by checking the court of appeals docket sheet to see if the taxpayer has filed a petition for rehearing. If a timely petition for rehearing is filed, the court of appeals judgment or order becomes final when the order denying rehearing is entered on the court of appeals docket or when a separate judgment or order is entered after rehearing.



### Note:



A petition for panel rehearing or a petition for rehearing en banc may be filed within 45 days after the entry of a judgment or order on the docket unless an order shortens or extends the time. See Fed. R. App. P. 35 and 40.

3. Once a final judgment or order has been issued, the P&A attorney will call the attorney in the Tax Division Appellate Section assigned to the case to confirm the finality of the court of appeals decision and that no petition for rehearing was filed. If a final judgment or order has been issued, the P&A attorney should confirm the precise date it was entered on the court of appeals docket.


**36.2.6.2.5.5.2** **(05-16-2012)**

###### After a Final Court of Appeals Judgment or Order is Entered

1. When the P&A attorney has confirmed that a final judgment or order favorable to the Government has been entered, the attorney should inform the trial attorney assigned to the case of the final judgment or order.



### Note:



This is merely a status update, and no action is required of the trial attorney at this point.

2. The P&A attorney should also ensure that the date the final judgment or order was entered on the court of appeals docket is input into TL-CATS. The entry of this date will move the case into status code 12 – Decided Circuit Court.

3. The P&A attorney should continue to monitor the case to determine when the Tax Court CDP case becomes final. The earliest a Tax Court decision can become final is the date the 90-day period for filing a petition for writ of certiorari expires, as measured from the date of the final court of appeals judgment or order. See CCDM 36.2.5.3, Finality of Tax Court Decisions and Mandamus, for instructions on determining when a Tax Court decision is final.


**36.2.6.2.5.5.3** **(05-16-2012)**

###### After the Tax Court CDP Decision Is Final

1. When the Tax Court CDP decision becomes final, the P&A attorney should notify the trial attorney. See CCDM 36.2.5.3, Finality of Tax Court Decisions and Mandamus, for instructions on determining when a Tax Court decision is final. At this time, the P&A attorney should inform the trial attorney of (a) the date the Tax Court CDP decision became final, (b) the need to send to Appeals the administrative file, Tax Court decision and any opinion, and the court of appeals judgment or order and any opinion, and (c) the need to request the CDP case be closed by Appeals to Collection. See CCDM 35.9.3.6, Closing Collection Due Process Cases. The P&A attorney should also provide a copy of the court of appeals judgment or order to the trial attorney.



### Note:



If the taxpayer filed a petition for a writ of certiorari, and it was granted, the P&A attorney should also provide a copy of the Supreme Court mandate.

2. After the P&A attorney informs the trial attorney that the Tax Court CDP decision is final, the trial attorney should, in an expeditious manner, send to the APS office specified on the orange sheet in the administrative file:



   - Administrative file

   - Copy of final Tax Court decision, including any opinion

   - Copy of final judgment or order of court of appeals, including any opinion

   - If applicable, a copy of the Supreme Court order mandate, issued after the petition for a writ of certiorari is granted

   - A \[manually-generated Transmittal\] Form 1734 specifying the date the Tax Court decision became final, which is the date the suspension of the collection statute of limitations ended, and requesting that the CDP case be closed in Appeals.


### Note:

It is important to also clearly communicate any actions required pursuant to the final CDP decision. For example, in situations when an alternative resolution of the CDP case is reached or situations when the CDP decision includes a liability determination, costs, or sanctions, the trial attorney should include with the transmittal Form 1734 any information that APS will need to process the alternative resolution or the additional assessment. See CCDM 35.9.3.6, Closing Collection Due Process Cases, for specific instructions on the information that should be transmitted to APS in these situations.

3. When APS receives notification that the Tax Court CDP decision is final, the appealed case is closed and the freeze code is reversed.


**36.2.6.2.5.6** **(08-13-2019)**

##### Closing Whitleblower Cases to the Whistleblower Office after Tax Court Decision is Final

1. Special attention should be paid to closing whistleblower cases. Unlike other Tax Court cases, whistleblower cases are closed to the IRS Whistleblower Office, not the Office of Appeals.

2. The P&A attorney should immediately take steps to close the case in the Associate Chief Counsel office once the Tax Court decision has become final. See CCDM 36.2.5.3, Finality of Tax Court Decisions and Mandamus. Note that remanded cases are closed by transfer to the Area Counsel office that handled the case in the Tax Court.

3. The P&A attorney should regularly check the court of appeals docket sheets (accessed by PACER) to monitor whether a judgment or order has been issued. Thereafter, the P&A attorney should monitor the judgment or order to determine when it is final.

4. Once a final judgment or order has been issued, the P&A attorney should call the attorney in the Tax Division Appellate Section (DOJ attorney) assigned to the case to confirm the finality of the court of appeals decision and that no petition for rehearing or cert was filed. During this call, the P&A attorney should ask whether the DOJ attorney has the Whistleblower Office’s administrative claim file. Finally, during the call, the P&A attorney should request that the DOJ attorney immediately route the legal files and administrative claim file (if in their possession) to the P&A attorney for closing.

5. After receiving a closing letter and the files from the DOJ attorney, the P&A attorney should compile one legal file with non-duplicate documents placed in reverse chronological order. If the DOJ legal files or the closing letter are missing, contact the DOJ attorney.

6. If the DOJ attorney provides the IRS Whistleblower Office’s administrative claim file, then the P&A attorney should immediately route the administrative claim file back to the IRS Whistleblower Office. If the DOJ attorney does not provide the administrative claim file, then the P&A attorney should contact the Area Counsel office that handled the case in Tax Court. The P&A attorney should notify the Area Counsel attorney that the case is final and ask that the Area Counsel attorney immediately route the administrative claim files back to the IRS Whistleblower Office.

7. When sending the administrative claim file to the IRS Whistleblower Office, the appropriate Chief Counsel attorney must include a copy of the Tax Court decision, including any opinion, a copy of the final judgement or order of the court of appeals, including any opinion, and, if applicable, a copy of the Supreme Court order mandate issued after the petition for a writ of certiorari is granted.

8. The IRS Whistleblower Office will not process the payment of an award until all appeals of the Whistleblower Office’s determination are final. _See_ Treas. Reg. § 301.7623-4(d)(1). The IRS Whistleblower Office depends on the Office of Chief Counsel to return the IRS Whistleblower Office’s administrative claim file when the appellate litigation concludes and to confirm when any appeals of the IRS Whistelblower Office’s determination are final.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part36/irm_36-002-006#addtoany "Show all")

A2A