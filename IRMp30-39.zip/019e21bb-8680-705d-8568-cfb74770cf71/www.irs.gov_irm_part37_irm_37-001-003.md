---
url: "https://www.irs.gov/irm/part37/irm_37-001-003"
title: "37.1.3 The Counsel Governmental Liaison Coordination Program | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part37/irm_37-001-003#main-content)

- 37.1.3 [The Counsel Governmental Liaison Coordination Program](https://www.irs.gov/irm/part37/irm_37-001-003#idm140048795058224)
  - 37.1.3.1 [Counsel Governmental Liaison Coordination](https://www.irs.gov/irm/part37/irm_37-001-003#idm140048795010912)
  - 37.1.3.2 [Counsel Governmental Liaison Program](https://www.irs.gov/irm/part37/irm_37-001-003#idm140048795007904)
  - 37.1.3.3 [Governmental Liaison Counsel Contacts](https://www.irs.gov/irm/part37/irm_37-001-003#idm140048795043264)
  - 37.1.3.4 [Counsel Governmental Liaison Coordinator](https://www.irs.gov/irm/part37/irm_37-001-003#idm140048795037584)
  - 37.1.3.5 [Requests for Legal Advice](https://www.irs.gov/irm/part37/irm_37-001-003#idm140048795023680)

# Part 37. Disclosure

# Chapter 1. Sections 6110 and 6103 of Title 26

# Section 3. The Counsel Governmental Liaison Coordination Program

* * *

## 37.1.3 The Counsel Governmental Liaison Coordination Program

#### Manual Transmittal

January 23, 2013

#### Purpose

(1) This transmits new CCDM 37.1.3, Sections 6110 and 6103 of Title 26; The Counsel Governmental Liaison Coordination Program.

#### Background

CCDM 37.1.3 is being issued to add a new section describing the Counsel Governmental Liaison Coordination Program.

#### Material Changes

(1) This section describes procedures for Counsel attorneys contacted by Service Governmental Liaison personnel seeking legal advice.

(2) CCDM 37.1.3.3 provides instructions for SBSE field counsel who serve as the principal points of contact to local governmental liaisons on routine matters.

(3) CCDM 37.1.3.4 describes the function and duties of the Counsel Governmental Liaison Coordinator.

(4) CCDM 37.1.3.5 provides instructions for field counsel requesting legal advice relating to governmental liaison matters from Associate Chief Counsel subject matter experts.

#### Effect on Other Documents

This section incorporates CC Notice CC-2009-017, dated June 5, 2009. CC Notice CC-2009-017 is now obsolete.

#### Audience

Chief Counsel

#### Effective Date

(01-23-2013)

Deborah A. Butler

Associate Chief Counsel

(Procedure and Administration)

**37.1.3.1** **(01-23-2013)**

### Counsel Governmental Liaison Coordination

1. IRC § 6103(d)(1) authorizes the Service to disclose federal returns and return information to state revenue agencies for use in state tax administration. The mission of the Service’s Governmental Liaison program is to facilitate joint activities and projects with other government agencies to improve compliance with federal, state and local tax laws. This enables the Service and other federal, state and qualifying local agencies to perform their responsibilities more efficiently and effectively. See IRM 11.4.1, Governmental Liaison Operations, et seq. The Office of Governmental Liaison serves as a facilitator and coordinator for joint activities or projects between the Service and federal, state and qualifying local government agencies.


**37.1.3.2** **(01-23-2013)**

### Counsel Governmental Liaison Program

1. Governmental Liaison may need legal advice from the Office of Chief Counsel on a joint activity or project at either the local or national level. The legal issues involved in the Governmental Liaison program include:



1. Appropriate use of government resources

2. Information sharing

3. Legal and policy issues arising from Governmental Liaison activities


2. If the Service proposes to enter into either a joint activity or project with another governmental entity, Governmental Liaison will generally memorialize the agreement in a Memorandum of Understanding, Letter of Understanding or a contract. The Office of Chief Counsel will review these documents unless the local Governmental Liaison (GL) is using a template previously approved by the appropriate Associate Chief Counsel or Division Counsel Headquarters office.


**37.1.3.3** **(01-23-2013)**

### Governmental Liaison Counsel Contacts

1. **Field Office Governmental Liaison**. The Associate Area Counsels, Small Business/Self Employed (SB/SE) Division, serve as Chief Counsel's principal contact points for providing legal advice to field GL for routine matters. In general, there is one SB/SE attorney contact for each state’s GL, and each attorney will establish a working relationship with the Governmental Liaison and Disclosure (GLD) Area Manager.

2. The local GL, in coordination with the GLD Area Manager, determines when legal advice is needed on a joint activity or project. If necessary, the GL will notify the local Counsel contact. The local Counsel contact will give advice to the GL, provided that the activity or project does not have national implications, or, if advice is not needed from an Associate Chief Counsel or a Division Counsel Headquarters office.


**37.1.3.4** **(01-23-2013)**

### Counsel Governmental Liaison Coordinator

1. **Novel or significant issues** arising in the Governmental Liaison program require coordination with the appropriate Associate Chief Counsel or Division Counsel Headquarters office. A Senior Counsel to the Associate Chief Counsel (Procedure & Administration) serves as the Counsel Governmental Liaison Coordinator for these matters. In addition to coordinating requests for legal advice sent from local Counsel to Associate Chief Counsel or Division Counsel Headquarters offices, the Counsel Governmental Liaison Coordinator serves as the primary liaison between the Office of Governmental Liaison and the Associate Chief Counsel and Division Counsel Headquarters offices.



### Note:



The position is not responsible for determining substantive legal conclusions, but instead acts as a catalyst to ensure that policy and legal issues are brought to the attention of, and addressed by, the appropriate Associate Chief Counsel and Division Counsel Headquarters offices.

2. The Counsel Governmental Liaison Coordinator's liaison responsibilities include:



   - Coordinating requests for advice between the Office of Governmental Liaison and Associate Chief Counsel and Division Counsel offices

   - Meeting with external stakeholders (e.g., Federation of Tax Administrators) as requested

   - Coordinating Governmental Liaison training for and by Counsel

   - Coordinating the Associate Chief Counsel and Division Counsel Headquarters response on the legal aspects and policy implications of proposed final templates provided to Associate Chief Counsel and Division Counsel by the Office of Governmental Liaison


3. **Criminal Tax Matters**. Agreements entered into between the Service’s Criminal Investigation function and other federal, state or local law enforcement agencies must be forwarded to the Office of Division Counsel/Associate Chief Counsel (Criminal Tax) for review and coordination with Office of Associate Chief Counsel (General Legal Services) and the Counsel Governmental Liaison Coordinator in Procedure and Administration.


**37.1.3.5** **(01-23-2013)**

### Requests for Legal Advice

1. **Initial Coordination**. If a joint activity or project has national implications, or requires advice from an Associate Chief Counsel or Division Counsel Headquarters office, the request for legal advice should be forwarded to the Counsel Governmental Liaison Coordinator, through the Technical Services Support Branch (TSS 4510) for assignment.




| Requests for advice can be: |
| --- |
| _e-mailed_ | to the "TSS4510" mailbox |
| _faxed_ | 202-622-4817 |
| _mailed_ | Technical Services Support Branch, Legal Processing Division<br>Room 5331, CC:PA:LPD:TSS<br>1111 Constitution Ave., NW<br>Washington, DC 20224 |







1. The request should be clearly marked as a "Governmental Liaison" matter.

2. TSS will send the request to the Counsel Governmental Liaison Coordinator, who will determine which Associate Chief Counsel or Division Counsel Headquarter office has subject matter jurisdiction and needs to be involved in providing the advice requested.


2. **Associate Chief Counsel or Division Counsel Review**. Generally, within ten calendar days of receipt of a request for advice from local Counsel on a Governmental Liaison matter forwarded by the Counsel Governmental Liaison Coordinator, the affected Associate Chief Counsel or Division Counsel Headquarters office will:



1. Review the request for any issue on which advice should be provided to local Counsel

2. Review the request to determine if the response should be coordinated among Associate and Division Counsel offices

3. Coordinate to determine whether advice will be provided to local Counsel from any other Associate Chief Counsel or Division Counsel Headquarters office

4. Notify local Counsel and the Counsel Governmental Liaison Coordinator when advice will be provided and whether the advice will be oral advice or written advice


3. **Associate Chief Counsel or Division Counsel Advice**. Written advice generally will be submitted to local Counsel within 45 calendar days of receipt of the assignment. Copies of the written advice will be provided to the affected Associate Chief Counsel and Division Counsel Headquarters offices and the Counsel Governmental Liaison Coordinator. If the request involves a combination of issues, the respective Associate Chief Counsel or Division Counsel Headquarters office shall coordinate their response with the Counsel Governmental Liaison Coordinator. The Counsel Governmental Liaison Coordinator will provide the consolidated written response to local Counsel, and will provide a copy of the consolidated written response to the respective Associate Chief Counsel or Division Counsel Headquarters offices involved.

4. **Local Counsel Legal Advice**. Any written advice from local Counsel to the GL generally will be provided promptly after receipt of the advice from the Associate Chief Counsel or Division Counsel Headquarters office (or notification that advice will not be provided). Copies of any local Counsel advice will be provided promptly to the Counsel Governmental Liaison Coordinator.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part37/irm_37-001-003#addtoany "Show all")

A2A