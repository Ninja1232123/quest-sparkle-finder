---
url: "https://www.irs.gov/irm/part36/irm_36-002-004"
title: "36.2.4 Closing Appeal Cases | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part36/irm_36-002-004#main-content)

- 36.2.4 [Closing Appeal Cases](https://www.irs.gov/irm/part36/irm_36-002-004#idm140076766085536)
  - 36.2.4.1 [General Procedures for Closing Appeal Cases](https://www.irs.gov/irm/part36/irm_36-002-004#idm140076770999024)

    - 36.2.4.1.1 [Preparing Legal Files for Closing](https://www.irs.gov/irm/part36/irm_36-002-004#idm140076797332864)
    - 36.2.4.1.2 [Transmitting Files to the Field](https://www.irs.gov/irm/part36/irm_36-002-004#idm140076763725424)
    - 36.2.4.1.3 [Preparing Closing or Transfer Memorandum](https://www.irs.gov/irm/part36/irm_36-002-004#idm140076778177328)
    - 36.2.4.1.4 [Classification of Closed Case](https://www.irs.gov/irm/part36/irm_36-002-004#idm140076797320960)
    - 36.2.4.1.5 [File Retention](https://www.irs.gov/irm/part36/irm_36-002-004#idm140076812172608)

  - 36.2.4.2 [Closing Procedures Specific to Disclosure Cases](https://www.irs.gov/irm/part36/irm_36-002-004#idm140076797313152)
  - 36.2.4.3 [Closing Procedures Specific to Refund Cases](https://www.irs.gov/irm/part36/irm_36-002-004#idm140076766249328)

# Part 36. Appellate Litigation and Actions on Decision

# Chapter 2. Appeal/Certiorari Recommendations

# Section 4. Closing Appeal Cases

* * *

## 36.2.4 Closing Appeal Cases

#### Manual Transmittal

April 11, 2013

#### Purpose

(1) This transmits revised CCDM 36.2.4, Appeal/Certiorari Recommendations; Closing Appeal Cases.

#### Material Changes

(1) CCDM 36.2.4.3 was revised to incorporate procedures for preparing and routing payment memoranda at the conclusion of refund litigation issued in Chief Counsel Notice CC-2013-009.

(2) References in CCDM 36.2.4.1.3, CCDM 36.2.4.1.4 and CCDM 36.2.4.3 were corrected; titles and hyperlinks were added.

#### Effect on Other Documents

CCDM 36.2.4 dated August 11, 2004 and Chief Counsel Notice CC-2013-009 are superseded.

#### Audience

Chief Counsel

#### Effective Date

(04-11-2013)

Thomas R. Thomas

Acting Associate Chief Counsel

(Procedure and Administration)

**36.2.4.1** **(08-11-2004)**

### General Procedures for Closing Appeal Cases

1. Appeal cases should be closed promptly after the necessary action is completed on the case.



1. Adverse appeal cases in which no appeal was recommended should be closed after receipt of a letter from the Tax Division stating that the Solicitor General has determined an appeal will not be prosecuted.

2. Appeal files, where there has been a favorable decision, may be closed after the appeal period has expired.

3. The belief that an appeal has not been taken should be verified with the Tax Division.


2. Where the Government has been awarded a judgment that has not been paid, the Department of Justice may keep a case open solely for collection purposes. In such cases the Chief Counsel file should be closed without the closing letter.

3. Once the appellate or Supreme Court review is final, the Associate Chief Counsel attorney should complete the case closing documentation (including the appellate database entry form if applicable), submit the case file for closing, and the case should be closed on the appropriate case tracking database.

4. Division Counsel attorneys are responsible for closing all Court of Federal Claims cases, except those involving Windfall Profits tax, and all refund cases initially assigned or transferred to the division while still pending in district court.


**36.2.4.1.1** **(08-11-2004)**

#### Preparing Legal Files for Closing

1. In preparing a case for closing, the loose correspondence and documents that are in the open folder should be inserted in chronological order in the legal file. All essential papers, transcripts of account, briefs, opinions and other official documents should be placed in the legal file.

2. In any case in which a refund has been made, a copy of the payment memorandum and recomputation used to determine the amount refundable and a copy of the Notice of Adjustment memorandum should be in the legal file.


**36.2.4.1.2** **(08-11-2004)**

#### Transmitting Files to the Field

1. The Area Counsel attorney's file forwarded to the Associate Chief Counsel office should be returned with a transmittal form.

2. In adverse cases, either a copy of the Tax Division's letter should be inserted in the Area Counsel attorney's file or the transmittal form should indicate the date and decision of the Solicitor General regarding appeal. If the Area Counsel attorney's file was not forwarded to the Associate Chief Counsel attorney, a transmittal form should be prepared forwarding a copy of the Tax Division letter if the decision was adverse. The Tax Division's recommendation or the recommendation of the attorneys in the Solicitor General's office should be placed in the Associate Counsel file and not in the Area Counsel attorney file.

3. When a refund case is ready for closing, a closing memorandum is prepared, returning the administrative files to the Internal Revenue Service Campus or the appropriate Area Director's office. In most cases, the administrative files will be returned by the Department of Justice with the closing letter, but in some instances it may be necessary to remind the Department of Justice attorney to return the administrative files.


**36.2.4.1.3** **(04-11-2013)**

#### Preparing Closing or Transfer Memorandum

1. For instructions on preparing the closing or transfer memorandum, see CCDM 34.10.1.2.1, Closing Memorandum.

2. A separate memorandum need not be prepared to close a jacketed division file in a general litigation case.


**36.2.4.1.4** **(04-11-2013)**

#### Classification of Closed Case

1. See CCDM 34.10.1.2.1, Closing Memorandum, for instructions regarding the classification of closed cases.


**36.2.4.1.5** **(08-11-2004)**

#### File Retention

1. The Area Counsel attorney is to retain and close legal files unless an appeal is filed or a special need exists for permanent storage. If files are forwarded to an Associate Counsel office for appeal consideration, but no appeal is filed, the files are returned to the appropriate Area Counsel office for closing and storage.

2. For appealed cases and tried cases closed prior to September 1, 1990, the Docket, Records & User Fee Branch of Office of the Associate Chief Counsel (Procedure and Administration) will continue to maintain a log of closed cases and will obtain the closed files on request. To obtain a file closed by the Docket, Records & User Fee Branch, the Area Counsel attorney need only provide the case name, docket number, and approximate closing date (e.g., month, year). For tried, unappealed cases closed after September 1, 1990, the Area Counsel attorney offices should insure that:



1. Files are available locally and readily retrievable for one year after closing

2. FRC data is readily available for files that are needed after they have been forwarded to a federal records center


**36.2.4.2** **(08-11-2004)**

### Closing Procedures Specific to Disclosure Cases

1. After the appellate process is complete and there is a final adjudication of the matter, the attorney should contact all appropriate functions, as well as the Office of Government Liaison & Disclosure, provide them with a copy of the court's decision and inform them of the likely ramifications of that decision on Service procedures. Such notification should occur in cases where the Government prevails in litigation, as well as those where the Government loses.


**36.2.4.3** **(04-11-2013)**

### Closing Procedures Specific to Refund Cases

1. A crucial prerequisite to closing a refund case in which a refund is to be paid to a taxpayer is preparing a payment memorandum and transmitting it to the appropriate IRS Campus. A payment memorandum is a document that authorizes and instructs the Service to refund or credit a certain amount of tax, applicable amounts of penalty, and assessed underpayment interest. It is only prepared when the Government has either partially or totally lost a case and a final judgment in favor of the taxpayer has been entered or when the Government has settled or conceded a case and a refund or credit is warranted.

2. See CCDM 34.10.1.2.2, Payment Memoranda, for instructions on preparing and transmitting payment memoranda. The field attorney prepares the payment memorandum in all cases in which a Chief Counsel attorney, rather than a Department of Justice attorney, is responsible for preparing the payment memorandum even if an Associate Chief Counsel attorney is also assigned to the case.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part36/irm_36-002-004#addtoany "Show all")

A2A