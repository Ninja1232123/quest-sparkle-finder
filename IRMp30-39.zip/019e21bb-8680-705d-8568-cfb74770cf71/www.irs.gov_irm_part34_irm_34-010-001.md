---
url: "https://www.irs.gov/irm/part34/irm_34-010-001"
title: "34.10.1 General Procedures | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part34/irm_34-010-001#main-content)

- 34.10.1  [General Procedures](https://www.irs.gov/irm/part34/irm_34-010-001#idm139887185633632)
  - 34.10.1.1  [Notification of Decisions](https://www.irs.gov/irm/part34/irm_34-010-001#idm139887189970800)
    - 34.10.1.1.1  [Procedures — Field Offices](https://www.irs.gov/irm/part34/irm_34-010-001#idm139887189967760)
    - 34.10.1.1.2  [Appeal Procedures and Recommendations](https://www.irs.gov/irm/part34/irm_34-010-001#idm139887185625792)
    - 34.10.1.1.3  [Certiorari Matters](https://www.irs.gov/irm/part34/irm_34-010-001#idm139887185624032)
  - 34.10.1.2  [Closing Refund Cases](https://www.irs.gov/irm/part34/irm_34-010-001#idm139887185621552)
    - 34.10.1.2.1  [Closing Memorandum](https://www.irs.gov/irm/part34/irm_34-010-001#idm139887157477792)
    - 34.10.1.2.2  [Payment Memorandum](https://www.irs.gov/irm/part34/irm_34-010-001#idm139887157537232)
      - 34.10.1.2.2.1  [Preparing the Payment Memorandum](https://www.irs.gov/irm/part34/irm_34-010-001#idm139887158017200)
      - 34.10.1.2.2.2  [Where to Send the Payment Memorandum](https://www.irs.gov/irm/part34/irm_34-010-001#idm139887157115904)
      - 34.10.1.2.2.3  [Computation of Statutory Interest](https://www.irs.gov/irm/part34/irm_34-010-001#idm139887157112992)
  - 34.10.1.3  [Closing Collection Cases](https://www.irs.gov/irm/part34/irm_34-010-001#idm139887157110800)
    - 34.10.1.3.1  [Litigation Case Files](https://www.irs.gov/irm/part34/irm_34-010-001#idm139887157109024)
    - 34.10.1.3.2  [Notification to Other Offices](https://www.irs.gov/irm/part34/irm_34-010-001#idm139887157130464)
  - 34.10.1.4  [Closing Appellate Cases](https://www.irs.gov/irm/part34/irm_34-010-001#idm139887157099056)
  - 34.10.1.5  [Closing a Section 7428 Declaratory Judgment Case in United States District Court for District of Columbia or Court of Federal Claims](https://www.irs.gov/irm/part34/irm_34-010-001#idm139887157091024)
  - 34.10.1.6  [Notification to the IRS Campus of Need for Assessment in BBA Partnership Cases in District Court and the Court of Federal Claims](https://www.irs.gov/irm/part34/irm_34-010-001#idm139887157088736)
  - 34.10.1.7  [Notification to the IRS Campus of Need for Assessment in TEFRA Partnership Cases in District Court and the Court of Federal Claims](https://www.irs.gov/irm/part34/irm_34-010-001#idm139887158486832)
  - 34.10.1.8  [Closing Passport Cases](https://www.irs.gov/irm/part34/irm_34-010-001#idm139887157341056)

# Part 34. Chief Counsel Directives Manual Litigation in District Court, Bankruptcy Court, Court of Federal Claims, and State Court

# Chapter 10. Post-Trial Procedures

# Section 1. General Procedures

* * *

## 34.10.1 General Procedures

#### Manual Transmittal

August 09, 2023

#### Purpose

(1) This transmits a new subsection to CCDM 34.10.1.8, Closing Passport Cases.

#### Material Changes

(1) CCDM 34.10.1.8 describes the procedures for closing section 7345 passport cases that originated in the district court.

#### Effect on Other Documents

CCDM 34.10.1, dated July 10, 2023, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(08-09-2023)

Robert T. Wearing

Deputy Associate Chief Counsel

(Procedure & Administration)

**34.10.1.1** **(04-16-2013)**

### Notification of Decisions

1. The decision to appeal from an adverse decision will be made by the Chief Counsel. That decision will be based on the recommendation of the Associate Chief Counsel with responsibility over the technical issues presented in the case. The Associate Chief Counsel will have considered Division Counsel’s recommendation and will have reached a consensus with Division Counsel regarding appeal, or will present the opposing points of view to the Chief Counsel for resolution.

2. Procedures for appellate cases are contained in CCDM Part 36, Appellate Litigation and Actions on Decision. For a discussion of what constitutes an appellate case for purposes of these procedures, see CCDM 36.1.1.2, Definition of Appeal Cases.


**34.10.1.1.1** **(07-10-2023)**

#### Procedures — Field Offices

1. **In General**. Field Counsel must establish appropriate procedures to learn of the entry of each judgment or appealable order concerning any collection case at the earliest possible time. The Department of Justice (DOJ) has instructed each U.S. Attorney to promptly furnish copies of all opinions, orders, and decisions directly to the appropriate Field Counsel office. With respect to adverse state court decisions, the U.S. Attorney will explicitly advise Field Counsel of the applicable state court appellate time limits within which the Government’s appeal processing is to be completed.

2. **Correspondence**. Upon being informed of an adverse decision by the Tax Division or the U.S. Attorney, Field Counsel should immediately contact the Associate Chief Counsel office with jurisdiction over the case, by telephone or email, to advise the appropriate branch chief. As soon as the adverse decision is received, Field Counsel should fax or email a copy to the appropriate Associate office. All pertinent documents to the issues on appeal should be transmitted immediately to the appropriate branch without waiting for a request by DOJ or the Associate office. The correspondence should not be directly sent to DOJ or the U.S. Attorney. If time permits, the Associate office attorney may request additional documentation from Field Counsel.

3. **Time Limitations**. Unless a specific deadline has been set or the circumstances of the case require a shorter period to act, within 30 days of the adverse decision, Field Counsel should contact the DOJ attorney who tried the case and request the filing of a protective notice of appeal.



1. From United States District Courts and Court of Federal Claims. In appeals to courts of appeals, including bankruptcy cases, the recommendation of Division Counsel, if any, should be received by the Associate office with jurisdiction over the case no less than 10 days after notification of the adverse decision unless the Associate office agrees to a longer period.

2. From Courts of Appeals. Recommendations by Division Counsel relative to certiorari should be received by the Associate office with jurisdiction over the case no later than 10 days from the date of the order unless the Associate office agrees to a longer period.

3. State Court. In state court proceedings where the time for appeal is 30 days or more, the recommendation of Division Counsel, if any, should be received by the Associate office with jurisdiction over the case no less than 10 days after entry of the adverse decision unless the Associate office agrees to a longer period. If the period for appeal is less than 30 days, Field Counsel should advise the appropriate Associate office branch chief by telephone so that steps can be taken to protect the appeal period and ensure that a recommendation is made to the Department of Justice within sufficient time to allow DOJ to act before the expiration of the time for appeal.

4. Effect of Extensions. In considering the time for referral of proposed appeal recommendations, Division Counsel should not rely upon or consider any extended time which may be secured by reason of the filing of a protective notice of appeal.


4. **Offers in Settlement**. If the Tax Division forwards an offer in settlement in an appeal case, the matter, at a minimum, will be orally coordinated with Field Counsel. If time permits, the Department of Justice letter, together with copies of the offer in settlement and any documents necessary to consider the offer in settlement, will be forwarded (preferably by secure email) to Field Counsel for a recommendation. Field Counsel will respond with the recommendation. The Department of Justice has agreed that when requesting Chief Counsel’s view, it will furnish all pertinent information, including its views on settlement.

5. **Recommendations**. See CCDM Part 36, Appellate Litigation and Actions on Decision, for procedures concerning appeal recommendations.

6. **Closing the Field Counsel Case**. Field Counsel’s case should be closed and a copy of its closing memorandum placed in the legal file prior to transmittal of the file to the Associate office with jurisdiction over the case. The file or relevant portions thereof may be transmitted electronically. If the case cannot be closed because other aspects of the case remain open at the trial level or due to other reasons, Field Counsel should either extract from the file all documents pertaining to the appeal, or transmit such documents to the Associate office, with recommendation of Division Counsel concerning an adverse appeal, if appropriate. These documents may be maintained in electronic form and transmitted electronically to the Associate office.

7. **Appellate Briefs and Documents**. If more than one copy of any appellate brief is received from the Tax Division, the Associate office will transmit a copy to Field Counsel. In addition, the Associate office will transmit to Field Counsel a copy of any important document or letter received from the Tax Division. Field Counsel is not required to furnish any comments on the brief, document, or letter unless requested to do so by the Associate office or it believes some comment is necessary.

8. **Return of the Area Counsel File**. Most files will be maintained in electronic form. If Field Counsel sends paper files to the Associate office, these paper files will be kept until the time for certiorari expires and then returned to Field Counsel.



1. After final disposition of the appellate aspects of a case, the Associate Chief Counsel project file is closed and Field Counsel’s legal file (if forwarded to the Associate office) will be returned for such further field action as may be required. Associate Chief Counsel will notify the Field Counsel when the file is closed if no paper file was sent.

2. Field Counsel should advise the Area Director’s office of any adjustment of accounts, refunds of monies, release of levies, and other actions.


**34.10.1.1.2** **(04-16-2013)**

#### Appeal Procedures and Recommendations

1. For procedures relating to appeals and the process for recommending for or against appeal, see CCDM 36.2.1, Appeal Recommendations in General.


**34.10.1.1.3** **(07-10-2023)**

#### Certiorari Matters

1. For procedures to be followed in certiorari matters, see CCDM 36.2.2, Petition for Writ of Certiorari.


**34.10.1.2** **(07-10-2023)**

### Closing Refund Cases

1. **Field Counsel Closing**. If a case is settled or tried and is not appealed, DOJ will send a letter to Field Counsel stating that the case has been closed in the Tax Division. The letter will be sent after all action has been completed on the settlement or the appeal period has expired. Usually, the DOJ closing letter on a case not appealed by the taxpayer is prepared 10 days after the expiration of the appeal period. On receipt of the closing letter, the Field Counsel attorney should close the case, even if the case is being kept open by DOJ solely for collection purposes.

2. **Associate Chief Counsel Office Closing**. If a case is appealed, but affirmed or decided such that no remand is necessary, an attorney from the appropriate Associate office should close the case when the DOJ closing letter is received. Those attorneys are also responsible for closing any other refund cases initially assigned or transferred to the Associate office while still pending in district court or the Court of Federal Claims.


**34.10.1.2.1** **(07-10-2023)**

#### Closing Memorandum

1. In most instances, the Department of Justice will return the administrative files to Field Counsel with its closing letter. It may be necessary, however, to remind the DOJ attorney to return the files. In many cases, documents are sent electronically and DOJ will not have paper files to return. Upon receipt of the files and closing letter, Field Counsel should prepare a closing memorandum, returning any paper administrative files to the Service Center or Area Director. A closing memorandum serves to process a refund suit for closing, tells the basis on which the case was closed, and disposes of the legal and administrative files. The closing memorandum may be sent electronically if there are no paper files to close or return.

2. There are two types of closing memoranda: Form 3011-B, Transmittal Memorandum (100% Penalty Cases), is used only for trust fund recovery penalty cases, and Form 3011-A, Transmittal Memorandum, is used for all other tax cases. The administrative files are returned to the Area Director only when a trust fund recovery penalty case is closed. If any returns were requested in a trust fund recovery penalty case from the Service Center, these files are returned to the Service Center. For TEGEDC cases, the closing memorandum may be sent electronically. If paper administrative files are obtained, they should be returned to the Service Center or Area Director. Where files are accessed electronically through the Reporting Compliance Case Management System (RCCMS), the files should be returned to the RCCMS Closed Case Library.

3. If a refund has been made, a copy of the computation used to determine the refundable amount and a copy of the Notice of Adjustment memorandum should be in the legal file.

4. The office closing the case must determine whether the case is to be classified as significant pursuant to the criteria listed in this paragraph. The legal files in cases classified as significant are forwarded to the Office of the Associate Chief Counsel (P&A), for storage. These files are retained for thirty years by one of the federal record centers of the General Services Administration, and then destroyed. All other cases are retained for ten years. The classification must be made by a person who is, at a minimum, a GS/GM-15. If a case is classified as significant, the words, "Significant Case" are to be written or stamped on the outside of the legal file. The initials of the person classifying the case and the date should be placed close to the words, "Significant Case." The following is a guideline as to which cases should be considered significant:



1. There has been a petition for certiorari filed by the Government or when the Government acquiesces in a petition for certiorari filed by a taxpayer or taxpayers.

2. Important, novel, or controversial tax questions are involved.

3. The Service prepared a formal Action on Decision.

4. An issue is decided which might affect the particular taxpayer for an extended time period.

5. In the discretion of the classifier, the file merits retention.


5. Closed files should normally be retained in the closing office for one year prior to being forwarded to a federal records center for storage so that they may be easily retrievable if needed in related or similar cases. More rapid forwarding to a federal records center may be authorized by the Area Counsel.



1. Upon forwarding to a Federal Records Center (FRC), the relevant FRC data (record group number, accession number, FRC box number, and FRC location number), should be recorded and retained to assist in the event retrieval from the federal records center is necessary. If the file is an electronic file, similar information should be retained about the electronic transfer to assist in requesting the file from the FRC at a later date.


**34.10.1.2.2** **(04-16-2013)**

#### Payment Memorandum

1. Payment memoranda are prepared at the conclusion of a refund suit when the Government has either partially or totally lost a case and a final judgment in favor of the taxpayer has been entered, or when the Government has settled or conceded the case resulting in a refund or credit due the taxpayer. The payment memorandum authorizes and instructs the Service to refund or credit a certain amount of tax, applicable amounts of penalty, and assessed underpayment interest. When a refund is warranted at the conclusion of a refund suit, the case cannot be closed until the refund is paid to the taxpayer, so it is important that the payment memorandum be prepared and transmitted timely. See CCDM 34.10.1.2.2.1(2) to determine who — the field attorney or the Department of Justice attorney — prepares the payment memorandum and transmits it to the appropriate IRS Campus for processing.

2. If the refund case involves a trust fund recovery penalty, Department of Justice and field attorneys should not follow the payment-memorandum procedures identified in CCDM 34.10.1.2.2. Instead, the DOJ attorney should notify the field attorney, in writing, that the refund litigation is concluded, and the field attorney should work with the local Field Collection Advisory Group (Advisory) to get a refund issued to the appropriate claimant(s). The assigned field attorney will need to provide a copy of the judgment or settlement document to Advisory, along with a memorandum explaining, in detail, the action that Advisory needs to take to refund the specified amounts to the claimant(s).


**34.10.1.2.2.1** **(04-16-2013)**

##### Preparing the Payment Memorandum

1. **How Prepared**. Use Form 8690, Memorandum — Refund Pursuant to Judgement, when a final judgment in favor of the taxpayer has been entered. Use Form 8691, Memorandum — Refund Pursuant To Settlement/Government Concession, (referred to as Form M-4457 by DOJ) when the Government has settled or conceded the case.

2. **By Whom Prepared**. In cases in which a final judgment in favor of the taxpayer has been entered, the field attorney will prepare the Form 8690 and send it to the appropriate Campus for processing. See Exhibit 34.12.1-37 , Sample Payment Memorandum (Form 8690). See Exhibit 34.12.1-33, Chart for Determining Campus to Process Refund, and Exhibit 34.12.1-36, Campus Addresses and Contacts, to determine the appropriate Campus. In cases in which the Government has settled or conceded the case, the DOJ attorney, when feasible, will prepare the Form 8691 (DOJ Form M-4457) and forward it directly to the Campus for processing. Even in settled and conceded cases, however, DOJ attorneys may, at their discretion, send prepared Forms M-4457 to the field attorney for execution and forwarding to the appropriate Campus. To ensure that payment memoranda are timely prepared and forwarded to the appropriate Campus for processing, it is imperative that the assigned field attorney communicate with the assigned DOJ attorney about who will prepare and transmit the memorandum.



### Note:



When a settlement is approved, but the overpayment amount has not yet been computed, the DOJ attorney may request that the field attorney obtain a recomputation as well as prepare and execute the payment memorandum. See CCDM 34.10.1.2.2.1(4) for more information on computations.

3. **Background Information**. When transmitting payment memoranda to the appropriate Campus, field attorneys should include the following as background information:



1. Closing letter from DOJ

2. An original and one copy of the certified judgment (or settlement document)

3. Computation (if required)

4. Copy of the taxpayer’s complaint

5. Any other information requested by the Campus


4. **Computations**. To obtain a computation for settlements and judgments in refund-litigation cases, field attorneys should contact Appeals Tax Computation Specialists (TCS). The computation must show breakdowns of tax, penalties, and underpayment interest by periods. See IRM 8.17.5.29, Refund Litigation Cases, for additional information.


**34.10.1.2.2.2** **(04-16-2013)**

##### Where to Send the Payment Memorandum

1. Exhibit 34.12.1-33, Chart for Determining Campus to Process Refund, is a chart to assist field attorneys in determining which Campus should process the refund. This chart cannot account for every type of refund case. If the chart does not clearly show which campus would handle the refund, field attorneys should call the Campus contacts to verify the correct point of delivery.

2. Exhibit 34.12.1-36, Campus Addresses and Contacts, provides a list, current as of the publication date in the CCDM, of Campus addresses and contacts to be used for payment memoranda purposes only. online at . To ensure the most current Campus mailing information, field attorneys should refer to this website. Field attorneys may also call a Campus contact in nonroutine cases if there is a question on whether additional information or documents are needed to process the refund. See CCDM 34.10.1.2.2.1(3)(e).


**34.10.1.2.2.3** **(04-16-2013)**

##### Computation of Statutory Interest

1. The payment memorandum should request copies of both the statutory interest computation and the notice of adjustment. See Exhibit 34.12.1-37, Sample Payment Memorandum (Form 8690). The purpose of these copies is to resolve quickly any dispute over the amounts refunded or credited. The field attorney should review the statutory-interest computation as soon as it is received. If any portion appears to be in error, the field attorney should consult the DOJ attorney about delaying delivery of the refund check until the statutory interest computation can be verified.


**34.10.1.3** **(07-10-2023)**

### Closing Collection Cases

1. In general, all collection cases (Associate office and field) will be closed as soon as the work required of the field office or the Associate office is completed.


**34.10.1.3.1** **(07-10-2023)**

#### Litigation Case Files

1. Cases in litigation should be kept open until notified by the Department of Justice or United States Attorney that the litigation has been completed, the matter will not be pursued further, or their case has been closed. In situations in which Field Counsel, based on the facts known to the office, is of the opinion the proceeding can be considered closed, Field Counsel may write to DOJ and advise them that the Chief Counsel’s file is being closed.

2. When there is an adverse order entered (excluding bankruptcy appeals to the district court), the case should be closed in the Field Counsel office and the file transmitted to the Associate Chief Counsel with jurisdiction over the case, together with any proposed appeal letter or recommendation of the Field Counsel.

3. Bankruptcy Code Proceeding. The general rule set forth in (1), above, is equally applicable to all Bankruptcy Code proceedings. However, if in the discretion of the supervisor, it is determined that no additional work will be necessary, the case can be closed upon the completion of the required work. If it becomes necessary to reopen the case under the same chapter, the reopening will be counted as a new receipt for statistical case load purposes. The reopened case will not be included as a receipt for staffing model purposes.


**34.10.1.3.2** **(07-10-2023)**

#### Notification to Other Offices

1. Whenever a case is closed, the office or officials who originated the case should be advised of such closing, the reason for the closing, and any action which should be taken. The following procedures are suggested.



1. Field Counsel should coordinate with Area Director offices to ascertain what information is feasible and necessary to forward and to what extent copies of documents need to be added to the Area Directors’ files.

2. The Area Director’s office should receive a copy of any judgments.

3. Field Counsel must make certain that the Area Director office is informed as to the final disposition of a court case and, when necessary, furnished with copies of trial or appellate court orders and opinions.


2. When a memorandum or letter is inappropriate or not available, a memorandum should be prepared for the file to advise any subsequent reader of the reason for closing the file.

3. **Use of a Closing Stamp**. The Area Counsel may find it feasible to use a process similar to the one described below which is in use in Associate offices.



1. A separate memorandum need not be prepared to close an Associate Chief Counsel file. The advisory opinion memorandum, letter, or memorandum advising the originating office of the case disposition or that files are being returned, or other document explaining that the matter has been finalized, serves to show the case can be closed.

2. When closed, all Associate office legal files will be stamped on the face of the jacket with the closing stamp and with the date and initials of the supervisor (or branch chief secretary, when so authorized), approving the closing. The closing stamp-mark must be initialed to show that the closing is approved.

3. After the branch records are marked CLOSED, the legal file is sent to the docket room; the file is then retained in the docket room or sent to closed files.


4. **Closing Field Counsel Files**. The Field Counsel files will be considered closed upon completion or review of the material submitted by the Area Director office. They will be retained for one year after the last piece of correspondence has been received, and then they will be destroyed.

5. **Significant Associate Office Cases**. Due to space and budgeting limitations, the retention period for closed Associate office files by the Federal Records Center is now 10 years after closing. However, pursuant to Records Control Schedule 106, if a file is designated as significant, it will be retained for 25 years prior to destruction. The designation as significant must be:



   - Made by a GS/GM-15 at closing

   - Clearly designated as significant in red ink on the case jacket

   - Initialed

   - Dated

   - Entered as a field in GLTRACK


6. **Definition of Significant**. A significant case is one that contains materials of an important precedential nature in which the legal issues are likely to arise again and are novel or controversial. The designation should not be made routinely. It should only apply to those cases which clearly merit an extended retention period of 25 years. The determination is to be done on a case-by-case basis and is a judgment to be made by the supervisor/manager.

7. **Penalty Refund Cases Under IRC §§ 6682, 6694, and 6702**. In any case in which a taxpayer has filed an action for a refund of the penalty imposed under IRC §§ 6682, 6694, or 6702, and Field Counsel has been advised that the court has made a final determination as to the taxpayer’s liability for the penalty, the Service Center will be notified as to the final outcome of the litigation so that steps can be taken to either collect or abate the penalty.



1. Field Counsel should periodically check the status of these cases with the Department of Justice to ascertain whether a decision has been rendered and the appeal period has run so that the appropriate action can be taken.

2. Form 3011-A, Transmittal Memorandum (which is presently being used by Procedure & Administration to close refund cases), should be used to notify the Service Center of the outcome of these types of collection litigation refund cases. Modifications should be made to the form where appropriate. An original and two copies of Form 3011-A should be transmitted.

3. Field Counsel should ascertain the appropriate office and STOP number in the Service Center to which the Transmittal Memorandum should be directed.

4. Along with the administrative file, relevant tax returns, and Certificate of Assessments and Payments, the Form 3011-A should advise the Service Center that the balance of the penalty should be collected (or the penalty abated).


**34.10.1.4** **(07-10-2023)**

### Closing Appellate Cases

1. **Appeal Cases**. Associate Chief Counsel office appeal cases will be closed when the Department of Justice advises that no appeal or petition for certiorari will be filed or the time for filing a petition or appeal from a final order has expired.



1. In General. Before closing appeal cases, copies of all correspondence, and briefs sent or filed at the appellate level should be inserted in the Associate office appeal file. Briefs should be attached to a cardboard back, two-hole punched and inserted in the appeal file.

2. Appeal cases should be closed promptly after the necessary action is completed on the case. Adverse appeal cases in which the Associate office has recommended no appeal should be closed after receipt of a letter from the Tax Division stating that the Solicitor General has determined an appeal will not be prosecuted. Where there has been a favorable decision, an appeal file may be closed after the appeal period has expired. The belief that an appeal has not been taken should be verified with the Tax Division.


2. **Field Counsel Notification**. If a paper filed was received, the Associate office should return the Field Counsel file with a transmittal form. In the transmittal's subject line include the taxpayer’s name and the Field-Counsel file reference. Indicate in the transmittal that the legal file is being returned and that the Associate-office file is closed. If the file was electronically transmitted and there is no paper file to return, the Associate office will notify Field Counsel that the Associate office file is now closed.

3. **Tax Division Correspondence**. In adverse cases, either a copy of the Tax Division’s letter should be inserted in the Field Counsel file or the last box should be checked and a notation inserted such as, "A copy of a letter dated September 9, 2011, advising that the Solicitor General determined an appeal would not be prosecuted." If the Field Counsel’s file was not forwarded to the Associate office, a transmittal form should be prepared forwarding a copy of the Tax Division letter if the decision was adverse. Tax Division’s recommendation or the recommendation of the attorneys in the Solicitor General’s office should be placed in the Associate office file and not in the Field Counsel file.


**34.10.1.5** **(07-10-2023)**

### Closing a Section 7428 Declaratory Judgment Case in United States District Court for District of Columbia or Court of Federal Claims

1. Exempt organization declaratory judgment cases under section 7428 in the United States District Court for the District of Columbia or the Court of Federal Claims are closed in a similar manner as declaratory judgment cases under section 7428 in the United States Tax Court. The closing memorandum may be sent electronically. If paper administrative files are obtained, they should be returned to Appeals. Where files are obtained electronically through RCCMS, the files should be return to the RCCMS Closed Case Library.


**34.10.1.6** **(07-10-2023)**

### **Notification to the IRS Campus of Need for Assessment in BBA Partnership Cases in District Court and the Court of Federal Claims**

1. Section 6232 provides in pertinent part that no assessment of an imputed underpayment may be made before the close of the 90th day after the day on which the IRS mails a notice of a final partnership adjustment (FPA) to the partnership and partnership representative (PR) entitled to receive notice of the FPA under section 6231. If the PR begins a proceeding under section 6234 in the Tax Court, a US District Court, or the Court of Federal Claims during such 90-day period, no assessment can be made until the court’s decision becomes final.

2. The Counsel Automated Tracking System for Docketed Cases will have an event created so that the attorney assigned to a US District Court or the Court of Federal Claims BBA partnership case will receive periodic reminders of the need to assess. Such a reminder will appear as an event entitled “Follow-Up with DJ,” which will occur approximately six months after a defense letter is mailed to DOJ, and it will continue to occur every six months. When such an event appears on the weekly suspense report, the attorney must coordinate with the DOJ attorney assigned to the case to determine whether DOJ has entered into a settlement agreement and whether a decision or dismissal has been entered in the BBA partnership case.



1. The CATS operator will receive from the attorney a written explanation of the status of the case (e.g., no decision, decision entered, or settlement), and the operator will enter a response into CATS.


3. Once partnership items are determined by settlement or court decision, the assigned attorney will instruct the campus to initiate the appropriate assessment procedure.



1. Items Needed in a Closing Package for the Campus



      > - A Form 3210 noted as a court decision package which clearly indicates the partnership name, tax year, EIN, and one-year assessment statute date;
      >
      >
      >       - A Form 886-Z with the corrected amount for each adjusted item of the key case entity return that reflects the terms of the court decision and/or settlement agreement;
      >
      >
      >       - A copy of the court decision document and/or settlement agreement;
      >
      >
      >       - A Form 886-A explaining the changes, if appropriate;
      >
      >
      >       - A completed Form 4605-A, and;
      >
      >
      >       - Penalty information (except for tax years ending after August 5, 1997, since penalties must be included in the Form 4605-A for tax years ending after that date). If penalties are not applicable, note that fact in the package;

2. The closing information should be sent as follows:


   - Internal Revenue Service


      Mail Stop 4510 – Attn: -4 Analyst


      1973 N. Rulon White Blvd.


      Ogden, Utah 84404


**34.10.1.7** **(07-10-2023)**

### Notification to the IRS Campus of Need for Assessment in TEFRA Partnership Cases in District Court and the Court of Federal Claims

1. Section 6225 provides in pertinent part that no assessment of a deficiency attributable to any partnership item may be made before the close of the 150th day after the day on which a notice of final partnership administrative adjustment is mailed to the tax matters partner. If a proceeding is begun in the Tax Court under section 6226 during such 150-day period, no assessment can be made until the Tax Court decision becomes final. Consequently, if the FPAA is petitioned only to a district court or the Court of Federal Claims, the FPAA adjustments may be immediately assessed if they are not subject to further partner-level affected item factual determinations.

2. A second restriction on assessment applies to affected items requiring partner-level determinations. These affected items require a notice of deficiency that generally cannot be issued until the docketed partnership proceeding becomes final. See _GAF Corp. and Subsidiaries v. Commissioner_, 114 T.C. 519 (2000); _Adkison v. Commissioner_, 592 F.3d 1050, 1053-1056 (9th Cir. 2010).

3. The Service generally has one year from the date a court decision becomes final to make direct assessments and to issue affected item notices of deficiency. I.R.C. § 6229(d).



1. Unlike Tax Court cases, district court and Court of Federal Claims cases become final 60 days after a decision is entered.


4. If a partner enters into a settlement agreement with the Department of Justice, the settling partner’s partnership items convert to nonpartnership items under section 6231(b)(1)(C) and the partner drops out of the partnership proceedings under section 6226(d)(1)(A). The Service generally has one year from the date that DJ accepts the partner’s written settlement offer to assess tax against the settling partner. I.R.C. § 6229(f).



1. DJ partner-level settlement agreements take the form of an offer by letter from the settling partner followed by an acceptance letter by DJ.

2. Note that a stipulation, by itself, is generally not treated as a “settlement agreement” under section 6224(c) because it is subject to acceptance by the court and, thus, is not independently binding.


5. The Counsel Automated Tracking System for Docketed Cases will have an event created so that the attorney assigned to a district court or the Court of Federal Claims TEFRA partnership case will receive periodic reminders of the need to assess. Such a reminder will appear as an event entitled “Follow-Up with DJ,” which will occur approximately six months after a defense letter is mailed to DJ, and it will continue to occur every six months. When such an event appears on the weekly suspense report, the attorney must coordinate with the DJ attorney assigned to the case to determine whether DJ has entered into a partner-level settlement agreement and whether a decision or dismissal has been entered in the TEFRA partnership case.



1. The CATS operator will receive from the attorney a written explanation of the status of the case (e.g., no decision, decision entered, or partner settlement), and the operator will enter a response into CATS. The CATS system will generate a monthly CATS status report of all such cases, and the report will be sent to both the Ogden Campus and the Brookhaven Campus.


6. Once partnership items are determined by settlement or court decision, the assigned attorney will instruct the campus to initiate the appropriate assessment procedure.



1. Items Needed in a Closing Package for the Campus



      > - A Form 3210 noted as a court decision package which clearly indicates the partnership name, tax year, EIN, and one-year assessment statute date; A Form 886-Z with the corrected amount for each adjusted item of the key case entity return that reflects the terms of the court decision and/or separate settlement agreement entered into by a partner;
      >
      >       - A copy of the court decision document and/or any separate partner-level settlement agreement;
      >
      >       - A Form 886-A explaining the changes, if appropriate;
      >
      >       - A completed Form 4605-A;
      >
      >       - Penalty information (except for tax years ending after August 5, 1997, since penalties must be included in the Form 4605-A for tax years ending after that date). If penalties are not applicable, note that fact in the package; and,
      >
      >       - If a partner of the partnership has reported a loss (or reduced gain) as a result of selling a partnership interest or distributed asset, the attorney must coordinate with Procedure and Administration branches 6 or 7 to determine whether to include notice of deficiency language and notify the Service of the protective procedures as described in CCDM 35.9.3.5.2 (4), _Assessing TEFRA Cases_.

2. It is important that the correct Campus be informed of a separate partner-level settlement and/or court decision as soon as possible to allow them time to process the investor returns. The closing information should be sent as follows:


       • For SB/SE Returns


       Brookhaven Compliance Center


       Internal Revenue Service


       P.O. Box 630


       Mail Stop 631 – Attn: TEFRA Coordinator


       Holtsville, New York 11742




       • For LB&I Returns:


       Internal Revenue Service


       Mail Stop 4510 – Attn: TEFRA Coordinator


       1973 N. Rulon White Blvd.


       Ogden, Utah 84404


**34.10.1.8** **(08-09-2023)**

### Closing Passport Cases

1. **Field Counsel Closing.** Field Counsel will close all passport cases, whether tried, settled, or dismissed, after the decision becomes final.



1. The IRS passport team, SB/SE Collection, monitors all district court cases. The passport team should be notified of any case closing, regardless of outcome. Contact the passport team at \*SBSE Passport Group. See I.R.M. 5.19.25. If a case requires a reversal of a certification, notify the passport team that a reversal is required.

2. If a case is settled, tried, or dismissed, and is not appealed, the Department of Justice will send a letter to Field Counsel stating that the case has been closed in the Tax Division. The letter will be sent after all action has been completed on the settlement or the appeal period has expired. Usually, the DOJ closing letter on a case not appealed by the taxpayer is prepared 10 days after the expiration of the appeal period. Upon receipt of the closing letter, the Field Counsel attorney should notify the assigned Associate Chief Counsel Office attorney and close the case.


2. **Associate Chief Counsel Office Closing.**If a case is appealed, but affirmed or decided such that no remand is necessary, an attorney from the Associate Chief Counsel (P&A), Branch 3 or 4, should close the case when the DOJ closing letter is received.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part34/irm_34-010-001#addtoany "Show all")

A2A