---
url: "https://www.irs.gov/irm/part30/irm_30-004-006"
title: "30.4.6 Leave Administration | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part30/irm_30-004-006#main-content)

- 30.4.6 [Leave Administration](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010922356784)
  - 30.4.6.1 [Authority](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010922356368)
  - 30.4.6.2 [Annual Leave](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010906959504)

    - 30.4.6.2.1 [Advanced Annual Leave](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010922171184)
    - 30.4.6.2.2 [Restoration of Forfeited Annual Leave](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010907211312)

      - 30.4.6.2.2.1 [Use of Restored Annual Leave](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010907189440)

    - 30.4.6.2.3 [Sequence of Leave Usage](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010907181696)
    - 30.4.6.2.4 [Separating From Federal Service](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010907164528)

      - 30.4.6.2.4.1 [Granting Annual Leave Prior to Separation](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010907159792)

    - 30.4.6.2.5 [Credit for Non-Federal Service](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010907152944)

      - 30.4.6.2.5.1 [Responsibilities](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010907139744)
      - 30.4.6.2.5.2 [Requirements for Granting Credit for Non-Federal Service](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010907122944)
      - 30.4.6.2.5.3 [Documentation for Granting Credit](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010907104304)

  - 30.4.6.3 [Sick Leave](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010907084672)

    - 30.4.6.3.1 [Advanced Sick Leave](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010907068224)

  - 30.4.6.4 [Leave Without Pay (LWOP)](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010907054720)

    - 30.4.6.4.1 [Extended LWOP (Three Months to One Year)](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010907044592)

  - 30.4.6.5 [Absence Without Leave (AWOL)](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010907026336)
  - 30.4.6.6 [Family and Medical Leave Act (FMLA) of 1993](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010907022496)
  - 30.4.6.7 [Other Types of Leave](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010907007728)

    - 30.4.6.7.1 [Absence for Maternity/Paternity Reasons](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010907005440)
    - 30.4.6.7.2 [Organ and Bone Marrow Donation](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010906997200)
    - 30.4.6.7.3 [Blood Donations](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010906992528)
    - 30.4.6.7.4 [Bar Examinations](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010906986656)
    - 30.4.6.7.5 [Court Leave](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010906980928)

      - 30.4.6.7.5.1 [Requesting and Evidencing Court Leave](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010906976080)

    - 30.4.6.7.6 [Military Leave](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010902754912)

      - 30.4.6.7.6.1 [Payment of Certain Military Reservists Coverage While in Non-pay Status](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010902749184)

    - 30.4.6.7.7 [Granting Time Off for Voting](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010902737152)

  - 30.4.6.8 [Adjustment of Work Schedules for Religious Observances](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010902732720)
  - 30.4.6.9 [Overtime and Compensatory Time-Off](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010902720608)

    - 30.4.6.9.1 [Overtime Pay under the Fair Labor Standards Act](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010902713744)

      - 30.4.6.9.1.1 [Nonexempt Positions under FLSA](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010902708960)

  - Exhibit 30.4.6-1 [Sample Memorandum: Request for Leave for Maternity/Paternity Reasons](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010902700736)
  - Exhibit 30.4.6-2 [Sample Memorandum: Request for an Adjusted Work Schedule for Religious Observances](https://www.irs.gov/irm/part30/irm_30-004-006#idm140010902642800)

# Part 30. Administrative

# Chapter 4. Personnel Administration, Training, and Equal Employment Opportunity

# Section 6. Leave Administration

* * *

## 30.4.6 Leave Administration

**30.4.6.1** **(05-22-2006)**

### Authority

1. In accordance with 5 U.S.C. Chapter 63 and 5 CFR Part 630, this section establishes the policies and procedures for leave administration within the Office of Chief Counsel and provides information on the Family and Medical Leave Act of 1993, overtime, and compensatory time off.


**30.4.6.2** **(05-22-2006)**

### Annual Leave

1. An employee’s request for annual leave will generally be granted, absent the needs of the Office for the employee’s specific skills or knowledge. An employee is expected to request annual leave as far in advance as possible. Management has the discretion to decide when and in what amount annual leave may be approved.

2. A full-time employee earns annual leave based on their length of Federal service.




| **_Years of Federal service_** | **_Annual leave earned each pay period_** |
| :-- | :-- |
| Less than 3 years | 4 hours |
| More than 3 but less than 15 years | 6 hours |
| 15 or more years | 8 hours |

3. A part-time employee earns annual leave according to the number of hours worked each pay period.




| **_Years of Federal service_** | **_Annual leave earned each pay period_** |
| :-- | :-- |
| Less than 3 years | 1 hour for each 20 hours worked |
| More than 3 but less than 15 years | 1 hour for each 13 hours worked |
| 15 or more years | 1 hour for each 10 hours worked |

4. Employees can carry over to the next leave year a maximum of 240 hours (30 days) of accrued annual leave (720 hours or 90 days for members of the Senior Executive Service). Leave earned in excess of these maximums is forfeited if not used by the end of the leave year. Under special conditions, forfeited annual leave may be restored, see CCDM 30.4.6.2.2.


**30.4.6.2.1** **(05-22-2006)**

#### Advanced Annual Leave

1. An employee has no right to advanced annual leave. However, under unusual circumstances, an employee may be granted advanced annual leave up to the amount the employee is expected to earn by the end of the leave year. Annual leave should not be advanced when it is known or reasonably assured that an employee will separate before the advanced leave will be earned.

2. Each Associate Chief Counsel/Division Counsel (or designee) will determine which management level will approve such leave. An employee should submit a request for advanced annual leave to their first line supervisor. While no specific form is required, the employee’s request should state in detail:



   - The reason(s) why such leave is requested

   - The amount of time requested

   - The specific time period involved

   - Full circumstances about why the employee does not have sufficient leave

   - How the advanced annual leave will be repaid before the end of the leave year


3. While the employee's personal wishes will be considered, the needs of the Office must be given priority in the consideration of granting advanced annual leave.


**30.4.6.2.2** **(03-04-2009)**

#### Restoration of Forfeited Annual Leave

1. At the end of each leave year, employees with an annual leave balance over 240 hours are required to "use or lose" such leave. Annual leave that has been forfeited cannot be restored until it has actually been lost.

2. Authority for approving restoration of forfeited annual leave has been delegated to the Associate Chief Counsel (Finance and Management) for the Associate Chief Counsel offices, and to Division Counsel for field offices.

3. Chief Counsel employees will use Form 9202, Request for Restoration of Annual Leave, to request restoration of forfeited annual leave. All approved request forms must be submitted with the appropriate documentation to Human Resources Division (HR) for processing after the leave year has ended. The employee must submit the restoration request to the supervisor no later than January 31. A request will not be acted upon if it is submitted after the employee has separated from Counsel either through transfer, reassignment, resignation or retirement. HR will notify the employee, supervisor and timekeeper once approval has been obtained so a separate leave account can be established.

4. The leave may be restored to the employee in a separate account under the conditions set forth in the following paragraphs:



   - Administrative error

   - Exigency of public business

   - Sickness of the employee


5. When an **administrative error** caused the loss of annual leave otherwise accruable, any annual leave that was forfeited because of the error may be restored to an employee's account.

6. When annual leave was scheduled in advance, and an **"exigency" of public business occurs**, whether anticipated or unanticipated, annual leave may be restored if it meets the following requirements:



1. Annual leave must be scheduled in writing before the start of the third pay period prior to the end of the leave year (usually mid-November).

2. The determination must be made that the exigency is of such importance that the employee cannot be excused from duty for the duration of the scheduled annual leave.

3. There is no reasonable alternative to the cancellation of the scheduled leave, and it is not generally practical to assign another employee to perform the work.


7. When a period of **sickness** (or injury, or any other medical condition for which sick leave would be approved) interfered with the use of scheduled annual leave, conditions for restoration are as follows:



1. The annual leave was scheduled in writing before the start of the third pay period prior to the end of the leave year.

2. The period of absence due to sickness occurred at such a late time in the leave year or was of such duration that the annual leave could not be rescheduled for use before the end of the leave year to avoid forfeiture.


**30.4.6.2.2.1** **(05-22-2006)**

##### Use of Restored Annual Leave

1. Annual leave restored to a separate leave account must be scheduled and used no later than the end of the leave year ending two years after one of the following:



   - The date annual leave was restored in correcting an administrative error

   - The date fixed by management as the termination of the exigency of public business that resulted in forfeiture of annual leave

   - The date the employee is determined to be recovered and able to return to duty, if leave was forfeited because of sickness


2. Managers and employees must be aware of the time limit and are responsible for making arrangements for the use of restored annual leave as soon as the workload permits.


**30.4.6.2.3** **(05-22-2006)**

#### Sequence of Leave Usage

1. To preclude the employee from losing restored forfeited annual leave, current "use or lose" annual leave, or compensatory time, Treasury has prescribed a sequence for leave usage.

2. Prior to Pay Period 18 of each year, the sequence is:



1. Compensatory time

2. Restored forfeited annual leave that will expire in the current leave year

3. Annual leave that will become use or lose at the end of the current leave year

4. Restored forfeited annual leave that does not expire in the current leave year

5. Annual leave with no use or lose balance for the current leave year


3. After Pay Period 18 of each year, the sequence changes to facilitate the use of all use or lose before forfeiture occurs. The sequence becomes:



1. Annual leave that will forfeit at the end of the leave year

2. Restored forfeited annual leave that will expire at the end of the leave year

3. Compensatory time absent

4. Restored forfeited annual leave that does not expire in the current leave year

5. Annual leave with no use or lose annual leave balance for the current leave year


4. An employee can choose to take credit hours at any given time, but should be reminded that credit hours can be carried forward for an indefinite period of time, but other types of leave are subjected to forfeiture. Therefore other types of leave should be considered first when scheduling time off.


**30.4.6.2.4** **(05-22-2006)**

#### Separating From Federal Service

1. An employee who is separated from the Federal Service is entitled to a lump-sum payment for accumulated and currently accrued annual leave, and a maximum of 24 credit hours for full-time employees (pro-rated for part-time employees).

2. When an employee separates from the Government and is indebted for unearned annual leave and/or sick leave, the employee must refund the amount due or have the amount owed deducted from any monies due. Collection is waived when the separation is because of disability reasons, including a resignation for medical reasons.


**30.4.6.2.4.1** **(05-22-2006)**

##### Granting Annual Leave Prior to Separation

1. The Comptroller General has determined that employees separating from the Federal Service must not be permitted to take annual leave immediately prior to separation, thus permitting the employee to earn additional leave while taking leave, see 34 Comp. Gen. 61 (1954).



### Example:



An employee wishes to resign on September 6 and will have accrued ten days annual leave by that date. The employee cannot resign effective September 20, with the last day in the office being September 6, taking annual leave the next two weeks until September 20. Were the employee to do so, additional annual leave would be accrued during the two weeks on annual leave. Instead, the employee should resign effective September 6 and receive a lump-sum payment for ten days accrued annual leave.

2. Each Associate Chief Counsel/Division Counsel is responsible for ensuring that an employee will not be granted annual leave immediately prior to separation from the Federal Service in any case where it is known in advance that the employee is to be separated from the Service, unless the needs and interests of the Service require the retention of an employee in an annual leave status.


**30.4.6.2.5** **(04-02-2008)**

#### Credit for Non-Federal Service

1. This policy only applies to individuals who meet the definition of "employee" as noted below. The creditable service for non-Federal work experience only applies to the Service Computation Date (SCD) for Annual Leave. The policy does not affect the IRS Career Service Award, the SCD for Retirement, SCD for Thrift Savings Plan, or SCD for Reduction in Force. In addition, Senior Executive Service (SES) and SL employees are not eligible for this program (under SES/SL employment, new hires start under the 8-hour leave category).



1. _**Employee**_ — A person who is covered by the Federal annual and sick leave program established in 5 U.S.C., Chapter 63, and is either receiving a first appointment (regardless of tenure) as a civilian employee of the Federal Government, or is being reappointed following a break in service of at least 90 calendar days after the last period of civilian Federal employment.


2. The Office of Chief Counsel will utilize available personnel flexibilities to recruit and retain a highly skilled professional workforce. When the applicant for a new appointment or a reappointment requires an incentive to accept the offer of employment and the skills of the applicant meet the other criteria outlined in this policy, the hiring official may consider using the authority of the Federal Workforce Flexibility Act of 2004 to credit prior non-Federal or active duty honorable uniformed service experience for the purpose of determining the annual leave accrual rate.



1. **_Uniformed Service_** — The Armed Forces, the Army National Guard, and the Air National Guard when engaged in active duty for training, inactive duty training, or full-time National Guard duty, the commissioned corps of the Public Health Service, and any other category of persons designated by the President in time of war or national emergency.


**30.4.6.2.5.1** **(04-02-2008)**

##### Responsibilities

1. Associate Chief Counsels/Division Counsels are responsible for:



1. Determining when to request use of this authority

2. Developing the justification documentation for each employee to which prior non-Federal or military service is being requested for annual leave accrual

3. Completing the SF 144A, Statement of Prior Creditable Service Worksheet


2. Human Resources Division is responsible for:



1. Reviewing the request to determine whether the prior experience meets the qualifications and directly-related experience requirement

2. Determining the specific amount of time that may be creditable toward the annual leave accrual

3. Forwarding the reviewed documentation to the Associate Chief Counsel (Finance and Management) for approval

4. If approved, processing the accession personnel action to ensure that the approved time creditable for annual leave accrual is granted on the effective date of the initial appointment or reappointment of Federal service


3. The Associate Chief Counsel (Finance and Management) is responsible for:



1. Reviewing the request for regulatory and policy compliance and deciding whether or not to grant credit

2. Informing the Human Resources Division of final decision


**30.4.6.2.5.2** **(04-02-2008)**

##### Requirements for Granting Credit for Non-Federal Service

1. Credit for non-Federal or active duty honorable uniformed service may be granted only when a special incentive is needed to attract the applicant and if it is determined that the skills and experience the applicant possesses are:



   - Essential to the new position and were acquired through performance in a prior position having duties that directly relate to the duties of the position to which he or she is being appointed; **or**

   - Essential to the new position and were acquired through performance in an active duty honorable uniformed service position having duties that directly relate to the duties of the new position; **and**

   - Necessary to achieve an important agency mission or performance goal.


2. A determination must be made that providing the annual leave credit would directly enhance Counsel’s ability to fill a critical position with an extremely capable person.

3. If credit is given for less than full time service, then such credit should be based on the number of hours and the percentage of time the employee performed directly-related duties. The methodology used must be documented.

4. Credit for non-Federal service or active duty honorable uniformed service is granted to the employee on the effective date of his or her initial appointment or reappointment to Federal service. According to 5 CFR 630.205 (d), prior service cannot be granted retroactively or subsequent to the effective date of the employee’s appointment or reappointment.

5. Credit for prior work experience remains creditable for annual leave purposes thereafter, provided the employee completes one full year of continuous service with the Department of Treasury.

6. The one-year of continuous service must be extended by any time spent in a leave without pay (LWOP) status in order to permanently retain the prior service credit for annual leave accrual purposes. Exceptions occur when an employee is placed on LWOP, either to serve on active duty uniformed service or because of a compensable injury, and the employee later returns to work.

7. If an employee separates from Federal service or transfers to another Federal agency before completing one full year of continuous service with the Department of the Treasury, the employee is not entitled to retain any prior service credit.



1. The accrual credit allowed for prior non-Federal service time must be subtracted from the employee’s total creditable service before the employee separates or transfers, and Counsel must establish a new service computation date (SCD-Leave) for leave accrual purposes.

2. Any annual leave accrued or accumulated by an employee as a result of receiving credit for prior service remains with the employee or is paid in a lump-sum payment under 5 CFR 550.1205, if the employee is separating from Federal service or moving into a position to which annual leave cannot be transferred.


**30.4.6.2.5.3** **(04-02-2008)**

##### Documentation for Granting Credit

1. Since implementing guidance issued by the Office of Personnel Management (OPM) requires that service credit must be documented and approved in advance of the applicant’s entry on duty, it is imperative that the justification documentation be developed and forwarded to the Human Resources Division as far in advance of the applicant’s entry on duty as practical to ensure sufficient time for eligibility, policy and regulatory compliance reviews. The supporting document **must** include:



1. A description of the applicable qualifications of the individual and the special need of Counsel that justifies use of the authority

2. Other factors that affect the use of this authority (for example, the nature of the labor market, the demand in the private sector for the knowledge and skills possessed by the individual, significant disparities between Federal and private sector salaries for the knowledge and skills required in the position to be filled, etc.)

3. A description of the directly-related work experience of the applicant during his or her non-Federal or active duty honorable uniformed service, including the specific dates (see paragraph 2, below)


2. Acceptable written documentation may include:



   - Position or Military Occupational Specialty (MOS) descriptions

   - Letters from supervisors or performance evaluations indicating duties and time period(s) the employee performed the duties

   - Resumes

   - Employment or military service records

   - Copies of contracts or agreements

   - Other documentation that is deemed sufficient to verify the service

   - Written self-certification that the employee was not terminated for cause from any of the positions upon which the creditable service was based


3. Upon final approval, the Human Resources Division will code the accession personnel action completing Block 31, SCD-Leave, of the SF 50, Notification of Personnel Action, with correctly calculated SCD and using the remarks code B73 or B74 to explain the added credit.

4. If the request is denied, the Human Resources Division will maintain a separate file of denied requests.

5. The Human Resources Division will maintain the approval and denial documentation for a period of five years. The Department of the Treasury or OPM may conduct periodic reviews of this authority.


**30.4.6.3** **(05-22-2006)**

### Sick Leave

1. Pursuant to 5 CFR § 630.401, approval of sick leave will ordinarily be granted to an employee when the employee:



1. Receives medical, dental, or optical examinations or treatment

2. Is incapacitated for the performance of duties by physical or mental illness, injury, pregnancy or childbirth

3. Provides care for a family member who is incapacitated as the result of physical or mental illness, injury, pregnancy, or childbirth or who receives medical, dental, or optical examination or treatment

4. Makes arrangements necessitated by the death of a family member or attends the funeral of a family member

5. Would, as determined by the health authorities having jurisdiction or by a health care provider, jeopardize the health of others by their presence on the job because of exposure to a communicable disease

6. Must be absent from duty for purposes relating to the employee’s adoption of a child, including appointments with adoption agencies, social workers, and attorneys; court proceedings; required travel; and any other activities necessary to allow the adoption to proceed


2. A full-time employee earns four hours of sick leave each pay period. A part-time employee earns sick leave on a prorated basis, at the rate of one hour for each 20 hours worked.

3. An employee may request annual leave, if available, or leave without pay for a period of illness which cannot be covered by sick leave to an employee’s credit, or advanced to the employee. However, annual leave may not be substituted retroactively for regular sick leave.



### Note:



Annual leave may be substituted retroactively to liquidate an employee’s indebtedness for advance sick leave.

4. Generally, absences of three days or less for which sick leave is requested do not require medical documentation. However, an employee may be required to provide medical documentation or other administratively acceptable evidence for sick leave of more than three consecutive workdays, or for a shorter period when determined necessary. Employees must submit required documentation within a reasonable amount of time after return to duty. Failure to submit required medical documentation may result in the employee’s absence being charged with Absence Without Leave (AWOL) and may result in disciplinary action.


**30.4.6.3.1** **(05-22-2006)**

#### Advanced Sick Leave

1. An employee has no right to be advanced sick leave. However, an employee may be granted advanced sick leave, if he/she has a serious health condition and other conditions are satisfied. Advanced sick leave may be granted subject to the following:



   - A request for more than three workdays must be supported by a medical certificate or other administratively acceptable documentation

   - There must be a reasonable indication that the employee will return to duty after the illness

   - The total amount advanced may not exceed 240 hours (30 work days) at any time


2. Each Associate Chief Counsel/Division Counsel (or designee) will determine which management level will approve such leave.

3. An employee should submit a request for advanced sick leave to their first line supervisor; supporting medical certification **must** be included with the request. While no specific form is required, the employee’s request should state in detail:



   - The reason(s) why such leave is requested

   - The amount of time requested

   - The specific time period involved


4. Instead of requesting advanced sick leave, an employee may charge sick leave to accumulated annual leave when approved by their supervisor.


**30.4.6.4** **(05-22-2006)**

### Leave Without Pay (LWOP)

1. LWOP is _approved_ leave for which an employee is not paid. Except for specified situations such as the Family and Medical Leave Act, an employee is not entitled to LWOP.

2. Each Associate Chief Counsel/Division Counsel (or designee) will determine which management level will approve such leave.

3. An employee should submit a request for LWOP to their first line supervisor. While no specific form is required, the employee’s request should state in detail:



   - The reason(s) why such leave is requested

   - The amount of time requested

   - The specific time period involved

   - To the extent that the reasons are health-related (either for the employee or for someone else), supporting medical certification must be included with the request


**30.4.6.4.1** **(05-22-2006)**

#### Extended LWOP (Three Months to One Year)

1. In rare instances, an employee may request extended LWOP for up to one year when it is determined that the period of absence will benefit the Office. Extended LWOP may be granted to an employee for such purposes as:



   - Obtaining a higher education

   - Pursuing a personal goal or objective

   - Exploring a career change

   - Meeting a family obligation

   - Any other reason which does not conflict with the needs of the Office and which is not ethically prohibited


2. The purpose of the leave of absence does not have to be job related. An employee requesting extended LWOP will normally be required to exhaust all of their annual leave before LWOP may be granted. An employee granted extended LWOP must agree in writing to extend their tenure with the Office for a period of one year (or the amount of the LWOP period) following completion of the LWOP. See CCDM 30.4.6.6 regarding the Family and Medical Leave Act (FMLA) for certain health or family related issues.

3. Extended LWOP for the purposes cited in paragraph (1) may be granted to an employee:



1. Only once in a five-year period

2. Upon completion of five years’ service in a permanent position in the Office of Chief Counsel

3. If the employee’s performance is Fully Successful or better


4. An employee is excluded from extended LWOP if he/she is:



   - Occupying a time limited appointment

   - A newly appointed supervisor or manager who is serving a supervisory/managerial probationary period

   - Eligible for voluntary retirement with an immediate annuity prior to or during the LWOP period


**30.4.6.5** **(05-22-2006)**

### Absence Without Leave (AWOL)

1. AWOL is a non-pay status charged to an employee for an absence from duty which is not authorized or for which a request for leave is denied. No advance warning is required before AWOL is charged. Disciplinary action or adverse action may be taken for unauthorized absences.


**30.4.6.6** **(12-13-2006)**

### Family and Medical Leave Act (FMLA) of 1993

1. The Family and Medical Leave Act (FMLA) allows an employee to take leave for certain health or family related issues. Under FMLA, an employee is entitled to a total of 12 administrative workweeks of unpaid leave during any 12-month period for the following:



1. The birth of a son or daughter of the employee and the care of such son or daughter

2. The placement of a son or daughter with the employee for adoption or foster care

3. The care of a spouse, son, daughter, or parent who has a serious health condition

4. A serious health condition of the employee that makes the employee unable to perform the duties of their position


2. In order for an employee to receive leave under FMLA, he/she must submit Form 9611, Application For Leave Under the Family and Medical Leave Act, and Form WH-380, U.S. Department of Labor Certification of Health Care Provider . The application forms must be submitted to the employee’s first line supervisor generally not less than 30 days before leave is to begin or, in emergencies, as soon as is practical. Each Associate Chief Counsel/Division Counsel will determine which management level will approve such leave.

3. The basic entitlement under FMLA is for LWOP. An employee may choose to substitute paid leave for all or part of the 12 weeks for FMLA. An employee may substitute annual leave, compensatory time, or credit hours without restrictions. However, in order for an employee to use sick leave for FMLA-related purposes, their sick leave must be appropriate under the regular rules for using sick leave (e.g., illness of the employee, etc.). _See_ CCDM 30.4.6.3, Sick Leave.

4. FMLA is administered under 5 CFR § 630.1201 et seq. Managers should contact the Labor and Employee Relations Division for guidance when a request for leave under FMLA is received.


**30.4.6.7** **(05-22-2006)**

### Other Types of Leave

1. This subsection addresses leave for maternity and paternity reasons; organ, bone marrow and blood donation; bar examinations; court proceedings; and military duties.


**30.4.6.7.1** **(05-22-2006)**

#### Absence for Maternity/Paternity Reasons

1. In addition to entitlement under the Family and Medical Leave Act, as stated in CCDM 30.4.6.6, the Office generally considers a period of six months adequate time for maternity and paternity leave. The length of absence will be determined by the employee, the physician, and the employee’s supervisor.

2. Sick leave for maternity reasons may be used when an employee is incapacitated due to pregnancy and for time to deliver and care for a newborn child. Sick leave for paternity reasons may be used to care for a newborn child. Annual leave, leave without pay, compensatory time, or credit hours may also be used to cover the absence for maternity and paternity leave. The employee may determine in what order their leave will be taken.

3. The employee is responsible for notifying their supervisor of the intent to request leave for maternity/paternity reasons, including the type of leave, approximate dates, and anticipated duration. The employee must submit a request for leave for maternity/paternity reasons to their first line supervisor for appropriate approval(s); _See Exhibit 30.4.6-1._.

4. An employee planning to return to work can expect continued employment in the same position or one of like seniority, status, and pay, unless separation is warranted for other reasons unrelated to the maternity/paternity absence, such as expiration of appointment, for cause, or reduction-in-force. An employee not planning to return to work should submit a letter of resignation at the end of the period of incapacitation. The employee may be separated at an earlier date for reasons unrelated to the maternity/paternity absence.


**30.4.6.7.2** **(05-22-2006)**

#### Organ and Bone Marrow Donation

1. An employee is entitled to 30 days of paid leave each calendar year to serve as an organ donor and seven days of paid leave each calendar year to serve as a bone marrow donor.

2. Leave for organ or bone marrow donation is in addition to any annual leave or sick leave that may be requested and approved for these purposes.


**30.4.6.7.3** **(05-22-2006)**

#### Blood Donations

1. If permission to donate blood is granted by the supervisor, an employee is entitled to four hours of excused absence without charge to leave. The four hours of excused absence shall be granted only on the date that blood is donated and are in addition to the time required to travel to and from the blood center, and to actually give blood.

2. The purpose of this leave is to provide a reasonable time for the employee to recuperate after donating blood. An employee is entitled to, and encouraged to take, the full four hours of excused absence.

3. If the employee is not accepted for blood donation, only the time necessary for the trip to and from the blood center, and the time required by the center to make the determination, is allowed as excused absence.


**30.4.6.7.4** **(05-22-2006)**

#### Bar Examinations

1. If an employee is not already admitted to the bar, administrative leave will be approved, for the taking of one bar examination and for one local bar admission ceremony.

2. While no administrative leave is to be granted for attending bar review courses or studying for the bar examination, work hours may be adjusted where practical. Also, advanced annual leave or leave without pay may be granted as prescribed by leave policy.

3. Requests for administrative leave pursuant to this section are handled in accordance with regular leave procedures in each Associate Chief Counsel/Division Counsel office.


**30.4.6.7.5** **(05-22-2006)**

#### Court Leave

1. An employee is entitled to court leave, without charge to annual leave or loss of pay, for absence from work when summoned to a judicial proceeding by the responsible court of authority to serve as a juror or as a witness on behalf of any party in connection with any judicial proceeding to which the United States, the District of Columbia, or a State or local government is a party.

2. Court leave for witness service is permissible only if the employee is summoned by the court or authority responsible for the proceeding. Although a subpoena is not necessarily required, the official request, invitation, or call must be evidenced in writing.


**30.4.6.7.5.1** **(05-22-2006)**

##### Requesting and Evidencing Court Leave

1. When called for service which qualifies for court leave, either as a juror or as a witness, the employee must advise their supervisor and submit a copy of the court order, subpoena, summons, or other written request as far in advance as possible.

2. Upon return to duty, the employee must submit written evidence of attendance at the judicial proceeding, showing the dates (and hours if possible) served. These statements, which generally may be secured from the Clerk of the Court or other court official, should include information about any money received, such as the jury or witness fees and rate thereof, or any amounts received for meals and transportation. The statements will be forwarded to the timekeeper.

3. An employee summoned for jury duty will be granted leave for the entire period, from the date stated in the summons on which he/she is required to report to the court, to the time he/she is discharged by the court. However, if an employee is excused or released by the court for any day or a substantial portion of a day, he/she is expected to return to duty, unless the return would cause the employee hardship because of the distances between home, duty office, and the court. Failure to return to duty, when it is reasonable for the employee to do so, may result in a charge to annual leave, LWOP, or AWOL. The supervisor is responsible for instructing the employee before he/she begins court leave as to when and under what conditions he/she will be expected to return to duty during a temporary release from court service.

4. An employee may not retain fees received for jury or witness service if he/she served while in official duty status or on court leave. However, the fees may be retained in the following circumstances:



1. If the jury fee is greater than the amount of regular salary due, the employee may retain the difference.

2. If the jury service falls on a non-workday or on a holiday falling within the employee's regular tour of duty, he/she may retain the fee for that day.

3. If the employee is on LWOP when called for jury or witness service, he/she may retain the fees.

4. If the applicable state or local law provides that payments for jury services are for travel and/or related expenses (rather than a salary for being a juror), employees may retain such payments. If there is any question about whether any such payments may be retained, employees should consult the Human Resources Division.

5. The employee may retain allowance for mileage and subsistence.


5. The employee should collect and turn in the fees, together with a copy of the court statement and a memorandum giving their name, social security number, office code, and the dates of attendance in court to his or her Administrative Officer/Office Manager.


**30.4.6.7.6** **(05-22-2006)**

#### Military Leave

1. Military leave is the authorized absence of an employee from official duty to perform active or inactive military duty in the National Guard or as a Reserve of the Armed Forces. This provision is for full-time employees whose appointment is not limited to one year and is prorated for part-time employees.

2. Full-time employees working 40-hour workweeks will accrue 120 hours (15 days X 8 hours) of military leave in a fiscal year, or the equivalent of three 40-hour work weeks. Part-time employees will accrue military leave proportionate to the number of hours in their regularly scheduled bi-weekly pay period.

3. Employees may choose not to take military leave and instead take annual leave in order to retain both civilian and military pay.


**30.4.6.7.6.1** **(05-22-2006)**

##### Payment of Certain Military Reservists Coverage While in Non-pay Status

1. Effective September 11, 2001, the Office of Chief Counsel will pay Federal Employee Health Benefit (FEHB) premiums for certain military reservists. The Office will pay up to 24 months of health benefit premiums provided for in the authority for eligible employees called to active duty on or after September 14, 2001. Payment will be made for employee and government portions of the FEHB premiums and any additional administrative expenses for employees who are:



   - Enrolled in an FEHB plan and elect to continue enrollment

   - Members of a reserve component of the armed forces

   - Called or ordered to duty (voluntarily or involuntarily) in support of a "contingency operation," as defined in 10 U.S.C. § 101(a)(13)

   - Placed on leave without pay or separated from civilian service to perform active military duty

   - Serve on active military duty for more than 30 consecutive days


2. The employee must provide proof of qualifying service by providing a copy of written orders, which specify that he or she has been called to active duty in support of a contingency operation. Examples of acceptable written orders include:



   - Listing the statutory authority of the orders as 10 U.S.C. §§ 12301(a), 12302, or 12304

   - The orders state that the duty is in support of one of the named contingency/operations and the statutory authority is a provision of 10 U.S.C.


**30.4.6.7.7** **(05-22-2006)**

#### Granting Time Off for Voting

1. When the voting polls are not open at least three hours either before or after an employee‘s regular hours of work, management may grant an amount of administrative leave to vote which will allow an employee to report to work either three hours after the polls open, or leave work three hours before the polls close, whichever requires the lesser amount of time.


**30.4.6.8** **(05-22-2006)**

### Adjustment of Work Schedules for Religious Observances

1. An employee may work compensatory overtime for the purpose of taking time off without charge to leave when personal religious beliefs require that the employee abstain from work during certain periods of the workday or workweek. Normally, the religious compensatory time will be worked in advance of the time off. In all cases, religious compensatory time shall be completed within 120 days before or after the granting of the compensatory time off.

2. An employee requesting an adjusted work schedule for religious observances must submit a "Request for an Adjusted Work Schedule for Religious Observances" to their supervisor for appropriate approval(s). _See Exhibit 30.4.6-2_. An employee’s request for compensatory overtime work must specify the precise days and hours during which such work will occur. The employee’s request should be submitted 15 days prior to the period for which the employee's religious beliefs will require the employee to abstain from work.

3. When deciding whether an employee’s request for an adjusted work schedule should be approved, a supervisor should not make any judgment about the employee’s religious beliefs or their affiliation with a religious organization. The only requirements are that the employee's personal beliefs be of a religious nature, and that the employee's personal beliefs require the abstention from work during the period the employee is requesting time off. To the extent that such modifications in work schedules do not interfere with the efficient accomplishment of the mission of the Office, the employee shall be granted compensatory time off. A supervisor may, however, disapprove an employee’s request if modifications of an employee’s work schedule would interfere with the efficient accomplishment of the Office’s mission.

4. Religious compensatory time is not suitable for those situations where an employee's personal religious beliefs require a deviation in normal working hours because of a recurring weekly religious observance (e.g., the necessity of leaving work early on Friday to be home before sundown). Such situations are more properly handled under established procedures for flextime.

5. Religious compensatory time off may be credited and taken in 15-minute increments. Employees must request and receive approval for the earning of religious compensatory time in advance. Religious compensatory time must be used within one year from the date it is earned.


**30.4.6.9** **(12-13-2006)**

### Overtime and Compensatory Time-Off

1. Overtime duty, whether on a paid or compensatory time off basis, shall be approved only when necessary to accomplish work that cannot be deferred, to eliminate backlogs, or to prevent foreseeable emergency work situations.

2. Official authorization or approval of overtime, whether paid, compensatory or holiday, is to be reported in advance on Form 2787, Authorization and Report of Overtime Worked. Form 2787 must be prepared for each covered pay period for which overtime or compensatory time is authorized.

3. In emergency situations, approved overtime which is worked on the last Friday night or Saturday of a pay period must be annotated on a separate Form 2787 or added to an already approved Form 2787 for that respective pay period. Also, this overtime must be recorded on the time and attendance roster and then reported to the centralized timekeeper in your area no later than 1:00 p.m. on the following Monday; otherwise an amended T/A Roster will be submitted by the centralized timekeeper for processing.

4. The Associate Chief Counsel of each respective area is authorized to control, order and approve the performance of overtime duty for employees under their jurisdiction. This authority may be redelegated no lower than a Branch Chief's supervision and control.

5. In field offices, Division Counsel are authorized to order or approve the performance of overtime duty for employees under their jurisdiction and may, as appropriate, redelegate this authority to lower-level managers. A copy of all authorizations for overtime shall be retained by each Division Counsel.


**30.4.6.9.1** **(05-22-2006)**

#### Overtime Pay under the Fair Labor Standards Act

1. The Fair Labor Standards Act (FLSA) provides for minimum standards for both wages and overtime entitlement, and spells out administrative procedures by which covered work time must be compensated. In addition, FLSA exempts specified employees or groups of employees from the application of certain of its provisions. Some of the key concepts of the act, as they apply to the Office of Chief Counsel, are summarized below.

2. An employee occupying an exempt position (which includes all attorneys) is not subject to the overtime provisions of the act.


**30.4.6.9.1.1** **(05-22-2006)**

##### Nonexempt Positions under FLSA

1. An employee occupying a nonexempt position (generally support staff employees) is subject to the overtime provisions of the Act for hours actually worked in excess of 40 per week.

2. An employee occupying a nonexempt position is entitled to overtime compensation for all work which management "suffers or permits" to be performed. Thus, any work performed for the benefit of the Office, whether requested or not, by an employee covered by the overtime provision of the act is work performed on an overtime basis if the supervisor knows or has reason to believe it is being performed. This includes work performed prior to or after the established shift hours, or during the prescribed lunch period.

3. The Act provides that an employee can seek relief directly from the courts for overtime work performed for which an employee believes he/she has not been properly compensated.

4. The Act does not in any way diminish a supervisor's responsibility for ordering or authorizing overtime work. It simply adds an additional supervisory responsibility, i.e., to see to it that overtime work is not, in fact, performed except when payment for such overtime is intended.

5. Supervisors must keep accurate records concerning the hours worked by their nonexempt employees.


**Exhibit 30.4.6-1** **(12-13-2006)**

### Sample Memorandum: Request for Leave for Maternity/Paternity Reasons

| **date:** |  |  |
| --: | :-- | :-- |
| **to:** | Associate Chief Counsel/Division Counsel |
| **thru:** | Supervisor |
| **from:** | Employee |
| **subject:** | Request for Leave for Maternity/Paternity Reasons |
|  | I hereby request \_\_\_\_\_\_\_\_ hours (annual leave/sick leave/advance annual leave/advance sick leave/leave without pay) for maternity/paternity reasons. The leave will begin on or about \_\_\_\_\_\_\_\_\_\_\_ (date) and will extend through \_\_\_\_\_\_\_\_\_\_\_ (date), or thereabouts. |
|  | I will use my accumulated sick and/or annual leave during this absence. I will also keep my timekeeper advised of my status. |
|  |  |
|  |  |  |
|  |  |  |
|  |  | Employee’s Signature |
|  |  |
|  |
|  | Approved/Disapproved |  |
|  |  |  |
|  | \\_\\_\\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |
|  | Associate Chief Counsel/Division Counsel (Signature) |

**Exhibit 30.4.6-2** **(12-13-2006)**

### Sample Memorandum: Request for an Adjusted Work Schedule for Religious Observances

| **date:** |  |  |
| --: | :-- | :-- |
| **to:** | Associate Chief Counsel/Division Counsel |
| **thru:** | Supervisor |
| **from:** | Employee |
| **subject:** | Request for an Adjusted Work Schedule for Religious Observances |
|  | I request that I be granted \_\_\_\_\_\_\_\_ hours compensatory time off on \_\_\_\_\_\_\_\_\_\_\_ (date) for the following religious observance because my personal religious beliefs require me to abstain from work during this period: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ (for example, Good Friday). I further request that I be authorized to perform \_\_\_\_\_\_\_\_ hours compensatory overtime work on \_\_\_\_\_\_\_\_\_\_\_ (date). |
|  |  |
|  |  |  |
|  |  |  |
|  |  | Employee’s Signature |
|  |  |
|  |
|  |  |
|  | Approved \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |
|  | Associate Chief Counsel/Division Counsel (Signature) |
|  |  |  |
|  |  |  |
|  | The foregoing request is approved, and I certify that work is available for this employee during the time requested for compensatory overtime, and if no supervision is available, that he/she is capable of working independently. |
|  | The foregoing request for compensatory time off is approved. Compensatory overtime will be worked on \_\_\_\_\_\_\_\_\_\_\_ (date). |

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part30/irm_30-004-006#addtoany "Show all")

A2A