---
url: "https://www.irs.gov/irm/part36/irm_36-002-001"
title: "36.2.1 Appeal Recommendations in General | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part36/irm_36-002-001#main-content)

- 36.2.1 [Appeal Recommendations in General](https://www.irs.gov/irm/part36/irm_36-002-001#idm140076812277968)
  - 36.2.1.1 [Preparation of Appeal Letters](https://www.irs.gov/irm/part36/irm_36-002-001#idm140076797386048)

    - 36.2.1.1.1 [Nature and Contents](https://www.irs.gov/irm/part36/irm_36-002-001#idm140076812111968)
    - 36.2.1.1.2 [Format](https://www.irs.gov/irm/part36/irm_36-002-001#idm140076812108768)
    - 36.2.1.1.3 [Specific Recommendations](https://www.irs.gov/irm/part36/irm_36-002-001#idm140076812089392)
    - 36.2.1.1.4 [Signatures](https://www.irs.gov/irm/part36/irm_36-002-001#idm140076812085072)
    - 36.2.1.1.5 [Transmittal of Appeal Letter](https://www.irs.gov/irm/part36/irm_36-002-001#idm140076812193104)

      - 36.2.1.1.5.1 [District Court](https://www.irs.gov/irm/part36/irm_36-002-001#idm140076812190176)
      - 36.2.1.1.5.2 [State Court](https://www.irs.gov/irm/part36/irm_36-002-001#idm140076812186912)
      - 36.2.1.1.5.3 [Criminal Cases](https://www.irs.gov/irm/part36/irm_36-002-001#idm140076812182352)
      - 36.2.1.1.5.4 [Court of Federal Claims](https://www.irs.gov/irm/part36/irm_36-002-001#idm140076812173488)
      - 36.2.1.1.5.5 [Bankruptcy Court Cases](https://www.irs.gov/irm/part36/irm_36-002-001#idm140076812169456)

        - 36.2.1.1.5.5.1 [Procedures for Adverse Decision](https://www.irs.gov/irm/part36/irm_36-002-001#idm140076812166480)
        - 36.2.1.1.5.5.2 [Direct Appeal to Court of Appeals](https://www.irs.gov/irm/part36/irm_36-002-001#idm140076812147424)

  - 36.2.1.2 [Court of Appeals Cases](https://www.irs.gov/irm/part36/irm_36-002-001#idm140076797364672)

    - 36.2.1.2.1 [Federal Rules of Appellate Procedure](https://www.irs.gov/irm/part36/irm_36-002-001#idm140076797362912)
    - 36.2.1.2.2 [Governments Petition for Rehearing or Rehearing En Banc](https://www.irs.gov/irm/part36/irm_36-002-001#idm140076797353744)

      - 36.2.1.2.2.1 [Standards for Petitions for Rehearing in the Courts of Appeals](https://www.irs.gov/irm/part36/irm_36-002-001#idm140076797343584)
      - 36.2.1.2.2.2 [Standards for Petitions for Rehearing En Banc](https://www.irs.gov/irm/part36/irm_36-002-001#idm140076797337872)

    - 36.2.1.2.3 [Associate Chief Counsel Attorney Responsibilities in Rehearing En Banc Cases](https://www.irs.gov/irm/part36/irm_36-002-001#idm140076797331792)

      - 36.2.1.2.3.1 [Initial Responsibilities Rehearing En Banc Cases](https://www.irs.gov/irm/part36/irm_36-002-001#idm140076797328832)
      - 36.2.1.2.3.2 [Documents and Files](https://www.irs.gov/irm/part36/irm_36-002-001#idm140076797324896)
      - 36.2.1.2.3.3 [Coordination within Chief Counsel](https://www.irs.gov/irm/part36/irm_36-002-001#idm140076797321664)
      - 36.2.1.2.3.4 [Information Memorandum Rehearing En Banc Cases](https://www.irs.gov/irm/part36/irm_36-002-001#idm140076797318272)
      - 36.2.1.2.3.5 [Action Documents](https://www.irs.gov/irm/part36/irm_36-002-001#idm140076797301296)
      - 36.2.1.2.3.6 [Letter to Department of Justice Rehearing En Banc Recommendation](https://www.irs.gov/irm/part36/irm_36-002-001#idm140076797285664)

# Part 36. Appellate Litigation and Actions on Decision

# Chapter 2. Appeal/Certiorari Recommendations

# Section 1. Appeal Recommendations in General

* * *

## 36.2.1 Appeal Recommendations in General

#### Manual Transmittal

March 27, 2012

#### Purpose

(1) This transmits revised CCDM 36.2.1, Appeal/Certiorari Recommendations; Appeal Recommendations in General.

#### Background

This section was revised to provide procedures for recommending the filing of a petition for rehearing or rehearing en banc from an adverse decision of a court of appeals.

#### Material Changes

(1) CCDM 36.2.1.2.2 was revised to more clearly set forth the initial actions to be taken when an adverse decision of a court of appeals is issued.

(2) CCDM 36.2.1.2.2.1 was revised to more fully set forth the standards for petitions for rehearing in the court of appeals.

(3) CCDM 36.2.1.2.2.2 was revised to more fully set forth the standards for petitions for rehearing en banc in the court of appeals.

(4) CCDM 36.2.1.2.3 et seq. was added to set forth Associate Chief Counsel responsibilities in rehearing en banc cases.

#### Effect on Other Documents

CCDM 36.2.1, dated November 14, 2006, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(03-27-2012)

Deborah A. Butler

Associate Chief Counsel

(Procedure & Administration)

**36.2.1.1** **(08-11-2004)**

### Preparation of Appeal Letters

1. An objective evaluation of whether to recommend appeal is imperative. The Office of Chief Counsel must balance a variety of considerations in deciding whether to recommend appeal. Appeals often take many months, and the results are often unpredictable. An error of fact, law or analysis, standing alone, does not necessarily merit an appeal recommendation. The Office of Chief Counsel should recommend appeal only as part of an overall strategy to support Service position and sound tax administration.

2. The legal correctness or incorrectness of the lower court decision is the primary basis for determining whether to recommend appeal. Attorneys should carefully consider the opinion of the lower court with an open mind. If persuaded by the court's rationale, the attorney should recommend acquiescence or other change in Service position.

3. Consider the administrative importance, whether national or local, and include a discussion in the appeal letter. Administrative considerations may include the potential revenue impact of the adverse decision, and the number of taxpayers the decision may affect. The Service may have information that will assist with this factor.

4. Consider the record on appeal, e.g., is the Government's position set out clearly and supported by competent testimony and documentary evidence, was the correct argument made?

5. Weigh the equities of the case. Cases involving taxpayers who appear in a sympathetic light or where the Service's actions are called into question may not present the best vehicles for obtaining favorable precedent on important legal issues.

6. Consider whether the Government will derive any pecuniary benefit if the adverse decision is reversed. For example, in a bankruptcy case, consider whether the Government can expect to be paid given the financial condition of the bankruptcy estate. Even if the Government may derive no pecuniary benefit, consider whether the decision will adversely affect collection in other cases. A case involving no pecuniary benefit to the Government rarely will be appealed.

7. In collection cases, consider whether there are other sources of collection that may be available apart from the source of collection precluded by the adverse decision.


**36.2.1.1.1** **(08-11-2004)**

#### Nature and Contents

1. The nature and contents of an appeal letter depend upon whether the issues are of a legal or factual nature and the court making the decision. An appeal letter must always be written in light of the standard of review applicable to the case and should be focused on the issues relevant to the appeal.


**36.2.1.1.2** **(08-11-2004)**

#### Format

1. The following format should be followed when drafting an appeal recommendation.

2. **Opening Paragraph** — the opening paragraph should include the following information:



   - The court from which an appeal is being considered

   - The time period for filing an appeal

   - A brief statement of the lower court's ruling on the issues decided and being considered for appeal

   - A statement as to whether or not the Office of Chief Counsel recommends appeal


3. **Issues** — the issues under consideration for appeal as appropriate.

4. **Background** — relevant factual background and procedural history of the case, as well as the court's holdings and rationale on each issue.

5. **Discussion** — a discussion of all of the legal arguments relevant to the recommendation for appeal, the positions taken by the Service in the lower court(s), and the views of the Office of Chief Counsel. The letter should also include a discussion of all policy considerations relevant to the decision and the probable effects on Service operations if the Government does not appeal. Generally, although not invariably, the discussion should begin with relevant statutory authority and relevant regulations before moving to discussions of applicable case law.

6. **Conclusion** — this may contain a concise summary of the major points supporting the recommendation and must contain a specific statement regarding the action recommended in the case.

7. **Legal Citation** — the legal citation guide for appeal recommendations is the current edition of _A Uniform System of Citation_, published by the Harvard Law Review Association.



### Note:



In appeal recommendations in Tax Court cases, refer to the taxpayer as taxpayer instead of petitioner to avoid confusion because the taxpayer may be referred to as the respondent in the appellate court.


**36.2.1.1.3** **(08-11-2004)**

#### Specific Recommendations

1. The letter should include a recommendation for or against appeal, or a qualified recommendation, such as cross-appeal if the other side appeals.

2. If an action on decision has been prepared or will be prepared that recommends acquiescence on an issue related to the issue on appeal, the letter should state that the Service will not make a determination on whether or not to acquiesce on the related issue until the conclusion of the appellate proceedings. Actions on decision are the subject of CCDM 36.3.1..


**36.2.1.1.4** **(08-11-2004)**

#### Signatures

1. Appeal letters to the Department of Justice are generally signed at the Associate Chief Counsel level. However, depending on the issue involved and level of coordination the Chief Counsel (or delegate) could retain signature authority.

2. The following documents should be prepared for signature by the Associate Chief Counsel, for the Chief Counsel, unless otherwise determined:



   - All letters recommending appeal

   - All letters recommending certiorari

   - All letters recommending rehearing or rehearing en banc

   - Letters recommending that the Department of Justice confess error or defend the case on alternative grounds

   - Letters recommending no appeal, except letters recommending no appeal in _non-significant_ cases, may be signed by the appropriate Assistant Chief Counsel, Deputy Assistant Chief Counsel, or branch chief, depending upon the procedures followed by the particular office

   - Letters recommending no certiorari, except letters recommending no certiorari in _routine_ no certiorari cases may be signed by the appropriate Assistant Chief Counsel, Deputy Assistant Chief Counsel, or branch chief, depending upon the procedures followed by the particular office

   - Recommendations regarding settlement, unless there is a significant tax administration issue at stake


3. In appeal and certiorari matters the Associate Chief Counsel should bring to the attention of the Chief Counsel all no appeal and no certiorari recommendations in significant cases.

4. Matters involving cases previously brought to the attention of the Chief Counsel or Deputy Chief Counsel through a briefing or prior appeal recommendation should be brought to the attention of the Associate before a recommendation is forwarded. The Associate may advise the Deputy Chief Counsel or Chief Counsel of the matter.

5. For appeals from state court decisions, see CCDM 36.2.1.1.5.2, State Court.

6. For appeals from bankruptcy court decisions, see CCDM 36.2.1.1.5.5, Bankruptcy Court Cases.

7. Exhibit 36.4.1–1, Sample Letter Recommending Appeal, contains a sample appeal recommendation.


**36.2.1.1.5** **(08-11-2004)**

#### Transmittal of Appeal Letter

1. Send appeal recommendations to the attention of the Appellate Section of the Tax Division of the Department of Justice. Send a copy to the appropriate Civil Trial Section of the Tax Division, Division Counsel, and Area Counsel.

2. Appeal recommendations in Tax Court cases have a 60-day deadline from the date of entry of the decision. Appeal recommendations in other cases have a 30-day deadline unless otherwise agreed to by the Office of Chief Counsel and the Appellate Section in a particular case. See CCDM 36.2.5., Appeals of Tax Court Cases.


**36.2.1.1.5.1** **(08-11-2004)**

##### District Court

1. In appeals to United States Courts of Appeals including bankruptcy cases, the recommendation of Division Counsel, if any, should be received by the appropriate Associate Chief Counsel office no less than 10 days after notification of the adverse decision.


**36.2.1.1.5.2** **(08-11-2004)**

##### State Court

1. In state court proceedings where the time for appeal is 30 days or more, the recommendation of Division Counsel, if any, should be received by Collection, Bankruptcy & Summonses (CBS) no less than 10 days after entry of the adverse decision. If the period for appeal is less than 30 days, the Division Counsel attorney should inform the appropriate CBS branch chief of that fact by telephone so that steps can be taken to protect the appeal period and a recommendation made to the Department of Justice within sufficient time to allow the Department to take action before the expiration of the time for appeal.


**36.2.1.1.5.3** **(08-11-2004)**

##### Criminal Cases

1. Pursuant to 18 U.S.C. § 3731 where one or more counts of an indictment or information have been dismissed, the Government may appeal within 30 days, unless the double jeopardy clause of the United States Constitution prohibits further prosecution. Similarly, this section provides for an appeal by the Government, within 30 days in specified situations where a district court has suppressed or excluded evidence or has required the return of seized property.

2. Pursuant to 18 U.S.C. § 3742, the Government may file a notice of appeal in the district court for review of an otherwise final sentence if the sentence:



   - Was imposed in violation of law

   - Was imposed as a result of an incorrect application of the sentencing guidelines

   - Is less that the sentence specified in the applicable guideline range to the extent that the sentence includes a lesser fine or term of imprisonment, probation or supervised release than the minimum established in the guideline range, or includes a less limiting condition of probation or supervised release under section 3503(b)(6) or (b)(11) than the minimum established in the guideline range

   - Was imposed for an offense for which there is no sentencing guideline and is plainly unreasonable


**36.2.1.1.5.4** **(08-11-2004)**

##### Court of Federal Claims

1. In the Court of Federal Claims, all cases are either tried to the court or submitted on a stipulation of facts.

2. Review of decisions by the Court of Federal Claims is by appeal to the United States Court of Appeals for the Federal Circuit.


**36.2.1.1.5.5** **(11-14-2006)**

##### Bankruptcy Court Cases

1. This subsection discusses appeals in Bankruptcy Court cases. See also CCDM 34.11.1 , The SAUSA Program.


**36.2.1.1.5.5.1** **(11-14-2006)**

###### Procedures for Adverse Decision

1. **Appeal to Bankruptcy Appellate Panel or District Court**. Under Fed. R. Bankr. P. 8002, a notice of appeal must be filed within 10 days of the entry of the judgment or order being appealed to the bankruptcy appellate panel (BAP) or to the district court. In view of the extremely short period for filing a notice of appeal, the Area Counsel attorney will contact by telephone the Chief of the respective Civil Trial Section immediately after receipt of an adverse bankruptcy court decision.

2. For information on Direct Appeal to Court of Appeals, see CCDM 36.2.1.1.5.5.2.

3. **Protective Notice**. The Area Counsel attorney should take necessary precautions to ensure that the filing date of the appeal is observed and protected by appropriate orders of the court. If necessary, contact the U.S. Attorney for purposes of filing for an extension of time or filing a protective notice of appeal. Clear such action by telephone with the Tax Division, as is appropriate.



1. If the case was assigned to a SAUSA, the SAUSA will provide his or her recommendation concerning appeal and obtain the Chief’s determination as to whether an appeal is to be filed and who is to file it. If the Chief decides that the SAUSA is to file the appeal, the SAUSA will immediately prepare and file a notice of appeal. If for any reasons the SAUSA is unable to obtain a timely determination by the Chief, the SAUSA is responsible for timely filing a protective notice of appeal. As soon as possible after filing a notice of appeal, the SAUSA will transfer the case to the Tax Division by memorandum stating the SAUSA’s views as to appeal.


4. **Letters to Tax Division**. Whenever a bankruptcy judge renders a decision that is adverse to the Government, the Department of Justice may request the Chief Counsel’s recommendation as to the advisability of filing and prosecuting an appeal.



1. After learning of an adverse decision, the Area Counsel attorney will immediately consider the decision and, if requested, prepare a letter on Division Counsel stationery addressed to the Assistant Attorney General, Tax Division, Department of Justice. See CCDM 36.2.1.1 through CCDM 36.2.1.1.4, for procedures for preparing appeal recommendations.

2. The letter will recommend for or against appeal and _will be signed on behalf of the Chief Counsel_ in the name of the Area Counsel.

3. If the suit authorization or defense letter was prereviewed by Collection, Bankruptcy & Summonses (CBS), any appeal of the issue shall also be prereviewed by CBS. Since time is of the essence, the proposed letter should reach CBS not more than seven calendar days from the date the adverse order is entered.

4. Copies of any letters that are coordinated with CBS should be sent to the appropriate Division Counsel Headquarters.


5. **Appeal by Opposing Party**. Immediately after notification that an opposing party has appealed a bankruptcy court decision that is the favorable to the Government, the Area Counsel attorney will transfer the case by memorandum to the Tax Division.


**36.2.1.1.5.5.2** **(11-14-2006)**

###### Direct Appeal to Court of Appeals

1. **Direct Appeal in General**. Under certain circumstances, an appeal from an adverse bankruptcy court decision may be made directly to a court of appeals if certification is made that a basis for direct appeal exists and the court of appeals authorizes direct appeal. 28 U.S.C. § 158(d)(2). Direct appeals are only authorized in bankruptcy cases commenced on or after October 17, 2005. Bankruptcy Abuse Prevention and Consumer Protection Act of 2005 (BAPCPA), Pub. L. 109-8, 119 Stat. 23. Direct appeal eliminates review by the district court or the BAP. Interim Rules 8001(f) and 8003(d) have been adopted to implement the direct appeal provisions. Three grounds for direct appeal are specified in the statute. The required certification may be made by the bankruptcy court, district court, or BAP acting on its own motion or on the request of a party. Interim Rule 8001(f)(2) provides that only the court in which the matter is "pending" may make the certification. A matter is "pending" in the district court or the BAP after an appeal of a final judgment, order, or decree has been docketed in accordance with Fed. R. Bankr. P. 8007(b) or after leave to appeal an interlocutory judgment, order, or decree has been granted. The matter is otherwise pending in the bankruptcy court.

2. **Standards for Direct Appeals**. Recommendations for direct appeal should be made by the Office of Chief Counsel only in rare and unusual circumstances and only with the approval of the Division Counsel (SB/SE) and the Associate Chief Counsel (Procedure & Administration). The Solicitor General will decide whether to authorize a direct appeal. If a direct appeal is pursued, a notice of appeal must be filed within 10 days of the entry of the judgment or order being appealed pursuant to Fed. R. Bankr. P. 8002(a). A notice of appeal is necessary because the court of appeals has discretion not to authorize a direct appeal, leaving appeal to the BAP or the district court as the only means to obtain judicial review of an adverse bankruptcy decision. In jurisdictions that have adopted the Interim Rules, a notice of appeal must be filed within the 10-day period as a prerequisite to direct appeal certification. Interim Rule 8001(f)(1).

3. **Filing Notice of Appeal**. The procedures outlined in CCDM 36.2.1.1.5.5.1(3) should be followed to ensure that a notice of appeal is timely filed when pursuing a direct appeal recommendation. Both a referral for direct appeal following the procedures below in CCDM 36.2.1.1.5.5.2(4)e and a referral for appeal to the district court or the BAP should be made. See CCDM 36.2.1.1.5.5.1(4) concerning letters to the Tax Division in connection with an appeal to the district court or the BAP.

4. **Direct Appeal Recommendation Procedures**. A request for certification for direct appeal must be made not later than 60 days after the entry of the judgment, order, or decree. 28 U.S.C. § 158(d)(2)(E). A petition to the court of appeals requesting permission to appeal based on a certification must be filed with the circuit clerk not later than 10 days after the certification is entered on the docket of the bankruptcy court, the district court, or the BAP. A copy of the certification must be attached to the petition. BAPCPA § 1233(b)(4). Rule 5 of the Federal Rules of Appellate Procedure governs the manner in which a direct appeal will be taken, including the place for filing the petition for permission and the contents of the petition. BAPCPA § 1233(b)(3).



1. Meeting the 60-day deadline will require prompt action by Area Counsel, Division Counsel (SB/SE), and the Associate Chief Counsel (Procedure & Administration). For the Government to meet the 60-day deadline, the following actions must be performed within the times specified below, unless another time is agreed upon among the Government offices referred to below.

2. Within two business days of the bankruptcy court’s entry of the adverse judgment, order, or decree, the Area Counsel attorney (or the attorney’s manager) must telephone Branch 2 of CBS to discuss the case and explain why the Government should seek a direct appeal to the court of appeals.

3. Following the discussion with Branch 2 of CBS, if the Area Counsel attorney and the attorney’s manager wish to pursue direct appeal, the Area Counsel attorney must draft a memorandum recommending direct appeal and notify the appropriate Civil Trial Section Chief that Area Counsel will recommend direct appeal. If the case was handled by the U.S. Attorney’s office, the Area Counsel attorney must also notify the U.S. Attorney’s office that a direct appeal will be recommended. The memorandum must discuss why a direct appeal should be pursued and recommend whether a motion should be filed to stay proceedings pending in the bankruptcy court, district court, or BAP. The memorandum must be approved by the Area Counsel and Division Counsel (SB/SE). The memorandum must be received by Branch 2 of CBS not later than 10 calendar days after entry of the adverse judgment, order, or decree.

4. Consistent with CCDM 36.1.1.7.2, Coordination with Division Counsel, the Associate Chief Counsel (Procedure & Administration) will consider SB/SE Division Counsel’s recommendation for a direct appeal, in addition to other recommendations, in determining whether to pursue a direct appeal.

5. If it is agreed that a recommendation for direct appeal should be made, the CBS attorney assigned the case will draft a recommendation for direct appeal for the approval of the Associate Chief Counsel (Procedure & Administration). Upon approval by the Associate Chief Counsel, the direct appeal recommendation must be received by the Appellate Section of the Tax Division, Department of Justice, not later than 30 days after entry of the adverse judgment, order or decree.



      ### Note:



      A copy of the recommendation should be provided to the Civil Trial Section Chief and, if applicable, to the U.S. Attorney’s office.

6. The Solicitor General must approve a recommendation to request certification for direct appeal.


5. **Direct Appeal by Another Party**. If a party other than the Government requests certification for direct appeal, immediate action is necessary. Interim Rule 8001(f)(3)(D) provides that a party has only 10 days to file a response or cross-request to a request for certification, unless another time is fixed by the court. For the Government to meet the 10-day deadline, the following actions must be promptly performed.



1. The Area Counsel attorney (or the attorney’s manager) must immediately telephone the following parties to notify them of the pending request for certification: Branch 2 of CBS, Division Counsel (SB/SE), the Civil Trial Section Chief, and the appropriate Assistant U.S. Attorney (if applicable). These parties must be immediately notified regardless of whether the bankruptcy court’s judgment, order, or decree is entirely favorable to the Government or is adverse in whole or in part.

2. The Area Counsel attorney (or the attorney’s manager) must immediately fax copies of the request for certification and the bankruptcy court’s judgment, order, or decree to Branch 2 of CBS, Division Counsel (SB/SE), the Civil Trial Section Chief, and the appropriate Assistant U.S. Attorney (if applicable). Branch 2 of CBS will consult with Area Counsel and Division Counsel (SB/SE) to determine what recommendation should be made to the Department of Justice.

3. If the recommendation is to oppose the other party’s direct appeal request in its entirety, Branch 2 of CBS should telephone the Civil Trial Section Chief and the Chief of the Appellate Section to discuss the matter.

4. If the recommendation is to acquiesce in or to join in the other party’s request for direct appeal on one or more issues, or to file a separate cross-request that seeks a direct appeal on one or more issues, Branch 2 of CBS must obtain the approval of the recommendation by the Associate Chief Counsel (Procedure & Administration). If the recommendation to acquiesce in, join in, or file a cross-request is approved, Branch 2 will convey the recommendation by telephone to the Civil Trial Section Chief and the Chief of the Appellate Section. A recommendation to acquiesce in or join in the other party’s request, or to file a cross-request for direct appeal, should be rare.



      ### Note:



      The 10-day deadline of Interim Rule 8001(f)(3)(D) does not shorten the 60-day period under 28 U.S.C. § 158(d)(2)(E) within which the Government may seek a direct appeal. If a party other than the Government requests a direct appeal more than 10 days before the end of the 60-day period, the Government may file its own request for direct appeal at any time before the end of the 60-day period.

5. The Chief of the Appellate Section must approve a recommendation to acquiesce in, or to oppose, a request for certification filed by another party. The Solicitor General must approve a recommendation to join in another party’s request or to file a separate cross-request seeking direct appeal.


6. **Certification by Court**. Immediate action is required if the bankruptcy court, district court or BAP issues a certification for direct appeal of an adverse decision before the Area Counsel office has had an opportunity to determine whether to recommend direct appeal. A party only has 10 days after the certification is docketed to petition the court of appeals for permission to appeal. BAPCPA § 1233(b)(4). Consequently, the following actions must be performed immediately after the court issues a certification.



1. The Area Counsel attorney (or the attorney’s manager) must immediately telephone the following parties to notify them of the certification: Branch 2 of CBS, Division Counsel (SB/SE), the Civil Trial Section Chief, and the appropriate Assistant U.S. Attorney (if applicable).

2. The Area Counsel attorney (or the attorney’s manager) must immediately fax copies of the certification and the bankruptcy court’s judgment, order, or decree to Branch 2 of CBS, Division Counsel (SB/SE), the Civil Trial Section Chief, and the appropriate Assistant U.S. Attorney (if applicable). Branch 2 of CBS will consult with Area Counsel and Division Counsel (SB/SE) to determine what recommendation should be made to the Department of Justice.


**36.2.1.2** **(08-11-2004)**

### Court of Appeals Cases

1. This subsection discusses the distinction between the terms judgment, opinion, and mandate, as well as the standards for rehearing and rehearing en banc in the Courts of Appeals


**36.2.1.2.1** **(08-11-2004)**

#### Federal Rules of Appellate Procedure

1. For purposes of the next section, and many that follow, it is important to distinguish among the terms _judgment, opinion,_ and _mandate_ as they relate to the appellate courts.

2. Rule 36 of the Federal Rules of Appellate Procedure states that a judgment is entered when it is noted on the docket. On the date judgment is entered, the clerk mails to all the parties a copy of the opinion, if any, or of the judgment if no opinion was written, and notice of the date of entry of the judgment.

3. A certified copy of the judgment and a copy of the opinion of the court, if any, and any direction as to costs constitutes the "mandate" of the court, unless the court directs the issuance of a formal mandate. The mandate of the court must issue seven days after the time to file a petition for rehearing expires, or seven days after entry of an order denying a timely petition for panel rehearing, rehearing en banc, or motion for stay of mandate, whichever is later. See Fed. R. App. P. 41.

4. Pursuant to Fed. R. App. P. 42(b), the clerk of the court of appeals may dismiss a docketed appeal if the parties file a signed dismissal agreement specifying how costs are to be paid and pay any fees that are due.

5. Mandamus. Rule 21 of the Federal Rules of Appellate Procedure provides that a party petitioning for mandamus or prohibition directed to a court must file a petition with the circuit clerk. The court may deny the petition without an answer. Otherwise, it must order the respondent, if any, to answer within a fixed time. The trial court judge may address the petition, but only by invitation or order of the court of appeals.


**36.2.1.2.2** **(03-27-2012)**

#### Government’s Petition for Rehearing or Rehearing En Banc

1. Opinions of the courts of appeals are transmitted by letter from the Appellate Section, Tax Division, Department of Justice. Upon receipt, they are logged and forwarded to the appropriate Associate's office by the Technical Services Support Branch of the Legal Processing Division in the Office of the Associate Chief Counsel (Procedure and Administration) (P&A). Upon receipt of a court of appeals opinion, the assigned Associate Chief Counsel attorney must carefully review the opinion, taking particular note of the reasons for any reversal or modification of the lower court's decision. If the court of appeals opinion is adverse to the Government, in whole or in part, the attorney must decide whether to recommend the filing of a petition for rehearing or rehearing en banc in the court of appeals (see below), or a petition for writ of certiorari. See CCDM 36.2.2.1, Petition for Certiorari Generally. Both petitions for rehearing or rehearing en banc involve short time limitations and require expeditious consideration. The Office of Chief Counsel will make a recommendation on whether to file a petition for rehearing or rehearing en banc to the Department of Justice in the form of a letter to the Assistant Attorney General (Tax Division).

2. The General Counsel, Treasury must approve recommendations for filing a petition for rehearing en banc. Accordingly, letters recommending rehearing en banc should be coordinated with the Chief Counsel. The Appellate Section of the Tax Division will review the Chief Counsel's recommendation and will prepare its own recommendation to the Assistant Attorney General (Tax Division). If the recommendations are in agreement, the Appellate Section drafts a memorandum for the Assistant Attorney General to the Solicitor General.

3. The Appellate Section's recommendation may conflict with the Chief Counsel's recommendation. In such a case, the Appellate Section will send Chief Counsel a copy of its draft recommendation at the same time or shortly before the recommendation is forwarded to the Assistant Attorney General. Time and circumstances permitting, the Assistant Attorney General will withhold final action on the Tax Division's draft recommendation in order to reconcile the differences. A conference may be held to discuss the recommendations.

4. The Solicitor General will make the final determination as to whether to file a petition for rehearing or rehearing en banc. The Office of the General Counsel, Treasury should be invited to any meeting with the Office of the Solicitor General regarding any recommendation in favor of or in opposition to a petition for rehearing en banc. If the Solicitor General determines that a petition for rehearing en banc should be filed, the Department of Justice will file the petition with the court of appeals in which the appeal is docketed.


**36.2.1.2.2.1** **(03-27-2012)**

##### Standards for Petitions for Rehearing in the Courts of Appeals

1. Petitions for rehearing are rarely granted. Associate Chief Counsel attorneys should generally recommend rehearing only when the court of appeals has overlooked applicable sections of the statutes, regulations, opinions of the Supreme Court, well-established judicial precedents, or other compelling reasons that would warrant the court reconsidering its opinion. Merely because the court of appeals disagreed with the Government's arguments is not an appropriate ground to recommend rehearing.

2. Refer to local rules of the particular circuit since each has specific standards for rehearing.

3. Rule 40 of the Federal Rules of Appellate Procedure provides that when the United States or an agency or officer of the United States is a party, the time within which any party may seek a panel rehearing is 45 days after entry of judgment, unless an order shortens or extends the time. Unless an extension is sought, a recommendation for a rehearing should be transmitted to the Department of Justice within 15 days after receipt of the court's opinion. Any request for an extension of time must be filed within the 45 days or such shorter period prescribed by local rule or order.


**36.2.1.2.2.2** **(03-27-2012)**

##### Standards for Petitions for Rehearing En Banc

1. Rehearing en banc is rarely requested, and even more rarely granted. If it is determined that an appellate panel has overlooked applicable statutory or judicial authorities, and if the local rules of the court of appeals permit, a petition for rehearing en banc may be authorized.

2. Rule 35 of the Federal Rules of Appellate Procedure provides that an en banc rehearing is not favored and ordinarily will not be ordered unless: (a) en banc consideration is necessary to secure or maintain uniformity of the court's decisions; or (b) the proceeding involves a question of exceptional importance. The petition must begin with a statement that either the panel decision conflicts with a decision of the United States Supreme Court or of the court to which the petition is addressed; or the proceeding involves one or more questions of exceptional importance. See Fed. R. App. P. 35 and the local rules of the particular circuit.

3. Rule 35(c) of the Federal Rules of Appellate Procedure provides that a petition for a rehearing en banc must be filed within the time prescribed by Appellate Rule 40 for filing a petition for rehearing. Accordingly, a petition for rehearing en banc in cases in which an officer or agency of the United States is a party must be filed within 45 days after entry of judgment, unless an order shortens or extends the time.


**36.2.1.2.3** **(03-27-2012)**

#### Associate Chief Counsel Attorney Responsibilities in Rehearing En Banc Cases

1. This subsection describes the responsibilities of the Associate Chief Counsel Attorney in rehearing en banc cases.


**36.2.1.2.3.1** **(03-27-2012)**

##### Initial Responsibilities — Rehearing En Banc Cases

1. If the adverse appellate court opinion reverses or modifies a Tax Court decision, the attorney should consult CCDM 36.2.5.12, Cases Remanded to the Tax Court/Recomputations, for cases remanded to the Tax Court. For example, if the Tax Court's decision was favorable to the Government and the taxpayer prevailed on appeal in the court of appeals, the case will usually be remanded to the Tax Court for entry of a new decision in accordance with the mandate of the court of appeals. Any action on remand, however, must await the expiration of the rehearing en banc period or, if rehearing en banc is petitioned and granted, the conclusion of proceedings in the court of appeals that has subject matter jurisdiction over the case. Nevertheless, Area Counsel should be advised of the remand by the Associate Chief Counsel attorney.


**36.2.1.2.3.2** **(03-27-2012)**

##### Documents and Files

1. The assigned Associate Chief Counsel attorney should obtain all documents and files required to make an informed decision regarding rehearing en banc, including the recommendation of the Appellate Section, if available.


**36.2.1.2.3.3** **(03-27-2012)**

##### Coordination within Chief Counsel

1. If the issues lost on appeal are within the jurisdiction of other offices within the Office of Chief Counsel or with other branches within the responsible Associate's office, further action should be coordinated with that office or branch. See CCDM 36.1.1.6, Responsibilities of Associate Chief Counsel Offices in Appeal Cases, for instructions regarding coordination.


**36.2.1.2.3.4** **(03-27-2012)**

##### Information Memorandum — Rehearing En Banc Cases

1. If it is reasonably probable that an affirmative recommendation for rehearing en banc will be made, the Associate Chief Counsel office will prepare an information memorandum summarily describing the adverse court opinion, Service position, and the administrative significance or other reason for potentially recommending filing a petition for rehearing en banc. The memorandum concludes with a statement that an affirmative recommendation for rehearing en banc is being considered.

2. The purpose of the information memorandum is to provide early notification to Chief Counsel officials, the Commissioner's office, and the General Counsel's office that the Associate Chief Counsel is strongly considering recommending filing a petition for rehearing en banc. The Associate Chief Counsel attorney should prepare the information memorandum sufficiently early to allow adequate time to react to the potential recommendation.

3. The Associate Chief Counsel transmits the information memorandum via email. The information memorandum may either be embedded in the email or attached to it. A copy of the adverse appellate court opinion should be attached. The email and memorandum should highlight the due dates for action. The email should be sent to the following:



   - Chief Counsel

   - General Counsel

   - Both Deputy Chief Counsel

   - Associate Chief Counsel and Division Counsel

   - Commissioner

   - Deputy Commissioner for Services and Enforcement and Assistant Deputy Commissioner for Services and Enforcement

   - Chief of Staff to the Commissioner and Deputy Chief of Staff

   - The Counselor to the General Counsel, Treasury

   - The Office of Tax Policy at Treasury, as appropriate

   - Other Commissioner’s staff who may have been involved in the issue or are generally involved in litigation matters


4. The email should highlight the critical dates for recommending a rehearing en banc. A sample information memorandum email for rehearing en banc cases appears on page 4 of Exhibit 36.4.1–2..

5. Should a decision be made not to seek rehearing en banc after an information memorandum has been circulated, the originator of the information memorandum should prepare a short memorandum explaining the reasons for not seeking rehearing en banc that may be transmitted via email by the Associate Chief Counsel to the above parties.


**36.2.1.2.3.5** **(03-27-2012)**

##### Action Documents

1. After the information memorandum is circulated and assuming the Office initially has decided that a recommendation for a petition for rehearing en banc is appropriate, the process works as follows: the attorney should prepare a signature package for review and approval by the Chief Counsel, which package shall include an Action Memorandum. The Action Memorandum should briefly describe the adverse court opinion, Service position, and the administrative significance or other reason for potentially recommending filing a petition for rehearing en banc. The package is first sent to the Associate Chief Counsel who will forward it to the Chief Counsel through the responsible Deputy Chief Counsel. Since the General Counsel, Treasury, must approve the petition for rehearing en banc, this package serves two purposes. It allows the Chief Counsel to review and approve the draft recommendation to the Department of Justice. It also transmits this recommendation to the General Counsel, Treasury, for consideration and approval. The Chief Counsel will sign the Action Memorandum to the General Counsel, Treasury, and the Associate Chief Counsel will transmit the Action Memorandum to the General Counsel via email. Once approval by the General Counsel is received, the Associate Chief Counsel can sign the letter and deliver it to the Department of Justice.

2. The responsible Associate will forward the following documents to the Chief Counsel for review and concurrence:



   - Transmittal document transmitting the package to the Chief Counsel

   - Draft undated letter to the Department of Justice recommending rehearing en banc

   - Draft Action Memorandum from the Chief Counsel to the General Counsel (see page 2 of Exhibit 36.4.1–3 ).

   - Copies of the relevant opinion and other attachments, if any


3. Once the Chief Counsel has approved the draft letter and signed the Action Memorandum, the package will be returned to the appropriate Associate Chief Counsel for handling. The Associate will transmit scanned copies of the following documents to the General Counsel, Treasury, via email:



   - Action Memorandum to the General Counsel signed by the Chief Counsel

   - Copy of the draft letter to the Department of Justice

   - Copy of the opinion and other attachments


### Note:

The email should highlight the critical dates when action is required. The signed Action Memorandum should be scanned and attached to the email. (see page 2 of Exhibit 36.4.1–3).

4. The General Counsel, Treasury, will be responsible for clearance of the matter with the appropriate Treasury officials. Once the General Counsel informs the Associate office that Treasury concurs in the recommendation, the Associate will sign the letter and forward the package to the Department of Justice. Copies of the letter will also be forwarded to any of the Associates or Division Counsel who were involved in developing the letter.


**36.2.1.2.3.6** **(03-27-2012)**

##### Letter to Department of Justice — Rehearing En Banc Recommendation

1. The Associate Chief Counsel is responsible for preparing the letter and ultimately signs the letter to the Assistant Attorney General, Tax Division, Department of Justice, recommending for or against the filing of a petition for rehearing en banc. The Associate should take into consideration the views and comments generated by the Information Memorandum or provided by Division Counsel over the trial level case and should coordinate the draft letter with those parties that made substantive comments. Coordination is particularly important when the letter recommends for rehearing en banc.

2. A letter recommending a petition for rehearing en banc must be sent to the Department of Justice no later than 10 days after the court of appeals' opinion or order is filed or after receipt of the request from the Department of Justice. Since any letter recommending a petition for rehearing en banc must be reviewed and approved by various offices within the Office of Chief Counsel and by the Chief Counsel and General Counsel, Treasury, it is imperative that such letters be prepared expeditiously.

3. Considerations in recommending rehearing en banc.



1. a. For rehearing en banc, as for other appellate purposes, controversy in tax cases is defined in terms of a decision against the Government and not a mere refusal to accept the Government's legal theory. See CCDM 36.2.1.1, Preparation of Appeal Letters. The letter to the Department of Justice should set forth very persuasive reasons why rehearing en banc should be sought.

2. Rehearing en banc is generally recommended when either the panel decision conflicts with a decision of the United States Supreme Court or of the court to which the petition is addressed or the proceeding involves one or more questions of exceptional importance, and this should be clearly stated in the letter.

3. In the absence of an intracircuit or Supreme Court conflict, en banc review may nevertheless be recommended when the issue is one of exceptional administrative importance requiring prompt resolution.

4. The exceptional administrative importance of the issue should be stated explicitly, and the intracircuit or Supreme Court conflict, if any, should be explained.

5. The nationwide jurisdiction of the Federal Circuit is one factor in considering a recommendation for rehearing en banc. A loss in this circuit may mean that the Government will not litigate another case with the issue.


4. The letter to the Department of Justice recommending rehearing en banc should include the following statement: _The General Counsel concurs with this recommendation._


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part36/irm_36-002-001#addtoany "Show all")

A2A