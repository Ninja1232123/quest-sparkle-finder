---
url: "https://www.irs.gov/irm/part33/irm_33-001-002"
title: "33.1.2 Chief Counsel’s Legal Advice Program | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part33/irm_33-001-002#main-content)

- 33.1.2  [Chief Counsel’s Legal Advice Program](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191200530192)
  - 33.1.2.1  [Informal Advice](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191200519520)
  - 33.1.2.2  [Formal Legal Advice](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191200514016)
    - 33.1.2.2.1  [Legal Advice by Field Counsel](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191200513088)
    - 33.1.2.2.2  [Coordination of Legal Advice with Associate Chief Counsel](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191200509776)
      - 33.1.2.2.2.1  [Presubmission Conferences](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191200562096)
    - 33.1.2.2.3  [General Procedures for Legal Advice from Associate Chief Counsel](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191200559184)
      - 33.1.2.2.3.1  [Form of Legal Advice Provided by Associate Offices to Field Offices](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191201546560)
      - 33.1.2.2.3.2  [Technical Advice vs. Legal Advice in Nondocketed Cases](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191201542384)
      - 33.1.2.2.3.3  [Format of Legal Advice](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191201536592)
      - 33.1.2.2.3.4  [Additional Considerations Governing Preparation of Chief Counsel Advice](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191202398848)
      - 33.1.2.2.3.5  [Additional Procedures for Certain Non-Taxpayer Specific Legal Advice, Including Generic Legal Advice](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191202394864)
      - 33.1.2.2.3.6  [Reconsideration of Legal Advice](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191202383200)
    - 33.1.2.2.4  [Legal Advice to Program Managers](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191202381216)
  - 33.1.2.3  [Legal Advice Prepared in the Field and Reviewed by an Associate Office](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191202371184)
    - 33.1.2.3.1  [Format for Advice](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191202369248)
    - 33.1.2.3.2  [Procedures for Requesting Associate Office Review](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191202366096)
  - 33.1.2.4  [Advice to Taxpayer Advocate Service](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191200495264)
    - 33.1.2.4.1  [Legal Advice Requests from TAS](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191200494112)
    - 33.1.2.4.2  [Responsibility within Counsel for Providing Legal Advice](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191200492320)
    - 33.1.2.4.3  [Procedures for Providing Legal Advice to TAS](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191200481344)
      - 33.1.2.4.3.1  [Coordination of TAS Advice with CC:NTA or Associate Offices](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191200477648)
      - 33.1.2.4.3.2  [Time Frames for Requests for TAS Advice](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191200471440)
      - 33.1.2.4.3.3  [Local Taxpayer Advocate’s Discretion Not to Disclose](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191200462288)
        - 33.1.2.4.3.3.1  [Scope of LTA’s Discretion](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191200460256)
        - 33.1.2.4.3.3.2  [Role of Counsel in the Section 7803(c)(4)(A)(iv) Context](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191200451072)
  - 33.1.2.5  [Advice to Internal Revenue Service Campuses](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191200444320)
    - 33.1.2.5.1  [Service Campus Legal Advice Procedures](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191200438784)
    - 33.1.2.5.2  [Field Counsel Procedures — Advice to IRS Campuses](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191229305456)
    - 33.1.2.5.3  [Transmitting Associate Office Advice to Service Campuses](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191229300256)
    - 33.1.2.5.4  [Division Counsel Procedures for Advice Requests from IRS Division Commissioners](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191229297872)
    - 33.1.2.5.5  [Service Campuses Requests for Advice Received by Associate Offices](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191229292768)
  - 33.1.2.6  [Abusive Tax Schemes](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191229289392)
  - 33.1.2.7  [Ex Parte Communication Rules Applicable to Advice to Appeals](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191229286944)
    - 33.1.2.7.1  [Ex Parte Communications](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191229283104)
      - 33.1.2.7.1.1  [Counsel Exceptions to Ex Parte Communications](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191229270992)
    - 33.1.2.7.2  [Advice in Docketed Tax Court Cases](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191229268352)
      - 33.1.2.7.2.1  [Communications Regarding Collection Matters](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191229265280)
    - 33.1.2.7.3  [Legal Advice in Nondocketed Cases](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191229255904)
      - 33.1.2.7.3.1  [Cases with Multiple Open Years](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191229243696)
      - 33.1.2.7.3.2  [Closing Agreements](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191202329680)
      - 33.1.2.7.3.3  [Global Settlement Initiatives](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191202326656)
    - 33.1.2.7.4  [Review of Statutory Notices of Deficiency](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191202322848)
  - 33.1.2.8  [Review of Notices of Deficiency and Claim Disallowance](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191202311792)
    - 33.1.2.8.1  [Additions to Tax](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191202299536)
    - 33.1.2.8.2  [Net Operating Loss and Carrybacks](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191202277392)
    - 33.1.2.8.3  [Actions upon Receipt of Deficiency Notice for Review](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191202274608)
    - 33.1.2.8.4  [Actions After Review of Deficiency Notice](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191202271424)
    - 33.1.2.8.5  [Munro Computations](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191202265648)
    - 33.1.2.8.6  [Review of Statutory Notices of Claim Disallowance](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191202260384)
    - 33.1.2.8.7  [Review of Notices of Determination of Worker Classification](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191229235248)
    - 33.1.2.8.8  [Determination by Appeals](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191229232592)
    - 33.1.2.8.9  [Second Statutory Notices](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191229228672)
    - 33.1.2.8.10  [Compliance with Section 7522 Notices to Taxpayers](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191229220864)
      - 33.1.2.8.10.1  [Content](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191229216480)
      - 33.1.2.8.10.2  [Taxpayer Challenges](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191229211648)
      - 33.1.2.8.10.3  [Field Counsel Responsibilities](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191229204624)
    - 33.1.2.8.11  [Statutory Notices in Cases Having Criminal Aspects](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191229199792)
      - 33.1.2.8.11.1  [Exhibits in Criminal Tax Cases](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191229185824)
  - Exhibit  33.1.2-1  [Format for Generic Legal Advice Memorandum](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191229183456)
  - Exhibit  33.1.2-2  [Checksheet for Processing Generic Legal Advice](https://www.irs.gov/irm/part33/irm_33-001-002#idm140191229161184)

# Part 33. Chief Counsel Directives Manual Legal Advice

# Chapter 1. Legal Advice

# Section 2. Chief Counsels Legal Advice Program

* * *

## 33.1.2 Chief Counsel’s Legal Advice Program

#### Manual Transmittal

January 19, 2021

#### Purpose

(1) This transmits revised CCDM 33.1.2, Legal Advice; Chief Counsel’s Legal Advice Program.

#### Material Changes

(1) CCDM 33.1.2.4, Advice to Taxpayer Advocate Service, was updated to reflect the name change for the Division Counsel/Associate Chief Counsel (National Taxpayer Advocate Program) (CC:NTA).

(2) CCDM 33.1.2.4.2(2), Responsibility within Counsel for Providing Legal Advice, was updated to clarify that Division Counsel (SB/SE) will generally provide legal advice to TAS local offices and reflect the name change for the Division Counsel/Associate Chief Counsel (National Taxpayer Advocate Program).

(3) CCDM 33.1.2.4.2(4), Responsibility within Counsel for Providing Legal Advice, was updated to clarify the responsibilities of CC:NTA in providing advice to the National Taxpayer Advocate and TAS local offices, and to update the list of issues under the jurisdiction of the office to be consistent with CCDM 30.3.2.1.2 (10-29-2020), Division Counsel/Associate Chief Counsel (National Taxpayer Advocate Program).

(4) CCDM 33.1.2.4.2(5), Responsibility within Counsel for Providing Legal Advice, was added to describe procedures for handling confidential information provided by TAS.

#### Effect on Other Documents

This section supersedes CCDM 33.1.2 dated July 30th, 2020.

#### Audience

Chief Counsel

#### Effective Date

(01-19-2021)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**33.1.2.1** **(08-11-2004)**

### Informal Advice

1. Any attorney providing informal assistance, whether by telephone or email, should summarize the substance of the advice as appropriate and have it reviewed and approved by a manager. Any recordation of informal advice should be very short and contain only a brief description of the facts, if necessary, issue, and conclusion. Little or no legal analysis is to be included. Any error found upon review should be corrected promptly. The mistaken advice should be quickly withdrawn, and a record made of the amended advice. The Informal Field Assistance (Telephone Call) form, which can be found on CC Macros, should be used to memorialize the advice given by telephone. To simplify this process and assist the manager in reviewing the advice, it may be helpful to attach relevant email traffic.

2. All telephone calls and email messages requesting advice should be acknowledged and responded to within one business day. Final advice may follow in accordance with agreed timeframes and consistent with the business rules.

3. Each Associate and Division Counsel should establish procedures for maintaining copies of the advice given which will allow for retrieval of the advice. In addition, copies of informal advice provided by the Associate offices to field counsel should be accumulated and sent to the Technical Services Support Branch of the Legal Processing Division, Office of the Associate Chief Counsel (Procedure & Administration) on a weekly basis to be forwarded monthly to the appropriate Division Counsel office for review.


**33.1.2.2** **(08-11-2004)**

### Formal Legal Advice

1. The following subsection discusses the procedures governing formal written legal advice given by Field Counsel and the Associate offices.


**33.1.2.2.1** **(04-12-2013)**

#### Legal Advice by Field Counsel

1. Although relatively routine and simple questions may be addressed orally or by email, legal advice should generally be provided by memorandum.

2. When a written opinion is provided, a copy should be retained for association with any related matter, subsequently proposed deficiency notice, or docketed case.

3. A memorandum providing legal advice should be tailored to the needs of the recipient and the question posed. Legal advice prepared by Field Counsel should follow the format contained at _CCDM 33.1.2.2.3.3_, Preparation of Legal Advice.


**33.1.2.2.2** **(08-11-2004)**

#### Coordination of Legal Advice with Associate Chief Counsel

1. When Field Counsel identifies an issue or matter that must be coordinated with an Associate office in the process of developing a case for litigation or in rendering legal advice to the Service, coordination should occur as early as practicable and should continue, as appropriate, through case development, litigation, and resolution.

2. Field Counsel may contact the Associate office initially either by telephone or email. The Chief Counsel Code and Subject Matter Directory listing attorney or branch contacts in the Associate Chief Counsel offices may be used as a starting point to determine who to contact. See _CCDM 33.1.2.2.3_, General Procedures for Legal Advice from Associate Chief Counsel. As part of the process, Field Counsel may provide documents to the Associate office attorneys to assist in understanding the facts, the transaction, or the issues, and the Associate office attorneys may request additional information as needed to determine how to handle the request. Such contacts will also clarify the nature and urgency of the advice being requested. Any informal advice given should be memorialized as described in _CCDM 33.1.2.1_, Informal Advice.

3. Counsel should strive to deliver the most appropriate advice in a given situation. During their informal contact, Field Counsel and the Associate office attorney or advisor should discuss whether Field Counsel will need to draft written advice or whether Field Counsel will need written advice from the Associate office. Field Counsel and the Associate office may also discuss whether a presubmission conference would be appropriate, the form that any legal advice should take, and whether the taxpayer should be involved in the process. When a written response is appropriate, it may be:



1. Unreviewed written advice from Field Counsel to the client

2. Written advice from Field Counsel submitted for pre-review by the Associate office under the procedures in _CCDM 33.1.2.3_, Legal Advice Prepared in the Field and Reviewed by an Associate Office

3. Legal advice from the Associate office to Field Counsel

4. A Technical Advice Memorandum prepared under Rev. Proc. 2004-02, or its successor

5. Some combination of the above. In some cases, it may be decided that the issue would be best be addressed in published guidance or that a published guidance project should be opened on an issue raised by a request for legal advice in addition to responding to the request.


4. If the Associate office attorney, Field Counsel and their reviewers, as appropriate, agree that written advice is needed, Field Counsel shall submit a memorandum setting forth the issues upon which advice is being sought, together with a discussion of the facts, law, and conclusions or course of action proposed by Field Counsel. In general, requests should include the following information:



1. The name and docket number of the case on the subject line, if the advice is being requested with respect to a matter in litigation

2. The Uniform Issue List number for each issue

3. Whether the advice request relates to either a Technical Advisors Program issue, a Coordinated Industry Case (CIC), or an issue involving at least $10,000,000 in tax, penalties, or interest. Requests in TEFRA cases should indicate whether or not they impact partner level adjustments totaling at least $10,000,000.

4. Whether it concerns legal advice to the Taxpayer Advocate Service or whether it concerns legal advice to Service Campuses

5. The proposed positions of Field Counsel, IRS Field employees, Appeals, and the taxpayer, as well as the basis for such positions

6. The expiration date of the statute of limitations for issuing the notice, if the case is a pre-90-day case

7. Whether the request requires an expedited response

8. The current posture of the case, if the case is docketed


5. Where the written advice will be processed for release to the public, taxpayer-specific requests for advice must also include at the time they are submitted:



1. The taxpayer’s full name

2. The taxpayer’s last known mailing address

3. The taxpayer’s taxpayer identification number (TIN)

4. If a taxpayer has a representative who has a power of attorney to represent the taxpayer in the matter that is the subject of the request, the name and address of the representative and a copy of the power of attorney

5. Any information in the request, or other background file documents submitted with the request that the Field office believes should not be made available for public inspection. If the Field office recommends that information in the background file documents should be deleted, the request for advice must include the basis for the recommendations. See CCDM 37.1.1, Written Determinations Under Section 6110.


6. These procedures also apply to declaratory judgment cases. In these cases, the attorney should recognize the need for advice at the earliest possible time if such procedures are to be effective. It is theoretically possible for a declaratory judgment case to be submitted within four months of the date of issuance of the determination letter, assuming the petitioner files an early petition and reply. In view of that possibility, the submission of a prepetition advice request is encouraged, even though a response cannot be anticipated before the determination letter must be issued.

7. Advice that implicates the issues or matters within the subject matter of another Associate office should be coordinated with those offices as early in the advice process as possible. The coordination and reconciliation procedures are discussed in full in CCDM 31.1.4, Coordination and Reconciliation of Disputes.


**33.1.2.2.2.1** **(08-11-2004)**

##### Presubmission Conferences

1. Depending on the significance, novelty, and complexity of the proposed request, the Associate office may choose to have a more formal presubmission conference. A formal presubmission conference would include any attorneys and managers of the organizations that either have subject matter jurisdiction over the issues involved in the matter or have an interest in resolution of the matter. Field Counsel or the Associate office may invite Service representatives to participate in the conference if this would assist in defining the issues upon which advice is needed. Presubmission conferences should not be held in taxpayer specific cases with Service representatives unless Field Counsel participates or declines to participate.

2. Formal presubmission procedures are required in connection with Technical Advice as set out in Revenue Procedure 2004-2 or its successors. Presubmission conferences are encouraged for other forms of legal advice.


**33.1.2.2.3** **(08-11-2004)**

#### General Procedures for Legal Advice from Associate Chief Counsel

1. Requests for legal advice from either Field Counsel or components of the Service should be addressed to the Associate office that has subject matter jurisdiction over the primary issue in the case.

2. Requests for written legal advice from Associate offices, other than the Division Counsel/Associate Chief Counsel (Criminal Tax) (CT) and the Associate Chief Counsel (General Legal Services) (GLS), should be submitted to the Associate offices through the Technical Services Support Branch, Associate Chief Counsel (Procedure and Administration) (P&A). Requests should be submitted by email using normal sensitivity and addressed to TSS4510. The email should include the names of any Associate office attorneys or reviewers with whom the request had been informally coordinated. It should also include the case number. Supporting documents should be sent by email or express mail to the Technical Services Support Branch, CC:PA:LPD:TSS, Room 5329, 1111 Constitution Avenue, NW, Washington, D.C. 20224.

3. The Technical Services Support Branch will send an email acknowledging the receipt of a request for Associate office assistance to the Field office that requested the assistance. The email will identify the Associate office to which the case is assigned and provide the Field office with the name of that Associate office’s contact person. A copy of this email will be sent to the Associate office’s contact person. If an Associate office does not receive an assignment within one business day from the date of the email, the Associate office should contact the Technical Services Support Branch to determine if the case file has been misdirected or misplaced.

4. The Technical Services Support Branch will send a copy of any request for advice relating to Service Campuses when appropriate to Wage and Investment (W&I) Division Counsel, the Customer Accounts Manager (Small Business/Self-Employed (SB/SE)), and the SB/SE and W&I analysts responsible for Service Campus operations with a request for such additional information or comment as these offices might wish to provide.

5. Upon receipt of a case, the Associate attorney should contact the attorney assigned in Field Counsel to inform them of their assignment to the case and to solicit the Field’s participation in the development of the Associate office’s response or review. Any requests for expedited treatment should be discussed, and, if an expedited response is necessary, a time for response should be established. Disputes regarding expedited responses should be promptly elevated and reconciled.

6. The Associate office assigned primary responsibility for preparing legal advice is responsible for coordinating the request for advice with the other Associate offices as needed. This coordination should occur shortly after the initial case assignment. The procedures governing coordination and reconciliation are discussed more fully in CCDM 31.1.4.2.3, Coordination among Associate Chief Counsel, and CCDM 31.1.4.2, Coordination within the Office of Chief Counsel.

7. The attorney assigned primary responsibility for preparing written legal advice should communicate with the requesting office when a tentative conclusion has been reached. Such communication enables the requesting office to raise informal concerns to the proposed advice product and to call attention to facts or arguments that may not have previously been raised, developed, or disclosed. Any Counsel office that receives advice or assistance must follow the advice or implement the assistance, unless the receiving office requests reconsideration of the advice or assistance and the advice or assistance is changed through the reconciliation procedure. Early communication is, thus, essential to a meaningful dialogue in the reconciliation process.

8. Requests for legal advice on issues arising under the jurisdiction of the Division Counsel/Associate Chief Counsel (CT) should be addressed to that office or the appropriate Area Counsel. Requests for legal advice on issues arising under the jurisdiction of the Associate Chief Counsel (GLS) should be directed to that office or the appropriate Area Counsel.


**33.1.2.2.3.1** **(04-12-2013)**

##### Form of Legal Advice Provided by Associate Offices to Field Offices

1. The form of legal advice should be tailored to the question asked, the type of response anticipated, and the need of the office to set out a full, comprehensive analysis of an issue or a case. It is generally, however, not an efficient use of Counsel’s resources to craft lengthy memoranda that set out extensive discussions of the facts where the facts are not subject to any real ambiguity or dispute or merely restate undisputed facts contained in other documents. Nor should memoranda contain extensive discussions of the law _where the issue is narrow,_ there is no need to set out such an analysis of the law, or where there is no concern that a related question or issue should be explored. If there is confusion regarding the state of the law on an issue, then it may be appropriate to write a memorandum that contains extensive legal analysis without any need to apply the law to the specific facts of a case. Such a memorandum might not require any discussion of the litigating hazards. Advice may address strategy or case development without an extensive recital of the applicable statutes and regulations. In some instances, it may be necessary to include both strategic advice and legal background discussion if both are necessary to convey the appropriate resolution of the case.


**33.1.2.2.3.2** **(08-31-2010)**

##### Technical Advice vs. Legal Advice in Nondocketed Cases

1. The choice between whether to request Technical Advice or some other form of legal advice depends on whether the advice is intended to establish the position of the Service in a specific case and whether it is advisable to have the taxpayer participate in the advice request process. If the above types of conditions apply, technical advice must be requested and will result in the issuance of a Technical Advice Memorandum. Questions about whether Technical Advice is appropriate are further addressed in CCDM 33.2, Technical Advice And Technical Expedited Advice. Generally, all other forms of advice constitute legal advice. Legal advice may be issued to the Field, to a program manager, or to a Division or Division Counsel. It may be issued in either docketed or nondocketed cases and may cover legal issues, tactics, and strategy related to a case, a generic issue, or program. Legal advice may also respond to the type of coordination needed with the Associate offices in pursuing the issue, the advisability of identifying test cases with particular fact patterns, or the strategies that might be considered to resolve the issue without litigation.

2. Legal advice does not preclude a request for technical advice in the same case. Depending on the circumstances, the requests for different types of advice may be made at different stages of case development or at the same time with respect to different types of issues. For example, some form of legal advice might be needed at a preliminary stage in order to decide what lines of factual development should be pursued, and technical advice might then be requested at a later stage to determine final Service position based on the facts that have been developed. In some cases, technical advice might be requested in order to establish Service position based on the facts that have been developed with respect to certain legal issues while some other form of legal advice might at the same time be provided to assist with tactical or strategic case-development issues.

3. Technical advice may not be used to provide legal advice intended to be generally applicable to an industry or a discrete class of taxpayers. See _CCDM 33.1.2.2.3.5_.

4. Chief Counsel Advice is a term used to describe a certain subset of legal advice that is required to be released to the public under IRC 6110. Not all legal advice is subject to this public disclosure requirement. For a more complete discussion of what constitutes Chief Counsel Advice, see CCDM 33.1.3.1.1, Definition of Chief Counsel Advice.


**33.1.2.2.3.3** **(04-12-2013)**

##### Format of Legal Advice

1. Legal advice may contain the following elements when appropriate to the content of the legal advice being rendered:



01. Written legal advice should contain a caption/information identifying the case. The caption and identifying references will include the CASE number, office symbols of the office drafting the advice, the appropriate UILs, the name of the case, the title of the person to whom the advice is directed, and the title of the person signing the advice. The subject line should reflect the primary issue in the case, even if the memorandum provides case specific advice, and should not categorize the advice by a name, such as Chief Counsel Advice or Generic Legal Advice.



       ### Note:



       If the names of the person assigned to case, the person to whom the advice is sent, and the person signing the advice are included in the memorandum, they may not be redacted when the advice is processed for release. See CCDM 33.1.3.2, Redacting Legal Advice Prior to Public Release.

02. The opening paragraph of should state: "This document should not be used or cited as precedent." The opening paragraph of the advice may then briefly set forth the nature of the case (for example, submission of a proposed revenue ruling for concurrence or comment). That the office has previously rendered legal advice on the case may be mentioned.

03. The opening paragraph of a memorandum that provides advice of the type described in _CCDM 33.1.2.2.3.5_ should state the general issue that the memorandum addresses.

04. Taxpayer-specific advice should include a legend for identifying the references to taxpayer information in the advice.

05. Issue headings should be used as appropriate. If there is more than one issue, each issue is stated in a separate paragraph, and each paragraph is numbered. State the issues in clear, precise language. Whenever appropriate, state any additional issues that have been identified but were not specifically raised in the incoming request for advice.

06. A **Conclusion** heading should be used if an issue heading is appropriate. There should be a specific statement of the conclusion reached with respect to each issue. This conclusion must be written to leave no doubt as to its meaning and to make it clear it is based solely on the facts presented.

07. A **Statement of Facts** heading should normally be used. It should contain those facts necessary to understand the analysis of the issues. The facts should be set out concisely, but without sacrificing clarity. Generic facts may be used if they do not sacrifice clarity.

08. A **Law and Analysis** heading should normally be used. The analysis portion of the advice sets forth clearly and concisely the pertinent law, regulations, published rulings of the Service, and case law or other precedent and the rationale to bridge between the issue, facts, law, and conclusion.

09. A **Case Development, Hazards, and Other Considerations**heading should be used when the document will be processed for release as Chief Counsel Advice or if it is advice provided under _CCDM 33.1.2.2.3.5_. This part of the advice might include a discussion of audit techniques, case development, legal precedent or other factual or tactical considerations that may pose litigation hazards. Depending on the circumstances, all or part of the information in this section may be exempt from disclosure. For further information on redacting this material, see CCDM 33.1.3.2.2, Permissive Deletions of Privileged Material.

10. The law and analysis section (or the case development section, if any) may be followed by a summary in a complex case. The summary may be used to restate the facts and the law, to reiterate the conclusions reached on each issue, and to set forth recommended action.


2. The CC macros should be used to ensure the format of the memorandum is correct. Headings normally introduce the statement of the issue or issues, the conclusion or conclusions, the statement of facts, the analysis, and the summary. Headings need not be used if the advice is four pages or fewer. The format for memoranda signed by Associate Chief Counsel executive prepared to provide non-taxpayer specific legal advice is shown in _Exhibit 33.1.2-1_.

3. The citation forms in the current edition of _The Bluebook: A Uniform System of Citation_ should be used in legal memoranda.

4. In preparing memoranda providing legal advice, attorneys and managers should consider the character of the advice being given. A memorandum that consists entirely of case development and strategic advice that would be subject to the attorney client or law enforcement privilege, or that is given with respect to a docketed case or in anticipation of litigation, will have little, if any, material that will be subject to public disclosure under IRC 6110. Such memoranda may be prepared without legends and other tools that facilitate redaction. A memorandum that contains a background discussion of the law or a description of the facts will likely have significant portions disclosed. In such cases, the memorandum should be prepared using the redaction tools.

5. When legal advice has been coordinated with other Associate offices or branches within an Associate office, the response received from those offices must not be attached to the memorandum that is provided to Field Counsel or other IRS field employee. Rather, the office responsible for preparing written legal advice should integrate the analysis, as appropriate, into the memorandum.


**33.1.2.2.3.4** **(08-11-2004)**

##### Additional Considerations Governing Preparation of Chief Counsel Advice

1. As with legal advice in general, Chief Counsel advice does not set out official rulings or positions of the Service and may not be attached or referred to in other advisory products or subsequent Chief Counsel advice as precedent. These documents may be reviewed as part of an attorney’s legal research, and the subsequent legal advice should integrate any relevant analysis into the Chief Counsel advice when the documents address the same or similar issues. Thus, legal advice should not cite to prior Chief Counsel advice as authority for the conclusions or recommendations contained in the advice, nor should the previously issued document be attached.

2. Drafts of the factual portions of Chief Counsel advice may be shared with the requesting office to ensure that the facts are accurate and complete. Generally, drafts of the legal analysis should not be shared. It is expected, however, that discussions will occur between the requesting office and the issuing office regarding the proposed legal analysis before the Chief Counsel advice is drafted and issued. Occasionally, a team of experts, which would include the Associate office and Field Counsel, will work jointly on the drafting of the Chief Counsel advice. In such situations, complete drafts may be shared among all the participating attorneys. Once complete drafts are shared, the request for the advice may not be withdrawn. Rather, the Chief Counsel advice will be completed and issued.


**33.1.2.2.3.5** **(04-12-2013)**

##### Additional Procedures for Certain Non-Taxpayer Specific Legal Advice, Including Generic Legal Advice

01. When an issue arises in a number of cases that affects an industry segment or there is a need to address a legal issue as it relates to an amalgamated set of facts, it may be desirable to have an Associate Chief Counsel executive whose office is responsible for the issue sign a generic legal advice. This type of advice is in contrast to issuing non-taxpayer specific legal advice at the branch level. Generic legal advice might be appropriate, for example, where a common set of material facts applies to a significant number of taxpayers, and advice with respect to facts representative of those common material facts will assist the Service in resolving the cases more efficiently than advice applicable only to a specific taxpayer.

02. Legal advice of this type may originate from a request for advice by the Service or a field office of Counsel, or at the initiative of an Associate Chief Counsel executive. To ensure that non-taxpayer specific legal advice is designed to meet the needs of IRS program mangers, a request for legal advice of general applicability made under these procedures must in general be submitted by a program manager with national responsibility for the issue or by a Division Counsel executive. In either case, legal advice of this type may be issued upon a determination by an Associate Chief Counsel executive that it is appropriate to render such advice in this form to promote efficiency, to promote consistent treatment of similarly situated taxpayers, or to otherwise promote sound tax administration. If the legal advice is at the initiative of an Associate Chief Counsel executive, that executive will coordinate with Division Counsel upon initiation of the project, so that Division Counsel may seek the views of the appropriate Service executives.

03. For requests by program managers or a Division Counsel executive, the Associate Chief Counsel must conduct a presubmission conference. The presubmission conference should include, as appropriate, the Division Counsel executive and the program manager. A presubmission conference will help to confirm the form of legal advice that is appropriate under the circumstances. It will also assist in defining the issues on which advice is needed, in developing the amalgamated facts upon which to base the legal advice, and in discussing possible timeframes within which advice will be provided once the request is submitted.

04. After submission of a request for this type of legal advice, the Associate Chief Counsel executive, the Division Counsel executive, and the requesting program manager, where appropriate, should agree upon a mutually acceptable timeframe for completion. The facts and circumstances surrounding the request will determine the appropriate timeframe, and may include consideration, as appropriate, of the requester's priorities, the priority of the advice relative to other work in the office, and the complexity or sensitivity of the issues presented. The Associate Chief Counsel office will confirm the agreement in writing, either by email or memorandum, identifying the issue or issues to be addressed and the agreed upon date of completion.

05. The Associate Chief Counsel executive should notify the Division Counsel executive and, where applicable, the program manager of any developments in processing the request for advice that might delay the response beyond the agreed upon date. The program manager or Division Counsel executive that submitted the request may ask for a conference with the Deputy Chief Counsel (Operations) if the response is delayed beyond the agreed upon date. The Associate Chief Counsel and the appropriate Division Counsel must brief the Deputy Chief Counsel (Operations) if the response is not issued within 180 days of submission.

06. The Associate office must in general coordinate the proposed response with the appropriate Division Counsel office prior to issuing the response. Doing so will allow the identification of any points requiring further development or discussion of any possible areas of disagreement prior to issuance. Any disagreements should be resolved using the procedures contained in CCDM 31.1.4.6, Reconciliation of Disputes.

07. A memorandum issued under this subsection must be addressed to the national program manager or Division Counsel executive who submitted the request. The Division Counsel should receive a copy of all memoranda issued to program managers under this subsection. The advice should be based on a representative set of amalgamated facts generally applicable to the industry segment or taxpayer class that gave rise to the request. Care should be taken to ensure that facts and figures derived from specific cases within the industry or taxpayer class are modified so that they do not reference a specific taxpayer.

08. Advice of this type is intended to be released to the public in its entirety. It should not contain any privileged material that will be redacted. When it is determined there is a need to address strategic advice, the development of a specific case, or litigation hazards, a separate memorandum may be sent to the program manager or the appropriate Counsel office.

09. As with other forms of legal advice, this type of legal advice does not set out official rulings or positions of the Service and may not be referenced in other documents as precedent. A subsequent decision to adopt a different position on the same or a similar issue will, therefore, not require the withdrawal or revocation of the prior legal advice memorandum. Instead, a new memorandum setting out the current advice should be issued. The Associate Chief Counsel executive may choose to include a reference to the prior memorandum to assist the Service in verifying that the more recent memorandum reflects the Associate office's current advice.

10. The checksheet that should be used to process this type of advice for release is contained in _Exhibit 33.1.2-2_.


**33.1.2.2.3.6** **(08-11-2004)**

##### Reconsideration of Legal Advice

1. It is not appropriate to withdraw or revoke legal advice once it is issued. Thus, following further reflection, the receipt of additional information, or new case law, new advice should be issued. The new advice should provide an analysis of the case based on the facts and law at the time the advice is reconsidered.


**33.1.2.2.4** **(07-30-2020)**

#### Legal Advice to Program Managers

1. The term "program manager" in this section includes all IRS employees who are not considered Field or Service Center employees of the Service.

2. Requests for legal advice by program managers in the business units will generally be handled by the appropriate Division Counsel. To the extent these requests involve matters where the law is unclear or Service position is not established, Division Counsel must coordinate with the appropriate Associate offices.

3. Where a request for legal advice principally concerns the interpretation of the Internal Revenue Code, a recently enacted Code provision, or the application of published guidance to a program, program managers may seek advice directly from the appropriate Associate office. Associate offices may choose in appropriate cases to issue such advice under the signature of the Associate Chief Counsel. When that is done, the procedures in _CCDM 33.1.2.2.3.5_ for Generic Legal Advice should be followed. Such advice should in general be coordinated with the appropriate Division Counsel.

4. Consistent with the considerations set out in _CCDM 33.1.2.2.2_ and _33.1.2.2.3.1_, legal advice to program managers may be provided orally or in writing, as appropriate.

5. Legal advice to a program manager by an Associate office will be provided to the National Taxpayer Advocate upon request. In rare instances, the advice can be withheld from the National Taxpayer Advocate by the Chief Counsel upon consultation with the Commissioner of Internal Revenue. When this occurs, the Chief Counsel will inform the National Taxpayer Advocate within 30 days from the date of the advice was issued or requested by the National Taxpayer Advocate.

6. Legal advice to a program manager by an Associate office will be released to the public when the advice is provided in a formal written memorandum.

7. In general, Associate office attorneys will provide legal advice requested by office heads who report to the Commissioner of Internal Revenue (including the National Taxpayer Advocate) or the Deputy Commissioners in a formal written memorandum. The Associate office with primary responsibility for providing the legal advice will simultaneously furnish a copy of the advice to the National Taxpayer Advocate. See _CCDM 33.1.2.4.2_ regarding additional procedures for providing legal advice to the National Taxpayer Advocate.

8. The standards for disseminating legal advice that has been released to the public are set out in CCDM 33.1.3.3. These standards also apply to the dissemination of legal advice issued to program managers described in this section.

9. Formal written memorandum provided this section should be in the format outlined in _CCDM 33.1.2.2.3.3_, Format of Legal Advice, and must be processed for release as Legal Advice to Program Managers following the directions in _Exhibit 33.1.2-1_.


**33.1.2.3** **(08-11-2004)**

### Legal Advice Prepared in the Field and Reviewed by an Associate Office

1. This subsection provides instructions for processing for public inspection legal advice prepared by the field and reviewed in the Associate offices. These procedures are for memoranda reviewed prior to issuance, although in unusual circumstances memoranda may be sent for review after issuance.


**33.1.2.3.1** **(08-11-2004)**

#### Format for Advice

1. After the advice is reviewed by an Associate office and issued by the Field, it will be made available for public inspection after appropriate deletions are made. To make the redaction and disclosure of these memoranda to the public easier, the same format used to prepare Chief Counsel advice may be used for this advice. See _CCDM 33.1.2.2.3.3_, Preparation of Legal Advice. The legal advice memorandum macro is available to facilitate the preparation of these memoranda using this format.

2. The name and signature of the person signing the advice, and any contact person named in the memorandum, generally will not be deleted from the document that is made available for public inspection unless it would establish the identity of the taxpayer.


**33.1.2.3.2** **(04-12-2013)**

#### Procedures for Requesting Associate Office Review

1. Requests for Associate office review of legal advice prepared in the Field are to be submitted as an attachment to an email message, using normal sensitivity, to the TSS4510 mailbox. Also, any background material needed by the Associate office to review the advice that is not in electronic format should be sent by express mail to the Technical Services Support Branch, Office of the Chief Counsel, Internal Revenue Service, CC:PA:LPD:TSS, Room 5329, 1111 Constitution Avenue, N.W., Washington, D.C. 20224. The assigned attorney in Field Counsel should send copies of the request for Associate office review through their own reviewers consistent with Division Counsel procedures. The Associate office will review the advice and complete the documentation described below in 15 calendar days. The time period for the Associate office to respond may be extended after consultation with the Field, for a time period not to exceed an additional 14 calendar days. Once review is completed, the Associate office attorney shall prepare a Response Form reflecting its consideration. See Exhibit 33.1.1-1, Field Advice Reviewed by the Associate Office Response Form.

2. Depending on the nature of the response the following process will be followed:



1. **Agreed:** If the Associate office attorney agrees with the Field Counsel’s memorandum, the Associate office attorney responsible for the review will orally inform the Field attorney that the advice has been approved and may be signed, dated, and issued to the Service field office. The Associate office attorney also will prepare and send by email a Response Form to reflect the concurrence.

2. **Modified:** If the Associate office attorney disagrees with the advice and believes that the advice should be modified, the Associate office attorney will orally communicate the recommended modifications to the assigned attorney in Field Counsel, prepare the Response Form, and email them the form. If Field Counsel agrees with the modification, the advice will be revised by the assigned attorney in Field Counsel, signed, dated, and issued to the Service field office. If the Associate office attorney disagrees with the advice and believes it cannot be modified (i.e., the advice should not be issued), the Associate office attorney will orally inform Field Counsel that the request for Associate office review should be withdrawn and Field Counsel should not issue the advice to the Service field office. If Field Counsel does not agree with the Associate office attorney’s recommendation, the disagreement must be reconciled pursuant to established procedures.

3. **Converted:** If the Associate office attorney believes the advice submitted would be more appropriate if issued as legal advice or as published guidance, the Associate office attorney will orally notify Field Counsel and discuss the appropriate form for the advice. If the decision is to continue the review of the field advice and issue additional legal advice or a form of published guidance, the procedures in A or B above will be followed with respect to the field advice. Note that the procedures in B may be appropriate if it is anticipated that the published guidance cannot be issued in time to resolve the matter addressed in the memorandum. If the decision is that field advice should not be issued and that another form of advice or published guidance is more appropriate, the Associate office attorney will memorialize that decision in a Response Form, email the form to the assigned attorney in Field Counsel, and copy TSS 4510 on that email.


3. TSS 4510 will close the existing assignment and open a new assignment with the correct category if the decision is made to issue legal advice. If the decision is made to issue published guidance, the Associate office will open an appropriate case.

4. Field Counsel will contact the Service field office requesting the advice and advise them of the decision. If supplemental information is needed by the Associate office attorney, the request for information from Field Counsel should be made as soon as practicable.

5. Field advice reviewed under these procedures will be made available to the public pursuant to procedures set out in _CCDM 33.1.2.5_, Processing Legal Advice for Public Inspection.


**33.1.2.4** **(01-19-2021)**

### Advice to Taxpayer Advocate Service

1. These procedures set forth guidelines for providing legal advice to the Taxpayer Advocate Service (TAS) that apply to all Field Counsel and Associate offices. Additionally, Associate offices must provide comments on TAS legislative proposals and other matters through the Office of the Division Counsel/Associate Chief Counsel (National Taxpayer Advocate Program) (CC:NTA).


**33.1.2.4.1** **(04-12-2013)**

#### Legal Advice Requests from TAS

1. TAS’s procedures for requesting legal advice are found in IRM 13.1.10, Special Processes.


**33.1.2.4.2** **(01-19-2021)**

#### Responsibility within Counsel for Providing Legal Advice

1. Chief Counsel is responsible for providing legal advice and support to TAS for the fulfillment of its mission, whether the support relates to the casework or the systemic advocacy function. In many cases, TAS often needs expedited legal advice regarding the applicable law, the rights of the taxpayer, and the responsibilities of the Service. TAS may also request advice about what assistance, if any, TAS legally may provide in a given situation. In cases involving advocacy issues, TAS may request guidance in understanding existing law and procedure or require advice regarding the legal and policy implications of alternatives TAS may propose.

2. Generally, the attorneys assigned to Division Counsel (SB/SE) will provide legal advice to TAS local offices. In every Field office, there is an SB/SE manager or senior attorney designated as the point of contact for providing advice to TAS. The list of SB/SE contacts can be found on the Division Counsel/Associate Chief Counsel (National Taxpayer Advocate Program) website. The local SB/SE contact will be responsible for providing advice for all legal issues that relate either to SB/SE or Wage & Investment (WI), formulating and referring matters for coordination with the Associate offices, and coordinating legal services with other offices. When TAS employees raise Large Business and International (LB&I) or Tax Exempt and Government Entities (TEGE) issues, the SB/SE contact must coordinate the response with the respective Area Counsel for LB&I or TEGE, or refer the case for assignment through the Area Counsel for LB&I or TEGE.

3. Advice on issues involving personnel, labor, and procurement should be requested from General Legal Services (GLS). Similarly, advice on criminal tax matters should be requested from Criminal Tax (CT). The lists of local GLS and CT contacts can be found on the CC:NTA website.

4. The Office of the CC:NTA primarily provides legal advice to the National Taxpayer Advocate and TAS headquarters employees. On occasion, the CC:NTA also provides legal advice to TAS local offices. When issues under the jurisdiction of the CC:NTA are referred to the SB/SE contact, the request must be handled pursuant to the provisions in _CCDM 33.1.2.4.3.1_, Coordination of TAS Advice with CC:NTA or Associate Offices. The following issues are under the exclusive jurisdiction of the CC:NTA:



1. IRC § 7803(a)(3) and (c), including the Local Taxpayer Advocate’s discretion not to disclose information to the IRS under IRC § 7803(c)(4)(A)(iv)

2. IRC § 7811

3. IRC § 7526

4. Taxpayer Advocate Directives

5. The scope of TAS’s statutory authority or delegated authority

6. Issues regarding TAS legislative proposals or any other matter related to the NTA’s annual reports to Congress


5. The Office of Chief Counsel will respect the confidentiality of information provided by TAS. When TAS requests that particular information is to be kept confidential and confined to a specified Counsel attorney or office, that Counsel attorney or office will not disclose information to other Counsel attorneys or offices or to the IRS or other third parties. In rare instances, after consultation with the National Taxpayer Advocate, CC:NTA may inform the Chief Counsel or a Deputy Chief Counsel of that information if the NTA intends to take a public position adverse to the position of the Office of Chief Counsel.


**33.1.2.4.3** **(08-31-2010)**

#### Procedures for Providing Legal Advice to TAS

1. In general, legal advice procedures for TAS will be the same as for other legal advice provided by Counsel. The SB/SE contact will determine whether advice can be given directly or whether consultation with the Associate offices is necessary.

2. When a taxpayer is involved in tax litigation with the Service or the United States (whether in the Tax Court, the U.S. Court of Federal Claims, a U.S. Court of Appeals, a U.S. district court, the U.S. Supreme Court, or a federal bankruptcy court), jurisdiction over the case rests with either the Office of Chief Counsel or the Department of Justice, and the litigation matter is assigned to an attorney in the appropriate office. Once a taxpayer becomes involved in this litigation, TAS employees have no jurisdiction over the issues involved in the litigation. Thus, if a TAS employee contacts a Counsel employee for assistance after litigation has commenced, the Counsel employee will remind the TAS employee that TAS does not participate in the litigation process and that the taxpayer (or the taxpayer’s representative) must be referred to the attorney assigned to the case. If the Counsel employee learns that the taxpayer is not represented in the litigation, the Counsel employee will remind the TAS employee that the taxpayer may be eligible for representation from a Low Income Taxpayer Clinic. See Publication 4134 for a list of organizations that receive a low income taxpayer clinic matching grant from the IRS. A Counsel employee may not direct the TAS employee to a specific clinic.


**33.1.2.4.3.1** **(07-30-2020)**

##### Coordination of TAS Advice with CC:NTA or Associate Offices

1. When it is not clear whether the Associate offices should be consulted about a TAS specific issue, contact the CC:NTA for further guidance.

2. Advice that is given directly by SB/SE, GLS, or CT Counsel to TAS should not be forwarded to the CC:NTA unless TAS disagrees with the advice and wishes to elevate the matter.

3. Generally, the form, content, and coordination of TAS advice requests with the CC:NTA or Associate offices should follow procedures outlined in _CCDM 33.1.2.2.3_, General Procedures for Legal Advice from Associate Chief Counsel, as appropriate. The request should be sent to the Technical Services Support Branch as described in those procedures and should be clearly identified as a request for TAS advice. TSS will:



1. Assign the request to the CC:NTA or the Associate office primarily responsible for providing the response

2. Provide a copy of the request to the CC:NTA, if the CC:NTA is not primarily responsible for providing the response based on subject matter jurisdiction

3. Enter the TAS aspect code in order that case assignments may be appropriately tracked


4. If legal advice is provided by an Associate office in a formal written memorandum, the Associate office with primary responsibility for providing the legal advice will provide a copy of the response to the CC:NTA and to the Division Commissioner of the operating division or the head of any other Service component that may be affected by the legal advice. See CCDM 31.1.4.1.


**33.1.2.4.3.2** **(08-31-2010)**

##### Time Frames for Requests for TAS Advice

1. To prevent taxpayers from experiencing further delay in having their issue(s) resolved, it is important that the assigned attorney ascertain when a response is necessary and whether the request for assistance from TAS should be expedited. The normal timeframes established in the business rules or by management for requests for legal advice often do not apply; in general, by the time a taxpayer comes to TAS for assistance, time is of the essence. When an expeditious response is required, Counsel will make every reasonable effort to provide such assistance in a timely manner. At all times, Counsel should be keeping TAS informed as to the status of the advice.

2. To avoid delay in getting the taxpayer’s issues resolved, determine whether the inquiry may be timely and informally answered without a written response ( _i.e._, a memorandum). If the request is handled informally, the procedures at _CCDM 33.1.2.1_, Informal Advice, should be followed.

3. Upon receipt of any written request for advice from TAS, or an oral request if a written response will be provided, the assigned attorney will:



1. Promptly contact the requesting TAS office to confirm receipt and determine when a response is needed

2. Provide written notification, whether by fax, e-mail, or memorandum, to the requesting TAS office that includes the name and telephone number of the attorney assigned to the request and the anticipated completion date

3. Notify the manager if the employee anticipates any delay in meeting the agreed upon date, the reasons for the delay, and the anticipated length of the delay. If the manager decides that a delay in the response is unavoidable, the manager shall promptly notify the requesting TAS office of the anticipated delay, the reasons for the delay, and the expected response date.


### Note:

The manager must make sure that the case is opened and assigned as a nondocketed case with a TAS aspect code.

4. .If the requesting TAS office disagrees with advice provided by the Counsel office to which the request for advice was directed, the Local Taxpayer Advocate should first discuss the advice with the Field Counsel attorney who provided the advice and, as appropriate, the attorney's manager. If no agreed resolution is reached following those discussion(s) and the TAS manager believes further review of the advice is warranted based, for example, on the difficulty or importance of the issue or case, or due to the nature of the taxpayer's complaint or request for assistance might reasonably be perceived as raising a question about impartiality, after consultation with the TAS Area Director, the matter should be brought to the attention of the Special Counsel to the NTA (CC:NTA). CC:NTA will thereafter coordinate, as necessary, with the appropriate Division Counsel or Associate Chief Counsel office(s) to ensure the matter is appropriately reviewed.


**33.1.2.4.3.3** **(11-07-2007)**

##### Local Taxpayer Advocate’s Discretion Not to Disclose

1. IRC § 7803(c)(4)(A)(iv) provides Local Taxpayer Advocates (LTAs) the discretion not to disclose to the rest of the IRS, taxpayer contact or taxpayer provided information.


**33.1.2.4.3.3.1** **(08-31-2010)**

###### Scope of LTA’s Discretion

1. The discretion not to disclose taxpayer contact or taxpayer-provided information to the IRS rests with LTAs and the supervisory levels above the LTA. TAS employees below the LTA level cannot exercise this discretion. The discretion not to disclose:



   - Applies to taxpayer contact (or representative) and to any information provided by the taxpayer (or representative)

   - Is limited to the withholding of information from the IRS

   - Does not apply to non-IRS entities such as the Department of Justice, the Treasury Inspector General for Tax Administration, the Government Accountability Office, or the United States Attorney’s Office

   - Does not except LTAs from requests submitted through the Freedom of Information Act (FOIA) or compulsory process, e.g., court orders and subpoenas

   - Provides no basis for withholding information required to be disclosed under IRC § 6110 and FOIA


2. With the exception of criminal and fraudulent acts discussed below, the determination of what taxpayer provided information to withhold from the IRS and what to disclose is a determination to be made by the LTA. TAS procedures require that TAS employees provide all pertinent information to the IRS with regard to any assistance request made on the taxpayer’s behalf, not just the information beneficial to the taxpayer.

3. IRC § 7214(a)(8) requires all Federal employees who have knowledge or information of violations of the Internal Revenue laws, to report such violations in writing to the Secretary of the Treasury. (Treas. Reg. § 301.7214-1 provides that the violation should be reported to the Commissioner). Failure to report such violations could result in termination, fines, or imprisonment. The discretion not to disclose taxpayer contact or taxpayer provided information does not extend to the reporting of criminal violations and acts of fraud against the United States under the Internal Revenue laws. The current policies and procedures of the NTA for implementing IRC § 7803(c)(4)(A)(iv) requires the reporting of criminal violations or fraud committed under the internal revenue laws consistent with IRC § 7214(a)(8).



### Note:



For more information about the LTA’s discretion not to disclose, see IRM 13.1.5 , Taxpayer Advocate Service (TAS) Confidentiality.


**33.1.2.4.3.3.2** **(11-07-2007)**

###### Role of Counsel in the Section 7803(c)(4)(A)(iv) Context

1. Chief Counsel attorneys providing advice and support to TAS regarding identified or identifiable taxpayers will not share information obtained from TAS with other divisions or functions of the IRS. Disclosure within Counsel does not constitute disclosure to the IRS within the meaning of IRC § 7803(c)(4)(A)(iv). Counsel attorneys providing assistance to TAS will refrain from disclosing to any other function within the IRS any of the information provided by TAS, including the identity of the taxpayer seeking assistance from TAS. If you do need to discuss this case with the IRS, please contact the CC:NTA first for guidance.

2. Field Counsel previously providing advice to TAS regarding a particular taxpayer or tax case should not generally be assigned an advisory request on the same taxpayer from another IRS division or function, if the LTA assigned to the case has exercised the discretion not to disclose taxpayer information to the IRS. The attorney’s manager must assign another attorney who was not involved with the earlier TAS advisory.

3. In providing advice to TAS, where applicable, Field Counsel should identify to the LTA any information establishing a criminal violation or an act of fraud against the United States and inform the LTA of the potential reporting issue under IRC § 7214(a)(8). The decision whether to report the violation or transaction under IRC § 7214(a)(8) or to extend confidentiality rests with the LTA, not Counsel. Where the LTA is following the policies and procedures established by the NTA, the obligation of Field Counsel is complete upon advising the LTA that information that would normally have to be reported under IRC § 7214(a)(8) exists or appears to exist and a subsequent response from the LTA indicating that a IRC § 7803(c)(4)(A)(iv) determination has been made in accordance with the policies and procedures established by the NTA.

4. In any instance where it is clear to Field Counsel that the LTA has failed to adhere to the NTA’s policies and procedures regarding criminal violations or acts of fraud reportable under IRC § 7214(a)(8), the attorney will report any such violation to the CC:NTA and the CC:NTA will report the violation to the NTA for appropriate action, with a copy to the Deputy Chief Counsel (Operations).


**33.1.2.5** **(08-11-2004)**

### Advice to Internal Revenue Service Campuses

1. This subsection contains additional procedures relating to legal advice to Internal Revenue Service Campuses. Internal Revenue Service Campus or Service Campus as used in this subsection includes the Submission Processing or Customer Service Campuses, as well as the Martinsburg and Detroit Computing Centers.

2. Legal advice to Service Campuses is provided using the same guidelines and procedures as set forth for legal advice in general. The legal advice program for Service Campuses is, however, distinct in several ways:



1. Local field counsel in SB/SE is responsible for providing advice to Service Campuses through a visitation program described below;

2. Field Counsel must be alert to matters that are more appropriate for Associate office attorneys to address. Additionally, field Counsel who advise these campuses should provide assistance to Associate office attorneys in implementing any legal advice provided;

3. Attorneys rendering advice under these procedures must determine the appropriate way to deliver such advice so as to have the desired effect on Campus procedures or processes. This may involve identifying the appropriate Service analyst in order to make processing or IRM changes. Additionally, such advice may be rendered informally or may result in an IRM change as opposed to formal legal advice; and

4. Attorneys who render advice to Service Campuses are encouraged to coordinate issues among themselves through the Service Campus Advice Network. This coordination is facilitated by Division Counsel (SB/SE).


**33.1.2.5.1** **(08-11-2004)**

#### Service Campus Legal Advice Procedures

1. Except as indicated above, legal advice procedures for Service Campuses will be the same as for other legal advice provided by Counsel. Local Field Counsel will determine whether advice can be given directly or consultation with the Associate offices is necessary using the criteria in CCDM 33.1.1.2, Role of Field Counsel in Providing Legal Advice.

2. Advice provided by the Associate offices to Service Campuses will address the interpretation or application of the internal revenue laws generally and is not intended to assist in the resolution of a specific taxpayer’s case. Informal advice and coordination are encouraged.

3. In general, Service Campus advice



   - Is not taxpayer-specific and does not contain any other information that is protected from disclosure under the provisions of IRC § 6103

   - Does not include settlement guidelines, analyses of litigation hazards of current or proposed Service positions, or similar information

   - Does not ordinarily include investigative tolerances, prosecutorial criteria, or similar information

   - May discuss differing or inconsistent points of view on an issue, but should not attribute them to particular individuals or offices


4. All advice provided to Service Campuses that has been coordinated with the Associate offices and related Service functions will be distributed to the appropriate Service personnel who are responsible for writing the procedures governing Service Campus operations. Counsel personnel who are responsible for providing advice to Service Campuses will assist in this process of implementing the advice and will have primary responsibility for dealing with the Service Campus.

5. Legal advice rendered by the Associate offices regarding Service Campuses is processed for public release as Chief Counsel advice, and this advice should be disseminated in the same fashion as Chief Counsel advice. See CCDM 33.1.3.3, Dissemination of Chief Counsel Advice.


**33.1.2.5.2** **(08-11-2004)**

#### Field Counsel Procedures — Advice to IRS Campuses

1. Each Field Counsel office designated to serve a Service Campus should take the initiative to inform the appropriate Service Campus personnel of the availability of Counsel assistance and of the manner in which requests for advice should be submitted. Field Counsel managers and attorneys should meet regularly with the appropriate Service Campus personnel to establish a relationship with these Campuses.

2. The Field Counsel office receiving a request for advice from a Service Campus has the initial responsibility to determine whether the advice should be rendered informally or formally or whether the advice sought must be coordinated with the Associate offices. Campus personnel are not expected to make this determination, although the requester may be asked to provide factual information that will assist in the classification (e.g., How many cases in the Service are believed to raise the issue? Do other Service Campuses have similar cases? Is the issue related to the design of a program intended to deal with a significant number of cases?). When in doubt as to whether an issue must be coordinated with the Associate offices, Field Counsel should coordinate with the Associate offices.

3. Copies of any written advice that are provided to the Service Campuses directly by Field Counsel should be sent to the CAS Manager, Headquarters, SB/SE Counsel, Customer Accounts Manager (SB/SE), and Division Counsel (W&I). This will permit the identification of emerging issues or trends that might not be apparent to individual Counsel offices and will ensure that the advice was appropriate for field advice. Field advice to Service Campuses will not be digested, indexed, maintained, or cited as precedent for the resolution of future cases.


**33.1.2.5.3** **(03-23-2011)**

#### Transmitting Associate Office Advice to Service Campuses

1. Field Counsel is responsible for providing specific advice to the Service Campus based on the Associate office’s response. If additional taxpayer specific advice would be helpful to the IRS Campus in handling the particular matter that gave rise to the request, Field Counsel should provide separate advice. A copy of any separate memorandum should be provided to W&I, LB&I, TEGE, and SB/SE Division Counsel, as appropriate.


**33.1.2.5.4** **(08-11-2004)**

#### Division Counsel Procedures for Advice Requests from IRS Division Commissioners

1. Generally, all requests for advice regarding Service Campus issues from Division Commissioner functions, including all headquarters or program functions within the Division Commissioner’s office, are to be sent to Division Counsel, who will coordinate or provide legal advice as appropriate. Division Counsel will:



   - Provide any required coordination of the request among the IRS Division and those executives responsible for the Service Campus and Computing Center operations

   - Provide a copy of the request to the Local Counsel principally servicing that Campus if the request involves a particular Service Campus or Computing Center

   - Coordinate the request, as appropriate, with the Associate offices


2. When a request for legal advice is coordinated with the Associate offices, Division Counsel will provide specific advice to the SB/SE & W&I executives responsible for the Service Campus or Computing Center operations and will work with the SB/SE and W&I executives responsible for Service Center operations to incorporate the advice, as appropriate, into Service procedures.


**33.1.2.5.5** **(08-11-2004)**

#### Service Campuses Requests for Advice Received by Associate Offices

1. Service Campuses may request advice directly from the Associate offices. Any requests that could have been handled by local Field Counsel should be referred to local Field Counsel for response. If the request is one that these procedures require be referred to an Associate office, the Associate office will consult with the appropriate Division Counsel on how to handle the request. If it is decided that legal advice from the Associate offices is desirable, the request will be treated as a request for advice in accordance with the procedures set forth in _CCDM 33.1.2.2.2_, Coordination of Legal Advice with Associate Chief Counsel, and _CCDM 33.1.2.2.3_, General Procedures for Legal Advice from Associate Chief Counsel, and a response will be provided directly to the requestor. If not, the request will be returned to the Campus with an explanation of why advice is not being provided.


**33.1.2.6** **(08-11-2004)**

### Abusive Tax Schemes

1. \[Reserved\]


**33.1.2.7** **(06-02-2014)**

### Ex Parte Communication Rules Applicable to Advice to Appeals

1. Section 1001(a) of the IRS Restructuring and Reform Act of 1998, Pub. L. No. 105-206, 112 Stat. 685, required the Service to establish guidelines to ensure an independent Appeals function, including the prohibition of ex parte communications between Appeals employees and other Service employees to the extent that these communications appear to compromise the independence of Appeals.

2. Appeals has broad authority to negotiate settlements by applying a "hazards-of- litigation" standard. Under the guidelines of Revenue Procedure 2012-18, 2012-10 I.R.B. 455 (March 5, 2012), ex parte communications concerning the substance of a case, _i.e._, beyond mere ministerial, administrative, or procedural matters, are prohibited unless the taxpayer or the taxpayer’s representative has been given a reasonable opportunity to participate in the communication either in person or by conference call.

3. Appeals will continue to be able to obtain legal advice from the Office of Chief Counsel, subject to limitations designed to ensure that the advice to Appeals is not provided by the same attorney who previously gave advice on the same issue in the same case to the Service officials who made the determination Appeals is reviewing.


**33.1.2.7.1** **(06-02-2014)**

#### Ex Parte Communications

1. Ex parte communications are communications between any Appeals employee (e.g., Appeals Officers, Appeals Team Case Leaders, Appeals Tax Computation Specialists) and employees of other Service offices, without the participation of the taxpayer or the taxpayer’s representative. Ex parte communications may be oral or written, manually or computer-generated.

2. Ex parte communications are prohibited to the extent that the communications appear to compromise the independence of Appeals. Whether a communication appears to compromise the independence of Appeals depends upon the nature of the communication. Generally, Appeals may ask Service employees questions that involve ministerial, administrative, or procedural matters and do not address the substance of the issues or positions taken in the case.

3. The following inquiries by Appeals employees are not prohibited ex parte communications (see section 2.03(2)(a) of Rev. Proc. 2012-18 for additional examples):



1. Questions about whether certain information was requested and whether it was received

2. Questions about whether a document referred to in the work papers that the Appeals Office cannot locate in the file is available

3. Clarification of the content of illegible documents or writings

4. Questions about case controls on the Service’s management information systems

5. Questions relating to tax calculations that are solely mathematical in nature


4. Prohibited ex parte communications, unless the taxpayer is given the opportunity to participate, include:



1. Discussions about the accuracy of the facts presented by the taxpayer and the relative importance of the facts to the determination

2. Discussions of the relative merits or alternative legal interpretations of authorities cited in a protest or in a report prepared by the originating function

3. Discussions of the originating function’s perception of the demeanor or credibility of the taxpayer or taxpayer’s representative

4. Discussions of the originating function's views concerning the level of cooperation (or lack thereof) of the taxpayer/representative during the originating function's consideration of the case

5. Discussions regarding the originating function's views concerning the strengths and weaknesses of the case or the parties' positions in the case

6. Communications from the originating function to advocate for a particular result or to object to a potential resolution of the case or an issue in the case


5. The taxpayer/representative may waive the prohibition on ex parte communications. If the taxpayer/representative is given an opportunity to participate in a discussion, but decides not to participate, the prohibition is waived. Generally, a waiver will be granted on a communication-by-communication basis. Alternatively, the waiver could encompass all communications that might occur during the course of Appeals’ consideration of a specified case.


**33.1.2.7.1.1** **(06-02-2014)**

##### Counsel Exceptions to Ex Parte Communications

1. Generally, the restriction on ex parte communications does not apply to field reviewers or national office attorneys and reviewers when advising Appeals. See _CCDM 33.1.2.7.3(2)a_, Legal Advice in Nondocketed Cases.

2. Counsel-to-counsel communications are never considered ex parte communications.


**33.1.2.7.2** **(06-02-2014)**

#### Advice in Docketed Tax Court Cases

1. The limitations on ex parte communications do not apply to communications between Counsel and Appeals in connection with cases docketed in Tax Court, with the exception of remanded CDP cases discussed in _CCDM 33.1.2.7.2.1_, Communications Regarding Collection Matters, below. Docketed cases will be handled in accordance with Rev. Proc. 87-24, 1987-1 C.B. 151, including any successor procedures, and the Tax Court Rules.

2. Cases docketed in district court or the Court of Federal Claims do not fall within the docketed case exception. However, the ex parte communication rules do not apply to communications between the Department of Justice and Appeals.


**33.1.2.7.2.1** **(06-02-2014)**

##### Communications Regarding Collection Matters

1. The ex parte communications prohibition also applies to Appeals’ consideration of cases involving collection matters, e.g., collection due process (CDP) appeals, collection appeals program (CAP) cases, offers in compromise, trust fund recovery penalty cases, etc. Appeals may not engage in discussions of the strengths and weaknesses of the issues and positions in the case, which would appear to compromise Appeals’ independence. The taxpayer/representative should be given an opportunity to participate in any discussion that involves matters other than ministerial, administrative, or procedural matters. IRC §§ 6320 and 6330, regarding due process in Service collection actions, state that, at a hearing, the Appeals Officer must obtain verification that the requirements of any applicable law or administrative procedure have been met. Communications seeking to verify compliance with legal and administrative requirements are similar to the ministerial, administrative, or procedural inquiries discussed in _CCDM 33.1.2.7.1(3)_, Ex Parte Communications. Therefore, these communications are not subject to the prohibition on ex parte communications.

2. Although the ex parte communication rules do not apply to communications between Counsel and Appeals in docketed cases, the ex parte communication rules do apply in CDP cases that are remanded by the Tax Court for further consideration.



1. When a CDP case is remanded to Appeals, the trial attorney should prepare a memorandum to Appeals explaining why the court remanded the case, any special requirements in the court’s order, and what issues the court has ordered Appeals to address on remand.


       — The memorandum may include legal analysis or legal advice to the extent necessary to fully explain the court’s instructions.


       — The memorandum should not discuss the credibility of the taxpayer or the accuracy of the facts presented by the taxpayer.


       — A copy of the memorandum should be provided to the taxpayer or representative.

2. The trial attorney may communicate with Appeals regarding court deadlines and should monitor the matter to ensure court deadlines are met or appropriately extended.

3. The trial attorney may provide legal advice to Appeals in connection with the remanded CDP case without providing the taxpayer or representative the opportunity to participate.

4. The trial attorney should review the supplemental notice of determination before it is issued to the taxpayer for the limited purpose of ensuring compliance with the court’s remand order.


**33.1.2.7.3** **(06-02-2014)**

#### Legal Advice in Nondocketed Cases

1. Attorneys in the Office of Chief Counsel are expected to provide legal advice without bias in favor of either the Government or the taxpayer. Rev. Proc. 2012-18, § 2.02(1) (citing Rev. Proc. 64-22, 1964-1 C.B. 689). To balance Appeals employees’ need to obtain legal advice with the requirement that they avoid ex parte communications that would appear to compromise Appeals’ independence, the following limitations will apply to communications between Appeals employees and attorneys in the Office of Chief Counsel in cases not docketed in the United States Tax Court.

2. A field attorney should not communicate ex parte with Appeals employees regarding an issue in a case pending before Appeals if the field attorney personally provided legal advice regarding the same issue in the same case to the originating function ( _e.g._, Exam) or personally served as an advocate for the originating function regarding the same issue in the same case. Section 2.06(1) of Rev. Proc. 2012-18.



1. This restriction generally does not apply to field reviewers or national office attorneys and reviewers, unless those persons are essentially functioning like a field docket attorney.


3. If the restriction on ex parte communications applies, Counsel will assign a different attorney to provide assistance to Appeals.



1. It is permissible and appropriate for the newly assigned (second) attorney to see the advice previously given and to discuss the case with the first attorney if something is unclear or for any other reason.

2. There is no violation of the ex parte communication rules so long as the second attorney and the reviewer exercise independent judgment in rendering the advice to Appeals.

3. If the original attorney is best suited to advise Appeals, for example, because the original attorney is an expert on a particular matter, that attorney may provide advice to Appeals as long as the taxpayer or representative is given an opportunity to participate in the discussion.


### Example:

Field Attorney Flounder previously provided advice to Exam on a particular issue in the Jones case. The case was transferred to Appeals for consideration. Appeals submitted a request for legal advice to Counsel in the Jones case relating to the same issue about which Attorney Flounder advised Exam. Because Attorney Flounder provided advice to Exam regarding the same issue in the same case, Appeals’ request for legal advice should be assigned to another attorney. The assigned attorney may discuss the issue with Attorney Flounder and review Attorney Flounder’s case file and notes without violating the ex parte communication rules because the assigned attorney has a responsibility to evaluate the case independently.

4. The restriction on ex parte communications with Appeals only applies while Appeals is performing its duties of evaluating the strengths and weaknesses of the specific issues in specific cases and the overall hazards of litigation for those cases. If an Appeals employee is not functioning in that capacity, (e.g., preparing a statutory notice of deficiency), the restriction on ex parte communications does not apply. See _CCDM 33.1.2.7.4_, Review of Statutory Notices of Deficiency.

5. Appeals’ requests for legal advice will be handled as appropriate under the procedures in _CCDM 33.1.2.2.2_, Coordination of Legal Advice with Associate Chief Counsel.


**33.1.2.7.3.1** **(06-02-2014)**

##### Cases with Multiple Open Years

1. Cases can have long lives, with multiple participants with changing roles. Counsel attorneys must be especially careful to observe the ex parte communication rules in large cases with multiple open years for the same taxpayer. Open tax years may be under the jurisdiction of Exam, Appeals, Counsel or even the Department of Justice.



### Example:



Exam conducted an audit of Taxpayer with respect to Year 1 and transferred the case to Appeals upon the receipt of a protest submitted by Taxpayer. One of the issues in the case is a recurring accounting issue. Taxpayer and Appeals reached an agreement regarding the accounting issue with respect to Year 1. However, the issue is also present in Year 2, which is being audited by Exam. Taxpayer’s representative informs the revenue agent of the settlement of the accounting issue with Appeals and requests that Exam treat the issue the same way in Year 2. Since Year 1 is still open in Appeals because there are other unagreed issues, Appeals has not sent an Appeals Closing Memorandum to Exam describing the resolution of the accounting issue or offered Exam an opportunity to participate in a post-settlement conference. Consequently, under the ex parte communication rules, Exam may not discuss the accounting issue with Appeals unless Exam obtains a waiver from Taxpayer’s representative or provides the representative with an opportunity to participate in the discussion with Appeals.





### Example:



Appeals has completed its consideration of Year 1 without reaching an agreement with Taxpayer and is getting ready to issue a notice of deficiency for that year. Year 2 is currently under audit by Exam. Taxpayer’s representative informs the Appeals Officer that there is a net operating loss in Year 2, the amount of which has been agreed upon by Exam and the Taxpayer, and that the carryback of that NOL would affect the tax liability for Year 1. The Appeals Officer may communicate with Exam to verify the amount of the NOL carryback. This communication is considered ministerial and is permissible under the ministerial, administrative, and procedural matters exception to the ex parte communication rules.


**33.1.2.7.3.2** **(06-02-2014)**

##### Closing Agreements

1. Appeals may speak to Counsel attorneys regarding how to prepare closing agreements in nondocketed cases.

2. Advice regarding how to document a settlement does not interfere with the independence of Appeals because Appeals has finished the decision-making part of its process. Appeals is no longer considering the strengths and weaknesses of the case or the advisability of the settlement.

3. Counsel and Appeals are permitted to discuss the substance of a settlement to enable Counsel to draft the operative provisions of the agreement to properly reflect the terms of the settlement or advise Appeals on how to do so.


**33.1.2.7.3.3** **(06-02-2014)**

##### Global Settlement Initiatives

1. Appeals is permitted to collaborate with Compliance and Counsel to assist with the development of settlement initiatives by providing input to other IRS functions in generic discussion of issues and transactions.

2. An Appeals Technical Guidance Coordinator (ATGC), assigned to develop settlement parameters for an Appeals Settlement Guideline or Appeals Settlement Position, may seek Counsel’s advice even if the Counsel attorney assigned is a member of an Issue Practice Group that is responsible for the transactions and issues in question so long as the communication is not with respect to specific open cases.

3. General discussions between the ATGC and the Counsel attorney about the issues and analysis of reported opinions in cases no longer subject to Appeals’ consideration do not violate the ex parte communication rules.


**33.1.2.7.4** **(06-02-2014)**

#### Review of Statutory Notices of Deficiency

1. A statutory notice of deficiency prepared by Appeals reflects Appeals’ determination that an administrative settlement will not be reached with the taxpayer and the case will close unagreed. A statutory notice of deficiency represents the IRS’s determination of a taxpayer’s liability, not just the determination of Appeals.

2. It is Counsel’s responsibility to ensure that the statutory notice reflects the legal theories and positions that are consistent with the current IRS position. This includes providing advice on issues for inclusion in a statutory notice of deficiency for a proper determination of the tax liability relating to the transactions involved, regardless of whether the issue, position, or theory was previously considered by the revenue agent or Appeals.

3. This advice does not violate the ex parte communications rules, regardless of whether the attorney who authors the advice to Appeals previously advised Exam about the issues or case in question.



1. Appeals will continue to follow the principles found in Policy Statement 8-2 and the guidelines outlined in IRM 8.6.1, Conference and Issue Resolution, in deciding whether to raise any new issue recommended by Counsel.


4. If the field attorney who previously advised Exam on an issue recommends that a theory or adjustment be added to the statutory notice, the attorney’s manager should closely scrutinize the recommendation before approving the memorandum to Appeals setting forth that position.



1. Particular attention should be paid to recommendations previously advocated by Exam that were affirmatively rejected by Appeals during its consideration of the case.


5. If Appeals adopts Counsel’s recommendation, a meeting should be held between Appeals, Counsel, and the taxpayer or representative to explain any additional adjustments prior to issuing the notice of deficiency.



### Example:



Counsel Attorney Doe previously provided advice to Exam on a particular issue in the Smith case. The case was transferred to Appeals for consideration. The taxpayer and Appeals did not reach a settlement so Appeals submitted a draft statutory notice of deficiency to Counsel for review. The notice of deficiency does not raise the particular issue about which Attorney Doe had previously advised Exam. Attorney Doe is permitted to advise Appeals regarding the notice of deficiency without violating the ex parte communication rules, even though she previously provided advice to Exam in the Smith case. This is because Appeals’ independence is no longer a factor in this case because at this stage, Appeals is not functioning in its role to settle the case inasmuch as Appeals has decided to issue a notice of deficiency. Attorney Doe may even advise Appeals to add an adjustment relating to the particular issue about which Attorney Doe previously advised Exam, without violating the ex parte communication rules. Attorney Doe’s manager should closely review the additional adjustment before approving Attorney Doe’s recommendation to add the adjustment. If Appeals adopts Attorney Doe’s recommendation, a meeting should be held between Appeals, Counsel and the taxpayer or representative to discuss the additional adjustment.


**33.1.2.8** **(10-17-2016)**

### Review of Notices of Deficiency and Claim Disallowance

01. The authority to issue a deficiency notice rests with the Commissioner, Area Directors, Field Territory Managers, Service Campus Directors, and Appeals Team Managers. The role of the Field Counsel is to advise whether a deficiency notice should be issued, and if so, to make recommendations concerning the issues to be asserted and the wording of the determination. The criteria for submitting a Notice of Deficiency to Field Counsel for review are in IRM 4.8.9.9, Reviewing the Notice of Deficiency.

02. The review must verify the adequacy of the evidence in support of the proposed determination. The attorney should evaluate the validity of the proposed issues, gauge the extent to which the prospective Service challenge has been developed, and consider whether any additional matters should be noted. The standard for factual review is one of reasonableness: Have the key witnesses been interviewed and all appropriate statements obtained? Are the documents necessary to the issue in the file? Have any essential areas of inquiry been ignored? Occasionally, there are instances in which all that needs to be done is to show that the taxpayer has failed to substantiate deductions or exemptions.

03. When the Service has the burden of proof, the factual and evidentiary development should be complete. The Service should be able to present a prima facie case from the contents of the administrative file. The material should include a discussion of the nature and scope of the evidence and its expected effect on the taxpayer’s anticipated defenses. The factual development is critical; the answer will have to make allegations sufficient to support any affirmative relief sought.

04. If further investigation is required, the Field Territory Manager or Appeals Team Manager should be requested to have it made. The request should specify the remaining problems, identify the specific area of the inquiry as well as the documents required and the people to be interviewed, and offer consultation. When appropriate, use of summonses should be recommended.

05. Field Counsel should review the proposed deficiency in light of the pertinent law and purported facts without limitation to the particular theory proposed. If there is doubt as to Service position or disagreement with the issuing official over the stand to be made, advice should be sought from the appropriate Associate office.

06. Upon the receipt of a request for legal advice for a nondocketed case, the technical assistant, the attorney’s supervisor, and the docket attorney, will each verify the statutory bar date.

07. The proposed explanatory paragraphs should be carefully reviewed to make sure that the taxpayer will be adequately apprised of the nature of the adjustment and that all of the grounds necessary to support the determination are included. Citations to Internal Revenue Code sections are not required but, if provided, should be comprehensive. The deficiency shown should be the "statutory deficiency" and the notice should not refer to any years for which there has been an overassessment.

08. Only those alternative theories that result in smaller deficiencies than the primary theory may be mentioned in the notice. An intended alternative resulting in more deficiency than the primary theory could be switched to become the primary theory, or could be introduced in the answer, with a request for a larger deficiency.

09. Conflicting determinations may raise a question as to the presumptive correctness of the determination, particularly if made for the same taxable year of the same taxpayer. Some conflicting determinations do have to be made. For example, the determination that the income is includable for a taxpayer in each of two years or in respect of each of two taxpayers may be necessary to protect the revenue. It is a case-by-case decision. Doubtful instances should be resolved by Field Counsel.

10. **Amounts not subject to deficiency procedures**: The notice of deficiency should also be examined to make sure that the determinations made are subject to deficiency procedures. Various penalties which are not based on a deficiency, as that term is defined in IRC § 6211, are not subject to deficiency procedures. These include the penalties imposed under IRC § 6651 and 6654, including the fraud delinquency penalty under IRC § 6651(f), to the extent that they are imposed on amounts shown on a return filed by the taxpayer. See IRC § 6659 (IRC § 6665, for years after 1989). Other penalties not subject to deficiency procedures include information reporting penalties under IRC §§ 6721 through 6724, the promoter penalties under IRC §§ 6700 and 6701, and the tax shelter penalties under IRC §§ 6707 and 6708. These amounts should not be asserted in the notice of deficiency, but should instead be assessed immediately. Penalties that are subject to deficiency procedures, such as the accuracy-related and civil fraud penalties, should also be asserted, if appropriate. Amounts of liability ordered pursuant to a restitution order under 18 USC § 3556 are not subject to deficiency procedures pursuant to IRC § 6213(b)(5)(A). See IRC § 6204(a)(4)(A).


**33.1.2.8.1** **(04-12-2013)**

#### Additions to Tax

01. IRC § 6651(a)(2) authorizes the imposition of an addition to tax where, without reasonable cause, a taxpayer fails to pay the amount shown as tax on a return on or before the payment due date. Prior to the enactment of IRC § 6651(g), no comparable failure to pay penalty applied to taxpayers who did not file a return. Recognizing the inequity of imposing the failure to pay penalty on filers but not on nonfilers, Congress enacted IRC § 6651(g). IRC § 6651(g)(2) provides that, for returns due after July 30, 1996, an IRC § 6020(b) return will be treated as a return filed by the taxpayer for purposes of determining the IRC § 6651(a)(2) addition to tax.



    1. The Service prepares two types of IRC 6020(b) returns: Forms 13496 and Automated Substitute For Return (ASFR) Certifications. Either the Form 13496, IRC Section 6020(b) Certification, (when packaged with Form 4549, Income Tax Examination Changes, or Form 886-A, Explanation of Items) or the ASFR Certification (with accompanying 30-day letter) can be a valid IRC 6020(b) return if it identifies the taxpayer’s name and TIN, contains information to compute the taxpayer’s tax liability and is properly subscribed. See Treas. Reg. § 301.6020-1. IRC 6020(b) returns are prepared either by hand or through automated means. The name and title of an internal revenue officer or employee appearing on a IRC 6020(b) return suffices as a subscription adopting the document as the taxpayer’s return, whether the officer’s or employee’s name or title is handwritten, stamped, typed, printed, or otherwise mechanically affixed to the document, so long as the name was placed on the document to signify that the employee or officer adopted the document as a return for the taxpayer. The subscription, as well as the accompanying document or set of documents, may be in written or electronic form. See Treas. Reg. § 301.6020-1(b)(2) and CCDM 35.2.2.11, Answers in Failure to Pay (Section 6651(a)(2) Cases With a Substitute for Return Filed under Section 6020(b)).

    2. To meet the burden of production with respect to the IRC 6651(a)(2) addition to tax for a non-filer, the Form 13496 or ASFR Certification package that satisfies the above elements should be put into evidence. Whenever relying on automated or electronic certification or subscription, a citation to Treas. Reg. § 301.6020-1(b)(2) should be included in the pleading or other written document.

    3. Where all or part of the Form 13496 return or ASFR Certification package is not included in the administrative file, attorneys should contact the originating campus to provide documentation of the return. See CCDM 35.2.2.11, Answers in Failure to Pay (Section 6651(a)(2) Cases With a Substitute for Return Filed under Section 6020(b)). Where no Form 13496 or ASFR Certification package can be secured from the campus, attorneys should review the documents in the administrative file to determine whether there is a document or documents that would meet the elements of an IRC § 6020(b) return as set forth in the Tax Court’s opinions, _Cabirac v. Commissioner_, 120 T.C. 163 (2003) and _Spurlock v. Commissioner_, T.C. Memo. 2003-124. Before proceeding with an argument that documents other than Form 13496 or an ASFR Certification meet the definition of an IRC 6020(b) return, attorneys must coordinate with Branch 1 or 2, Procedure and Administration.


02. If the IRC § 6651(a)(2) addition to tax is to be conceded because documents comprising a IRC § 6020(b) return do not exist, attorneys should plead the increase in the amount of IRC § 6651(a)(1) addition to tax that results from the inapplicability of the IRC § 6651(c)(1) limitation on the amount of the IRC § 6651(a)(1) penalty. This additional amount may be forgone in "S" Cases where the amount is sufficiently small. The decision to forgo the increased IRC § 6651(a)(1) addition to tax must be approved by the trial attorney’s manager.

03. For returns, the due date of which is after December 31, 1989 (without regard to extensions), the accuracy-related penalty pursuant to IRC § 6662 imposes a 20 percent penalty on underpayments attributable to, among other things, negligence or disregard of rules and regulations.

04. The accuracy-related penalty can be applied only to a return that has been filed by the taxpayer. _See_ IRC § 6664(b).

05. Negligence includes any failure to make a reasonable attempt to comply with the provisions of the tax law, exercise ordinary and reasonable care in tax return preparation, keep adequate books and records, or substantiate items properly. _See_ Treas. Reg. §1.6662-3(b).

06. Disregard of rules or regulations relates to the taxpayer’s failure to follow the appropriate law in completing the return, and reflects a disregard of the Internal Revenue Code, temporary or final regulations, notices, or revenue rulings (other than notices of proposed rule making). The term "disregard" includes careless, reckless, or intentional disregard. A taxpayer who takes a position contrary to a revenue ruling or notice has not disregarded the ruling or notice if the position has a realistic possibility of being sustained on its merits.

07. The accuracy-related penalty attributable to negligence will not be asserted solely for filing a return late or solely due to the taxpayer’s failure to appear for an audit or respond to an inquiry or notice. The facts and circumstances from the return and the case file, however, may warrant assertion of the accuracy-related penalty attributable to negligence.

08. Reasonable cause exception: The accuracy-related penalty does not apply if the taxpayer has reasonable cause and acted in good faith, _i.e._, if an error was due to an honest misunderstanding of the facts or the law and the taxpayer took reasonable steps to comply with the law.

09. For returns, the due date of which is after December 31, 1989 (without regard to extensions), the civil fraud penalty pursuant to IRC § 6663 imposes a 75 percent penalty on the portion of the underpayment attributable to fraud.

10. The civil fraud penalty will be asserted when there is clear and convincing evidence to prove that some part of the underpayment of tax was due to fraud. Such evidence must show the taxpayer’s intent to evade the payment of tax which the taxpayer believed to be owing. Intent is distinguished from inadvertence, reliance on incorrect technical advice, honest difference of opinion, negligence, or carelessness.

11. The civil fraud penalty can be applied only to a return filed by the taxpayer. Where the taxpayer has fraudulently failed to file returns, the fraudulent failure to file penalty pursuant to IRC § 6651(f) should be applied.

12. The fraud penalty and the accuracy-related penalty cannot both be imposed with respect to the same portion of an underpayment. If the case does not involve collateral estoppel, it may be prudent to consider raising the appropriate equivalent and lesser penalties in the notice of deficiency as alternative determinations. Likewise, with the assertion of the fraud delinquency penalty (IRC § 6651(f)), the alternative of the regular delinquency penalty should be considered.


**33.1.2.8.2** **(08-11-2004)**

#### Net Operating Loss and Carrybacks

1. If the proposed notice covers a year for which there has been a tentative allowance resulting from a net operating loss carryback, the issue of the loss year is before the court if the taxpayer petitions from the tentative allowance year. If the loss year has not been audited and the Service wishes to examine the loss year, it should be asked to do it promptly after the issuance of the statutory notice. If the Service chooses to survey the year, a letter to that effect should be obtained. Thereupon the issue may be ignored.

2. If the taxpayer has not received a tentative allowance for the loss year, the issue will not be before the court unless raised in the petition. Nevertheless, the Service should be asked whether it wants to conduct an examination of the loss year.


**33.1.2.8.3** **(04-12-2013)**

#### Actions upon Receipt of Deficiency Notice for Review

1. The proposed deficiency notice should be reviewed expeditiously. Immediately upon its receipt, the manager and the assigned attorney in Field Counsel should verify the statutory bar date for each return in the administrative file. In determining the last day for timely assessments, they should consider the status of any Form 872-A, Special Consent to Extend the Time to Assess Tax. The proposed address should be verified as the last known address of each of the taxpayers. If the taxpayer is a corporation, the continued existence of the entity to which the notice is addressed should be verified. If the notice is to be sent to a successor or the parent of a group of corporations filing a consolidated return, the prospective recipient’s status should be confirmed.


**33.1.2.8.4** **(08-11-2004)**

#### Actions After Review of Deficiency Notice

1. **Unagreed Cases**: If the Field Counsel does not agree to the issuance of a statutory notice, the case should be returned to the referring office with a memorandum stating the reasons for the disagreement. If the file reflects a settlement offer Counsel views as reasonable, that view should be noted. If the disagreement is based upon inadequate factual development, the areas of inadequacy should be stated and the required remedial investigation should be specified. The Service is not bound by Counsel’s opinion of the merits of the proposed notice. Counsel should state whether the issuance of the notice is not recommended, either definitively, i.e., not at all, or conditionally pending further action. If Counsel returns a proposed notice to Appeals with a memorandum recommending that the notice not be issued in whole or in part, the Appeals Team Manager and the Associate Area Counsel will resolve the disagreement. If they fail to resolve the disagreement, it will be resolved by the Area Counsel with the advice of the Area Director of Appeals.

2. **Agreed Cases**: A proposed statutory notice is considered agreed if it is correct on its face or Field Counsel concurs that more tax is due. Counsel need not adopt the rationale of the initiating office or approve the RAR or supporting statement. Counsel is not barred from requesting a supplemental investigation. If Counsel favors different or additional grounds for the proposed deficiency, a brief explanation should be included in the recommendation memorandum principally as background material for any ensuing litigation.

3. Copies of all writings prepared during notice considerations should be kept for inclusion in the legal file if litigation results.


**33.1.2.8.5** **(08-11-2004)**

#### Munro Computations

1. At the time that a statutory notice of deficiency is issued it is unknown whether the case will be settled, tried or defaulted. Therefore, it is necessary to prepare such notices in accordance with _Munro v. Commissioner_, 92 T.C. 71 (1989), in all cases where nonpartnership items of the taxpayer are being adjusted but the taxpayer has also invested in an entity that is subject to the unified audit and litigation (TEFRA) provisions and that entity is the subject of an ongoing entity-level proceeding for the years at issue in the statutory notice of deficiency. Otherwise, if a case is defaulted and Munro computations were not used in preparing the statutory notice of deficiency, the Service will only be permitted to assess the amount of the deficiency and penalties that are reflected in the notice. IRC § 6213(c). Moreover, the Service may be precluded from assessing and collecting the differential deficiency at the completion of the TEFRA proceeding if the taxpayer subsequently challenges the assessment or collection of said differential deficiency on the ground that it is barred by the expiration of the statute of limitations. See CCDM Part 35, Tax Litigation, for additional guidance. The Munro computations apply for all years ending after the enactment of TEFRA on September 3, 1982.

2. **Munro Computations and Oversheltered Returns**. For years ending after August 5, 1997, the Munro computations continue to apply without change, except in the case of an oversheltered return. IRC § 6234 now permits a declaratory judgment action in Tax Court for nonpartnership items oversheltered by partnership deductions. Specifically, the procedure applies when a return shows no taxable income and a net loss from partnership items and, as a consequence, no deficiency in tax arises from an adjustment to nonpartnership items. Accordingly, the Service may issue a notice of adjustment, which adjusts nonpartnership items. If a TEFRA partnership proceeding subsequently causes the nonpartnership adjustments to result in tax, the tax attributable to the nonpartnership adjustments may be assessed as part of the computational adjustment of partnership items. The notice of adjustment is treated similarly to a notice of deficiency for purposes of the petition period, statute of limitations suspension, restrictions on issuing a second notice, etc. An adjustment notice that results in a deficiency in tax (as a result of a final determination of any partnership item for the taxable year) is automatically deemed to be a valid notice of deficiency. Similarly, a notice of deficiency that results in no deficiency in tax will automatically be deemed to be a proper notice of adjustment if the notice otherwise meets the criteria of IRC § 6234.


**33.1.2.8.6** **(04-12-2013)**

#### Review of Statutory Notices of Claim Disallowance

1. The procedure for reviewing proposed claim disallowances is the same as that for proposed deficiencies. See IRM 8.17.4, Notices of Deficiency .


**33.1.2.8.7** **(08-11-2004)**

#### Review of Notices of Determination of Worker Classification

1. The general principles applied in the review of notices of deficiency to determine the legal sufficiency of supporting information and documents also apply to Counsel review of notices of determination of worker classification under IRC § 7436, or any of the final adverse determination letters that taxpayers can petition under the declaratory judgment procedures of IRC §§ 7428, 7476, and 7478 that are within the subject matter responsibility of the Division Counsel/Associate Chief Counsel (TEGE).


**33.1.2.8.8** **(04-12-2013)**

#### Determination by Appeals

1. If after review of the proposed notice, claim disallowance, or final adverse letter, Field Counsel believes it should not be issued either in whole or in part, Field Counsel will return the case to Appeals with a memorandum setting forth its reasons. Where the Appeals Team Manager and the Associate Area Counsel cannot resolve a disagreement regarding the notice, claim, or letter, the disagreement will be resolved by the Area Counsel with the advice and assistance of the Area Director of Appeals.

2. In relatively uncomplicated nondocketed cases, Appeals may request informal assistance from Field Counsel when advice is needed as to the hazards of litigation, interpretation of the law, and/or evaluation of the evidence. This assistance will be provided through informal arrangements between each Field Counsel and Appeals office. See IRM 8.1.10, Ex Parte Communications, regarding limitations on ex-parte communications with Appeals. This informal procedure is not intended to take the place of, or alter in any way, technical advice procedures.

3. In large dollar and/or complex nondocketed cases, Appeals may request that such cases be informally considered by Field Counsel. In addition, Field Counsel may be asked to attend settlement conferences in nondocketed matters, but serve only in advisory roles. Counsel will cooperate in providing this assistance as long as resources and workloads permit. See IRM 8.1.10, Ex Parte Communications, regarding limitations on ex-parte communications with Appeals.


**33.1.2.8.9** **(08-11-2004)**

#### Second Statutory Notices

1. IRC 6212(c) precludes the Service from determining additional deficiencies after the taxpayer has filed a timely petition for the same years with the Tax Court. An exception exists for fraud. Also, mathematical or clerical adjustments as well as termination and jeopardy assessments may be made. _See_ IRC §§ 6213(b)(1), 6851, and 6861.

2. Additional deficiencies may be determined in the Tax Court under IRC § 6214(a), if by answer respondent raises new issues and requests increased deficiencies. If an increased deficiency is recommended after a deficiency notice has already been issued, no attempt should ordinarily be made to issue another notice during the period for filing a petition with the Tax Court. It is Service position that a statutory notice issued within 90 days after an earlier one becomes a nullity if the taxpayer files a timely petition from the first notice. If the taxpayer files a petition from the first notice, the additional issues can and should be raised in the answer with a request for an increased deficiency. If the taxpayer does not file a timely petition, a second statutory notice should then be issued for the additional deficiency. Care should be taken so that the period of limitations does not expire. _See_ Treas. Reg. §301.6503(a)-1.

3. IRC § 6212(d) now provides for rescission (which operates to rescind the whole notice and not a part thereof) if the parties mutually agree to the rescission. A rescinded notice cannot form the basis of a petition in the Tax Court.

4. If the statutory notice is returned undelivered because the taxpayer’s address has changed, the issuer should attempt to ascertain if a new address exists. If found, a new notice should be sent to obviate the contention that the Service did not do all it should have to send the notice to the taxpayer’s last known address. A second notice can only be sent if the period of limitations for assessment remains open.


**33.1.2.8.10** **(04-12-2013)**

#### Compliance with Section 7522 Notices to Taxpayers

1. IRC § 7522, effective for mailings made after January 1, 1990, provides that any notice, including notices of deficiency and notices of tax due, must describe the basis for and identify the amounts of the tax due, interest, additional amounts, additions to tax, and assessable penalties included in such notice. An inadequate description will not invalidate the notice. IRC § 7522 applies to any tax due notice or notice of deficiency under IRC §§ 6155, 6212, or 6303. It also applies to any notice generated out of any information return matching program (e.g., CP-2000 Underreporter Program).

2. The stated purpose of IRC § 7522 is to improve the clarity of explanations sent to taxpayers. H.R. Conf. Rep. No. 1104, 100th Cong., 2d Sess., pt. 2, at 219, 1988-3 C.B. 473, 481. While the statutory requirement is limited to enumerated notices, the conference report notes the desire of Congress that the Service make every effort to improve the clarity of all explanations sent to taxpayers. No details are provided as to what may or may not be a sufficient explanation other than inclusion of the information in the original notice sent to taxpayers; later copies of a particular notice to the same taxpayer need not contain the explanatory information if the Service determines that including it would be confusing. In the case of interest, it is sufficient if the notice states that interest at the legal rate is owing on the amount due.


**33.1.2.8.10.1** **(08-11-2004)**

##### Content

1. Prior to enactment of IRC § 7522, the courts had uniformly held that a notice of deficiency must do at least three things. First, it must inform the taxpayer that a deficiency has been determined. Second, it must specify the year for which the deficiency is asserted. Third, it must state the amount of the deficiency in unequivocal terms. Although the Service was not previously required to provide an explanation of the basis for a proposed deficiency, it has been the practice of the Service to do so. While the Service has maintained the practice of providing taxpayers with an explanation for the proposed deficiency, both in a 30-day letter and in a 90-day notice of deficiency, taxpayers or Counsel may challenge the explanation.

2. A notice of deficiency is not required to inform the taxpayer that statutory interest at the legal rate will apply to any deficiency determined (or redetermined) by the Commissioner or the Tax Court. The reason is that a notice of deficiency relates exclusively to deficiencies. Generally, interest is not subject to deficiency procedures. IRC § 6601(e)(1). The Service, however, includes a statement regarding the accrual of interest in each notice of deficiency. By contrast, a notice and demand under IRC § 6303 for tax and interest assessed would be subject to IRC § 7522 and must contain at least an explanation that interest included therein has been assessed at the legal rate.


**33.1.2.8.10.2** **(08-11-2004)**

##### Taxpayer Challenges

1. The intent of IRC § 7522 is to provide the taxpayer with a better explanation but not to permit the avoidance of tax legally due. Existing law as to what constitutes a notice of deficiency and the circumstances under which the burden is shifted to the Commissioner in a Tax Court proceeding generally remain unchanged. It is clear that the courts will not look behind the notice of deficiency to evaluate the procedures and evidence relied on to support the determination. Only in certain limited circumstances is the deficiency determination not accorded the presumption of correctness, shifting the burden of going forward to the Service. If the court determines that the notice of deficiency is arbitrary and excessive, i.e., it bears no factual relationship to the taxpayer’s liability, the burden of proof will shift. In determining whether a notice of deficiency is arbitrary and excessive, courts routinely refuse to examine the evidence used or the propriety of the Commissioner’s motives or administrative policy or procedure in making the determination.

2. Under IRC § 6201(d) the Service will have the burden of producing reasonable and probative information in a court proceeding if the taxpayer asserts a reasonable dispute with respect to an item of income reported to the Service on an information return. IRC § 7491 also provides for the shifting of the burden of proof under certain circumstances. IRC § 7491(c) places the burden of production on the Service in any court proceeding with respect to the liability of any individual for any penalty, addition to tax or additional amount imposed by the Internal Revenue Code.

3. Failure to comply with the requirements of IRC § 7522 in a notice of deficiency may also result in the IRS bearing the burden of proof. In _Shea v. Commissioner_, 112 T.C, 183 (1999), the Court held that if the basis on which the Service relies is not described in the notice of deficiency, and different evidence is required for that issue, the Service will bear the burden of proof on that issue.

4. Challenges can be expected in litigation involving both tax due notices and notices that relate to information return matching programs, such as where the taxpayer does not receive a deficiency notice and assessment of tax, penalty, and interest is made upon expiration of the 90-day period. While such notices are valid, district courts may assert equitable powers that include remedies such as shifting the burden of proof to the United States or striking a penalty that is not explained.


**33.1.2.8.10.3** **(04-12-2013)**

##### Field Counsel Responsibilities

1. Field Counsel attorneys who review deficiency notices prior to issuance should be sensitive to the mandate of IRC § 7522. This does not mean, for example, that explanation of a fraud penalty would require detailed reasons for its assertion. But, time permitting, it may be necessary to add a few sentences if the attorney feels that the description of the basis for the addition to tax is inadequate.

2. If a taxpayer raises the issue of the Commissioner’s failure to comply with IRC § 7522, whether in a Tax Court proceeding or in a district court refund action, the Field Counsel attorney responsible for preparing the Commissioner’s defense in the Tax Court or preparing the defense letter to the Department of Justice may seek informal advice from the Office of the Associate Chief Counsel (P&A). Any Tax Court pleadings, briefs, or motions should also be referred for review prior to filing. See CCDM 35.3.1.14, Motions to Shift the Burden of Proof; CCDM 31.1.1.2.3, Pre-Review of Litigation Documents by the Associate Chief Counsel; and Exhibit 31.1.1-1, Issues Requiring Associate Office Review.


**33.1.2.8.11** **(10-17-2016)**

#### Statutory Notices in Cases Having Criminal Aspects

1. Issuing a statutory notice may have an impact on a pending criminal case as outlined, in part, below. Thus, in cases in which the criminal case is pending with Field Counsel, the contents of the proposed statutory notice should be coordinated and reviewed by both the appropriate field office of the Division Counsel/Associate Chief Counsel (CT) and the appropriate field office of Division Counsel (LB&I), Division Counsel (SB/SE), or Division Counsel/Associate Chief Counsel (TEGE).

2. If the criminal aspects of the case are pending with the Department of Justice and the Field office, and the appropriate CT field office and the appropriate LB&I, SB/SE, and TEGE field office agree that a statutory notice should be issued to protect the civil liability, Field Counsel has discretion to communicate directly with the Department of Justice. In the event higher level coordination is desirable, the reviewed proposed statutory notice and a proposed letter to the Department of Justice should be sent to Division Counsel/Associate Chief Counsel (Criminal Tax).

3. Clearance with the Department of Justice is not required prior to action to solicit consents or issue statutory notices as to taxable years having no relationship to years included in the prosecution recommendation made to the Department of Justice or as to related taxpayers not included in such recommendation unless there are transactions involved which have a bearing on the criminal case. For Service policies and procedures regarding solicitation of consents, and issuance of statutory notices in pending criminal cases, including cases with the Department of Justice, see IRM 9.4, Investigative Techniques, and CCDM Part 38, Criminal Tax. Clearance is required for issuing statutory notices in instances where prosecution has been recommended for willfully failing to file income tax returns and the taxpayer has filed delinquent, nonfraudulent returns only if the fraud penalty is not determined in the statutory notice.

4. If a copy of a proposed statutory notice is forwarded to the Division Counsel/Associate Chief Counsel (Criminal Tax) for transmittal to the Department of Justice, it should first be reviewed and agreed to as to form and content by both the appropriate CT field office and the appropriate LB&I, SB/SE, and TEGE field office, which agreement should be noted in the transmittal to the Division Counsel/Associate Chief Counsel (Criminal Tax). The statutory notice adjustments should be consistent with the items in the criminal case.

5. The transmittal should be addressed to the attention of the Associate Chief/Division Counsel offices. Appropriate coordination will be made between the Criminal Tax and Associate Chief/Division Counsel offices on the clearance for issuance of the statutory notice, and the Associate Chief/Division Counsel offices will be furnished with copies of all clearance documents and letters.

6. The issuance of the statutory notice must be made with the realization that respondent will have to comply with the rules of the court and will lose control over the extent to which facts involved in the tax determination and facts in support of the fraud penalty can be kept from the taxpayer.

7. The court, however, may be willing to suspend proceedings such as trial and discovery to the extent the proceedings would prematurely disclose facts and prejudice the criminal case. Field Counsel should consider whether a motion to stay proceedings would be appropriate.

8. Once the criminal aspects of a case have been concluded, the decision to issue a statutory notice should be made by the appropriate civil first-line manager, after coordinating with the Criminal Tax Area Counsel. In the event the civil first-line manager proposes to concede, after coordination with the Criminal Tax Area Counsel, either:



1. The fact of fraud after the taxpayer has been convicted of IRC § 7201, or

2. The fact of delinquency after the taxpayer has been convicted of IRC § 7203, the appropriate Area Counsel (LB&I, SB/SE or TEGE) will make the final decision.


9. If a notice of deficiency is prepared for the same tax periods for which the federal district court orders restitution under 18 USC § 3556, field counsel must make sure that the notice of deficiency is not issued based on the amount ordered pursuant to a restitution order because an assessment of restitution is not subject to deficiency procedures. See IRC § 6213(b)(5). Taxpayers assessed an amount of restitution are precluded by IRC § 6201(a)(4)(C) from challenging the amount of restitution on the basis of the existence or the amount of the underlying tax liability. For those tax periods, a notice of deficiency should only be prepared with respect to the amount of tax liability and civil penalties determined by a subsequent civil examination. With respect to the penalties asserted, if any, a notice of deficiency must be issued only to the extent that the penalties are based on a deficiency. See _CCDM 33.1.2.8(10)_.


**33.1.2.8.11.1** **(08-11-2004)**

##### Exhibits in Criminal Tax Cases

1. If a notice of deficiency is issued, a set of exhibits to the Special Agent’s Report to the extent available will be forwarded to Field Counsel. The exhibits, whether with Criminal Investigation Division, the Department of Justice, or the United States Attorney, can be obtained by or made available for the use of Counsel, except in grand jury cases, when a Fed. R. Crim. P. 6(e) order will be needed.


**Exhibit 33.1.2-1**

### Format for Generic Legal Advice Memorandum

|  | **Office of Chief Counsel**<br>**Internal Revenue Service**<br>**memorandum** |
| --- | --- |
|  | CC:PA<br> POSTN-123456-06 |
| UILC: | 01.00.00-00 |
| **date:** | October 25, 2010 |
| **to:** | Industry Director , HMT<br> (Large Business and International) |
| **from:** | Associate Chief Counsel<br> (Procedure & Administration) |
| \\_\\_\\_\_\_\_ |
| **subject:** | \[Description of Issue\] |
|  | This memorandum addresses \[description of issue\]. This memorandum should not be used or cited as precedent. |
|  | ISSUES |
|  | CONCLUSIONS |
|  | LAW AND ANALYSIS |
|  | Please call me at (202) 622-3400 if you have any further questions. |
|  |  |
|  | cc: Division Counsel<br> Field Counsel |

**Exhibit 33.1.2-2**

### Checksheet for Processing Generic Legal Advice

| **Checksheet for Processing Generic Legal Advice** |
| :-: |
| Case Control Name: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |
| Case Control Number: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ | WLI # \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |
| Associate Office: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ | Date of issuance (signed): \_\_\_\_\_\_\_\_\_\_\_ |
| \_\_\_\_1. | Does the memorandum reflect the uniform issue list number(s)? |
| \_\_\_\_2. | Has the electronic version of the memorandum been submitted to CC:PA:LPD:DLS through Counsel’s content management system (Documentum)? (If the original memorandum was date-stamped, the date that the document was signed should be inserted directly below the letterhead on the electronic version.) To submit a document, click the "Submit" button on the lower right-hand side of the e-word toolbar to submit a document through Documentum. **A copy of the electronically generated receipt acknowledging the submission of the memorandum through Documentum must be placed in the office's official case file.** |
| \_\_\_\_3. | Forward a paper copy of the document and a paper copy of the completed checksheet to CC:PA:LPD:DLS (Rm. 5201) the day the document is submitted for processing. Place a copy of this checksheet in the office's official case file. |
| Initiator: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ | Date:\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |
| Reviewer: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ | Date:\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |

### Note:

Initiators and Reviewers are responsible for ensuring that these procedures have been followed and that the documents have been sent to CC:PA:LPD:DLS.

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part33/irm_33-001-002#addtoany "Show all")

A2A