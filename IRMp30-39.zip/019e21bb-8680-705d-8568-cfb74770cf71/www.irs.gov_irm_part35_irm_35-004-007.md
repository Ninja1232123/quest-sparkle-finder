---
url: "https://www.irs.gov/irm/part35/irm_35-004-007"
title: "35.4.7 Stipulating Facts and Documents | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-004-007#main-content)

- 35.4.7 [Stipulating Facts and Documents](https://www.irs.gov/irm/part35/irm_35-004-007#idm140295802756592)
  - 35.4.7.1 [Overview of the Courts Requirements](https://www.irs.gov/irm/part35/irm_35-004-007#idm140295827459120)
  - 35.4.7.2 [Duty to Stipulate](https://www.irs.gov/irm/part35/irm_35-004-007#idm140295803330912)
  - 35.4.7.3 [The Stipulation Process](https://www.irs.gov/irm/part35/irm_35-004-007#idm140295824185664)
  - 35.4.7.4 [Objections to Stipulation](https://www.irs.gov/irm/part35/irm_35-004-007#idm140295822817872)
  - 35.4.7.5 [Compelling Stipulation](https://www.irs.gov/irm/part35/irm_35-004-007#idm140295810663360)
  - 35.4.7.6 [Effect of Stipulation](https://www.irs.gov/irm/part35/irm_35-004-007#idm140295807831312)
  - 35.4.7.7 [Stipulation Format and Contents](https://www.irs.gov/irm/part35/irm_35-004-007#idm140295805359664)
  - 35.4.7.8 [Documents and Other Exhibits](https://www.irs.gov/irm/part35/irm_35-004-007#idm140295813061904)
  - 35.4.7.9 [Stipulation of Facts and Submission of Administrative Record in Collection Due Process (CDP) Cases](https://www.irs.gov/irm/part35/irm_35-004-007#idm140295816195856)

# Part 35. Tax Court Litigation

# Chapter 4. Pre-Trial Activities

# Section 7. Stipulating Facts and Documents

* * *

## 35.4.7 Stipulating Facts and Documents

#### Manual Transmittal

July 26, 2012

#### Purpose

(1) This transmits revised CCDM 35.4.7, Pre-Trial Activities; Stipulating Facts and Documents.

#### Material Changes

(1) CCDM 35.4.7.9, Stipulation of Facts and Submission of Administrative Record in Collection Due Process (CDP) Cases, was added to provide instructions concerning the preparation of stipulations of fact and the submission of the administrative record in CDP cases.

(2) Organizational references to APJP were updated in CCDM 35.4.7.8 to refer to the appropriate P&A practice group.

(3) Titles and hyperlinks were added to references throughout the section.

#### Effect on Other Documents

CCDM 35.4.7, dated August 11, 2004, is superseded. This revision incorporates procedures contained in Chief Counsel Notice CC-2009-010.

#### Audience

Chief Counsel

#### Effective Date

(07-26-2012)

Deborah A. Butler

Associate Chief Counsel

(Procedure and Administration)

**35.4.7.1** **(08-11-2004)**

### Overview of the Court’s Requirements

1. The following discussion is intended as an overview of the Court’s requirements for a comprehensive stipulation of facts, and the rationale for filing as complete a stipulation as possible.

2. In accordance with the Court’s rules, the stipulation of facts may be filed in advance of the trial or it may be presented at the trial. Some judges expect the parties to lodge the stipulation of facts at the calendar call. The original and one copy of the stipulation, and one set of the exhibits incorporated in the stipulation, must be filed with the Court. A stipulation of facts is filed, rather than formally offered into evidence.

3. Before beginning the draft of a stipulation, the attorney must have a thorough knowledge of the facts of the case, after reviewing the reports and documents in the legal and administrative files of the case and any related cases, discovery, and personal investigation. Tax Court Rule 91(e) provides that the Court will treat the stipulation as conclusive and binding, to the extent of its terms. Respondent’s attorney must ensure that only facts known to be true are stipulated.


**35.4.7.2** **(08-11-2004)**

### Duty to Stipulate

1. The purpose of the stipulation of facts is to limit the trial to the facts in dispute, and to narrow the issues for trial. Tax Court Rule 91 requires the parties to prepare a comprehensive stipulation of facts before the trial. The Court takes a dim view of evidence offered at trial which could have been incorporated in a stipulation of facts.

2. As soon as Counsel acquires sole jurisdiction, the attorney should contact petitioner to schedule a conference to determine which facts are in dispute or must be developed. A stipulation of facts conference should be held as soon as the facts are sufficiently developed, and no later than 30 days after the issuance of the trial calendar. It is appropriate for respondent to initiate the stipulation process, and to prepare a draft stipulation of facts. By taking the lead, the attorney will have a greater role in the language and the format, as well as in the substance of the stipulation.

3. Prompt action in the preparation of the stipulation of facts may give respondent the opportunity to utilize discovery to develop any facts or evidence previously overlooked or unavailable.

4. Prompt action in the completion of a stipulation of facts will allow respondent to determine what facts must be proved at trial through witnesses and exhibits.


**35.4.7.3** **(08-11-2004)**

### The Stipulation Process

01. The facts should be stated clearly and concisely. Related facts should be grouped in short paragraphs, and each paragraph should be numbered serially. Only facts should be stated; conclusions, arguments, and reasons should not be included. Where the substance of a transaction is in dispute, the facts surrounding the transaction may be stipulated, but generally not their legal effect. Likewise, documents attached to the stipulation may generally not be characterized, as such documents speak for themselves. Most judges expect the narrative part of the stipulation to outline the facts of the case, and not to serve merely as an index to the documents.

02. Generally, the stipulation does not contain either a statement of the issues or a statement of the contentions of the parties.

03. Although not properly a part of the stipulation of facts, a statement should be included as to the issues settled or conceded by the parties. If extensive, it is preferable that the settlements be shown in a separate Stipulation of Settled Issues, to be filed with the Court. The statement should properly identify issues conceded or settled by referring to the appropriate paragraph number of the notice of deficiency or the appropriate pleading.

04. The stipulation should not contain facts which either party needs to support an anticipated amended pleading unless the other party is informed of the intent to move to amend the pleadings.

05. Except in unusual circumstances, the attorney should not stipulate to the amount of the deficiency which may result from the Court’s decision on an issue.

06. Generally, where a fact or facts are contained in a document, the stipulation should incorporate the entire document rather than a part or parts thereof. The authenticity of petitioner’s documents may be stipulated, but the attorney should not stipulate to the truth of their contents, or their interpretation, or the legal effect. When there is a disagreement as to the truth of the contents of a document, the stipulation should expressly so state and reserve the right to introduce contradictory evidence.

07. The facts set out in the stipulation should not be contradictory. Any apparent inconsistency should be pointed out to the Court and explained in the opening statement at trial. The correct facts are to be stipulated even if they result in a modification of the determination in the statutory notice.

08. If a complete copy of the statutory notice of deficiency is not attached to the petition, a complete copy should be included as an exhibit.

09. In valuation, transferee, fraud (bank deposits and net worth) cases, and in other issues where the answer contains affirmative allegations, every effort should be made to stipulate to the financial or statistical facts where possible to avoid unnecessary trial time. Entries or summaries from books of account and other records and documents may be stipulated, and voluminous data may be summarized and stipulated as an attached exhibit.

10. If an alternative or offset claim is alleged in the answer, the facts with reference thereto should be embodied in the stipulation. In most cases, petitioner will agree that such alternative or offset follows.

11. Respondent should, when agreeing to the fact but objecting to it on the grounds of relevance, stipulate the fact with appropriate reservations. A disagreement between the parties as to the relevance of undisputed facts should not impede the stipulation of such facts.

12. The stipulation must include the facts to establish the venue for an appeal. For the noncorporate petitioner, venue is established by stating the petitioner’s legal residence when the petition was filed. For the corporate petitioner, venue is established by stating the petitioner’s principal place of business or principal office or agency when the petition was filed. In addition, for the corporate petitioner, if not previously established by the pleadings, the place where the income tax return was filed should be included in the stipulation.

13. The initial draft should be based upon the known facts and documents contained in the administrative file, admissions contained in the pleadings, answers to informal or formal discovery, requests for admissions, and other facts or documents secured during trial preparation.

14. Where the petitioner submits a proposed stipulation at the conference, it may be discussed, but the attorney should bear in mind and advise petitioner that respondent formally agrees to a stipulation of facts only when the document is signed by the reviewer.


**35.4.7.4** **(08-11-2004)**

### Objections to Stipulation

1. The respondent should not include any facts not known to be true, even if the attorney believes the facts to be irrelevant. Facts known to be true may be stipulated at the request of petitioner even if the attorney believes the facts to be irrelevant. Objections on the grounds of relevance may be reserved in the opening paragraph, and stated at the end of any statement which respondent believes to be objectionable. Objections on grounds other than relevance may also be reserved, in keeping with the preamble paragraph.


**35.4.7.5** **(07-26-2012)**

### Compelling Stipulation

1. If petitioner refuses to stipulate to facts and evidence which should not be in dispute, a motion to show cause why proposed facts and evidence cannot be established should be considered. A Rule 91(f) motion cannot be filed before the trial notice has been issued, and it cannot be filed less than 45 days before the date of the calendar call. See CCDM 35.3.4.7, Motion to Compel Stipulation Under Tax Court Rule 91(f), for a discussion of motions to compel stipulation. _See also_ T.C. Rule 91(f), for the specific requirements and procedures.


**35.4.7.6** **(07-26-2012)**

### Effect of Stipulation

1. T.C. Rule 91(e) provides that a stipulation is binding on the parties, and is treated as a conclusive admission as to the facts stipulated in the pending case. The Court will generally not permit a party to qualify, change, or contradict any facts stipulated. As such, the attorney has an obligation to assist a pro se petitioner, particularly in a small case, to include the facts relevant to his position, to assist the Court to reach the correct result.

2. T.C. Rule 122 provides for the submission of cases to the Court on the basis of the pleadings, admissions obtained pursuant to Rule 90, stipulations of fact with attached exhibits, and deposition testimony. Because there is no evidentiary hearing in a case submitted under T.C. Rule 122, it is critical that a comprehensive stipulation of facts be prepared to support respondent’s position. Further, a case should not be submitted under Rule 122 where petitioner is pro se, and refuses to stipulate to facts which respondent believes are necessary for petitioner’s theory of the case. Respondent should not rely solely a pro se petitioner’s failure to meet the burden of proof in Rule 122 cases. _See_ T.C. Rule 122, concerning the submission of a case without a trial.

3. Declaratory judgment cases are usually submitted under T.C. Rule 122, as fully stipulated cases.



1. T.C. Rule 217(b) requires the parties to stipulate to all or the pertinent portions all of the administrative record within 30 days after service of the answer. Accordingly, the entire administrative record should be segregated from the remainder of the administrative file, and kept available for inspection (and copying if necessary) by petitioner at reasonable times in the Counsel office which is handling the case.

2. When the answer is filed, a letter should be mailed to petitioner, proposing a conference for the purposes of stipulating to the pertinent portions of the administrative record. A copy of the index should be attached, with the statement that such index reflects respondent’s view of what should be considered to constitute the administrative record. The conference should be scheduled for a date not later than two weeks after the mailing of the answer. The letter should also state that the entire administrative record will be made available for inspection at the Counsel office prior to the proposed conference and will remain available throughout the 30-day period following the date of service of the answer. See CCDM 35.2.2.9, Answers in Declaratory Judgment Cases and Worker Classification Cases Under Section 7436, for preparation of answers in these cases.

3. If the parties agree upon what constitutes the administrative record, but cannot agree upon what portions are pertinent, the entire administrative record should be stipulated, entitled Stipulation as to the Administrative Record. In the absence of a stipulation, respondent is required to file with the Court the entire administrative record, appropriately certified as to its genuineness. T.C. Rule 217(b)(1). T.C. Rule 210(b)(10) contemplates the filing of the original papers constituting the administrative record, rather than copies thereof. If the parties are unable to agree upon what constitutes the administrative record, respondent should submit the record with a Notice of Filing of the Administrative Record.

4. The administrative record should be assembled chronologically, with the earliest dated documented being the first exhibit. The contents of the administrative record, when stipulated, should bear the appropriate exhibit numbers, i.e., 1-J, 2-J, etc. If the parties cannot agree, the respondent should identify the contents of the record by numbering the documents serially, i.e., 1-R, 2-R, etc. If the parties cannot agree, the respondent should identify the contents of the record by numbering the documents. The documents should be fastened together at the top of the pages, not at the side, and should have a white cover on both front and back. The front cover should contain the caption of the case and the docket number. A copy of the Stipulation or the Notice should be the first document in the file. The Stipulation or Notice should list the documents comprising the administrative record.

5. In the usual case, the facts contained in the administrative record will have been supplied by the applicant and accepted by respondent without verification for purposes of the determination letter. Therefore, the stipulation should be worded to avoid any implication that respondent is agreeing to the truth of the facts contained in the administrative record.

6. As soon as the case is at issue, under T.C. Rule 214, a joint motion to submit the case under Rule 122 should be submitted to petitioner for execution, unless it appears that the issues cannot be resolved solely on the basis of the administrative record. Unless the case involves unusually difficult technical issues, the joint motion should request that briefing dates be fixed in accordance with Rule 151. Since the parties are usually aware of each other’s positions on the issues, simultaneous briefs should be requested.

7. The preparation of respondent’s brief in a declaratory judgment case should commence prior to the submission of the case. Since there will rarely be a trial, the relevant facts will be fixed and determined at the time the petition is filed. An early start in the actual writing of the brief will facilitate the detection of any problems which may require advice and will also assist the attorney in determining whether routine briefing times will be adequate by the time the joint motion for submission is prepared.


**35.4.7.7** **(08-11-2004)**

### Stipulation Format and Contents

1. The title of the document is always Stipulation of Facts to distinguish it from a settlement stipulation. A Supplemental Stipulation of Facts may also be filed. If additional supplemental stipulations of facts are necessary, they should be so identified, such as Second Supplemental Stipulation of Facts.

2. If the parties do not agree on the relevance of undisputed facts, it may be appropriate to file separate stipulations: one in which the parties agree as to all of the facts to be stipulated without any reservations, and a second stipulation containing the stipulated facts upon which the parties reserve the right to object to the relevancy thereof.

3. The parts of a stipulation of facts are the introductory paragraph, numbered paragraphs containing the facts stipulated, signatures by or on behalf of the parties, and attached exhibits, if any. Attorneys of Counsel are not listed on a stipulation of facts. In cases submitted under T.C. Rule 122, the listing Counsel of Record is used.

4. The introductory paragraph of a stipulation of facts will vary with the circumstances of the case. The paragraph should be worded to take into account the following factors:



1. Whether either party is reserving the right to object to the facts stipulated on the ground of relevance;

2. Whether there are exhibits attached to the stipulation of facts; and/or

3. If known, whether a separate or supplemental stipulation of facts is going to be prepared.


5. The wording of the introductory paragraph of a stipulation of facts should be in accordance with the intent of the parties, the facts, and any reservations by the parties in entering into the stipulation. The following are examples of opening paragraphs.



1. In accordance with Tax Court Rule 91(e), the parties agree to this Stipulation of Facts pursuant to the general terms of this preamble unless specifically expressed otherwise. All stipulated facts shall be considered authentic. All copies shall be considered electronic reproductions of the originals and shall be treated as if originals. The truth of assertions within stipulated exhibits may be rebutted or corroborated with additional evidence. The terms "partnership," and "lease," together with all related derivatives, are used merely for convenience in describing what petitioners contend are transactions. For tax purposes, these terms are used without prejudice to respondent’s determination and contention that such transactions, agreements, classifications, etc., were not, in truth and substance, that which these terms suggest. Use of these terms does not relieve or shift the burden of proof or the burden of going forward. All evidentiary objections are waived unless specifically expressed within this stipulation.

2. It is hereby stipulated that for the purposes of this case the following statements may be accepted as facts and all exhibits referred to herein and attached hereto may be accepted as authentic, and are incorporated in this stipulation and made a part hereof; provided, however, that either party has the right to object to the admission of any such facts and exhibits in evidence on the grounds of materiality and relevancy, and provided, further, that either party may introduce other evidence not inconsistent with the facts herein stipulated.

3. The parties hereby stipulate and agree that for the purpose of this case, the following facts and exhibits attached hereto (or incorporated herein by reference) and made a part hereof may be taken as true and correct, subject to the rights of the parties to introduce other evidence not inconsistent with this stipulation (including any supplemental stipulations of fact) and preserving the parties’ rights to object, at the time of trial, to any and all portions of said stipulation and said exhibits as they may deem to be irrelevant or immaterial, and unless otherwise expressly stipulated, the parties are not hereby stipulating as to the truth or falsity or the contents, or any part thereof, of the exhibits annexed hereto or incorporated herein by reference.

4. It is hereby stipulated that, for the purposes of this case, the following statements may be accepted as facts and all exhibits referred to herein and attached hereto may be accepted as authentic and are incorporated in this stipulation and made a part hereof; provided, however, that either party has the right to object to the admission of any such facts and exhibits in evidence on the grounds of relevancy and materiality, but not on other grounds unless expressly reserved herein, and provided, further, that either party may introduce other and further evidence not inconsistent with the facts herein stipulated.

5. It is hereby stipulated that, for the purposes of this case only, the following facts are true, and the exhibits attached hereto are true copies of the documents they represent and are admissible into evidence.


6. Following the introductory paragraph, the facts should be concisely stated in short paragraphs, numbered serially, using Arabic numbers. If additional stipulations are prepared, the numbering of the paragraphs should commence with the next consecutive number following the last used in the previous stipulation of facts.

7. Exhibits attached to a stipulation are required to be appropriately lettered and numbered. Exhibits attached to a stipulation shall be numbered serially, i.e., 1, 2, 3, etc. The exhibit number shall be followed by "P" if offered by the petitioner, e.g., 1-P; "R" if offered by the respondent, e.g., 2-R; or "J" if a joint exhibit, e.g., 3-J. Respondent should not permit the marking of exhibits which are strictly those of the petitioner as joint exhibits. Copies of the income tax returns of the petitioner for the years at issue and the notice of deficiency, if agreed to by the parties, are normally marked as joint exhibits. A statement in the introductory paragraph is used to clearly show that the attached exhibits are a part of the stipulation of facts.

8. Exhibits numbered and lettered at trial must not duplicate any numbers and letters used for exhibits attached to a stipulation of facts or, to a Rule 91(f) motion upon which an order to show cause was issued.

9. The stipulation of facts should be signed by the petitioner or petitioner’s counsel, before it is submitted to the reviewer for execution on behalf of the respondent. The stipulation is executed on behalf of the Chief Counsel after it has been reviewed and approved by the reviewer. After the stipulation is approved, the petitioner, or petitioner’s counsel, as appropriate, should be promptly notified and furnished with a conformed copy. The original executed stipulation must be retained by respondent’s counsel until it is filed with the Court.


**35.4.7.8** **(07-26-2012)**

### Documents and Other Exhibits

1. All exhibits which are to be introduced in evidence on behalf of the respondent should be put in the order in which they are expected to be introduced into evidence. They should not be numbered, unless they are being attached to the stipulation of facts.

2. A checklist of all exhibits should be prepared, indicating whether each has been included in a stipulation or will be introduced at trial.

3. Legible copies of original documents may be offered directly in evidence in lieu of the original, where there is no objection, or where the original is available but admission of a copy is authorized by the Court. Copies should be retained of all exhibits in evidence for use in preparing the brief or for administrative purposes, such as the preparation of Rule 155 computations. No copies should be offered in evidence which are not as clear and legible as the original. If the original document is handwritten, or otherwise hard to read, it should be typed so that a clear copy can be furnished to the Court with the original, if the Court requires introduction of the original.

4. The exhibits are serially numbered and lettered, in accordance with T.C. Rule 91(b).

5. In all instances in which a T.C. Rule 91(f) order to show cause has been issued and there are exhibits attached or made part of a proposed stipulation filed therewith, the exhibit numbers used for that purpose should not be used again in the stipulation of facts.

6. A return to be introduced in evidence should be examined to confirm that all attachments which are not a part of the return are removed and that only those papers and schedules which were attached to the return when it was filed remain attached to the return. A copy should be made of the return prior to the trial in order that the original return may be retained and the copy admitted in evidence or substituted for the original if the original is required to be put in evidence.

7. Waivers to extend the statute of limitations may be attached to returns in the course of the audit. These are not a part of the return and should be detached from the return. If a statute of limitations issue is raised in the case, each waiver pleaded should be specifically stipulated or be separately introduced in evidence and, as in the case of returns, a copy should be available to offer in evidence or to substitute for the original of the waiver.

8. The Tax Court will not take judicial notice of matters merely because they are contained in its files in other cases. If the official file of the Tax Court is needed, in whole or in part, for the purpose of introduction of evidence with respect to issues involved in the case to be tried, a request therefor should be made. The official file may be important when issues such as res judicata or collateral estoppel are pled, based upon a decision in another Tax Court case. The attorney should prepare a letter addressed to the clerk of the Tax Court for the signature of the Chief Counsel (to be forwarded to the Associate Chief Counsel (Procedure and Administration) to the attention of Branches 6 and 7). The letter should request the clerk to transmit to the place of trial the designated official file of the Tax Court along with the file of the current case so that the requested file, or parts thereof, may be introduced in evidence. If the Tax Court file is incomplete because of destruction in the usual course of business of some or all of the papers previously filed therein, the clerk should be requested to forward a certification of such destruction. A certification is essential to a proper foundation for the introduction in evidence of copies of the missing Tax Court papers which may be retained in the respondent’s closed file


**35.4.7.9** **(07-26-2012)**

### Stipulation of Facts and Submission of Administrative Record in Collection Due Process (CDP) Cases

1. The stipulation of facts should include facts and documents relevant to issues subject to trial de novo. The stipulation should also attach the documents comprising the administrative record as discussed in CCDM 35.4.7.9 (2). If the taxpayer will not cooperate on the stipulation of facts, the attorney should file, at least 45 days before calendar call, a motion under T.C. Rule 91(f) to compel stipulation.

2. If a stipulation of facts cannot be agreed to within sufficient time to file a motion to compel, the attorney should still prepare a proposed stipulation of facts for submission to the Tax Court at the trial calendar call. Additionally, the attorney should prepare a declaration of the appeals officer who made the CDP determination to authenticate the administrative record. This is similar to the declaration that is prepared for a summary judgment motion in a CDP case. See CCDM 35.3.23.8.4, Declaration. The attorney should send a copy of the declaration to the taxpayer, informing the taxpayer of the plan to offer the documents into evidence. Under Fed. R. Evid. 902(11), the declaration permits the documents comprising the administrative record to be self-authenticating, provided written notice of the intention to use the documents is given to the taxpayer and the records and declaration are made available for inspection sufficiently in advance to provide the taxpayer a fair opportunity to challenge them. By using this declaration, the appeals officer’s live testimony is not necessary to authenticate the administrative record at trial. The hearsay exception for business records found in Fed. R. Evid. 803(6) also applies to permit admission of the declaration into evidence. _Clough v. Commissioner_, 119 T.C. 183 (2002).

3. The attorney should submit the administrative record to the Tax Court as part of the stipulation of facts, as outlined below. Submission of a standardized and comprehensive administrative record should decrease the need for testimony of the appeals officer in CDP cases and reduce the court’s need to go beyond the administrative record. Although the Tax Court held in Robinette v. Commissioner, 123 T.C. 85 (2004), rev’d, 439 F.3d 455 (8th Cir. 2006), that it would consider evidence outside of the administrative record in CDP cases, the Tax Court was reversed by the Eighth Circuit. In addition, the First and Ninth Circuit Courts of Appeals have also held that abuse of discretion review in CDP cases should be limited to the administrative record. Keller v. Commissioner, 568 F.3d 710, 718 (9th Cir. 2009); Murphy v. Commissioner, 469 F.3d 27, 31 (1st Cir. 2006), aff’g on different grounds, 125 T.C. 301 (2005). See also Treas. Reg. §§ 301.6320-1(f)(2) Q&A F4, 301.6330-1(f)(2) Q&A F4.

4. Under well-settled principles of administrative law, the administrative record consists of the information an agency reviews when making its determination. _James Madison Ltd. by Hecht v. Ludwig_, 82 F.3d 1085, 1095 (D.C. Cir. 1996). In general in CDP cases, the administrative record consists of all of the documents in the case file. Treas. Reg. §§ 301.6320-1(f)(2) Q&A F4, 301.6330-1(f)(2) Q&A F4. If a case is remanded to the Appeals, additional materials considered on remand, including documents submitted by the taxpayer and the supplemental notice of determination, become part of the administrative record.

5. The administrative record attached to the stipulation of facts should generally include the items described above that should be attached to a declaration filed with a motion for summary judgment. See CCDM 35.3.23.8.4, Declaration, which lists the minimum items that should comprise every administrative record.

6. The administrative record includes written legal advice from Counsel to Appeals on the case ( _e.g._, advice on whether or not to accept an offer in compromise). The attorney-client privilege should generally _not_ be asserted with respect to these documents.

7. When preparing the stipulation of facts, the attorney should place the items comprising the administrative record in the categories and order described in CCDM 35.3.23.8.4, Declaration. If there is more than one document within a category, the items should be listed in chronological order ( _e.g._, the taxpayer’s bankruptcy petition, the taxpayer’s bankruptcy schedules, the bankruptcy court’s order of discharge).

8. The stipulation should contain a paragraph stating that the specifically enumerated exhibits constitute the entire administrative record. Each item, labeled with a separate exhibit number, should be attached to the stipulation. If the item contains more than one page and is not otherwise numbered, the item should be paginated sequentially. A sample stipulation of facts attaching the administrative record is in Exhibit 35.11.1-212, Collection Due Process Case: Stipulation of Facts Attaching Administrative Record.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-004-007#addtoany "Show all")

A2A