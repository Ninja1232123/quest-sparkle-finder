---
url: "https://www.irs.gov/irm/part32/irm_32-002-004"
title: "32.2.4 Background Information Note (BIN) and Legal Memorandum (Legal Memo) | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part32/irm_32-002-004#main-content)

- 32.2.4 [Background Information Note (BIN) and Legal Memorandum (Legal Memo)](https://www.irs.gov/irm/part32/irm_32-002-004#idm139984126278752)
  - 32.2.4.1 [General Information about the BIN and Legal Memo](https://www.irs.gov/irm/part32/irm_32-002-004#idm139984129403824)
  - 32.2.4.2 [Form for BIN](https://www.irs.gov/irm/part32/irm_32-002-004#idm139984108442304)

    - 32.2.4.2.1 [Contents of BIN](https://www.irs.gov/irm/part32/irm_32-002-004#idm139984117636096)

      - 32.2.4.2.1.1 [Holding, Procedure, or Contents](https://www.irs.gov/irm/part32/irm_32-002-004#idm139984134741600)
      - 32.2.4.2.1.2 [Source](https://www.irs.gov/irm/part32/irm_32-002-004#idm139984130382432)
      - 32.2.4.2.1.3 [Reason for Publication](https://www.irs.gov/irm/part32/irm_32-002-004#idm139984115875520)
      - 32.2.4.2.1.4 [Consistency with Underlying Document](https://www.irs.gov/irm/part32/irm_32-002-004#idm139984106694368)
      - 32.2.4.2.1.5 [Pending Litigation](https://www.irs.gov/irm/part32/irm_32-002-004#idm139984133793472)
      - 32.2.4.2.1.6 [Pending Regulations](https://www.irs.gov/irm/part32/irm_32-002-004#idm139984123526224)
      - 32.2.4.2.1.7 [Coordination](https://www.irs.gov/irm/part32/irm_32-002-004#idm139984099503488)

        - 32.2.4.2.1.7.1 [Coordination with Another Agency](https://www.irs.gov/irm/part32/irm_32-002-004#idm139984134621120)
        - 32.2.4.2.1.7.2 [Significant Issues Raised During Coordination and Circulation](https://www.irs.gov/irm/part32/irm_32-002-004#idm139984107456176)

      - 32.2.4.2.1.8 [Prospective Application](https://www.irs.gov/irm/part32/irm_32-002-004#idm139984113704720)
      - 32.2.4.2.1.9 [Contra Argument](https://www.irs.gov/irm/part32/irm_32-002-004#idm139984120070000)
      - 32.2.4.2.1.10 [Research Statement](https://www.irs.gov/irm/part32/irm_32-002-004#idm139984155041200)
      - 32.2.4.2.1.11 [Form 1099 Consideration](https://www.irs.gov/irm/part32/irm_32-002-004#idm139984155039648)
      - 32.2.4.2.1.12 [Attachment List in the BIN](https://www.irs.gov/irm/part32/irm_32-002-004#idm139984135385520)

  - 32.2.4.3 [Legal Memo](https://www.irs.gov/irm/part32/irm_32-002-004#idm139984124289840)
  - Exhibit 32.2.4-1 [Format for Background Information Note (BIN)](https://www.irs.gov/irm/part32/irm_32-002-004#idm139984119689760)
  - Exhibit 32.2.4-2 [Format for Page 2 of the Background Information Note (BIN)](https://www.irs.gov/irm/part32/irm_32-002-004#idm139984106774192)

# Part 32. Published Guidance and Other Guidance to Taxpayers

# Chapter 2. Chief Counsel Publication Handbook

# Section 4. Background Information Note (BIN) and Legal Memorandum (Legal Memo)

* * *

## 32.2.4 Background Information Note (BIN) and Legal Memorandum (Legal Memo)

**32.2.4.1** **(08-11-2004)**

### General Information about the BIN and Legal Memo

1. The draft of each proposed publication is accompanied by a BIN and, if appropriate, a Legal Memo, which contain special information for reviewers. The BIN and Legal Memo are prepared by the drafting attorney. The BIN is the sole clearance document for proposed publication items. The BIN is signed by the appropriate official when that official approves the proposed publication item. The BIN must be signed (or other appropriate approval must be received) before the publication item moves from one clearance level to another. Because the BIN and Legal Memo are internal working documents, they may contain colloquial expressions, dates expressed in figures, and well-known abbreviations. The BIN must reflect coordination with other Associate offices as appropriate. _See_ CCDM 32.2.5.2.


**32.2.4.2** **(08-11-2004)**

### Form for BIN

1. General Content —The BIN consists of two parts, a Record of Clearance (page 1) and Background Information (page 2). Background information is typed single spaced on page 2 and is confined to one page in length, if possible.

2. Record of Clearance — Page 1 of the BIN ( _see_ Exhibit 32.2.4-1). The Record of Clearance identifies the drafting attorney, the reviewers, and the date submitted and date cleared at each level of the clearance process. After approving the proposed publication item, the reviewers sign their names (where applicable) and include the date of their approval. _See_ CCDM 32.2.7.4. Alternate methods for documenting approval exist for the Commissioner’s Office ( _see_ CCDM 32.2.7.7) and for Treasury ( _see_ CCDM 32.2.7.8). Alternate approval documentation should be attached to the BIN and a copy should be retained in the background file for the publication item.

3. Background Information — Page 2 of the BIN. The BIN for revenue rulings should include pertinent background information. The BIN for revenue procedures should include a brief statement of the purpose and procedure in lieu of a holding. The BIN for notices, announcements, and news releases should include a brief statement of the purpose or need for the publication. The BIN should be organized under the captions indicated in CCDM 32.2.3.2.1, as appropriate.

4. Signature Line —The number and symbols of the originating office are typed following the title of the assigned reviewer, directly below the signature line near the bottom of the last page of the BIN.



### Note:



The format of a typical page 2 of the BIN is set forth in Exhibit 32.2.4-2.


**32.2.4.2.1** **(08-11-2004)**

#### Contents of BIN

1. The BIN contains paragraphs indicated by appropriate captions discussing each of the following items, as applicable, in the following order.


**32.2.4.2.1.1** **(08-11-2004)**

##### Holding, Procedure, or Contents

1. State in general terms the holding, procedure, or content of the proposed publication. Include background information that would be helpful to reviewers.


**32.2.4.2.1.2** **(08-11-2004)**

##### Source

1. If the project originates with an oral or written suggestion made by Treasury or Service personnel outside the branch, the BIN should so state and identify the originator. A written suggestion should be attached to the BIN.

2. If the project is based on a written suggestion from the Section of Taxation of the American Bar Association (or a similar group), the BIN should so state. The written suggestion, or the relevant part of the written suggestion, should be attached to the BIN, if helpful. Otherwise, the relevant language from the written suggestion can be quoted in the BIN.



### Note:



If the project is based on a letter ruling or technical advice the caption " Source" is omitted. Instead, the caption "Consistency with Underlying Document" is used. (Discussed below).


**32.2.4.2.1.3** **(08-11-2004)**

##### Reason for Publication

1. State why the issue warrants publication.


**32.2.4.2.1.4** **(08-11-2004)**

##### Consistency with Underlying Document

1. State whether the proposed publication is consistent with the underlying document, if any. If the position stated in the underlying letter ruling or technical advice is being reversed or changed by the proposed publication, the BIN should include a statement whether the appropriate Service official or taxpayer will be advised of the change and, if not, the statement should specify why. If there is no underlying document this caption is omitted.


**32.2.4.2.1.5** **(08-11-2004)**

##### Pending Litigation

1. If litigation is pending in a case involving the same issue or procedure dealt with in the proposed publication, the BIN should identify the case, and briefly give its status and the litigating position of the Service. If there is no pending litigation this caption is omitted.


**32.2.4.2.1.6** **(08-11-2004)**

##### Pending Regulations

1. If no final or temporary regulations for a section of the Internal Revenue Code involved have been issued, the consistency of the position stated with any published proposed regulations should be indicated in the BIN with a statement such as: "Section xxx was amended by the Tax Reform Act of 1986, and the conclusions reached in the proposed publication are consistent with the proposed regulations published in the Federal Register on xx-xx-xx." The consistency of the proposed publication with proposed or draft regulations in process, including the regulation project number, should be noted in the BIN.

2. If it has been previously ascertained that the Office of the Tax Legislative Counsel, Benefits Tax Counsel, or International Tax Counsel believes the position to be consistent with any regulations in process, a statement to this effect should be included in the BIN.

3. If there are no pending regulations, this caption is omitted.


**32.2.4.2.1.7** **(08-11-2004)**

##### Coordination

1. The drafting attorney should document certain coordination in the BIN.


**32.2.4.2.1.7.1** **(08-11-2004)**

###### Coordination with Another Agency

1. Social Security Administration: If a proposed publication involves social security taxes, an advance copy of the publication generally is sent for clearance to the Social Security Administration, which shares jurisdiction with the Service on social security tax matters. Information about any coordination of the proposed publication with the Social Security Administration should be included in the BIN. _See_ CCDM 32.2.5.4.1.

2. Other Government Agencies: With approval of the appropriate Associate Chief Counsel, representatives of other government agencies may be asked to read an advance copy of a proposed publication that affects that agency and to discuss it with Service personnel. Included in the BIN should be information received from another agency that gives rise to the proposed publication and information about any coordination of the proposed publication with another government agency. _See_ CCDM 32.2.5.4.

3. If there is no coordination with other agencies, this caption is omitted.


**32.2.4.2.1.7.2** **(08-11-2004)**

###### Significant Issues Raised During Coordination and Circulation

1. If there were any significant issues raised during coordination or circulation, the resolution of those issues should be discussed in this section of the BIN, unless discussed elsewhere in the BIN.


**32.2.4.2.1.8** **(08-11-2004)**

##### Prospective Application

1. If a proposed revenue ruling is to be applied prospectively only, the BIN should state and discuss the reasons for and against the prospective application. For revenue procedures, a statement in the BIN as to the effective date typically is sufficient. When an effective date other than the date of publication is used, however, the reasons for selecting that other date should be discussed in the BIN.



### Caution:



With respect to a proposed revenue ruling that modifies, revokes, clarifies, or otherwise affects a prior revenue ruling but does not apply the new position prospectively only, the BIN must state the reason(s) for not recommending prospective only application, even if it is only to say that the new position is more favorable to taxpayers than the old position. If, however, the new position is adverse to taxpayers, the grounds for rejection of relief or the reason why section 7805(b)(8) is inapplicable should be discussed in greater detail. _See_ CCDM 32.2.3.5.1.2.7.


**32.2.4.2.1.9** **(08-11-2004)**

##### Contra Argument

1. The BIN should briefly summarize any contra argument and refer to the page(s) in the Legal Memo where the contra argument and the rebuttal are discussed or should state that there is no contra argument. If there is no Legal Memo, the BIN should contain a discussion of the rebuttal. If the proposed publication item has an effect on other documents or is contrary to other cases, this section should include a discussion of those documents or cases, the effect of the proposed publication item, and any reasons why the proposed effect is not desired.


**32.2.4.2.1.10** **(08-11-2004)**

##### Research Statement

1. Include in the BIN the statement: "Researched by the preparer through (date)." The drafting attorney should update the research and change the research date when the project moves to another review level or after a significant lapse of time.


**32.2.4.2.1.11** **(08-11-2004)**

##### Form 1099 Consideration

1. Normally, if the proposed publication will have the effect of requiring the filing of a Form 1099, a separate paragraph should be included (preferably at or near the end of the BIN or, in the case of news releases, at or near the end of the memorandum to the Associate Chief Counsel), and state that the proposed publication is not to be referred to the Bulletin Unit between November 1 and April 1, and in applicable situations, not to be issued as a news release between November 15 and April 15.

2. If, however, in unusual circumstances, publication should not be delayed, the reasons for urgency of publication should be stated in the BIN.

3. If the proposed publication does not have the effect of requiring the filing of a Form 1099, then this caption is omitted.


**32.2.4.2.1.12** **(08-11-2004)**

##### Attachment List in the BIN

1. When the proposed publication item goes into formal clearance, relevant material should be attached to the BIN. _See_ CCDM 32.2.7.2.


**32.2.4.3** **(08-11-2004)**

### Legal Memo

1. A Legal Memo is prepared in certain situations to accompany the proposed publication through the clearance process. A Legal Memo can be helpful particularly if additional research, other issues, or other items are not reflected in the final proposed publication but have been considered during its development. A Legal Memo is generally not required for revenue procedures, notices, announcements, or news releases, but may be included if it would be helpful to reviewers.

2. The Legal Memo should not duplicate information in the BIN or the proposed publication.

3. The following items may be included in the Legal Memo:



   - A restatement of the issue

   - A restatement of the holding

   - Justification, arguments, and lines of research that are not reflected fully in the proposed publication

   - Principal arguments (if any) for reaching a position contrary to that proposed in the revenue ruling or if there are no good arguments for the contra position, the Legal Memo should so state

   - Rebuttal to any contra arguments


**Exhibit 32.2.4-1** **(08-11-2004)**

### Format for Background Information Note (BIN)

![This is an Image: 29176001.gif](https://www.irs.gov/pub/xml_bc/29176001.gif)

There is currently no description available for this image. For help with this image, please call the IRS.gov Helpdesk at 1-800-876-1715.

[Please click here for the text description of the image.](https://www.irs.gov/media/157631 "")

**Exhibit 32.2.4-2** **(08-11-2004)**

### Format for Page 2 of the Background Information Note (BIN)

![This is an Image: 29176003.gif](https://www.irs.gov/pub/xml_bc/29176003.gif)

There is currently no description available for this image. For help with this image, please call the IRS.gov Helpdesk at 1-800-876-1715.

[Please click here for the text description of the image.](https://www.irs.gov/media/157636 "")

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part32/irm_32-002-004#addtoany "Show all")

A2A