---
url: "https://www.irs.gov/irm/part36/irm_36-001-001"
title: "36.1.1 Guiding Principles for Appeals | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part36/irm_36-001-001#main-content)

- 36.1.1 [Guiding Principles for Appeals](https://www.irs.gov/irm/part36/irm_36-001-001#idm139690241890448)
  - 36.1.1.1 [Appellate Guiding Principles](https://www.irs.gov/irm/part36/irm_36-001-001#idm139690248697904)
  - 36.1.1.2 [Definition of Appeal Cases](https://www.irs.gov/irm/part36/irm_36-001-001#idm139690223313840)

    - 36.1.1.2.1 [Definitions of Favorable Appeal and Adverse Decision](https://www.irs.gov/irm/part36/irm_36-001-001#idm139690233838288)
    - 36.1.1.2.2 [Protective Appeals and Cross-Appeals](https://www.irs.gov/irm/part36/irm_36-001-001#idm139690184653424)

  - 36.1.1.3 [Standards of Appellate Review](https://www.irs.gov/irm/part36/irm_36-001-001#idm139690251204960)
  - 36.1.1.4 [Responsibilities and Functions of Department of Justice in AppealCases](https://www.irs.gov/irm/part36/irm_36-001-001#idm139690234597872)
  - 36.1.1.5 [Responsibilities of Division Counsel in Appeal Cases](https://www.irs.gov/irm/part36/irm_36-001-001#idm139690216204320)
  - 36.1.1.6 [Responsibilities of Associate Chief Counsel Offices in Appeal Cases](https://www.irs.gov/irm/part36/irm_36-001-001#idm139690216354448)
  - 36.1.1.7 [Responsibilities of Associate Chief Counsel Attorneys in AppealCases](https://www.irs.gov/irm/part36/irm_36-001-001#idm139690218634800)

    - 36.1.1.7.1 [Initial Assignment of New Appeal Cases](https://www.irs.gov/irm/part36/irm_36-001-001#idm139690218645536)
    - 36.1.1.7.2 [Coordination with Division Counsel](https://www.irs.gov/irm/part36/irm_36-001-001#idm139690244746080)
    - 36.1.1.7.3 [Letter to Department of Justice](https://www.irs.gov/irm/part36/irm_36-001-001#idm139690231222960)
    - 36.1.1.7.4 [Technical Assistance to the Department of Justice](https://www.irs.gov/irm/part36/irm_36-001-001#idm139690217798416)
    - 36.1.1.7.5 [Review of Appellate Briefs](https://www.irs.gov/irm/part36/irm_36-001-001#idm139690239827296)
    - 36.1.1.7.6 [Acknowledgment of Notification of Schedule of Oral Argument](https://www.irs.gov/irm/part36/irm_36-001-001#idm139690227680672)
    - 36.1.1.7.7 [Closing the Case to the Area Counsel Office](https://www.irs.gov/irm/part36/irm_36-001-001#idm139690189606912)

# Part 36. Appellate Litigation and Actions on Decision

# Chapter 1. Guiding Principles for Appeals

# Section 1. Guiding Principles for Appeals

* * *

## 36.1.1 Guiding Principles for Appeals

**36.1.1.1** **(08-11-2004)**

### Appellate Guiding Principles

1. The Office of Chief Counsel's interest in litigation continues even after a trial court's decision: to ensure a correct and administrable interpretation of the Internal Revenue Code and related statutes. This section will discuss appeals from adverse decisions including those of the Tax Court, a bankruptcy court, bankruptcy appellate panel, state trial court, district court, the Court of Federal Claims, or a court of appeals.

2. This chapter will discuss appeal cases in general, and the responsibilities of Division Counsel offices and Associate Chief Counsel offices for handling appeal cases. Chapter 36.2 discusses appeal recommendations in general, and the sections that follow discuss procedures that pertain to specific types of appeals, such as appeals from the Tax Court, see CCDM 36.2.5, Appeals of Tax Court Cases, or from a bankruptcy court, see CCDM 36.2.1.2.5, Bankruptcy Court Cases. Actions on decision are discussed in CCDM 36.3 Actions on Decision.

3. This chapter does not apply to appeal of cases within the responsibility of the Associate Chief Counsel (General Legal Services), which is discussed in CCDM Part 39.

4. The Associate Chief Counsel will generally decide whether the Office of Chief Counsel will recommend appeal. The Associate Chief Counsel is responsible for coordinating appeal matters within the Office and with the Chief Counsel, as appropriate.


**36.1.1.2** **(08-11-2004)**

### Definition of Appeal Cases

1. General. An appeal case is any case in which the trial court has issued a final order or decision appealable under 28 U.S.C. § 1291, or in which the trial court has issued an interlocutory order appealable under either 28 U.S.C. §§ 1292(a) or 1292(b).

2. Exceptions. Appeal cases do not include the following:



1. Trial de novo. Some courts have procedures where litigants may appeal a trial court decision to a higher court that conducts a trial de novo. The procedures in Part 36 do not apply to these cases.

2. Bankruptcy Appeals. These are appeals from bankruptcy court orders to a district court or to a bankruptcy appellate panel. See CCDM 36.2.1.2.5 Bankruptcy Court Cases, for procedures for handling appeals from bankruptcy court orders.


3. Judgments. The Tax Court enters decisions to dispose of most cases on the merits, but many other courts enter judgments. References in Part 36 to decisions include judgments unless the context indicates otherwise.


**36.1.1.2.1** **(08-11-2004)**

#### Definitions of Favorable Appeal and Adverse Decision

1. A Taxpayer appeal is an appeal of a decision favorable to the Government by one or more of the other litigants.

2. An adverse decision is a decision that is adverse to the Government in whole or in part.


**36.1.1.2.2** **(08-11-2004)**

#### Protective Appeals and Cross-Appeals

1. Attorneys may need to take protective action when a case, or relevant cases, involves inconsistent alternatives as to tax years, tax treatments, or taxpayers liable for tax. In some of these cases, a reversal in a taxpayer appeal might result in inconsistent treatment disadvantageous to the Government on the alternative issues if the attorney does not take protective action. Thus, if a reversal on appeal would change the tax liability, even in part, to another year or taxpayer (not otherwise on appeal), the attorney must consider whether to protect the Government's interest by filing an appropriate notice of appeal or such other action as is warranted under the circumstances.

2. Protective Appeal vs. Cross-Appeal. A protective appeal is filed when the need for protective action arises due to the existence of related parties or matters in a different docket number from that which a taxpayer appealed. A cross-appeal is filed when the need for protective action arises under the same docket number. When a taxpayer files an appeal, the Government generally has additional time beyond the time for filing a direct appeal within which to file a cross-appeal. _See_ section 7463; Fed. R. App. P. 4(a)(3), 13(a)(1).



### Example:



Assume the Commissioner has won at least one issue and lost an issue that would not, in itself, justify the effort and cost of appeal. If the taxpayer files an appeal, the attorney should consider whether to recommend filing a cross-appeal of the issue the Commissioner lost. The potential for inconsistent tax treatment if the taxpayer prevails on appeal is a factor to consider.







### Example:



Assume the Commissioner determined in a single docket before the Tax Court that a certain item is includible in income in either 1990 or 1991, and the Tax Court includes the item in 1990. The attorney should consider recommending a cross-appeal if the taxpayer appeals that determination. If, however, tax years 1990 and 1991 were tried separately under two different docket numbers, a protective appeal may be appropriate, even though the cases were consolidated for purposes of trial, briefing, and opinion.

3. The need for protective action is not limited to Tax Court cases. Protective appeals may also be necessary when the same or related issues, taxpayers, or transactions are involved within the same court or in different courts at the same time.

4. Further discussion of protective appeals and cross-appeals and additional examples of situations requiring such action can be found in CCDM 36.2.6.2.3, Protective Appeals and Cross-Appeals in Tax Court Cases.


**36.1.1.3** **(08-11-2004)**

### Standards of Appellate Review

1. If the court's reasons are founded in facts, determine if the court's factual findings were clearly erroneous -- the standard for reversal of factual issues. Since the clearly erroneous standard is difficult to satisfy and factual holdings generally have little or no precedential value, the Office of Chief Counsel only infrequently recommends appeal based on factual findings.

2. If the court bases its reasons for the adverse holding in law or law applied to fact, appellate review is de novo. Thus, reversal on appeal is much easier to accomplish.


**36.1.1.4** **(08-11-2004)**

### Responsibilities and Functions of Department of Justice in Appeal Cases

1. The Department of Justice prosecutes claims for, and defends claims against, the Government in tax matters in all courts except the Tax Court. Accordingly, the Commissioner is represented in the appellate courts by the Department of Justice. Executive Order 6166, dated June 10, 1933, vests in the Department of Justice the authority to determine in what manner to prosecute, defend, compromise, or to appeal any case referred to the department for prosecution or defense.

2. Appeals in civil tax cases (including appeals from the Tax Court, the Court of Federal Claims, district courts, bankruptcy appellate panels, and state trial courts) are briefed and argued by the attorneys in the Department of Justice, Tax Division's Appellate Section. After receipt of the Chief Counsel's and the Civil Trial Section's recommendation, the Appellate Section prepares its own memorandum to the Assistant Attorney General (Tax Division). If all agree, the Assistant Attorney General will send a memorandum to the Solicitor General stating the Tax Division's recommendation regarding appeal. (The memorandum generally is drafted by the Appellate Section.) If there is disagreement, the Tax Division generally will provide an opportunity for a conference. See CCDM 36.2.3.1, Conflicts in Appeal or Certiorari Recommendations. A similar practice is followed for certiorari recommendations regarding adverse decisions in the U.S. courts of appeal.

3. The Chief, Appellate Section, has generally been delegated the authority to accept offers in compromise where the amount to be conceded by the Government does not exceed $300,000.00 and such action is not opposed by the Service or by the trial section in which the case originated. Additionally, the Appellate Section may reject any offer, provided that rejection is not opposed by the Service. See CCDM 36.2.3.2, Offers in Settlement.

4. The Solicitor General supervises all litigation in the Supreme Court, including tax litigation. The Solicitor General also determines whether the Government will appeal any case, civil or criminal, including appeals from decisions in Tax Court and district courts. The Office of Chief Counsel files notices of appeal from adverse Tax Court decisions and, accordingly, the decision of the Office of Chief Counsel not to appeal a Tax Court case is controlling. In other appeal cases, the Solicitor General receives the recommendation of the Office of Chief Counsel as well as that of the Tax Division before a final decision concerning appeal is made. The briefing and arguing of tax cases before the courts of appeals is generally handled by the Appellate Section. The Appellate Section also prepares draft petitions, memoranda, and briefs for cases filed in the Supreme Court. Attorneys in the Solicitor General's office review and file the papers and argue the cases.

5. As only the Solicitor General has authority to decide whether to appeal a case, the attorney should be careful not to reveal to persons outside of the Office of Chief Counsel or, in appropriate circumstances, the Office of the General Counsel of the Department of Treasury, any recommendations on appeal that are made.


**36.1.1.5** **(08-11-2004)**

### Responsibilities of Division Counsel in Appeal Cases

1. Division Counsel may prepare, by memorandum, a recommendation regarding appeal. The Associate Chief Counsel office will consider the Division Counsel's recommendation and will forward the Division Counsel recommendation with its own.

2. Similarly, Division Counsel may prepare, by memorandum, a recommendation regarding whether an Action on Decision (AOD) should be prepared. The Associate Chief Counsel office will consider this recommendation, in addition to other recommendations, in drafting the AOD.

3. Division Counsel may prepare, by memorandum, a recommendation regarding certiorari. The Associate Chief Counsel office will consider the Division Counsel's recommendations and will forward the Division Counsel recommendation with its own.

4. To the extent Division Counsel attorneys and Associate Chief Counsel attorneys do not agree regarding whether to appeal, or the content of an appeal recommendation, the reconciliation procedures should be used. If the reconciliation procedures do not produce agreement among the Division Counsel and Associate Chief Counsel offices with responsibility for the case, the unresolved issues should be raised to the Chief Counsel level for resolution. See CCDM 31.1.4.2, Reconciliation of Disputes.


**36.1.1.6** **(08-11-2004)**

### Responsibilities of Associate Chief Counsel Offices in Appeal Cases

1. The Associate Chief Counsel offices have the following responsibilities:



1. Associate Chief Counsel. Each Associate (or delegate) will:



      > - Prepare letters recommending appeal for the signature of the appropriate official
      >
      >       - Resolve all disputes involving divisions or branches within that Associate's office, and attempt to resolve disagreements between divisions or branches within that Associate's office and Division Counsel with respect to appeal recommendations
      >
      >       - Sign all correspondence to the Department of Justice recommending no appeal, except that letters recommending no appeal in non-significant cases may be signed by an Assistant Chief Counsel, Deputy Assistant Chief Counsel, or branch chief, depending upon procedures delegating that authority to those individuals
      >
      >       - Elevate appeal recommendations that cannot be resolved by agreement between the Associate office and the Division Counsel
      >
      >       - Determine whether to protest to the Department of Justice Tax Division or the Office of the Solicitor General disagreements as to appeal, rehearing, or certiorari actions and the positions to be taken in appellate courts and the Supreme Court and elevate such disagreements as appropriate
      >
      >       - Coordinate with the Department of Treasury as appropriate and necessary under Treasury directives any recommendations and positions to be taken in appellate courts and the Supreme Court

2. In conjunction with the Associate Chief Counsel (P&A), each Associate Chief Counsel will:



      > - Institute inventory control and due date controls to permit the Associate Chief Counsel (P&A) to oversee and report on the timeliness of appellate activities, and
      >
      >       - Cooperate with the Associate Chief Counsel (P&A) in preparing reports as required for Office of Chief Counsel appellate activities

3. The Associate Chief Counsel (P&A) will monitor and update CCDM provisions related to appellate procedures within the Office of Chief Counsel and will, with the cooperation of the other Associate offices and, as directed, oversee the maintenance of the significant case database as well as any additional reporting requirements that the Chief Counsel may deem appropriate.

4. The Technical Services Support Branch of the Office of the Associate Chief Counsel (P&A) will receive routine documents from the Department of Justice, such as opinions, briefs, and recommendation memoranda, and will route these to the appropriate Associate office/division for handling.

5. The Technical Services Support Branch, assigned Associate Chief Counsel attorneys, paralegals, reviewers, and branch chiefs in all Associate offices should maintain records (including but not limited to TLCATS) showing the status and progress of Government and taxpayer appeals, including assessment status.


2. If the Government has lost any issues within the jurisdiction of any Associate office, the decision with respect to further action on those issues should be coordinated with all affected offices.

3. As part of the Associate office's responsibility to coordinate with Treasury, the Associates must be alert to significant cases that should be reported to Treasury, even if Treasury approval is not technically required. Such cases are reported using the Treasury website for significant cases.


**36.1.1.7** **(08-11-2004)**

### Responsibilities of Associate Chief Counsel Attorneys in Appeal Cases

1. The Associate Chief Counsel attorney is responsible for reviewing decisions and opinions of trial courts, preparing recommendations for appeal and/or settlement after consultation with the Division Counsel office, monitoring the status of the case while on appeal, and preparing recommendations for certiorari where appropriate. The Associate Chief Counsel attorney will be responsible for notifying the Division Counsel office when appellate proceedings are concluded, and for closing the case. In some cases, more than one Associate Chief Counsel office will have responsibility for different issues in the same case. The Associate Chief Counsel attorney assigned primary responsibility for preparing the appeal recommendation must coordinate with other Associate Chief Counsel offices in addition to Division Counsel, to ensure that the recommendation reflects the views of the Office of Chief Counsel as a whole.


**36.1.1.7.1** **(08-11-2004)**

#### Initial Assignment of New Appeal Cases

1. The Associate Chief Counsel office opens a Workload Item in all cases where the Government has won at the lower court level and another party appeals or when a decision adverse to the Government in whole or in part has been entered. The name of the Area Counsel attorney can be obtained from CASE-MIS. If unable to identify the Area Counsel attorney via CASE-MIS, the Associate Chief Counsel attorney should contact the Division Counsel Headquarters senior legal counsel or special counsel for assistance. If the Area Counsel attorney has not yet received a copy of the opinion, one should be faxed to the Area Counsel office.

2. The Associate Chief Counsel attorney should request from the Area Counsel office any documents thought necessary for processing the case in the court of appeals, generally including the entire legal file and any miscellaneous law files. The Area Counsel office may retain copies of materials necessary to permit preparation of the memorandum setting forth the Area Counsel office's views regarding appeal. With the consent of the Associate Chief Counsel office, the Area Counsel office may submit the files contemporaneously with the memorandum if doing so will not delay transmission of the file. When received from the Area Counsel office, the legal and miscellaneous law files should be reviewed to be sure all exhibits and transcripts are accounted for.


**36.1.1.7.2** **(08-11-2004)**

#### Coordination with Division Counsel

1. The Associate Chief Counsel office should receive the recommendations by the Division Counsel office no later than 10 days from the date of the appealable order. The Associate Chief Counsel office will consider this recommendation, in addition to other recommendations, in drafting any recommendations for or against appeal, certiorari, or issuance of an Action on Decision.

2. The Associate Chief Counsel attorney will consider and describe Division Counsel's recommendation in the transmittal to the Associate Chief Counsel recommending appeal. Under these procedures, it is contemplated that the Division Counsel and Associate Chief Counsel attorney will reach consensus and, to the extent that they do not, will elevate the issues appropriately to their respective superiors. The Division Counsel and the Associate should reach consensus on the handling of significant matters. In the event that they cannot agree, unresolved issues shall be raised to the Chief Counsel level.


**36.1.1.7.3** **(08-11-2004)**

#### Letter to Department of Justice

1. The Associate Chief Counsel attorney assigned to the case is responsible for drafting an appeal recommendation. See CCDM 36.2.1.1 Preparation of Appeal Letters.

2. Appeal letters should generally be provided to the Department of Justice by a date agreed to with the Appellate Section or within 30 calendar days of the date of entry of the unfavorable order by the court to ensure that the views of the Chief Counsel office are available to inform the Solicitor General's decision whether to appeal. See CCDM 36.2.6.2.2.1.1, Letter to Department of Justice, which provides for a 60-day deadline.


**36.1.1.7.4** **(08-11-2004)**

#### Technical Assistance to the Department of Justice

1. The Department of Justice may request assistance from the Office of Chief Counsel while the appeal is pending. Associate Chief Counsel attorneys should promptly inform their reviewer of any requests and provide appropriate assistance. This may involve obtaining information from the Area Counsel office or the area director with regard to the specific case or it may involve explaining, refining or clarifying the Service's technical position or administrative practice in similar cases on related issues. If the attorney cannot furnish the assistance from information available (for example, if the problem relates to administrative or accounting aspects of the case rather than legal), the attorney should arrange with the appropriate Area or Division Counsel office or the appropriate Commissioner's office to promptly render the assistance. The attorney should also provide pertinent information as the case progresses, such as calling attention to relevant rulings or court decisions that arise after referral of the case to the Department of Justice.

2. The Department of Justice may inquire as to the administrative importance of a case or issue. It may ask for information concerning the number of pending cases involving the issue or issues on appeal. This often happens in cases in which a petition for a writ of certiorari or a motion for rehearing may be filed by the Government or the taxpayer. The Associate Chief Counsel Attorney should coordinate gathering such statistics with the help of Division Counsel and IRS personnel.


**36.1.1.7.5** **(08-11-2004)**

#### Review of Appellate Briefs

1. Associate Chief Counsel attorneys should request advance (draft) copies of the briefs prepared by the Appellate Section to ensure adherence to Service position in unusually significant or sensitive cases. Generally, however, the Department of Justice files the briefs before review by the Chief Counsel's office. Copies of the briefs are furnished to the Chief Counsel after filing.

2. The Associate Chief Counsel attorney should review each brief promptly to ensure that it reflects Service position on the issue. Upon the discovery of any serious departure from Service position, the attorney should immediately discuss the discrepancy with the reviewer and then immediately notify the Department of Justice attorney. The Associate Chief Counsel attorney should then prepare a letter to the Department of Justice explaining the discrepancy in detail so that it can be further considered by the department and perhaps corrected in a reply brief, by letter, or at oral argument.

3. In cases where the department furnishes an advance copy of the Government's brief, either prior to printing or prior to filing, it should be reviewed as thoroughly as possible within the time allowed. Suggestions by the attorney with regard to changes in the brief should be reviewed and approved on behalf of the Chief Counsel by the reviewer before being transmitted to the Department of Justice.

4. In most cases, the Department of Justice provides multiple copies of the brief. In Tax Court cases, the responsible branch should forward one copy to the Digest Room marked microfiche or do not microfiche, depending on the importance of the issue as determined by the branch.


**36.1.1.7.6** **(08-11-2004)**

#### Acknowledgment of Notification of Schedule of Oral Argument

1. Some courts of appeal notify this office of the date and time of oral argument. If such notification is received, the notice should either be faxed to the Appellate attorney at the Department of Justice or the attorney should confirm by telephone that the Appellate attorney has received the notice. It is the responsibility of the Department of Justice attorney to acknowledge receipt of the notice.


**36.1.1.7.7** **(08-11-2004)**

#### Closing the Case to the Area Counsel Office

1. The Associate Chief Counsel attorney is responsible for notifying the Division Counsel office when appellate proceedings are concluded, and closing the case after the necessary action is completed. See CCDM 36.2.4.1, General Procedures for Closing Appeal Cases, and CCDM 36.2.6.5, Closing Procedures Specific to Tax Court Appeals.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part36/irm_36-001-001#addtoany "Show all")

A2A