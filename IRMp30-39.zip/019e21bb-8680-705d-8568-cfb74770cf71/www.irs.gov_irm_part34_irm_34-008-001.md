---
url: "https://www.irs.gov/irm/part34/irm_34-008-001"
title: "34.8.1 Settlement Procedures Overview | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part34/irm_34-008-001#main-content)

- 34.8.1 [Settlement Procedures Overview](https://www.irs.gov/irm/part34/irm_34-008-001#idm140678666489152)
  - 34.8.1.1 [Settlement Letters](https://www.irs.gov/irm/part34/irm_34-008-001#idm140678673814816)

    - 34.8.1.1.1 [Settlement Policy](https://www.irs.gov/irm/part34/irm_34-008-001#idm140678667322400)
    - 34.8.1.1.2 [Settlement Authority](https://www.irs.gov/irm/part34/irm_34-008-001#idm140678667693136)

  - 34.8.1.2 [Settlement Recommendations](https://www.irs.gov/irm/part34/irm_34-008-001#idm140678683573392)

    - 34.8.1.2.1 [Submission of Offers by Tax Division](https://www.irs.gov/irm/part34/irm_34-008-001#idm140678659491792)
    - 34.8.1.2.2 [Initial Consideration of a Proposed Settlement](https://www.irs.gov/irm/part34/irm_34-008-001#idm140678683606288)

      - 34.8.1.2.2.1 [Conflict between Terms of Offer and Department of Justice Acknowledgment](https://www.irs.gov/irm/part34/irm_34-008-001#idm140678682471040)
      - 34.8.1.2.2.2 [Documentation for Proper Evaluation](https://www.irs.gov/irm/part34/irm_34-008-001#idm140678684091776)
      - 34.8.1.2.2.3 [Recomputation of Settlement](https://www.irs.gov/irm/part34/irm_34-008-001#idm140678661521520)

  - 34.8.1.3 [Coordination](https://www.irs.gov/irm/part34/irm_34-008-001#idm140678667376128)

    - 34.8.1.3.1 [Appeals Office, Examination Office](https://www.irs.gov/irm/part34/irm_34-008-001#idm140678667290176)
    - 34.8.1.3.2 [Coordination of Settlement of Related Tax Court and Refund Litigation Cases](https://www.irs.gov/irm/part34/irm_34-008-001#idm140678673321360)
    - 34.8.1.3.3 [Criminal Tax Division](https://www.irs.gov/irm/part34/irm_34-008-001#idm140678667813728)
    - 34.8.1.3.4 [Other Divisions or Offices](https://www.irs.gov/irm/part34/irm_34-008-001#idm140678676535680)
    - 34.8.1.3.5 [Appellate Section, Tax Division, Department of Justice](https://www.irs.gov/irm/part34/irm_34-008-001#idm140678659737760)
    - 34.8.1.3.6 [Direct Mailing of Settlement Letters](https://www.irs.gov/irm/part34/irm_34-008-001#idm140678676228016)
    - 34.8.1.3.7 [Discretionary Review by Associate Chief Counsel](https://www.irs.gov/irm/part34/irm_34-008-001#idm140678679249328)
    - 34.8.1.3.8 [Monitoring of the Direct Mailing Procedure](https://www.irs.gov/irm/part34/irm_34-008-001#idm140678682944016)

# Part 34. Litigation in District Court, Bankruptcy Court, Court of Federal Claims, and State Court

# Chapter 8. Settlement Procedures

# Section 1. Settlement Procedures Overview

* * *

## 34.8.1 Settlement Procedures Overview

#### Manual Transmittal

June 05, 2017

#### Purpose

(1) This transmits revised CCDM 34.8.1, Settlement Procedures; Settlement Procedures Overview.

#### Material Changes

(1) The content of CCDM 34.8.1.1.2, Settlement Authority, has been revised to update current policy on who has authority to sign recommendation letters to DJ concerning settlement offers for taxpayers and taxable periods not in suit on behalf of the Office of Chief Counsel, consistent with Delegation Order 30-2.

#### Effect on Other Documents

CCDM 34.8.1, dated August 11, 2004, is superseded. This section incorporates the procedures in Delegation Order 30-2, dated February 10, 2005.

#### Audience

Chief Counsel

#### Effective Date

(06-05-2017)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**34.8.1.1** **(08-11-2004)**

### Settlement Letters

1. This chapter discusses the policies and procedures governing settlements of litigation pending in courts other than the Tax Court. For procedures governing settlements of Tax Court cases, see CCDM 35.5, Settlement Procedures. Cases classified Settlement Option Procedure (S.O.P.) generally may be settled by the Department of Justice (DJ) on any basis without reference to or the concurrence of the Office of Chief Counsel. If the case is classified Standard, DJ will refer any settlement offer to Counsel for recommendation. If Counsel recommends rejection of the offer, the letter recommending rejection should indicate whether the case is deemed susceptible to settlement and, if so, set forth the basis of an acceptable out-of-court settlement.

2. If a settlement offer affects tax periods or taxpayers in addition to those in suit, the recommendation will be coordinated with the appropriate Examination or Appeals office, and the settlement letter will be prepared for the signature of the appropriate Associate Chief Counsel. Collateral closing agreements may also have to be prepared.

3. If the settlement involves a refund of income, estate, gift, or certain other taxes and assessed interest of more than $2,000,000 to any one taxpayer, the settlement must be submitted for review by the Joint Committee on Taxation. Joint Committee cases should be examined by the attorney for any offsetting adjustments.

4. Counsel may also be asked to compute the amount of refund pursuant to a settlement. The refund computations will normally be prepared by the Appeals Office, and should be reviewed by the Counsel attorney upon their receipt. Particular attention should be given to ensuring that any amounts of assessed interest previously paid by the taxpayer are set out separately and designated as interest so as not to be mistakenly treated by the Service Center as tax paid when determining statutory interest. Any case involving a refund claim which arose from payment of an audit deficiency is likely to include assessed and paid interest.

5. District court settlement letters are prepared in Field Counsel offices and may generally be mailed directly to DJ, unless covering tax periods or taxpayers not in suit, in which case the letter is coordinated with and prepared for the signature of the appropriate Associate Chief Counsel. Associate office review will also be required for letters recommending acceptance of offers in tax shelter cases that do not have outstanding project settlement offers or when the offer for which acceptance is recommended does not conform to the outstanding project settlement offer. Letters involving novel or important issues or significant cases also require Associate office review. In addition, recommendations for settlement of attorney’s fees issues must be reviewed in the appropriate Associate office if administrative costs are requested, any of the requested costs are based on a not substantially justified position of the United States taken prior to the issuance of a statutory notice of deficiency or a final decision of the Appeals office, or costs are for an individual licensed to practice before the Service but not before the district court. Furthermore, Field Counsel may, in their discretion, send any letter to the appropriate Associate office for review.

6. 45-day Settlement Procedure for STANDARD cases. When settlement offers are being considered, cases classified "STANDARD" are subject to a 45-day settlement procedure. Under this procedure, if DJ concludes that Counsel’s response to a request for a settlement recommendation has not been timely made, it may by letter advise the Field Counsel (with a copy to the appropriate Associate Chief Counsel) or the Associate office handling the case that unless it hears from that office within 45 days from the date of the letter (the "45-day letter" ) it will process the case on the assumption that Counsel has no objection to the proposed settlement. Counsel will be considered to have responded to the 45-day letter if, before the end of that period, DJ receives either a recommendation or a request for additional time and an estimate as to when the recommendation will be received.



1. Before initiating the 45-day letter procedures, DJ must have furnished Counsel with everything needed to process the settlement, either in advance of or within the 45-day letter, including a copy of the trial attorney’s memorandum.


7. Settlement Offers Based upon Collectibility. Regardless of whether a case has been classified "S.O.P." , DJ shall refer any settlement offer that is based upon considerations of collectibility to Field Counsel who, in turn, shall forward it to the Area Director for verification.



1. Within two business days of receipt of the Area Director’s response, Field Counsel shall forward the response to DJ. Field Counsel may initial the same or may, by separate letter accompanying the Area Director’s verification, furnish such comments or recommendations as are appropriate.


8. Post-settlement Review. The Department of Justice shall provide Field Counsel with a written explanation as to the settlement reached in each "S.O.P." case. Field Counsel shall forward a copy of such explanation to the Area Director.


**34.8.1.1.1** **(08-11-2004)**

#### Settlement Policy

1. All recommendations regarding settlement must accord with the Principles of Litigation set forth at CCDM 31.1.1.3. The principles embodied in the Settlement Policy with regard to Tax Court cases, _see_ CCDM 31.1.1.3.1, apply equally to recommendations to settle cases referred to DJ, except that consideration of collectibility may play a greater role, particularly in collection cases.


**34.8.1.1.2** **(06-05-2017)**

#### Settlement Authority

1. Cases in Litigation. Pursuant to section 7122, the Secretary of the Treasury may compromise any civil or criminal case arising under the internal revenue laws prior to referral to DJ for prosecution or defense. After referral to DJ, however, only the Attorney General or delegate may compromise the case. Accordingly, in all non-Tax Court litigation cases handled by the Office of Chief Counsel, DJ has complete settlement authority. While the views of Counsel are sought in the most significant cases (e.g., those classified Standard), DJ has authority to settle matters in litigation whether or not the views of Counsel are sought. _See_ CCDM 34.8.1.2.1. As a practical matter, however, DJ will not settle significant cases without eliciting Counsel’s views. Furthermore, because of internal delegations of authority within DJ, the views of the Chief Counsel will generally be given great weight. See Tax Division Directive No. 54, 28 C.F.R., Part O, Appendix to Subpart Y, which explains the settlement authority of the various units of the Tax Division. Neither the Trial Sections nor the Office of Review in the Tax Division, Department of Justice, has been delegated authority to approve settlements that are opposed by the Office of Chief Counsel. Such settlements must be approved at a higher level.

2. Taxpayers and Taxable Periods Not in Suit. Section 5 of Executive Order No. 6166, Organization of Executive Agencies, issued June 10, 1933, transferred from all federal agencies to DJ the functions of prosecuting and defending all claims by and against the United States. Thus, the conduct and control of all federal tax litigation, except that in the Tax Court, is vested in DJ, and the authority to compromise or settle any civil or criminal tax case referred to DJ is codified in section 7122(a) of the Code. Moreover, the question of whether DJ is authorized to compromise or settle years not in suit was answered by the Attorney General in 1934 when he determined: that the effect of Executive Order No. 6166 is to vest in the Attorney General exclusive control of any case after it has been referred to his department; that the Executive Order did not in any way curtail the Attorney General’s prior and plenary power which is in part inherent, appertaining to the office, and in part derived from the various statutes and decisions; and that DJ may compromise non-suit years if they are germane to the matters in suit. 38 Op. Att’y Gen. 98, 124, XIII-2 C.B. 445 (1934), and XIV-1 C.B. 442 (1935).

3. Even though DJ has concluded that it does not need the Service’s consent to settle periods not in suit, DJ nevertheless refers all such settlement proposals to the Service for recommendation in accordance with the agreement of July 28, 1981, between the Service and DJ. **See** Exhibit 35.11.1-26.

4. The authority to sign recommendation letters to DJ concerning settlement offers related to pending refund cases or any other cases or matters referred to DJ for prosecution or defense with respect to persons or periods not in suit, is delegated to Associate Chief Counsel. Additionally, authority is delegated to Associate Chief Counsel to sign recommendation letters concerning settlement offers related to pending refund cases or any other cases or matters referred to DJ for prosecution or defense with respect to:



1. periods not in suit ending prior to the date of the resulting settlement agreement;

2. tax consequences for periods not in suit ending after the date of the settlement agreement that necessarily result from the settlement of the periods in suit;

3. issues conceded in full by the taxpayer for periods not in suit ending after the date of the settlement agreement;

4. persons not in suit for the periods described in (a); and

5. persons not in suit for the items described in (b) and (c). _See_ Deleg. Order No. 30-2


5. Generally, matters not in suit are settled by DJ upon approval of the Service. Occasionally, however, a nunc pro tunc concurrence of Counsel will be sought for settled matters.

6. The Service and DJ have agreed, most recently in the year 2000, that if a proposed settlement offer for persons or periods not in suit provides for the execution of a closing agreement as part of the settlement, the closing agreement must be reviewed only on behalf of the appropriate Division Commissioner or the local Appeals Office or Examination Office (in a field case) prior to the Government’s acceptance of the offer.


**34.8.1.2** **(08-11-2004)**

### Settlement Recommendations

1. Reasons for Settlement. Because of the delay, expense, and burden placed on the courts by the trial of cases, it is in the interest of the government as well as taxpayers to settle cases. There are some cases that present issues that are not susceptible to settlement. Frequently, legal issues arise where the Service position clearly calls for the issue to be defended rather than settled. Other legal issues are litigated because of the value of establishing a precedent. Some factual issues and some legal issues are litigated because the taxpayer fails to make a settlement offer commensurate with the litigating hazards.

2. Objectives of Settlement Recommendations. The primary objective of Counsel’s settlement recommendation, or settlement letter, to DJ is to recommend whether the taxpayer’s settlement offer should be accepted or rejected. Occasionally, Counsel will prepare a settlement letter in response to DJ’s request for Counsel’s views concerning full concession of a case. Normally, the taxpayer will not have submitted a settlement offer if that concession is contemplated. See CCDM 34.10.1.2.2.3 for procedures dealing with attorney’s fees in cases conceded by the Government.

3. Aside from recommending acceptance or rejection of the taxpayer’s offer (or for or against concession), Counsel settlement letters have several other important objectives:



1. Explain in detail to DJ Counsel reasons for or against settlement on the basis proposed so that DJ can better independently evaluate the settlement proposal.

2. If the recommendation is to reject the settlement proposal, Counsel should explore possible alternative bases for settlement that would or might meet with Counsel’s approval. If Counsel suggests a specific offer which would be found acceptable and which is ultimately made by the taxpayer, DJ would not have to elicit Counsel’s views a second time. If Counsel concludes that settlement is inappropriate, and the case should be litigated, it should be so stated.

3. If further facts need to be developed to appropriately evaluate the settlement proposal, Counsel should advise DJ which facts need to be further developed.

4. If the settlement proposal would affect cases pending in other divisions, the recommendation should be coordinated with those divisions.


**34.8.1.2.1** **(08-11-2004)**

#### Submission of Offers by Tax Division

1. Receipt by Tax Division. Offers to settle are normally submitted by taxpayers to the Tax Division of DJ. This is appropriate because DJ possesses the final authority to accept or reject such offers. _See_ CCDM 34.8.1.1.2(1). Often the terms of settlement offers received by the Tax Division have been carefully negotiated by taxpayer’s counsel and the Tax Division trial attorney prior to their submission. However, there are a substantial number of cases in which settlement offers have not been negotiated or even discussed with the Tax Division trial attorney. Accordingly, when an offer is received by a Chief Counsel attorney, it cannot be assumed it was negotiated by or meets with the approval of the Tax Division trial attorney. See CCDM 34.8.1.3.5, Offer Submitted to Field Office, for procedures to be used when a taxpayer submits a settlement offer to Field Counsel.

2. Processing Offers by Tax Division. Generally, settlement offers submitted to the Tax Division have been negotiated by the trial attorney and the taxpayer’s attorney after completion of pretrial discovery.



1. Upon receipt of a settlement offer, its terms will be carefully reviewed by the Tax Division trial attorney. Normally, the trial attorney will then send a letter to taxpayer’s attorney acknowledging the receipt of the offer, setting forth its terms, and stating that it will be given careful consideration. However, where the offer is clearly unacceptable, DJ may summarily reject it.


3. Submission of Offers by Tax Division to Counsel. Whether an offer received by DJ will be submitted to the Field Counsel depends largely upon the case classification. Accordingly, where a case has been classified Standard, DJ must submit the settlement offer to Counsel. The only exception to this rule is where DJ summarily rejects the settlement offer. The summary rejection procedure is only used when the settlement offer is obviously unacceptable. When a case is classified S.O.P., Counsel’s recommendation is not sought, even if the case involves a Joint Committee settlement, unless the settlement proposal covers years of the taxpayer not in suit. DJ generally will not refer a settlement offer for Counsel’s views if one of the exceptions in the agreement dated July 28, 1981, between DJ and the Office of the Chief Counsel is applicable. Furthermore, DJ may seek Counsel’s views on the settlement of S.O.P. cases if it decides such coordination would be desirable. Finally, on occasion DJ will request that a case be reclassified to the S.O.P. category in order to avoid referral of a settlement offer for Counsel’s views.

4. In cases in which DJ seeks Counsel’s views on settlement offers, DJ will send Counsel the following material:



1. A letter requesting Counsel’s views within a certain time period, usually 30 days

2. Copies of the settlement offer

3. Copies of the letter sent to taxpayer’s counsel acknowledging and confirming the settlement offer

4. The administrative file if an adequate retained file is unavailable

5. Additional material developed by the Tax Division, including on some occasions views of the trial attorney or US Attorney, depositions, interrogatories, requests for admissions and answers thereto, additional pleadings, pretrial orders and reports on pretrial conferences, views expressed by the court, additional documentary evidence, and other information obtained in conferences with revenue agents, opposing counsel, etc.


**34.8.1.2.2** **(08-11-2004)**

#### Initial Consideration of a Proposed Settlement

1. Examination of Settlement Offer. Upon receiving a Department of Justice letter seeking Counsel’s views with respect to a proposed settlement, the terms of the proposed settlement should be carefully examined. The attorney should make sure the settlement proposal does not have any ambiguities before consideration is given to the proposal. It would be undesirable to prepare a recommendation only to find the provisions of the taxpayer’s settlement proposal have been misapprehended.

2. Clarification of Offer. If the terms of the settlement proposal are unclear, it is helpful to examine the letter from DJ to the taxpayer or opposing counsel acknowledging the terms of the offer. If the terms of the offer remain unclear after the acknowledgment letter is examined, steps should be taken to have a clarified offer submitted. This can be done formally by letter to DJ, or informally through contact with the Tax Division trial attorney.


**34.8.1.2.2.1** **(08-11-2004)**

##### Conflict between Terms of Offer and Department of Justice Acknowledgment

1. The terms of the taxpayer’s settlement offer and DJ acknowledgment letter should be carefully compared to determine whether there is a conflict between them. Frequently the acknowledgment letter will merely quote or closely paraphrase the offer letter.



1. If a conflict appears, the Tax Division trial attorney should be contacted to determine the reason for the apparent conflict.

2. If the DJ acknowledgment letter is in error, a corrected one should be requested.

3. If the taxpayer’s offer letter does not properly reflect the negotiated settlement, a revised offer should be solicited by the Tax Division.


**34.8.1.2.2.2** **(08-11-2004)**

##### Documentation for Proper Evaluation

1. After examining the settlement proposal and DJ acknowledgment letter, the attorney should determine whether there are sufficient documents in the file to properly evaluate the settlement proposal. This is particularly important if the issues are factual and were not fully developed when the referral letter was written. Counsel attorneys should make sure interrogatories, depositions, and other similar materials related to the offer are available.



1. If such materials are not received, the attorney should request them.

2. If the attorney concludes the facts have not been sufficiently developed to prepare a recommendation, the settlement offer should be rejected.


2. Attorneys generally should not delay an offer in an attempt to develop the facts on their own. Where most of the issues can be discussed based on the facts at hand, however, Counsel should furnish Counsel’s views, if practical, as to the acceptability of that portion of the offer. It would be difficult to express Counsel’s views if the settlement offer is for an overall dollar amount and not all the issues could be evaluated.


**34.8.1.2.2.3** **(08-11-2004)**

##### Recomputation of Settlement

1. Cases are often not settled for specific dollar amounts but on an issue or percentage basis. This is particularly true of refund cases. Thus, if five issues are presented in a case, the Government may be asked to concede two in return for the taxpayer’s concession of the remaining three. Issues may be split. For example, the Government may concede 60 percent of a deduction. A number of ways of settling cases exist. Most settlements require a recomputation of the tax liability to determine the amount of the refund and allocation between tax and interest (or penalty) paid. Where a settlement contemplates a specific dollar refund of tax, a recomputation is still necessary since a computation of the penalties or assessed interest allocable to the refund will be needed. When the Government is conceding a case in its entirety, a recomputation should be prepared since the dollar amount placed in suit by the taxpayer may be overstated unless the amount in suit is the amount determined in an audit and the entire issue giving rise to adjustment is conceded. It may be impossible to predict the ultimate result of a proposed settlement without first having a recomputation as the adjustments may have a cumulative effect which might not be obvious when the proposed settlement is considered on an issue-by-issue basis.



1. If the offer is unacceptable, a recomputation generally should not be prepared. Possible exceptions exist where DJ has specifically requested a recomputation, or where the recomputation will be helpful in determining the basis for an acceptable offer.


2. Timing of Recomputation Request. When an offer letter is received, a recomputation, if one will be necessary, should be requested immediately. On occasion it will be difficult to work on the settlement proposal and have a recomputation prepared since the same files are needed. It is usually preferable to work on the settlement letter. If practical, the files should be divided or copied so work on both the settlement and the recomputation may proceed. Work on the settlement letter should not be delayed while waiting for the results of the recomputation, unless such results are absolutely necessary for an evaluation of the offer. This should rarely occur.



1. The need arises for a recomputation when Counsel is authorized to issue a refund pursuant to a settlement or a judgment. Many settlements are finalized without consulting us because the cases are classified S.O.P. When a recomputation is necessary under these circumstances, the attorney must forward the request for a recomputation within 10 calendar days. The short deadline is necessary to prevent delays in the issuance of refund checks. For further information in the preparation of recomputations, see CCDM 34.6.2.1.1.

2. In some cases the recomputation can be prepared by the attorney, rather than the Appeals office. Good judgment must be exercised in determining the capability for preparing a recomputation. Normally, only the simplest recomputations should be prepared by the attorney. If an attorney has any doubt concerning a recomputation, there should be no reluctance to send it to Appeals. For those cases assigned to an Associate Chief Counsel office, the request for recomputation should ordinarily be made to the Washington Appeals office; however, the Appeals office for the district where the case originated may also be available to assist in the recomputations. Consideration should be given to requesting this assistance in cases involving large corporations or corporations subject to continuous audit as the local office will have a greater knowledge of continuing issues.


3. Forwarding Recomputations. Upon receipt of a recomputation, the attorney should promptly forward three copies of it to the Tax Division.


**34.8.1.3** **(08-11-2004)**

### Coordination

1. In many cases the settlement of one case will have an impact on related cases, or create a precedent for the disposition of pending and future cases. The settlement recommendations in such cases should be sent to the appropriate Associate Chief Counsel office for review and coordination.


**34.8.1.3.1** **(08-11-2004)**

#### Appeals Office, Examination Office

1. If a settlement offer contemplates the settlement of years not in suit or the settlement includes taxpayers not in suit, the offer must be coordinated with either the Appeals office or Division Commissioner’s office which has under consideration the matter or period not in suit. Where coordination is necessary, it should be done as quickly as possible and should not be delayed while the recommendation is being prepared. Accordingly, as soon as a settlement proposal is received, a determination regarding the necessity of coordination must be made.

2. Counsel should refer proposed settlements involving non-suit periods or non-suit parties to the Examination or Appeals office which has jurisdiction. If both Appeals and an Examination office are involved, referral should be to Appeals.

3. It is a simple matter to determine whether the settlement involves a taxpayer not in suit. It is more difficult to determine whether a year not in suit is sufficiently affected to warrant referral of the settlement proposal to Appeals. For example, if the issues in suit involve the basis of an asset for purposes of depreciation as well as its useful life, where the life of the asset extends beyond the years in suit, a settlement will have an impact on post-suit years. However, disposing of these questions is logically necessary to determine how much depreciation should be allowed in the suit years. The depreciation issue could have been settled on a percentage basis (for example, 50 percent allowed, 50 percent disallowed), but behind such percentages there would have to be an understanding as to basis and useful life. If the settlement is limited to disposing of the issue in suit, the settlement does not have to be coordinated with Appeals even though the settlement has an impact on non-suit years. In the basis-useful life case described, the settlement would be considered to encompass non-suit years if a specific depreciation schedule was agreed to for post-suit years. This type of settlement could resolve other issues, such as whether the asset remained in service, whether it remained the property of the taxpayer, whether capital improvements or repairs were made, etc. In this context, the settlement would not be strictly limited to the questions in suit, and would, therefore, require coordination with Appeals.

4. If the issue in question is factual, and the facts vary with each transaction, disposing of the issue for years not in suit requires coordination. For example, the question of whether real estate is held for sale to customers in the ordinary course of trade or business is factual, and each sale must be viewed separately. If this question is disposed of for non-suit years, coordination would be necessary.

5. When a settlement proposal is coordinated with Appeals, Appeals is not advised of Counsel’s views since to do so would unduly delay coordination. Since any settlement must be handled expeditiously, a deadline should be set for receiving the views of Appeals on the settlement proposal.


**34.8.1.3.2** **(08-11-2004)**

#### Coordination of Settlement of Related Tax Court and Refund Litigation Cases

1. Frequently, refund litigation cases are related to Tax Court cases. Settlement offers in such cases must be coordinated.


**34.8.1.3.3** **(08-11-2004)**

#### Criminal Tax Division

1. When a case is related to a criminal matter, it is important that settlement of the case be properly coordinated. When an offer is received to dispose of a case with a related criminal matter, the appropriate Area Counsel (CT), should be sent an information copy of the offer letter. Subsequently, when the proposed settlement letter is sent to the Area Counsel (CT) office with jurisdiction over the case, that office will then decide whether further coordination with the Division Counsel/Associate Chief Counsel (Criminal Tax) is necessary.


**34.8.1.3.4** **(08-11-2004)**

#### Other Divisions or Offices

1. Normally settlement offers are not coordinated with other divisions or offices within the Office of Chief Counsel. The appropriate time to coordinate a case with other divisions and offices is when the referral letter is being prepared setting forth Service position or shortly thereafter. Where there is no initial coordination, coordination may later prove necessary because of developments in the law or a position DJ wishes to take. Formal coordination with other divisions and offices should only be done through the Office of the Associate Chief Counsel (Procedure and Administration). Field Counsel should send all requests for advice concerning settlement to the Associate Chief Counsel (Procedure and Administration), who will forward the request to the appropriate division.


**34.8.1.3.5** **(08-11-2004)**

#### Appellate Section, Tax Division, Department of Justice

1. Cases on appeal to the United States Courts of Appeal are subject to settlement. These settlements involve the Appellate Section of the Tax Division and the Associate Chief Counsel office with jurisdiction over the case. The same considerations and standards applicable to the settlement of cases in the trial courts pertain to this type of settlement. A particularly important factor in determining whether to accept such a settlement is the precedential effect of an appellate decision as well as any potential for seeking Supreme Court review.


**34.8.1.3.6** **(08-11-2004)**

#### Direct Mailing of Settlement Letters

1. All settlement letters prepared in Field Counsel offices may be mailed directly to DJ with the exception of the letters involving issues in tax shelter cases, other novel or important issues, or significant cases.


**34.8.1.3.7** **(08-11-2004)**

#### Discretionary Review by Associate Chief Counsel

1. Notwithstanding the above, Division Counsel, in their discretion, may send any letter to the Associate Chief Counsel (Procedure and Administration) for review.


**34.8.1.3.8** **(08-11-2004)**

#### Monitoring of the Direct Mailing Procedure

1. The Associate Chief Counsel (Procedure and Administration) will monitor the direct mailing procedure to ensure cases warranting Associate Chief Counsel review are receiving it, and to determine whether categories of cases should be added or deleted. A copy of each settlement letter, mailed directly to DJ, shall be sent to the Associate Chief Counsel (Procedure and Administration).


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part34/irm_34-008-001#addtoany "Show all")

A2A