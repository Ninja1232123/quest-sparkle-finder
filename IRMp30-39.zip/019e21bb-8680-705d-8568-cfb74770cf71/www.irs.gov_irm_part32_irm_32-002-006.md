---
url: "https://www.irs.gov/irm/part32/irm_32-002-006"
title: "32.2.6 Circulating Draft Publication Items | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part32/irm_32-002-006#main-content)

- 32.2.6  [Circulating Draft Publication Items](https://www.irs.gov/irm/part32/irm_32-002-006#idm140208756976768)
  - 32.2.6.1  [Circulation Procedures](https://www.irs.gov/irm/part32/irm_32-002-006#idm140208757634656)
  - 32.2.6.2  [Branch Review](https://www.irs.gov/irm/part32/irm_32-002-006#idm140208757639296)
  - 32.2.6.3  [Associate Chief Counsel Approval Prior to Circulation](https://www.irs.gov/irm/part32/irm_32-002-006#idm140208757637776)
  - 32.2.6.4  [General Circulation](https://www.irs.gov/irm/part32/irm_32-002-006#idm140208784415072)
  - 32.2.6.5  [Executive Summary](https://www.irs.gov/irm/part32/irm_32-002-006#idm140208757620704)
  - 32.2.6.6  [Changes to the Proposed Publication](https://www.irs.gov/irm/part32/irm_32-002-006#idm140208757060160)

# Part 32. Published Guidance and Other Guidance to Taxpayers

# Chapter 2. Chief Counsel Publication Handbook

# Section 6. Circulating Draft Publication Items

* * *

## 32.2.6 Circulating Draft Publication Items

#### Manual Transmittal

November 12, 2019

#### Purpose

(1) This transmits revised CCDM 32.2.6, Chief Counsel Publication Handbook; Circulating Draft Publication Items.

#### Material Changes

(1) CCDM 32.2.6, Circulating Draft Publication Items, is being revised to require that the Office of Tax Analysis be included in green circulations.

#### Effect on Other Documents

This section supersedes CCDM 32.2.6 dated August 2, 2018.

#### Audience

Chief Counsel

#### Effective Date

(11-12-2019)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**32.2.6.1** **(08-11-2004)**

### Circulation Procedures

1. The circulation procedures are subject to modification based on the organizational structure and the preferences of the incumbent Division Counsel/Associate Chief Counsel, Chief Counsel, and Commissioner.

2. In certain emergency situations, the Office of Chief Counsel may need to issue published guidance very quickly. In these limited situations, the Associate Chief Counsel may authorize significantly shortening the time period for review, may eliminate certain steps in the review and clearance process, or may otherwise deviate from these procedures in order to have the publication released in a timely manner.


**32.2.6.2** **(08-11-2004)**

### Branch Review

1. After the proposed publication item is drafted, incorporating any comments received through coordination, it is reviewed by a branch reviewer. The branch reviewer examines the pertinent background file and reviews the proposed publication for technical accuracy and appropriate supporting rationale. Clarity, completeness, proper format, and accuracy of citations and cross references are also checked in this review. The branch reviewer is responsible for ensuring that the BIN and Legal Memo contain all the information required by CCDM 32.2.4, Background Information Note (BIN) and Legal Memorandum (Legal Memo), and that the coordination required by CCDM 32.2.5, Coordination and Clearance, has been completed. Upon completion of this review, the branch reviewer’s name and complete telephone number are entered on page 1 of the BIN and the branch reviewer signs on the last page of the BIN.


**32.2.6.3** **(10-28-2011)**

### Associate Chief Counsel Approval Prior to Circulation

1. After a proposed publication has been reviewed by the branch, it is forwarded to the appropriate Associate office for approval prior to circulation.

2. If the Associate office determines that a briefing is necessary, then the Associate office, as appropriate, notifies representatives of the Chief Counsel, the Commissioner, Treasury, and any other office with an interest in the publication item (including the Publications Coordinators or designees from the Division Counsel) of the date, time, and place of the briefing. In advance of the scheduled briefing the Associate office distributes copies of the proposed publication item and all relevant background information to the appropriate personnel.

3. The Associate Chief Counsel decides who briefs the proposed publication to those attending the briefing. Before the briefing ends, the participants agree on the decision (that is, approved, approved with changes, not approved, or some other disposition), the next action to be taken and by whom, and the time frame for completion of the action. If a briefing is conducted, the drafting attorney must draft a conference memorandum summarizing the decisions made at the briefing. A copy of the conference memorandum should be provided to all participants in the briefing within one week of the briefing.

4. If the Associate Chief Counsel determines that no briefing is necessary, then the Associate Chief Counsel (or any other appointed reviewer in the Associate office) reviews the proposed publication item and approves it for general circulation. Once the proposed publication has been circulated additional briefings may be held if appropriate.


**32.2.6.4** **(11-12-2019)**

### General Circulation

1. After the proposed publication item is approved by the appropriate Associate Chief Counsel the item is circulated for general comment to other offices within the Service and Treasury. This general circulation must be done for proposed publication items (except ministerial products).

2. Generally, proposed publication items are circulated to the following offices or individuals:



   - The Deputy Chief Counsel (Technical) or the Deputy Chief Counsel (Operations), as appropriate

   - Other Associate Chief Counsel and their representatives

   - The Publication Coordinator or designee in Large Business and International

   - The Publication Coordinator or designee in Small Business/Self Employed

   - The Publication Coordinator or designee in Wage and Investment

   - The Publication Coordinator or designee in Tax Exempt and Government Entities

   - The National Taxpayer Advocate

   - Counsel to the National Taxpayer Advocate

   - The Assistant to the Commissioner

   - Senior Technical Advisor to the Commissioner (TE/GE)

   - Chief, Appeals and key staff

   - The Director, Tax Forms and Publications and the Technical Advisor to the Director, Tax Forms and Publications

   - The Office of National Public Liaison

   - The Office of the Privacy Advocate

   - Tax Legislative Counsel, Benefits Tax Counsel, or International Tax Counsel, as appropriate

   - The Treasury attorney assigned to the publication

   - Office of Tax Analysis

   - Any internal distribution within the initiating Associate office

   - Any other office or individual within the Service or Counsel with a potential interest in the publication or that were involved in drafting the document


3. Proposed publications are generally distributed for general circulation by email see Exhibit 32.1.6-2 for a sample general circulation email). In all cases, hard copies should be delivered to the Deputy Chief Counsel, and to any office that specifically so requests.

4. The email (or hard copy, if applicable) should clearly state that a proposed publication is being circulated for general comment. A deadline for submitting comments should clearly be stated. Generally, a minimum of one week should be allowed for comments. The email (or hard copy) should provide the name and telephone number of a contact person (usually the drafting attorney) to whom comments should be addressed. It should also contain a brief description of the guidance being provided (for example, a revenue ruling or a revenue procedure) and the subject of the guidance.

5. In addition, the drafting attorney must include an Executive Summary with the general circulation, see CCDM 32.2.6.5.


**32.2.6.5** **(08-11-2004)**

### Executive Summary

1. The Executive Summary generally should be no longer than a page and may be in bullet format. The Executive Summary should not include the detail and background that more appropriately should be included in the BIN and Legal Memo described in CCDM 32.2.4, Background Information Note (BIN) and Legal Memorandum (Legal Memo). See Exhibit 32.1.6-1 for a sample executive summary.

2. The Executive Summary should include:



   - Description of the guidance

   - Why/how guidance was initiated

   - What taxpayers are impacted by the guidance

   - Names of persons with whom the drafting attorney coordinated the guidance, and the outcome of that coordination

   - Whether the guidance is controversial (either internally or externally)

   - Impact on pending litigation and coordination with DOJ, as appropriate

   - Critical dates, if any, for publication (For example, the deadline for filing season readiness, ABA meeting, end of the calendar year, etc. The target publication date is not a critical date)


3. The Executive Summary should be updated to reflect the results of coordination (including the names of the persons with whom the project was coordinated), and included in the orange folder containing the publication package.

4. The Executive Summary should be made part of the background file for the publication project. Since it is a predecisional document that is used to obtain approval for publication, however, the Executive Summary generally may be withheld (or redacted) under the deliberative process privilege if the file is the subject of a FOIA or discovery request.


**32.2.6.6** **(08-11-2004)**

### Changes to the Proposed Publication

1. The drafting attorney may receive comments or suggested changes to the proposed publication in numerous formats, including handwritten markups of the item, redrafted language (either showing the suggested changes (red-lined, strike-out) or incorporated), email comments, and oral suggestions. Copies of all comments should be retained in the background file. Oral comments should be documented with the name and symbols of the person providing comments and the date of the conversation. Changes made directly to an electronic version of the item should be identified by creating a red-lined, strike-out version. The copies retained in the background file should reflect the name of the person requesting the change, the symbols of the person’s office, and the date of the recommended change.

2. The drafting attorney and the assigned reviewer will review the comments and reconcile any disagreements in a similar manner as discussed in CCDM 32.2.5.2, Coordination Within the National Office.

3. The drafting attorney will incorporate any agreed upon comments and suggested changes into the draft publication item. The Draft Date line opposite the CASE-MIS Number on page 1 of the proposed publication must be updated as necessary to reflect the date when the most recent changes were made.

4. When a suggestion is made but no language is proposed for the publication item, the drafting attorney should draft language to include in the proposed publication. If it is not clear what changes are necessary based on the comment, the drafting attorney should contact the person who made the comment and request clarification or request suggested language to address the issue. Where the drafting attorney drafts language responsive to the comment, it may be appropriate to send the revised portion of the publication item to the person who made the comment to obtain concurrence.

5. After all comments are received and incorporated, but prior to formal clearance, the drafting attorney will send a red-lined, strike-out version to the Publication Coordinator or designee in the Division Counsel offices showing all the changes that were made to the circulation version. Any issues that a Division Counsel office has with the proposed publication item must be resolved at this point prior to proceeding to formal clearance.

6. If the draft is extensively revised based on comments received, it may be advisable to conduct a second general circulation. If so, a red-lined version should be included.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part32/irm_32-002-006#addtoany "Show all")

A2A