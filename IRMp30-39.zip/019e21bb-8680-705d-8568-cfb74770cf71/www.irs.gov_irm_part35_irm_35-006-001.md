---
url: "https://www.irs.gov/irm/part35/irm_35-006-001"
title: "35.6.1 Calendar Calls | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-006-001#main-content)

- 35.6.1 [Calendar Calls](https://www.irs.gov/irm/part35/irm_35-006-001#idm139724103996608)
  - 35.6.1.1 [Tax Court Sessions](https://www.irs.gov/irm/part35/irm_35-006-001#idm139724104000752)
  - 35.6.1.2 [Access to Tax Court Facilities in Field Locations](https://www.irs.gov/irm/part35/irm_35-006-001#idm139724104080912)
  - 35.6.1.3 [Responsibility of the Trial Attorney](https://www.irs.gov/irm/part35/irm_35-006-001#idm139724104076768)
  - 35.6.1.4 [Opening of Court](https://www.irs.gov/irm/part35/irm_35-006-001#idm139724073713760)
  - 35.6.1.5 [No Settlement Negotiations before the Trial Judge](https://www.irs.gov/irm/part35/irm_35-006-001#idm139724082372880)
  - 35.6.1.6 [Off-the-Record Chambers Conferences and Telephone Conference Calls](https://www.irs.gov/irm/part35/irm_35-006-001#idm139724103998624)
  - 35.6.1.7 [Default by Petitioner](https://www.irs.gov/irm/part35/irm_35-006-001#idm139724104001616)
  - 35.6.1.8 [Petitioners Duty to the Court](https://www.irs.gov/irm/part35/irm_35-006-001#idm139724072939776)
  - 35.6.1.9 [Reporting Settlements to the Court](https://www.irs.gov/irm/part35/irm_35-006-001#idm139724077963392)
  - 35.6.1.10 [Preliminary Motions](https://www.irs.gov/irm/part35/irm_35-006-001#idm139724083310672)
  - 35.6.1.11 [Trial Dates](https://www.irs.gov/irm/part35/irm_35-006-001#idm139724079243984)
  - 35.6.1.12 [Subpoenaed Witnesses](https://www.irs.gov/irm/part35/irm_35-006-001#idm139724066398480)
  - 35.6.1.13 [Impounding Documents under Subpoena](https://www.irs.gov/irm/part35/irm_35-006-001#idm139724079425616)
  - 35.6.1.14 [Responsibility to Follow Views of Reviewer](https://www.irs.gov/irm/part35/irm_35-006-001#idm139724073105776)
  - 35.6.1.15 [Alternative Dispute Resolution](https://www.irs.gov/irm/part35/irm_35-006-001#idm139724069793744)

# Part 35. Tax Court Litigation

# Chapter 6. Trial

# Section 1. Calendar Calls

* * *

## 35.6.1 Calendar Calls

**35.6.1.1** **(08-11-2004)**

### Tax Court Sessions

1. The Tax Court divides the fiscal year for trial sessions into three terms. The Fall Term generally begins in September; the Winter Term begins in January; and the Spring Term begins in April.

2. The calendar call is the court’s first appearance at a designated location, and it is the beginning of the court’s session. Before the cases are called, most of the judges open with introductory remarks about how the session will be conducted. Unless other arrangements have been made for particular cases, as described below, attorneys should expect all cases which have not been settled or continued to be called.


**35.6.1.2** **(08-11-2004)**

### Access to Tax Court Facilities in Field Locations

1. On occasion, Chief Counsel employees may wish to gain access to Tax Court facilities prior to the opening of a trial calendar in order to set up files, exhibits, or equipment in connection with a scheduled proceeding. Unless arranged beforehand with the presiding judge or other appropriate Tax Court officials with the knowledge of the opposing party, such access may give rise to an appearance of unfairness or impropriety.

2. Tax Court facilities maintained in field locations, including courtrooms and counsel rooms, are spaces belonging to the Tax Court. Access to this space is under the exclusive control of the Tax Court, even when the court’s facilities are located in federal buildings to which Chief Counsel employees otherwise may have access. If Chief Counsel employees require access to any Tax Court space before the commencement of the trial session, they must request permission in advance from either the presiding judge or other appropriate Tax Court official and should follow the directions given with respect to the request for access. For example, if there is a need to deliver and set up voluminous files or exhibits in advance of the commencement of the session in connection with the trial of large case, arrangements should be made through a telephone conference with the presiding judge and opposing party. The judge may require advance contact with the trial clerk at the session or communication with the Office of the Clerk of the Court in Washington, D.C. If the presiding judge is unavailable for a telephone conference, the calendar administrator should contact the Clerks’ Office in Washington by telephone at (202) 606–8754 to make a request.

3. Chief Counsel employees should not under any circumstances enter any of the court’s space without first obtaining permission from the presiding judge or the Office of the Clerk of the Court. This prohibition includes any request that building security or courtroom security officers unlock a courtroom or counsel room. This prohibition also includes any use of any available office keys that may operate locks on courtrooms or counsel rooms in federal buildings. In addition, if Chief Counsel employees arrive at court for a session and find that the facilities have been unlocked and opened by building security or by a court security officer before the arrival of the trial clerk, Chief Counsel employees should not enter the court’s facilities until the trial clerk has arrived, unless advance arrangements have been made as described above.

4. Unauthorized or premature access to courthouse facilities creates a perception problem. Further, the Tax Court’s files and internal papers of the presiding judge, not available to the parties, may have been delivered for storage in the courtroom in advance of the session, or left in the courtroom after each day’s proceedings. Thus, court facilities are restricted when court personnel are not present. If any Chief Counsel employee has possession of any keys to Tax Court facilities, the employee should immediately contact the Special Counsel (Tax Practice & Procedure), in APJP, Branch 3.


**35.6.1.3** **(08-11-2004)**

### Responsibility of the Trial Attorney

1. The Field attorney represents the Service before the United States Tax Court. As such, the duty to the client cannot be overstated. The failure to answer the call of an assigned case is inexcusable. Allowance should be made for possible transportation delays in reaching the courtroom before the calendar call. Whenever the attorney is unable to attend the calendar call, arrangements must be made to substitute another attorney or reviewer to answer the call of any assigned cases on the calendar. If an emergency will prevent anyone from appearing on behalf of the respondent, a telephone call should be made to the trial clerk if possible, or to the Office of the Clerk of the Court in Washington, D.C., at 202–606–8754.


**35.6.1.4** **(08-11-2004)**

### Opening of Court

1. At the calendar call, it is customary for the calendar administrator and a secretary to be seated at respondent’s counsel table. Field attorneys should be seated close to respondent’s counsel table to enable them to proceed to the table as their cases are called. Courtesy dictates that Field attorneys should not be seated at petitioner’s counsel table.

2. At the time designated in the trial calendar, the judge will enter. The clerk will open the session and proceed to call each case in the order in which it appears on the calendar, omitting those cases previously stricken from the calendar. As each case is called, the assigned Field attorney will proceed to respondent’s counsel table. After petitioner or counsel for petitioner has made an appearance, the Field attorney will then enter an appearance as counsel for respondent and report the status of the case, such as that it is ready for trial. Only attorneys in the Office of Chief Counsel admitted to practice before the Tax Court may enter an appearance on behalf of respondent. Unless other arrangements have been made as discussed in CCDM 35.6.1.11, the Field attorney must be prepared to try all of his or her cases on any day of the session.

3. The court may question the parties concerning certain aspects of the case during the calendar call. Being prepared to try the case on that day enables the Field attorney to answer any questions. In any event, the Field attorney should inform the court of the issues, the expected trial time, and the extent to which the facts have been stipulated or the reasons for any failure to stipulate. With the approval of the Field attorney’s reviewer, this may be the appropriate time to request a pretrial or chambers conference, and to explain the need for the court’s assistance. If there is a considerable discrepancy between the estimated trial time given by the attorney at the calendar call and the estimated trial time reported on the Pretrial Memorandum, the attorney should be prepared to explain the difference.


**35.6.1.5** **(08-11-2004)**

### No Settlement Negotiations before the Trial Judge

1. The Field attorney’s reviewer should attend all pretrial, post-trial, or other conferences in chambers scheduled by the court in any case other than a small tax case.

2. Occasionally, the trial judge attempts to participate in settlement negotiations and orders the parties to disclose their prior settlement proposals. If that occurs, the Field attorney and reviewer should refuse to conduct settlement negotiations in the presence of the trial judge. They should respond to questions from the judge regarding respondent’s position on any issue in the case. Often, concessions of issues or agreements as to the existence of certain facts are made in chamber conferences. _See_ CCDM 35.6.1.6 for procedures with respect to such off-the-record agreements.

3. The Field attorney and reviewer may reveal to the trial judge the extent of prior settlement negotiations and, in general terms, the degree to which the parties’ settlement positions differ. Under no circumstances, however, may the Field attorney or reviewer disclose to the trial judge any specific settlement proposals made by either party during the non-docketed or the docketed stages of the case. A specific settlement proposal, for this purpose, includes a proposal made in terms of dollars or percentages, either with respect to the entire case or one or more issues in the case. Likewise, respondent should object if petitioner or petitioner’s representative attempts to reveal to the trial judge specific settlement proposals.

4. Disclosure to the court of specific settlement proposals in small tax cases should not be made by the Field attorney or reviewer. Such disclosures by _pro se_ petitioners or their representatives should be resisted in small tax cases.


**35.6.1.6** **(08-11-2004)**

### Off-the-Record Chambers Conferences and Telephone Conference Calls

1. The trial judge may conduct chambers conferences or telephone conference calls in which discovery schedules, stipulation difficulties, the parties’ positions on the issues, and other pretrial issues are discussed. Occasionally, the parties’ recollection of facts or issues agreed upon differs from that of the trial judge or each other. Since there is no transcript, there is often little the Field attorney can do to counter the judge’s or the opposing counsel’s contrary memories. In these instances, the attorney should consult with the reviewer as to the advisability of memorializing any agreements, or the lack of an agreement, for the record. Sound judgment is required in these instances. In general, it is a better practice to confirm, in writing, any agreements or concessions made by the parties in contacts where no transcript will be prepared.

2. If such a conference is held during a trial session, and it is advisable to memorialize any agreements or the lack of an agreement, a court reporter is normally available to record the results of the conference for the record. The attorney should request the court’s permission to state the substance of the conference on the record. The attorney should state the terms of any stipulations reached, as the Field attorney understands them. In addition, the Field attorney should state for the record, that, while other matters were discussed, no other agreements were reached. Example: " The parties just concluded a chambers conference with the court. We agreed to stipulate that \[describe stipulated matters\], and we agreed to file a written stipulation to that effect by \[date\]. While other matters were discussed, no other agreements were reached."

3. Telephone conference calls have been widely used by the court to conduct pretrial scheduling in lieu of formal status hearings. Since opportunities for misunderstandings exist, Field attorneys should consult with reviewers and use judgment concerning whether to follow up with a letter to the petitioner’s representative, with a copy to the trial judge, confirming the agreements reached and acknowledging those areas in which agreements were not reached. In general, it is a better practice to confirm in writing any agreements or concessions made by the parties in contacts where no transcript will be prepared.


**35.6.1.7** **(08-11-2004)**

### Default by Petitioner

1. If no appearance is made by or on behalf of petitioner, the Field attorney should normally move to dismiss the case for the lack of prosecution.

2. Before proceeding to the trial of the issue(s) on which respondent bears the burden of proof (persuasion or production), the Field attorney should consider the feasibility of moving for dismissal for failure to prosecute, or for a default judgment, and meeting respondent’s burden on penalty issues by attaching documentary evidence to the motion or, if affirmative allegations in the answer have been made, by asking the court to deem such allegations admitted. For example, in a nonfiler situation, a certified transcript attached to the motion should be sufficient to satisfy respondent’s burden, without the need for a trial. Similarly, where negligence is at issue, it may be appropriate to attach a declaration by the revenue agent. For motions with respect to the burden on penalties or additions to the tax, under section 7491(c), _see_ CCDM 35.3.1.14. For motions for default or dismissal generally, _see_ CCDM 35.3.4.5.


**35.6.1.8** **(08-11-2004)**

### Petitioner’s Duty to the Court

1. The petitioner’s representative has the duty to represent petitioner before the court. The Field attorney should not arrange to make a representation to the court on petitioner’s behalf. Any exceptions to this prohibition must be approved in advance by the Field attorney’s reviewer, and normally such approval will only be given under unusual circumstances regarding perfunctory matters, such as indicating petitioner’s acquiescence to a routine motion. Settlement stipulations usually may be filed without the presence of petitioner’s representative. (Some judges may insist that petitioner’s representative be present. The calendar administrator should attempt to ascertain the practice of the judge handling the session in this regard by consulting the Post Trial Calendar Report on TLCATS.)


**35.6.1.9** **(08-11-2004)**

### Reporting Settlements to the Court

1. Decision documents should be submitted for filing at the calendar call, or before the calendar call, if permitted by the court. To submit a decision document at the calendar call, the Field attorney should enter an appearance, state that the parties settled the case and executed a decision document, and state that the respondent would like to submit it for filing. The attorney should then ask for permission to approach the clerk with the decision document. The decision document may be submitted at the calendar call by the attorney or reviewer, as determined by the reviewer.

2. Where the parties have reached a basis of settlement, but the documents have not been completed and/or executed by the parties, the Field attorney may represent to the court only that a basis of settlement has been reached. The Field attorney should request that the parties be permitted to read the terms of the settlement into the record, and may also ask the court to recall the case during the session for the submission of the decision document.

3. Particular care must be taken when a case is reported as settled. If the settlement is dependent on future actions, such as the petitioner’s producing proof of an expenditure or the execution of a closing agreement affecting nondocketed years, the case is not, in fact, settled. When the status is reported, the conditions or qualifications for a prospective settlement must be clearly stated. If a delay occurs in submitting the decision document following a representation that the case is settled, the court may issue an order to show cause as to why the decision has not been submitted or why the case should not be disposed of under T. C. Rule 123 (default and dismissal). Such show cause orders may also include a pointed reference to Rule 202, concerning disqualification, suspension, or disbarment of counsel who previously reported the case as settled. If care is not taken to communicate the conditions to achieving a final, binding settlement agreement, the court may enforce a reported settlement agreement, even though it has not been finalized through the execution of a decision document, and even though one of the parties no longer agrees to be bound. _See_ CCDM 35.5.2 for Counsel settlements.


**35.6.1.10** **(08-11-2004)**

### Preliminary Motions

1. After the parties enter their appearances, preliminary motions are often made. A motion for a continuance may be argued at this time. When it is anticipated that petitioner’s representative will file a motion for a continuance, and, after consultation with the reviewer, the Field attorney is instructed to oppose the motion, the attorney in opposition to the motion should present the record of any prior continuances of the case along with all other arguments and material which support the Service’s argument. It is advisable to submit written motions pertaining to the pleadings or for the consolidation of related cases, particularly where such motions may affect the anticipated trial time or the trial date. Because preliminary motions may require considerable time for argument, they should be brought to the court’s attention prior to the session, such as in the respondent’s Pretrial Memorandum or during a conference call with the court. _See_ CCDM 35.3 for motions generally.


**35.6.1.11** **(08-11-2004)**

### Trial Dates

1. While the Field attorneys and reviewers are responsible for preparing their assigned cases for trial, the calendar administrator has coordination and reporting responsibilities. As such, the calendar administrator may be aware of the judge’s scheduling preferences before the session begins and can serve as a resource for the Field attorneys and reviewers. All scheduling matters should be coordinated with the calendar administrator.

2. The court must have the ability and the flexibility to set the time of trial of all cases. Therefore, the Field attorney should make no agreement with petitioner’s counsel for a particular trial time. The attorney may, however, after coordinating with the reviewer and the calendar administrator, inform petitioner’s counsel that respondent will not object to petitioner’s request. Moreover, the parties may make a joint request for a conference call with the court for the purpose of requesting a date and time certain. Such a request may be justified by the distances which witnesses must travel, or the anticipated trial time and complexity of the case.

3. In rare instances, prior to the calendar call, it may be necessary for the calendar administrator to communicate to the court information concerning the cases which are to be tried and to inform the court of any suggested trial dates to which the parties have agreed and why. The administrator may not discuss the procedural or substantive merits of a particular case. The administrator should not arrange the trial date of any other cases on the assumption that the court will grant a specific trial date for any case. The extent to which the court adopts the requested trial dates varies from judge to judge. Often, the court will not set specific trial dates, and will set only the order of the trials. The Field attorneys and reviewers must be ready for trial immediately after the calendar call, unless the court previously granted a specific date and time for trial of a case.

4. Upon the completion of the calendar call, the court normally takes a short recess, and schedules the hearings and the trials. After the recess, the court announces the order, and may or may not set specific dates and times for all trials. If the court inadvertently omitted a case from its announcement of the order of the trials and the hearings, the calendar administrator should immediately bring it to the court’s attention.


**35.6.1.12** **(08-11-2004)**

### Subpoenaed Witnesses

1. After the setting of the order of the trials, if respondent’s subpoenaed witnesses are present in the courtroom, and if the Field attorney has concerns about their appearance at the trial, the Field attorney may ask the court to instruct the witnesses to appear on the designated trial date.


**35.6.1.13** **(08-11-2004)**

### Impounding Documents under Subpoena

1. If documents were brought to the courtroom in response to respondent’s subpoena duces tecum, but the witness asserts a privilege or otherwise refuses to make them available, the Field attorney may ask the court to take custody of the documents and permit respondent to examine them prior to trial.


**35.6.1.14** **(08-11-2004)**

### Responsibility to Follow Views of Reviewer

1. If, in the course of preparing a case for trial, there have been any disagreements concerning any position to be taken by respondent between the Field attorney and reviewer, and if the Field attorney has been instructed to take a certain position by the reviewer either at the calendar call or at the trial of the case, the Field attorney must follow such instructions or directions. If the facts and circumstances have altered to the extent that new instructions would be appropriate, the attorney should consult with the reviewer.


**35.6.1.15** **(08-11-2004)**

### Alternative Dispute Resolution

1. _See_ CCDM 35.5.5, Arbitration and Mediation, for alternative means to resolving disputes.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-006-001#addtoany "Show all")

A2A