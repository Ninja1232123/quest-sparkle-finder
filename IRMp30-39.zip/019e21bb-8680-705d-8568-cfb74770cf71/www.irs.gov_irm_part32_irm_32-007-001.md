---
url: "https://www.irs.gov/irm/part32/irm_32-007-001"
title: "32.7.1 Counsel Review of Fact Sheet FAQs | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part32/irm_32-007-001#main-content)

- 32.7.1  [Counsel Review of Fact Sheet FAQs](https://www.irs.gov/irm/part32/irm_32-007-001#idm140442452645408)
  - 32.7.1.1  [Overview](https://www.irs.gov/irm/part32/irm_32-007-001#idm140442452769248)
  - 32.7.1.2  [Review of Fact Sheet FAQs](https://www.irs.gov/irm/part32/irm_32-007-001#idm140442452765888)
  - 32.7.1.3  [Format of Fact Sheet FAQs](https://www.irs.gov/irm/part32/irm_32-007-001#idm140442452763104)

# Part 32. Chief Counsel Directives Manual Published Guidance and Other Guidance to Taxpayers

# Chapter 7. Frequently Asked Questions

# Section 1. Counsel Review of Fact Sheet FAQs

* * *

## 32.7.1 Counsel Review of Fact Sheet FAQs

#### Manual Transmittal

July 21, 2022

#### Purpose

(1) This transmits new CCDM 32.7.1, Counsel Review of Fact Sheet FAQs.

#### Material Changes

(1) CCDM 32.7.1.1, Overview, provides an overview of the procedures for Counsel review and approval of certain frequently asked questions (FAQs) that the Executive Counsel determines should be issued in the form of "Fact Sheet FAQs."

(2) CCDM 32.7.1.2 Review of Fact Sheet FAQs, sets forth procedures for Counsel review of Fact Sheet FAQs.

(3) CCDM 32.7.1.3 Format of Fact Sheet FAQs, specifies the content and format required for Fact Sheet FAQs, including model disclaimer language.

#### Effect on Other Documents

Chief Counsel Notice 2022-006, _Procedures for review and posting of certain frequently asked questions (FAQs) on IRS.gov_, issued June 30, 2022, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(07-21-2022)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure and Administration)

**32.7.1.1** **(07-21-2022)**

### Overview

1. The Chief Counsel Office of Executive Counsel (Executive Counsel) will serve as the primary point of contact for the review, clearance and issuance of Fact Sheet FAQs. In addition, the role of Executive Counsel includes determining which FAQs are subject to these procedures and coordinating review of Fact Sheet FAQs among the various stakeholders, including the IRS (as further described below), the Associate Offices with subject matter jurisdiction, the relevant Division Counsel, the Chief Counsel, and Treasury.

2. These procedures apply to FAQs prepared for newly enacted legislation and in other contexts, such as emerging issues, as appropriate, where no pre-existing Internal Revenue Bulletin guidance, including regulations, has been issued. The procedures provide clarity regarding taxpayer reliance on Fact Sheet FAQs and ensure that Fact Sheet FAQs are archived and searchable on IRS.gov, so taxpayers can later locate the version they relied on should they need to do so.

3. Questions as to whether these procedures apply to any particular set of FAQs should be addressed to Executive Counsel.


**32.7.1.2** **(07-21-2022)**

### Review of Fact Sheet FAQs

1. Counsel attorneys and reviewers who are drafting FAQs or reviewing FAQs that have been drafted by the IRS should coordinate with Executive Counsel if the FAQs address newly enacted legislation or an emerging issue to determine if FAQs are subject to these procedures.

2. The Associate office will draft and approve the Fact Sheet FAQs under normal procedures including, if appropriate, Treasury review. Once that process is completed, further review, clearance and issuance will be coordinated by Executive Counsel. Executive Counsel will coordinate with other Associate offices, the Deputy Chief Counsel, Senior Advisor to the IRS Deputy Commissioner for Services and Enforcement (DCSE), and the Treasury Department, as appropriate, to ensure that all interested parties have the opportunity to review.


**32.7.1.3** **(07-21-2022)**

### Format of Fact Sheet FAQs

1. Executive Counsel will coordinate with the Associate Office and with Communications and Liaison (C&L) to ensure that Fact Sheet FAQs are incorporated into an IRS Fact Sheet linked to an IRS News Release using appropriate format and disclaimer language, as described in this section 32.7.1.3.

2. The IRS Fact Sheet should include:



   - Reciprocal links between the Fact Sheet and News Release.

   - Standard disclaimer language with a link to the Reliance Page, a number assigned by C&L, and the date.

   - If the Fact Sheet revises or updates a prior Fact Sheet, a note at the top of the page indicating the FAQ is a revision of a prior Fact Sheet, the number of the prior Fact Sheet, and the specific FAQs from the prior Fact Sheet that are superseded. Link between the prior and current Fact Sheet (and corresponding News Releases).


3. The following model disclaimer language should be used on all Fact Sheets containing Fact Sheet FAQs:



**Below are answers to frequently asked questions (FAQs) related to \[fill in the blank\]. These FAQs are being issued to provide general information to taxpayers and tax professionals as expeditiously as possible. Accordingly, these FAQs may not address any particular taxpayer’s specific facts and circumstances, and they may be updated or modified upon further review. Because these FAQs have not been published in the Internal Revenue Bulletin, they will not be relied on or used by the IRS to resolve a case. Similarly, if an FAQ turns out to the an inaccurate statement of the law as applied to a particular taxpayer’s case, the law will control the taxpayer’s tax liability. Nonetheless, a taxpayer who reasonably and in good faith relies on these FAQs will not be subject to a penalty that provides a reasonable cause standard for relief, including a negligence penalty or other accuracy-related penalty, to the extent that reliance results in an underpayment of tax. Any later updates or modifications to these FAQs will be dated to enable taxpayers to confirm the date on which any changes to the FAQs were made. Additionally, prior versions of these FAQs will be maintained on IRS.gov to ensure that taxpayers, who may have relied on a prior version, can locate that version if they late need to do so.**



**For more information about reliance see: https://www.irs.gov/newsroom/general-overview-of-taxpayer-reliance-on-guidance-published-in-the-internal-revenue-bulletin-and-faqs.**

4. If applicable, the disclaimer language should include a statement that the Treasury Department and the IRS continue to consider publishing additional guidance in the Internal Revenue Bulletin on the issues addressed in the Fact Sheet FAQs.

5. The standard disclaimer language should appear at the top of all Fact Sheets containing Fact Sheet FAQs, with a link to the Reliance Page. In the first sentence of the disclaimer, a description of the legislation or guidance to which the FAQs relate should be filled in within the space provided.

6. If the Fact Sheets are late updated or modified, a "Note" in bold should be added at the top indicating that the Fact Sheet is a revision of a prior Fact Sheet. Sample language for revised/updated Fact Sheet FAQs:



### Note:



**These FAQs supersede earlier FAQs that were posted in FS-20XX-XX on \[date\].**

7. When the Fact Sheet FAQs are ready to issuance, the IRS Fact Sheet and IRS News Release are posted on IRS.gov and later added to the Fact Sheet/News Release archive on IRS.gov.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part32/irm_32-007-001#addtoany "Show all")

A2A