---
url: "https://www.irs.gov/irm/part35/irm_35-009-001"
title: "35.9.1 Tax Court Opinions and Decisions | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-009-001#main-content)

- 35.9.1 [Tax Court Opinions and Decisions](https://www.irs.gov/irm/part35/irm_35-009-001#idm140379494964944)
  - 35.9.1.1 [Issuance By The Tax Court](https://www.irs.gov/irm/part35/irm_35-009-001#idm140379495032448)
  - 35.9.1.2 [Review of Tax Court Opinions](https://www.irs.gov/irm/part35/irm_35-009-001#idm140379460233744)

    - 35.9.1.2.1 [Review by Field](https://www.irs.gov/irm/part35/irm_35-009-001#idm140379461123408)

      - 35.9.1.2.1.1 [Favorable Opinion Review](https://www.irs.gov/irm/part35/irm_35-009-001#idm140379494974944)
      - 35.9.1.2.1.2 [Adverse Opinion Review](https://www.irs.gov/irm/part35/irm_35-009-001#idm140379462773120)
      - 35.9.1.2.1.3 [Follow-up Responsibilities](https://www.irs.gov/irm/part35/irm_35-009-001#idm140379467262848)

    - 35.9.1.2.2 [Review in the Appropriate Associate Office](https://www.irs.gov/irm/part35/irm_35-009-001#idm140379458391024)

      - 35.9.1.2.2.1 [Favorable Opinion Review](https://www.irs.gov/irm/part35/irm_35-009-001#idm140379474739136)
      - 35.9.1.2.2.2 [Adverse Opinion Review](https://www.irs.gov/irm/part35/irm_35-009-001#idm140379459374528)

    - 35.9.1.2.3 [Listing of Counsel for Respondent in Tax Court](https://www.irs.gov/irm/part35/irm_35-009-001#idm140379474919312)
    - 35.9.1.2.4 [Motions for Reconsideration of Findings or Opinion](https://www.irs.gov/irm/part35/irm_35-009-001#idm140379462956112)

  - 35.9.1.3 [Review of Tax Court Decisions](https://www.irs.gov/irm/part35/irm_35-009-001#idm140379465882416)

    - 35.9.1.3.1 [Finality of Tax Court Decision](https://www.irs.gov/irm/part35/irm_35-009-001#idm140379451907312)
    - 35.9.1.3.2 [Motions Regarding Decisions](https://www.irs.gov/irm/part35/irm_35-009-001#idm140379458101200)

      - 35.9.1.3.2.1 [Motions to Vacate or Revise Decision](https://www.irs.gov/irm/part35/irm_35-009-001#idm140379466341024)
      - 35.9.1.3.2.2 [Statutory Interest Determinations](https://www.irs.gov/irm/part35/irm_35-009-001#idm140379495039104)
      - 35.9.1.3.2.3 [Taxpayer Motions to Modify Decisions in Section 6166 Estate TaxCases](https://www.irs.gov/irm/part35/irm_35-009-001#idm140379457007472)

  - 35.9.1.4 [Post-review Significant Case Procedures](https://www.irs.gov/irm/part35/irm_35-009-001#idm140379444583792)

# Part 35. Tax Court Litigation

# Chapter 9. Post Opinion Activities

# Section 1. Tax Court Opinions and Decisions

* * *

## 35.9.1 Tax Court Opinions and Decisions

**35.9.1.1** **(08-11-2004)**

### Issuance By The Tax Court

1. This section sets forth the actions taken by the Service following the issuance by the Tax Court of its opinion and decision. The purpose of this section is to provide step-by-step assistance to Field attorneys and Associate offices after the Tax Court has completed its consideration of a case.

2. The material in this chapter uses the term deficiency. Worker classification employment tax cases under section 7436 do not involve a deficiency (as defined in section 6211). The principles set forth below, however, apply to section 7436 cases as if the section 7436 notice of determination were a notice of deficiency. In addition, decisions in certain post-assessment proceedings such as interest abatement, spousal relief, and collection due process cases do not necessarily determine "deficiencies." Often, such cases determine "liabilities" or determine periods of interest abatement or other forms of relief.

3. It is important to distinguish between opinion and decision, as the terms are not interchangeable. The opinion is the written determination of the Tax Court on the issues tried and submitted to the court for decision. The opinion is filed by the court. The decision of the Tax Court is based upon its opinion and is the determination of the resulting deficiency or overpayment. A decision is entered by the court, and appeal is taken from the court’s decision. Another point to remember about a Tax Court decision is that a separate decision is entered for each docket number, even though several docketed cases may be consolidated for purposes of trial, briefing, and opinion. There may be occasions where more than one decision is entered in a single docket; _e.g._, where petitioners’ cases have been severed after the filing of a joint petition.

4. In most cases, the last lines of the court’s opinion will state whether the decision is to be entered for the petitioner (taxpayer), for the respondent (Service), or under T.C. Rule 155. A decision will be entered for the petitioner when the taxpayer has prevailed on all of the issues before the court and has not made any concessions. In this situation, the decision will state that there is no deficiency in tax for the year or years before the court, or that there has been an overpayment in a specific amount. A Rule 155 computation is also appropriate if either party has raised adjustments in addition to those in the statutory notice.

5. A decision will be entered for the respondent when the Service has prevailed on all of the issues before the court and has not made any concessions. In this situation, the decision will reflect the deficiency (and additions to tax and penalties, if any) as determined by the Service in the statutory notice of deficiency.

6. Neither of the above situations requires a recomputation of the deficiency. There is either no deficiency or the deficiency remains the same as determined in the statutory notice of deficiency.

7. Decisions will be entered under T.C. Rule 155 in instances where the court has resolved some issues in favor of the petitioner and some in favor of the respondent, and in instances where the prevailing party has conceded one or more issues. In these cases, a deficiency reflecting the concession(s) and/or the court’s opinion must be recomputed and the computation filed with the court by the Field attorney.

8. In cases where the decision will be entered for the respondent, the court will likely enter the decision on the same day the opinion is filed or very shortly thereafter. In cases where the decision will be entered for the petitioner, the court may withhold entry of decision for 30 days or more in order to permit the filing of a motion for an award of reasonable litigation costs pursuant to section 7430. _See_ T.C. Rule 231(a)(2). In T.C. Rule 155 cases, the decision may not be entered for weeks or months following the issuance of the opinion. The entry of a decision in T.C. Rule 155 cases is dependent upon prompt submission of a proposed recomputation by the parties. _See_ T.C. Rule 155(a).


**35.9.1.2** **(08-11-2004)**

### Review of Tax Court Opinions

1. Once the Tax Court has issued its opinion and/or entered its decision, authority to take any action regarding the opinion and/or decision shifts to the appropriate Associate office. This rule applies to settled cases as well as to cases decided on the merits. Therefore, with the exception of T.C. Rule 155 computations, any further action with respect to the opinion and/or decision must be reviewed and approved for filing by the appropriate Associate office. Field Counsel’s responsibilities and functions are discussed below.


**35.9.1.2.1** **(08-11-2004)**

#### Review by Field

1. It is the Field attorney’s responsibility to examine all opinions and decisions to ensure that they conform to the pleadings and that all issues involved have been covered so that the decision is the final, accurate disposition of all phases of the case.


**35.9.1.2.1.1** **(08-11-2004)**

##### Favorable Opinion Review

1. In cases in which the court decides the issues favorably to the Service, it is the duty of the Field attorney to examine the primary facts found by the court to determine if the primary facts found support the ultimate facts, and if the facts found by the court are sufficient to support the court’s legal holding. Field Counsel should bring to the attention of the appropriate Associate office any material defect in the opinion or decision.


**35.9.1.2.1.2** **(08-11-2004)**

##### Adverse Opinion Review

1. Upon receipt of an adverse opinion (either a loss or a split opinion), the Field attorney should determine which issues were decided adversely to the Service, keeping in mind that further actions taken with respect to the adverse opinion must be coordinated with the appropriate Associate office. Additionally, all motions prepared in response to an adverse opinion require not only appropriate Associate office review and approval, but some may also require review and approval at higher levels. There are several motions which can be filed, depending on the circumstances of the case, which are discussed below. With respect to adverse opinion review, the Field attorney should keep in mind the following post opinion possibilities:



   - Motion for Reconsideration of Findings or Opinion. _See_ CCDM 35.9.1.2.4.

   - Motion to Vacate or Revise Decision. _See_ CCDM 35.9.1.3.2.1.

   - Protective Appeal and Cross-Appeal. _See_ CCDM 36.1.1.2.2.

   - Appeal of Case. _See_ CCDM Part 36

   - Action on Decision. _See_ CCDM 36.3.


**35.9.1.2.1.3** **(08-11-2004)**

##### Follow-up Responsibilities

1. Field attorneys should consult the provisions of CCDM 35.9.2.7.1 regarding cases remanded to the Tax Court and recomputations, and CCDM 35.9.2 for assessment responsibilities.


**35.9.1.2.2** **(08-11-2004)**

#### Review in the Appropriate Associate Office

1. When Tax Court opinions are received, the Technical Services Support Branch in the office of the Associate Chief Counsel (P&A) reviews them and designates them (W) wins, (S) splits or (L) losses. The determination is based on how the court held on the tried issues discussed in the opinion. The result is entered on TLCATS CTRI (trial record screen).



1. Once the opinion has been recorded by the Associate Chief Counsel (P&A), it is forwarded to the responsible Associate office and assigned to an attorney or paralegal.

2. The Associate attorney must take affirmative steps to ascertain whether a decision has been entered and the status of the decision documents. The Tax Court’s web site at www.ustaxcourt.gov should be consulted. Associate attorneys can also contact the Field attorney to ascertain whether the Field attorney is aware of a decision having been entered. If it has been determined that the decision has not yet been entered, and no further documents need to be filed with the Tax Court prior to entry of the decision ( _e.g._, where an opinion states that the decision will be entered for petitioner or stipulated decision documents have been filed), the Field attorney or Associate attorney should contact APJP, Branch 3, who will communicate with the court to determine why the expected decision has not yet been entered.


**35.9.1.2.2.1** **(08-11-2004)**

##### Favorable Opinion Review

1. When an Associate attorney is assigned a favorable opinion, the Field attorney is responsible for verifying, by a careful reading, that the Service has prevailed on all issues. If not, this fact should be brought to the attention of the attorney’s reviewer (or branch chief). If a favorable opinion is verified, the attorney should keep the copy of the opinion in the attorney’s files. When the decision is entered in the case, a copy of the decision will be forwarded to the attorney who will file the copy of the decision along with the copy of the opinion in the attorney’s files. If the appeal period expires and the petitioner has not filed a notice of appeal, the attorney should wait an additional ten days before discarding both copies. In general, the appeal period is 90 days from the date of the entry of decision. _See_ CCDM Part 36, Appellate Litigation and Actions on Decision, for a discussion of the time limitations for filing a notice of appeal. The additional ten-day waiting period provides for the possibility that the petitioner’s notice of appeal was timely mailed by the petitioner but not received by the Tax Court by the 90th day.

2. Upon receipt of the opinion, the petitioner may file a motion for reconsideration of findings or opinion. When the decision is entered in the case, the petitioner may file a motion to vacate or revise the decision. If the petitioner files either motion, Field Counsel may be required to file a response. Field Counsel’s response must be reviewed and approved for filing with the Tax Court by an Associate attorney and reviewer.

3. When reading the Tax Court’s opinion, the Associate attorney should be alert to any circumstances which would indicate that the Service should file a protective appeal or a cross-appeal. These appeals are discussed at CCDM **36.1.1.2.2** . The need for such action is usually apparent from a reading of the opinion, but the Associate office relies heavily on Field Counsel for recommendations of protective appeals or cross-appeals.


**35.9.1.2.2.2** **(08-11-2004)**

##### Adverse Opinion Review

1. Unlike a favorable opinion review, an adverse opinion review requires that an Associate Chief Counsel attorney write a memorandum to a reviewer. The memorandum itself is referred to as an adverse opinion review. The purpose of the adverse opinion review memorandum is twofold: to determine whether any or all of the issues decided adversely to the Service should be appealed, and to determine whether an action on decision should be prepared. Actions on Decision are discussed fully in CCDM 36.3.

2. Although the attorney will be reviewing the opinion, it is the decision that will be appealed. _See_ CCDM Part 36, for a detailed discussion of appellate procedure. Also, if an appeal is recommended, the recommendation must be reviewed at several levels. Any letter recommending appeal must be prepared for signature by the Chief Counsel. Accordingly, time is always of the essence in submitting an adverse opinion review.

3. Upon receipt of an adverse opinion, designated either (S) split or (L) loss, an Associate attorney should take the following steps:



1. If the Associate attorney believes the legal file is needed as an aid in review, he or she may call the Field attorney who handled the case in the Tax Court and request that the legal and any miscellaneous law files be sent to the appropriate Associate office. Judgment should be exercised when requesting the legal file for initial adverse opinion review, since the Field Counsel may need it for preparation of the T.C. Rule 155 submission or for other purposes.

2. If the Service has lost any issues within the jurisdiction of another Associate office, the decision with respect to further action on those issues should be coordinated with that office. Depending upon the procedures followed in the responsible attorney’s branch, this coordination may be formal or informal. Generally, a copy of the opinion is hand-carried to the appropriate office with a buckslip attached, pointing out the issues lost and requesting comments or suggestions as to further action. A response date should also be requested. The buckslip may be neatly handwritten or typed. It should be addressed to the branch chief and be signed by the attorney’s reviewer.

3. The attorney should study the court’s reasons for its adverse holding. If the court’s reasons are founded in fact, the attorney should determine if the court’s factual findings are clearly erroneous — the standard for reversal of a factual issue. Since the clearly erroneous standard is difficult to satisfy, it is unusual to have an appeal recommendation based on a factual finding.

4. If the court’s reasons for the adverse holding are founded in law or law applied to fact, appellate review is _de novo_. Reversal on appeal is much easier to accomplish. In either of these cases, the attorney should research the law and the Service’s position to ascertain whether the court was correct in its legal analysis.

5. Regardless of whether the attorney plans to recommend appeal, the attorney should prepare a brief adverse opinion review memorandum setting forth the issues decided adversely to the Service; the pertinent facts of the case; the Service’s position and the petitioner’s position if such will aid in the review; the court’s holding and reasoning; and the attorney’s analysis on why the court’s decision is correct or, if not correct, why it is clearly erroneous or legally incorrect. While the attorney should briefly note any issues that the Service won, the attorney need not provide analysis on these issues.

6. The attorney must contact the Field attorney to obtain the attorney’s views on whether the case should be appealed. Field Counsel may, but need not, provide an appeal recommendation. The Field attorney’s recommendation(s), if any, should be considered and stated in the adverse opinion review memorandum. The Field attorney’s recommendation should be stated in any transmittal to the Chief Counsel recommending appeal. If the recommendation is in favor of appeal, Field Counsel must obtain the concurrence of Division Counsel before transmitting its recommendation to the Associate office.

7. For procedures relating to appeals of adverse opinions, _see_ CCDM Part 36.


**35.9.1.2.3** **(08-11-2004)**

#### Listing of Counsel for Respondent in Tax Court

1. If the court omits an attorney’s name in the counsel line, contact APJP, Branch 3, who will communicate with the court to correct the opinion’s counsel line.


**35.9.1.2.4** **(08-11-2004)**

#### Motions for Reconsideration of Findings or Opinion

1. In rare instances, it may be necessary to file a motion requesting reconsideration of findings or opinion. These motions must be recommended by the Division Counsel, reviewed in the appropriate Associate Chief Counsel’s office and approved by the Chief Counsel. _See_ T.C. Rule 161.

2. Motions for reconsideration of findings or opinion should only be filed in cases of substantial error or where exceptional and compelling circumstances exist. A motion for reconsideration may not merely reiterate the arguments respondent presented on brief. Usually the basis for this motion is an apparent conflict with some other decision of the Tax Court or another court. Thus, an example of an acceptable ground for a motion for reconsideration is where the Tax Court’s decision conflicts with a recent opinion of another court, which was not addressed by the parties or by the Tax Court. Harmless error, as defined in T.C. Rule 160, is not a valid ground for a new trial or a change of the court’s order or decision. A motion for reconsideration is not to be joined or made a part of any other motion. T.C. Rule 163.

3. Under T.C. Rule 161, motions for reconsideration of an opinion or finding of fact, with or without a new or further trial, must be filed within 30 days after the opinion or transcript is served, except by leave of the court. All motions for reconsideration should be fully coordinated with APJP, Branch 3 or the appropriate Associate office and must be approved by the Chief Counsel.

4. Occasionally the Tax Court will fully sustain respondent’s determination, yet the court will order that the decision be entered under T.C. Rule 155. A motion for reconsideration and revision of opinion should not be filed in an attempt to correct the court’s erroneous designation in the opinion’s decision line. Rather, respondent’s determination sustaining the notice of deficiency should be submitted in the form of a T.C. Rule 155 computation.


**35.9.1.3** **(08-11-2004)**

### Review of Tax Court Decisions

1. The provisions of CCDM 35.9.1.2.1 apply to the review of Tax Court Decisions by Field Counsel and the appropriate Associate office.



### Caution:



Keep in mind the distinction between opinions and decisions


**35.9.1.3.1** **(08-11-2004)**

#### Finality of Tax Court Decision

1. Section 7481 governs the finality of a Tax Court decision. The attorney should keep in mind that finality of the decision is a prerequisite to assessment procedures. The finality of a Tax Court decision is important since the entire assessment and collection procedure is dependent upon the timing of such finality.

2. The decision of the Tax Court will become final upon the expiration of the appeal period (90 days from the date the decision is entered) if no appeal is taken by either party during that time. The appeal period may be extended by a motion to vacate or revise the decision or by a motion for litigation costs (since the court typically vacates the decision and enters a new decision determining the award of litigation costs, if any).

3. If either party files a timely notice of appeal, the finality of the Tax Court decision depends upon the outcome of the case on appeal. _See_ CCDM Part 36 for a detailed discussion of appeals and appellate procedures.

4. If a Tax Court decision is remanded by a court of appeals or the Supreme Court to the Tax Court for a rehearing, the decision entered as a result of the rehearing will become final in the regular manner as if there had been no prior proceedings; _i.e._, after the expiration of the 90-day appeal period. As used in this context, the term rehearing encompasses any Tax Court proceedings beyond the mere entry of a new decision. Note, however, that if the case has been remanded for rehearing by the court of appeals, no trial or further proceedings should be instituted until after the certiorari period has expired. _See_ CCDM 36.2.5.12.2 Transfer of Case to Area Counsel for cases remanded to the Tax Court.

5. After a Tax Court decision has become final, the Tax Court is without jurisdiction to vacate or modify the decision in any way, with several exceptions, including fraud upon the court, lack of jurisdiction over the subject matter or the parties (in this situation the decision would be void), and the modification, if necessary, of a final decision in an estate tax case solely to reflect the estate’s entitlement to a deduction for interest paid during an extended-payment period on the federal or state estate tax liability. _See_ section 7481(d).


**35.9.1.3.2** **(08-11-2004)**

#### Motions Regarding Decisions

1. After a decision has been entered by the Tax Court, either in a tried or settled case, it should not be disturbed after the decision becomes final, unless it is shown that such decision was produced by fraud upon the court. Fraud upon the court has been defined as embracing only that species of fraud which does, or attempts to, defile the court itself or is a fraud perpetuated by officers of the court so that the judicial machinery cannot perform in the usual manner its impartial task of adjudging cases. _See_ 7 J. Moore & J. Lucas, Moore’s Federal Practice, P. 60.33 at 60–360 (2d ed. 1990).

2. Another exception to the rule of finality of Tax Court decisions occurs where the court lacked jurisdiction over the subject matter or the parties. In that instance, the judgment rendered would be void and never can become final.

3. Questions have occasionally arisen concerning whether final decisions can be modified or vacated based on grounds other than fraud on the court or lack of jurisdiction. Although the Tax Court has not prescribed a rule that governs such situations, T.C. Rule 1(a) provides that when there is no applicable rule of procedure, the court may prescribe the procedure, giving particular weight to the Federal Rules of Civil Procedure to the extent that they are suitably adaptable to govern the matter at hand. In this regard, consult Fed. R. Civ. P. 60(a) and (b).


**35.9.1.3.2.1** **(08-11-2004)**

##### Motions to Vacate or Revise Decision

1. Motions to vacate or revise decision must be filed within 30 days after the decision has been entered, except by leave of the court. T.C. Rule 162. In general, leave to file a motion to vacate decision cannot be given after the decision becomes final, unless a claimed exception to finality exists. If the decision is entered in connection with an opinion, and a motion is to be filed for reconsideration of findings or opinion, a separate motion to vacate the decision should be concurrently filed. _See_ Exhibit 35.11.1–60.

2. Because of the sensitive nature of motions asking the Tax Court to vacate otherwise final decisions, as well as the uncertainty in the law regarding the Tax Court’s power to do so, any motion to vacate or revise a final decision must be sent to the APJP, Branch 3 for review.


**35.9.1.3.2.2** **(08-11-2004)**

##### Statutory Interest Determinations

1. Petitioner may, within one year after the date the decision of the Tax Court becomes final, file a motion to redetermine interest on the deficiency pursuant to section 7481(c). _See_ T.C. Rule 261. If any motion under T.C. Rule 261 is filed and served on Field Counsel, the Service’s response under Rule 261(c) must be reviewed by the office of the Associate Chief Counsel (P&A), prior to filing with the Tax Court. Rule 261(c) requires the Service’s response to detail its computation on interest. Computational support is available through Appeals offices.

2. A decision with respect to a proceeding to redetermine interest is reviewable on appeal in the same manner as a decision of the Tax Court with respect to the deficiency.


**35.9.1.3.2.3** **(08-11-2004)**

##### Taxpayer Motions to Modify Decisions in Section 6166 Estate Tax Cases

1. Section 7481(d), effective with respect to Tax Court cases for which a decision was not final on November 11, 1988, established jurisdiction in the Tax Court to reopen a case where the time for payment of an estate tax has been extended under section 6166. The Tax Court may reopen the case solely to modify the decision in order to reflect the estate’s entitlement to a deduction, pursuant to section 2053, for interest on (1) the estate tax imposed under section 2001, or (2) any estate, succession, legacy or inheritance tax imposed by a state. Only one such reopening is permissible and only after all installments of tax under section 6166 have been paid. T.C. Rule 262 implements the court’s jurisdiction to reopen an estate tax decision. If any motion under section 7481(d) is filed by an estate to which the Service objects, the Service’s response under Rule 262(c) must be reviewed by Associate Chief Counsel (P&A) prior to filing it with the Tax Court. Any order of the court disposing of a motion filed under section 7481(d) is reviewable on appeal in the same manner as a decision of the Tax Court with respect to the deficiency.


**35.9.1.4** **(07-01-2002)**

### Post-review Significant Case Procedures

1. Significant Case Procedures are discussed in detail at CCDM 31.5.1. Field Counsel assigned to a significant case requiring the implementation of significant case procedures should consult that section.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-009-001#addtoany "Show all")

A2A