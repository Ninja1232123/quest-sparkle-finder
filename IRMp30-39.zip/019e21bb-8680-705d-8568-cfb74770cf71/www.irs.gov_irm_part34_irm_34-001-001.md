---
url: "https://www.irs.gov/irm/part34/irm_34-001-001"
title: "34.1.1 Jurisdiction of the District Courts | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part34/irm_34-001-001#main-content)

- 34.1.1  [Jurisdiction of the District Courts](https://www.irs.gov/irm/part34/irm_34-001-001#idm139820906184160)
  - 34.1.1.1  [General Jurisdiction to Issue Judgments and Writs to Enforce Internal Revenue Laws](https://www.irs.gov/irm/part34/irm_34-001-001#idm139820907258016)
  - 34.1.1.2  [Suits Challenging the Validity of Tax Determinations/Counterclaims](https://www.irs.gov/irm/part34/irm_34-001-001#idm139820906343200)
  - 34.1.1.3  [Enforcement of Summonses and Challenges to Summonses](https://www.irs.gov/irm/part34/irm_34-001-001#idm139820907343840)
  - 34.1.1.4  [Suits Related To Wrongful Levy, Surplus Proceeds, Substituted Sales Proceeds, and Substitution of Value, Generally Brought by Persons Other Than Taxpayers](https://www.irs.gov/irm/part34/irm_34-001-001#idm139820907342240)
  - 34.1.1.5  [Suits by Taxpayer Alleging Improper Acts by the IRS](https://www.irs.gov/irm/part34/irm_34-001-001#idm139820906150528)
  - 34.1.1.6  [Review of IRS Collection Actions before Levy on Principal Residence](https://www.irs.gov/irm/part34/irm_34-001-001#idm139820906245120)
  - 34.1.1.7  [Interpleader/Quiet Title/Foreclosure or Other Actions Involving Property in Which IRS may Claim an Interest](https://www.irs.gov/irm/part34/irm_34-001-001#idm139820906242976)
    - 34.1.1.7.1  [Types of Cases](https://www.irs.gov/irm/part34/irm_34-001-001#idm139820938774304)
  - 34.1.1.8  [Injunctive Relief Sought by Taxpayer or Third Party](https://www.irs.gov/irm/part34/irm_34-001-001#idm139820934169264)
  - 34.1.1.9  [Injunctive Relief Sought by United States](https://www.irs.gov/irm/part34/irm_34-001-001#idm139820934165952)
  - 34.1.1.10  [Declaratory Judgments Relating to Status and Classification of Organizations under Section 501(c)(3)](https://www.irs.gov/irm/part34/irm_34-001-001#idm139820934675408)
  - 34.1.1.11  [Review of Certification of Individuals as Having a Seriously Delinquent Tax Debt](https://www.irs.gov/irm/part34/irm_34-001-001#idm139820934672896)

# Part 34. Chief Counsel Directives Manual Litigation in District Court, Bankruptcy Court, Court of Federal Claims, and State Court

# Chapter 1. Jurisdiction of the District Courts

# Section 1. Jurisdiction of the District Courts

* * *

## 34.1.1 Jurisdiction of the District Courts

#### Manual Transmittal

August 04, 2023

#### Purpose

(1) This transmits new subsection to CCDM 34.1.1.11, Review of Certification of Individual as Having a Seriously Delinquent Tax Debt.

#### Material Changes

(1) CCDM 34.1.1.11 describes the district court’s jurisdiction in actions under section 7345, which permits an individual who has been certified as having a seriously delinquent tax debt to bring a civil action in Tax Court.

#### Effect on Other Documents

This section supersedes CCDM 34.1.1, dated April 22, 2021.

#### Audience

Chief Counsel

#### Effective Date

(08-04-2023)

Robert T. Wearing

Deputy Associate Chief Counsel

(Procedure & Administration)

**34.1.1.1** **(08-11-2004)**

### General Jurisdiction to Issue Judgments and Writs to Enforce Internal Revenue Laws

1. The United States District Courts have a broad grant of jurisdiction to issue orders, judgments, and decrees necessary to enforce the internal revenue laws. Typical enforcement actions that are commenced in the district courts include:



1. Reducing tax assessments against a taxpayer to judgment. Section 7402. Commencing an action to reduce tax assessments to judgment effectively extends the statute of limitation for collection. Section 6502.

2. Obtaining judgments against third parties, including:



      > - Estate fiduciaries for liability arising under 37 U.S.C. § 3713(b),
      >
      >       - Transferees of property from insolvent estates to the extent that they received property subject to federal tax liens, and
      >
      >       - Transferees of fraudulently conveyed property, who may be liable under state law. Section 7402.

3. Foreclosing tax liens by sale of property, either real estate or personal property. Section 7403. As part of the foreclosure proceeding, the district court may decree that the property was fraudulently conveyed by the taxpayer. The court can also issue any order or writ incidental to the seizure and sale of property. Sections 7402 & 7403. Orders relating to the seizure and sale of property could include eviction, appointment of a receiver, sale of property by the U.S. Marshal, and confirmation of sale.

4. Recovery of erroneous refund by judgment against either the taxpayer or a third party. Section 7405.

5. Collecting Estate Tax from Property of Decedent. Section 7404.


**34.1.1.2** **(04-22-2021)**

### Suits Challenging the Validity of Tax Determinations/Counterclaims

1. Taxpayers may challenge the validity of the Service’s tax determination by paying the disputed tax and commencing a suit for a refund. Section 7422; 28 U.S.C. § 1346. In order to invoke the court’s jurisdiction, a taxpayer must first have filed an administrative claim for refund or credit which was denied or deemed denied under applicable regulations. Section 7422(a). In certain instances, it may be necessary for the Service to assert a counterclaim against the taxpayer for any unpaid tax liability that should be made part of the lawsuit (e.g., a Trust Fund Recovery Penalty is considered a divisible tax, and the taxpayer need pay only a portion of the total assessment before filing a refund claim).

2. Under the Tax Equity and Fiscal Responsibility Act (TEFRA), a tax matters partner, or, if the tax matters partner fails to do so, certain other partners, may file a petition for readjustment of the partnership item. Section 6226. A tax matters partner or another partner may also petition the court if the Service denies any part of an administrative adjustment request. Section 6228. TEFRA, however, does not apply to partnership returns for taxable years after 12/31/2017 because it was repealed by the Bipartisan Budget Act of 2015 (BBA).

3. The centralized partnership audit regime under BBA governs most examinations of partnership returns for taxable years beginning 1/1/2018. If a partnership is subject to BBA, only the partnership representative may file a petition for readjustment of a final partnership adjustment. Section 6234.


**34.1.1.3** **(08-11-2004)**

### Enforcement of Summonses and Challenges to Summonses

1. The statutory authority for issuing a summons is contained in section 7604. Prior court approval is required before service of a summons which does not identify the person with respect to whose liability the summons is to be issued (a "John Doe" summons). Section 7609(f). If the taxpayer or other summoned party fails to comply with the summons, the Service, by referral to the Tax Division or U.S. Attorney, must obtain an order enforcing the summons from the district court. Section 7602.

2. Taxpayers may commence proceedings to challenge or quash summonses served upon third parties. In these proceedings, the Service may seek an order compelling compliance with the summons. Section 7609(b)(2). In an enforcement proceeding commenced by the government against a summoned party, taxpayers may also intervene for the purpose of challenging a summons. Section 7609(b)(1).


**34.1.1.4** **(08-11-2004)**

### Suits Related To Wrongful Levy, Surplus Proceeds, Substituted Sales Proceeds, and Substitution of Value, Generally Brought by Persons Other Than Taxpayers

1. The district courts have jurisdiction over wrongful levy actions under section 7426(a)(1). "Wrongful" as used in this section refers to a proceeding against property that is not the taxpayer’s. In general, if a levy has been made on property, or property has been sold pursuant to a levy, any person other than the taxpayer who claims an interest in or lien on such property, and that such property was wrongfully levied upon, may bring a civil action against the United States. The district courts have jurisdiction over actions related to surplus proceeds, section 7426(a)(2), and substitution of value. Section 7426(a)(4). Like wrongful levy actions, these actions can only be brought by persons other than the taxpayer.

2. The district courts also have jurisdiction over actions related to substituted sales proceeds. Section 7426(b)(3). These actions can be brought by both taxpayers and persons other than taxpayers.

3. Pursuant to 28 U.S.C. § 1402, venue for these actions lies only in the judicial district where the property levied on is situated at the time of levy. Where the action does not arise out of a wrongful levy, proper venue for the action is where the event giving rise to the lawsuit occurred.


**34.1.1.5** **(08-11-2004)**

### Suits by Taxpayer Alleging Improper Acts by the IRS

1. Review of Termination of Taxable Period, Jeopardy Assessment and Jeopardy Levy Procedures. The district courts have jurisdiction under section 7429(b) to review a taxpayer’s challenge to any jeopardy assessment, jeopardy levy, or termination assessment undertaken by the Service.

2. Unauthorized Collection Actions. Taxpayers may bring suit for damages if an officer or employee of the Service recklessly or intentionally, or by reason of negligence, disregards any provision of the Code or any regulation thereunder in connection with any collection of tax. Section 7433.

3. Failure to Release Lien. Taxpayers may bring suit for damages if an officer or employee of the IRS knowingly, or by reason of negligence, fails to release a lien under section 6325. _See_ section 7432.

4. Unauthorized Enticement of Information Disclosure. Taxpayers may bring suit for damages if any officer or employee of the Service intentionally compromises the determination or collection of any tax due from an attorney, certified public accountant, or enrolled agent representing the taxpayer in exchange for information concerning the taxpayer’s tax liability. Section 7435.

5. Unauthorized Inspection or Disclosure of Returns and Return Information. Taxpayers may bring suit for damages if any officer or employee of the United States knowingly, or by reason of negligence, inspects or discloses any return or return information with respect to a taxpayer in violation of any provision of section 6103. _See_ Section 7431.

6. Failure to Disclose — Freedom of Information Act and Privacy Act Litigation. The district courts have jurisdiction for actions under the Freedom of Information Act, 5 U.S.C. § 552, and any actions in the nature of injunctions under the Privacy Act of 1974, 5 U.S.C. § 552a.


**34.1.1.6** **(08-11-2004)**

### Review of IRS Collection Actions before Levy on Principal Residence

1. Section 6334(e)(1) requires a district court order prior to administrative seizure of certain principal residences. These include the principal residence of the taxpayer, the taxpayer’s spouse, the taxpayer’s former spouse, and the taxpayer’s minor child.


**34.1.1.7** **(08-11-2004)**

### Interpleader/Quiet Title/Foreclosure or Other Actions Involving Property in Which IRS may Claim an Interest

1. Under 28 U.S.C. § 2410, Congress has consented to the joinder of the United States, under prescribed conditions, in a civil action in any Federal or state court having jurisdiction of the following suits with respect to any real or personal property on which the United States has a mortgage or other lien:



   - Suits to quiet title to property

   - Suits to foreclose a mortgage or other lien upon property

   - Suits to partition property

   - Condemnation suits

   - Interpleader suits or suits in the nature of interpleader


2. Section 2410 of Title 28 is a consent statute only; it does not confer authority upon any court to foreclose a lien, quiet title to property, partition or condemn property, or to entertain an interpleader suit. There must be a basis for jurisdiction independent of section 2410. Generally these actions apply to cases where the claim of the United States is based upon a lien and not one of title.


**34.1.1.7.1** **(04-22-2021)**

#### Types of Cases

1. Actions to Quiet Title. An "action to quiet title" is a proceeding instituted by persons claiming some interest in or to title in the property and seeking to remove a cloud from their title.

2. Foreclosure Actions. Section 2410(a)(2) permits the Government to be named as a party in a judicial proceeding to foreclose a mortgage or other lien upon property on which the United States has or claims a lien. An action to foreclose a mortgage or other lien, in which the United States is named a party under section 2410, must seek a judicial sale.

3. Partition Suits. A partition is a division between two or more persons of real or personal property owned as coparceners (joint heirs), joint tenants, or tenants in common.



1. As a general rule, a partition purchaser takes subject to liens and outstanding interests unless the decree of court provides for the sale free and clear of such encumbrances. The question whether the interests of third parties, including the United States, may be satisfied out of the property partitioned, or must be satisfied from the proceeds of sale of the property, is governed by state law.


4. Condemnation Suits. Eminent domain is, broadly, the right or power to take private property for public use. A condemnation proceeding is one to set apart or expropriate land for public use in the exercise of the power of eminent domain.



1. A condemnation action is a proceeding in rem, and is therefore not a taking of rights in the ordinary sense but an appropriation of the land or property itself. All existing estates or interests in the land are appropriated. As a consequence, the condemnation award stands in the place of the land, and federal tax liens attaching to the land are transferred to the award.


5. Interpleader Suits. An interpleader suit allows a person holding property of, or who owes an obligation to, another to have a court decide the ownership rights of two or more parties with adverse claims to the same property or the same obligation. The purpose of an interpleader action is to protect the person from exposure to multiple liability or multiple litigation. There are two ways in which a person may bring an interpleader action. Statutory interpleader under 28 U.S.C. § 1335 grants original jurisdiction in the district courts to hear an interpleader action when the adverse claimants are of diverse citizenship (not including the United States) and the property worth $500 or more has been deposited into the registry of the court. Rule interpleader under Rule 22 of the Fed. R. Civ. P. requires an independent basis for subject matter jurisdiction in the district courts, such as federal question jurisdiction.


**34.1.1.8** **(08-11-2004)**

### Injunctive Relief Sought by Taxpayer or Third Party

1. A taxpayer or a third party is generally prohibited from seeking an injunction against the enforcement of the internal revenue laws. This prohibition is contained in section 7421, the Anti-Injunction Act. This act codifies the general rule of equity that where a person has an adequate remedy at law, by way of suit for refund or appeal to the Tax Court, equitable relief by way of injunction against the assessment or collection of taxes may not be sought.

2. The prohibition against declaratory judgments with respect to tax matters, provided by 28 U.S.C. § 2201, can often be utilized to prohibit injunctive relief.


**34.1.1.9** **(08-11-2004)**

### Injunctive Relief Sought by United States

1. Action to Enjoin Tax Return Preparer. The district court for the district in which a tax preparer resides, or has his principal place of business, or in which the taxpayer with respect to whose return the action is brought resides, has jurisdiction over any action commenced by the United States to enjoin the tax preparer. Section 7407.

2. Action to Enjoin Specified Conduct Related to Tax Shelters and Reportable. The district court for the district in which a promoter resides, has his principal place of business, or has engaged in specified conduct described under section 7408(c) has jurisdiction over any action commenced by the United States to enjoin such person. Section 7408.

3. Action to Enjoin Political Expenditures by Section 501(c)(3) Organizations. The district court for the district in which the section 501(c)(3) organization has its principal place of business, or any district in which the organization has made political expenditures, has jurisdiction over any action commenced by the United States to enjoin the organization. Section 7409.


**34.1.1.10** **(08-11-2004)**

### Declaratory Judgments Relating to Status and Classification of Organizations under Section 501(c)(3)

1. The United States District Court for the District of Columbia (in addition to the Tax Court and Claims Court), has jurisdiction to make a declaration with respect to the Service’s determination, or failure to make a timely determination, of an organization’s initial qualification or continuing qualification under section 501(c)(3) or with respect to its classification as a private foundation. Section 7428.


**34.1.1.11** **(08-04-2023)**

### Review of Certification of Individuals as Having a Seriously Delinquent Tax Debt

1. An individual who has been certified as having a seriously delinquent tax debt may bring a civil action to determine whether the certification was erroneous or whether the Commissioner has failed to reverse the certification. The action may be brought in federal district court, against the United States, or in the Tax Court, against the Commissioner. The court first acquiring jurisdiction over such an action has sole jurisdiction.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part34/irm_34-001-001#addtoany "Show all")

A2A