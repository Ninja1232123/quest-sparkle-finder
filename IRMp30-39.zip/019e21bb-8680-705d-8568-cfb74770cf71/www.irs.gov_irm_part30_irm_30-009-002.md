---
url: "https://www.irs.gov/irm/part30/irm_30-009-002"
title: "30.9.2 Guidelines for Specific Categories of Case Files | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part30/irm_30-009-002#main-content)

- 30.9.2 [Guidelines for Specific Categories of Case Files](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203704336816)
  - 30.9.2.1 [Published Guidance](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203662991664)

    - 30.9.2.1.1 [Regulations](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203704372400)
    - 30.9.2.1.2 [Revenue Rulings, Revenue Procedures, and Other Nonregulatory Published Guidance](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203670710864)
    - 30.9.2.1.3 [Action on Decisions (AOD)](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203684499408)
    - 30.9.2.1.4 [Published Guidance Project (PGP)](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203656237568)

  - 30.9.2.2 [Advanced Case Resolution](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203684056912)

    - 30.9.2.2.1 [Advanced Pricing Agreements (APA)](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203674566800)
    - 30.9.2.2.2 [Change in Accounting Methods (CAM) and Change in Accounting Periods (CAP)](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203672909584)
    - 30.9.2.2.3 [Private Letter Rulings (PLR)](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203662532752)

  - 30.9.2.3 [Treaties, Legislation, Congressional, and Executive Correspondence](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203676193472)
  - 30.9.2.4 [Legal Advice](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203660497616)

    - 30.9.2.4.1 [Technical Advice Memoranda](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203689216112)
    - 30.9.2.4.2 [Files for Review of Documents](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203677208528)

  - 30.9.2.5 [Tax Court Files](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203674560224)

    - 30.9.2.5.1 [Tax Court Cases on Appeal](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203673612768)

  - 30.9.2.6 [District Court United States/Court of Federal Claims/State Court Cases](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203704347008)

    - 30.9.2.6.1 [District Court and Court of Federal Claims Cases on Appeal](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203684418048)

  - 30.9.2.7 [Criminal Tax](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203704291600)

    - 30.9.2.7.1 [Case Opening Procedures](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203678039584)

      - 30.9.2.7.1.1 [Case Jacketing Procedures](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203667158400)
      - 30.9.2.7.1.2 [Legal Assistance](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203674060448)

    - 30.9.2.7.2 [Criminal Tax File Contents and Maintenance](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203676055792)

      - 30.9.2.7.2.1 [Administrative Files](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203657346112)

    - 30.9.2.7.3 [Security of Criminal Tax Files](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203654876080)
    - 30.9.2.7.4 [Closing Criminal Tax Cases](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203674408864)

      - 30.9.2.7.4.1 [Closing Cases Where Counsel Is or Was the Referral Authority](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203671480624)
      - 30.9.2.7.4.2 [Automatic Closing Procedures](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203678628496)

  - 30.9.2.8 [General Legal Services Files](https://www.irs.gov/irm/part30/irm_30-009-002#idm140203679784288)

# Part 30. Administrative

# Chapter 9. File Management

# Section 2. Guidelines for Specific Categories of Case Files

* * *

## 30.9.2 Guidelines for Specific Categories of Case Files

**30.9.2.1** **(07-21-2005)**

### Published Guidance

1. This subsection provides guidelines for establishing and maintaining files related to regulations, revenue rulings, revenue procedures, action on decisions, and other types of published guidance.


**30.9.2.1.1** **(07-21-2005)**

#### Regulations

01. Open a regulation project only with approval from an Assistant or Associate Chief Counsel and, if it will appear on the Guidance Priority List, the Treasury Department. Depending on the procedures adopted by each Assistant or Associate office, front office or branch personnel may open a regulation project on TECHMIS.

02. To open a regulation project, enter the TECHMIS "Add Case" screen and complete the required fields: category: PUBGUID, subcategory REG. In some circumstances, Counsel may decide to open the project using subcategory "PGP." TECHMIS generates a project number (CASE ID) that begins with "REG" (or "PGP" , if applicable). Use only this CASE ID for all phases of the regulation process, from drafting the ANPRM/NPRM to publishing the final regulation.

03. IRC § 7805(e) requires the Service to issue a cross-referencing NPRM when it issues temporary regulations. Open only one regulation project for temporary regulations with a cross-referencing NPRM. When the Service publishes the temporary regulations and cross referencing NPRM, update TECHMIS with status code 715 - TEMP/XREF Published. The CASE ID remains open until the Service publishes the NPRM as a final regulation or withdraws it and removes the temporary regulation.

04. Occasionally, Counsel and Treasury will decide to issue several final regulations with respect to one NPRM. The first final regulation project retains the original CASE ID. After publishing the first final regulation, close that CASE ID. Open a new CASE ID for each subsequent final regulation project. In the TECHMIS remarks screen for each subsequent final regulation project, note the name and original CASE ID of the underlying NPRM and all related final regulations. Also enter this information in the remarks screen for the first final regulation.

05. After opening the regulation project on TECHMIS, the drafting attorney creates a legal file maintains the legal file, is responsible for its contents, and retains it until the project is closed.

06. Punch holes at the top of the back cover of the legal file and all papers to be included in it. The first item in the file will be a copy of the TECHMIS control screen. Secure the papers with file fasteners. Label the file with the project title and CASE ID.

07. The legal file contains all documents germane to the publication of the regulation and, in accordance with Form 9506, Treasury Decision File Closing Information Sheet and Assembly Checklist , organized by subject files using Form 7881, Chief Counsel’s File. (Do not include duplicate material, any readily available printed matter \[e.g., statutes and the associated legislative history, court decisions\], or scraps, blank sheets, etc. that do not contain substantive information). The attorney establishing the file and the reviewing attorney sign and date Form 9506.

08. The subject files and materials to be included are:



    - _Published Regulations and Notices_— all initialed and certified copies of the regulation

    - _Unmarked drafts_ — a clean copy of each draft and related buckslips and distribution memoranda

    - _Service and Treasury mark-ups_ — pertinent pages of mark-ups and related buckslips and distribution memoranda

    - _Briefing Memos_ — internal memoranda prepared for briefings

    - _Service and Treasury Memos_ — transmittal and policy memos and internal comments

    - _Conference and Briefing Reports_ — summaries of conferences and briefing sessions

    - _Public Comments_— public comments, including summaries of these comments and documents related to the public hearing

    - _Administrative Memos_ — regulations subsystem form and regulations development checklist (if completed), Small Business Administration documents, 7-point memo material, closing memo (if prepared), plain language summaries, and material prepared pursuant to the Paperwork Reduction Act and Small Business Regulatory Fairness Enforcement Act


09. Place handwritten notes and email communications in the appropriate subject matter file, in reverse chronological order.

10. Attach a copy of the Federal Register reprint to the cover of the legal file.

11. A regulations project is complete when the Service publishes an NPRM as a final regulation, withdraws a published NPRM without publishing final regulations, or decides not to publish a regulation. If the Service published a temporary regulation with a cross-referencing NPRM, the project is complete when the Service removes the temporary regulation and publishes the NPRM as a final regulation or withdraws the NPRM.

12. If the IRS publishes a final regulation, close the final regulation project on TECHMIS using status code 951 (closed - publication). If the IRS withdraws an NPRM and does not publish final regulations, use status code 960 (closed - withdrawn). If the IRS decides not to publish a regulation, use status code 952 (closed - non-publication). Refer to the TECHMIS handbook for additional status codes (closed - other, closed - transferred out, closed - opened in error), not described above.

13. All regulations projects close with classification code J (Regulation & Legislation Projects).

14. When the legal file for a TD (final and temporary regulations) is complete, label it with the TD number and submit it to the Docket, Records and User Fee Branch for storage.

15. The drafting attorney retains the NPRM file after the document is published as reference for (and to be included in the legal file for) the final regulations.

16. After the Service withdraws a regulation or closes a project without publishing it, assemble the legal file and send it to the Docket, Records and User Fee Branch in room 5336 for storage. The attorney should prepare a closing memorandum to include in the legal file.


**30.9.2.1.2** **(12-23-2010)**

#### Revenue Rulings, Revenue Procedures, and Other Nonregulatory Published Guidance

01. Revenue Rulings, Revenue Procedures, and other nonregulatory Published Guidance help Service personnel apply the tax laws correctly and uniformly and help taxpayers comply with the tax laws.

02. Before opening a guidance project, it must be approved by the Associate Chief Counsel and, if it will appear on the Guidance Priority List, Treasury.

03. When approved, open the project on TECHMIS (category: Published Guidance, subcategory: RR, RP, or NOT as applicable) in accordance with the TECHMIS Users Handbook. Depending on the procedures adopted by the Assistant or Associate Office, Branch or front office personnel may open the project.

04. Project titles must refer to the issue addressed, not a taxpayer name. If the project pertains to a prior publication, the project title must begin with that publication (i.e. Rev. Rul. XX-XX Revocation, not Revocation of XX-XX).

05. TECHMIS generates a project number (CASE ID) that begins with "NOT" for Notices and Announcements, "RP" for Revenue Procedures, "RR" for Revenue Rulings, and "PGP" for projects without an assigned format. Use only this project number for all phases of the publication process, from drafting through publication.

06. The attorney drafting the published guidance project opens the legal file. The first item in the file will be a print-out of the TECHMIS control screen.

07. In general, the contents of the legal file for Revenue Rulings, Revenue Procedures, Announcements, and Notices will be the same. The legal file contains, in chronological order when possible:



    01. Form 9718, Case History

    02. A signed completed copy of the Background Information Note (BIN), containing the record of clearances, attachment list and all other pertinent information

    03. Background memoranda discussing the development of the project and comments from Treasury, Counsel, and Service officials and staff

    04. A copy of the first draft of the publication.

    05. A copy of each later draft (or part of the draft) that is significantly different from prior drafts and/or contains information, such as substantive comments, that clarifies the meaning of the publication. File only the page(s) that contain the significant change and/or clarifying information. Put the date of the draft, title of the project, and project number on the page, and list the people who received a copy of the draft.

    06. A significant change is one that adopts a rule different from the one initially drafted and/or clarifies the meaning of the rule adopted.

    07. Briefing and conference memoranda

    08. Small Business Administration documents, plain language summaries, and material prepared pursuant to the Paperwork Reduction Act and Small Business Regulatory Fairness Enforcement Act (if prepared)

    09. Bibliography of references analyzed when researching the project. Do not include a copy of the research material unless it will facilitate future research. If included, highlight the critical text.

    10. Copies of material not available in the Chief Counsel library or on the Internet, including memorandum pertaining to other projects, studies, and reports

    11. Written and oral comments, if any, from the public

    12. "Comment" or "Suspend" memoranda from Treasury, the Commissioner, the Chief Counsel, or an Associate Chief Counsel, Division Counsel, or member of their staff

    13. An original or copy of the approval memorandum

    14. Coordination memoranda from other Chief Counsel offices

    15. The Form 12972 , Internal Revenue Bulletin Submission Record, and the Form 12971, Memorandum for Bulletin Unit Coordinator, stamped by the Bulletin Unit, that posts the publication number and the date of the IRB and the IRB number in which it will appear

    16. A copy of the publication, as it appeared in the IRB

    17. Signed completed copy of Form 1889, Record of Bulletin Editorials

    18. A cross-reference sheet for each secondary Internal Revenue Code section listed in the "coding" at the top of the revenue ruling

    19. A copy or photocopy of any correction notice as it appeared in the IRB

    20. A closing memorandum


08. Do not include handwritten notes or email communications unless they address substantive matters addressed in the published guidance.

09. If a publication is newsworthy, the Service may pre-publish (" early drop" ) a document, prior to its publication in the Internal Revenue Bulletin, by issuing a news release, making it available to the tax services, and posting it to the Service web site. Put a copy of the memorandum authorizing the "early drop" in the legal file.

10. When the Service publishes a revenue ruling or revenue procedure, close the project on TECHMIS with status code 951 (closed - published). For items the Service decides not to publish, use status code 952 (closed - non-publication). Refer to the TECHMIS user guide for additional status codes (e.g., closed - other, closed - transferred out, closed - opened in error) not described above.

11. Revenue Rulings and Revenue Procedures close with file retention code J - Revenue Ruling or Procedure. For Notices, close with status code B if the file is to be retained for reference, H if historical, and F if routine.

12. After issuing the published guidance, submit the legal file to the Docket, Records, and User Fee Branch for storage.


**30.9.2.1.3** **(07-21-2005)**

#### Action on Decisions (AOD)

1. The legal file for AODs contains:



   - A copy of the AOD

   - A copy of the court opinion to which the AOD relates

   - Conference and other memoranda discussing the basis on which the decision to issue an AOD was made and the contents of the AOD document


2. AOD assignments will be opened in the Associate office.

3. Closed AOD files will be forwarded to the Docket, Records and User Fee Branch for storage.


**30.9.2.1.4** **(07-21-2005)**

#### Published Guidance Project (PGP)

1. When the format of the published guidance project (e.g., Regulations, Revenue Ruling, Revenue Procedure, or Notice) has not been determined, a Published Guidance Project (PGP) on TECHMIS is opened, category: Published Guidance, subcategory: PGP. TECHMIS will generate a CASE ID beginning with "PGP."

2. The drafting attorney opens the legal file. The first item in the file will be the TECHMIS control screen.

3. PGPs are developed in the same manner as other published guidance projects. Accordingly, the contents of the PGP legal file will include the same material as the legal file for other published guidance.

4. When an Associate office determines the kind of published guidance to issue, open a new project on TECHMIS using the subcategory to which the PGP will be converted. Continue using the existing PGP legal file, conforming it to the appropriate specifications.

5. Close the PGP on TECHMIS, with status code 900 (closed - other) and classification code F (routine).


**30.9.2.2** **(07-21-2005)**

### Advanced Case Resolution

1. This subsection discusses establishing and maintaining files for advanced pricing agreements, change in accounting methods, change in accounting period, and private letter rulings.


**30.9.2.2.1** **(07-21-2005)**

#### Advanced Pricing Agreements (APA)

1. The team leader maintains and closes the official APA case file, insuring that the file contains the following material:



   - The taxpayer’s request for APA and related documents

   - The case plan

   - A file memorandum, or file note, for every meeting or significant telephone call

   - Copies of all outgoing correspondence, such as questions or information requests sent to the taxpayer

   - The original of each correspondence item from the taxpayer or the field, such responses to questions or other information

   - Copies of documents (including email messages) that perform the function of a conference memo, memorialize a decision, or transmit comments on a draft document

   - Copies of all analysis prepared by any APA or field economist

   - Copies of any assistance from a technical branch

   - A copy of the Director’s memo

   - A copy of the Associate Chief Counsel’s memorandum

   - A copy of the signed recommended negotiating position

   - A copy of the redacted recommended negotiating position

   - A copy of the signed APA


2. The official APA case file should not contain the original executed APA. The team leader should provide it to his/her secretary for safekeeping in the APA Docket Room.


**30.9.2.2.2** **(07-21-2005)**

#### Change in Accounting Methods (CAM) and Change in Accounting Periods (CAP)

1. There are two types of CAM and CAP cases, advanced consent for which taxpayers submit Form 3115, Application for Change in Accounting Method, and "automatics" .

2. Taxpayers address requests for CAMs and CAPs to the Docket, Records, and User Fee Unit (CC:PA:LPD:DRU). The DRU picks up the mail, screens the requests for subject matter jurisdiction, opens the case on TECHMIS, and creates a legal file. The CASE-ID will begin with the prefix CAM or CAP, as appropriate.

3. The legal file created by CC:PA:CRU contains the following:



   - Copy of the taxpayer’s submission, including the taxpayer’s request for closing agreement, taxpayer’s request for a private letter ruling, Form 3115, checklists submitted pursuant to Rev. Proc. 2004-1 (or its successor) and other applicable Service publications, Penalties of Perjury Statement, Power of Attorney, and documents and other material supporting the taxpayer’s request

   - A copy of the TECHMIS general detail opening case screen (" control sheet" )

   - Form 9718, Case History

   - A coding sheet identifying the case as a CAM or CAP

   - User Fee sheet

   - IRC § 6110 statement


4. As the initiating attorneys work on the case, they will include the following in the legal file:



   - Subsequent correspondence (and related Penalties of Perjury statements, if needed) from the taxpayer

   - Other documents or memoranda pertaining to the disposition of the CAM

   - Copy of Counsel’s letter to the taxpayer

   - A copy of the TECHMIS general detail closed case screen (" control sheet" )


5. Close CAM and CAP cases on TECHMIS (TECHMIS — CAM or CAP detail screen) with the appropriate closing status code.

6. After closing the CAM or CAP on TECHMIS submit the files for advanced consent cases to the Docket, Records, and User Fee Unit for storage. The retention schedule requires the Service to retain "automatics" for three years. After two years, the files may be retired to the Federal Records Center.


**30.9.2.2.3** **(07-21-2005)**

#### Private Letter Rulings (PLR)

1. Taxpayers address requests for a PLR to the Docket, Records, and User Fee Branch (CC:PA:LPD:DRU). The DRU picks up the mail, screens the requests for subject matter jurisdiction, opens the case on TECHMIS, and creates a legal file. The CASE-ID will begin with the prefix PLR.

2. The DRU opens the PLR legal file. It contains:



   - The taxpayer’s submission, including the taxpayer’s request for a private letter ruling, checklists submitted pursuant to Rev. Proc. 2004-1 (or subsequent annual revenue procedure) and other applicable Service publications, Penalties of Perjury Statement, Power of Attorney, and documents and other material supporting the taxpayer’s request for private letter ruling

   - A copy of the TECHMIS general detail opening case screen (" control sheet" )

   - Form 9718, Case History

   - A coding sheet identifying the case as a PLR

   - User Fee sheet

   - IRC § 6110 statement


3. As the initiating attorneys work on the case, they will include the following in the legal file:



   - Subsequent submissions (and related Penalties of Perjury statement, if needed) from the taxpayer and third parties — including documentation, financial information, and legal material supporting the request for private letter ruling — organized in reverse chronological order

   - Bibliography listing references, available in the Chief Counsel library or online, used to develop the private letter ruling. Include a copy of the research material only to facilitate future research. Highlight the critical text.

   - Copies of material not available in the Chief Counsel library or on the Internet, including memorandum pertaining to other projects, studies, and reports

   - Other documents or memoranda (such as legal memoranda, conference reports recording meetings with taxpayers and/or Chief Counsel employees) pertaining to the disposition of the PLR

   - Responses to requests for assistance from another Office of Associate/Assistant Chief Counsel

   - Copy of the private letter ruling issued to the taxpayer

   - Copy of the private letter ruling with the deletions made in accordance with IRC § 6110

   - Form 9818, Case Processing


4. Close the case on TECHMIS using the appropriate closing status code. Depending on the disposition of the case, enter one of the following file retention classification codes.



   - Enter "A" if the case is recommended for publication. (Also, enter "A" in this box if the case was the basis of revenue ruling and insert instructions to associate the case file with the revenue ruling file.)

   - Enter "B" if the case file has such significant future reference value because of the issues involved that it should be index-digested by the technical employee even though it does not meet the publication standards. The "Reference" code is entered in relatively few cases and is never entered in a case pertaining to the exempt status of a IRC § 521 organization.

   - Enter "D" if the case is a letter ruling that is closed with status code 960 - Withdrawn or 900 - Other

   - Enter "F" in the box for routine cases


5. Submit the legal file to the DRU for processing and storage with the following items attached (top to bottom):



   - Two copies of the TECHMIS general detail closed case screen

   - The original signed outgoing letter and enough copies for each taxpayer representative and field office. Include a Power of Attorney transmittal letter (Letter 1690) for each taxpayer representative receiving a copy of the letter. Provide envelopes or address labels for each recipient.

   - Administrative file copy (usually a yellow copy) of the letter signed by the reviewer(s)


6. At the request of the Commissioner, the Office of Chief Counsel determines whether to grant taxpayers’ requests for relief pursuant to IRC § 9100. The opening and closing procedures for requests for 9100 relief and the contents of the legal file are the same as those outlined for private letter rulings. The legal file will also include:



   - If the taxpayer submitted its request to the Commissioner’s office and not CC:PA:LPD:DRU, the memorandum from the Commissioner forwarding case to Counsel

   - Copies of the taxpayer’s tax returns for all applicable years

   - A copy of Counsel’s disposition memorandum notifying the Commissioner whether Counsel issued a private letter ruling granting or denying the taxpayer’s request for relief or the taxpayer withdrew its request for IRC § 9100 relief. If the taxpayer withdrew its request for IRC § 9100 relief, Counsel will not issue an adverse private letter ruling.


7. Sometimes taxpayers request closing agreements in addition to or in lieu of private letter rulings. These requests are addressed similarly and processed by the DRU similarly to PLR requests. The CASE ID will begin with the prefix CLAG. The file created by the DRU will be similar to a PLR file. The drafting attorney, however, creates a CLAG Special File. The Special File is a temporary file in a manila folder containing all papers relating to the closing agreement. Mark the outside of the folder SPECIAL FILE and label it with the taxpayer name, CASE ID, and office symbol of the branch handling the case. The Special File contains the following:



   - The file created in CC:PA:LPD:DRU

   - All subsequent correspondence from the taxpayer

   - Reports from revenue agents and/or office reports

   - Official file copies of the closing agreement and, if issued, the private letter ruling

   - The original and copies of the transmittal letter and memorandum to the taxpayer and appropriate Director

   - Three copies of private letter ruling, if prepared, for each closing agreement in file

   - Closing agreements, executed in triplicate, with necessary documentary evidence

   - Manifold copies, excluding the yellow copy

   - For a "Mass Closing Agreement" or other agreement that a taxpayer representative signs for a taxpayer, the power of attorney authorizing the representative to sign the original closing agreement

   - Material to be used by the Operating Division examining the returns

   - Transmittal memorandum to the Associate Chief Counsel

   - If the closing agreement is subject to public disclosure as an integral part of a private letter ruling, a redacted copy of both the closing agreement and the private letter ruling


8. After the appropriate officials sign the closing agreement and return it to the branch, photocopy the original closing agreement, prepare deleted copies in accordance with CCDM 32.3.4.7.4.1, Special File. The Associate Chief Counsel office retains the original and a copy of the closing agreement and a copy of the related private letter ruling, if any, and transmittal memorandum to the Operating Division. If applicable, associate the Special File with the legal file for the private letter ruling. Close the CLAG on TECHMIS using the applicable closing status code (see appendix for closing status codes). Use classification code E - Closing Agreement. Submit the legal file to DRU for processing and storage in accordance with CCDM 32.3.4.7.4.2, Signing and Disposition of Closing Agreements and Special Files.


**30.9.2.3** **(07-21-2005)**

### Treaties, Legislation, Congressional, and Executive Correspondence

1. The legal file for Congressional and other correspondence submitted to and controlled by the Service (e.g., Executive Correspondence) includes:



   - Incoming correspondence

   - Legal memoranda discussing the issue(s) presented

   - Bibliography listing references, available in the Chief Counsel library or online, used to develop the response. Include a copy of the research material only to facilitate future research. Highlight the critical text.

   - Copies of material not available in the Chief Counsel library or on the Internet, including memorandum pertaining to other projects, studies, and reports and other documents on which the response is based

   - Initial draft(s) of the response and a copy of the final response


2. The legal file for Tax Treaties and Protocols between the United States and foreign countries includes:



   - Typed notes of negotiations

   - Copies of drafts exchanged with the other country

   - Copies of materials received from and provided to the other country

   - Copies of letters, faxes, and email messages to and from the other country

   - Copies of significant materials concerning the law or policy of the other country (e.g. internal memos or policy memos)

   - Memos or email messages summarizing significant conference calls or meetings

   - Copies of letters, faxes, and email messages from third parties pertaining to problems with the existing treaty or making suggestions for the new treaty or protocol

   - Copies of any significant articles or news stories pertaining to problems with the existing treaty or making suggestions for the new treaty or protocol

   - Copies of assistance requests to other branches or associate offices and any responses received. A copy of the treaty or protocol as initialed

   - Copies of any Memoranda of Understanding or Exchange of Notes signed in connection with the treaty or protocol

   - Significant drafts of the Technical Explanation drafted by the Treasury Department

   - Copy of the treaty or protocol and accompanying materials as submitted to the Senate for approval

   - Copies of the Joint Committee and Senate reports

   - Transcript or other materials concerning the Senate hearing

   - Copy of document reflecting Senate approval together with information about any reservations

   - Copies of press releases or other official public announcements

   - Form 9718, Case History


**30.9.2.4** **(07-21-2005)**

### Legal Advice

1. The following should appear in reverse chronological order of their development or consideration.



   - Original request for advice including any memoranda or enclosures attached to the request

   - Conference and telephone conference memoranda, and any memoranda to the file

   - Coordination and referral requests and memoranda, including any memoranda of views

   - Copy of an explanatory memorandum if the request for advice is withdrawn

   - Copy of the transmittal letter if a copy of the advice is forwarded to the Department of Justice

   - Copy of the advice as issued

   - Form 9718, Case History


2. If the advice is subject to IRC § 6110 procedures, the file should also contain the following documents re: IRC § 6110 procedure:



   - Copy of the black and gray version with applicable authority for the redactions

   - Copy of the confirmation copy of the fax sheet transmitting the original and black and gray version to the field

   - Copy of any memo to the file re the specific privileges being claimed

   - Copy of black and white version

   - Checksheet for processing CCA

   - The final document as released, with the publication number that is returned from CC:PA:LPD:DLS


3. If a field office is providing the advice, the closed file should be closed and stored following local procedures. If the advice is provided by a national office unit, the closed file should be forwarded to the Legal Processing Division for storage.


**30.9.2.4.1** **(07-21-2005)**

#### Technical Advice Memoranda

1. Technical Advice Memorandum and Technical Expedited Advice Memorandum requests are forwarded from field offices to the Docket Records and User Fee Branch. After initial processing, the DRU transfers the request to TSS4510 for assignment and file creation.

2. The following should appear in chronological order of their development or consideration.



   - Original request for technical advice submitted by the director or area director, appeals, including any memoranda or enclosures attached to the request, together with submissions by the taxpayer or its representative, see CCDM 33.2.2.3, Using the Technical Advice or the Technical Expedited Advice

   - Conference and telephone conference memoranda, status memoranda, and any memoranda to the file

   - Coordination and referral requests and memoranda

   - Copy of an explanatory memorandum if the request for Technical Advice is withdrawn

   - Copies of all memoranda approving the issuance of the technical advice memorandum

   - Copies of all correspondence from the taxpayer or its representative

   - A copy of the transmittal letter if a copy of the Technical Advice is forwarded to the Department Of Justice

   - Form 9718, Case History

   - Copy of the Technical Advice Memorandum issued to the field. These should include the technical advice transmittal memorandum; the technical advice memorandum; copies of the Notice of Intention to Disclose; a redacted copy of the technical advice memorandum; and instructions for dating the Notice of Intention to Disclose.


3. Closed TAM or TEAM files should be sent to the Docket Records and User Fee Branch for storage.


**30.9.2.4.2** **(07-21-2005)**

#### Files for Review of Documents

1. As described in CCDM 30.9.1.4(1)b, Other Files, TSS4510 opens assignments and creates files for Associate office review of motions and briefs to be filed in the Tax Court; defense, suit and settlement letters to be sent to the Department of Justice; and Coordinated Issue Papers, Appeals Settlement Guidelines, Forms, Publications, Internal Revenue Manual provisions and other documents from the Service.

2. Attorneys should ensure that these files contain:



   - The original document sent for review

   - Any requests for assistance

   - The marked up version of the document or transmittal memorandum describing necessary changes

   - The clearance form, brief review sheet or other document reflecting clearance of the document

   - Copies of TECHMIS assignment sheets


3. Files should be sent to the Docket, Records and User Fee Branch when the case is closed.


**30.9.2.5** **(12-23-2010)**

### Tax Court Files

01. The legal file is the official file of the Office of Chief Counsel in a Tax Court case. It is created in the National Office upon the service of a new Tax Court petition upon the Chief Counsel. The Docket, Records and User Fee Branch, upon entering the case in the TL CATS system, makes up the legal file by filing the petition and other papers served on the Chief Counsel in the file jacket. One TL CATS generated label is permanently attached to the face of the legal file and the other placed inside the legal file for the field office’s use. The DRU then mails the legal file containing the petition and its attachments to the appropriate Field office.

02. Because the DRU’s allocation of cases between SB/SE/LB&I/TEGE can only be a rough approximation of the responsible Division, there may be initial misassignment of cases, and it may be desirable to transfer primary responsibility to a different Division from that originally assigned. Until the case is formally transferred, the Field group originally assigned the case remains responsible for assuring that all necessary actions (e.g., answering the case) are taken in a timely fashion. Because of concern that administrative files may be lost or misplaced if the case is reassigned before retrieval of the administrative file, the Division originally assigned a case should generally answer the case prior to transfer to any group in a different geographic location. At the request or written consent of the transferring organization, however, the case may be transferred prior to answer. The case file and TL CATS/TECHMIS will be appropriately annotated to reflect the Division and local office responsibilities with respect to the case.

03. In addition to containing the formally approved official documents, the legal file should reflect the current status of the case at all times.

04. Copies of all incoming inter-office memoranda for a case should be date-stamped when received and placed in the legal file. Copies of the final signed original version of all outgoing memoranda should be placed in the legal file. Where Counsel has reviewed a proposed statutory notice of deficiency, copies of any memorandum concerning pre-issuance review should be placed in the legal file for the docketed proceeding.

05. The attorney should prepare memoranda for the file to record all principal action in the case, which is not otherwise reflected therein by formal documents. This will enable the supervisor or another attorney to whom the case may be assigned, to ascertain from the file the current status of the case, as well as what action has been taken therein. Memoranda for the file should be prepared of principal action taken by the attorney in telephone or informal conversations having a material bearing on the processing or disposition of the case. Conference memoranda should also be prepared, when applicable, in the predocketed consideration of a case, and such memoranda should be inserted in the legal file when the case becomes docketed. Each memorandum for the file should be dated and signed by the attorney preparing it.

06. Copies of all incoming correspondence (including printouts of email messages) should be date-stamped when received and placed in the legal file. Copies of the final signed original version of all outgoing correspondence should be placed in the legal file.

07. The copy of the Tax Court petition (and all exhibits thereto) served upon respondent should be retained in the legal file. Similarly, copies of any amended petition or amendments to a petition should be retained in the legal file.

08. A complete copy of the statutory notice of deficiency upon which a docketed case is based should be placed in the legal file.

09. There should be in the legal file a record of all principal action taken by the attorney towards the disposition of the case by trial or settlement. These matters oftentimes are important in the consideration of the case by the National Office for tax litigation advice, review of briefs or actions on decision. Information contained in the office file or the administrative file does not fulfill this requirement.

10. The initialed copy of all papers filed with the Tax Court, together with a copy of such papers bearing the stamped impression when a particular paper was sent, was lodged, or was filed, etc., with the court, the served copy, the final signed original of all outgoing correspondence, the originals of all incoming correspondence, and any other pertinent papers must be filed in the legal file strictly in chronological order, with the most recent on top.

11. The original of served subpoenas should be included in the legal or miscellaneous law file. A reviewer’s approval should also appear in the file by retention of the initialed copy or other means.

12. The first documents in the legal file for a case settled by Appeals should be the Appeals Case Memorandum and supporting statement. Included with such material should be a complete copy of any Audit Statement, computations, and account transcripts for the relevant taxable periods.

13. For each case settled by Counsel, a complete copy of the final signed original Counsel Settlement Memorandum should be kept in the legal file. The file should also contain a copy of the stipulated decision entered by the Court and a copy of any pertinent settlement computations.

14. For cases that are not settled, the file should contain the documents that dispose of the case, _e.g._, the order dismissing the case or the opinion and decision document.


**30.9.2.5.1** **(07-21-2005)**

#### Tax Court Cases on Appeal

1. When a Tax Court case is appealed, whether by the taxpayer or the government, responsibility for the case is transferred to the Associate office with primary subject matter jurisdiction.

2. The legal file is transmitted to the Department of Justice for its use in the appellate litigation. Before transmitting the file to Justice, attorneys should take care to retain copies of essential case documents in a duplicate legal file.

3. When the case is resolved on appeal, Justice will return the legal file to the Associate office. Unless the case is remanded to the Tax Court, the Associate office will close the case and send the file to the Disclosure and Litigation Support Branch for processing.

4. If the case is remanded, the legal file will be returned to the responsible Field counsel office.


**30.9.2.6** **(07-21-2005)**

### District Court United States/Court of Federal Claims/State Court Cases

01. Court of Federal Claims refund cases are forwarded to the Legal Processing Division in the national office. The Division assigns the case to a field office, creates a legal file and requests the administrative file from the Service. The legal file is then forwarded to the assigned field office.

02. Upon receipt of the summons and complaint in a district court or Court of Federal Claims case by Field counsel, a designated reviewer (an attorney or paralegal) should read the complaint to determine if the case is in the correct Field counsel office and if the matter should be controlled as a tax litigation function case or as a general litigation or general legal services matter.

03. Case Categories. Every case jacketed in a Field office must be designated for report purposes as set forth in paragraph, below. For the most part, the type of case to be designated on the file jacket is easily ascertained. At times cases and matters are assigned to the general litigation activity that do not clearly fall within the specific categories of cases.

04. Documents placed in the legal file should be securely fastened to the file. Bulky briefs or trial or deposition transcripts may be stored in a manila file envelope, provided the envelope is clearly marked to indicate that it is a part of the legal file. The legal file should accompany any letter sent to an Associate office for review.

05. The legal file should contain a copy of all of the filings and Court documents and trial or deposition transcripts furnished by the Department of Justice; a copy of all correspondence sent to or received from the Department of Justice or any other agency or Service office; a copy of memoranda to the file prepared by the attorney; and a copy of all transcripts of account. The file should also contain technical advice memoranda, legal advice, or letter rulings showing any prior Office of Chief Counsel consideration of the case. Normally, the legal file will contain only one copy of each document.

06. In addition to the formally approved official documents the legal file should reflect the current status of the case at all times.

07. Copies of all incoming inter-office memoranda for a case should be date-stamped when received and placed in the legal file. Copies of the final signed original version of all outgoing memoranda should be placed in the legal file. Where Counsel has reviewed a proposed statutory notice of deficiency, copies of any memorandum concerning pre-issuance review should be placed in the legal file for the docketed proceeding.

08. The attorney should prepare memoranda for the file to record all principal action in the case, which is not otherwise reflected therein by formal documents. This will enable the supervisor or another attorney to whom the case may be assigned, to ascertain from the file the current status of the case, as well as what action has been taken therein. Memoranda for the file should be prepared of principal action taken by the attorney in telephone or informal conversations having a material bearing on the processing or disposition of the case. Conference memoranda should also be prepared, when applicable, in the pre-docketed consideration of a case, and such memoranda should be inserted in the legal file when the case becomes docketed. Each memorandum for the file should be dated and signed by the attorney preparing it.

09. Copies of all incoming correspondence (including printouts of email messages) should be date-stamped when received and placed in the legal file. Copies of the final signed original version of all outgoing correspondence should be placed in the legal file.

10. When a refund case is ready for closing, a closing memorandum is prepared, returning the administrative files to the Service.

11. In any case in which a refund has been made, a copy of the recomputation used to determine the amount refundable and a copy of the Notice of Adjustment memorandum should be in the legal file.

12. An important and crucial prerequisite to the closing of a refund case in which money is repaid is the preparation and transmittal to the service center of a payment memorandum known as a notice of adjustment.

13. In a refund case, include a signed copy of the original Settlement Letter that was prepared by the attorney and sent to the Department of Justice.


**30.9.2.6.1** **(07-21-2005)**

#### District Court and Court of Federal Claims Cases on Appeal

1. When a District Court or Court of Federal Claims case is appealed, whether by the taxpayer or the government, responsibility for the case is transferred to the Associate office with primary subject matter jurisdiction.

2. The legal file is transferred from the Field counsel office to the Associate office for appeal monitoring.

3. When the case is resolved on appeal, Justice will return the legal file to the Associate office. Unless the case is remanded, the Associate office will close the case and send the file to the Disclosure and Litigation Support Branch for processing.

4. If the case is remanded, the legal file will be returned to the responsible Field counsel office.


**30.9.2.7** **(07-21-2005)**

### Criminal Tax

1. The following changes in how the Division Counsel/Associate Chief Counsel (Criminal Tax) does business, brought about by or in conjunction with the Criminal Investigation (hereinafter referred to as CI) and Criminal Tax (hereinafter referred to as CT) reorganization of July 2000, caused significant changes in the area of CT file creation and maintenance, as well as how and when CT cases are to be closed. This section establishes general procedures for file opening, maintenance and closing of all types of CT cases. Unless otherwise stated, these procedures apply to all CT cases, whether worked in field offices or in the headquarters office. To the extent specific procedures are not covered herein, they will be provided separately by the Division Counsel/Associate Chief Counsel (Criminal Tax) and/or by the Area Counsel.


**30.9.2.7.1** **(07-21-2005)**

#### Case Opening Procedures

1. The original and copies of all incoming correspondence, forms, transmittal memoranda, and/or reports must be stamped upon receipt to show the date and office in which received. For incoming Field Counsel assignments, the Area Counsel must also be immediately notified upon receipt of the new assignment. The number of exhibits and/or attachments received with the special agent’s report (SAR) or other incoming correspondence are to be checked to make certain that they correspond to number and identification as listed in the SAR or other incoming correspondence, and that all specified exhibits and attachments have been received.

2. CASEMIS databases (hereinafter CASE) should be searched to determine whether a case(s) related to the incoming target/assignment has been previously handled. All relevant CASE screen(s) should be printed and associated with the incoming assignment.

3. All new CT workload matters on which two or more hours will be spent are to be opened on CASE and a separate CASE number should be assigned to each proposed target in a Form 9131, Request for Grand Jury Investigation, or SAR. In the case of forfeitures, a separate CASE Number will be assigned to each Form 4008, Seized Property Report, received from CI.


**30.9.2.7.1.1** **(07-21-2005)**

##### Case Jacketing Procedures

1. One case jacket (file folder) will be prepared, taking into account the following guidelines:



1. For administrative and grand jury cases, the file will be in the name of the key target, proposed in the Form 9131 or SAR, regardless of the number of targets. For grand jury cases, the case jacket should also be stamped, "GRAND JURY."

2. For forfeitures, the file will be in the name of the primary property item seized, with a cross reference to the property owner

3. For search warrants, the file will be in the name of the proposed target

4. For summonses, the file will be in the name of the proposed target

5. For all other categories of case files, see the Division Counsel/Associate Chief Counsel (Criminal Tax) and/or Area Counsel for instruction


2. The following information should be recorded on the face of the case jacket:



1. The name and address found in the Form 9131 or SAR for the key target recommended, and in the case of forfeitures, the name of the owner of the property and the property items seized

2. All other names or aliases used by the target or business entity

3. Names of related cases (actual and/or proposed targets)

4. Cases involving numbered proposed targets with tax violations relating to corporations which are not numbered targets should be captioned: Doe John Involving ABC Corporation

5. The CI POD in which the case arises


**30.9.2.7.1.2** **(07-21-2005)**

##### Legal Assistance

1. With certain exceptions which require written submissions (e.g. search warrants), requests for legal assistance from CI may be written or oral, and, generally, responses should be in like form. It is beneficial to memorialize oral legal assistance rendered since subsequent criminal cases containing a prosecution recommendation may be based in part or whole on the prereferral legal assistance provided. Files on oral legal assistance are at the discretion of the CT Manager.

2. An appropriate case jacket should be opened for any written legal advice.


**30.9.2.7.2** **(07-21-2005)**

#### Criminal Tax File Contents and Maintenance

1. Initially, the CT file will contain one copy of the incoming correspondence or documentation giving rise to the assignment. While the assignment is opened, copies of all case related correspondence/documentation, as well as each final work product ( _e.g._, conference memorandum, supplemental investigation requests, criminal evaluation memorandum, forfeiture memorandum of law) will also be enclosed in the file. Additionally, all relevant CASE screen(s) should be printed and placed in the case jacket. This material should be fastened in the file folder in reverse chronological order.

2. No notations or marks are to be made on the originals of documents received from taxpayers or their representatives other than the necessary stamp to record the date and place of receipt. No notations, marks, or corrections are to be made on originals of the exhibits, or on papers or tax returns received from administrative officials in connection with criminal tax cases and matters.

3. The criminal tax file should always remain in the assigned CT office, except in the case of transfers. When the case is transferred, the complete file will be copied, unless directed otherwise by the Division Counsel/Associate Chief Counsel (Criminal Tax) and/or Area Counsel; the original documentation sent to the newly assigned office; and the copies retained by the transferring office. These same procedures will apply for transmittals to Division Counsel/Associate Chief Counsel (Criminal Tax) for review and evaluation.

4. With CI’s and CT’s increased use of electronic transmission of documentation, CT attorneys should look to the Division Counsel/Associate Chief Counsel (Criminal Tax) and Area Counsel for additional advice relative to the creation and retention of electronic files.


**30.9.2.7.2.1** **(07-21-2005)**

##### Administrative Files

1. Administrative files should only be received in rare instances. In these situations, action should be taken immediately and the administrative file promptly returned. To the extent administrative files are transmitted to CT attorneys, proper precaution regarding original tax returns should be maintained.


**30.9.2.7.3** **(12-23-2010)**

#### Security of Criminal Tax Files

1. Security measures should be observed at all times to avoid jeopardizing a case through loss of files or unauthorized disclosure of the contents thereof.

2. Generally, CT case files and CI records in CT possession are classified as High Security items. The protection for these items involves storage in secure containers ( _i.e._, locked file cabinets) or in areas protected by a secure room.

3. The security guidelines offered by IRM 10.2.15, Minimum Protection Standards (MPS), deal with the protection of sensitive tax data and grand jury information from purposeful or inadvertent disclosure, as well as protection of Service personnel and equipment. You should be aware of the guidelines the Service utilizes in this regard, and comply with them.

4. When additional security precautions are deemed advisable, the correspondence should be placed in double-sealed envelopes, clearly marked _OPEN BY ADDRESSEE ONLY_ on the inner envelope. This requirement is inclusive of all copy distribution. To assure that all correspondence comes unopened to the Division Counsel/Associate Chief Counsel (Criminal Tax) the mailing envelope should be stamped _NOT TO BE OPENED IN THE MAIL ROOM_.

5. When transmitting by mail, original documents which may be used as evidence in trial ( _e.g._, original returns, signed confessions, books and records, etc.), registered mail with confirmation of delivery requested or a comparable method of delivery should be used. A private service may be an appropriate method of delivery if the sender can be notified that all of the material sent reached its destination and that there is a method of tracing material which is lost en route. Should confirmation of notification of delivery not be received by the office transmitting such files or documents within a reasonable period of time, inquiry should be made to trace the material.


**30.9.2.7.4** **(12-23-2010)**

#### Closing Criminal Tax Cases

1. Except where noted below, cases opened after July 17, 2000 should be closed on CASE immediately upon completing the requested action. Exceptions are those cases in which Counsel is the referral authority, primarily summons enforcement cases and certain forfeiture cases.

2. Closing a criminal tax case encompasses closing the case on CASE, taking closing action relative to any file that was created and sending copies of specified documents to the Division Counsel/Associate Chief Counsel (Criminal Tax) and Area Counsel for review.

3. Closing a criminal tax case on CASE does not mean that the referral of the criminal case is "terminated" within the meaning of IRC § 7602(d)(2)(B).



1. "The responsibility for closing \[a\] criminal investigation rests with the referring authority." Prior to July 17, 2000, Counsel was the referral authority for (a) requests for grand jury of Title 26 and/or Title 26-related offenses and (b) recommendations to prosecute Title 26 and/or Title 26-related offenses investigated administratively.

2. For those cases in which Counsel is the referral authority, unless other arrangements are made with CI and the Department of Justice, when Counsel learns that such a case has been resolved within the meaning of IRC § 7602(d)(2)(B), Counsel should take action to obtain the needed "in writing" case closing information from Justice.


4. CASE operators must be timely advised of the need to close a criminal tax case on CASE by being provided with a copy of any closing document. If there is no formal closing document, the CT attorney should take care to advise the CASE operator of the date the action on the case was completed so that the case can be closed as of that date.

5. The date the advice is rendered and/or the action document transmitted is the date the case will be put in 500 status on the CASE system. In the majority of cases, immediately thereafter, the case should be closed, _i.e._, put in 900 status. In the case of Title 26 and/or Title 26-related search warrants, the case should remain open and in 500 status until the inventory review has been completed, at which time the case should be closed and put in 900.

6. A copy of any closing document should be included in any file that was created for the case. A printout of the CASE screen showing the case in closed 900 Status should also be placed in the file. Such a file should be stamped or marked _CLOSED_.

7. Closed case files should be maintained separately from open case files and with appropriate security. Closed grand jury case files should be maintained separately from closed non-grand jury files.

8. All closed files should be retired to the federal record center in accordance with pertinent IRM record retention and shipping provisions. See Item No. 7 of IRM Exhibit 1.15.13-1, Records Control Schedule for the Chief Counsel. Grand jury files should be reviewed before any file is shipped to make sure that any grand jury material is properly handled.


**30.9.2.7.4.1** **(07-21-2005)**

##### Closing Cases Where Counsel Is or Was the Referral Authority

1. CI should be contacted periodically to determine if referred grand jury investigations are still active. If the matter is no longer active, Counsel should close the matter. The "in writing" requirement of IRC § 7602(d)(2)(B) need not take any particular form and can be as simple as a concurrence line to a CI discontinuance memorandum, provided the document clearly sets forth that the referral to DOJ is terminated and an appropriate Justice official ( _e.g._, the United States Attorney or his or her delegate) signs on the concurrence line.

2. For grand jury requests, if a prosecution recommendation results, the grand jury request case should be closed on CASE as of the date the special agent’s report is received and the grand jury evaluation case is opened. Counsel remains the referral authority for the matter. The closing of the grand jury request case on CASE is merely for Counsel record keeping purposes and does not "terminate" the referral.

3. Cases in which Counsel recommended prosecution, forfeiture or summons enforcement as the referral authority should be closed within five (5) workdays of receipt of sufficient information from which it can be reasonably determined that the criminal aspects have been concluded. Grand jury evaluation cases where Counsel was the referral authority for the underlying grand jury request should also follow this rule.

4. If a case is prosecuted, the automatic closing procedures set forth below can be used. If a recommendation for prosecution is not authorized by DOJ, or it is discontinued by Justice prior to indictment after authorization, the case can be closed upon receipt of the declination letter from Justice of a final determination made that the declination will not be protested or the case resubmitted with additional evidence.


**30.9.2.7.4.2** **(07-21-2005)**

##### Automatic Closing Procedures

1. In the following categories of cases, the Tax Division has agreed to the immediate closing and release for civil disposition of the criminal case by the Service without Tax Division authorization:



1. Acquittals where the entire criminal subject matter is terminated, _i.e._, no remaining counts or related defendants

2. Dismissals after indictment, where the entire criminal subject matter is terminated

3. Cases where sentencing has occurred following conviction, if a motion for new trial has not been made or has been denied and no notice of appeal has been filed within the designated time

4. Cases where sentencing has occurred following entry of plea of guilty or _nolo contendere_, if no motion for withdrawal of plea was made

5. Cases where termination of all appellate jurisdiction has occurred, after a judgment of guilty, without a remand for new trial


2. Where a case is being closed pursuant to the above automatic closing procedures, notification to the Tax Division is made by letter containing the judgment and commitment order and/or as much of the following information as possible:



01. The date of the indictment or information

02. A listing of the counts by year and charge

03. The judgment entered on each count

04. The date of that judgment and verdict or plea on which it was based

05. The exact sentence imposed on each count

06. Date of sentence

07. Whether an appeal was filed and the results, including an opinion

08. Date any petition for writ of certiorari was denied

09. Whether the case should be forwarded for supervision of collection ( _i.e._, if any fines were imposed, any restitution ordered or costs imposed by the court)

10. Any other applicable information


**30.9.2.8** **(12-23-2010)**

### General Legal Services Files

01. Two sets of case numbers are used by the Office of Associate Chief Counsel (General Legal Services).



    1. The first set is composed of three parts: the GLS prefix, a six digit number generated by TECHMIS, an automated case tracking system, and a two-digit suffix denoting the last two digits of the calendar year.

    2. The second set is a GLS file number generated by TECHMIS for local GLS use. It is composed of a "GLS" prefix, followed by a two character geographic office designation, followed by an ordering number of indefinite digits, and concluded with a two-digit suffix denoting the last two digits of the calendar year (each character set separated by a hyphen).


02. The following persons may assign and open cases at the Associate Chief Counsel (GLS) office:



    - Associate Chief Counsel

    - Deputy Associate Chief Counsel

    - Branch Chief

    - Assistant Branch Chief

    - A delegate of any of these officials


03. At Area Counsel offices, the following persons may assign and open cases:



    - Area Counsel

    - A delegate of this official


04. In general, a case file must be opened when it is expected that a matter will require two or more hours of work by an attorney or paralegal, or regardless of the amount of time, if a matter is judged "significant" by a person authorized to assign cases (see above). "Significant" is defined as a situation where it is likely there will be a need to recollect and retrieve the advice given in the matter. The term "significant" used here is not necessarily the same as how the term "significant" is used for case coordination purposes or under the record control schedules applicable to GLS matters.

05. Each GLS case file jacket should include the following information:



    - Caption/name of case

    - Case ID

    - GLS File No.

    - Date opened

    - Date closed (when determined)

    - Attorney’s name

    - Branch symbols (where applicable)

    - Cross reference line(s)


06. Types of cases fall under the four groups listed below. All case types are located in the CASE-GLS Handbook, Chapter 4. Additional rules pertaining to specific case types and naming conventions for specific case types are also located in Chapter 4.



    1. Litigation direct

    2. Legal projects

    3. Legal opinions

    4. Litigation support


07. _Requirements for Information Systems Tracking_. Cases are opened in TECHMIS. Information regarding data entry requirements into TECHMIS are found in the CASE-GLS Handbook, Chapters 4 - 8.

08. Case files should contain the following information:



    - Final work product

    - Research results

    - Printouts of material email messages

    - Form 12956, Staff Summary Sheet (which replaced obsolete Form 1937A, Correspondence Approval and Clearance)

    - All other unbound, material documents in chronological order when practical


09. If the principal work product of the case is oral advice, work on a task force, or preparation for meetings, memoranda to the file must be placed in the folder indicating the advice given, recommendations made, and similar information. Attorneys and paralegals are responsible for ensuring that all material documents are in case files, in proper order, and securely fastened with binder clips.

10. All bound documents, i.e., transcripts, separate MSPB Agency Response files, should be referred to in the case file and put in a secondary file next to the case file in the docket room or storage area.

11. GLS cases are closed promptly when action on the case, i.e., final memorandum of advice or other responsive action is completed and no further significant work product or verbal advice is anticipated for the case. Give the complete, fully organized case file jacket and contents to the person responsible for closing the case on GLS files. He/she records closing data in the electronic files and on the case jacket. An electronic copy of GLS work products should be retained for addition to GLS databases for future research.

12. For file retention and storage, see Exhibit 1.15.13-1, Records Control Schedule for the Chief Counsel, Item No. 10.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part30/irm_30-009-002#addtoany "Show all")

A2A