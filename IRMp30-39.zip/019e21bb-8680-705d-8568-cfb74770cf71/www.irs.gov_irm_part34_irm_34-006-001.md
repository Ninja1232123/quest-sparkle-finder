---
url: "https://www.irs.gov/irm/part34/irm_34-006-001"
title: "34.6.1 Affirmative Litigation | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part34/irm_34-006-001#main-content)

- 34.6.1  [Affirmative Litigation](https://www.irs.gov/irm/part34/irm_34-006-001#idm140062046834176)
  - 34.6.1.1  [General Procedures for Handling Affirmative Litigation](https://www.irs.gov/irm/part34/irm_34-006-001#idm140062019792512)
    - 34.6.1.1.1  [Steps Prior to Litigation](https://www.irs.gov/irm/part34/irm_34-006-001#idm140062046684608)
  - 34.6.1.2  [Miscellaneous Procedures Applicable to Suits to Collect](https://www.irs.gov/irm/part34/irm_34-006-001#idm140062019208640)
    - 34.6.1.2.1  [Emergency Procedure](https://www.irs.gov/irm/part34/irm_34-006-001#idm140062019206976)
    - 34.6.1.2.2  [Additional Assessments or Collection](https://www.irs.gov/irm/part34/irm_34-006-001#idm140062019778224)
    - 34.6.1.2.3  [Appointment of Agent to Bid at Execution Sale](https://www.irs.gov/irm/part34/irm_34-006-001#idm140062019775024)
    - 34.6.1.2.4  [Use of Writ of Ne Exeat](https://www.irs.gov/irm/part34/irm_34-006-001#idm140062019765440)
    - 34.6.1.2.5  [Injunction Procedures by the United States](https://www.irs.gov/irm/part34/irm_34-006-001#idm140062019711520)
    - 34.6.1.2.6  [Estate Tax Lien](https://www.irs.gov/irm/part34/irm_34-006-001#idm140062019702096)
    - 34.6.1.2.7  [Gift Tax Lien](https://www.irs.gov/irm/part34/irm_34-006-001#idm140062019755520)
    - 34.6.1.2.8  [Limited Action Recommendations](https://www.irs.gov/irm/part34/irm_34-006-001#idm140062019753456)
    - 34.6.1.2.9  [Procedure After Judgment Becomes Final](https://www.irs.gov/irm/part34/irm_34-006-001#idm140062019750528)
    - 34.6.1.2.10  [Settlement Procedures](https://www.irs.gov/irm/part34/irm_34-006-001#idm140062019747504)
    - 34.6.1.2.11  [Restrictions Applicable to Deficiencies](https://www.irs.gov/irm/part34/irm_34-006-001#idm140062019730480)
  - 34.6.1.3  [Preparation of Suit Letters](https://www.irs.gov/irm/part34/irm_34-006-001#idm140062019728912)
    - 34.6.1.3.1  [Format of Suit Letters](https://www.irs.gov/irm/part34/irm_34-006-001#idm140062019725248)
    - 34.6.1.3.2  [Contents of Suit Letters](https://www.irs.gov/irm/part34/irm_34-006-001#idm140062019717920)
    - 34.6.1.3.3  [The Basis for the Complaint](https://www.irs.gov/irm/part34/irm_34-006-001#idm140062019624880)
    - 34.6.1.3.4  [Tax Data](https://www.irs.gov/irm/part34/irm_34-006-001#idm140062019615008)

# Part 34. Chief Counsel Directives Manual Litigation in District Court, Bankruptcy Court, Court of Federal Claims, and State Court

# Chapter 6. Suits Brought by the United States

# Section 1. Affirmative Litigation

* * *

## 34.6.1 Affirmative Litigation

#### Manual Transmittal

July 27, 2021

#### Purpose

(1) This transmits revisions to CCDM 34.6.1, Suit Brought by the United States - Affirmative Litigation.

#### Background

This section incorporates updates to the delegation of authority with respect to the appointment of an agent to bid at execution sale and references to IRC 7407 and 7408.

#### Material Changes

(1) The current version of CCDM 34.6.1.2.3 is revised to reflect to the delegation of authority with respect to the appointment of an agent to bid at an execution sale.

(2) The current version of CCDM 34.6.1.2.5 is revised to update references to IRC 7407 and 7408.

#### Effect on Other Documents

This section supersedes CCDM 34.6.1 dated October 7, 2015.

#### Audience

Chief Counsel

#### Effective Date

(07-27-2021)

Robert T. Wearing

Deputy Associate Chief Counsel

(Procedure & Administration)

**34.6.1.1** **(08-11-2004)**

### General Procedures for Handling Affirmative Litigation

1. This chapter sets forth procedures for handling cases (except insolvencies) to collect an unpaid tax assessment, recover money, or to pursue some other legal remedy with the ultimate aim of allowing the Government to satisfy obligations arising under the internal revenue laws. It includes actions on bonds, suits to open safe deposit boxes, actions under section 3505, injunction actions by the United States and summons enforcement.

2. Instructions for handling bankruptcies and other insolvencies are set forth in CCDM 34.3 and CCDM 34.4.

3. Miscellaneous non-collection suits other than bankruptcies and other insolvencies that might involve the United States, the Service, or Service employees will be found in CCDM 39.3, CCDM 34.6.3, and CCDM 34.5.


**34.6.1.1.1** **(07-27-2021)**

#### Steps Prior to Litigation

1. General Information and Procedures. Field Counsel renders legal advice as to the most appropriate course of action and the probability of processing a case through to a successful conclusion.



1. After receipt of the Area Director’s recommendation, the attorney examines the case to determine whether or not suit is warranted. The attorney should review the transcript to determine whether there is any pending administrative action (e.g. Offers in Compromise, Installment Agreements, or pending action with the Taxpayer Advocate) that would make referral inappropriate. If suit is warranted, the attorney prepares a letter to DJ requesting the institution of suit. This suit letter must contain a discussion of the facts and supporting documents, tax information, applicable statutes and pertinent judicial decisions involved in the case.

2. The letter is generally forwarded directly to the Tax Division for action. Mandatory pre-review of documents by the Associate offices is required only in exceptional circumstances, where the subject matter is of unusual sensitivity or presents certain novel and significant issues, such as treaty related matters. Accordingly, unless the case involves an issue for which pre-review is required by Exhibit 35.11.1-1, the suit letter will usually be forwarded directly to DJ by Field Counsel.

3. When DJ receives the authorization for a suit, they take responsibility for the case. If a settlement is proposed, DJ should seek the recommendation of the Office of Chief Counsel unless the case has been designated Settlement Option Procedure (S.O.P). _See_ CCDM 34.5.1.1.1. Generally, the recommendation of the Office of Chief Counsel is followed.

4. The authority for the United States to commence a court action for the collection or recovery of taxes is set forth in section 7401.


2. Report from the Area Director. The Area Director’s office will generally send a report to the Field Counsel requesting that a suit be instituted. The general requirements for various types of suits are discussed in_CCDM 34.6.1.3_ and under the separate suit headings. The Technical Support Services Branch will obtain and forward all administrative files and other documents pertinent to the case.



1. In those cases where Field Counsel learns that the Government has been named a defendant, such as in an interpleader suit, it will advise the Area Director of the proceeding and request an investigation and a report. Field Counsel is responsible for following up on such requests. _See_ CCDM 34.5.

2. Exhibits 34.12.1-5 through 34.12.1-7 suggest basic checklists for the attorney to use in analyzing revenue officers’ reports.


3. Exhaustion of Administrative Remedies. Upon receipt of a suit request, Field Counsel must first determine whether the Area Director’s office has exhausted its administrative remedies.



1. Existing instructions provide that Area Directors should recommend suit in a collection matter only where administrative remedies have been exhausted or have become impracticable. A statement to this effect should be included by Field Counsel in the letter to DJ.


4. Efforts by Field Counsel Prior to Litigation. Upon receipt of the case, Field Counsel should attempt a resolution of the matter without litigation. A letter from Field Counsel may achieve the desired result by indicating that the Service is embarking on the first step to enforce its rights.



1. If these attempts fail, or it appears useless to attempt them, or the imminent expiration of the statute of limitations prevents them, then authorization for suit should be undertaken.


5. Executive Order 12778 on Civil Justice Reform. Section 1(a) of Executive Order No. 12778 (57 F.R. 3640, January 30, 1992) requires that, in referring a civil action to DJ for the purpose of instituting a suit, either the Office of Chief Counsel or DJ make a reasonable effort to notify all disputants about the nature of the dispute and to attempt to achieve a settlement. By agreement with DJ, notification will normally be provided by Tax Division Attorneys. There may be instances, however, where counsel attorneys are requested to provide the required notification on behalf of DJ. A simple declarative statement in either the introductory or jurisdictional section of the suit letter affirming (1) that the notice of the Government’s intent to sue has been made, and (2) that the Service has attempted to resolve the dispute prior to referral, is sufficient. The notice and settlement provisions do not apply in any action in which the Service is not the plaintiff. The notice and settlement provisions are also inapplicable in the following circumstances:



1. In any action to seize or forfeit assets subject to forfeiture or in any action to seize property;

2. In any bankruptcy, insolvency, conservatorship, receivership, or liquidation proceeding;

3. When the assets that are the subject of the action or that would satisfy the judgment are subject to flight, dissipation, or destruction;

4. When the defendant is subject to flight;

5. When, as determined by litigation counsel, exigent circumstances make providing such notice impracticable, or such notice would otherwise defeat the purpose of the litigation, such as in actions seeking temporary restraining orders or preliminary injunctive relief.


6. Suit Not Recommended. Field Counsel is responsible for determining whether institution of suit should be requested. If Field Counsel determines that suit is not advisable, the Territory Manager’s office should be advised by a memorandum that sets forth the reasons therefor.



1. If a Service Territory Manager disagrees with a determination by Field Counsel that a suit is not advisable, the case can be forwarded to the Area level with the personal recommendation of both the Field Counsel and the Territory. The Area will be responsible for resolving the problem. If agreement cannot be reached at the Area level, the case should be forwarded to Division for resolution, together with the recommendations.

2. The expense and time consumed in processing every suit is a factor to be considered.


7. Referral to DJ. Section 7401 requires that any suit to collect or to recover taxes must be authorized or sanctioned by the Secretary or a delegate. The authority of the Chief Counsel has, in most cases, been redelegated to Field Counsel.



1. Unless there are specific Division Counsel instructions to the contrary, or pre-review is required by Exhibit 35.11.1-1, all letters to DJ are to be prepared on Field Counsel stationery and signed on behalf of the Chief Counsel by the Field Counsel with the appropriate by-line.

2. The general contents of suit letters are found in CCDM 34.6.1.3.2 and Exhibit 34.12.1-8.

3. Field Counsel is responsible for following up on all cases referred to DJ to ensure that timely and appropriate action is taken on behalf of the client.


**34.6.1.2** **(08-11-2004)**

### Miscellaneous Procedures Applicable to Suits to Collect

1. The following procedures may arise in affirmative suits to collect.


**34.6.1.2.1** **(08-11-2004)**

#### Emergency Procedure

1. The emergency procedure can be utilized where there appears to be an imminent dissipation of assets, a need for immediate intervention, where the taxpayer should be restrained, or in any other situation demanding expeditious action. It should also be utilized where there is a short statute of limitations for collection.

2. If suit must be instituted immediately, the following procedure will be used.



1. If the statute of limitations on collection will expire within 20 working days and no suit letter has been mailed to DJ, or one of the other situations described above in paragraph (1) are present, Field Counsel will contact the Chief, Civil Trial Section, (appropriate) Region of the Tax Division, explaining the nature of the case and the urgency of the situation.

2. The supervisor in the Tax Division, if in agreement that suit is necessary, will direct that the appropriate U.S. Attorney be contacted by telephone or otherwise, and authorized to file proper pleadings.

3. All tax data and pertinent documents, together with available facts, should be available to be given to the Tax Division and the appropriate U.S. Attorney. In those cases where pre-review is necessary then the appropriate division should be contacted by Field Counsel first for appropriate coordination.


3. A suit letter sanctioning the action must be forwarded as soon as possible.


**34.6.1.2.2** **(08-11-2004)**

#### Additional Assessments or Collection

1. If additional assessments are made after a suit has been referred, a supplemental letter to DJ should be prepared to include the additional taxes so that the judgment will cover all outstanding obligations of the taxpayer. DJ must be notified immediately of any payment made during the course of litigation.

2. The suit letter should mention when other sources of collection are available and whether the Service intends to pursue collection activity.

3. Amending a complaint to include new or omitted assessments is looked upon with disfavor by the courts. It is therefore suggested that collection be attempted from other sources rather than by suit, or if the amounts are de minimis, to ignore them for purposes of the suit. Any collection activities by the IRS during the pendency of the suit should be cleared in advance with Field Counsel and the Tax Division.


**34.6.1.2.3** **(07-27-2021)**

#### Appointment of Agent to Bid at Execution Sale

1. In rare instances, the General Counsel of the Treasury Department will appoint an agent with authority to act for the United States in bidding at certain execution sales of property where the United States is the plaintiff in the action. The statutes and delegations provide that, under 31 U.S.C. 3715, the Secretary is authorized to purchase real property upon which the United States has a lien at a judicial foreclosure sale. Section 7403(c) of the Code grants similar authority, limited to purchase of property upon which the United States has a first lien. The General Counsel of the Department of Treasury has been delegated authority under 31 U.S.C. 3715. Treasury Order 101-05 (December 17, 2015), paragraph 2 (delegating authority to General Counsel to perform any function the Secretary of the Treasury is authorized to perform). Similarly, the Commissioner of Internal Revenue has been delegated authority under section 7403(c). Treasury Order 150-10 (delegating to Commissioner the Secretary’s authority to enforce and administer the internal revenue laws). The Commissioner has further delegated that authority to the Deputy Commissioner. Delegation Order 1-23 (formerly Delegation Order 193 (Rev. 6)). Appointment of an agent is necessary because currently there is no delegation of authority from the General Counsel or the Deputy Commissioner to any IRS officer or employee to purchase property at a judicial foreclosure sale pursuant to section 7403(c) or 31 U.S.C. 3715.

2. The following documentation is required:



   - Memorandum from Chief Counsel to General Counsel, Treasury Department- Re Appointing Agent (where tax lien is not senior lien)

   - Document executed by General Counsel appointing the agent (where tax lien is not senior lien)

   - Memorandum from Chief Counsel to Commissioner of the Internal Revenue - Re Appointing Agent (where tax lien is senior lien)

   - Document executed by Commissioner of the Internal Revenue appointing agent (where tax lien is senior lien)

   - Letter to agent advising of appointment

   - Letter to Tax Division of Department of Justice advising it of appointment of agent


3. When it becomes necessary to secure the appointment under 31 U.S.C. 3715 of an agent to bid at an execution sale, documents modeled in Exhibits 34.12.1-9 through 34.12.1-14 will be effective.

4. The same documentation will be used in bidding in 28 U.S.C. 2410 cases. _See_ CCDM 34.5.6.3.


**34.6.1.2.4** **(10-07-2015)**

#### Use of Writ of Ne Exeat

1. A writ of ne exeat will be issued only where it can be shown that a defendant is about to leave the United States and that he or she has conveyed away his or her property, or has concealed cash or other property that has been arranged and concealed so that it may be taken out of the United States.

2. Since the nature of the writ is to protect the power of a court to give equitable relief to an injured party, it is necessary that a civil action requesting relief be commenced simultaneously with or soon after the application for a writ ne exeat. A writ of ne exeat may be issued before judgment, it may be provided for in a final decree, or it may even be issued after judgment is established. It is a temporary remedy, and is not intended to operate as a perpetual restriction upon a defendant’s freedom of movement. In personam jurisdiction is required.

3. The present provisions for writ of ne exeat are found in 28 U.S.C. 1651— also known as the all writs statute — and section 7402(a). In any court proceeding where there exists justification to use a writ of ne exeat, the following pleadings are usually necessary:



   - Motion for writ of ne exeat (Exhibit 34.12.1-15)

   - Affidavit or affidavits containing facts sufficient to establish a prima facie case for the issuance of such a writ (Exhibit 34.12.1-16)

   - Writ of ne exeat (this is signed by the Clerk of the Court and is addressed to the U.S. Marshall from the President of the United States, and the Marshall is charged with the responsibility of serving it (Exhibit 34.12.1-17)

   - Order for writ of ne exeat (Exhibit 34.12.1-18)

   - Bond (Exhibit 34.12.1-19)


4. Actions to obtain writs of _ne exeat republica_ shall be coordinated with the Office of the Associate Chief Counsel (International), Branch 1, where the taxpayer is an alien or nonresident citizen who has resided in a foreign jurisdiction for a period of time. If the taxpayer is a longtime U.S. citizen, coordination is with the Office of the Associate Chief Counsel (Procedure & Administration), Branch 3 or 4.


**34.6.1.2.5** **(07-27-2021)**

#### Injunction Procedures by the United States

1. The United States as a plaintiff in an action has exactly the same rights and remedies available relative to restraining and injunctive relief as any other party to a proceeding. In _U.S. v. Ernst & Whinney_, 735 F.2d 1296 (11th Cir. 1983), the Court held that section 7402(a) gives the district courts broad powers to grant injunctive and other equitable relief necessary to enforce the internal revenue laws. For Injunction actions brought by the United States under section 7402(a), review and approval by the Associate Chief Counsel (Procedure & Administration) is required. Suit letters should be forwarded to Branch 5, for review.

2. Civil injunctions under section 7402(a) to restrain pyramiding. Where a taxpayer is pyramiding trust fund taxes and the seizure of the business would not yield net proceeds, IRM 5.7.2 and IRM 5.17.4.17 set forth procedures that must be followed before seeking an injunction under section 7402(a). Where the Service determines that a judicial order is necessary, the usual writ of entry procedures should not be followed. In these cases, a suit letter should be prepared authorizing DJ to take appropriate action to enjoin further pyramiding. This letter should describe the extent of the taxpayer’s pyramiding and the Service’s previous efforts to bring the taxpayer into compliance. Generally, the Service will have given the taxpayer notice pursuant to section 7512. DJ will seek an injunction against further pyramiding and may, in appropriate cases, seek an entry order as a sanction for contempt.

3. Streamlined section 7402(a) procedure. There is also a streamlined section 7402(a) injunction procedure dealing with section 861 Employment Tax Stop Filer Cases. For such an injunction the Service needs to demonstrate:



1. That the employer is still in business and paying wages,

2. That the employer is refusing to withhold based on the frivolous section 861 argument, and

3. That the employer has been warned by the IRS and requested to start withholding and has failed to do so.


4. Section 7407, Action to Enjoin Income Tax Preparers. Under this section the United States has specific authority to enjoin tax return preparers who engage in certain proscribed practices.

5. Section 7408, Actions to Enjoin Specified Conduct Related to Tax Shelters and Reportable Transactions. This provides specific authority for the United States to enjoin any person who takes action or fails to take action that is subject to a penalty under section 6700, 6701, 6707, or 6708 or is in violation of Circular 230.


**34.6.1.2.6** **(08-11-2004)**

#### Estate Tax Lien

1. The statutory 10-year estate tax lien is not based on an assessment but arises automatically on the date of death. The 10-year estate tax lien is of absolute duration. Therefore, a lien foreclosure must be completed before the expiration of 10 years. On the other hand, an administrative levy is completed once the notice of levy is served or, in the case of tangible property, when the notice of seizure is given. Thus, any suit outside the 10-year period to enforce a levy would not be barred. The estate tax lien may be available as a basis for action when the assessment lien or general lien is not applicable or is not entitled to priority under the circumstances. If the assessment lien arises after intervening rights come into play reliance must be placed upon the estate tax lien. There should be a thorough analysis of the circumstances giving rise to the estate tax lien and how it achieves priority over any intervening lien.

2. A remedy available but not often used is the suit to collect the estate tax lien from property listed in the gross estate on the federal estate tax return but not a part of the probate estate. _See_ section 6324(a).

3. A remedy may be available based on the special lien provided for in section 6324A for estate tax deferred under section 6166 or 6166A (extension of time for payment of estate tax where estate includes closely held business). A remedy may also be available based on the special lien provided for in section 6324B for additional estate tax that may arise where specially valued property is disposed of or ceases to qualify for the special valuation under section 2032A (property used as a farm or used in a trade or business).


**34.6.1.2.7** **(08-11-2004)**

#### Gift Tax Lien

1. The statutory 10-year gift tax lien arises automatically upon the making of the gift. Therefore, it may achieve a priority over rights that have arisen prior to the actual date of assessment. In any suit letter based upon this gift tax lien, there should be an analysis of how the lien arose, what property it is applicable to, and how priority over intervening creditors has been achieved. The names and addresses of any other claimants to the property should be included in the letter.


**34.6.1.2.8** **(08-11-2004)**

#### Limited Action Recommendations

1. Whenever Field Counsel believes that a limited action is preferable, this should be clearly stated in the letter to DJ, with the reasons for such recommendation.

2. The authorization paragraph of the letter should contain the usual broad and general authorization statement; it should not be limited to the specific action later requested in the letter.

3. Where appropriate, it is proper to recommend as many counts in the same action as may be appropriate or necessary to accomplish a desired result.


**34.6.1.2.9** **(08-11-2004)**

#### Procedure After Judgment Becomes Final

1. The primary responsibility for the collection of judgments rendered in favor of the United States rests with DJ. As a general rule, DJ looks to the local U.S. Attorney to collect judgments. The U.S. Attorney will generally request assistance from the Area Director. If Field Counsel is contacted regarding the judgment, it will also seek assistance from the Area Director’s office. _See_ IRM 5.17.4.


**34.6.1.2.10** **(10-07-2015)**

#### Settlement Procedures

1. Collection suits referred to and pending with DJ under most circumstances are under the settlement authority of the Attorney General. A suit letter to the Tax Division requesting and authorizing suit is ordinarily sufficient "reference" to give the Attorney General the authority to compromise under section 7122. A court proceeding need not be in existence. General guidelines for settlement procedures can be found at CCDM 34.8.

2. In all cases where the United States has obtained a judgment for the tax liabilities, compromise authority thereafter is only with the Attorney General. The Service cannot compromise under section 7122 taxes that have been reduced to judgment (except Tax Court judgments). In the past, when the Service has compromised taxes not realizing judgment has been entered, the facts have been forwarded to DJ and a request made that the compromise be affirmed.

3. Most suit recommendations referred to DJ will be subject to S.O.P. procedures, which means that DJ need not refer a settlement offer to the Office of Chief Counsel, unlike a case that is classified as STANDARD. Examples of cases that should be classified STANDARD are cases that require the review or approval by the Office of the Associate Chief Counsel (Procedure & Administration) or Division Counsel, cases where the taxpayer is in flagrant noncompliance, cases that are especially sensitive, or cases in which settlement may create difficulty in collecting from other taxpayers. _See_ CCDM 34.5.1.1.1 Case Classification.

4. Regardless of whether a case has been classified S.O.P, DJ will refer any settlement offer based on collectibility to Field Counsel, who will refer it to the Area Director for verification.

5. Field Counsel has the responsibility of furnishing a settlement recommendation to the Tax Division on behalf of the Service. There is no specific requirement that the Area Director be contacted and asked for views; however, whenever possible, Field Counsel should obtain the views and recommendations of the Director’s office. Where the views of Field Counsel and the Territory Manager’s office regarding the offer are not in agreement, it is suggested that the case be referred to the Area level for resolution. If there is no resolution at the Area level then the case should go to Division for resolution.

6. The letter to the Tax Division should state the recommendation of the Office of Chief Counsel. A counteroffer can also be recommended.

7. There are no conferences by litigants and their representatives with the Associate Chief Counsel (Procedure & Administration) concerning offers in cases pending with Field Counsel.

8. Settlement recommendations to the Tax Division on offers in field cases are usually signed in the Field Counsel’s office.


**34.6.1.2.11** **(08-11-2004)**

#### Restrictions Applicable to Deficiencies

1. Unassessed deficiencies for income, estate, and gift taxes are not recommended for suit.


**34.6.1.3** **(08-11-2004)**

### Preparation of Suit Letters

1. A suit letter is the letter to DJ requesting and authorizing the institution of civil action to collect or recover taxes. The letter states the authorization required by sections 7401 and 7403. In some instances the suit letter may sanction legal action already taken by DJ.

2. If the case is classified as S.O.P. by the Area Director or meets the S.O.P. criteria, the Field Counsel attorney shall enter S.O.P in capital letters on the bottom of the first page of the initial letter to DJ. If the S.O.P. procedure does not apply, the attorney shall enter "STANDARD " . Where the classification is omitted, DJ will presume that a case can be treated as S.O.P. See CCDM 34.5.1.1.1 for case classification guidelines.

3. The suit letter should include all relevant facts and legal arguments. It should anticipate all legal defenses to the Service position and include a reply to such defenses.

4. The suit letter should clearly state the action DJ is being requested to take.


**34.6.1.3.1** **(07-27-2021)**

#### Format of Suit Letters

1. The suit letter is prepared on Field Counsel stationery in the style prescribed by Office of Chief Counsel instructions concerning correspondence. It is signed on behalf of the Chief Counsel by the Field Counsel, with an appropriate by-line, subject to proper delegation to the Field Counsel.

2. The letter is personally addressed to the Assistant Attorney General, Tax Division, Department of Justice, for the attention of the Chief, Civil Trial Section of the appropriate Region.

3. The symbols of the originating office are indicated on the letter.

4. The caption of the letter should include the caption of the court action, where there is one, and DJ file symbols if known. The name and address of the taxpayer will be stated in the caption. The social security number or other taxpayer identification number should also be included. Special instructions concerning captions in cases where more than one function is involved will be found in the orders concerning coordination. Furthermore, the applicable statute of limitations date should be stated.

5. The originating attorney and reviewing supervisors should initial the letter on the designated initialed copy.

6. For cases where pre-review is required the suit letter will be emailed to Area Counsel and mailbox TSS Assignments where it will be forwarded to the appropriate Associate Chief Counsel office which will promptly contact the Field Counsel attorney assigned to the case.

7. Copies. The original is sent to the Tax Division. The copies should show the following distribution:



   - 1 cc-Technical Support staff with address of originating office

   - 1 cc- Area Counsel

   - 1 cc- U.S. Attorney, if desired, with address

   - 1 cc-Any other office or function that may be concerned


**34.6.1.3.2** **(07-27-2021)**

#### Contents of Suit Letters

01. See Exhibit 34.12.1-8 for a checklist for use in preparing suit letters.

02. The first paragraph of a suit letter generally requests and authorizes suit or sanctions action pursuant to section 7401 or section 7403. Also, the first or second paragraph of the letter should state clearly what is being recommended, i.e., money judgment, foreclosure, enforcement of a levy, etc. If a personal judgment should not be secured, this fact should be stated, together with the reasons.

03. In addition to all the necessary data concerning the tax liability, information as to all efforts by the Area Director to enforce the tax lien administratively should be included. The collection history of the case is vital. State to what extent administrative remedies have been exhausted and the potential for future collection if the statute of limitations is extended.

04. Where appropriate, the suit letter should set forth a complete description of the property, the nature and amount of competing liens, and the identity of all lienors (and other affected parties) and their addresses so that they may be served as party defendants. The revenue officer’s report should not seek to determine the validity of the various claims.

05. The suit letter should analyze the relative priorities and indicate the fair market value of the property involved. Encumbrances that may have been satisfied or are otherwise unenforceable but have not been marked satisfied should be included in the letter.

06. All persons claiming any interest in the property to be foreclosed should be joined in the action and, preferably, at the beginning of the suit, because it is difficult to amend pleadings and amendments are frowned on by the courts.

07. Title searches should be complete, current, and accurate.

08. Where the Government has the burden of proving fraud, the suit letter should include Special Agents’ reports, Revenue Agents’ reports and any other data indicating fraud. Accurate information is necessary to back up all affirmative allegations.

09. Where cases involve trust fund recovery penalty assessments, the following should be included:



    - Is the corporation still in existence?

    - Has any of its liability been paid?

    - Are there other responsible persons?

    - Does the Service intend to sue other responsible persons?

    - Explain why the officer is responsible and how he/she willfully failed to pay the United States the withholding taxes.


10. If insolvency is involved, it must be affirmatively alleged with as many facts supporting insolvency.

11. If an operating receivership is requested, the request should be well-documented since it is quite expensive and hard to control. There must be a clear need for a receiver shown, and if a potential person is known, his or her name should be included.

12. Where the United States seeks an injunction, evidence of equitable need must be presented to the Court before such relief will be granted.

13. All suit letters should include information pertaining to any notices issued and/or hearings conducted pursuant to sections 6320 and 6330 including court proceedings and their final disposition. A summary of all issues raised in these proceedings (where relevant) should be included.

14. Limitations on Assessments and Collection. Since DJ affirmatively alleges that the suit is timely the letter should explain why the collection periods are open where the suit is being commenced more than 10 years from the date of assessment. Copies of all available proof must be transmitted as enclosures to the suit letter. Furthermore, the letter should point out where the original documents are located. Keep in mind that the authority to extend the collection period under section 6502(a) has been severely curtailed and can only be done in very limited cases. _See_ IRM 5.17.4.5.



    1. When the assessment is more than three years from the due date of the filing of the return, the reasons why the assessment is timely must be explained. The following can extend the assessment period: execution of a waiver, omission of 25 percent of gross income, fraud, or that no return was filed. The fact that a petition was filed with the Tax Court and assessment had to await the outcome of the proceedings is another possibility. Waivers and any other documents explaining the delay in assessment should be obtained, if necessary.


15. At the institution of the suit, DJ should be informed as to what information will be made available and what is in existence. Attach what you have to the suit letter.

16. Additionally, the suit letter should contain:



    1. The request and authorization for the commencement of the suit;

    2. The necessary tax data in a schedule or stated in the letter;

    3. A complete statement of the venue, jurisdictional and substantive issues presented;

    4. The applicable statutes (federal and state) and regulations;

    5. The citation of pertinent court decisions;

    6. A determination of the Government’s position and, where appropriate, suggestions regarding the type and content of pleadings to be filed;

    7. The identification of individuals having information relevant to the claims and defenses — i.e., the names and current or last-known telephone numbers of the case agent (revenue officer; revenue agent, etc.) and principal witnesses with testimony/evidence relevant to the case; and

    8. The identification of the specific location or custodian of documents most relevant to the case — i.e., the name, business address and telephone number of a Service contact who is the custodian of the relevant case documents (typically the administrative files).


17. Copies of all pertinent documents should be enclosed (many of which will be included administrative file in collection suits) with the letter including:



    - Tax returns, including waivers

    - Copy of R.A. and S.A. reports

    - Copy of statutory notices

    - Appeals Division memorandum, if applicable

    - Conference memoranda with taxpayers, etc.

    - Copies of all summonses issued

    - Copies of Proofs of Claim filed

    - Tax collection waivers (copies go with suit letter)

    - Copies of any installment agreements

    - Copies of offers in compromise submitted by taxpayer

    - Copies of financial statements submitted by taxpayer

    - Copies of all assessment waivers, e.g., 870, 870 AD, and trust fund recovery penalty waivers

    - Transcript of account

    - Copies of original notice of lien and refilings

    - Copies of notice of levy

    - Copies of notices issued in accordance with sections 6320, 6330, and 6331(d)

    - Application for discharge

    - Asset appraisals, if any


**34.6.1.3.3** **(08-11-2004)**

#### The Basis for the Complaint

1. A suit is instituted by filing a complaint. It is a notice-type proceeding. Adequate and full information should be contained in the suit letter. Supplemental letters can be sent to DJ if additional information is subsequently obtained after the due date of the letter. There are three phases of a complaint: Jurisdiction and Venue, Statement of the Claim, and Prayer for Relief.

2. Jurisdiction. Usually jurisdiction is statutory in federal courts, and there are generally no problems. The following questions should nonetheless be considered:



01. Where is the party?

02. Can the federal court assume control of the property involved or is control in a state?

03. Court or a bankruptcy court?

04. Is there personal jurisdiction over a party to secure a personal judgment? (In this connection, it is suggested that a state’s long-arm statute should be used to a greater degree.)

05. Who are the defendants to the suit? This question must be considered before requesting a suit.

06. If a minor is involved, is there a guardian ad litem?

07. If the taxpayer is deceased, is an administrator necessary?

08. If a defunct corporation is involved, state law must be looked into to determine who is to be sued and when.

09. If a municipality is involved, whom do you sue?

10. If a business association is involved, is it a legal, suable entity, and how do you sue?

11. If a receiver, trustee, or other fiduciary is involved, is approval of the court necessary before suing?


3. Venue for an in-rem proceeding is where the res is located. Venue requirements for suit are where the return is filed, where the liability occurs, or where the taxpayer resides.

4. A Statement of the Claim is necessary to allege that an assessment has been made.

5. Prayer for Relief. This portion of the complaint follows from the theory of the case.


**34.6.1.3.4** **(08-11-2004)**

#### Tax Data

1. The Tax Division has indicated that, in addition to the items listed above, the following tax data should be included in all suit letters:



1. Date of assessment;

2. Breakdown of assessment to show type and amount of tax (penalty and interest are to be stated separately) and the type of penalty is to be described by reference to the applicable section of the Code;

3. Clear description of the assessments. If excise taxes are involved, specify what type of excise tax;

4. Date of Notice and Demand;

5. Amount of tax, penalty and interest currently outstanding (tax, penalty and interest are to be separately stated; the rate of daily accrual of interest should be shown).


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part34/irm_34-006-001#addtoany "Show all")

A2A