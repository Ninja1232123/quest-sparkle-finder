---
url: "https://www.irs.gov/irm/part31/irm_31-001-004"
title: "31.1.4 Coordination and Reconciliation of Disputes | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part31/irm_31-001-004#main-content)

- 31.1.4 [Coordination and Reconciliation of Disputes](https://www.irs.gov/irm/part31/irm_31-001-004#idm139939610122624)
  - 31.1.4.1 [Guidelines for Coordination](https://www.irs.gov/irm/part31/irm_31-001-004#idm139939610122176)
  - 31.1.4.2 [Coordination within the Office of Chief Counsel](https://www.irs.gov/irm/part31/irm_31-001-004#idm139939610231312)

    - 31.1.4.2.1 [Coordination among Division Counsel](https://www.irs.gov/irm/part31/irm_31-001-004#idm139939610228896)

      - 31.1.4.2.1.1 [Case Assignment across Division Counsel](https://www.irs.gov/irm/part31/irm_31-001-004#idm139939610224416)
      - 31.1.4.2.1.2 [Assignment of Cases to Special Trial Attorneys](https://www.irs.gov/irm/part31/irm_31-001-004#idm139939610208544)

    - 31.1.4.2.2 [Coordination among Associate Chief Counsel](https://www.irs.gov/irm/part31/irm_31-001-004#idm139939610170704)
    - 31.1.4.2.3 [Coordination among Associate Chief Counsel and Division Counsel](https://www.irs.gov/irm/part31/irm_31-001-004#idm139939610153680)
    - 31.1.4.2.4 [Coordination of Related Cases or Matters in Litigation](https://www.irs.gov/irm/part31/irm_31-001-004#idm139939610141600)
    - 31.1.4.2.5 [Coordination of Employee Benefit Cases](https://www.irs.gov/irm/part31/irm_31-001-004#idm139939610129856)
    - 31.1.4.2.6 [Coordination with Industry and Issue Specialization Programs](https://www.irs.gov/irm/part31/irm_31-001-004#idm139939610125856)

  - 31.1.4.3 [Coordination with IRS Divisions](https://www.irs.gov/irm/part31/irm_31-001-004#idm139939595345392)
  - 31.1.4.4 [Treasury](https://www.irs.gov/irm/part31/irm_31-001-004#idm139939595341648)

    - 31.1.4.4.1 [Financial Management Service](https://www.irs.gov/irm/part31/irm_31-001-004#idm139939595331904)

  - 31.1.4.5 [Coordination with other Government Agencies](https://www.irs.gov/irm/part31/irm_31-001-004#idm139939595326400)

    - 31.1.4.5.1 [Department of Justice](https://www.irs.gov/irm/part31/irm_31-001-004#idm139939595320496)
    - 31.1.4.5.2 [Coordination of Indian Tax Cases](https://www.irs.gov/irm/part31/irm_31-001-004#idm139939595315856)

  - 31.1.4.6 [Reconciliation of Disputes](https://www.irs.gov/irm/part31/irm_31-001-004#idm139939595299712)

# Part 31.Guiding Principles

# Chapter 1. Guiding Principles

# Section 4. Coordination and Reconciliation of Disputes

* * *

## 31.1.4 Coordination and Reconciliation of Disputes

**31.1.4.1** **(08-11-2004)**

### Guidelines for Coordination

1. To achieve accuracy, uniformity, and consistency in Chief Counsel documents, advice must often be solicited from other Chief Counsel, Service, or Agency offices on issues crossing into their jurisdictional areas. In addition, proposed action should be coordinated with other governmental entities and entities outside the Government. The following sections address the manner in which coordination and reconciliation of differences should be undertaken.

2. Assistance should be sought from any Chief Counsel office or other components of the Service that has assigned expertise in the subject matter involved in a project or whose operational area may be affected by the position to be taken. The following are examples the types of matters in which assistance should be sought:



   - Published guidance, technical advice memorandums, and legal advice that have a significant potential impact on the workload, procedures, or operating plans of other Counsel or Service components

   - Matters that involve issues within the technical subject matter jurisdiction of other offices as set out in the code and subject matter directories

   - Matters in which Service position has not been established

   - Sources of controversy and other problems revealed in the management of operating division programs that indicate a potential need for technical clarification

   - Legal or operational issues that will affect more than one taxpayer segment


3. Offices should identify matters that require coordination with another office or organization as early as possible and should continue, as appropriate, until resolution of the matter. Any doubts with respect to whether an issue should be coordinated should be resolved in favor of coordination.

4. The specific method of coordination will depend on the significance and complexity of the matter, as well as any external deadlines. Coordination can be accomplished through telephone or email contact or by formal memorandum. The originating organization, however, will coordinate its work in a way that encourages meaningful review and comment by other organizations.

5. The specific procedures governing coordination of:



   - Published guidance are contained in CCDM Part 32, Published Guidance and Other Guidance to Taxpayers.

   - Legal advice are contained in CCDM 33.1, Legal Advice.

   - Cases in litigation are contained in CCDM 31.2, Significant Case Coordination; CCDM Part 34, Litigation in District Court, Bankruptcy Court, Court of Federal Claims , and State Court; and CCDM Part 35, Tax Court Litigation.

   - Matters among Associate offices are contained in CCDM 31.1.4.2.2.

   - Matters involving more than one taxpayer segment or issues handled by one Division Counsel for all taxpayer segments are contained in CCDM 31.1.4.2.1.


6. In some situations, matters handled by Associate Chief Counsel or Division Counsel require coordination with other offices within the Department of Treasury or other governmental agencies, such as the Department of Justice, other federal departments or agencies, or state taxing authorities. When these situations arise, early coordination, through appropriate management channels, is required.

7. Any disagreements between Division Counsel and Associate Chief Counsel, DC and DC, ACC and ACC concerning legal positions shall be resolved through the reconciliation procedures described in CCDM 31.1.4.4. Disagreements with the Service functions will be reconciled using procedures similar to those that apply to disagreements within Counsel. Any dispute should be resolved or elevated and resolved before action is taken.

8. An attorney should advise the appropriate Associate Chief Counsel or Division Counsel whenever there is a case which may generate publicity, be it because of the type of issue involved or the particular taxpayer involved. Also, Field Counsel should advise the Associate or Division Counsel whenever a case is received which involves a significant issue such as, for example, an issue that may have industry wide impact.


**31.1.4.2** **(08-11-2004)**

### Coordination within the Office of Chief Counsel

1. The overriding goal of the coordination process within Chief Counsel is to ensure anything signed by or approved in the Chief Counsel’s name should represent the position of the entire office and not merely the position of a particular individual, division, or office. This coordination ensures that issues that cut across operating divisions are resolved consistently and that the specialized expertise of the subject matter experts in the Associate office is combined with the experience and expertise of the professionals in the Division Counsel organizations.


**31.1.4.2.1** **(10-20-2010)**

#### Coordination among Division Counsel

1. Matters under the jurisdiction of the respective Division Counsel may affect matters handled by other Division Counsel. Examples are tax shelters, large bankruptcy cases, certain industry-related initiatives, LB&I or SB/SE cases involving TEGE issues, or cases in different Divisions dealing with the same taxpayer. Division Counsel attorneys should be alert to situations where legal positions, strategies, or programs of other Division Counsel cut across Counsel organizations and coordinate through appropriate management channels to ensure a consistent and uniform approach.


**31.1.4.2.1.1** **(10-20-2010)**

##### Case Assignment across Division Counsel

1. Work or inquiries directed to a post of duty (POD) that is not addressed to a specific group within that POD or that does not fall wholly within the responsibilities of a particular Counsel Division will be directed to points of contact established as described below.



1. All incoming case work that is not specifically directed to a given group should be given to the POD contact manager who will review and determine to which Division the request should be routed within the office. The POD contact manager will also field all general, non-directed incoming correspondence, calls, and requests for support from community organizations (e.g., general local bar). The contact manager for a particular POD will be designated by the Area Counsel(s) with managers situated in that POD. The contact manager assignment may be rotated or modified as agreed by the Area Counsel.

2. All incoming case work relating to a Division with more than one practice group should be given to the contact manager for that Division who will review and assign cases to the multiple groups within the Division. This contact should also handle all incoming correspondence, calls, or requests for the Division that are directed to that Division but not specifically directed to a Division attorney or group. The contact manager for each Division in the POD will be designated by the Area Counsel for that Division.

3. Disputes concerning the assignment of work within PODs will be resolved by the respective Area or Division Counsel, as appropriate.


2. Assignment of work between Divisions will be made by agreement of the respective Division Counsel.



1. If an LB&I case is assigned to an SB/SE attorney, the Large Business & International (LB&I) manager with responsibility for the work from that POD will review the case. The LB&I AAC geographically connected with the SB/SE attorney will keep the SB/SE attorney informed of all LB&I practices, developments, and procedures that may have an impact on the case for which he or she is responsible. The SB/SE attorneys assigned responsibility for LB&I cases will be subject to the same reporting requirements as LB&I practice groups and will coordinate reports through the LB&I ACC.

2. If an SB/SE case is assigned to an LB&I attorney, the SB/SE manager will review the case. The SB/SE AAC from whom the SB/SE case is transferred will keep the LB&I attorney informed of all SB/SE practices, developments, and procedures that may have an impact on the case for which he or she is responsible. The LB&I attorneys assigned responsibility for SB/SE cases will be subject to the same reporting requirements as SB/SE practice groups and will coordinate reports through the SB/SE AAC from whom the SB/SE case is transferred.


3. Issues will arise in cases involving taxpayers that should be coordinated with other Divisions. For example, SB/SE groups will handle most matters that were formerly classified as general litigation, but may need to coordinate substantive tax issues arising in cases involving LB&I taxpayers with LB&I. An LB&I case may contain several issues, one of which is a TEGE issue. Attorneys should seek assistance from the affected Division through their Area Counsel. Area Counsel may agree that the case should be transferred in its entirety or that the other division will provide assistance on certain issues. If it is determined that the other Division will handle only certain issues in the matter, the offices should ensure that they resolve the issues in a consistent fashion.


**31.1.4.2.1.2** **(10-20-2010)**

##### Assignment of Cases to Special Trial Attorneys

1. Special Trial Attorneys (STA) are a Counsel-wide resource. They handle the Office’s most significant and complex Tax Court litigation, assisted by teams of co-counsel. Cases are selected for assignment to Special Trial Attorneys through a careful Division Counsel coordination process. Special Trial Attorneys may be assigned cases referred from other Division Counsel. Also, while most co-counsel are drawn from LB&I, attorneys from other parts of Chief Counsel’s Office may serve as co-counsel to Special Trial Attorneys after coordination between their offices and LB&I Division Counsel.

2. Criteria to consider in evaluating cases for assignment to STAs include: whether the case involves a deficiency over $1M; whether the case originates with the Industry or Issue Specialization, International, or CIC programs; whether the case involves an Appeals Coordinated Issue or other significant issue with broad impact; and whether the case has cross-Area implications or involves highly complex issues.



1. LB&I practice groups should identify potential STA cases while the cases are in nondocketed status and determine if it would be beneficial for an STA to be involved at this stage of the case. Additionally, notifying the Deputy Area Counsel (Strategic Litigation) about potential STA cases allows STA groups to plan for incoming docketed cases. Accordingly, each LB&I Associate Area Counsel (AAC) should notify the Deputy Area Counsel (SL) as early available as possible when a potential STA issue is identified in a nondocketed case. Options include:



      |     |
      | --- |
      | • Assigning an STA, often with assistance of LB&I practice group attorneys, to develop the case; |
      | • Assigning an STA to serve as a consultant or advisor to the LB&I practice group attorney(s); or |
      | • Assigning the nondocketed matter to the LB&I practice group and deferring the decision about STA assignment pending the statutory notice stage or screening of the petition for significant case coordination. |

2. Each LB&I AAC will notify the appropriate Deputy Area Counsel (SL) when the group receives for review a notice of deficiency that meets these criteria. While sufficient documentation about the issues should accompany the notification to enable an informed decision about STA assignment, the practice group should not generally forward the entire file or transfer the case until a decision is reached that an STA will be involved.

3. Expeditiously upon receipt of each new docketed case, practice groups will notify the Strategic Litigation manager of the STA group in their Area. The practice group should retain the file and not transfer the case until it is decided that an STA will handle the case. An AAC should provide notification of a new docketed case even if notification of a request for statutory notice review in the case was not provided. For many cases, a decision to assign a case to an STA will not be made until the case is docketed. Notification of a new docketed case is also necessary even if an STA was involved in the statutory notice review. Legal Processing Division employees cannot identify STA cases from the face of a new petition or from a statutory notice if attached. The instructions for assignment provide that new LB&I cases are to be served on practice groups, rather than on STA groups. Without notice from the practice group that the docketed case had arrived, the STA group may not know that a petition had been filed.

4. Practice groups should refer potential STA cases to the Deputy Area Counsel (SL) in their geographic Area. If an Area has more than one Deputy Area Counsel (SL), the practice group should send the notification to the Deputy Area Counsel (SL) designated by the Area Counsel. The Deputy Area Counsel (SL) receiving notification is responsible for coordinating with other Deputy Area Counsels (SL) having an interest in the case or issue and with Area and Division Counsel, who will make the case assignment to an STA.

5. Upon receipt of a referral from a practice group, the Deputy Area Counsel (SL) will evaluate whether a new case is appropriate for assignment to an STA, as opposed to a practice group attorney, based on the factors described above. The Deputy Area Counsel (SL) may ask the practice group for additional excerpts from the file in order to make this judgment. Questionable situations should be reviewed with the Area Counsel.

6. Assuming the case is appropriate for an STA, the Deputy Area Counsel (SL) who received the referral will assess which other Areas may have STAs possessing specialized familiarity with the issue or industry involved. In conjunction with the affected Area Counsel, the Deputy Area Counsel (SL) who received the case referral from the practice group will forward his or her recommendation concerning assignment to the Area Counsel and assist with coordination with other relevant Areas. Area Counsel will coordinate with the Division Counsel to determine the most appropriate STA to whom to assign the case, taking into account all relevant perspectives and factors, including the site of the taxpayer, relevant books and records, witnesses, and revenue agents; the place of trial; the experience level and skills required of the lead trial attorney and team members for the particular case; the number and location of available co-counsel; and the particular expertise of the STA and/or team members as to the type of substantive issue or industry involved. Inter-Area team member support or other consultation arrangements among Areas may also be discussed.

7. Deputy Area Counsels (SL) and Area Counsel should keep the Division Counsel apprised at times when their groups have either capacity for additional assignments or exceptionally heavy workloads, so that the Division Counsel can balance STA workload nationally when making assignments.


3. Managers in SB/SE and TEGE, in consultation with LB&I, will use the criteria set forth above to determine whether a case should be considered for assignment to an LB&I STA. Division Counsel in SB/SE or TEGE will forward to the LB&I Division Counsel the recommendation that a case be assigned to an STA. The LB&I Division Counsel, after consulting with the other Division Counsel, will determine whether a case will be assigned to an STA and, after appropriate consideration, will make the assignment.

4. STAs will evaluate their team member needs on a case by case basis and discuss them with their managers, taking into account the particular experience level or expertise needed for the specific issues and tasks, the probable duration of the assignment, and the estimated percentage of attorney time required. Thereafter, the Deputy Area Counsel (SL) will contact LB&I practice group managers to discuss potential team members. If a specific LB&I attorney was identified during discussion with the STA, the Deputy Area Counsel (SL) will contact that attorney’s manager. Otherwise, the Deputy Area Counsel (SL) will contact another LB&I practice group in the Area, typically the group that provided nondocketed assistance on the case or a group that has particular experience with the issue. The Area Counsel may elect to participate in this process. If a conflict over team member availability cannot be resolved, the managers will elevate the problem to the Area Counsel for resolution. If the Area Counsel was not involved previously, Deputy Area Counsels (SL) should discuss the assignments with the Area Counsel before making a final decision regarding team assignments.



1. In evaluating team member needs, STAs and Deputy Area Counsels (SL) should be alert to situations where trial team attorneys possessing particular industry or issue expertise may be located in a different LB&I area. When such a need is identified, the Deputy Area Counsel (SL) should discuss this with Area Counsel, who will then contact his or her counterpart Area Counsel to discuss the assignment of an attorney with the requisite expertise. Conflicts between Area Counsel will be resolved by the Division Counsel.

2. After assignment of team members, the STAs and Deputy Area Counsels (SL) should communicate regularly with the practice group managers to ensure that each team member’s workload is appropriate and to forecast any unusual demands from either the STA case or practice group work. They should review CASE time reports to confirm that time commitments are fulfilled and to identify any workload imbalances. A co-counsel time projection sheet may be used each month to aid the STAs, team members, and their respective managers, in forecasting the team member’s time commitment to the STA assignment for the current month and next three months.


5. Although most team members will be drawn from LB&I practice groups, in some instances attorneys from SB/SE and TEGE may be assigned to STA teams. If a practice group manager from another Division recommends that an attorney serve as an STA team member, that manager will contact his or her Area Counsel who will then contact the LB&I Area Counsel to recommend the attorney. If, after conferring with the Deputy Area Counsel (SL) and the STA, the LB&I Area Counsel determines that the attorney from the other Division should serve as a trial team member, the LB&I Area Counsel will contact the LB&I Division Counsel who will contact the other Division’s Division Counsel to seek permission to assign the attorney to the trial team.

6. Where the STA and Deputy Area Counsel (SL) believe that an attorney from another Division would enhance an STA trial team, the Deputy Area Counsel (SL) will discuss the need for that attorney with the LB&I Area Counsel. The LB&I Area Counsel will contact the LB&I Division Counsel. If the LB&I Division Counsel agrees with the recommendation, the other Division Counsel will be contacted about the request. If the Division Counsel in the other Division agrees, after discussing the request with the affected attorney and practice group manager, the attorney will be assigned to the STA trial team. In situations involving team members from other divisions, STAs and Deputy Area Counsel (SL) may elect to use a co-counsel time projection sheet to facilitate a common understanding of the team member’s time commitment to the STA case.


**31.1.4.2.2** **(08-11-2004)**

#### Coordination among Associate Chief Counsel

1. The Associate offices will provide an early opportunity for input to any other Associate office that might have an interest in a project. Coordination should include not only specific issues listed in the code and subject matter directories as within the jurisdiction of another organization, but also matter affecting programs or operations of another organization.

2. Work sent to the Associate offices, whether a brief or a ruling request, is assigned to the Associate office with subject matter jurisdiction over the principal issue. That office is primarily responsible for the completion of the assignment (i.e., filing in Tax Court, responding to a ruling request).

3. The office having primary responsibility for a work item is responsible for coordinating secondary issues outside its subject matter expertise with the appropriate offices. In responding to coordination requests, one branch in each Associate office will be assigned primary responsibility for the Associate office’s response. That branch is responsible for obtaining all necessary coordination within the Associate offices and combining them into a single response for the coordinating Associate.

4. The Associate Chief Counsel Procedure & Administration is responsible for many judicial practice issues. P&A attorneys are subject matter experts on procedural matters and will provide technical assistance for procedural and substantive issues. The CCDM, Tax Court Rules of Practice and Procedure, and the Special Counsel in Associate front offices should be consulted prior to consultation with P&A on routine matters.

5. More complex matters regarding judicial practice and other procedural issues should be coordinated with P&A as the subject matter experts using the same standard that would apply to coordination of other issues in a case. Issues involving sanctions or ethics must be formally coordinated with P&A. The Associate Chief Counsel (Procedure & Administration) is the sanctions officer for tax litigation matters; sanctions officer approval of such matters is required by the Executive Order on Civil Justice Reform.

6. Certain work items have very short deadlines and require nearly immediate coordination with Associate offices having responsibility for issues in the work item. The primary Associate office must coordinate these issues no later than the second day after receiving the assignment. Priority work items include:



   - Prebrief Review

   - Brief Review

   - Motion Review

   - Certiorari Recommendations

   - Legal Advice reviewed by Associate Offices (see CCDM 33.1, Legal Advice).


7. It is also essential for the office receiving the coordination to communicate immediately with the primary Associate office to advise of the receipt of the coordination and the identity of the attorney assigned to it. Offices receiving a coordination request should confirm their receipt of a coordination by phone or email. Coordination responses are to be completed no later than two working days prior to the filing date of any litigation matter. If a coordination response cannot be completed within that timeframe, the responsible manager must advise a manager in the coordinating branch prior to the close of business two working days prior to the filing date. The responsible manager must confirm this contact is made; unacknowledged email or voicemail will not suffice. Although uncommon, circumstances may also arise where a more expeditious response is required. If such a case arises, requests for expeditious treatment should be made by the responsible manager.


**31.1.4.2.3** **(10-20-2010)**

#### Coordination among Associate Chief Counsel and Division Counsel

1. Associate Chief Counsel and Division Counsel in their headquarters and field offices have complementary roles. See CCDM 31.1.4.2 above. They must, therefore, work together in handling cases and in producing many types of work products. In many instances, the National Office provides advice and assistance to Division Counsel. The advice and assistance may be provided formally or informally, orally or in writing. Whenever the National Office provides advice and assistance to Division Counsel, any disagreement that cannot be resolved through discussion must be reconciled through appropriate procedures. See CCDM 31.1.4.4 for reconciliation procedures.

2. Associate offices providing telephone assistance to any field function are required to maintain current records of each incoming call, the question posed, and the response given, pursuant to procedures in CCDM 33.1.3, Releasing Legal Advice to the Public.

3. Requests for formal technical advice pursuant to Rev. Proc. 2004–2, and succeeding yearly RPS, will be processed as provided in CCDM 33.2, Technical Advice And Technical Expedited Advice.

4. Written assistance by Associate offices to field counsel, other than TAMs and TEAMs, will be handled in accordance with CCDM 33.1, Legal Advice.

5. Division Counsel (Large Business & International) is responsible for coordinating Industry Specialization matters and will request review of IS Coordinated Issue Papers (CIPs) and Appeals Settlement Guidelines (ASGs) from the Associate office having primary subject matter jurisdiction for the issue. See CCDM 33.3.4, Division Counsel (LB&I) Industry Program, and CCDM 33.3.3, Appeals Settlement Guidelines, respectively. Division Counsel (Small Business/Self-Employed) is responsible for MSSP matters and may request review of audit technique guides (ATGs) and similar documents from the Associate offices having primary subject matter jurisdiction over the issues addressed in the guides. In addition to review by the subject matter experts on the issues addressed in an ASG, the ASGs are also reviewed by the office of the Deputy Associate Chief Counsel (Legislation & Privacy). See CCDM 33.3.3, Appeals Settlement Guidelines. . All CIPs, ASGs, and ATGs to be coordinated with the Associate offices will be sent by the Division Counsel to TSS4510 and will be assigned to the Associate office having jurisdiction over the subject matter issues that predominate in the document and to ACC (DPC).

6. See CCDM Part 32, Published Guidance and Other Guidance to Taxpayers, for procedures governing pre-filing agreements, Industry Issue Resolution, and requests for submissions to the Business Plan and CCDM 31.2, Significant Case Coordination, for significant case procedures.

7. The procedures governing designating cases for litigation are contained in CCDM 33.3.6, Designating a Case for Litigation.


**31.1.4.2.4** **(10-20-2010)**

#### Coordination of Related Cases or Matters in Litigation

1. The handling and processing of matters in litigation must be closely coordinated so as to establish a consistent litigation position in all the courts. Actions taken in one case potentially can have direct or indirect impact on other cases, involving either the same or related taxpayers. TECHMIS should be used to locate cases involving the same taxpayer and related or similar issues, and appropriate coordination with attorneys assigned related cases should be undertaken.

2. Generally speaking, a "related case" for coordination purposes is any pending case or matter which could be materially affected by a proposed action in a particular case, or any pending case or matter in which a proposed action would materially affect a particular case. The cases may be related because they involve the same taxpayer, either for the same or for different taxes or taxable years or for different aspects of the same tax liability; or because they involve the same or similar issues arising out of the same or similar transactions; or because they involve different taxpayers whose relationship is such that action taken with respect to one may materially affect the action to be taken with respect to the other. The case or matter "related" to the second case may be another case of the same type or one pending before another court or at some other stage in its development; it may be pending at various administrative levels within the Service, or before any of the functional divisions or sections in the National Office or field offices of the Chief Counsel, Treasury or the Department of Justice. All related circumstances cannot be precisely described, nor can the extent of the coordination appropriate in every instance be specifically detailed. The attorneys and supervisors should exercise judgment in determining the relationship of related cases or other matters.

3. A related criminal case or a Tax Court case having open criminal aspects may not be defined with exactitude. The related criminal case may involve either a case to which Criminal Investigation Division jurisdiction has attached, or in which there is a proposed or pending criminal prosecution of either the petitioner or of another person so related to the petitioner that the action proposed, or to be taken, in either the Tax Court case or the criminal case may materially affect the other. Thus, the criminal case and the Tax Court case may be related for coordination and other purposes described in this manual even though each involves different taxpayers and even though the taxable years involved in the two cases are not the same. Furthermore, the Tax Court case is to be considered related to the criminal case for coordination purposes even though the Criminal Tax Division authorized the issuance of the statutory notice during the criminal investigation of the taxpayer, or related taxpayer, and even though clearance with the Department of Justice was not required prior to issuance of the statutory notice upon which the Tax Court case is based. A Tax Court case may have criminal aspects if there is involved proposed or pending criminal prosecution of the taxpayer, or a related taxpayer, for alleged criminal violations of the Internal Revenue Code or the provisions of Title 18 of the United States Code involving revenue matters. The procedures governing the coordination of Tax Court and criminal cases begin at CCDM 35.4.1.5, Coordination with Criminal, Refund, and Collection Cases.

4. A Tax Court case and a refund suit shall be considered related cases if the concession or settlement of one, or the course of action to be pursued at the trial of one, may have a material effect upon the disposition of the other. Thus, the two cases may be related because they involve the same or related taxpayers, either for the same or different taxes or taxable years; or because they involve the same or similar facts or issues; or because they involve issues arising out of the same transactions. The procedures governing the coordination of Tax Court and refund cases are contained in CCDM 35.4.1.5.2, Coordination with Refund Cases, CCDM 35.5.3.3, Coordination of Tax Court and Refund Cases, and CCDM 34.5.2.5, Case Coordination/ Coordination of Tax Court and Refund Cases.

5. A Tax Court case and a collection suit or other general litigation matter, whether handled in the field or in the National Office, should be considered related cases, if significant action in one may have a material effect upon the other. Related general litigation matters may include a collection suit or other suits to enforce liens resulting from jeopardy assessments; claims filed in bankruptcy, receivership, probate court proceedings; injunction suits; suits to enforce administrative summons; various other state or federal court proceedings; and various administrative collection activities or International matters. Related collection activities usually relate to the same tax liability which is involved in the Tax Court case, and a settlement of such liability on the merits in either case may be dispositive of the other. In some related collection matters, the tax liability involved may not be the same as that in the Tax Court case, but if there is a direct relationship between the two and action with respect to one may materially affect the other, appropriate coordinating procedures should be followed. The procedures governing the coordination of Tax Court and collection matters begin at CCDM 35.4.1.5.3, Coordination of Tax Court Cases and Collection or Insolvency Cases.


**31.1.4.2.5** **(08-11-2004)**

#### Coordination of Employee Benefit Cases

1. Associate/Division Counsel (TEGE). The Office of the Associate/Division Counsel (Tax Exempt and Government Entities) is a hybrid structure encompassing both the types of duties carried out by an Associate Office and those of a field organization. The Associate/Division Counsel (TEGE) is responsible for providing all needed legal services, regardless of topic or function, for the IRS TEGE Division and its taxpayer segment. Occasionally TEGE will request the assistance of other Divisions in serving these clients. In addition, for certain topics, the Associate Chief Counsel (TEGE) office is also responsible for the delivery of topical legal expertise, regardless of customer or functional activity. Thus if Associate Chief Counsel or Division Counsel handling cases of taxpayers in other taxpayer segments encounter such topics in those cases, it is important that they coordinate with Associate/Division Counsel (TEGE).


**31.1.4.2.6** **(10-20-2010)**

#### Coordination with Industry and Issue Specialization Programs

1. Division Counsel (LB&I), in conjunction with the Pre-filing and Technical Guidance Office of the IRS LB&I Division, manages Industry and Issue Programs for specified industries and issues. The purpose of the programs is to identify emerging issues, develop current knowledge of the industry or issue, develop Service position on industry issues or other prominent, common technical issues, and ensure consistent treatment of taxpayers. Coordination with Industry and Issue Counsel is required whenever attorneys encounter issues in these areas. See CCDM 33.3.4, Division Counsel (LB&I) Industry Program, for a description of operation of the program.

2. Field attorneys should coordinate significant industry and issue specialization issues, in both docketed and nondocketed cases, with Industry and Issue Counsel. For assistance in determining whether an issue is significant for this purpose, the attorney may consult the IRS Technical Advisors’ web pages, which include specific industry guides (available through the Service’s LB&I PFTG site), or contact either the Industry Counsel or Technical Advisor. Responsibility for assuring appropriate coordination resides with the Associate Area Counsel.

3. When an Industry or Issue Counsel is contacted on an issue arising from a specific audit, the Industry Counsel must advise the Associate Area Counsel responsible for the audit location. When a taxpayer contacts an Associate Chief Counsel Office concerning a significant industry issue, the attorney in the Associate Office should notify the Industry or Issue Counsel. When an Industry Counsel receives an inquiry directly from an audit team or field attorney, he or she should coordinate with the IRS Technical Advisor.

4. Industry or Issue Counsel should coordinate with the appropriate Associate Chief Counsel Office to assure an issue reflects the correct interpretation of the law as applied to the facts of the particular case. The Industry or Issue Counsel should consult with the IRS Technical Advisor concerning proposals for published guidance that may affect industry issues.


**31.1.4.3** **(08-11-2004)**

### Coordination with IRS Divisions

1. Maintaining contact and open communication with Chief Counsel’s IRS clientele is vitally important to understanding and meeting their service needs and to supporting IRS initiatives and programs. Operating Division personnel should be kept informed of status of their cases and consulted when appropriate. Many Division personnel have extensive experience and expertise, which can be of assistance to Counsel attorneys.


**31.1.4.4** **(10-20-2010)**

### Treasury

1. Published guidance must be coordinated with Treasury. The procedures governing published guidance are contained in CCDM Part 32, Published Guidance and Other Guidance to Taxpayers.

2. Other matters that should be coordinated with Treasury include:



1. Certain letter rulings and technical advice memoranda involving significant policy issues, see CCDM 32.3, Letter Rulings, Information Letters, And Closing Agreements, and CCDM 33.2,Technical Advice And Technical Expedited Advice, respectively

2. Votes on plans in certain circumstances, see CCDM 34.3.1.3.2, Coordination

3. Appointment of an agent to bid at execution sales, see CCDM 34.4.1.8, Receiverships

4. Letters to the Department of Justice recommending appeal of a case important to tax administration, rehearing en banc, the filing of an amicus brief in the Supreme Court, or the filing of a petition for certiorari, see CCDM Part 36, Appellate Litigation and Actions on Decision.


3. Field offices may request information directly from to divisions of the Commissioner’s office in Washington, other Treasury bureaus in Washington, or other departments or agencies in Washington. If difficulties are encountered when a field office attempts to obtain services or documents directly from Washington agencies or bureaus or other divisions of the Treasury Department in Washington, then the request may be processed through the appropriate Associate office.


**31.1.4.4.1** **(08-11-2004)**

#### Financial Management Service

1. Civil cases handled by the Office of Chief Counsel occasionally involve a claim that a tax refund is due when the transcript of account or other Service records show that the refund check has already been issued, This may arise, for example, in a refund litigation case where the facts indicate that a Treasury check may have been endorsed by the wrong party, mailed to the wrong address, forged, lost, stolen or mutilated, or is otherwise missing. This situation may also arise in a taxpayer suit seeking mandamus or injunctive relief.

2. The Financial Management Service, a bureau within the Department of the Treasury, has the authority to investigate these claims and, if appropriate, to order the issuance of a substitute check. See 31 U.S.C. §§ 3331, 3343; 31 CFR Parts 235, 245. Whenever a Counsel attorney becomes aware of a claim in litigation that a Treasury check has been lost, stolen, forged, mutilated or destroyed, or is otherwise missing, the attorney should seek advice from the Chief Counsel, FMS. The initial contact with FMS should be by telephone call to the bureau’s Chief Counsel.


**31.1.4.5** **(08-11-2004)**

### Coordination with other Government Agencies

1. It occasionally is necessary that Chief Counsel attorneys coordinate with other governmental agencies. This may be undertaken at the local level, where the matter is completely within the jurisdiction of Division Counsel and the other local agency. In such cases, Chief Counsel attorneys should pay particular attention to any restrictions imposed under section 6103. Where jurisdiction in the matter lies in the National Office of the other Government agency, coordination should be arranged as much as possible at the local level and the matter transmitted to the appropriate Associate Chief Counsel to complete coordination with the other Government agency on a National Office level.

2. Any disputes with another agency concerning the legal position taken by the Service should be coordinated with the appropriate Associate Counsel.

3. In any instance in which documents are borrowed from another governmental department or agency located in Washington, D.C., and in which documents must be returned to such department or agency, an extra copy of the request letter should be prepared and forwarded to the National Office for information of the Facilities Management Division. These documents should be returned to the appropriate department or agency as soon as they have served their purpose and, in any event, not later than when the case is closed. For documents obtained from other governmental departments or agencies, Division Counsel should establish appropriate control records.


**31.1.4.5.1** **(08-11-2004)**

#### Department of Justice

1. The Department Justice is responsible for handling all federal tax litigation, except those cases filed in the United States Tax Court. Executive Order No. 6166 (June 10, 1933). The coordination of significant Tax Court cases with refund suits is discussed in CCDM 35.4.5.1.2 and CCDM 34.5.2.5, Case Coordination/Coordination of Tax Court and Refund Cases.

2. The Department of Justice should be contacted if there is congressional inquiry involving a suit that has been referred to them for handling. Usually, the Department of Justice prefers that the congressional inquiry be referred to it for preparation of a response. If the Department requests that the Office of Chief Counsel prepare the response, the response should be coordinated with the Department. Division Counsel should establish local procedures to assure that such coordination occurs.


**31.1.4.5.2** **(10-20-2010)**

#### Coordination of Indian Tax Cases

1. The United States has a unique relationship with the more than five hundred federally recognized Indian tribal governments, which is reflected in Presidential executive orders, U.S./Indian treaties, and specific tax and non-tax laws. Attorneys need to be aware of two notification requirements that will ensure that appropriate protocols are observed and that the attorney receives the specialized input and support necessary.

2. All tax cases in litigation involving "Indian natural resource trust interests" must be brought to the attention of the Solicitor, Department of the Interior. This agreement permits the Department of the Interior to intervene on behalf of the Indian taxpayer, if deemed appropriate. By separate agreement with the Chief Counsel, Internal Revenue Service, the Tax Division of the Department of Justice is designated as the "clearing house" for Indian tax cases that must be reported to the Department of the Interior.

3. The term "Indian natural resource trust interests" has been given a broad construction. It originally encompassed income from land allotted to Indians under such acts as the Indian General Allotment Act of 1667, 24 Stat. 388 (25 U.S.C. §§ 331~81). It also includes income from tribal properties created by the Indian Reorganization Act of 1934, 48 Stat. 984 (25 U.S.C. §§ 461–495) and income derived by Indians under the Alaska Native Claims Settlement Act of 1971, 85 Stat. 688 (43 U.S.C. §§1601–1624). In general, it may be stated that any case involving taxation of an Indian, in which the Indian claims exemption on account of his status as an Indian, should be reported to the Tax Division, with a copy to the attention of the Division Counsel/Associate Chief Counsel (Tax Exempt and Government Entities), CC:TEGE.

4. When an Indian tax case is brought in a refund forum, the defense letter should contain a statement to the effect that "it would appear that this case should be brought to the attention of the Solicitor, Department of the Interior, pursuant to the 1972 agreement between the Attorney General and the Secretary of the Interior." A copy of the defense letter should be forwarded to the Associate Chief Counsel (TEGE).

5. The IRS office of Indian Tribal Governments in the Commissioner, Tax Exempt and Government Entities, serves as the central point for all Service contacts with federally recognized Indian tribes. It is responsible not only for most Service compliance activities with tribes, but is also responsible for ensuring that the Service is in compliance with relevant Presidential Executive Orders that outline the relationships and protocols required in working with tribes. The Commissioner requires that all aspects of federal tax administration that impact on Indian tribal governments and their related entities be coordinated with the IRS office of Indian Tribal Governments in the office of the Commissioner, Tax Exempt and Government Entities. See the following:



   - IRM 4.86.1.1, Indian Tribal Governments, et seq

   - [http://www.irs.gov/govt/tribes](http://www.irs.gov/govt/tribes/)

   - IRM 4.86.1.1.3, Coordination Between Divisions, regarding coordination between IRS Operating Divisions

   - Exhibit 4.88.1–7, Memorandum of Understanding addressing excise taxes

   - Exhibit 4.88.1–5, Memorandum of Understanding regarding Title 31 compliance checks

   - Exhibit 4.86.1–1 for the memorandum from Director, Compliance, SB/SE requiring approval of the IRS office of Indian Tribal Governments to initiate work with Indian tribal governments.


**31.1.4.6** **(08-11-2004)**

### Reconciliation of Disputes

1. The final step in the coordination process is the resolution of disputes. No item of work may be issued or any action taken until agreement between disputing offices is reached or the matter is resolved though the process of elevation. Because anything signed by or approved in the Chief Counsel’s name should represent the position of the entire office and not merely the position of a particular individual, division, or office, reconciliation of differing views is an important means of ensuring that the views of all Chief Counsel attorneys are adequately considered and the position of the office as a whole is advanced. The reconciliation process helps identify possible errors or omissions in the proposed item of work. The reconciliation process also improves the ability of the Office of Chief Counsel to avoid inconsistent treatment of similarly situated taxpayers and to fulfill its mission to provide the correct legal interpretation of the law.

2. Points of disagreement should be identified early and resolved quickly. The office responsible for the work item, however, must give the office disagreeing with the answer or analysis a reasonable amount of time to respond, taking into account any external deadlines, such as court dates or periods of limitation.

3. Any Counsel office that receives advice or assistance must follow the advice or implement the assistance unless the receiving office requests reconsideration of the advice or assistance and the advice or assistance is changed through the reconciliation process. When there is doubt about whether on the advice is directive or suggestive, the receiving office should ask for clarification rather than proceed on a possible erroneous presumption that the advice was merely suggestive.

4. Absent extraordinary circumstances, reconsideration should begin by the receiving office requesting reconsideration and providing the reasons for its disagreement to the office that provided the advice or assistance. If that office adheres to its views after reconsideration, the receiving office must follow the advice or assistance or elevate the request for reconsideration to the next higher level.



1. A request for reconsideration of branch level advice to the field should be elevated to the branch’s Assistant Chief Counsel or Associate Chief Counsel; field Counsel should make such requests through the Area Counsel and they should be coordinated with the Division Counsel. If the dispute cannot be resolved at this level, the matter should be elevated to the Deputy Chief Counsel by the Division Counsel or Associate Chief Counsel.

2. A request for reconsideration within the National Office should be made by an Associate Chief Counsel to another Associate Chief Counsel. If the Associates are unable to reconcile their views, the matter should be elevated to the Deputy Chief Counsel.


5. Disagreements between and among Division Counsel components should be resolved at the lowest level possible. If the dispute cannot be resolved, the issue should be elevated prior to taking action. Disputes between and among Division Counsel shall be elevated to and resolved by the Deputy Chief Counsel (Operations) or, if necessary, the Chief Counsel. Disputes relating to substantive tax issues should be resolved through coordination with the appropriate Associate Chief Counsel.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part31/irm_31-001-004#addtoany "Show all")

A2A