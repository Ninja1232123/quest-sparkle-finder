---
url: "https://www.irs.gov/irm/part34/irm_34-005-002"
title: "34.5.2 Refund Litigation | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part34/irm_34-005-002#main-content)

- 34.5.2  [Refund Litigation](https://www.irs.gov/irm/part34/irm_34-005-002#idm140486854168160)
  - 34.5.2.1  [Definition and Scope](https://www.irs.gov/irm/part34/irm_34-005-002#idm140486855207200)
  - 34.5.2.2  [Pre-Litigation Activity](https://www.irs.gov/irm/part34/irm_34-005-002#idm140486854192704)
  - 34.5.2.3  [Processing of Refund Suits Prior to Receipt of a Case By Counsel Attorney](https://www.irs.gov/irm/part34/irm_34-005-002#idm140486824897440)
  - 34.5.2.4  [Role of Chief Counsel in Refund Litigation](https://www.irs.gov/irm/part34/irm_34-005-002#idm140486827274384)
    - 34.5.2.4.1  [Preparation of Defense Letter](https://www.irs.gov/irm/part34/irm_34-005-002#idm140486826698512)
    - 34.5.2.4.2  [Defenses Peculiar to Refund Litigation](https://www.irs.gov/irm/part34/irm_34-005-002#idm140486826696736)
      - 34.5.2.4.2.1  [Limitations on Claims for Refund](https://www.irs.gov/irm/part34/irm_34-005-002#idm140486826695168)
      - 34.5.2.4.2.2  [Overpayments due to new issues raised in Refund Litigation](https://www.irs.gov/irm/part34/irm_34-005-002#idm140486825014464)
      - 34.5.2.4.2.3  [Prior Petition Filed in Tax Court](https://www.irs.gov/irm/part34/irm_34-005-002#idm140486825003504)
      - 34.5.2.4.2.4  [Assignment of Claim](https://www.irs.gov/irm/part34/irm_34-005-002#idm140486824994800)
      - 34.5.2.4.2.5  [Constitutional Issues](https://www.irs.gov/irm/part34/irm_34-005-002#idm140486824992240)
      - 34.5.2.4.2.6  [Tax Shelter Penalty Refund](https://www.irs.gov/irm/part34/irm_34-005-002#idm140486824975664)
      - 34.5.2.4.2.7  [Statutes of Limitations on Assessment](https://www.irs.gov/irm/part34/irm_34-005-002#idm140486824969888)
  - 34.5.2.5  [Case Coordination/Coordination of Tax Court and Refund Cases](https://www.irs.gov/irm/part34/irm_34-005-002#idm140486824956336)
  - 34.5.2.6  [Prohibition Against Requesting Taxpayers to Waive Right to Bring Civil Actions Against the United States](https://www.irs.gov/irm/part34/irm_34-005-002#idm140486824953104)

# Part 34. Chief Counsel Directives Manual Litigation in District Court, Bankruptcy Court, Court of Federal Claims, and State Court

# Chapter 5. Suits Brought Against the United States

# Section 2. Refund Litigation

* * *

## 34.5.2 Refund Litigation

#### Manual Transmittal

April 22, 2021

#### Purpose

(1) This transmits revised CCDM 34.5.2, Refund Litigation.

#### Material Changes

(1) CCDM 34.5.2.4.2.2, Raising New but Untimely Issues in Refund Litigation to Adjust or Defeat Alleged Overpayment (formerly Setoff Defenses), is revised to clarify the distinctions among section 6402 setoffs, the equitable recoupment doctrine, and the Government’s ability to defend a refund by contesting the amount of a purported overpayment.

#### Effect on Other Documents

This section supersedes CCDM 34.5.2 dated December 21, 2012.

#### Audience

Chief Counsel

#### Effective Date

(04-22-2021)

Robert T. Wearing

Deputy Associate Chief Counsel

(Procedure & Administration)

**34.5.2.1** **(08-11-2004)**

### Definition and Scope

1. For a discussion of the refund jurisdiction of the district courts and the Court of Federal Claims, see CCDM 34.1.1, Jurisdiction of the District Courts, and CCDM 34.2.1, Jurisdiction of the Court Of Federal Claims.

2. A taxpayer may seek a refund of tax or other relief such as the following:



1. Both a refund of tax and other relief, such as an injunction against the collection of similar tax in the future

2. Damages for an alleged tort by an IRS employee (see CCDM 39.3.1, Claims, Suits, and Related Matters)

3. A request for disclosure of a document under the Freedom of Information Act


3. Under section 7422(a), a taxpayer is required to file a claim for refund before filing a suit for refund. Pursuant to Treas. Reg. § 301.6402-2(b)(1), the claim for refund must include each ground upon which a credit or refund is claimed and facts sufficient to apprise the Commissioner of the exact basis thereof. There may be grounds for a motion to dismiss if the taxpayer fails to adequately state a basis for relief in a refund claim. _United States v. Felt & Tarrant Mfg. Co._ 283 U.S. 269 (1931). The Service cannot, however, determine that a claim is defective after disallowing the claim for refund on its merits. _Ford v. United States_, 402 F.2d 791 (6th Cir. 1968).

4. There are formal and informal claims for refund. The following are examples of formal claims for refund:



   - Form 1120X, Amended U.S. Corporation Income Tax Return, or other appropriate amended return (for refund of income tax per Treas. Reg. § 301.6402-3)

   - Form 843, Claim For Refund and Request for Abatement


5. The IRS can treat a taxpayer’s claim on an improper form or a claim as an informal claim for refund. Some examples of informal claims are letters addressed to the IRS, protests, and petitions to the Tax Court. _United States v. Kales_, 314 U.S. 186 (1941).

6. The taxpayer is required to file a separate claim for each type of tax (income, gift, federal unemployment) for each taxable period. _See_ Treas. Reg. § 301.6402-2(d).


**34.5.2.2** **(12-21-2012)**

### Pre-Litigation Activity

1. When the Service selects a return for audit, it generally first assigns the case to a revenue agent in the appropriate office of an Area Director or Director of Field Operations. The revenue agent may adjust the taxpayer’s liability and propose a deficiency as defined under section 6211. The review staff of the appropriate office may have to approve the proposed deficiency and if they concur with the revenue agent, the revenue agent will send the taxpayer a 30 day letter. The taxpayer can protest the proposed deficiency in the 30 day letter or accept the proposed deficiency by signing Form 870, Waiver of Restrictions on Assessment & Collection of Deficiency in Tax & Acceptance of Overassessment, or similar form, and pay the tax. By signing this waiver, the taxpayer waives his right to receive a statutory notice of deficiency (the taxpayer’s ticket to the Tax Court). Even after signing the waiver and paying the tax, the taxpayer may still contest the deficiency by filing a claim for refund.

2. If the taxpayer files a protest in response to the 30 day letter, an Appeals Officer will meet with the taxpayer and attempt to settle the case. The Appeals Officer will consider the merits of the taxpayer’s position and may take into account the hazards of litigation.

3. If the taxpayer does not sign a waiver or does not voluntarily pay the proposed deficiency, the Service will generally send the taxpayer a statutory notice of deficiency (also known as the 90 day letter). If the taxpayer wants to contest the proposed deficiency but does not want to pay the tax, he must file a petition with the Tax Court within 90 days (150 days if the notice is addressed to a taxpayer outside the United States) after the Service mails the statutory notice. Section 6213.

4. The Service will assess the deficiency if the taxpayer signs a waiver or fails to file a petition with the Tax Court during the 90-day (or 150-day, if applicable) period. Generally, the taxpayer must pay this assessed deficiency. Pursuant to section 7422(j), however, the federal district courts and the United States Court of Federal Claims have jurisdiction to determine the correct amount of estate tax liability (for estates that have elected the installment method of payment under section 6166), even though the estate has not paid the full amount of the estate tax liability, provided that it has met current paying requirements. After paying the tax, the taxpayer can continue to contest the liability by filing a claim for refund. The taxpayer can also file a refund claim for tax that he paid with the original tax return. Generally, under section 6511, the taxpayer is required to file a claim for refund within three years from the date the original return was filed or two years from the date the tax was paid, whichever is later.

5. A revenue agent or tax auditor will review the claim for refund and inform the taxpayer, by letter, if the Service will accept the claim or disallow the claim in full or in part. A taxpayer can then request a conference with the Appeals Office if the claim is disallowed in whole or in part. If the Appeals Officer agrees with the revenue agent’s determination or if the taxpayer does not request a conference, the Service will generally issue a statutory notice of claim disallowance. Under section 6532, the taxpayer has two years from the date of the notice of claim disallowance in which to bring suit. The statute of limitations does not begin to run until the Service issues a notice of claim disallowance. If the Service does not send the taxpayer a notice of claim disallowance, the taxpayer cannot file a suit less than six months from the date he filed a claim for refund. Under section 6532(a)(3), a taxpayer may waive a notice of disallowance regarding his claim for refund. If this occurs, the two year period for filing a suit begins on the date the taxpayer files such waiver. If the taxpayer does not waive a notice of claim disallowance, and the Service has not issued such notice, then the taxpayer may file a refund suit at any time after six months from the filing of the administrative claim. Rev. Rul. 56-381, 1956-2 C.B. 953, remains valid and in effect and should be followed by Chief Counsel attorneys. The Service and the Department of Justice should be advised that the general six-year period of limitation for bringing claims against the Government in 28 U.S.C. §§ 2401 and 2501 does not apply to tax refund suits.

6. A taxpayer must file a suit for refund of taxes paid in the U.S. district court where the taxpayer resides (or where a corporation has its principal place of business), or in the Court of Federal Claims.


**34.5.2.3** **(08-11-2004)**

### Processing of Refund Suits Prior to Receipt of a Case By Counsel Attorney

1. A refund suit begins when a taxpayer files a complaint in a U.S. district court or Court of Federal Claims. In the district courts, the taxpayer must deliver a copy of the summons and complaint to the appropriate U.S. Attorney and the Attorney General by registered or certified mail. _See_ Fed. R. Civ. P. 4. In the Court of Federal Claims, after the taxpayer files his complaint, the clerk serves copies on the Attorney General. Cl. Ct. R. 4. The Government has 60 days from the service of the summons and complaint (or from the service of the complaint in the Court of Federal Claims) in which to file an answer.

2. A designated reviewer (attorney or paralegal) should read the summons and complaint to determine if the case is in the correct Field Counsel office and if Field Counsel should reassign the case to the Office of the Associate Chief Counsel (GLS).

3. If the taxpayer seeks a refund of return preparer penalties or W-4 penalties or if the cases involve erroneous refunds and issues involving collection issues such as challenged levies or liens, the Field Counsel attorney should be an SB/SE Field Counsel attorney.

4. If the case is not in the correct Field Counsel office, the attorney should immediately forward the complaint to the appropriate office.

5. If the case involves the exemption of an organization under section 501(c)(3), the complaint should be assigned to the appropriate office within the Division Counsel/Associate Chief Counsel (TEGE) that would be responsible for defense letter preparation. If the exemption letter is issued by the headquarters office of the Division Commissioner (TEGE), the appropriate office would be the headquarters office of the Division Counsel/Associate Chief Counsel (TEGE). If the exemption letter is issued by the field office of the Division Commissioner (TEGE), the appropriate office is the applicable Area Counsel office of the Division Counsel/Associate Chief Counsel (TEGE).


**34.5.2.4** **(08-11-2004)**

### Role of Chief Counsel in Refund Litigation

01. The administrative file normally contains the taxpayer’s tax returns, administrative reports, correspondence with the taxpayer, and the transcript of account. A transcript of account is a chronological record of tax assessments, abatements, payments, and refunds. The attorney should immediately examine the complaint to determine which tax returns and related documents will be needed. In particular, the attorney should ascertain the following:



    - The name and address of the taxpayer and any related entity (such as a partnership or subchapter "S" corporation) whose returns the attorney will need

    - The taxpayer’s social security or employer identification number

    - The type of tax in suit

    - The tax periods for which the returns will be required


02. Using this information, the attorney should promptly prepare a memorandum requesting the administrative files.

03. The attorney should address the memorandum to the appropriate Internal Revenue Service Campus or Director of Field Operations/Area Director office where the taxpayer filed its returns, as identified on the complaints. If an attorney cannot get this information from the complaint, the attorney should send the memorandum to the Campus or Director of Field Operations/Area Director that has jurisdiction over the city and state where the taxpayer resides or where a corporation has its principal place of business.

04. After an attorney sends a request for tax returns in a refund case, the appropriate Campus will generally freeze the taxpayer’s accounts for the subject years. Normally, once the Campus freezes the taxpayer’s account, the Service will not issue any refunds or post credits on the frozen account. If returns or documents relating to another taxpayer or taxable period are requested, the attorney should indicate that the Service should not freeze the accounts for these related taxpayers/years.

05. Attorneys should request only copies, and not originals, of the returns for related years or taxpayers. If originals are requested, the attorney should ensure that the responsible office monitors the statute of limitations on any open year.

06. If an attorney nevertheless receives original returns for related years or taxpayers, the attorney should make copies and return the originals to the Campus or the office of the Director of Field Operations or Area Director. If the attorney has to keep the originals, the attorney should write to the Area Director/ Director of Field Operations’ office no later than 40 days prior to the expiration of the assessment period and ask it to obtain consents extending the period of limitations. If the consents cannot be obtained, the Area Director/Director of Field Operations should take any steps appropriate to protect the statute of limitations for assessment, including issuing a statutory notice of deficiency.

07. An attorney can request additional files by calling the appropriate Campus in trust fund recovery penalty cases and sending a confirming memorandum of the supplemental request for files.

08. The attorney should determine whether the administrative file includes all documents needed to write the defense letter and all documents the Department of Justice (DOJ) will need to review jurisdiction in the case. The following items are normally in the file:



    - Tax Returns for all years in the refund suit

    - Claims for Refund

    - Revenue Agent’s Report (if IRS audited the years in suit)

    - Appeals Division Report

    - Taxpayer Protest

    - Form 872, Consent To Extend the Time to Assess Tax, or Form 872-A, Special Consent to Extend the Time to Assess Tax (extension agreement with no fixed expiration date). Forms 872 are generally attached to the returns for the years for which extensions were secured.

    - Statutory notice of deficiency

    - Form 870, Waiver of Restrictions on Assessment & Collection of Deficiency in Tax & Acceptance of Overassessment, or Form 870-AD, Offer to Waive Restrictions on Assessment and Collection of Tax Deficiency and to Accept Overassessment

    - Transcripts of Account

    - Notice of Claim Disallowance


09. A Revenue Agent’s Report (RAR) consists of introductory and explanatory T-pages (T-1, T-2, T-3, etc.), which are confidential and have not been sent to the taxpayer, followed by normally numbered pages (1, 2, 3, etc.), which have been sent to the taxpayer. Even if the suit is for the refund of original tax (as opposed to a deficiency), the filing of the claim for refund should have triggered an audit. Normally, the file will contain an extensive RAR for the years in suit and a very limited RAR with respect to the claims for refund. The RAR on the claims for refund may refer only to the earlier RAR.

10. Form 870 is a Waiver of Restrictions on Assessment and Collection of Deficiency in Tax and Acceptance of Overassessment, Form 870-AD is an Offer to Waive Restrictions on Assessment and Collection of Tax Deficiency and to Accept Overassessment. The IRS can assess the tax after the taxpayer signs a Form 870 or Form 870-AD.


**34.5.2.4.1** **(08-11-2004)**

#### Preparation of Defense Letter

1. The defense letter in a refund suit should be prepared, and the case should be classified, under the guidelines found in CCDM 34.5.1.1.1, Case Classification, and CCDM 34.5.1.1.2, Defense Letters.


**34.5.2.4.2** **(08-11-2004)**

#### Defenses Peculiar to Refund Litigation

1. In addition to the defenses discussed in CCDM 34.5.1.1.2.2.3, Affirmative Defenses, the following defenses are found specifically in refund litigation.


**34.5.2.4.2.1** **(08-11-2004)**

##### Limitations on Claims for Refund

1. Generally, the taxpayer must file a claim for refund within three years from the time he files his return or within two years from the time the tax was paid, whichever is later. Section 6511(a). If no tax return was filed, a claim must be filed within two years from the time the tax was paid.

2. If a taxpayer files a claim for refund during the three year period prescribed by section 6511(b)(1), the amount recoverable is limited to the amount paid during the three years immediately preceding the filing of the claim plus the period of any extension of time for filing the return. Section 6511(b)(2)(A). In administrative actions and litigation, the Service can refund a taxpayer’s withholding and estimated taxes if the taxpayer files an original delinquent return/claim for refund more than two but less than three years after the due date of the return. Under section 6513(a), prepaid taxes, such as withholding and estimated taxes, are deemed paid on the last day prescribed for filing the return.

3. When a taxpayer files a claim within the two-year period following payment, but not during the three-year period following the filing of a return, the amount recoverable is limited to the amount of tax paid during the two years immediately preceding the filing of the claim. Section 6511(b)(2)(B).

4. When the taxpayer and the Service execute an agreement to extend the period for assessment (generally by Form 872), the time for filing a claim does not expire until six months after the expiration of the extended assessment period. Section 6511(c)(1). The amount that the taxpayer may claim when the taxpayer and the Service have executed an extension is equal to the tax paid after the execution of the extension, plus any amounts that could have been claimed on the date the Service and the taxpayer executed the extension agreement. Section 6511(c)(2).

5. The following are exceptions to the general period of limitations for filing claims for refund:



1. **Worthless Bad Debt or Worthless Security**. The taxpayer can file a claim for refund within seven years from the date prescribed for filing the return. Section 6511(d)(1).

2. **Net Operating Loss or Capital Loss Carryback**. The taxpayer can file a claim for refund within three years after the due date (with regard to extensions) of the return for the year of the net operating loss or capital loss, or an extended period, whichever expires later. Section 6511(d)(2).



      ### Example:



      If an individual files a 1979 return on or before April 15, 1980, and claims a net operating loss that is carried back to 1976, the taxpayer will normally have until April 15, 1983 to file the claim for refund, even though the claim relates to 1976.

3. **Foreign Taxes Paid or Accrued**. If a claim relates to an overpayment attributable to any foreign taxes paid or accrued, the taxpayer can file a claim for refund within 10 years from the date prescribed for filing the return.

4. **Credit Carrybacks**. In the case of an overpayment attributable to a credit carryback, in lieu of the normal three-year period of limitations, the taxpayer must file a claim within three years after the due date of the return, including any extension of time to file, for the tax year of the unused credit. With respect to any portion of a credit carryback from a tax year attributable to a net operating loss carryback, capital loss carryback, or other credit carryback from a subsequent tax year, the taxpayer must file a claim within three years after the due date of the return for the subsequent year, including extensions. If the taxpayer has signed a waiver for such tax year, the applicable period of limitations is the period prescribed in the waiver or the period within which a claim for credit or refund could have been filed for that year, whichever expires later. Section 6511(d)(4)(A). These extensions only apply to the three year limitation period and do not change the two years from payment rule. The term credit carryback includes any business carryback under section 39. Section 6511(d)(4)(C).


**34.5.2.4.2.2** **(04-22-2021)**

##### Overpayments due to new issues raised in Refund Litigation

1. In most refund cases, the period of limitations on assessment will have expired before the taxpayer files suit. Therefore, if Field Counsel/DOJ develops a new issue during litigation, the Service cannot assess additional tax attributable to this new issue. If the statute of limitations has not expired and the Service wants to assess additional tax, Field Counsel should follow the procedures in CCDM 34.5.1.1.2.5, Counterclaims and Third-Party Complaint Authorization. When the Service cannot assess the additional tax, an attorney should raise the newly developed issue or issues as early as possible by including it in the Government’s answer or amended answer.

2. The Government can raise new issues as a defense in refund litigation, even if it is too late to assess tax attributable to those issues, because the taxpayer must prove that there is an overpayment to prevail. _Lewis v. Reynolds_, 284 U.S. 281 (1932). A taxpayer will not prevail if the Government successfully raises new issues to defeat the refund claim by refuting the overpayment, even if the statute of limitations for assessment of the additional tax has expired. These new issues that may be raised by the Government to reduce or eliminate a credit or refund claimed by the taxpayer, however, may not give rise to a money judgment in favor of the Government. _Patterson v. Belcher_, 302 F.2d 289 (5th Cir. 1962). The new issues must relate to the same taxable period, same taxpayer, and generally the same type of tax. If the new issue involves a different year, different kind of tax, or a related taxpayer, then the Government may not raise such new issue unless the doctrine of equitable recoupment is applicable. For a discussion of equitable recoupment, seeCCDM 34.5.1.1.2.2.1, Equitable Recoupment.

3. The Government may raise a new issue that results in an upward adjustment in the tax liability, but for which the additional tax is no longer assessable because the assessment period of limitation has expired. In these cases, the taxpayer may also raise a new issue that results in a downward adjustment to the tax liability to reduce or eliminate the Government’s upward adjustment. See _Union Pacific R.R. Co. v. United States_, 524 F.2d 1343 (Ct. Cl. 1975). The taxpayer may only raise a new issue to defeat the Government’s newly-raised issue and may not use a newly-raised issue to increase the amount of the original refund claim. A taxpayer is otherwise limited to arguing in the refund suit only the grounds provided in the original claim for refund. _United States v. Felt & Tarrant Mfg. Co._, 283 U.S. 269 (1931); _Angelus Milling Co. v. Comm._, 325 U.S. 293 (1945). The ability to raise a matter that will adjust a tax liability, for purposes of computing an overpayment after the assessment period, should not be confused with the more traditionally understood "right of setoff" of monetary claims in which a creditor’s right to payment may be reduced or offset by an amount it owes to the debtor on a different transaction. This is true whether the Government raises new upward adjustments to offset a taxpayer’s originally claimed reduction to the determined tax liability or the taxpayer raises new issues to defeat the Government’s newly-raised upwards adjustment. Instead, these issues may only be raised to help determine the existence or amount of an overpayment for purposes of section 6402.


**34.5.2.4.2.3** **(08-11-2004)**

##### Prior Petition Filed in Tax Court

1. Generally, under section 6512(a), if the taxpayer timely files a petition in Tax Court, the Service cannot issue a refund or post a credit for any income tax, gift tax, estate tax, or a tax under chapters 41-44, and the taxpayer is precluded from subsequently filing a refund suit for the same taxable period/estate. There are six exceptions to this general rule:



1. An overpayment determined by a decision of the Tax Court that has become final

2. An amount collected in excess of an amount computed in accordance with a decision of the Tax Court that has become final

3. An amount collected after the period of limitation upon the making of levy or beginning a proceeding in court for collection has expired; but in any such claim for credit or refund or in any such suit for refund the decision of the Tax Court that has become final, as to whether such period has expired before the notice of deficiency was mailed, and shall also be conclusive

4. As to overpayments attributable to partnership items

5. As to any amount collected within the period during which the IRS is prohibited from making the assessment or from collecting by levy or through a proceeding in court under section 6213(a)

6. As to overpayments the IRS is authorized to refund or credit pending appeal


2. Furthermore, even if the Tax Court proceedings are terminated prematurely (e.g., because of a failure to prosecute), the taxpayer is still precluded from filing a subsequent refund suit because this is not one of the exceptions to the general rule. _Florentino v. United States_, 226 F.2d 619 (3rd Cir. 1955). If the Tax Court never acquires jurisdiction (e.g., because the taxpayer did not timely file its petition), the taxpayer will not be precluded from filing a subsequent refund suit.

3. If the Tax Court enters a decision reflecting an overpayment, the taxpayer can file a subsequent refund suit if the IRS does not pay or credit the taxpayer such overpayment. The taxpayer, however, does not have to file a claim for refund as to the amount of overpayment in the decision. See _United States v. Rochelle_, 363 F.2d 225 (5th Cir. 1966). Under section 7422(a), the taxpayer must file a claim for refund for any amount in excess of the overpayment reflected in the decision, assuming one of the exceptions to the general rule applies.


**34.5.2.4.2.4** **(08-11-2004)**

##### Assignment of Claim

1. Generally, a taxpayer cannot assign a refund suit claim to another party. A transfer of this claim by operation of law, such as by will or complete liquidation of a corporation by a decree in bankruptcy, is valid. _Novo Trading Corp. v. Commissioner_, 113 F.2d 320 (2d Cir. 1940).


**34.5.2.4.2.5** **(08-11-2004)**

##### Constitutional Issues

01. An attorney may encounter the following Constitutional issues in refund suits.

02. **First Amendment** freedom of religion, speech, freedom of the press, right of peaceable assembly and the right to petition the Government for redress of grievances. Taxpayers have contended that various taxes, the requirement to file tax returns, and the manner in which the Service has administered the tax law have the effect of abridging their right to the free exercise of their religion or their freedom of speech.

03. **Second Amendment** right to keep and bear arms. Any tax cases involving these issues would probably come under the National Firearms Act as amended by the Gun Control Act of 1968 (section 5801 et seq. of the Code). The Bureau of Alcohol, Tobacco, Firearms and Explosives has jurisdiction over this issue.

04. **Fourth Amendment** protection against unreasonable searches and seizures. Taxpayers have successfully defeated assessments based on illegally seized evidence, and have compelled the IRS to return unlawfully seized property. Field Counsel should coordinate this issue with the Office of the Assistant Chief Counsel (Collection, Bankruptcy &Summonses), Branch 3.

05. **Warrantless Seizure of Property**. The Supreme Court has held in _G.M. Leasing Corp. v. United States_, 429 U.S. 338 (1977), that a warrant was not necessary for the seizure of property from public streets but that the taxpayer’s office was a constitutionally protected area requiring a warrant. General procedure is to obtain a writ of entry to seize property not in public view. See CCDM 34.6.2.4.1, Writs of Entry.

06. **Use of illegal evidence**. In _United States v. Janis_, 428 U.S. 433 (1976), the Supreme Court, however, held that in a federal civil tax case, unlawfully obtained evidence should not be suppressed.

07. **Right of privacy**. The Supreme Court has held that the only proper objection to the forced production of documents would be under the Fifth Amendment, and not the Fourth Amendment. _Fisher v. United States_, 425 U.S. 391 (1967).

08. **Fifth Amendment** protection from double jeopardy compelled self-incriminating testimony, and the deprivation of liberty or property without due process of law. Fifth Amendment problems, because of the nature of the amendment, usually arise in criminal cases or potential criminal cases when taxpayers frequently argue that the Service is taking their property without due process and/or that they are being compelled to testify against themselves.

09. **Seventh Amendment** guarantee of the right to a jury trial in suits at common law where the amount in controversy exceeds $20.00. Only the District Court affords the taxpayer a right to trial by jury. The Supreme Court has held that the Seventh Amendment does not apply to tax controversies with the Government. _Phillips v. Commissioner_, 283 U.S. 589 (1931).

10. Congress’s power under the **Sixteenth Amendment** to impose income taxes without apportionment among the states. Most disputes arising under the Sixteenth Amendment arise out of what is meant by the term income.


**34.5.2.4.2.6** **(08-11-2004)**

##### Tax Shelter Penalty Refund

1. Under section 6700, the Service can assess civil penalties against promoters of abusive tax shelters and under section 7408 can enjoin these promoters from engaging in any further activity. The Service can assess these penalties without going through normal deficiency procedures. Section 6703(b). Under section 6703(c), when a taxpayer pays 15 percent of the penalty within 30 days after the day on which the notice and demand is made and files a claim for refund in that amount, the Service will suspend the collection of the remainder of the penalty until there is a final resolution of the taxpayer’s suit for the determination of his liability for the penalty. The taxpayer must file suit in U.S. district court within (1) 30 days after the Service denies his or her refund claim, or (2) 30 days after the expiration of 6 months from the day the taxpayer files his or her claim, whichever is earlier.

2. An attorney working on a new section 6700 or 6701 refund case should determine if an active section 7408 injunction suit is being litigated or whether the person against whom the penalty was assessed, or related promoter or salesman, has already been enjoined from engaging in further abusive tax shelter activity.

3. If a section 7408 case is open and has not been concluded, the attorney should coordinate the subject case with the Field Counsel and DOJ attorneys who are handling the section 7408 case. If, after trial or hearing, a section 7408 injunction has been entered, the facts set forth in the court’s memorandum in support of the injunction will show how the promoter violated section 6700 or section 6701. Under certain circumstances, the Field Counsel attorney can rely on these facts to assert collateral estoppel in the refund case. The attorney should also review any consent or stipulation of the parties to determine whether the taxpayer admitted violating section 6700 or section 6701 or agreed to any other terms that would affect the proceeding in the refund suit.


**34.5.2.4.2.7** **(08-11-2004)**

##### Statutes of Limitations on Assessment

1. If the Service did not timely assess the subject tax in the suit or if the taxpayer did not timely and properly file claims for refund, and/or a refund suit complaint, an attorney may not have to consider the merits of the taxpayer’s claim.

2. **Statute Of Limitations For Any Items Other Than Partnership Items**. Generally, the Service must assess the tax within three years after the taxpayer files a return even when the taxpayer files the return after the date prescribed for filing. Section 6501(a). The following lists the principal exceptions and modifications to the general rule.



1. If the taxpayer files a return before the prescribed due date, the return will be deemed to have been filed on the last day prescribed for filing. Section 6501(b)(1).

2. The Service can assess the tax at any time if the taxpayer files a false or fraudulent return, or if the taxpayer does not file any return. Sections 6501(c)(1) and 6501(c)(3).

3. The Service must assess the tax within six years from the filing of the return if the taxpayer omits more than 25% of gross income (or more than 25% of the gross estate or from reported gifts on an estate or gift tax return). Section 6501(e).

4. Except for estate tax, the taxpayer and the Service can extend by written agreement the period of limitations for assessment. Section 6501(c)(4). The taxpayer and the Service must execute the agreement prior to the expiration of the period for assessment and can execute further extensions in writing, but the taxpayer and the Service must execute each successive extension prior to the expiration of the previous extension.

5. Assuming a taxpayer fails to petition the Tax Court, the period for assessment is suspended for 90 days after the issuance of the statutory notice of deficiency (150 days if addressed outside the United States) and for an additional 60 days. The Service can tack on to this 60 days any period of time remaining between the date the Service issues the notice of deficiency and the formal date the period for assessment would have expired. If the taxpayer files a petition in the Tax Court, the period for assessment is suspended until the Tax Court decision becomes final and for 60 days thereafter. Section 6503(a).

6. Under section 6511, generally, the statute of limitations for filing a refund claim is suspended during the period when a taxpayer is financially disabled.


3. **Statute Of Limitations For Partnership Items**. Generally, the IRS must assess the tax within three years after the partnership files its return even when the partnership files its return after the date prescribed for filing (determined without regard to extensions). Section 6229(a). The following are principal exceptions and modifications to the general rule.



1. If the partnership files a false or fraudulent return, the Service can assess the tax at any time only as to the partner who, with the intent to evade tax, signed or participated directly or indirectly in the preparation of a partnership return that includes a false or fraudulent item. Section 6229(c)(1)(A). In the case of all other partners, the Service can assess the tax within six years after the later of the date on which the partnership files its return or the last day for filing such return for such year (determined without regard to extensions). Section 6229(c)(1)(B).

2. The Service can assess the tax at any time if the partnership does not file any return. Section 6229(c)(3).

3. The Service must assess the tax within six years from the filing of the return if the partnership omits more than 25% of gross income. Section 6229(c)(2).

4. The partnership (through the tax matters partner or any other person authorized by the partnership in writing to enter in such an agreement) and the IRS can extend by written agreement the period of limitations for assessment with respect to all partners. section 6229(b)(1)(B). An individual partner and the Service can also extend by written agreement the period of limitations as to this partner only. Section 6229(b)(1)(A). The taxpayer and the Service must execute the agreement prior to the expiration of the period for assessment and can execute further extensions in writing, but the taxpayer and the Service must execute each successive extension prior to the expiration of the previous extension.

5. Once the Service issues a notice of final administrative adjustment, the period for assessment is suspended for 90 days after the issuance of the notice of deficiency (150 days if addressed outside the United States) and for an additional one year. Section 6229(d).


**34.5.2.5** **(08-11-2004)**

### Case Coordination/Coordination of Tax Court and Refund Cases

1. Attorneys should coordinate Tax Court cases and refund suits to establish a consistent litigation position in all the courts. Under some circumstances, the attorney may give DOJ a statement of the facts proposed to be stipulated, or a statement of the facts proposed to be introduced into evidence if the Tax Court case will be tried, or if the refund suit case is going to trial, the attorney can give DOJ a letter setting forth factors involved in the related Tax Court case.

2. An attorney should determine the nature of the related case and its impact upon his newly assigned case, and coordinate with the other office any action or proposed action that might affect the related case. If an attorney in the same Field Counsel office is handling the related case, informal coordination will be appropriate. The attorney should advise the attorney who has the related case of the legal position being taken and any significant developments in the refund case. If different Field Counsel offices are involved, or if an attorney is coordinating with an Associate office, the attorney should advise the attorney in the other office of the related case and provide a copy of the defense letter.


**34.5.2.6** **(04-11-2009)**

### Prohibition Against Requesting Taxpayers to Waive Right to Bring Civil Actions Against the United States

1. Section 3468 of the Internal Revenue Service Restructuring and Reform Act of 1998 (RRA) prohibits officers or employees of the United States from requesting a taxpayer to waive the right to bring a civil action against the United States or any officer or employee of the United States for any action taken in connection with the internal revenue laws, except if:



   - The taxpayer waives the right knowingly and voluntarily;

   - The request by the officer or employee is made in person and the taxpayer’s attorney or other federally authorized tax practitioner is present; or

   - The request is made in writing to the taxpayer’s attorney or other representative.


2. A Counsel attorney may not request a taxpayer to waive the right to bring a civil action unless the taxpayer is represented by an attorney or other authorized representative. If the taxpayer is represented by an attorney or other representative, and the Counsel attorney seeks a waiver, the request must be made in person and the taxpayer’s attorney or other authorized tax practitioner must be present or the request must be made in writing to the taxpayer’s attorney or other representative. If the taxpayer wishes to waive the right to bring a civil action on his or her own, the waiver must be made in a manner that shows a "knowing and voluntary" waiver of the right. In any event, Counsel attorneys should document the manner by which the waiver was obtained.

3. The prohibition on requesting a taxpayer to waive the right to file a civil action does not apply to:



   - The waiver of claims for attorney’s fees or costs;

   - The waiver of one or more claims brought in the same administrative or judicial proceeding as other claims that are being settled; or

   - The waiver of rights under the Internal Revenue Code.


4. See Exhibit 34.12.1-34, Questions and Answers Regarding Prohibition Against Requesting Taxpayers to Waive Right to Bring Civil Actions Against the United States, for questions and answers regarding the section 3468 prohibition.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part34/irm_34-005-002#addtoany "Show all")

A2A