---
url: "https://www.irs.gov/irm/part34/irm_34-005-005"
title: "34.5.5 Injunctions | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part34/irm_34-005-005#main-content)

- 34.5.5 [Injunctions](https://www.irs.gov/irm/part34/irm_34-005-005#idm140487800280144)
  - 34.5.5.1 [Nature of Proceedings](https://www.irs.gov/irm/part34/irm_34-005-005#idm140487801330992)
  - 34.5.5.2 [Rules for Seeking Injunctive Relief](https://www.irs.gov/irm/part34/irm_34-005-005#idm140487805252384)
  - 34.5.5.3 [Prohibition of Suits to Enjoin](https://www.irs.gov/irm/part34/irm_34-005-005#idm140487791194496)
  - 34.5.5.4 [Exceptions to Statutory Prohibition of Section7421](https://www.irs.gov/irm/part34/irm_34-005-005#idm140487777701872)
  - 34.5.5.5 [Termination of Taxable Period, Jeopardy Assessment and JeopardyLevy Procedures Section7429](https://www.irs.gov/irm/part34/irm_34-005-005#idm140487788670480)

    - 34.5.5.5.1 [Defense of Section7429(b) Actions](https://www.irs.gov/irm/part34/irm_34-005-005#idm140487783621152)
    - 34.5.5.5.2 [Relationships with the United States Attorney's Office](https://www.irs.gov/irm/part34/irm_34-005-005#idm140487804303728)

  - 34.5.5.6 [Freedom of Information Act Injunctions and Actions Under the PrivacyAct](https://www.irs.gov/irm/part34/irm_34-005-005#idm140487799540848)
  - 34.5.5.7 [Hybrid InjunctionRefund Suit](https://www.irs.gov/irm/part34/irm_34-005-005#idm140487789744304)
  - 34.5.5.8 [Consent by Justice Department to Temporary Restraining Order](https://www.irs.gov/irm/part34/irm_34-005-005#idm140487798373680)

# Part 34. Litigation in District Court, Bankruptcy Court, Court of Federal Claims, and State Court

# Chapter 5. Suits Brought Against the United States

# Section 5. Injunctions

* * *

## 34.5.5 Injunctions

**34.5.5.1** **(08-11-2004)**

### Nature of Proceedings

1. An injunction case is a court proceeding whereby the plaintiff seeks one of two things, either to prevent the defendant from doing in the future that which threatens to cause or is already causing harm to the plaintiff, or to compel an affirmative act by the defendant. The first is a preventative or negative injunction, the second a mandatory injunction.

2. In its various stages the injunction may take the form of a temporary restraining order (TRO), a preliminary injunction, or a permanent injunction. The restraining order is a temporary order entered in an action, if necessary, without notice to the other party, and upon a summary showing of its necessity in order to prevent immediate and irreparable injury pending a fuller hearing and determination of the rights of the parties or the court's jurisdiction upon a motion or bill for a preliminary injunction. Its purpose is to preserve the status quo until the motion for a preliminary injunction can be brought on for hearing and decision. Such order is effective for ten days only, unless extended during such period. Fed. R. Civ. P. 65(b).

3. A preliminary injunction, on the other hand, can only be issued after notice (Fed. R. Civ. P. 65(a)) and usually is not for a fixed period of time, since ordinarily its purpose is to preserve the status quo until the issues are adjudged after a final hearing. A permanent injunction is one granted by the judgment that finally disposes of the injunction suit.

4. The entry of an order granting a TRO or other injunction should always be called to the attention of the administrative office concerned, which should be advised to desist from taking action until receipt of further advice by Field Counsel.


**34.5.5.2** **(08-11-2004)**

### Rules for Seeking Injunctive Relief

1. Federal Rule of Civil Procedure 65 covers the procedures under which injunctions and temporary restraining orders are issued in federal courts. If a restraining order, or injunction, is issued, the order must set forth the reason for its issuance, in specific terms, and must describe in reasonable detail the act or acts sought to be restrained.

2. The relief sought by a taxpayer frequently does not take the express form of an injunction. If the relief sought constitutes in effect a request for an injunction, the complaint will be treated as such and will be governed by the law applicable to injunctions. Some examples are:



   - Suits to quash a levy

   - Suits to have tax assessments declared invalid

   - Suits to enjoin the Government's suit to foreclose its tax liens

   - Suits to enjoin a sale pursuant to levy made upon property

   - Suits to prevent the collection of certain penalty assessments


3. Some taxpayers attempt to thwart a levy by having a receiver appointed under state law _after_ a levy has been made by the federal government. The receiver would obtain authority to take possession of all the taxpayer's assets under an injunction issued in the receivership proceedings enjoining everyone from interfering with the receiver in taking charge of the assets. Such actions are proscribed by the statutory prohibition against injunctions contained in section 7421, and the action of any state court in issuing such an order is contrary to the provisions of 28 U.S.C. § 2463.

4. Injunction actions are instituted by nontaxpayers as well as by taxpayers having unpaid tax liabilities.


**34.5.5.3** **(08-11-2004)**

### Prohibition of Suits to Enjoin

1. A taxpayer is prohibited from seeking an injunction against the enforcement of the internal revenue laws. This prohibition is contained in section 7421, the Anti-Injunction Act.

2. Section 7421 states the general rule of equity that where a person has an adequate remedy at law, by way of suit for refund or appeal to the Tax Court of the United States, equitable relief by way of injunction against the assessment or collection of taxes may not be sought.

3. In addition, many times the prohibition against declaratory judgments with respect to tax matters provided by 28 U.S.C. § 2201 can be used to prohibit injunctive relief.


**34.5.5.4** **(08-11-2004)**

### Exceptions to Statutory Prohibition of Section 7421

1. Section 7421 provides certain exceptions to the prohibition of suits to restrain assessment or collection of a tax. These exceptions relate to provisions of sections 6015(e), 6212(a) and (c), 6213(a), 6225(b), 6246(b), 6330(e)(1), 6331(i), 6672(c), 6694(c), 7426(a) and (b)(1), 7429(b), and 7436.

2. See CCDM 34.5.5.5 concerning injunctive relief under section 7429 following jeopardy and termination assessments under the provisions of sections 6851, 6861, and 6862, or jeopardy levies under section 6331(a).

3. Section 6212(a) provides that if a deficiency in income, estate or gift taxes or public charities, private foundations or qualified pension plan taxes or Real Estate Investment Trusts is determined, the Secretary of the Treasury or delegate is authorized to send a notice of deficiency to the taxpayer by certified or registered mail. section 6212(c) provides, with certain exceptions, that if a deficiency notice is mailed as provided in section 6212(a), and if, thereafter, the taxpayer files a timely petition with the Tax Court of the United States, an additional deficiency may not be determined for the same taxable year (if income taxes are involved), or for the taxable estate of the same decedent. Accordingly, if timely appeal is taken to the Tax Court, the issuance of a second statutory notice could be enjoined.

4. Section 7421 also excepts from the general prohibition on suits to restrain the assessment or collection of taxes suits for wrongful levy under section 7426(a)(1), suits for surplus proceeds under section 7426(a)(2), and suits for substituted sales proceeds under section 7426(a)(3).

5. Other statutory exceptions to the rule that no injunction may issue to restrain assessment or collection of any tax are those recognized in sections 6015(e), 6212(c), 6213(a), 6225(b), 6246(b), 6330(e)(1), 6331(i), 6672(c), 6694(c), 7426(a)(1), 7429(b) and 7436 6213(a), 6672(b), and 6694(c).

6. The courts have recognized an additional exception to section 7421 based on well-established rules prevailing in a court of equity. Before an injunction may be issued:



1. The United States cannot establish its claim for the tax under the most liberal view of the law and the facts.

2. There must be present special and extraordinary circumstances establishing that the taxpayer does not have an adequate remedy at law by way of a suit for refund of the taxes sought to be collected.

3. Illegality without special circumstances is not sufficient.

4. Conversely, the fact that the taxpayer may suffer irreparable injury if collection is enforced is not grounds for relief if the Government can possibly establish its claim for the tax.


**34.5.5.5** **(08-11-2004)**

### Termination of Taxable Period, Jeopardy Assessment and Jeopardy Levy Procedures — Section 7429

1. In accordance with IRM 5.1.4.3, Field Counsel will prereview the recommendation to determine whether there is sufficient basis in fact to defend any lawsuit that may be brought challenging whether the termination or jeopardy assessment action was warranted and whether the amount to be assessed or demanded as a result of the proposed action is appropriate under the circumstances.

2. Section 7429(a)(1)(A) requires that the Chief Counsel or his delegate personally approve in writing a jeopardy or termination assessment or a levy made less than 30 days after notice and demand for payment is made. The Chief Counsel has delegated his authority to the Area Counsel, and this authority may be redelegated to the Associate Area Counsel.

3. The attorney assigned to review the proposed assessment or levy for the reasonableness of the tax determined should note approval or prepare a brief memorandum setting forth any additional reasons why it is believed that the amount of the proposed assessment is or is not appropriate under the circumstances. This memorandum will then be associated with the legal file to be opened with respect to the jeopardy or termination assessment action, or jeopardy levy.

4. The legal file should contain copies of the following documents:



   - Recommendation for assessment or levy

   - The agent's report

   - Prior returns

   - Any other supporting documentation, memoranda and written comments used in review


5. Policies concerning the use of jeopardy and termination assessments are contained in IRM 5.1.4.1, P-4-88, and P-4-89.


**34.5.5.5.1** **(08-11-2004)**

#### Defense of Section 7429(b) Actions

1. The Territory Manager, Technical Services will monitor the course of administrative review procedures initiated by the taxpayer and will advise Field Counsel immediately upon learning that judicial proceedings have been commenced under section 7429(b). Counsel shall also have the responsibility to monitor the case by maintaining contact with the Technical Services where there is reasonable cause to believe that litigation may ensue.

2. Upon learning that the taxpayer has commenced judicial proceedings under section 7429(b), Field Counsel will request the Chief, P & I or Technical Services to transmit the administrative file to Field Counsel within one working day. If it is determined that the case will require review by the Office of the Assistant Chief Counsel (Collection, Bankruptcy & Summonses), then Field Counsel will promptly telephone the Chief of CBS, Branch 1 and advise him/her of the case. If the case is to be referred directly to DJ, then Field Counsel should notify the appropriate Section Chief of the Tax Division by telephone.

3. Upon receiving the administrative file, a defense letter will be prepared by the Field Counsel directed to the Tax Division of DJ. This letter should include, among other things, an analysis of whether the making of the assessment or levy was reasonable under the circumstances and whether the amount assessed was appropriate. The proposed letter will be transmitted to the recipient by the quickest means possible within two working days of the receipt of the administrative file.

4. Upon receipt of a proposed defense letter by CBS, Branch 1, the attorney assigned the case will immediately review the letter and transmit the letter to the Tax Division within one working day following its receipt.


**34.5.5.5.2** **(08-11-2004)**

#### Relationships with the United States Attorney's Office

1. Since the district court must rule on the reasonableness of the assessment or levy and the appropriateness of the amount assessed within 20 days of the filing of the initial pleadings, unless the taxpayer requests an extension, the Field Counsel should make arrangements to have the U.S. Attorney's Office immediately notify the Field Counsel of the commencement of a section 7429(b) action.


**34.5.5.6** **(08-11-2004)**

### Freedom of Information Act Injunctions and Actions Under the Privacy Act

1. Injunction actions under the Freedom of Information Act (5 U.S.C. § 522) and any actions in the nature of injunctions under the Privacy Act of 1974 (5 U.S.C. § 552a) are handled by the Office of the Assistant Chief Counsel (Disclosure and Privacy Law). Pleadings of any sort received in the field office indicating action under these Acts should be immediately forwarded to that office, which handles all actions, including defense letters, in such cases.


**34.5.5.7** **(08-11-2004)**

### Hybrid Injunction—Refund Suit

1. Whenever letters are referred to the Office of the Assistant Chief Counsel (CBS) wherein the plaintiff taxpayer alleges a refund is due from the Government for taxes, and there is also a prayer that injunctive relief be granted to restrain the collection of other tax liabilities owed by the plaintiff, the appropriate branch of CBS must confer with a supervisor in the appropriate branch of APJP to decide which office will handle the case. CBS will advise the field office servicing the particular district court which division will handle the case.

2. Where time allows, the defense letter in these cases should discuss the merits of the claim as well as the issue of injunctive relief. The request for an injunction will often require immediate action before the administrative files can be assembled.


**34.5.5.8** **(08-11-2004)**

### Consent by Justice Department to Temporary Restraining Order

1. Since injunction cases are often set for hearing on very short notice, DJ, in some instances, will consent to a _status quo_ arrangement whereby the Territory Manager will agree to take no collection activity for a specified period of time in order to afford the Internal Revenue Service an opportunity to conduct an investigation and prepare a defense letter. In some instances, however, it may be necessary to consent to a Temporary Restraining Order to accomplish the same purpose. Fed. R. Civ. P. 65(b). In either case, prior authorization would be obtained from the appropriate Civil Trial Section of the Tax Division, usually after clearance with the Office of the Assistant Chief Counsel (CBS). CBS would in turn contact the appropriate field office before advising DJ in the case. The field office would contact the Territory Manager's office.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part34/irm_34-005-005#addtoany "Show all")

A2A