---
url: "https://www.irs.gov/irm/part35/irm_35-002-002"
title: "35.2.2 Answers | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-002-002#main-content)

- 35.2.2  [Answers](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973663168)
  - 35.2.2.1  [General Requirements for Answers](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973633920)
    - 35.2.2.1.1  [Adequate Answer Required](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973632144)
    - 35.2.2.1.2  [Admit Facts Known to Be True](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973782192)
    - 35.2.2.1.3  [Admission of Facts Inconsistent with Statutory Notice](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973768016)
    - 35.2.2.1.4  [Filing Amended Answers](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973766240)
  - 35.2.2.2  [Form of Answers](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973293472)
    - 35.2.2.2.1  [Format for Answers](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973291808)
    - 35.2.2.2.2  [Title of Answer](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973285936)
    - 35.2.2.2.3  [Amendment to Answer vs. Amended Answer](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973281584)
    - 35.2.2.2.4  [Introductory Paragraph](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973278768)
    - 35.2.2.2.5  [Responsive Paragraphs - Admissions and Denials](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973276048)
    - 35.2.2.2.6  [Responsive Paragraphs - Affirmative Allegations of Fact](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973259168)
    - 35.2.2.2.7  [General Denial](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973253264)
    - 35.2.2.2.8  [Affirmative Allegations](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973356144)
    - 35.2.2.2.9  [Prayer](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973348608)
  - 35.2.2.3  [Response to Petitioner’s Allegations](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973346448)
    - 35.2.2.3.1  [Address of Petitioner](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973344640)
    - 35.2.2.3.2  [Admission or Denial of Allegations Concerning Statutory Notice of Deficiency](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973341184)
    - 35.2.2.3.3  [Allegations Concerning Tax Returns](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973338384)
    - 35.2.2.3.4  [Amount in Dispute](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973331296)
    - 35.2.2.3.5  [Assignments of Error](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973327536)
    - 35.2.2.3.6  [Petitioner’s Allegations of Fact](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973322928)
    - 35.2.2.3.7  [Claim for Attorney’s Fees](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973320656)
    - 35.2.2.3.8  [Shift in Burden of Proof - Section 7491](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973315136)
    - 35.2.2.3.9  [Affirmative (New) Issues](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973301872)
  - 35.2.2.4  [Affirmative Allegations](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414975577792)
    - 35.2.2.4.1  [Manner of Alleging Affirmative Facts](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414975569968)
    - 35.2.2.4.2  [Statute of Limitations](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414975560672)
    - 35.2.2.4.3  [Collateral Estoppel and Res Judicata](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414975549808)
    - 35.2.2.4.4  [Collateral Estoppel in Fraud Cases with Prior Criminal Conviction](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414975548176)
      - 35.2.2.4.4.1  [Elements of Civil and Criminal Fraud and General Rules](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414975546144)
      - 35.2.2.4.4.2  [Pleading Collateral Estoppel](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414975518032)
      - 35.2.2.4.4.3  [Narrowing the Issues for Trial — Pleadings Based on a Section 7206(1) Conviction](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414975512864)
      - 35.2.2.4.4.4  [Motions for Summary Judgment](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414975503776)
    - 35.2.2.4.5  [Alternative Pleading Shifting Items or Bases of Determination](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414975497456)
    - 35.2.2.4.6  [Pleading Negligence or Delinquency as Alternative to Fraud](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414975492272)
    - 35.2.2.4.7  [Pleading Delinquency as a New Issue](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414975488784)
    - 35.2.2.4.8  [Increased Deficiencies](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414975486400)
    - 35.2.2.4.9  [Allegations of Further Defense](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414975482928)
    - 35.2.2.4.10  [Joint Returns](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414975479056)
    - 35.2.2.4.11  [Sanctions under Section 6673](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414975475984)
  - 35.2.2.5  [Answers in Cases with Criminal Aspects](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414975471680)
  - 35.2.2.6  [Answers in Fraud Cases](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414975466704)
    - 35.2.2.6.1  [Limit Allegations to Fraudulent Items and Amounts](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414975462352)
    - 35.2.2.6.2  [Elements of Fraud](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414975457920)
    - 35.2.2.6.3  [Specific Items Method](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414975012720)
    - 35.2.2.6.4  [Bank Deposit Method](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414975005696)
    - 35.2.2.6.5  [Net Worth Method](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414974999328)
    - 35.2.2.6.6  [Establish Taxable Source or Negate Nontaxable Sources](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414974988624)
  - 35.2.2.7  [Answers in Transferee and Fiduciary Liability Cases](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414974986464)
    - 35.2.2.7.1  [In General](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414974984736)
    - 35.2.2.7.2  [Limited and Unlimited Liability](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414974976560)
    - 35.2.2.7.3  [Interest in Transferee Cases](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414974968624)
    - 35.2.2.7.4  [General Transferee Pleading Requirements](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414974963904)
    - 35.2.2.7.5  [Merged Corporations](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414974952816)
    - 35.2.2.7.6  [Fiduciary Liability](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414974949536)
  - 35.2.2.8  [Answers in Accumulated Earnings Tax Cases](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414974944736)
    - 35.2.2.8.1  [Burden of Proof in Tax Court Cases](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414974943008)
    - 35.2.2.8.2  [Tax Court Pleadings](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414974929248)
  - 35.2.2.9  [Answers in Declaratory Judgment Cases and Worker Classification Cases Under Section 7436](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414974926672)
    - 35.2.2.9.1  [Answers in EP Declaratory Judgment Cases](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414974908048)
    - 35.2.2.9.2  [Answers in Exempt Organization Declaratory Judgment Cases](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414974888448)
    - 35.2.2.9.3  [Answer in Government Obligation Declaratory Judgment Cases](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973135344)
    - 35.2.2.9.4  [Answers in Worker Classification Cases under Section 7436](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973117504)
  - 35.2.2.10  [Answers in Gift Valuation Cases](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973115568)
  - 35.2.2.11  [Answers in Failure to Pay (Section 6651(a)(2) Cases With a Return Made under Section 6020(b))](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973107840)
  - 35.2.2.12  [Answers in Cases Where Petitioners Seek Relief from Joint and Several Liability](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973077360)
    - 35.2.2.12.1  [Petition for Review](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973075664)
    - 35.2.2.12.2  [Notification of Nonpetitioning Spouse](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973071584)
  - 35.2.2.13  [Answers in Collection Due Process (CDP) Cases under Sections 6320 and 6330](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973051616)
  - 35.2.2.14  [Answers in Passport Cases](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973047328)
  - 35.2.2.15  [Answers in Interest Abatement Cases](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973042016)
  - 35.2.2.16  [Motions](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973039952)
  - 35.2.2.17  [Designation of Place of Trial](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973037392)
    - 35.2.2.17.1  [Where Designated](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973033568)
    - 35.2.2.17.2  [Transfer of Cases](https://www.irs.gov/irm/part35/irm_35-002-002#idm140414973023872)

# Part 35. Chief Counsel Directives Manual Tax Court Litigation

# Chapter 2. Petition and Answer

# Section 2. Answers

* * *

## 35.2.2 Answers

#### Manual Transmittal

August 02, 2022

#### Purpose

(1) This transmits revised CCDM 35.2.2 Petition and Answer; Answers.

#### Background

Guidance is provided on the electronic filing and service of the Notice of Filing of Petition and Right to Intervene in spousal relief cases brought under I.R.C. § 6015.

Section 32101 of the FAST Act (Fixing America’s Surface Transportation Act) added section 7345 to the Internal Revenue Code in 2015, which provides for the revocation or denial of passports in the case of certain tax delinquencies as well as judicial review of passport certification determinations. Guidance is provided on the requirement to file an answer in passport cases.

Section 6404(h) provides for the judicial review of a determination not to abate interest. Guidance is provided on the requirement to file an answer in interest abatement cases.

#### Material Changes

(1) CCDM 35.2.2.12.2 is revised to describe electronic filing an service of the Notice of Filing of Petition and Right to Intervene in spousal relief cases.

(2) New CCDM section 35.2.2.14 is added to provide guidance on filing answers in passport cases.

(3) New CCDM 35.2.2.15 is added to provide guidance on filing answers in interest abatement cases.

(4) Existing CCDM section 35.2.2.14 and 35.2.2.15 are renumbered accordingly.

#### Effect on Other Documents

CCDM 35.2.2, dated August 13, 2021, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(08-02-2022)

Richard G. Goldman

Deputy Associate Chief Counsel

(Procedure & Administration)

**35.2.2.1** **(08-11-2004)**

### General Requirements for Answers

1. The following subsections address requirements that are applicable to all answers. As a general rule, answers should be mailed to the Tax Court no later than five working days before the due date to ensure timely filing.


**35.2.2.1.1** **(08-12-2010)**

#### Adequate Answer Required

01. An adequate answer must be filed in all cases. An adequate answer includes appropriate admissions, qualifications, and denials of each material fact alleged in the petition; presents all defenses available to the respondent; requests any affirmative relief to which the respondent is entitled; and alleges facts in sufficient detail to support any issue upon which the respondent has the burden of proof. An adequate answer may be one in which detailed facts are alleged, or one in which the minimum required facts are alleged, depending upon the facts and circumstances of each case. In determining the amount of detail to be alleged, consideration must be given to the result to be accomplished by such allegations and particularly whether the answer with minimum allegations can be defended as adequate under the court's rules if petitioner files a motion with respect thereto. These are general guidelines on the overall policy of the Office of Chief Counsel with respect to answers. Particular points and problems to consider in answering a case are discussed in subsequent sections.

02. In those cases in which the statutory notice refers to other documents, such as the 30−day letter, or the explanation and basis for the adjustment is not adequately set forth in the statement accompanying the notice, the answer should allege the nature and basis for the adjustments in controversy. Affirmative allegations as to the basis of the adjustments are necessary to inform the court and the petitioner of the adjustments in controversy and the position of the respondent thereon.

03. In answering petitions, Counsel personnel generally must rely on the information contained in the administrative file. In certain cases, however, an answer can be filed without the administrative file if there is sufficient information to answer the case ( _e.g._, information is secured from the notice or from the petitioner). When an answer is filed in such a case, the file should document the steps taken to secure the administrative file and the source of the information.

04. Further, a case may be answered without the administrative file if the attorney and manager have determined that affirmative allegations in the answer are not required or a review of the petition and other information in Counsel’s possession indicate that there are no issues raised in the petition that requires a review of the administrative file in order to properly answer the case. The answer should be amended once the administrative file is received if necessary or appropriate under the circumstances. When it is determined that review of the administrative file is necessary in order to properly answer the case, a Motion to Extend the Time In Which to Answer should be filed. _See_ _CCDM 35.2.2.2.8(3)-(5)_.

05. T.C. Rule 33(b) imposes upon counsel (as well as pro se petitioners) the duty to make reasonable inquiry as to both the facts and the law prior to the filing of any pleading. The signature of counsel constitutes a certification that counsel has read the pleading and, that after reasonable inquiry, has determined that it is well grounded in fact and is warranted by existing law or a good faith argument for the extension, modification or reversal of existing law. If the court determines that a pleading has been filed in violation of this rule, sanctions may be imposed. See CCDM 35.10.2.2, Miscellaneous Sanctions and Costs Provisions.

06. Fed. R. Civ. P. 11, upon which T.C. Rule 33(b) is based, expands the inherent powers of United States District Courts to award expenses, including reasonable attorney’s fees, to a litigant whose opponent acts in bad faith in instituting and conducting litigation. This rule stresses the need for some prefiling inquiry into both the facts and law to satisfy the affirmative duty imposed by the rule. The objective standard is reasonableness under the circumstances, which is a more stringent standard than one of good faith. Fed. R. Civ. P. 11, Advisory Committee’s Note.

07. It is clear that T.C. Rule 33(b) imposes an affirmative duty upon counsel to investigate the facts of the case and the relevant law prior to filing an answer or other pleading. A good faith belief that the case is well grounded in fact and law is not sufficient. Reasonable inquiry is a more stringent standard than good faith. What constitutes a reasonable inquiry may depend on such factors as:



    - How much time for investigation was available to the signer of the answer or motion

    - Whether the signer had to rely on a client for information as to the facts underlying the pleading, motion, or other paper

    - Whether the pleading, motion, or other paper was based on a plausible view of the law

    - Whether the signer depended on forwarding counsel or another member of the bar


08. As stated above, one of the factors the court will consider in determining whether the reasonable inquiry standard has been met is whether the attorney had to rely upon a client for information. The reasonable inquiry standard should be met in the first instance by the periodic attempts to obtain the administrative file. These periodic attempts to obtain the administrative file are necessary even in those offices where automatic or continuing requests for an administrative file are in place.

09. Tax Court Rule 173(b) as amended now requires answers to be filed in all "S" cases. The amendment is effective for all petitions filed after March 13, 2007. This change will assist petitioners and low−income taxpayer clinics in contacting the attorney assigned to the case and result in the earlier consideration of small tax cases. The principles and procedures described elsewhere in this section are equally applicable to the answers filed in small tax cases. Pursuant to Rule 173(c), no reply to an answer shall be filed unless otherwise directed by the court and any affirmative allegations contained therein shall be deemed denied. Should it be determined that a reply is necessary, a Motion to Require Petitioner to File Reply should be filed. The case is considered at issue upon the filing of the answer pursuant to Rule 38 unless a reply is directed to be filed by the court.

10. Upon receipt, each new small tax case petition should be reviewed to determine whether the small tax case election is allowable or otherwise appropriate, such as cases with potential precedential value or those presenting novel issues resulting from changes in the tax law. This consideration should also continue during the preparation of the case for trial or other disposition, to reduce the instances of dilatory procedural and jurisdictional motions that are sometimes filed in these cases.


**35.2.2.1.2** **(08-11-2004)**

#### Admit Facts Known to Be True

1. T. C. Rule 36 requires the specific admission or denial of each material allegation in the petition. Therefore, the attorney, in the preparation of the answer, must ascertain what facts alleged in the petition are known by the respondent to be true. The attorney usually determines this from a complete examination of the administrative file. The attorney is normally not required to conduct further investigation to determine the accuracy of alleged facts prior to answering the petition. If an alleged fact would be stipulated on the basis of the investigative reports and other information contained in the respondent’s file, it should be admitted in the answer. The court’s rules do not require the admission of immaterial facts, facts colored by the petitioner’s pleading, allegations representing half-truths, arguments, or conclusions, but care should be exercised in denying facts not in dispute merely because of the manner in which they are alleged. For allegations of fact in the foregoing categories it may be advisable to deny the fact as alleged but follow it with a correct allegation of the fact.

2. Responses to factual allegations of the petition need not be restricted to simple admissions or denials. This is especially true in substance versus form situations, where a fact, while literally true, may be misleading. Qualified admissions or denials will permit the admission of those facts literally true while making clear at the same time respondent’s position as to substance. Such pleading also avoids the risk that an unduly restrictive attitude of the court toward the amendment of the answer or the admission of evidence may prevent respondent from making his full position clear on the record.



> _EXAMPLE 1_:
>
> **Allegation of Petition**: § 5(e). On July 1, 2001, a certificate of dissolution of the petitioner was filed with the Secretary of State of the State of \_\_\_, and on July 5, 2001, the petitioner was duly liquidated.





> **Responsive Answer**: § 5(e). Admits that on or about July 1, 2001, a document purporting to be a certificate of dissolution was filed with the Secretary of the State of \_\_\_, and that on or about July 5, 2001, the petitioner purported to be liquidated. Denies that the said document constituted in truth and substance a certificate of dissolution, or was filed with the intention or purpose that petitioner would be dissolved and/or liquidated. Further denies that the said transaction or occurrence which took place on or about July 5, 2001, constituted a liquidation of petitioner in substance. Denies all remaining allegations of paragraph 5(e) of the Petition.





> _EXAMPLE 2_:
>
> **Allegation of Petition**: § 5(d)(1). On June 20, 2002, the petitioner and ABC, Inc., entered into an Agreement of Sale of the business and assets of petitioner. A true and correct copy of said Agreement of Sale is attached to the petition and marked as Exhibit B.





> **Responsive Answer**: § 5(d)(1). Admits that Exhibit B attached to the petition is a true and correct copy of a document which bears the title Agreement of Sale. Denies that said title is consistent with the true nature and substance of the transaction as actually contemplated and carried out by the parties. Denies for lack of sufficient information the date upon which the said document was signed or executed, the genuineness of the signatures, or the true identity of the signers.


**35.2.2.1.3** **(08-11-2004)**

#### Admission of Facts Inconsistent with Statutory Notice

1. Facts which are known to be true should be admitted in the answer even though this would require the concession, in whole or in part, of an issue.


**35.2.2.1.4** **(08-11-2004)**

#### Filing Amended Answers

1. Pleadings should be completed as soon as possible. Every effort should be made in the preparation of the original answer to include all allegations which are necessary for the trial and disposition of the case. If facts become known which necessitate the filing of an amended answer, it should be done as soon as possible, and in any event in sufficient time to avoid a continuance of the trial. Amended answers raising affirmative issues, and particularly claims for increased deficiencies, should not be filed on the mere hope that evidence can be obtained to sustain the affirmative issues. _See_ _CCDM 35.2.2.4.9_.

2. To the extent that respondent raises an issue which was not included in the original notice of deficiency or in the pleadings, and which either increases the amount of the original deficiency, requires the presentation of different evidence, or is inconsistent with the original deficiency notice, the court may consider the issue a new matter. The burden of proof with respect to new matters is placed on respondent in accordance with T.C. Rule 142(a). Before the respondent may obtain leave of the court to present a new matter, however, respondent may be required to satisfy the court that petitioner was given fair warning of the issue. Fair warning means that respondent’s failure to notify petitioner in the notice of deficiency or in the pleadings of the intention to rely on a particular theory did not prejudice petitioner’s ability to prepare for the case. Of key importance in evaluating the existence of prejudice is the degree of surprise and the need of the party opposed to the new position to obtain additional evidence. _Pagel, Inc. v. Commissioner_, 91 T.C. 200, 211–212 (1988). Once respondent realizes that a new matter must be raised, it is critical that the new matter be asserted as soon as possible. The closer in time to the scheduled trial date, the less likely the court is to allow the filing of an amended answer. While the petitioner should have to show that he or she has been prejudiced, the court, when faced with a motion for leave to file an amended answer close to the trial date, may simply make a conclusory finding that the petitioner has been prejudiced, although the court’s failure to articulate the basis of such a finding may constitute appealable error.

3. T.C. Rule 41(b)(1) generally provides that when issues not raised by the pleadings are tried by express or implied consent of the parties they shall be treated in all respects as though raised in the pleadings, and that failure to amend will not affect the result. T.C. Rule 41(b)(1) is silent as to whether petitioner’s failure to object to respondent’s evidence constitutes consent to the trial of the new issue. Accordingly, an amended answer should be filed to clearly state any new issue not previously raised. Respondent’s failure to object to petitioner’s submission of evidence might be deemed to constitute consent to the trial of a new issue. Respondent should make timely objections on the record to such evidence when appropriate, or move to restrict its use to the issues framed by the pleadings. If the court permits petitioner to amend, respondent should, if necessary, immediately request that the record be kept open to afford respondent adequate opportunity to investigate fully and to amend respondent’s pleadings to the extent necessary.


**35.2.2.2** **(08-11-2004)**

### Form of Answers

1. This subsection addresses the format and basic structure of answers.


**35.2.2.2.1** **(08-13-2021)**

#### Format for Answers

1. The form of an answer will follow the general form of all Tax Court documents, the rules prescribed in Tax Court Rule 23, _Form and Style of Papers_, and the requirements of the CCDM with respect to form, appearance, size, and style of Tax Court documents. The parts are the caption, the title, the body, the closing paragraph or prayer, the signature, and of Counsel. An answer, however, does not contain any endorsement of petitioner, or petitioner’s counsel. An endorsement of No Objection to respondent’s filing an amended answer is always made on the motion for leave to file the amended answer and not on the amended answer itself.

2. The body of an answer includes the introductory paragraph, the responsive paragraphs to petitioner’s pleading, a general denial, and affirmative allegations (when applicable). After the introductory paragraph, the responsive paragraphs in the body of the answer shall be numbered to correspond with those of the petition to which they relate. _See_ T.C. Rule 36. Thus, if the petition uses Arabic numbers, such numbers will be used in the answer; if the petition uses Roman numerals in numbering the paragraphs, Roman numerals will be used in the answer. The type of numbering used in the responsive paragraphs will be carried through and used in sequence with respect to the general denial paragraph and the affirmative allegations. Unnumbered pleading paragraphs in the petition shall be specifically identified and an appropriate response made thereto. Unnumbered paragraphs should not be considered as part of a preceding or subsequent numbered paragraph. The prayer, however, is not an unnumbered paragraph.


**35.2.2.2.2** **(08-11-2004)**

#### Title of Answer

1. The answer shall contain a heading or title indicating the type of answer being filed. Usually, the first answer filed in the case is titled Answer. Other headings which should be used, when appropriate, are: Answer to Petition, as Amended; Answer to Amended Petition; Amended Answer; Amendment to Answer; or Second Amended Answer; etc., or a combination of these types of answers, such as Amended Answer to Petition, as Amended.

2. If the petition is amended by the filing of an "amendment to the petition" prior to the filing of the original answer, the title of the document would be Answer to Petition, as Amended. The due date of this pleading is computed from the date the amendment to the petition is served. This title would be applicable unless a complete "amended petition" was filed. In such case the heading would be Answer to Amended Petition. Care must be exercised to title the document to specifically identify the particular petition, original or as amended, which is being answered. The Tax Court’s web site ( [www.ustaxcourt.gov](http://www.ustaxcourt.gov/)) may be consulted to determine how the court has designated a particular pleading.


**35.2.2.2.3** **(08-11-2004)**

#### Amendment to Answer vs. Amended Answer

1. If, in fraud, transferee, or other cases in which the answer contains affirmative allegations, it is necessary to amend the answer, consideration should be given to whether an entire amended answer, or just an amendment to the answer, should be filed. If an amended answer is filed, the petitioner’s admissions or denials in the reply to the affirmative allegations in the original answer may be nullified. Thus, if similar allegations are used in an amended answer to those in the original answer, but the petitioner’s reply to such allegations in the amended answer is different than his reply to such allegations in the original answer, doubt will exist as to the facts established by the pleadings. Accordingly, judgment should be used in determining the type of amendment to be filed.


**35.2.2.2.4** **(08-11-2004)**

#### Introductory Paragraph

1. The introductory paragraph of an answer should be in the following form: "THE RESPONDENT, in answer to the petition filed in this case, admits and denies as follows:"

2. The introductory paragraph should be revised in accord with the type of answer being filed. Thus, it may be necessary to substitute for the words "in answer" in this paragraph the words for "amended answer," or for "amendment to the answer," etc. Also, for the word "petition" substitute the words "amended petition," or "amendment to the petition," etc., as applicable. Whenever there are affirmative allegations in the answer, the words "admits and denies" will be changed to read "admits, denies and alleges."


**35.2.2.2.5** **(09-24-2012)**

#### Responsive Paragraphs - Admissions and Denials

1. The responsive paragraphs of an answer contain the specific admissions and denials of each assignment of error and each material allegation of fact in the petition. The answer shall be drafted so that it will advise the petitioner and the court of the nature of the respondent’s defense and the facts on which it is founded. _See_ T.C. Rule 36(b). Material allegations in the petition not expressly admitted or denied in the answer shall be deemed admitted. _See_ T.C. Rule 36(c). Therefore, the attorney must be sure to respond to each assignment of error and each material allegation of fact in the petition. The admissions and denials must be drafted so that there is no ambiguity as to the scope of each admission or denial.

2. In instances in which the entire paragraph or subparagraph in the petition is to be admitted or denied, the responsive paragraph may be in the following language: "5(a). Admits (or denies)" as appropriate. See Exhibit 35.11.1-9, Answer — Petitioner’s Burden of Proof: Complete Admissions and Denials.

3. Exceptional care should be exercised by both the attorney and the reviewer with respect to partial admissions or partial denials. If the Service has no knowledge or information sufficient to form a belief as to the truth of an allegation, the answer must so state and the statement will have the effect of a denial. If the Service intends to qualify or to deny only a part of an allegation, he shall specify what is true and deny the remainder. _See_ T.C. Rule 36(b). Any partial admission with denial of the remainder operates in itself as a qualification of the pleading.

4. Whenever it would appear to raise an ambiguity by making a partial admission or partial denial, it may be appropriate to allege lack of information or knowledge sufficient to form a belief as to the truth of an allegation in the petition. This choice of pleading may also be appropriate when the administrative file has not been received in sufficient time to prepare a fully responsive pleading. If the latter situation occurs, the answer should be amended, or a motion for leave to file an amendment or amended answer should be sent the court as expeditiously as possible upon receipt of the administrative file.

5. It is not necessary to be totally formal and legalistic when pleading partial admissions or denials. See Exhibit 35.11.1-10, Answer — Petitioner’s Burden of Proof: Qualified Admissions and Denials. If partial admissions and partial denials are used, the following samples are acceptable assuming specific admissions or denials correspond to the paragraph numbering in the petition:



1. Denies, except admits that (stating the specific portion of the paragraph (or subparagraph) which is to be admitted)

2. Admits, except denies that (stating the specific portion of the paragraph (or subparagraph) which is to be denied)

3. Denies, except admits the second and third sentences

4. Admits, except denies the first, fifth, and sixth sentences

5. Denies for lack of sufficient information


6. If the petition contains both numbered and unnumbered paragraphs, the following samples are acceptable (see Exhibit 35.11.1-11, Answer — Petitioner’s Burden of Proof: Unnumbered and/or Unlettered Paragraphs):



1. First unnumbered paragraph following paragraph 5. Admits

2. Second unnumbered paragraph following paragraph 5. Admits, except denies the first sentence

3. Third unnumbered paragraph following paragraph 5. Admits, except denies that (stating the specific portion of the paragraph which is to be denied)

4. Fourth unnumbered paragraph following paragraph 5. Denies, except admits that (stating the specific portion of the paragraph which is to be admitted)

5. First unnumbered paragraph following paragraph 5. Denies for lack of sufficient information


7. The attorney or person signing the pleading should be aware of the responsibilities imposed by T.C. Rule 33(b). _See_ _CCDM 35.2.2.1.1_.


**35.2.2.2.6** **(09-24-2012)**

#### Responsive Paragraphs - Affirmative Allegations of Fact

1. Normally, affirmative allegations by the respondent in the nature of a defense to the petitioner’s allegations, or with respect to affirmative relief, or to sustain any issue with respect to which the respondent has the burden of proof, are made in the affirmative "further answering" portion of the answer after a response has been made to the allegations in the petition. There are instances, however, in which affirmative allegations are so closely tied to the allegations in the petition that it is appropriate to allege affirmative facts in the same paragraph in which a response is made to the petitioner’s allegations. This course of pleading is particularly applicable with respect to petitioner’s allegations as to party petitioners, tax, years, and amounts in controversy, filing of the return or returns involved or the lack of filing thereof, jurisdictional facts establishing the jurisdiction of the Tax Court, etc. For example, if the allegation in the petition sets forth the incorrect date of the issuance of the statutory notice or the incorrect amount or kind of tax or year involved in the case and these allegations are denied in the responsive paragraph of the answer, affirmative allegations should follow such denials setting forth the correct facts. This may be illustrated as follows:



1. Denies; alleges that the deficiencies determined by the Commissioner are in income tax for the taxable year 2000 in the amount of $50,000.00.

2. Admits; except denies that the return for the period here involved was filed with the Director, Memphis Service Center; alleges that the income tax return for the taxable year 2000, which is involved in this case, was filed with the Director, Andover Service Center. See Exhibit 35.11.1-10, Answer — Petitioner’s Burden of Proof: Qualified Admissions and Denials.


**35.2.2.2.7** **(08-11-2004)**

#### General Denial

1. Every answer must contain a general denial paragraph bearing the next number following the last numbered responsive paragraph of the petition. This general denial paragraph is an additional precaution to assure that each allegation contained in the petition is either admitted or denied, and to prevent any allegation in the petition from being deemed admitted under T.C. Rule 36(c). The usual form of the general denial paragraph is as follows: Denies generally each and every allegation of the petition (or amended petition, or petition, as amended, etc.) not herein before specifically admitted, qualified or denied.


**35.2.2.2.8** **(08-12-2010)**

#### Affirmative Allegations

1. The answer must contain affirmative allegations of any facts upon which the respondent relies for defense or for affirmative relief or to sustain any issue with respect to which the burden of proof is on the respondent. These allegations should follow immediately after the general denial paragraph and be numbered consecutively beginning with the number following that given to the general denial paragraph. The first paragraph of each statement of facts with respect to which respondent is required to plead affirmatively should be a short introductory paragraph to inform the court and the petitioner of the nature of the respondent’s defense or the form of relief requested or with respect to the issue of fraud or transferee liability, etc., which should be covered in the allegations to follow. Each further defense and the allegations with respect to each issue upon which the respondent has the burden of proof will be separately and consecutively numbered with the detailed allegations of supporting facts. See Exhibits 35.11.1-12 through 35.11.1-16.

2. It is generally advisable to avoid getting into the second and third alphabet in the lettering of subparagraphs of affirmative allegations. This may be avoided in a number of different ways. For example, if there are a number of years involved with respect to which allegations are made in support of the fraud penalty, the first of the lettered subparagraphs may allege facts which are applicable to all or most of the years involved, followed by lettered paragraphs containing separate allegations which pertain to the years individually.

3. If a case requires affirmative allegations by respondent or a review of the petition and other information indicates that a review of the administrative file is necessary to properly answer the case and the administrative file cannot be secured in time to answer, a Motion to Extend the Time In Which to Answer should be filed. The motion should explain the circumstances as to why the motion is necessary, ask for ample time to a date certain in which to file an answer, and should contain a statement pursuant to T.C. Rule 50(a) as to whether petitioners object to the granting of the motion.

4. Attempts to plead affirmative allegations and making uninformed responses without the benefit of the administrative file may result in sanctions under T.C. Rule 33(b), and may also raise pleading and proof problems. Affirmative allegations, for example, that are made without the benefit of the administrative file tend to be very general in nature and invite petitioners’ motion for judgment on the pleadings. These motions for judgment on the pleadings may be scheduled for hearing fairly quickly. The administrative file will be needed to respond to the motion.

5. In instances in which affirmative allegations are called for but the administrative file cannot be located after a reasonable number of requests, the attorney should inform the appropriate management officials in order to determine how next to proceed.


**35.2.2.2.9** **(08-11-2004)**

#### Prayer

1. Each answer concludes with a prayer for relief. The standard form of the prayer is to be used in all cases in which there are no issues on which the respondent has the burden of proof. If the case contains issues as to which the respondent has the burden of proof (including increased deficiencies) or as to which respondent has taken alternative positions, the prayer should contain a request as to each such item. The answers in the exhibits set forth the types of prayers to be used in various circumstances.


**35.2.2.3** **(08-11-2004)**

### Response to Petitioner’s Allegations

1. This subsection discusses the response to the petitioner’s allegations.


**35.2.2.3.1** **(08-11-2004)**

#### Address of Petitioner

1. In considering whether to admit or deny an allegation as to petitioner’s principal place of residence, the requirement that the statutory notice of deficiency must be mailed to the petitioner’s last known address should be considered and care must be taken to avoid an unintended admission on the allegation that might be incorrect and prejudicial. For venue purposes on appeal, petitioner’s legal residence as of the date the petition was filed with the Tax Court should be established in the case of a petitioner other than a corporation. In the case of a corporate petitioner, the location of its principal place of business or principal office or agency as of the date the petition was filed with the Tax Court should be established. Any allegation that venue on appeal would lie in a particular circuit should be denied as a conclusion of law.


**35.2.2.3.2** **(08-11-2004)**

#### Admission or Denial of Allegations Concerning Statutory Notice of Deficiency

1. It is important that the pleadings establish whether the copy of the statutory notice of deficiency which is attached to the petition is correct. If the statutory notice attached to the petition is correct in all respects except with respect to the date issued or other minor error that does not affect the court’s jurisdiction, such error may be corrected by a partial denial and an affirmative allegation in response to the petitioner’s allegation. If the petition alleges the attachment of the statutory notice and an incomplete copy of that document (usually only the face page) is attached, the answer should deny the allegation and allege affirmatively that a complete copy of the statutory notice is attached as an exhibit to the answer.


**35.2.2.3.3** **(08-11-2004)**

#### Allegations Concerning Tax Returns

1. If the petitioner is a corporation that has no principal place of business or principal office or agency in any judicial district, the Area Director’s office where its tax return was filed determines venue on appeal. In such cases, the pleading should establish in which Area Director’s office or service center campus the return was filed. Reference is always made to the principal office of the Area Director and not a suboffice within the area even though the return may have been handled or mailed to a suboffice.

2. Before either admitting or alleging the filing of a return for the tax and period involved, the attorney should examine such return and determine whether it fulfills the statutory requirements of a return. A document on the appropriate return form which does not fulfill the statutory requirements, such as the statutory requirement for execution, is not a return, and any allegation in the petition that a return was filed should be denied. The filing of a statutory return is essential, not only to establish venue in certain instances, but also to determine whether any statutory deficiency exists, any overpayment of tax is barred by the statute of limitations, as well as whether the statute of limitations has started to run on the assessment and collection of the deficiency or liability. For statute of limitations purposes it is also essential that the filing date of a statutory return be established.

3. The attorney should also examine each return involved to determine that it was timely filed. _See_ IRC §§ 6501(b) and 6513(a) for the presumptive date of the filing of returns. Ordinarily, calendar year income tax returns are not stamped with the received date if such returns are timely filed but are stamped if filed after the due date. To admit the filing date of the return or returns involved, as alleged by petitioner, the allegation as to such date must always be either the actual date of filing, if the return in fact bears the receipt date, or the presumptive date of filing, as applicable. If the petitioner’s allegation as to the date of filing is incorrect, such allegation must be denied and the correct date of filing alleged.

4. Since the date of filing a return is an essential element with respect to an issue raised by the petitioner on the timeliness of the issuance of the statutory notice, care must be exercised in the admission of this fact. The rule is that the filing date alleged in the petition, if correct, should be admitted, except for compelling reasons under the particular facts of the case.


**35.2.2.3.4** **(08-11-2004)**

#### Amount in Dispute

1. Care should be taken in admitting the amount of taxes in controversy. The amount alleged in the petition should not be admitted unless it is clearly correct. As a general rule, the amount of taxes in dispute as alleged in the petition should be the amount of taxes of the kind and for the years determined in the statutory notice (and which are placed in controversy in the petition) plus any increased deficiency or liability claimed in the answer. If not all of the adjustments in the statutory notice are placed in controversy in the petition, it is advisable in the answer to show the court the amount of the deficiency and penalty as determined in the statutory notice, and the fact that not all of said deficiency and penalty are in dispute. This is necessary since the court’s decision must determine the full deficiency, or full liability in transferee cases, even though part of such deficiency is not contested. If the petitioner claims an overpayment of tax, an admission should be made that such claimed overpayment is in dispute, but the correctness of the amount claimed should be denied. The reason for this is that it is difficult to determine without a recomputation whether the amount claimed as an overpayment by the petitioner is correct even if the issue will be decided in petitioner’s favor.


**35.2.2.3.5** **(08-11-2004)**

#### Assignments of Error

1. The assignments of error in the petition should be compared with the adjustments shown in the statutory notice. If all of the adjustments are not covered by assignments, this is an indication that part of the tax asserted in the notice is admitted to be due. In this instance, the decision will need to be filed under T.C. Rule 155 if any of the assignments of error are decided favorably to the petitioner since some tax would still be due. If the assignments of error cover not only all adjustments in the statutory notice but also some other items, this is an indication that the petitioner is seeking an overpayment of tax even though not specifically stated in the petition. If any of the assignments of error do not pertain to adjustments for determining the correct tax liability, a motion to strike may be proper prior to the preparation of the answer. Such improper allegations of error in most instances, however, may be adequately handled by a denial without the filing of a motion to strike.

2. Some of the reasons for possible admissions of error are: the statutory notice when issued was contrary to the Service’s position; facts established after issuance of the notice may not support the factual or legal conclusion which was the basis for the statutory determination; changes in statutory law, regulations or rulings; change in Service position caused by announced acquiescence in a Tax Court case, acceptance of district court or appellate court case, or decision by the Supreme Court after the statutory notice; or an alternative determination to be alleged in the answer requires abandonment of the statutory notice position.

3. If an adjustment in the statutory notice to which an error is assigned is consistent with Service position but the attorney is of the opinion that the case should not be presented under the circumstances, no concession of such issue, in whole or in part, shall be made without first obtaining approval from the appropriate Division Counsel and Associate offices.


**35.2.2.3.6** **(08-11-2004)**

#### Petitioner’s Allegations of Fact

1. The petitioner’s allegations of fact should be with respect to the assignments of error. As such, the portion of the answer dealing therewith usually contains an admission or denial of the facts alleged in the petition. To correct or to complete the facts alleged in the petition, it may be necessary to allege affirmative facts in this portion of the answer. Respondent’s affirmative case, however, should not be alleged in the responsive paragraphs to petitioner’s allegations.


**35.2.2.3.7** **(04-13-2012)**

#### Claim for Attorney’s Fees

1. For a general discussion of claims for attorney’s fees, see CCDM 35.10.1, Awards of Litigation and Administration Costs and Fees.

2. When a petition, other than a petition for administrative costs pursuant to T.C. Rule 271, requests an award of litigation or administrative costs, the following procedure will be employed. A motion to strike under T.C. Rule 52 shall not be filed even though T.C. Rule 34 provides that a claim for reasonable litigation costs shall not be included in the petition. The answer should contain the following appropriate responses:



   - A general denial that petitioner is entitled to an award for reasonable litigation or administrative expenses

   - An allegation that the request is premature since T.C. Rule 34 provides that such claims shall not be included in the petition

   - If the petition requests the award of litigation or administrative costs in the prayer, respondent should add to the prayer in the answer a statement to the effect that the petitioner is not entitled to litigation or administrative costs and that such a request, in any event, is premature


3. If the petition is filed under IRC § 7430(f)(2) as an appeal from an administrative denial (in whole or in part) of an award of administrative costs, an answer in conformity with T.C. Rule 272 must be filed. Such answers must be submitted to the Associate Chief Counsel (P&A), Branch 5, for review. see CCDM 35.10.1, Awards of Litigation and Administration Costs and Fees.


**35.2.2.3.8** **(08-11-2004)**

#### Shift in Burden of Proof - Section 7491

1. IRC § 7491(a) places the burden of proof on the Service in any court proceeding involving a factual issue if an eligible petitioner introduces credible evidence with respect to the factual issue relevant to ascertaining the petitioner’s tax liability and meets certain requirements. Allegations in the petition that the burden of proof is on the Service under IRC § 7491(a) are premature. Hence, attorneys need not respond to a IRC § 7491(a) pleading with affirmative allegations. The allegation may be denied if it is clear that the petitioner has failed to meet any requirement of the statute. Sample answer paragraphs are shown below. Attorneys should not file answers in "S" cases merely because the petition alleges that IRC § 7491(a) applies.

2. IRC § 7491(b) places the burden of proof on the Service in any court proceeding where the Service reconstructs a petitioner’s income solely through the use of statistical information of unrelated taxpayers. IRC § 7491(b) does not apply where Bureau of Labor Statistics or Consumer Price Index data merely supplements information regarding the petitioner’s income. If the administrative file shows that the determination of income was not based solely on statistics from third parties, the attorney should deny that the respondent has the burden of proof under IRC § 7491(b) in the answer.

3. IRC § 7491(c) provides that the Service shall have the burden of production in any court proceeding relating to the appropriateness of applying penalties, additions to tax and additional amounts imposed by the Code to the petitioner. Since IRC § 7491(c) does not place the burden of proof as to penalties on the respondent, no affirmative allegations are required in the answer. Note that IRC § 7491(c) by its terms applies only to an individual petitioner.

4. Set forth below are some sample answer paragraphs responding to IRC § 7491 allegations:



1. If petition alleges generally that IRC § 7491(a) applies:


       "Neither admits or denies; a determination of the application of I.R.C. § 7491(a) is premature based upon the pleadings."

2. Where IRC § 7491(a) does not apply due to the date the examination commenced:


       "Denies; alleges that the examination commenced on \[date\], which date precedes July 22, 1998, the effective date of I.R.C. § 7491(a)."

3. Where IRC § 7491(a) does not apply because the issue is a legal issue:


       "Denies; alleges that \[describe issue\] is a legal issue, not a factual issue and, therefore, I.R.C. § 7491(a) is not applicable."

4. Where the Service relied on BLS or CPI data as a component for a net worth construction of income:


       "Denies; alleges that the determination was not based solely on third party statistics because Bureau of Labor Statistics figures were used only as a component of the net worth construction of petitioner’s income."

5. Where the petitioner is a corporation that does not meet the net worth requirements:


       "Denies; alleges that the petitioner’s net worth is in excess of $7,000,000.00 \[or has more than 700 employees\]."

6. Where the petition asserts that the Service bears the burden of proof on a penalty, addition to tax or additional amount:


       "Denies; admits that pursuant to I.R.C. § 7491(c), the Commissioner bears the burden of producing evidence to support the application of the \[penalty, addition to tax or additional amount\]; alleges that the petitioner bears the burden of proof with respect to all defenses to the application of the \[penalty, addition to tax or additional amount\]."


**35.2.2.3.9** **(08-13-2021)**

#### Affirmative (New) Issues

1. For docketed cases the term affirmative issue or new issue, as used herein, may be defined as an issue raised in the answer or amended answer which was not one of the adjustments in the statutory notice. An affirmative issue also includes all issues which result in increased deficiencies as well as alternative issues or positions conflicting with the adjustments set forth in the statutory notice. It does not include: affirmative pleadings required for issues upon which the burden of proof is placed by statute upon the Service; matters alleged for affirmative defense, such as exceptions to the statute of limitations, res judicata, and estoppel; or most matters of further defense such as additional grounds in support of the statutory adjustments, or further defense to positions, theories, or qualifications of fact alleged by the petitioner. See CCDM 35.4.1.2, Raising New Issues in Tax Court Cases, for a discussion of when it is appropriate to raise a new issue.

2. Section 6751(b)(1) requires personal, written supervisory approval of the initial determination "of \[a penalty\] assessment" for most Title 26 penalties (except for penalties under sections 6651, 6654, 6655, and 6662(b)(9), and penalties that are automatically calculated through electronic means). This includes a penalty the attorney intends to affirmatively plead in the answer that was not included in the statutory notice of deficiency. If a penalty was not included in a statutory notice of deficiency, an attorney may raise a penalty in the answer or amended answer. The determination of whether to raise the penalty in an answer or amended answer should be made on a case-by-case basis in consultation with the attorney’s immediate supervisor. If an attorney raises a penalty in an answer or amended answer, the attorney’s immediate supervisor must sign the answer or amended answer, and the answer or amended answer must identify the supervisor’s signature as the written supervisory approval of the attorney’s initial determination pursuant to section 6751(b)(1).

3. Upon review of the statutory notices, preparation of pleadings, and litigating positions of the office, the attorney has the responsibility to bring to the supervisor’s attention any affirmative issue necessary for a proper determination of the tax liability of the transactions involved in accord with the current Service position, whether or not such issue or position or theory was previously considered by the revenue agent or by Appeals.


**35.2.2.4** **(08-11-2004)**

### Affirmative Allegations

1. The respondent must plead affirmatively as to any issue upon which the Service has the burden of proof at the trial, or as to facts which will be relied upon for defense of the statutory determination or for affirmative relief. Some of the matters upon which the answer must contain affirmative allegations are:



   - Issues upon which the respondent has the statutory burden of proof, such as fraud (including fraud delinquency), transferee liability, and corporate accumulated earnings tax (IRC § 534)

   - Affirmative relief issues, such as claim for an increased deficiency or liability, new issues or matters not included within the scope of the statutory notice, alternative positions, correction of errors of commission, or corrections of omissions in the statutory notice requiring the presentation of different evidence

   - Affirmative defenses such as exceptions to the statute of limitations, res judicata and estoppel

   - Additional grounds or further defenses in support of the statutory notice adjustments or qualification of facts alleged by petitioner


2. If a petitioner has not assigned error to a fraud or transferee issue (normally requiring affirmative allegations), the attorney should not make affirmative allegations with respect to those issues. Before answering, however, the attorney should consider contacting petitioner or petitioner’s counsel if there is any question whether the failure to assign error was intentional. If not intentional, petitioner’s counsel should be requested to immediately file an amended petition. If petitioner’s counsel does not thereafter amend within a reasonable time, the attorney should consider filing a motion for partial summary judgment or proposing a stipulation as to the undisputed issue. The motion cannot be filed until at least 30 days after the case is at issue. Also in the amount in dispute paragraph, respondent should affirmatively allege that petitioner is not contesting or has conceded the issue. The prayer should include the undisputed penalty (or transferee liability).

3. T.C. Rule 40 requires that the respondent must plead every defense to claims for relief set forth in a pleading, which would include matters and facts which support the statutory determination but are not set forth in the statutory notice. This situation may be illustrated as follows: The statutory notice sets forth one ground for the adjustment in the determination. A second or third ground is also to be urged in support of the same determination at the trial. Before the court can consider the other grounds in deciding the issues, respondent must first plead such other grounds or otherwise satisfy the requirements of the court’s rules for considering issues not raised by the pleadings. _See_ T.C. Rule 41(b).


**35.2.2.4.1** **(04-11-2013)**

#### Manner of Alleging Affirmative Facts

1. Affirmative facts, particularly in fraud and transferee cases, must be alleged in a proper manner. Many facts in respondent’s case are susceptible of admission by the petitioner if properly alleged. Thus, as a general rule, each single fact should be alleged in a separate subparagraph in a concise and straightforward manner without coloring and without interpretation. This will permit the petitioner’s reply to admit such facts without committing the petitioner to the conclusion to be drawn therefrom. Ultimate facts, conclusions, and allegations of fraudulent elements of intent to evade tax must be set forth in separate paragraphs from allegations of facts upon which such conclusion is based. If multiple allegations of facts are combined in one paragraph, or are combined with allegations of fraud, intent to evade, ultimate facts, or conclusions, the reply most likely will deny such allegations due solely to the manner by which uncontested facts are alleged. In such instance, any motion contesting the adequacy of the reply will generally be ineffective.

2. The only facts established by the statutory notice of deficiency are the deficiency or liability determined and the basis upon which it was determined. Therefore, attaching a copy of the statutory notice does not relieve the respondent from pleading the required affirmative facts in the answer.

3. Exhibits attached to the answer, such as net worth schedules, may, if appropriately incorporated as part of the answer proper, be used in appropriate instances in lieu of separate allegations. If, however, there are particular items in the schedules to which a definite and specific reply is sought in the petitioner’s reply, it is the better practice to allege specifically in the answer proper the facts with respect to such item or items; otherwise, difficulties may be encountered in the filing of a motion directed to petitioner’s reply for a specific admission, qualification, or denial with respect to the alleged assets or liabilities involved. When schedules attached to the answer are to be used, in whole or in part, as allegations of specific assets or liabilities or other matters, care must be used in the wording in the answer proper with respect to such schedules. A common error is to allege that the schedule attached hereto as Exhibit A shows the net worth computation of the petitioner for the period \[date\] to \[date2\]. This is not an allegation that the petitioner did in fact have the assets and liabilities or other matters included on such schedule, but is simply an allegation as to the method of computation, and is not an allegation of the specific facts involved.



1. The proper form for this type of allegation would be in language similar to the following:


       "There is attached as Exhibit A, which is incorporated by reference and made a part hereof, a net worth statement of the assets and liabilities of the petitioner for the period \[date\] to \[date2\]; that the petitioner did in fact on the dates specified in Exhibit A have the specific items of assets and liabilities in the various amounts as set forth therein."


**35.2.2.4.2** **(09-24-2012)**

#### Statute of Limitations

1. Affirmative pleadings with respect to the statute of limitations need not be included in the answer unless the petition raises the statute of limitations as a bar to the assessment and collection of the deficiency or liability. If the petition, directly or indirectly, raises the statute of limitations issue, the answer must contain affirmative allegations with respect thereto. _See_ IRC §§ 6501 to 6504 for statutory limitations on assessment and collection.

2. The defense of the exception to the usual three-year statute of limitations may be based upon any or a combination of the following:



   - Valid waivers (agreements extending the statutory period) have been secured (see Exhibit 35.11.1-15, Answer — Affirmative Allegations: Statute of Limitations — Waivers or Consents as Defense, and Exhibit 35.11.1-16, Answer — Affirmative Allegations: Statute of Limitations — Waivers or Forms 872A as Defense)

   - Facts falling within IRC § 6501(e) (see Exhibit 35.11.1-13, Answer — Affirmative Allegations: Statute of Limitations — 25% Omission as Defense)

   - Facts showing no valid return was filed, (see Exhibit 35.11.1-14, Answer – Affirmative Allegations: Statute of Limitations — Delinquency as Defense)

   - Facts showing fraud (see Exhibit 35.11.1-12, Answer — Affirmative Allegations: Statute of Limitations — Fraud as Defense)

   - Facts which bring the case within any other section of the Code which provides for the extension or suspension of the running of the statute of limitations


3. If more than one exception exists with respect to the running of the statute of limitations, all defenses should be pleaded and all facts necessary to sustain each exception relied upon must be fully pleaded. If fraud is an exception to be relied upon, facts evidencing fraud must be specifically pleaded in defense of the statute of limitations as well as to support the fraud penalty. The necessary detailed allegations required in this portion of the answer may be made by incorporating by reference the allegations with respect to the fraud penalty.

4. When petitioner raises a statute of limitations issue and respondent answers that no valid return was filed, respondent should obtain a Form 4340, Certificate of Assessments and Payments (transcript of account), and Certificate of Non-Filing to submit as evidence that respondent has no record of having received petitioner’s return. See _Bruder v. Commissioner_, T.C. Memo, 1989–328; see also _Buttke v. United States_, 13 Cl. Ct. 191 (1987). Note that additional proof may be required in jurisdictions which recognize the common law mailbox rule. In particular, the court may require a showing by respondent that the Service did not lose the return between the time of its receipt and the time it would have been recorded as received.


**35.2.2.4.3** **(08-11-2004)**

#### Collateral Estoppel and Res Judicata

1. \[Reserved\]


**35.2.2.4.4** **(08-12-2010)**

#### Collateral Estoppel in Fraud Cases with Prior Criminal Conviction

1. In general, the case should be carefully evaluated to determine whether collateral estoppel may be pleaded as to any year pending in the Tax Court if for the same year a judgment of conviction for criminal tax evasion of the same tax has been entered against the petitioner, or the officers of a corporation for the criminal tax evasion of the same tax of a corporate petitioner.


**35.2.2.4.4.1** **(09-24-2012)**

##### Elements of Civil and Criminal Fraud and General Rules

1. Collateral estoppel should not be pleaded if the judgment of conviction is based upon a _nolo contendere_ plea. _Blohm v. Commissioner_, 994 F.2d 1542, 1554 (11th Cir. 1993); _Yarbrough Oldsmobile Cadillac, Inc. v. Commissioner_, T.C. Memo. 1993-20. A "nolo" plea and resulting conviction can be used for impeachment purposes, however. Fed. R. Crim. Proc. 11(f); Fed. R. Evid. 410; _Hicks v. Commissioner_, 56 T.C. 982, 1027, _aff’d_, 470 F.2d 87 (1st Cir. 1972). For the purposes of applying collateral estoppel, a conviction can be based either upon a trial on the merits or a guilty plea. _Gray v. Commissioner_, 708 F.2d 243, 246 (6th Cir. 1983); _Moore v. Commissioner_, T.C. Memo. 2001-77. Collateral estoppel is not applicable with respect to the petitioner's individual tax liability, if the petitioner is an individual who has been convicted for evasion of a corporate tax only. If it is concluded that collateral estoppel should be pleaded, the supporting facts should be pleaded in the answer in support of the civil fraud penalty.

2. To support collateral estoppel, there should be a showing that a court of competent jurisdiction has entered a final judgment of conviction, other than one based upon a _nolo contendere_ plea, in a case between parties who are the same as, or in privity with, the parties to the Tax Court case, and that the facts or issues were either presented and actually determined in the prior criminal case, or were essential to support the judgment entered therein. See Exhibit 35.11.1-17, Answer — Collateral Estoppel — General. Collateral estoppel applies to establish liability for the addition to tax for fraud, and to establish any other facts or issues actually determined in the criminal case or essential to support the judgment therein, such as the existence of an understatement of tax which is due to fraud. Collateral estoppel is premised upon the judgment entered in the other case. The judgment of conviction, as well as the indictment or information, should be either set forth verbatim in the answer or a copy thereof attached as an exhibit to the answer.

3. It is well established that a conviction for criminal tax evasion under IRC § 7201 after a trial on the merits (or a guilty plea) collaterally estops the convicted taxpayer from subsequently denying the specific intent requirement of civil fraud under IRC § 6663. See _Amos v. Commissioner_, 43 T.C. 50 (1964). Because a criminal conviction under IRC § 7201 does not require the determination of an exact tax liability (see _Moore v. United States_, 360 F.2d 353, 356-57 (4th Cir. 1965); _Wapnick v. Commissioner_, T.C. Memo. 1997-133), the petitioner is not estopped from disputing the amount of the underpayment. A conviction under IRC § 7201 based on failure to file a return will constitute collateral estoppel for the fraud delinquency penalty provided by IRC § 6651(f). _Madge v. Commissioner_, T.C. Memo. 2000-370, _aff’d by unpub. opin._, 23 Fed Appx. 604 (8th Cir. 2001); _Unger v. Commissioner_, T.C. Memo. 2000-267; _Wallace v. Commissioner_, T.C. Memo. 2000-49.

4. A conviction under IRC § 7203 for willfully failing to file tax returns may be used to prevent a petitioner from challenging the addition to tax under IRC § 6651(a)(1) for failure to file. See _Kotmair v. Commissioner_, 86 T.C. 1253 (1986). A conviction under IRC § 7203 does not, however, constitute collateral estoppel as to the fraud delinquency penalty under IRC § 6651(f). _Wilkinson v. Commissioner_, T.C. Memo. 1997-410. If the taxpayer has been convicted under IRC § 7203, collateral estoppel and summary judgment procedures similar to those described below with respect to IRC § 7206(1) convictions should be followed to narrow the issues in a Tax Court case involving the fraud delinquency penalty.

5. For a conviction under IRC § 7206(1), the government must prove that the taxpayer: (1) filed a return, statement, or other document that was false as to a material matter; (2) signed the return, statement, or other document under penalty of perjury; (3) did not believe the return, statement, or other document was true as to every material matter; and (4) willfully subscribed to the false return with the specific intent to violate the law. _United States v. Hanson_, 2 F.3d 942, 945 (9th Cir. 1993). A criminal conviction under IRC § 7206(1) for willfully filing a false return does not estop the petitioner from challenging a civil fraud penalty in the year of the conviction. See _Wright v. Commissioner_, 84 T.C. 636 (1985). The holding in _Wright_ is based on the fact that the element of intent to evade tax is present in IRC § 6663, but not in IRC § 7206(1). Although not conclusive as to fraud, the conviction is admissible as evidence of fraud. _Wright_ at 643-44. The conviction does estop the petitioner from denying that petitioner willfully filed false income tax returns.



### Note:



The issue in _Wright_ involved former IRC § 6653(b), the predecessor to IRC § 6663.





### Note:



The term "intent to evade tax" is synonymous with "fraud." See _Mitchell v. Commissioner_, 118 F.2d 308, 310 (5th Cir. 1941) ("Negligence, whether slight or great, is not equivalent to the fraud with intent to evade tax named in the statute. The fraud meant is actual, intentional wrongdoing, and the intent required is the specific purpose to evade a tax believed to be owing." ).


**35.2.2.4.4.2** **(09-24-2012)**

##### Pleading Collateral Estoppel

1. Collateral estoppel is an affirmative defense that must be pled in the answer. Because the respondent bears the burden of proof with respect to fraud, affirmative allegations supporting fraud must also be pled in the answer. Thus, for cases involving both conviction and nonconviction years, it is essential to plead adequately all facts supporting the fraud penalty for the nonconviction years. Even though collateral estoppel applies to the conviction years, the factual evidence of fraud in the year or years covered by estoppel is admissible for the purpose of establishing a pattern consistent with the arguments for the years not covered by collateral estoppel. Thus, in that type of case, and particularly in cases involving net worth determinations or cases in which it is necessary to show a pattern of tax omission, the facts evidencing fraud should be pleaded for all years. See Exhibit 35.11.1-17, Answer — Collateral Estoppel — General, and Exhibit 35.11.1-22, Answer — Affirmative Allegations: Fraud — Collateral Estoppel as to Tax Year; _Williams v. Commissioner_, T.C. Memo. 1991-521.

2. If the original answer is filed prior to the indictment or disposition of the related criminal case, an amended answer, together with a motion for leave to file, should be filed in order to plead the facts as may be appropriate as a result of the disposition of the related criminal case.


**35.2.2.4.4.3** **(09-24-2012)**

##### Narrowing the Issues for Trial — Pleadings Based on a Section 7206(1) Conviction

1. If a taxpayer is convicted under IRC § 7206(1) for willfully misstating a matter on a return that affects the computation of the tax owed, the conviction may be used to narrow the issues for trial in the Tax Court. If the willful misstatement was a willful underreporting of income, collateral estoppel should be pled to establish the fact that the petitioner willfully underreported income. Once that fact is established, the petitioner may not defend against a finding of fraud by contending that he did not willfully underreport income. _Miller v. Commissioner_, T.C. Memo. 1989-461. Furthermore, it may be argued that the obvious purpose and the result of willfully underreporting income is to intentionally avoid paying tax known to be due on the omitted income.

2. If the basis of a conviction under IRC § 7206(1) was overstated deductions or some other factual basis with a direct nexus to the petitioner’s tax liability, an analogous analysis applies. Collateral estoppel should be pled to establish the factual basis — _e.g._, the overstatement of deductions — and thereby preclude the petitioner from arguing facts that are inconsistent with the factual basis of the IRC § 7206(1) conviction.

3. The criminal case will have collateral estoppel effect in the civil case only with respect to the facts that were necessary to support the criminal conviction as charged in the indictment or information. For example, if the petitioner had been convicted of violating IRC § 7206(1) by filing a false return that understated income, the conviction would not collaterally estop the petitioner from claiming that disallowed deductions were not willfully overstated or that some portion of unreported income was not willfully underreported. Accordingly, case analysis and development should establish whether the civil case involves disputes over types of income, deductions, or other tax items that were not necessarily decided in the criminal case.

4. Collateral estoppel should be pled in the answer, and should include that the petitioner is collaterally estopped from claiming not to have known at the time the return was filed that the return understated income, overstated deductions, or included or excluded some other tax item, as appropriate based on the petitioner’s conviction. See Exhibit 35.11.1-233, Answer — Affirmative Allegations: Civil Fraud Penalty — Collateral Estoppel of Certain Issues After a Criminal Conviction under IRC 7206(1).

5. A copy of the indictment (or bill of information), the judgment and conviction (or plea agreement), the closing statements, the jury charges, and the jury verdicts from the criminal case should be obtained. The indictment and judgment and conviction should be set forth verbatim in the answer or attached as an exhibit to the answer. If the criminal case was appealed, a citation to the appellate opinion should also be included in the answer.


**35.2.2.4.4.4** **(08-12-2010)**

##### Motions for Summary Judgment

1. The fact that the petitioner intended to evade tax will need to be established by clear and convincing evidence. The fact that the petitioner knowingly and willfully understated income (or overstated deductions, etc.) should be in the record. This fact would have been established during the criminal proceedings, and the petitioner will be collaterally estopped from denying this fact in the Tax Court proceeding.

2. The link between the petitioner’s understatement of income (or overstatement of deductions, etc.) and the petitioner’s knowledge that an understatement of income (or overstatement of deductions, etc.) on the return would results in an underreporting of tax liability must be established.

3. The petitioner’s tax and financial background, educational level, and general business sophistication must be established through stipulations, admissions, interrogatories, and other discovery methods. The more educated, knowledgeable, experienced, and sophisticated a petitioner is, the less likely the petitioner failed to understand the link between understatement of income (or overstatement of deductions) and underreporting of tax.

4. Once sufficient facts are established to show that the petitioner knew the willfully false statement on the tax return would result in an underpayment of tax and, therefore, intended to avoid or evade tax at the time the false statement was made, a motion for summary judgment, or partial summary judgment, as appropriate, should be filed. The motion for summary judgment should include the following general arguments: First, the petitioner knowingly understated income. Second, Facts A, B, and C, established by joint stipulations, admissions, etc., show that the understated income that was the basis of the false return in the petitioner’s criminal case is the same as the understated income leading to the underreporting of tax liability in this Tax Court case. Third, Facts X, Y, and Z, established by joint stipulations, admissions, etc., show that the petitioner knew at the time the return was filed that an understatement of income would result in an underreporting of tax liability. Fourth, a prima facie showing of fraud under IRC § 6663 is established. Therefore, unless the petitioner can come forward with evidence to rebut the prima facie showing, the requisite intent to evade tax exists, and the court should find the petitioner liable for the IRC § 6663 fraud penalty.


**35.2.2.4.5** **(08-11-2004)**

#### Alternative Pleading Shifting Items or Bases of Determination

1. Where there are two or more years before the Tax Court, petitioner’s allegations may shift income from one year to another year, or may claim a deduction in one year which has been allowed in another year. For example, a salary included in an earlier year in the statutory notice on a constructive receipt basis is claimed to be taxable in the later year of actual receipt.

2. In some instances the statutory notice is determined upon either a factual or legal basis which results in the greatest taxable income, but the government is also contending for a deficiency or liability upon alternative facts or upon an alternative legal basis. It is necessary in these instances to plead affirmatively the alternative positions of the respondent. This may be illustrated by a situation in which in the statutory notice of deficiency an item was capitalized and depreciation allowed thereon; in the petition this item is claimed as an expense deduction in full. Thus, there must be pleaded in the alternative that if the petitioner is correct and the item should be expensed, then the depreciation deduction allowed in the statutory notice should be disallowed.

3. In many instances the facts which formed the basis for the shifting of income or deductions or the shifting of the basis of a determination which results in the necessity for alternative pleadings, are not developed when the statutory notice is petitioned. Because of the relevance limitation in the Tax Court’s discovery rules, a petitioner may attempt to limit the possible alternative positions that the government might pursue through discovery that are not set forth in the pleadings. Therefore, the attorney should be alert to cases where there is the necessity of pleading in the alternative particularly where it is necessary to factually develop the issue through discovery.


**35.2.2.4.6** **(09-24-2012)**

#### Pleading Negligence or Delinquency as Alternative to Fraud

1. Under IRC § 6662(b) (for years after 1989), the negligence penalty and other accuracy-related penalties may not be imposed on any portion of an underpayment to which the fraud penalty applies. Furthermore, no accuracy-related penalty or fraud penalty may be imposed where the taxpayer has not filed a return (other than the fraudulent failure to file penalty). IRC § 6664(b). For years after 1989, the delinquency penalty may be imposed in addition to the fraud or accuracy-related penalty if the taxpayer files his return late and on his late-filed return there is an underpayment attributable to fraud, negligence, or other penalized conduct. Also, if the taxpayer failed to file a tax return, the delinquency penalty may be asserted as an alternative to the IRC § 6651(f) fraudulent failure to file penalty. See Exhibit 35.11.1-21, Answer — Affirmative Allegations: Fraud — Alternative Negligence and Delinquency Penalties.


**35.2.2.4.7** **(08-11-2004)**

#### Pleading Delinquency as a New Issue

1. It is the general policy of the Office of Chief Counsel not to raise the delinquency penalty as a new issue after the case is pending in the Tax Court in instances in which the prescribed tax return form, accompanied by proper payment of tax, was timely filed, even though the return form does not legally constitute a return due to a failure to sign or properly execute the return form and the facts clearly negate either willful intent to disobey the statute or gross negligence. Raising a delinquency penalty as a new issue may be necessary, however, if the defect on the return is to be relied upon as a defense to the statute of limitations, for example, on the basis that the period of limitations did not begin because a valid return had not been filed.


**35.2.2.4.8** **(08-11-2004)**

#### Increased Deficiencies

1. Affirmative issues, other than those upon which the statutory burden of proof is upon the respondent, often involve an increased deficiency from that determined in the statutory notice. Increased deficiencies may also result from alternative pleadings. Thus, in any instance in which an increased deficiency is to be claimed, it must be specifically pleaded. _See_ IRC § 6214(a). Generally, an increased deficiency should not be claimed in the original or amended answer unless the evidence supporting such claim is in the hands of the attorney or can be readily obtained.


**35.2.2.4.9** **(08-11-2004)**

#### Allegations of Further Defense

1. In cases in which there are several grounds to support the determined deficiency, it is necessary for the respondent to allege affirmative facts to place before the court all issues not raised in the statutory notice, even though the burden of proof is not placed upon the respondent. The failure to do so may result in the case being decided for the petitioner due to the failure of the respondent to raise a good defense to the petitioner’s contention. This may be illustrated by the following example: In the statutory notice of deficiency a travel expense deduction was disallowed on the basis that the amount claimed was not substantiated; in the petition only the issue of substantiation was raised. If the attorney believes there is also an issue as to whether the petitioner was in travel status when the expenses were incurred, it would be necessary to allege affirmatively in the answer that the petitioner was not in travel status and, therefore, the expense, even if substantiated, is not allowable as a matter of law.

2. Any additional defense, in fact or in law, discovered after filing the answer, must be promptly pled by amendment to the answer, accompanied by a motion for leave to amend where the court’s permission is required under T.C. Rule 41(a).


**35.2.2.4.10** **(08-11-2004)**

#### Joint Returns

1. If the statutory notice of deficiency is based upon a joint return of husband and wife and either spouse denies that a joint return was filed, the respondent should assert, in the alternative, a claim for an increased deficiency against the spouse who clearly filed the return. If the court should hold as to noncommunity income that a joint return was not in fact filed, the court should determine the entire deficiency against the party filing the return. A different problem exists with respect to community income since, if the court should hold that a joint return was not in fact filed, only half of the community income would be taxable to the spouse filing the return. In such instances a question may arise as to the validity of the statutory notice as to the spouse who was not a party to the return and whether under such circumstance a new statutory notice against such party may be issued. Thus, for protective purposes there should be alleged in the answer, in the alternative, that if the court should hold that joint returns were not in fact filed, separate deficiencies should be determined against each spouse, and a claim should be made, in the alternative, for a separate deficiency against the spouse who denies filing a joint return based on half of the community income. Care should be exercised in disposition of the case so that the court does not tax one spouse with only half of the community income and determines no deficiency as to the other spouse.


**35.2.2.4.11** **(08-11-2004)**

#### Sanctions under Section 6673

1. The IRC § 6673(a)(1) penalty should be claimed in all cases where the principal arguments being made by the petitioner are those already deemed frivolous and without merit by the courts, in certain cases where the petitioner (or a related party) has already litigated the same issue in an earlier case and lost, and in other cases where circumstances warrant. See CCDM 35.10.2, Penalties and Sanctions.

2. Although the penalty can be claimed at any time prior to entry of decision, as a rule, the claim should be affirmatively pled at the earliest possible time. The claim may be raised in the answer, by amendment to the answer or by oral or written dispositive motion, such as a motion for summary judgment or a motion to dismiss for failure to prosecute.

3. In every case, the factual basis upon which the penalty is claimed must be affirmatively pled. In a case where the penalty is claimed in the answer or amendment to the answer, the Service’s position is that T.C. Rule 37 requires the petitioner to file a reply. Where a reply is not filed by the petitioner, respondent should file a motion under T.C. Rule 37(c) requesting an order that the undenied affirmative allegations in the answer be deemed admitted.


**35.2.2.5** **(08-11-2004)**

### Answers in Cases with Criminal Aspects

1. In preparing the answer or amended answer the criminal aspects of the case must be protected to the extent possible. Copies of any documents filed with the court will also be provided to the office currently charged with the criminal case, i.e., Criminal Investigation, Department of Justice (DOJ), and/or the United States Attorney. See CCDM 35.2.1.1.5.1, Criminal Cases.

2. At the time of answer, it should be determined whether the Tax Court case should be processed only after the criminal trial. If so, a motion for stay should be filed so that the Tax Court proceedings will not interfere with ongoing criminal proceedings. See CCDM 35.4.1.5.1, Coordination with Criminal Tax Cases, and CCDM 35.3.9.12, Motion for Stay of Civil Proceedings; _Zackim v. Commissioner_, 91 T.C. 1001 (1988), _rev’d on other grounds_, 887 F.2d 455 (3d Cir. 1989), and _Singleton v. Commissioner_, 65 T.C. 1123 (1976).


**35.2.2.6** **(08-11-2004)**

### Answers in Fraud Cases

1. The burden of proving fraud is, by statute, placed upon the respondent. The answer, therefore, must affirmatively allege the facts upon which the respondent will rely at the trial to establish the elements of fraud. Affirmative allegations supporting the fraud or fraud delinquency penalty must be alleged in the answer except where the petition contains no assignments of error as to the fraud determination or where the fraud or fraud delinquency penalty is clearly and specifically admitted in the petition. If a joint return is involved, there must be affirmative allegations as to the fraud of each spouse if each of them is to be held liable for the fraud penalty. Where no return is filed, fraud must also be proved against both spouses to sustain the fraud penalty or fraud delinquency penalty (after 1989) against each. Fraud must also be specifically pleaded in transferee cases in which the fraud or fraud delinquency penalty of the transferor is a part of the transferee liability.

2. The Tax Court requires that the answer contain specific details of the facts upon which the respondent relies to support the fraud penalty. The filing of an inadequate answer which is subject to a motion for a more definite statement is very likely to result in an order of the court requiring the allegation of more details than would have to be alleged if an adequate answer had been filed originally or prior to the hearing on petitioner’s motion. Alternatively, a deficient answer may subject respondent to petitioner’s successful motion for judgment on the pleadings if the pleadings do not contain sufficient grounds which, if true, would sustain a fraud determination.


**35.2.2.6.1** **(08-11-2004)**

#### Limit Allegations to Fraudulent Items and Amounts

1. For years prior to 1990 and for the fraud delinquency penalty after 1989, it is only necessary to establish that part of the underpayment of tax was due to fraud. If it is initially alleged that the entire deficiency is due to fraud and the petitioner files a motion for a better answer with respect thereto, it may not be possible to allege in an amended answer that only a part of the deficiency is due to fraud and thereby avoid alleging detailed facts as to all the adjustments giving rise to the asserted deficiency. Therefore, the ultimate allegation should always be phrased as all or part of the underpayment is due to fraud.

2. For years after 1989, the fraud penalty is only imposed on the portion of the underpayment attributable to fraud. If, however, the Service establishes that a portion of the underpayment is attributable to fraud, the entire underpayment will be presumed to be attributable to fraud, unless the taxpayer proves otherwise. Therefore, the ultimate allegation should still state that all or part of the underpayment is due to fraud, in cases involving tax years after 1989.

3. The initial answer should allege fraud only with respect to the particular adjustments which will be relied upon and proved at the trial to establish fraud. In cases having criminal aspects, the initial answer should be consistent with the allegations of fraud to be relied upon for criminal purposes in the absence of unusual circumstances. Generally, it should be easier to sustain the fraud or fraud delinquency penalty by applying the same theory as the criminal case, even though the theory of the criminal case may be inconsistent with the civil determination. This could occur in situations in which various civil items have been conceded for purposes of presenting the criminal case. If the case is one in which it is more desirable to employ the civil adjustments in support of a fraud or fraud delinquency penalty, the criminal theory could then be alleged as evidence of fraudulent intent.


**35.2.2.6.2** **(08-11-2004)**

#### Elements of Fraud

1. IRC § 6663 (for years after 1989) provides for the fraud penalty if any part of any underpayment (as defined in subsection(c)) of tax required to be shown on a return is due to fraud. Once the respondent has established that a portion of the underpayment is due to fraud, the entire underpayment is presumed to be attributable to fraud unless the petitioner rebuts the presumption by presenting evidence that some part of the underpayment is not attributable to fraud. The elements necessary to establish the penalty are (1) an underpayment of tax, and (2) some part of the underpayment being due to fraud. Fraud has been defined as an intentional wrongdoing motivated by a specific purpose to evade tax known or believed to be owing. _Stoltzfus v. United States_, 398 F.2d 1002, 1004 (3d Cir. 1968), _Hebrank v. Commissioner_, 81 T.C. 640 (1983). These elements must be present within the allegations of the fraud answer. There is no specific format for the allegation of these elements that will suffice in all cases. The form and substance will, of necessity, depend upon the peculiar facts of each case.

2. Ordinarily, the determination of the correct taxable income is based upon the use of several methods of determining taxable income; i.e., specific items, bank deposit method, or the net worth and expenditures method. The specific items method is based upon direct evidence pertaining to specific items of omitted or incorrectly reported income or claimed deductions which are unallowable, in whole or in part. On the other hand, the bank deposit method or the net worth and expenditures method involves proof of the correct taxable income by indirect or circumstantial evidence which establishes, without reference to specific items of income or deductions, that the correct taxable income exceeds that reported. Whichever method is used, it has one purpose ( the determination of the correct taxable income. In appropriate cases two methods may be used in determining the correct taxable income; however, one method should be pleaded as the primary position of the respondent, and the other as the alternative. The alternative method will be reached by the court only in the event it fails to sustain the respondent on the primary method. In this event the court will decide which is the proper method of computation and determine the correct taxable income under that method. In cases in which indirect methods are used, however, specific items of income included in such computation may be pleaded in support of the fraud penalty to show the requisite fraudulent intent and a taxable source for the income.


**35.2.2.6.3** **(09-24-2012)**

#### Specific Items Method

1. Where a deficiency is determined from the omission of items of income, disallowed claimed expenses, or other specific adjustments, the answer should set forth allegations of fact which impute fraud to some portion of the specific adjustments. See Exhibit 35.11.1-20, Answer — Affirmative Allegations: Fraud — Specific Items Method. In many cases the specific adjustments in the statutory notice can be classified as fraudulent and nonfraudulent adjustments. It is inadvisable to impute fraud to a specific adjustment which is clearly not fraudulent.

2. The correct taxable income is frequently determined by resorting to one of the methods of circumstantial evidence when the taxpayer has concealed sources of income, or has no books or records, or where the books or records maintained by the taxpayer or made available to the examining agents are inadequate to permit adjustments to specific items of recorded or reported income or deductions. In these instances, it is preferable to plead and prove those facts which in the particular case warrant resort to a method of circumstantial evidence to establish correct taxable income. Direct proof of specific errors or omissions in the books or records is not a condition precedent to utilization of circumstantial evidence to establish correct taxable income; where direct evidence is unavailable, the circumstantial evidence, buttressed by other evidence of the taxpayer’s financial history, may itself independently demonstrate the inadequacy or inaccuracy of the books or records. _Holland v. United States_, 348 U.S. 121 (1954). Where correct income is determined under the bank deposit or net worth and expenditures method, it is necessary to adduce additional evidence to support the inference that the income thus established was derived from a taxable source and was currently taxable in the particular year involved, or to negate any inference that the income thus established was derived from nontaxable sources.

3. If a method of circumstantial evidence was used in the determination of the deficiency, but specific items of omitted income are also known to respondent, such specific items of omitted income should be specifically alleged in the answer to provide a basis for proof of source to establish the taxable character of the funds involved in the excess accretion of net worth or otherwise unexplained bank deposits.


**35.2.2.6.4** **(09-24-2012)**

#### Bank Deposit Method

1. The reconstruction of income under the bank deposit method requires analysis of all bank deposits and all expenditures, both by cash and by check. An analysis of deposits and comparison with the records and reported receipts may demonstrate that some of the taxable receipts have been deposited without being recorded on the taxpayer’s records or, where reported receipts are in agreement with the bank deposits, that some receipts have been withheld from deposit. The withheld deposits may be linked to assets purchased or disbursements made. Gross receipts under this method consist of bank deposits plus undeposited receipts. The gross bank deposits must be adjusted to eliminate deposits of a non-income nature, such as transfers, loans deposited, or other such items. Undeposited receipts usually are shown by cash expenditures or accumulations not traceable to withdrawals of deposited funds and not accounted for by undeposited nontaxable receipts. Taxable income is derived by subtracting from such gross receipts the deductible expenses determined from an analysis of cancelled checks and cash expenditures, including any noncash deduction, such as depreciation. The records and testimony of the taxpayer and third parties may establish the deductible expenses as well as establish receipts not recorded, deposited, or reported by the taxpayer.

2. The facts in each case must be analyzed, and the method or combination of methods used in the computation of taxable income must be followed in setting out the fraud allegations. In identifying the bank deposits the allegations should name the bank or banks and the amount or amounts of deposits representing receipts for the periods covered. The amounts of receipts which are alleged to have been withheld from deposit must be identified in some reasonable manner. Each factual element of the bank deposit reconstruction of correct taxable income must be alleged to show the court the facts upon which the respondent will rely to prove that the underpayment of tax is due, in whole or in part, to fraud. See Exhibit 35.11.1-18, Answer — Affirmative Allegations: Fraud — Bank Deposit Method.


**35.2.2.6.5** **(09-24-2012)**

#### Net Worth Method

1. The net worth and expenditures method of determining the correct taxable income requires proof of the assets and liabilities of the taxpayer as of the beginning and the end of each year during the period involved, from which there is established the annual increase or decrease in net worth for each year by comparison of the beginning net worth and the ending net worth. The taxpayer’s nondeductible expenditures during the year, including personal living expenses, federal income taxes paid, and other such items which are not reflected in the increase or decrease of net worth for such year are added to the net worth figure. There is then deducted from such total for each year the amount of any nontaxable items received during the year. The resultant figure is the corrected taxable income for such year. The reported taxable income is subtracted from such corrected taxable income and the excess, if any, is alleged as the unreported taxable income for the year.

2. The Tax Court requires the respondent’s answer to show in detail the assets and liabilities at the beginning and end of each taxable year, and to clearly identify each item on the net the worth schedule and in the adjustments thereto in determining the correct taxable income. For example, the details required with respect to categories of assets and liabilities include:



   - Bank accounts — the name of each account and bank with which it is carried, and the amounts on deposit in each account at the starting point and end of each year involved, adjusted for outstanding checks, if any;

   - Securities —identify each security by name and the cost of each held as of the beginning and end of each year;

   - Real estate — identify each parcel and cost of each, etc.;

   - Personal property — describe each item with sufficient detail to permit its identification, together with its cost, etc.;

   - Liabilities — identify each mortgage, note, or other item and the amount thereof, etc.; and

   - Nondeductible expenditures, such as living expenses, taxes, etc. — must be identified or explained sufficiently to permit responsive pleading by petitioner.


3. The net worth schedule may be either alleged in the answer proper, or attached to the answer as an exhibit, or both. See Exhibit 35.11.1-19, Answer — Affirmative Allegations: Fraud — Net Worth Method. If the net worth schedule is attached as an exhibit without the contents thereof being fully alleged in the answer proper, the body of the answer must contain specific allegations that the taxpayer did in fact have the assets, liabilities and other items as set forth on the attached schedule as of the date or dates shown thereon, and that the petitioner did make the nondeductible expenditures listed on the exhibit and added thereon to the increase in the net worth for each year. An allegation in the answer that the attached schedule merely shows the method of computation of taxable income is not an acceptable allegation; the facts as to specific expenditures and existence of specific assets and liabilities are required to be alleged.


**35.2.2.6.6** **(08-11-2004)**

#### Establish Taxable Source or Negate Nontaxable Sources

1. A specific allegation should be included in the answer to the effect that the accretion in net worth, or the bank deposits in question, for the year or years involved did not include, or result from, any items of nontaxable income. If, however, a reduction was made for specifically identified nontaxable items in the computation of correct taxable income under the net worth or bank deposits method in the determination of the deficiency, such reduction shall be alleged and the further allegation made that no other nontaxable items were received during the pertinent year or years.


**35.2.2.7** **(08-11-2004)**

### Answers in Transferee and Fiduciary Liability Cases

1. This section addresses issues relating to answering transferee and fiduciary liability cases.


**35.2.2.7.1** **(09-24-2012)**

#### In General

1. IRC § 6901 sets forth summary procedures under which the Service may assess and collect taxes, penalties, and interest owed by a transferor from the transferee, or from the transferee of a transferee. This statutory provision, however, does not create substantive transferee liability. The existence of, or the extent of, a transferee’s liability at law or in equity is to be determined by the applicable state or federal substantive law. _Commissioner v. Stern_, 357 U.S. 39 (1958). _See_ IRC § 6324 for an example of federal substantive liability.

2. In proceedings before the Tax Court, the respondent has the burden of proof to show that the petitioner (transferee) is liable as a transferee of property of the petitioner (transferor) but not to show that the petitioner was liable for the tax. IRC § 6902(a). Thus, the respondent must plead and prove all the essential elements of transferee liability. See Exhibit 35.11.1-23, Answer — Affirmative Allegations: Transferee Liability.

3. A fiduciary liability case is a case involving the personal liability of the petitioner under the provisions of 31 U.S.C. § 3713 for income, estate, or gift taxes due from the estate of the petitioner, the decedent, or the donor, as the case may be. IRC § 6901(a)(1)(B) makes the summary procedures for the assessment and collection of such taxes from the fiduciary the same as in the transferee cases. The controlling substantive law with respect to fiduciary liability cases, however, is the federal body of substantive law and not the state substantive law, as in transferee cases.

4. In transferee and fiduciary liability cases, the terms used to designate the fiduciary capacity of the petitioner in the answer should be the same as in the statutory notice. For example, if the statutory notice uses the term transferee, transferee and trustee, fiduciary, executor, administrator, trustee, insurance beneficiary and trustee, donee, or transferee and donee, etc., the same terminology should be used in the pleadings, stipulation, and other documents filed with the court. In gift cases, the transferor is usually referred to as the donor but in some instances the statutory notice will use the term transferor or donor and transferor, in which event the same terminology will be used in documents to be filed with the court.

5. In the handling and processing of a transferee case the attorney must observe the distinction between a transferee case and a deficiency case. The various types of statutory notices that are issued by the Service and the statutory notice of liability are important not only in pleading but also in the disposition of the case by a settlement stipulation or a T.C. Rule 155 computation.


**35.2.2.7.2** **(08-11-2004)**

#### Limited and Unlimited Liability

1. The items that generally make up the amount of the transferee liability are:



   - Any unpaid tax reported on original or amended returns

   - Deficiency in tax and penalty due from the transferor

   - Statutory interest on the unpaid tax and on the deficiency from the due date of the tax to the date of the transfer of assets to the transferee (if the liability at law or in equity is based upon the transfer)

   - Statutory interest on the penalty from the date of the notice and demand to the date of the transfer of the assets


2. While it may be necessary to break down in the statutory notice of deficiency or in the answer the transferor’s liability for tax, penalty, and interest for the years involved, the amount of the transferee liability is always a single total amount. In setting forth the amount of the transferee liability it is generally advisable to set forth separately the deficiency in tax from the amount of the unpaid original tax, the total of which make up, in whole or in part, the transferee liability. Normally, the statutory notice does not include transferor interest as part of the transferee liability. Thus, in unlimited cases the single total amount of the transferee liability will be the total liability of the transferor for all taxes and all penalties for all years involved due from the transferor, together with the applicable interest thereon. In limited liability cases the single total transferee liability is the value of the assets transferred. In any case in which the transferee liability is incorrectly or improperly determined in the statutory notice, such determination must be modified in the answer and the total amount of the transferee liability correctly alleged.

3. For the purpose of pleading and trial, the transferee liability is a single amount, based upon the value of assets received by the transferee to be applied, in whole or in part, to the unpaid original tax, deficiency tax, penalty, and interest due from the transferor for all years before the court. The reason for this procedure is to avoid, particularly in limited liability cases, a reduction in the transferee liability below the value of the transferred assets due to the court’s holding that a part of the tax or penalties determined against the transferor is erroneous.


**35.2.2.7.3** **(08-11-2004)**

#### Interest in Transferee Cases

1. Interest is an essential element in every transferee case and must be pleaded in the answer, set forth in the settlement stipulation or Rule 155 computation, and a proper determination with respect thereto must be included in the Tax Court’s decision. Strictly speaking, there are two types of interest involved in every transferee case. "Transferor interest" is a part of the transferee liability, even if it is omitted from the statutory notice. "Transferee interest" is the interest due from the transferee on the amount of the transferee liability whether the case involves limited or unlimited transferee liability.

2. In every transferee answer, the specific amount of the transferee liability must be alleged, plus interest as provided by law. It is preferable that the answer allege specifically the date on which interest on the transferee liability begins to run. When this is not possible, the words "plus interest as provided by law" should follow the allegation of the amount of the transferee liability.

3. For cases in which the amount of the deficiency in tax due from the transferor is reduced by an operating loss or credit carryback or carryforward, either in the statutory notice or in the court’s redetermination of the amount of tax due from the transferor, care must be exercised in pleading or in determining the interest due from the transferor or the transferee on the deficiency in tax prior to such reduction.


**35.2.2.7.4** **(08-11-2004)**

#### General Transferee Pleading Requirements

1. In any case in which the fraud or fraud delinquency penalty is involved in determining the amount of the transferee liability, the burden of alleging and proving fraud of the transferor is upon the respondent to the same extent as it is in any other fraud case. Thus, in any transferee case in which the fraud or fraud delinquency penalty has been determined against the transferor, affirmative allegations showing fraud or fraudulent failure to file must be made in addition to the required affirmative allegations of transferee liability. Also, if there are matters of the statute of limitations, affirmative defense, alternative positions, etc., they must be affirmatively pleaded and proved to the same extent as in any other case.

2. The general elements which must be pleaded in every transferee case are set forth below. The particular elements will vary from case to case, and not all of these elements are involved in every transferee case. In addition there are generally specific and necessary elements under state law which must be pleaded and proved. These general elements are:



01. The deficiency in tax and any unpaid original tax owed by the transferor for each year involved

02. All additions to the tax (penalty) owed by the transferor for the years involved

03. Any interest due from the transferor under the restrictive interest provisions of the Code due to operating loss or credit carrybacks, etc., and any other interest element essential to the case

04. All reasonable actions to collect from the transferor have been exhausted, or such other allegation as the circumstances warrant to show that the amounts due from the transferor cannot be collected, or that to pursue the collection procedures would be a useless act. Such allegations are unnecessary in estate tax cases.

05. If the liability at law or in equity is based upon the transfers of assets, as for example, the Uniform Fraudulent Conveyance Act, the particular type of fraudulent conveyance relied upon should be alleged. If the intent to evade or defeat creditors cause of action, or the transfer prior to insolvency cause of action is used, allegations appropriate to the theory should be alleged. If the lack of consideration while insolvent cause of action is used, there should be alleged reasonable description of the property transferred by the transferor to the transferee without full, fair or adequate consideration; the specific date or dates of the transfer of the properties involved; and that the transfer of the properties from the transferor to the transferee was made when the transferor was insolvent or was rendered insolvent by reason of the transfer of such properties.

06. If the basis of the transferee liability is at law, appropriate allegations must be made to sustain that basis, such as by contract, or distribution of an estate or defunct corporation

07. The transfer of the property or other assets had a value to the transferee

08. The fair market value of the assets on the date or dates transferred to the transferee. If the case involves a transferee of a transferee, appropriate allegations should be made with respect thereto.

09. The necessary elements required by state statutes or judicial decisions involving fraudulent conveyances or the liability applicable to the particular case involved

10. Appropriate allegations with respect to interest due from the transferee on the amount of the transferee liability. In most cases the specific amount of transferee interest cannot be alleged, and it is not necessary to do so. However, there should be alleged and raised as an issue, the date on which interest begins to run on the amount of the transferee liability. Such interest runs from such date to the date paid.



       ### Example:



       The transferee is liable for interest as provided by law on the aforesaid $50,000 from April 15, 2000, until paid.


**35.2.2.7.5** **(08-11-2004)**

#### Merged Corporations

1. Particular care must be exercised in pleading with respect to cases in which the determination is made against the successor of merged corporations, or in other situations in which the petitioner is an assignee of property by operation of law. These are not true transferee cases; however, there may be situations in which as a result of an apparent merger a true transferee liability is involved. If the statutory notice was issued as a notice of transferee liability, even though incorrect, it is generally advisable to plead, process, and close the case as a transferee case. If the petitioner questions the transferee determination or there are other problems involved which necessitate a different treatment, appropriate action should be taken to protect the government’s interest in accord with the particular facts and circumstances.


**35.2.2.7.6** **(08-11-2004)**

#### Fiduciary Liability

1. 31 U.S.C. § 3713, provides for the priority of debts due the United States and makes fiduciaries who distribute assets without paying a prior debt due the United States personally liable for the debt. Furthermore, this fiduciary liability is subject to the assessment and collection procedures of IRC § 6901(a)(1)(B). Unlike transferee liability cases under IRC § 6901, however, it is the Service’s position that in fiduciary liability cases, petitioners have the burden of proof except as may be otherwise provided under other statutory provisions, such as IRC § 7491. See _Bank of the West v. Commissioner_, 93 T.C. 462, 467 (1989); _McCourt v. Commissioner_, 15 T.C. 734, 737 (1950). Some of the essential elements of fiduciary liability are that the fiduciary had actual or constructive notice of the tax claims of the government prior to the distribution of the assets and that the estate or donor was insolvent or was made insolvent by such distribution. Thus, once the Service has made a prima facie showing of fiduciary liability, petitioners will generally seek to provide either that they had no knowledge of the government’s claim or that the estate or donor was not insolvent during the relevant time period.


**35.2.2.8** **(08-11-2004)**

### Answers in Accumulated Earnings Tax Cases

1. The following section addresses issues that arise when answering accumulated earnings tax cases.


**35.2.2.8.1** **(08-11-2004)**

#### Burden of Proof in Tax Court Cases

1. IRC §§ 531 through 537 govern the imposition of an accumulated earnings tax on corporations deemed to have engaged in unreasonable (i.e., excessive) accumulations of earnings and profits for tax avoidance purposes, including the insulation of shareholders against income taxes which they would have had to pay if the corporations had paid out (more of) their incomes in dividends.

2. IRC § 534 provides that the burden of proof in the Tax Court with respect to an allegation that all or any part of earnings and profits have been permitted to accumulate beyond the reasonable needs of the business shall: If a notification with respect thereto has not been timely sent, be on the Service; or if a statement has been timely submitted by the petitioner in response to such notification, be on the Service with respect to those grounds set forth in such statement in accordance with the statutory provisions. Any determination imposing the accumulated earnings tax is necessarily based on some sort of allegation that earnings have been accumulated beyond the reasonable needs of the business inasmuch as the interrelationship of the accumulated earnings credit, including an allowance for current earnings retained for the reasonable needs of the business, would otherwise eliminate the accumulated taxable income. Therefore, placement of the burden of proof concerning reasonable business needs must be considered in every Tax Court case involving the accumulated earnings tax.

3. In defending accumulated earnings tax cases, the government is not under any requirement or duty to allege or prove the amount of tax saved by any stockholder in consequence of the purported unreasonable accumulation of corporate earnings. In any given case, however, the attorney may adopt that tactic to strengthen the government’s position. A stockholder’s return can be used as evidence. Even though disclosure of the returns is permissible for that purpose, it is preferable to limit disclosure as much as possible and proceed through stipulation whenever feasible.

4. In order to avoid or to limit the burden of proof with respect to the reasonable needs of the business, the Service must timely send by registered or certified mail a notification informing the petitioner that a proposed assertion of tax or addition to tax includes imposition of the accumulated earnings tax. To be timely, such notification must be sent prior to the issuance of the 90-day letter.

5. If a timely notification has been sent, the petitioner must timely submit a valid statement in response thereto in order to shift to the Service the burden of proof as to the grounds (supported by facts to show the basis thereof) set forth in such statement to establish that earnings were not accumulated beyond the reasonable needs of the business. To be timely, petitioner’s statement must be submitted within 60 days (with a 30-day extension available) after the mailing of the notification. To be properly submitted the statement must be sent to the Internal Revenue Service office which issued the notification of the proposed assertion of the accumulated earnings tax. In determining the acceptability of a statement the attorney must consider whether it was submitted to the proper Internal Revenue Service office within the time permitted.

6. If a notification has been timely sent and the petitioner has timely submitted an acceptable statement in response, the Service has a burden of proof, but only with respect to the ground or grounds which are:



   - Specifically set forth in such statement

   - Relevant

   - Accompanied by an exposition of facts sufficient to show the basis


7. The attorney should never voluntarily assume a greater burden than that imposed by statute. The burden of proof remains upon the petitioner with respect to any grounds set forth therein in an unacceptable manner ( _e.g._, without supporting facts); or any grounds not included in petitioner’s statement, which it may nevertheless try to introduce. For example: If petitioner’s statement addresses itself exclusively to a need for a new factory building to justify accumulations, and in subsequent Tax Court proceedings the petitioner seeks to have the court consider the need for a source of funds for internal financing of credit sales, the petitioner has the burden to prove that the accumulations were made for, and justified by, a reasonable business need to finance credit sales. Similarly, if petitioner in its statement asserted that its business needs required the accumulation of $500,000 to acquire a new building, the petitioner must bear the burden of proof that any accumulations in excess of $500,000 were warranted by the need for the new building.


**35.2.2.8.2** **(09-24-2012)**

#### Tax Court Pleadings

1. The form of the answer filed in an accumulated earnings tax case varies depending upon whether the Service and the petitioner followed the procedures outlined above. See Exhibit 35.11.1-24, Answer — Accumulated Earnings Tax: Inadequate Section 534(c) Statement, Exhibit 35.11.1-25, Answer — Accumulated Earnings Tax Answer: Petitioner Failed to Submit Section 534(c) Statement, and Exhibit 35.11.1-26, Answer — Accumulated Earnings Tax Answer: Section 534 Letter Sent But No Response.


**35.2.2.9** **(09-24-2012)**

### Answers in Declaratory Judgment Cases and Worker Classification Cases Under Section 7436

01. The Tax Court is authorized to issue declaratory judgments with regard to letter rulings issued by the Commissioner in numerous areas. These areas include: status and classification of organizations regarding their exemption from tax (IRC § 7428); qualification of retirement plans (IRC § 7476); determinations regarding valuation of gifts (IRC § 7477); and status regarding tax exemption of certain governmental obligations (IRC § 7478). Declaratory judgment cases arising under IRC § 7476 are generally handled by Field Counsel because of their frequency. Cases arising under IRC § 7428 are handled by either Field or Associate office attorneys depending on the type of case and where the adverse ruling was issued. See CCDM 35.2.1.1.15.2(3), (4), Initial Review of EO Declaratory Judgment Cases. Cases arising under IRC §§ 7477 and 7478 are relatively rare and almost always require extensive coordination. For these reasons they are tried by attorneys in the Division Counsel/Associate Chief Counsel (TEGE).

02. Prior to preparing an answer in a declaratory judgment case, the attorney should ascertain that the Tax Court has jurisdiction over the proceeding. One of the most important jurisdictional prerequisites is the exhaustion of administrative remedies. See _Thompson v. Commissioner_, 71 T.C. 327 (1978). See jurisdictional requirements at CCDM 35.3.8, Motions in Declaratory Judgment Cases and Section 7436 Worker Classification Cases.

03. The answer in a declaratory judgment action will differ in one important respect from that filed in a deficiency case: it must contain a complete index to the administrative record as defined in T.C. Rule 210(b)(12). See Exhibit 35.11.1-27, Declaratory Judgment Case: Employee Plans (Stipulated Administrative Record). This index generally will not have been prepared during the administrative processing of the case. The attorney must personally prepare a complete and accurate index. The task of preparing or verifying the index may be time consuming and should be commenced at an early stage in the preparation of the answer. It should never be delegated to support staff. Particular care should be taken to assure that the index only contains the material defined as part of the record in the court’s rules and does not include internal Service documents containing the mental impressions, conclusions, and reasoning of Service personnel.

04. T.C. Rule 213(a)(2) permits facts, other than jurisdictional facts and facts involved in a revocation or a governmental obligation action, to be admitted by respondent for purposes of the pending action for declaratory judgment only, and answers should be so drafted. This should be done in retirement plan declaratory judgment answers as well as those involving exempt organizations. The facts admitted should be limited to those contained in the administrative record. See Exhibit 35.11.1-27, Declaratory Judgment Case: Employee Plans (Stipulated Administrative Record), and Exhibit 35.11.1-28, Declaratory Judgment Case: Employee Plans (Administrative Record Submitted Unagreed). Where facts alleged in the petition were never presented to the Service in support of the request for the determination and are not, therefore, contained in the administrative record, the answer should be neither admits nor denies on the grounds that the allegations are not a part of the administrative record and thus not cognizable by the Court. In some instances, consideration should be given to filing a motion to strike pursuant to T.C. Rule 52. Under T.C. Rule 217(a), facts outside the administrative record will not be considered by the court except under limited and unusual circumstances. See _Houston Lawyer Referral Service, Inc. v. Commissioner_, 69 T.C. 570 (1978).

05. Declaratory judgment cases should be handled very carefully. Even though they are nondeficiency cases, they have wide-ranging application and, in many instances, enormous economic impact for affected persons, organizations and the Treasury. Field attorneys should not hesitate to seek assistance from the appropriate Associate office if they have questions not answered by this section.

06. Any additional grounds supporting the determination that a plan is not qualified or that an organization is not exempt which are not contained in the determination letter may be raised in the answer. Under T.C. Rule 213(b), a reply is required in every declaratory judgment action and when a reply is not filed, affirmative allegations in the answer will be deemed admitted.

07. For purposes of the declaratory judgment action, the Service will accept as true the facts presented by the organization during the administrative determination procedure. Generally, therefore, there will be no need for a stipulation conference to determine which documents are part of the administrative record. Only documents that are a part of the record (and the facts derived from those documents) are subject to stipulation. Objection should be made to the admission of any document which is not a part of the administrative record and the finding of any fact which is not supported by that record. In those cases in which grounds supporting the Commissioner’s determination, revocation, or ruling are alleged for the first time in the answer, petitioner will be permitted to introduce evidence not already in the record to support its position that the Commissioner’s determination is in error. In most instances, it will be possible to stipulate to those additional documents. Coordination with the Exempt Organizations division of the Division Counsel/Associate Chief Counsel (TEGE) is essential to evaluate the significance of this additional documentary evidence.

08. Stipulation of the administrative record should occur within 30 days after service of the answer. See Exhibit 35.11.1-27, Declaratory Judgment Case: Employee Plans (Stipulated Administrative Record). If agreement has been reached but the stipulation is not ready for filing within the 30-day period prescribed by T.C. Rule 217(b), a motion to extend the time for submission must be filed. When the answer is filed, the attorney should consider forwarding a copy of a proposed stipulation to petitioner so that any disagreements can be worked out before the expiration of the 30-day period. If the parties are unable to file a stipulated administrative record, the government must file the entire record with a Notice of Filing of the Administrative Record and a Commissioner’s Certificate as to the Genuineness of the Entire Administrative Record between 30 and 45 days after the service of the answer. Accordingly, the entire administrative record must be segregated from the remainder of the administrative file and kept available for inspection (and copying if necessary).

09. The administrative record in both initial qualification and revocation cases is defined in T.C. Rule 210(b)(12) to comprise the request for determination, all documents submitted to the Service by petitioner in support of its request for determination, all written correspondence between the Service and petitioner, all pertinent returns, and the notice of determination. The administrative record closes at the moment the final adverse determination letter or notice of revocation is mailed. While the administrative record is defined in the same manner for both initial qualification and revocation cases, the crucial difference between the two is that an initial qualification case is almost always decided solely on the administrative record, while in a revocation case the court may routinely consider evidence outside the administrative record. T.C. Rule 217(a). See CCDM 35.4.7.6(3), Effect of Stipulation, for guidance on preparing and stipulating to the administrative record.

10. Although in a revocation case the court may look at evidence outside of the administrative record, in an initial qualification case evidence outside the record can only be introduced upon a showing of "good cause." T.C. Rule 217(a). The Tax Court has construed this limitation in determination cases narrowly. See _Church in Boston v. Commissioner_, 71 T.C. 102 (1978). T.C. Rule 217(a). In a governmental obligation action, the administrative record may be augmented by additional evidence to the extent the court may direct. In addition, the court may, upon the basis of evidence presented, make findings of fact that differ from the administrative record. T.C. Rule 217(b).


**35.2.2.9.1** **(09-24-2012)**

#### Answers in EP Declaratory Judgment Cases

01. Prior to preparing an answer in a declaratory judgment case, the attorney should ascertain that the Tax Court has jurisdiction. One of the most important jurisdictional prerequisites is the exhaustion of administrative remedies. See _Thompson v. Commissioner_, 71 T.C. 327 (1978).

02. In some cases a petition will be filed because the Service has failed to make a timely final determination. In these cases, coordination with the Division Counsel/Associate Chief Counsel (TEGE) will be necessary, so that all grounds supporting a determination adverse to the petitioner can be raised in the answer. If no determination has been requested, a motion to dismiss for lack of jurisdiction should be filed.

03. The answer in a declaratory judgment action will differ in one important respect from that filed in a deficiency case: it must contain a complete index to the administrative record as defined in T.C. Rule 210(b)(12). See Exhibit 35.11.1-27, Declaratory Judgment Case: Employee Plans (Stipulated Administrative Record). This index generally will not have been prepared during the administrative processing of the case and the attorney must personally prepare a complete and accurate index. The task of preparing or verifying the index may be time consuming and should be commenced at an early stage in the preparation of the answer. It should never be delegated to support staff. Particular care should be take to assure that the index contains only the material described in Rule 210(b)(12) does not include internal Service documents containing the mental impressions, conclusions, and reasoning of Service personnel.

04. Pursuant to T.C. Rule 212, in a revocation case there shall be filed with the answer a statement setting forth the date on which it is anticipated the case will be ready for submission to the court.

05. T.C. Rule 213(a)(2) permits facts, other than jurisdictional facts and facts involved in a revocation, to be admitted by respondent for purposes of the pending action for declaratory judgment only, and answers should be so drafted. This should be done in retirement plan declaratory judgment answers. The facts admitted should be limited to those contained in the administrative record. See Exhibit 35.11.1-27, Declaratory Judgment Case: Employee Plans (Stipulated Administrative Record), and Exhibit 35.11.1-28, Declaratory Judgment Case: Employee Plans (Administrative Record Submitted Unagreed). Where facts alleged in the petition were never presented to the Service in support of the request for the determination and are not, therefore, contained in the administrative record, the answer should be neither admits nor denies on the grounds that the allegations are not a part of the administrative record and thus not cognizable by the court. In some instances, consideration should be given to filing a motion to strike pursuant to T.C. Rule 52, although the better practice almost always is to answer rather than move with respect to the petition. If a petition alludes to material not part of the administrative record, the answer should state that respondent denies for lack of knowledge, and that the referenced material cannot be considered by the court because the material is not part of the administrative record. Under T.C. Rule 217(a), facts outside the administrative record will not be considered by the court except under limited and unusual circumstances. See _Houston Lawyer Referral Service, Inc. v. Commissioner_, 69 T.C. 570 (1978).

06. Declaratory judgment cases should be handled very carefully. Even though they are nondeficiency cases, they have wide-ranging application and in many instances, enormous economic impact for affected persons, organizations, and the U.S. Treasury. Field attorneys should not hesitate to seek assistance from the appropriate Associate office if they have questions not answered by this section.

07. It is essential that any additional grounds supporting the determination or revocation be raised in the answer. Immediately upon receipt of a declaratory judgment action, an examination of the case should be made to determine whether there are additional grounds supporting respondent’s determination to be raised in the answer. Assistance and advice from the Division Counsel/Associate Chief Counsel (TEGE) may be needed to determine the existence of any additional grounds. Many of these cases will involve unfamiliar, difficult and novel issues which will require substantial time to review. Some issues will require extensive coordination with the Labor Department through its national office. To facilitate this coordination, examination of the administrative file should not be put off until the end of the answer period. This is important because if new grounds are raised in the answer, respondent may assume the burden of proof for those grounds. This should pose no problem in the usual case, in which a new issue is purely legal and the relevant information is already in the administrative record. See _BBS Associates, Inc v. Commissioner_, 74 T.C. 1118, 1121–1122 (1980). As the court’s review of any determination letter case is limited to the existing administrative record, there must be existing factual support in the record for any new ground raised in the answer.

08. Under T.C. Rule 213(b), a reply is required in every declaratory judgment action and when a reply is not filed, affirmative allegations in the answer will be deemed admitted. As the administrative record is due 30 days after the answer and the mandatory reply is due 60 days after the answer, a motion to extend the time within which to file the administrative record may be appropriate.

09. For purposes of the declaratory judgment action, the Service will accept as true the facts presented by the organization during the administrative determination procedure. Generally, therefore, there will be no need for a stipulation conference to determine which documents are part of the administrative record. The administrative record is composed of items contained in the administrative file only, and only those items exchanged between the parties are to be included in the administrative record. Only documents that are a part of the record (and the facts derived from. those documents) are subject to stipulation. Objection should be made to the admission of any document which is not part of the administrative record and the finding of any fact which is not supported by that record. In those cases in which grounds supporting the Commissioners’ determination or revocation are alleged for the first time in the answer, petitioner will be permitted to introduce evidence not already in the record to supports its position that the Commissioner’s determination is in error. In most instances, it will be possible to stipulate to those additional documents.

10. Stipulation of the administrative record should occur within 30 days after service of the answer. See Exhibit 35.11.1-27, Declaratory Judgment Case: Employee Plans (Stipulated Administrative Record). If an agreement has been reached but the stipulation is not ready for filing within the 30-day period prescribed by T.C. Rule 217(b), a motion to extend the time for submission must be filed. See Exhibit 35.11.1-69, Declaratory Judgment Case: Motion to Extend Time Within Which to Stipulate as to Administrative Record. When the answer is filed, the attorney should consider forwarding a copy of a proposed stipulation to petitioner so that any disagreements can be worked out before the expiration of the 30-day period. If the parties are unable to file a stipulated administrative record, the Service must file the entire record with a Notice of Filing of the Administrative Record and a Commissioner’s Certificate as to the Genuineness of the Entire Administrative Record between 30 and 45 days after the service of the answer. Accordingly the entire administrative record must be segregated from the remainder of the administrative file and kept available for inspection (and copying if necessary). See CCDM 35.4.7.6(3), Effect of Stipulation, for guidance on preparing and assembling the administrative record.

11. The administrative record in both initial qualification and revocation cases is defined in T.C. Rule 210(b)(12) to comprise all documents submitted to the Service by petitioner in support of its request for determination, all written correspondence between the Service and petitioner, all pertinent returns and notices of determination. The administrative record closes at the moment the final adverse determination letter or revocation letter is mailed. Where a petition is filed by an employer, plan administrator, or interested party prior to the issuance of a final letter, the administrative record closes on the date the petition is filed.

12. If either the petitioner or the respondent moves for a stay before the answer is filed, the motion or response, as appropriate, should include a request that respondent be allowed a full 60 days following termination of the stay within which to file the answer.


**35.2.2.9.2** **(09-24-2012)**

#### Answers in Exempt Organization Declaratory Judgment Cases

01. When declaratory judgment petitions involving exempt status are served on the Chief Counsel, those cases in which determination or revocation letters have been issued will be assigned to the appropriate Counsel office. Those cases in which final adverse determination letters have been issued by the Commissioner (TEGE) will be assigned to the Division Counsel/Associate Chief Counsel (TEGE). See CCDM 35.2.1.1.15.2(3), (4), Initial Review of EO Declaratory Judgment Cases, The outside cover of the legal file jacket will contain the permanent stamped designation, Declaratory Judgment Case.

02. Immediately upon receipt of a declaratory judgment case, a request for the complete administrative file should be addressed to the office that issued the determination, revocation, or ruling letter. Upon receipt of the file, the attorney should immediately examine the petition and file to determine whether there are jurisdictional questions which should be raised by motion.

03. If the petition arises from a revocation for a year for which a deficiency could be assessed, the attorney should ensure that consents for extending the statute of limitations are obtained. The declaratory judgment is limited to the issue of qualification or classification. Tax liability will never be an issue in a declaratory judgment action. The three-year statute of limitation generally starts to run at the time an organization, believing in good faith that it is exempt, files a return or, if the return was filed before due, then the due date.

04. The petition must be filed before the 91st day after the date of certified mailing of the final adverse determination letter. IRC § 7428(b)(3). If the petition is untimely, a motion to dismiss for lack of jurisdiction should be filed. Pursuant to T.C. Rule 211(b), every petition shall be entitled Petition for Declaratory Judgment (Exempt Organization). The petition shall contain all of the items enumerated in T.C. Rule 211(g). If the petition does not contain a copy of the final adverse determination letter, respondent’s answer should contain an appropriate allegation and a copy of the letter should be attached. Similarly, where the petition does not allege exhaustion of administrative remedies, respondent’s answer should contain such an allegation, if appropriate.

05. It is essential that any additional grounds supporting the determination, revocation, or ruling be raised in the answer. Immediately upon receipt of a declaratory judgment action, an examination of the case should be made to determine whether there are additional grounds supporting respondent’s determination which should be raised in the answer. Assistance and advice from the Exempt Organizations Division of the Division Counsel/Associate Chief Counsel (TEGE) may be needed to determine the existence of any additional grounds. Many of these cases will involve unfamiliar, difficult, and novel issues which will require substantial time to review. To facilitate this coordination, examination of the file should not be put off until the end of the answer period. This is important because if new grounds are raised in the answer, respondent may assume the burden of proof as to those grounds. This should pose no problem in the usual case where the new issue is purely legal and the relevant factual data is already in the administrative record. Under T.C. Rule 213(b), a reply is required in every declaratory judgment action and, when a reply is not filed, affirmative allegations in the answer will be deemed admitted.

06. In some cases a petition will be filed because the Service has failed to reach a determination. In these cases, coordination with the Exempt Organizations Division of the Division Counsel/Associate Chief Counsel (TEGE) will be necessary so that all grounds supporting a determination adverse to the petitioner can be affirmatively raised in the answer. If no ruling has been requested, a motion to dismiss for lack of jurisdiction is proper.

07. Pursuant to T.C. Rule 212, in a revocation case there shall be filed with the answer a statement setting forth the date on which it is anticipated the case will be ready for submission to the Court.

08. In initial qualification or classification cases, frequently a petition will allege facts not contained in the administrative record or will attempt to argue the legal effect of facts whether or not contained in the administrative record. In such instances, a motion to strike the allegations on the ground of not being contained in the administrative record or as being argumentative in nature, as the case may be, may be considered. In most situations, however, and particularly where the organization is not represented by counsel, the better practice is for respondent to answer, rather than move, in the following manner as required by the allegations of the petition:



    1. Neither admits nor denies the allegation on the ground it deals with facts not part of the administrative record and thus not cognizable by the court.

    2. Denies the allegation on the ground it is argumentative in nature and not a fact in the administrative record.


09. Other considerations include:



    1. Under IRC § 7428(a), the threshold requirement for the Tax Court to acquire jurisdiction is that the suit involve an actual controversy over the Commissioner’s determination or lack thereof with respect to the initial or continuing qualification of an organization as exempt under IRC § 501(c)(3) or IRC § 170(c)(2); a private foundation under IRC § 509(a); or a private operating foundation under IRC § 4942(j)(3). For an actual controversy to exist the Commissioner’s determination or failure to make such a determination must bring about one of the specified adverse consequences. See _Urantia Foundation v. Commissioner_, 684 F.2d 521 (7th Cir. 1982).

    2. The Tax Court has ruled that an actual controversy exists if the Commissioner determines that an applicant is a nonprivate foundation under a provision other than the one raised in the application. _Friends of the Society of the Servants of God v. Commissioner_, 75 T.C. 209 (1980).

    3. A ruling letter that concludes that a proposed transaction would jeopardize petitioner’s existing exempt status is not a determination within the meaning of IRC § 7428(a)(1). _New Community Senior Citizen Housing Corp. v. Commissioner_, 72 T.C. 372 (1979).

    4. Similarly, if a petitioner agrees to modify its activities in response to a proposed adverse ruling and subsequently receives a wholly favorable ruling, the court cannot consider the effect of the unmodified activities on exempt status because no final ruling was issued with respect to those activities. _AHW Corporation v. Commissioner_, 79 T.C. 390 (1982).

    5. IRC § 7428 also requires that an organization must exhaust its administrative remedies by timely taking all reasonable steps to secure a determination. These requirements are filing a substantially complete Form 1023, Application for Recognition of Exemption Under Section 501(c)(3) of the Internal Revenue Code, or private foundation determination request, and timely submitting all additional information requested by the Service, and exhausting all administrative appeals available within the Service. Treas. Reg. § 601.201(n)(7)(iv).

    6. An organization is not to be deemed to have exhausted its administrative remedies merely because the Service has failed to make a determination before the 270th day following the request for such determination. The 270-day period of IRC § 7428(b)(2) is a minimum time period, enabling the Service to consider ruling requests without judicial interference. The Tax Court has held that in revocation cases, the 270-day period begins when the organization protests the Service’s proposed adverse ruling. _Gladstone Foundation v. Commissioner_, 77 T.C. 221 (1981). If a delay is caused by petitioner’s unresponsiveness or if the administrative procedure is still actively in process, petitioner may not have exhausted its administrative remedies. The exhaustion requirement ensures that the administrative record will be as nearly complete as possible.


10. Declaratory judgment cases dealing with final adverse determination letters will normally be submitted fully stipulated under T.C. Rule 122. T.C. Rule 217(b) requires efforts by the parties to stipulate the pertinent portions if not all of the administrative record within 30 days after service of the answer. Accordingly, the entire administrative record should be segregated from the remainder of the administrative file and kept available for inspection (and copying if necessary) by the petitioner or petitioner’s counsel at reasonable times in the office that is handling the case.

11. At the time the answer is filed, a letter should be mailed to the petitioner or petitioner’s counsel proposing a conference for purposes of stipulating to the administrative record. A copy of the index as attached to the answer should be attached, with the statement that the index reflects respondent’s view of what should be considered as constituting the administrative record. The conference should be scheduled for a date not later than two weeks after the mailing of the answer. The letter should also state that the entire administrative record will be made available for inspection in the office prior to the proposed conference and will remain available throughout the 30-day period following the date of service of the answer. If distance makes a conference problematic, the proposed stipulation and proposed administrative record should be mailed to the petitioner or the petitioner’s counsel as an enclosure to the letter. The petitioner or petitioner’s counsel should be asked to sign the stipulation and return it or to contact the attorney if there are any problems with the materials. See Exhibit 35.11.1-27, Declaratory Judgment Case: Employee Plans (Stipulated Administrative Record).

12. If the parties agree on what documents constitute the administrative record, the parties can then stipulate to the entire administrative record. _See_ T.C. Rule 210(b)(10) for a definition of what constitutes the administrative record. Parties may stipulate that some documents although part of the administrative record can be eliminated from the record because they are duplicates, _e.g._, the petitioner faxes in a document and then sends in the same document. If the parties agree upon what constitutes the administrative record, but not on the portions that are pertinent, the entire administrative record should be stipulated entitled Stipulation as to the Administrative Record since, in the absence of a stipulation, respondent is required to file with the court the entire administrative record, appropriately certified as to its genuineness. T.C. Rule 217(b)(1). _See_ CCDM 35.2.2.9(8). T.C. Rule 210(b)(11) contemplates the filing of the original papers constituting the administrative record rather than copies thereof. If the parties are unable to agree upon what constitutes the administrative record, the respondent should submit the record with a Notice of Filing of the Administrative Record. File the original plus two copies of the Stipulation or Notice. See CCDM 35.4.7.6(3), Effect of Stipulation, for guidance on preparing, assembling and stipulating to the administrative record.

13. As soon as the case is at issue, that is, upon the filing of the reply or at the expiration of the time for doing so (T.C. Rule 214), a joint motion to submit the case under Rule 122 should be submitted to petitioner or petitioner’s counsel for execution, unless it appears that the issues cannot be resolved solely on the basis of the administrative record. Unless the case involves unusually difficult technical problems, the joint motion should request that briefing dates be fixed in accordance with Rule 151. Since the parties will usually be fully aware of each other’s positions on the issues, simultaneous briefs should ordinarily be requested.

14. If the petitioner refuses to stipulate to the administrative record or declines to submit the case under Rule 122, a Motion for Order to Show Cause Why Case Should Not Be Submitted on the Administrative Record as Provided in T.C. Rule 217 should be filed, but not until petitioner’s time to reply has expired. See Exhibit 35.11.1-70, Declaratory Judgment Case: Motion for Order to Show Cause Why Case Should Not Be Submitted on Administrative Record as Provided in T.C. Rule 217.

15. The preparation of respondent’s brief in a declaratory judgment case should ordinarily commence prior to the submission of the case. Since there will rarely be a trial, the relevant facts will be fixed and determinable at the time the petition is filed. An early start in the actual writing of the brief will facilitate the early detection of any problems which may require advice and will also assist the attorney in determining whether normal briefing times will be adequate by the time the joint motion for submission is prepared.

16. Pursuant to T. C. Rule 215(c), joinder of parties is not permitted in IRC § 7428 declaratory judgment actions. Consolidation under T.C. Rule 141 is not prohibited, however. Rule 141 permits the court to order a joint hearing of any common questions of law or fact; orders of this kind may be made by the court if they tend to prevent unnecessary costs, delays, or duplication. The decision whether respondent should move for consolidation in IRC § 7428 actions will have to be made on a case-by-case basis. It can be expected that consolidation requests in these cases will be rare.


**35.2.2.9.3** **(09-24-2012)**

#### Answer in Government Obligation Declaratory Judgment Cases

01. Authority to issue final adverse determination letters regarding whether issues of governmental obligations will be described in IRC § 103(a) is vested in the Division Counsel/Associate Chief Counsel (TEGE).

02. When declaratory judgment petitions involving governmental obligations are served on the Chief Counsel, they will be assigned to the Division Counsel/Associate Chief Counsel (TEGE) office. The outside cover of the legal file jacket will contain the permanent stamped designation, Declaratory Judgment Case. Because cases arising under IRC § 103 arise infrequently and may have enormous economic impact for affected persons, the office that prepared the adverse ruling will have significant involvement in the litigation of the case.

03. Immediately upon receipt of a declaratory judgment case, the assigned attorney should request the complete administrative file from the office and/or attorney that prepared the adverse ruling. Upon receipt of the administrative files, the attorney should immediately examine the petition and file to determine whether there are jurisdictional questions which should be raised by motion. _See_ T.C. Rules 210(c) and 211(e); _see, e.g._, Rev. Proc. 96-16, 1996-1 C.B. 630. T.C. Rule 213 allows 45 days from the date of service of the petition within which to file a motion with respect to the petition.

04. The petition must be filed before the 91st day after the date of mailing, by certified or registered mail, of the adverse determination letter. IRC § 7478(b)(3). Pursuant to T.C. Rule 211(b), each petition arising out of a ruling under IRC § 103 will be entitled Petition for Declaratory Judgment (Governmental Obligation). The attorney should verify that the petition contains all of the items enumerated in T.C. Rule 211(e). If the petition does not contain a copy of the final adverse determination letter, respondent’s answer should contain an appropriate allegation and a copy of the letter should be attached.

05. Under IRC § 7478(a), the threshhold requirement for the court to acquire jurisdiction is that the suit involves an actual controversy. To meet this requirement in part, the petition must allege that the prospective issuer of governmental obligations described in IRC § 103(a) has adopted an appropriate resolution in accordance with State or local law authorizing the issuance of such obligations. T.C. Rule 211(e)(3).

06. IRC § 7478(b)(2) requires that a petitioner exhaust its administrative remedies. A petitioner will not be deemed to have exhausted its administrative remedies regarding whether prospective obligations are described in IRC § 103(a) before the expiration of 180 days after the request for a determination was made and sufficient facts were provided for making such a determination. Note that the 180-day limit for making a determination regarding governmental obligations differs from the other ruling period limits discussed in this chapter. The exhaustion requirement ensures that the administrative record will be as nearly complete as possible. A motion to dismiss for failure to exhaust administrative remedies is proper in the event of the filing of a petition prior to the expiration of 180 days.

07. Joinder of parties in a governmental obligation action is not permitted. T.C. Rule 215(c).

08. As with other declaratory judgment cases, the answer in a governmental obligation must contain a complete index to the administrative record as defined in T.C. Rule 210(b)(12). See, _e.g._, Exhibit 35.11.1-27, Declaratory Judgment Case: Employee Plans (Stipulated Administrative Record). This index generally will not have been prepared during the administrative processing of the case and the attorney must personally prepare a complete and accurate index. The task of preparing or verifying the index may be time consuming and should be commenced at an early stage in the preparation of the answer. See CCDM 35.4.7.6(3), Effect of Stipulation, for guidance on preparing and assembling the administrative record.

09. Unlike some other declaratory judgment cases, T.C. Rule 213(a)(2) does not permit facts in a governmental obligation action to be admitted by respondent for purposes of the pending action for declaratory judgment only.

10. As with other declaratory judgment cases, stipulation of the administrative record should occur within 30 days after service of the answer. T.C. Rule 217(b)(1); see Exhibit 35.11.1-27, Declaratory Judgment Case: Employee Plans (Stipulated Administrative Record). If agreement has been reached but the stipulation is not ready for filing within the 30-day period prescribed by T.C. Rule 217(b), a motion to extend the time for submission must be filed. See Exhibit 35.11.1-69, Declaratory Judgment Case: Motion to Extend Time Within Which to Stipulate as to Administrative Record. When the answer is filed, the attorney should consider forwarding a copy of a proposed stipulation to petitioner so that any disagreements can be worked out before the expiration of the 30-day period. If the parties are unable to file a stipulated administrative record, the Service must file the entire record with a Notice of Filing of the Administrative Record and a Commissioner’s Certificate as to the Genuineness of the Entire Administrative Record between 30 and 45 days after the service of the answer. T.C. Rule 217(b)(1); see Exhibit 35.11.1-28, Declaratory Judgment Case: Employee Plans (Administrative Record Submitted Unagreed). See CCDM 35.4.7.6(3), Effect of Stipulation, for guidance on the preparation of and stipulation to the administrative record.

11. Respondent is required by T.C. Rule 212 to file a separate statement with the answer setting forth the date on which respondent expects the action will be ready for submission to the court and an estimate of the time required for trial. This requirement is unique to governmental obligation declaratory judgment actions. From experience, a minimum of four months will be required before a case can be prepared for submission. More complex cases may require the gathering of data to support some assertions made in the ruling letter and four months may be insufficient. No case to date has required trial, but this possibility exists more so with governmental obligation actions than with the other declaratory judgment actions. Therefore, a generous estimate of the length of trial is three days. It is permissible to advise the Tax Court by a Rule 122 motion that no trial is required and that the case is being submitted fully stipulated. See CCDM 35.4.7.6(3), Effect of Stipulation.

12. In a governmental obligation action, the administrative record may be augmented by additional evidence to the extent the court may direct. In addition, the court may, upon the basis of evidence presented, make findings of fact that differ from the administrative record. T.C. Rule 217(b).


**35.2.2.9.4** **(08-11-2004)**

#### Answers in Worker Classification Cases under Section 7436

1. The general instructions for answering deficiency cases in CCDM 35.2.2 apply in answering these cases. Unlike declaratory judgment cases, no administrative record is involved in these proceedings. See CCDM 35.2.1.1.15.4, Initial Review of Worker Classification Cases under Section 7436, for further information and assistance on the required statutory elements for a petition in this kind of proceeding.


**35.2.2.10** **(08-11-2004)**

### Answers in Gift Valuation Cases

1. The Tax Court is authorized to issue declaratory judgments with regard to an actual controversy involving a determination by the Service of the value of any gift effective for gifts made after August 5, 1997. _See_ IRC § 7477 as enacted by section 506(c) and (e) of the Taxpayer Relief Act of 1997 (the 1997 Act), Pub.L. No. 105–34. The Tax Court has adopted amendments to Title XXI of its Rules of Practice and Procedure for declaratory judgment actions under IRC § 7477. IRC § 7477 was designed to permit judicial review in circumstances in which the Commissioner has made a redetermination of value with respect to the gift that does not result in a deficiency for the calendar year. Cases arising under IRC § 7477 should be coordinated with the appropriate Associate office.

2. Historically, courts have permitted the Commissioner to redetermine the value of a gift for which the statute of limitations period has expired in order to determine the appropriate tax bracket and unified credit for the estate tax. Congress has legislatively altered this judicial practice. Gifts may not be revalued for estate tax purposes after the expiration of the statute of limitations applicable to the gift for gift tax purposes. _See_ section 506(a) of the 1997 Act. It should be noted, however, that the statute of limitations will not run on an inadequately disclosed transfer.

3. In order to revalue a gift that has been adequately disclosed on a gift tax return, the Service must issue a final notice of redetermination of value (a final notice) within the statute of limitations applicable to the gift for gift tax purposes (generally, three years). This limitations period is applicable even where the value of the gift as shown on the return does not result in any gift tax liability for the calendar year ( _e.g._, through the use of the unified credit). A taxpayer will be able to challenge a redetermination of value prior to the Service’s issuance of a final notice through an administrative appeals process. Upon the mailing of a final notice of redetermination of value, a taxpayer may challenge the redetermination by filing a petition for a declaratory judgment with the Tax Court. The petition must be filed on or before 90 days from the date that the final notice was mailed. _See_ section 506(c) of the 1997 Act; H.R. Rep. No. 148, 105th Cong., 1st Sess. 359-60 (1997); and H.R. Conf. Rep. No. 220, 105th Cong., 1st Sess. 408 (1997).


**35.2.2.11** **(04-11-2013)**

### Answers in Failure to Pay (Section 6651(a)(2) Cases With a Return Made under Section 6020(b))

1. IRC § 6651(a)(2) authorizes the imposition of an addition to tax where, without reasonable cause, a taxpayer fails to pay the amount shown as tax shown as due on a return on or before the payment due date. Prior to the enactment of IRC § 6651(g), no comparable failure to pay penalty applied to taxpayers who did not file a return. Recognizing the inequity of imposing the failure to pay penalty on filers but not on nonfilers, Congress enacted IRC § 6651(g). IRC § 6651(g)(2) provides that, for returns due after July 30, 1996, a IRC § 6020(b) return will be treated as a return filed by the taxpayer for purposes of determining the IRC § 6651(a)(2) addition to tax. _See_ Taxpayer Bill of Rights 2, Pub. L. 104-168, § 1301(a), 110 Stat. 1452 (July 30, 1996).

2. IRC § 6020(b)(1) authorizes the Secretary to make a return upon either a taxpayer’s failure to file a return or upon a taxpayer’s filing of a fraudulent return. The Tax Court clarified what constitutes a return under IRC § 6020(b) for purposes of the addition to tax under IRC § 6651(a)(2) in _Cabirac v. Commissioner_, 120 T.C. 163 (2003), and _Spurlock v. Commissioner_, T.C. Memo. 2003-124. In _Spurlock_, the Tax Court held that a return for IRC § 6020(b) purposes must be "subscribed, it must contain sufficient information from which to compute the taxpayer’s tax liability, and the return form and any attachments must purport to be a ‘return’." _Spurlock_, slip. op. at 27. In _Cabirac_, the documents the Service proffered as constituting a IRC § 6020(b) return were (a) dummy Forms 1040 that identified the taxpayer, but which were not signed and did not show any tax due, (b) a subsequently prepared 30-day letter, and (c) a revenue agent’s report attached to the 30-day letter explaining how the Service computed the taxpayer’s liability. Applying the analysis later explained in _Spurlock_, the Tax Court held that these documents did not constitute a IRC § 6020(b) return. Critical to the Tax Court’s analysis was that the Service never treated the documents, which the Service created at various times, as one group purporting to be a return. See _Millsap v. Commissioner_, 91 T.C. 926 (1988), _acq. in result in part_, 1991-2 C.B. 1, where various documents were grouped and treated as a valid IRC § 6020(b) return.

3. To satisfy each of the elements of IRC § 6020(b) and to defend the 6651(a)(2) addition to tax when a return is prepared under IRC § 6020(b), Counsel will need a Form 13496 package consisting of (1) a signed and dated Form 13496, IRC Section 6020(b) Certification, (2) a Report summarizing Examination changes or an equivalent report of adjustments, and (3) a Form 886-A, Explanation of Items, appropriate lead sheet or similar form. The forms attached to the Form 13496 must be generated on or before the date that the Form 13496 was signed, and should contain the information necessary to calculate the taxpayer’s liability for the period and the amount of the failure-to-pay addition to tax. In lieu of a Form 13496 package, Counsel may use an Automated Substitute for Return (ASFR) Certification package consisting of (1) a Letter 2566, 30 Day Proposed Assessment (SFR-01) 910, which includes the taxpayer’s name, identification number and sufficient information to compute the taxpayer’s liability, and (2) a certification (the IRC 6020(b) ASFR Certification) certifying that the electronic data in the taxpayer’s account on IDRS constitutes a valid 6020(b) return as of that date.



1. Treas. Reg. § 301.6020-1 provides that the IRC § 6020(b) return can be signed either by hand or through automated means. The name and title of an internal revenue officer or employee appearing on a IRC § 6020(b) return suffices as a subscription adopting the document as the taxpayer’s return, whether the officer’s or employee’s name or title is handwritten, stamped, typed, printed, or otherwise mechanically affixed to the document, so long as the name was placed on the document to signify that the employee or officer adopted the document as a return for the taxpayer. The document, or set of documents, and signature may be in written or electronic form. Treas. Reg. § 301.6020-1(b)(2).

2. Whenever relying on automated or electronic certification or subscription of a IRC § 6020(b) return, a citation to Treas. Reg. § 301.6020-1 should be included in the pleading or other legal documents.


4. The contacts for obtaining Form 13496 package documentation or ASFR Certification package documentation differ depending on the type of IRC § 6020(b) return involved. The first step is to determine whether an ASFR Certification or a Form 13496 was prepared. The answer will be evident from the administrative file or a transcript of the taxpayer’s account. If TC 494 appears on the transcript, an ASFR Certification was most likely, but not invariably, prepared. The return could have been incorrectly coded on the account. If the transcript shows "SFR" at the far right on the TC 150 line or shows a TC 420 or 424 followed by "SPCL-PROJ>0277," then a Form 13496 was prepared.

5. ASFR Certifications are generated electronically and archived for seven years. The system on which the returns are stored allows certain Service personnel in any of the campuses that prepare ASFR Certifications to access any archived ASFR Certification. To obtain an ASFR Certification, Counsel should contact the persons identified in the "ASFR Contacts" link under the "Who/Where" tab in the Servicewide Electronic Research Program (SERP). The employees identified there are only able to provide information on ASFR Certifications and do not have access to returns prepared on Form 13496.

6. Forms 13496 are prepared either electronically or manually by Examination personnel. The campus where a return was prepared may be able to provide documentation of the return when all or part of a Form 13496 package is not in the file. Counsel can request a copy of the missing records by completing a Form 2275, Records Request, Charge and Recharge. The Form 2275 should be sent to the originating campus, which is designated on the lower right-hand portion of the Form 13496, if available, and by the first two digits of the Document Locator Number (DLN) of the administrative file (the control DLN) (a key can be found at section 4-3 of Document 6209, IRS Processing Codes and Information). The DLN can also be obtained through IDRS.



1. The Form 2275 should be signed by the requesting attorney. If multiple Forms 2275 are being mailed to a particular campus, the requests should be ordered by year and DLN.

2. Obtaining the documentation could be difficult as well as time-consuming and may not be possible in some cases. Form 13496 documentation is likely to be less readily available than ASFR documentation. If, despite best efforts, the documentation cannot be obtained in time to meet litigation deadlines, the IRC § 6651(a)(2) addition to tax should be conceded.


7. The IRC § 6020(b) return must be placed into evidence to satisfy the Service’s burden of production under IRC § 7491(c). The IRC § 6020(b) return may be introduced in a number of ways. The simplest way is by stipulation of the parties, and, if necessary, through a motion to compel stipulation pursuant to T.C. Rule 91(f). If a motion for summary judgment or other dispositive motion is filed, the IRC § 6020(b) return should accompany the motion as an exhibit to an affidavit or declaration authenticating the IRC § 6020(b) return. At trial, the IRC § 6020(b) return may be offered into evidence through a witness who is qualified to testify that it was made and kept in the course of the Service’s regularly conducted business activities. In the alternative, the return may be introduced as a record of a regularly conducted activity under Fed.R. Evid. 803(6) without a witness through an affidavit or declaration of the custodian or other qualified person ( _e.g._, a revenue agent who can explain how the record was made) prepared pursuant to the requirements of Fed. R. Evid. 902(11). Notice of intent to use this procedure and access to the affidavit or declaration and underlying record are required to give the opposing party an opportunity to test the adequacy of the foundation prior to trial. See _Clough v. Commissioner_, 119 T.C. 183 (2002); _Spurlock v. Commissioner_, T.C. Memo. 2003-124.

8. The Office of Chief Counsel will concede the IRC § 6651(a)(2) addition to tax where it cannot submit into evidence a valid IRC § 6020(b) return. If it is necessary to concede the IRC § 6651(a)(2) addition to tax, attorneys should seek to increase the IRC § 6651(a)(1) addition to tax. Ordinarily, the amount of the failure to file addition to tax is 5 percent of the amount required to be shown as tax if the failure is for not more than one month, with an additional 5 percent for each additional month or fraction thereof during which such failure continues, for no longer than 5 months. Under IRC § 6651(c)(1), the 5 percent determined under IRC § 6651(a)(1) is reduced by the amount of the addition to tax under IRC § 6651(a)(2) to 4.5 percent for any month in which both additions are imposed. Therefore, when the IRC § 6651(a)(2) addition is conceded, the failure to file addition to tax should be set at the 5 percent rate per month, instead of the 4.5 percent per month that applied when the Service determined the IRC § 6651(a)(2) addition to tax. This increase should be alleged in the answer.

9. Deviations from these procedures must be approved in advance by Division Counsel and the Associate Chief Counsel (P&A). For further guidance on IRC § 6020(b) returns, please contact the Associate Chief Counsel (P&A), Branches 1 or 2 to coordinate respondent’s position in the case. For questions about introducing proof of IRC § 6020(b) returns into evidence, contact the Associate Chief Counsel (P&A), Branches 6 or 7.


**35.2.2.12** **(08-11-2004)**

### Answers in Cases Where Petitioners Seek Relief from Joint and Several Liability

1. The following subsections address pleading and notification requirements in cases where petitioners are seeking relief from joint and several liability.


**35.2.2.12.1** **(08-11-2004)**

#### Petition for Review

1. IRC § 6015 provides three avenues of relief from joint and several liability under IRC § 6015(b), (c), and (f). IRC § 6015(b) allows taxpayers who have filed joint income tax returns relief from joint and several liability under certain circumstances. IRC § 6015(c) provides taxpayers who meet certain threshold marital requirements the opportunity to limit their liability by electing to allocate the deficiency. IRC § 6015(f) allows the Secretary to grant relief when, taking into account all of the facts and circumstances, it is inequitable to hold the individual liable and relief is unavailable under IRC § 6015(b) or (c). _See also_ Rev. Proc. 2000-15, 2000-1 C.B. 447. IRC § 6015(e) confers jurisdiction upon the Tax Court to review the Secretary’s determinations under IRC § 6015. The Tax Court reviews the Secretary’s determinations under IRC § 6015(b) and (c) de novo and determinations under IRC § 6015(f) for an abuse of discretion.


**35.2.2.12.2** **(08-02-2022)**

#### Notification of Nonpetitioning Spouse

1. **General Requirements**. In accordance with T.C. Rule 325, the attorney, on or before 60 days from the date of service of a petition raising relief from joint and several liability under IRC § 6015, must serve notice of the filing of the petition on the other individual filing the joint return (Notice of Filing of Petition and Right to Intervene). In addition, T.C. Rule 325 requires the attorney to simultaneously file with the court a copy of the notice with an attached certificate of service. As with all court filings, the attorney should also serve a copy of the Notice on the petitioner. The Notice shall advise the other individual of the right to intervene by filing a notice of intervention with the court not later than 60 days after the date of service on the other individual. The other individual may intervene to challenge or support the petitioning individual’s entitlement to relief. If a petitioner raises a claim for relief from joint and several liability after filing the petition from a notice of deficiency where the other individual is not a joint petitioner in the case, the attorney should send the Notice to the other individual as soon as possible so that the 60-day intervention period expires prior to calendar call. See Exhibit 35.11.1-29 ,Notice of Filing of Petition and Right to Intervene, and Exhibit 35.11.1-30, Notice of Filing of Petition and Right to Intervene (Deceased Nonpetitioning Spouse). If both individuals filing the joint return have filed a joint petition from a statutory notice of deficiency, no Notice of Filing of Petition and Right to Intervene is required.

2. **Specific Instructions**. In all cases (including "S" cases) the attorney should file and serve the Notice of Filing of Petition and Right to Intervene in the following manner:



1. The Notice should be mailed to the nonpetitioning spouse and should include only a certificate of service with the nonpetitioning spouse’s address.

2. A copy of the Notice should be mailed to the petitioner and should include only a certificate of service with the petitioner’s address.

3. A copy of the Notice should be filed with the Court with copies of both certificates of service sent to the respective spouses attached.

4. Care should be taken to ensure that the separate certificates of service are properly attached to the respective service copies of the Notice in order that address information of each spouse is not disclosed to the other.

5. A cover letter and a copy of T.C. Rule 325 should be sent with the Notice to the nonpetitioning spouse. See Exhibit 35.11.1-29, Notice of Filing of Petition and Right to Intervene.

6. The Notice of Filing of Petition and Right to Intervene may be eFiled and served electronically to the extent permitted by T.C. Rules 23 and 26, and the Tax Court’s eFiling Instructions on the Tax Court’s web site at www.ustaxcourt.gov.


3. **Jurisdictional Defects**. If the attorney determines that there is a jurisdictional defect in the case and files a Motion to Dismiss for Lack of Jurisdiction within 60 days of the date of service of the petition, the attorney may defer notification of the nonpetitioning spouse of the claim for relief from joint liability until the jurisdictional motion is filed and ruled upon by the court. The motion should contain a statement that the nonpetitioning spouse has not been notified of the claim for relief pending the court’s resolution of the jurisdictional motion. If the court denies the jurisdictional motion, the attorney should serve the Notice of Filing of Petition and Right to Intervene on the nonpetitioning spouse as soon as possible.

4. **Defective Notification**. If the notification to the nonpetitioning spouse is returned with a notation of undeliverable or incorrect address, the attorney should attempt to find a more recent/correct address and then resend the Notice. In many cases, the original notice may be resent, without restarting the 60-day intervention period or recertifying the notification to the Tax Court. In cases in which there are less than 30 days remaining in the intervention period, it is recommended that a second notice be sent with a new intervention period commencing on the date of the second notice. In determining whether to restart the 60-day intervention period, the facts and circumstances of the case should be considered, including, but not limited to, the following: whether the original notice was sent to the nonpetitioning spouse’s last known address, how many days remain in the intervention period, and how many days remain prior to the calendar call.

5. **Deceased Nonpetitioning Spouse**. In cases in which the nonpetitioning spouse is deceased, the attorney should serve the personal representative of the nonpetitioning spouse’s estate with the Notice of Filing of Petition and Right to Intervene. If an estate has not been probated or administered there will be no personal representative to serve the notice upon. Instead, a Notice of Filing of Petition And Right to Intervene stating the reasons why the nonpetitioning spouse was not notified should be filed with the court and served on the petitioner. See Exhibit 35.11.1-30, Notice of Filing of Petition and Right to Intervene (Deceased Nonpetitioning Spouse).

6. **Motion to Continue and Shorten Time for Intervention**. If the intervention period in the original notice or the subsequent notice expires after the calendar call, the attorney should file a Motion for Continuance and a Motion to Shorten the Time Period for Intervention. The Motion for Continuance should be filed concurrently with the Motion to Shorten the Time Period for Intervention. Each motion should cross-reference the other and state that they are in the alternative. Generally, the motions should be filed if the calendar call is more than 30 days, but less than 60 days, from the date the notice is sent to the nonpetitioning spouse. T.C. Rule 325(b) provides that the nonpetitioning spouse has 60 days to file a notice of intervention, unless the court directs otherwise. Thus, the Tax Court may direct that the intervention period be shortened, if necessary, to ensure that the case is resolved within the trial session, while allowing adequate time for the nonpetitioning spouse to intervene. If the case is calendared less than 30 days from the date the notice is sent to the nonpetitioning spouse, the attorney should contact the Associate Chief Counsel (P&A), Branches 1 or 2 for further guidance.


**35.2.2.13** **(04-13-2015)**

### Answers in Collection Due Process (CDP) Cases under Sections 6320 and 6330

1. T.C. Rule 333(a) provides that the Commissioner will file an answer or move with respect to the petition within the periods specified in T.C. Rule 36(a). If the tax liability is properly at issue and the Commissioner has the burden of proof, the answer should include, as required by T.C. Rule 36(b), affirmative allegations as to every ground relied upon by the Service. Also, under T.C. Rule 39, any avoidance or affirmative defense should be raised in the answer, as appropriate.

2. Pursuant to IRC § 6330(c)(2)(B), a taxpayer may not raise liability in a CDP proceeding if he or she previously received a notice of deficiency for such tax liability or otherwise had an opportunity to dispute the liability. Also, under section 6330(c)(4), any issue may be precluded if it was previously raised in an administrative or judicial proceeding, and the taxpayer meaningfully participated in such proceeding. The facts involving these issues should be made as averments in the answer, not as affirmative allegations. The averments concerning these issues should not be the basis of a T.C. Rule 37(c) motion to deem affirmative allegations as admitted. Additionally, if the petitioner was previously involved in a judicial proceeding involving the same tax liabilities and years that are listed in the taxpayer's petition, the answer should make averments describing that litigation and the results therein.


**35.2.2.14** **(08-02-2022)**

### Answers in Passport Cases

1. As in other Tax Court actions, and consistent with Tax Court Rule 353, the title of the answer to a petition should be "Answer."

2. The following is recommended language for the prayer for relief when the taxpayer is not entitled to relief:


    WHEREFORE, it is prayed that the relief sought in the Petition for Certification of Failure to Reverse Certification Action Under Code Section 7345(e) be denied.

3. If the taxpayer does not attach a Notice of Certification of Your Seriously Delinquent Tax Debt (Notice CP508C) to the petition, a copy of the CP508C, which can be requested from the Service’s CDP coordinators, should be included with the Answer. Before filing the Answer, the assigned attorney must verify that the petitioner’s certification has not been reversed.

4. Consistent with IRS Notice 2018-01, 2018-3 I.R.B. 299, after the assigned attorney files the Answer, the attorney will not refer the docketed case to the Independent Office of Appeals. Appeals consideration of these cases under Rev. Proc. 2016-22, 2016-15 I.R.B. 577, will not occur given the automated nature of the Service’s process for identifying modules and certifying individuals with seriously delinquent tax debts and because the determinations will have been verified by the assigned attorneys in answering the cases.


**35.2.2.15** **(08-02-2022)**

### Answers in Interest Abatement Cases

1. The general instructions for answering deficiency cases in CCDM 35.2.2 apply in answering these cases. Pursuant to T.C. Rule 283, respondent is required to file an answer within the periods specified and in accordance with the requirements of T.C. Rule 36.

2. A reply to the answer is to be filed to the extent required by T.C. Rule 37.


**35.2.2.16** **(08-11-2004)**

### Motions

1. See CCDM 35.3.3, Motions Pertaining to Pleadings, for a discussion of motions to deem allegations in the answer admitted, motions to amend pleadings, motions relating to replies and motions for improved pleadings.

2. See CCDM 35.3.8, Motions in Declaratory Judgment Cases and Section 7436 Worker Classification Cases, for a discussion of motions in declaratory judgment cases and worker classification cases under IRC § 7436.


**35.2.2.17** **(09-24-2012)**

### Designation of Place of Trial

1. If the petitioner has not designated a place of trial, the attorney shall prepare a designation and file it with the Tax Court at the earliest reasonable time ( _e.g._, with a motion or answer). See Exhibit 35.11.1-31, Designation of Place of Trial. Once a place of trial has been designated by either party, it can only be changed by a motion. The attorney should check the Tax Court’s electronic docket sheet before mailing a designation of place of trial to the court to make certain the petitioner has not already filed a designation.

2. T.C. Rule 140(c) provides that a motion to change a place of trial filed after the notice of time of trial has been issued will ordinarily be deemed dilatory. The motion will be denied unless the grounds upon which the motion is based arose after the notice was issued or there was good reason for not making the motion earlier.


**35.2.2.17.1** **(08-11-2004)**

#### Where Designated

1. IRC § 7446 provides that the place of trial shall be fixed with as little inconvenience and expense to taxpayers as is practicable. The respondent must have a strong and convincing position to get a different location for the trial from that designated by the petitioner. In a case in which the burden of proof is on the respondent and the petitioner has not designated a place of trial, the attorney should designate as the place of trial the place or locality where the witnesses and books and records are located.

2. If the petitioner has not filed a designation of place of trial, respondent’s designation of place of trial will generally designate the place most convenient to the petitioner. In the event the parties fail to designate a place of trial, the court may designate a place of trial closest to petitioner’s residence. After such a designation by the Court, the place of trial can only be changed by motion.

3. In those cases where petitioner has designated a place of trial but it is obvious from the file that another city would be more appropriate because pertinent records and witnesses ( _e.g._, bank records, brokerage records, third party witnesses) are located in the other city, an unagreed motion by respondent to change the place of trial filed shortly after the case is at issue generally will not be granted. The court will usually only grant such motions if respondent has reached an impasse in preparing a stipulation of facts with petitioner who refuses to stipulate to records and third party witnesses will have to travel to a distant city to give testimony to place the matters into evidence. Only at that point in the case development is there a realistic hope that a motion to change place of trial will be granted. The court has indicated that, in general, it will change the place of trial over petitioner’s objection only where it appears that the case will in fact have to be tried and that witnesses will necessarily be inconvenienced by having to travel to a distant place of trial.

4. Factors to be considered in deciding whether a motion to change the place of trial should be filed are:



   - Whether fraud, fraudulent failure to file, transferee or other issues upon which the respondent has the burden of proof are involved

   - Whether the respondent has a large number of witnesses located a great distance from the place of trial set by the court

   - The location of probable witnesses and records of the petitioner

   - The present address of the petitioner and whether the designated place of trial is solely for the convenience of petitioner’s counsel

   - The nature and difficulties in the trial of the issues and whether the instant case is related to other cases which have designated trial locations within the office to which the instant case is assigned


**35.2.2.17.2** **(08-11-2004)**

#### Transfer of Cases

1. The desirability for the transfer of cases from one office to another office may arise in the initial stages of handling the case, or may arise at a later date due to the action of the Tax Court in setting the location for trial. A transfer between offices prior to the case becoming at issue may only be made if there is sufficient time for the receiving office to obtain the files and take appropriate action with respect to a motion or answer on the petition. Because of time factors, except in unusual circumstances, ( _e.g._, where affirmative allegations are required and it is in the best interest of the receiving office to answer the case), the case is to be answered before transferring it. On those rare occasions when a case is to be transferred prior to being answered, it must be with the prior approval of the receiving office. Additionally, the files must be sent so as to be received at least 30 days prior to the due date of the answer. Express mail service, or other commercial express delivery services should be used to ensure prompt delivery of the files. Further, the files should be flagged or marked in some manner so that the receiving office will be able to see immediately that time is critical.

2. Before transferring a case to another Field Counsel office, the proposed transfer should be discussed with Appeals to determine whether there are any nondocketed cases pending with Appeals or the local Area Director and whether Appeals objects to the transfer. The presence of any related nondocketed cases locally is a factor to consider when deciding whether to transfer the docketed case, as is Appeals’ willingness to transfer the administrative file to the other area.

3. When transferring a case, the attorney will transmit the legal file, the administrative file if in Counsel’s possession, and the miscellaneous law file to the other Field Counsel office. The legal, administrative and miscellaneous law files should be transmitted using TLCATS transmittal directly from one Field Counsel office to the other Field Counsel office.

4. For each case transferred, the attorney must forward a copy of the TLCATS transmittal to both the Appeals office that will transfer the case and to the Appeals office which will have administrative jurisdiction after the transfer. This notification will enable Appeals to transfer administrative jurisdiction to the receiving Appeals office simultaneously with Counsel’s transfer of the legal file.

5. If the case is transferred prior to answer, the TLCATS transmittal should contain the statement: This case has not been answered. The answer is due \[date\].

6. See CCDM 35.2.1.1(5), Analysis of New Tax Court Petitions, for guidelines on transfer or coordination of cases involving issues handled by the Division Counsel (TEGEDC) or the Associate Chief Counsel (EEE).


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-002-002#addtoany "Show all")

A2A