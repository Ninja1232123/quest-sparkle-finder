---
url: "https://www.irs.gov/irm/part30/irm_30-004-008"
title: "30.4.8 Public Information (Speeches, Publications, and Teaching) | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part30/irm_30-004-008#main-content)

- 30.4.8 [Public Information (Speeches, Publications, and Teaching)](https://www.irs.gov/irm/part30/irm_30-004-008#idm140010874976176)
  - 30.4.8.1 [Policy](https://www.irs.gov/irm/part30/irm_30-004-008#idm140010892900112)
  - 30.4.8.2 [Definitions](https://www.irs.gov/irm/part30/irm_30-004-008#idm140010902641328)
  - 30.4.8.3 [Authorization to Speak, Teach, or Publish](https://www.irs.gov/irm/part30/irm_30-004-008#idm140010902753488)

    - 30.4.8.3.1 [Principles and Standards for Authorization](https://www.irs.gov/irm/part30/irm_30-004-008#idm140010882771056)
    - 30.4.8.3.2 [Request for Authorization](https://www.irs.gov/irm/part30/irm_30-004-008#idm140010871047232)

  - 30.4.8.4 [Review for Conformance](https://www.irs.gov/irm/part30/irm_30-004-008#idm140010873193216)
  - 30.4.8.5 [Disclaimers and Identification as Employee](https://www.irs.gov/irm/part30/irm_30-004-008#idm140010895652768)
  - 30.4.8.6 [Remuneration and Expenses for Speaking or Writing in Official Capacity](https://www.irs.gov/irm/part30/irm_30-004-008#idm140010878967856)
  - 30.4.8.7 [Speakers Release Forms](https://www.irs.gov/irm/part30/irm_30-004-008#idm140010896949344)

# Part 30. Administrative

# Chapter 4. Personnel Administration, Training, and Equal Employment Opportunity

# Section 8. Public Information (Speeches, Publications, and Teaching)

* * *

## 30.4.8 Public Information (Speeches, Publications, and Teaching)

**30.4.8.1** **(04-27-2006)**

### Policy

1. This section sets forth the policy and procedures of the Office of Chief Counsel concerning speeches before public groups (including panel discussions), articles for publication, and teaching outside the Office. This section implements Government-wide and Treasury conduct rules, as well as rules set forth in the Internal Revenue Manual.

2. This section applies to all personnel in the Office of Chief Counsel, and to all matters involving the Office of Chief Counsel, the Internal Revenue Service, or the Treasury Department. This section does not apply to academic submissions for non-publication purposes, such as masters theses, which do not disclose official or confidential information, nor does it apply to recruitment activities.

3. The Office encourages and authorizes officials and employees to deliver speeches, participate in tax forums, and write articles for publication to the extent that such activities promote taxpayers' understanding of their rights and obligations under the tax laws, and represent effective and efficient means of conveying particular information to the public.


**30.4.8.2** **(12-14-2010)**

### Definitions

1. The terms **_public_** and **_publicly_** apply to any activity where persons who are not Treasury Department employees are present or where such persons will have access to written information presented in or resulting from such activity.

2. The phrase **_involves the Office_** means any activity which:



1. Relates to or involves the responsibilities, programs, or activities of the Office

2. Draws upon data and information obtained from or through employment in the Office which has not been made public or which is not available to the public upon request

3. Involves cost to the Government in either money or time


3. All speeches, publications, and teaching involving the Office that are undertaken as part of an employee's duties constitute **_official activities_**. All speeches, publications, and teaching involving the Office not undertaken as part of an employee's duties constitute **_unofficial activities_**.


**30.4.8.3** **(12-14-2010)**

### Authorization to Speak, Teach, or Publish

1. Advance approval by the authorizing official is required to speak, teach, or publish an article, book, or other item on any matter that involves the Office.

2. The sponsor of a program should not be advised by the requesting attorney that he/she is receptive to participate in the program until the requisite approval has been granted as required by this section.

3. Division Counsel and Associate Chief Counsel (or their designees) are the authorizing officials for speeches, publications and official teaching requests by employees under their supervision.



1. The authorizing official for a member of a Deputy Chief Counsel's immediate staff shall be the Deputy Chief Counsel.

2. The authorizing official for a member of the Chief Counsel's immediate staff shall be the Chief Counsel.

3. Associates Chief Counsel and Division Counsel are not required to seek authorization, but shall inform their respective Deputy Chief Counsel of any speeches, publications and official teaching requests.

4. The Deputies Chief Counsel are not required to seek authorization but shall inform the Chief Counsel of any speeches, publications, and official teaching requests.


**30.4.8.3.1** **(12-14-2010)**

#### Principles and Standards for Authorization

1. Invitations to speak should not be accepted from other than tax exempt organizations. Chief Counsel personnel may not speak at events which appear to be sponsored principally for profit making purposes, regardless of whether the sponsor is a taxable business or a tax exempt organization. An invitation to speak to any group should not be accepted where the evident purpose or probable result of the event may be to indicate that the sponsor has a preferential relationship with the Internal Revenue Service or the Office of Chief Counsel; where it might appear that information not available to others is being provided to a preferred group; or where it appears that the speaker’s official position with the Office of Chief Counsel is being used primarily to foster a private purpose rather than to promote the objective of informing and educating the public. Exceptions to this policy may on a limited basis be justified when the Service or the Office of Chief Counsel has a particular message to convey to a particular group and a speech is the most efficient method to convey that message.

2. Requests to speak at events sponsored by other Government agencies or members of Congress will be afforded the same consideration as other requests. Each request should be considered on its own merit.

3. Generally, approval to speak, publish, or teach in an official capacity will be given only to employees with expertise in the subject to be discussed, published, or taught.

4. The use of confidential information obtained as a result of the employee's work within the Office will not be authorized.

5. An employee engaged in an unofficial activity will not be authorized to make a pre-announcement of Office policy.

6. Issues involved in or expected to be involved in litigation may not be discussed if the Office's position or the rights of taxpayers would be adversely affected.

7. Authorizing officials approving speaking, publishing, or teaching requests should consider the following factors:



1. The subject matter of the activity

2. The cost involved to the Office

3. The nature and size of the potential audience

4. Where the activity will be held and any unfavorable publicity associated with the venue

5. Whether it interferes with the employee's job, such as by excessive absence or time devoted to the activity

6. The relationship of the sponsor to the speaker

7. Whether the agency has approved similar engagements


8. Requests may be denied in any case in which:



1. The Service would not benefit from the employee's participation or attendance

2. The positions taken by the requesting employee would conflict with earlier pronouncements of the Commissioner or other high ranking IRS or Treasury officials

3. The efficient performance of the employee's duties would be impaired due to excessive absence or time for preparation

4. Unfavorable publicity could arise


**30.4.8.3.2** **(12-14-2010)**

#### Request for Authorization

1. Organizations should request Counsel participation in their programs in writing.

2. A separate request must be submitted for each speech, publication, or teaching engagement. Each presentation of the same subject or topic requires separate authorization.

3. Any official speech or teaching request must be documented on Form 8175, Authorization to Speak or Teach and to Accept Related Benefits. The form can also be found at http://ccintranet.prod.irscounsel.treas.gov/Common/EthicsLink/OutsideActivities/Pages/Teaching,SpeakingandWriting.aspx. Each request must contain the following information:



1. The name, address and telephone number of the program sponsor

2. Any relationship of the program sponsor to the employee

3. Any relationship of the program sponsor, if a business entity, to the Department of the Treasury

4. A description of the program

5. The proposed duration and anticipated number of hours involved

6. If offered, the nature and source of any offers of free attendance (e.g. conference fee waiver, meals) or expense reimbursement


4. The original of the Form 8175, once signed by the authorizing official, should be given to the requesting employee, and a copy forwarded to the appropriate office for inclusion in the employee's drop file maintained by the immediate manager.

5. In the case of a speech, a copy or outline of the proposed speech should be attached to the Form 8175 along with a copy of the request from the sponsoring organization. If participating in a panel discussion, the employee should attach a copy of the program agenda, if available, and a copy of the communication from the sponsor.

6. In the case of a publication, a copy should be attached to the transmittal memorandum.

7. Each reviewing official should set forth reasons for recommending for or against approval. See CCDM 30.4.8(2) .

8. With respect to requests to teach in an official capacity, an estimation of the teaching capabilities of the employee should also be noted by reviewing supervisors both in terms of course content and classroom presence. Consideration should be given to:



1. Whether the entity in question is accredited and well thought of in the local community

2. The precise time the teaching will occur ( _e.g._, Thursdays, 6:30 p.m.- 8:00 p.m.)

3. The amount of preparation time required

4. The time period in which such preparation will be accomplished


9. Any unofficial speaking, teaching, or writing request must be documented on Form 7995-A, Chief Counsel Outside Employment or Business Activity Request.



### Note:



Teaching the same course at the same school under the same conditions can be for an indefinite period and new requests need not be submitted.


**30.4.8.4** **(12-14-2010)**

### Review for Conformance

1. While the content of a proposed speech or article for publication will not be subject to review for grammar, organization, or overall format, it will be scrutinized for conformance with the requirements of CCDM 30.4.8.3.1, with particular emphasis on possible conflicts of interest and consistency with established Service and Treasury positions.

2. In requesting approval for a publication, the author should discuss in a transmittal memorandum to the authorizing official whether the Service has taken a position on any of the issues to be presented, and identify how the book or article may be in conflict therewith. This memorandum, along with a draft of the proposed publication, should be routed through the immediate and higher level supervisors of the requesting employee to the Associate Chief Counsel with subject matter jurisdiction over the topic of the publication for comment and recommendation.


**30.4.8.5** **(12-14-2010)**

### Disclaimers and Identification as Employee

1. When a request to speak, publish, or teach as an **_official_** activity is approved, the employee may be identified as a Chief Counsel employee in any program, article, course announcement, or catalog connected with the activity.

2. When a request to speak, publish, or teach as an **_unofficial_** activity is approved, the employee may be identified as a Chief Counsel employee in any program, article, course announcement, or catalog connected with the activity when included as one of several biographical details, provided that the employee's Chief Counsel position is given no more prominence than other biographical details. The introduction or identification of the employee must be accompanied by a disclaimer that the employee is writing or speaking solely for himself and not for the Office.


**30.4.8.6** **(12-14-2010)**

### Remuneration and Expenses for Speaking or Writing in Official Capacity

1. Except as provided below, no employee shall receive an honorarium or compensation for teaching or writing for publication related to their official duties.



### Note:



The restrictions on honorarium and compensation do not prohibit the acceptance of nominal courtesies normally extended in the spirit of hospitality. For example, an employee may accept modest items of food and refreshments, such as soft drinks, coffee, and donuts, offered other than as part of a meal.

2. When an employee is assigned to participate as a speaker on behalf of the Office at a conference or other event, the employee may accept an offer of free attendance to the event on the day that he is speaking in accordance with 5 C.F.R. 2635.204(g)(1). Free attendance includes a waiver of all or part of the conference fee, and instructional materials, food, refreshments, and entertainment offered to all attendees as an integral part of the event; it does not include payment or reimbursement of travel expenses. 5 C.F.R. § 2635.204(g)(4). If the employee is offered free attendance to a multi-day event where he is not speaking each day, he should consult CCDM 30.4.3.2 , Widely Attended Gatherings, or contact the Ethics and General Government Law Branch of General Legal Services for additional guidance.

3. An employee who has been authorized in an official capacity to speak at or to participate in an event may accept payment for and/or reimbursement of reasonable expenses for domestic travel, lodging, and meals from an organization described in IRC § 501(c)(3), and from any state, county, or municipal agency. See CCDM 30.3.2.2.1.3, Travel, Relocation, and Related Matters, and 30.3.2.3.2.2(1)m, Functions of the Office of the Associate Chief Counsel (F&M), for officials authorized to approve payment of travel expenses from IRC § 501(c)(3) organizations and state or local governments. Expense reimbursement or payment will be limited to actual expenses not to exceed coach airfare plus necessary ground transportation, the cost of a standard single room at the forum site, and reasonable meal costs.

4. If the reimbursement will be made to the Office or is for international travel, the Office must seek authorization from the Deputy Commissioner, through the Associate Chief Counsel (General Legal Services), to accept payment of or reimbursement of travel, lodging, and subsistence expenses from the program sponsor. Please contact the Ethics and General Government Law Branch of General Legal Services for additional guidance.

5. Employees may seek additional guidance on remuneration and reimbursement of expenses from the Ethics and General Government Law Branch of General Legal Services.


**30.4.8.7** **(12-14-2010)**

### Speaker’s Release Forms

1. Employees should generally decline to sign any form purporting to transfer rights in a speech (or other government work) to the sponsor of an event or another third party.

2. Speeches prepared by an employee as part of the employee's official duties are considered works of the United States Government and are not afforded copyright protection. 17 U.S.C. §105. The same rule applies to a paper, report, publication or any other work prepared by an employee as part of the employee's official duties. Instead of signing a release form, employees should advise the sponsor in writing that that speech is a work of the United States Government which is in the public domain, and the speech may be freely copied and distributed.

3. If the sponsor insists on a signed release, employees should seek additional guidance from the Ethics and General Government Law Branch of General Legal Services.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part30/irm_30-004-008#addtoany "Show all")

A2A