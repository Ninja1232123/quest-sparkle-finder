---
url: "https://www.irs.gov/irm/part32/irm_32-004-003"
title: "32.4.3 Industry Issue Resolution | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part32/irm_32-004-003#main-content)

- 32.4.3 [Industry Issue Resolution](https://www.irs.gov/irm/part32/irm_32-004-003#idm140273600709840)
  - 32.4.3.1 [Industry Issue Resolution Program](https://www.irs.gov/irm/part32/irm_32-004-003#idm140273572557552)
  - 32.4.3.2 [Solicitation of Potential IIR Issues](https://www.irs.gov/irm/part32/irm_32-004-003#idm140273595444544)

    - 32.4.3.2.1 [Issues Appropriate for IIR](https://www.irs.gov/irm/part32/irm_32-004-003#idm140273570685840)
    - 32.4.3.2.2 [Who May Submit Issues](https://www.irs.gov/irm/part32/irm_32-004-003#idm140273584358720)
    - 32.4.3.2.3 [Manner of Submission](https://www.irs.gov/irm/part32/irm_32-004-003#idm140273570475136)

  - 32.4.3.3 [Review of IIR Submissions](https://www.irs.gov/irm/part32/irm_32-004-003#idm140273590192912)

    - 32.4.3.3.1 [Operating Division Prioritization of Recommendations](https://www.irs.gov/irm/part32/irm_32-004-003#idm140273595540064)
    - 32.4.3.3.2 [Selection of IIR Issues for the Guidance Priority List](https://www.irs.gov/irm/part32/irm_32-004-003#idm140273582522720)
    - 32.4.3.3.3 [Disposition of Non-selected Issues](https://www.irs.gov/irm/part32/irm_32-004-003#idm140273572788688)

  - 32.4.3.4 [Role of IIR Team and Role of Office of Associate Chief Counsel](https://www.irs.gov/irm/part32/irm_32-004-003#idm140273604026240)
  - 32.4.3.5 [Clearance and Approval Process for Published Guidance](https://www.irs.gov/irm/part32/irm_32-004-003#idm140273580035040)

# Part 32. Published Guidance and Other Guidance to Taxpayers

# Chapter 4. Special Pre-Filing Agreement Programs

# Section 3. Industry Issue Resolution

* * *

## 32.4.3 Industry Issue Resolution

**32.4.3.1** **(10-28-2010)**

### Industry Issue Resolution Program

1. The Large Business and International Division (LB&I) developed the Industry Issue Resolution (IIR) Program to work with business taxpayers, industry associations, taxpayer representatives, and other interested parties to identify frequently disputed tax issues common to a significant number of business taxpayers and to resolve those issues through published or administrative guidance. Resolving issues through prefiling guidance rather than post-filing examination is a goal of both the Service and the Office of Chief Counsel.

2. The Service announced the Industry Issue Resolution Pilot Program in Notice 2000-65, 2000-2 C.B. 599. The objective of the pilot program was to establish and evaluate a procedure to resolve frequently disputed tax issues that are common to a significant number of large or mid-size business taxpayers through prefiling guidance rather than post-filing examination. After evaluating the pilot program, the Service announced in Notice 2002-20, 2002-17 I.R.B. 796, that the IIR Program would be made permanent.

3. Notice 2002-20 expanded the IIR Program to identify and resolve frequently disputed issues common to any size business taxpayers and to address opportunities to reduce burden for all business taxpayers. LB&I and the Small Business and Self-Employed Division (SB/SE) share operational responsibility for the IIR Program.

4. Revenue Procedure 2003-36, 2003-18 I.R.B. 859, sets forth the procedures for business taxpayers, industry associations, and other interested parties to submit issues for consideration under the IIR program. The program was modified to allow issues to be proposed on a continuous basis and to provide for selections for the IIR program to be made at least semi-annually.

5. This section provides instructions regarding the coordination within Counsel of issues proposed for inclusion in the Industry Issue Resolution Program.


**32.4.3.2** **(08-11-2004)**

### Solicitation of Potential IIR Issues

1. Generally, the primary method of soliciting issues for the IIR program was by means of Notices. Because submissions may now be made at any time, the Service may issue periodic News Releases concerning the IIR program which will include an invitation for submission of proposed issues.


**32.4.3.2.1** **(10-28-2010)**

#### Issues Appropriate for IIR

1. The issues most appropriate for inclusion in the IIR Program will have two or more of the following characteristics:



   - The proper tax treatment of a common factual situation is uncertain

   - The uncertainty results in frequent, and often repetitive, examinations of the same issue

   - The uncertainty results in taxpayer burden

   - The issue is significant and impacts a large number of taxpayers, either within an industry or across industry lines

   - The issue requires extensive factual development, and an understanding of industry practices and views concerning the issue would assist the Service in determining the proper tax treatment


2. The following issues are not suitable:



   - Issues that are unique to one or a small number of taxpayers

   - Issues that are primarily under the jurisdiction of Operating Divisions of the Service other than the LB&I and SB/SE Divisions

   - Issues that involve transactions that lack a bona fide business purpose, or transactions with a significant purpose of improperly reducing or avoiding federal taxes

   - Issues that involve transfer pricing or international tax treaties


**32.4.3.2.2** **(08-11-2004)**

#### Who May Submit Issues

1. The IIR Program is intended to engage business taxpayers, industry associations, and other interested parties in the guidance process. Because other avenues are available for Service personnel to suggest issues that need guidance, a proposal for the IIR Program from an employee, in general, will be considered only if the proposal is adopted and sponsored by a business taxpayer, industry association, or other interested party.


**32.4.3.2.3** **(08-11-2004)**

#### Manner of Submission

1. An issue submitted for consideration under the IIR Program is not required to be submitted in a particular format. The submission should, however, include an issue statement, a description of why the issue is appropriate for the IIR Program, an explanation of the need for guidance, the estimated number of taxpayers affected by the issue, and the name and telephone number of a person to contact if additional information is needed. The submission may also include a recommendation as to how the issue may be resolved. All submissions are made available for public inspection and copying in their entirety; therefore, the submission should not include confidential, taxpayer-specific information.


**32.4.3.3** **(10-28-2010)**

### Review of IIR Submissions

1. Submission of issues for consideration under the IIR program will be directed to the LB&I Office of Pre-Filing and Technical Services. That office will prepare a package (recommendation package) consisting of the information contained in the submission package and a check sheet for recommendations as to inclusion of an issue in the IIR Program. That office will forward the recommendation package to all functions from whom input is appropriate, including Counsel.

2. The recommendation package directed to Counsel will be sent to LB&I Division Counsel to the attention of the Special Counsel (Pre-filing and Guidance). The Special Counsel (Pre-filing and Guidance) will forward the recommendation package, with any additional background material to the Technical Services Section of the Office of Associate Chief Counsel (PA) for assignment and the due date for a response from the Associate office with jurisdiction over the issue. The Special Counsel (Pre-filing and Guidance) will also advise all LB&I Area Counsel of the IIR issues that have been submitted through the Special Counsel located at the Division Counsel (LB&I) headquarters office.

3. To enable LB&I and SB/SE to timely consider the IIR issues submitted, the Associate Offices will review the recommendation packages and, within the time frame established for response, advise the Special Counsel (Pre-filing and Guidance) or, if otherwise indicated, the Office of Pre-Filing and Technical Services, as to the appropriateness of the issue for possible inclusion in the IIR Program.


**32.4.3.3.1** **(10-28-2010)**

#### Operating Division Prioritization of Recommendations

1. LB&I and SB/SE will, first independently and then cooperatively, review the IIR submissions to determine the order of priority that those functions believe the issues should be considered and recommended for possible inclusion in the IIR program and on the Guidance Priority List or a periodic update of that list. LB&I and SB/SE Division Counsel will assist in the review and prioritization process.


**32.4.3.3.2** **(10-28-2010)**

#### Selection of IIR Issues for the Guidance Priority List

1. Issues selected for the IIR program will be included on the Guidance Priority List or the periodic update of that list. However, a recommendation by LB&I or SB/SE does not guarantee that the issue will be selected either as an IIR project or for inclusion on the Guidance Priority List or a periodic update of the list. In deciding whether to select issues recommended by LB&I and SB/SE under the IIR Program for inclusion on the Guidance Priority List, the Office of Chief Counsel and the Treasury Department will consider, among other things, recommendations from other sources and whether the requested guidance under the IIR Program promotes sound tax administration. Projects selected for the IIR Program may either be included on the Guidance Priority List for the upcoming year or on a quarterly update to the list during the year.


**32.4.3.3.3** **(10-28-2010)**

#### Disposition of Non-selected Issues

1. LB&I and SB/SE are responsible for informing the parties who submitted issues that their issues were not selected for the IIR Program. When possible, alternative methods of addressing the issue will be suggested and pursued.


**32.4.3.4** **(10-28-2010)**

### Role of IIR Team and Role of Office of Associate Chief Counsel

1. The Service, Treasury, and Chief Counsel will staff each project that is included in the IIR Program with a team (the IIR team). The team is responsible for gathering facts; meeting with taxpayers, industry associations, and other interested parties; analyzing relevant information; and proposing a resolution for the issue. IIR team members will include appropriate personnel from LB&I and SB/SE, the Office of the Associate Chief Counsel with subject matter expertise with respect to the issue, Appeals, and Treasury. Typically, the LB&I Industry Counsel for the industry or issue to which the IIR pertains will be a member of the team. Other personnel, as needed, may be team members. In some circumstance, the Service may find it necessary to hire outside experts.

2. The Associate Chief Counsel representative on the IIR team will serve as the subject matter expert and the primary drafter of any proposed guidance. The preparation and issuance of the published guidance under the IIR Program is the sole responsibility of the Office of Associate Chief Counsel.

3. Activities and duties of team members include:



   - Participate in work team and industry orientations

   - Assist in creating IIR work plan

   - Provide technical expertise

   - Discuss industry’s proposal for resolution

   - Seek and evaluate facts and legal positions on the issue

   - Consult with audit teams dealing with the issue

   - Ensure that Counsel management stays informed during the project


**32.4.3.5** **(08-11-2004)**

### Clearance and Approval Process for Published Guidance

1. All procedures applicable for published guidance projects on the Guidance Priority List are equally applicable to IIR projects included on the Guidance Priority List. The representative of the Office of Associate Chief Counsel is responsible for the clearance and approval process for IIR published guidance projects. Briefings on proposed guidance will include, whenever feasible, all IIR team members.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part32/irm_32-004-003#addtoany "Show all")

A2A