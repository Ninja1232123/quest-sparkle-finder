---
url: "https://www.irs.gov/irm/part38/irm_38-001-002"
title: "38.1.2 Administrative Requests for Grants of Statutory Use Immunity | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part38/irm_38-001-002#main-content)

- 38.1.2 [Administrative Requests for Grants of Statutory Use Immunity](https://www.irs.gov/irm/part38/irm_38-001-002#idm140048772485264)
  - 38.1.2.1 [Statutory Use Immunity](https://www.irs.gov/irm/part38/irm_38-001-002#idm140048746726528)
  - 38.1.2.2 [Procedures Regarding Judicial Immunity](https://www.irs.gov/irm/part38/irm_38-001-002#idm140048774617088)
  - 38.1.2.3 [Procedures Regarding Administrative Immunity](https://www.irs.gov/irm/part38/irm_38-001-002#idm140048741323040)
  - 38.1.2.4 [Requesting Immunity for Acts of Production](https://www.irs.gov/irm/part38/irm_38-001-002#idm140048770512256)

    - 38.1.2.4.1 [Act of Production Immunity Requests](https://www.irs.gov/irm/part38/irm_38-001-002#idm140048774605184)
    - 38.1.2.4.2 [Authorization and Approval for the Compulsion Order](https://www.irs.gov/irm/part38/irm_38-001-002#idm140048748597712)

# Part 38. Criminal Tax

# Chapter 1. Assistance to Criminal Investigation During Investigatory Stage

# Section 2. Administrative Requests for Grants of Statutory Use Immunity

* * *

## 38.1.2 Administrative Requests for Grants of Statutory Use Immunity

**38.1.2.1** **(10-03-2007)**

### Statutory Use Immunity

1. Title II of the Organized Criminal Control Act of 1970 enacted a broad witness immunity statute applicable to judicial, agency, and Congressional proceedings and repealed all conflicting immunity statutes. The constitutionality of these witness immunity provisions was upheld by the Supreme Court, which found that the use immunity granted was coextensive with the Fifth Amendment privilege against self-incrimination. The statute only requires the confirmation of use immunity. It does not require transactional immunity.

2. Use immunity, as defined in 18 U.S.C. § 6002, provides immunity from the use of the compelled testimony and evidence derived directly or indirectly therefrom.

3. Testimony or other information compelled under this order, and information directly or indirectly derived therefrom, may not be used against the witness in any criminal proceeding, except a prosecution for perjury, giving a false statement, or otherwise failing to comply with the order.

4. Under transactional immunity, a witness is immunized from prosecution for the crime about which he/she is testifying.

5. Immunity may be provided by a court, by an agency, or by Congress.



1. _Judicial Immunity_. When an individual is called to testify or provide other information at any proceeding before or ancillary to a court (including the United States Tax Court) or a grand jury, the district court, upon the request of the US Attorney, may immunize the individual and require him/her to testify or provide other information. _See_ 18 U.S.C. § 6003.

2. _Administrative Immunity_. When an individual is called to testify or provide other information at an agency proceeding, the agency may, with the approval of the Attorney General, issue an order compelling the individual to testify or provide other information. _See_ 18 U.S.C. § 6004.

3. _Congressional Immunity_. An individual called to testify or provide other information before either House of Congress can also be immunized. _See_ 18 U.S.C. § 6005.


**38.1.2.2** **(08-11-2004)**

### Procedures Regarding Judicial Immunity

1. Judicial immunity is formally granted by a United States district court upon the application of a US Attorney. An application for judicial immunity must be authorized by the Attorney General or his/her delegate. _See_ 18 U.S.C. § 6003 (b). Should an immunity question arise in the context of a Tax Court proceeding, the Criminal Tax attorney should contact the office of the Associate Chief Counsel (Procedure & Administration).


**38.1.2.3** **(08-11-2004)**

### Procedures Regarding Administrative Immunity

1. An agency proceeding, as defined in 18 U.S.C. § 6001, is a proceeding before an agency with respect to which it is authorized to issue subpoenas and to take testimony or receive other information from witness under oath.

2. For our purposes, the issuance of a summons starts our agency proceeding.

3. With the approval of the Attorney General or his/her delegate, the Secretary of the Treasury is authorized to issue orders compelling testimony in agency proceedings pursuant to 18 U.S.C. §§ 6002 and 6004. By Treasury Department Order No. 150-88, dated November 29, 1977, the Secretary of the Treasury delegated this authority to the Commissioner of Internal Revenue who in turn delegated the authority to the Deputy Commissioner and the Chief, Criminal Investigation ( _See_ Delegation Order No. 169, as revised). Under this statute, only the Attorney General (or delegate) is authorized to issue compulsion orders.

4. A request should consist of a Form 6186, Request for Authorization to Issue a Compulsion Order (Witness Identification Sheet), http://publish.no.irs.gov/getpdf.cgi?catnum=43159, and a memorandum containing the following:



01. A brief summary of the background of the investigation, the relevant criminal violations, and years under investigation, including attempts to obtain evidence from other sources that the witness is expected to provide and the reasons that this information cannot be obtained from those other sources

02. A statement as to whether the witness is related, either by blood or marriage, to the subject of the investigation

03. A summary of the witness’s role

04. A description of the circumstances surrounding the witness’s invocation of the Fifth Amendment privilege and in what capacity he/she claimed the privilege

05. A summary of the witness’s expected testimony

06. Any indication as to whether the witness can exculpate the subject

07. A summary of known criminal activity; and the name and address of the witness’s attorney

08. The basis for the special agent’s conclusion that the witness will cooperate and testify truthfully if compelled to

09. A statement as to whether assurances or agreements have been made to the witness by any Government representative that may have an effect on this matter

10. A list of any electronic surveillance involved in the investigation with a summary attached


5. Should the Chief, Criminal Investigation agree that a request for authorization to compel testimony is appropriate, the original and two copies of the request will be forwarded to the Associate Chief Counsel (CT), for review of the propriety and legal sufficiency of the request and for preparation of a compulsion order to accompany the request.

6. The Associate Chief Counsel (CT) will review and evaluate the propriety and legal sufficiency of the request.



1. If the request is determined to be proper and legally sufficient, the Associate Chief Counsel (CT) shall prepare a proposed compulsion order for each witness and transmit them, along with an original and one copy of the request, to the Chief, Criminal Investigation. See Exhibit 38.3.1-2, Compulsion Order, http://publish.no.irs.gov/getpdf.cgi?catnum=39139.

2. The original request with all supporting exhibits and copies of all proposed compulsion orders will then be transmitted to the Assistant Attorney General, Tax Division, Department of Justice, Attention: Chief, \[REGION\] Criminal Enforcement Section.

3. If the request is determined not to be proper and/or not legally sufficient, the Associate Chief Counsel (Criminal Tax) will advise the Chief, Criminal Investigation.


**38.1.2.4** **(08-11-2004)**

### Requesting Immunity for Acts of Production

1. Where grand jury subpoenas were issued to a sole proprietor demanding production of business records, the Supreme Court held that contents of the records are not privileged. Where preparation of business records was voluntary, there is no compulsion, and the Fifth Amendment is not violated. A subpoena that demands production of documents does not compel oral testimony; nor would it ordinarily compel the taxpayer to restate, repeat or affirm the truth of the contents of the documents sought. The Court held further that the act of production was protected by the Fifth Amendment privilege and could not be compelled without a statutory grant of use immunity pursuant to 18 U.S.C. §§ 6002 and 6004.

2. The testimonial aspects of the act of production go to the existence, possession, and authenticity of the records being sought. That is, merely by producing subpoenaed or summoned records, the witness provides an admission that:



   - The records called for in the subpoena or summons exist

   - Such records are in the possession and control of the witness

   - The records being produced are the records described in the subpoena or summons


**38.1.2.4.1** **(08-11-2004)**

#### Act of Production Immunity Requests

1. A compulsion order under 18 U.S.C. § 6004 may be used to immunize only those aspects of the act of production that are testimonial in nature. When a witness receives such immunity, the Government is precluded from the use and derivative use of the witness’ act of production to establish the existence, possession, or authenticity of the records that are produced. When the Government can establish independently from the act of production that the records do exist and are in the possession of the witness, and there is an independent means by which the records can be authenticated (e.g., third party testimony, handwriting analysis, etc.), the contents of the records may be used in evidence against the witness in a criminal proceeding.

2. A request for immunity under 18 U.S.C. § 6004 solely for a witness’s act of production will be considered only in factual situations that satisfy all of the following statutory and policy conditions:



1. The investigation is a criminal investigation

2. The witness must have a valid Fifth Amendment claim to the production of such records

3. The records sought to be compelled are clearly business records

4. The summons being issued does not seek testimony from the witness

5. The records sought to be compelled are described with sufficient particularity so as to be easily identified

6. If the party summonsed is a target of the investigation, the records sought to be compelled are not otherwise obtainable from third parties (e.g., banks, bookkeepers, accountants)

7. The witness to be immunized is not being required, as a result of the summons, to create any records

8. There is evidence available to establish that the records being sought presently exist in the possession of the party to be summonsed and there appears to be an independent means to authenticate the records once production is made


3. When a special agent determines that a summons should be issued for business records from a witness or target for whom act of production immunity will be required, the agent will obtain the concurrence of the Criminal Tax attorney that the above criteria have been met and if needed, Field Counsel will assist in drafting the summons. The summons must be narrowly drafted to seek only production of business records that are known to presently exist in the possession of the summonsed party.

4. If the summoned party refuses to comply based on a valid Fifth Amendment claim in a recorded Question and Answer, Criminal Investigation will prepare and process a compulsion order request. See CCDM 38.1.2.3(4), CCDM 38.1.2.3(5), and Exhibit 38.3.1-3, http://publish.no.irs.gov/getpdf.cgi?catnum=39139.


**38.1.2.4.2** **(10-03-2007)**

#### Authorization and Approval for the Compulsion Order

1. After authorization for the compulsion order by the Department of Justice (DOJ) and the approval to issue it by the Chief, Criminal Investigation, an agency proceeding will be conducted as described in paragraphs (2) through (8).

2. The Criminal Tax attorney will attend the proceeding.

3. The summoned party will be directed to turn over the requested documents to the Criminal Tax attorney, who will immediately inspect the records to determine whether any documents are produced that are not covered by the summons.

4. If the volume of documents makes it impractical to perform an inspection at the time of production, the witness will be advised that the documents will remain under the control of the Criminal Tax attorney until such an inspection can be performed.

5. The Criminal Tax attorney will perform an inspection of the documents as soon as possible following the agency proceeding. Until such an inspection is completed, none of the documents produced will be made available to the special agent.

6. After inspection, all documents covered by the summons will be released to the special agent.

7. All documents outside the scope of the summons will be immediately returned to the witness or the witness’s attorney by certified mail.

8. If the summonsed party does not comply with the summons after receipt of the Compulsion Order, Criminal Investigation will refer the summons to the Criminal Tax attorney for judicial enforcement under existing procedures. The enforcement letter prepared by the Criminal Tax attorney will be coordinated, when appropriate, with the office of Associate Chief Counsel (Procedure & Administration) Branches 6 or 7, before forwarding to the DOJ.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part38/irm_38-001-002#addtoany "Show all")

A2A