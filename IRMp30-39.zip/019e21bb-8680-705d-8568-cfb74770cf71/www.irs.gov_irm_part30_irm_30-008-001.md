---
url: "https://www.irs.gov/irm/part30/irm_30-008-001"
title: "30.8.1 Counsel Library Services | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part30/irm_30-008-001#main-content)

- 30.8.1 [Counsel Library Services](https://www.irs.gov/irm/part30/irm_30-008-001#idm140203704314960)
  - 30.8.1.1 [Office of Chief Counsel Libraries](https://www.irs.gov/irm/part30/irm_30-008-001#idm140203704376768)
  - 30.8.1.2 [IRS Counsel Library](https://www.irs.gov/irm/part30/irm_30-008-001#idm140203704362160)
  - 30.8.1.3 [Associate/Division Counsel Libraries](https://www.irs.gov/irm/part30/irm_30-008-001#idm140203680334064)
  - 30.8.1.4 [Field Libraries](https://www.irs.gov/irm/part30/irm_30-008-001#idm140203661240896)

    - 30.8.1.4.1 [Field Library Point of Contact](https://www.irs.gov/irm/part30/irm_30-008-001#idm140203704365904)
    - 30.8.1.4.2 [Core Library Collection](https://www.irs.gov/irm/part30/irm_30-008-001#idm140203677188672)

      - 30.8.1.4.2.1 [Field Library Spreadsheets](https://www.irs.gov/irm/part30/irm_30-008-001#idm140203677192240)

        - 30.8.1.4.2.1.1 [Maintenance of the Core Collection Spreadsheets](https://www.irs.gov/irm/part30/irm_30-008-001#idm140203670766080)

      - 30.8.1.4.2.2 [Ordering Procedures for Core Materials](https://www.irs.gov/irm/part30/irm_30-008-001#idm140203678425264)

        - 30.8.1.4.2.2.1 [Receipt and Acceptance in IPS](https://www.irs.gov/irm/part30/irm_30-008-001#idm140203660919072)

      - 30.8.1.4.2.3 [Exceptions to the Core Library Collection](https://www.irs.gov/irm/part30/irm_30-008-001#idm140203665658208)

        - 30.8.1.4.2.3.1 [Additions to the Core Library Collection](https://www.irs.gov/irm/part30/irm_30-008-001#idm140203678414816)
        - 30.8.1.4.2.3.2 [Deletions from the Core Library Collection](https://www.irs.gov/irm/part30/irm_30-008-001#idm140203662011328)

  - 30.8.1.5 [Electronic Research Services](https://www.irs.gov/irm/part30/irm_30-008-001#idm140203668526864)

    - 30.8.1.5.1 [Electronic Research Coordinators](https://www.irs.gov/irm/part30/irm_30-008-001#idm140203677766352)
    - 30.8.1.5.2 [Subscription to an Electronic Research Services](https://www.irs.gov/irm/part30/irm_30-008-001#idm140203680780496)
    - 30.8.1.5.3 [Electronic Research Database ID/Passwords and Training](https://www.irs.gov/irm/part30/irm_30-008-001#idm140203679924128)

      - 30.8.1.5.3.1 [Cancellation of Electronic Research Database ID/Passwords](https://www.irs.gov/irm/part30/irm_30-008-001#idm140203684930160)
      - 30.8.1.5.3.2 [Security of Identification Cards](https://www.irs.gov/irm/part30/irm_30-008-001#idm140203675176672)

  - Exhibit 30.8.1-1 [Electronic Research Coordinators](https://www.irs.gov/irm/part30/irm_30-008-001#idm140203664049104)

# Part 30. Administrative

# Chapter 8. Library Services

# Section 1. Counsel Library Services

* * *

## 30.8.1 Counsel Library Services

#### Manual Transmittal

December 05, 2013

#### Purpose

(1) This transmits revised CCDM 30.8.1, Library Services; Counsel Library Services.

#### Material Changes

(1) Exhibit 30.8.1-1 is being updated to reflect the telephone change for the IRS Counsel Library in the Contact Information section of the exhibit.

#### Effect on Other Documents

CCDM 30.8.1 dated November 09, 2012 is superseded.

#### Audience

Chief Counsel

#### Effective Date

(12-05-2013)

Marlene Henrikson

Director, IRS Counsel Library

**30.8.1.1** **(11-09-2012)**

### Office of Chief Counsel Libraries

1. This section establishes procedures and guidelines for the IRS Counsel Library, Associate/Division Counsel office libraries, and Counsel Field office libraries.

2. Libraries are located in all Associate Counsel and corresponding branch offices, and in every Field Counsel Office. They are funded by the Associate Chief Counsel (Finance and Management). The IRS Counsel Library, located in National Office, is the main library for the Office of Chief Counsel and the IRS and is staffed by professional librarians and technician staff. Field Libraries are located in Counsel posts of duty (POD) and contain a collection of standardized titles (the core library collection), and monographic treatises (titles that have no supplementation), single titles, and one time publications that will not be maintained or supported in the core library collection.

3. The IRS Counsel Library Director (Library Director) is responsible for the IRS Counsel Library and for the Field library collection content and budget.

4. A Field Library Advisory Committee, designated by the Associate/Division Counsel, provides expertise in the content needs of the business units. The Field Advisory Committee assists the IRS Counsel Library Director in evaluating and changing the field core collection. Business units represented include Small Business/Self-Employed (SB/SE), Large Business and International (LB&I), General Legal Services (GLS), Tax Exempt and Government Entities (TEGE), and Criminal Tax (CT).


**30.8.1.2** **(11-09-2012)**

### IRS Counsel Library

1. The IRS Counsel Library Division (National Office Library), located in Washington, D.C., is made up of the General Legal Research Branch, Digest Branch, and the Technical Services Branch. The Library is not open to the public.



1. The General Legal Research Branch has two sections which are General Research Section and Legislative Research Section.

2. The Digest Branch houses original administrative publications. Access is restricted. Visitors must show an IRS badge and sign in prior to entering the collection area.

3. The Technical Services Branch purchases print and non-print materials for all Counsel offices, maintains an web-based catalog to the library collections, and develops the budget for all Counsel Libraries.


2. The IRS Counsel Library provides the following services:



   - In-depth research in tax, law, legal and non-legal subject areas

   - Interlibrary loan services

   - Assistance in researching commercial databases e.g., Lexis, Westlaw, Tax Analysts Tax Notes, Hein-Online, and Accurint

   - Assistance in identifying, locating, and verifying expert witnesses

   - Creates in-depth print and electronic legislative histories and tracks current legislation

   - Creates specialized publications such as training materials, research guides, topical guides

   - Provides Agency, administrative, and regulatory research

   - Procures print, non-print books, periodicals, databases for the IRS Counsel Library, Associate/Division Counsel libraries, and Field office libraries

   - Serves as the administrator and ID creator of Counsel IDs to commercial databases

   - Catalogs newly acquired books and periodicals for IRS Counsel Library, Associate/Division Counsel libraries, and Field libraries

   - Creates citator and digest cards for items housed in Digest collection

   - Trains Counsel employees in the use of electronic research products

   - Clearance for separating Counsel personnel for library materials and commercial electronic research resources


3. The IRS Counsel Library provides electronic access to a broad range of research materials via the CC intranet. Sources and extensive information on the assistance provided by the IRS Counsel Library may be found on the IRS Counsel Library home page.



1. IRS Counsel Library Catalog, also known as CounselCat — is a searchable web-based catalog to the titles purchased for and located in the IRS Counsel Library in Washington, D.C., as well as the unique titles owned by the Field Libraries and Associate Offices.

2. Interlibrary Loans — The IRS Counsel Library brokers interlibrary loans for all Chief Counsel offices regardless of post of duty. Requests for interlibrary loans may be submitted via the Library Request form.

3. Title suggestions for the IRS Counsel Library are made on the Suggest A Title form.

4. Research Assistance — is provided via submission of the Library Request form.


**30.8.1.3** **(11-09-2012)**

### Associate/Division Counsel Libraries

1. Excel spreadsheets are maintained for every Associate/Division Counsel Library. The spreadsheets serve as a record of the titles maintained in the library and as a budget/procurement tool for the Technical Services Branch. The spreadsheets are updated frequently and located on a shared drive. Mapping instructions are located on the Field Library Support page, entitled "Directions for Mapping to Shared Drive."

2. Associate/Division Counsel Offices review their collection titles annually via a Library survey provided in May or June by the IRS Counsel Library Technical Services Branch. Using the survey, Associate/Division Counsel specify the titles they want to renew or drop. Titles of similar value may be requested in lieu of dropped titles.

3. New titles, in addition to collection titles, must be requested via a Library Purchase Justification form and cataloged in CounselCat.

4. The Technical Services Branch purchases the library titles for the Associate/Division Counsel Libraries and procures filing services for selected offices.

5. The Technical Services Branch must be informed when books, updates, subscriptions are not received.

6. The Technical Services Branch does receipt and acceptance for books purchased for the IRS Counsel Library, Associate/Division Libraries, for items purchased by the National Office for the Field libraries.

7. The Technical Services Branch must be informed when books are removed from Associate/Division Counsel collections. The titles are offered to field libraries, other Division/Counsel Libraries, and federal libraries via Library of Congress FEDLIB Bulletin Board prior to destruction and must be removed from the catalog.


**30.8.1.4** **(11-09-2012)**

### Field Libraries

1. Field libraries are located in Counsel PODs and are maintained by Finance and Management (F&M) staff.


**30.8.1.4.1** **(11-09-2012)**

#### Field Library Point of Contact

1. Each F&M Area has designated a Field Library Point of Contact (POC) who serves as the point of contact between the IRS Counsel Library staff and the Area's field libraries. The POC is expected to be knowledgeable of the core collections in the field libraries.

2. The POC is responsible for:



1. Coordinating field library acquisitions.

2. Identifying titles which provide a discount when purchased in bulk, and consolidating those purchases for the Area.

3. Ensuring that staffing figures used for supporting purchases are correct.

4. Coordinating requests for exceptions to the Core Library Collection.

5. Determining how to handle vendor open market letters for items not renewed.

6. Coordinating the Printed Tax Reference Material (PTRM) Survey code and regulation ordering information and providing correct numbers to the IRS Counsel Library Technical Branch.


**30.8.1.4.2** **(11-09-2012)**

#### Core Library Collection

1. In Fiscal Year 2003, the core library collection was established for all Field Counsel Offices. The libraries are divided by FM areas into Area 1, Area 2, Area 3, and Area 4. In general, the core library collection consists of standardized books and subscriptions that are housed in each field library. The core library collection is periodically evaluated to see whether changes need to be made. The procedures for requesting exceptions to the Core Library Collection are provided in CCDM 30.8.1.4.2.3.


**30.8.1.4.2.1** **(11-09-2012)**

##### Field Library Spreadsheets

1. An Excel spreadsheet was developed for each F&M Area. Every Counsel office has a library worksheet. The worksheets are grouped into a spreadsheet containing all of the cities within their respective areas. These spreadsheets are designed to serve as a record of which titles are maintained for each city’s library as well as a procurement tool for the IRS Counsel Library staff and the FM staff responsible for local library purchases.

2. Field Library spreadsheets are mapped to the shared drive set up and maintained by the IRS Counsel Library staff. No changes can be made to the spreadsheets on the shared drive. A shortcut icon can be created on the desktop to access this drive after the mapping is created. The intranet mapping instructions are located on the Field Library Support page.

3. Every title designated as either a core item or as an essential item is listed on the spreadsheet. Area library collection spreadsheets are updated by the IRS Counsel Library to reflect known current fiscal year renewals, new title purchases, and bona fide need purchases.

4. Titles deleted from the core are listed with a strike-through and a comment. The titles are removed from the spreadsheet in the following year.

5. The spreadsheet is not an inventory of everything housed within the field library. Many libraries contain monographic treatises (titles that have no supplementation), single titles, one time publications, etc., that will not be maintained or supported in the core definition.

6. The spreadsheets provide vendor information, titles, what has been ordered, what needs to be ordered, who has ordering responsibility, estimated cost and/or actual cost, and the procurement vehicle (i.e., requisition number or purchase order number). See the Field Library Support page for information on accessing the F&M Field Library spreadsheets.

7. As additional titles are approved for purchase the titles will be added to the spreadsheet.

8. The Library Director is responsible for all spending related to the Library; therefore, all library books and subscriptions must be approved by the Director or the designee prior to purchase.

9. Funding for the titles in the Core Library Collection is in the IRS Counsel Library’s financial sub-plan. The IRS Counsel Library supplies the appropriate accounting string and requisition numbers to the Area POC each fiscal year.


**30.8.1.4.2.1.1** **(11-09-2012)**

###### Maintenance of the Core Collection Spreadsheets

1. The POC periodically copies the spreadsheets from the shared drive, saves them by office, and updates them as necessary. Errors on the spreadsheets should be brought to the Library Director’s attention so necessary corrections may be made as soon as possible.

2. The POC sends the annotated spreadsheets to the field offices for tracking receipt of ordered materials, identifying which items will be received weekly, monthly, quarterly biannually, or annually.


**30.8.1.4.2.2** **(11-09-2012)**

##### Ordering Procedures for Core Materials

1. Items listed in the F&M Field Library spreadsheets are the only items that may be ordered. All exceptions must be approved by the Library Director. See CCDM 30.8.1.4.2.3, Exceptions to the Core Library Collection, below.

2. All requisitions for core materials must be approved by the Library Director before the Area POC approves library materials purchases. Both approvals must be secured prior to purchase regardless of whether the requisition is a credit card purchase or a purchase order.



### Note:



In the absence of the Library Director, the approving official will be the Chief, Technical Services Branch.

3. The IRS Counsel Library staff either purchases or provides the procurement information for all new titles and renewals from Commerce Clearing House (CCH), Bloomberg BNA, Thomson Reuters RIA, Lexis Nexis Matthew Bender, and Thomson West with the exception of any open market items. The open market items are those that are published periodically throughout the fiscal year and are not part of the Federal Supply Schedule.



### Example:



Although the U. S. Code Annotated (USCA ) is on the Federal Supply Schedule, West may publish additional volumes to a title that are not part of the subscription or on the Federal Supply Schedule.

4. Field offices should send subscription renewal notices to the Area POC.



1. The POC will review the appropriate office spreadsheet to verify the item(s) is to be ordered.

2. If the renewal is from a vendor for which IRS Counsel Library is to do the requisition, the POC provides a copy of the renewal to the IRS Counsel Library. After the requisition is completed, the POC will notify the field office of the purchase order number.

3. For renewals processed by the POC, appropriate entry into the Integrated Procurement System (IPS) is completed for either a credit card purchase or purchase order procurement. Field offices will be notified of requisition or purchase order number.


**30.8.1.4.2.2.1** **(11-09-2012)**

###### Receipt and Acceptance in IPS

1. Subscriptions are "received" in IPS (Integrated Procurement System) at the time the purchase is completed as "advance pay." In other words, the requisition/purchase order is annotated as received in total.

2. If the IRS Counsel Library orders a title that is not a subscription and will need to be posted in IPS when received, the Area POC will be notified.



1. When the title is received, the POC will obtain and email/fax a copy of the title page and the packing slip annotated with the date received and the requisition number or purchase order number to the National Office (N.O.). The N.O. will indicate in IPS that the items have been received by the offices so the invoices can be paid.


3. Receipt and acceptance in IPS for certain purchase order are completed as line items are invoiced. When invoiced, the Beckley Finance Center will notify the POC via email/fax. The POC enters the receipt and acceptance data as necessary and informs the Beckley contact of that action.

4. Field offices must send copies of receipt documents to the POC for filing in the requisition folders.

5. Items that are ordered and not received must be claimed, i.e. the vendor must be contacted and informed that the item was not received by the library. In this case, the Field Counsel Office will notify the POC that items have not been received so that proper follow-up can be done.


**30.8.1.4.2.3** **(11-09-2012)**

##### Exceptions to the Core Library Collection

1. All exceptions to the core library collection must be approved by the Library Director. Exceptions include both requests for new title purchases as well as the deletion of current items from the field library core collections.

2. Each request will be determined individually. The overall process is as follows:



1. All exceptions to the library must be routed through the Field Library POC with a courtesy copy to the FM Area Manager.

2. The field library POC routes the request to the IRS Counsel Library Director with a courtesy copy to the IRS Counsel Library Technical Services Branch Chief.

3. The Library Director informs the field Library POC of the final decision.

4. The POC or local FM Office Manager informs the patron requesting the title of the decision.


3. Alternatives to purchasing additional titles include interlibrary loans from other field libraries, the IRS Counsel Library, or public, academic, and specialized libraries.


**30.8.1.4.2.3.1** **(11-09-2012)**

###### Additions to the Core Library Collection

1. Each new title purchase request must be justified and requested via the field Library Purchase Justification form on the IRS Counsel Library home page. If that form is not used, a library purchase justification must contain the following information:



1. Requestor name, office symbols, telephone number, fax number, email address

2. Book Title/Author/Edition or Copyright date

3. Publisher and cost (if known)

4. What type of information does this title have that is not readily available in your local resources either print or electronic? If already available in one format, is it important to have this information available in multiple formats? What advantage does one format have over the available format?

5. Is the information in this title of lasting value to the government? How often do you anticipate using this title (daily, weekly, monthly, etc.)?

6. Does the title have information needed in past instances but not otherwise located? How was not having the information a disadvantage?


2. All requests for new titles must be supported by the Area Counsel (AC) of the office requesting the title. For example, if an SBSE attorney or manager indicates that a field office needs a particular title, the SBSE Area Counsel for that office must concur with the purchase. The field office must include documentation of the Area Counsel's concurrence when sending the request to the Field Library POC.

3. The POC ensures the proper justification and/or authorization is provided for the specialized title request and reviews the IRS Counsel Library catalog to see if the item is already owned by any of the libraries within the Office of Chief Counsel. The POC will then submit the request and approvals to the IRS Counsel Library Director.

4. New purchase requests are reviewed by the Library Director. When appropriate, the Division/Deputy Division Counsel, Associate Counsel of Finance and Management, or the Field Advisory Group is consulted regarding the purchase.

5. The Field Library POC is informed regarding the decision. The POC is responsible for informing the individual/office who made the initial request of the final decision.

6. The newly purchased item is added to the appropriate field library spreadsheet by the IRS Counsel Library. See the purchasing guidelines in CCDM 30.8.1.4.2.1 to determine who purchases the title.


**30.8.1.4.2.3.2** **(11-09-2012)**

###### Deletions from the Core Library Collection

1. If a title is included on the field library spreadsheet that isn’t wanted or needed by the offices the library supports, the following steps must be taken to delete the title.



### Note:



Funds saved by deleting titles will not necessarily be used to purchase new titles for the requesting office or other field libraries.

2. The office must prepare a memorandum or email for the IRS Counsel Library explaining the office's conclusion and it must be signed by the Area Counsel(s) for every business unit represented in the office. The field office will send the memorandum or email to the Field Library POC for coordination.

3. The Library Director must approve a core title deletion from the collection. The field office memorandum as well as any other supporting documentation will be retained by the IRS Counsel Library.

4. The IRS Counsel Library sends the title discard list to the Library of Congress FEDLIB Bulletin Board, Field Library POCs, and National Office Administrative Officers so that titles may be redistributed as needed.

5. If approved, the IRS Counsel Library will delete the title from the affected Field Library spreadsheet and the Library Catalog, CounselCat.

6. If a title is removed from all field library collections, the Core Library Definition will be changed as needed and the title will be removed from all spreadsheets.


**30.8.1.5** **(11-09-2012)**

### Electronic Research Services

1. Electronic research refers to the use of computer assisted research systems, whether on-line or via CDs, to perform legal research. The Office of Chief Counsel presently subscribes to several electronic research services. Counsel users may access these services using approved equipment. (See also IRM 10.8.1.5.2.8, Personally-Owned and Other Non-Government Furnished Equipment.)



### Caution:



SBU information may not be used on personal equipment.


**30.8.1.5.1** **(11-09-2012)**

#### Electronic Research Coordinators

1. Contact information for Field and National Office Electronic Research Coordinators are provided in Exhibit 30.8.1-1. A brief explanation of the duties of the respective coordinators follows.

2. The Office of Servicewide Policy, Directives and Electronic Research ( SPDER) serves as the Contracting Officer Representative (COR) of the Servicewide electronic research contracts.

3. The **FEDLINK Coordinator** serves as the point of contact and initiates all paperwork between the Office of Chief Counsel and Library of Congress FEDLINK interagency agreements.

4. The **Counsel Electronic Research Oversight Committee member** monitors and reports on Counsel electronic research service usage, coordinates the addition or elimination of the respective services for all Counsel entities, and serves as the Counsel contact for all actions and problems pertaining to electronic research. The coordinator serves as Local Coordinator for the offices under the Associate Chief Counsel (F&M) and the Office of Chief Counsel.


**30.8.1.5.2** **(11-09-2012)**

#### Subscription to an Electronic Research Services

1. The Finance and Management libraries are responsible for coordinating all library purchases, electronic or print, through the IRS Counsel Library (Counsel Electronic Research Oversight Committee member).

2. Field and local coordinators should request approval for all electronic research services by submitting a memorandum of justification to the Counsel Electronic Research Oversight Committee member stating why the service is needed. The memorandum should also state the:



   - Estimated number of users of the service

   - Estimated hours of usage per month

   - Counsel Research Coordinator has verified that funding is available

   - Format of desired electronic research, i.e. web-based, other on-line service, CD-ROM

   - Name, address, and telephone number of the Local Coordinator

   - Vendor name, address, point of contact and telephone number


3. All electronic research services contracts are routed to Servicewide Policy, Directives & Electronic Research (SPDER) by Procurement for final approval.


**30.8.1.5.3** **(11-09-2012)**

#### Electronic Research Database ID/Passwords and Training

1. All requests for commercial electronic research database ID, passwords, and training are requested through the IRS Counsel Library, via the Library email address, by the designated field and local coordinators.


**30.8.1.5.3.1** **(11-09-2012)**

##### Cancellation of Electronic Research Database ID/Passwords

1. The field or local coordinator contacts the IRS Counsel Library, via the Library email address, when a Counsel employee separates so that the passwords and IDs to commercial electronic databases will be cancelled.

2. When there is suspected abuse of on-line electronic research system access, the field or local coordinator may request an immediate cancellation of the user identification number in question by contacting the Library Director.


**30.8.1.5.3.2** **(11-09-2012)**

##### Security of Identification Cards

1. With a valid user identification number and password, the databases for the respective electronic research services can be accessed from practically any computer at any location. Access to these databases is charged to IRS. Users should be instructed to exercise the following controls over their user identification numbers:



   - Do not share the identification number or password with anyone.

   - Do not leave or post the user identification card at the terminal site.

   - Do not access the database for purposes other than official business.


**Exhibit 30.8.1-1**

### Electronic Research Coordinators

| _**Electronic Research Coordinators — Contact Information**_ |
| :-: |
| Service-wide Electronic Research Coordinator | FEDLINK Coordinator, <br>Internal Revenue Service RAS:SPDER <br>1111 Constitution Ave., NW <br>500 NC 8-65 <br>Washington, DC 20224 |
| Counsel Electronic Research Coordinator | Internal Revenue Service <br>Division Director, IRS Counsel Library CC:FM:LIB <br>1111 Constitution Ave., NW <br>Room 4324 <br>Washington, DC 20224 <br>(202) 317-7323 |
| Field Electronic Research Coordinator | Contact the office of the F&M Area Manager |
| Local Electronic Research Coordinator | Contact the Administrative Officer for the functional area in the National Office |

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part30/irm_30-008-001#addtoany "Show all")

A2A