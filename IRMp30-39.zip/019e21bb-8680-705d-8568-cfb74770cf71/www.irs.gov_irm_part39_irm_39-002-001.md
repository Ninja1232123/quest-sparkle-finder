---
url: "https://www.irs.gov/irm/part39/irm_39-002-001"
title: "39.2.1 Labor-Management Contract Negotiations | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part39/irm_39-002-001#main-content)

- 39.2.1  [Labor-Management Contract Negotiations](https://www.irs.gov/irm/part39/irm_39-002-001#idm139912169318128)
  - 39.2.1.1  [The Role of the GLS Attorney](https://www.irs.gov/irm/part39/irm_39-002-001#idm139912169315280)
  - 39.2.1.2  [Proceedings before the Federal Services Impasses Panel](https://www.irs.gov/irm/part39/irm_39-002-001#idm139912169363088)
  - 39.2.1.3  [Negotiability Appeals Before the Federal Labor Relations Authority Arising During Negotiations or Arising From Agency-Head Review Delegated to Labor Relations](https://www.irs.gov/irm/part39/irm_39-002-001#idm139912169356880)
    - 39.2.1.3.1  [Prehearing Procedures](https://www.irs.gov/irm/part39/irm_39-002-001#idm139912169354736)
    - 39.2.1.3.2  [Hearing](https://www.irs.gov/irm/part39/irm_39-002-001#idm139912169179872)
    - 39.2.1.3.3  [Appeals](https://www.irs.gov/irm/part39/irm_39-002-001#idm139912169177216)
  - 39.2.1.4  [Negotiability Appeals Before the FLRA Arising From Treasury Agency-Head Review](https://www.irs.gov/irm/part39/irm_39-002-001#idm139912169171744)

# Part 39. Chief Counsel Directives Manual General Legal Services

# Chapter 2. Labor and Related Matters

# Section 1. Labor-Management Contract Negotiations

* * *

## 39.2.1 Labor-Management Contract Negotiations

#### Manual Transmittal

April 08, 2022

#### Purpose

(1) This transmits revised CCDM 39.2.1, Labor and Related Matters; Labor-Management Contract Negotiations.

#### Background

This section is being revised to provide current policy concerning proceedings before the Federal Services Impasses Panel and the Federal Labor Relations Authority.

#### Material Changes

(1) CCDM 39.2.1.2 was revised to clarify the role of GLS in proceedings before the Federal Services Impasses Panel.

(2) CCDM 39.2.1.3 and related subsections were revised to add a reference to the regulations applicable to negotiability appeals, and to clarify procedures for handling negotiability appeals.

(3) CCDM 39.2.1.4 was revised to remove a reference to national negotiations and to include a reference to Agency-Head review.

(4) Minor typographical errors were corrected and editorial changes made throughout.

#### Effect on Other Documents

This section supersedes CCDM 39.2.1, dated January 22, 2009.

#### Audience

Chief Counsel

#### Effective Date

(04-08-2022)

Mark Kaizen

Associate Chief Counsel

General Legal Services

**39.2.1.1** **(01-22-2009)**

### The Role of the GLS Attorney

1. The Associate Chief Counsel (General Legal Services) has the responsibility of providing legal representation to the Service and Counsel management at certain collective bargaining negotiations between:



   - The Service and the collective bargaining representative of Service employees

   - The Office of Chief Counsel and the collective bargaining representative of Counsel employees


2. This section describes the procedures the GLS attorney will use when assigned to national-level contract negotiations and/or negotiations that the Service or Counsel have delegated to their local labor-representatives.

3. Attorneys from the Area Counsel (GLS) offices act as legal advisors in the negotiation and administration of Service and Counsel collective bargaining agreements delegated to the local parties. In all other negotiations, the Deputy Associate Chief Counsel GLS or Branch Chief, Claims, Labor and Personnel Law Branch (CLP) will designate the legal advisor.

4. The role of the GLS attorney will be decided on a case-by-case basis and may include one or more of the following:



01. Participating on negotiating teams as legal counsel only

02. Being present at negotiating sessions

03. Providing legal opinions, research and advice in preparation for negotiations and at all stages of negotiations

04. Drafting and reviewing contract language

05. Advising committee members of possible legal problems including negotiability issues

06. Serving on the planning committee to recommend to the negotiating committee proposals and strategy

07. Proposing changes to negotiated agreements to cure legal problems encountered in past and current agreements

08. Handling negotiability issues arising in negotiations including responding to a request for a written declaration of non-negotiability and preparing submissions to the Federal Labor Relations Authority

09. Advising the committee on potential unfair labor practices

10. Assisting in the preparation of any written materials for presentation to the Federal Mediation and Conciliation Service or a private third-party mediator retained by the parties

11. Participating in proceedings with the Federal Mediation and Conciliation Service or a private third-party mediator providing the same legal advice and assistance role as in negotiations with the Union

12. Representing the Service and Counsel before the Federal Services Impasses Panel. See CCDM 39.2.1.2, Proceedings before the Federal Services Impasses Panel.


5. The GLS attorney will not serve as management spokesperson in negotiations involving the Service or Counsel.


**39.2.1.2** **(04-08-2022)**

### Proceedings before the Federal Services Impasses Panel

1. When either party files a request for assistance with the Federal Services Impasses Panel (FSIP or Panel), the GLS attorney is responsible for representing IRS or Counsel management at all stages of the proceedings before the FSIP in accordance with the FSIP regulations at 5 C.F.R. Part 2470. If the GLS attorney has not been involved in the negotiations leading up to the request for assistance with the Panel, then the IRS or Counsel Labor Relations Specialist is usually responsible for preparing the request. If the GLS attorney has participated in the bargaining, the GLS attorney and the Labor Relations Specialist will work together to submit the request. After the request for assistance is filed, the role of the GLS attorney will include:



1. Preparing all pre-hearing written submissions to the FSIP, as appropriate.

2. Representing the client in any impasse proceedings (typically informal conference/mediation-arbitration) ordered by the FSIP.

3. When factfinding is ordered, presenting management’s case before the factfinder, including preparing the case for hearing, examining witnesses, introducing documents, and presenting oral argument.

4. Preparing a post-hearing brief/final Agency statement (depending upon the dispute resolution proceeding employed by the FSIP), unless the FSIP directs otherwise.

5. Where factfinding before a third-party has been ordered, and if permitted by the Panel’s procedures, preparing a written statement to the FSIP setting forth the reasons for not accepting the factfinder’s recommendations if IRS or Counsel management determines not to follow the recommendations of the factfinder. The FSIP rarely resolves an impasse by ordering factfinding.


**39.2.1.3** **(04-08-2022)**

### Negotiability Appeals Before the Federal Labor Relations Authority Arising During Negotiations or Arising From Agency-Head Review Delegated to Labor Relations

1. GLS is responsible for representing IRS and Counsel management in negotiability appeals arising during negotiations or arising as a result of the Agency-Head review delegated to the appropriate Labor Relations Office. The Federal Labor Relations Authority (FLRA) regulations governing appeals from an assertion that a provision or proposal is not within the duty to bargain are found at 5 C.F.R. Part 2424.


**39.2.1.3.1** **(08-11-2004)**

#### Prehearing Procedures

1. A negotiability appeal commences when the Union files a petition for review. Where the Union has filed a petition for review of a Service or Counsel allegation that a Union proposal is not within the duty to bargain, the GLS attorney will, if served with a copy of the petition for review, and consistent with any existing memoranda of understanding and office practice, notify the appropriate servicing labor relations offices and client organizations of receipt of the petition.

2. The GLS attorney will examine the petition to (a) determine the extent of the Agency’s response and the applicable time frames; and (b) see if the petition complies with the requirements of the FLRA regulations. If appropriate, the GLS attorney will file objections to the petition.

3. The GLS attorney will assist management in preparing and participating in the post-petition conference held with a representative of the FLRA.

4. The GLS attorney will prepare and file the Agency’s statement of position in accordance with the requirements of the FLRA regulations. The Agency’s statement of position must include any request for a hearing and the reasons supporting such request.

5. If the Union files a response to the Agency’s statement of position, the GLS attorney will prepare and file a reply to the Union’s response, as appropriate, and consistent with FLRA regulations. A decision not to file a reply must be approved by Area Counsel (GLS) or the Chief, CLP, as appropriate.

6. The FLRA rarely holds hearings in negotiability appeals. If a hearing is scheduled by the FLRA, the GLS attorney will prepare the case including determining the facts, identifying and interviewing prospective witnesses, and identifying and gathering necessary documents.


**39.2.1.3.2** **(08-11-2004)**

#### Hearing

1. The GLS attorney will be prepared to make both opening and closing statements. Because the FLRA regulations provide that additional submissions will not be considered unless the FLRA, in its discretion, grants permission, the GLS attorney will consider requesting permission to file a post-hearing brief if it would be in the interest of the client and circumstances warrant an additional filing.

2. At the hearing, the GLS attorney will introduce relevant documentary and testimonial evidence which supports the Service’s or Counsel’s case.


**39.2.1.3.3** **(04-08-2022)**

#### Appeals

1. Appeals of final decision by the FLRA in negotiability disputes are to the circuit courts and are handled by the Department of Justice. If the FLRA issues a decision adverse to the Agency’s position, the GLS attorney will:



1. Promptly review the decision to determine whether grounds exist for appeal to the circuit court and to determine the applicable time frame for appeal.

2. Consult with the appropriate client organizations which have final authority for deciding whether to appeal and with servicing labor relations offices.

3. Consult with and obtain approval for an appeal from the Associate Chief Counsel, GLS.

4. Ensure compliance with General Counsel Order No. 10 and/or General Counsel Order No. 4.

5. Prepare a written memorandum for the Department of Treasury/Department of Justice supporting the appeal.

6. Ensure that any appeal to the Court of Appeals or higher has the approval of the Chief Counsel or Chief Counsel’s delegate.


**39.2.1.4** **(04-08-2022)**

### Negotiability Appeals Before the FLRA Arising From Treasury Agency-Head Review

1. Negotiability appeals arising from Agency-Head review conducted by the Department of the Treasury are handled by Treasury. Upon request, the GLS attorney will provide assistance and litigation support to the General Counsel, Department of the Treasury.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part39/irm_39-002-001#addtoany "Show all")

A2A