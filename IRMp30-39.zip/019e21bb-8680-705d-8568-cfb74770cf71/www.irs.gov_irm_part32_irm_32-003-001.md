---
url: "https://www.irs.gov/irm/part32/irm_32-003-001"
title: "32.3.1 Forms of Advice | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part32/irm_32-003-001#main-content)

- 32.3.1 [Forms of Advice](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236018236880)
  - 32.3.1.1 [Overview of Forms of Advice](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236020426784)

    - 32.3.1.1.1 [Scope](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236019499152)
    - 32.3.1.1.2 [Roles of the Associate Chief Counsel and Service Personnel in Issuing Letter Rulings, Determination Letters, and Information Letters](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236014964608)

  - 32.3.1.2 [Circumstances in Which the Associate Chief Counsel Issues Letter Rulings](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236020175344)

    - 32.3.1.2.1 [Income and Gift Tax Matters](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236008598288)
    - 32.3.1.2.2 [Estate Tax Matters](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236015263552)
    - 32.3.1.2.3 [Generation-skipping Transfer Tax Matters](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236027509008)
    - 32.3.1.2.4 [Matters Involving Additional Tax under Section 2032A(c)](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236005105184)
    - 32.3.1.2.5 [Matters Involving Qualified Domestic Trusts under Section 2056A](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236024339376)
    - 32.3.1.2.6 [Employment and Excise Tax Matters](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236000388656)
    - 32.3.1.2.7 [Administrative Provisions Matters](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236031987520)
    - 32.3.1.2.8 [Issuance of Letter Rulings Prior to the Issuance of Temporary or Final Regulations or Other Published Guidance](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236027271632)
    - 32.3.1.2.9 [Issuance of Letter Rulings for an Extension of Time](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236013626256)

  - 32.3.1.3 [Discretionary Authority to Issue Letter Rulings or Enter into Closing Agreements](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236006933552)
  - 32.3.1.4 [Areas Where No Letter Rulings Will Be Issued](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236012988016)

    - 32.3.1.4.1 [No Rule Areas Revenue Procedures](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236011854272)
    - 32.3.1.4.2 [Identical Issue under Examination](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236010985200)
    - 32.3.1.4.3 [Not on Part of an Integrated Transaction](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236017675792)
    - 32.3.1.4.4 [Not on Which Entity is Employer](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236008285056)
    - 32.3.1.4.5 [Not to Business, Trade, or Industrial Associations](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236029347040)
    - 32.3.1.4.6 [Not to Foreign Governments and Political Subdivisions](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236032361472)
    - 32.3.1.4.7 [Not on Proposed Legislation](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236008605984)
    - 32.3.1.4.8 [Not before Issuance of Regulations or Other Published Guidance](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236027675984)
    - 32.3.1.4.9 [Not on Frivolous Issues](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236000331408)
    - 32.3.1.4.10 [No "Comfort" Letter Rulings](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236000317888)
    - 32.3.1.4.11 [Not on Property Conversion after Return Filed](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236028679904)
    - 32.3.1.4.12 [Not on Alternative Plans or Hypothetical Situations](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236022375536)
    - 32.3.1.4.13 [Not on Matters in Litigation or Subject to Appeal](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236002719216)

  - 32.3.1.5 [Referral of Matters to Other Offices](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236016141856)
  - 32.3.1.6 [Letter Rulings](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236029993408)

    - 32.3.1.6.1 [May be Revoked or Modified if Found to be in Error](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236012962016)
    - 32.3.1.6.2 [Revoked or Modified Retroactively Based on Material Change in Facts](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236005939424)
    - 32.3.1.6.3 [Not Otherwise Generally Revoked or Modified Retroactively](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236028652304)
    - 32.3.1.6.4 [Retroactive Revocation to a Continuing Transaction](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236029982272)
    - 32.3.1.6.5 [Generally not Retroactively Revoked or Modified if Related to Sale or Lease Subject to Excise Tax](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236016707472)
    - 32.3.1.6.6 [May be Revoked or Modified When Transaction is Entered into Before the Issuance of the Letter Ruling](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236020426480)
    - 32.3.1.6.7 [Taxpayer may Request that Retroactivity be Limited](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236000387664)

  - 32.3.1.7 [Determination Letters](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236022261200)
  - 32.3.1.8 [Information Letters](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236007566944)
  - 32.3.1.9 [Oral Advice to Taxpayers](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236010362032)
  - 32.3.1.10 [Request to Send Response by Fax](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236006428432)
  - 32.3.1.11 [Withdrawal of Requests and Notification to Field](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236031988768)
  - 32.3.1.12 [Correction of Obvious Error](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236008807600)

    - 32.3.1.12.1 [Procedures](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236019499840)

  - 32.3.1.13 [Requirements with Respect to Submission of Requests for Letter Rulings](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236031100320)

    - 32.3.1.13.1 [Two-Part Letter Ruling Requests](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236026064864)
    - 32.3.1.13.2 [Officials to Whom Requests Are to Be Submitted](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236014744000)
    - 32.3.1.13.3 [Effect of Section 6110 on Letter Rulings](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236031737376)

      - 32.3.1.13.3.1 [Section 6110 Procedures](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236006926128)

  - Exhibit 32.3.1-1 [Sample Format for Recommendation of Application of Section 301.9100-1 Relief](https://www.irs.gov/irm/part32/irm_32-003-001#idm140236020785232)

# Part 32. Published Guidance and Other Guidance to Taxpayers

# Chapter 3. Letter Rulings, Information Letters, and Closing Agreements

# Section 1. Forms of Advice

* * *

## 32.3.1 Forms of Advice

#### Manual Transmittal

October 7, 2011

#### Purpose

(1) This transmits revised CCDM 32.3.1, Letter Rulings, Information Letters, and Closing Agreements; Forms of Advice.

#### Background

CCDM 32.3.1, Forms of Advice, is being revised to remove references to the expedited published guidance program.

#### Material Changes

(1) The deletion of former CCDM 32.3.1.10, Request for Expedited Treatment, removes references to the expedited published guidance program.

(2) Exhibit 32.3.1-1 was made compliant with Section 508 of the Rehabilitation Act.

(3) References were updated and hyperlinked.

#### Effect on Other Documents

CCDM 32.3.1 dated August 11, 2004 is superseded.

The August 11, 2004 version of CCDM 32.3.1 incorrectly stated that it incorporated procedures contained in Chief Counsel Notice CC-2003-006 CC Notice CC-2003-006 was incorporated into CCDM 32.2.5 in August, 2004.

#### Audience

Chief Counsel

#### Effective Date

(10-07-2011)

Deborah A. Butler

Associate Chief Counsel

(Procedure & Administration)

**32.3.1.1** **(08-11-2004)**

### Overview of Forms of Advice

1. Upon written request, the Service responds to inquiries by taxpayers or their authorized representatives to advise them of the proper application to specific situations of the provisions of the internal revenue laws, related statutes and regulations, or revenue rulings, and other precedents published in the Internal Revenue Bulletin. This is done to promote voluntary compliance with, and consistent administration of, the internal revenue laws in accordance with the intent and purpose of Congress. The Service responds to these inquiries in the following forms:



   - Letter rulings

   - Information letters

   - Closing agreements


2. A "letter ruling" is a written determination issued to a taxpayer by the Associate office that interprets and applies the tax laws to the taxpayer’s specific set of facts. A letter ruling includes the written permission or denial of permission by the Associate office to a request for a change in a taxpayer’s accounting method or accounting period. Once issued, a letter ruling may be revoked or modified for any number of reasons, unless it is accompanied by a "closing agreement. "

3. An "information letter" is a statement issued either by the Associate office or by a director. It calls attention to a well-established interpretation or principle of tax law (including a tax treaty) without applying it to a specific set of facts. An information letter is advisory only and has no binding effect on the Service. An information letter may be issued if the taxpayer’s inquiry indicates a need for general information or if the taxpayer’s request does not meet the requirements for a letter ruling or a determination letter, and the Service thinks general information will help the taxpayer. If the Associate office issues an information letter in response to a request for a letter ruling, the information letter is not a substitute for a letter ruling. Information letters that are issued by an Associate office are made available to the public. Information letters that are issued by the field or a director are not made available to the public.

4. A "closing agreement" is a final agreement between the Service and a taxpayer on a specific issue or liability. It is entered into under the authority in section 7121 and is final unless fraud, malfeasance, or misrepresentation of a material fact can be shown. A closing agreement may be entered into when it is advantageous to have the matter permanently and conclusively closed or when a taxpayer can show that there are good reasons for an agreement and that making the agreement will not prejudice the interests of the Government. In appropriate cases, a taxpayer may be asked to enter into a closing agreement as a condition to the issuance of a letter ruling. In other cases, closing agreements are entered into without an accompanying letter ruling.


**32.3.1.1.1** **(08-11-2004)**

#### Scope

1. The Office of Chief Counsel responds to written requests from taxpayers or their authorized representatives for letter rulings, information letters, and closing agreements under the jurisdiction of the following offices:



   - Associate Chief Counsel (Corporate)

   - Associate Chief Counsel (Financial Institutions and Products)

   - Associate Chief Counsel (Income Tax and Accounting)

   - Associate Chief Counsel (International)

   - Associate Chief Counsel (Passthroughs and Special Industries)

   - Associate Chief Counsel (Procedure and Administration)

   - Division Counsel/Associate Chief Counsel (Tax Exempt and Government Entities)


2. Appropriate Service officials in the operating divisions respond to requests for determination letters on matters that relate to Code sections under the jurisdiction of the Associate Chief Counsel and Division Counsel/Associate Chief Counsel (TEGE).

3. The first revenue procedure published each year in the Internal Revenue Bulletin provides detailed information on letter rulings, determination letters, information letters, and closing agreements and describes matters within the jurisdiction of the Associate Chief Counsel and Division Counsel/Associate Chief Counsel (TEGE).

4. Separate revenue procedures provide guidance on the procedures for obtaining letter rulings, determination letters, etc., on employee plans and exempt organizations that are under the jurisdiction of the Commissioner, Tax Exempt and Government Entities Division; and the procedures for issuing determination letters on the qualified status of pension, profit-sharing, stock bonus, annuity, and employee stock ownership plans under sections 401, 403(a), 409, and 4975(e)(7), and the status for exemption of any related trusts or custodial accounts under section 501(a).

5. For procedures that apply to inquiries received from taxpayers, tax practitioners, Members of Congress, and others that relate to the position of the Service on broad problems or that constitute general inquiries see CCDM 33.1.1, Roles and Responsibilities for Providing Legal Advice.

6. For procedures relating to Advanced Pricing Agreements, see CCDM 32.4.1, Advance Pricing Agreements.


**32.3.1.1.2** **(08-11-2004)**

#### Roles of the Associate Chief Counsel and Service Personnel in Issuing Letter Rulings, Determination Letters, and Information Letters

1. The Associate Chief Counsel and Division Counsel/Associate Chief Counsel (TEGE) issue letter rulings. Appropriate Service personnel in the operating divisions issue determination letters. The Associate Chief Counsel, Division Counsel/Associate Chief Counsel (TEGE), and Service personnel in the operating divisions issue information letters.


**32.3.1.2** **(08-11-2004)**

### Circumstances in Which the Associate Chief Counsel Issues Letter Rulings

1. There are certain guidelines that apply in considering whether the Associate Chief Counsel or Division Counsel/Associate Chief Counsel (TEGE) will issue letter rulings.


**32.3.1.2.1** **(08-11-2004)**

#### Income and Gift Tax Matters

1. In income and gift tax matters, the Associate office generally issues a letter ruling on a proposed transaction and on a completed transaction if the letter ruling request is submitted before the return is filed for the year in which the transaction that is the subject of the request was completed.


**32.3.1.2.2** **(08-11-2004)**

#### Estate Tax Matters

1. In general, the Associate office issues prospective letter rulings on transactions affecting the estate tax on the prospective estate of a living person and affecting the estate tax on the estate of a decedent before the decedent’s estate tax return is filed. The Associate office will not issue letter rulings for prospective estates on computations of tax, actuarial factors, and factual matters.

2. If the taxpayer is requesting a letter ruling regarding a decedent’s estate tax and the estate tax return is due to be filed before the letter ruling is expected to be issued, the taxpayer should obtain an extension of time for filing the return and should notify the branch considering the letter ruling request that an extension has been obtained.

3. If the return is filed before the letter ruling is received from the Associate office, the taxpayer must disclose on the return that a letter ruling has been requested, and the taxpayer should attach a copy of the pending letter ruling request to the return, and notify the Associate office that the return has been filed. The Associate office should make every effort to issue the letter ruling within 3 months of the date the return was filed.

4. If the taxpayer requests a letter ruling after the return is filed, but before the return is examined, the taxpayer must notify the director having jurisdiction over the return that a letter ruling has been requested, attach a copy of the pending letter ruling request, and notify the Associate office that a return has been filed. The Associate office should make every effort to issue the letter ruling within 3 months of the date the return has been filed.

5. If the letter ruling cannot be issued within that 3-month period, the Associate office will notify the field office having jurisdiction over the return, who may, by memorandum to the Associate office, grant an additional period for the issuance of the letter ruling.


**32.3.1.2.3** **(08-11-2004)**

#### Generation-skipping Transfer Tax Matters

1. In general, the Associate office issues letter rulings on proposed transactions that affect the generation-skipping transfer tax and on completed transactions that occurred before the return is filed. In the case of a generation-skipping trust or trust equivalent, letter rulings are issued either before or after the trust or trust equivalent has been established.


**32.3.1.2.4** **(08-11-2004)**

#### Matters Involving Additional Tax under Section 2032A(c)

1. In matters involving additional estate tax under section 2032A(c), the Associate office issues letter rulings on proposed transactions and on completed transactions that occurred before the return is filed.


**32.3.1.2.5** **(08-11-2004)**

#### Matters Involving Qualified Domestic Trusts under Section 2056A

1. In matters involving qualified domestic trusts under section 2056A, the Associate office issues letter rulings on proposed transactions and on completed transactions that occurred before the return is filed.


**32.3.1.2.6** **(08-11-2004)**

#### Employment and Excise Tax Matters

1. In employment and excise tax matters, the Associate office issues letter rulings on proposed transactions and on completed transactions either before or after the return is filed for those transactions. Generally, the employer is the taxpayer and requests the letter ruling. If the worker asks for the letter ruling, both the worker and the employer are considered to be the taxpayer and both are entitled to the letter ruling.


**32.3.1.2.7** **(08-11-2004)**

#### Administrative Provisions Matters

1. The Associate office may issue letter rulings on matters arising under the Code and related statutes and regulations that involve the following:



   - The time, place, manner, and procedures for reporting and paying taxes

   - The abatement, credit, or refund of an overassessment or overpayment of tax

   - The filing of information returns


**32.3.1.2.8** **(08-11-2004)**

#### Issuance of Letter Rulings Prior to the Issuance of Temporary or Final Regulations or Other Published Guidance

1. Unless the issue is otherwise covered by a no rule area, an Associate Chief Counsel and Division Counsel/Associate Chief Counsel (TEGE) will issue a letter ruling before the issuance of temporary or final regulations or other published guidance under the following conditions:



1. If the letter ruling request presents an issue for which the answer seems clear by applying the statute to the facts or for which the answer seems reasonably certain but not entirely free from doubt, a letter ruling may be issued.

2. The Associate office will consider all letter ruling requests and use its best efforts to issue a letter ruling even if the answer does not seem reasonably certain where the issuance of a letter ruling is in the best interests of tax administration.


2. A letter ruling will not be issued if the letter ruling request presents an issue that cannot be readily resolved before a regulation or other published guidance is issued.



### Note:



In this case, the taxpayer should be advised that it may resubmit the letter ruling request after the regulation or other published guidance has been issued (if the regulation or other published guidance does not address the issue) or when the Service has closed a regulation project or any other published guidance project that might have answered the issue or decides not to open a regulation project or any other published guidance project.


**32.3.1.2.9** **(08-11-2004)**

#### Issuance of Letter Rulings for an Extension of Time

1. The Associate Chief Counsel and Division Counsel/Associate Chief Counsel (TEGE) will consider a request for an extension of time for making an election or other application for relief under section 301.9100-3 of the Regulations on Procedure and Administration. Even if submitted after the return covering the issue presented in the section 301.9100 request has been filed and even if submitted after an examination of the return has begun or after the issues in the return are being considered by an area office or a federal court, a section 301.9100 request is a letter ruling request.

2. An election made pursuant to section 301.9100-2 is not a letter ruling request and does not require payment of any user fee. This election pertains to an automatic extension of time.

3. A section 301.9100 request (other than an election made pursuant to section 9100-2) must be in the general form of, and meet the general requirements for, a letter ruling request. In addition, the section 301.9100 request must include the information required by section 301.9100-3(e).

4. The running of any applicable period of limitations is not suspended for the period during which a section 301.9100 request has been filed. See section 301.9100-3(d)(2). If the period of limitation on assessment under section 6501(a) for the taxable year in which an election should have been made or any taxable year that would have been affected by the election had it been timely made will expire before receipt of a section 301.9100 letter ruling, the Service ordinarily will not issue a section 301.9100 ruling. See section 301.9100-3(c)(1)(ii). Therefore, the taxpayer must secure a consent under section 6501(c)(4) to extend the period of limitation on assessment. Note that the filing of a claim for refund under section 6511 does not extend the period of limitation on assessment. If section 301.9100 relief is granted, the Service may require the taxpayer to consent to an extension of the period of limitation on assessment. See section 301.9100-3(d)(2).

5. If the Service starts an examination of the taxpayer’s return for the taxable year in which an election should have been made or any taxable year that would have been affected by the election had it been timely made while a section 301.9100 request is pending, the taxpayer must notify the Associate office.

6. If the taxpayer’s return for the taxable year in which an election should have been made or any taxable year that would have been affected by the election had it been timely made is being examined by a field office or considered by an area office or a federal court, the Associate office will notify the appropriate examining agent, appeals officer, or government counsel that a section 301.9100 request has been submitted to the Associate office. The examining officer, appeals officer, or government counsel is not authorized to deny consideration of a section 301.9100 request. The letter ruling will be mailed to the taxpayer and a copy will be sent to the appropriate Service official in the operating division that has examination jurisdiction of the taxpayer’s tax return, appeals officer, or government counsel.

7. To ensure uniformity in responding to requests for relief under section 301.9100-3, each Associate Chief Counsel and Division Counsel/Associate Chief Counsel (TEGE) designates an official who is responsible for clearing actions taken in response to requests for relief and coordinating with other Associate Chief Counsel and Division Counsel/Associate Chief Counsel (TEGE) offices as needed.

8. The initiator to whom the section 301.9100-1 request is assigned may prepare a file memorandum with the proposed recommended action, which is forwarded to the reviewer and the coordinating official designated by the Associate Chief Counsel or Division Counsel/Associate Chief Counsel (TEGE) with the letter for approval. This memorandum also explains the basis for the recommendation. This file memorandum is prepared in the format shown in Exhibit 32.3.1-1.

9. The letter ruling granting or denying section 301.9100-1 relief is prepared for the signature of the appropriate official. See Delegation Order 30-3, Extension of Time for Making Certain Elections (IRM 1.2.53.4).



### Caution:



Not all reviewers have been delegated the authority to sign letters responding to requests for relief under section 301.9100-1. See Delegation Order 30-3.


**32.3.1.3** **(08-11-2004)**

### Discretionary Authority to Issue Letter Rulings or Enter into Closing Agreements

1. The Service has discretionary authority to issue letter rulings or to enter into closing agreements. That discretion is exercised in the light of all relevant circumstances, including the business or other reasons motivating the transaction and considering whether issuing the letter ruling or entering into the agreement is consistent with sound tax administration.

2. Generally, the Service does not issue letter rulings dealing with a particular area that is under extensive study or review, except that, where the Service has an established position, it will ordinarily continue to rule in accordance with that position until it has adopted a new or changed position.


**32.3.1.4** **(08-11-2004)**

### Areas Where No Letter Rulings Will Be Issued

1. The Service has identified a number of specific and general areas in which it will not issue letter rulings.


**32.3.1.4.1** **(08-11-2004)**

#### No Rule Areas — Revenue Procedures

1. There are certain areas in which, because of the inherently factual nature of the problem involved, or for other reasons, the Service will not issue or ordinarily will not issue letter rulings. A list of these areas is set forth in separate revenue procedures issued annually. When there are additions to and deletions from these no-rule revenue procedures, they are announced in revenue procedures published during the year.



### Note:



The Service publishes changes to the no-rule areas throughout the year to inform taxpayers of changes as they are approved by an Associate Chief Counsel or Division Counsel/Associate Chief Counsel (TEGE). A branch should submit any proposal to establish a no-rule area or to resume ruling in a previously approved no-rule area promptly and with adequate explanation, to the appropriate Associate Chief Counsel or Division Counsel/Associate Chief Counsel (TEGE) for approval.

2. The Associate Chief Counsel and Division Counsel/Associate Chief Counsel (TEGE) may decline to rule on an issue even though the issue is not listed in a revenue procedure as a no-rule area. If the issue is recurring or otherwise part of a pattern, the office should consider submitting a proposal to establish a no-rule area for the issue.


**32.3.1.4.2** **(08-11-2004)**

#### Identical Issue under Examination

1. The Service ordinarily does not issue a letter ruling if, at the time of the request the identical issue is involved in the taxpayer’s return for an earlier period and that issue:



1. Is being examined by a field office;

2. Is being considered by an area office;

3. Is pending in litigation in a case involving the taxpayer or a related taxpayer;

4. Has been examined by a field office or considered by an area office and the statutory period of limitations on assessment or on filing a claim for refund or credit of tax has not expired; or

5. Has been examined by a field office or considered by an area office and a closing agreement covering the issue or liability has not been entered into by a field office or by an area office.


**32.3.1.4.3** **(08-11-2004)**

#### Not on Part of an Integrated Transaction

1. An Associate office ordinarily will not issue a letter ruling on only part of an integrated transaction. If, however, a part of a transaction falls under a no-rule area, a letter ruling on other parts of the transaction may be issued.


**32.3.1.4.4** **(08-11-2004)**

#### Not on Which Entity is Employer

1. The Service does not ordinarily issue a letter ruling on which of two entities, under common law rules applicable in determining the employer-employee relationship, is the employer, when one entity is treating the worker as an employee.


**32.3.1.4.5** **(08-11-2004)**

#### Not to Business, Trade, or Industrial Associations

1. The Service does not issue letter rulings to business, trade, or industrial associations or to similar groups concerning the application of the tax laws to members of the group. But groups and associations may submit suggestions of generic issues that would be appropriately addressed in revenue rulings. The Service may issue letter rulings to groups or associations on their own tax status or liability.


**32.3.1.4.6** **(08-11-2004)**

#### Not to Foreign Governments and Political Subdivisions

1. The Service does not issue letter rulings to foreign governments or their political subdivisions about the U.S. tax effects of their laws. The Associate office also does not issue letter rulings on the effect of a tax treaty on the tax laws of a treaty country for purposes of determining the tax of the treaty country. Treaty partners can continue to address matters such as these under the provisions of the applicable tax treaty. In addition, the Associate office may issue letter rulings to foreign governments or their political subdivisions on their own tax status or liability under U.S. law.


**32.3.1.4.7** **(08-11-2004)**

#### Not on Proposed Legislation

1. The Service ordinarily does not issue letter rulings on a matter involving the federal tax consequences of any proposed federal, state, local, municipal, or foreign legislation. The Office of Division Counsel/Associate Chief Counsel (Tax Exempt and Government Entities) may issue letter rulings regarding the effect of proposed state, local, or municipal legislation upon an eligible deferred compensation plan under section 457(b) provided that the letter ruling request relating to the plan complies with the other requirements of this revenue procedure. The Associate office also may provide general information in response to an inquiry.


**32.3.1.4.8** **(08-11-2004)**

#### Not before Issuance of Regulations or Other Published Guidance

1. The Service will not issue a letter ruling if the request presents an issue that cannot be readily resolved before a regulation or any other published guidance is issued. When the Service has closed a regulation project or any other published guidance project that might have answered the issue or decides not to open a regulation project or any other published guidance project, the Associate office may consider all letter ruling requests unless the issue is covered by a no-rule area.


**32.3.1.4.9** **(08-11-2004)**

#### Not on Frivolous Issues

1. The Service will not issue a letter ruling on frivolous issues. A "frivolous issue" is one without basis in fact or law, or that espouses a position which has been held by the courts to be frivolous or groundless. Examples of frivolous or groundless issues include, but are not limited to:



1. Frivolous "constitutional" claims, such as claims that the requirement to file tax returns and pay taxes constitutes an unreasonable search barred by the Fourth Amendment; violates Fifth and Fourteenth Amendment protections of due process; violates Thirteenth Amendment protections against involuntary servitude; or is unenforceable because the Sixteenth Amendment does not authorize nonapportioned direct taxes or was never ratified;

2. Claims that income taxes are voluntary, that the term "income" is not defined in the Internal Revenue Code, or that preparation and filing of income tax returns violates the Paperwork Reduction Act;

3. Claims that tax may be imposed only on coins minted under a gold or silver standard or that receipt of Federal Reserve Notes does not cause an accretion to wealth;

4. Claims that a person is not taxable on income because he or she falls within a class entitled to "reparation claims" or an extra-statutory class of individuals exempt from tax, e.g., "free-born" individuals;

5. Claims that a taxpayer can refuse to pay taxes on the basis of opposition to certain governmental expenditures;

6. Claims that taxes apply only to federal employees; only to residents of Puerto Rico, Guam, the U.S. Virgin Islands, the District of Columbia, or "federal enclaves" ; or that sections 861 through 865 or any other provision of the Internal Revenue Code imposes taxes on U.S. citizens and residents only on income derived from foreign based activities;

7. Claims that wages or personal service income are not "income," are "nontaxable receipts," or "are a nontaxable exchange for labor;"

8. Claims that income tax withholding by an employer on wages is optional; or

9. Other claims the courts have characterized as frivolous or groundless.


2. Further information on frivolous tax arguments can be found at http://www.irs.gov/pub/irs-utl/friv\_tax.pdf.


**32.3.1.4.10** **(08-11-2004)**

#### No "Comfort" Letter Rulings

1. In general, a letter ruling will not be issued with respect to an issue that is clearly and adequately addressed by statute, regulations, decisions of a court, revenue rulings, revenue procedures, notices, or other authority published in the Internal Revenue Bulletin. However, the Associate office may in its discretion determine to issue a letter ruling on such an issue if the Associate office is otherwise issuing a ruling on another issue arising in the same transaction.


**32.3.1.4.11** **(08-11-2004)**

#### Not on Property Conversion after Return Filed

1. The Associate office does not issue a letter ruling on the replacement of involuntarily converted property, whether or not the property has been replaced, if the taxpayer has already filed a return for the taxable year in which the property was converted.


**32.3.1.4.12** **(08-11-2004)**

#### Not on Alternative Plans or Hypothetical Situations

1. The Service will not issue a letter ruling on alternative plans of proposed transactions or on hypothetical situations.


**32.3.1.4.13** **(08-11-2004)**

#### Not on Matters in Litigation or Subject to Appeal

1. The Service will not issue a letter ruling on a matter upon which a court decision adverse to the Government has been handed down and the question of following the decision or litigating further has not yet been resolved.


**32.3.1.5** **(08-11-2004)**

### Referral of Matters to Other Offices

1. Requests for determination letters received by directors that may not be issued by a field office will be forwarded to the Associate office for reply. The field office will notify the taxpayer that the matter has been referred.

2. If the request involves an issue on which the Service will not issue a letter ruling or determination letter, the request will not be forwarded to the Associate office. The field office will notify the taxpayer that the Service will not issue a letter ruling or a determination letter on the issue.

3. Requests for letter rulings received by the Associate office that are covered by a no rule area, or if the Associate in its discretion decides not to issue a ruling, will be forwarded to the field office that has examination jurisdiction over the taxpayer’s return. The taxpayer will be notified of this action.

4. A request for a letter ruling mistakenly sent to a director will be returned by the director to the taxpayer so that the taxpayer can send it to the Associate office.

5. Directors will also refer to the Associate office any request for a determination letter that in their judgment should have the attention of the Associate office.


**32.3.1.6** **(08-11-2004)**

### Letter Rulings

1. Generally, no statement by any official of the Service, other than a closing agreement under section 7121, is final and conclusive upon the Service.

2. A taxpayer may not rely on a letter ruling issued to another taxpayer. See section 6110(k)(3).

3. A letter ruling, except to the extent incorporated in a closing agreement, may be revoked or modified at any time under appropriate circumstances.

4. A taxpayer ordinarily may rely on a letter ruling received from the Associate office subject to the conditions and limitations described in this section.


**32.3.1.6.1** **(08-11-2004)**

#### May be Revoked or Modified if Found to be in Error

1. Unless it was part of a closing agreement, a letter ruling found to be in error or not in accord with the current views of the Service may be revoked or modified. If a letter ruling is revoked or modified, the revocation or modification applies to all years open under the period of limitations unless the Service uses its discretionary authority under section 7805(b) to limit the retroactive effect of the revocation or modification.

2. A letter ruling may be revoked or modified by:



   - A notice to the taxpayer to whom the letter ruling was issued;

   - The enactment of legislation or ratification of a tax treaty;

   - A decision of the United States Supreme Court;

   - The issuance of temporary or final regulations; or

   - The issuance of a revenue ruling, revenue procedure, notice, or other statement published in the Internal Revenue Bulletin.


3. The publication of a notice of proposed rulemaking does not affect the application of any letter ruling.

4. If a letter ruling relates to a continuing action or a series of actions, it ordinarily will be applied until any one of the events described above occurs or until it is specifically revoked.


**32.3.1.6.2** **(08-11-2004)**

#### Revoked or Modified Retroactively Based on Material Change in Facts

1. The revocation or modification of a letter ruling will be applied retroactively to the taxpayer for whom the letter ruling was issued or to a taxpayer whose tax liability was directly involved in the letter ruling if:



1. There has been a misstatement or omission of controlling facts;

2. The facts at the time of the transaction are materially different from the controlling facts on which the letter ruling was based; or

3. If the transaction involves a continuing action or series of actions, the controlling facts change during the course of the transaction.


2. If a letter ruling is issued covering a particular transaction and the controlling facts on which the letter ruling is based are later changed, a taxpayer is not protected against retroactive revocation or modification of the letter ruling when the transaction is completed after the change in the controlling facts. Similarly, a taxpayer is not protected against retroactive revocation or modification of a letter ruling involving a continuing action or a series of actions occurring after the controlling facts on which the letter ruling is based have changed.


**32.3.1.6.3** **(08-11-2004)**

#### Not Otherwise Generally Revoked or Modified Retroactively

1. Except in rare or unusual circumstances, the revocation or modification of a letter ruling for reasons other than a change in facts as described in CCDM 32.3.1.6.2, Revoked or Modified Retroactively Based on Material Change in Facts, will not be applied retroactively to the taxpayer for whom the letter ruling was issued or to a taxpayer whose tax liability was directly involved in the letter ruling provided that:



1. There has been no change in the applicable law;

2. The letter ruling was originally issued for a proposed transaction; and

3. The taxpayer directly involved in the letter ruling acted in good faith in relying on the letter ruling, and revoking or modifying the letter ruling retroactively would be to the taxpayer’s detriment.


2. If a letter ruling is revoked or modified by a letter with retroactive effect, the letter will, except in fraud cases, state the grounds on which the letter ruling is being revoked or modified and explain the reasons why it is being revoked or modified retroactively.


**32.3.1.6.4** **(08-11-2004)**

#### Retroactive Revocation to a Continuing Transaction

1. If a letter ruling is issued covering a continuing action or series of actions and the letter ruling is later found to be in error or no longer in accord with the position of the Service, the appropriate Associate Chief Counsel or Division Counsel/Associate Chief Counsel ordinarily will limit the retroactive effect of the revocation or modification to a date that is not earlier than that on which the letter ruling is revoked or modified.


**32.3.1.6.5** **(08-11-2004)**

#### Generally not Retroactively Revoked or Modified if Related to Sale or Lease Subject to Excise Tax

1. A letter ruling holding that the sale or lease of a particular article is subject to the manufacturer’s excise tax or the retailer’s excise tax may not retroactively revoke or modify an earlier letter ruling holding that the sale or lease of such an article was not taxable if the taxpayer to whom the letter ruling was issued, in relying on the earlier letter ruling, gave up possession or ownership of the article without passing the tax on to the customer. (Section 1108(b), Revenue Act of 1926.)


**32.3.1.6.6** **(08-11-2004)**

#### May be Revoked or Modified When Transaction is Entered into Before the Issuance of the Letter Ruling

1. A taxpayer is not protected against retroactive revocation or modification of a letter ruling involving a transaction completed before the issuance of the letter ruling or involving a continuing action or series of actions occurring before the issuance of the letter ruling because the taxpayer did not enter into the transaction relying on a letter ruling.


**32.3.1.6.7** **(08-11-2004)**

#### Taxpayer may Request that Retroactivity be Limited

1. If a letter ruling is revoked or modified, the new letter ruling applies to all open years under the statutes, unless the Commissioner or the Commissioner’s delegate exercises the discretionary authority under section 7805(b) to limit the retroactive effect of the new letter ruling.



### Caution:



See section 6404(f) regarding the abatement of penalties or addition to tax attributable to erroneous written advice of the Service.


**32.3.1.7** **(08-11-2004)**

### Determination Letters

1. A determination letter issued by a director has the same effect as a letter ruling issued to a taxpayer.


**32.3.1.8** **(08-11-2004)**

### Information Letters

1. An information letter is advisory only and has no binding effect on the Service.

2. See CCDM 32.3.3, Information Letters, for procedures concerning information letters.


**32.3.1.9** **(08-11-2004)**

### Oral Advice to Taxpayers

1. The Service does not orally issue letter rulings or determination letters, nor does it issue letter rulings or determination letters in response to oral requests from taxpayers. Service employees ordinarily will discuss with taxpayers or their representatives inquiries regarding whether the Service will rule on particular issues and questions relating to procedural matters about submitting requests for letter rulings or determination letters for a particular case.

2. At the discretion of the Service and as time permits, substantive issues also may be discussed. Such a discussion will not be binding on the Service in general or on the Office of Chief Counsel in particular and cannot be relied upon as a basis for obtaining retroactive relief under the provisions of section 7805(b).

3. Substantive tax issues involving the taxpayer that are under examination, in appeals, or in litigation will not be discussed by Service employees not directly involved in the examination, appeal, or litigation of the issues unless the discussion is coordinated with those Service employees who are directly involved in the examination, appeal, or litigation of the issues. The taxpayer or the taxpayer’s representative ordinarily will be asked whether the oral request for guidance or information relates to a matter pending before another office of the Service or before a federal court.


**32.3.1.10** **(08-11-2004)**

### Request to Send Response by Fax

1. If the taxpayer requests, a copy of any document related to the letter ruling request may be faxed to the taxpayer or the taxpayer’s authorized representative (for example, a request for additional information or the letter ruling).

2. A request to fax a copy of any document related to the letter ruling request to the taxpayer or the taxpayer’s authorized representative must be made in writing, either as part of the original letter ruling request or prior to the mailing, or with respect to the letter ruling prior to the signing, of the document.

3. The letter ruling may be faxed by either the branch representative or the Docket, Records, and User Fee Branch of the Legal Processing Division (CC:PA:LPD:DRU). The branch representative will fax all documents, other than the letter ruling, to the taxpayer or the taxpayer’s authorized representative.

4. For purposes of § 301.6110-2(h), a letter ruling is not issued until the ruling is mailed.


**32.3.1.11** **(08-11-2004)**

### Withdrawal of Requests and Notification to Field

1. A taxpayer may withdraw a request for a letter ruling or determination letter at any time before the letter ruling or determination letter is signed by the Service. Correspondence and exhibits related to a request that is withdrawn or related to a letter ruling request for which the Associate office declines to issue a letter ruling will not be returned to the taxpayer. In appropriate cases, the Service may publish its conclusions in a revenue ruling or revenue procedure.

2. If a taxpayer withdraws a letter ruling request or if the Associate office declines to issue a letter ruling, the Associate office generally will notify, by memorandum, the appropriate Service official in the operating division that has examination jurisdiction of the taxpayer’s tax return and may give its views on the issues in the request to the Service official to consider in any later examination of the return.


**32.3.1.12** **(08-11-2004)**

### Correction of Obvious Error

1. Occasionally, an obvious error in a letter ruling is discovered by the taxpayer or the Service. Depending on the nature of the error, corrections may be accomplished by substituting corrected pages or by reissuing an entire letter.

2. An obvious error includes a typographical error, incorrect citation, incorrect cross references, or an inadvertent omission of a requested ruling.



### Caution:



A request for reconsideration of a ruling or a request for supplemental rulings is not a request for correction of an obvious error and therefore is not subject to the procedures that follow.


**32.3.1.12.1** **(08-11-2004)**

#### Procedures

1. A taxpayer may request correction of obvious errors either orally or in writing. Requests for corrections of obvious errors in letter rulings are to be processed within 14 calendar days of the receipt of the request for correction.

2. The initiator should take the following preliminary steps to process the correction:



1. Ask the taxpayer to confirm an oral request in writing

2. Obtain the official file for the original ruling

3. Ensure that the taxpayer’s request meets the definition of an obvious error

4. Contact the Disclosure & Litigation Support Branch, Office of the Associate Chief Counsel (P&A), to determine if the underlying letter ruling has been released for public inspection under section 6110; if not, determine when it is scheduled for release.


3. If the underlying letter ruling has not been released under section 6110, request that the Disclosure & Litigation Support Branch remove the letter ruling from those to be released pending the submission of the requested correction. Using the TECHMIS number of the letter ruling, provide the Disclosure & Litigation Support Branch with the following information:



   - Taxpayer’s name

   - Correction of the obvious error

   - Date of request for correction

   - TECHMIS number of the original ruling and workload item number

   - Originating office

   - Closing date of underlying letter


4. Prepare a short cover letter addressed in the same manner as the original letter ruling to transmit the page or pages that are being corrected along with copies of the corrected pages deleted for section 6110 purposes. In addition, if the taxpayer’s representative received a copy of the original letter ruling, prepare another Letter 1690 (Exhibit 32.3.2-1 ) in order to transmit to the representative a copy of the cover letter and the corrected page or pages along with a section 6110 copy.

5. Place a copy of the taxpayer’s request and a copy of the corrected letter ruling in the official file of the original ruling.

6. Send the original of the corrected letter ruling, three sanitized copies of the corrected ruling for section 6110 purposes, the official file, and an explanatory Form 1725, Routing Slip, to the Docket, Record & User Fee Branch for mailing. The TECHMIS case closing sheet must contain the following notation: Correction of Obvious Error-Do Not Prepare Another Notice of Intention to Disclose. Email the redacted version of the corrected letter ruling to the mailbox 6110 Disclosure.

7. If the underlying letter ruling has been released under section 6110, the request for correction of the obvious error should be controlled as an initial request for ruling but processed within 14 days of receipt of the request for correction. When released, it will be cross-referenced to the previously released section 6110 document.


**32.3.1.13** **(08-11-2004)**

### Requirements with Respect to Submission of Requests for Letter Rulings

1. Every request for a letter ruling must comply with the general requirements set forth in the annual revenue procedure for letter rulings.

2. If a request does not comply with those requirements, the office that receives the request will acknowledge the request and inform the requester of the requirements of the revenue procedure that have not been met. If the request lacks essential information, which may include additional information needed to satisfy the procedural requirements as well as substantive changes to transactions or documents needed from the taxpayer, the branch representative will tell the taxpayer during the initial or subsequent contact that the request will be closed if the Service does not receive the information within 21 calendar days from the date of the request for additional information, unless an extension of time is granted.

3. A request must be accompanied by the appropriate user fee. If the Service provides general information instead of the requested ruling, a requester may be entitled to a refund of the user fee.


**32.3.1.13.1** **(08-11-2004)**

#### Two-Part Letter Ruling Requests

1. As an alternative procedure for the issuance of letter rulings, a taxpayer who is requesting a particular conclusion on a proposed transaction may request a two-part letter ruling request. The first part must include the complete statement of facts and related documents.

2. The second part must include a summary statement of the facts the taxpayer believes to be controlling in reaching the conclusion requested. If the Service accepts the taxpayer’s statement of controlling facts, it will base its letter ruling on these facts. Ordinarily, the statement of controlling facts will be incorporated into the letter ruling. The Service reserves the right to rule on the basis of a more complete statement of the facts and to seek more information in developing the facts and restating them.


**32.3.1.13.2** **(08-11-2004)**

#### Officials to Whom Requests Are to Be Submitted

1. Requests should be sent to the appropriate offices as provided in the annual revenue procedure for letter rulings and determination letters.

2. A request for a closing agreement from an Associate Chief Counsel or Division Counsel/Associate Chief Counsel (TEGE) should be addressed as if it were a letter ruling request.

3. If a request is not addressed to the proper official, the office that receives the request in error will acknowledge the request, forward the request to the appropriate office, and advise the requester of the office to which the request was forwarded.


**32.3.1.13.3** **(10-02-2011)**

#### Effect of Section 6110 on Letter Rulings

1. Subject to the deletion of certain information, letter rulings are required to be open to public inspection under section 6110. The Service makes the deletions required by section 6110(c) before the text is made available to the public. See CCDM 37.1.1, Written Determinations Under Section 6110, and CCDM 37.1.2, Disclosure of Information, for the rules and procedures concerning disclosure under section 6110.

2. To help the Service make the required deletions, a request for a letter ruling must be accompanied by a deletions statement, which states the deletions desired. If the deletions statement is not submitted with the request, a Service representative will tell the taxpayer that the request will be closed if the Service does not receive the deletions statement within 21 calendar days.

3. Notations of third party communications should be included in any letter ruling or determination letter. See CCDM 37.1.2.9, Jurisdiction over Coordination of Litigation Involving Disclosure Issues.


**32.3.1.13.3.1** **(10-02-2011)**

##### Section 6110 Procedures

1. To accommodate procedures that apply to the Disclosure & Litigation Support Branch a letter ruling that modifies, revokes, supersedes, or otherwise affects an earlier letter involving the same taxpayer should reference in the opening or closing paragraph of the letter the date of the earlier letter, the earlier letter’s PLR number, and how the earlier letter is affected. If the taxpayer requests that the date of the earlier letter be deleted for purposes of section 6110, the initiator should contact the Disclosure & Litigation Support Branch for further instructions.

2. To satisfy section 6110(f), letter rulings issued must include the following:



   - The letter ruling plus any additional copies requested by the taxpayer

   - A deleted copy of the letter ruling

   - A Notice of Intention to Disclose, Notice 437


3. A taxpayer may protest the disclosure of certain information in a letter ruling. A taxpayer may make this protest after receiving the notice under section 6110(f)(1) of intention to disclose the letter ruling including a copy of the version proposed to be open to public inspection and notations of third-party communications under section 6110(d).

4. A taxpayer may request a delay of public inspection under section 6110(g)(3) or (4). The taxpayer must send the request for delay after receiving the notice under section 6110(f)(1) of intention to disclose, but no later than 60 calendar days after the date of the notice. See CCDM 37.1.2.2, Disclosure to Committees and Members of Congress, for additional information on deletions.


**Exhibit 32.3.1-1**

### Sample Format for Recommendation of Application of Section 301.9100-1 Relief

| **SECTION 301.9100 FILE MEMO** |
| :-: |
| Branch: (Originating Branch Number)<br>Attorney:<br>Case Control Number: | CC: (Division Symbols)<br>Phone Number: |
| Taxpayer Name: |
| Code and/or Regulation Section(s) Involved: |
| Date the election filing was due: |
| Date the failure to file was discovered: |
| Length of time from date of discovery to date § 301.9100 relief request was sought: |
| Whom did taxpayer rely on for advice: |
| FACTS: |
| Did the taxpayer apply for relief before the failure to make the election was discovered by the Service (see § 301.9100–3(b)(1)(i) of the Procedure and Administration Regulations)? |
| If the Service first discovered the failure to make the election, did that taxpayer satisfy the requirements listed in § 301.9100–3(b)(1)(ii) (inadvertence, etc), (iii) (unaware of necessity for election), (iv) (reliance on the Service), or (v) (reliance on tax professionals)? Explain briefly. |
| Is the taxpayer considered to have acted reasonably and in good faith, taking into account § 301.9100–3(b)(3)(i) (accuracy-related penalties), (ii) (whether taxpayer chose not to file), and (iii) (hindsight)? Explain briefly. |
| How has the taxpayer satisfied the requirement that there is no prejudice to the interests of the government (see § 301.9100–3(c)(1) (lower tax liability and closed years), (2) (accounting method regulatory elections), and (3) (accounting period regulatory elections))? |
| Section 301.9100 relief recommendation: GRANT\_\_\_\_\_\_ Deny\_\_\_\_\_\_ |
| RECOMMENDATION | BR. REVIEWER<br>STAFF |
| APPROVED |  |
| DISAPPROVED |  |
| DATE |  |

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part32/irm_32-003-001#addtoany "Show all")

A2A