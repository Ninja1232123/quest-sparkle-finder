---
url: "https://www.irs.gov/irm/part32/irm_32-001-002"
title: "32.1.2 Procedural Requirements for Regulation Projects | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part32/irm_32-001-002#main-content)

- 32.1.2  [Procedural Requirements for Regulation Projects](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208784562080)
  - 32.1.2.1  [The Legal File](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757652816)
  - 32.1.2.2  [Opening a Regulation Project](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757065184)
    - 32.1.2.2.1  [Published Guidance Proposals and Studies (PGP)](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757058672)
    - 32.1.2.2.2  [Project ID](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757638144)
    - 32.1.2.2.3  [Coordination with Division Counsel and Operating Divisions](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757632752)
    - 32.1.2.2.4  [Federal Register Liaison (FRL) Assignment and Review](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757629904)
    - 32.1.2.2.5  [Obtaining an OMB Regulation Identifier Number (RIN)](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208784544736)
    - 32.1.2.2.6  [Numbering the Regulation](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208784538032)
  - 32.1.2.3  [Overview of Relevant Federal Administrative Law](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208784533232)
  - 32.1.2.4  [OMB Notice of Planned Regulatory Action (7-Point Memo)](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208784264128)
  - 32.1.2.5  [Applicability of Paperwork Reduction Act](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757464192)
    - 32.1.2.5.1  [Notice of Proposed Rulemaking (NPRM)](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757566640)
    - 32.1.2.5.2  [Temporary Regulation with Cross-Referencing NPRM](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757559456)
    - 32.1.2.5.3  [Final Regulation](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757556576)
    - 32.1.2.5.4  [OMB Control Numbers](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757553072)
  - 32.1.2.6  [Certain Procedures during the Life of Regulation Project](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757550240)
    - 32.1.2.6.1  [Updates on CASE-MIS](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757549232)
    - 32.1.2.6.2  [Milestones and Other Steps](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757054576)
      - 32.1.2.6.2.1  [Issues Memorandum](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757046496)
      - 32.1.2.6.2.2  [Coordination with Other Offices Before Initial Green Circulation Draft](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757042160)
      - 32.1.2.6.2.3  [Initial Green Circulation Draft](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757039008)
      - 32.1.2.6.2.4  [Coordination with Treasury on Material Issues](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757035328)
      - 32.1.2.6.2.5  [Chief Counsel or Joint Briefing](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757032448)
      - 32.1.2.6.2.6  [Tracking Interim Milestones](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757029808)
    - 32.1.2.6.3  [Priority Guidance Plan Reports](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757025504)
    - 32.1.2.6.4  [OMB Unified Agenda](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757023776)
    - 32.1.2.6.5  [OMB Regulatory Plan](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757615968)
    - 32.1.2.6.6  [Plain Language Summary](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757609248)
  - 32.1.2.7  [Executive Order 13175](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757607056)
  - Exhibit  32.1.2-1  [Regulatory Information Service Center Regulatory Information Data Form](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757601344)
  - Exhibit  32.1.2-2  [Instructions for Completing the Regulatory Information Data Form](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757598080)
  - Exhibit  32.1.2-3  [Sample 7-Point Memo for an NPRM](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757594880)
  - Exhibit  32.1.2-4  [Sample 7-Point Memo for TD](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208757015328)
  - Exhibit  32.1.2-5  [Form 14029, Paperwork Reduction Act Submission](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208756986736)
  - Exhibit  32.1.2-6  [Instructions for Completing Form 14029](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208756983600)
  - Exhibit  32.1.2-7  [Supporting Statement for Paperwork Reduction Act Submissions](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208756979312)
  - Exhibit  32.1.2-8  [Model Language for NPRM with a Collection of Information](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208784357184)
  - Exhibit  32.1.2-9  [Model Language for Temp With a Collection of Information](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208784448512)
  - Exhibit  32.1.2-10  [Model Language for Final with a Collection of Information](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208784442768)
  - Exhibit  32.1.2-11  [Model Language for "No-Change" Memo](https://www.irs.gov/irm/part32/irm_32-001-002#idm140208784438368)

# Part 32. Published Guidance and Other Guidance to Taxpayers

# Chapter 1. Chief Counsel Regulation Handbook

# Section 2. Procedural Requirements for Regulation Projects

* * *

## 32.1.2 Procedural Requirements for Regulation Projects

#### Manual Transmittal

November 12, 2019

#### Purpose

(1) This transmits revised CCDM 32.1.2, Chief Counsel Regulation Handbook; Procedural Requirements for Regulation Projects.

#### Background

CCDM 32.1.2, Procedural Requirements for Regulations, is being revised to update information regarding the Unified Agenda, update 7-point memorandum requirements, and make other updates as necessary.

#### Material Changes

(1) CCDM 32.1.2.2.5 regarding Regulation Identifier Numbers has been updated..

(2) CCDM 32.1.2.4 has been updated to provide additional information regarding the content of 7-point memorandums and update the procedure to provide 7-point memorandums to Treasury.

(3) CCDM 32.1.2.6.2.4 has been updated to include coordination with the Office of Tax Analysis.

(4) CCDM 32.1.2.6.4 has been updated to include Executive Order 13771.

(5) Exhibits 32.1.2-3 and 32.1.2-4 have been updated with new sample 7-point memorandums.

(6) Exhibits 32.1.2-5 and 32.1.2-6 have been updated with current Paperwork Reduction Act Submission forms.

#### Effect on Other Documents

This section supersedes CCDM 32.1.2, dated August 16, 2018.

#### Audience

Chief Counsel

#### Effective Date

(11-12-2019)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**32.1.2.1** **(08-16-2018)**

### The Legal File

1. The drafting team is responsible for creating the legal file and should begin compiling the file as soon as the regulation project is opened. The legal file consists of several folders (Form 7881A , Chief Counsel File Folder) that contain all documents related to the publication of the regulation. The documents are assembled in accordance with Form 9506, Treasury Decision File Closing Information Sheet and Assembly Checklist. Each folder should be numbered and labeled with the title of the project and the project number.

2. The legal file should contain:



   - Requests received from either internal or external sources for the published guidance

   - A copy of the CASE-MIS control screen

   - All significant drafts of the regulation

   - Briefing memoranda, briefing confirmation, and Conference Reports

   - IRS and Treasury memos, transmittal and policy memos, and internal comments

   - The green circulation and the pink circulation documents

   - Pertinent handwritten notes and email communications (in reverse chronological order)

   - Public comment letters

   - Public hearing agendas, copies of sign-in sheets, speaking outlines, and notes

   - Records of any meetings with members of the public, including a list of attendees and the date, time, and place of the meeting; any documents received; and notes taken during the meeting

   - A record of all cases, statutes, regulations, legislative history, treaties, or other legal documents considered during the drafting process (for hard-to-find documents, copies of the documents themselves should be included)

   - Articles or other documents that were considered during the drafting process

   - Administrative memos and forms — CASE-MIS form, 7-point memo, completed Regulatory Flexibility Act checklist, closing memo, plain language summaries, Executive Summary, Background Memorandum, and material prepared pursuant to the Paperwork Reduction Act and Congressional Review Act/Small Business Regulatory Fairness Enforcement Act

   - Final Congressional Review Act material including Acknowledgement of Receipt forms from the Senate, House of Representatives, and GAO

   - Federal Register reprint


**32.1.2.2** **(08-11-2004)**

### Opening a Regulation Project

1. A regulation project may be opened only with the approval of the Associate Chief Counsel and Treasury. Each Associate’s office will determine the personnel that may open a regulation project on CASE-MIS.

2. Regulation projects are tracked on the Technical Management Information System (TECHMIS, which is part of Counsel’s Automated System Environment (CASE-MIS), under the PUBGUID category and the REG subcategory (and in limited situations, the PGP subtype, _see_ CCDM 32.1.2.2.1). CASE-MIS is designed to track the progress of a regulation project throughout the entire life of the project. The drafting attorney must ensure that TECHMIS is updated to reflect the interim milestones during the development of the regulation. _See_ CCDM 32.1.2.6.2 for a further discussion of interim milestones.

3. Open only one regulation project for a temporary regulation with a cross-referencing NPRM. When the IRS publishes a temporary regulation and a cross-referencing NPRM, the project ID remains open until the IRS publishes the NPRM as a final regulation or withdraws it.

4. Occasionally, Counsel and Treasury will decide to issue several final regulations with respect to one NPRM. The first final regulation retains the original project ID. After publishing the first final regulation, close that project ID. Open a new project ID for each subsequent final regulation project.

5. See CCDM 32.1.8, Publishing the Final Regulation, and CCDM 32.1.9, Closing a Regulation Project, for further discussions of procedures for tracking and closing regulation projects.


**32.1.2.2.1** **(08-16-2018)**

#### Published Guidance Proposals and Studies (PGP)

1. Published Guidance/Proposals and Studies (PGP) is a CASE-MIS subcategory (under the Published Guidance category). Counsel opens a project as a PGP when the IRS, Counsel, and Treasury have not determined what form of published guidance should be issued. PGP projects ultimately may be included on the Priority Guidance Plan.

2. Counsel also opens a PGP project for work (preparation and review) on special studies of technical issues requiring extensive research or to determine if published guidance should be issued. For example, Counsel may open a PGP for:



1. Study to determine the need for legislation or regulation on a particular tax issue,

2. Review of an IRS position to determine whether action is necessary, and

3. Congressionally mandated studies.


3. PGP projects may result in a regulation project. When that occurs, the drafting attorney should close the PGP project and open a REG project on CASE-MIS.

4. PGP projects are not included in the Unified Agenda ( _see_ CCDM 32.1.2.6.4).


**32.1.2.2.2** **(08-11-2004)**

#### Project ID

1. When a regulation project is opened, CASE-MIS assigns the project a unique identifying (project ID) number. The project ID number has three elements.



1. The first is the letters "REG" , to identify the project as a regulation project (or "PGP" , to identify it as a Published Guidance Project).

2. The second is a sequentially assigned number that represents the order in which the project was opened during the calendar year.

3. The third identifies the calendar year in which the project was opened.



      ### Example:



      REG-134026-02


2. Continue using the project ID for all stages of the project until a final regulation is published or the project is closed without regulations. See CCDM 32.1.8 ,Publishing the Final Regulation, and CCDM 32.1.9 , Closing a Regulation Project, for further discussions of procedures for tracking and closing regulation projects.


**32.1.2.2.3** **(08-16-2018)**

#### Coordination with Division Counsel and Operating Divisions

1. Once the drafting attorney begins working on the regulation project, the drafting attorney or branch reviewer should coordinate the project with the Division Counsel and other Associate offices through their publication coordinators or other person specifically designated as the contact person for the project. Each Division Counsel is responsible for further coordination within their respective office and with their respective Operating Divisions. _See_ CCDM 32.1.6.1, Review, Approval, and Publication of Regulations, for a further discussion of coordination with Division Counsel and IRS Offices.


**32.1.2.2.4** **(09-23-2011)**

#### Federal Register Liaison (FRL) Assignment and Review

1. After a regulation project is opened, a Federal Register Liaison (FRL) will be assigned to the project. The person assigning the FRL enters the FRL assignment on CASE-MIS.

2. The FRLs are experts on the Federal Register formatting and stylistic requirements. The drafting attorney should consult with the FRL assigned to the project when drafting the regulation to ensure that the regulation complies with the format and stylistic requirements for Federal Register documents. The FRL serves as the IRS’s representative with the OFR for the regulation project.

3. After the first working draft of the regulation is completed and has been approved by the branch reviewer, and prior to the Associate Chief Counsel review, the drafting attorney must provide a copy to the assigned FRL for review. The FRL should review and provide comments on the green circulation draft and the signature package draft regulation prior to those circulations. The drafting team should not send the regulation forward in green circulation and in signature package until the regulation has been reviewed by the FRL and the FRL’s changes have been made to the regulation. The FRL reviews the regulation again before it is submitted to the OFR.

4. In emergency situations, when the assigned FRL is absent, the drafting attorney should contact another FRL to review the regulation project at any stage of the project.


**32.1.2.2.5** **(11-12-2019)**

#### Obtaining an OMB Regulation Identifier Number (RIN)

1. The Regulatory Information Service Center (RISC) of the General Services Administration (GSA) uses a Regulation Identifier Number (RIN) to track every regulation project under development in all agencies of the Federal government. The Office of Management and Budget (OMB) requests that agencies include RINs in the heading of regulations published in the Federal Register.

2. Shortly after opening a regulation project, the drafting attorney, in coordination with the attorney’s reviewer, should request a RIN. The drafting attorney may contact the Publications and Regulations Branch to obtain a RIN Data Form or obtain it from https://www.reginfo.gov/public/jsp/regform/download ( _Exhibit 32.1.2-1_ ). Return the completed Regulatory Information Service Center Regulatory Information Data Form to the Publications and Regulations Branch, and a specialist in the Publications and Regulations Branch will obtain the RIN from OMB. If a RIN is requested, the project will be included on the Unified Agenda, which is available to the public.

3. A final regulation uses the same RIN as the underlying NPRM. If an NPRM is followed by multiple final regulations, the drafting attorney may obtain a new RIN for the second and any other subsequent final regulation. Alternatively, for multiple final regulations that relate to the same NPRM, the Associate Office may choose to use the same RIN, which has the advantage of limiting the number of projects and identifying related projects. If the same RIN is used, the drafting attorney should inform the Publications and Regulations Branch that the RIN should not be marked as complete and the next action on the Unified Agenda is another final regulation. In the case of a temporary regulation cross-referencing an NPRM, the TEMP and NPRM each have a separate RIN.

4. The RIN consists of two elements: "1545-" , which identifies the project as an IRS project, followed by an alphanumeric element composed of two capital letters and two numeric digits.



### Example:



1545-AQ23

5. See Exhibit 32.1.2-1, Regulatory Information Service Center Regulatory Information Data Form, and Exhibit 32.1.2-2, Instructions.


**32.1.2.2.6** **(08-11-2004)**

#### Numbering the Regulation

1. Each part in Title 26 of the CFR deals with a particular subject matter, some broad, some narrow. For example, part 1 pertains to income tax, while part 41 pertains to excise tax on use of certain highway motor vehicles. The drafting attorney must determine to which CFR part the regulation belongs.

2. The OFR sometimes allows a regulation to be keyed to a specific paragraph within a section of the Code, rather than to the section itself (for example, § 1.401(k)-1 is keyed to paragraph 401(k) of the Code). This numbering system offers advantages in identifying regulations under an especially lengthy or complex section of the Code. However, the OFR severely restricts its use because variations in the standard numbering system introduce further complexity into the CFR citation system.

3. Although a -0 section, if used, usually contains a table of contents, it may also include an overview, effective date, or any other information that is more conveniently presented at the very beginning of the regulation. The section heading must clearly identify what material is covered in the section.

4. Temporary regulations are designated with "T" as the final character in the section number and "(temporary)" at the end of the section heading (for example, § 1.280F-4T Special rules for listed property (temporary)).


**32.1.2.3** **(08-16-2018)**

### Overview of Relevant Federal Administrative Law

1. Several Federal administrative laws and procedures apply to the regulatory process. IRS/Treasury regulations are also subject to IRC § 7805. The drafting team must include a description of IRS compliance with these requirements in the Supplementary Information section of the Preamble.

2. **Paperwork Reduction Act**. The Paperwork Reduction Act (PRA) requires Federal agencies to obtain OMB approval before enforcing any "collection of information" requirement. Generally, the term "collection of information" includes reporting, recordkeeping, or disclosure requirements imposed on ten or more persons. A collection of information in a regulation is presumed to involve 10 or more persons. _See_ CCDM 32.1.2.5 for further discussion of the PRA.

3. **Administrative Procedure Act**. The Administrative Procedure Act (APA) requires agencies to publish Notices of Proposed Rulemaking (NPRMs) in the Federal Register and permit the public to submit comments. The APA also requires that regulations be published at least 30 days prior to their effective date. Interpretative regulations are generally exempt from the APA rulemaking requirements, including its notice and comment requirements. Although most IRS/Treasury regulations are interpretative, the IRS usually publishes its NPRMs in the Federal Register and solicits public comments. See CCDM 32.1.5.4.7.5.1, Administrative Procedure Act, for further discussion of the APA.

4. **Executive Order 12866 and Executive Order 13563**. Executive Order 12866 (E.O. 12866) requires agencies to notify OMB of all planned regulatory actions by preparing the 7-Point memorandum. Executive Order 12866 also requires a regulatory assessment of all regulations characterized as "significant." A regulatory assessment requires preparation of a cost-benefit analysis that must be submitted to the Office of Information and Regulatory Affairs at OMB. Generally, IRS/Treasury regulations are not "significant" as defined in the executive order. See CCDM 32.1.5.4.7.5.3 for further discussion of E.O. 12866 and treatment of significant regulations.



1. Executive Order 12866 also requires agencies to provide the public with meaningful participation in the regulatory process. Before publishing an NPRM, the views of those who are intended to be affected by the regulation should be sought. After the publication of an NPRM, the public should generally be afforded a period of at least 60 days to comment on the proposed regulation. Executive Order 12866 was supplemented by E.O. 13563 (January 18, 2011). Executive Order 13563 reinforces the notion that regulations should be adopted through an open exchange of information and a process that involves public participation. Both E.O. 12866 and E.O. 13563 also provide broad principles of regulation for agencies to follow. See CCDM 32.1.5.4.7.5.3 (12) and (13) for further discussion.


5. **Executive Order 13771.** Executive Order 13771 (E.O. 13771) provides that any new incremental cost associated with new regulations must be offset by eliminating costs imposed by at least two existing regulations. The executive order also requires that a regulation must be identified on the most recent update to the Unified Agenda prior to publication unless an exception is granted.

6. **Regulatory Flexibility Act.** Congress enacted the Regulatory Flexibility Act (RFA) to ensure that agency regulations and collection of information requirements are appropriate in scope for the businesses, organizations, and governmental jurisdiction regulated. RFA applies to interpretative regulations containing a collection of information requirements and to all legislative regulations. If the regulation is subject to RFA, the drafting team must prepare a regulatory flexibility analysis to determine whether the collection of information requirement (or, in the case of a legislative regulation, the rule itself) will have a "significant economic effect" on a substantial number of small entities. If the collection of information requirement/rule will not impose this adverse effect, an agency may certify that a regulatory flexibility analysis is not required. The drafting attorney must include a RFA checklist in the signature package. See CCDM 32.1.5.4.7.5.4 for further discussion of the RFA.

7. **Sections 7805(e) and (f)**. IRC § 7805(e)(1) provides that a temporary regulation must also be published as an NPRM. Section 7805(e)(2) provides that temporary regulations expire within three years of the date issued. Section 7805(f) provides that a final regulation, not superseding an NPRM, must be submitted to the Chief Counsel for Advocacy of the Small Business Administration for comment at least four weeks before the date of publication. Sections 7805(f)(1) and (2) require that, after publication, proposed and temporary regulations must be sent to the Small Business Administration for its comments on the regulation’s effect on small businesses. If the IRS receives comments, the preamble to the final regulations must discuss the comments. The Publications and Regulations Branch sends proposed and temporary regulations to the Small Business Administration after it is published in the Federal Register.

8. **Congressional Review Act/Small Business Regulatory Enforcement Fairness Act**. The Small Business Regulatory Enforcement Fairness Act of 1996 (SBREFA) added the Congressional Review Act (CRA). The CRA provides that temporary and final rules cannot become effective until the issuing agency submits a report to the House of Representatives, the Senate, and the Comptroller General of the General Accountability Office. The IRS meets this requirement by submitting a Congressional Review Act form (or CRA form), the regulation, the plain language summary, and other supporting documents. Note that, unlike other requirements, the preamble to the regulations does not discuss compliance with CRA/SBREFA. The CRA also mandates that no "major" rule can become effective until 60 days after the rules is delivered to the House. See CCDM 32.1.6.11.2.5 , Congressional Review Act Forms, for further discussion of the Congressional Review Act.

9. **Executive Order 13175**. Executive Order 13175 (E.O. 13175) requires agencies to maintain a process to ensure meaningful and timely consultation and collaboration with tribal officials on the development of policies with tribal implications, in particular on regulatory actions that would have a direct effect on Indian tribes. See CCDM 32.1.2.7 for further discussion of E.O. 13175.


**32.1.2.4** **(11-12-2019)**

### OMB Notice of Planned Regulatory Action (7-Point Memo)

1. Pursuant to E.O. 12866, OMB reviews all regulatory actions prior to publication. Regulatory actions are any substantive action normally published in the Federal Register that are expected to lead to a final regulation (for example, ANPRMs and NPRMs). The Notice of Planned Regulatory Action (7-point memo) is the Service’s notification to OMB of its intent to publish a regulation.

2. The 7-point memo (that actually contains 8 points) provides the following information:



1. Title and CASE-MIS ID number of the regulation

2. Whether the regulatory action is significant, as defined in E.O. 12866

3. Upcoming Action (ANPRM, NPRM, etc.)

4. Expected date of publication in the Federal Register, or expected date of submission to OMB for review, as applicable

5. RIN

6. Statutory/Judicial Deadline, if applicable

7. Brief plain language description of the regulation

8. Agency Contact (name and telephone number of Chief Counsel attorney who can respond to questions about the regulation)


3. The 7-point memo must provide context for the regulation, summarize the content of the regulation, and explain the significance of the regulation (i.e., economically significant, significant, or not significant). A significant regulatory action is a regulatory action that is likely to result in a rule that may:




|  |
| --- |
| - Have an annual effect on the economy of $100 million or more or adversely affect in a material way the economy; a sector of the economy; productivity; competition; jobs; the environment; public health or safety; or State, local, or tribal governments or communities;<br>     <br>   - Create a serious inconsistency or otherwise interfere with an action taken or planned by another agency;<br>     <br>   - Materially alter the budgetary impact of entitlements, grants, user fees, or loan programs or the rights and obligations of recipients thereof; or<br>     <br>   - Raise novel legal or policy issues arising out of legal mandates, the President’s priorities, or the principles set forth in E.O. 12866. |





1. Regulations that qualify as significant under the first bullet are generally referred to as economically significant.

2. Regulations that qualify as significant under the fourth bullet are generally referred to as policy significant.

3. IRS/Treasury regulations are rarely economically significant regulatory actions because the effect of the rule is usually due to the underlying statute, rather than to the regulation. When an IRS/Treasury regulatory action is determined to be significant, a cost-benefit analysis and a regulatory assessment must be submitted to OMB. OMB has issued guidance on what is required for an effective cost-benefit analysis. See http://www.whitehouse.gov/omb/ and CCDM 32.1.5.4.7.5.3 for further discussion on E.O. 12866 and determining whether a regulation may be significant.


4. The drafting attorney must prepare and submit the 7-point memo regarding the regulation as early in the drafting process as possible. The 7-point memo must be sent to the Treasury attorney-advisor assigned to the regulation.

5. If the IRS plans to issue a temporary regulation (TEMP) with a cross-referencing NPRM, the drafting attorney prepares only one 7-point memo. The drafting attorney should include the RINs ( _see_ CCDM 32.1.2.2.5) for both the TEMP and the cross-referencing NPRM on the 7-point memo.

6. The drafting attorney must prepare a new 7-point memo for a final regulation. The 7-point memo for a final regulation should contain a high-level summary of significant comments and whether the comments were adopted.

7. The Treasury attorney-advisor will coordinate the 7-point memo within Treasury as necessary and provide the memo to the General Counsel’s Senior Legal Advisor for Regulatory Affairs, who is the Treasury point of contact with OIRA.



### Note:



CC:FM provides a report to the Deputy Chief Counsel (Technical) that tracks all 7-point memos.

8. See Exhibit 32.1.2-3, Sample 7-Point Memos.


**32.1.2.5** **(08-16-2018)**

### Applicability of Paperwork Reduction Act

01. The Paperwork Reduction Act (44 U.S.C. 3501-3520) requires that, before any information collection request in a regulation may be enforced, the agency must:



    1. Request and obtain OMB approval for the information collection request,

    2. Explain in the information collection request how the information is to be used,

    3. State in the information collection request whether responses to the request are voluntary, required to obtain a benefit, or mandatory, and

    4. Display the OMB assigned control number on the information collection request.


02. In general, the term "collection of information" means a reporting, recordkeeping, or disclosure requirement that is imposed on ten or more persons. A collection of information in an IRS/Treasury regulation is presumed to be imposed on 10 or more persons. It does not matter whether the requirement is voluntary or mandatory, or if the requirement is imposed by statute.

03. The term "reporting requirement" means a requirement that persons provide information to an entity of the Federal government. For example, a regulation that requires a separate statement to be attached to a tax return imposes a paperwork burden subject to the PRA. However, a regulation that requires a form to be filed does not impose a paperwork requirement subject to the PRA because the form, and not the regulation, is the "instrument of collection" that is subject to the PRA.

04. The term "recordkeeping requirement" means that a person must maintain _specified_ records, whether or not an entity of the federal government or any other person actually seeks access to the records or is provided those records. The mandate to maintain specified records is a requirement in addition to the general books and records requirement of section 6001 of the Code. Thus, because a recordkeeping requirement is one that requires _specified_ records, a regulation that does not require that particular records be maintained, but nonetheless prompts some taxpayers to maintain records consistent with the provisions of section 6001, does not impose a recordkeeping requirement. This is an important distinction for purposes of determining whether the Regulatory Flexibility Act applies to the regulation. _See_ CCDM 32.1.5.4.7.5.4 for further discussion of the Regulatory Flexibility Act.

05. The term "disclosure requirement" means that a person must disclose information to another person, the Federal government, or to the public.

06. A regulation contains a collection of information if it requires:



    1. Partnerships to provide annual statements to partners that list the amount of each partner’s share of the partnership's adjusted bases of depreciable property,

    2. Taxpayers to attach a prescribed statement to their federal income tax return if they want to make an election, or

    3. Employers to keep a copy of employee reimbursement requests for seven years.


07. A regulation contains a collection of information if it imposes a new requirement or if it removes, increases, or decreases an existing requirement. The collection of information can be on paper or in electronic format.

08. If the regulation contains a collection of information, the drafting team must estimate the number of taxpayers affected and the time needed to comply with the collection of information. The drafting team must also include the burden estimates in the OMB submission.

09. If the drafting attorney is unsure whether the regulation contains a collection of information requirement, or needs assistance in determining the estimates specified in the preceding paragraph, he or she should consult with the IRS Reports Clearance Officer or the Paperwork Reduction Act contact person in the Special Services Section of the IRS Tax Forms and Publications division.

10. The PRA is available at [http://www.archives.gov/federal-register/laws/paperwork-reduction/](http://www.archives.gov/federal-register/laws/paperwork-reduction/). Additional information about PRA compliance is available at [http://www.whitehouse.gov/omb/inforeg/infocoll.html](http://www.whitehouse.gov/omb/inforeg/infocoll.html).


**32.1.2.5.1** **(08-16-2018)**

#### Notice of Proposed Rulemaking (NPRM)

1. If an NPRM contains a collection of information requirement, the drafting attorney must complete Form 14029, Paperwork Reduction Act Submission, and a Supporting Statement. As soon in the drafting process as final decisions are made with respect to a regulation’s collection of information requirements, the drafting attorney must provide the Paperwork Reduction Act contact person with:



   - Form 14029

   - Supporting Statement

   - Copy of the regulation

   - Copy of the underlying statute


2. The drafting attorney should send an email containing electronic versions of the documents to the omb.unit@irs.gov (\*OMB Unit) and a contact person will be assigned. The drafting attorney should contact the Paperwork Reduction Act contact person for questions regarding the Form 14029 or the Supporting Statement. _See_ Exhibit 32.1.2-4, Form 14029, Paperwork Reduction Act Submission; Exhibit 32.1.2-5, Instructions for Form 14029, Paperwork Reduction Act Submission; Exhibit 32.1.2-6, Sample completed Supporting Statement For Paperwork Reduction Act Submissions; and Exhibit 32.1.2-7, Model Language For NPRM With A Collection Of Information.



### Note:



See also OMB Form 83-I, Paperwork Reduction Act Submission (With Supporting Statements). Form 14029 is the IRS version of OMB Form 83-I.

3. For NPRMs, OMB must receive the PRA package by the date of publication. OMB has 60 days to either submit comments or approve the collection of information. If approved, OMB will assign the regulation an OMB control number.


**32.1.2.5.2** **(08-16-2018)**

#### Temporary Regulation with Cross-Referencing NPRM

1. For a temporary regulation with a cross-referencing NPRM, the drafting attorney prepares only one PRA package. The drafting attorney should submit the package to the PRA contact person at the time the signature package is circulated. OMB approval of the regulation is required before publication. OMB has at least 60 days to review the collection of information requirements in the temporary regulation. The drafting attorney should contact the PRA contact person if the regulation is "fast track" so that OMB approval may be requested on an expedited basis. _See_ Exhibit 32.1.2-8, Model Language for Temp with a Collection of Information.


**32.1.2.5.3** **(08-16-2018)**

#### Final Regulation

1. If a final regulation was preceded by an NPRM, the collection of information in the NPRM was approved by OMB, and the collection of information requirements are not changed in the final regulation, the drafting attorney prepares a "no-change" memo. The drafting attorney should provide the PRA contact person with an electronic version of the memo and the regulation. _See_ Exhibit 32.1.2-9, Model Language For Final With A Collection Of Information, and Exhibit 32.1.2-10, Model Language For "No-Change" Memo.

2. If the collection of information requirements in the NPRM changes in the final regulation (increased, decreased, removed) or if the regulation has a new collection of information, a new PRA package that accounts for the changed collection of information requirements may be necessary. The drafting attorney should submit the new PRA package to the PRA contact person at the time the signature package is circulated.


**32.1.2.5.4** **(08-16-2018)**

#### OMB Control Numbers

1. When OMB assigns a control number, it also assigns an expiration date for the number. The expiration date varies but is usually three years from the approval date. The Paperwork Reduction Act contact person will contact the drafting attorney or the designated contact in the appropriate associate office for assistance in renewing the control number when a control number for a regulation is about to expire. To renew the control number, a revised Form 14029 package is prepared to reflect changes in the collection of information burden.


**32.1.2.6** **(08-16-2018)**

### Certain Procedures during the Life of Regulation Project

1. The Associate office must make updates in CASE-MIS and consider the appropriateness of certain procedures during the life of a regulation project.


**32.1.2.6.1** **(08-16-2018)**

#### Updates on CASE-MIS

1. The Associate Office is responsible for ensuring that a regulation project is opened, updated to reflect milestones during the development of the regulation, and closed in accordance with the CASE-MIS handbook.

2. Each Associate office is required to enter status report and progress updates into CASE-MIS to track the progress of items on the Priority Guidance Plan (also called the Business Plan).

3. The Business Plan Tracking Instructions are available on the F&M Chief Counsel Intranet website under Planning and Finance, Systems Coordination Branch.

4. Two reports are available on CASE-MIS to track the progress of published guidance projects. The Business Plan Status Report (BPSR) reflects milestone dates and other relevant information and may be generated using various values to provide customized information. The Business Plan Mandatory Date Report allows users to quickly see which cases need immediate action based on the parameters selected by the user.


**32.1.2.6.2** **(08-16-2018)**

#### Milestones and Other Steps

1. The Office of Chief Counsel uses various milestones to manage the published guidance process. Those milestones are reflected in the revised status codes described in the Business Plan Tracking Instructions. These milestones assist in identifying whether a published guidance project is on track to be issued by its target publication date. Only the dates for "interim milestones," described in CCDM 32.1.2.6.2.6, must be estimated and tracked on CASE-MIS. The other steps in the published guidance process described in more detail below also may be appropriate for tracking the progress of particular projects.

2. The formal interim milestones set forth in CCDM 32.1.2.6.2.6 are not intended to be used as inflexible deadlines. It is understood that target dates are changed for a variety of reasons inherent in the published guidance process. Ultimately, it is more important for the Associate offices to meet the target publication dates of the individual projects over interim milestone date projections. An annual measurement is a more accurate reflection of the relative success of the Associate office in publishing guidance than a measurement of whether interim milestones have been met.

3. In addition to the mandatory green circulation draft, each Associate office may consider one or more of the following steps to complement the milestones tracked on CASE-MIS:



   - Issues memorandum

   - Coordination with other offices before initial green circulation draft

   - Initial green circulation draft

   - Coordination with Treasury on material issues

   - Chief Counsel or joint briefing


4. Associate offices should identify which of these steps may be appropriate for each project and establish target dates for completion. Except for the green circulation draft, whether any specific step described below is appropriate for a project is within the judgment and discretion of the Associate office. The steps taken and the order in which they are completed will be governed by factors such as the complexity of the project and type of guidance to be issued, as well as the relationship a particular office has with Treasury and the participating IRS operating divisions. It is anticipated that the need for particular steps will be revisited throughout the plan year as published guidance projects progress towards completion and as new developments arise.

5. These interim milestones and steps, in conjunction with the target publication date, should provide an early warning of whether delays are being encountered with respect to a project, without imposing an undue administrative burden on the Associate office. Progress on these milestones, specifically, whether and which of the interim milestones have been completed, when viewed in relation to the target publication date, will assist in determining which projects are subject to delay.


**32.1.2.6.2.1** **(08-16-2018)**

##### Issues Memorandum

1. The preparation of an issues memorandum is strongly encouraged for virtually all published guidance projects. Ideally, an issues memorandum will be prepared at a relatively early stage in the process, preferably before any significant drafting has been done. For certain more complex projects, it may be desirable to prepare additional issues memoranda as the project progresses to reflect newly identified issues and recommendations or significant revisions to the previously identified issues and recommendations. This may be appropriate, for example, in advance of a Chief Counsel or joint briefing.

2. There is no prescribed format for the issues memorandum and the level of detail is left to the discretion of the Associate office. In general, however, the issues memorandum should identify the significant issues raised in the project and should include an analysis and recommended resolution. The issues memorandum should present alternative and opposing positions, as well as whether coordination with specific offices is needed to prepare a green circulation draft.

3. Preparation of an issues memorandum will assist the Associate office in determining which other steps would be appropriate for the project, such as whether coordination should occur prior to circulation of a draft or whether a Chief Counsel or joint briefing will be needed.

4. If an issues memorandum is written, this step will be considered to have been completed when the initial issues memorandum is approved by the Associate Chief Counsel. In general, this step should be completed well before the target publication date.


**32.1.2.6.2.2** **(08-16-2018)**

##### Coordination with Other Offices Before Initial Green Circulation Draft

1. This step is designed to ensure that the Associate office coordinates with other Associate offices, Division Counsel, or IRS functions that are either directly affected by an issue in the project or with subject matter jurisdiction over an issue in the project. This coordination may be formal or informal and should be prior to any widespread circulation of a draft. It is expected that the coordination contemplated by this step will ordinarily occur at the developmental stage of the process, such as during the preliminary draft or precirculation stage.

2. This step may be appropriate more than once during the course of the project, since the need for additional coordination with other offices may arise as the project progresses. In this regard, the circulation of preliminary drafts to a wider audience is strongly encouraged. Required coordination with other offices is discussed in CCDM 32.1.1.4.5, Coordination, CCDM 32.1.2.2.3, CCDM 32.1.6.1, Coordination with Division Counsel and IRS Offices, CCDM 32.1.6.2, Coordination with Associate Offices and Counsel for the National Taxpayer Advocate, and CCDM 32.1.6.4, Review of Drafts.


**32.1.2.6.2.3** **(11-12-2019)**

##### Initial Green Circulation Draft

1. Green circulation is required for all published guidance projects except for extraordinary circumstances. The green circulation draft is discussed in CCDM 32.1.6.7, "Green" Circulation Draft. Green circulation is intended to provide offices that are not involved in the development of a project with a meaningful opportunity for comment. This milestone must be entered into CASE-MIS

2. The existing practice in some offices has been to only do a general green circulation shortly before the expected publication of the project. This practice may minimize any meaningful opportunity for comment by functions that were not previously involved in the drafting process and can result in comments being received late in the game that may delay or derail the project. Consequently, the circulation of preliminary drafts to a wider audience is strongly encouraged. Depending on the nature and extent of the comments received, it is sometimes appropriate to circulate additional drafts prior to beginning the "pink" signature package approval process.

3. This milestone will be considered to have been completed when a draft is widely circulated outside the Associate office responsible for the project. In general, the target date for this milestone should be about 2 to 4 months prior to the target publication date.


**32.1.2.6.2.4** **(11-12-2019)**

##### Coordination with Treasury on Material Issues

1. This step entails soliciting input from Treasury regarding material issues in the project, including, when appropriate, the Office of Tax Analysis regarding the economic effect of the regulatory action. Material issues are those issues requiring direction from Treasury in order to meaningfully move the project towards completion. Ideally, this coordination will occur at a relatively early stage in the process. It is recognized, however, that this step may be appropriate more than once during the course of the project, since the need for additional coordination with Treasury may arise as the project progresses and additional issues are identified and developed.

2. This step differs from the joint briefing step described in CCDM 32.1.2.6.2.5 in that the coordination contemplated in this step is generally informal and is at a level below the Assistant Secretary for Tax Policy.


**32.1.2.6.2.5** **(04-28-2009)**

##### Chief Counsel or Joint Briefing

1. This step is appropriate when a decision is needed by the Chief Counsel or Assistant Secretary for Tax Policy regarding policy or other significant issues in the project. A Chief Counsel or joint briefing is often used to resolve conflicts. In some complex projects, more than one Chief Counsel or joint briefing may be needed.

2. A Chief Counsel or joint briefing is a formal briefing at which all interested offices or functions will be represented. Accordingly, a briefing package normally will be distributed ahead of time to the participants and a conference memorandum will be prepared after the briefing summarizing the decisions that were made at the briefing.


**32.1.2.6.2.6** **(08-16-2018)**

##### Tracking Interim Milestones

1. The Business Plan Status Report Instructions (found on Finance and Management’s webpage) describe interim milestone fields on CASE-MIS. While interim milestone dates are not mandatory, they are required for all Priority Guidance Plan items. The milestone date fields are: Green Sheet, Pink Sheet, CC Review, Commissioner Review, and OTP Review. It is expected that target dates for the interim milestones that are considered appropriate for the project will be established near the beginning of the business plan year or shortly after a project is opened, for projects that are begun during the business plan year. Each target date is considered met when a project enters the next appropriate status, and once the appropriate status code is entered the checkbox next to the milestone is automatically populated. The field can be updated but the checkbox will remain checked. For example, if a case that reached status 718 (Pink Sheet) required extensive rewriting, you may put the status back to 717 (Green Sheet circulation). The new green sheet circulation date will be noted on the case history screen but the green sheet will continue to be shown as completed. Reports will show the last date a project has passed the milestone.

2. Since the interim milestones are intended to be a management tool, not an evaluative tool, the target dates for the milestones may be changed by the Associate office as appropriate. In addition, there is only one target date field per interim milestone, which will be overridden whenever a new target date is entered for that milestone.


**32.1.2.6.3** **(08-16-2018)**

#### Priority Guidance Plan Reports

1. Each Associate office enters status report and progress updates into CASE-MIS. The Priority Guidance Plan Administrator (Management Analyst, Office of the Associate Chief Counsel (Financial and Management) distributes a report providing periodic updates.


**32.1.2.6.4** **(11-12-2019)**

#### OMB Unified Agenda

1. Pursuant to the Regulatory Flexibility Act and section 4(b) of E.O. 12866, each April and October OMB publishes a government-wide _Unified Agenda of Federal Regulatory and Deregulatory Actions_ (Unified Agenda). Unified Agendas describe all regulations under development or review during the upcoming 12 months following publication of the Unified Agenda in the Federal Register. This includes, at a minimum, any plans to publish or otherwise implement an ANPRM, NPRM, or TD. Inclusion of activities that will have a next action beyond 12 months is optional.

2. A regulation with a RIN is automatically included in subsequent Unified Agendas until the RIN is closed or the regulation is published as a rule (TEMP or Final Regulation). This information is available to the public.

3. During winter and summer of each year, the Publications and Regulations Branch prepares the IRS portion of the Unified Agenda. The Publications and Regulations Branch sends instructions to the Associate offices to provide the information and updates needed to prepare the Unified Agenda. The Publications and Regulations Branch also sends copies of Regulatory Information Service Center (RISC) Update Documents (UDs) for the regulation projects assigned to each Associate office. Deadlines set by the Publications and Regulations Branch for the Associate offices to submit all required information and updates are generally firm because the Publications and Regulations Branch’s deadlines for submitting information to RISC are firm.

4. The Unified Agenda is available at [http://www.reginfo.gov/public/](http://www.reginfo.gov/public/) (click on Unified Agenda and Regulatory Plan).

5. Executive Order 13771 provides that before a regulation can be published in the Federal Register the regulation must be included on the most recent version of the Unified Agenda unless an exception is obtained from the OMB Director.


**32.1.2.6.5** **(08-16-2018)**

#### OMB Regulatory Plan

1. Pursuant to section 4(c) of E.O. 12866, an annual Regulatory Plan is prepared for the October – September fiscal year. The Regulatory Plan is a single Government-wide document that OMB publishes in the Federal Register during October. The Regulatory Plan describes the most important significant regulatory and deregulatory actions that will help implement the Administration’s policies and priorities that each agency reasonably expects to issue in proposed or final form during the upcoming fiscal year. IRS/Treasury regulations are rarely considered significant regulatory actions. However, each department or agency’s section of the Regulatory Plan contains a narrative statement of its regulatory priorities. Included in IRS/Treasury’s narrative statement are descriptions of regulatory projects to which the IRS will accord priority during the upcoming fiscal year.

2. Each summer (usually July or August), each Associate office is asked to identify and describe two or more of its most important regulatory actions (priority projects) from the current Priority Guidance Plan that the office reasonably expects to issue in proposed or final form during the upcoming Regulatory Plan fiscal year. The description for each priority project includes the need for the project, any past actions related to it, the problem/issue the regulations will address, and whether the project will be a TD or NPRM. The combined list is reviewed by the Chief Counsel’s office, which selects and prioritizes the proposed IRS list. The IRS list is then reviewed and cleared by various Treasury officials and approved by (or on behalf of) the Secretary of the Treasury.

3. The Regulatory Plan is published with the October Unified Agenda, and is available at [http://www.reginfo.gov/public/](http://www.reginfo.gov/public/) (click on Unified Agenda and Regulatory Plan).


**32.1.2.6.6** **(08-16-2018)**

#### Plain Language Summary

1. The drafting team must prepare a plain language summary (PLS) of the regulation that is included in the signature package. The PLS explains the issue addressed in the regulation in a manner easily understood by taxpayers with little or no knowledge of the tax laws. Ideally, the PLS should be six lines or less. Its purpose is to notify taxpayers (particularly individuals and small businesses) of the new regulations, explain how to get more information, and help taxpayers to determine whether they may be affected and whether to consult a tax advisor. Despite its title, the PLS is not intended to explain or summarize the substance of the regulation.


**32.1.2.7** **(09-23-2011)**

### Executive Order 13175

1. Executive Order 13175 requires agencies to consult and collaborate on the development of proposed regulations and other rules when they have policies with tribal implications. Policies with tribal implications include regulations, legislative comments or proposed legislation, and other policy statements or actions that have substantial direct effects on one or more Indian tribes, on the relationship between the Federal Government and Indian tribes, or on the distribution of power and responsibilities between the Federal Government and Indian tribes.

2. A statement or action has tribal implications if the issue solely affects tribal groups or individuals, affects a unique set of rules such as tribal treaties or nontax Federal statutes, has a disparate impact upon tribal individuals or organizations more so than other taxpayers, or has a significant or unique economic impact upon the tribal community. Reference to tribes should be read broadly to include individual tribal members, tribally owned businesses, joint ventures owned with nontribal partners, tribal government instrumentalities or subdivisions, or any other tribal organization.

3. The executive order requires consultation with tribal governments before promulgation of any regulation not required by statute that has tribal implications if the regulation either imposes substantial direct and identifiable compliance costs on a tribal government without Federal government subsidy or reimbursement for the direct costs or preempts tribal law. To the extent practicable and permitted by law, the agency must consult with tribal officials early in the process of developing the proposed regulation, provide a tribal summary impact statement in a separately identified portion of the preamble to the regulation, and make available to the Director of OMB any written communications submitted to the agency by tribal officials. The tribal summary impact statement must consist of a description of the extent of the agency’s prior consultation with tribal officials, a summary of the nature of their concerns and the agency’s position supporting the need to issue the regulation, and a statement of the extent to which the concerns of tribal officials have been met.


**Exhibit 32.1.2-1**

### Regulatory Information Service Center Regulatory Information Data Form

![This is an Image: 38994001.gif](https://www.irs.gov/pub/xml_bc/38994001.gif)

> This is a sample Regulatory Information Service Center regulatory information data form.

[Please click here for the text description of the image.](https://www.irs.gov/media/38994001.gif "")

![This is an Image: 38994002.gif](https://www.irs.gov/pub/xml_bc/38994002.gif)

> This is the second page of a sample Regulatory Information Service Center regulatory information data form.

[Please click here for the text description of the image.](https://www.irs.gov/media/38994002.gif "")

**Exhibit 32.1.2-2**

### Instructions for Completing the Regulatory Information Data Form

![This is an Image: 38994003.gif](https://www.irs.gov/pub/xml_bc/38994003.gif)

> This is the first page of instructions for completing the regulatory information data form.

[Please click here for the text description of the image.](https://www.irs.gov/media/38994003.gif "")

![This is an Image: 38994004.gif](https://www.irs.gov/pub/xml_bc/38994004.gif)

> This is the second page of instructions for completing the regulatory information data form.

[Please click here for the text description of the image.](https://www.irs.gov/media/38994004.gif "")

**Exhibit 32.1.2-3**

### Sample 7-Point Memo for an NPRM

| **Notice of Planned Regulatory Action** |
| :-: |
| Pursuant to Executive Order 12866 |
|  |
| DEPARTMENT OF THE TREASURY |
|  |
| Agency: Internal Revenue Service |
| Title: Tax Return Preparer Due Diligence Penalty Under Section 6695(g) |
| Significance: Not Significant |
| Upcoming Action: Notice of Proposed Rulemaking |
| Planned Publication Date: September 2018 |
| RIN 1545-BO63 |
| Statutory/Judicial Deadline: Not Applicable |
| Description: Before tax return preparers begin working on a client’s tax return, they gather information from the taxpayer through documents and in conversations. The purpose of gathering this information is to obtain the necessary facts to correctly prepare a taxpayer’s return and correctly determine a taxpayer’s tax obligations. As part of this process, tax return preparers gather information necessary to determining a taxpayer’s correct filing status and eligibility for credits. |
| Section 6695 of the Internal Revenue Code provides for penalties that can be asserted against tax return preparers if certain actions are taken or are not taken during the course of preparing a tax return. Paragraph (g) of section 6695 provides for a penalty if a tax return preparer fails to exercise due diligence when determining eligibility for certain tax benefits. When section 6695(g) was added to the Code, it only addressed due diligence requirements related to a taxpayer’s eligibility for the earned income credit (EIC) under section 32. The Treasury Department and the IRS issued regulations establishing due diligence requirements requiring tax return preparers to complete a checklist that walks the preparer through the necessary elements to correctly determine eligibility for the earned income credit. This checklist is found in Form 8867. This method of implementing the due diligence requirements created minimal burden for tax return preparers because it merely ensures tax return preparers obtain the information necessary to determine eligibility under statute that authorizes the credit. The only additional burden created by the regulation was the requirement to check the boxes on the form and maintain the checklist, which could be requested if the tax return preparer was audited. |
| At the end of 2015, Congress added three addition tax credits to section 6695(g), the child tax credit (CTC) under section 24, the additional child tax credit (ACTC) under section 24, and the American opportunity tax credit (AOTC) under section 25A(i). In response to these statutory changes, the Treasury Department and the IRS issued proposed and temporary regulations under section 6695(g) that incorporated the CTC, ACTC, and the AOTC in the due diligence requirements already established for the EIC. The Form 8867 was also updated to incorporate the additional credits. |
| Agency Contact: Marshall French at 202-317-XXXX. |

**Exhibit 32.1.2-4**

### Sample 7-Point Memo for TD

|     |
| --- |
| **Notice of Planned Regulatory Action** |
| Pursuant to Executive Order 12866 |
|  |
| DEPARTMENT OF THE TREASURY |
|  |
| Agency: Internal Revenue Service (IRS) |
| Title: Modification of Discounting Rules for Property and Casualty Insurance Companies REG-103163-18 |
| Significance: Not Significant |
| Upcoming Action: Final Regulations |
| Planned Publication Date: June 22, 2019 |
| RIN: 1545-BO50 |
| Statutory/Judicial Deadline: Not Applicable |
| Description: These final regulations adopt, with one change described at the end of the next page, proposed regulations under section 846 of the Internal Revenue Code (Code) set forth in a notice of proposed rulemaking (NPRM) published in the Federal Register (83 FR 55646) on November 7, 2018. OIRA determined that the proposed regulations were not significant and waived review of the NPRM. |
| In general, to compute a non-life insurance company’s taxable income for Federal income tax purposes, the insurance company’s income is reduced by the amount of its unpaid losses and the amount of its estimated salvage recoverable for the taxable year. These amounts are required to be discounted for this purpose. |
| Section 846 provides rules to determine these discounted amounts based on discount factors associated with a line of insurance business, accident year, and taxable year. Section 846 requires the Secretary to annually determine the discount factors that insurance companies use to discount their unpaid losses on non-life insurance policies and estimated salvage recoverable, and the discount factors are listed in a revenue procedure published by the Internal Revenue Service (IRS) each year. The discount factors are derived using the applicable loss payment pattern for each line of insurance business based on aggregate industry loss payment data (as detailed in section 846(d)) and the annual interest rate determined by the Secretary under section 846(c). |
| Prior to its amendment by section 13523 of the Tax Cuts and Jobs Act, P.L. 115-97 (TCJA), section 846(c) provided that the annual interest rate had to be based on a 60-month average of the "applicable Federal mid-term rates" set forth in section 1274(d) of the Code, which are based on an average of market yields of Treasury debt securities with a term of more than three years but less than nine years. Section 13523 of the TCJA amended section 846(c) to define the annual interest rate for discounting as "a rate determined on the basis of the corporate bond yield curve (as defined in section 430(h)(2)(D)(i), determined by substituting ‘60-month period’ for ‘24-month period’ therein)." However, as amended, section 846(c) does not specify how to use the corporate bond yield curve to determine the annual interest rate. Section 13523 of the TCJA also amended the computational rules for determining the loss payment patterns used for discounting under section 846(d). In addition, section 13523 of the TCJA repealed the section 846(e) election to use the taxpayer’s own historical loss payment pattern instead of the pattern published by the Secretary. |
| The NPRM proposed rules to implement the changes made to section 846 by section 13523 of the TCJA and proposed a technical improvement to the derivation of loss payment patterns. As the proposed rules were not expected to have any material effect on the economy and did not present any novel policy issues, OIRA waived their review. Additionally, Rev. Proc. 2019-06, 2019-02 I.R.B. 284, released on December 19, 2018, prescribes discount factors determined under the proposed regulations for computing discounted unpaid losses and discounted salvage recoverable for the 2018 accident year and earlier accident years. The Department of the Treasury (Treasury Department) and the IRS requested and received public comments on both the proposed regulations and Rev. Proc. 2019-06, and held a public hearing on the proposed regulations on December 20, 2018. Only eight comment letters were received on the NPRM and the revenue procedure, all of which were considered in drafting the final regulations. |
| With respect to section 846(c), the proposed regulations proposed the use of a single annual rate for discounting based on maturities of corporate bonds from the prescribed corporate bond yield curve ranging from 0.5 to 17.5 years. Commenters agreed with the use of a single annual rate for all lines of insurance business, but expressed concern regarding the maturity range selected in the NPRM to determine that single rate. Commenters requested the adoption of a narrower maturity range with an average maturity closer to the 7-year average maturity of the industry’s bond investments over the past decade. In response to these comments, the final regulations adopt a maturity range of 4.5 to 10 years (average of 7.25 years) to better align with the average maturity of the industry’s bond investments. |
| This change to the maturity range is the only difference between the proposed regulations and the final regulations. |
| Agency Contact: Kathryn M. Sneade (202) 317-XXXX. |

**Exhibit 32.1.2-5**

### Form 14029, Paperwork Reduction Act Submission

![This is an Image: 38994005.gif](https://www.irs.gov/pub/xml_bc/38994005.gif)

> This is a first page of the Form 14029.

[Please click here for the text description of the image.](https://www.irs.gov/media/38994005.gif "")

![This is an Image: 38994006.gif](https://www.irs.gov/pub/xml_bc/38994006.gif)

> This is the second page of the Form 14029.

[Please click here for the text description of the image.](https://www.irs.gov/media/38994006.gif "")

**Exhibit 32.1.2-6**

### Instructions for Completing Form 14029

![This is an Image: 38994007.gif](https://www.irs.gov/pub/xml_bc/38994007.gif)

> This is the first page of instructions for completing Form 14029.

[Please click here for the text description of the image.](https://www.irs.gov/media/38994007.gif "")

![This is an Image: 38994008.gif](https://www.irs.gov/pub/xml_bc/38994008.gif)

> This is the second page of instructions for completing Form 14029.

[Please click here for the text description of the image.](https://www.irs.gov/media/38994008.gif "")

![This is an Image: 38994009.gif](https://www.irs.gov/pub/xml_bc/38994009.gif)

> This is the third page of instructions for completing Form 14029.

[Please click here for the text description of the image.](https://www.irs.gov/media/38994009.gif "")

**Exhibit 32.1.2-7**

### Supporting Statement for Paperwork Reduction Act Submissions

| SUPPORTING STATEMENT |
| :-: |
| 1. | CIRCUMSTANCES NECESSITATING COLLECTION OF INFORMATION |
|  | Explain the circumstances that make the collection of information necessary. Include any legal or administrative requirements that necessitate the collection. |
|  | A copy of the appropriate section of each statute and of each regulation mandating or authorizing the collection of information should be attached to the supporting statement. |
| 2. | USE OF DATA |
|  | Indicate how, by whom, and for what purpose the information is to be used. |
| 3. | USE OF IMPROVED INFORMATION TECHNOLOGY TO REDUCE BURDEN |
|  | There are no plans to provide electronic filing because electronic filing is not appropriate for the collection of information in this submission. |
|  | **_or_** |
|  | We have no plans to offer electronic filing. IRS publication, regulations, notices and letters are to be electronically enabled on an as practicable basis in accordance with the IRS Reform and Restructuring Act of 1998. |
| 4. | EFFORTS TO IDENTIFY DUPLICATION |
|  | We have attempted to eliminate duplication within the agency wherever possible. |
| 5. | METHODS TO MINIMIZE BURDEN ON SMALL BUSINESSES OR OTHER SMALL ENTITIES |
|  | If the collection of information has a significant impact on substantial number of small businesses or other small entities (Item 5 of OMB Form 83-I), describe any methods used to minimize burden. Otherwise: Not applicable. |
| 6 | CONSEQUENCES OF LESS FREQUENT COLLECTION ON FEDERAL PROGRAMS OR POLICY ACTIVITIES |
|  | Not applicable. |
| 7. | SPECIAL CIRCUMSTANCES REQUIRING DATA COLLECTION TO BE INCONSISTENT WITH GUIDELINES IN 5 CFR 1320.5(d)(2) |
|  | Not applicable. |
| 8. | CONSULTATION WITH INDIVIDUALS OUTSIDE OF THE AGENCY ON AVAILABILITY OF DATA, FREQUENCY OF COLLECTION, CLARITY OF INSTRUCTIONS AND FORMS, AND DATA ELEMENTS |
|  | NPRM and temporary regulations: |
|  |  | A notice of proposed rulemaking is being published simultaneously with temporary regulations which will afford the public a 60-day period in which to review and provide public comments relating to any aspect of the regulations. A public hearing will be held with respect to the notice of proposed rulemaking if any person who has submitted written comments requests one. |
|  | NPRM: |
|  |  | This notice of proposed rulemaking will be published in the Federal Register to provide the public a 60-day period in which to review and provide public comments relating to any aspect of the proposed regulation. A public hearing will be held with respect to this NPRM if any person who has submitted written comments requests one. |
|  | Notices, Revenue Procedures, and Announcements: |
|  |  | We will publish a notice in the Federal Register in the near future to solicit public comments on this (notice, revenue procedure, or announcement). |
|  | ### Note:<br>For regulations whose OMB approval is being renewed, summarize the comments received in response to the Federal Register notice published prior to submission to OMB and indicate actions taken in response to these comments. If no comments add the following: We received no comments during the comment period in response to the Federal Register notice dated March XX, 2001. |
| 9. | EXPLANATION OF DECISION TO PROVIDE ANY PAYMENT OR GIFT TO RESPONDENTS |
|  | Not applicable. |
| 10. | ASSURANCE OF CONFIDENTIALITY OF RESPONSES |
|  | Generally, tax returns and tax return information are confidential as required by 26 USC 6103. |
| 11. | JUSTIFICATION OF SENSITIVE QUESTIONS |
|  | Not applicable. |
| 12. | ESTIMATED BURDEN OF INFORMATION COLLECTION |
|  | Citation followed by discussion of the reporting or recordkeeping requirement and the burden estimate. |
|  | **Please add the following:** Estimates of the annualized cost to respondents for the hour burdens shown are not available at this time. |
| 13. | ESTIMATED TOTAL ANNUAL COST BURDEN TO RESPONDENTS |
|  | For new NPRM, temporary, final regulations, other published guidance only: |
|  |  | Estimates of capital or start-up costs and costs of operation, maintenance, and purchase of services to provide information are not available at this time. |
|  | For renewals: |
|  |  | As suggested by OMB, our Federal Register notice dated March xx, 2001, requested public comments on estimates of cost burden that are not captured in the estimates of burden hours, i.e., estimates of capital or start-up costs and costs of operation, maintenance, and purchase of services to provide information. However, we did not receive any response from taxpayers on this subject. As a result, estimates of the cost burdens are not available at this time. |
| 14. | ESTIMATED ANNUALIZED COST TO THE FEDERAL GOVERNMENT |
|  | Not applicable. |
| 15. | REASONS FOR CHANGE IN BURDEN |
|  | For existing regulations whose OMB approval is being renewed, explain the reasons for any burden change. If there is no change in burden: There is no change in the paperwork burden previously approved by OMB. We are making this submission to renew the OMB approval. |
|  | For new regulations: Not applicable. |
| 16. | PLANS FOR TABULATION, STATISTICAL ANALYSIS AND PUBLICATION |
|  | Not applicable. |
| 17. | REASONS WHY DISPLAYING THE OMB EXPIRATION DATE IS INAPPROPRIATE |
|  | We believe that displaying the OMB expiration date is inappropriate because it could cause confusion by leading taxpayers to believe that the regulations sunset as of the expiration date. Taxpayers are not likely to be aware that the Service intends to request renewal of the OMB approval and obtain a new expiration date before the old one expires. |
| 18. | EXCEPTIONS TO THE CERTIFICATION STATEMENT ON 0MB FORM 83-I |
|  | Not applicable. |
| ### Note:<br>The following paragraph applies to all of the collections of information in this submission: |
|  | An agency may not conduct or sponsor, and a person is not required to respond to, a collection of information unless the collection of information displays a valid OMB control number. Books or records relating to a collection of information must be retained as long as their contents may become material in the administration of any internal revenue law. Generally, tax returns and tax return information are confidential, as required by 26 U.S.C. 6103. |
| ### Note:<br>\*If this is an emergency submission, please give a reason for the emergency at the end of the supporting statement. |

**Exhibit 32.1.2-8**

### Model Language for NPRM with a Collection of Information

\[4830-01-p\]

**DEPARTMENT OF THE TREASURY**

**Internal Revenue Service**

**26 CFR Parts 1, 20, 25, 26, 31, and 301**

**\[REG-148998-13\]**

**RIN 1545-BM10**

**Definition of Terms Relating to Marital Status**

**AGENCY:** Internal Revenue Service (IRS), Treasury.

**SUMMARY:**This document contains proposed regulations that reflect the holdings of _Obergefell v. Hodges_, 576 U.S. \_\_\_, 135 S. Ct. 2584 (2015), _Windsor v. United States_, 570 U.S. \_\_\_, 133 S. Ct. 2675 (2013), and Revenue Ruling 2013-17 (2013-38 IRB 201), and that define terms in the Internal Revenue Code (Code) describing the marital status of taxpayers. The proposed regulations primarily affect married couples, employers, sponsors and administrators of employee benefit plans, and executors. This document invites comments from the public regarding these proposed regulations.

**DATES:**Written or electronic comments and requests for a public hearing must be received by December 7, 2015.

**ADDRESSES:**Send submissions to: CC:PA:LPD:PR (REG-148998-13), room 5205, Internal Revenue Service, P.O. Box 7604, Ben Franklin Station, Washington, DC 20044. Submissions may be hand-delivered Monday through Friday between the hours of 8 a.m. and 4 p.m. to CC:PA:LPD:PR (REG-148998-13), Courier’s Desk, Internal Revenue Service, 1111 Constitution Avenue, N.W., Washington, DC; or sent electronically via the Federal eRulemaking Portal at www.regulations.gov (IRS REG 148998 13).

**FOR FURTHER INFORMATION CONTACT:**Concerning the proposed amendments to the regulations, Mark Shurtliff at (202) 317-XXXX; concerning submissions of comments and requests for a hearing, Regina Johnson at (202) 317-XXXX (not toll-free numbers).

**SUPPLEMENTARY INFORMATION:**

**Background and Explanation of Provisions**

This document contains proposed amendments to the Income Tax Regulations (26 CFR part 1), the Estate Tax Regulations (26 CFR part 20), the Gift Tax Regulations (26 CFR part 25), the Generation-Skipping Transfer Tax Regulations (26 CFR part 26), the Employment Tax and Collection of Income Tax at Source Regulations (26 CFR part 31), and the Regulations on Procedure and Administration (26 CFR part 301).

Amendments to Regulations Incorporating Holdings of Windsor, Obergefell, and Revenue Ruling 2013-17

On June 26, 2013, the Supreme Court in **United States v. Windsor**, 570 U.S. \_\_\_, 133 S. Ct. 2675 (2013), held that Section 3 of the Defense of Marriage Act, which generally prohibited the federal government from recognizing the marriages of same-sex couples, is unconstitutional because it violates the principles of equal protection and due process. Revenue Ruling 2013-17 provides guidance on the **Windsor** decision’s effect on the IRS's interpretation of Code sections that refer to taxpayers’ marital status. **Cf**. Notice 2014-19 (2014-47 IRB 979), amplified by Notice 2014-37 (2014-24 IRB 1100) (regarding the application of the **Windsor** decision to qualified retirement plans); Notice 2014-1 (2014-02 IRB 270) (regarding elections and reimbursements for same-sex spouses under cafeteria plans, flexible spending arrangements, and health savings accounts following the **Windsor** decision); Notice 2013-61 (2013-44 IRB 432) (regarding the application of the **Windsor** decision and Rev. Rul. 2013-17 to employment taxes and special administrative procedures for employers to make adjustments or claims for refund or credit); and Revenue Procedure 2014-18 (2014-7 IRB 513) (regarding extensions of time for estates to make a portability election). On June 26, 2015, the Supreme Court in **Obergefell v. Hodges**, 576 U.S. \_\_\_ (2015), held that state laws are **invalid to the extent they exclude same-sex couples from civil marriage on the same terms and conditions as opposite-sex couples** and **that there is no lawful basis for a State to refuse to recognize a lawful same-sex marriage performed in another State on the ground of its same-sex character.****Obergefell**, 576 U.S. at 23, 28.

In light of the holdings of **Windsor and Obergefell**, the Treasury Department and the IRS have determined that, for federal tax purposes, marriages of couples of the same-sex should be treated the same as marriages of couples of the opposite-sex and that, for reasons set forth in Revenue Ruling 2013-17, terms indicating sex, such as **husband,****wife,** and **husband and wife,** should be interpreted in a neutral way to include same-sex spouses as well as opposite-sex spouses. Accordingly, these proposed regulations amend the current regulations under section 7701 of the Internal Revenue Code (Code) to provide that, for federal tax purposes, the terms **spouse,****husband,** and **wife** mean an individual lawfully married to another individual, and the term **husband and wife** means two individuals lawfully married to each other. These definitions apply regardless of sex.

In addition, these proposed regulations provide that a marriage of two individuals will be recognized for federal tax purposes if that marriage would be recognized by any state, possession, or territory of the United States. Under this rule, whether a marriage conducted in a foreign jurisdiction will be recognized for federal tax purposes depends on whether that marriage would be recognized in at least one state, possession, or territory of the United States. This comports with the general principles of comity where countries recognize actions taken in foreign jurisdictions, but only to the extent those actions do not violate their own laws. See **Hilton v. Guyot**, 159 U.S. 113, 167 (1895) (**A judgment affecting the status of persons, such as a decree confirming or dissolving a marriage, is recognized as valid in every country, unless contrary to the policy of its own law.**).

Although these proposed regulations define terms relating to marital status for federal tax purposes, the IRS may provide additional guidance as needed. For example, the IRS has already issued more particular guidance for employers regarding the application of Revenue Ruling 2013-17 to qualified retirement plans, and that guidance remains in effect. See Notice 2014-19 (2014-47 IRB 979).

Registered Domestic Partnerships, Civil Unions, or Other Similar Relationships Not Denominated as Marriage

For federal tax purposes, the term **marriage** does not include registered domestic partnerships, civil unions, or other similar relationships recognized under state law that are not denominated as a marriage under that state’s law, and the terms **spouse,****husband and wife,****husband,** and **wife** do not include individuals who have entered into such a relationship.

Except when prohibited by statute, the IRS has traditionally looked to the states to define marital status. See **Loughran v. Loughran**, 292 U.S. 216, 223 (1934) (**Marriages not polygamous or incestuous, or otherwise declared void by statute, will, if valid by the law of the state where entered into, be recognized as valid in every other jurisdiction.**); see also Revenue Ruling 58-66 (1958-1 CB 60) (if a state recognizes a common-law marriage as a valid marriage, the IRS will also recognize the couple as married for purposes of federal income tax filing status and personal exemptions). States have carefully considered the types of relationships that they choose to recognize as a marriage and the types that they choose to recognize as something other than a marriage. Although some states extend all of the rights and responsibilities of marriage under state law to couples in registered domestic partnerships, civil unions, or other similar relationships, those states have intentionally chosen not to denominate those relationships as marriages. Similar rules exist in some foreign jurisdictions.

Some couples have chosen to enter into a civil union or registered domestic partnership even when they could have married, and some couples who are in a civil union or registered domestic partnership have chosen not to convert those relationships into a marriage even when they have had the opportunity to do so. In many cases, this choice was deliberate, and couples who enter into civil unions or registered domestic partnerships may have done so with the expectation that their relationship will not be treated as a marriage for purposes of federal law. For some of these couples, there are benefits to being in a relationship that provides some, but not all, of the protections and responsibilities of marriage. For example, some individuals who were previously married and receive Social Security benefits as a result of their previous marriage may choose to enter into a civil union or registered domestic partnership (instead of a marriage) so that they do not lose their Social Security benefits. More generally, the rates at which some couples’ income is taxed may increase if they are considered married and thus required to file a married-filing-separately or married-filing-jointly federal income tax return. Treating couples in civil unions and registered domestic partnerships the same as married couples who are in a relationship denominated as marriage under state law could undermine the expectations certain couples have regarding the scope of their relationship. Further, no provision of the Code indicates that Congress intended to recognize as marriages civil unions, registered domestic partnerships, or similar relationships. Accordingly, the IRS will not treat civil unions, registered domestic partnerships, or other similar relationships as marriages for federal tax purposes.

**Effect on Other Documents**

These **_proposed regulations would, as of the date they are published as final regulations in the Federal Register_**, obsolete Revenue Ruling 2013-17. Taxpayers may continue to rely on guidance related to the application of Revenue Ruling 2013-17 to employee benefit plans and the benefits provided under such plans, including Notice 2013-61, Notice 2014-37, Notice 2014-19, and Notice 2014-1.

**Proposed Effective Date**.

The regulations, as proposed, would be effective as of the date of publication of a Treasury decision adopting these rules as final regulations in the Federal Register. See §301.7701-18(d) for applicability date.

**Statement of Availability for IRS Documents**

For copies of recently issued Revenue Procedures, Revenue Rulings, Notices, and other guidance published in the Internal Revenue Bulletin, please visit the IRS website at [http://www.irs.gov](http://www.irs.gov/).

**Special Analyses**

This regulation is not subject to review under section 6(b) of Executive Order 12866 pursuant to the Memorandum of Agreement (April 11, 2018) between the Department of the Treasury and the office of Management and Budget regarding review of tax regulations. Because the regulations do not impose a collection of information on small entities a Regulatory Flexibility Act (5 U.S.C. chapter 6) analysis is not required. Pursuant to section 7805(f) of the Code, this notice of proposed rulemaking will be submitted to the Chief Counsel for Advocacy of the Small Business Administration for comment on its impact on small businesses.

**Comments and Requests for Public Hearing**

Before these proposed regulations are adopted as final regulations, consideration will be given to any comments that are submitted timely to the IRS as prescribed in this preamble under the "Addresses" heading. Treasury and the IRS request comments on all aspects of the proposed rules. All comments will be available at [www.regulations.gov](https://www.regulations.gov/) or upon request. A public hearing will be scheduled if requested in writing by any person who timely submits written comments. If a public hearing is scheduled, notice of the date, time, and place for the public hearing will be published in the _Federal Register_.

**Drafting Information**

The principal author of these proposed regulations is Mark Shurtliff of the Office of the Associate Chief Counsel, Procedure and Administration.

**List of Subjects**

**26 CFR Part 1**

Income Taxes, Reporting and recordkeeping requirements.

**26 CFR Part 20**

Estate taxes, Reporting and recordkeeping requirements.

**26 CRF Part 25**

Gift taxes, Reporting and recordkeeping requirements.

**26 CFR Part 26**

Estate, Reporting and recordkeeping requirements.

**26 CFR Part 31**

Employment taxes, Income taxes, Penalties, Pensions, Reporting and recordkeeping requirements, Social Security, Unemployment compensation.

**26 CFR Part 301**

Employment taxes, Estate taxes, Gift taxes, Income taxes, Penalties, Reporting and recordkeeping requirements.

**Proposed Amendments to the Regulations**

Accordingly, 26 CFR parts 1, 20, 25, 26, 31, and 301 are proposed to be amended as follows:

**PART 1--INCOME TAXES**

Paragraph 1. The authority citation for part 1 continues to read in part as follows:

Authority: 26 U.S.C. 7805 \*\*\*

Par. 2. Section 1.7701-1 is added to read as follows:

**§1.7701-1 Definitions; spouse, husband and wife, husband, wife, marriage.**

(a) _In general._ For the definition of the terms spouse, husband and wife, husband, wife, and marriage, see §301.7701-18 of this chapter.

(b) _Applicability date._ The rules of this section are proposed to apply to taxable years ending on or after the date of publication of the Treasury decision adopting these rules as final regulation in the _Federal Register._

**PART 20--ESTATE TAX; ESTATES OF DECEDENTS DYING AFTER AUGUST 16, 1954**

Par. 3. The authority citation for part 20 continues to read in part as follows:

Authority: 26 U.S.C. 7805 \*\*\*

Par. 4. Section 20.7701-2 is added to read as follows:

**§20.7701-2 Definitions; spouse, husband and wife, husband, wife, marriage.**

(a) _In general._ For the definition of the terms spouse, husband and wife, husband, wife, and marriage, see §301.7701-18 of this chapter.

(b) _Applicability date._ The rules of this section are proposed to apply to taxable years ending on or after the date of publication of the Treasury decision adopting these rules as final regulation in the _Federal Register._

**PART 25--GIFT TAX; GIFTS MADE AFTER DECEMBER 31, 1954**

Par. 5. The authority citation for part 25 continues to read in part as follows:

Authority: 26 U.S.C. 7805 \*\*\*

Par. 6. Section 25.7701-2 is added to read as follows:

**§25.7701-2 Definitions; spouse, husband and wife, husband, wife, marriage.**

(a) _In general._ For the definition of the terms spouse, husband and wife, husband, wife, and marriage, see §301.7701-18 of this chapter.

(b) _Applicability date._ The rules of this section are proposed to apply to taxable years ending on or after the date of publication of the Treasury decision adopting these rules as final regulation in the _Federal Register._

**PART 26--GENERATION-SKIPPING TRANSFER TAX REGULATIONS UNDER THE TAX REFORM ACT OF 1986**

Par. 7. The authority citation for part 26 continues to read in part as follows:

Authority: 26 U.S.C. 7805 \*\*\*

Par. 8. Section 26.7701-2 is added to read as follows:

**§26.7701-2 Definitions; spouse, husband and wife, husband, wife, marriage.**

(a) _In general._ For the definition of the terms spouse, husband and wife, husband, wife, and marriage, see §301.7701-18 of this chapter.

(b) _Applicability date._ The rules of this section are proposed to apply to taxable years ending on or after the date of publication of the Treasury decision adopting these rules as final regulation in the _Federal Register._

**PART 31--EMPLOYEMENT TAXES AND COLLECTION OF INCOME TAX AT THE SOURCE**

Par. 9. The authority citation for part 31 continues to read in part as follows:

Authority: 26 U.S.C. 7805 \*\*\*

Par. 10. Section 31.7701-2 is added to read as follows:

**§31.7701-2 Definitions; spouse, husband and wife, husband, wife, marriage.**

(a) _In general._ For the definition of the terms spouse, husband and wife, husband, wife, and marriage, see §301.7701-18 of this chapter.

(b) _Applicability date._ The rules of this section are proposed to apply to taxable years ending on or after the date of publication of the Treasury decision adopting these rules as final regulation in the _Federal Register._

**PART 301--PROCEDURE AND ADMINISTRATION**

Par. 11. The authority citation for part 301 continues to read in part as follows:

Authority: 26 U.S.C. 7805 \*\*\*

Par. 12. Section 301.7701-18 is added to read as follows:

**§301.7701-18 Definitions; spouse, husband and wife, husband, wife, marriage.**

(a) _In general._ For federal tax purposes, the terms _spouse_, _husband_, and _wife_ mean an individual lawfully married to another individual. The term _husband and wife_ means two individuals lawfully married to each other.

(b) _Persons who are married for federal tax purposes._ A marriage of two individuals is recognized for federal tax purposes if the marriage would be recognized by any state, possession, or territory of the United States.

(c) _Persons who are not married for federal tax purposes._ The terms _spouse_, _husband_, and _wife_ do not include individuals who have entered into a registered domestic partnership, civil union, or other similar relationship not denominated as a marriage under the law of a state, possession, or territory of the United States. The term _husband and wife_ does not include couples who have entered into such a relationship, and the term marriage does not include such relationships.

(d) _Applicability date._ The rules of this section are proposed to apply to taxable years ending on or after the date of publication of the Treasury decision adopting these rules as final regulation in the _Federal Register_.

|     |
| --- |
|  |
| John M. Dalrymple, |
| Deputy Commissioner for Services and Enforcement. |

**Exhibit 32.1.2-9**

### Model Language for Temp With a Collection of Information

SUPPLEMENTARY INFORMATION:

**Paperwork Reduction Act**

These temporary regulations are being issued without prior notice and public procedure pursuant to the Administrative Procedure Act (5 U.S.C. 553). For this reason, the collection of information contained in these regulations has been reviewed and pending receipt and evaluation of public comments, approved by the office of Management and Budget under control number 1545-1570. Responses to this collection of information are mandatory.

An agency may not conduct or sponsor, and a person is not required to respond to, a collection of information unless the collection of information displays a valid control number.

For further information concerning this collection of information, and where to submit comments on the collection of information and the accuracy of the estimated burden, and suggestions for reducing this burden, please refer to the preamble to the cross-referencing notice of proposed rulemaking published in the proposed Rules section of this issue of the **Federal Register.**

Books and records relating to a collection of information must be retained as long as their contents may become material in the administration of any internal revenue law. Generally, tax returns and tax return information are confidential, as required by 26 U.S.C. 6103.

**Exhibit 32.1.2-10**

### Model Language for Final with a Collection of Information

SUPPLEMENTARY INFORMATION:

**Paperwork Reduction Act**

The collection of information contained in these final regulations has been reviewed and approved by the Office of Management and Budget in accordance with the Paperwork Reduction Act of 1995 (44 U.S.C. 3507(d)) under control number 1545-XXXX. The collection of information in these final regulations is in § 1.XXXX-X. This information is required to enable the IRS to verify that a taxpayer is reporting the correct amount of income or gain or claiming the correct amount of losses, deductions, or credits from that taxpayer's interest in the partnership.

An agency may not conduct or sponsor, and a person is not required to respond to, a collection of information unless it displays a valid control number.

Books and records relating to a collection of information must be retained as long as their contents might become material in the administration of any internal revenue law. Generally, tax returns and tax return information are confidential, as required by 26 U.S.C. 6103.

**Exhibit 32.1.2-11**

### Model Language for "No-Change" Memo

| **Internal Revenue Service** |
| --- |
| **m e m o r a n d u m** |
| **date:** |  |
| **to:** | IRS Reports Clearance Officer |
| **from:** | Drafting Attorney CC:PSI:8 |
| **subject:** | Final Regulations Relating to the Tax Imposed on Ozone-Depleting Chemicals and on Products Containing those Chemicals |
|  |  |
|  | The collection of information contained in these final regulations were submitted to the Office of Management and Budget in a notice of proposed rulemaking (REG-123456-XX) and approved on April 25, YYYY, under control number 1545–1153. Written comments responding to the notice were received, but no public hearing was requested or held. These final regulations adopt the proposed regulations with minor revisions based on the comments received. There is no change in the paperwork burden. |
|  |  |
|  | Attachment (1) |
|  | \[Draft of final regulation\] |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part32/irm_32-001-002#addtoany "Show all")

A2A