---
url: "https://www.irs.gov/irm/part34/irm_34-004-001"
title: "34.4.1 Insolvencies | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part34/irm_34-004-001#main-content)

- 34.4.1 [Insolvencies](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487827106528)
  - 34.4.1.1 [General Procedures](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487827097504)

    - 34.4.1.1.1 [Coordination with Compliance Technical Support](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487827094576)
    - 34.4.1.1.2 [Handling Legal Files](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487827092960)
    - 34.4.1.1.3 [Advisory Function](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487827023008)
    - 34.4.1.1.4 [Affirmative Action in Proceedings](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487827017248)
    - 34.4.1.1.5 [Adverse Decisions](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487827007776)
    - 34.4.1.1.6 [Significant Insolvency Cases](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487827005248)

  - 34.4.1.2 [Coordination of Tax Court Cases With Non-Bankruptcy Insolvencies](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487827003200)
  - 34.4.1.3 [Coordination with United States Attorney and Tax Division in Non-Bankruptcy Insolvency Cases](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487827001440)
  - 34.4.1.4 [Contesting the Merits of Federal Taxes in State Court](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487826986144)
  - 34.4.1.5 [Proofs of Claim](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487826978544)
  - 34.4.1.6 [Proposed Overassessment, Settlement, Adjustments, and Compromises](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487826972048)
  - 34.4.1.7 [The Insolvency Statute, 31 U.S.C. 3713(a)](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487826964608)
  - 34.4.1.8 [Receiverships](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487826953104)

    - 34.4.1.8.1 [Opening a Legal File in Receivership Cases](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487826948752)
    - 34.4.1.8.2 [Jurisdiction in Receivership Cases](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487826944656)
    - 34.4.1.8.3 [Collection Remedies in Receivership Cases](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487826940560)
    - 34.4.1.8.4 [Receivership Cases Initiated by the United States](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487826932048)
    - 34.4.1.8.5 [Immediate Assessments and Form 1005(DO) Letters](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487826927904)

      - 34.4.1.8.5.1 [Field Counsel Procedures](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487826922720)

  - 34.4.1.9 [Assignments for the Benefit of Creditors](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487826918016)

    - 34.4.1.9.1 [Nature of the Assignment for the Benefit of Creditors Proceeding](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487826912736)
    - 34.4.1.9.2 [Collection Remedies Against Assignees](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487826909712)

  - 34.4.1.10 [Estates of Decedents or Incompetents](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487812218928)

    - 34.4.1.10.1 [Opening a Legal File](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487812215328)
    - 34.4.1.10.2 [Collection Rights Against Estates of Decedents](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487812212608)

  - 34.4.1.11 [Corporate Dissolutions](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487812205312)

    - 34.4.1.11.1 [Nature of Corporate Dissolution Proceedings](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487812203088)
    - 34.4.1.11.2 [Converting Nonjudicial Dissolution into a Receivership](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487812197872)
    - 34.4.1.11.3 [Collection Remedies in Corporate Dissolutions](https://www.irs.gov/irm/part34/irm_34-004-001#idm140487812194576)

# Part 34. Litigation in District Court, Bankruptcy Court, Court of Federal Claims, and State Court

# Chapter 4. Insolvencies

# Section 1. Insolvencies

* * *

## 34.4.1 Insolvencies

#### Manual Transmittal

March 24, 2016

#### Purpose

(1) This transmits new CCDM 34.4.1, Litigation in District Court, Bankruptcy Court, Court of Federal Claims, and State Court; Insolvencies.

#### Background

CCDM 34.4.1.8.4, Receivership Cases Initiated by the United States, is being revised to reflect a change in the delegation of authority for appointment of a receiver.

#### Material Changes

(1) CCDM 34.4.1.8.4(3) was revised to provide that a request to appoint a receiver must now be approved by the Division Counsel (Small Business/Self-Employed).

#### Effect on Other Documents

This section supersedes CCDM 34.4.1, dated August 11, 2004. This section also incorporates procedures contained in Chief Counsel Notice CC-2014-010.

#### Audience

Chief Counsel

#### Effective Date

(03-24-2016)

Frederick W. Schindler

Deputy Associate Chief Counsel

(Procedure & Administration)

**34.4.1.1** **(08-11-2004)**

### General Procedures

1. SB/SE attorneys in the field are responsible for handling cases involving the collection of federal taxes in non-bankruptcy insolvency proceedings. These proceedings include receiverships, assignments for the benefit of creditors, corporate dissolutions, decedents’ estates, and estates of incompetents.

2. For additional reference material see IRM 5.5, Insolvencies, Decedent Estates and Estate Taxes and IRM 5.17.13, Legal Reference Guide for Revenue Officers, Insolvencies and Decedents’ Estates.


**34.4.1.1.1** **(08-11-2004)**

#### Coordination with Compliance Technical Support

1. The local Insolvency Unit is the point of contact for Field Counsel. That Unit in each territory protects the Government’s interests with respect to the collection of any federal taxes that the Government may claim in non-bankruptcy insolvencies. The Unit may request assistance from or refer a case to Field Counsel.


**34.4.1.1.2** **(08-11-2004)**

#### Handling Legal Files

1. SB/SE should open a legal file in connection with non-bankruptcy insolvency proceedings when the Insolvency Unit requests legal assistance or refers the case for action of a legal nature. For specific rules regarding the opening of receivership cases (for example, reviewing a Form 1005(DO) letter) or cases involving decedents’ or incompetents’ estates, see CCDM 34.4.1.10.

2. Advisory assistance in a case ordinarily will be jacketed as to the type of insolvency involved. If the case involves a general referral, such as where the Unit refers all receiverships to Field Counsel, it should be counted as post-filing legal advice, not as a Non-Bankruptcy Insolvency.

3. Field Counsel ordinarily should close a file when the issues for which the Unit referred the case to SB/SE have been disposed of. Field Counsel does not need to wait until the proceeding is closed.


**34.4.1.1.3** **(08-11-2004)**

#### Advisory Function

1. The Unit may ask Field Counsel for advice concerning a number of insolvency issues. Some of these issues may arise concerning matters currently independent of a pending adversary action in court. For example, during a proof of claim review Field Counsel might be asked whether:



   - A proof of claim should be filed in the proceeding

   - Certain items should be included therein

   - A proposed overassessment should be scheduled

   - A proof of claim constitutes an amendment of a proof of claim filed at an earlier time

   - To file a notice of lien during the pendency of the proceeding

   - A set off can be effected where another department or agency of the government is indebted to the taxpayer

   - Seizure of property is permissible


2. Questions may arise concerning what action, if any, the Government should take to collect federal taxes due from third persons who are not parties to the insolvency proceedings. For example, issues may arise concerning transferee liability or liability for Trust Fund Recovery Penalties under section 6672.


**34.4.1.1.4** **(08-11-2004)**

#### Affirmative Action in Proceedings

1. Insolvency proceedings often involve federal tax controversies that require affirmative action. Some of these controversies relate to the merits of claimed federal taxes. Others relate to a multitude of additional questions involving creditors’ rights that may be tried in the proceeding. Some controversies may require the United States:



   - To reclaim trust fund taxes

   - To oppose claims of other creditors

   - To question a compromise sought by the fiduciary

   - To object to claimed fees

   - To require the filing of returns and payment of current taxes by the fiduciary

   - To oppose efforts by a fiduciary to require the Insolvency Unit to turn over assets seized before the proceeding began

   - To oppose attempts to subpoena Service records

   - To oppose efforts to have Service employees testify


2. When a party objects to the merits of claimed federal taxes before the court, or where some other controversy has arisen that affects the interests of the United States in the collection of federal taxes, Field Counsel should consider the questions at issue, examine the pertinent statutes and court decisions, and inform the Department of Justice of Field Counsel’s determinations.

3. If Field Counsel determines that the Government should take affirmative action in connection with the federal taxes or federal tax liens involved in a proceeding, and that the exercise of such affirmative action requires authorization under section 7401 or section 7403, Field Counsel should prepare and send a suit letter under normal case referral procedures to the Assistant Attorney General, Tax Division, Department of Justice. _See_ CCDM 34.6.


**34.4.1.1.5** **(08-11-2004)**

#### Adverse Decisions

1. Decisions adverse to the Government in whole or in part should be brought to the immediate attention of the Office of the Assistant Chief Counsel (Collection, Bankruptcy and Summonses). _See_ CCDM Part 36.


**34.4.1.1.6** **(08-11-2004)**

#### Significant Insolvency Cases

1. CCDM 34.3.1.3 contains special rules for handling significant bankruptcy cases. The procedural rules therein are the same as those to be used for significant insolvency cases, defined generally as insolvencies having significant tax liabilities, significant or sensitive issues, or significant audit impact. If one of these cases arises, Field Counsel should refer to the special rules.


**34.4.1.2** **(08-11-2004)**

### Coordination of Tax Court Cases With Non-Bankruptcy Insolvencies

1. When the Service attempts to collect a tax liability in a non-bankruptcy insolvency case, a related Tax Court case may require coordination. Procedures for coordination are outlined in CCDM Part 31.


**34.4.1.3** **(08-11-2004)**

### Coordination with United States Attorney and Tax Division in Non-Bankruptcy Insolvency Cases

1. Coordination in Insolvency Proceeding. When a controversy arises concerning the legal position or the claim of the United States for taxes in a non-bankruptcy insolvency proceeding, Field Counsel usually will work directly with the appropriate U.S. Attorney’s Office.

2. Not every claim of the United States or every action taken by Field Counsel in insolvency matters is within the province of the U.S. Attorney. In order to be within the U.S. Attorney’s province there should be an actual controversy in the case. This controversy might be a formal opposition to the claim of the United States on its merits, an opposition to its claimed priority, the award of improper priority to another claim, or opposition by the United States to action taken in the proceedings, such as the payment of fees, the allowance of other claims, inordinate delay, and so forth.

3. Generally, a matter will be referred to the Department of Justice:



1. As soon as an objection has been filed to a United States claim for taxes in a proceeding.

2. Whenever an issue requires a written or oral communication with the court on behalf of the United States (other than the filing of the proof of claim or the adjustment of a claim as described in CCDM 34.4.1.5 and CCDM 34.4.1.6).

3. Whenever an adversary proceeding or a contested matter arises in which the United States is or should be a party or any matter arises in which the interest of the United States should be represented in court by counsel.


4. If the Tax Division writes other than a status request letter to Field Counsel, Field Counsel should assume that the Tax Division has taken over responsibility for the case and all subsequent communications should go to the Tax Division unless the Tax Division directs otherwise.

5. Coordination in Probate Proceedings. In deciding whether to refer a probate matter to the Tax Division or the United States Attorney, counsel should consider the following:



1. The U.S. Attorney usually defends the merits of a claim priority in probate. The U.S. Attorney may in turn call on the Tax Division for help. If the claim is disallowed in whole or in part and further action to collect the tax is necessary, Field Counsel may need to write a suit authorization letter to the Tax Division, e.g., some states provide that if a claim is not allowed, suit must be brought on the claim within 90 days or the claim is forever barred.

2. If a contest develops or if it becomes necessary to compel the personal representative to act on a claim, Field Counsel generally may communicate directly with the U.S. Attorney and attempt to obtain compliance without the necessity of a formal petition.

3. Field Counsel does not need to write a formal letter to the Tax Division if the requested action is merely to obtain the removal of an administrator or an accounting. A letter to the United States Attorney is sufficient.

4. If a formal objection to the Service’s proof of claim is filed in probate proceedings, and the case or issue is of some importance, Field Counsel should notify the Office of the Assistant Chief Counsel (Collection, Bankruptcy & Summonses), Branch 2 by telephone before consulting with or writing the United States Attorney. CBS will coordinate the matter with the Tax Division if necessary.

5. An urgent matter may necessitate the referral of a case directly to the U.S. Attorney to avoid the expiration of the statute of limitations, the dissipation of assets, or other action that might prejudice the rights of the United States before the matter can be authorized through the Tax Division. When such a matter requires prereview, Field Counsel should immediately contact CBS, Branch 2 by phone. The matter will then be referred to the Tax Division as in the normal procedure with the suit letter sanctioning retroactive authorization to the Attorney General.


6. Notification of Tax Division, Department of Justice. Where notification of the Tax Division is required, Field Counsel should send notification promptly by letter, accompanied by a copy of the proof of claim, the objection thereto, and any pleading, offer, proposed plan, or other relevant documents. As soon as practicable thereafter or within any applicable time limits, a letter discussing the facts and legal principles involved should be forwarded to the Tax Division for any appropriate legal action.



1. If any objection to a proof of claim has been filed, or the merits are in controversy, the material forwarded to the Tax Division should include copies of the protests or claims filed by the taxpayer, returns, revenue agent’s reports and workpapers, and the Appeals Office report.

2. If collectibility is in issue, the material forwarded to the Tax Division should include copies of recent financial statements that the Service may have and tax returns for the period of administration.


7. Referrals of Settlement, Adjustment, or Compromise. To determine whether a settlement, adjustment of a tax claim, or a compromise in a non-bankruptcy insolvency proceeding must be referred to the Department of Justice, see CCDM 34.4.1.5.


**34.4.1.4** **(08-11-2004)**

### Contesting the Merits of Federal Taxes in State Court

1. State Court’s Jurisdiction Over the United States. When the Government files a proof of claim in state court it risks having submitted to the jurisdiction of the court for all purposes, though there may be some circumstances in which the Government has a viable argument against the jurisdiction of the state court. In any event, there are alternatives to filing a proof of claim, even though rarely used, which should be considered when warranted.

2. Alternatives to Filing Proof of Claim. Field Counsel should consider alternatives to filing a proof of claim to avoid the issue of whether a state court has the jurisdiction to consider the merits of the tax.



1. The Government should give notice in writing to the fiduciary of the federal tax debt owed and rely on 31 U.S.C. § 3713. A fiduciary is personally liable for a known tax claim to the extent the fiduciary pays, in whole or in part, any debt due by the person or estate without first paying the debts owed to the Government where the fiduciary has actual notice of the claim of the United States. _See_ CCDM 34.4.1.7.

2. The Government may file suit to reduce the assessments to judgment in federal district court to obtain a judgment on the merits of the tax claim or attempt to expedite the federal court’s consideration of a pending suit. To the extent that the federal court enters a final order prior to the entry of a final order on the merits of the tax liability in the insolvency proceeding, the state court is bound by the federal court’s order.

3. The Government may assert liability against a transferee or third party. A third party may be liable under a contract or under state laws governing transactions such as corporate dissolutions (and a bulk sale). The Government may assert liability against certain distributees of decedents’ estates and donees of gifts under sections 6324(a) and (b) for unpaid estate and gift taxes.


**34.4.1.5** **(08-11-2004)**

### Proofs of Claim

1. Generally. A proof of claim must be filed to collect any tax liability from the assets available for distribution in an insolvency proceeding.

2. Claiming Interest and Penalties. The rules for claiming interest and penalties on proofs of claim in insolvencies and decedents’ estates are contained in IRM 5.17.13.7(Filing the Proof of Claim). _See_ Rev. Rul. 87-99.

3. Bar Dates. State statutes of limitations for filing a claim, set by state law or by the fiduciary administering the proceeding, may not be applicable to the United States. _United States v. Summerlin_, 310 U.S. 414 (1940). To avoid the necessity of litigating the Government’s right to file its claim at a later time, however, the Government should attempt to meet bar dates.



1. Should the time for filing claims in a proceeding be likely to expire before the administrative processes can be completed and deficiencies or additional taxes contemplated, the Insolvency Unit will notify Field Counsel.

2. Field Counsel should seek an extension of time for filing the claim. If an extension cannot be obtained, a proof of claim in an estimated amount may be filed without waiting for assessment.


**34.4.1.6** **(08-11-2004)**

### Proposed Overassessment, Settlement, Adjustments, and Compromises

1. Proposed Overassessment. Before the Insolvency Unit schedules an overassessment in connection with a non-bankruptcy insolvency proceeding, the Unit may seek the advice of Field Counsel. Upon receipt of a request for advice, Field Counsel should open a legal file. The attorney should consider the administrative file and particularly the effect of the proceeding upon the proposed overassessment, the right of the Government to any particular setoffs, and other outstanding items of federal taxes or other federal claims.

2. Settlement Jurisdiction. Settlement of claims in non-bankruptcy insolvency proceedings (excluding the adjustment of a tax claim as discussed in paragraph (3) below) generally will be within the jurisdiction of the Department of Justice. Because the case will have been referred to DJ for defense or prosecution, Field Counsel should write to the Tax Division setting forth a recommendation.



1. Pursuant to section 6405(a), any proposed settlement or concession in a case resulting in a refund or credit in excess of $ 2,000,000 is subject to Joint Committee review. For procedures regarding Joint Committee Cases, see CCDM 34.8.2.8.


3. Adjusting a Tax Claim. The Service may adjust its tax claim in an insolvency proceeding to reflect the actual tax liability or a subsequently agreed to tax liability without reference to DJ provided no formal objections have been filed to the Government’s proof of claim. The tax liability may be adjusted if subsequent information indicates that the original claim was excessive in amount or part of the original claim is erroneous on the merits (for example, mathematical or clerical errors, substantiation of claimed deductions or payments of tax, interest, or penalty). The litigation hazard of any or all of the issues involved will form a basis for making an adjustment. An adjustment may result from a conference after the issuance of a Form 1005(DO) letter.



1. If a claim has been sent because deficiencies have been determined but not assessed, the proof of claim may be reduced without further reference to DJ provided: 1) there has not been an objection filed to the proof of claim; 2) there has not been an earlier reference to DJ; 3) the reduction is not based on the hazards of litigation; and 4) the reduction is consistent with the authority of an Appeals Officer to dispose of matters.


4. Offer in Compromise during Proceedings. If an offer to compromise the tax liability of the taxpayer is submitted under section 7122 during non-bankruptcy insolvency proceedings proposing payment of funds not under the jurisdiction of the court, the offer should be referred to Field Counsel, who will determine whether the offer should be processed through DJ or handled by the Service.


**34.4.1.7** **(08-11-2004)**

### The Insolvency Statute, 31 U.S.C. § 3713(a)

1. Where there are tax liabilities in a non-bankruptcy insolvency, the Government’s right to priority under 31 U.S.C. § 3713(a) should be considered, especially when the Government does not have a tax lien to rely on for collection. Section 3713(a) generally requires that taxes be paid before the claims of other creditors. For a complete discussion of federal priority, the exceptions thereto, and the fiduciary’s personal liability, see IRM 5.17.13.

2. Exceptions to 31 U.S.C. § 3713(a) include:



1. Prior Interests. Section 3713(a) does not give a federal tax claim priority over a prior perfected interest in property or an interest in property that otherwise has priority under Internal Revenue Code section 6323. _Estate of Romani_, 523 U.S. 517 (1998).

2. Administrative Expenses. These are expenses incurred for the general welfare of creditors, and include court costs and expenses incurred to collect and preserve assets. Funeral expenses are deemed to be costs of administration. Administrative expenses may be subject to a standard of reasonableness or specific dollar limitations; therefore, state law should be consulted. Note that the expense of last illness is not entitled to priority. _See_ Rev. Rul. 80-112.

3. Family Allowance. A widow’s allowance or family allowance is generally construed as a charge against the estate and, thus, payable before payment of the debts of the decedent. These expenses are given priority over the federal tax claim if in a reasonable amount. _See_ Rev. Ruls. 79-399 and 80-112.


3. Debts owed to the Government are to be satisfied from the debtor’s estate only. The Government cannot seek payment from property that has been divested before priority accrues under 31 U.S.C. § 3713(a).

4. Fiduciary Liability. Where the federal priority of 31 U.S.C. § 3713(a) applies, a fiduciary is personally liable for debts owed to the Government to the extent the fiduciary pays, in whole or in part, any debt due by the person or estate without first paying the debts owed to the Government. _See_ 31 U.S.C. § 3713(b); CCDM 34.6.2.8; IRM 5.5.1.6 and IRM 5.17.13.8, relating to Personal Liability of the Fiduciary Under 31 U.S.C. section 3713(b).


**34.4.1.8** **(08-11-2004)**

### Receiverships

1. Receiverships are proceedings in state or federal court outside the scope of the Bankruptcy Code where a receiver is appointed to manage the assets of the debtor.

2. There are two types of receiverships:



1. A general receivership is one in which the receiver takes control of all of the assets of the debtor. Collection in a general receivership can be based on the tax lien or on 31 U.S.C. § 3713.

2. A limited receivership is either one in which specific assets are in the custody of a receiver or a proceeding for the benefit of a specific creditor such as a foreclosing mortgagee. Generally, a limited receivership does not involve an insolvent debtor and collection is based on the tax lien. See IRM 5.5.2.2, Working Non Bankruptcy Insolvency Cases and IRM 5.17.13.11, Insolvency and Decedents’ Estates, relating to receiverships.


3. The general rules discussed in CCDM 34.4.1.1 through CCDM 34.4.1.7 apply to receiverships.


**34.4.1.8.1** **(08-11-2004)**

#### Opening a Legal File in Receivership Cases

1. A case is opened by Field Counsel when a problem is referred from the Area Director’s office or there is a need to provide legal advice in a proceeding.



1. If a receivership case is already open, the review of a Form 1005(DO) letter will be handled as part of the open case.

2. If there is no open case, the review of the Form 1005(DO) letter will be jacketed, and a case file should be opened under the appropriate case category.


2. The case will usually be closed when review of the Form 1005(DO) letter has been completed. The receipt of an information copy of a Form 1005(DO) letter is not by itself sufficient basis to jacket a case. See CCDM 34.4.1.8.5 for a general discussion of the Form 1005 letter procedures.


**34.4.1.8.2** **(08-11-2004)**

#### Jurisdiction in Receivership Cases

1. Receiverships are generally filed in state courts pursuant to the court’s general equity jurisdiction. _See_ IRM 5.17.13.11(Receiverships).

2. In jurisdictions where formal intervention is required by local court rules, the filing of a proof of claim may not suffice. In those jurisdictions, Technical Services should refer the matter to Field Counsel so that action may be taken to have a Petition for Intervention filed. A suit letter to the Tax Division requesting and authorizing intervention is required.

3. If the receivership is in federal court, the Government is to intervene to assert its rights. Mere reliance on the filing of a claim will not provide the Government with standing to challenge any action taken in the court proceeding. A suit letter to the Tax Division requesting and authorizing intervention is required. See CCDM 34.6.1 for suit letter preparation instructions and guidelines.


**34.4.1.8.3** **(08-11-2004)**

#### Collection Remedies in Receivership Cases

1. A receiver does not fall within one of the protected classes of section 6323. Accordingly, the Service’s lien priority rights in receivership cases will be governed by comparing the assessment date with the date the receivership proceeding was commenced. Thus, if federal taxes were assessed prior to the receivership, the Service can simply rely on its lien rights. If taxes were not assessed prior to the receivership, the Government must rely on its priority rights under 31 U.S.C. § 3713(a) as discussed in CCDM 34.4.1.7. _See also_ IRM 5.17.13.2 (Priority of Government Claims under 31 U.S.C. section 3713(1)).

2. Problems may arise as to whether or not the court has taken sufficient jurisdiction of all the taxpayer’s assets to bar administrative or other collection activities on the part of the United States during the proceeding. Ordinarily, the United States will not administratively seek collection from assets within the control of the court ( _in custodia legis_) but will take any necessary collection action against property not taken over either in the general receivership or the limited receivership. _See_ IRM 5.17.3.1.3.6. Field Counsel will be called upon to advise the area director as to the permissible limits of collection action in receivership cases.

3. Receiverships are dramatically different from bankruptcy proceedings in that there are no discharge provisions. Thus, any claim filed in the receivership proceeding and not paid would not be subject to discharge, but rather can be collected thereafter from the taxpayer, either by levy or by proceeding in court, to the same extent as if the receivership had not taken place. Taxes not claimed, of course, would be similarly collectible. The normal ten-year period for collection of the tax after assessment under section 6502 would also be suspended by section 6503(b) for the period during which the assets of the taxpayer were under the control or custody of the court in the receivership proceeding, and for six months thereafter. _See_ IRM 5.17.3.

4. For a discussion of the Government’s priority under 31 U.S.C. § 3713(a) and general information regarding the Government’s rights against a receiver under 31 U.S.C. § 3713(b), see CCDM 34.4.1.7.


**34.4.1.8.4** **(03-24-2016)**

#### Receivership Cases Initiated by the United States

1. The Service can seek the appointment of a general receiver for all of the taxpayer’s assets by filing a suit to foreclose the tax lien pursuant to section 7403. Section 7403(d) provides that a court may appoint a receiver upon request by the Government. _See_ IRM 5.17.13.10(4) (Receiverships).

2. The Government’s suit letter in a section 7403 proceeding should request the appointment of a receiver when necessary for the collection, preservation, and orderly liquidation of assets.

3. A request to appoint a receiver must be approved by the Division Counsel (Small Business/Self-Employed).


**34.4.1.8.5** **(08-11-2004)**

#### Immediate Assessments and Form 1005(DO) Letters

1. General Information. Section 6871 requires immediate assessment of any deficiency in income, estate, or gift taxes at the time a receivership proceeding is commenced. This is an exception to the usual procedure requiring the issuance of a statutory notice of deficiency prior to the assessment of certain taxes. _See_ sections 6212 and 6213. The regulations provide that whenever an immediate assessment is made, the fiduciary shall be advised of the assessment and the basis upon which the assessment is made. Treas. Reg. § 301.6871(b)-1(c). Thus, when a receiver is appointed, the Area Director issues a Form 1005(DO) letter for open years if deficiencies have been determined but not assessed. The Form 1005(DO) letter is similar in content to the 90-day letter, even though it is not a document required to be issued by statute. _See_ Exhibit 35.11.1-6.

2. Under Section 6871(c) the Tax Court has no jurisdiction in these cases unless jurisdiction already exists at the time of the appointment of a receiver. _See_ CCDM 35.4.1.5.3.1.


**34.4.1.8.5.1** **(08-11-2004)**

##### Field Counsel Procedures

1. Reviewing the Form 1005(DO) Letter. Not all Form 1005(DO) letters require counsel review before issuance; however, certain Form 1005(DO) letters must be forwarded to Field Counsel for the same review given to certain statutory notices of deficiency. The case file should be forwarded to Field Counsel, but if not, it should be requested whenever deemed necessary. The Field Counsel attorney assigned to review the Form 1005(DO) letter should check to ascertain if a petition has been filed with the Tax Court, and, if so, the two cases should be coordinated.

2. The Form 1005(DO) Conference. The Form 1005(DO) letter invites the fiduciary to request a conference in the event an adjustment is questioned. The Area Director is required to notify counsel’s office of any such conference. If Field Counsel decides to attend, then the office will be involved in the resolution of any question raised at the conference. The extent to which counsel’s office participates in these conferences will depend upon the nature of the controversy, its importance, and the availability of personnel. The decision to participate is made by Field Counsel.

3. Bar Date Expired. If assessment has not been made and the Form 1005(DO) letter has not been sent prior to the expiration of the bar date for filing claims in the proceeding, Field Counsel should be consulted concerning the assertion of personal liability under 31 U.S.C. § 3713 and/or whether or not the assessment should be made and a claim tardily filed in the proceeding.


**34.4.1.9** **(08-11-2004)**

### Assignments for the Benefit of Creditors

1. An Assignment for the Benefit of Creditors is a state law proceeding in which the debtor (the assignor) transfers all of his property (a general assignment) or a part of his property (a partial assignment) to an assignee, who then liquidates the property and applies the proceeds to the debts of the assignor. _See_ IRM 5.5.2.5.

2. The general rules discussed in CCDM 34.4.1.1 through CCDM 34.4.1.7 apply to Assignment for the Benefit of Creditors proceedings.

3. An Assignment for the Benefit of Creditors proceeding has been deemed to be the equivalent of a receivership proceeding, thus permitting the automatic assessment of deficiencies pursuant to section 6871 and the Form 1005 (DO) letter procedures discussed above. _See Williams v. Commissioner_, 44 T.C. 673 (1965), acq. 1966-2 C.B. 4 and 1966-2 C.B. 7. _See also_ IRM 5.17.13.11.2.


**34.4.1.9.1** **(08-11-2004)**

#### Nature of the Assignment for the Benefit of Creditors Proceeding

1. State law should be consulted to determine whether a valid assignment has been made. Generally, contract law is applied to determine if the assignment is valid. A fatal defect to an assignment is fraud on the part of the assignor or an intent to defraud creditors. Fraud must be proven and cannot be presumed.

2. Because these are rather infrequent types of proceedings, the Area Director’s office may not be familiar with the consideration that must be given any possible claim of the United States. Accordingly, whenever Field Counsel is advised of any such proceedings where there is a tax claim, the jurisdiction of the court should be determined, and the Area Director advised as to how to proceed. It is likely most Field Counsel offices have advised Technical Services how to handle assignments in their respective localities.


**34.4.1.9.2** **(08-11-2004)**

#### Collection Remedies Against Assignees

1. An assignee does not fall within one of the protected classes of section 6323. The date of assessment will therefore determine whether the Government has a lien effective against the assignee.

2. Property passes to an assignee subject to existing encumbrances. Therefore, if an assessment was made prior to an assignment, the Government can rely on its lien rights.

3. After a general assignment, no property remains to which a lien can attach. Therefore, if an assessment has not been made prior to the assignment, the Government must rely on 31 U.S.C. § 3713. For a discussion of the Government’s priority under 31 U.S.C. § 3713(a) and general information regarding the Government’s rights against a receiver under 31 U.S.C. § 3713(b), see CCDM 34.4.1.7.


**34.4.1.10** **(08-11-2004)**

### Estates of Decedents or Incompetents

1. Administration of the estate of a decedent or an incompetent is governed by state law. Priority of payment, however, is determined by federal law.

2. The purpose of these proceedings is to marshal all the assets, pay all debts of the debtor and estate, and distribute the balance. The estate may or may not be insolvent. _See_ IRM 5.5.3.1 (Decedent Estates Section Overview) and IRM 5.17.13.10.1 (Administrative Collection).

3. The general rules discussed above in CCDM 34.4.1.1 through CCDM 34.4.1.7 apply to estates of decedents.


**34.4.1.10.1** **(08-11-2004)**

#### Opening a Legal File

1. A legal file is opened by Field Counsel after reference from the Area Director’s office or on Field Counsel’s own initiative. It is not necessary for a court proceeding to be pending in order for Field Counsel to open a file.

2. An offer in compromise that concerns a decedent’s taxes, with no probate pending, should be jacketed as an Offer in Compromise.


**34.4.1.10.2** **(08-11-2004)**

#### Collection Rights Against Estates of Decedents

1. The decedent’s death does not affect tax liens existing at the time of death. Where the assessment is made after death, the tax lien will not attach to property that has already passed to the decedent’s heirs, devisees, or legatees.

2. Administrative collection can be pursued against the decedent’s property if: (i) the lien arose upon assessment prior to the time title to the property passed to heirs, devisees, or legatees (usually at the time of death); and (ii) the property is not under the control of the court (for example, nonprobate assets such as proceeds from life insurance policies). _See_ sections 6321 and 6322; Treas. Reg. § 301.6331-1(a). Note, however, that certain transferees are protected against the federal tax lien under sections 6323 and 6324. _See_ Treas. Reg. § 301.6331-1(a). The decedent’s heirs, devisees, or legatees do not fall within any of the protected categories of section 6323.

3. For a discussion of administrative collection against the estate or distributees of a decedent, see IRM 5.17.13.10.1(Administrative Collection). Note also that section 6871 is not applicable to decedent’s estates. If there is an estate tax deficiency, or if income or gift taxes have not been assessed prior to the decedent’s death, the fiduciary for the estate is entitled to receive a statutory notice of deficiency, which can be petitioned to the Tax Court.

4. For a discussion of the Government’s priority under 31 U.S.C. § 3713(a) and general information regarding the Government’s rights against an executor or administrator under 31 U.S.C. § 3713(b), see CCDM 34.4.1.7.


**34.4.1.11** **(08-11-2004)**

### Corporate Dissolutions

1. State law governs the creation and termination of a corporation. A corporate dissolution can be either judicial or nonjudicial.

2. The general rules discussed in CCDM 34.4.1.1 through 34.4.1.7 apply to corporate dissolutions.


**34.4.1.11.1** **(08-11-2004)**

#### Nature of Corporate Dissolution Proceedings

1. A "receiver," "liquidator," or other fiduciary is appointed by the court in a judicial dissolution to oversee the winding up of corporate affairs while the court hears and determines any controversies that may arise. A nonjudicial dissolution is usually conducted by the officers of the corporation who are in effect trustees for the creditors and, thus, act in a fiduciary capacity.

2. Corporate dissolutions are rare, and procedures in each case will depend largely on state law. _See_ IRM 5.5.2.4 4 (Dissolutions) and IRM 5.17.13.13 (State-law Corporate Dissolutions).

3. A judicial dissolution proceeding may arguably be deemed sufficiently equivalent to a receivership proceeding, under the rationale of _Williams v. Commissioner_, 44 T.C. 673 (1965), so as to permit the automatic assessment of deficiencies pursuant to section 6871. _See_ CCDM 34.4.1.9.


**34.4.1.11.2** **(08-11-2004)**

#### Converting Nonjudicial Dissolution into a Receivership

1. If at any time it is determined that the interests of the United States are not being protected in a nonjudicial dissolution, a suit to subject corporate properties to payment of tax under section 7403 could be brought, and a receiver can be appointed thereunder. _See_ CCDM 34.4.1.8.4. If this is done, it will probably result in converting the nonjudicial dissolution into a judicial dissolution, after which the proceeding will continue under supervision of the court.

2. If tangible property is accessible, seizure action might be faster and more appropriate than filing suit.


**34.4.1.11.3** **(08-11-2004)**

#### Collection Remedies in Corporate Dissolutions

1. In a judicial dissolution, a proof of claim is usually filed and normal administrative collection activities are suspended until it is determined that certain collection activities will not interfere with the court’s administration.

2. In a nonjudicial dissolution, administrative collection activities, including levies, may be appropriate.

3. Taxes can also be collected through assertion of transferee liability, a suit to set aside a fraudulent conveyance, and Trust Fund Recovery Penalty procedures.

4. Some states provide that stockholders who have received a distribution are liable for unpaid corporate debts to the extent of the distribution. There are three possible means of collection from stockholders:



1. If federal tax liens attached to the property before the distribution, the transfer does not divest the tax liens and the property received may be foreclosed in the hands of the stockholders by suit under section 7403(b).

2. Transferee liability may be assessed under section 6901 and the transferee’s property may be seized and sold in the usual manner.

3. Suit may be filed to set aside the transfer as a conveyance in fraud of creditors.


5. For a discussion of the Government’s priority under 31 U.S.C. § 3713(a) and general information regarding the Government’s rights against corporate officers, directors and shareholders as fiduciaries under 31 U.S.C. § 3713(b), see CCDM 34.4.1.7.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part34/irm_34-004-001#addtoany "Show all")

A2A