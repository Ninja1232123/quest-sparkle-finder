---
url: "https://www.irs.gov/irm/part33/irm_33-001-003"
title: "33.1.3 Releasing Legal Advice to the Public | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part33/irm_33-001-003#main-content)

- 33.1.3 [Releasing Legal Advice to the Public](https://www.irs.gov/irm/part33/irm_33-001-003#idm140642417981456)
  - 33.1.3.1 [Processing Legal Advice for Public Inspection](https://www.irs.gov/irm/part33/irm_33-001-003#idm140642375513936)

    - 33.1.3.1.1 [Definition of Chief Counsel Advice](https://www.irs.gov/irm/part33/irm_33-001-003#idm140642383743808)

  - 33.1.3.2 [Redacting Legal Advice Prior to Public Release](https://www.irs.gov/irm/part33/irm_33-001-003#idm140642369902992)

    - 33.1.3.2.1 [Mandatory Deletions of Taxpayer Identifying Information](https://www.irs.gov/irm/part33/irm_33-001-003#idm140642375416224)
    - 33.1.3.2.2 [Permissive Deletions of Privileged Material](https://www.irs.gov/irm/part33/irm_33-001-003#idm140642395108304)
    - 33.1.3.2.3 [Coordinating Proposed Redactions with Field Counsel](https://www.irs.gov/irm/part33/irm_33-001-003#idm140642386034960)
    - 33.1.3.2.4 [Coordinating Proposed Redactions with Associate Offices](https://www.irs.gov/irm/part33/irm_33-001-003#idm140642375279008)

  - 33.1.3.3 [Dissemination of Chief Counsel Advice and Field Advice Reviewed by the Associate Offices](https://www.irs.gov/irm/part33/irm_33-001-003#idm140642390953136)
  - Exhibit 33.1.3-1 [Check Sheet for Processing Taxpayer Specific CCA](https://www.irs.gov/irm/part33/irm_33-001-003#idm140642388454752)
  - Exhibit 33.1.3-2 [Check Sheet for Processing NonTaxpayer Specific CCA](https://www.irs.gov/irm/part33/irm_33-001-003#idm140642384101888)
  - Exhibit 33.1.3-3 [Checksheet for Processing CCA Memoranda Withheld in their Entirety](https://www.irs.gov/irm/part33/irm_33-001-003#idm140642375014800)
  - Exhibit 33.1.3-4 [Check Sheet for Processing CCA from CAM/CAP Cases](https://www.irs.gov/irm/part33/irm_33-001-003#idm140642373691968)
  - Exhibit 33.1.3-5 [Check Sheet for Processing Field Advice Reviewed by the Associate Offices](https://www.irs.gov/irm/part33/irm_33-001-003#idm140642364621408)
  - Exhibit 33.1.3-6 [List of Taxpayer Identifiers](https://www.irs.gov/irm/part33/irm_33-001-003#idm140642390815792)

# Part 33. Legal Advice

# Chapter 1. Legal Advice

# Section 3. Releasing Legal Advice to the Public

* * *

## 33.1.3 Releasing Legal Advice to the Public

#### Manual Transmittal

July 05, 2011

#### Purpose

(1) This transmits revised CCDM 33.1.3, Legal Advice; Releasing Legal Advice to the Public.

#### Material Changes

(1) The table structures in Exhibits 33.1.3-3 and 33.1.3-6 were modified to correct the printed display.

#### Effect on Other Documents

CCDM 33.1.3 dated January 25, 2011 is superseded.

#### Audience

Chief Counsel

#### Effective Date

(07-05-2011)

Michael T. Cochis

Director, Planning and Management Division

**33.1.3.1** **(01-25-2011)**

### Processing Legal Advice for Public Inspection

1. This section provides procedures for processing legal advice for release to the public. This includes advice categorized as Chief Counsel advice (CCA) under IRC § 6110, as well as legal advice prepared in the Field that is reviewed by the Associate offices under the procedures discussed in CCDM 33.1.2.3, Legal Advice Prepared in the Field and Reviewed by an Associate Office.

2. Legal advice that constitutes CCA and its background file documents are made available for public inspection in accordance with IRC § 6110. Nontaxpayer specific CCA must be made available for public inspection within 60 days after the date on which it is signed. Taxpayer specific CCA generally must be made available for public inspection 75 to 90 days after the Service provides notice of intention to disclose to the taxpayer to whom the advice pertains. Background file documents are made available upon written request.

3. Legal advice is categorized as CCA only for the purpose of determining whether it must be made available for public inspection. Whether advice is CCA does not determine its category for purposes of Counsel’s management information reporting systems. Not all legal advice is subject to public disclosure. For instance, legal advice in docketed cases may be considered attorney work product in its entirety and would not be released to the public.

4. See Exhibit 33.1.2-1 for Questions and Answers that provide additional information about the release of legal advice to the public.


**33.1.3.1.1** **(01-25-2011)**

#### Definition of Chief Counsel Advice

1. IRC § 6110(i)(1)(A) defines CCA as written advice or instruction, under whatever name or designation, prepared by any National Office component of the Office of Chief Counsel that



1. Is issued to Field or Service Center employees of the Service or Field employees of the Office of Chief Counsel, and

2. Conveys any legal interpretation of a revenue provision, any Service or Office of Chief Counsel position or policy concerning a revenue provision, or any legal interpretation of State law, foreign law, or other Federal law relating to the assessment or collection of any liability under a revenue provision.


2. CCA includes both taxpayer specific and nontaxpayer specific advice. CCA includes Service Campus Advice, TAS Advice, and any written legal opinion pertaining to revenue provisions from a National Office component of the Office of Chief Counsel to any Field Office. The following general guidelines should be followed in determining whether a document is CCA:



1. Only advice that conveys legal interpretations or positions of the Service concerning existing or former revenue provisions is considered to be CCA. The term "revenue provisions" includes the Internal Revenue Code, regulations, revenue rulings, revenue procedures, or other administrative interpretations or guidance, tax treaties, court decisions, and opinions. CCA also includes legal interpretations of state law, foreign law, or other federal law relating to the assessment or collection of liabilities under revenue provisions. Thus, advice provided by an Associate office relating to labor law or procurement law is not CCA because the advice does not concern revenue provisions. Advice or instruction written by, for example, Criminal Tax, that addresses Federal statutes that do not relate to the assessment or collection of liabilities under the revenue laws (e.g., money laundering or "pure" Title 31 cases) should not be treated as CCA.

2. Only those documents written by the National Office of Chief Counsel and issued to field offices are considered to be CCA. Thus, an advisory or instructional document that the National Office of Chief Counsel provides to National Office program executives is not CCA. Also, suit letters to, and subsequent correspondence with, the Department of Justice, appeal or certiorari recommendation letters are not CCA.

3. Informal advice provided by a National Office professional is not CCA. In the case of e-mail responses to questions from the Field, if the response involves less than two hours of research and preparation, such that a case file is not opened, then the e-mail is considered informal advice and is not CCA. Conversely, if the time expended in researching and preparing an e-mail response consumes two or more hours, then the e-mail is not informal advice and may be CCA if it meets the definition. The two-hour business rule is the touchstone for determining, for business reasons, whether advice is considered "informal" or "formal." The Office of Chief Counsel follows this business rule as to what is informal advice regardless of the manner of delivery of the advice.

4. While legal advice prepared by the Field and reviewed in the National Office are not, technically, CCA because they are not written or issued by a National Office component, they are released to the public. Also, the formal response of the National Office may be CCA, depending on the nature of that response. If only a telephone contact sheet is prepared because there are no controversies or changes to the field advisory, the contact sheet is not CCA. If changes or more formal advice is needed, the National Office response is CCA.

5. A proposed Notice of Deficiency or proposed defense letter that has been marked up or edited by an Associate office attorney and returned to the Field Counsel attorney or Service employee is not CCA. Also, the actual Notice of Deficiency issued to the taxpayer or the defense letter sent to the Department of Justice is not CCA.

6. The memorandum sent by an Associate office to the local Service office with a Technical Advice that offers additional information, such as case development, litigating hazards, or settlement parameters, is CCA. Thus, both taxpayer identifying information and any privileged information must be redacted before it is released. Please note that this memorandum should not repeat the analysis of the issue addressed in the Technical Advice, including the recitation of, and the response to, arguments not adopted by the Technical Advice.

7. Legal advice issued by the National Office and distributed to Field employees in writing is generally CCA regardless of the form or title of that writing.

8. A transmittal memorandum that notifies a local Service office that the accompanying incoming request for PLR, or similar document (e.g., Change of Accounting Method, Change of Accounting Period, Closing Agreement) has been withdrawn by the taxpayer and offering to provide assistance is not CCA. Such a transmittal memorandum should not include legal advice (including the reasons as to why the Service may have tentatively been adverse to the PLR request). Rather, any legal advice issued to the local office, whether issued at the time of withdrawal or subsequently, should be provided in a separate memorandum and is CCA.

9. The questions and answers in Exhibit 33.1.2-1 provide further clarification about the kinds of documents that are CCA and the kinds that are not.


3. For a document to be CCA, it must be issued by a National Office component of the Office of Chief Counsel. The following offices are considered National Office components, and all other offices are considered field offices:



   - Associate Chief Counsel and Assistant Chief Counsel offices

   - Division Counsel offices, including Division Counsel (Small Business/Self-Employed), Division Counsel (Large Business and International), Division Counsel (Wage and Investment) and the immediate headquarters staff

   - The immediate headquarters staff of the Associate Chief Counsel (Tax Exempt and Government Entities), Associate Chief Counsel (Criminal Tax), and Associate Chief Counsel (General Legal Services)



     ### Note:



     Advice from the headquarters of GLS will only constitute CCA if it otherwise meets the requirements of IRC § 6110.


4. To qualify as CCA, a document must be issued to field or Service Campus employees of the Service or Field employees of the Office of Chief Counsel. Service Campuses, processing centers, and other organizations denoted as field functions are considered field organizations for purposes of receiving CCA. The following offices, however, are considered National Office components:



   - Industry director offices of Large Business and International (LB&I)

   - TEC, CAS, and Compliance program and policy offices of Small Business/Self-Employed (SB/SE)

   - CARE, CAS, and Compliance program and policy offices of Wage and Investment (W&I)

   - Directors and their staff in Tax Exempt and Government Entities (TE/GE)


**33.1.3.2** **(08-11-2004)**

### Redacting Legal Advice Prior to Public Release

1. The Service must delete taxpayer identifying information and it may delete privileged information in accordance with subsections (b) and (c) of the Freedom of Information Act before legal advice or their background file documents are made available for public inspection.

2. If an attorney’s name, unique identifying number (badge number), or the names and unique identifying numbers of Service or Chief Counsel employees, other than the name of the individual who signs the document, are included in the legal advice, they may not be redacted at the time the advice is prepared for release. Generally, legal advice that will be released to the public should be prepared without this information.

3. Legal advice must be prepared for release using eWord and the eWord tool bar. The eWord tool bar allows the attorney to identify privileged matter and taxpayer identifiers in the legal advice and to automatically submit the document to the Chief Counsel Disclosure and Litigation Support Branch. Instructions for using eWord can be found on the Chief Counsel intranet site.


**33.1.3.2.1** **(08-11-2004)**

#### Mandatory Deletions of Taxpayer Identifying Information

1. The Service is required to delete of the names, addresses, and other identifying details of the person to whom the legal advice pertains and of any other person identified in the legal advice when legal advice is released to the public. The standard for deciding whether legal advice contains taxpayer identifying details is whether a reasonable person generally knowledgeable with respect to the appropriate community will be able to identify the person or entity based on the information available in the community at the time the document is to be released. The "appropriate community" can be an industry or geographical community.

2. Dates, dollar amounts, percentages, or the taxpayer’s industry, geographic location, business relationships, or associates should be redacted only when, given the facts of a particular case, it identifies the taxpayer.


**33.1.3.2.2** **(08-11-2005)**

#### Permissive Deletions of Privileged Material

1. Information in a legal advice document that is protected from disclosure under the Freedom of Information Act (FOIA) may be deleted before the document is made available for public inspection. This includes, but is not limited to, information that would not be available by law to a party other than the Service in litigation against the Service (attorney work product or attorney-client communications), or information compiled for law enforcement purposes if the release of such information could reasonably be expected to interfere with enforcement proceedings, would constitute an unwarranted invasion of privacy, could reasonably be expected to disclose the identity of a confidential source, would disclose law enforcement techniques or procedures, tolerances, or guidelines if such disclosure could reasonably be expected to risk circumvention of the law. See IRM 11.3.13.7 , Review and Editing.

2. Generally, discussions of a legal argument that may be applicable to a given set of facts is not per se protected by the attorney-client privilege. Information the government attorney gives to the case agent to assist in case development may, however, include material protected by the attorney-client privilege. For example, discussion of how the case agent should develop a set of facts to support a given legal argument may be protected by the attorney-client privilege.

3. The claim of deliberative process only applies to discussions as to the shape and direction of ongoing or upcoming policy discussions and/or considerations which may appear in legal advice. For example, language such as "we are discussing with Treasury the prospects for legislation to close this loophole" or "we are recommending that Treasury expedite this regulation project" may be withheld, so long as the information is not otherwise already known by the public (e.g., public addresses before external stakeholders or press, which may discuss, for example, details of the Guidance Priority List) may be redacted.

4. Claiming attorney work product requires a litigation predicate, either docketed in court, or, based on the totality of the facts, there is a reasonable anticipation of litigation (e.g., designated case, prior cycles with the taxpayer on these issues were litigated; taxpayer representative advises of intention to litigate, etc.). In cases where the legal advice is not to be made available for public inspection on the basis of attorney work product, the appropriate Check Sheet must be completed and accompany the legal advice when it is transmitted to the Disclosure & Litigation Support Branch.

5. Strategic discussions should be redacted. A specific assessment of a litigating hazard, and the recommendation which follows from it (i.e., settle, litigate, concede a particular issue), also should be redacted." We see the court holding in our favor as a 50-50 proposition" along with an analysis may be withheld. A numeric assessment, however, is not needed in order to redact. For example, the phrase "the court is likely to accept taxpayer’s position" should be redacted because the phrase "likely" means "more than 50%."

6. In documents for which the attorney work product predicate is not present, information may be redacted in reliance on FOIA exemptions 2 or 7. These types of strategic discussions, which may include recommendations as to the development of specific additional facts, tolerances, assessments of litigating hazards or the case’s strengths and weaknesses, or particulars as to the scope and direction of the case, may be redacted in reliance on FOIA exemption 7A, where it is established that the information’s disclosure will frustrate, or otherwise adversely affect, the audit, investigation, litigation, or similar ongoing compliance activity. Similarly, discussions of litigating hazards, tolerances, settlement criteria, or the prospects for concession, when they may affect similarly situated taxpayers, should be redacted under FOIA exemptions 2 and 7E, which protect from disclosure guidelines for law enforcement investigations.

7. The following are types of interferences with ongoing enforcement activities (e.g., examinations, criminal investigations, collection activities, judicial proceedings) that are encompassed by FOIA exemption 7A — fears of disclosure of:



01. Evidence

02. Witnesses

03. Prospective testimony

04. The reliance placed by the government upon the evidence

05. The transactions being investigated

06. The direction of the investigation

07. Government strategy

08. Confidential informants

09. The scope and limits of the government’s investigation

10. The attorney work product

11. The methods of surveillance

12. Subjects of surveillance



       ### Note:



       The disclosure of this information could reasonably be expected to risk circumvention of law and may be claimed on a case-by-case basis.


8. The exemptions incorporated into IRC § 6110(i)(3) are borrowed from the FOIA, which is a disclosure, rather than a confidentiality, statute. Accordingly, the presumption is to disclose, with the burden on the Service to justify any nondisclosure. Even where it is determined that information may be subject to one or more of the permissive exemptions, the information may be disclosed, consistent with the Commissioner’s discretionary disclosure policy (Policy Statement 11–13 (4/23/2004)), after giving "a full and deliberate consideration of the institutional, commercial and personal privacy interests that could be implicated by disclosure." Before making the decision to waive any applicable FOIA exemption and release the information, the attorney and manager should give equal weight to all competing governmental, proprietary, and personal interests, including the need for candor in decision-making. A memorandum to the file should, thus, be prepared and placed in the official case file that reflects the balancing of these competing interests and the reasons why (or why not) any applicable exemption is (or is not) to be waived as a matter of discretion. For a more detailed explanation of the discretionary disclosure policy, see CCDM 30.11.1.6 , Discretionary Disclosure.

9. Legal advice that inadvertently includes material that could be redacted as privileged "above the line," that is, other than in the section labeled "Case Development & Strategy Recommendations," should not be rewritten to place this material below the line. If, however, sensitive governmental information is included in other portions of an issued legal advice, the privileged information should be redacted before it is made available to the taxpayer and the public.


**33.1.3.2.3** **(01-25-2011)**

#### Coordinating Proposed Redactions with Field Counsel

1. The Associate office that issues the Chief Counsel Advice (CCA) must fax (not e-mail) the unredacted CCA and the Black and Gray version of the CCA to the person who requested the CCA, with a CCA Transmittal Cover Sheet requesting comments on the proposed redactions on the same date that the CCA is issued.

2. The assigned attorney in Field Counsel or the attorney’s manager must telephone or e-mail the Associate Office attorney verifying receipt of the fax. If there has been no contact to confirm receipt of the fax one business day after it was sent, the Associate office attorney should confirm by telephone or e-mail that the fax was received and that the assigned attorney in Field Counsel (or the attorney’s manager) knows that the CCA will be submitted for processing, if no comments on the proposed redactions are received within three business days after the fax was sent.

3. The recipient of the CCA has three business days to provide any comments on the proposed redactions. If no comments are received, the Associate office may assume that none are forthcoming and submit the CCA for processing. When Field Counsel recommends either additional or fewer redactions to the CCA, the Associate office attorney must review these recommendations and make a judgment on their appropriateness. The Associate office and Field Counsel must agree on the redactions before the CCA is sent to the Disclosure and Litigation Support Branch for processing. Any disagreements concerning the proposed redactions must be reconciled under reconciliation procedures within five business days after the Field has provided its comments on the proposed redactions.



### Note:



Once the CCA has been issued (signed and dated), the text of the CCA may not be moved or changed, except for obvious typographical errors.

4. The appropriate CCA check sheet must be completed and placed in the official case file. The check sheets must be used to accompany closing cases to ensure proper processing. See Exhibits 33.1.3-1, 33.1.3-2, 33.1.3-3, 3 and 33.1.3-4. The check sheets include instructions regarding use of the UILC, taxpayer mailing information (if appropriate), number of copies, and electronic processing. The check sheets are also available on the Procedure & Administration website. See Exhibit 33.1.3–6 for a non-exclusive list of taxpayer identifiers.

5. An electronic copy of the CCA must be submitted to the Disclosure and Litigation Support Branch using the submit button on the eWord toolbar no later than five business days after the Field has provided (or is deemed to have provided) its comments on the proposed redactions to the Associate office. A copy of the automated message acknowledging receipt of the document for processing by the Branch must be placed in the official case file.

6. A paper copy of the completed check sheet must be forwarded to the Disclosure and Litigation Support Branch no later than five business days after the field provided (or was deemed to have provided) their comments on the proposed redactions to the Associate office.


**33.1.3.2.4** **(08-11-2004)**

#### Coordinating Proposed Redactions with Associate Offices

1. The assigned attorney in Field Counsel will, within three business days from the date on which the approved and signed advice is transmitted to the Field under the procedures in CCDM 33.1.2.3, Legal Advice Prepared in the Field and Reviewed by an Associate Office , submit the black and white version of the document and the memorandum discussing the claimed privileges to the Associate office for review as an attachment to an e-mail message sent to the Associate office attorney who had primary responsibility for reviewing the advice.

2. The Associate office attorney will review the proposed redactions to ensure that the material deleted either identifies the taxpayer or is privileged. Within three business days from the date on which the redacted advice has been submitted to the Associate office for review of the proposed deletions, the Associate office attorney will send a response to Field Counsel.



1. If the Associate office attorney agrees with the Field’s proposed deletions, the Associate office attorney will e-mail the assigned attorney in Field Counsel indicating concurrence and that the redacted version may be submitted for processing.

2. If the Associate office attorney believes that the proposed deletions need to be modified or additional deletions be made, the Associate office attorney will send by e-mail the recommended modifications, along with an explanation of the reasons for the modified or additional deletions, to the assigned attorney in Field Counsel. If Field Counsel agrees with the modifications, the revised redacted advice should be resubmitted to the Associate office clearly marking the e-mail as a resubmission. Field Counsel will attach the Associate office attorney’s e-mail, reflecting the modifications, to the memorandum to the file prepared by Field Counsel that identifies the privileges claimed and provides the reasons the Service is claiming privilege. If Field Counsel does not agree with the modifications, the disagreement must be reconciled pursuant to established procedures.


3. Within one business day after agreement is reached on the proposed redactions, the assigned attorney in Field Counsel will submit the advice for processing using the submit button on the eWord toolbar. A copy of the automated message acknowledging receipt of the document for processing by the Disclosure and Litigation Support Branch must be placed in the official case file.

4. A completed check sheet should be e-mailed to the "6110 Disclosure" mailbox using normal sensitivity contemporaneous with submission of the advice to the Disclosure and Litigation Support Branch. See Exhibit 33.1.3-5, Check Sheet for Processing Field Advice Reviewed by the Associate Offices. The Branch is responsible for providing the taxpayer with the notice of intention to disclose when the advice is taxpayer specific.


**33.1.3.3** **(08-11-2004)**

### Dissemination of Chief Counsel Advice and Field Advice Reviewed by the Associate Offices

1. Because CCA in redacted form is made available to the public, questions arise about the extent to which unredacted advice or the unredacted potions of advice may be disseminated. This subsection sets forth the restrictions governing the dissemination of CCA and legal advice that has been prepared in the field and reviewed by the Associate offices.

2. Nontaxpayer specific CCA is made available for public inspection within 60 days after the CCA has been issued. CCA are issued when they are dated and signed by the Counsel employee authorized to sign the CCA. Taxpayer specific CCA is made available for public inspection not less than 75 days and not more than 90 days after the taxpayer to whom the CCA pertains has been provided notice of intent to disclose. Because of processing constraints, neither the release of taxpayer specific or nontaxpayer specific CCA can be expedited. The same time frames apply to the processing of legal advice prepared in the field and reviewed by the Associate offices.

3. Service employees (including Appeals and Counsel) are not permitted to transmit legal advice released to the public electronically, except that the file available in the Electronic Freedom of Information Room may be sent as an attachment to an e-mail. Dissemination of the hard copy ensures that the version that was issued is the one being disseminated. At this time, an electronic version increases the likelihood of mistakes. Dissemination of the hard copy also precludes any manipulation of the actual issued content of the legal advice.

4. The original, unredacted advice may be disseminated to the recipient and other Service or Chief Counsel employees who have a "need to know." For this purpose, "need to know" is consistent with the standard applicable under IRC § 6110(h)(1). This need-to-know standard also applies to the dissemination of other forms of legal advice.



1. Legal advice may be disseminated to any Service or Chief Counsel employee before it is available to the public if the advice is not taxpayer specific (does not contain any taxpayer identifying information) and there is no privileged material in the document.

2. Legal advice that contains taxpayer identifying information or privilege material may not be disseminated internally, except to the recipient or any other Service or Chief Counsel employee who has a "need to know" unless the document has been made available to public. Employees who do not have a "need to know" may only receive the copy of the document that is available publicly. Before the taxpayer notification process is completed, it is possible that additional redactions will need to be made. Thus, only by waiting until the legal advice is made publicly available may we be assured that all appropriate redactions have been made.

3. Service employees (including Appeals and Counsel) who are working on the case in which the legal advice was issued have a need to know regardless of when the employee begins to work on the case.

4. Service employees (including Appeals and Counsel) who are working on a case involving the same taxpayer, but a different audit cycle, to whom legal advice pertains satisfy the need-to-know standard with respect to the legal advice.

5. Service employees (including Appeals and Counsel) who are working on a case that is transactionally related to the case to which the legal advice pertains satisfy the need-to-know standard with respect to the legal advice.

6. Industry program analysts satisfy the need-to-know standard with respect to the legal advice that affect their respective industries or subject matter jurisdiction. This material is necessary for industry program analysts to perform their tax administration duties of ensuring a coordinated and consistent approach in their respective industries or subject matter jurisdiction.

7. Division Counsel program managers and Senior Legal Counsel satisfy the need-to-know standard with respect to the legal advice that affect their respective industries or subject matter jurisdiction.


5. Taxpayer specific legal advice (with or without privileged material) generally may not be shared with Service and/or Counsel field personnel working on cases with different, untransactionally related taxpayers, which may have facts and/or issues in common. The Associate office that issues or reviews the advice serves as gatekeeper for this purpose. The Associate office determines whether the legal document should be further disseminated, based upon an IRC § 6103(h)(1) need-to-know standard (for taxpayer specific CCA), and management’s assessment that this further dissemination is the best means by which to provide assistance to other recipients. Caution should be exercised, however. Dissemination may affect the ability to protect privileged materials.

6. Nontaxpayer specific advice that contains privileged material that is issued to one field office may not be disseminated to other field offices within the same geographic area. Dissemination may affect the ability to protect privileged materials.

7. The original, unredacted advice may only be disseminated to persons outside of the Service as follows:



1. Attorney-advisors in the Office of Tax Policy or General Counsel attorneys in the Department of Treasury are afforded access to Chief Counsel advice under the same standards applicable to Service and Chief Counsel employees.

2. Department of Justice trial attorneys who are representing the government in a tax proceeding may receive taxpayer-specific advice if the taxpayer is a party to the tax proceeding or the proceedings are out of, or in connection with, determining the taxpayer’s liability, or if the "item" or "transaction" tests of subsections (h)(2)(B) and/or (C) are met.

3. Department of Justice trial attorneys who are representing the Government in a tax proceeding may receive nontaxpayer-specific advice if they are representing the Service with respect to a matter addressed in the legal advice.


**Exhibit 33.1.3-1**

### Check Sheet for Processing Taxpayer Specific CCA

|  |
| :-: |
| **Checksheet for Processing Taxpayer Specific CCA** |
| Case Control Name: \_\_\_\_ |
| Case Control Number: \_ | WLI #: \_ |
| N.O. Issuing Branch: \_ | Date of Issuance (signed): \_ |
| Mailing address for CC:PA:LPD:DLS — Taxpayer's (not Taxpayer's representative) address: |
| \\_\\_\\_\_\_\_ |
| \\_\\_\\_\_\_\_ |
| \\_\\_\\_\_\_\_ |
| \\_\\_\\_\_\_\_ |
| \_ | 1\. Does the CCA reflect the uniform issue list number(s)? |
| \_ | 2\. Does the CCA contain any taxpayer identifiers or privileged matter? |
|  | \_ | If yes, have the taxpayer identifiers and/or privileged matter been redacted from the CCA? |
| \_ | 3\. Was the redacted (black and gray — privilege matter redacted in black and IRC 6110 information highlighted in gray) version and an unredacted version (or, if no redactions, only the unredacted version) of the CCA and the CCA transmittal cover sheet faxed (**not e-mailed**) to the Field for comment on redactions (or potential redactions) **on the date that the advice was issued (signed)**? |
|  | \_ | Did the Field attorney or his or her manager telephone or e-mail the National Office attorney verifying receipt of the fax as required by the CCA transmittal cover sheet? |
|  | \_ | If the Field attorney or his or her manager did not contact the National Office attorney to confirm receipt of the fax within 1 business day after it was sent, did the National Office attorney telephone or e-mail the Field attorney (or his or her manager) to confirm that the fax was received and that the **Field attorney (or his or her manager) knew that their comments on the proposed redactions (taxpayer identifiers and privileges) were needed no later than 3 business days after the fax was sent and that the National Office would assume that they had no comments if a response was not received within that time**? |
| \_ | 4\. Did the Field provide any comments on the proposed redactions? The results of any discussions with the Field on the proposed redactions should be noted on the case history sheet. |
|  | \_ | If the Field provided comments on the proposed redactions, has the redacted version of the CCA been revised to reflect the Field's comments (disagreements on potential redactions must be reconciled in accordance with applicable Chief Counsel procedures) and 3 copies of the revised redacted (black and gray) version been printed (Two copies to be forwarded to CC:PA:LPD:DLS (see #8 below) and one copy with the applicable authority for the redactions noted to be retained in the official case file)? |
|  | \_ | If the Field did **not** provide any comments on the proposed redactions, have 3 copies of the redacted (black and gray) version been printed (One copy to be forwarded to CC:PA:LPD:DLS (see #7 below) and one copy with the applicable authority for the redactions noted to be retained in the official case file)? |
| \_ | 5\. Has a memo to the file been prepared and placed in the official case file identifying the specific privileges being claimed, if any, and describing the harm which would result from disclosure of the privileged matter? |
| \_ | 6\. Has the electronic version of the CCA been redacted using the e-Word toolbar (note: if the original CCA was date-stamped, the date that the document was signed should be inserted directly below the letterhead on the electronic version of the CCA) and submitted to CC:PA:LPD:DLS through Counsel’s content management system (Documentum).? (Click the “Submit” button on the lower right-hand side of the e-Word toolbar to submit a document through Documentum.) **A copy of the electronically generated receipt acknowledging the submission of the CCA through Documentum must be placed in the office's official case**. |
| \_ | 7\. Forward 2 paper copies of the Black and Gray version of the CCA, and a paper copy of the completed checksheet to CC:PA:LPD:DLS (Rm. 5201) **no later than 5 business days after the Field provided (or was deemed to have provided) their comments** on the redactions to the National Office. Place a copy of this checksheet in the office's official case file. |
| Initiator: \_\_ | Date: \_ |
| Reviewer: \_\_ | Date: \_ |
|  |
| _**Note:** Initiators and Reviewers are responsible for ensuring that CCA procedures have been followed and that the documents have been sent to CC:PA:LPD:DLS._ |
| _(Rev. Sept. 2005)_ |

**Exhibit 33.1.3-2**

### Check Sheet for Processing NonTaxpayer Specific CCA

|  |
| :-: |
| **Checksheet for Processing NonTaxpayer Specific CCA** |
| Case Control Name: \_\_\_\_ |
| Case Control Number: \_ | WLI #: \_ |
| N.O. Issuing Branch: \_ | Date of Issuance (signed): \_ |
| \_ | 1\. Does the CCA reflect the uniform issue list number(s)? |
| \_ | 2\. Does the CCA contain any taxpayer identifiers or privileged matter? |
|  | \_ | If yes, have the taxpayer identifiers and/or privileged matter been redacted from the CCA? |
| \_ | 3\. Was the redacted (black and gray — privilege matter redacted in black and IRC 6110 information highlighted in gray) version and an unredacted version (or, if no redactions, only the unredacted version) of the CCA and the CCA transmittal cover sheet faxed (**not e-mailed**) to the Field for comment on redactions (or potential redactions) **on the date that the advice was issued (signed)**? |
|  | \_ | Did the Field attorney or his or her manager telephone or e-mail the National Office attorney verifying receipt of the fax as required by the CCA transmittal cover sheet? |
|  | \_ | If the Field attorney or his or her manager did not contact the National Office attorney to confirm receipt of the fax within 1 business day after it was sent, did the National Office attorney telephone or e-mail the Field attorney (or his or her manager) to confirm that the fax was received and that the **Field attorney (or his or her manager) knew that their comments on the proposed redactions (taxpayer identifiers and privileges) were needed no later than 3 business days after the fax was sent and that the National Office would assume that they had no comments if a response was not received within that time**? |
| \_ | 4\. Did the Field provide any comments on the proposed redactions? The results of any discussions with the Field on the proposed redactions should be noted on the case history sheet. |
|  | \_ | If the Field provided comments on the proposed redactions, has the redacted version of the CCA been revised to reflect the Field's comments (disagreements on potential redactions must be reconciled in accordance with applicable Chief Counsel procedures) and 2 copies of the revised redacted (black and gray) version been printed (One copy to be forwarded to CC:PA:LPD:DLS (see #7 below) and one copy with the applicable authority for the redactions noted to be retained in the official case file)? |
|  | \_ | If the Field did **not** provide any comments on the proposed redactions, have 2 copies of the redacted (black and gray) version been printed (One copy to be forwarded with addressed envelope to CC:PA:LPD:DLS (see #7 below) and one copy with the applicable authority for the redactions noted to be retained in the official case file)? |
| \_ | 5\. Has a memo to the file been prepared and placed in the official case file identifying the specific privileges being claimed, if any, and describing the harm which would result from disclosure of the privileged matter? |
| \_ | 6\. Has the electronic version of the CCA been redacted using the e-Word toolbar (note: if the original CCA was date-stamped, the date that the document was signed should be inserted directly below the letterhead on the electronic version of the CCA) and submitted to CC:PA:LPD:DLS through Counsel’s content management system (Documentum)? (Click the "Submit" button on the lower right-hand side of the e-Word toolbar to submit a document through Documentum.) **A copy of the electronically generated receipt acknowledging the submission of the CCA through Documentum must be placed in the office's official case file**. |
| \_ | 7\. Forward a paper copy of the Black and Gray version and a paper copy of the completed checksheet to CC:PA:LPD:DLS (Rm. 5201) **no later than 5 business days after the Field provided (or was deemed to have provided) their comments** on the redactions to the National Office. Place a copy of this checksheet in the office's official case file. |
| Initiator: \_\_ | Date: \_ |
| Reviewer: \_\_ | Date: \_ |
|  |
| _**Note:** Initiators and Reviewers are responsible for ensuring that CCA procedures have been followed and that the documents have been sent to CC:PA:LPD:DLS._ |
| _(Rev. Sept. 2005)_ |

**Exhibit 33.1.3-3**

### Checksheet for Processing CCA Memoranda Withheld in their Entirety

|  |
| :-: |
| **Checksheet for Processing CCA Memoranda _Withheld in their Entirety_** |
| Case Control Name: \_\_\_\_ |
| Case Control Number: \_\_ | WLI #: \_ |
| Associate Office Branch/ <br>Division Counsel Office: \_\_\_\_ |
| Date signed: \_ |
| \_ | 1\. Does the CCA reflect the uniform issue list number(s)? |
| \_ | 2\. Does the CCA contain only privileged matter (see next page)? |
|  | \_ | If yes, was the CCA and the CCA transmittal cover sheet faxed (**not e-mailed**) to the Field for comment on the proposed withholding **on the date that the advice was signed**? |
|  | \_ | Did the Field attorney or his or her manager telephone or e-mail the National Office attorney verifying receipt of the fax? |
|  | \_ | If the Field attorney or his or her manager did not contact the National Office attorney to confirm receipt of the fax within one business day after it was sent, did the National Office attorney telephone or e-mail the **Field attorney (or his or her manager) to confirm that the fax was received and that the Field attorney (or his or her manager) knew that their comments on the proposed withholding were needed no later than 3 business days after the fax was sent and that the National Office would assume that they had no comments if a response was not received within that time?** |
| \_ | 3\. Did the Field provide any comments on the proposed withholding? Note the results of any discussions with the Field on the case history sheet. |
|  | \_ | If the Field disagreed with the proposed withholding of the CCA in its entirety, has the disagreement been reconciled? CCDM 31.1.4. If the CCA is to be made available for public inspection with some redactions, please use the appropriate CCA checksheets. If it is determined that the CCA contains only privileged matter and is to be withheld in its entirety, forward one copy to CC:PA:LPD:DLS (see #6 below) and one copy with the applicable authority for the withholding noted to be retained in the official case file. |
|  | \_ | If the Field did not provide any comments, has one copy been forwarded to CC:PA:LPD:DLS (see #6 below) and one copy with the applicable authority for the withholding noted to be retained in the official case file? |
| \_ | 4\. Has a memo to the file been prepared and placed in the official case file identifying the reason for any specific claims of privilege? **If the work product doctrine is being claimed, you can complete the next page of this form instead of a memo.** |
| \_ | 5\. Has the electronic version of the CCA been named with its CASE-MIS number and WLI, and e-mailed to the 6110 Disclosure mailbox (for example, "TL N-12345-98WLI2.doc" ). The e-mail must state that this document is to be withheld in its entirety and be sent using "Normal" sensitivity. A copy of the e-mail transmitting the electronic version must be placed in the official case file. |
| \_ | 6\. Deliver a paper copy of the CCA and a paper copy of the completed checksheet to CC:PA:LPD:DLS (Rm. 5201) no later than five business days after the Field provided (or was deemed to have provided) their comments to you. Place a copy of this check sheet in the office's official case file. |
| Initiator: \_\_ | Date: \_ |
| Reviewer: \_\_ | Date: \_ |
|  |
| _**Note:** Initiators and Reviewers are responsible for ensuring that CCA procedures have been followed and that the documents have been sent to CC:PA:LPD:DLS._ |
|  |
| \\_\\_\\_\_\_\_ |

| **Work Product Doctrine** |
| :-: |
| CCA that is subject to FOIA exemption 5 and the work product doctrine may be withheld in its entirety. In _Tax Analysts v. IRS_, 294 F.3rd 71, 76 (D.C. Cir. 2002), the appellate court adopted the district court's holding that IRS need not segregate and release agency working law from documents withheld in their entirety pursuant to the work product doctrine. The work product doctrine permits the deletion of any material prepared in anticipation of litigation or for trial, by or for a party, or by or for that party's representative, including the party's attorney, consultant, or agent. Documents prepared in the ordinary course of business, in which legal advice or assistance is rendered ( _e.g_., routine review of statutory notices of deficiency or FPAAs, summonses, IDRs,), are not subject to the work product doctrine **_per se_**, unless it can be established that the documents were prepared to aid in reasonably anticipated future litigation. In order for the work product doctrine to apply, one or more of the following statements is true: |
|  | 1\. The case is already docketed in court, including bankruptcy court, when the CCA is issued.<br> 2\. The taxpayer or taxpayer's representative has affirmatively represented that it will litigate any issue addressed in the CCA.<br> 3\. The case has been designated for litigation.<br> 4\. The taxpayer is reputed for its litigious nature.<br> 5\. If you did not check any of the above statements, but believe that the work product doctrine applies, please articulate the basis upon which you believe it does. For example, the issue being discussed in the CCA is one this taxpayer, or the taxpayer's representative, has litigated time and time again and can be expected to in this case. |
| \\_\\_\\_\_\_\_ |

| **Attorney-Client Privilege** |
| :-: |
| A CCA that is subject to FOIA exemption 5 and the attorney-client privilege may be withheld in its entirety. For purposes of CCA, the attorney-client privilege does not protect the legal conclusions that are based upon information obtained from taxpayers. In _Tax Analysts v. IRS_, 117 F.3rd 617, 619 (D.C. Cir. 1997), the court upheld the assertion of the attorney-client privilege for confidential information regarding the scope, direction, or emphasis of audit activity. Thus, if the CCA is limited to strategic advice, _i.e._, a discussion of nonroutine factual development, an evaluation of the strengths and weaknesses of the case, or an analysis of the hazards regarding the Service's technical position, it may be withheld in its entirety. To be withheld in its entirety, the CCA should not contain a lengthy dissertation on the law or an extensive recitation of the facts. Only the most pertinent facts and legal principles as are necessary to understand the advice being given should be included. |
|  | This CCA consists entirely of strategic advice as described in Chief Counsel Directives Manual 33.1.3.2. |
| \\_\\_\\_\_\_\_ |

| **Other Exemptions** |
| :-: |
| Pages 14-15 of the CCA Training Materials, which may be found at http://intranet.prod.irscounsel.treas.gov/Cca/pdf/cca%20training%20materials.pdf, describes other FOIA exemptions that may apply. If you believe one or more of them apply to the entirety of the CCA, please indicate which exemptions and the reason you believe them applicable. If you are claiming one of these exemptions with regard to e-mail advice, please include this information in the e-mail itself. If you accessed this checksheet from the CCACheck dialog box, exit the checksheet, click Cancel on the dialog box, enter the exemption and the reason the exemption is applicable in the text of the e-mail, and then send the e-mail. |
|  |
| ### Note:<br>_Initiators and Reviewers are responsible for ensuring that CCA procedures have been followed and that the documents have been sent to CC:PA:LPD:DLS._ |
|  |
|  |
| _(Rev. May 2008)_ |

**Exhibit 33.1.3-4**

### Check Sheet for Processing CCA from CAM/CAP Cases

|  |
| :-: |
| **Checksheet for Processing CCA from CAM/CAP Cases** |
| Case Control Name: \_\_\_\_ |
| Case Control Number: \_ | WLI #: \_ |
| N.O. Issuing Branch: \_\_\_\_ |
| Date of Issuance (signed): \_\_\_\_ |
| Mailing address for CC:PA:LPD:DLS — Taxpayer's address: |
| \_\_\_\_\_\_ |
| \_\_\_\_\_\_ |
| \_\_\_\_\_\_ |
| \_\_\_\_\_\_ |
| \_ | 1\. Does the CAM/CAP reflect the uniform issue list number(s)? |
| \_ | 2\. Has the Service received a written request to make this CAM/CAP available for public inspection under IRC 6110(g)(5)? A copy of the written request must be placed in the office's official case file for the 6110 written request. |
| \_ | 3\. Has a redacted (Black and Gray) version (taxpayer identifiers and the author's name and identification (badge) number highlighted in gray) of the CAP/CAM been prepared? See page 2 of this checksheet for non-exclusive list of taxpayer identifiers. The Black and Gray version of the CAM/CAP must be prepared **no later than 5 business days after the Associate Office receives a copy of the written request to make the CAM/CAP available for public inspection**. _Note:_ If the original was date-stamped, the date that the document was signed should be inserted directly below the letterhead on the first page of the document. |
| \_ | 4\. Have 3 copies of the Black and Gray version of the CAP/CAM been printed? |
|  |  | • One copy for the office receiving the CCA (forwarded with addressed envelope to CC:PA:LPD:DLS for distribution)<br>• One copy for CC:PA:LPD:DLS<br>• One copy to be retained in the office's official case file |
| \_ | 5\. Has the electronic version of the CAP/CAM been redacted using the e-Word toolbar (note: if the original CAP/CAM was date-stamped, the date that the document was signed should be inserted directly below the letterhead on the electronic version of the CAP/CAM) and submitted to CC:PA:LPD:DLS through Counsel’s content management system (Documentum)? (Click the "Submit" button on the lower right-hand side of the e-Word toolbar to submit a document through Documentum.) **A copy of the electronically generated receipt acknowledging the submission of the CAP/CAM through Documentum must be placed in the office's official case.** |
| \_ | 6\. Forward 2 Black and Gray copies and a copy of the checksheet to CC:PA:LPD:DLS (Rm. 5201) **no later than 5 business days after the Associate Office receives a copy of the written request to make the CAM/CAP available for public inspection**. |
|  |
| Initiator: \_\_ | Date: \_ |
| Reviewer: \_\_ | Date: \_ |
|  |
| **Always redact the author's name and identification (badge) number from the CAP/CAM.** |
| **_Note:_**Initiators and Reviewers are responsible for ensuring that these procedures have been followed and that the documents have been sent to CC:PA:LPD:DLS. |
| _(Rev. Sept. 2005)_ |

**Exhibit 33.1.3-5**

### Check Sheet for Processing Field Advice Reviewed by the Associate Offices

|  |
| :-: |
| **Checksheet for Processing Field Advice Reviewed by the Associate Offices** |
| Case Control Name: \_\_\_\_ |
| Case Control Number: \_ | WLI #: \_ |
| Issuing Office Symbols: \_ | Date of Issuance (signed): \_ |
| \_ | 1\. Does the advice reflect the uniform issue list number(s)? |
| \_ | 2\. Does the advice contain any taxpayer identifiers or privileged matter? |
|  | \_ | If yes, have the taxpayer identifiers and/or privileged matter been redacted from the advice? |
| \_ | 3\. Was the redacted (black and white privilege matter redacted in black and IRC § 6110 information highlighted in white) version and an unredacted version (or, if no redactions, only the unredacted version) of the advice sent to the proper Associate Office for comment on redactions (or potential redactions) **within 3 business days of the date that the advice was issued (signed)**? |
|  | \_ | Did the Associate Office attorney (or his or her manager) verify receipt (e.g., telephonically, by e-mail "read" return receipt, etc.) of this transmission from the Field attorney within 1 business day after it was sent? |
|  | \_ | If the Associate attorney (or his or her manager) did not contact the Field attorney to confirm receipt of the transmission within 1 business day after it was sent, did the Field attorney (or his or her manager) telephone or e-mail the Associate Office attorney (or his or her manager) to confirm that the transmission was received and that the Associate attorney (or his or her manager) knew that their comments on the proposed redactions (taxpayer identifiers and privileges) were needed no later than 3 business days after the transmission was sent and that the Field attorney would assume that they had no comments if a response was not received within that time? |
| \_ | 4\. Did the Associate Office attorney provide any comments on the proposed redactions? Any discussions with the Associate Office on the proposed redactions should be noted on the case history sheet. |
|  | \_ | If the Associate Office provided comments on the proposed redactions, has the redacted version of the advice been revised to reflect these comments (disagreements on potential redactions must be reconciled in accordance with applicable Chief Counsel procedures)? |
| \_ | 5\. Has a memorandum to the file been prepared and placed in the official case file identifying the specific privileges being claimed, if any, and describing the harm which would result from disclosure of the privileged matter? |
| \_ | 6\. Has a Black and White version (privileged matter redacted in black and IRC § 6110 information redacted in white) been prepared (note: if the original advice was date-stamped, the date that the document was signed should be inserted directly below the letterhead on the first page of the advice) and one copy retained in the official case file)? |
| \_ | 7\. Has an electronic version of the advice been redacted using the eWord toolbar and the file been named (or renamed) with its TECHMIS (or case control) number, WLI, and ".doc" suffix. ? For example, the advice may be named/renamed "TL N-12345-98WLI2.doc" . |
| \_ | Has the electronic version of the advice named with its TECHMIS (or case control) number been e-mailed to CC:PA:LPD:DLS's mailbox - "6110 Disclosure" . The e-mail must be sent using "Normal" sensitivity. **A copy of the e-mail transmitting the electronic version to the "6110 Disclosure" mailbox must be placed in the office's official case file.** |
| Initiator: \_\_ | Date: \_ |
| Reviewer: \_\_ | Date: \_ |
|  |
| _**Note:** Initiators and Reviewers are responsible for ensuring that these procedures have been followed and that the documents have been sent to CC:LPD:DLS._ |
| _(Rev. July 2004)_ |

**Exhibit 33.1.3-6**

### List of Taxpayer Identifiers

The following is a non-exclusive list of taxpayer identifiers:

1\. Taxpayer’s name, address (but not necessarily location) and identification number wherever mentioned, including the subject line

2\. Identifying details that a member in the "appropriate community" could use to determine the identity of the taxpayer (see IRC § 6110(i))

| **a. _Per se_ unique facts** |
| --- |
|  | 01. Court Docket number(s) (whether or not the docket number appears in the Techmis number)<br>    <br>02. Policy numbers<br>    <br>03. Outside consultants (names of individuals, not necessarily firm names)<br>    <br>04. Authorized representatives (names of individuals, not necessarily firm names)<br>    <br>05. "Brand name" product lines<br>    <br>06. References to another case involving the same taxpayer(s)<br>    <br>07. Beneficiaries<br>    <br>08. Patents and trademarks<br>    <br>09. Trade secrets<br>    <br>10. Any quotations from an opinion or searchable data base ( _i.e._, SEC filings), if they are associated with the taxpayer(s) |
| **b. Potential unique facts** |
|  | 01. Dollar figures (do not redact $ sign)<br>    <br>02. Dates, including tax years<br>    <br>03. Percentages (do not redact % symbol)<br>    <br>04. Type of business if unique or industry is small<br>    <br>05. Shareholder information<br>    <br>06. Taxpayer location, including State of incorporation<br>    <br>07. Countries of operation<br>    <br>08. Business location (city and state)<br>    <br>09. Region, district, city, including symbols, circuit court<br>    <br>10. References to state law<br>    <br>11. References to unique federal law that impacts few industries or individuals<br>    <br>12. Names of local IRS officers and employees<br>    <br>13. "Generic" product lines<br>    <br>14. Taxpayer hired consultants (Firm names)<br>    <br>15. Firms authorized to represent taxpayer(s)<br>    <br>16. Other information which could be cross referenced in other publicly available sets of information including electronic databases such as Lexis |

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part33/irm_33-001-003#addtoany "Show all")

A2A