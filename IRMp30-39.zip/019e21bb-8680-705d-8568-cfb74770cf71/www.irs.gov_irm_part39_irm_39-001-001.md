---
url: "https://www.irs.gov/irm/part39/irm_39-001-001"
title: "39.1.1 Matters Relating to Ethics and General Government | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part39/irm_39-001-001#main-content)

- 39.1.1  [Matters Relating to Ethics and General Government](https://www.irs.gov/irm/part39/irm_39-001-001#idm139912198203344)
  - 39.1.1.1  [Ethics & General Government Law](https://www.irs.gov/irm/part39/irm_39-001-001#idm139912198206624)
    - 39.1.1.1.1  [Significant Case Coordination](https://www.irs.gov/irm/part39/irm_39-001-001#idm139912171267072)
  - 39.1.1.2  [Professionalism](https://www.irs.gov/irm/part39/irm_39-001-001#idm139912170712752)
    - 39.1.1.2.1  [Our Special Responsibility to the Internal Revenue Service and to the Public](https://www.irs.gov/irm/part39/irm_39-001-001#idm139912170711984)
    - 39.1.1.2.2  [Ethics, Conduct, and Professionalism](https://www.irs.gov/irm/part39/irm_39-001-001#idm139912170707952)
      - 39.1.1.2.2.1  [Standards Applicable to All Office of Chief Counsel Employees](https://www.irs.gov/irm/part39/irm_39-001-001#idm139912170705408)
      - 39.1.1.2.2.2  [Standards Applicable to Office of Chief Counsel Attorneys](https://www.irs.gov/irm/part39/irm_39-001-001#idm139912171209168)
    - 39.1.1.2.3  [Misconduct and Disciplinary Proceedings](https://www.irs.gov/irm/part39/irm_39-001-001#idm139912171206576)
      - 39.1.1.2.3.1  [Matters for Referral to the Treasury Inspector General for Tax Administration](https://www.irs.gov/irm/part39/irm_39-001-001#idm139912171200848)
      - 39.1.1.2.3.2  [Matters for Referral to the Deputy Chief Counsel (Operations) for Consideration](https://www.irs.gov/irm/part39/irm_39-001-001#idm139912169210928)
      - 39.1.1.2.3.3  [Follow Up and Investigation](https://www.irs.gov/irm/part39/irm_39-001-001#idm139912198284592)
      - 39.1.1.2.3.4  [Matters Which May be Handled Under Local Procedures](https://www.irs.gov/irm/part39/irm_39-001-001#idm139912198278800)
      - 39.1.1.2.3.5  [Annual Report](https://www.irs.gov/irm/part39/irm_39-001-001#idm139912198271344)
  - 39.1.1.3  [Government Ethics Programs](https://www.irs.gov/irm/part39/irm_39-001-001#idm139912198268576)
    - 39.1.1.3.1  [Government Ethics Matters in General](https://www.irs.gov/irm/part39/irm_39-001-001#idm139912198267648)
    - 39.1.1.3.2  [Definitions and Delegations of Authority](https://www.irs.gov/irm/part39/irm_39-001-001#idm139912198260800)
    - 39.1.1.3.3  [Follow Up and Investigation](https://www.irs.gov/irm/part39/irm_39-001-001#idm139912169126480)
    - 39.1.1.3.4  [Confidential Financial Disclosure](https://www.irs.gov/irm/part39/irm_39-001-001#idm139912169124416)
      - 39.1.1.3.4.1  [Review](https://www.irs.gov/irm/part39/irm_39-001-001#idm139912169113984)

# Part 39. Chief Counsel Directives Manual General Legal Services

# Chapter 1. Professionalism and Government Ethics Programs

# Section 1. Matters Relating to Ethics and General Government

* * *

## 39.1.1 Matters Relating to Ethics and General Government

#### Manual Transmittal

April 11, 2022

#### Purpose

(1) This transmits CCDM 39.1.1, Ethics and General Government Law; Matters Relating to Ethics and General Government.

#### Background

CCDM 39.1.1 is being issued to more fully describe the subject matter areas handled by the Ethics and General Government Branch (EGG).

#### Material Changes

(1) The heading for CCDM 39.1.1 was changed from Professionalism to Matters Relating to Ethics and General Government.

(2) CCDM 39.1.1.1 was added to more fully describe the subject matter areas assigned to EGG.

(3) CCDM 39.1.1.1.2 was added to describe case-coordination expectations for significant cases falling within EGG’s subject matter areas.

(4) CCDM 39.1.1.2, Professionalism, was revised and moved from former CCDM 39.1.1 to this subsection.

(5) CCDM 39.1.1.3, Government Ethic Programs, was revised and moved from former CCDM Section 39.1.2 to this section.

(6) Minor typographical errors were corrected and editorial changes made throughout.

#### Effect on Other Documents

This section replaces CCDM 39.1.1 dated June 3, 2009.

#### Audience

Chief Counsel

#### Effective Date

(04-11-2022)

Mark Kaizen

Associate Chief Counsel

General Legal Services

**39.1.1.1** **(04-11-2022)**

### Ethics & General Government Law

1. The Ethics and General Government Law Branch (EGG) is responsible for providing legal advice and litigation support on a variety of non-tax legal matters not otherwise assigned to another Counsel or GLS office. EGG attorneys perform in-depth legal research and analysis to provide written and oral legal advice, including program considerations and alternatives, to the IRS and IRS Office of Chief Counsel. The EGG Ethics Program Specialist, working with the EGG Branch Chief, assists the Associate Chief Counsel in executing his or her responsibilities as the Deputy Ethics Official. Subject matter areas assigned to EGG include, but are not limited to, the following:


    a. Ethics and professional responsibility matters under 18 U.S.C. Pt. I, Ch. 11; the Ethics in Government Act; and Government-wide, Treasury, Service, Office, and professional standards and rules of conduct (see CCDM 39.1.3)



1. Conflicts of Interest

2. Post-Employment

3. Outside Employment

4. Standards of Professional Conduct

5. Ethics training

6. Financial disclosure


b. Fiscal and budgetary statutes and regulations


1. Lapses in Appropriations

2. Anti-Deficiency Act

3. User Fees

4. Purpose Statute

5. Bona Fide Needs

6. Miscellaneous Receipts

7. Recording and Liquidating Obligations


c. Delegations of Authority

d. Intellectual Property


1. Copyright

2. Trademark

3. Use of IRS name and symbols


e. The Federal Advisory Committee Act

f. The Federal Records Act

g. Federal Vacancies Reform Act

h. Federal employee travel statutes and regulations


1. Litigation of travel claims before the Civilian Board of Contract Appeals


i. Government property management and regulations.


**39.1.1.1.1** **(04-11-2022)**

#### Significant Case Coordination

1. The Associate Chief Counsel (GLS) must be kept informed of significant issues and cases handled by the Ethics & General Government Law Branch. Attorneys shall promptly bring significant cases to the attention of the Deputy Associate Chief Counsel (GLS) and/or the Chief, Ethics & General Government Law Branch.


**39.1.1.2** **(04-11-2022)**

### Professionalism

1. Subsections 39.1.1.2.1 - 39.1.1.2.3 below discuss matters relating to Professionalism.


**39.1.1.2.1** **(04-11-2022)**

#### Our Special Responsibility to the Internal Revenue Service and to the Public

1. Members of the Office of Chief Counsel play a special role in the administration of the internal revenue laws. The mission of the Internal Revenue Service is to apply the tax law with integrity and fairness. As the independent legal counsel to the Service, the responsibility of the Office of Chief Counsel is to ensure that the Service is able to fulfill this mission. The Office of Chief Counsel does this by providing the correct legal interpretation of the internal revenue laws, representing the Service in litigation, and providing all other legal support needed by the Service in its administration of the tax law.

2. The Office of Chief Counsel must carry out these responsibilities by interpreting the law with complete impartiality. The duty of service requires attorneys in the Office of Chief Counsel to think and act to ensure that the American public receives the fair and correct interpretation of our tax law. It is not to provide an answer that is most beneficial to the government, but to provide the answer that most accurately reflects the meaning of the tax code.

3. The Office of Chief Counsel is a professional services firm whose function is to serve the Service. In that regard, members of the Office Chief Counsel must dedicate themselves to providing the highest level of legal service to help the Service achieve its program goals. This demands excellence in our work as well as timely responses. Furthermore, the Office of Chief Counsel cannot adequately serve the Service if we fail to exercise courtesy in dealing with the client, the public and other members of the Office of Chief Counsel. Everyone is encouraged to maintain the high level of professionalism that is required by the legal profession, especially in avoiding any overreaching or unnecessary demands on taxpayers.


**39.1.1.2.2** **(04-11-2022)**

#### Ethics, Conduct, and Professionalism

1. The Office of Chief Counsel is committed to maintaining the highest standards of ethical and professional conduct. Moreover, our legal practice and conduct should always be characterized by adherence to the highest standards of professionalism, honesty, and fair play.

2. It is the responsibility of each employee to seek information and guidance from his or her management chain if there is doubt as to what is considered acceptable conduct in specific situations. Management will seek clarification from the Associate Chief Counsel (GLS) whenever necessary.


**39.1.1.2.2.1** **(04-11-2022)**

##### Standards Applicable to All Office of Chief Counsel Employees

1. The rules governing employee conduct and ethics are set forth in the provisions listed below. Employees must adhere to these provisions in letter and spirit.



1. Office of Government Ethics’ Standards of Ethical Conduct for Employees of the Executive Branch, 5 C.F.R. Part 2635

2. Supplemental Standards of Ethical Conduct for Employees of the Department of the Treasury, 5 C.F.R. Part 3101

3. Department of the Treasury Employee Rules of Conduct, 31 C.F.R. Part 0

4. Office of Personnel Management Regulations on Employee Responsibilities and Conduct, 5 C.F.R. Part 735


**39.1.1.2.2.2** **(04-11-2022)**

##### Standards Applicable to Office of Chief Counsel Attorneys

1. In addition to the provisions listed in CCDM 39.1.2.2.1, attorney personnel are bound by the letter and spirit of (i) the professional codes of the states where they are admitted to the bar, (ii) the Model Rules of Professional Conduct of the American Bar Association, and (iii) the Tax Court Rules of Practice and Procedure.

2. The Office of Chief Counsel may discipline an attorney for a violation of the codes listed in Paragraph (1) where the underlying conduct violates the provisions listed in CCDM 39.1.2.2.1 or otherwise brings discredit upon the Service or the Treasury Department.


**39.1.1.2.3** **(04-11-2022)**

#### Misconduct and Disciplinary Proceedings

1. Allegations or evidence of employee misconduct must be investigated and acted upon in a uniform and consistent manner.

2. The Office of Chief Counsel recognizes that uniform procedures must be established which will assure consistent treatment of allegations or evidence of employee misconduct, unprofessional behavior, or the failure to follow established procedures, and which will build public and internal confidence in the processes used to investigate and evaluate such allegations or evidence of misconduct. In addition, the organization recognizes the need for clarification of which matters should be referred to the Treasury Inspector General for Tax Administration (TIGTA) and which matters should be retained and handled as management matters. Finally, the Office of Chief Counsel recognizes that confusion as to whether an event should be dealt with in the evaluation/feedback or disciplinary process, or whether an allegation warrants referral to higher levels of management, could lead to inconsistent treatment of employees. To address these issues, the Office of Chief Counsel has established the following procedures, which cover matters to be referred to TIGTA, the Deputy Chief Counsel (Operations), or local management, and the investigative procedures which may follow such referrals.

3. The procedures described below apply to all allegations or evidence of misconduct by a Counsel employee received from any source, including:



   - An administrative or judicial body

   - A taxpayer or other member of the public

   - An employee of the Internal Revenue Service, Office of Chief Counsel, or other Treasury bureau

   - An official or employee of another federal agency


**39.1.1.2.3.1** **(04-11-2022)**

##### Matters for Referral to the Treasury Inspector General for Tax Administration

1. Allegations or evidence concerning the possible existence of criminal or other misconduct constituting a violation of law, rules, or regulations, or mismanagement, gross waste of funds, abuse of authority, a violation of a taxpayer's rights, or a substantial and specific danger to the public health and safety should be referred to the Deputy Chief Counsel (Operations) for referral to TIGTA. See Treasury Order No. 115–01 (May 24, 2018).

2. Complaints or allegations referred by the Deputy Chief Counsel (Operations) to TIGTA for investigation include allegations or evidence of potential criminal conduct occurring on the job or in connection with official duties, and all integrity issues, unless the conduct is otherwise covered by established procedures (e.g., EEO complaints, grievances, and employee tax compliance issues).

3. Examples of matters which should be referred to TIGTA include, but are not limited to, allegations of:



1. Misuse of office or official credentials

2. Unauthorized outside employment raising conflict of interest issues

3. Unauthorized access to taxpayer information


4. **Referral Procedures.** While all employees have the right to refer matters directly to TIGTA (see paragraph (5), below), the management of Counsel offices is improved when managers and executives are made aware of allegations of misconduct of subordinates. Accordingly, referrals should generally be made through the management chain. Management may be able to provide additional information to the referral that TIGTA will find useful in determining whether to investigate the complaint.



1. Managers should refer all potential TIGTA matters to the Deputy Chief Counsel (Operations) through the management chain. See 31 C.F.R. § 0.203. If an allegation involves an individual in the chain of referral, the referral should be made to the next higher official in the chain.


5. The foregoing referral procedure does not limit any person’s right to report an allegation of misconduct directly to TIGTA for investigation.

6. Questions as to whether a matter should be referred to the Deputy Chief Counsel (Operations) should be coordinated with the Claims, Labor and Personnel Law (CLP) Branch of the Office of the Associate Chief Counsel (GLS).


**39.1.1.2.3.2** **(04-11-2022)**

##### Matters for Referral to the Deputy Chief Counsel (Operations) for Consideration

1. Matters not described in CCDM 39.1.2.3.1, Matters for Referral to the Treasury Inspector General for Tax Administration, or reserved for local handling in CCDM 39.1.2.3.4, Matters Which May Be Handled under Local Procedures, will be referred through the appropriate management structure to the Deputy Chief Counsel (Operations).

2. Allegations or evidence of an employee’s serious or significant failure to comply with the accepted standards of legal practice within the Office of Chief Counsel, including the standards of practice set forth in the CCDM, will be referred through the appropriate management chain to the Deputy Chief Counsel (Operations).

3. Serious or significant matters include actions which potentially prejudice the client’s interests and which are more than an isolated, unintentional occurrence. There may be situations, however, when an isolated, unintentional matter must be referred due to the dollar impact, sensitivity or significance of the issue, or the importance of the legal standard to the efficiency or mission of the organization. It is in the client’s interest to protect the taxpayer’s right to fair and ethical treatment by Counsel employees, and to ensure that the taxpayer’s interests are not prejudiced as the result of unprofessional conduct.

4. Examples of serious or significant matters which should be referred include, but are not limited to, the following:



1. A nonfrivolous allegation or evidence of professional misconduct

2. The failure to properly coordinate a legal position, settlement, or policy matter with the appropriate party as required by the CCDM, i.e., a Notice case, a case involving a prior criminal matter, etc.

3. The failure to protect a statute of limitations

4. Any alleged ethical violation

5. Repeatedly failing to meet pleading dates


5. Managers should coordinate with the CLP Branch of GLS as to whether a matter requires referral to the Deputy Chief Counsel (Operations). In determining whether a serious or significant matter is involved, managers and CLP should consider, among other factors, the following:



1. Whether the failure to follow standard practices and procedures was willful

2. The number of similar or related instances

3. The effect of the employee’s actions on the functioning of the Office


6. Upon receipt by a manager of an allegation or evidence of a matter which is referable to the Deputy Chief Counsel (Operations) under the above provisions, the matter should be referred through the appropriate management chain to the Deputy Chief Counsel (Operations). If a matter involves an individual within that management structure, the referral should be made to the next higher official in the management chain.


**39.1.1.2.3.3** **(04-11-2022)**

##### Follow Up and Investigation

1. The Deputy Chief Counsel (Operations) will determine the appropriate action to be taken with respect to referrals to that office. While referral of a matter to higher levels of management serves the objective of informing management of matters of which it should be aware, the Deputy Chief Counsel (Operations) may determine that a referred matter should be handled locally. Such matters may be returned for further investigation and handling under local procedures. See CCDM 39.1.2.3.4, Matters Which May Be Handled Under Local Procedures.

2. The Deputy Chief Counsel (Operations) will determine whether a referred matter warrants a centrally coordinated investigation by the Office. The Deputy Chief Counsel (Operations) will, with the assistance of the appropriate Division Counsel or Associate Chief Counsel and the CLP Branch of GLS, determine the composition of the investigative team. In matters in which the action in question results in actual prejudice to the client’s interest, and in matters which have been returned by TIGTA for further investigation, the investigative team will generally include individuals outside the employee’s office, but may include, at the discretion of the Deputy Chief Counsel (Operations), individuals from within the office in which the alleged misconduct occurred.

3. Upon completion of an investigation requested by the Deputy Chief Counsel (Operations), the investigative report will be transmitted to the Division Counsel or Associate Chief Counsel, with a copy to the Deputy Chief Counsel (Operations). Management will consult with the CLP Branch of GLS regarding whether the matter should be dealt with through the evaluation/feedback process or through disciplinary procedures. If disciplinary procedures are appropriate, management should consult with the CLP Branch of GLS as well as Counsel Labor Relations as to an appropriate range of discipline. If referral to a state bar for violation of a state bar professional code of conduct is appropriate, the Associate Chief Counsel (GLS) will refer the matter to any state bar to which that Counsel attorney is admitted. If the violation was based on conduct before the Tax Court, the Associate Chief Counsel (GLS) will consult with the Associate Chief Counsel (Procedure and Administration). The referral of a violation to a state bar authority does not preclude an employee from additional discipline by the Office.

4. The Deputy Chief Counsel (Operations) is responsible for reporting to TIGTA on the disposition of matters investigated at the request of TIGTA.


**39.1.1.2.3.4** **(04-11-2022)**

##### Matters Which May be Handled Under Local Procedures

1. Matters which may be handled under local procedures include performance and discipline matters which:



1. Are covered under other formal procedures within the Office of Chief Counsel, the Treasury Department, or the Federal government

2. Do not require referral to TIGTA (see CCDM 39.1.2.3.1)

3. Do not require referral to the Deputy Chief Counsel (Operations) (see CCDM 39.1.2.3.2)

4. Have been returned to local management by the Deputy Chief Counsel (Operations) for handling under local procedures


2. Matters returned by the Deputy Chief Counsel (Operations) (including matters returned by TIGTA), and other matters which, after consultation with CLP, have been determined not to require referral to the Deputy Chief Counsel (Operations) will be handled as directed by the Division Counsel or Associate Chief Counsel with jurisdiction over the employee involved.

3. Examples of matters which may be handled under local procedures, absent special circumstances, include, but are not limited to:



   - Employee tax compliance issues

   - Personnel practices subject to grievance procedures

   - EEO matters

   - Office altercations

   - Failure to follow standard office procedures


**39.1.1.2.3.5** **(04-11-2022)**

##### Annual Report

1. The Office of Chief Counsel, Finance & Management (F&M), will prepare an annual report that will inform employees and the public about the Office’s actions regarding allegations and evidence of misconduct. The manner of presentation will ensure that the privacy rights of employees are protected.


**39.1.1.3** **(04-11-2022)**

### Government Ethics Programs

1. Subsections 39.1.1.3.1 - 39.1.1.3.4 below discuss matters relating to Government Ethics Programs.


**39.1.1.3.1** **(04-11-2022)**

#### Government Ethics Matters in General

1. The Associate Chief Counsel (GLS) acts as the Deputy Ethics Official (DEO) for the agency under the Ethics in Government Act and provides advice on matters as to the propriety of acts involving IRS and IRS Office of Chief Counsel employees and former employees, and acts involving practitioners under 18 U.S.C. Part I, Chapter 11; the Ethics in Government Act; Government-wide, Treasury, Service, and Counsel standards and rules of conduct or behavior; and Treasury Circular 230.

2. Summaries of the ethics rules, applicable approval procedures, and information about seeking ethics advice may be found on EthicsLink at: https://ccintranet.prod.irscounsel.treas.gov/Common/EthicsLink/Pages/default.aspx

3. Government ethics matters are handled by the Ethics and General Government Law Branch (EGG) of GLS.

4. A GLS Area Counsel office receiving a request for a legal opinion on a government ethics issue should forward the request immediately upon receipt, but in any case no more than 3 business days of receipt, to the EGG Branch Chief for response.

5. Questions relating to conflicts of interest or other ethical considerations of a former employee or an individual representing another before the Service will be referred to EGG.

6. Questions regarding whether an employee’s own actions, or the actions of another Counsel employee, comply with the applicable ethics rules should be referred through the employee’s management chain to the Associate or Division Counsel. The Associate or Division Counsel (or their designee) may seek GLS advice on the appropriate course of action.

7. Questions regarding whether the actions of the Chief Counsel, the Commissioner, or their Deputies comply with applicable ethics rules should be referred through the Associate or Division Counsel with responsibility over the matter to the Associate Chief Counsel (General Legal Services).

8. Standards of professionalism and courtesy require that any question concerning a potential ethical issue involving another employee be raised in a confidential manner through supervisory channels and not be made the subject of speculation or rumor.


**39.1.1.3.2** **(04-11-2022)**

#### Definitions and Delegations of Authority

1. As used in 5 CFR part 2635 and except as noted in CCDM 39.1.3.2.2, the term _agency designee_ means the employee’s immediate supervisor or another official in the employee’s management chain.

2. As used in 5 CFR 2635.204(m), the Associate Chief Counsel (General Legal Services) is the agency designee for purposes of accepting gifts of instructional materials in excess of $100 from a single source in a calendar year.

3. The following officials are authorized to grant individual waivers pursuant to 18 USC 208(b)(1):



1. The Associate Chief Counsel (GLS) for all counsel employees, except Senior Executive Service (SES) and Senior Level (SL) employees. This authority has been delegated to the Deputies Associate Chief Counsel (GLS) and may not be redelegated.

2. The Deputy Chief Counsel (Operations) for SES and SL counsel employees except the Chief Counsel and Deputy Chief Counsel (Technical).

3. The Chief Counsel for the Deputies Chief Counsel.


4. The authority granted to the Associate Chief Counsel (GLS) by Treasury Directive 61-01, _Implementation of the Public Financial Disclosure and Periodic Transaction Report Requirements of the Ethics in Government Act of 1978, as amended,_ and Treasury Directive 61-02, _Implementation of the Confidential Financial Disclosure Report Filing Requirements_, is delegated to the Senior Level Counsel (GLS). This delegation includes the authority to certify public financial disclosure reports, to grant filing extensions, and to waive late filing fees.


**39.1.1.3.3** **(04-11-2022)**

#### Follow Up and Investigation

1. Questions relating to conflicts of interest or other ethical considerations of an individual representing another before a court, including the Tax Court, related to tax matters, should be referred by Division Counsel to the Office of the Associate Chief Counsel (P&A). The Office of the Associate Chief Counsel (P&A) will coordinate with the Office of Associate Chief Counsel (GLS), as appropriate.


**39.1.1.3.4** **(04-11-2022)**

#### Confidential Financial Disclosure

1. The Office of Government Ethics (OGE) Form 450, Confidential Financial Disclosure Report, is required to be filed by certain officers and employees of the executive branch by regulations issued by the Office of Government Ethics found at Title 5 Code of Federal Regulations (CFR), Part 2634. The confidential financial disclosure assists the Office in avoiding financial conflicts of interest.

2. Confidential filers ("covered" positions) in Counsel include:



1. All GS-15 positions

2. All positions, regardless of grade, which have been delegated signature authority for tax and revenue rulings, accounting periods and methods, or for contracting warrants

3. Employees who participate personally and substantially in contracting/procurement; administering/monitoring federal grants, etc.; regulating or auditing non-federal entities; or other activities having a direct and substantial economic effect on the interests of a non-federal entity; or whose official duties require such disclosure in order to avoid a conflict of interest

4. All non-SES positions which have supervisory authority over a covered position

5. Any Special Government Employees


3. **New entrants.** An employee must file an _OGE Form 450_ with his/her immediate supervisor within 30 days of assuming a confidential filer position, absent an extension. A new entrant report covers the 12 months previous to the signature date on the report.

4. **Annual reports.** Incumbents in covered positions must file an annual OGE Form 450 with their immediate supervisor no later than February 15, absent an extension. Annual reports cover the previous calendar year.

5. **Extensions.** A filer who is unable to meet the filing deadline should submit a written request for an extension to GLS.Ethics@irscounsel.treas.gov as soon as possible before the filing deadline. A request must contain an explanation of why such an extension is requested. The Senior Level Counsel (GLS) or designee may, for good cause, grant one or more extensions totaling not more than 90 days. The Senior Level Counsel (GLS) or designee approves or denies extension requests in writing.

6. **Notification.**The Executive Resources Board is required to inform new entrants and annual OGE Form 450 filers of the requirement to file their reports in a timely manner.


**39.1.1.3.4.1** **(04-11-2022)**

##### Review

1. **Review.** Every OGE Form 450 will be reviewed to ensure it is properly completed, ensure the date of receipt is noted, compare disclosures to filer’s duties in order to help the filer avoid conflicts of interest, and take any remedial action necessary.

2. **Initial Review.**Initial review is conducted by the employee's first-line supervisor. If the first-line supervisor is an SES, he or she should sign as the Final Reviewing Official and forward the report to the OGE Form 450 Point of Contact as described below. If the first-line supervisor is not an SES, he or she should sign the report at the “Supervisor/Other Intermediate Reviewer” signature line and then proceed to Final Review.

3. **Final Review** (as needed). When a non-SES first-line supervisor has completed the review and signed the report as the Supervisor/Other Intermediate Reviewer, the report should be forwarded to the second-line supervisor, who will serve as the Final Reviewing Official.

4. **Forwarding to Point of Contact.** Following the review, the Final Reviewing Official will sign the report and provide it to the OGE Form 450 Point of Contact, who then forwards it to the Executive Resources Board, where it will be retained for six years. Both the Final Reviewing Official and the Intermediate Reviewer (if any) may retain a copy of the report for their own reference in assigning duties. However, the retained copies must be protected from improper disclosure. See 5 C.F.R. 2634.604.

5. **Remedies.**If information from the report submitted, or from other sources, indicates an actual or potential conflict of interest on the part of a filer, the employee concerned shall be given an opportunity to explain the conflict or apparent conflict. Any questions or requests for advice in resolving a conflict or apparent conflict shall be referred to EGG Branch Chief.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part39/irm_39-001-001#addtoany "Show all")

A2A