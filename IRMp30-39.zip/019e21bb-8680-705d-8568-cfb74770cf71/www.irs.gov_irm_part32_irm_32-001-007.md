---
url: "https://www.irs.gov/irm/part32/irm_32-001-007"
title: "32.1.7 Inquiries, Comments, and Public Hearings | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part32/irm_32-001-007#main-content)

- 32.1.7  [Inquiries, Comments, and Public Hearings](https://www.irs.gov/irm/part32/irm_32-001-007#idm140208784343904)
  - 32.1.7.1  [Inquiries from the Press or Public Concerning Recently Issued Published Regulations](https://www.irs.gov/irm/part32/irm_32-001-007#idm140208784299968)
  - 32.1.7.2  [Comments](https://www.irs.gov/irm/part32/irm_32-001-007#idm140208784284672)
    - 32.1.7.2.1  [Processing Incoming Comments](https://www.irs.gov/irm/part32/irm_32-001-007#idm140208784326336)
    - 32.1.7.2.2  [Extending the Comment Period](https://www.irs.gov/irm/part32/irm_32-001-007#idm140208784323152)
  - 32.1.7.3  [Public Hearings](https://www.irs.gov/irm/part32/irm_32-001-007#idm140208784319872)
    - 32.1.7.3.1  [Teleconferenced Public Hearings](https://www.irs.gov/irm/part32/irm_32-001-007#idm140208784309824)
    - 32.1.7.3.2  [Rescheduling a Public Hearing](https://www.irs.gov/irm/part32/irm_32-001-007#idm140208784306960)

# Part 32. Published Guidance and Other Guidance to Taxpayers

# Chapter 1. Chief Counsel Regulation Handbook

# Section 7. Inquiries, Comments, and Public Hearings

* * *

## 32.1.7 Inquiries, Comments, and Public Hearings

#### Manual Transmittal

November 12, 2019

#### Purpose

(1) This transmits revised CCDM 32.1.7, Regulation Handbook, Inquiries, Comments and Public Hearings.

#### Material Changes

(1) CCDM 32.1.7 is revised to update the processing of public comments.

#### Effect on Other Documents

This section supersedes CCDM 32.1.7, dated August 1, 2018.

#### Audience

Chief Counsel

#### Effective Date

(11-12-2019)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**32.1.7.1** **(08-01-2018)**

### Inquiries from the Press or Public Concerning Recently Issued Published Regulations

1. If a reporter from a general news outlet (newspaper, wire service, radio, television, etc.) or a specialized media outlet (tax service, financial or industry newsletter) contacts an attorney or office concerning a regulation, the attorney or office must immediately refer the reporter to Media Relations at (202) 317-4000. The attorney or office must not answer any questions or commit the IRS to answering any questions at this point. Rather, the attorney or office should call Media Relations and explain the subject of the call (to the extent known) and who in Counsel will be available to respond to the reporter’s questions (after consulting the Branch Chief or Associate Chief Counsel front office, as appropriate).

2. Media Relations discusses and resolves the following points with the reporter to determine whether and under what conditions the attorney or other Counsel/IRS representative will speak for the agency:



   - The nature of the questions

   - Attribution ground rules for the interview

   - Any deadlines under which the reporter is working


3. After Media Relations resolves these issues and agrees to an interview, a representative from that office will schedule an interview with the designated attorney. A representative from Media Relations will be on the phone during the interview.

4. Attorneys in the Associate Chief Counsel office usually answer inquiries from the public concerning recently published regulations. Where an answer is unclear, however, an attorney may not respond to the question before consulting with his or her branch reviewer; Associate Chief Counsel or Deputy; or, if appropriate, the Office of Tax Legislative Counsel (or Benefits Tax Counsel or International Tax Counsel, as appropriate). Ordinarily, the attorney whose name is published in the Federal Register as the contact person for information or the reviewer on the project responds to inquiries concerning that regulation project. An attorney should consult his or her Branch Chief or Associate Chief Counsel front office for any special instructions (such as coordinating inquiries with the Chief Counsel’s staff).


**32.1.7.2** **(11-12-2019)**

### Comments

1. The Publications and Regulations Branch receives written and electronic comments with respect to ANPRMs and NPRMs (and any other regulation project under development) through the government-wide regulations web site, [www.regulations.gov](https://www.regulations.gov/), and the U.S. mail. The Publications and Regulations Branch processes all incoming comments on regulation projects. ( See CCDM 32.1.7.2.1). All written and electronic comments received become part of the public record, are routinely released to several commercial tax services, and are available for public inspection and copying.

2. IRS procedures relating to public comments are set forth in 26 CFR 601.601(b).

3. If the drafting attorney receives comments (including email) that did not come through the Publications and Regulations Branch, the drafting attorney immediately forwards the comments to the Publications and Regulations Branch for processing and distribution. If the drafting attorney receives informal comments by telephone, the drafting attorney should keep a record of the comments and consider the comments when drafting the final regulation.

4. If the drafting attorney compiles a summary of comments to be used at the public hearing on the NPRM (if a public hearing is held), the summary of comments is due to the Publications and Regulations Branch at least two weeks before the hearing.


**32.1.7.2.1** **(11-12-2019)**

#### Processing Incoming Comments

1. The Publications and Regulations Branch stamps the date received on each written comment and screens the comments to ensure that they may be released to the public in their entirety. If any comment may not be released in its entirety, the Publications and Regulations Branch returns it, along with an explanation, to the person who submitted it.

2. The Publications and Regulations Branch sends the original of each comment to the drafting attorney, who should place the comment in the legal file for the regulation project. If the drafting attorney receives comments (including email) that did not come through the Publications and Regulations Branch, the drafting attorney must immediately forward the comments to the Publications and Regulations Branch for processing and distribution.

3. The Publications and Regulations Branch also sends copies to the reviewer of the regulation project. The Publications and Regulations Branch also retains a copy in its comment file.


**32.1.7.2.2** **(08-11-2004)**

#### Extending the Comment Period

1. If the Associate Chief Counsel office decides to extend the time provided for public comments on an ANPRM or NPRM project, the drafting attorney must immediately coordinate the extended due date with the Publications and Regulations Branch specialist assigned to the public hearing. The Publications and Regulations Branch specialist drafts the notice announcing the extension of time for public comments and, after review by the drafting attorney, sends the extension announcement to the OFR for publication in the Federal Register.

2. Extending the comment period will not necessarily cause the hearing to be rescheduled. _See_ CCDM 32.1.7.3.2 for discussion of rescheduling a hearing.


**32.1.7.3** **(08-19-2011)**

### Public Hearings

1. IRS procedures relating to public hearings are set forth in 26 CFR 601.601(a)(2) and (3). In general, the NPRM announces the hearing date, time, and place. However, if it is unlikely that a particular regulation will generate interest in a hearing, the NPRM invites those interested to request a hearing and does not provide for a scheduled hearing. If any person requests a public hearing, the drafting attorney should contact the Publications and Regulations Branch to schedule the public hearing and to announce the date, time and place of the hearing. The Publications and Regulations Branch prepares a notice of public hearing and, after the drafting attorney reviews it, sends it to the OFR for publication in the Federal Register.

2. The IRS will conduct a hearing so long as at least one person requests to speak.

3. The Associate office identifies the members of the hearing panel. Typically, the panel includes (but is not strictly limited to):



   - Drafting attorney

   - Branch reviewer

   - An executive from the Associate office

   - Treasury staff attorney


4. The Publications and Regulations Branch specialist assigned to the NPRM ( see CCDM 32.1.6.9.1, Schedule Hearing Room for NPRM) assembles a hearing briefing book for each member of the hearing panel. The hearing book contains:



   - The hearing agenda

   - The written comments and outlines of oral comments submitted by the speakers

   - The summary of the written comments ( _see_ CCDM 32.1.7.2)


5. The contents of the hearing book become part of the legal file.

6. Each speaker is allowed ten minutes to present oral comments. Members of the panel may ask questions of the speakers. The time consumed by questions does not infringe on the speaker’s allotted ten minutes.

7. Due to building security rules, Counsel employees must escort all visitors attending the hearing from the Constitution Avenue entrance security desk to the hearing room and from the hearing room back to the security desk at the end of the hearing. The Associate office conducting the hearing provides staff to escort attendees to and from the hearing.


**32.1.7.3.1** **(08-01-2018)**

#### Teleconferenced Public Hearings

1. A public hearing may be teleconferenced. Teleconferenced public hearings are hearings that are conducted at the National Office or New Carrollton IRS site simultaneously with other IRS remote videoconference sites. Taxpayers can attend and testify from selected IRS locations throughout the country.

2. Because teleconferenced public hearings are complicated and expensive, any proposal for a teleconferenced public hearing must be approved by the appropriate Associate Chief Counsel prior to the issuance of an NPRM or notice of public hearing soliciting public interest for a teleconference public hearing. If the drafting attorney and reviewer determine a teleconference public hearing may be appropriate for an NPRM, they should consult with the Associate Chief Counsel and the Publications and Regulations Branch early in the drafting process.


**32.1.7.3.2** **(08-11-2004)**

#### Rescheduling a Public Hearing

1. If the Associate Chief Counsel office decides to reschedule a public hearing previously announced in the Federal Register, the drafting attorney must immediately coordinate the rescheduling of the public hearing with the Publications and Regulations Branch specialist assigned to the public hearing. The Publications and Regulations Branch specialist will cancel the hearing room for the originally scheduled public hearing, reserve a room for the new public hearing date, and draft a notice canceling and rescheduling the public hearing. After the drafting attorney reviews the notice, the specialist sends it to the OFR for publication in the Federal Register.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part32/irm_32-001-007#addtoany "Show all")

A2A