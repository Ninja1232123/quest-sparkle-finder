---
url: "https://www.irs.gov/irm/part35/irm_35-004-001"
title: "35.4.1 Trial Planning | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-004-001#main-content)

- 35.4.1  [Trial Planning](https://www.irs.gov/irm/part35/irm_35-004-001#idm140573999057920)
  - 35.4.1.1  [Introduction](https://www.irs.gov/irm/part35/irm_35-004-001#idm140573999060352)
  - 35.4.1.2  [Raising New Issues in Tax Court Cases](https://www.irs.gov/irm/part35/irm_35-004-001#idm140574025894624)
  - 35.4.1.3  [Coordination with Other Tax Court Cases](https://www.irs.gov/irm/part35/irm_35-004-001#idm140574025847936)
  - 35.4.1.4  [Coordination with Other Counsel Offices](https://www.irs.gov/irm/part35/irm_35-004-001#idm140574025845456)
  - 35.4.1.5  [Coordination with Criminal, Refund, and Collection Cases](https://www.irs.gov/irm/part35/irm_35-004-001#idm140574025841120)
    - 35.4.1.5.1  [Coordination with Criminal Tax Cases](https://www.irs.gov/irm/part35/irm_35-004-001#idm140574025840256)
    - 35.4.1.5.2  [Coordination with Refund Cases](https://www.irs.gov/irm/part35/irm_35-004-001#idm140573998524864)
    - 35.4.1.5.3  [Coordination of Tax Court Cases and Collection or Insolvency Cases](https://www.irs.gov/irm/part35/irm_35-004-001#idm140573998521424)
      - 35.4.1.5.3.1  [Non-bankruptcy Insolvency Proceedings](https://www.irs.gov/irm/part35/irm_35-004-001#idm140573998519344)
  - 35.4.1.6  [Burden of Proof](https://www.irs.gov/irm/part35/irm_35-004-001#idm140573998510816)
    - 35.4.1.6.1  [Revised Burden of Proof Rules Under Section 7491(a)](https://www.irs.gov/irm/part35/irm_35-004-001#idm140573998507376)
    - 35.4.1.6.2  [Evaluation of Petitioner’s Burden of Proof Cases](https://www.irs.gov/irm/part35/irm_35-004-001#idm140573998502384)
    - 35.4.1.6.3  [Section 6751(b) Penalty Approval Requirement](https://www.irs.gov/irm/part35/irm_35-004-001#idm140573998308416)
  - 35.4.1.7  [Developing a Trial Preparation Plan](https://www.irs.gov/irm/part35/irm_35-004-001#idm140573998306048)
    - 35.4.1.7.1  [Coordination with Appeals](https://www.irs.gov/irm/part35/irm_35-004-001#idm140573998303088)
    - 35.4.1.7.2  [Trial Calendars](https://www.irs.gov/irm/part35/irm_35-004-001#idm140573998298784)
    - 35.4.1.7.3  [Trial Teams](https://www.irs.gov/irm/part35/irm_35-004-001#idm140573998295312)
  - 35.4.1.8  [Ethical Considerations](https://www.irs.gov/irm/part35/irm_35-004-001#idm140573998291920)
    - 35.4.1.8.1  [Petitioner’s Counsel’s Conflicts of Interest](https://www.irs.gov/irm/part35/irm_35-004-001#idm140573998288384)
      - 35.4.1.8.1.1  [Conflict of Interest Based on Planning, Promoting, or Operating a Shelter, or Dual Representation](https://www.irs.gov/irm/part35/irm_35-004-001#idm140573998282144)
      - 35.4.1.8.1.2  [Claims for Relief from Joint and Several Liability under Section 6015 or Duress Cases](https://www.irs.gov/irm/part35/irm_35-004-001#idm140574025890208)
      - 35.4.1.8.1.3  [Financial or Other Personal Interest](https://www.irs.gov/irm/part35/irm_35-004-001#idm140574025885376)
      - 35.4.1.8.1.4  [Petitioner’s Attorney as a Witness](https://www.irs.gov/irm/part35/irm_35-004-001#idm140574025881936)
    - 35.4.1.8.2  [General Procedures for Handling Conflicts of Interest](https://www.irs.gov/irm/part35/irm_35-004-001#idm140574025874480)
      - 35.4.1.8.2.1  [Conflict Letters](https://www.irs.gov/irm/part35/irm_35-004-001#idm140574025867024)
      - 35.4.1.8.2.2  [The Background Memorandum](https://www.irs.gov/irm/part35/irm_35-004-001#idm140574025862016)
      - 35.4.1.8.2.3  [Additional Procedures for Conflict of Interest Cases](https://www.irs.gov/irm/part35/irm_35-004-001#idm140574026146192)
  - 35.4.1.9  [The Trial Brief/Trial Folder](https://www.irs.gov/irm/part35/irm_35-004-001#idm140574026141104)
    - 35.4.1.9.1  [Structure of the Trial Brief/Trial Folder](https://www.irs.gov/irm/part35/irm_35-004-001#idm140574026135312)
  - 35.4.1.10  [Depositions Before Commencement of Case—T.C. Rule 82](https://www.irs.gov/irm/part35/irm_35-004-001#idm140574026112800)
  - 35.4.1.11  [Potential Security Threats](https://www.irs.gov/irm/part35/irm_35-004-001#idm140573998268032)
  - 35.4.1.12  [Interest Abatement Cases](https://www.irs.gov/irm/part35/irm_35-004-001#idm140573998260928)

# Part 35. Chief Counsel Directives Manual Tax Court Litigation

# Chapter 4. Pre-Trial Activities

# Section 1. Trial Planning

* * *

## 35.4.1 Trial Planning

#### Manual Transmittal

June 09, 2023

#### Purpose

(1) This transmits revised CCDM 35.4.1, Pre-Trial Activities; Trial Planning.

#### Material Changes

(1) CCDM 35.4.1 is revised to describe the types of coordination necessary in abusive tax transaction situations.

#### Effect on Other Documents

CCDM 35.4.1, dated June 15, 2022, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(06-09-2023)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**35.4.1.1** **(08-11-2004)**

### Introduction

1. The basic goal in preparing to try and trying a case in the Tax Court is to apply the law to the facts. Very simply, this involves:



   - Contemplating methods of dealing with disputed facts and potential evidentiary problems

   - Integrating the undisputed facts with respondent’s version of the disputed facts

   - Creating and presenting a theory that is more plausible and persuasive than petitioner’s


**35.4.1.2** **(08-11-2004)**

### Raising New Issues in Tax Court Cases

1. Ideally, the notice of deficiency or liability or other determination underlying the Tax Court case should contain and explain the proper basis or bases upon which the adjustment or other disputed item is to be litigated. This is not always the case, however. In any event, the answer or amended answer is to be filed, and the case is to be tried, under legal theories and positions that are in accord with the current Service position, regardless of the basis upon which the notice was issued. Any "new issue" should be raised as soon as possible so that full consideration may be given to it in both settlement negotiations and trial preparation.

2. A "new issue" is an issue raised in the answer or amended answer which was not one of the adjustments or positions shown in the notice. "New issue" includes all issues which result in increased deficiencies as well as alternative issues or positions conflicting with the adjustments or positions set forth in the notice. The term does not include affirmative pleadings required for issues upon which the burden of proof is placed by statute upon the Service (such as fraud or transferee liability), if shown in the notice; matters alleged for affirmative defense (such as exceptions to the statute of limitations, _res judicata_, and estoppel); or most matters of further defense such as additional grounds in support of the statutory adjustments, or further defense to positions, theories, or qualifications of fact alleged by the petitioner.

3. In general, respondent’s counsel will not raise new issues, unless the grounds are substantial and the potential effect on tax liability is material. "Substantial" is defined as strong, possessing real merit. "Material" is defined as having real importance and great consequence. Grounds for raising a new issue or a new position (alternative issue or position) in support of an original adjustment to the taxpayer’s return usually are considered substantial, if the new issue or new position represents the correct legal theory and position of the Service on the transactions included in the notice. Affirmative issues involving items not included in the notice may be raised in the docketed status of the case, but only if the grounds are substantial, the effect on tax liability is material, and there is a sufficient basis in available facts to sustain the Commissioner’s position on the item.

4. At all times during the pendency of the Tax Court case, the Field attorney has the responsibility to find and bring to the reviewer’s attention any new issue necessary for a proper determination of the case in accord with the current Service position, whether or not the issue or position or theory was previously considered by the Division Counsel or Appeals. The Field attorney and reviewer should seek legal advice from APJP, Branch 3 if assistance is needed with any problems encountered in the pleadings or trial of a docketed case, relative to the raising of affirmative issues.

5. In some instances, even in docketed cases, it may be necessary to return the case to the originating operating division for further factual development before a decision can be made as to the proper issues to be raised, the proper theories to be advanced, or the proper basis for litigating the adjustment or other item under current Service position. Particular care must be exercised in this area if the case is docketed. Petitioners or their representatives may not be contacted by the examining agent or officer in connection with this further factual development, and no administrative summons should be issued. The examining agent or officer must work under the direction of the Field attorney and the reviewer.

6. Normally, new issues should not be raised after the case has been set for trial. The court may be inclined to deny leave to raise it, because petitioner is not likely to have enough time to prepare a defense. If the case is continued, this limitation will no longer apply. An affirmative issue raised by an amended answer filed during the calendared period may well (but does not automatically) result in a continuance of the case, since the petitioner has 45 days in which to reply to the amended answer, and the case may not be at issue at calendar call. In any event, the court usually will not force a trial when the petitioner has not had sufficient time to prepare a defense to the respondent’s affirmative issues.


**35.4.1.3** **(08-11-2004)**

### Coordination with Other Tax Court Cases

1. Actions taken in one Tax Court case potentially can have direct or indirect impacts on other cases pending in the Tax Court, whether or not the cases involve the same taxpayer.

2. TLCATS and CASE-MIS give the Field attorney and reviewer the capability of locating cases involving the same taxpayer and related parties. TLCATS and CASE-MIS should be consulted for such information, and the Field attorney should coordinate with the attorneys assigned to other relevant cases.


**35.4.1.4** **(02-07-2013)**

### Coordination with Other Counsel Offices

1. Other attorneys in the Field attorney’s division, and other attorneys throughout the Office of Chief Counsel, can be important sources of information and technical expertise that may be useful to the Field attorney in preparing a case for trial or other appropriate disposition. The Field attorney may also be an important source of information to other Chief Counsel attorneys, both in Field and Associate offices, who are assigned to handle similar issues in a variety of contexts. Counsel attorneys should both seek assistance from, and give assistance to, other Chief Counsel offices.

2. The Office of Chief Counsel should speak with one voice. Anything signed or approved by or in the name of the Chief Counsel must represent the position of the entire office and not merely the position of a particular division or part of the office. Disagreements are to be reconciled through established management channels. Field attorneys and Associate office attorneys must coordinate proposed action in one function that may affect litigation or technical positions to be taken by another function. See coordination principles at CCDM 31.1.4, Coordination and Reconciliation of Disputes.


**35.4.1.5** **(08-11-2004)**

### Coordination with Criminal, Refund, and Collection Cases

1. This section discusses coordination with criminal, refund and collection cases.


**35.4.1.5.1** **(06-09-2023)**

#### Coordination with Criminal Tax Cases

1. The policy of the Service is to appropriately balance criminal and civil aspects of a case. See Policy Statement P-4-26, Criminal and Civil Aspects in Enforcement. If there is an open criminal tax investigation related to the pending Tax Court case, the criminal case should be protected to the extent possible while at the same time complying with the rules, orders, and directives of the Tax Court. Any prospective action toward settlement or trial preparation must be closely coordinated with the Division Counsel/Associate Chief Counsel (CT) and Criminal Investigation in order to ensure that the potential impact upon the criminal case is thoroughly considered.

2. When a criminal matter (investigation or prosecution) involves a promoter or facilitator of an abusive tax transaction, and the transaction’s participants are involved in civil matters (examinations, investigations, or litigation), then coordination between Counsel, Service, and Department of Justice stakeholders is necessary. See IRM 1.2.1.5.11. Also refer to IRM 4.32.2.7, 5.1.5.2, and 9.5.1.5 for information regarding parallel investigations and parallel proceedings. Coordination tasks for these related criminal and civil matters may include:



1. Identifying Counsel, Service, and Department of Justice stakeholders and inventory; and

2. Designating a lead to coordinate matters such as information sharing, working with Appeals, and implementing freeze codes, among others.


3. If there is an open criminal tax case related to the pending Tax Court case, the Area Counsel (CT) office currently charged with the related criminal matter must be informed of any significant developments in the Tax Court. Copies of the pleadings, significant motions, requests for discovery or admissions, and responses to requests for discovery or admissions will be furnished to Area Counsel (CT). The Field attorney should also periodically request that any additional information developed or received by Area Counsel (CT) (other than information which may not be disclosed for civil purposes, _i.e._, certain grand jury or wiretap evidence) be furnished. Area Counsel (CT) should coordinate with Department of Justice (DOJ) if the criminal case is pending in DOJ. In this way the offices charged with the civil liability and the criminal matter will each be kept informed of all developments which might affect their cases, and the positions taken in both cases will be consistent.

4. At the time of answer, it should be determined whether the Tax Court case should be processed only after the criminal trial. If so, a motion for stay of proceedings should be filed prior to the filing of the answer, if possible. See CCDM 35.4.6.4.1(2), General Procedures for Protecting the Criminal Case.

5. If a motion to stay is denied by the court over respondent’s contention that the criminal case should first be resolved, consideration should be given to initiating the discovery and admissions procedure for the purpose of fully developing the nature of the taxpayer’s defense to the fraud allegations. DOJ should be advised of this action. Because the taxpayer will have been successful in opposing a motion to stay because of the criminal proceedings, the request for discovery or admissions may place the taxpayer in a position of self-incrimination or claiming the Fifth Amendment. If the claim of Fifth Amendment privilege is asserted and sustained by the court, it will provide a basis for a renewed motion to stay because of the pendency of the criminal proceeding. Otherwise, consideration should be given to a motion for sanctions, including dismissal if appropriate, on the issue with respect to which the taxpayer is declining to respond.

6. If, in the course of preparation for trial of the civil case, it is established that facts relied upon in the referral of the criminal case to DOJ are incorrect and/or inconsistent with the facts developed in the Tax Court case, the Field attorney should inform the responsible Criminal Investigation office, which will, in turn, inform DOJ.

7. Additional directives on coordinating Tax Court and Criminal Tax cases are set out at CCDM 35.4.6.4, Cases Having Related Criminal Aspects.


**35.4.1.5.2** **(02-07-2013)**

#### Coordination with Refund Cases

1. The handling and processing of related Tax Court cases and tax refund suits to their ultimate disposition must be closely coordinated so as to establish a consistent litigation position in all the courts.

2. Under some circumstances, when the Tax Court case is to be tried prior to the related tax refund suit, it may be advisable for the Field Counsel to submit to the DOJ a statement of the facts proposed to be stipulated, or a statement of the facts proposed to be introduced into evidence in the trial of the Tax Court case. Likewise, in cases in which the tax refund suit is to be tried prior to the Tax Court case, in appropriate instances, it may be advisable for the Field Counsel to forward to the DOJ attorney a letter setting forth factors involved in the related Tax Court case which should be borne in mind by the DOJ attorney in the trial of the refund suit.

3. For directives regarding settlement of related Tax Court and tax refund cases, see CCDM 35.5.3.3, Coordination of Tax Court and Refund Cases.


**35.4.1.5.3** **(02-07-2013)**

#### Coordination of Tax Court Cases and Collection or Insolvency Cases

1. Attorneys handling related Tax Court and collection litigation cases should carefully consider the effect any proposed action in one case will have in the related case. If different attorneys, in any operating division or office, are handling related Tax Court and collection litigation cases, they should coordinate with each other. For directives regarding settlement of Tax Court cases and related collection litigation cases, see CCDM 35.5.3.5, Coordination of Tax Court Cases and Collection Matters.


**35.4.1.5.3.1** **(02-07-2013)**

##### Non-bankruptcy Insolvency Proceedings

1. Non-bankruptcy insolvency proceedings include federal receiverships, state receiverships, state probate proceedings, etc. In non-receivership proceedings, claims for deficiencies in income, estate and gift taxes may be filed. The effect of the allowance of such claims or whether the court has jurisdiction to consider the merits of the claim will vary, depending upon the type of case and the forum. Depending on the timing of the petition in the Tax Court, the court in the insolvency proceeding may have concurrent jurisdiction to consider the merits of the tax. Section 6871(a) generally provides that on the appointment of a receiver for the taxpayer in any federal or state receivership, any deficiency in income, estate, or gift taxes, or in taxes under chapters 41 through 44, may be immediately assessed. Also, section 6871(c) generally provides that a claim for such deficiency may be made to the receivership court despite the pendency of a related Tax Court proceeding, but that no petition may be filed with the Tax Court after the appointment of the receiver. In insolvency proceedings, questions may be raised as to the government’s claim for taxes, either upon the merits of the tax liability or for technical reasons pertaining to the claim itself, such as the timeliness of the proof of claim, the inclusion therein of penalties, priority of the government’s lien, etc.

2. When a Tax Court case and a non-bankruptcy insolvency case are pending at the same time, appropriate action should be taken, when feasible, to expedite the disposition of the Tax Court case prior to the conclusion of an insolvency proceeding in which both courts have concurrent jurisdiction. This may involve obtaining the approval of the fiduciary to having the Tax Court determine the tax liability prior to final action in the insolvency case on the government’s claim. Disposing of the Tax Court case prior to the closing of the insolvency case will avoid many problems which may be encountered after the closing of the insolvency case.

3. In many instances a question may arise as to who has authority to negotiate settlement or to prosecute the Tax Court case on behalf of the taxpayer. The particular law involved should be researched before making a decision on this point.

4. In instances in which it is not practicable or feasible to settle the Tax Court case prior to the disposition of the related insolvency case, and the taxpayer fails to prosecute or proceed as required by the court’s rules or orders, the Tax Court case may be disposed of by moving for dismissal and/or default judgment upon failure to appear when the case is set for trial or other appropriate failure supporting a motion to dismiss.

5. For directives regarding settlement of Tax Court cases and related non-bankruptcy insolvency cases, see CCDM 35.5.3.5.1, Insolvency Cases.


**35.4.1.6** **(08-11-2004)**

### Burden of Proof

1. A presumption of correctness attaches to respondent’s determinations that are at issue in Tax Court, placing the burden of production (or of going forward) on petitioners, unless otherwise provided by statute or rule. This presumption is a procedural device which requires petitioner to come forward with enough evidence to support a finding contrary to the determination. Pursuant to T.C. Rule 142(a), the petitioner also bears the burden of proof. This burden is a burden of persuasion that requires petitioner to demonstrate the merits of petitioner’s claim by at least a preponderance of the evidence.

2. The Traditional Rule. To rebut respondent’s presumption, petitioner must introduce some substantial evidence tending to show that respondent was wrong. If petitioner satisfies this burden, then the burden of going forward with the evidence will shift to the respondent. Where petitioner has carried the burden of going forward, petitioner must still carry the ultimate burden of proof or persuasion. If petitioner has sustained the burden of going forward, petitioner is entitled to judgment if respondent produces no evidence in support of respondent’s burden of going forward.


**35.4.1.6.1** **(08-11-2004)**

#### Revised Burden of Proof Rules Under Section 7491(a)

1. Section 7491(a) places the burden of proof on the Service in any court proceeding involving a factual issue if the taxpayer introduces credible evidence with respect to the factual issue relevant to ascertaining the taxpayer’s tax liability. The Service will have the burden of proof under this section if the taxpayer: (1) complies with all the substantiation requirements of the Code; (2) maintains all the records required by the Code; (3) cooperates with the Service’s reasonable requests for information; and (4) meets certain net worth requirements. The new section applies to income, estate, gift and generation skipping taxes. Corporations, trusts, and partnerships whose net worth exceeds $7,000,000 are not eligible for the benefits of the new section. No net worth limitation is applicable to individuals.

2. Section 7491(b) places the burden of proof on the Service in any court proceeding where the Service reconstructs a taxpayer’s income solely through the use of statistical information of unrelated taxpayers. With respect to this subsection, there is no requirement that the taxpayer maintain records or cooperate with the Service.

3. Section 7491(c) provides that the Service shall have the burden of production in any court proceeding relating to the appropriateness of applying penalties, additions to tax and additional amounts imposed by the Code to the taxpayer.

4. Section 7491 is effective in court proceedings arising in connection with audits beginning after July 22, 1998. Where there is no audit, the amendment applies to tax periods or events beginning after July 22, 1998.


**35.4.1.6.2** **(08-11-2004)**

#### Evaluation of Petitioner’s Burden of Proof Cases

1. Even when petitioner must meet both the burden of going forward and the burden of persuasion, if petitioner’s testimony or the testimony of petitioner’s witnesses is uncontradicted, the court generally will believe that testimony. This should be taken into consideration in the evaluation of a settlement or in the determination of whether the case should proceed to trial. An attorney should not rely solely upon cross-examination of the petitioner and petitioner’s witnesses to establish the respondent’s case if there is affirmative evidence available which can be presented on behalf of respondent. Thus, the attorney should develop, to the extent practicable, all affirmative evidence to sustain the Commissioner’s determination, even where petitioner has the burden of proof on the issues. In making this determination, it should be remembered that the so-called burden of proof rule does not mean a great deal in our trials since it does not take much evidence on behalf of the petitioner to shift to the respondent the burden of going forward with the evidence.


**35.4.1.6.3** **(08-12-2021)**

#### Section 6751(b) Penalty Approval Requirement

1. Section 6751(b)(1) requires the initial determination of a penalty to be personally approved in writing by the immediate supervisor of the individual making the determination or such higher official as the Secretary may designate. Section 6751(c) defines "penalty" under section 6751 to include any addition to tax or any additional amount. The requirement imposed by section 6751(b)(1) does not apply to penalties imposed under section 6651, 6654, 6655, or 6662(b)(9). Section 6751(b)(1) also does not apply to "any other penalty automatically calculated through electronic means." Field Attorneys should ensure that any penalties imposed by the IRS complied with section 6751(b)(1). Attorneys should consult the Associate Chief Counsel (Procedure and Administration) Branch 1 or 2 with questions on compliance with section 6751(b)(1).


**35.4.1.7** **(08-11-2004)**

### Developing a Trial Preparation Plan

1. Careful planning and preparation are the keys to appropriate handling of a Tax Court case. The proper trial of a case requires a clear understanding of the issues, the gathering of evidence, and the organization of the evidence as it relates to the issues. This can be achieved best if the Field attorney, as early as the time the answer is prepared, understands what steps must be taken in the case, including use of discovery and admissions, and resolves to follow those steps. The attorney should also consider whether the importance or complexity of the case calls for expedited or special handling.

2. The Field attorney’s plan for the case should be reviewed from time to time, and, as circumstances change, changes should be made to the plan.


**35.4.1.7.1** **(02-07-2013)**

#### Coordination with Appeals

1. Settlement discussions are most effective when a case has been fully developed both factually and legally. Due to practical limitations, however, many docketed cases are referred to Appeals for settlement consideration without full development. See CCDM 35.5.1.4, Settlements by Appeals.

2. Since no answer is required in "S" cases, the Field attorney often does not see the administrative file in a docketed case until Appeals returns the case to Field Counsel for trial preparation or filing of decision documents, or unless the Appeals officer asks for legal advice.

3. If the Field attorney has had access to the administrative file, and becomes aware of shortcomings in case development, these concerns and suggestions for remedying the shortcomings and an offer to assist should be made to Appeals when the case is referred to Appeals for settlement consideration. Care should be taken to honor any restrictions on ex parte communications in communications with Appeals.

4. In cases in which the Field attorney has not had access to the administrative file, the Field attorney should also make the assigned Appeals officer aware of Counsel’s willingness to assist Appeals in dealing with any shortcomings in case development.


**35.4.1.7.2** **(08-11-2004)**

#### Trial Calendars

1. The Tax Court schedules almost all cases for trial in the order of their filing of their petition, taking into consideration the designated place of trial and the court’s schedule of sessions. In regular cases, trial notices are generally are issued to the parties at least five months prior to the date of the scheduled trial session. In "S" cases, trial notices are generally issued to the parties at least two months prior to the date of the scheduled trial session.

2. The court may be reluctant to add cases to the calendar after it is issued. If, however, there are uncalendared cases designated for the same place of trial that are related to cases on the calendar, a motion should be filed to have those cases added to the calendar and consolidated with the calendared cases for trial. If circumstances warrant, other cases may be the subject of a motion to calendar for trial. The motion should clearly indicate the number of trial hours that will be added as a result of the case being calendared.


**35.4.1.7.3** **(08-11-2004)**

#### Trial Teams

1. In large or complex cases, it is often not possible or appropriate for only one Field attorney to handle all of the work connected to the case. In such cases, it is appropriate to form a trial team, that may include paralegals or other personnel in addition to attorneys. In this way, the respondent benefits from the various skills of all members of the team.

2. Even in smaller or less complex cases, it may be appropriate for a variety of reasons to form a trial team. This arrangement often could provide training or mentoring to less experienced attorneys.


**35.4.1.8** **(02-07-2013)**

### Ethical Considerations

1. Practitioners in the Tax Court, including Chief Counsel attorneys, are required to carry on their practice in accordance with the letter and spirit of the Model Rules of Professional Conduct of the American Bar Association. T.C. Rule 201(a). See CCDM 39.1.1.3, Employee Conduct and Ethics.

2. Field attorneys also are required to follow the requirements of [Executive Order 12988](http://www.epa.gov/adr/civiljustice.pdf), Civil Justice Reform, which encourages voluntary dispute resolution, limits the unnecessary use of discovery, and requires that the use of sanctions be prudent. See CCDM 31.1.1.1.3(4), Principles of Litigation, and CCDM 31.1.1.2.4, Sanctions and Attorneys Fees.

3. To implement the Executive Order, all matters involving the conflicts of interest discussed below are subject to the review procedures detailed in _CCDM 35.4.1.8.2_, below.


**35.4.1.8.1** **(02-07-2013)**

#### Petitioner’s Counsel’s Conflicts of Interest

1. Conflicts of interest are governed by the ABA Model Rules of Professional Conduct (which the Tax Court has adopted) and in the Tax Court Rules, in particular ABA Model Rule 1.7 and Tax Court Rule 24(g).

2. Conflicts of interest for petitioner’s counsel and other ethical issues related to representation of a client may arise in a number of ways, including:



   - The attorney has business connections to a person who is not a party to the case (such as a tax shelter promoter), and that person’s interests do or potentially could conflict with petitioner’s interests

   - The attorney has other personal or financial interests that may conflict with the interests of petitioner

   - The attorney promoted, or was otherwise involved, in the planning, organization, sale, or related activity of a tax shelter or similar transaction or arrangement at issue in the case

   - The attorney represents more than one petitioner (either in the same case or in different cases), and the interests of the petitioners are adverse (e.g., husband and wife petitioners in a joint deficiency case in which one of them claims innocent spouse relief under section 6015)

   - The attorney will be called as a witness for either side


3. These common conflicts are discussed in more detail below.


**35.4.1.8.1.1** **(02-07-2013)**

##### Conflict of Interest Based on Planning, Promoting, or Operating a Shelter, or Dual Representation

1. T.C. Rule 24(g) provides that if any counsel of record was involved in planning or promoting a transaction, or operating an entity, that is connected to any issue in the case, or represents more than one person with differing interests as to any issue in a case, then counsel must either:



   - Secure the informed consent of the client,

   - Withdraw from the case, or

   - Take whatever other steps are necessary to obviate a conflict of interest or other violation of the ABA Model Rules of Professional Conduct.


### Note:

The court may inquire into the circumstances of counsel’s employment in order to deter violations. _See_ T.C. Rule 201

2. In addition, ABA Model Rule 1.7(a) provides that an attorney has a conflict of interest if the attorney represents clients with directly adverse interests or if there is a significant risk that the attorney’s representation of a client will be materially limited by the attorney’s responsibility to another current client, former client, or third person, or by a personal interest of the attorney.

3. A sample letter, addressed to opposing counsel, for use in this situation is set forth in Exhibit 35.11.1–77, Sample Letter To Attorneys in Conflict Situations Involving Planning, Promoting or Operating a Tax Shelter.


**35.4.1.8.1.2** **(02-07-2013)**

##### Claims for Relief from Joint and Several Liability under Section 6015 or Duress Cases

1. A specific type of dual representation conflict of interest involves innocent spouse claims. ABA Model Rule 1.7 and Tax Court Rule 24(g) are directly implicated when petitioner’s counsel represents both spouses who filed one or more joint returns in a case in which the underlying deficiency is contested and a claim for relief under section 6015 is or may be asserted. Similarly, petitioner’s counsel may have a conflict of interest when one petitioner claims that the return was signed under duress by the other spouse, invalidating the joint election. _Harbin v. Commissioner_, 137 T.C. 93, illustrates the conflict that may appear when joint filers separate during the course of a Tax Court case. Persons representing joint filers should be aware of the discussion in _Harbin_. If joint petitioners separate or divorce during the course of a Tax Court case, a conflict of interest letter should be sent to petitioners’ counsel. Exhibit 35.11.1–78, Sample Letter To Attorneys in Conflict Situations Involving Multiple Representation; IRC § 6015 at Issue, is a sample conflict letter to pettiioner’s counsel for use in this situation.


**35.4.1.8.1.3** **(02-07-2013)**

##### Financial or Other Personal Interest

1. While less common, petitioner’s counsel may have a financial or other personal interest that conflicts with an interest of the petitioner in the docketed case. In that regard, ABA Model Rule 1.7.(a)(2) provides that an attorney must generally not represent a client when it would conflict with a personal interest of the attorney. An attorney in that situation may eliminate the conflict of interest by giving up the personal interest, for example by resigning from a position or office in an organization or through divestiture of financial holdings. If the attorney does not give up the personal interest, then the attorney must withdraw from the representation or the client must consent to the representation. Exhibit 35.11.1-77, Sample Letter To Attorneys in Conflict Situations Involving Planning, Promoting or Operating a Tax Shelter, can be modified for use in these cases.


**35.4.1.8.1.4** **(06-15-2022)**

##### Petitioner’s Attorney as a Witness

1. A petitioner’s counsel is prohibited from representing the petitioner in a proceeding if petitioner’s counsel is likely to be a necessary witness unless:



   - The testimony relates to an uncontested issue;

   - The testimony relates to the nature and value of legal services rendered in the case; or

   - Disqualification of counsel would work substantial hardship on the client.


A petitioner may not waive this conflict. See T.C. Rule 24(g)(2)(A); ABA Model Rule 3.7(a).



2. Because of the potential for disruption to petitioner’s case and difficulty in obtaining new counsel, petitioner’s counsel should be called as a witness only if necessary and only if there are no alternatives, like a stipulation of facts. It is important for the conflict of interest to be raised as soon as it is determined or anticipated that opposing counsel should be called as a witness. Doing this helps to ensure that the court does not view the intended use of petitioner’s counsel as a witness as a prejudicial trial tactic.

3. Communications with petitioner’s counsel about the conflict, and a letter to petitioner’s counsel if necessary, should request that petitioner’s counsel withdraw from the representation. If petitioner’s counsel does not withdraw, the matter must be brought to the court’s attention. Exhibit 35.11.1-79, Conflict of Interest Situations Where Petitioner’s Attorney Is a Potential Witness, provides a sample letter to petitioner’s counsel.

4. Before listing petitioner’s counsel as a potential witness in a trial memorandum,the petitioner’s counsel must be notified that counsel will be listed and the Sanctions Officer's approval to list petitioner’s counsel must be obtained. In no event should petitioner’s counsel be listed as a witness in a trial memorandum without first following the procedures set forth in _CCDM 35.4.1.8.2_.


**35.4.1.8.2** **(02-07-2013)**

#### General Procedures for Handling Conflicts of Interest

1. Any conflict of interest must be addressed with opposing counsel. If a conflict of interest is not addressed and satisfactorily resolved, a petitioner may later challenge a settlement or decision on the ground that the petitioner’s attorney had a conflict of interest, and the decision could be overturned.

2. Respondent’s counsel of record must make every effort to contact opposing counsel, preferably by telephone, to discuss the potential conflict informally as early as possible and should make repeated efforts to communicate with counsel if necessary. The conflict of interest issues should be raised with opposing counsel well before trial and before settlement negotiations or full-fledged trial preparation begin.

3. In these informal communications, assurances should be sought from petitioner’s counsel that an apparent or potential conflict of interest has been properly resolved. To resolve the conflict, opposing counsel should furnish a letter stating that the attorney informed each client with adverse interests of the potential conflict and that they consented to continued representation. In the alternative, opposing counsel may provide copies of the client’s waivers.

4. If opposing counsel promises to resolve a conflict, with waivers or in some other way, follow up with opposing counsel within a reasonable time should occur.

5. All attempts to contact an opposing counsel and any discussions with opposing counsel about a conflict of interest should be noted in the legal file.

6. Because petitioner’s counsel is considered to represent petitioner until the Tax Court grants a motion to withdraw, see Tax Court Rule 24(c), counsel may continue to communicate with petitioner’s counsel regarding settlement or discovery until the conflict is resolved.

7. If all informal efforts to resolve a conflict of interest are unsuccessful, the next step is to send a conflict letter to opposing counsel, as described in _CCDM 35.4.1.8.2.1_.


**35.4.1.8.2.1** **(02-07-2013)**

##### Conflict Letters

1. The purpose of a conflict letter is to formally advise opposing counsel of one or more actual or potential conflicts of interest and to request opposing counsel to take appropriate action, such as withdrawal, client waivers, divestment of a financial interest of the attorney, or other action to remove the conflict. The letter should briefly state the nature of each conflict, including references to the applicable ABA Model Rules and the Tax Court Rules, and should request an actual response date, usually within 30 days of the letter. The letter should not discuss the merits of the case or allege any ethical violations or wrongdoing by opposing counsel. The letter should not threaten to file a motion to disqualify if the opposing counsel does not act on the conflict.

2. All conflict letters must be submitted, with a background memorandum (see _CCDM 35.4.1.8.2.2_) to TSS for assignment to Procedure and Administration for review and approval by the Sanctions Officer, the Associate Chief Counsel (Procedure and Administration). The letter should be submitted for approval as soon as possible after other means have failed. If a long period has passed between the last contact with opposing counsel on the subject and the letter (ordinarily 30 days), another informal attempt should be made immediately before submitting the letter for approval.

3. Sample letters for the different conflict situations are provided in Exhibits 35.11.1-77, Sample Letter To Attorneys in Conflict Situations Involving Planning, Promoting or Operating a Tax Shelter; 35.11.1-78, Sample Letter To Attorneys in Conflict Situations Involving Multiple Representation, IRC § 6015 at Issue; and 35.11.1-79, Conflict of Interest Situations Where Petitioner’s Attorney Is a Potential Witness.


**35.4.1.8.2.2** **(02-07-2013)**

##### The Background Memorandum

1. A draft background memorandum must be submitted with every draft conflict letter. The purpose of the background memorandum is to inform Procedure and Administration about the facts of the case and the existence of the conflict or conflicts. Thus, the background memorandum should be drafted bearing in mind that its readers may be uninformed about any aspect of the case, but are required to make a recommendation to the Sanctions Officer about a potentially serious matter based primarily (if not entirely) on the information set forth in the background memorandum.

2. A background memorandum should include, at a minimum:



   - The facts of the underlying case

   - The facts of each conflict of interest

   - The trial date or date of most recent developments in the case

   - The case status

   - The informal steps (with dates) taken to raise and resolve the conflict(s) with the opposing counsel and the results

   - The opposing counsel’s prior history (if any) of conflicts in docketed cases and the outcomes, if known


3. When the conflict of interest is that opposing counsel will be a necessary witness, the background memorandum should also include:



   - An explanation of the reasons why opposing counsel is a necessary witness, as defined by the Model Rules

   - The expected testimony

   - The alternatives to the testimony

   - The presence of co-counsel, or the availability of another attorney to readily assume the representation


4. Copies of any documents that may be helpful or necessary to the review should be attached to the memorandum.


**35.4.1.8.2.3** **(02-07-2013)**

##### Additional Procedures for Conflict of Interest Cases

1. Because cases involving conflicts of interest may lead to a request that the court impose sanctions on an opposing counsel, the provisions of [Executive Order 12988](http://www.epa.gov/adr/civiljustice.pdfe-reform), Civil Justice Reform, apply. See CCDM 35.4.1.8 and CCDM 35.10.2.2.3, Sanctions Requiring National Office Review. The Executive Order requires that before filing a motion for sanctions, government counsel must submit the motion for review by the Sanctions Officer.

2. Any motion to disqualify an opposing counsel because of a conflict of interest must also be submitted to the Sanctions Officer for review.

3. If a conflict letter does not resolve the potential conflict of interest, a motion to disqualify must be submitted to the court. Before submitting a motion to disqualify, the issue must be raised with the trial judge by requesting a joint conference call. In the alternative, the issue may be raised at a conference call previously scheduled by the court. The court may issue orders to resolve the conflict. For example, it may order opposing counsel to furnish client assurances by a particular date, or order the filing of a motion to disqualify. The outcome of the contact with the court must be detailed in the background memorandum for any subsequent Motion to Disqualify.

4. Any Motion to Disqualify should be submitted to TSS for formal assignment to Procedure and Administration. In addition, a copy should be sent to the PA attorney who previously reviewed the conflict letter. An updated background memorandum, detailing the developments in the case since the conflict letter was sent, should accompany the draft Motion, along with a copy of any order the court issued.


**35.4.1.9** **(08-11-2004)**

### The Trial Brief/Trial Folder

1. No matter how simple or complex a case is or seems, the Field attorney must have an effective way to organize planning and presentation of the case. For most attorneys, a "trial brief" or "trial folder" will work well.

2. The trial brief serves many purposes, such as:



   - Ensures that the attorney will present to the court all theories of the case

   - Assists adequate trial preparation in that it obliges the attorney to consider the facts of the case and how to get those facts into evidence

   - Highlights any gaps in the case which must be filled

   - Requires a study of the applicable legal authorities


3. The trial brief should reflect a clear understanding of the issues and should marshal the evidence so as to indicate the effect of such evidence and the issue to which it pertains. In addition, the trial brief acts as a log showing the attorney’s preparation and whether other work should be done before the case will be ready for trial. The trial brief also serves as a ready reference during the trial of the case so that the attorney may check on the points intended to be covered in the presentation.


**35.4.1.9.1** **(08-11-2004)**

#### Structure of the Trial Brief/Trial Folder

01. Trial briefs are for the use of the attorney and should be structured in whatever manner is most useful, practical, and helpful to the attorney for the type of case involved. The form of the trial brief is immaterial. Some may prefer 3-ring binders with dividers, while others refer individual folders placed inside other folders, while others may use different structures. It is the substance and help to the attorney which it renders which is important. A suggested organization for the Trial Brief/Trial Folder follows:

02. The **Preliminary Section**should contain information pertaining to:



    1. The caption of the case

    2. Information regarding the type of taxpayer—individual, corporation, partnership, trust, estate, transferee, etc.

    3. The legal residence of a non-corporate petitioner or the principal place of business or principal office or agency of the corporate petitioner on the date the petition was filed with the Tax Court

    4. The name, address, and telephone number of petitioner’s attorney or the _pro se_ petitioner

    5. The tax, years, and amounts involved, including references to amounts of the deficiencies, penalties, and overpayments and the status of such items, i.e., whether they have been assessed by jeopardy or on waiver of restrictions. This section should also indicate whether payment has been made, not only of the deficiency but also of the tax shown on the return and any previous assessments. Whether an adequate transcript of account has been secured should be indicated

    6. The jurisdiction of the Tax Court


03. The **Motions Section**should contain information pertaining to any necessary or potential motions, such as for amendments to the answer or to eliminate years and taxes not properly before the Tax Court.

04. The **Issues Section** should contain a statement of the issues before the court. They should be concisely stated in separately numbered paragraphs. Issues raised in the petition should be stated first, followed by issues raised in the answer. A notation should be made of each issue eliminated by concession, abandonment, or settlement stating the document in the file indicating that the issue was eliminated.

05. The **Prospective Issues Section** should list prospective issues which the Field attorney has reason to believe may be raised by an amended petition or which respondent may raise in the alternative or by an amended answer to conform the pleadings to the proof. In this section, any potential issue of the statute of limitations should be listed.

06. The **Theory of the Case Section**. As to each issue involved, the trial brief/trial folder should set forth concisely the legal theory upon which respondent relies. It should be periodically reviewed to ensure that it is current as to issues, facts, and positions, taken by both petitioner and respondent.

07. The **Proof of Facts—Uncontested Facts Section**. Facts established by the pleadings and facts subject to stipulation should be briefly listed in separate categories. Each fact should be separately numbered. Following each fact susceptible to stipulation, there should be added, in parentheses, references to the documentary proof which supports the statement.

08. The **Proof of Facts—Contested Facts Section**. Contested facts should be listed either under the issue to which they pertain or in the questions prepared for particular prospective witnesses. There should be a parenthetical reference adjacent to each fact indicating the document, witness, or other source of evidence which will be relied upon to prove such fact. Space should be left for reference to where the fact is established in the record if, after the trial brief is prepared, such fact is stipulated or otherwise established in the record.

09. The **Respondent’s Witnesses Section**. The names, addresses, and telephone numbers, if known, of persons whom respondent expects to call as witnesses should be listed. The Field attorney should note briefly the documents and records which the witness is to bring to the trial. Witnesses who are not to be subpoenaed, namely, employees of federal or state agencies, should be listed in a separate group apart from the witnesses who are to be subpoenaed. In a case where an extensive trial will be necessary and several witnesses will be called, it is preferable to list under the name of each witness the points that the attorney expects to cover on examination or cross-examination, or the questions themselves. In relatively simple cases involving only a few witnesses, this portion of the trial brief may be substantially shortened.

10. The **Memorandum of Authorities Section**. The statutes, regulations, decisions, and other authority supporting respondent’s position should be listed together with a summary statement of the point for which such authority is to be used. The memorandum could be the basis for a portion of the Trial Memorandum or Memorandum of Points and Authorities. If the judge requests oral argument at the conclusion of the trial, respondent’s Theory of the Case Section and the Legal Authorities Section should provide an adequate outline from which the argument may be made.

11. The **Evidentiary and Procedural Problems Section**. Evidentiary and procedural problems which the Field attorney can reasonably anticipate will arise during the trial should be noted. The argument and authorities in support of respondent’s position on the points should then be set forth. This section can serve also as the basis for a portion of the Trial Memorandum or Memorandum of Points and Authorities.


**35.4.1.10** **(02-07-2013)**

### Depositions Before Commencement of Case—T.C. Rule 82

1. A person who desires to perpetuate his or her own testimony or that of another person, or to preserve any document or thing that may be recognizable in court, may file an application with the Tax Court to take a deposition, even before a notice of deficiency is issued or other determination is made. Under the language of T.C. Rule 82, the use of a deposition in anticipation of becoming a party to a Tax Court action is not restricted solely to a potential petitioner; it is literally available to the respondent as well. Although this rule has been used by respondent rarely, it is possible, for example, that if during the pendency of an examination it appears that an essential witness in any prospective court action may be unavailable (for example, a revenue agent develops a terminal illness), that the Service could proceed under T.C. Rule 82 to perpetuate the agent’s testimony.

2. The application under Rule 82 is entered upon a special docket, and service and pleading with respect to the application will proceed subject to the requirements otherwise applicable to a motion. _See_ T.C. Rules 50–55. A hearing on the application may be required by the court. The case is docketed with a single digit prefix, followed by the two digit year indicator and a "D" designation, e.g., 1–03D.

3. If the court is satisfied that the perpetuation of the testimony or the preservation of the document or thing may prevent a failure or delay of justice, it will make an order authorizing the deposition and including such other terms and conditions as it may deem appropriate, consistent with the rules. If the deposition is taken, and if thereafter the expected case is commenced in the Tax Court, the deposition may be used in that case subject to the rules which would apply if the deposition had been taken after commencement of the case. See CCDM 35.4.4.5.2.2, Depositions Prior to Trial — T.C. Rule 81, and CCDM 35.4.4.5.2.7, Use of Deposition.

4. Since the application by a potential petitioner may be filed before the Field attorney has any knowledge of the case at all, it is important that, as soon as Field Counsel learns of any such application (or is advised that one will be filed), the Field attorney should start to assemble the background files so that an adequate response to the application, as well as participation in the deposition itself, may be accomplished.

5. The Field attorney must be prepared at the deposition to raise any available defense based on privilege. See CCDM 35.4.6.3.3, Privileges.


**35.4.1.11** **(02-07-2013)**

### Potential Security Threats

1. The safety of the employees of the Office of Chief Counsel and of the Service is of the highest priority. In any contacts with a taxpayer or witness, the Field attorney should be sensitive to signs that a threat is being, or may be, posed to the attorney or any other Chief Counsel or Service employee.

2. Signs that a threat is being, or may be, posed, include:



   - A physical assault on a Chief Counsel or Service employees

   - A show of weapons to a Chief Counsel or Service employee

   - A specific threat of bodily harm to a Chief Counsel or Service employee

   - A use of animals to threaten or intimidate Service or Chief Counsel employees

   - Actions similar to those listed above against employees of other governmental agencies at federal, state, county, or local levels


3. The Service classifies certain taxpayers as "Potentially Dangerous Taxpayers." Counsel more broadly refers to "potentially dangerous persons" to include other individuals such as witnesses. See IRM 5.1.3, Safety, Security, and Control. If the petitioner is classified as a PDT, or if the Field attorney perceives a threat, a request may be made to Criminal Investigation to provide an armed escort or other security arrangement for meetings with the taxpayer. Armed Service employees do not, however, provide security during courtroom proceedings; instead, that function is performed, at the request of the Tax Court, by the United States Marshals Service.

4. Any current threat or assault by a taxpayer should be reported in accordance with local safety and security procedures. If not made to TIGTA at the time of the threat or assault, a report should be made to TIGTA as soon as possible.

5. For procedures on reporting Potentially Dangerous Persons to the Tax Court, see CCDM 35.6.3, Tax Court Procedures for Reporting Potentially Dangerous Persons.


**35.4.1.12** **(02-07-2013)**

### Interest Abatement Cases

1. The Tax Court’s jurisdiction over claims to abate interest is explained at CCDM 35.1.1.9, Interest Abatement Claims.

2. Interest abatement cases are somewhat unique in that, due to the nature of the issue presented (involving the reasons, if any, for delay of certain Service actions), the respondent usually has better control over the facts than does petitioner. As a result, most of the witnesses to be contacted and the evidence to be discovered will be within the Service and its files. See CCDM 35.4.2.2, Use of IRS Personnel.

3. The Field attorney should carefully coordinate interest abatement cases with APJP Branch 3. See CCDM 35.2.1.1.10, Initial Review of Interest Abatement Cases.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-004-001#addtoany "Show all")

A2A