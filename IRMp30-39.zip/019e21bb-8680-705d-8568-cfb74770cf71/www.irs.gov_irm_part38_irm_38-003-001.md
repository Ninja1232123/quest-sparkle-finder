---
url: "https://www.irs.gov/irm/part38/irm_38-003-001"
title: "38.3.1 Miscellaneous Matters | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part38/irm_38-003-001#main-content)

- 38.3.1  [Miscellaneous Matters](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234910240064)
  - 38.3.1.1  [Resubmissions Following Declinations by the Department of Justice](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234910496944)
  - 38.3.1.2  [Assignments Requiring Associate Chief Counsel (Criminal Tax) Approval and/or Concurrence](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234910521904)
  - 38.3.1.3  [Prosecution Standards](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234910514976)
    - 38.3.1.3.1  [Voluntary Disclosure Practice](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234910511776)
    - 38.3.1.3.2  [Voluntary Disclosure Process](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234910175712)
  - 38.3.1.4  [Dual and Successive Prosecution](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234910167344)
    - 38.3.1.4.1  [Application of the Dual and Successive Prosecution Policies](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234910163216)
    - 38.3.1.4.2  [Exceptions to the Dual and Successive Prosecution Policies](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234910155072)
    - 38.3.1.4.3  [Review of Dual and Successive Prosecution during Investigative Stage](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234910237520)
    - 38.3.1.4.4  [Reviewing Cases with Dual or Successive Prosecution Considerations](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234910231264)
  - 38.3.1.5  [Health, Age, and Mental Condition](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234910229376)
  - 38.3.1.6  [Solicitation of Returns](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234910226640)
  - 38.3.1.7  [Fugitive and Absentee Taxpayers](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234910223712)
  - 38.3.1.8  [Balancing Criminal and Civil Aspects](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234910219280)
  - 38.3.1.9  [Exhibits](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234910210560)
  - Exhibit  38.3.1-1  [Search Warrant Check Sheet](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234910208848)
  - Exhibit  38.3.1-2  [Compulsion Order](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234911676208)
  - Exhibit  38.3.1-3  [Act of Production Compulsion Order](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234912109520)
  - Exhibit  38.3.1-4  [Memorandum of Law and Fact to the SAC Re: Administrative Title 18 Forfeitures](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234912087952)
  - Exhibit  38.3.1-5  [Letter to Attorney Offering Conference](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234939686736)
  - Exhibit  38.3.1-6  [Letter to Taxpayer Offering Conference](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234939668016)
  - Exhibit  38.3.1-7  [Sample Conference Outline](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234939794032)
  - Exhibit  38.3.1-8  [Sample Conference Memorandum](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234939737152)
  - Exhibit  38.3.1-9  [Sample Criminal Evaluation Memorandum](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234939500688)
  - Exhibit  38.3.1-10  [Sample Search Warrant Evaluation Memorandum](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234911593824)
  - Exhibit  38.3.1-11  [Sample Grand Jury Request Memorandum](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234909801904)
  - Exhibit  38.3.1-12  [Sample Undercover Evaluation Memorandum](https://www.irs.gov/irm/part38/irm_38-003-001#idm140234909795232)

# Part 38. Chief Counsel Directives Manual Criminal Tax

# Chapter 3. Criminal Tax Policy and Exhibits

# Section 1. Miscellaneous Matters

* * *

## 38.3.1 Miscellaneous Matters

#### Manual Transmittal

March 26, 2021

#### Purpose

(1) This transmits revised CCDM 38.3.1, Criminal Tax Policy and Exhibits; Miscellaneous Matters.

#### Background

CCDM 38.3.1 is being revised to provide current policy on the Voluntary Disclosure Practice for the Office of Chief Counsel.

#### Material Changes

(1) CCDM 38.3.1.3.1 has been updated to reflect the Voluntary Disclosure Practice of Criminal Investigation contained in IRM 9.5.11.9.

(2) CCDM 38.3.1.3.2 has been added to reflect the Voluntary Disclosure Process of Criminal Investigation contained in IRM 9.5.11.9.1.

#### Effect on Other Documents

This section supersedes CCDM 38.3.1, dated 04/09/2020.

#### Audience

Chief Counsel

#### Effective Date

(03-26-2021)

Richard T. Lunger

Division Counsel/Associate Chief Counsel

(Criminal Tax)

**38.3.1.1** **(08-11-2004)**

### Resubmissions Following Declinations by the Department of Justice

1. Where the Department of Justice (DOJ) or the US Attorney has declined to authorize criminal proceedings, the letter declining prosecution will be reviewed by the Special Agent in Charge (SAC) office that initiated the prosecution recommendation to determine whether the declination should be protested and the case resubmitted to DOJ. To be effective, resubmissions to DOJ should normally be based on additional evidence and/or legal arguments overlooked by DOJ. Where there is a disagreement in judgment, the resubmitted case should be particularly strong from an evidentiary standpoint or be of significant import to the tax enforcement program.

2. In addition, the fact that DOJ notifies the taxpayer that the matter has been returned to Criminal Investigation at the time of the declination will not preclude a resubmission of the matter, or the subsequent prosecution of the case if prosecution is warranted. Taxpayers who contact either Criminal Investigation or the Criminal Tax attorney following the receipt of such notification should be advised that the matter is still under consideration for prosecution if a resubmission is contemplated, or that the case has been (or will be) returned to the Service for civil disposition as appropriate.

3. When the SAC determines resubmission is appropriate, the case will be returned to the Criminal Tax attorney for review and evaluation regarding a possible resubmission. The Criminal Tax attorney will notify the Area Counsel (CT) that he/she is in receipt of a resubmission. The Area Counsel (CT) will notify the Associate Chief Counsel (CT) of the resubmission.

4. If after reviewing the case, the Criminal Tax attorney concurs with the SAC’s decision to resubmit the case, the complete case file will be transmitted to the Associate Chief Counsel (CT) for review and evaluation. If the Criminal Tax attorney disagrees with the prosecution recommendation, he/she will prepare a criminal evaluation memorandum and return the case to the SAC.

5. The Associate Chief Counsel (CT) will review and evaluate the case and prepare a criminal evaluation memorandum. The criminal evaluation memorandum and the entire case file will be transmitted to the Director of Field Operations for coordination with the SAC.


**38.3.1.2** **(10-03-2007)**

### Assignments Requiring Associate Chief Counsel (Criminal Tax) Approval and/or Concurrence

1. The following assignments require Associate Chief Counsel (CT) approval and/or concurrence:



1. Criminal reference letters where the recommended violation is 18 U.S.C. §§ 1621, 1622, or 1623, involving perjury, subornation of perjury, or a false declaration occurring during the Tax Court proceedings require the signature of the Associate Chief Counsel (CT)

2. Cases previously referred for prosecution and declined by the Tax Division or US Attorney should be submitted to the Associate Chief Counsel (CT) for consideration and evaluation of Criminal Investigation’s decision to resubmit the case to DOJ

3. Grand Jury Investigation Requests or Expansions involving politically sensitive individuals as defined in CCDM 38.2.2.2.3

4. Administrative Cases involving politically sensitive individuals as defined in CCDM 38.2.1.3.3

5. Search Warrants directed at the premises owned, controlled or under the dominion of a subject or target of an investigation described in CCDM 38.1.1.3.1(5)

6. The authority to authorize forfeiture proceedings with respect to nonwagering IRC § 7302 forfeitures that do not solely relate to violations regarding the filing of Forms 8300 concerning the receipt of more than $10,000.00 cash by a trade or business pursuant to IRC § 6050I

7. Final recommendations regarding petitions for remission or mitigation of forfeitures


**38.3.1.3** **(08-11-2004)**

### Prosecution Standards

1. In order to concur with Criminal Investigation’s criminal prosecution recommendation, the evidence must be sufficient to establish guilt beyond a reasonable doubt and a reasonable probability of conviction must exist.

2. All the facts and circumstances must be considered when reviewing a criminal tax case. Consideration must be given to various factors, including but not limited to whether a voluntary disclosure was made, whether dual or successive prosecution exists, the health, age and mental condition of the taxpayer and whether solicitation of returns has occurred. The presence of any of the foregoing may impact on willfulness and significantly impair or eliminate the probability of conviction. These factors should be considered as early as possible in each case (e.g., prereferral, inventory review) to avoid unnecessary utilization of resources. If any of the above factors is present in a criminal case, it must be discussed thoroughly in the criminal evaluation memorandum.


**38.3.1.3.1** **(03-26-2021)**

#### Voluntary Disclosure Practice

1. The Voluntary Disclosure Practice is a long-standing practice of the IRS that provides taxpayers with criminal exposure a means to come into tax compliance and potentially avoid criminal prosecution.

2. The Voluntary Disclosure Practice is a compliance option for taxpayers who have committed tax or tax-related crimes and have criminal exposure due to their willful violation of the law. If the violation of the law was not willful, taxpayers should consider other options including correcting past mistakes by filing amended or past due returns.

3. A voluntary disclosure will be considered along with all other factors in determining whether criminal prosecution will be recommended. A voluntary disclosure does not guarantee immunity from prosecution.

4. The Voluntary Disclosure Practice creates no substantive or procedural rights for taxpayers. Taxpayers cannot rely on the fact that other similarly situated taxpayers may not have been recommended for criminal prosecution. IRS-CI’s determinations, including but not limited to determinations concerning timeliness, completeness, truthfulness, rejection, and revocation decisions, are not subject to any administrative or judicial review or appeal process.

5. The Voluntary Disclosure Practice is not available to taxpayers with illegal source income. Income from activities determined to be legal under state law but illegal under federal laws is considered illegal source income for purposes of the IRS-CI Voluntary Disclosure Practice.

6. A voluntary disclosure occurs when the communication is truthful, timely, and complete. The practice also requires taxpayers to:



1. Cooperate with the IRS in determining their tax liability and compliance reporting requirements,

2. Cooperate with the IRS in investigating any professional enablers who aided in the noncompliance,

3. Submit all required returns, information returns, and reports for the disclosure period, and

4. Make good faith arrangements with the IRS to pay in full, the tax, interest, and any penalties determined by the IRS to determined by the IRS to be applicable.


7. A disclosure is timely if it is received before:



1. The IRS has commenced a civil examination or criminal investigation of the taxpayer.

2. The IRS has received information from a third party (e.g., informant, other governmental agency, or the media) alerting the IRS to the taxpayer’s noncompliance.

3. The IRS has acquired information directly related to the noncompliance of the taxpayer from an enforcement action (e.g., search warrant, summons, grand jury subpoena).


8. Any taxpayer who contacts the IRS in person or through a representative regarding the voluntary disclosure practice will be directed to CI Headquarters International Operations. See IRM 9.5.11.9.3.


**38.3.1.3.2** **(03-26-2021)**

#### Voluntary Disclosure Process

1. All voluntary disclosures must meet the requirements contained in IRM subsection 9.5.11.9.

2. Taxpayers must utilize Form 14457 - Voluntary Disclosure Practice Preclearance Request and Application to participate in the Voluntary Disclosure Practice. For detailed information on how to complete Form 14457, taxpayers should review the Instructions for Form 14457, found on www.irs.gov/vdp.

3. Form 14457 is submitted to IRS-Criminal Investigation (IRS-CI) in two parts. Part I - Preclearance Request is submitted to request preclearance. Preclearance involves supplying key information for IRS-CI to determine if the taxpayer is eligible to make a voluntary disclosure, including establishing if the unreported income is from legal sources and that the timeliness requirements are met. IRS-CI will provide the taxpayer with written notification of whether the preclearance request is approved or denied.

4. After receiving written confirmation of preclearance, the taxpayer must submit Part II - Voluntary Disclosure Application within 45 days. One additional 45-day extension may be granted upon written request. Part II cannot be submitted without first obtaining preclearance and a case control number in the written confirmation of preclearance.

5. Part II requires a narrative, signed under the penalties of perjury by the taxpayer (and their spouse if making a joint disclosure), with specific facts that detail the complete story of the willful on compliance. The narrative must address the taxpayer’s personal and professional background. The narrative must identify all professional advisors that rendered services to the taxpayer from the inception of the noncompliance. And the narrative must provide the whole story with all favorable and unfavorable facts including the entire history of noncompliance from the inception through the present. Instructions for Form 14457 provide guidance for taxpayers in preparing narratives. Any submission that does not contain a narrative statement of facts including all elements addressed in the Instructions to Form 14457 will be considered incomplete.



1. Taxpayers who fail to submit complete narratives that include every element addressed in the Instructions to Form 14457 will not be given an opportunity to supplement their submissions.

2. IRS-CI will notify taxpayers who fail to submit complete narratives by letter that their voluntary disclosure was not preliminarily accepted.


6. CI will review Part II of Form 14457 and determine if the taxpayer may participate in the Voluntary Disclosure Practice. If approved to participate, CI will provide the taxpayer with a Preliminary Acceptance Letter and forward the Form 14457 to a civil section of the IRS. Once the case is assigned, an examiner will contact the taxpayer.

7. For additional guidance and definitions to complete the Form 14457, please see the Instructions for Form 14457 - Voluntary Disclosure Preclearance Request and Application found on www.irs.gov/vdp.


**38.3.1.4** **(08-11-2004)**

### Dual and Successive Prosecution

1. DOJ’s Dual Prosecution Policy. The dual prosecution policy precludes the initiation or continuation of a federal prosecution following a state prosecution based substantially on the same act or acts unless there is a compelling federal interest supporting the dual prosecution. US Attorneys’ Manual (USAM), Sec. 9-2.031.

2. DOJ’s Successive Prosecution Policy. The successive prosecution policy applies when there has been a prior federal prosecution based substantially on the same act or acts unless there is a compelling federal interest supporting the successive prosecution. USAM, 9-2.031.


**38.3.1.4.1** **(08-11-2004)**

#### Application of the Dual and Successive Prosecution Policies

1. If either policy is applicable, prosecution will not be initiated without prior approval of the Assistant Attorney General, Tax Division.

2. The policies:



1. Apply whenever the underlying acts or transactions have been the subject of a prior criminal proceeding to which jeopardy attached;

2. Are not terminated upon the filing of an indictment or criminal information; and

3. Are not influenced by the fact that reversal of the earlier conviction is a possibility.


3. Whenever the Solicitor General concludes that either the dual or successive prosecution policies has been violated, a motion will be filed requesting that the judgment of conviction be vacated.

4. The foregoing reflects:



1. DOJ, under its dual or successive prosecution procedures, evaluates all IRS recommendations for prosecution in light of any state and federal convictions of the taxpayer occurring before the criminal tax trial is commenced or guilty plea accepted concerning conduct that may also constitute the criminal tax offense;

2. DOJ will probably decline a criminal tax prosecution if the taxpayer is already serving a long jail sentence on any matter;

3. Absent compelling reasons, DOJ will not institute prosecution where the taxpayer has previously been convicted for the same transaction (i.e., where the unreported income in the proposed criminal tax case was derived from bribery, for which the taxpayer has been convicted);


5. In applying its dual or successive prosecution policy, the Tax Division has asserted that it considers such matters as the similarity in the transaction(s) in the earlier conviction and the criminal tax case; the appropriateness of the punishment in connection with the prior conviction; its deterrent effect; and, where appropriate, the appellate status of the prior conviction.


**38.3.1.4.2** **(08-11-2004)**

#### Exceptions to the Dual and Successive Prosecution Policies

1. Prosecution of a case having dual or successive prosecution implications is not necessarily prohibited if the Assistant Attorney General, Tax Division, concludes that the prior proceeding left substantial federal interests demonstrably unvindicated.


**38.3.1.4.3** **(08-11-2004)**

#### Review of Dual and Successive Prosecution during Investigative Stage

1. The procedures outlined below are not meant to preclude the use of informal prereferral consultation between Criminal Investigation and the Criminal Tax attorney.

2. When Criminal Investigation identifies the existence or potential existence of dual and/or successive prosecution issues, Criminal Investigation may ask the Criminal Tax attorney for prereferral legal assistance. Sufficient facts should be provided to enable the Criminal Tax attorney to determine whether dual or successive prosecution policy considerations apply and if they do apply, whether there are, nevertheless, compelling reasons to prosecute the criminal tax offense.

3. Criminal Tax Attorney Procedures during the Investigatory Stage. Upon receipt, the Criminal Tax attorney will review the request and determine whether the dual or successive prosecution policy considerations apply and so advise the SAC in writing. The Criminal Tax attorney is encouraged to work with Criminal Investigation in the early detection and resolution of dual or successive prosecution issues.

4. DOJ’s Dual and/or Successive Prosecution Prereferral Opinions. Where compelling reasons exist warranting prosecution, notwithstanding the existence of dual and/or successive prosecution issues, opinions pertaining to the specific case may be obtained from the Tax Division. The Criminal Tax attorney prepares a written request with relevant documentation attached, for the SAC’s signature, to the appropriate Chief, \[Region\] Criminal Enforcement Section, Tax Division, for its opinion on the application of the policy. Extreme care will be exercised so that only material meeting the tests set forth in IRC § 6103(h)(2) is forwarded to the Tax Division. The Tax Division has agreed to this procedure and will give expeditious consideration to requests for opinions.


**38.3.1.4.4** **(08-11-2004)**

#### Reviewing Cases with Dual or Successive Prosecution Considerations

1. When present in a case, the Criminal Tax attorney will discuss the dual or successive prosecution considerations in the criminal evaluation memorandum. The discussion will address whether or not compelling reasons exist warranting prosecution.


**38.3.1.5** **(08-11-2004)**

### Health, Age, and Mental Condition

1. The taxpayer’s health, age and mental condition (not rising to the level of insanity), both at the time of the alleged offense and at the time of the referral for prosecution, are among the factors to be considered when reviewing a prosecution recommendation.

2. The criminal evaluation memorandum must analyze and discuss these factors to the extent they affect willfulness and the probability of conviction.


**38.3.1.6** **(08-11-2004)**

### Solicitation of Returns

1. Solicitation generally consists of an oral or written request for the filing of specific returns by a revenue agent and/or officer, or a summons for information by which a return can be prepared if the taxpayer understands that a return could be filed in lieu of specific compliance with the summons.

2. DOJ considers the active solicitation of a return as detrimental to a criminal case in that the defense can be expected to argue that the prosecution was instituted because of the unsuccessful attempt to dispose of the matter civilly and as a substitute for unsuccessful collection. Solicitation of a return where no return is subsequently filed is not considered to detract from prosecution. When solicitation is present in a criminal case, the Criminal Tax attorney must discuss its possible impact on the successful prosecution of the case in the criminal evaluation memorandum.


**38.3.1.7** **(08-11-2004)**

### Fugitive and Absentee Taxpayers

1. There are a number of problems in referring a case where the taxpayer is either outside the United States or a fugitive. DOJ employs the following presumptions in determining whether such a case merits indictment:



1. If the party is a United States citizen, DOJ will assume he/she has some ties with the United States that will induce him/her to return.

2. If the party is an alien, the presumption will be against his/her returning to the United States.


2. When reviewing prosecution recommendations involving a fugitive taxpayer, the Criminal Tax attorney will look into all the facts and circumstances, including the taxpayer’s business interests and family ties in the United States, and evidence supporting and/or rebutting either of the presumptions should be discussed in the criminal evaluation memorandum.


**38.3.1.8** **(10-03-2007)**

### Balancing Criminal and Civil Aspects

1. The criminal and civil aspects of a case do not present an either/or proposition. Rather, the criminal and civil aspects of a case should be balanced to the extent possible without prejudicing the criminal prosecution.

2. While a case is under criminal investigation, and until the criminal aspects of the case are closed, all proposed civil actions must be coordinated with the Criminal Tax attorney/manager. Regardless of which Operating Division generates the request, the Criminal Tax attorney/manager will consult with all necessary civil attorneys/managers, as well as Criminal Investigation and/or DOJ. If agreement is reached between the parties, the Criminal Tax attorney/manager will provide to the requesting client the Counsel position regarding whether and to what extent any civil action may take place prior to the time the criminal aspects of the case are closed. If agreement is not reached, then the matter will be reconciled using normal reconciliation procedures. See CCDM 31.1.4.4.

3. Examples of proposed civil actions that require coordination with the Criminal Tax attorney include without limitation:



   - contact with the criminal target

   - solicitation of consents to extend the civil statute of limitations

   - assessments, including jeopardy and termination assessments

   - issuance of notices of deficiency

   - filing notices of federal tax lien

   - issuance of summonses

   - solicitation of collection waivers

   - any collection action

   - eliminating or partially conceding the fraud penalty

   - investigation of offers in compromise


4. Once the criminal aspects of a case have been concluded, proposed civil actions should be discussed with the Area Counsel (CT). All civil actions, including reduction of deficiency figures below the criminal figures, will be determined by the appropriate civil Associate Area Counsel.


**38.3.1.9** **(08-11-2004)**

### Exhibits

1. The exhibits for Part 38 have been consolidated for ease of use.


**Exhibit 38.3.1-1**

### Search Warrant Check Sheet

| **1\. TARGET(s)** |
| --- |
| **2\. VIOLATION(s)** |
| **3\. PREMISES TO BE SEARCHED** |
|  | a. | Identified (address and location description) |
|  |  | i. | Business or corporate office(s) |
|  |  | ii. | Residence |
|  |  | iii. | Other (specify/describe) |
|  | b. | Are owned or controlled by |
|  |  | i. | Accountant |
|  |  | ii. | Lawyer |
|  |  | iii. | Physician |
|  |  | iv. | Public official (federal, state, local, or foreign) or political candidate |
|  |  | v. | Member of the clergy |
|  |  | vi. | News media official (electronic or printed) |
|  |  | vii. | Labor union official |
|  |  | viii. | Official of an organization deemed to be exempt under I.R.C. § 501(c) or (d) |
|  |  | ix. | Disinterested third parties |
| **4\. AFFIDAVIT IDENTIFIES IN NONCONCLUSORY TERMS KEY FACTS ESTABLISHING PROBABLE CAUSE TO BELIEVE:** |
|  | a. | Specified crime(s) has been (or is being) committed |
|  |  | i. | All elements of the offense established |
|  |  | ii. | If conspiracy (18 U.S.C. § 371) alleged, two or more persons are party to the agreement to commit the offense or defraud the U.S. |
|  | b. | There is evidence of the crime, e.g., records |
|  |  | i. | Records sought |
|  |  |  | 1. | have nexus to crime alleged and |
|  |  |  | 2. | are described with requisite particularity (No laundry lists; no general subpoena-type lists; Appropriate accounting terminology used when describing books and records) |
|  |  | ii. | Clearly defined temporal limitations |
|  |  |  | 1. | Tax years/periods and/or calendar years at issue |
|  |  |  | 2. | Tailored to statute of limitations |
|  |  | iii. | Records clearly limited to targets and related entities specifically mentioned in affidavit |
|  |  | iv. | Computers |
|  |  |  | 1. | Computer expert justification for seizure |
|  |  |  | 2. | Computer expert procedure to be followed |
|  |  |  | 3. | Computer system/components identified w/particularity |
|  | c. | Evidence sought is presently on the premises to be searched |
|  |  | i. | Observations of Informant/Witness/Agent or Admissions |
|  |  |  | 1. | Reliability |
|  |  |  | 2. | Specificity |
|  |  |  | 3. | Not over 6 months old |
|  |  | ii. | Accurate description/depiction of where the evidence is located and how maintained |
|  |  | iii. | Staleness |
|  |  |  | 1. | History of owner’s possession of evidence/records sought |
|  |  |  | 2. | Relevant retention period(s) for evidence/records sought |
|  |  |  | 3. | Likelihood evidence/records sought are still on premises to be searched |
| **5\. INFORMANTS AND WITNESSES** |
|  | a. | Basis of Knowledge/Credibility/Reliability |
|  |  | i. | Extent of personal, actual knowledge of relevant information |
|  |  | ii. | Criminal/informant history |
|  |  | iii. | Informant reward claim |
|  | b. | Independent, substantial corroboration |
| **6\. REASONS WHY LESS INTRUSIVE MEANS (E.G., SUMMONS, SUBPOENA) ARE NOT BEING USED ARE ADEQUATELY DISCUSSED** |
| **7\. POTENTIAL PROBLEMS AND PROPOSED RESOLUTIONS** |
|  | a. | Privileges and privilege team |
|  | b. | Use of permeated-with-fraud theory |
|  | c. | Other (specify/describe) |
| **8\. MEMO TO FILE** |
|  | a. | I have reviewed this search warrant application for legal sufficiency and compliance with IRS policy and procedure and conclude: |
|  |  | i. | There are sufficient facts to establish probable cause to believe: |
|  |  |  | 1. | The target(s) has committed (or is committing) the alleged violations (specify) |
|  |  |  | 2. | The records sought are likely to contain evidence of such crimes. |
|  |  |  | 3. | The records sought are presently located on the premises to be searched. |
|  |  | ii. | There is sufficient explanation as to why other less intrusive means to obtain this evidence/records are not being utilized. |

**Exhibit 38.3.1-2**

### Compulsion Order

| Compulsion Order<br> 18 U.S.C. §§ 6002, 6004 |
| --- |
| Internal Revenue Service Proceeding<br> Investigating the Tax Liability of:<br> Name of subject of investigation<br> Address |
| At the request of the Special Agent in Charge, \[City\], and the Director of Field Operations \[Area\], submitted with supporting documentation sufficient to show to my satisfaction: |
| 1\. That \[Name of witness\] has been summonsed to testify or provide other information to the Internal Revenue Service pursuant to 26 U.S.C. § 7602; and |
| 2\. That \[Name of witness\] has refused to testify or provide other information on the basis of his/her privilege against self-incrimination; and |
| 3\. That, in the judgment of the Chief, Criminal Investigation, the testimony or other information from \[Name of witness\] may be necessary to the public interest; and |
| 4\. That the aforesaid request has been approved by the Assistant Attorney General of the Tax Division of the Department of Justice, pursuant to the authority vested in him/her by 18 U.S.C. § 6004 and 28 C.F.R. 0.175. |
| NOW, THEREFORE, IT IS ORDERED, pursuant to 18 U.S.C. § 6002 that \[Name of witness\] gives testimony or provide other information that he/she refuses to give or provide on the basis of his/her privilege against self-incrimination as to all matters about which he/she may be interrogated during the course of the Internal Revenue Service proceedings. |
| This order shall become effective only if after the date of this order \[Name of witness\] refuses to testify or provide other information on the basis of his/her privilege against self-incrimination. |
| That pursuant to 18 U.S.C. § 6004, \[Name of witness\] be granted use immunity in any criminal case, except a prosecution for giving a false statement or otherwise failing to comply with this order. |
| This order is issued with the approval of the Assistant Attorney General, Tax Division, Department of Justice by the Chief, Criminal Investigation, Internal Revenue Service, pursuant to the authority delegated to him/her by 18 U.S.C. § 6004, Treasury Department Order No. 150-88, dated November 24, 1977 and Delegation Order 169 (as revised). |
|  | UNDERSCORE<br> \[Name\]<br> Chief, Criminal Investigation<br> Internal Revenue Service |
| UNDERSCORE<br> Date |  |

**Exhibit 38.3.1-3**

### Act of Production Compulsion Order

| Compulsion Order<br> 18 U.S.C. §§ 6002, 6004 |
| --- |
| Internal Revenue Service Proceeding<br> Investigating the Tax Liability of:<br> Name of subject of investigation<br> Address |
| At the request of the Special Agent in Charge \[City\], and the Director of Field Operations \[Area\], submitted with supporting documentation sufficient to show to my satisfaction: |
| 1\. That \[Name\] has been summonsed to produce the books and records of \[Name\], to the Internal Revenue Service pursuant to 26 U.S.C. § 7602; and |
| 2\. That \[Name\] has refused to produce these books and records on the basis of his/her privilege against self-incrimination; and |
| 3\. That, in the judgment of the Chief, Criminal Investigation, the production of these books and records from \[Name\] may be necessary to the public interest; and |
| 4\. That the aforesaid request has been approved by the Assistant Attorney General of the Tax Division of the Department of Justice, pursuant to the authority vested in him/her by 18 U.S.C. § 6004 and 28 C.F.R. 0.175. |
| NOW, THEREFORE, IT IS ORDERED, pursuant to 18 U.S.C. § 6002 that \[Name\] produce the books and records of \[Name\] which he/she refuses to give or provide on the basis of his/her privilege against self-incrimination during the course of the Internal Revenue Service proceeding. |
| This order shall become effective only if after the date of this order \[Name\] refuses to produce the books and records on the basis of his/her privilege against self-incrimination. |
| That pursuant to 18 U.S.C. § 6004, \[Name\] be granted use immunity relative to the act of production of books and records of \[Name\], in any criminal case, except a prosecution for perjury, giving a false statement or otherwise failing to comply with this order. |
| This order is issued with the approval of the Assistant Attorney General, Tax Division, Department of Justice by the Chief, Criminal Investigation, Internal Revenue Service, pursuant to the authority delegated to him/her by 18 U.S.C. § 6004, Treasury Department Order No. 150-88, dated November 24, 1977 and Delegation Order 169 (as revised). |
|  | UNDERSCORE<br> \[Name\]<br> Chief, Criminal Investigation<br> Internal Revenue Service |
| UNDERSCORE<br> Date |  |

**Exhibit 38.3.1-4**

### Memorandum of Law and Fact to the SAC Re: Administrative Title 18 Forfeitures

|  |  |  | \[Date\] |  |
| --- | --- | --- | --- | --- |
|  |  |  |  | \[CASE No.\]<br> \[Name\] |
|  |  |  |  |  |
| MEMORANDUM FOR SPECIAL AGENT IN CHARGE, \[City\] FIELD OFFICE<br> Attn: Supervisory Special Agent \[Name\]<br> Special Agent \[Name\] |
| FROM: | \[Name\]<br> Attorney \[City\] |
| SUBJECT: | Proposed Administrative Forfeiture of \_\_\_ seized at<br>\[Place of Seizure\]<br> Property Owner: \_\_\_<br> AFTRAK No. \_\_\_\_ |
| On \[date\], you forwarded to us a Form 4008, Seized Property Report, indicating that the above-described property had been seized on \[date\], pursuant to a seizure warrant issued by the United States in the district of \_\_\_ for forfeiture under 18 U.S.C. § 981(a)(1)(A) as property traceable to property involved in financial and monetary transactions in violation of 18 U.S.C. §§ 1956/1957. |
| Based on our review of this matter, we conclude there is a basis for civil forfeiture of this property and advise you to send notice of intent to administratively forfeit that property to all parties having an interest therein no later than _\[date that is 60 days from date of seizure\]_. |
| _FACTS_ |
| \[Set forth all relevant information/facts on the underlying scheme, how Criminal Investigation became aware of the scheme, and the relationship of the seized property to the scheme, i.e., the basis of seizure.\] |
| \[Set forth relevant facts specific to alleged violation, for example:<br> For violations of 31 U.S.C. § 5324(a), set out facts concerning pattern of deposits or withdrawals, such as several deposits on same day to different accounts, or same account at different branches or different tellers, knowledge of Bank Secrecy Act requirements, how the property was involved in or traceable to structuring activity. |\
| For violations of 18 U.S.C. §§ 1956/1957, set out information regarding underlying criminal activity. How the property constitutes proceeds of that activity, and information regarding the financial or monetary transaction.\] |
| \[CASE No.\] |  |  |  |
| _LAW AND ANALYSIS_ |
| \[Set out 18 U.S.C. § 981(a)(1)(A), (or 31 U.S.C. § 5317(c)) and language of predicate statute. |\
| \[If a violation of 31 U.S.C. § 5324(a), discuss how pattern of transactions constitutes structuring. How is this property involved in the structuring violation, or traceable to property involved in such activity? If there has been deposit and withdrawal activity in the account, does 18 U.S.C. § 984 apply and allow forfeiture.\] |\
| \[If theory is that property is forfeitable as involved in or traceable to a violation of § 1956, discuss what evidence indicates: |\
|  | The property constitutes the proceeds of specified unlawful activity (SUA), and what is the SUA? How does this property constitute the proceeds of it? What is the financial transaction or attempted transaction? What is the intent, specified in § 1956(a)(1), with which the transaction was conducted?\] |\
| \[If theory is that property is forfeitable as involved in or traceable to a violation of § 1957, discuss what evidence indicates: |\
|  | What is the monetary transaction? How is the property criminally derived? Is the value of the property greater that $10,000? What is the financial institution?\] |\
| \[How is the property involved in a transaction or attempted transaction that violates § 1956 or § 1957, or how is it traceable to property so involved?\] |\
| \[Discuss Government’s burden of proof (preponderance of the evidence), analyze available evidence in light of this burden, and the elements of proof for forfeiture.\] |\
| \[Discuss applicable defenses, potential Constitutional bases for challenge, and impact of mitigation guidelines if applicable, e.g., innocent owners defenses and the proportionality of civil forfeiture (i.e., excessive fines determination). If appropriate, discuss elapsed time since seizure in context of statutory requirements under 18 U.S.C. § 983.\] |\
| \[If the Service lacks a legal or factual basis to forfeit property seized, set forth reasons why the seized property cannot be forfeited and discuss case law that bears on the issue. For example: the Government cannot prove a transaction occurred with the SUA proceeds. If an alternative forfeiture theory could work with additional investigation, give guidance and offer assistance.\] |\
| _CONCLUSION_ |\
| \[Set out the steps to perfect forfeiture, including requirement to publish an advertisement advising of the seizure and pending forfeiture, the time periods for filing a claim or petition for remission or mitigation of forfeiture and steps to take should one be filed. Advise that Criminal Investigation should contact Counsel if a Claim, a Petition of Remission or Mitigation, or an offer in compromise is received.\] |\
| \[Case No.\] |  |  |  |\
| \[If memorandum recommends return of the property, conclude with recommendation on deficiency of proposed forfeiture and need to return seized property.\] |\
| As indicated above, we find there is sufficient evidence to sustain forfeiture of the subject property by a preponderance of the evidence. Accordingly, this office recommends you act under Delegation Order No. 158 to perfect administrative forfeiture by taking the steps required for such perfection. |\
| If you have any questions or concerns about this matter, please contact the undersigned at (123) 456-7890. |\
|  |  |  |  | \[Name\]<br> Area Counsel \[City\]<br> Criminal Tax |\
|  |  |  |  |  |\
|  |  |  |  | \\_\\_\\_\_\_\_\_\_\_<br> \[Attorney Name\]<br> Criminal Tax, \[City\] |\
|  |  |  |  |  |\
| 1cc: Division Counsel/Associate Chief Counsel (Criminal Tax), Washington, D.C.<br> 2cc: Supervisory Special Agent<br> 1cc: Special Agent |\
\
**Exhibit 38.3.1-5**\
\
### Letter to Attorney Offering Conference\
\
| \[Symbols\] |  |\
| --- | --- |\
| Ms. \[Name\]<br> Attorney at Law<br> \[Address\] |  |\
| In re: | \[Name of Taxpayer\]<br> \[City\] |  |\
| Dear Ms. \[Name\]: |  |\
| This office has under consideration a recommendation that criminal proceedings be instituted against \[Name of Taxpayer\] for \[criminal violation/statute\] for the years \_\_\_ through \_\_\_, in violation of \[cite statute\]. Based on the information currently available, the additional income and tax for criminal purposes is \_\_\_\_\_\_ \[list the amounts\]. The \_\_\_\_\_\_ method of proof was used to determine the tax liabilities. Please note that the recommended charges, additional income and tax amounts, and method of proof are subject to change. |\
| If you desire a conference in this matter, it will be held on \[date\] at \[time\], in my office which is located at \[address\]. Please contact this office before _\[date\]_ indicating _whether or not you plan to attend the conference_. If you wish to contact me by telephone, my telephone number is \[telephone number\]. If you prefer, you may submit in writing any defenses or other information which you want this office to consider in lieu of a face-to-face meeting. Please forward any such information before the above conference date. Please note _our review of this matter will not be delayed_ beyond the above conference date. |\
| Please be advised that the conference is not an opportunity for discovery. Moreover, plea bargaining, civil settlement, negotiations and/or compromise of the tax liabilities involved will not be considered or discussed at this conference. |\
|  |  | Sincerely, |\
|  |  |  |\
|  |  | \\_\\_\\_\_\_\_<br> \[Name\]<br> Special Agent in Charge |\
\
**Exhibit 38.3.1-6**\
\
### Letter to Taxpayer Offering Conference\
\
| \[Symbols\] |  |\
| --- | --- |\
| \[Taxpayer Name\]<br> \[Address\] |  |\
| Dear \[Taxpayer Name\]: |  |\
| This office has under consideration a recommendation that criminal proceedings be instituted against you for \[criminal violation/statute\] for the years \_\_\_ through \_\_\_, in violation of \[cite statute\]. Based on the information currently available, the additional income and tax for criminal purposes is \_\_\_\_\_\_ \[list the amounts\]. The \_\_\_\_\_\_ method of proof was used to determine the tax liabilities. Please note that the recommended charges, additional income and tax amounts, and method of proof are subject to change. |\
| If you desire an opportunity to discuss these matters and present any information you think we should have when considering your case, a conference has been scheduled for \[date\] at \[time\] at \[location\]. Should you decide, you may be accompanied by counsel at the conference, or if you prefer, to be represented by counsel without appearing in person. Please note that the government will not provide counsel to represent you at this conference. |\
| Please contact this office before _\[date\]_ indicating whether or not you plan to attend the conference. If we do not hear from you by then, we will assume that you do not wish to attend a conference. If you wish to contact me by telephone, my number is \[telephone number\]. If you prefer, you may submit, in writing, any defenses or other information which you may want this office to consider in lieu of a face-to-face meeting. Please forward any such information before the above conference date. Please note _our review process can not be delayed_ beyond the above conference date. |\
| If you are to be represented by counsel, the Treasury Department’s Rules of Practice require such representative to file a proper power of attorney covering the years \_\_\_ through \_\_\_, together with a statement concerning his/her qualifications to practice. (Treasury Department Form 2848, Power of Attorney, is suggested for this purpose). |\
| Please be advised that the conference is not an opportunity for discovery. Moreover, plea bargaining, civil settlement, negotiations and/or compromise of your tax liability will not be considered or discussed at this conference. |\
|  | Sincerely, |\
|  |  |\
|  | \\_\\_\\_\_\_\_<br> \[Name\]<br> Special Agent in Charge |\
\
**Exhibit 38.3.1-7**\
\
### Sample Conference Outline\
\
|  | \[Special Agent’s Name\]<br> \[Revenue Agent’s Name\] |\
| --- | --- |\
| **CONFERENCE OUTLINE**<br> FOR<br>**Taxpayer’s Name**<br> and Address |\
| _I. Description of Case:_ |\
| An investigation conducted by Criminal Investigation has determined that \[Taxpayer\] willfully filed false income tax returns for each of the years 1985, 1986 and 1987. |\
| _II. Recommended Charges:_ |\
| The Special Agent has recommended that \[Taxpayer\] be charged with three counts of violating I.R.C. § 7206(1). Section 7206(1) provides: "Any person who willfully makes and subscribes any return, statement, or other document, which contains or is verified by a written declaration of perjury, and which he does not believe to be true and correct as to every material matter shall be guilty of a felony and upon conviction thereof, shall be fined not more than $250,000 ($500,000 in the case of a corporation), or imprisoned not more than 3 years, or both, together with costs of prosecution." |\
| _III. Method of Proof:_ |\
| The specific items method of proof was used. This means that the agents documented specific items of income and expenses. |\
| _IV. Constitutional Warnings and Advice:_ |\
| This conference is voluntary on your part, and on the part of your representative(s). Therefore, you or your representative(s) may terminate it at any time. |\
| You, or your representative(s), may refuse to answer any questions or make any statements which may incriminate you, as provided by the Fifth Amendment of the United States Constitution. However, any statements made by you or on your behalf by your representative(s) may be used against you in any subsequent proceedings instituted by the Government. Do you understand these rights? |\
| Please be advised that plea bargaining, civil settlement, negotiations and/or compromise of the tax liabilities involved will not be considered or discussed at this conference. |\
| _V. Processing Procedures:_ |\
| The purpose of this conference is to aid the Government in determining whether prosecution will be recommended to DOJ. Therefore, it is an opportunity for you to present any evidence or information you have which you believe will influence the Government in its determination. However, even if prosecution is recommended, DOJ will make its own de novo review of the case. DOJ may also accept the case as submitted, if prosecution is recommended, in which instance the case will then be forwarded to the appropriate US Attorney for prosecution. |\
| As a result of this conference today, prosecution may also be declined by this office, in which instance the case will not be sent to the DOJ, but rather will be returned to the IRS for civil processing. |\
| Regardless of whether prosecution is recommended or declined by this office, you and/or your representatives will be notified by this office of our decision. |\
\
| _VI. Civil Figures:_ |\
| --- |\
| Year | Additional Tax | Fraud Penalty | Total Additional Tax & Penalties |\
| 1985 | $16,156.17 | $ 8,078.09 | $ 24,234.26 |\
| 1986 | $25,927.71 | $12,963.86 | $ 38,891.57 |\
| 1987 | $36,476.22 | $18,238.11 | $ 54,714.33 |\
|  | $76,560.10 | $39,280.06 | $117,840.16 |\
\
| These figures are only recommendations of the civil tax liabilities for the years in question. They are not necessarily the same as the criminal tax figures and, since they are only recommendations, are subject to change. |\
| --- |\
| _VII. Criminal Penalties_ |\
| In the event that prosecution is recommended, the potential criminal penalties to which you would be subject if the recommended charges are sustained are: |\
| 1\. Imprisonment: Up to three (3) years for each count, i.e., up to a maximum of nine (9) years; |\
| AND/OR |\
| 2\. Fine: Up to $250,000 \[$500,000 if corporation\] for each count, i.e., up to a maximum of $750,000 \[$1,500,000 if corporation\]. |\
| _VIII. General Considerations:_ |\
| You should also know that although this conference today will be directed to the specific charges recommended which have already been discussed, this office is in no way limited to such charges, and may, in appropriate cases, recommend other charges as well. Therefore, bearing this fact in mind, as well as your Constitutional right to remain silent, we may proceed with a discussion of the case as recommended. I will be making notes of this discussion, and you or your representative may also make notes if you wish. |\
\
**Exhibit 38.3.1-8**\
\
### Sample Conference Memorandum\
\
| (Symbols) |\
| --- |\
| **CONFERENCE MEMORANDUM** |\
| In re: | John Doe<br> Los Angeles, California | (Date) |\
| APPEARANCES: |\
|  |  | For Taxpayer: | \[Name\]<br> Attorney |  |\
|  |  |  | John Doe<br> Taxpayer |  |\
|  |  | For Government: | \[Name\]<br> Special Agent in Charge |  |\
|  |  |  | \[Name\]<br> Criminal Tax Attorney |  |\
| A conference was held in the above-captioned case on \[Date\] at \[Time\]. This was the first conference held in this office in this matter. A power of attorney and declaration of authority to practice has previously been filed with the Service authorizing \[Attorney representing taxpayer\] to represent John Doe before the Service. |\
| \[Attorney representing taxpayer\] informed \[SAC\] that his client had been informed of his _Miranda_ warnings and knew his rights. \[SAC\] then informed \[Attorney representing taxpayer\] of the proposed charges, years, method of proof, and civil figures. |\
| The taxpayer was reminded that plea bargaining, civil settlement, negotiations and/or compromise of the tax liabilities involved would not be considered or discussed at this conference. In addition, the taxpayer was informed of the recommended criminal charges, years and method of proof being considered, and that if the SAC determines those charges, or others, are appropriate, a prosecution recommendation will be forwarded to DOJ for its consideration. If DOJ concludes that criminal prosecution is warranted, the matter will then be forwarded to the US Attorney’s office for indictment. The taxpayer was also informed of his/her conference opportunity with DOJ in Washington, D.C. Finally, the taxpayer was told that if the SAC concludes prosecution is not warranted, he/she will be notified, in writing, that his/her case is being returned to IRS for civil consideration. |\
| \[Discuss who said what.\] |\
| The conference was terminated at \[Time\]. |\
|  |  |  |  | \\_\\_\\_\_\_\_<br> \[Name\]<br> Special Agent in Charge |\
|  |  |  |  | \\_\\_\\_\_\_\_<br> \[Name\]<br> Criminal Tax Attorney |\
|  |  |  |  |  |\
| NOTED: \_\_\_\_\_\_<br> Date dictated |\
| \\_\\_\\_\_\_\_<br> \[Name\]<br> Area Counsel |\
\
**Exhibit 38.3.1-9**\
\
### Sample Criminal Evaluation Memorandum\
\
| **\[CAUTION: CONTAINS GRAND JURY INFORMATION\]** or<br>_This heading should appear if the CEM contains grand jury information._ |\
| --- |\
| **\[NOTE: COUNSEL HAS CLASSIFIED THIS CASE AS NON-COMPLEX CASE\]**<br>_This heading should appear if the administrative case is designated non-complex._ |\
| CC:CT:XXX:- -03 |  | Date |\
| MEMORANDUM FOR SPECIAL AGENT IN CHARGE, XX FIELD OFFICE |\
| FROM: | \[Criminal Tax Attorney/Senior Counsel\], XX POD |\
| SUBJECT: | Evaluation of SAR and Exhibits **\[Administrative or Grand Jury\]** Tax Case |\
| **CRIMINAL SUBJECTS(S)** |\
|  |  | Name<br> Address<br> SSN |\
|  |  | Related Case(s) _If related cases(s), provide the names(s) of the criminal subject(s)._ |\
| **COUNSEL'S RECOMMENDATION** |\
|  | **Charge(s)** | **Year(s)** |  | **Count(s)** |\
| _If Counsel believes prosecution is warranted, one of these sentences should follow:_<br> This recommendation concurs with the Special Agent's recommendation.<br> This recommendation differs from the Special Agent's recommendation and will be explained below. |\
| _If Counsel believes prosecution is not warranted, then this sentence should follow "COUNSEL'S RECOMMENDATION" , and there is no need for "Charge(s), Year(s), Count(s)" :_<br> In our opinion, prosecution is not warranted in this matter. |\
|  | **Venue** | **Statute of Limitations**<br> Bold the Statute of Limitations date if imminent. |\
| **EXECUTIVE SUMMARY** |\
| In a nutshell, either **in a short paragraph or using bullets**, summarize the subject's actions that give rise to the criminal prosecution recommendation as well as relevant information important to the reader of this document. For instance, include or note: the amount of tax dollars (including relevant conduct); harm to the government; the indirect method of proof; an expiring statute of limitations; investigative techniques; and the technical tax issues(s). For example: |\
|  | **• Questionable Return Preparer**<br>**• Undercover Investigation**<br>**• Twenty-five false returns**<br>**• $250,000 of tax harm including relevant conduct** |\
| **CRIMINAL VIOLATIONS(S) AND DISCUSSION OF THE LAW**<br>**Elements of the offense**<br> Discuss the principal evidence available to establish the elements of the criminal offense(s). Please cite Supreme Counsel and/or your specific Circuit Court law, when applicable. |\
| **Element #1**<br> Use subheadings for each element of the proposed offense. Set forth items of evidence with bullets to separate and give the reader and idea of how many exhibits/how much evidence there is on a given element. |\
|  | **• EVIDENCE** |\
| **Element #2** |\
|  | **• EVIDENCE** |\
| **Element #3** |\
|  | **• EVIDENCE** |\
| Discuss any legal, procedural, and/or policy issues regarding: (1) venue; (2) statute of limitations; (3) how the investigation originated (when and by whom the taxpayer was first contacted); (4) investigative techniques; (5) aspects of personal history of significance to the case; age, marital status during the years at issue (especially in community property states), health (if a major problem is known), education and criminal record. |\
| **TAX LOSS, COMPUTATIONS, METHOD OF PROOF AND TECHNICAL TAX ISSUES**<br> Every case may not have a Technical Tax Issue, so this heading will only be utilized when applicable. Note the tax loss, computations and method of proof. When an indirect method of proof is utilized, additional discussion on the method of proof is warranted. When warranted, provide a further discussion. Discuss any tax or tax-related issues or any technical tax issues, e.g., a trust fraud case would include a discussion of the issue of whether a trust was a sham for tax purposes; a case involving a tax shelter promotion would discuss the merits of underlying shelter; etc. Other technical tax issues include: providing the actual line item of the return which is false; _Greenberg_ problem in both specific items and indirect method of proof cases; earnings and profits in corporate diversion cases; failure to file involving one married taxpayer (joint or separate tax rates/community property). Also discuss coordination with other Counsel functions. |\
| **CURRENT LIFESTYLE**<br> Bring the case up-to-date. Update information relative to each subject's current lifestyle; job history (is the subject working on the same job); filing history (the recommended offense may be failure to file, but the subject has since been current in filing tax returns); audit history _(i.e._, was the subject cooperative or obstructive during prior contact with the Service); etc. Note, if this information is relevant to the case and it is not readily available to the agent, then discuss this in the **OTHER ISSUES AND SUGGESTIONS** section. |\
| **DEFENSES**<br> Discuss defense contentions or reasonably probable defenses and available rebuttal evidence. When no defenses are foreseeable, so note. |\
| **OTHER ISSUES AND SUGGESTIONS**<br>_This heading is optional and should be utilized when applicable._<br> Discuss problems/issues/concerns with the case. For example, a key witness may have died. Discuss suggestions where the case can be improved. For example, there is an additional witness that should be interviewed; the accountant/return preparer’s testimony may need to be tied down in the grand jury; additional expenses may need to be investigated. |\
| **SENTENCING**<br> In either a short paragraph or by using bullets, summarize sentencing, including the base offense level, specific offense characteristics, and proposed adjustments for aggravating or mitigating offense related conduct. For example: |\
|  | **• TAX LOSS - $250,000 (includes relevant conduct)**<br>**• BASE OFFENSE LEVEL - 18 (2001 Book)**<br>**• NOTE POSSIBLE ENHANCEMENTS and/or REDUCTIONS** |\
| **CONCLUSION**<br> After careful consideration, we are **\[convinced/not convinced\]** that the evidence relied upon to support the recommended prosecution is sufficient to indicate guilt beyond a reasonable doubt and that there **\[is/is not\]** a reasonable probability of conviction. |\
| We are closing our file in this case as of the date of this memorandum. Please be advised that the "referral" of this matter will remain in effect until terminated within the meaning of I.R.C. § 7602(d)(2)(B). |\
| Should you have any questions about this memorandum, please contact the undersigned at xxx-xxx-xxxx. |\
|  |  |  |  |\
|  |  |  | XXXXXXXXXXXX<br> Area Counsel (XXX), Criminal Tax |\
|  |  | By: | \\_\\_\\_\_\_\_\_\_\_<br> NAME<br> Criminal Tax Attorney |\
\
**Exhibit 38.3.1-10**\
\
### Sample Search Warrant Evaluation Memorandum\
\
| **Office of Chief Counsel**<br>**Internal Revenue Service**<br>**MEMORANDUM** |\
| :-- |\
| CC:CT:**\[POD\]**:CT-\_\_\_\_\_-18<br> Attorney First and Middle Initials/Last Name |\
| --- |\
| **CAUTION: CONTAINS GRAND JURY INFORMATION \[if applicable\]** |\
| date: |  |\
| to: | Special Agent in Charge, \_\_\_\_ (Criminal Investigation)<br>**\[if sensitive SW: Director, Field Operations, \_\_\_\_ Area (Criminal Investigation)\]** |\
| from: | \_\_\_\_\_\_, Criminal Tax Attorney _(City, State)_<br>**\[if sensitive SW: \_\_\_\_, Division Counsel/Associate Chief Counsel (Criminal Tax)\]** |\
| subject: | **Evaluation of Search Warrant Application** |\
|  |  |  | **Target(s) of the Investigation:** |\
|  |  |  | Name, Title**\[if applicable\]** |\
|  |  | Premises to be Searched: **\[If multiple locations, list each separately, including respective CT#\]** |\
| We conclude the affidavit and attachments \[establish/do not establish\] probable cause to believe: (1) violations of federal law have been committed; (2) evidence of those violations will be found at the location(s) to be searched; (3) the location(s) to be searched and the evidence to be seized are described with sufficient particularity; and \[only in tax and tax-related investigations\] (4) the search warrant is the least intrusive means of obtaining the evidence sought. |\
| - _Summarize concerns and/or recommendations (e.g., over breadth of items to be seized, time period too expansive)._<br>  <br>- _If there are several recommendations and/or concerns, consider using a numbered list._ |\
| **EXECUTIVE SUMMARY** |\
| The search warrant application **\[or package\]** seeks authorization to search the above-mentioned location(s) in connection with an **\[administrative/grand jury\]** investigation involving \_\_\_\_\_\_\_ **\[if relevant, state that target is an attorney, physician, etc.\]**. |\
| - _Briefly describe alleged criminal conduct in 1-2 sentences (if possible)._<br>  <br>- _List criminal statutes, the offenses they reference, and the specific time period._ |\
| **\[Add in the case of a sensitive search warrant\]** Review of this search warrant package has been centralized within the Office of Division Counsel/Associate Chief Counsel (Criminal Tax) because the locations to be searched are owned or controlled by a \_\_\_\_\_\_\_\_\_\_\_\_\_, a sensitive target under IRM 38.1.1.3.1(5). |\
| **FACTS** |\
| - _Provide a brief description of the investigation to date **\[Add a sentence on background of investigation - source of investigation\]**. Use your own words; do not cut and paste from the affidavit. Use neutral facts; no legal conclusions._<br>  <br>- _Use subheadings to organize the important facts of your case._<br>  <br>- _Summarize the salient facts in 2-3 pages, or less. There is no need to include everything that is in the affidavit. Tell a story._ |\
| **LAW AND ANALYSIS** |\
| The Fourth Amendment of the Constitution requires that a search warrant be issued only upon a showing of probable cause to believe that a crime has been committed and evidence of that crime will be found at the location to be searched, and only if the place to be searched and the items to be seized are described with sufficient particularity. \[In tax and tax-related investigations include the following\] In addition, pursuant to IRM 9.4.9.2(5) and (6), the warrant must be the least intrusive means available to obtain the information sought. |\
| **A. Probable Cause** |\
| The Fourth Amendment states that “no warrants shall issue but upon probable cause, supported by oath or affirmation\[.\]” U.S. CONST. Amend. IV. The determination of probable cause involves a “practical, common-sense decision” that is based on a “totality of the circumstances analysis.” SeeIllinois v. Gates, 462 U.S. 213, 238 (1983). The Supreme Court has held that probable cause exists where “the known facts and circumstances are sufficient to warrant a man of reasonable prudence in the belief that contraband or evidence of a crime will be found\[.\]” Ornelas v. United States, 517 U.S. 690, 696 (1996). There must be “a reasonable ground for belief of guilt,” which means “more than bare suspicion\[.\]” Brinegar v. United States, 338 U.S. 160, 175 (1949). **\[Keep Supreme Court law and add relevant, recent Circuit law\]** |\
| In order to establish probable cause, the written affidavit must set forth facts and circumstances to show that (1) a reasonable person would be justified in believing that “an offense has been or is being committed;” and (2) there is a “fair probability” that evidence of the offense “will be found in a particular place.” Brinegar, 338 U.S. at 175; Gates, 462 U.S. at 238. **\[Keep Supreme Court law and add relevant, recent Circuit law\] \[If search of cell phone is contemplated, cite Riley v. California, 134 S. Ct. 2473 (2014); if search will involve use of GPS, cite United States v. Jones, 132 S. Ct. 945 (2012)\]** |\
|  | **1\. Probable Cause to Believe a Crime Has Been Committed** |\
| - _If bullets are used, they should be sufficiently detailed and include full sentences; The bullets should be preceded by an introductory paragraph._ |\
| The following facts from the affidavit support probable cause to believe violations of the following statute(s) have been committed: |\
| - **\[Statute #1\]** |\
|  | - _List the facts that support probable cause to believe the target committed the alleged violations under each statute._ |\
| _State your conclusion (i.e., whether we believe the affidavit sets forth sufficient probable cause to believe the target committed the alleged violations)._ |\
| _Describe any concerns or recommendations regarding this prong of the probable cause requirement._ |\
|  | **2\. Probable Cause to Believe Evidence of Crimes Will Be Found at the Location\[s\] to be Searched** |\
| - _If bullets are used they should be sufficiently detailed and include full sentences; The bullets should be preceded by an introductory paragraph._ |\
| The following facts from the affidavit establish probable cause to believe that evidence of the alleged offenses will be found at the location\[s\] to be searched. **\[Examples may include evidence derived from surveillance, undercover activity, trash runs, mail covers, etc.\]** |\
| - _List the facts that support probable cause to believe evidence of the alleged crime(s) will be found at the location(s) to be searched._<br>  <br>- _If multiple locations, list each one separately using the format under 1, above (PC to believe crime(s) were committed)._ |\
| _State conclusion (i.e., whether affidavit sets forth sufficient probable cause to believe evidence of the alleged violations will be found\]._ |
| _Describe any concerns or recommendations regarding this prong of the probable cause requirement._ |
|  | **3\. Staleness \[Include this section only if relevant\]** |
| - _Include discussion of relevant case law and apply to facts._ |
| **B. Particularity** |
| In addition to requiring that a search warrant be issued only “upon probable cause,” the Fourth Amendment mandates that the warrant “particularly describ\[e\] the place to be searched, and the persons or things to be seized.” U.S. CONST. Amend. IV. A lack of particularity will render a warrant invalid regardless of whether probable cause has been established. See, e.g., United States v. Bridges, 344 F.3d 1010, 1015 (9th Cir. 2003). In order to satisfy the particularity requirement, the warrant must enable the executing officer to locate and identify the place to be searched and the items to be seized “with reasonable effort” and “to avoid mistakenly searching the wrong places or seizing the wrong items.” Steele v. United States, 267 U.S. 498, 503 (1925). Further, the warrant must clearly limit the authorization to search to “the specific areas and things for which there is probable cause to search.” Maryland v. Garrison, 480 U.S. 79, 84 (1987). The Supreme Court has made clear that the Fourth Amendment prohibits “open-ended” or “general” warrants. See, e.g., Steagald v. United States, 451 U.S. 204, 220 (1981); Andresen v. Maryland, 427 U.S. 463, 492 (1976) (“The problem to be avoided is ‘not that of intrusion per se, but of a general, exploratory rummaging in a person's belongings.’”) (citation omitted). **\[Keep Supreme Court law and add relevant, recent Circuit law\]** |
| We note that “\[t\]he Fourth Amendment by its terms requires particularity in the warrant, not in the supporting documents.” Groh v. Ramirez, 540 U.S. 551, 557 (2004). **\[cite recent relevant Circuit law indicating whether the affidavit and attachments are required to be attached to the warrant or incorporated by reference\]** Here, the attachments describing the place to be searched and the items to be seized **\[are/are not\]** expressly incorporated by reference in both the affidavit and the warrant itself. Because some courts require that the affidavit and its attachments be incorporated into the warrant by reference and also attached thereto, we recommend that both measures be taken. |
|  | **1\. Location\[s\] to be Searched** |
| - _Describe the information that is provided with respect to the location to be searched (e.g., address, photo, detailed description, etc.). Summarize the information provided rather than quoting from the attachment to the affidavit._<br>  <br>- _State your conclusion as to whether the level of detail provided is sufficient to satisfy the particularity requirement with respect to the location to be searched._<br>  <br>- _Describe any concerns or recommendations._ |
| **\[If a multi-district search and/or seizure of electronically stored information or electronic devices is expected, the memorandum should Rule 41(b)(6), pursuant to which magistrate judges may authorize warrants that allow federal agents to remotely access computers (and other devices) and to seize information stored on those computers, regardless of where the computers are physically located if either: (i) the computer user has used technology to hide the computer’s location; or in a computer hacking investigation; or (ii) if the affected computers are located in five or more judicial districts. In this case, federal agents may apply for a warrant in any of those districts.\]** |
|  | **2\. Items to be Seized** |
| - _Describe what is included in the list of items to be seized. Summarize the types of items sought rather than quoting from the attachment to the affidavit. Note whether the items are limited to the alleged offenses and the relevant time period under investigation._<br>  <br>- _State your conclusion as to whether the level of detail provided is sufficient to satisfy the particularity requirement with respect to the items to be seized. Is the list clearly limited to those items for which there is probable cause?_<br>  <br>- _If there is more than one location to be searched, consider whether the lists of items to be seized are separately tailored to each location (they should be)._<br>  <br>- _If the warrant seeks all the records of a business, discuss whether the affidavit alleges sufficient facts to support a “permeated with fraud” theory. See the Search Warrant Handbook for discussion of this issue._<br>  <br>- _Describe any concerns or recommendations._ |
| **\[If proposed search involves electronic evidence or electronic storage media, add particularity concerns in Ganias and progeny and recommend that IRS-CI do its best to narrow the search locations and items to be seized and address the disposition on nonresponsive items. Sample language may include:\]** |
| In United States v. Ganias, 755 F.3d 125 (2d Cir. 2014), a panel of the Second Circuit held the government violated the Fourth Amendment when it retained non-responsive records obtained through the imaging of the defendant’s computer as part of the execution of a prior search warrant and then sought to search these nonresponsive records over two years later pursuant to a new warrant. The panel further held that the good-faith exception to the exclusionary rule did not apply because the government did not establish it acted in good faith. On rehearing en banc, the Second Circuit reversed the panel’s decision, holding the good-faith exception to suppression applied in this case. The court, however, expressly declined to rule on the Fourth Amendment issue. Although the court recognized there may be legitimate evidentiary reasons to image and retain an entire hard drive, it left the question open on these facts. |
| More recently, in United States v. Ulbricht, 858 F.3d 71 (2d Cir. 2017), the Second Circuit acknowledged that the Fourth Amendment’s particularity requirement is especially important in computer searches because of the vast trove of personal information that is seized and retained by the government. The court also recognized, however, that the nature of digital storage makes it unfeasible to extract and segregate responsive from non-responsive data. In balancing these two competing interests, the Second Circuit cautioned the government that while the description of the items to be seized in electronic searches need not be perfect to meet the particularity requirement, the government must acquire and include all descriptive facts which a reasonable investigation could be expected to cover. |
| In light of Ganias and Ulbricht, we recommend that IRS-CI work with prosecutors to limit the scope of search and seizures and ensure proper disposal of nonresponsive electronic files and documents under local rules. **\[Please update citations and research any legal updates\]** |
| **\[If warrant is directed to ISP and involves search/seizure of electronic records that may be stored in ISP’s foreign server(s) add the following language\]:** |
| Before March 23, 2018, it was unclear whether the Stored Communications Act (“SCA”) applied to electronic records stored by electronic communication service providers outside the U.S. The issue was settled on March 23, 2018, when Congress passed the Clarifying Lawful Overseas Use of Data (“CLOUD”) Act. The Act expressly provides for the extraterritorial application of the SCA by requiring electronic-communication providers to comply with all SCA requirements, e.g., preserve, backup, and disclose the contents and records of subscribers’ electronic communications, regardless of whether the communications or records are located within or outside the U.S. This portion of the law addresses the issue that was pending before the Supreme Court in United States v. Microsoft, 829 F.3d 197 (2d Cir. 2016), cert. granted, 138 S. Ct. 356 (2017), i.e., whether a U.S. provider of email services must comply with a probable-cause-based warrant issued under 18 U.S.C. § 2703 by making disclosure in the United States of electronic communications within that provider’s control, even if the provider has decided to store that material abroad. In light of the passage of the CLOUD Act, on April 17, 2018, the Supreme Court dropped the Microsoft case after both sides said a new federal law stripped the case of any practical significance. **\[Please update citations and research any legal updates\]** |
| **\[If the warrant involves compelling an individual to use his/her fingerprints to unlock an electronic device, please note that case law on this issue is limited, conflicting, and unsettled. Please remember to elevate to the National Office Review Team (NORT) and to research any recent legal developments on this issue.\]** |
| **C. Taint Team \[include this section only if relevant\]** |
| - _If the location to be searched is owned or controlled by an accountant, lawyer, or physician, this section should discuss any potential privilege or privacy issues and recommend the use of a taint team. See IRM 38.1.1.3.4(1)(I)._ |
| **D. Delayed Notice \[include this section only if relevant\]** |
| - **Rule 41(f)(3) allows federal agents to request, and magistrate judges to authorize, delayed notice of the search, but only “if the delay is authorized by statute.” See 18 U.S.C. § 3103a (authorizing delayed notice in limited circumstances). The memorandum should discuss whether delayed notification is appropriate and set forth any delayed notification requests under Rule 41(f)(3).** |
| **D. Least Intrusive Means \[Only if tax or tax-related investigation\]** |
| IRS policy limits the use of search warrants in tax and tax-related investigations to situations in which a warrant is the least intrusive means of obtaining the evidence sought. See IRM 9.4.9.2(5) and (6). We **\[were/were not\]** provided with a Form 13739, Enforcement Action Review, explaining why a search warrant is the least intrusive means available for obtaining the evidence sought. |
| - _Discuss the EAR’s explanation and whether it is sufficient to satisfy this requirement._<br>  <br>- _If no EAR was provided, discuss whether the affidavit includes facts to support the conclusion that a search warrant is the least intrusive means available._<br>  <br>- _Make recommendations as necessary (including possible alternatives to a search warrant, if applicable)._ |
| **\[If items to be seized include emails, include the following language re IRS Warshak policy\]**Policy Statement 4-120, approved May 3, 2013, provides that the IRS will follow the holding in United States v. Warshak, 631 F.3d 266 (6th Cir. 2010), and obtain a search warrant in all cases when seeking from an internet service provider (“ISP”) the content of e-mail communications stored by the ISP. |
| **CONCLUSION** |
| We conclude the probable cause and particularity standards **\[have/have not\]** been satisfied. Moreover, we conclude the proposed search warrant **\[represents/does not represent\]** the least intrusive means of obtaining the information sought **\[Only in tax and tax-related investigations\].** |
| Should further assistance be required, please contact \_\_\_\_\_\_\_\_\_\_ at (XXX) XXX-XXXX. |
| cc: Area Counsel (XXXX), Criminal Tax<br> SAC, XXXX (Criminal Investigation) **\[in case of sensitive search warrant\]**. |

**Exhibit 38.3.1-11**

### Sample Grand Jury Request Memorandum

![This is an Image: 39139001.gif](https://www.irs.gov/pub/xml_bc/39139001.gif)

> First page of the Sample Grand Jury Request Memorandum.

[Please click here for the text description of the image.](https://www.irs.gov/media/216421 "")

![This is an Image: 39139002.gif](https://www.irs.gov/pub/xml_bc/39139002.gif)

> Second page of the Sample Grand Jury Request Memorandum.

[Please click here for the text description of the image.](https://www.irs.gov/media/216426 "")

![This is an Image: 39139003.gif](https://www.irs.gov/pub/xml_bc/39139003.gif)

> Third page of the Sample Grand Jury Request Memorandum.

[Please click here for the text description of the image.](https://www.irs.gov/media/216431 "")

![This is an Image: 39139004.gif](https://www.irs.gov/pub/xml_bc/39139004.gif)

> Fourth page of the Sample Grand Jury Request Memorandum.

[Please click here for the text description of the image.](https://www.irs.gov/media/216436 "")

![This is an Image: 39139005.gif](https://www.irs.gov/pub/xml_bc/39139005.gif)

> Fifth page of the Sample Grand Jury Request Memorandum

[Please click here for the text description of the image.](https://www.irs.gov/media/216441 "")

**Exhibit 38.3.1-12**

### Sample Undercover Evaluation Memorandum

| **Office of Chief Counsel**<br>**Internal Revenue Service**<br>**MEMORANDUM** |
| :-- |
| CC:CT:**\[POD\]**:CT-\_\_\_\_\_-XX<br> Attorney First and Middle Initials/Last Name |
| --- |
| **CAUTION: CONTAINS GRAND JURY INFORMATION \[if applicable\]** |
| date: |  |
| to: | SPECIAL AGENT IN CHARGE, \_\_\_\_ **\[SAC LOCATION\]** |
| from: | \_\_\_\_\_\_, Criminal Tax Attorney/**Senior Counsel** _**(**City, State)_<br>**\[if case is reviewed by NORT, Area Counsel should appear on signature line\]** |
| subject: | **Review of Request for \[Group I or Group II\] Undercover Operation** |
|  |  | CRIMINAL SUBJECT\[S\] \[delete \[s\] if only one subject\]: |
|  |  |  | **Name**<br>**Address**<br>**CT CASE # \[if more than one subject\]** |
| By email dated **\[insert date\]**, Criminal Investigation ("CI" ) requested the assistance of Criminal Tax Counsel ("CT Counsel" ) in reviewing a request to conduct a **\[Group I or Group II\]** undercover operation related to **\[name of subject(s)\]**. The proposed undercover operation is part of the existing **\[insert Undercover Name and Undercover Number\]**. Based on the information presented, we conclude that the proposed undercover operation **\[meets/does not meet\]** the requirements found in Internal Revenue Manual ("IRM" ) § 9.4.8.4(3)(a) for conducting an undercover operation, including that it **\[meets/does not meet\]** the reasonable person standard for belief that the target is in violation of the law. We further conclude that the operation **\[does not raise/raises\]** an issue of entrapment. **\[If the proposed operation raises an issue of entrapment, add an explanatory sentence, e. g. the evidence fails to establish that target was predisposed to commit this crime\]**. **\[Insert any noteworthy concerns with undercover operation, if any, here\]**. |
| **SCOPE OF CT REVIEW** |
| IRS-CI is required to consult CT Counsel in all undercover operations. CT Counsel’s role in an undercover operation is to render legal advice on all aspects of the operation, as well as attending all pre-operational and operational meetings. IRM § 38.1.1.4(4) and (5). |
| **\[The views of the assigned AUSA should not be discussed in the undercover memo. CT Counsel’s review is independent of the AUSA’s opinion\]** |
| **STANDARD OF REVIEW** |
| In evaluating the request to conduct an undercover operation, CT Counsel must determine whether the information obtained to date would lead a reasonable person to believe the target is in violation of the law. See IRM § 9.4.8.4(3). |
| **EXECUTIVE SUMMARY** |
| \[Provide a succinct summary of the case. Tell a story: what is the case about, in one or two paragraphs. Write in full sentences; do not use bullets. Do not duplicate verbatim from the Facts section\]. |
| **FACTS** |
| \[Bullets are used for convenience - facts should be in paragraph form\] |
|  | • Keep the tone of the facts neutral and avoid legal conclusions. |
|  | • Tell a coherent story. Do not list the facts verbatim from the IRS-CI undercover memo. Use your own words. |
|  | • Identify the source of the information (e.g., information provided by the special agent or information found by CI). |
|  | • Identify the origin/source of the case (e.g., NCIU), whistleblower, fraud referral, etc.). |
|  | • If known, discuss whether the target is represented by counsel. If so, note whether the representation is in connection with the matter under investigation. |
|  | • If the source of the case is a confidential informant, address the individual’s trustworthiness, including past history and any corroboration for the information provided. |
|  | • If the confidential informant will be paid for the information provided, note that a Memorandum of Understanding will be needed. The MOU must be provided by GLS and CT. |
|  | • If the information has criminal exposure, note whether those issues have been resolved. Address whether a cooperation agreement has been reduced to writing. |
|  | • If applicable, discuss whether the information provided is tainted, e.g. attorney-client privilege. |
|  | • When introducing individuals/entities, provide background (e.g., education, training, entity type/tax type, etc.) |
|  | • Insert subsections to enhance presentation of factual details. |
| **TARGETING CRITERIA** |
| The proposed undercover operation meets the following approved targeting criteria set forth in the **\[insert Undercover Name and Undercover Number\]**:<br> <br>- List the targeting criteria that the proposed undercover operation meets from the annual blanket authorizations. Bullet points may be used. These are typically identified in the IRS-CI memo. |
| **PROPOSED OPERATION** |
| **\[This section should be in paragraph form\]** |
|  | • State which Code sections IRS-CI believes the target has violated. Insure that a crime has been articulated and that IRS-CI does not intend to engage in indiscriminate surveillance. |
|  | • Describe the proposed undercover operation. Insure that there is an alignment between the crime articulated and the proposed plan of action. |
|  | • Discuss any undercover equipment that will be used in the proposed operation. |
|  | • If a confidential informant will be used, note any issues that may arise and any precautions IRS-CI has taken. |
|  | • If a confidential informant will be used in the operation, note whether that individual has a minimal role in the scheme, or based upon the specific facts of the case, whether the target is likely to discuss details of the scheme with the informant or individual. Using that individual may result in a failed undercover operation, thus undermining the investigation by creating _Brady material_. |
|  | • If there is a possibility the targets of the operation may be involved in terrorism, note that IRS-CI should run the target(s) name(s) through a terrorist watch list to insure that we are not transacting funds with a known terrorist organization. |
|  | • If the case presents international issues, confirm that all appropriate approvals and authorizations are obtained, including consensual monitoring authority. |
|  | • If the plan of action is not likely to result in a successful operation, e.g. a false return being prepared, note that it may create _Brady material_. |
|  | • Identify any pertinent evidentiary issues. For example, does the plan of action, call upon the target to make incriminating statements about past conduct as opposed to commenting on, or taking action related to, an ongoing scheme. If the former, what is the likely probative value of the evidence CI is trying to obtain, and is it likely to add to the sum total of evidence already in hand? |
| **OBJECTIVES** |
| The objectives of this undercover operation are a follows: |
|  | • List the objectives in CI’s undercover memo. They may be listed in bullet point format. |
|  | • If IRS-CI has too many objectives for the proposed operation, suggest that the operation be narrowed to meet fewer objectives. |
| **ANALYSIS** |
| I. | Reasonable Person Standard of Review |
|  | • Analyze whether or not the information presented would lead a reasonable person to believe that the target is in violation of the law. State this conclusion. |
|  | • Note the facts that support this conclusion. |
|  | • If appropriate, reiterate concerns previously expressed in prior CT CEMs involving the target; in particular, if we concluded previously there were not articulable facts that a crime has been committed. |
|  | • Discuss information provided by any confidential informants or cooperating witnesses. |
| II. | Entrapment |
| Undercover operations have long been sanctioned by the courts. The entrapment defense is a judicially created doctrine. _United States v. Diaz-Maldonado_, 727 F.3d 130, 139 (1st Cir. 2013) (quoting _United States v. Teleguz_, 492 F.3d 80, 84 (1st Cir. 2007)). Therefore, the doctrine must take into account the difficulties faced by law enforcement. _Id._ Predisposition to commit the crime is the primary legal issue. In entrapment cases, courts draw the line between undercover operations to ensnare criminals and undercover operations to ensnare innocent citizens. |
| **\[Insert Circuit specific entrapment law from Appendix\]** |
|  | • Analyze all relevant factors. |
|  | • Address whether the government has induced the target to commit a crime. |
|  | • Address whether the defendant was predisposed to commit the crime. Include any evidence that the defendant knows his or her conduct is illegal. |
| **_Brady, Giglio_ and Other Evidentiary Issues/Suggestions** |
|  | • This section should analyze the undercover operation from an evidentiary perspective. CT attorneys should consider how likely the operation is to generate _Brady/Giglio material_. Those considerations should be balanced with the probative value of any evidence generated by the undercover. |
|  | • This section should also address any other issues that are presented or may arise in the undercover operation. |
| **CONCLUSION** |
| For the foregoing reasons, we believe that the proposed undercover operation **\[is/is not\]** legal, **\[meets/does not meet\]** the reasonable person standard and **\[does not raise/raise\]** any entrapment issues. **\[If the proposed operation raises an issue of entrapment, repeat the explanatory sentence from the beginning of the memo\]**. We request that our office be notified or any pre-operational meetings. |
| **\[If the case is a grand jury investigation, insert the following paragraph:\]** |
| Access to and knowledge of grand jury material will be restricted solely to those counsel personnel who provided assistance to the grand jury. Please advise the Department Of Justice Tax Division and/or the United States Attorney’s Office that the following names should be added to the list required to be maintained pursuant to Federal Rules of Criminal Procedure Rule 6(e)(3)(B): **\[Include list of the Area Counsel, all local CT attorneys, National Office CT attorneys and support personnel who will have access to the file\]**. |
| If you have any questions or concerns about this matter, please contact **\[insert name of CT attorney\]** at **\[insert phone number\]**. We will be available to provide any additional assistance as needed. |
|  |
| cc: | Area Special Agent in Charge **\[insert name\]**<br> Supervisory Special Agent **\[insert name\]**<br> Special Agent **\[insert name\]**<br> Area Counsel (CT) **\[insert name\]**<br> Deputy Area Counsel (CT) **\[insert name\]** |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part38/irm_38-003-001#addtoany "Show all")

A2A