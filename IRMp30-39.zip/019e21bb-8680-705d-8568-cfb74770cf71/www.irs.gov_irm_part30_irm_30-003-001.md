---
url: "https://www.irs.gov/irm/part30/irm_30-003-001"
title: "30.3.1 Chief Counsel Delegations, Organization, and Succession | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part30/irm_30-003-001#main-content)

- 30.3.1 [Chief Counsel Delegations, Organization, and Succession](https://www.irs.gov/irm/part30/irm_30-003-001#idm140198816784576)
  - 30.3.1.1 [Introduction of Section](https://www.irs.gov/irm/part30/irm_30-003-001#idm140198829638592)
  - 30.3.1.2 [Authority Delegated to the Chief Counsel for the Internal Revenue Service](https://www.irs.gov/irm/part30/irm_30-003-001#idm140198816783456)
  - 30.3.1.3 [Application of Delegation Principles under the Internal Revenue Code and IRS Internal Management Document System](https://www.irs.gov/irm/part30/irm_30-003-001#idm140198855365904)
  - 30.3.1.4 [Joint Delegation Orders](https://www.irs.gov/irm/part30/irm_30-003-001#idm140198855363264)
  - 30.3.1.5 [Interpretive Authority](https://www.irs.gov/irm/part30/irm_30-003-001#idm140198855356656)
  - 30.3.1.6 [Organization](https://www.irs.gov/irm/part30/irm_30-003-001#idm140198855353488)
  - 30.3.1.7 [Acting Chief Counsel under the Federal Vacancies Reform Act and Other Matters of Succession](https://www.irs.gov/irm/part30/irm_30-003-001#idm140198831193200)

# Part 30. Administrative

# Chapter 3. Organizations, Functions, Designations, and Delegations of Authority

# Section 1. Chief Counsel Delegations, Organization, and Succession

* * *

## 30.3.1 Chief Counsel Delegations, Organization, and Succession

#### Manual Transmittal

November 20, 2017

#### Purpose

(1) This transmits revised CCDM 30.3.1.7, Acting Chief Counsel under the Vacancies Reform Act and Other Matters of Succession.

#### Material Changes

(1) This revision clarifies the role of the Deputy Chief Counsel (Technical) as the principal deputy.

(2) This revision updates order of succession in the absence of the Chief Counsel.

#### Effect on Other Documents

CCDM 30.3.1.7 dated January 12, 2017 is superseded.

#### Audience

Chief Counsel

#### Effective Date

(11-20-2017)

Mark Kaizen

Acting Associate Chief Counsel

(Finance and Management)

**30.3.1.1** **(12-17-2008)**

### Introduction of Section

1. This section describes the delegation of authority from the General Counsel to the Chief Counsel, the delegation principles and organizational structure for the Office of Chief Counsel, and the designation of an Acting Chief Counsel in the event of a vacancy.


**30.3.1.2** **(11-18-2011)**

### Authority Delegated to the Chief Counsel for the Internal Revenue Service

1. Section 7803(b)(2) of the Internal Revenue Code provides that the Chief Counsel shall perform such duties as the Secretary shall prescribe. The Secretary has broadly delegated the performance of the Department's legal activities and supervision of its lawyers to the General Counsel. (see Treas. Order Nos. 101-05, 107-04, and 107-07 at [http://www.treasury.gov/about/role-of-treasury/orders-directives/Pages/default.aspx](http://www.treasury.gov/about/role-of-treasury/orders-directives/Pages/default.aspx).) [General Counsel Order No. 4](http://intranet.treas.gov/General_Counsel/orders-dir/) is the principal delegation of authority from the General Counsel of the Department of the Treasury to the Assistant General Counsel, who is the Chief Counsel for the Internal Revenue Service. See also 31 U.S.C. § 301(f)(2).

2. The Commissioner of Internal Revenue has included the Chief Counsel, and certain other officials of the Office of Chief Counsel, in the delegation orders found in IRM 1.2.2, Delegations of Authority. These redelegable authorities of the Commissioner principally derive from Treas. Order 150-10 and the Internal Revenue Regulation. See Treas. Reg. 301.7701-9 (as to Commissioner's authority to delegate under the regulation). Exhibit 30.3.2-16 provides a list of Commissioner Delegation Orders that name the Chief Counsel or other officials in the Office as delegates or that historically have been regarded as making delegations to the Chief Counsel or other officials in the Office.

3. One purpose of this chapter is to redelegate various authorities delegated to the Chief Counsel or Chief Counsel subordinates by the General Counsel and the Commissioner and, where appropriate, to provide for restrictions or conditions on further redelegation. The delegations made in General Counsel Order No. 4 and IRM 1.2.2, Delegations of Authority are not repeated. Another purpose of this chapter is to set forth statements of organization and function of subordinate offices within the Office of Chief Counsel, which serve as delegations of authority to these organizations.


**30.3.1.3** **(07-21-2005)**

### Application of Delegation Principles under the Internal Revenue Code and IRS Internal Management Document System

1. In assessing whether or not a statutory assignment of responsibility under the Internal Revenue Code may be delegated, refer to IRC § 7701(a)(11)-(12) and Treas. Reg. § 301.7701-9.

2. Delegations of authority from the Commissioner to the Chief Counsel or to Chief Counsel subordinates by order should be interpreted in accordance with principles set forth in IRM 1.11.4, Delegation Orders.


**30.3.1.4** **(11-18-2011)**

### Joint Delegation Orders

1. Commissioner Delegation Orders that also derive from the authority of the Chief Counsel or that substantially affect the responsibilities of the Chief Counsel are signed by the Chief Counsel. The Commissioner's Office issues these orders in IRM 1.2.40 through IRM 1.2.64.

2. The current Joint Delegation Orders are:



   - Delegation Order 8–1, Appeals Functions, Settlement of Cases Docketed in the United States Tax Court (Supplemented by Delegation Orders 30-4 and 4-39)

   - Delegation Order 4-48, Authority to Sign Secured Employee Benefits Settlement Agreements

   - Delegation Order 4-30, Authority to Offer and Accept Settlement Offers and to Execute Closing Agreements Made under the Targeted Jobs Tax Credit Initiative


3. Although the Chief Counsel's signature is not noted on the delegation, Delegation Order 11-2, Authority to Permit Disclosure of Tax Information and to Permit Testimony or the Production of Documents, is issued, in part, under the authority of the Chief Counsel.


**30.3.1.5** **(07-21-2005)**

### Interpretive Authority

1. In order to promote the uniformity of interpretation of delegation orders in the Office and the Service, the Associate Chief Counsel, General Legal Services (GLS) is designated to provide necessary legal interpretations of all delegation orders of the Treasury, the Service, or other Government agencies that impact on the Service.

2. Whenever a delegation order affects a specific Chief Counsel office other than GLS, GLS will consult and coordinate with the office prior to issuing an opinion interpreting such delegation order.

3. Whenever a conflict of authority between the Commissioner and the Chief Counsel is raised in any delegation question, any opinion prepared by the Associate Chief Counsel (GLS) will be reviewed by the Chief Counsel before it is issued.


**30.3.1.6** **(07-21-2005)**

### Organization

1. **Organizational Charts**. Exhibits 30.3.2-1 through Exhibit 30.3.2-15 contain organizational charts for the Office of Chief Counsel for the Internal Revenue Service; see CCDM 30.3.2, Delegations of Authority and Designations.

2. **Delineation of Functions and Organizational Units**. The Office of Chief Counsel consists of all offices headed by the Chief Counsel and Deputies Chief Counsel, Division Counsel, Associates Chief Counsel, Special Counsels, Assistants Chief Counsel, Area Counsel, Area Managers, Branch Chiefs, and other heads of component offices.

3. **Field Offices**. Each Division Counsel, the Associate Chief Counsel (General Legal Services) and the Associate Chief Counsel (Finance & Management) maintain area offices as well as headquarters offices. The area offices are headed by Area Counsels, Associate Area Counsels, and Area Managers.


**30.3.1.7** **(11-20-2017)**

### Acting Chief Counsel under the Federal Vacancies Reform Act and Other Matters of Succession

1. Acting Chief Counsel under the Federal Vacancies Reform Act



1. In the event that the position of Chief Counsel for the Internal Revenue Service is vacant and an Acting Chief Counsel is not otherwise lawfully designated, the Deputy Chief Counsel (Technical), as first assistant and principal deputy to the Chief Counsel, will act as Chief Counsel under the Federal Vacancies Reform Act (VRA) (5 U.S.C. §§ 3345-3349d) and 31 CFR §18.1. In these circumstances, the Deputy Chief Counsel (Technical) has the full authority of the Chief Counsel.

2. In the absence of an Acting Chief Counsel under the VRA, the Deputy Chief Counsel (Technical), as principal deputy, shall serve as the senior official in the Office of Chief Counsel and is authorized to perform all of the functions and duties of the Chief Counsel, except those actions as by law are required to be taken by the Chief Counsel personally. The incumbent shall use the title Principal Deputy Chief Counsel and Deputy Chief Counsel (Technical).


2. Matters of Succession Outside of the VRA



1. In the absence of the Chief Counsel, the Deputy Chief Counsel (Technical) is authorized to perform all functions and duties of the Chief Counsel, except those actions as by law are required to be taken by the Chief Counsel personally.

2. In the absence of the Deputy Chief Counsel (Technical), the Deputy Chief Counsel (Operations) is authorized to perform the functions and duties of the Chief Counsel, except those actions as by law are required to be taken by the Chief Counsel personally.

3. In the absence of both Deputies Chief Counsel, the following officials, in the order prescribed, are authorized to perform the functions and duties of the Chief Counsel, except those actions as by law are required to be taken by the Chief Counsel personally, until such time as a Deputy Chief Counsel is able to serve, or the Chief Counsel resumes duty:


       1) Division Counsel (Small Business/Self-Employed)


       2) Division Counsel (Large Business and International)


       3) Associate Chief Counsel (General Legal Services)


       4) Associate Chief Counsel (Procedure and Administration)


       5) Area Counsel (Area 6) (Small Business/Self-Employed) (Dallas)


       6) Area Counsel (Large Business and International) (Area 2) (Philadelphia)


       7) Area Counsel (Area 3) (Small Business/Self-Employed) (Jacksonville)


       8) Area Counsel (Large Business and International) (Area 5) (Oakland)

4. Nothing in this directive shall be construed in a manner that would conflict with any provision of the VRA


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part30/irm_30-003-001#addtoany "Show all")

A2A