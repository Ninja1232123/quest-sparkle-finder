---
url: "https://www.irs.gov/irm/part36/irm_36-004-001"
title: "36.4.1 Litigation Exhibits | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part36/irm_36-004-001#main-content)

- 36.4.1 [Litigation Exhibits](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624314934240)
  - 36.4.1.1 [Supplementary Material](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624319438944)
  - Exhibit 36.4.1-1 [Sample Letter Recommending Appeal](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624334406992)
  - Exhibit 36.4.1-2 [Information Memoranda and Information Emails](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624299364448)
  - Exhibit 36.4.1-3 [Action Memoranda and Action Emails](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624292754464)
  - Exhibit 36.4.1-4 [Motion for Certification of Question for Appeal](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624313614720)
  - Exhibit 36.4.1-5 [Notices of Appeal Tax Court](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624292496688)
  - Exhibit 36.4.1-6 [Stipulation of Venue](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624295167600)
  - Exhibit 36.4.1-7 [Letter to Tax Court (Record on Appeal)](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624296633360)
  - Exhibit 36.4.1-8 [Memorandum to Appeals (Authorizing Overpayment Refund/Credit)](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624302510800)
  - Exhibit 36.4.1-9 [Remand Memorandum (No Rehearing)](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624292223632)
  - Exhibit 36.4.1-10 ["No Appeal" Memorandum](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624289515536)
  - Exhibit 36.4.1-11 [Remand Memorandum (Rehearing)](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624288459104)
  - Exhibit 36.4.1-12 [Transfer Memorandum (Rehearing)](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624305066496)
  - Exhibit 36.4.1-13 [Transfer Memorandum (No Rehearing)](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624293421584)
  - Exhibit 36.4.1-14 [Form 9725, NON-TEFRA Cases Only (Memorandum)](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624298682208)
  - Exhibit 36.4.1-15 [Form 9724, TEFRA Cases Only (Memorandum)](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624288165824)
  - Exhibit 36.4.1-16 [Taxpayer Appeal Letter](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624306419024)
  - Exhibit 36.4.1-17 [Sample Transmittal of Files to Justice](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624295485360)
  - Exhibit 36.4.1-18 [Ninth Circuit Representation Statement](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624292803952)
  - Exhibit 36.4.1-19 [Seventh Circuit Docketing Statement](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624334516848)
  - Exhibit 36.4.1-20 [Eighth Circuit Appellant's Form A, Appeal Information Form](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624310993424)
  - Exhibit 36.4.1-21 [Eighth Circuit Appellee's Form B, Appeal Information Form](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624319526768)
  - Exhibit 36.4.1-22 [Protective Appeal Letter](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624297097232)
  - Exhibit 36.4.1-23 [Interpreting a 14 or 13 Digit Document Locator Number (DLN)](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624307930048)
  - Exhibit 36.4.1-24 [Contact Information for Service Centers](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624284895904)
  - Exhibit 36.4.1-25 [Transfer Memorandum (Bonded Appeal)](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624303630048)
  - Exhibit 36.4.1-26 [Action on Decision](https://www.irs.gov/irm/part36/irm_36-004-001#idm139624304410912)

# Part 36. Appellate Litigation and Actions on Decision

# Chapter 4. Litigation Exhibits

# Section 1. Litigation Exhibits

* * *

## 36.4.1 Litigation Exhibits

#### Manual Transmittal

March 01, 2013

#### Purpose

(1) This transmits revised CCDM 36.4.1, Appellate Litigation and Actions on Decision; Litigation Exhibits.

#### Material Changes

(1) Exhibit 36.4.1-26 was replaced to clarify that actions on decision are signed on behalf of the Chief Counsel.

(2) Exhibits 36.4.1-14 and 36.4.1-15 were replaced with the January, 2013 versions of Forms 9725 and 9724 respectively.

(3) The following graphic exhibits were converted to xml compatible formats to comply with the requirements of Section 508 of the Rehabilitation Act: 36.4.1-5, 36.4.1-6, 36.4.1-18, and 36.4.1-19. The content of the exhibits was not changed.

#### Effect on Other Documents

CCDM 36.4.1 dated March 29, 2012 is superseded.

#### Audience

Chief Counsel

#### Effective Date

(03-01-2013)

Deborah A. Butler

Associate Chief Counsel

(Procedure & Administration)

**36.4.1.1** **(08-11-2004)**

### Supplementary Material

1. This section provides sample documents and other material used in Counsel's appellate litigation practice, as described in CCDM 36.1.1 through CCDM 36.3.1.


**Exhibit 36.4.1-1**

### Sample Letter Recommending Appeal

Use Office of Chief Counsel letterhead

|  |
| :-: |
| **DEPARTMENT OF THE TREASURY**<br>**INTERNAL REVENUE SERVICE**<br>**WASHINGTON, D.C. 20224** |
|  |
|  | \[Org. Symbols\] \[Attorney initials\] <br>\[Case Number\] |
|  |
| The Honorable \[Name\] <br>Assistant Attorney General <br>Tax Division <br>Department of Justice <br>P.O. Box 502 <br>Benjamin Franklin Station <br>Washington, D.C. 20044 |
|  | Attn: Chief, Appellate Section |
|  | Re: \[Case name\] <br> Civil Action No. XXXXXXX \[Court. date of order\] <br> Taxpayer: Name of taxpayer <br> Your Ref: |
|  |
| Dear \[Name\]: |
| This letter provides our views regarding appeal of this decision. We recommend \[short statement of recommendation\]. |
| ISSUES |
| \[State issues under consideration for appeal.\] |
| BACKGROUND |
| \[Provide relevant facts and procedural history of the case.\] |
| DISCUSSION |
| \[Discuss the legal arguments relevant to the recommendation for appeal, the positions taken by the Service, and the views of the Office of Chief Counsel. The letter should also include a discussion of all policy considerations relevant to the decision and the probable effects to Service operations if the Government does not appeal.\] |
| CONCLUSION |
| \[May provide a concise summary of the major points supporting the recommendation and must contain a specific statement regarding the action being recommended in the case.\] |
| If you have any questions, please contact \[Name of assigned attorney\] at (202) \[telephone number\]. |
|  |
|  | Sincerely, |
|  | \[Chief Counsel Name\] <br>Chief Counsel |
|  |
| By: | \_\_ |
|  | \[Associate Chief Counsel\] <br>\[Office\] |
|  |
| cc: Associate Area Counsel, Area X (\[Division Counsel\]) <br>Division Counsel (\[name\]) <br>Chief, Civil Trial Section, \[name\] Region |

**Exhibit 36.4.1-2**

### Information Memoranda and Information Emails

![This is an Image: 39023002.gif](https://www.irs.gov/pub/xml_bc/39023002.gif)

There is currently no description available for this image. For help with this image, please call the IRS.gov Helpdesk at 1-800-876-1715.

[Please click here for the text description of the image.](https://www.irs.gov/media/157771 "")

![This is an Image: 39023033.gif](https://www.irs.gov/pub/xml_bc/39023033.gif)

There is currently no description available for this image. For help with this image, please call the IRS.gov Helpdesk at 1-800-876-1715.

[Please click here for the text description of the image.](https://www.irs.gov/media/157776 "")

![This is an Image: 39023034.gif](https://www.irs.gov/pub/xml_bc/39023034.gif)

There is currently no description available for this image. For help with this image, please call the IRS.gov Helpdesk at 1-800-876-1715.

[Please click here for the text description of the image.](https://www.irs.gov/media/157781 "")

![This is an Image: 39023035.gif](https://www.irs.gov/pub/xml_bc/39023035.gif)

There is currently no description available for this image. For help with this image, please call the IRS.gov Helpdesk at 1-800-876-1715.

[Please click here for the text description of the image.](https://www.irs.gov/media/157786 "")

**Exhibit 36.4.1-3**

### Action Memoranda and Action Emails

![This is an Image: 39023003.gif](https://www.irs.gov/pub/xml_bc/39023003.gif)

There is currently no description available for this image. For help with this image, please call the IRS.gov Helpdesk at 1-800-876-1715.

[Please click here for the text description of the image.](https://www.irs.gov/media/157791 "")

![This is an Image: 39023036.gif](https://www.irs.gov/pub/xml_bc/39023036.gif)

There is currently no description available for this image. For help with this image, please call the IRS.gov Helpdesk at 1-800-876-1715.

[Please click here for the text description of the image.](https://www.irs.gov/media/157796 "")

![This is an Image: 39023037.gif](https://www.irs.gov/pub/xml_bc/39023037.gif)

There is currently no description available for this image. For help with this image, please call the IRS.gov Helpdesk at 1-800-876-1715.

[Please click here for the text description of the image.](https://www.irs.gov/media/157801 "")

![This is an Image: 39023038.gif](https://www.irs.gov/pub/xml_bc/39023038.gif)

There is currently no description available for this image. For help with this image, please call the IRS.gov Helpdesk at 1-800-876-1715.

[Please click here for the text description of the image.](https://www.irs.gov/media/157806 "")

**Exhibit 36.4.1-4**

### Motion for Certification of Question for Appeal

RESPONDENT MOVES, pursuant to I.R.C. § 7482(a)(2)(A) and Tax Court Rule 193, that the Court amend its order ruling of (Date), in the above docket to include a statement that a controlling question of law is involved with respect to which there is a substantial ground for difference of opinion and that an immediate appeal from that order may materially advance the ultimate termination of the litigation.

IN SUPPORT THEREOF, respondent respectfully states: STATEMENT OF FACTS

1\. . . . \[In numbered paragraphs, briefly summarize (1) the factual background out of which the question arose, (2) the procedure leading to the order (or ruling), and (3) the holding of the order (or ruling).\]

STATEMENT OF THE CONTROLLING QUESTION

4\. . . . \[In continuing numbered paragraphs, state the question raised by the order (or ruling), with a statement of the reasons why the question is a controlling question which is not settled by applicable legal authority. The question is a controlling question if an answer contrary to that given in the Tax Court's order will terminate the litigation or the litigation of a particular substantive issue. A controlling question of law may also be one central to the litigation that, if answered as the Respondent believes it should be answered, will make unnecessary a considerable expense of effort by the Tax Court or the parties.\]

STATEMENT OF THE REASONS WHY A SUBSTANTIAL BASIS EXISTS FOR A DIFFERENCE OF OPINION ON THE QUESTION

7\. . . . \[In continuing numbered paragraphs, briefly describe decisions of courts that are in conflict with the conclusion in the Tax Court's order (or ruling), citing legislative history, or other reasons why the Tax Court's order (or ruling) is improper or inappropriate.\]

STATEMENT OF THE REASONS WHY AN IMMEDIATE APPEAL MAY MATERIALLY ADVANCE THE TERMINATION OF THE LITIGATION

10\. . . . \[In continuing numbered paragraphs, show how the proposed content of the order (or ruling) sought by Respondent will dispose of the litigation (or the litigation of a particular issue) or, if not, what effect Respondent's proposed order would have on the progress of the case in the Tax Court in terms of saving the time of courts and litigants.\]

WHEREFORE, respondent requests that the Court grant this motion and certify the question for appeal.

**Exhibit 36.4.1-5**

### Notices of Appeal — Tax Court

|  |
| --- |
| UNITED STATES TAX COURT |
|  |
| \[Petitioner's name\], | ) |  |
| Petitioners -- Appellees. | ) |  |
| v. |  | )<br>) | Docket No. \[Number\] |
| COMMISSIONER OF INTERNAL REVENUE,<br> Respondent -- Appellant. | )<br>) |  |
| NOTICE OF APPEAL |
| Notice is hereby given that the Commissioner of Internal Revenue appeals to the United States Court of Appeals for the \[Circuit Court\] from the decision of the Tax Court entered in the above-captioned proceeding on the \[date\]. |
| Petitioners resided in \[city, state\], at the time the petition was filed. Accordingly, appellate venue properly lies in the United States Court of Appeals for the \[Circuit Court\]. |
| Date: \_ | \_\_<br>\[NAME OF ASSISTANT ATTORNEY GENERAL\]<br>Assistant Attorney General <br>Department of Justice |
|  | \_\_<br>\[NAME OF CHIEF COUNSEL\] <br>Chief Counsel <br>Internal Revenue Service |
|  | \_\_<br>\[NAME OF BRANCH CHIEF\] <br>T.C. Bar No. xx 0000 <br>Chief, (Name of Branch) <br>\[Associate Office\] <br>Internal Revenue Service <br>1111 Constitution Avenue, N.W. <br>Washington, D.C. 20224 <br>Tel. No. 202-622-xxxx |

**Exhibit 36.4.1-6**

### Stipulation of Venue

|  |
| --- |
| UNITED STATES COURT OF APPEALS <br>FOR THE \[Circuit Number\] CIRCUIT |
|  |
| \[TAXPAYER\], |  |
| Appellant. |  |
| v. | No. \[Docket No.\] |
| COMMISSIONER OF INTERNAL REVENUE,<br> Appellee. |  |
| **STIPULATION OF VENUE** |
| Pursuant to Section 7482(b)(2), Internal Revenue Code of 1986, it is hereby stipulated and agreed by and between the parties hereto, that venue for review of the above-captioned case shall be in the United States Court of Appeals for the Circuit, that an order to this effect be entered herein by the Clerk of the Court, and that notification of entry of the order be transmitted to each of the parties. |
| \_<br>Date | \[NAME OF COUNSEL FOR APPELLANT\] <br>\[Address of Counsel\] <br>Counsel for Appellant |
| \_<br>Date | \[NAME OF ASSISTANT ATTORNEY GENERAL\] <br>\[Assistant Attorney General\] <br>Tax Division <br>Department of Justice <br>Washington, DC 20044 <br>Counsel for the Appellee |

**Exhibit 36.4.1-7**

### Letter to Tax Court (Record on Appeal)

|  |
| :-: |
| **DEPARTMENT OF THE TREASURY**<br>**INTERNAL REVENUE SERVICE**<br>**WASHINGTON, D.C. 20224** |
|  |
|  | \[Org. Symbols\] \[Attorney initials\] |
|  |
| \[Name of Clerk\] <br>Clerk, United States Tax Court <br>400 Second Street, N.W. <br>Washington, DC 20217 |
|  |
| Dear \[Name of Clerk\]: |
| This is to inform you that the Solicitor General of the Department of Justice has declined to authorize prosecution of the Commissioner's appeal of \[Case name\], for which a notice of appeal was filed on \[date\] . |
| If the record has not yet been transmitted to the United States Court of Appeals for the District of Columbia Circuit, we request that you retain the record in the Tax Court. |
|  |
|  | Sincerely, |
|  | \[NAME OF CHIEF COUNSEL\]<br>Chief Counsel |
|  |
| By: | \_\_ |
|  | Chief, Branch (Number)<br>\[Name of Office\] |

**Exhibit 36.4.1-8**

### Memorandum to Appeals (Authorizing Overpayment Refund/Credit)

|  |
| --- |
|  | **Office of Chief Counsel**<br>**Internal Revenue Service**<br>**m e m o r a n d u m**<br>\[Org. symbols & attorney initials\]<br>\[Case number\] |
| date: |  |
| to: |  |
| from: |  |
| subject: | Refund pursuant to section 3464 of the IRS Restructuring and Reform Act of 1998 (I.R.C. § 6512(b)(1)) |
|  | RE: \[Taxpayer's Name; SSN or EIN\] |
|  | \[Tax Court case name, docket number, and citation\] |
|  | The Tax Court has determined a deficiency of \[amount\] for \[tax year\] and an overpayment of \[amount\] for \[tax year\]. The taxpayer is appealing the court's determination of the deficiency and \[partial amount\] of the overpayment/and is not contesting any portion of the overpayment. Pursuant to I.R.C. § 6215(b)(1), we authorize and request you to issue a manual \[credit / refund\] of \[amount\] to the taxpayer. |

**Exhibit 36.4.1-9**

### Remand Memorandum (No Rehearing)

|  |
| --- |
|  | **Office of Chief Counsel**<br>**Internal Revenue Service**<br>**m e m o r a n d u m**<br>\[Org. symbols & attorney initials\]<br>\[Case number\] |
| date: |  |
| to: | Associate Area Counsel, \[Division Counsel\] <br>Attn: \[Division Counsel Attorney's Name\] |
| from: | \[Reviewer, Branch, and Associate Office\] |
| subject: | \[Case Name\] |
|  | In the attached opinion dated \[date\], the United States Court of Appeals for the \[Circuit Court\] reversed the Tax Court with respect to the Commissioner's appeal concerning the Tax Court's holding \[set forth holding\]. Following the expiration of the certiorari period on \[date\], this case will be closed in the national office and formally transferred to your office for the preparation and filing of new decision documents with the Tax Court. |
|  | In the interim, as CATS shows that the administrative file is in the possession of the \[City/location\] Appeals Office, please obtain an updated transcript and request the Appeals Office to prepare the necessary recomputation and statement of account. This should be done as quickly as possible, as the Tax Court generally orders that the recomputations be filed immediately after the expiration of the certiorari period. See CCDM 36.2.10.12. |
|  | If further information is needed, please call \[Associate Chief Counsel attorney\] at \[telephone number\]. |
|  | Attachment (1) \[Opinion\] |

**Exhibit 36.4.1-10**

### "No Appeal" Memorandum

![This is an Image: 39023010.gif](https://www.irs.gov/pub/xml_bc/39023010.gif)

There is currently no description available for this image. For help with this image, please call the IRS.gov Helpdesk at 1-800-876-1715.

[Please click here for the text description of the image.](https://www.irs.gov/media/157811 "")

**Exhibit 36.4.1-11**

### Remand Memorandum (Rehearing)

|  |
| --- |
|  | **Office of Chief Counsel**<br>**Internal Revenue Service**<br>**m e m o r a n d u m**<br>\[Org. symbols & attorney initials\] \[Case number\] |
| date: |  |
| to: | Associate Area Counsel, \[Division Counsel\] <br>Attn: \[Division Counsel Attorney's Name\] |
| from: | \[Reviewer, Branch and Associate Office\] |
| subject: | \[Case Name\] |
|  | By opinion dated \[date\], the United States Court of Appeals for the \[Circuit Court\] vacated the decision of the Tax Court and remanded the case to consider relevant evidence relating to an ambiguous term and to make more thorough findings of fact. Following the expiration of the certiorari period on \[date\], this case will be closed in the national office and formally transferred to your office for further proceedings in the Tax Court in accord with the mandate of the \[Circuit Court\]. See CCDM 36.2.10.12. |
|  | If further information is needed, please call \[Name\] at \[telephone number\]. |
|  | Attachment (1) \[Opinion\] |

**Exhibit 36.4.1-12**

### Transfer Memorandum (Rehearing)

|  |
| --- |
|  | **Office of Chief Counsel**<br>**Internal Revenue Service**<br>**m e m o r a n d u m**<br>\[Org. symbols & attorney initials\]<br>\[Case number |\
| date: |  |\
| to: | Associate Area Counsel, \[Division\]<br>Attn: \[Division Counsel Attorney's Name\] |\
| from: | \[Reviewer, Branch and Associate Office\] |\
| subject: | \[Case Name\] |\
|  | In our memorandum to you dated \[date\], we attached an opinion dated \[date\], by the United States Court of Appeals for the \[Circuit Court\] that vacated the decision of the Tax Court and remanded the case for us to consider relevant evidence relating to an ambiguous term and to make more thorough findings of fact. We advised you that following the expiration of the period for filing a petition for writ of certiorari to the Supreme Court on \[date\], we would transfer the case to your office. |\
|  | Neither party has filed a petition for writ of certiorari, and the time for doing so has expired. We are therefore closing the case in the national office and formally transferring it to your office for further proceedings in the Tax Court in accord with the mandate of the \[Circuit Court\]. See CCDM 36.2.10.12. |\
|  | CATS shows that the administrative file is in the possession of the \[City/location\] Appeals Office. At the conclusion of the Tax Court proceedings, please obtain an updated transcript and request the Appeals Office to prepare the necessary recomputation and statement of account. |\
|  | Once the new decision entered by the Tax Court has become final, your office will be responsible for any required assessment. See CCDM 36.2.12.4 and CCDM 36.2.12.4.5. |\
|  | If further information is needed, please call \[Name\] at \[telephone number\]. |\
|  | Attachment (1) \[Legal File\] |\
\
**Exhibit 36.4.1-13**\
\
### Transfer Memorandum (No Rehearing)\
\
|  |\
| --- |\
|  | **Office of Chief Counsel**<br>**Internal Revenue Service**<br>**m e m o r a n d u m**<br>\[Org. symbols & attorney initials\]<br>\[Case number\] |\
| date: |  |\
| to: | Associate Area Counsel, \[Division\] <br>Attn: \[Division Counsel Attorney's Name\] |\
| from: | \[Reviewer, Branch and Associate Office\] |\
| subject: | \[Case Name\] |\
|  | In our memorandum to you dated \[date\], we attached an opinion dated \[date\], by the United States Court of Appeals for the \[Circuit Court\] that reversed the Tax Court with respect to the Commissioner's appeal concerning the Tax Court's holding \[describe holding\]. We advised that you should obtain an updated transcript and request the \[city/location\] Appeals Office to prepare the necessary recomputation and statement of account, and that following the expiration of the period for filing a petition for writ of certiorari to the Supreme Court on \[date\], we would transfer the case to your office for the preparation and filing of new decision documents with the Tax Court. |\
|  | The petitioner did not file a petition for writ of certiorari and the period for filing has expired. Therefore, we are closing this case in the national office and formally transferring it to your office for preparation and filing of new decision documents with the Tax Court. See CCDM 36.2.10.12. |\
|  | Once the new decision entered by the Tax Court has become final, your office will be responsible for any required assessment. See CCDM 36.2.12.4 and CCDM 36.2.12.4.5. |\
|  | If further information is needed, please call \[Name\] at \[telephone number\]. |\
|  | Attachment (1) \[Legal File\] |\
\
**Exhibit 36.4.1-14**\
\
### Form 9725, NON-TEFRA Cases Only (Memorandum)\
\
![This is an Image: 39023014.gif](https://www.irs.gov/pub/xml_bc/39023014.gif)\
\
There is currently no description available for this image. For help with this image, please call the IRS.gov Helpdesk at 1-800-876-1715.\
\
[Please click here for the text description of the image.](https://www.irs.gov/media/157816 "")\
\
**Exhibit 36.4.1-15**\
\
### Form 9724, TEFRA Cases Only (Memorandum)\
\
![This is an Image: 39023016.gif](https://www.irs.gov/pub/xml_bc/39023016.gif)\
\
There is currently no description available for this image. For help with this image, please call the IRS.gov Helpdesk at 1-800-876-1715.\
\
[Please click here for the text description of the image.](https://www.irs.gov/media/157821 "")\
\
**Exhibit 36.4.1-16**\
\
### Taxpayer Appeal Letter\
\
|  |\
| :-: |\
| **DEPARTMENT OF THE TREASURY**<br>**INTERNAL REVENUE SERVICE**<br>**WASHINGTON, D.C. 20224** |\
|  |\
|  | \[Org. Symbols\] \[Attorney initials\] |\
| The Honorable Eileen J. O'Connor <br>Assistant Attorney General <br>Tax Division <br>Department of Justice <br>P.O. Box 502 <br>Benjamin Franklin Station <br>Washington, DC 20044 |\
|  | Attn:<br>Re: | Chief, \[Name of Region\] Trial Section<br>\[Petitioner names\] v. Commissioner <br>T.C. Docket No. \[Docket number\] Venue: \[Court\]. |\
|  |\
| Dear Ms. O'Connor:: |\
| On \[date\], the taxpayer filed with the United States Tax Court a timely notice of appeal to the United States Court of Appeals for the \[Circuit Court\]. The decision of the Tax Court was entered on \[date\]. |\
| At the time the petition was filed, the taxpayer resided in \[City of Residence/Place of Business\], \[State\]. Accordingly, venue properly lies in the \[name of court\]. |\
| The issues on appeal are whether \[describe issues\]. |\
| The petitioner is represented on appeal by \[Attorney name, address\]. Phone number is \[attorney phone number\]. |\
| The Associate Chief Counsel attorney/paralegal assigned to this case is \[name\], who can be reached at \[phone number\]. The Area Counsel attorney assigned to this case is \[Area Counsel attorney name\], who can be reached at \[telephone number\]. |\
| This case is reported at Tax Court \[citation\]. The legal file has been requested and will be forwarded to your office. For your use in the interim, we are enclosing copies of the notice of filing, the notice of appeal, the notice of transmission, and decision in this case. |\
| If you have any questions, please contact \[Name\] at (202) \[telephone phone number\]. |\
|  |\
|  | Sincerely, |\
|  | \[Chief Counsel Name\] <br>Chief Counsel |\
|  |\
| By: | \_\_ |\
|  | \[Branch Reviewer\] <br>\[Division/Branch\] |\
|  |\
| Enclosures (4) \[Notice of Filing Notice of Appeal, Notice of Appeal, Docket Entries, Tax Court Opinion\] |\
\
**Exhibit 36.4.1-17**\
\
### Sample Transmittal of Files to Justice\
\
|  |\
| :-: |\
| **DEPARTMENT OF THE TREASURY**<br>**INTERNAL REVENUE SERVICE**<br>**WASHINGTON, D.C. 20224** |\
|  |\
|  | \[Org. Symbols\] \[Attorney initials\] |\
|  |\
| The Honorable Eileen J. O'Connor <br>Assistant Attorney General <br>Tax Division <br>Department of Justice <br>P.O. Box 502 <br>Benjamin Franklin Station <br>Washington, DC 20044 |\
|  | Attn:<br>Re:<br>Ref: | Chief, Appellate Section <br>\[Name of case\] <br>\[DOJ's reference number\] |\
|  |\
| Dear Ms. O'Connor: |\
| On \[date\], taxpayer filed a notice of appeal in this case. Pursuant to established procedures, we are forwarding the legal and miscellaneous law files for your use in the appellate proceedings. Upon completion of the appellate proceedings, please promptly return the files for closing to Associate Chief Counsel (Procedure & Administration), Attn: Technical Services Support Branch, Office of Chief Counsel, 1111 Constitution Avenue, N.W., Washington, D.C. 20224. |\
|  |\
|  | Sincerely, |\
|  | \[Chief Counsel Name\] <br>Chief Counsel |\
|  |\
| By: | \_\_ |\
|  | \[Branch Reviewer\] <br>\[Title\] |\
|  |\
| Enclosures: (2) \[Legal File, Miscellaneous Law File\] |\
\
**Exhibit 36.4.1-18**\
\
### Ninth Circuit Representation Statement\
\
|  |\
| --- |\
| UNITED STATES TAX COURT |\
|  |\
| \[Petitioner's name\], | ) |  |\
| Petitioner-- Appellee. | )<br>) |  |\
| v. | )<br>) | Docket No. XXXX-XX |\
| COMMISSIONER OF INTERNAL REVENUE, | ) |  |\
| Respondent -- Appellant. | ) |  |\
| REPRESENTATION STATEMENT |\
| Pursuant to Rule 12(b) of the Federal Rules of Appellate Procedure and Rule 3-2(b) of the Local Rules of the United States Court of Appeals for the Ninth Circuit, counsel for the appellant hereby states that the notice of appeal in the above-entitled case was filed on this date, by the undersigned attorney of the Office of Chief Counsel of the Internal Revenue Service, who represents the Commissioner of Internal Revenue in this Court. On appeal, the Commissioner of Internal Revenue will be represented by attorneys of the Appellate Section of the Tax Division, U.S. Department of Justice, Room 4324 Main Justice Bldg., 10th and Constitution Avenue, N.W., Washington, D.C. 20530, telephone 202-514-3361. Petitioner-Appellee will be represented on appeal by \[name, address, and telephone number\] . \[Petitioner-Appellee is appearing on appeal pro se.\] \[Petitioner-Appellee's representative on appeal is unknown.\] |\
| Date: | \_\_<br>\[ASSISTANT ATTORNEY GENERAL\]<br>Assistant Attorney General<br>Department of Justice |\
|  | \_\_<br>\[NAME OF CHIEF COUNSEL\]<br>Chief Counsel<br>Internal Revenue Service |\
|  | \_\_<br>\[NAME OF BRANCH CHIEF\]<br>T. C. Bar No. XX 0000<br>Office of the Associate Chief Counsel \[Division\] <br>Internal Revenue Service<br>1111 Constitution Avenue, N.W.<br>Washington, D.C. 20224<br>Tel. No. 202-622 \[number\] |\
\
**Exhibit 36.4.1-19**\
\
### Seventh Circuit Docketing Statement\
\
|  |\
| --- |\
| UNITED STATES TAX COURT |\
|  |\
| \[Petitioner's name\], | ) |  |\
| Petitioner -- Appellee. | )<br>) |  |\
| v. | )<br>) | Docket No. XXXX-XX |\
| COMMISSIONER OF INTERNAL REVENUE, | ) |  |\
| Respondent -- Appellant. | ) |  |\
| DOCKETING STATEMENT |\
| Pursuant to Rule 3(c) of the Rules of the United States Court of Appeals for the Seventh Circuit, the Commissioner of Internal Revenue, appellant herein, files this docketing statement. |\
| On \[date\], the Commissioner mailed a statutory notice of deficiency pursuant to Sections 6212(a) and 6213(a) of the Internal Revenue Code of 1986 to \[name of petitioner\], determining a deficiency in federal income tax for the taxable year \[year\]. On \[date\], within the 90-day period following the mailing of the notice of deficiency set by Section 6213(a) of the Code, taxpayer filed a petition in the United States Tax Court, seeking redetermination of that deficiency. |\
| \[Make appropriate modifications to the docketing statement describing Tax Court proceedings other than deficiency actions, e.g., declaratory judgment cases, partnership actions, etc.\] |\
| \[Include one of the following, if applicable\]: |\
|  | \[1\] Taxpayer is a corporation incorporated in the State of \[name of State\], and has its principal place of business in the State of \[name of State\] . |\
|  | \[2\] The Petitioner-Appellee is an unincorporated association or partnership, the citizenship of whose members is identified on the attached schedule. |\
| The Tax Court has jurisdiction over taxpayer's petition under Sections 6213 \[or other statutory basis for the Tax Court's jurisdiction, e.g., declaratory judgment, partnership action, etc.\] and 7442 of the Code. In accordance with published/ memorandum/ unpublished\] opinion \[or order\] (\[officially/unofficially\] reported at \[citation\]), the Tax Court (Judge \[name of Judge\]) on \[date\], entered a decision that there was no deficiency \[or describe other disposition, e.g., a decision modifying the determination of the Commissioner, declaratory judgment, etc.\] in taxpayer's \[year\] federal income tax. The Tax Court's decision is final and disposes of all claims with respect to all parties. |
| The Commissioner filed a notice of appeal on \[date\]. This notice is timely because it was filed within 90 days of entry of the decision. See I.R.C. § 7483; Fed. R. App. P. 13(a). The Seventh Circuit has jurisdiction over the appeal pursuant to Section 7482 of the Code. |
| \[Include statement identifying by caption and docket number any prior or related appellate proceedings in the case, or earlier appellate proceedings if the party believes that the earlier appellate proceedings are sufficiently related to the new appeal. Add any additional explanation of post decisional motions or motions claimed to toll the time within which to appeal. Add any explanation of the jurisdictional basis for an interlocutory appeal.\] |
| Date: | \_\_<br>\[ASSISTANT ATTORNEY GENERAL\]<br>Assistant Attorney General<br>Department of Justice |
|  | \_\_<br>\[NAME OF CHIEF COUNSEL\]<br>Chief Counsel<br>Internal Revenue Service |
|  | \_\_<br>\[NAME OF BRANCH CHIEF\]<br>T. C. Bar No. XX 0000<br>Office of the Associate Chief Counsel \[Division\] <br>Internal Revenue Service<br>1111 Constitution Avenue, N.W.<br>Washington, D.C. 20224<br>Tel. No. 202-622 \[number\] |

**Exhibit 36.4.1-20**

### Eighth Circuit Appellant's Form A, Appeal Information Form

|  |
| :-: |
| U.S. COURT OF APPEALS — EIGHTH CIRCUIT/ Docket No. <br>APPELLANT'S FORM A <br>Appeal Information Form <br>To be filed with the Notice of Appeal |
|  |
| STYLE OF CASE | COUNSEL: NAME, ADDRESS, AND TELEPHONE NUMBER |
| Appellant/Appellee, |
| vs. |
| Appellant/Appellee. |
| DATE OF DISTRICT COURT JUDGMENT/TAX COURT DECISION: |
| BASIS OF: DISTRICT COURT/TAX COURT JURISDICTION:<br> APPELLATE JURISDICTION:<br>JURISDICTIONAL ISSUE, IF ANY: |
| IS THIS CASE SUITABLE FOR CONSIDERATION IN THIS COURT'S SETTLEMENT PROGRAM? <br>( ) Yes. ( ) No. If no, state why: |
| APPROPRIATE STANDARD OF APPELLATE REVIEW: |
| LIST ISSUES ON APPEAL: (List below and if necessary attach supplementary page.) Optional-Include citations for each issue and in jury cases attach challenged instructions and trial memoranda. |
| DOES THIS CONSTITUTE YOUR STATEMENT OF ISSUES UNDER FRAP 10(b)(3)? <br>( ) Yes. ( ) No. |
| Date: |
|  |
|  | ( NAME OF ASSISTANT ATTORNEY GENERAL) <br>Assistant Attorney General <br>Department of Justice <br>Telephone No. |
|  | (NAME OF CHIEF COUNSEL)<br>Chief Counsel<br>Internal Revenue Service |
|  | (NAME OF BRANCH CHIEF) <br>T. C. Bar No. <br>Internal Revenue Service <br>1111 Constitution Avenue, NW. <br>Washington, D.C. 20224 <br>Telephone No. |

**Exhibit 36.4.1-21**

### Eighth Circuit Appellee's Form B, Appeal Information Form

|  |
| :-: |
| U.S. COURT OF APPEALS — EIGHTH CIRCUIT/ Docket No. <br>APPELLEE'S FORM B<br>Appeal Information Form |
|  |
| STYLE OF CASE: |
| IS THE ALIGNMENT OF PARTIES, NAMES, ADDRESSES, AND TELEPHONE NUMBERS CORRECT ON APPELLANT'S FORM A? ( ) Yes. ( ) No. If no, list corrections below. |
| IF YOU WISH TO CLARIFY THE JURISDICTIONAL STATEMENT OR GENERAL STATEMENT, LIST THE ADDITIONAL ISSUES OR COMMENTS: |
| DO YOU BELIEVE THIS CASE IS SUITABLE FOR CONSIDERATION IN THIS COURT'S SETTLEMENT PROGRAM? ( ) Yes. ( ) No. If no, state why. |
| NAME, ADDRESS, AND TELEPHONE NUMBER OF COUNSEL COMPLETING THIS FORM: <br>Submitted by: |
|  | Signature | Date |

**Exhibit 36.4.1-22**

### Protective Appeal Letter

|  |
| :-: |
| **DEPARTMENT OF THE TREASURY**<br>**INTERNAL REVENUE SERVICE**<br>**WASHINGTON, D.C. 20224** |
|  |
|  | \[Org. Symbols\] \[Attorney initials\] |
|  |
| Honorable \[Name\] <br>Assistant Attorney General <br>Tax Division <br>Department of Justice <br>P.O. Box 502 <br>Washington, DC 20044 |
|  | Re: \[Case Name No.1\]<br> T.C. Docket No. XXXX-XX |
|  |
| Dear \[Name of Assistant Attorney General\]: |
| This letter seeks authorization to file an appeal from the Tax Court decision entered in the above-entitled case and to pursue that appeal in the event the taxpayer appeals from the decision of the Tax Court in \[Case Name No.2\]. Decisions were entered in these cases by the court on \[date\], pursuant to an opinion reported at \[citation\] (a copy of which is attached). Venue in these cases lies in the \[Circuit Court\] and we intend to file a protective appeal in \[Case Name No.1\] on or about \[date\], unless you advise us to the contrary. We expect that \[taxpayer No.2\], taxpayer in \[Case Name No.2\], will file an appeal in that case. If \[taxpayer No.2\] does not file an appeal, we will recommend that the Government's appeal in \[Case Name No.2\] be withdrawn or dismissed. |
| ISSUE |
| \[Set forth issues.\] |
| FACTS |
| \[Set forth facts.\] |
| CONCLUSION |
| While the issue is not without doubt, we feel that the Tax Court was correct in its holding. Nevertheless, there is a substantial chance that, on \[taxpayer No. 2's\] appeal, the \[Circuit Court\] may reverse the Tax Court. Because of that possibility and the loss of revenue if no appeal is taken in the case of \[taxpayer No.1\], a protective appeal is necessary from the adverse decision in his case. |
| Accordingly, we recommend that an appeal be taken. |
|  |
|  | Sincerely, |
|  | \[Chief Counsel Name\] <br>Chief Counsel |
|  |
| By: | \_\_ |
|  | \[Associate Chief Counsel\] <br>\[Office\] |

**Exhibit 36.4.1-23**

### Interpreting a 14 or 13 Digit Document Locator Number (DLN)

**Digits 1 and 2 - filing location code**

**Digit 3 - type of tax involved**

This is a critical digit. A 6 as the third digit signifies a nonmaster file assessment, whereas a 2 indicates individual income tax, fiduciary income tax, or a partnership return, for which master file assessments are normally made.

**Digits 4 and 5 - document codes**

These are also critical digits. A 51 in these positions indicates an expedited assessment and a 47 indicates a nonexpedited assessment. To illustrate: if the 3rd, 4th, and 5th digits are 651, a nonmaster file expedited assessment has been made. If the 3rd, 4th and 5th digits are 274, a nonexpedited master file assessment has been made.

**Digits 6, 7, and 8 - Julian date of the underlying transaction (i.e., the assessment)**

Julian dates begin with 1 for January 1 and end with 365 for December 31 (except for leap years). For example, 006 in the 6th, 7th, and 8th positions in the DLN indicates that the assessment was made on January 6; 138 in the 6th, 7th and 8th positions indicates that the assessment was made on May 18 (except in leap years).

**Digits 9, 10, and 11 - block numbers that assist in locating the underlying documents**

**Digits 12 and 13 - serial numbers that identify individual documents within each block**

**Digit 14 (if present) - the year the DLN was assigned**

For 1999, the 14th digit would be a 9; for 2000, a 0; and for 2001, a 1; etc.

**Exhibit 36.4.1-24**

### Contact Information for Service Centers

| **Service Center Addresses To Be Used Only For Payment Memoranda**<br>_(Updated December 1, 2006)_ |
| :-: |
| Director, Andover Service Center<br>Internal Revenue Service<br>Post Office Box 4053<br>Woburn, Massachusetts 01888 |
| Attention: Technical Unit, Stop 661 |
|  | (978) 474–9875 / (978) 474–5532 (backup)<br> Fax: (978) 474–9432 |
| Director, Atlanta Service Center<br>Internal Revenue Service<br>Post Office Box 47–421<br>Doraville, Georgia 30341 |
| Attention: Technical Unit, Stop 35 |
|  | (678) 530–7431 / (678) 530–7446 (backup)<br>Fax: (678) 530–6386 |
| Director, Austin Service Center<br>Internal Revenue Service<br>Post Office Box 934<br>Austin, Texas 78767 |
| Attention: Technical Unit, Stop 6813 AUSC |
|  | (512) 460–2811 <br>Fax: (512) 460–2898 |
| Director, Brookhaven Service Center<br>Internal Revenue Service<br>Post Office Box 777<br>Holtsville, New York 11742 |
| Attention: Lead Tax Examiner, Technical Unit, Stop 535 |
|  | (631) 654–6326 <br>Fax: (631) 447–4297 |
| Director, Cincinnati Service Center<br>Internal Revenue Service<br>Post Office Box 12267<br>Covington, Kentucky 41012–0267 |
| Attention: Team 101, Technical/Large Corp, Stop 537 |
|  | (859) 669–4970<br>Fax: (859) 669–5018 |
| Director, Fresno Service Center<br>Internal Revenue Service<br>Post Office Box 24011<br>Fresno, California 93779 |
| Attention: Accounts Management, Stop C1008 |
|  | (559) 454–6870 <br>Fax: (559) 456–5990 (call before sending fax) |
| Director, Accounts Management<br>Kansas City Campus<br>Internal Revenue Service<br>Post Office Box 24551<br>Kansas City, Missouri 64131–0551 |
| Attention: KC:AM1:AM5:AM503, Stop 6800, R-1 |
|  | (913) 345–5634/ (913) 266–9912<br>Fax: (913) 266–9901 |
| Director, Memphis Service Center<br>Internal Revenue Service<br>5333 Getwell Road<br>Memphis, Tennessee 38118 |
| Attention: Taxpayer Relations Branch, Stop 8411 |
|  | Team Leader, Tech 102<br>(901) 546–4130 / Fax: (901) 546–2810 |
| Director, Accounts Management<br>Ogden Campus<br>Internal Revenue Service<br>1973 North Rulon White Boulevard<br>Ogden, Utah 84201 |
| Attention: Restricted Interest Group, Stop 6800 |
|  | (801) 620–4245/ (801) 620–4208<br>Fax: (801) 620–6585 |
| Director, Philadelphia Service Center<br>Internal Revenue Service<br>Post Office Box 245<br>Bensalem, Pennsylvania 19020 |
| Attention: Restricted Interest Unit, DP 350-E |
|  | (215) 516–2169 / (215) 516–2170 (backup)<br>Fax: (215) 516–1190 |

**Exhibit 36.4.1-25**

### Transfer Memorandum (Bonded Appeal)

|  |
| --- |
|  | **Office of Chief Counsel**<br>**Internal Revenue Service**<br>**m e m o r a n d u m**<br>\[Org. symbols & attorney initials\]<br>\[Case number\] |
| date: |  |
| to: | Area Counsel, \[Division Counsel\] <br> Attn: \[Division Counsel Attorney's Name\] |
| from: | \[Reviewer, Branch and Associate Office\] |
| subject: | \[Case Name and docket number\] |
|  | The taxpayer(s) filed an appeal bond in the above-captioned case, in which the Tax Court decision became final on \[date\]. On \[date\], your office informed this office that assessment was made on \[date\]. Pursuant to the provisions of CCDM 36.2.3.13.6.1(4) and CCDM 36.2.13.6.2 we are now closing the case in the Associate Chief Counsel office and transferring it to your office for monitoring collection activity in coordination with the Special Procedures Function (SPF) in the Collection Division of the Area Director's office. |
|  | SPF is responsible for checking the taxpayer's account 60 days from receipt of this memorandum to determine whether the tax, interest, and penalties, if any, have been paid. |
|  | The Division Counsel attorney is reminded of its responsibilities pursuant to CCDM 36.2.3.13.6.2(8) to file with the Tax Court a prompt release notification or move the court to have the underlying deficiencies satisfied from the bond proceeds and to close the case upon satisfaction of the liabilities and/or notification to the Tax Court. |
|  | If further assistance is needed, please call \[name\] at \[telephone number\]. |
|  |  |
|  | Attachment (1) \[Legal File\] |
|  | cc: Chief, Appeals Office |

**Exhibit 36.4.1-26**

### Action on Decision

| **ACTION ON DECISION** |
| :-: |
| **Subject:** | International Business Machines Corp. v. United States, <br>343 F.2d 914 (Ct. Cl. 1965), cert. denied, 382 U.S. 1028 (1966) |

**Issue:** Whether I.R.C. § 7805(b) requires the Service to apply an adverse ruling only prospectively if its retroactive application would treat a taxpayer who requested the ruling differently from a taxpayer who received a favorable ruling on the same subject.

**Discussion:** Taxpayer, one of two companies that manufactured, sold, and leased "larger electronic computing systems," filed a refund suit for excise taxes, claiming disparate treatment related to section 3406(a)(6) of the 1939 Code and section 4191 of the 1954 Code, which placed a 10% excise tax on the sale price of "business machines" sold by the manufacturer. Prior to April 1955, taxpayer and its competitor paid excise taxes on the computer systems they sold. In April 1955, responding to the competitor’s request, the Service issued a ruling that determined that two of the competitor’s computer systems were not subject to excise taxes. In September 1955, the competitor requested a refund for excise taxes it paid from January 1, 1952 to April 30, 1955, which the Service granted. The Service later revoked the competitor’s ruling, but did so prospectively. As a result of the refund and the ruling, taxpayer's competitor avoided paying excise taxes on two of its computer systems from January 1952 through January 1958.

Taxpayer learned of its competitor’s ruling, and, in July 1955, requested that the Service issue the same ruling with respect to one of its "identical" computer systems. In July 1955, taxpayer filed a refund claim for the excise taxes it paid from June 1951 through May 1955. The Service responded to taxpayer’s ruling request in November 1957, determining that taxpayer’s computer system was a taxable business machine. In April 1958, taxpayer filed a second refund claim for June 1955 through January 1958, which was generally the period covered by the competitor’s ruling. The Service denied both refund claims, and taxpayer sued for a refund in the United States Court of Claims.

The Court of Claims approached the refund suit by analyzing whether section 7805(b) should prevent disparate treatment by requiring the Service to apply certain rulings prospectively to equalize the treatment between taxpayers in the "same class," irrespective of the rulings' correctness on the merits. The Court of Claims reasoned that, because section 7805(b) provides the Service with discretion to "prescribe the extent, if any, to which any ruling . . . shall be applied without retroactive effect," the Service abuses its discretion when a ruling’s retroactive effect causes the inequitable treatment of competitors. The Court of Claims concluded that the Service abused its discretion by applying taxpayer’s ruling retroactively because fairness required the Service not to tax the taxpayer for the period its competitor avoided excise taxes.

The Service's position is that IBM was incorrectly decided. The Service has never agreed with the holding. The government petitioned the United States Supreme Court, albeit unsuccessfully, for a writ of certiorari, plainly stating its disagreement with the holding. The Service also publicly announced its disagreement with the IBM holding. In AOD 1976-414, in re Rue R. Elson Co., Inc. v. United States, it was stated, "With respect to IBM, we believe the Court of Claims erred in ordering refund of taxes legally owed under the excise tax provisions of the Code." The AOD succinctly describes some of the fundamental difficulties with the IBM concept:

> The concept that an error or omission as to one taxpayer should entitle other similarly situated taxpayers to escape tax in order to achieve "equal justice," or avoid "discrimination," would mean that Congress would no longer determine who is liable for tax. Also, those taxpayers who could not employ discovery and other means to find a "similarly situated" taxpayer who had escaped tax would find the entire tax burden unjustly falling on them. Equal treatment is the goal, but this goal is not fostered by compounding error, and by letting the entire tax burden fall on those who are not "similarly situated" while those who are "similarly situated" escape tax.

IBM's vitality as precedent has been substantially eroded by later judicial pronouncements, including by both the original forum that decided it and its successor court. The same year that IBM was decided, two subsequent decisions of the en banc Court of Claims effectively limited the IBM holding to its facts. _See_ Knetsch v. United States, 348 F.2d 932, 940 n.14 (Ct. Cl. 1965) (limiting IBM as "based on the court's evaluation of the particular circumstances in that case" ), and Bornstein v. United States, 345 F.2d 558, 564 n.2 (Ct. Cl. 1965) (distinguishing IBM on the basis of "controlling factual differences" ). More recently, the Court of Federal Claims held that taxpayers "cannot claim entitlement to a particular tax treatment on the basis of a ruling issued to another taxpayer." Fla. Power & Light Co. v. United States, 56 Fed. Cl. 328 (2003), aff’d, 375 F.3d 1119 (Fed. Cir. 2004) (rejecting an electric utility’s argument that it could rely on private letter rulings issued to other taxpayers in order to seek refunds of heavy vehicle excise taxes). In affirming Florida Power & Light, the Court of Appeals for the Federal Circuit cited Knetsch and Bornstein, supra, noting that the en banc Court of Claims itself had limited the IBM holding to its facts. The Federal Circuit also hinted that the holding in IBM may have been effectively overruled by the Supreme Court's opinion in Dickman v. Commissioner, 465 U.S. 330, 343 (1984), in which the Court acknowledged the Commissioner's authority to change retroactively an earlier interpretation of the law. 375 F.3d at 1124-25 & n.10. _See also_ Peerless Corp. v. United States, 185 F.3d 922, 929 (8th Cir. 1999), in which the Eighth Circuit concluded that the Supreme Court’s holding in Dickman foreclosed the disparate treatment argument under IBM. In Atchison, Topeka, and Santa Fe Railway Co. v. United States, 61 Fed. Cl. 501, 506-07 (2004), involving a claim of disparate treatment under the Railroad Retirement Tax Act, the Court of Federal Claims again directly acknowledged its reluctance to extend the holding of IBM beyond the unique facts of that case. The court held that for a plaintiff to succeed on an "unequal treatment" argument, it must be considered through the equal protection component of the Fifth Amendment's Due Process Clause, _i.e._, whether the retroactive application of a change in interpretation of the law bears a rational relation to a legitimate governmental purpose.

In rejecting a disparate treatment argument based on IBM, the Third Circuit in Merck & Co., Inc. v. United States, 652 F.3d 475, 487 (3d Cir. 2011), stated:

> The policy concerns implicated here are obvious. A simple error by the IRS in applying the tax code should not effectively nullify that provision of the code for all other taxpayers, especially as it is not possible for the IRS to pursue every taxpayer who errs in calculating his tax liability. Further, as the IRS is constantly confronted with attempts of ever-increasing sophistication and variety to evade the tax code, it must be permitted to pursue later tax evaders even if it initially fails to detect a scheme which permits evasion. And if taxpayers could routinely challenge tax assessments by pointing to others who had not been compelled to pay under similar circumstances, the IRS would be swamped by collateral litigation of this kind rather than being able to focus on whether the taxpayer actually complied with the law — which is, in the end, the taxpayer's legal obligation.

Accordingly, the Service will not follow IBM in determining whether to apply adverse rulings or revocations of favorable rulings retroactively. In addition, the Service will not follow IBM in determining whether a taxpayer is entitled to a particular tax treatment because of a claim of disparity with respect to an alleged similarly situated taxpayer, whether or not the taxpayers applied for or received rulings on their respective positions.

**Recommendation:** Nonacquiescence.

|  |  |
| --- | --- |
|  | /s/ <br>Samuel T. Williams<br>Attorney<br>(Procedure and Administration) |
| **Reviewer:**<br>**TJK**<br>**RGG** |  |
| **Approved:** | William J. Wilkins<br>Chief Counsel<br>Internal Revenue Service |
| **By:** | /s/ <br>Deborah A. Butler<br>Associate Chief Counsel<br>(Procedure and Administration) |

### Note:

References to I.R.C. § 7805(b) are to the 1954 Code. The provisions regarding the retroactivity of rulings under I.R.C. § 7805(b) in the 1954 Code were moved to I.R.C. § 7805(b)(8) by the Taxpayer Bill of Rights 2, Public Law 104-168 (110 Stat. 1452, 1468-69 (1996)). Other references to the I.R.C. are to the 1986 Code, as amended.

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part36/irm_36-004-001#addtoany "Show all")

A2A