---
url: "https://www.irs.gov/irm/part30/irm_30-005-001"
title: "30.5.1 Space, Property, Procurement, and Telecommunications | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part30/irm_30-005-001#main-content)

- 30.5.1 [Space, Property, Procurement, and Telecommunications](https://www.irs.gov/irm/part30/irm_30-005-001#idm140010888028160)
  - 30.5.1.1 [Introduction to Space, Property, Procurement, and Telecommunications](https://www.irs.gov/irm/part30/irm_30-005-001#idm140010888028544)
  - 30.5.1.2 [Space Management](https://www.irs.gov/irm/part30/irm_30-005-001#idm140010907139536)

    - 30.5.1.2.1 [Responsibilities for Space Management](https://www.irs.gov/irm/part30/irm_30-005-001#idm140010922167520)
    - 30.5.1.2.2 [Work Environment](https://www.irs.gov/irm/part30/irm_30-005-001#idm140010902745504)
    - 30.5.1.2.3 [Use of Space](https://www.irs.gov/irm/part30/irm_30-005-001#idm140010874474048)

      - 30.5.1.2.3.1 [Requirements and Standards](https://www.irs.gov/irm/part30/irm_30-005-001#idm140010886853152)
      - 30.5.1.2.3.2 [Acquisition, Alteration, or Reduction of Space](https://www.irs.gov/irm/part30/irm_30-005-001#idm140010894298080)
      - 30.5.1.2.3.3 [Increasing, Decreasing or Replacing Staff at Posts of Duty](https://www.irs.gov/irm/part30/irm_30-005-001#idm140010873407504)

    - 30.5.1.2.4 [Miscellaneous](https://www.irs.gov/irm/part30/irm_30-005-001#idm140010880596416)

  - 30.5.1.3 [Property Management](https://www.irs.gov/irm/part30/irm_30-005-001#idm140010894188832)

    - 30.5.1.3.1 [Responsibilities for Property Management](https://www.irs.gov/irm/part30/irm_30-005-001#idm140010899648448)
    - 30.5.1.3.2 [Purchase or Lease of Property](https://www.irs.gov/irm/part30/irm_30-005-001#idm140010899249456)
    - 30.5.1.3.3 [Accountability and Protection of Property](https://www.irs.gov/irm/part30/irm_30-005-001#idm140010874526864)

      - 30.5.1.3.3.1 [Reports of Survey](https://www.irs.gov/irm/part30/irm_30-005-001#idm140010887711392)

    - 30.5.1.3.4 [Maintenance, Repair and Disposal of Property](https://www.irs.gov/irm/part30/irm_30-005-001#idm140010892091536)

  - 30.5.1.4 [Procurement Transactions](https://www.irs.gov/irm/part30/irm_30-005-001#idm140010899546720)

    - 30.5.1.4.1 [Government Purchase Card](https://www.irs.gov/irm/part30/irm_30-005-001#idm140010888731584)
    - 30.5.1.4.2 [Unauthorized Procurements](https://www.irs.gov/irm/part30/irm_30-005-001#idm140010891499264)

  - 30.5.1.5 [Telecommunications](https://www.irs.gov/irm/part30/irm_30-005-001#idm140010895845792)

    - 30.5.1.5.1 [Communications Systems, Services, and Equipment](https://www.irs.gov/irm/part30/irm_30-005-001#idm140010879207392)

      - 30.5.1.5.1.1 [Government Emergency Telecommunications Service (GETS) Card](https://www.irs.gov/irm/part30/irm_30-005-001#idm140010900605056)
      - 30.5.1.5.1.2 [Wireless Priority Service (WPS)](https://www.irs.gov/irm/part30/irm_30-005-001#idm140010902750304)

    - 30.5.1.5.2 [Telecommunications During Travel](https://www.irs.gov/irm/part30/irm_30-005-001#idm140010877939136)
    - 30.5.1.5.3 [Directories](https://www.irs.gov/irm/part30/irm_30-005-001#idm140010907055360)

# Part 30. Administrative

# Chapter 5. Resources, Services, and Financial Management

# Section 1. Space, Property, Procurement, and Telecommunications

* * *

## 30.5.1 Space, Property, Procurement, and Telecommunications

**30.5.1.1** **(10-26-2007)**

### Introduction to Space, Property, Procurement, and Telecommunications

1. This section establishes policy and procedures of the Office of Chief Counsel concerning the acquisition, alteration and use of space; the purchase, accountability and protection of government property; procurement transactions; and communications systems and equipment.


**30.5.1.2** **(03-10-2006)**

### Space Management

1. This subsection establishes policies and guidelines and delegates authority for the management of space occupied by the Office of Chief Counsel.

2. The Office of Chief Counsel will manage space consistent with all applicable laws and regulations, including but not limited to Executive Order 12072, Federal Space Management (Aug. 16, 1978), and those of the Office of Management and Budget, General Services Administration, and the Treasury Department.

3. The Office of Chief Counsel’s objectives with respect to space management are to:



   - Provide an effective working environment for employees

   - Provide efficient workflow

   - Foster effective space use

   - Promote efficiency and economy

   - Aid supervision through effective layouts


4. These policies and guidelines apply to all space occupied by the Office of Chief Counsel. For purposes of this CCDM section, headquarters office refers to any Associate Chief Counsel or Division Counsel office located in the Washington, D.C. metropolitan area not serviced by an Associate Chief Counsel (F&M) Area Manager. A field counsel office is any Chief Counsel office serviced by an (F&M) Area Manager.


**30.5.1.2.1** **(03-10-2006)**

#### Responsibilities for Space Management

1. Unless noted otherwise, the responsibilities listed below may be re-delegated.

2. The Associate Chief Counsel (Finance and Management) is responsible for determining internal policy, procedures, and standards for space management throughout the Office of Chief Counsel.

3. In field counsel offices, the F&M Area Managers are responsible for:



   - Planning for current and projected space requirements in field counsel offices

   - Ensuring proper allocation and use of space

   - Serving as the Office of Chief Counsel’s liaison with AWSS, other government agencies and contractors

   - Recommending action on all requests for space and other related commitments submitted by the divisions

   - Coordinating major space-related decisions with the Managing Counsel

   - Implementing space moves within their Area


4. Associate Chief Counsels and Division Counsels are responsible for submitting requests to the Associate Chief Counsel (F&M) for space modifications that require funding. If approved, the F&M office will support implementation of the projects.

5. It is the personal responsibility of all employees to maintain work areas in accordance with established housekeeping practices, security requirements and applicable safety guidelines.


**30.5.1.2.2** **(03-10-2006)**

#### Work Environment

1. It is the goal of the Office of Chief Counsel to provide a quality work environment that meets functional requirements. The safety and health of employees is a prime consideration when planning space.

2. It is generally desirable, although not required, for Office of Chief Counsel space to be in proximity to the client Service organizations.

3. F&M will ensure that current security guidelines applicable to Chief Counsel organizations are used when planning or renovating space.

4. Consideration will be given to all current safety, and accessibility requirements established by internal directives as well as federal, state, and local authorities.


**30.5.1.2.3** **(03-10-2006)**

#### Use of Space

1. The Office of Chief Counsel is committed to achieving the maximum use of space without adversely affecting employees or their work, creating a satisfactory working environment, and providing efficient use of space.

2. The office of the Associate Chief Counsel (F&M) will periodically review current space holdings to ensure that operations have an appropriate amount of space assigned.


**30.5.1.2.3.1** **(03-10-2006)**

##### Requirements and Standards

1. National Workplace and Occupancy Standards for Chief Counsel were jointly established in November, 1998 by the Office of Chief Counsel and the Service. These standards serve to standardize workspaces throughout the Office of Chief Counsel, promote the effective use of space, and provide optimal flexibility within offices. The workspace furniture standards define the square footage allocation and configuration for individual workspaces based on occupation or position. The occupancy standards establish guidelines for primary office support space and special space requirements unique to the Office of Chief Counsel. When combined, these standards determine the overall space requirements for each Office of Chief Counsel site.

2. The National Workplace and Occupancy Standards for Chief Counsel will be used for new office space acquisitions and relocations, and for office renovation projects. The Standards will be implemented within the physical limitation imposed by the building’s design.

3. The full text of the Standards are maintained by the Associate Chief Counsel (F&M). Questions on the use of the standards may be directed to the office of the Associate Chief Counsel (F&M), or to the servicing Area Manager (F&M) for field offices.


**30.5.1.2.3.2** **(03-10-2006)**

##### Acquisition, Alteration, or Reduction of Space

1. Requests for the acquisition of additional space or relocation of existing space will be based on the business needs of the office.

2. Alterations are defined as any remodeling, improvement, or other physical change to a building. Given available funding, alterations will be undertaken when necessary and at the least cost.


**30.5.1.2.3.3** **(03-10-2006)**

##### Increasing, Decreasing or Replacing Staff at Posts of Duty

1. When divisions consider increasing or decreasing staff at field posts of duty (POD), the headquarters representative designated by the Division Counsel should notify the office of the Associate Chief Counsel (F&M). Notification should include the anticipated POD(s) and the number and type of employees, and should preferably be made via e-mail.

2. When the request is to increase the number or type of staff, the Area Manager (F&M) will advise the Division and the Deputy Associate Chief Counsel (F&M) whether there is available vacant Counsel space to accommodate the expansion and whether alterations are required.

3. When the request for staff increases can be accommodated through the use of offices or workstations not currently occupied but " reserved" for another Division, F&M will contact that Division and Managing Counsel to confirm the continuing need for the vacant office.

4. When requests for staff increases can not be accommodated within Counsel space at the POD, the Area Manager (F&M) will confer with all the Divisions and Managing Counsels that have staff at the POD and with AWSS to determine what actions are necessary, determine and resolve funding issues, develop plans that take the needs of all affected Divisions into account, and undertake appropriate union notification.

5. Area Counsels and Associate Area Counsels will coordinate directly with the Area Managers (F&M) and Managing Counsel, or their designees, when departing staff is replaced.

6. Significant increases in or reductions to staff should be coordinated with F&M with as much lead time as possible.


**30.5.1.2.4** **(03-10-2006)**

#### Miscellaneous

1. _Parking_. The Office of the Comptroller General advises that, generally, parking at a commercial facility in connection with an employee's commute is a personal responsibility of the employee. When parking is provided at government or leased facilities, Counsel organizations will abide by the IRS parking policy in effect.

2. _Disability Accommodations._ Accommodations for the disabled will be provided in accordance with current law and regulations.

3. _Smoking_. The Office of Chief Counsel will adhere to the policies of the Treasury Department and GSA concerning smoking in the workplace.


**30.5.1.3** **(03-10-2006)**

### Property Management

1. This subsection contains the policies, guidelines and delegated authorities for the acquisition, use, and management of personal property in the Office of Chief Counsel.

2. The objectives of the Office of Chief Counsel’s property program are to enable the effective use and management of Government property. Personal property is defined as equipment or property of any kind owned or leased by the Federal Government, except real property (real estate) and records of the Federal Government. Personal property includes office equipment and information systems technology. All types of personal property will be referred to as "property" in the CCDM.

3. The policies and guidelines in this section apply to all employees in the Office of Chief Counsel and to all property owned or leased by the Office of Chief Counsel.

4. The acquisition, use, and management of property will be consistent with all applicable laws and regulations, including, but not limited to those in 41 CFR subtitle C, chapter 101, Federal Property Management Regulations; 48 CFR chapter 1, Federal Acquisition Regulations (FAR); and directives and guidance of the General Accounting Office (GAO), the General Services Administration (GSA), and the Treasury Department.

5. Detailed procedures for the acquisition, use, management, and disposal of property are contained within the F&M Administrative Handbook, CCDM and IRM directives, and various IRS/Office of Chief Counsel letters of understanding and service agreements.


**30.5.1.3.1** **(03-10-2006)**

#### Responsibilities for Property Management

1. Unless noted otherwise, the responsibilities listed below may be re-delegated.

2. The Associate Chief Counsel (F&M) is responsible for determining policies, procedures, and standards for property management throughout the Office of Chief Counsel.

3. The Associate Chief Counsel and Division Counsel have the following responsibilities for their respective offices in the metropolitan Washington D.C. area not serviced by an Area Manager (F&M), and the Area Managers have these responsibilities for their respective field counsel offices:



   - Planning for property requirements

   - Developing cost data for budget planning

   - Ensuring proper inventory, assignment and utilization

   - Serving as liaison with the servicing Modernization, Information Technology and Security Services (MITS) organization

   - The review and approval, as delegated, of requests for property and other related commitments submitted to the Service or GSA


**30.5.1.3.2** **(03-10-2006)**

#### Purchase or Lease of Property

1. Headquarters office. The administrative officer or designated official for each Associate Chief Counsel and Division Counsel will establish procedures for the purchase or lease of property within their organization within designated funding levels. Major purchases or leases of personal property will be requested through and coordinated with the Associate Chief Counsel (F&M) or designee.

2. Field counsel offices. The Area Managers (F&M) will establish procedures for the purchase or lease of all property for offices within their jurisdiction.

3. All requests for the purchase or lease of property will contain the applicable documentation required by the servicing IRS procurement organization.

4. Requests for the purchase or lease of information systems technology will be forwarded by the headquarters administrative officer or Area Manager (F&M) to the servicing MITS/Counsel Information Systems Office (CISO) organization.


**30.5.1.3.3** **(03-10-2006)**

#### Accountability and Protection of Property

1. Associate Chiefs Counsel, Division Counsels, and Associate Chief Counsel (F&M) Area Managers will:



1. Ensure government property is accounted for in accordance with established policies, regulations, and procedures

2. Ensure records are maintained of all property. Property assigned to individuals will be documented by Form 1930, Custody Receipt for Government Property.

3. Conduct periodic property inventories in order to provide controls for the avoidance of waste, fraud, and abuse and to determine whether property meets continuing office requirements. These inventories may be conducted in cooperation with the AWSS office.


2. The Office of Chief Counsel will adhere to all requirements for the protection of government property contained within the Code of Federal Regulations (CFR), GSA regulations and IRS directives. See CCDM 30.6.1, Security of Confidential Information, Official Documents, Tax Data, Personnel, and Property, http://publish.no.irs.gov/getpdf.cgi?catnum=29269.

3. Associate Chief Counsel, Division Counsel and Area Managers (F&M) will provide guidance and direction regarding the safeguarding and protection of property.

4. All employees are responsible for protecting Government property (whether or not it is personally assigned to them) in their work areas, complying with established procedures, and reporting loss, damage or misuse of property to their supervisor.


**30.5.1.3.3.1** **(03-10-2006)**

##### Reports of Survey

1. Reports of Survey are used to investigate loss, theft, damage, or destruction of Government-owned or leased property, not caused by normal wear and tear. The purpose of the investigation is to determine the facts and circumstances surrounding the loss, to establish the amount of the loss, and to recommend whom, if anyone, should be held financially liable for the loss. Current dollar thresholds and procedures for Reports of Survey can be found in GSA and IRS guidelines.

2. Associate Chiefs Counsel and Division Counsels are designated as the approving authority for Reports of Survey for their offices in the Washington, D.C. metropolitan area not serviced by an F&M Area Manager. In that capacity, they take final action on Reports of Survey generated in their area of responsibility. This authority may not be re-delegated.

3. The Associate Chief Counsel (F&M) is designated as the approving authority for Reports of Survey for field counsel offices and offices under his/her jurisdiction.


**30.5.1.3.4** **(03-10-2006)**

#### Maintenance, Repair and Disposal of Property

1. Procedures for the maintenance and repair of property can be found in the F&M Administrative Handbook and in MITS/CISO procedures.

2. Prior to disposing of property (other than information systems technology) in the Headquarters office, administrative officers or designated officials will determine whether the property is required in other headquarters offices. Upon determination that the property is surplus, administrative officers or designated officials will coordinate with AWSS to excessing property.

3. Prior to disposing of property (other than information systems technology) in field Counsel offices, office managers will determine whether the property is required in other field offices, taking into account the condition of the property, transportation charges, etc. Upon determination that the property is surplus, office managers will coordinate with the servicing AWSS office and follow appropriate procedures for excessing property.

4. Disposal of information systems technology property determined to be surplus is the responsibility of the servicing MITS/CISO organization.


**30.5.1.4** **(03-10-2006)**

### Procurement Transactions

1. All procurement transactions will comply with the FAR and applicable Treasury Department and IRS procurement regulations. Only contracting officers, and their duly authorized representatives, acting within their authority are authorized to commit the Government with respect to the award of contracts and purchase orders. Unauthorized personnel shall not make any commitment or promises relating to the award of contracts or purchase orders and will make no representation which could be construed as such a commitment. No Chief Counsel personnel will under any circumstances indicate to a business representative or firm that attempts will be made to influence another person or agency to give preferential treatment to his/her concern in the award of future contracts. Any person requesting preferential treatment will be informed by official letter that Treasury contracts are awarded only in accordance with established contracting procedures.

2. Requisitions for goods or services will be prepared through the Requisition Tracking System (RTS). All applicable information and documentation should be provided when submitting the requisition.



1. Headquarters office. Requisitions for goods or services should be submitted via RTS to the administrative officer or designated official, who will follow applicable procedures depending on the goods or services requested, dollar amount involved, etc.

2. Field counsel offices. F&M Area Managers will establish procedures for the submission and processing of requisitions for goods or services via RTS in field offices under their jurisdiction.


3. All expenditures, regardless of cost, must be authorized in advance.


**30.5.1.4.1** **(03-10-2006)**

#### Government Purchase Card

1. Regulations and guidelines for the Government purchase card are established by GSA, the Treasury Department and AWSS. The purchase card may be used as a stand-alone procurement instrument or used to place orders against established contracts if the terms of the contract authorize the use of the purchase card. Use of the purchase card does not relieve the cardholder from any requirements of the FAR, Treasury Department, Office of Chief Counsel or IRS regulations. Specific procedures to be followed are contained in Document 9185, IRS Purchase Card Guide, which may be viewed at http://publish.no.irs.gov/getpdf.cgi?catnum=17191 .

2. The Associate Chief Counsel (F&M) is responsible for developing any necessary supplemental operating guidelines for the use of the card within the Office of Chief Counsel.

3. In the Headquarters office, Administrative officers or designated officials are responsible for identifying cardholders within their organizations and developing internal procedures.

4. Area Managers (F&M) or their designees are responsible for identifying cardholders within their organizations and developing procedures for Field counsel offices in their jurisdictions.


**30.5.1.4.2** **(03-10-2006)**

#### Unauthorized Procurements

1. A commitment to purchase goods or services by other than a contracting officer or their duly authorized representative (e.g., Government purchase cardholder) acting within their authority is an unauthorized obligation/commitment or unauthorized procurement. Generally, unauthorized procurements are not binding on the Government. In addition, employees who make them are risking personal liability for payment to the vendor and potential disciplinary action by agency management.

2. Employees who become aware of a potential unauthorized procurement are responsible for promptly reporting the matter to their manager.

3. Managers should consult the servicing IRS Procurement office for guidance whenever an unauthorized procurement may have occurred.

4. Authority to ratify most unauthorized procurements rests with the IRS procurement organization. Requests to ratify an unauthorized procurement must be submitted through channels to the appropriate Associate Chief Counsel or Division Counsel. Requests must state the factual circumstances and contain the applicable documentation described in Treasury Department and IRS procurement regulations.

5. Requests for ratification of unauthorized procurements will not automatically be approved. If the appropriate Associate Chief Counsel or Division Counsel concurs with the request based on the circumstances and documentation, he/she will submit the request to ratify an unauthorized procurement to the servicing IRS procurement organization for processing.

6. Requests for ratifications of $100,000 or more must be reviewed by the Associate Chief Counsel (F&M) and Chief, Public Contracts & Technology Law Branch, General Legal Services, for concurrence and legal sufficiency before the request is transmitted to the Treasury Department for approval.


**30.5.1.5** **(03-10-2006)**

### Telecommunications

1. This subsection establishes policies and guidelines for the use of telecommunications by Chief Counsel employees.

2. The Office of Chief Counsel will adhere to the telecommunications policies and regulations of GSA, the Treasury Department and IRS, and will develop appropriate policies when necessary.


**30.5.1.5.1** **(03-10-2006)**

#### Communications Systems, Services, and Equipment

1. The acquisition of telecommunications systems must be supported by a requirements analysis and a cost/benefit analysis.

2. Procedures for adding, removing, or relocating communications equipment, services or lines, including voice mail and voice messaging systems, and for the maintenance of equipment and systems, are contained within applicable IRS directives.

3. Cell phones are provided for official government use for management officials in designated positions.

4. Government telephone credit cards may be issued to employees for making long distance calls for business purposes. Employees who are approved by their manager and meet one or more of the criteria listed below may obtain a card:



   - Travel in-and-around the commuting area, incurring long distance charges when calling back to the office, taxpayer, or employee's residence

   - Perform city-to-city travel (outside the commuting area) at least twice a year

   - Place international calls (limited to managers and Special Trial Attorneys)

   - Work flexiplace


5. Charges for directory assistance should be avoided if at all possible. Directory assistance should only be used when the information cannot be obtained by the telephone directories provided and are absolutely necessary. Employees that have access to the Internet should search one of the various white/yellow pages web sites. If information must be obtained from the directory assistance operator, the call should be direct-dialed to the information operator (9-411) or long distance information at 9-(area code) 555-1212.

6. Employees are discouraged from accepting collect calls except in the case of emergencies. Employees should notify their manager if such an emergency arises.

7. Telecommunications systems have a variety of capabilities for conferencing. Employees should consult their local Finance & Management staff or designated administrative representative for assistance. When arranging a telephone conference that exceeds system capabilities, the following methods may be used:



1. Employees located in the Washington D.C. metropolitan area may use the Treasury Department bridge. Instructions are provided in the F&M Administrative Handbook.

2. Employees in field counsel offices may use their government telephone credit card to place the conference call. Instructions may be obtained from the local Finance & Management staff.


8. Many telecommunications systems do not allow international calls to be made from all instruments or lines. Phones that are programmed for international calls should be located in a manager's office or conference room. If an international call needs to be made from a phone that is blocked, the employee should utilize their Government telephone credit card if the card is authorized for international calls.


**30.5.1.5.1.1** **(10-26-2007)**

##### Government Emergency Telecommunications Service (GETS) Card

1. Government Emergency Telecommunications Service (GETS) is provided by the Department of Homeland Security, National Communications Service for use during emergency events. See CCDM 30.6.2 at http://publish.no.irs.gov/getpdf.cgi?catnum=29610 for those individuals in Chief Counsel authorized a GETS card.

2. The GETS card will be turned over to the Administrative Officer or Office Manager when leaving the employ of the Office of Chief Counsel through separation or retirement. The card will be sent to Planning and Finance for termination of service and destruction.


**30.5.1.5.1.2** **(10-26-2007)**

##### Wireless Priority Service (WPS)

1. Wireless Priority Service (WPS) is a priority calling capability that greatly increases the probability of call completion when Emergency Preparedness user is unable to complete emergency calls while using their cellular phone. When an Emergency Preparedness user encounters difficulty completing an emergency call using their cell phone, they should re-attempt the call using WPS. See CCDM 30.6.2 for those individuals in Chief Counsel authorized WPS.


**30.5.1.5.2** **(03-10-2006)**

#### Telecommunications During Travel

1. Employees are encouraged to use Government telephone credit cards for all telephone calls while in travel status.

2. Travelers will receive reimbursement for local and long distance telephone calls made for official business. Procedures, guidelines, restrictions, and documentation for reimbursement are contained in current IRS travel guidance.

3. Employees may receive reimbursement for emergency personal telephone calls while in travel status.

4. Employees in travel status for more than one day may make one brief call to their residence each day.


**30.5.1.5.3** **(03-10-2006)**

#### Directories

1. Location Information for Office of Chief Counsel organizations and employees can be accessed via the Chief Counsel intranet. This directory contains not only telephone numbers and office addresses, but is also a source of other information such as office symbols, e-mail addresses, and the like. This directory contains live data that is updated at the National Office on a weekly basis.

2. The Associate Chief Counsel (F&M) is responsible for monitoring the status of the Chief Counsel web page and all related links. This includes automated reports, lists, and informational sites. Procedures for updating personal and organizational data may be obtained from administrative offices within the National Office or from Planning and Finance.

3. Telephone numbers and other information for IRS and Office of Chief Counsel employees can be accessed through the Discovery Directory on the IRS intranet site.


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part30/irm_30-005-001#addtoany "Show all")

A2A