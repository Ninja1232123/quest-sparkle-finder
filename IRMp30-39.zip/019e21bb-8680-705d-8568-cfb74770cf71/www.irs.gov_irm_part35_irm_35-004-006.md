---
url: "https://www.irs.gov/irm/part35/irm_35-004-006"
title: "35.4.6 Responding to Petitioner’s Information Gathering Attempts | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-004-006#main-content)

- 35.4.6  [Responding to Petitioner’s Information Gathering Attempts](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103092411232)
  - 35.4.6.1  [Introduction; Respondent’s Duty](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103092339712)
  - 35.4.6.2  [Responding to Requests for Admission](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103092336464)
  - 35.4.6.3  [Defenses Against Discovery](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103092434208)
    - 35.4.6.3.1  [Petitioner’s Failure to Abide by Court Rules](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103092433328)
    - 35.4.6.3.2  [Statutory Restrictions on Discovery from Respondent](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103092428928)
    - 35.4.6.3.3  [Privileges](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103092426320)
      - 35.4.6.3.3.1  [Governmental, Executive, Deliberative Process, or Informant’s Privilege](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103092423264)
        - 35.4.6.3.3.1.1  [Deciding Who May Claim the Deliberative Process Privilege](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103119386176)
        - 35.4.6.3.3.1.2  [Procedures for Formal Claim of the Privilege](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103119378832)
      - 35.4.6.3.3.2  [Approval Procedures for Identifying Confidential Informants](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103119367696)
      - 35.4.6.3.3.3  [Attorney-Client Privilege](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103119269616)
        - 35.4.6.3.3.3.1  [Specific Applications](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103119265936)
        - 35.4.6.3.3.3.2  [Waiver of the Privilege](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103119258848)
      - 35.4.6.3.3.4  [The Federally Authorized Tax Practitioner Privilege](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103119255200)
      - 35.4.6.3.3.5  [Work Product Doctrine](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103119251088)
      - 35.4.6.3.3.6  [Other Privileges That Petitioners May Raise](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103119245488)
      - 35.4.6.3.3.7  [Use of Whistleblower Information](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103092402368)
    - 35.4.6.3.4  [Impeachment Evidence](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103092387728)
  - 35.4.6.4  [Cases Having Related Criminal Aspects](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103092382592)
    - 35.4.6.4.1  [General Procedures for Protecting the Criminal Case](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103092378896)
    - 35.4.6.4.2  [Stipulation of Facts and Formal Discovery](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103092371552)
    - 35.4.6.4.3  [Pre-Trial Conferences](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103092365888)
  - 35.4.6.5  [Protective Orders](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103092363168)
    - 35.4.6.5.1  [Protective Order Procedures, Generally](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103092504080)
    - 35.4.6.5.2  [Protective Order Procedures, Whistleblower Proceedings](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103092493328)
  - 35.4.6.6  [Petitioner’s Subpoena Served on the Internal Revenue Service](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103092480928)
  - 35.4.6.7  [Disclosure in Tax Court Cases](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103092476560)
    - 35.4.6.7.1  [Disclosure of Security Threats at Tax Court Calendars](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103092471712)
    - 35.4.6.7.2  [Classified or Restricted Information](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103092469920)
    - 35.4.6.7.3  [Discovery of Unrelated Third Party Tax Returns](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103092464240)
    - 35.4.6.7.4  [In Camera Inspections](https://www.irs.gov/irm/part35/irm_35-004-006#idm140103119354944)

# Part 35. Tax Court Litigation

# Chapter 4. Pre-Trial Activities

# Section 6. Responding to Petitioners Information Gathering Attempts

* * *

## 35.4.6 Responding to Petitioner’s Information Gathering Attempts

#### Manual Transmittal

November 25, 2019

#### Purpose

(1) This transmits revised CCDM 35.4.6, Pre−Trial Activities; Responding to Petitioner’s Information Gathering Attempts.

#### Material Changes

(1) CCDM 35.4.6.3.3.7, Use of Whistleblower Information, was added to describe the process for completing and returning Form 11369, **Confidential Evaluation Report on Claim for Reward**, to the Whistleblower Office for cases in which Counsel uses whistleblowers or whistleblower information.

(2) CCDM 35.4.6.5 was revised to describe how case files with protective orders should be handled.

(3) CCDM 35.4.6.5.1 was added to describe the procedures that apply to protective orders in all cases.

(4) CCDM 35.4.6.5.2 was added to describe the procedures for protective orders in whistleblower proceedings.

#### Effect on Other Documents

This section supersedes CCDM 35.4.6 dated April 25, 2017.

#### Audience

Chief Counsel

#### Effective Date

(11-25-2019)

Kathryn A. Zuba

Acting Associate Chief Counsel

(Procedure & Administration)

**35.4.6.1** **(02-16-2016)**

### Introduction; Respondent’s Duty

1. Respondent’s duty to cooperate with petitioners in preparing cases for trial and to abide by the letter and spirit of the Court’s discovery rules is at least as great of that of petitioners.

2. The rules and procedures for informal and formal discovery (including admissions) described in CCDM 35.4.3, Gathering Information from the Petitioner, apply to respondent as well as petitioners. While both respondent and petitioners may assert certain defenses to discovery attempts by the other party, particular defenses are unique to respondent. See CCDM 35.4.6.3 and CCDM 35.4.6.7.2. In addition, certain considerations in responding to requests for admission present particular concerns for respondent. See CCDM 35.4.6.2.

3. Procedures regarding litigation holds and e-discovery are located in CCDM 34.7.1.1.4.


**35.4.6.2** **(08-16-2010)**

### Responding to Requests for Admission

01. Where respondent has been served with a request for admissions concerning a document, and the copy of the document itself is not attached, dangers may arise in admitting the authenticity of the document even if the revenue agent has previously obtained a copy for the administrative file. Conceivably, there may be more than one document which would qualify under the same general description contained in the request for admissions. As a result, the Field attorney should never admit the genuineness of a document (or a copy) that is not attached to the request for admission.

02. While requests for admission are "self-executing" in that a failure to respond is the equivalent of an admission, respondent’s counsel must file an appropriate response to every request for admission, even if the Field attorney intends to admit every request. Failure to do so not only reflects badly on the Field attorney and the Office of Chief Counsel, but may subject respondent to sanctions. See T.C. Rule 90(g).

03. By motion timely filed, the normal 30-day period for a response may be enlarged or shortened by court order. See CCDM 35.4.3.5.3, Responses to Requests for Admission — T.C. Rule 90(c). The timely filing of such motion by respondent when an adequate response cannot be made within the 30-day period is highly important. Similarly, in the event petitioner seeks to shorten the 30-day period, the Field attorney, in consultation with Procedure & Administration, Branches 6 & 7, should consider the preparation of an objection to the petitioner’s motion.

04. In lieu of a response to each separate request, the respondent may serve an appropriate objection to the matters requested. If the scope and tenor of the requested matters appear proper, but respondent cannot truthfully admit or deny such matters, a statement of the reasons for such inability to admit or deny must be set forth in the response.

05. A qualified response may not be made on the basis of lack of information or knowledge of the requested matter unless the responding party also states that reasonable inquiry has been made and that the information known or readily obtainable is insufficient to enable the party to admit or deny. What constitutes a reasonable inquiry will vary under the facts and circumstances of each situation. Respondent should not use administrative summonses on third parties in order to ascertain facts in compliance with the reasonable inquiry concept, but public records, or third party documents that are readily available without refusal of cooperation, should be obtained or examined in order to facilitate a proper response.

06. When contemplating a response which states that the matter cannot be admitted or denied although reasonable inquiry and diligent effort has been made, the Field attorney should consider contacting petitioner or petitioner’s counsel to determine further sources of inquiry. If the information requested is in the possession of the petitioner, the Field attorney is not required to take the information at face value without right of cross-examination.

07. A request may seek admission or denial of whether third persons performed certain acts. If the only sources of relevant information are the third parties themselves, consideration might be given to a response which neither admits nor denies on the grounds that respondent, without right of examination or cross-examination of the third parties under oath, should not be forced to take their information at face value. This presupposes that the Field attorney has at least arguable grounds to doubt the information offered by the third party.

08. In preparing the response to a request for admission, the Field attorney may conclude that some items may be responded to by admissions or denials, but that objections may exist to other items. In such a case, it is possible to either include the objections in the response or to file a separate objection to the specific items to which it is believed no response should be made. The responses and objections should be combined in one document, unless exceptional circumstances warrant the use of an objection document separate from a response document.

09. Although the last sentence of T.C. Rule 90(f) states that an admission by a party cannot be used against the party in any other proceeding, doctrines such as "judicial estoppel" may allow the use of an admission made in a particular Tax Court case against the respondent in a subsequent proceeding in another court. Leaving the estoppel argument aside, in a subsequent Tax Court proceeding the respondent would be hard-pressed to explain why, having admitted a matter in an earlier case, respondent now refuses to take the same position in the later case. Therefore, it is good practice for respondent, when responding to requests for admission, to admit items only if they are known to be true and only on consideration of any possible effects on matters outside the pending case. No admissions (and no answers to interrogatories or stipulations of fact) should be made for bargaining or trading purposes.

10. Under T.C. Rule 90(a), a party is obliged to respond to requests for admissions even though the response involves an opinion or contention of fact or of the application of law to fact. From time to time, a requested admission may be proposed in a form which will request certain facts to be taken into account and, if admitted, then propound a request for admission or denial of a legal conclusion.



    1. For example, a question might be phrased as follows: "Does respondent admit the authenticity and genuineness of the document attached hereto as Exhibit A and denominated 'Lease Agreement'? If the answer to the first question is yes, does respondent admit petitioner became a lessor of the assets described in said document to the X corporation upon execution hereof?"

    2. Or, another request might simply ask whether the respondent admits or denies that the only issue in the case (or the only basis of the adjustment in the statutory notice) concerns a specific item, such as "Does respondent admit that the only issue in this case is whether the petitioner can substantiate the dollar amount of payments to Corporation XYZ?"

    3. Pursuant to T.C. Rule 90(a), these types of requests are proper and must be answered.


11. If the statutory notice is precisely drawn, respondent should be readily able to admit or deny the basis of the adjustment in the statutory notice. But any admission as to what constitutes an issue should be couched in terms to the effect that, based upon the respondent’s present analysis of the files and the facts as currently available, the only issue is as stated in the request for admissions. This would facilitate raising an affirmative issue at a later date. Neither respondent nor petitioner is required to speculate in giving responses to requests for admissions simply because of the general proposition that opinions of fact or of the application of law to fact are within the scope of matters for which admissions may be sought under T.C. Rule 90(a).

12. In connection with a request to admit the genuineness of a document, care should be exercised where the respondent has no doubt as to the authenticity of the document but contests its substance. For example, in a debt versus equity case involving a shareholder, the respondent may be willing to admit the authenticity of a promissory note or mortgage or other evidence of indebtedness. But care should be taken to qualify the admission by denying that respondent accepts the substance of the documents or agrees with the labels borne by the documents.

13. While a lack of relevance objection will not relieve respondent of the duty to answer, extreme caution should be used with respect to requests to admit or deny documents indicating that the petitioner is seeking to go behind the notice of deficiency or other determination letter and attempting to litigate matters concerning the reasoning or mental impressions of the revenue agent (or the agent’s reviewer) or the accuracy or inaccuracy of such documents as a revenue agent’s report, a no−change letter, etc., even though respondent does not dispute the authenticity of certain reports, such as the revenue agent’s report or reports concerning other years. A timely objection to such requests for admissions should be served and filed.

14. In the event that a petitioner moves for sanctions or an order requiring a response to a request for admission of documents subject to a relevancy objection, a possible defense can be found in T.C. Rule 90(g), which provides that sanctions will not be imposed if the court finds that the admission sought was of no substantial importance. Similarly, rather than routinely admitting matters which are clearly irrelevant and utterly without any bearing on the case, the literal language of the last sentence of T.C. Rule 90(c) should not be followed without first making an objection. See also T.C. Rule 90(a), stating that a request should concern relevant matters. The mere fact that, by interrogatory or a request for production, the respondent has disclosed or produced or agreed to the authenticity of Service documents (such as a revenue agent’s report or a no−change letter) is not to be construed as requiring an admission as to such documents under T.C. Rule 90.


**35.4.6.3** **(08-11-2004)**

### Defenses Against Discovery

1. This sub-section discusses defenses against discovery.


**35.4.6.3.1** **(08-11-2004)**

#### Petitioner’s Failure to Abide by Court Rules

1. If a _pro se_ petitioner or petitioner’s counsel sends formal discovery to respondent’s counsel without first satisfying the _Branerton_ requirements, the Field attorney should send a letter, advising the requester of the _Branerton_ requirements and stating that respondent will treat the requests as informal.

2. Generally, a motion for protective order should not be filed if the sole ground is the failure of petitioner to make an informal request.


**35.4.6.3.2** **(08-11-2004)**

#### Statutory Restrictions on Discovery from Respondent

1. The primary statutory restrictions on respondent’s disclosure of information are contained in IRC § 6103. See CCDM 35.4.6.7.


**35.4.6.3.3** **(08-16-2010)**

#### Privileges

1. In general, matters which would be privileged against disclosure at the trial of the case are similarly privileged for pretrial discovery purposes. See T.C. Rules 70(b), 143. In each instance, the pleadings, answers to interrogatories, or admissions should be examined from the view of whether there has been a waiver of any privilege.

2. The court may draw adverse inferences in some instances from the assertion of a privilege by either petitioner or respondent.

3. Privilege may be an appropriate defense to discovery requests. The decision not to assert an available defense based on privilege is a serious matter requiring coordination with the Area Counsel or Associate Area Counsel in charge of the particular case and the Associate Chief Counsel with subject matter jurisdiction over the substantive issues in the case. If there is doubt whether a particular defense based on privilege is applicable or should be waived, advice should be secured from Procedure & Administration, Branches 6 & 7, who will coordinate with the appropriate Associate Chief Counsel.


**35.4.6.3.3.1** **(04-25-2017)**

##### Governmental, Executive, Deliberative Process, or Informant’s Privilege

1. The deliberative process privilege (sometimes referred to as the executive or governmental privilege) is a qualified privilege that protects from disclosure certain statements of advice, deliberation, and recommendation of governmental officials. In order to successfully claim the privilege, the respondent must show that a document is predecisional, _i.e._, "antecedent to the adoption of an agency policy" , and deliberative, _i.e._, "a direct part of the deliberative process in that it makes recommendations or expresses opinions on legal and policy matters." In considering the qualified nature of the privilege, the court will weigh the gravity of the need for disclosure only against the harm that disclosure may do to intragovernmental candor. Insofar as they contain statements of advice, opinions, conclusions, mental impressions, thought processes, and recommendations that are part of the deliberative process, certain documents commonly found in the administrative file and related files may be protected from discovery under privilege variously referred to as the governmental privilege, executive privilege, or deliberative process privilege. They include such items as:



   - Revenue Agent’s Reports and transmittal letters (T-letters, whose main purpose is to provide a place to summarize unagreed issues and to present information of a confidential nature, including the agent’s comments on the information contained therein)

   - Special Agent’s Reports

   - Appeals Case Memoranda (as well as its predecessor documents — Appeals Supporting Statements, Appellate Conferee’s Report, and District Conferee’s Report)

   - Memoranda to the file prepared by an Internal Revenue Service (Service) agent containing legal theories, thought processes and conclusions

   - Memoranda from an Associate office to Field Counsel or to an operating division


2. Purely factual material appearing in any of these documents is not protected by privilege if it is in a form that is severable without compromising the private remainder of the document.

3. Requests for production of documents, which are in the custody of other government agencies, should be resisted.

4. The governmental privilege is not absolute, but is qualified in that the petitioner’s need for disclosure may outweigh the need to keep the material confidential. Respondent will assert the privilege only if disclosure of the materials sought would significantly impede or nullify Service actions, or would constitute an unwarranted invasion of personal privacy.

5. Materials revealing the identity of a confidential informant are subject to the governmental privilege, specifically the informant’s privilege. Under the informant’s privilege, the government is not required to disclose the identity of an informant, unless the disclosure is vital to a fair trial. Additionally, under I.R.C. § 6103(h)(4), the Service may withhold disclosure of a return or return information in administrative and judicial proceedings if it determines that the disclosure will identify a confidential informant or seriously impair a civil or criminal tax investigation.

6. The Service and the Office of Chief Counsel (Counsel) have committed to using their best efforts to protect the identity of any confidential informant, which includes any individual that provides information to the Service under I.R.C. § 7623 (whistleblower). In some instances, however, it may be necessary and in the government’s best interests to reveal the identity of a confidential informant. The Service and Counsel have procedures for obtaining approval to identify confidential informants in civil tax matters. Under these procedures, the Service and Counsel will carefully consider and weigh the potential risks of disclosure and the government’s need for disclosure, and look for alternative solutions. When disclosure is necessary, the Service and Counsel will make every effort to notify the confidential informant prior to disclosure. Any question regarding the potential disclosure of the identity of a confidential informant should be immediately referred to Procedure & Administration, Branch 5. These procedures do not apply to criminal matters. For guidance with respect to criminal matters, refer to [IRM 9.4.2.5, Informants](http://publish.no.irs.gov/getpdf.cgi?catnum=36205).


**35.4.6.3.3.1.1** **(06-15-2011)**

###### Deciding Who May Claim the Deliberative Process Privilege

1. When the Field attorney and reviewer conclude that the deliberative process privilege should be claimed, a determination must be made as to whether privilege should be claimed, and the claiming affidavit executed, by the Commissioner, the head of another government agency, a delegated executive, an Associate office manager, or the Field attorney. There is no controlling Tax Court precedent on who should assert the deliberative process privilege in the Tax Court, and different divisions of the court have reached different conclusions in unpublished orders regarding who may assert the deliberative process privilege in particular cases.

2. In the absence of controlling contrary precedent, Service position continues to be that assertion of the deliberative process privilege in the Tax Court may be made by the Field attorney. Nevertheless, there are obvious hazards in maintaining such a position. Administrative realities dictate that these hazards cannot routinely be avoided by acquiring an affidavit from the Commissioner or the Deputy Associate Chief Counsel (Procedure & Administration) on every occasion when assertion of the deliberative process privilege before the Tax Court is contemplated. It is therefore of critical importance that a proposed assertion of the deliberative process privilege in Tax Court cases be quickly and carefully coordinated with Procedure & Administration, Branches 6 & 7. In deciding how to proceed, the Field attorney and the Associate offices will take into account the nature of the controversy, the documents or information sought, the degree of harm anticipated if disclosure were ordered, the amount in controversy, the status of the proceedings, and any other information relevant to the determination of the privilege issue.

3. The deliberative process privilege may be asserted by the Field attorney during initial responses to informal and formal discovery requests prior to a final determination of who should formally assert the privilege before the court in an enforcement action.

4. In the event a determination is made that the privilege should be claimed by the Commissioner, then, under Delegation Order No. 30-4, the Deputy Associate Chief Counsel (Procedure & Administration) may execute the affidavit to claim the privilege. If a determination is made that the Field attorney or some other official may claim the privilege, then that person may execute the affidavit.


**35.4.6.3.3.1.2** **(06-15-2011)**

###### Procedures for Formal Claim of the Privilege

1. As soon as practicable after a request for production of documents, notice of deposition, or interrogatories is received by the Field attorney, the attorney should analyze the request for discovery and determine the nature of the information sought and whether any of the requested information is privileged within the parameters of the deliberative process privilege. If the information sought includes communications in the custody of an Associate office or another Field Counsel, the Field attorney should request assistance from the other office.

2. Next, the requested documents should be gathered. Particular attention should be paid to time constraints and requests for enlargement of time, if necessary, should be sought from opposing counsel and the court. In such situations, the attorneys involved may be required to testify or file declarations regarding the exhaustiveness of the search. Therefore, a written record of the search should be made to assist the Field attorney in documenting the search.

3. Ordinarily, the determination whether to assert the deliberative process privilege should be coordinated with the originating office of the information or documents in question, in order to gain the fullest understanding of the nature of the material and how its disclosure may affect that office’s operations. If Service and Counsel files contain documents originating from other government agencies (including the Department of the Treasury), the Field attorney should not make the final determination regarding these documents. Rather, copies of such documents should be sent to the originating agency so that the originating agency may make the determination. A recommendation may be made where appropriate.

4. Portions of communications that are not within the privilege should be segregated from privileged material (if any) and made available if relevant to the request and if they are not subject to any other privilege or statutory bar to disclosure (such as tax return information of a third party; see CCDM 35.4.6.7). Tax return information and other material to be redacted should be highlighted or otherwise indicated (but not blackened so as not to impede the review process). Communications that are within the privilege should be indexed and tabbed. The index should contain a description of the communication in sufficient detail to illustrate its privileged nature but protect its contents, and should be sufficiently detailed to demonstrate to the court that a reasonable search was done. The tabs should correspond to the index. A declaration should be prepared with the index attached to it. The communications should then be copied and placed in two separate packages. One should be a complete package of all documents in order. The other should be a complete package of all documents, with privileged documents separated from those that will be released.

5. The declaration, index, and copies of the privileged documents, together with a transmittal memorandum, should be placed in one package. A copy of the petitioner’s discovery request should also be part of the package. The package should be forwarded to Procedure & Administration, Branches 6 & 7 for review. The transmittal memorandum should cite any cases that establish the need for the agency head’s formal claim of privilege and reflect how disclosure may adversely affect the originating office’s operations.

6. After completing its review, Procedure & Administration will either:



1. For non-Delegation Order No. 30-4 cases, make and keep a copy of the index, and return the documents, along with the index and, if appropriate, a declaration of an Associate office manager, to the responsible Field Counsel, or

2. For cases that require the signature level set forth in Delegation Order No. 30-4, forward the declaration, index and privileged documents to secure the signature of the Deputy Associate Chief Counsel (Procedure & Administration ). In the latter situation, after the declaration is signed, Procedure & Administration will forward the originals to the responsible Field Counsel. Procedure & Administration will maintain a copy of the index and declaration for protected documents.


7. The executed declaration, along with the two packages of documents, will be provided to the responsible Field Counsel in sufficient time for response to petitioner’s discovery requests.


**35.4.6.3.3.2** **(04-25-2017)**

##### Approval Procedures for Identifying Confidential Informants

1. The Internal Revenue Service (Service) and attorneys of the Office of Chief Counsel (Counsel attorney) must obtain approval from the Deputy Chief Counsel (Operations) before disclosing the existence or identity of a confidential informant. To request approval, Counsel attorneys must submit a memorandum, approved by Division Counsel, to Procedure and Administration (PA), Branch 5, in the format described below. PA will coordinate through Criminal Tax with IRS-CI to determine whether there is any potential overlap with a related criminal matter. In cases in which there is potential overlap with a criminal matter, PA will seek approval from IRS-CI, Director of Operations, Policy and Support. The views of IRS-CI will be incorporated into the memorandum. In cases involving a confidential informant that is a whistleblower, PA will forward the memorandum to the Director of the IRS Whistleblower Office (Whistleblower Office Director) for review and consideration. If the Whistleblower Office Director approves, and in all cases that involve a confidential informant that is not a whistleblower, PA will then forward the memorandum to the Deputy Chief Counsel (Operations) for review and consideration. PA will communicate the ultimate denial or approval to the Counsel attorney.

2. Regardless of whether approval to disclose is ultimately sought, all cases in which a court orders the Service or a Counsel attorney to disclose information that could identify the existence or the identity of a confidential informant should be immediately coordinated with PA, Branch 5. Finally, any disclosure of a confidential informant that occurs without approval, must also be immediately coordinated with PA, Branch 5.

3. Format of Memorandum for Approval



   - Subject and Heading: State the reason for the request. For example, request to use a confidential informant as a witness or request to use documents that may identify the existence or identity of a confidential informant. The subject line should also provide the case name, docket number, and the whistleblower claim number (if applicable).

   - Purpose: State the purpose of the memo, e.g., to call the confidential informant as a witness or use documents that may identify the confidential informant. This section should also explain any time limitations, such as an expiring assessment statute or any relevant trial deadlines.

   - Background and Issues: Provide a brief summary of the pertinent facts of the case, including a general overview of the case and an explanation of why it is necessary to reveal the existence or identity of a confidential informant. If the request is to use a confidential informant as a witness, the facts should explain how the informant obtained the relevant knowledge, the informant's relationship to the taxpayer, and any other relevant facts about the informant. If the request is to use confidential informant documents in a manner that could identify the informant, the Counsel attorney should describe the documents, the information contained in the documents, and any known information about how the informant acquired the documents. Following the statement of facts, provide a brief explanation of the relevant issues and law related to the alleged tax noncompliance along with a description of the Service’s position and the taxpayer’s position.

   - The Confidential Informant is a Necessary Witness/the Confidential Informant Documents are Essential to the Service’s Case: This section should tie together the facts and issues stated in the section above to explain the following: (1) why the informant is needed to testify or the informant documents are needed for the government’s case; (2) alternatives to disclosure, if any, and whether or not they are available; (3) how the informant or informant documents would be used to prove the government’s case; (4) the extent of any known potential risks faced by the informant as a result of being identified; (5) whether any privilege issues exist; (6) whether there are any unusual contacts or other issues relating to the informant's relationship with the Service; and (7) any other information that may be relevant in weighing the protection of the informant’s identity against the government’s interest.

   - Disclosure: This section should state whether the confidential informant is represented by an attorney and whether the informant is willing to be identified. This section should also note any concerns or requests that the confidential informant expresses with respect to being identified. The Counsel attorney must explain to the confidential informant that his or her status as an informant or whistleblower will have to be disclosed if used as a witness.

   - Conclusion: This section should summarize how revealing the existence or identity of the confidential informant is necessary to prove the government’s case.


**35.4.6.3.3.3** **(08-11-2004)**

##### Attorney-Client Privilege

1. While the attorney-client privilege will be asserted more frequently by petitioners than by respondent, there will be occasions when consideration should be given to asserting the privilege on behalf of the Service.

2. The scope of the attorney-client privilege should be strictly confined within the narrowest possible limits. The burden of establishing the existence of an attorney-client privilege rests on the claimant of the privilege. If there is a question as to whether there is in fact a privilege, the materials may be required to be produced for the court’s in camera inspection so that it can satisfy itself as to the validity of the privilege claim.

3. In simple terms, a claim of attorney-client privilege requires a showing that an attorney-client relationship existed, that a communication was made in the course of that relationship either seeking or giving legal advice, that the communication was confidential, and that the privilege has not been waived.


**35.4.6.3.3.3.1** **(08-11-2004)**

###### Specific Applications

1. The privilege protects only the confidential communication. Any facts that are otherwise discoverable are not protected simply because they were told to an attorney. The privilege does not protect preexisting documents that were in the hands of the client but have now been transmitted to the attorney in confidence.

2. Generally, the attorney-client privilege does not prohibit discovery of information concerning the general nature of the services performed by the attorney. Since an attorney’s services can involve both privileged and nonprivileged communications, it is proper to inquire into the nature of the services rendered to determine what areas may be inquired into further, and what areas are protected by the privilege.

3. The fact that an attorney has rendered an opinion in response to a client’s request for legal advice does not require a determination that the attorney-client communication is privileged. If petitioner’s attorney has participated in the acts which are the essence of the controversy, and where it would be unfair to allow the petitioner to introduce only selective evidence on the issue and bar opposing counsel from inquiring into other relevant circumstances, the attorney-client privilege is waived. For example, a petitioner cannot claim that he relied upon the advice of counsel and then refuse to divulge the advice.

4. A memorandum to the file prepared by a Service agent containing legal theories, thought processes and conclusions in connection with a request for legal advice from Chief Counsel, may be protected by the attorney-client privilege.

5. Revenue Agent’s Reports, Special Agent’s Reports, and Appeals Case Memoranda and their predecessor Appeals Supporting Statements, Appellate Conferee’s Report, and District Conferee’s Reports, are not protected by the attorney-client privilege since they are not prepared for the purpose of seeking legal advice from Chief Counsel, but rather are prepared in the ordinary course of business.

6. Memoranda from an Associate office to Field Counsel or to an operating division may be protected by the attorney-client privilege if they reveal confidential communications from the client for the purpose of obtaining legal advice.

7. The attorney-client privilege does not apply to information relating to the preparation of tax returns, or to communications made in assisting the commission of a crime or fraud.


**35.4.6.3.3.3.2** **(08-11-2004)**

###### Waiver of the Privilege

1. Once a party has begun to disclose any confidential communication otherwise protected by the attorney-client privilege, the privilege is lost for all communications relating to the same subject matter. A party cannot choose to disclose only so much of allegedly privileged material as is helpful to his case. Further, once there has been disclosure to an outsider, either by the client or by the attorney with the client’s authority, of the confidential communication, it is no longer privileged, unless the claimant of the privilege can establish that the assistance of the third party was in connection with enabling the attorney to render legal advice, and not merely in connection with carrying out the work previously rendered by the attorney.

2. The normal rule is that the attorney-client privilege will not be held to be waived merely as a result of a party bringing or defending a suit. In some instances, however, the nature of a case is such that a petitioner cannot proceed with the case without waiving the privilege.


**35.4.6.3.3.4** **(08-11-2004)**

##### The Federally Authorized Tax Practitioner Privilege

1. IRC § 7525 makes the attorney-client privilege, subject to all of its rules and limitations, applicable to "tax advice" communications between a taxpayer and a "federally authorized tax practitioner. "

2. For purposes of IRC § 7525, a "federally authorized tax practitioner" is any individual authorized under Federal law to practice before the Service if that practice is subject to 31 U.S.C. § 330, and "tax advice" is advice given by a federally authorized tax practitioner within the scope of that individual’s authority to practice as a federally authorized tax practitioner.

3. This privilege applies only to noncriminal proceedings before the Service, or to noncriminal Federal Court proceedings in which the Service or the United States is a party.

4. This privilege does not apply to certain written communications involving corporate tax shelters.


**35.4.6.3.3.5** **(08-11-2004)**

##### Work Product Doctrine

1. In the Tax Court, as in other courts, the "work product" doctrine exempts from discovery all materials prepared and assembled by an attorney, or under an attorney’s direction, to the extent they reflect the attorney’s mental impressions, conclusions, opinions, or legal theories, and were assembled or prepared in anticipation of litigation. Note to T.C. Rule 70(b), 60 T.C. 1057, 1098 (1973). Under the Federal Rules of Civil Procedure, discovery of such materials is permitted upon a showing of substantial need and undue hardship. See Fed. R. Civ. P. 26(b)(3). The Tax Court rules do not explicitly contain a similar limitation on the privilege. Nevertheless, the Tax Court may require production of otherwise protected information, if that information is highly probative, if there is no substantial equivalent available, and if the danger to the adversarial system in revealing the information is slight.

2. The term "materials prepared in anticipation of litigation" generally includes materials prepared by or under the supervision of a party’s attorney or other representative. As a result, most reports prepared by examining agents prior to a determination of the Service such as a notice of deficiency are not protected from discovery under this doctrine, since they were not prepared in anticipation of litigation or by or at the direction of the Service’s attorneys, but in the ordinary course of business irrespective of the prospect of litigation.

3. In determining whether to assert the work product doctrine in the Tax Court, consideration should be given to the extent to which the materials sought are already known to the petitioner or should have been furnished the petitioner if applicable administrative procedures had been followed. The nonconfidential portion of the Revenue Agent’s Report and the reports of Service specialists customarily fall into the latter category.

4. The work product exemption from disclosure may be waived if the party resisting disclosure makes testimonial use of its own work product.


**35.4.6.3.3.6** **(08-16-2010)**

##### Other Privileges That Petitioners May Raise

1. Parties in Tax Court proceedings may assert any privilege cognizable under federal common law as described in Fed. R. Evid. 501, as interpreted by the United States district courts for the District of Columbia in non-jury trials. See T.C. Rule 143; IRC § 7453. In considering the applicability of any common law privilege, such as the physician-patient privilege, the Field attorney should consider whether the bringing of an action by the petitioner places in issue matters otherwise protected by the privilege, resulting in its waiver. Guidance on waiver of privilege issues is available from Procedure & Administration, Branches 6 & 7.

2. The privilege against self-incrimination may be asserted as a defense to discovery only when there is reasonable probability (not remote and speculative) that a direct answer may incriminate the responding party. The privilege must be asserted on a question−by−question basis. Where the privilege is properly asserted, it will allow petitioner to avoid discovery, but also will limit petitioner’s ability to use the evidence in petitioner’s own case. The court will consider alternatives, such as a stay of proceedings, to preserve a legitimate claim of self-incrimination without imposing sanctions or drawing a negative inference.


**35.4.6.3.3.7** **(11-25-2019)**

##### Use of Whistleblower Information

1. Field attorneys may need to use whistleblower information to support adjustments or in litigation. Field attorneys may also need to use a whistleblower as a witness. _See_ _CCDM 35.4.6.3.3.2_ , _Approval Procedures for Identifying Confidential Informants_, before disclosing the existence or identity of a whistleblower.

2. At the end of any assignment where Field attorneys used whistleblower information to support adjustments or in litigation, Field attorneys must complete a Form 11369, _Confidential Evaluation Report on Claim for Reward_, including the narrative detailing whether and how the Field attorney used any whistleblower information. The Field attorney must sent the completed Form 11369 and narrative to the Whistleblower Office.



### Note:



Field attorneys conducting taint reviews need not complete the Form 11369. _See_ CCDM 33.3.8, _Whistleblower Taint Review Procedures_, for additional information on taint reviews.

3. The Form 11369 is used to inform the Whistleblower Office about the use of a whistleblower’s information. The Form 11369 and narrative assist the Whistleblower Office in making an award determination. Field attorneys must complete a Form 11369 and narrative for each relevant taxpayer. Taxpayers are relevant to a whistleblower submission when the whistleblower identifies the taxpayers in the claim, or the whistleblower information is considered in a civil, criminal, or judicial proceeding involving a taxpayer other than the taxpayer(s) identified in the claim(s).

4. Completion of the Form 11369 and its narrative fields is mandatory. The narrative must fully explain the issues identified by the whistleblower and the whistleblower’s contribution, if any, to the investigation. The narrative should cover all relevant dates including when significant actions were initiated. The narrative should also contain detailed feedback on how the whistleblower’s information was used, regardless of whether the laws administered, enforced, or investigated are outside of the Internal Revenue Code. This also encompasses information regarding other agencies involved and which agency has jurisdiction over the proceeds, if any.

5. The completed Form 11369 should explain how the whistleblower’s information was used, how it did or did not contribute to the identification and/or development of the issue(s) in litigation, and any other information that may assist the Whistleblower Office in making an award determination.



### Note:



When the Service uses whistleblower information for adjustments first asserted by Field attorneys, Field attorneys should complete the Form 11369.

6. When completing the section of the Form 11369 regarding Examined/Investigated Claims, Field attorneys will need to choose the box that most closely relates to their work on the case involving the use of whistleblower information. Form 11369 includes the following options: Examination, Criminal Investigation, and Collection. Each of the options provides additional questions to answer based on the type of work completed. For additional information on the completion of Form 11369, see IRM 25.2.1.5.5, _Form 11369 Requirements_.

7. The Whistleblower Office will verify that the Form 11369 and narrative explain and support whether the whistleblower’s information was used and whether the information did or did not contribute to the identification of issues.

8. The Whistleblower Office will review the information provided on the Form 11369 and narrative to determine whether the whistleblower’s information substantially contributed to an action. The Whistleblower Office may need to contact the Field attorney to obtain additional information or to review related files.


**35.4.6.3.4** **(08-11-2004)**

#### Impeachment Evidence

1. In the Tax Court, materials that are primarily of an impeaching character are protected from discovery. See Note to Tax Court Rule 70(b), 60 T.C. 1057, 1098 (1973). This defense should not be asserted by respondent, even though the evidence will have incidental impeachment value, if the evidence sought will be offered as part of respondent’s case in chief, such as to prove an element of fraud, or if it will help establish an affirmative defense as to which respondent has the burden of proof. Additionally, under the court’s Standing Pre-trial Order, only documents that are to be offered _solely_ for purposes of impeachment need not be identified and exchanged by the parties 14 days before the first day of the trial session; all others, including those documents that may be used for impeachment and other purposes, must be exchanged.

2. While the impeachment defense will not usually protect disclosure of the identity of a person having knowledge of a transaction, there are situations when disclosure of identity will be tantamount to disclosure of anticipated testimony. For example, the person’s involvement in the relevant transaction may have been limited. In such situations, consideration should be given to resisting pretrial discovery of the identity of the witness. Among the factors to be considered in this connection are whether the petitioner is firmly committed on the record to the details which will be contradicted or impugned by the impeaching witness, and the likelihood that the impeaching witness can be intimidated, corrupted, or otherwise persuaded to modify testimony. If the only danger is that the petitioner may tailor testimony to that of the impeaching witness, consideration may be given to requesting in the alternative a protective order postponing disclosure of the impeaching witness’ identity until petitioner has responded to interrogatories.


**35.4.6.4** **(08-11-2004)**

### Cases Having Related Criminal Aspects

1. While it is almost always advisable to complete the disposition of a criminal tax case prior to the issuance of a notice of deficiency involving the same or related taxpayers for the same or related tax and tax periods, sometimes a notice must be issued and the case becomes docketed before the Service would prefer. Once the case becomes docketed, it is the responsibility of the Field attorney and the Field attorney’s Associate Area Counsel to protect the criminal case to the fullest extent possible. It is imperative that the Field attorney continue to coordinate with the Criminal Tax Division and the Department of Justice (DOJ) (if the case has been referred).

2. No case will be referred to Appeals for settlement consideration so long as there are open criminal aspects. After disposition of the criminal case, no Appeals settlement, which would concede the fraud penalty or fraud delinquency penalty or reduce the tax liability figure below that recommended in the criminal case, may be effected without Chief Counsel concurrence.


**35.4.6.4.1** **(08-11-2004)**

#### General Procedures for Protecting the Criminal Case

1. Because of the sensitivity of a Tax Court case with related criminal aspects and the potential impact of the civil case on the criminal case, this type of case is particularly suited to handling by a team of attorneys with strong trial skills and experience in litigation of fraud cases. Direct involvement of the Field attorneys’ reviewer in litigation planning and preparation is particularly important.

2. As an initial matter, the Field attorneys should attempt to obtain the agreement of petitioner or petitioner’s counsel to stay proceedings in the Tax Court. Usually, that will not succeed, because taxpayers perceive that proceeding with the civil case may give the taxpayer an advantage in the criminal case, generally because of the ability to discover information in the Tax Court case. The Field attorneys must exercise extreme caution to avoid giving the appearance that petitioner’s agreeing to a stay will cause the Government to act leniently toward petitioner in either the criminal case or the civil case. See CCDM 35.4.1.5.1, Coordination with Criminal Tax Cases.

3. Even without the agreement of petitioner, respondent may seek a stay from the Tax Court. The Court generally will be reluctant to grant such a stay, unless respondent makes a showing that the stay will be to the advantage of the Court and will not burden petitioner or harm petitioner’s case. The Field attorneys should become completely familiar with the procedural posture of the criminal case. If the taxpayer has been charged, but is attempting to delay the criminal case, the Tax Court should be informed of this fact in the motion seeking a stay.

4. No stipulation of facts conferences or other correspondence or conference in a case with related criminal aspects should be allowed to evolve into a settlement conference or settlement negotiations. Negotiation of the civil liability prior to disposition of the criminal case could have direct adverse consequences on the criminal case.

5. Care must be exercised by the Field attorneys as to what facts are discussed with the taxpayer, or his counsel, in conferences or correspondence, and no facts are to be discussed which the Field attorney and reviewer, after coordination with the Associate Chief Counsel (Criminal Tax) (CT) and DOJ, have concluded must not be revealed to the taxpayer prior to the trial.

6. In general, the Field attorneys will best protect the criminal case, despite the pendency of the civil case, by fully developing any information obtained from the taxpayer or other witnesses and by completely presenting all the evidence to assure sustaining the civil fraud or fraud delinquency penalty.


**35.4.6.4.2** **(08-11-2004)**

#### Stipulation of Facts and Formal Discovery

1. Both the requirement of T.C. Rule 91 that the parties, during the course of preparation for trial, confer and stipulate all facts to which complete or qualified agreement can be reached, and all of the Court’s rules on discovery and admissions, apply to this type of case as to every other case. Despite this, caution must be taken at all steps to avoid jeopardizing the criminal case.

2. Before the Field attorneys write a _Branerton_ or stipulation of facts letter in this type of case, they should discuss with their reviewer the general course of action to be followed in the preparation and trial of the case and particularly the documentary evidence which may be susceptible of stipulation without detriment to the criminal case. If it is concluded that there are areas of facts which should be stipulated, the stipulation of facts letter will be written and conferences arranged.

3. Generally, the facts to be stipulated in this type of case are limited in nature. Both parties have reasons to avoid the type of full and open disclosure usually present in a civil case. Petitioner, seeking to protect Fifth Amendment rights, usually will not be as free or as willing to discuss or to stipulate facts as in other cases. Similarly, other than documentary facts, the Field attorney is not as free to discuss the facts at conferences in these cases as in others. Further, respondent usually would prefer to present a fraud case (especially one with related criminal aspects) with live testimony that may be of benefit to the Government in the later trial of the criminal case.

4. If petitioner issues formal discovery or admission requests, the Field attorneys must carefully and completely review the requests, fully develop any applicable objections, seek a protective order, if appropriate, and coordinate the responses with the Associate Chief Counsel (CT) and DOJ.


**35.4.6.4.3** **(08-11-2004)**

#### Pre-Trial Conferences

1. Because of the unusual nature of a Tax Court case with related criminal aspects, the Court may set the case on a report calendar, or if the case is calendared for trial, the Judge may set a pre-trial hearing during the trial session.

2. At an actual trial, the Field attorneys would be prepared to, and would, present all available evidence to support the tax determination and penalties. At a pre-trial conference, however, great care must be exercised in not revealing to the taxpayer evidence which supports the fraud or fraud delinquency penalty, if a premature disclosure would imperil criminal prosecution. Coordination between the Field attorneys, their reviewer, the Associate Chief Counsel (CT), and the Department of Justice is crucial in planning for such a conference.


**35.4.6.5** **(11-25-2019)**

### Protective Orders

1. All evidence received by the Tax Court is a matter of public record that is open to public inspection. IRC § 7461(a). Members of the general public have a legitimate interest in all stages of a judicial proceeding. Public access to judicial proceedings promotes public confidence in the fairness and integrity of the judicial proceedings. "The parties to a lawsuit are not the only people \[with\] a legitimate interest in the record compiled in a legal proceeding." _Citizens First Nat’l Bank of Princeton v. Cincinnati Ins. Co._, 178 F.3d 943, 944 (7th Cir. 1999).

2. Under IRC § 7461(b), the Tax Court may prevent disclosure of trade secrets or other confidential information by sealing the record to be opened only as directed by the court. The Tax Court will not seal the record regarding trade secrets or other confidential information in every case. Rather, courts exercise their discretion in deciding whether to seal the record, balancing the public’s right of access and the possibility of miscarriage of justice when the information sought to be protected is shown to be a trade secret or other confidential information. _Willie Nelson Music Company v. Commissioner_, 85 T.C. 914, 918-20 (1985). See _U.S. v. IBM_, 67 F.R.D. 40, 46 (S.D. N.Y. 1975); see also _Turick v. Yamaha Motor Corp._, 121 F.R.D. 32, 35 (S.D. N.Y. 1988)

3. T.C. Rule 103 provides that, upon motion by a party or other affected person, and for good cause shown, the Tax Court may enter any order which justice requires to protect a party or other person from annoyance, embarrassment, oppression, or undue burden or expense. T.C. Rule 103 describes the types of protective orders the court may enter to achieve these purposes. A protective order generally protects against disclosure to the general public, not the litigants.

4. "Good cause" for granting a motion for protective order under T.C. Rule 103 exists when intervention by the court is necessary to prevent substantial abuse. As an example, a protective order may be appropriate when a discovery request is excessively burdensome, repetitive, or clearly intended to harass, embarrass, or distract the responding party from trial preparation. _Wooten v. Commissioner_, T.C. Memo. 1993-241 (petitioner’s interrogatories unduly burdensome and irrelevant to the issues in the case). As another example, a protective order may be appropriate when a party serves formal discovery on the other party without first utilizing informal consultation or communications. _Schneider Interests, LP v. Commissioner_, 119 T.C. 151 (2002); _Branerton Corp. v. Commissioner_, 61 T.C. 691 (1974). Before seeking a protective order, attorneys should consider providing a partial response or objection, explaining the reason for doing so and offering to complete the response at the appropriate time.

5. If petitioner’s discovery request relates to matters that may cause concern to a nonparty, consideration should be given to informing the nonparty of the discovery request so that the nonparty may determine whether to object or otherwise seek relief. This notification can be provided by the petitioner or respondent to the nonparty. Any disclosure to the nonparty by or on behalf of respondent should comply with the requirements of IRC § 6103. See IRM 11.3.1, Introduction to Disclosure, and CCDM 37.1.2, Disclosure of Information.

6. A petitioner may respond to discovery by taking the position that the responsive information may not be provided until a protective order is entered by the Tax Court. In general, no agreement should be given that allows petitioner or an affected person to delay providing responsive information under the guise that responsive material will only be produced after issuance of a protective order. When interrogatories or a request for the production of documents are served and the petitioner files a motion seeking a protective order, after the petitioner’s time to respond expires, a motion to compel under T.C. Rule 104 should be filed. The Tax Court typically will schedule the hearing on the motion to compel and petitioner’s motion for protective order at the same time. If the motion to compel is not filed until the Tax Court acts upon the motion for protective order, there will be needless delay. Objections to petitioner’s motion for a protective order should be addressed in a separate written statement.

7. Whenever the Tax Court enters a protective order sealing the record in a case, in whole or in part, the case must be specially handled. The case file must be marked prominently so that anyone coming into contact with it will know that it is subject to a protective order. Any and all portions of the case file subject to a protective order must immediately be sealed in some meaningful way, subject to opening only by persons authorized by the protective order. The case file must also be subject to special storage procedures that will assure compliance with the protective order. The special handling and storage procedures are necessary to prevent any inadvertent violation of the protective order that may subject the attorneys of record or others to sanctions.


**35.4.6.5.1** **(11-25-2019)**

#### Protective Order Procedures, Generally

1. These procedures apply to protective orders in all cases. Special procedures may apply in whistleblower proceedings. _See_ _CCDM 35.4.6.5.2_ , _Protective Orders, Whistleblower Proceedings_.

2. Any proposed agreement to a protective order under T.C. Rule 103 and /or IRC § 7461 or any statement that there is no objection to the granting of a petitioner’s motion for protective order must, in all instances, be referred to Procedure & Administration, Branches 6 & 7, and be pre-approved by the Associate Chief Counsel (Procedure & Administration). See Exhibit 35.11.1-1, Issues Requiring Associate Office Review, subject to the guidelines set forth below.

3. In general, we will not agree to the filing of a joint motion for protective order to limit access to or seal the record at the request of a party or other affected person. The presumption of public access to case information is better served when the judge actually determines if good cause exists instead of signing off on the parties’ agreement to seal the record. _Citizens First Nat’l Bank of Princeton_, 178 F.3d at 946. This principle is equally applicable to internal access to case information within the Service as authorized by law. Permitting litigants to unilaterally limit access to or seal portions of the record, absent judicial determination, is contrary to law and amounts to giving each party carte blanche in deciding what part of the record can be kept secret. _Id._ at 945. Instead, the judge should be asked to independently determine whether the information is such that a protective order is appropriate under the circumstances.

4. Any motion for protective order relating to return information at the discovery stage of the proceedings should generally be opposed because the motion is almost always premature. Section 6103 provides protection for return information for a petitioner or an affected party until that return information is submitted in the Tax Court proceeding. IRC § 6103(h)(4)(A). Information obtained during the audit or through discovery or other processes in petitioner’s Tax Court case is petitioner’s "return information" within the meaning of section 6103(b)(2)(A) since it is collected by the Service for the determination of petitioner’s tax liability. This applies whether the information was provided by petitioner or a nonparty. Based on a case−by−case basis, however, consideration will be given to not objecting to a motion for protective order applicable to the discovery stage of the proceedings if a petitioner or a nonparty can demonstrate that the protection afforded return information by section 6103 is not adequate to prevent harm to the petitioner or the nonparty.

5. Relying on section 7461(b), a petitioner or an affected person may file a motion for protective order to have the court seal tax returns and return information admitted or to be admitted into evidence on the ground that disclosure would reveal trade secrets or other confidential information. These attempts should generally be resisted on the ground that all evidence received by the Tax Court, including tax returns and return information, are public records open to public inspection. IRC § 7461(a). The Office of Chief Counsel, in representing the public interest, has an obligation to protect the integrity of the tax litigation process by encouraging transparency in the judicial workings of the Tax Court. A petitioner’s tax returns and return information are at the very core of the tax dispute that a petitioner places before a public forum for resolution. The right of public access to evidence submitted to the Tax Court during the adjudication process is strongly presumed by statute, the common law, and the Constitution. Public access is essential to permit the public to monitor governmental functions and judicial performance. Accordingly, the Tax Court should be urged to narrowly construe its authority to seal records and to reject vague or conclusory allegations of harm to a petitioner or an affected person.


**35.4.6.5.2** **(11-25-2019)**

#### Protective Order Procedures, Whistleblower Proceedings

1. Section 6103(h)(4) may permit the disclosure of non-party taxpayer information to a petitioner in a whistleblower proceeding during discovery, but the Code does not impose a duty on petitioner or petitioner’s attorneys not to further disclose that information once it has been produced to them. Field Counsel must be mindful that a non-party taxpayer generally will have no control over information disclosed in a whistleblower proceeding that is petitioned to the Tax Court. Strict attention must be paid to the limitations on discovery set forth in T.C. Rule 70(b), which protects from discovery both matters that are privileged as well as matters not relevant to the pending case. Any information that potentially may be responsive to a petitioner’s discovery request in a whistleblower proceeding must be reviewed for claims of privilege and relevancy. A request for information that is privileged or that is not relevant to the case must be objected to and such information should not be produced in discovery or at trial. Include a watermark on each page of any non-party taxpayer information that is produced. The watermark should read, "Confidential Section 6103 Information - Further Dissemination May Subject Petitioner and/or Recipient to Liability."

2. Field Counsel must obtain a protective order under T.C. Rule 103(a) in every case where non-party taxpayer information will be produced to petitioner either in discovery or when filing a motion for summary judgment. Field Counsel must coordinate all novel or significant issues regarding the motion for protective order in whistleblower proceedings with Procedure & Administration, Branch 5.



1. The protective order ensures that petitioner is subject to the same section 6103 requirements against disclosure of tax return or return information as respondent, limits any further disclosure by petitioner, and requires petitioner to return all section 6103 information to respondent, or certify in writing to its destruction, within 14 days of the resolution of the case.

2. The protective order does not permit petitioners access to tax return and return information that does not meet the exception under section 6103(h)(4)(B).

3. When closing a whistleblower case, Field Counsel must prepare a letter to the whistleblower-petitioner informing the petitioner that, consistent with any protective order entered in the case, they must either return or certify destruction of all section 6103 information disclosed during the Tax Court case. This letter must be included in the legal file before it is closed. In the event the petitioner does not either return or certify the destruction of all section 6103 information disclosed at the conclusion of the Tax Court case, Field Counsel should contact Procedure & Administration, Branches 6 & 7 to request guidance. _See generally_ CCDM 35.9.3.7, _Closing Whistleblower Cases_.



      ### Note:



      T.C. Rule 345 does not require that confidential taxpayer information be sealed or otherwise protected in whistleblower proceedings. The Tax Court addresses the need protect non-party taxpayer information on a case-by-case basis. _See_ CCDM 35.3.3.11, _Petitioner’s Motion to Proceed Anonymously_.


**35.4.6.6** **(08-11-2004)**

### Petitioner’s Subpoena Served on the Internal Revenue Service

1. Petitioner may attempt to use a subpoena to require respondent to turn over documents, or to require the appearance of an agent as a witness for petitioner.

2. The Field attorney should resist any effort by the petitioner to belatedly use the subpoena to make up for petitioner’s failure to abide by, or properly use, the Court’s discovery rules. If the petitioner is attempting to use the subpoena in such a way, and the matter cannot be resolved informally, the Field attorney should file a motion to quash the subpoena.

3. The Field attorney should resist any effort by the petitioner to compel testimony of a Service agent or employee for the purpose of "going behind" respondent’s determination or introducing other irrelevant material at trial.

4. If petitioner issues a subpoena to the respondent, see CCDM 35.4.6.7 regarding disclosure.


**35.4.6.7** **(08-16-2010)**

### Disclosure in Tax Court Cases

1. IRC § 6103 generally prohibits the disclosure of income tax returns or information contained in such returns. See also IRC § 7213 and 18 U.S.C. § 1905. Disclosure of records or information in a Tax Court case can happen whenever information and documents are provided to petitioner or others informally or upon demand, including discovery requests and requests for admissions served upon respondent pursuant to the Tax Court’s rules. The term "demand" specifically includes any notice of deposition, either upon oral examination or written interrogatories, and other disclosure orders of any Court.

2. The Office of Chief Counsel has been formally delegated authority to determine the applicability of IRC § 6103, including the determination that disclosure would seriously impair Federal tax administration, and to disclose and authorize disclosure of tax returns, tax return information and taxpayer return information. See Exhibit 30.2.2-6, Department of the Treasury General Counsel Order No. 4. The Deputy Associate Chief Counsel (Procedure & Administration) has primary jurisdiction over all cases in which the sole issue concerns the unauthorized disclosure of tax return information under 26 U.S.C. § 7431 and disclosures requested under the Freedom of Information Act, 5 U.S.C. § 852, and the Privacy Act, 5 U.S.C. § 552a. All other disclosure, discovery, and privilege matters occurring in tax litigation cases, in the Tax Court, the U.S. Court of Federal Claims, or the District Courts, should be referred to Procedure & Administration, Branches 6 & 7 for coordination. Telephone authority for disclosure of confidential information may be obtained through the Associate Chief Counsel (Procedure and Administration) (P&A).


**35.4.6.7.1** **(08-11-2004)**

#### Disclosure of Security Threats at Tax Court Calendars

1. See the discussion of procedures for reporting potentially dangerous taxpayers at CCDM 35.6.3, Tax Court Procedures for Reporting Potentially Dangerous Persons.


**35.4.6.7.2** **(03-15-2011)**

#### Classified or Restricted Information

1. If the Field attorney finds any document or notation in a file indicating that some information has been given a restricted, secret, top secret, or similar security classification by the Department of Defense, State Department, Department of Energy (for atomic or nuclear energy matters), or other governmental unit, extreme care should be exercised to avoid any unauthorized use or disclosure of such information.

2. The Field attorney should determine first that the information was properly obtained and that a record exists of an authorized release or declassification of the information. If the information has not been declassified, then the attorney must arrange for a security clearance for herself and any other persons having access to the information. Also, the attorney must store the information in an appropriately secure location.

3. The Field attorney must also obtain precise instructions concerning what further use or disclosure may be made of the information. Normally, no further disclosure may be made until the information has been declassified.

4. In the event the file includes documents obtained through tax treaty requests or Tax Information Exchange Agreements (TIEA) disclosure of those documents may be prohibited. Information received under a tax treaty or TIEA is governed by IRC § 6103, the secrecy or confidentiality clause in the treaty or exchange agreement itself, and, in some cases, additional conditions proposed by the requested state at the time of the exchange. The Competent Authority (the Deputy Commissioner (International) in Large Business and International) is obligated to follow the TIEA and tax treaty secrecy provisions. See CCDM 35.4.5.2.3, Tax Treaties, and CCDM 35.4.5.2.4, Tax Information Exchange Agreements. Coordinate all disclosure of treaty and TIEA documents in litigation matters, whether informal or formal discovery, with the Associate Chief Counsel (International), Branch 7 who will coordinate with appropriate national office functions.

5. If any uncertainty exists with respect to the use or disclosure of such information, the matter should be referred to the Associate Chief Counsel (P&A).


**35.4.6.7.3** **(08-11-2004)**

#### Discovery of Unrelated Third Party Tax Returns

1. The approval of the Associate Chief Counsel (P&A) must be secured prior to production of a third party tax return, even where a Court order directing production has been entered. Before production of the third party return sought in a discovery request, the Field attorney should insist upon a Court order directing production unless the third party has consented to the disclosure. See CCDM 35.4.6.7.4.

2. Each discovery request for third party returns will be considered on a case by case basis. See CCDM 30.11.1.5 , Area Counsel or Associate Area Counsel Office Responsibilities, and IRM 11.3.2, Disclosure to Persons with a Material Interest.

3. There are narrow circumstances where third party tax returns and information may be lawfully disclosed. Under IRC § 6103(h)(4)(B), a third party taxpayer’s statutorily protected information may be disclosed in judicial tax proceedings only if the treatment of an item reflected on such (third party’s) return is directly related to the resolution of an issue in the proceeding. Under IRC § 6103(h)(4)(C), such information may be disclosed if it directly relates to a transactional relationship between a person who is a party to the proceeding and the taxpayer which directly affects the resolution of an issue in the proceeding.




| The narrowness of these exceptions can be seen from the following examples: |
| --- |
| _**Example 1.** The return of a third party with similar facts or situation to that of the taxpayer._: It is the Service’s position that disclosure of similarly situated, but unrelated, taxpayers’ tax returns and return information is not authorized by the item or transaction tests of IRC § 6103(h)(4)(B) and (C). |
| _**Example 2.** Use of comparable salaries from comparable companies._: In a reasonable compensation case, the return reflecting the compensation paid to an individual by an employer other than the taxpayer whose liability is at issue would not meet either the item or transaction tests described above. Thus, the reflection on a corporate return of the compensation paid its president would not represent an item the treatment of which was relevant to the liability on an unrelated corporation with respect to the deduction it claims for the salary it paid its president. |
| _**Example 3.** Use of competitor return information in IRC § 482 cases._: In IRC § 482 cases (involving the reallocation of profits and losses among related companies), it is sometimes necessary to determine the prices paid for certain services and products at arms-length between unrelated companies. The return or return information of a company which was unrelated to the taxpayer company would not be disclosable under either the item or transaction tests described above. |

4. Attorneys should resist party litigants’ attempts to discover tax returns and return information of unrelated third parties that are based on claims of disparate treatment, relying on IRC § 6103 and any other privileges or objections that may be appropriate. If a court orders the production of third party returns or return information, such order should be brought to the immediate attention of the responsible Associate office who will coordinate as appropriate with the Associate Chief Counsel (P&A) in fashioning a response to the Court order.


**35.4.6.7.4** **(08-11-2004)**

#### In Camera Inspections

1. There are a variety of situations where the Tax Court judge receives documents for an in camera inspection. As a general rule, when Field Counsel is resisting disclosure of files, any submission to the Court for an in camera inspection should be made pursuant to an agreement with the judge, or at least a statement on the record or in a cover letter, to the effect that the material or information submitted is to be retained in the Court’s file or returned to Field Counsel with an order or instruction by the Court as to the disclosure or turnover. The reason for this is that the Court should not make a direct disclosure or turnover to petitioner, even if it decides that disclosure or turnover is proper. Field Counsel still are entitled to refuse to disclose or turn over, and in certain cases might decide to suffer sanctions, or even default, rather than to disclose or turn over the information or material. An example could be informant identification in an appropriate case. See CCDM 35.4.6.3.3.1.

2. When complete documents are submitted to the Court for examination and comparison along with expurgated documents proposed for disclosure, care must be taken to avoid the possibility that a clerk in the Court’s docket room might take them as routine filings and prepare and serve copies of both documents upon petitioner. To avoid that, put both documents in an envelope and on the outside of that envelope put the case name and docket number, plus a notation in red ink reading "For delivery unopened to Judge \[name\]. Do not serve upon any party." That envelope and the cover letter are mailed in another envelope addressed to the judge.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-004-006#addtoany "Show all")

A2A