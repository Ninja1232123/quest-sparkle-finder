---
url: "https://www.irs.gov/irm/part35/irm_35-008-005"
title: "35.8.5 Miscellaneous Problems | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-008-005#main-content)

- 35.8.5  [Miscellaneous Problems](https://www.irs.gov/irm/part35/irm_35-008-005#idm140329916505664)
  - 35.8.5.1  [Merged Corporations and Assignment of Claims](https://www.irs.gov/irm/part35/irm_35-008-005#idm140329943611408)
  - 35.8.5.2  [Carrybacks — Special Limitation Periods — Restrictive Interest](https://www.irs.gov/irm/part35/irm_35-008-005#idm140329916491824)
  - 35.8.5.3  [Estate and Gift Tax](https://www.irs.gov/irm/part35/irm_35-008-005#idm140329916624384)
  - 35.8.5.4  [Husband and Wife — Joint Liability — Separate Petitions](https://www.irs.gov/irm/part35/irm_35-008-005#idm140329943643888)
  - 35.8.5.5  [Failure to Pay Addition to Tax for Returns Prepared Under Section 6020(b)](https://www.irs.gov/irm/part35/irm_35-008-005#idm140329943641600)
  - 35.8.5.6  [Consolidated Cases](https://www.irs.gov/irm/part35/irm_35-008-005#idm140329943638160)
  - 35.8.5.7  [Relief from Joint and Several Liability Cases](https://www.irs.gov/irm/part35/irm_35-008-005#idm140329943622096)
  - 35.8.5.8  [Abatement of Interest Cases](https://www.irs.gov/irm/part35/irm_35-008-005#idm140329943613776)
  - 35.8.5.9  [Disclosure Actions: Section 6110 Cases](https://www.irs.gov/irm/part35/irm_35-008-005#idm140329943612016)
  - 35.8.5.10  [Employment Tax Cases: Worker Classifications](https://www.irs.gov/irm/part35/irm_35-008-005#idm140329943666528)
  - 35.8.5.11  [Decisions in Declaratory Judgment Cases](https://www.irs.gov/irm/part35/irm_35-008-005#idm140329943654512)
    - 35.8.5.11.1  [Scope of Judgment in Employee Plans Declaratory Judgment Cases](https://www.irs.gov/irm/part35/irm_35-008-005#idm140329943599648)
    - 35.8.5.11.2  [Scope of Judgment in Exempt Organizations Declaratory Judgment Cases](https://www.irs.gov/irm/part35/irm_35-008-005#idm140329943595776)
    - 35.8.5.11.3  [Scope of Judgment in Government Obligations Declaratory Judgment Cases](https://www.irs.gov/irm/part35/irm_35-008-005#idm140329943590208)
  - 35.8.5.12  [Fraud in Bankruptcy: Entry of Stipulated Decision Involving Fraud Penalty](https://www.irs.gov/irm/part35/irm_35-008-005#idm140329943585712)

# Part 35. Chief Counsel Directives Manual Tax Court Litigation

# Chapter 8. Decisions, Orders of Dismissal, and Other Final Judgments

# Section 5. Miscellaneous Problems

* * *

## 35.8.5 Miscellaneous Problems

#### Manual Transmittal

June 29, 2022

#### Purpose

(1) This transmits revised CCDM 35.8.5, Decisions, Orders of Dismissal, and Other Final Judgments; Miscellaneous Problems.

#### Background

In November of 2018, Tax Court Rule 281 was amended to reflect changes to section 6404(h) relating to judicial review of requests for interest abatements. As part of the Protecting Americans from Tax Hikes Act of 2015, section 6404(h) was revised to provide that the taxpayer may petition the Tax Court for review of a request for interest abatement on a date which is 180 days after the date of filing of the request for abatement, even if a determination has not been issued.

#### Material Changes

(1) CCDM 35.8.5.8, Abatement of Interest Cases, is revised to reflect the November 2018 changes to Tax Court Rule 281 concerning the period for bringing actions for review of failure to abate interest under section 6404(h).

#### Effect on Other Documents

CCDM 35.8.5 dated May 22, 2012, is superseded.

#### Audience

Chief Counsel

#### Effective Date

(06-29-2022)

Richard G. Goldman

Deputy Associate Chief Counsel

(Procedure and Administration)

**35.8.5.1** **(05-22-2012)**

### Merged Corporations and Assignment of Claims

1. A determination against the successor or merged corporations for tax due by the separate corporations prior to the merger is not a true transferee case. Such matters should generally be handled as a deficiency case. The stipulation, Rule 155, and decision documents in these cases should specifically state that the liability at issue is not the petitioner’s own liability, but is its liability as successor to the merged corporations. If the statutory notice was incorrectly issued to the successor of merged corporations as a transferee liability, a new statutory notice should be issued to the successor corporation as primary obligor. Should the issuance of a new statutory notice be barred by the statute of limitations, it is advisable to process and handle the case as a transferee case, even though a transferee notice was incorrectly issued to the successor corporation. The successor of merged corporations may obtain an overpayment of tax paid by its predecessor. This is so because the successor corporation is in law a continuation of the taxpayer, and therefore, as a matter of law, there is no assignment of the claim. Thus, the overpayment to the successor is not prohibited by the Federal Assignment of Claims Act, 31 U.S.C. § 203. There may be other instances when an overpayment may be legally made to a petitioner who is not the taxpayer who paid the original tax. The courts have held that the Federal Assignment of Claims Act does not apply to an assignee by operation of law. When there is any question as to whether the petitioner in the Tax Court is entitled to an overpayment, the attorney must determine all necessary facts and thoroughly research the applicable law before preparing the stipulation, Rule 155, and decision documents. Furthermore, any question concerning these matters should be submitted to P&A for consideration prior to the Field attorney making a final commitment.

2. The processing of a merged corporation case as a transferee case is for procedural purposes only. The substantive transferee liability law is not applicable to a merged corporation case which is not in fact a true transferee case. In determining the deficiency in this instance, the same substantive law is applicable as is applicable in any other deficiency case.

3. The executor or administrator of a decedent’s estate is the personal representative of the decedent and stands in his/her place. Therefore, the Federal Assignment of Claims Act, 31 U.S.C. § 203, does not prohibit an overpayment of tax to the executor or administrator of an estate.

4. Refund suits usually may be maintained only by the party who paid the tax. The successor of merged corporations is considered to have paid the tax of the merged corporations for this purpose, and consequently may maintain a refund suit. Otherwise, voluntary assignments of a right to a refund are generally null and void as to the government. Federal Assignment of Claims Act, 31 U.S.C. § 203. Therefore, refund suits initiated by an assignee are generally subject to dismissal for lack of a proper party. See CCDM 35.5.2, Settlements by Counsel.


**35.8.5.2** **(05-22-2012)**

### Carrybacks — Special Limitation Periods — Restrictive Interest

1. These instructions address the special problems that must be considered to secure a proper decision in cases involving: net operating loss or credit carrybacks and carryovers; special limitation periods on overpayments; and restrictive interest computations. These instructions are applicable to deficiencies, overpayments, or transferee cases. The term "carryback," as used herein, includes carryovers or carryforwards of net operating losses or credits, together with any of the other types of adjustments in this special category, as applicable to the specific case.

2. A special period of limitations may permit an overpayment to be determined by the Tax Court which would otherwise be barred by the general statute of limitations. _See_ section 6512(b)(2). Such special limitations periods may arise with respect to a net operating or capital loss carryback, a credit carryback, a foreign tax credit, bad debts and worthless securities, reduction of policyholders surplus account of life insurance companies, amounts included in income subsequently recaptured under qualified plan termination, or partnership items of federally registered partnerships. Sections 6511(d) and 6511(g). In these cases the stipulation or Rule 155 computation must include all facts necessary to support the overpayment and to show it may be properly determined by the court.

3. For settled cases of the type referred to above, or in any other case in which the restrictive interest provisions of the internal revenue laws are applicable, there should be filed with the court a separate stipulation document. In these cases the combined stipulation and decision document should not be used, even though a deficiency is to be determined by the court. For decided cases, the Rule 155 computation will provide for all of the essential elements that are required for a settlement stipulation. The stipulation or the Rule 155 computation must contain all of the basic facts upon which the restrictive interest provisions can be applied to either a deficiency or overpayment. For example, if a case involves a net operating loss carryback, the agreement extending the statute for the year the net operating loss occurred must be shown if such agreement is necessary to support the timely filing of the refund claim upon which the overpayment is to be based. This example is not all-inclusive, and the attorney must thoroughly research the applicable provisions of the statutes and regulations in cases coming within the purview of these instructions.

4. For cases in which there is a deficiency, without considering the net operating loss carryback or other special adjustment, the stipulation or Rule 155 computation must show such deficiency. If the carryback results in a net overpayment, the document must show the deficiency prior to the carryback loss or credit and the overpayment after allowance of the carryback loss or credit. If there is a net deficiency, the document must show the deficiency, without considering the carryback loss or credit, and the deficiency after allowance of the carryback loss or credit. These requirements are necessary to permit the Service to make a proper adjustment for the deficiency and to apply the applicable restrictive interest provisions to the deficiency and to the overpayment.

5. Many of the carryback loss cases involve a previous allowance of so-called "quickie" or tentative refunds under section 6411. In some of these cases an issue is raised as to the amount of the "quickie" refund. In other cases the issues before the court are other adjustments that do not disturb the amount of the "quickie" refund allowed in the statutory notice. In both situations, the settlement stipulation or the Rule 155 computation must provide for the gross deficiency prior to the carryback and the net deficiency or overpayment after the carryback, or for the overpayment both before and after the carryback. This is necessary to establish a proper basis for applying the restrictive interest provisions and to foreclose questions arising at a later date as to the proper computation of interest.

6. If the overpayment, in whole or in part, or if the adjustment to the deficiency is based upon the allowance on the merits of a carryback loss or credit, the carryback loss or credit must be placed in issue by the petition or amended petition or by stipulation of the parties. The court cannot base an overpayment of tax or an adjustment of a gross deficiency on the merits of a carryback loss or credit unless such loss or credit is before the court. Such adjustment must be placed in issue prior to or simultaneous with the filing of the settlement stipulation. In decided cases the Rule 155 computation would not make the carryback adjustments unless an issue had been raised with respect thereto prior to the trial of the case. If an operating loss has been placed in issue by a petition or an amended petition, the settlement stipulation or Rule 155 computation and the court’s decision must dispose of the issue. These requirements are also applicable to any of the other special limitation provisions of the Code. Once a carryback adjustment has been properly placed in issue in a Tax Court case, it is very questionable whether it can be removed from the case by an amended petition or even by agreement of the parties. Similarly, a stipulation in a Rule 155 document to defer consideration of the validity and consequences of a carryback or carryforward loss or credit to an audit or to litigation covering the year to which the loss or credit is carried may be ineffective. Further consideration of the issue might be barred by section 6512 and/or res judicata. Thus, where the carryback adjustment has been properly placed in issue and the taxpayer attempts or seeks to withdraw it from the case, he or she should be informed that no assurance can be given that a carryback adjustment is thereafter allowable or will be allowed, unless disposed of by the decision in the instant case. That is, after the Tax Court’s decision becomes final, it would appear that no further adjustment could be made to the tax liability for the year or years before the court by reason of a carryback loss or credit which was at any time an issue in the case. This would not apply to cases in which the carryback loss or credit was not properly an issue before the Tax Court. In such cases the decision documents should explicitly state that the deficiency or overpayment determined is without regard to the carryback adjustments, which were not at issue in the case. Legal advice on the preparation of decision documents involving tentative or claimed carryback adjustments is available from the office of the Associate Chief Counsel (Procedure & Administration), Branch 3 or 4. See Exhibits 35.11.1–162 through 35.11.1–168 for guidance on preparation of decision documents concerning these issues.

7. For transferee cases in which an operating loss carryback or credit is used in the determination of the transferor’s tax liability, care must be exercised to include in the transferee liability the amount of interest on the portion of the deficiency which is reduced by the carryback.


**35.8.5.3** **(05-22-2012)**

### Estate and Gift Tax

1. Except as herein provided, the general provisions governing stipulations and Rule 155 computations in income tax cases are also applicable to estate and gift tax cases. The instructions as to transferee liability, interim assessments, prior unpaid assessments, or jeopardy assessments, etc., in income tax cases are also applicable here. The income tax forms in the exhibits for these special circumstances, with appropriate modifications, may be used for these estate and gift taxes.

2. In estate tax cases, no year is indicated in the stipulation, Rule 155 computation or decision. For gift tax cases, the calendar quarter or calendar year is used and not the taxable year or fiscal year.

3. In estate tax cases, additional deductions for expenses of administration incurred after the filing of the petition may be included in the stipulation, Rule 155 computation, or decision. Administration expense deductions incurred at or after trial may also be claimed in a Rule 155 computation.

4. To support a claim for a credit under section 2011 for the payment of state estate, inheritance, legacy, or succession taxes, the petitioner must furnish proof of actual payment. Therefore, in the settlement of estate tax cases, the gross deficiency or gross overpayment is usually stipulated because the petitioner is unable to furnish the required proof of payment necessary to compute the net deficiency or net overpayment when the settlement stipulation is prepared. Under section 2011(c), the petitioner may obtain credit for state death taxes after the decision is entered in the Tax Court if the claim therefore is submitted to the Service within the statutory period. If an extension has been granted under sections 6161 or 6166, the petitioner may use the longer of the periods provided in section 2011(c)(1)(2) and (c)(2). For the same reason, the gross deficiency or gross overpayment is usually determined in Rule 155 cases. Any dispute in a Rule 155 case over the allowance of the state inheritance tax credit should be resolved by giving the taxpayer assurance that under section 2011(c) the petitioner may obtain such credit if a claim is timely filed after the entry of the decision. Therefore, it is desirable to include in the stipulation, the stipulation portion of the combined decision document, the Rule 155 computation statement, or the stipulation portion of the Rule 155 decision a "credit paragraph." This paragraph must never be included in the court’s decision as distinguished from the stipulation portion of a combined stipulation and decision document. If the net deficiency or net overpayment of estate tax is stipulated or provided for in the Rule 155 computation, the "credit paragraph" must be omitted from these documents.

5. When payment of an estate tax liability has been deferred under sections 6161 or 6166, the amount of interest to be incurred on federal and state estate tax liabilities may be deducted only as that interest accrues.

6. In cases where an estate tax liability has been deferred under section 6166, a final decision should be entered. Pursuant to section 7481(d) and T.C. Rule 262, the petitioner may file a motion to modify the decision for allowance of interest expenses paid during the extended payment period once all the payments have been made. Only one Rule 262 motion may be filed at the end of the extended payment period in each case, but the estate may administratively file supplemental Forms 706, U.S. Estate Tax Return, to periodically recompute the estate tax liability and thus reduce the amount of the installment payments due over the extended payment period. _See_ Rev. Proc. 81–27, 1981–2 C.B. 548. In cases decided by the Tax Court, a Rule 262 motion is necessary to obtain a refund or credit of taxes overpaid during the installment period. As soon as the decision is filed, the petitioner should be reminded to file a motion under Rule 157 to have the Tax Court retain the official case file pending a Rule 262 motion. The attorney should also retain the legal file. If a Rule 262 motion for allowance of interest costs is filed, it should be reviewed for reasonableness. The attorney should ordinarily have no objection to the motion. If there is an objection, reasons and support therefor should be filed with the court.

7. In cases where an estate tax liability has been deferred under section 6161, no final decision should be entered until the final installment of the deferred tax is due or paid, whichever occurs earlier. Because section 7481(d) does not apply to interest on payments deferred under section 6161, the procedures implemented by the Tax Court prior to the enactment of section 7481(d) should be followed. In such a case, the parties should stipulate that the time for payment of the estate tax liability is extended and that the sole purpose for leaving the case open is to allow petitioner the right to claim the amounts of interest accruing on the installment payments as an expense of administration under section 2053. See Exhibit 35.11.1–169, Net Operating Losses: Deficiency Before and Overpayment After Net Operating Loss Carryback. A joint motion to stay proceedings for this purpose until the final installment of the estate tax liability is due or paid should also be filed. See Exhibit 35.11.1–170, Motion to Stay Proceedings: Deficiency in Estate Tax (Extended Payment under IRC § 6161) — Stipulation. The provisions of Rev. Proc. 81–27, 1981–2 C.B. 548, as discussed above, also apply to installment payments under section 6161.

8. In cases where it is determined that a petitioner has made an overpayment of estate tax, the stipulation or Rule 155 computation and the court’s decision should include an apportionment of the overpayment between the overpayment of the estate tax liability and any overpayment of interest. The dates on which the overpayments arose should be specified. If there is no overpayment of interest, the stipulation or Rule 155 document should so state. Both portions of the overpayment are subject to Tax Court jurisdiction and may be refunded under section 6512(b).


**35.8.5.4** **(08-11-2004)**

### Husband and Wife — Joint Liability — Separate Petitions

1. When a single statutory notice is issued to a husband and wife for their joint and several liability, and each files a separate petition with the Tax Court, difficulties may be encountered in the disposition of the cases. When possible, a motion should be filed to consolidate the two cases. Upon settlement or other disposition of the single liability due from the petitioners, a transferee duplication form of stipulation may be filed showing that the deficiency to be determined by the court in each case is a duplication of the deficiency in the other case.


**35.8.5.5** **(05-22-2012)**

### Failure to Pay Addition to Tax for Returns Prepared Under Section 6020(b)

1. Section 6651(g) provides for the application of section 6651(a)(2) "failure to pay" addition to tax to returns prepared pursuant to section 6020(b). Where the Tax Court has jurisdiction to redetermine the underlying tax deficiency, it may also have jurisdiction over the section 6651(a)(2) addition to tax imposed pursuant to section 6020(b) returns. See CCDM 35.2.2.11, Answers in Failure to Pay (Section 6651(a)(2) Cases Where Substitute for Return Filed under Section 6020(b)).

2. The preparation of decision documents for cases involving additions under section 6651(a)(2) will vary depending on the particular circumstances: _e.g._, whether the years in issue predate the enactment of section 6651(g); whether or not the addition to tax is continuing to accrue; whether the petitioner conceded the case in full; whether the case was settled for a reduced deficiency; whether the petitioner filed a delinquent return; whether the statutory notice of deficiency set forth the addition to tax in a sum certain; and where section 6651(a)(2) is not applicable. Sample decision document paragraphs addressing these scenarios are set forth in Exhibit 35.11.1–173, Failure to Pay Addition to Tax From Return Prepared under IRC section 6020(b). Questions concerning preparation of decision documents involving failure to pay addition to tax for returns prepared under section 6020(b) should be referred to Office of Associate Chief Counsel (P&A), Branch 1 or 2.


**35.8.5.6** **(08-11-2004)**

### Consolidated Cases

1. If the court consolidates a group of cases for trial and the entire group is settled at any time before the court issues an opinion, the stipulated decision documents for all the cases must be filed at one time. If only some of the cases in the group are settled, a motion to sever the settled cases from the remaining cases should be filed concurrently with the stipulated decision documents.

2. If the court consolidates a group of cases for trial and states in its opinion that the decisions will be entered under Rule 155, the Rule 155 computations and proposed decisions for all the cases in the group must be filed at one time. If the computations are agreed for some cases and unagreed for other cases, it is still necessary to file all the computations at one time. If it becomes necessary to file any agreed computations prior to filing computations for the remaining cases in the group, an appropriate motion to sever should be filed concurrently with the agreed computations and proposed decision. In most situations, the court prefers that decisions in consolidated cases decided by an opinion of the court be entered on the same day, so that all appeal periods of the consolidated petitioners run concurrently.


**35.8.5.7** **(05-22-2012)**

### Relief from Joint and Several Liability Cases

1. Section 3201 of the Internal Revenue Service Restructuring and Reform Act of 1998 (RRA98), Pub. L. No. 105–206, expanded relief from joint and several liability by repealing section 6013(e) and enacting section 6015. Section 6015 provides three avenues of relief from joint and several liability under section 6015(b), (c), and (f). Section 6015(b) allows taxpayers who have filed joint income tax returns relief from joint and several liability under certain circumstances. Section 6015(c) provides taxpayers who meet certain threshold marital requirements the opportunity to limit their liability by electing to allocate the deficiency. Section 6015(f) allows the Secretary to grant relief when, taking into account all of the facts and circumstances, it is inequitable to hold the individual liable and relief is unavailable under section 6015(b) or (c). _See also_ Rev. Proc. 2000–15, 2000–1 C.B. 447, and the superseding Rev. Proc. 2003-61, 2003-2 C.B. 296. Section 6015(e) confers jurisdiction upon the Tax Court to review the Secretary’s determinations under section 6015. The Tax Court reviews the Secretary’s determinations under section 6015(b) and (c) _de novo_ and determinations under section 6015(f) for an abuse of discretion. Section 6015 is effective for liabilities arising after July 22, 1998, and liabilities arising before July 22, 1998, that were unpaid as of that date. Former section 6013(e) still applies to liabilities arising before July 22, 1998, that were paid as of that date.

2. The preparation of decision documents for cases involving claims for relief from joint and several liability under section 6015 will vary depending on the particular circumstances of the case: _e.g._, whether the petitioner petitioned from a final determination letter under section 6015(e) or from a notice of deficiency under section 6213(a), whether relief is denied or granted in full/in part; or whether the granting of relief results in an overpayment. Sample decision documents are found in the accompanying exhibits. (See Exhibits 35.11.1–173 through 35.11.1–181). Questions concerning preparation of decision documents in cases involving relief from joint and several liability should be referred to Office of Associate Chief Counsel (P&A), Branch 1 or 2.


**35.8.5.8** **(06-29-2022)**

### Abatement of Interest Cases

1. Section 6404(h) provides the Tax Court with jurisdiction to determine whether the Service’s failure to abate interest was an abuse of discretion. Under this section, the taxpayer may petition the Tax Court on a date which is 180 days after the date of filing of the request for abatement, even if a determination has not been issued. Section 6404(h)(1). _See also_ T.C. Rule 281 (reflecting amendments to section 6404(h) as part of the Protecting Americans from Tax Hikes Act of 2015). Abatement of interest cases are different from traditional Tax Court cases in a number of fundamental ways. Decision documents in abatement cases are reviewed by Office of Associate Chief Counsel (P&A), Branch 3 or 4.


**35.8.5.9** **(05-22-2012)**

### Disclosure Actions: Section 6110 Cases

1. Section 6110(f)(2) provides the Tax Court with jurisdiction to review determinations by the Service with respect to whether and to what extent written determinations and background file documents may be disclosed to the public. This type of action may involve a trial, though almost all such actions are disposed of without trial. Questions concerning preparation of decision documents in such matters should be coordinated with the Deputy Associate Chief Counsel (Legislation & Privacy).


**35.8.5.10** **(05-22-2012)**

### Employment Tax Cases: Worker Classifications

1. Under section 7436(a), the Tax Court has jurisdiction to (1) review the Service’s determination that one or more individuals performing services for the taxpayer are employees; (2) review the Service’s determination that the taxpayer is not entitled to treatment under section 530(a) of the Revenue Act of 1978 with respect to those individuals; and (3) determine the proper amount of employment tax under the above determinations. A decision document in a section 7436 case will address all three of these issues.

2. The employment taxes imposed by subtitle C of the Code are Federal Insurance Contributions Act taxes (under sections 3101–3128), the Railroad Retirement Tax Act taxes (under sections 3201–3232), the Federal Unemployment Tax Act taxes (under sections 3301–3311), the Railroad Unemployment Repayment Tax taxes (under sections 3321–3322), and the collection of income tax at source on wages (under sections 3401–3406). "Employment tax" under the statutory language includes the additions to tax, additional amounts, and penalties provided by chapter 68A of the Code (sections 6651–6665). Thus, the Tax Court has jurisdiction to determine the proper amount of the additions to tax, additional amounts, and penalties that relate to the employment tax imposed by subtitle C with respect to determinations of worker classification and section 530 treatment. A decision document in a section 7436 case will set out these amounts for each tax period (quarter or year) in tabular form. See Exhibits 35.11.1–182 through 35.11.1–184.

3. Section 7436(a) does not provide the Tax Court with jurisdiction to review any employment tax determinations other than the three listed in the statute. Thus, a decision document in a section 7436 case will address only the three issues under the court’s jurisdiction. For example, a decision document in a section 7436 case will not address worker classification issues not arising under Subtitle C, such as the classification of individuals for purposes of pension plan coverage or the proper treatment of individual income tax deductions. Nor will a decision document in a section 7436 case address employment tax issues not listed in the statute, such as whether deductions are made under an accountable plan under section 62(c). A section 7436 decision document will not address income tax.

4. Section 7436(d)(1) provides that various restrictions on assessment in section 6213 apply in the same manner as if a notice of deficiency had been issued (only the principles of subsections (a), (b), (c), (d), and (f) of section 6213 apply to the worker classification proceedings under section 7436). Thus, after the Notice of Determination is mailed, the Service is precluded from assessing the taxes identified in the Notice of Determination prior to expiration of the 90-day period during which the taxpayer may file a timely Tax Court petition. The Service may immediately assess proposed employment tax amounts that do not arise as a result of a determination by the Service that an individual is an employee of the taxpayer. To the extent the employment taxes relate to individuals the taxpayer was already treating as employees, those tax amounts would not be included in the Notice of Determination and thus, assessment of those taxes would not be restricted by section 6213(a).

5. The decision document in an agreed section 7436 case should contain a waiver paragraph as follows:


    "It is stipulated that, effective upon the entry of this decision by the court, petitioner waives the restrictions contained in I.R.C. § 7436(d) (referring to I.R.C. § 6213(a)) prohibiting assessment and collection of the tax (and penalties and additions to the tax), plus statutory interest until the decision of the Tax Court becomes final."

6. In every section 7436 case in which a proper amount of employment tax greater than zero is stipulated, the separate stipulation document or the stipulation part of the combined stipulation and decision document should contain the following paragraph:


    "It is stipulated that interest will be assessed as provided by law on the tax, addition(s) to tax, and penalty(ies) due from petitioner."

7. In section 7436 worker classification cases involving a penalty, as opposed to an addition to tax, the penalty is referred to as a penalty. Also, employment tax cases under section 7436 do not involve a deficiency (as defined in section 6211); thus, the decision document will not state the amount of the deficiency, but rather the proper amount of employment tax.

8. As a general rule, decisions in section 7436 cases are reviewed and approved by the Division Counsel/Associate Chief Counsel (Tax Exempt and Government Entities).


**35.8.5.11** **(08-11-2004)**

### Decisions in Declaratory Judgment Cases

1. This sub-section discusses decisions in declaratory judgment cases


**35.8.5.11.1** **(05-22-2012)**

#### Scope of Judgment in Employee Plans Declaratory Judgment Cases

1. The amount of tax liability is not an issue under section 7476.

2. If a plan is determined not to be qualified, and if the Service has determined a deficiency against the employer arising from its claim of deductions for contributions to the plan, the employer can litigate the amount of the tax that it owes in a separate deficiency case. Similarly, if the Service has determined a deficiency against the trust based on income received while it was not exempt under section 401, the trust can litigate the amount of the tax that it owes in a separate deficiency case.

3. The decision must state whether the plan is qualified or not under section 401.

4. The decision document should state that the decision does not operate to prejudice the rights of any other parties under ERISA or any state or local law. See Exhibit 35.11.1–185, Employment Tax: Decision Document in Settled IRC § 7436 Case — Decision in Favor of Respondent, for decision document in such a case.


**35.8.5.11.2** **(05-22-2012)**

#### Scope of Judgment in Exempt Organizations Declaratory Judgment Cases

1. The amount of tax liability is not an issue under section 7428.

2. A taxpayer judicially determined not to be exempt can still litigate the amount of tax owed. _Synanon Church v. Commissioner_, T.C. Memo. 1989–270.

3. The decision must address whether the organization qualifies or fails to qualify for the exemption or classification. See Exhibit 35.11.1–186, Declaratory Judgement Cases: Retirement Plans. Section 7428 grants the Tax Court jurisdiction to make a declaration with respect to the Service’s determination (or failure to make a determination) of initial or continuing qualification of an organization under section 501(c)(3) or with respect to its initial or continuing classification as a private foundation, as defined in section 509(a), or a private operating foundation, as defined in section 4942(j)(3).

4. Any such declaration has the force and effect of a Tax Court decision and is reviewable as such. _See_ T.C. Rules 210–218 and Interim T.C. Rules 210, 211, 215, and 217.


**35.8.5.11.3** **(08-11-2004)**

#### Scope of Judgment in Government Obligations Declaratory Judgment Cases

1. In a governmental obligation declaratory judgment case, the Tax Court decision relates to whether interest on prospective obligations will be excludable from gross income under section 103(a). Any such declaration has the force and effect of a Tax Court decision and is reviewable as such. _See_ T.C. Rules 210–218. Tax Court decisions relating to governmental obligations may only be reviewed by the U.S. Court of Appeals for the District of Columbia Circuit. _See_ section 7482(b)(3).

2. Preparation of decision documents for tax exempt bond (government obligations) cases must be coordinated and pre-reviewed by Division Counsel/Associate Chief Counsel (TEGE).


**35.8.5.12** **(05-22-2012)**

### Fraud in Bankruptcy: Entry of Stipulated Decision Involving Fraud Penalty

1. Stipulated agreements as to fraud in civil tax cases do not generally have preclusive effect for dischargeability purposes in subsequent bankruptcy proceedings. When intended by the parties, however, Field attorneys should attempt to draft stipulated Tax Court decisions involving the fraud penalty in such a way as to avoid having to relitigate the issue of fraud in a subsequent bankruptcy proceeding.

2. A stipulated decision will not ordinarily result in any preclusive effect in determining dischargeability in bankruptcy proceedings. This is also true, of course, where a court has entered a default judgment against one of the parties. The parties may, however, be able to stipulate to the applicability of collateral estoppel by carefully drafting the stipulated decision to state such an intention. The following language can be used in stipulations in either Tax Court or refund litigation to establish the intent that collateral estoppel should apply as to fraud, but only in cases where the Service has asserted a positive monetary fraud penalty against the taxpayer:


    "The parties agree that it is their intention that the finding of fraud in regard to petitioner’s (plaintiff’s) tax return for taxable year \[year\] shall have preclusive effect under the doctrine of collateral estoppel in any subsequent litigation concerning taxable year \[year\]. Such litigation shall include litigation pursuant to Title 11of the United States Code."

3. In addition, the following language should be included in stipulated decisions themselves:


    "Pursuant to the agreement of the parties and incorporating the allegations of fact set forth in paragraph no. \[#\] of respondent’s answer as findings of fact of this court, it is hereby ordered . . ."

4. Conversely, field attorneys should carefully review any stipulation in cases where a determination has been made to forego assertion of the fraud penalty in Tax Court or refund litigation to ensure that it does not unintentionally preclude future litigation in bankruptcy proceedings as to the existence of fraud.

5. It is not intended that such provisions always be inserted in stipulated decisions when a fraud penalty is at issue in the case. Rather, only when the circumstances strongly indicate that the taxpayer will unfairly attempt to discharge his tax liabilities after agreeing to those taxes should this procedural tactic be considered. In either situation, review or drafting of the stipulations is not routine and should be coordinated with Office of Associate Chief Counsel (P&A), Branch 5.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-008-005#addtoany "Show all")

A2A