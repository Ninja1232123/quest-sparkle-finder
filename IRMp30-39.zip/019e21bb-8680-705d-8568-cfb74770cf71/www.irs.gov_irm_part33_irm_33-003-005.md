---
url: "https://www.irs.gov/irm/part33/irm_33-003-005"
title: "33.3.5 Congressional and Other IRS Controlled Correspondence | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part33/irm_33-003-005#main-content)

- 33.3.5  [Congressional and Other IRS Controlled Correspondence](https://www.irs.gov/irm/part33/irm_33-003-005#idm139835087737200)
  - 33.3.5.1  [Congressional Correspondence](https://www.irs.gov/irm/part33/irm_33-003-005#idm139835087751776)
  - 33.3.5.2  [Processing Congressional Correspondence](https://www.irs.gov/irm/part33/irm_33-003-005#idm139835087749136)
    - 33.3.5.2.1  [Centralized Receipt and Control of Congressional Correspondence](https://www.irs.gov/irm/part33/irm_33-003-005#idm139835087746528)
    - 33.3.5.2.2  [Signature Principles](https://www.irs.gov/irm/part33/irm_33-003-005#idm139835087823616)
  - 33.3.5.3  [Processing Other Service Controlled Correspondence](https://www.irs.gov/irm/part33/irm_33-003-005#idm139835087820320)

# Part 33. Chief Counsel Directives Manual Legal Advice

# Chapter 3. Other Legal Advice

# Section 5. Congressional and Other IRS Controlled Correspondence

* * *

## 33.3.5 Congressional and Other IRS Controlled Correspondence

#### Manual Transmittal

July 08, 2021

#### Purpose

(1) This transmits new CCDM 33.3.5, Other Legal Advice, Congressional and Other IRS Controlled Correspondence.

#### Background

CCDM 33.3.5 is being revised to set forth procedures ensuring that significant responses to congressional inquiries are reviewed before issuance by a Deputy Chief Counsel or the Chief Counsel.

#### Material Changes

(1) CCDM 33.3.5.2.1(2) is updated to reflect that draft replies to congressional inquiries must be sent to the Executive Secretariat Correspondence Office (ESCO).

(2) CCDM 33.3.5.2.2(1) is revised to reflect that the appropriate Associate Chief Counsel or Division Counsel must provide a copy of a significant response to a congressional inquiry, prior to issuance, to a Deputy Chief Counsel or the Chief Counsel.

(3) CCDM 33.3.5.2.1(3) and (4) are updated to reflect the change in the title of TSS from "TSS4510" to "TSS Assignments" .

#### Effect on Other Documents

This section supersedes CCDM 33.3.5 dated August 11, 2004.

#### Audience

Chief Counsel

#### Effective Date

(07-08-2021)

Robert T. Wearing

Deputy Associate Chief Counsel

(Procedure & Administration)

**33.3.5.1** **(08-11-2004)**

### Congressional Correspondence

1. Congressional correspondence and telephone contacts, including contacts with congressional staffers, are controlled within the Service and the Office of Chief Counsel. Office of Chief Counsel employees who receive a congressional telephone call are to report all such calls to their Division Counsel or Associate Chief Counsel through their manager. If the congressional telephone call concerns an issue involving the operation of, or business of, the Service, the telephone call generally is to be referred to the Office of Legislative Affairs (Communications and Liaison). Congressional telephone calls concerning a docketed Tax Court case generally will be handled by field counsel after coordination with Associate Chief Counsel offices, as appropriate. Congressional telephone calls concerning a taxpayer specific matter that has been referred to the Department of Justice are to be referred to the Department of Justice trial attorney for a response. Congressional telephone calls concerning general legal issues are to be referred to the appropriate Associate Chief Counsel office.


**33.3.5.2** **(08-11-2004)**

### Processing Congressional Correspondence

1. The Office of Legislative Affairs (Communications and Liaison) processes and controls all congressional correspondence for the Service. Legislative Affairs reviews the incoming correspondence and assigns it to the appropriate Service function, including the Office of Chief Counsel, for a response. Any congressional correspondence received by the Office of Chief Counsel directly must be routed to Legislative Affairs through the Legislative Liaison Branch, Legal Processing Division (Procedure & Administration) to ensure that the correspondence is properly processed and controlled.


**33.3.5.2.1** **(07-08-2021)**

#### Centralized Receipt and Control of Congressional Correspondence

1. Receipt, control, and acknowledgment of congressional correspondence assigned to the Office of Chief Counsel. All congressional correspondence assigned to the Office of Chief Counsel is controlled and processed by TSS4510, Legal Processing Division Procedure & Administration. Upon receipt of the congressional correspondence from the Office of Legislative Affairs (Communications and Liaison), TSS4510 opens a TECHMIS case for the correspondence and assigns the case to the appropriate Associate Chief Counsel or Division Counsel. The TSS4510 also prepares and mails an acknowledgment letter to the appropriate Congressional office. This letter provides that a final reply generally will be mailed within 20 business days.

2. Replying to controlled correspondence. Guidance on drafting replies to congressional correspondence, including the _Guide to Congressional Correspondence_ (IRS Document 11155), is available on the Office of Legislative Affairs (Communication and Liaison) intranet site. Note that this guidance may not be applicable to Office of Chief Counsel in all situations, particularly with regard to references to the Service organizational structure. A copy of the draft reply, once approved by the appropriate signatory official, must be sent to the Executive Secretariat Correspondence Office (ESCO) at Executive.Secretariat.EReview@irs.gov, with CC to TSS.Assignments@irscounsel.treas.gov and the Special.Counsels.to.DCCs@irscounsel.treas.gov resource mailbox. ESCO will inform the responsible Associate Chief Counsel or Division Counsel office when the proposed response has been cleared by ESCO and/or of any suggested revisions. Where the requested revisions do not implicate the technical meaning or accuracy of the response, the responsible branch or office is expected to make such revisions, prior to mailing the reply and closing the TECHMIS case. If, however, the requested revisions do implicate the technical meaning or accuracy of the response, the responsible branch or office must contact ESCO to resolve any disagreements, prior to mailing the reply and closing the TECHMIS case.

3. Unless directed otherwise by TSS Assignments, the responsible Associate Chief Counsel or Division Counsel office should respond to congressional correspondence within 20 business days from the date that the TECHMIS case is opened and assigned by TSS Assignments. If the Associate Chief Counsel or Division Counsel office determines that a final reply will not be mailed within 20 business days, that office must contact the initiating Congressional office to explain the delay and work out a new response date. If this contact is made by telephone, the responsible office will document the telephone conversation in the case file. If this contact is made in writing, a draft must be cleared by ESCO as set out above. The responsible office also must inform TSS Assignments of the new due date as well as the date of the contact and the name and location of the person contacted in a timely manner.

4. Closing the TECHMIS assignment and the case file. After the reply to congressional correspondence is mailed, the TECHMIS assignment is closed by the responsible office, and a PDF of the final signed copy is emailed to TSS.Assignments@irscounsel.treas.gov. TSS Assignments will close the assignment in e-Track. The case file should be closed and maintained in accordance with the applicable provisions in CCDM 30.9, File Management.


**33.3.5.2.2** **(07-08-2021)**

#### Signature Principles

1. Generally, responses to the members of the Leadership and members of the House Ways and Means Committee, Senate Finance Committee, House and Senate Appropriations Committees, House Government Reform Committee, and Senate Governmental Affairs Committee must be signed by the Associate Chief Counsel or Division Counsel. If the response is significant (e.g., new legislation or a controversial matter), the Associate Chief Counsel or Division Counsel must provide a copy of the correspondence and proposed response to the appropriate Deputy Chief Counsel and the Chief Counsel prior to issuance. In some circumstances, the Chief Counsel may decide to sign the response. Responses to other members of Congress may be delegated to branch reviewers for signature.

2. Congressional correspondence prepared for the signature of the Chief Counsel must be routed through the appropriate Associate Chief Counsel or Division Counsel. Congressional correspondence prepared for the signature of the Commissioner will be routed through the offices of the Associate Chief Counsel or Division Counsel, and Chief Counsel. Congressional correspondence prepared for the signature of a Treasury official will be routed through the offices of the Associate Chief Counsel or Division Counsel, Chief Counsel, and Commissioner.


**33.3.5.3** **(08-11-2004)**

### Processing Other Service Controlled Correspondence

1. All correspondence controlled by the Commissioner’s Correspondence Office on the Service’s Executive Control Management System and assigned to the Office of Chief Counsel will be assigned within the Office of Chief Counsel in the same manner as congressional correspondence. The responsible Associate Chief Counsel or Division Counsel office will prepare a reply following procedures similar to those for processing congressional correspondence, except that the draft reply does not need to be cleared by the Office of Legislative Affairs (Communications and Liaison), and the signature of a branch reviewer generally is sufficient.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part33/irm_33-003-005#addtoany "Show all")

A2A