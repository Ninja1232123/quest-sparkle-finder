---
url: "https://www.irs.gov/irm/part35/irm_35-010-001"
title: "35.10.1 Awards of Litigation and Administration Costs and Fees | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part35/irm_35-010-001#main-content)

- 35.10.1  [Awards of Litigation and Administration Costs and Fees](https://www.irs.gov/irm/part35/irm_35-010-001#idm140417524352224)
  - 35.10.1.1  [Awarding of Costs and Fees Under Section 7430](https://www.irs.gov/irm/part35/irm_35-010-001#idm140417496118576)
    - 35.10.1.1.1  [Motions for Attorneys’ Fees and Costs](https://www.irs.gov/irm/part35/irm_35-010-001#idm140417496089232)
    - 35.10.1.1.2  [Settlement Authority](https://www.irs.gov/irm/part35/irm_35-010-001#idm140417528648192)
      - 35.10.1.1.2.1  [Appeals Office](https://www.irs.gov/irm/part35/irm_35-010-001#idm140417528646608)
      - 35.10.1.1.2.2  [Field Counsel](https://www.irs.gov/irm/part35/irm_35-010-001#idm140417496102224)
      - 35.10.1.1.2.3  [Associate Chief Counsel (P&A)](https://www.irs.gov/irm/part35/irm_35-010-001#idm140417496117168)
    - 35.10.1.1.3  [Decision Documents, Payment of Costs, and Appeals of Awards](https://www.irs.gov/irm/part35/irm_35-010-001#idm140417496113920)
      - 35.10.1.1.3.1  [Decision Documents](https://www.irs.gov/irm/part35/irm_35-010-001#idm140417496112288)
      - 35.10.1.1.3.2  [Payment of Litigation and Administrative Costs](https://www.irs.gov/irm/part35/irm_35-010-001#idm140417528643968)
      - 35.10.1.1.3.3  [Appeal of Awards](https://www.irs.gov/irm/part35/irm_35-010-001#idm140417524044192)
  - 35.10.1.2  [Actions for Administrative Costs](https://www.irs.gov/irm/part35/irm_35-010-001#idm140417524041984)
  - 35.10.1.3  [Qualified Offer Rule](https://www.irs.gov/irm/part35/irm_35-010-001#idm140417524014368)
    - 35.10.1.3.1  [Requirements for Qualified Offer](https://www.irs.gov/irm/part35/irm_35-010-001#idm140417496287504)
    - 35.10.1.3.2  [Review of a Qualified Offer](https://www.irs.gov/irm/part35/irm_35-010-001#idm140417524032464)

# Part 35. Chief Counsel Directives Manual Tax Court Litigation

# Chapter 10. Special Procedures When Attorneys' Fees and Sanctions Are Sought

# Section 1. Awards of Litigation and Administration Costs and Fees

* * *

## 35.10.1 Awards of Litigation and Administration Costs and Fees

#### Manual Transmittal

December 21, 2023

#### Purpose

(1) This transmits revised CCDM 35.10.1, Awarding of Costs and Fees Under Section 7430.

#### Background

This material is being revised to reflect current coordination and submission procedures and legal developments.

#### Material Changes

(1) 35.10.1.1.1(3) Motions for Attorneys' Fees and Costs is revised to include relevant notice from BBA procedures and for consistent reference to existing notices.

(2) 35.10.1.1.1(6)a. Motions for Attorneys' Fees and Costs, Written Responses is updated to clarify the method and timing of coordination.

(3) 35.10.1.1.2.1 Appeals Office clarifies that delegations of settlement authority do not affect mandatory coordination requirements.

(4) 35.10.1.1.2.2 Field Counsel increases the dollar thresholds on Field Counsel settlement authority and clarifies that delegations of settlement authority do not affect mandatory coordination requirements.

(5) 35.10.1.1.3.1(1) Decision Documents clarifies when settlements should be addressed above or below the line in decision documents.

(6) 35.10.1.1.3.2(1)a. Payment of Litigation and Administrative Costs is updated to reflect the electronic process for submitting awards and timing for requesting payment.

(7) 35.10.1.1.3.2(2) Offset is revised to reflect the electronic process for submitting claims.

(8) 35.10.1.3 Qualified Offer Rule is revised to reference new case law concerning when the substance is conceded in full, and the litigation position on partnership-level TEFRA cases.

(9) 35.10.1.3.1(2)d. Requirements for Qualified Offer is revised to address minimal offer amounts.

(10) 35.10.1.3.2(1) Review of a Qualified Offer: Forward the Offer to Procedure and Administration is updated to remove the requirement to fax offers and revise contact information for TSS.

(11) 35.10.1.3.2(2) Review of a Qualified Offer: Procedure and Administration's Review of the Offer is updated to clarify standard timing for review and expectations regarding submission.

(12) 35.10.1.3.2(3)b. Review of a Qualified Offer: Response to the Offer is revised to reflect contact information for TSS.

(13) 35.10.1.3.2(4) Review of a Qualified Offer: Sample Letters is updated to reflect current numbering of Exhibits.

#### Effect on Other Documents

This section supersedes CCDM 35.10.1, dated 1-6-2016.

#### Audience

Chief Counsel

#### Effective Date

(12-21-2023)

Kathryn A. Zuba

Associate Chief Counsel

(Procedure & Administration)

**35.10.1.1** **(08-11-2004)**

### Awarding of Costs and Fees Under Section 7430

1. The material in this chapter uses the term deficiency. Worker classification employment tax cases under section 7436 do not involve a deficiency (as defined in section 6211). The principles set forth below, however, apply to section 7436 cases as if the section 7436 notice of determination were a notice of deficiency. In addition, decisions in certain post-assessment proceedings such as interest abatement, spousal relief, and collection due process cases do not necessarily determine "deficiencies." Often, such cases determine "liabilities" or determine periods of interest abatement or other forms of relief.

2. The Tax Equity and Fiscal Responsibility Act, Pub. L. No. 97–248 (TEFRA) added section 7430 to the Internal Revenue Code. This section provides for awards of litigation and administrative costs to prevailing parties other than the government in tax related suits in a court of the United States, including the Tax Court. For a discussion of attorneys’ fees suits filed in district courts and the Court of Federal Claims, please refer to CCDM Part 36. It should also be noted that the Equal Access to Justice Act, Pub. L. 96–481, 94 Stat. 2325, does not apply to Tax Court proceedings. _See_ 28 U.S.C. § 2412(e).


**35.10.1.1.1** **(12-21-2023)**

#### Motions for Attorneys’ Fees and Costs

1. Section 7430(a) provides that the prevailing party in any administrative or court proceeding may be awarded a judgment for:



1. Reasonable administrative costs incurred in connection with administrative proceedings within the Internal Revenue Service, and

2. Reasonable litigation costs incurred in connection with court proceedings.


2. A prevailing party is defined as a taxpayer who substantially prevails as to the amount in controversy or with respect to the most significant issue or set of issues. Section 7430(c)(4)(A)(i); Treas. Reg. § 301.7430–5(a)(2). A party will not be treated as the prevailing party if the government establishes that its position was substantially justified. Section 7430(c)(4)(B)(i). The Service will be found to be substantially justified where its position had a reasonable basis in both law and fact. A position is also substantially justified if the position is justified to a degree that could satisfy a reasonable person. The Service’s position may be incorrect, but nevertheless be substantially justified if a reasonable person could think it correct. The taxpayer must also meet the net worth requirements of 28 U.S.C. § 2412(d)(2)(B) to meet the definition of a prevailing party.

3. For litigation costs, the position of the United States is taken by the Service as of the answer to the petition. For administrative costs, the position of the United States is taken as of the earlier of the date of the statutory notice of deficiency or the date of receipt by the taxpayer of the notice of the decision of the Appeals Office. For purposes of section 7430, the Service treats a notice of Final Partnership Adjustment (FPA), notice of Final Partnership Administrative Adjustment (FPAA), and a notice of Final S Corporation Administrative Adjustment (FSAA) the same as a statutory notice of deficiency.

4. Expansion of Authority to Award Costs and Certain Fees. The Internal Revenue Service Restructuring and Reform Act of 1998 (RRA98), Pub. L. No. 105–206 modified section 7430 to allow for recoveries of reasonable administrative costs back to the date of the first letter of proposed deficiency that allows a taxpayer an opportunity of administrative review in Appeals. The point of determining the reasonableness of the Service’s determination, however, has not changed. This point remains at the time the matter is finally determined by Appeals or at the time the notice of deficiency is issued. RRA98 also raised the hourly rate cap to the amount provided in the Equal Access to Justice Act, expanded the reasons available for exceeding that hourly rate cap, considered losses in other circuits to be relevant to the issue of substantial justification, allowed for the recovery of fees by pro bono representatives, and imposed a rule awarding litigation and administrative costs where the Service rejects a "qualified offer" during the "qualified offer period" and later recovers less than the amount offered even when the Service’s position was substantially justified as long as the other requirements of section 7430 are met.

5. Section 7430 has been amended several times since its enactment. As a result of these amendments, the section applies in three different forms depending on the time period in which a case was commenced. As originally enacted, section 7430 applied to cases commenced after February 28, 1983, and before January 1, 1986. For cases commenced after December 31, 1985, with claims to be paid after September 30, 1986, the Tax Reform Act of 1986, Pub. L. No. 99–514, altered the definition of "prevailing party" under section 7430. The Technical and Miscellaneous Revenue Act of 1988, Pub. L. No. 100–647 (TAMRA) amended section 7430 for cases and administrative proceedings commenced after November 10, 1988.

6. Written Responses. Under T.C. Rule 232(b), respondent is to file a written response to petitioner’s motion for an award of reasonable litigation or administrative costs within 60 days after service of the motion. The court can also order respondent to file a written response to petitioner’s motion for an award of reasonable litigation or administrative costs a certain number of days earlier than 60 days after service of the motion. In those cases, Field Counsel may consider requesting an extension to allow for the time period provided for in T.C. Rule 232(b). The only situation in which a written response is not required is when respondent is fully settling the cost issue.



1. All written responses must be submitted to the Associate Chief Counsel (P&A) by email to TSS Assignments for review before filing with the court, even if the issues are not complex or the amount at issue is small. **See** Exhibit 35.11.1–1 (Issues Requiring Associate Office Review). Responses shall contain the statements required by T.C. Rule 232(b). To facilitate the preparation of the written response, early coordination with the Associate Chief Counsel (P&A) is required. It is not necessary to wait for the draft to be completed to begin coordination.

2. All written responses must be received by the Associate Chief Counsel (P&A) at least ten calendar days before they must be filed with the court. The Associate Chief Counsel (P&A) will further coordinate all attorneys’ fees motions with the Associate office(s) controlling the underlying substantive issue(s) of the case.

3. When a written response has not been filed and the court grants an award of litigation or administrative costs, Field Counsel should immediately notify the Associate Chief Counsel (P&A). Field Counsel should also consider filing a motion for reconsideration with the Tax Court. The motion for reconsideration must be received by the Associate Chief Counsel (P&A) for review at least five calendar days before it must be filed.

4. In drafting a response or a motion for reconsideration, in addition to the elements required by T.C. Rule 232(b), the response should include any matter inside or outside of the courtroom that unreasonably delayed the conclusion of the litigation, such as petitioner’s failure to comply with the court’s orders or refusal to stipulate to matters that fairly should have been stipulated.


**35.10.1.1.2** **(08-11-2004)**

#### Settlement Authority

1. This subsection discusses settlement authority.


**35.10.1.1.2.1** **(12-21-2023)**

##### Appeals Office

1. Appeals, in docketed cases in which it proposes to agree to an award of litigation or administrative costs, will prepare a memorandum stating the rationale for such an award.

2. Appeals will forward that memorandum to Field Counsel, along with the files, to evaluate such a settlement. Appeals will send a copy of the memorandum to the Director of Appeals.

3. Field Counsel will independently evaluate the proposed settlement. If Field Counsel concurs with the settlement, Field Counsel will prepare a memorandum setting forth the reasons for accepting the settlement and explaining why the litigation or administrative costs are justified. The memorandum should discuss the statutory requirements embodied in section 7430.

4. Field Counsel will send the memorandum and files to the Associate Chief Counsel (P&A). All cases in which Field Counsel proposes to agree to an award of litigation or administrative costs must be submitted to the Associate Chief Counsel (P&A) for approval prior to being filed with the court, with the exception of those that may be settled by Field Counsel. **See** Exhibit 35.11.1–1 (Issues Requiring Associate Office Review). The settlement authority delegated to the Field in CCDM 35.10.1.1.2.2 does not change the need to coordinate the matter with the Associate Chief Counsel (P&A). Coordination remains mandatory, even though settlement authority has been delegated.


**35.10.1.1.2.2** **(12-21-2023)**

##### Field Counsel

1. With the following exceptions, the litigation or administrative cost issue in docketed Tax Court cases cannot be settled without the approval of the Associate Chief Counsel (P&A). Settlement authority has been delegated to Field Counsel in the following situations:



1. The litigation costs settlement offer does not exceed $50,000 and the administrative costs settlement offer does not exceed $10,000;

2. The taxpayer has exhausted available administrative remedies;

3. No prepetition expenses are awarded other than reasonable attorneys’ fees for the preparation and filing of a petition in the Tax Court;

4. Payment for attorneys’ fees in excess of the hourly fee prescribed by statute may only be made where it is determined that the conditions for a higher hourly rate set forth in section 7430(c)(1)(B)(iii) are likely to be satisfied by opposing counsel;

5. Payment for attorneys’ fees in excess of the hourly fee prescribed by statute based on an increase in the cost of living may not be based on a period for the calculation of this increase beginning before January 1, 1986; and

6. In _pro se_ cases only the filing fee and other reasonable court costs are to be paid; no lost opportunity costs are to be included in the settlements.


2. Even though Field Counsel has the authority to settle litigation costs in section 35.10.1.1.2.2, Field Counsel must coordinate the proposed decision document with the Associate Chief Counsel (P&A), Branch 5 before it is accepted. _See_ Exhibit 35.11.1–1 (Issues Requiring Associate Office Review).


**35.10.1.1.2.3** **(01-06-2016)**

##### Associate Chief Counsel (P&A)

1. The following settlements under section 7430 require the approval of the Associate Chief Counsel (P&A) regardless of the amount involved:



1. The settlement awards litigation costs for an individual authorized to practice before the Service but not before the Tax Court; or

2. The settlement awards litigation costs incurred in an appeal to the Tax Court of the administrative denial of reasonable administrative costs


**35.10.1.1.3** **(08-11-2004)**

#### Decision Documents, Payment of Costs, and Appeals of Awards

1. This subsection discusses decision documents, payment of costs, and appeals of awards.


**35.10.1.1.3.1** **(12-21-2023)**

##### Decision Documents

1. _See_ CCDM 35.8.2.6 for a discussion of decision documents in cases involving attorneys’ fees under section 7430. For matters in which a Motion for Costs has been filed with the Tax Court, section 7430 should be addressed above the line. For matters in which a Motion for Costs has not been filed with the Tax Court, section 7430 should be addressed below the line.


**35.10.1.1.3.2** **(12-21-2023)**

##### Payment of Litigation and Administrative Costs

1. Request for the Payment of Litigation and Administrative Costs. Awards for litigation or administrative costs are paid from the General Judgment Fund. The General Judgment Fund is administered by the Judgment Fund Branch, which is a part of the Department of the Treasury Bureau of the Fiscal Service (BFS). If litigation or administrative costs have been awarded in a Tax Court case, either as a result of litigation or settlement of the issue, Field Counsel to whom the case is assigned must do the following:



1. Complete an Award Data Sheet. **See** Exhibit 35.11.1–207. To facilitate the proper and expeditious handling of the litigation and administrative costs award, all of the information specified on the Award Data Sheet must be provided. Instructions on how to complete the items requested on the Award Data Sheet are provided in footnotes to the Award Data Sheet. In this regard, particular attention should be given to item H, BRIEF STATEMENT OF WHY THE AWARD WAS MADE. As explained in the accompanying footnote, this should not be a statement of the legal issue. Similarly, a statement that the award was ordered by the court or our position was not substantially justified is not sufficient. The following are examples of acceptable statements:


       \- “The taxpayer provided substantiation of his claimed Schedule C expenses to the Service prior to the issuance of the notice of deficiency. Consequently, the statutory notice should not have been issued. Although the issue was ultimately settled after the taxpayer filed a petition in the Tax Court, the taxpayer unnecessarily was forced to incur attorney fees and costs to resolve the matter.”


       \- “The taxpayer submitted a qualified offer that was not accepted by the Service. The amount of the taxpayer’s liability pursuant to the Tax Court’s decision is less than what the liability would have been under the qualified offer had it been accepted by the Service. Therefore, the taxpayer is entitled to recover reasonable litigation costs pursuant to the qualified offer rule.”


       \- “The Service’s position was not substantially justified because the Service lacked basis in fact for determining that the taxpayer was liable for accumulated earnings tax when it had no facts about the taxpayer's business plans and did not show whether case was diligently investigated.”


       \- “The Service’s position was not substantially justified because the Service relied on an unsupported notice of deficiency. In particular, the taxpayer had presented the Service documentation regarding the taxpayer’s earnings. The amount of earnings the taxpayer had reported on the taxpayer’s return was inconsistent with the amount the payor had reported on the Form 1099. The Service, however, assessed a deficiency based on the amounts reported on the Form 1099, which Form was unsubstantiated by the payor and unreliable.”

2. Email the completed Award Data Sheet along with a copy of the entered decision to the TSS Assignments mailbox and the Associate Chief Counsel (P&A), Branch 5, Branch Chief. The Award Data Sheet and a copy of the entered decision should be emailed to the TSS Assignments mailbox and the Associate Chief Counsel (P&A), Branch 5, Branch Chief within ten calendar days of the **earliest** of:


       a. the date the entered decision become final, which is generally 90 days after the decision is filed under Tax Court Rule 190(a), or


       b. if the entered decision is wholly adverse to the Government, the date Field Counsel is informed that the Government decided not to seek further review of the entered decision, or


       c. if the entered decision is the result of a settlement, the date the entered decision is filed with the Tax Court.

3. See section (2) below regarding including instructions for offset in the Award Data Sheet.


2. **Offset**. If the entered decision reflects both a deficiency that is owed by the taxpayer and an award of litigation or administrative costs to the taxpayer, then Field Counsel must state on the Award Data Sheet that an offset is to be made and the amount of the offset.



1. BFS will **not** offset interest. The amount of the award that is eligible to be offset is limited to any unpaid deficiency that is determined in the entered decision that contains the award, exclusive of interest, regardless of whether the interest has been assessed. Consequently, do not include any unpaid interest in the offset amount set forth in the Award Data Sheet.

2. The award may only offset a deficiency for which a court has issued a judgment against the taxpayer, or for which the Service has issued a tax levy pursuant to section 6331. In cases where a court decision both awards litigation and administrative costs and determines a deficiency, BFS will automatically offset the deficiency against the litigation and administrative costs award. Similarly, in cases where the Service has issued a tax levy, BFS will automatically offset the deficiency against the litigation and administrative costs award.

3. In cases where the court decision did not determine a deficiency or the deficiency is not reflected in any other court document such as an order or judgment, then BFS will not automatically offset the litigation and administrative costs award against the deficiency. Instead, BFS will request the taxpayer to consent to the offset. If the taxpayer consents to the offset, then BFS will proceed to offset the deficiency against the award. If the taxpayer does not consent to the offset, then BFS will consult with the Service and the Department of Justice about bringing a civil action to reduce the deficiency to a judgment. If the civil action is successful, then BFS will offset the amount of the judgment from the litigation and administrative costs award. If the civil action is unsuccessful, then BFS will pay the withheld amount to the taxpayer with interest accruing from the date when the payment would have been made.


3. **Processing of Award.** Upon receipt of the Award Data Sheet and entered decision, the Associate Chief Counsel (P&A), Branch 5, inputs and submits the completed claim package in the Judgment Fund Internet Claims System (JFICS). The BFS Judgment Fund Branch accesses the completed claim in JFICS for processing and approval. The submission of all paperwork to, and communications with, the Judgment Fund Branch and Treasury regarding the processing, status updates or payment of litigation and administrative costs awards are the sole responsibility of the Office of the Associate Chief Counsel (Procedure and Administration). The Field Counsel assigned to the case should not communicate or send anything relating to the litigation and administrative costs award directly to the Judgment Fund Branch or other parts of Treasury. Field Counsel should immediately forward any communications received from the Judgment Fund Branch to Associate Chief Counsel (P&A), Branch 5, Branch Chief.

4. **Payment of the Award.** To the extent that the administrative and litigation costs award exceeds the amount of the offset, if any, it is the policy and practice of the Office of Chief Counsel to have the award check issued in the name(s) of the taxpayer(s), not the taxpayer’s representative. The check is mailed, however, to the attention of the Field Counsel at the appropriate office address. Upon receipt, it is the responsibility of that Field Counsel to deliver the check to the taxpayer’s representative. The check should not be given to the taxpayer. This procedure was adopted by our office to avoid involvement in fee disputes between the taxpayer and the taxpayer’s representative.



1. There should be no deviation from this procedure unless the case involves pro bono representation.

2. In the case of pro bono representation, the check should be made payable to the taxpayer’s pro bono representative, unless the Service is specifically instructed by the representative, in writing, to pay the fee to the representative’s employer, such as a law firm.


       (1). Fees awarded for services provided by an employee of a pro bono clinic or organization, or a student affiliated with a pro bono clinic or organization, will be paid to the clinic or organization.


       (2). If an individual representative who is not an employee of a pro bono clinic or organization volunteers to provide services in affiliation with a pro bono clinic or organization, fee awards in that context will be paid to the clinic or organization.


**35.10.1.1.3.3** **(01-06-2016)**

##### Appeal of Awards

1. Under section 7430(f), an order granting or denying (in whole or in part) an award for administrative or litigation costs is incorporated as a part of the decision or judgment in the case and is subject to appeal in the same manner as the decision or judgment. T.C. Rule 190(a) provides that the parties have 90 days after the decision is entered to file a notice of appeal. Such an award is appealable in the same manner as the decision or judgment and thus awards in "S" cases are not appealable. A decision granting or denying (in whole or in part) an award for administrative costs at the administrative level is appealable to the Tax Court for administrative proceedings commenced after November 10, 1988.


**35.10.1.2** **(01-06-2016)**

### Actions for Administrative Costs

1. Section 7430(f)(2), effective with respect to proceedings commenced after November 10, 1988, establishes jurisdiction in the Tax Court to decide appeals of taxpayers from decisions by the Internal Revenue Service denying awards for reasonable administrative costs within the meaning of section 7430(c)(2).

2. An action under T.C. Rule 271 is a separate litigation proceeding and is to be distinguished from a proceeding initiated by a motion under the Tax Court Rules of Practice and Procedure involving a dispute with respect to litigation costs and administrative costs where a deficiency proceeding is already before the Tax Court. _See_ T.C. Rules 230 through 233.

3. An action brought under T.C. Rule 271 for administrative costs is governed by the following small tax case rules: T.C. Rule 172 (representation) and T.C. Rule 174 (trial). _See_ T.C. Rule 274. Not all rules of small case procedure are applicable. For example, answers are required to be filed in all such cases under T.C. Rule 272.


**35.10.1.3** **(12-21-2023)**

### Qualified Offer Rule

1. Section 3101 of the Internal Revenue Service Restructuring and Reform Act of 1998 (RRA98), Pub. L. No. 105–206, made several modifications to section 7430, including the addition of a qualified offer rule effective for costs incurred after January 18, 1999.

2. In general, a prevailing party may recover the reasonable administrative and litigation costs incurred in administrative and court proceedings if the proceedings relate to the determination, collection, or refund of any tax, interest, or penalty under the Internal Revenue Code. Under the statute, as amended by RRA98, the making of a qualified offer may result in the taxpayer being treated as a prevailing party for purposes of a recovery of costs. A taxpayer is a prevailing party by reason of making a qualified offer if the taxpayer’s liability under the last qualified offer would equal or exceed the amount of the taxpayer’s liability under the judgment entered by the court.

3. Additional Requirements For Qualifying as a Prevailing Party. To qualify as a prevailing party under the statute, taxpayers must meet the net worth requirements of section 7430(c)(4)(A)(ii). Furthermore, to qualify for an award, taxpayers must meet the remaining requirements of section 7430, such as not unreasonably protracting the proceedings and, for purposes of an award of litigation costs, exhausting their administrative remedies.



1. A taxpayer cannot qualify as a prevailing party under the qualified offer rule if the determination of the court with respect to the adjustments included in the last qualified offer is issued pursuant to a settlement. **But see, Angle v. Commissioner,**T.C. Memo 2016-27 (respondent’s concession is not a settlement where it lacks consideration);**Knudsen v. Commissioner**, 793 F.3d 1030 (9th Cir. 2015) (respondent’s concession after submitting case fully stipulated was not a settlement); **Estate of Lippitz v. Commissioner**, T.C. Memo. 2007-293 (respondent’s concession after petitioner’s filing of motion for summary judgment was not a settlement); **see also Gladden v. Commissione**r, 120 T.C. 446 (2003) (judgment not issued exclusively pursuant to a settlement where the parties had already litigated and the court had already determined issues integral to the adjustments at issue).

2. A taxpayer cannot qualify as a prevailing party under the qualified offer rule in any proceeding in which the amount of tax liability is not in issue, including any declaratory judgment proceeding, any proceeding to enforce or quash any summons issued pursuant to the Internal Revenue Code, and any action to restrain disclosure under section 6110(f). A partnership cannot make a qualified offer in a TEFRA partnership-level proceeding because the qualified offer rule requires that the judgment of the court address the “liability of the taxpayer.” I.R.C. § 7430(c)(4)(E)(i). A partnership is not a taxpayer. Although tax liabilities flow through the partnership to the partners, the partners’ liabilities are not at issue in the TEFRA partnership-level proceeding. But see, **BASR Partnership v. United States**, 915 F.3d 771, FN 10 (Fed. Cir. 2019) (leaving open the question of whether a partnership could be considered a taxpayer under the qualified offer rule). See also, Hurford Investments No. 2, LTD. v. Commissioner, docket no. 23017-11, Orders dated December 21, 2018, and September 11, 2019.


4. A taxpayer qualifying as a prevailing party by reason of having made a qualified offer need not substantially prevail on either the amount in controversy or the most significant issue or set of issues presented.

5. Whether the positions of the United States in the administrative and litigation proceedings were substantially justified is not relevant for an award under the qualified offer rule.

6. The comparison of the taxpayer’s liability under the qualified offer with the liability under the judgment is central to the operation of the qualified offer rule. For a complete discussion of liability under the last qualified offer and liability pursuant to the judgment, refer to Treas. Reg. § 301.7430–7(b)(2), (b)(3).

7. An award based upon the taxpayer having made a qualified offer is limited to those reasonable administrative and litigation costs incurred on or after the date of the last qualified offer. If the taxpayer is a prevailing party without regard to the qualified offer rule, the reasonable administrative and litigation costs to which the taxpayer is thus entitled may not be awarded again by reason of the taxpayer having made a qualified offer. On the other hand, even though some costs in a proceeding may be awarded without regard to the qualified offer rule, it is possible for other costs in the same proceeding to be awarded under the qualified offer rule. For instance, costs incurred in different portions of the proceedings or with regard to different adjustments at issue may be awarded under the qualified offer rule despite the awarding of other costs without regard to the qualified offer rule.

8. The qualified offer rule is intended to encourage settlement. Therefore, if the taxpayer makes a qualified offer and the Services settles the matter, either by accepting the offer or by other means, the qualified offer rule does not provide for an award of fees.


**35.10.1.3.1** **(12-21-2023)**

#### Requirements for Qualified Offer

1. A qualified offer is a written offer that



1. Is made by the taxpayer to the United States during the qualified offer period, as defined in section 7430(g)(2) and Treas. Reg. § 301.7430-7(c)(7);

2. Specifies the offered amount of the taxpayer’s liability (determined without regard to interest unless interest is a contested issue);

3. Is designated as a qualified offer for purposes of section 7430 at the time it is made; and

4. Remains open from the date it is made until the earliest of the date the offer is rejected, the date the trial begins or the 90th day after the date the offer is made.


2. Specifies the Offered Amount of the Taxpayer’s Liability. To meet the requirement that the offer specifies the offered amount of the taxpayer’s liability, the offer must clearly specify the amount for the taxpayer’s liability (determined without regard to interest unless interest is a contested issue). The offer may be a specific dollar amount of the total liability or a percentage of the adjustments at issue in the proceeding at the time the offer is made. The amount must be with respect to all of the adjustments at issue in the administrative or court proceeding at the time the offer is made and only those adjustments. The specified amount must be an amount, the acceptance of which by the United States will fully resolve the taxpayer’s liability, and only that liability for the type or types of tax and the taxable year or years at issue in the proceeding.



1. An offer does not need to state that it is “without regard to interest.” Examples of compliant language include “Taxpayer offers $X in satisfaction of the tax liability and $Y in satisfaction of the penalty for tax year Z;” or “Taxpayer offers to concede X% of the tax liability and Y% of the penalty for tax year Z.”

2. Interest may only be included in the offer if interest “is a contested issue in the proceeding.” Generally, interest is considered a contested issue only if the interest is specifically at issue in the proceeding independent of the taxpayer’s objections to the underlying tax imposed. Moreover, before interest can be at issue, the court in which the proceeding has been brought must have jurisdiction to determine the amount of interest due on the underlying tax, penalties, additions to tax and additional amounts, which is relatively rare. For an extensive discussion of the limitations of the Tax Court’s jurisdiction with respect to interest, particularly within settlements, refer to **Smith v. Commissioner**, T.C. Memo. 2009-33. In **Smith**, the Tax Court explained that “even if the parties in a deficiency case unanimously requested it, the Court would not purport to enter a decision awarding or denying deficiency interest to the Commissioner.” Examples of cases in the Tax Court in which interest could be a contested issue are interest abatement cases under section 6404 and transferee liability cases. The statutory notice should specify if interest has been assessed, which would indicate that the Tax Court has jurisdiction over interest. In contrast, the district court generally will have jurisdiction over interest in a refund case. **See Commissioner v. McCoy**, 484 U.S. 3 (1987).

3. For administrative proceedings prior to the commencement of a court proceeding, interest will only be considered at issue if the Tax Court would have jurisdiction over interest once the taxpayer receives a statutory notice and files a petition. Unless and until a taxpayer full-pays the interest, no taxpayer may assert that interest is at issue because the district court could exercise jurisdiction over interest in a refund case. If the court would not have jurisdiction over interest, it cannot be a contested issue in the proceeding.

4. Offers for $1.00 or seeking a refund if one is available in the proceeding meet the requirement of specifying an offered amount.


3. **Period that the Offer Remains Open**. Counsel will treat the fourth requirement, that the offer remains open from the date it is made until the earliest of the date rejected, trial begins, or the 90th day after the date the offer is made as being met if, by its terms, the offer remains open at least until the earliest of those dates. If such an offer were to remain open longer than those three minimum periods, it would not fail to meet this requirement.



1. If no period is specified, the Service will presume the offer is open for the statutory period.

2. Any offer that states it is open until withdrawn by the taxpayer will not be considered open for the statutory period.

3. The taxpayer may extend the period the offer is open before it expires.


4. Made During the Qualified Offer Period. Aside from the minimum period during which a qualified offer must remain open, a qualified offer must be made during the qualified offer period. That period begins with the date the first letter of proposed deficiency that allows the taxpayer an opportunity for review in Appeals and it ends thirty days before the date the case is first set for trial. The qualified offer period will be extended if the case is removed from the trial calendar more than thirty days prior to the calendar call. In the United States Tax Court, cases are placed upon a calendar for trial and at the calendar call cases are scheduled for a specified day for trial during that trial calendar. Consequently, in determining when the qualified offer period ends for cases in the Tax Court and other courts of the United States using calendars for trial, the Office of Chief Counsel will consider a case to be set for trial on the date scheduled for the calendar call. Cases may be removed from a trial calendar at any time. Thus, a case may be removed from a calendar before the date which is 30 days before the date scheduled for that calendar. In those cases, the qualified offer period does not end until the case remains on a trial calendar on the date that precedes by thirty days the scheduled date of the calendar call for that trial session.



1. If the case is removed from the calendar more than 30 days prior to the original calendar date, then the qualified offer period remains open.

2. If the case is removed within 30 days of the calendar date set, then the qualified offer period ends on the date that is 30 days prior to the scheduled date of the calendar call for that trial session.

3. The qualified offer period may not be extended or reopened, although the period during which a qualified offer remains open may extend beyond the end of the qualified offer period.

4. For example, if a case is first scheduled for trial on May 1, the qualified offer period will end on April 1. If the case is continued on March 31 until July 1, then the end of the qualified offer period will be extended until June 1. If the case had been continued on April 1 until July 1, then the qualified offer period would not be extended and would end on April 1.


**35.10.1.3.2** **(12-21-2023)**

#### Review of a Qualified Offer

1. **Forward the Offer to Procedure and Administration**. Upon receipt of a settlement offer that purports to be a qualified offer, the attorney assigned to the case should promptly notify Associate Chief Counsel (P&A), Branch 5 by:



   - Forwarding a copy of the purported qualified offer and any relevant documentation, including a copy of the statutory notice and taxpayer’s petition, to the TSS Assignments mailbox and the Associate Chief Counsel (P&A), Branch 5, Branch Chief. This documentation should include the status of the case, including whether the case is on a trial calendar or has otherwise been set for trial, and if so, the date of the calendar call or trial.


2. **Procedure and Administration’s Review of the Offer**. Associate Chief Counsel (P&A), Branch 5, will review the purported qualified offer promptly and determine whether it meets the requirements of sections 7430(c)(4)(E) and (g). This review will include a determination as to whether the offer should be treated as a qualified offer, but generally will not include a recommendation as to whether the offer should be accepted. The review and determination will be conveyed in a timely manner, mindful of allowing adequate time for the assigned attorney to effectuate the acceptance or rejection of the offer. If there is a reason to expedite the review, such as trial preparation issues, please note that in the coordination request. There is no need to analyze the offer prior to submission for review by Associate Chief Counsel (P&A), Branch 5.

3. **Response to the Offer**. If a valid qualified offer is to be accepted, a written response should be prepared and sent. If it is determined that a valid qualified offer should be rejected on the merits, then, on a case-by-case basis, either a written response should be sent or the offer should be allowed to lapse. If it is determined that the offer is not a valid qualified offer, a written response should be prepared and sent either accepting the offer on its merits as a regular settlement offer or rejecting the offer on its merits.



1. All written responses should include the following:


       \- State if the offer is a valid qualified offer.


       \- State whether the Service will accept or reject the offer.


       \- Describe briefly the Service’s understanding of the terms of the offer.


       \- If the offer is not a qualified offer, explain why that is so, and (if the offer is not accepted) how the offer could be revised to constitute a qualified offer.


       \- Affirmatively request that, if the Service has misconstrued the offer, petitioner’s representative reply in writing explaining the misunderstanding regarding the offer.

2. Prior to being sent to the petitioner(s)’ representative, all written responses should be submitted to the TSS Assignments mailbox for review. To help expedite this review process, a copy should also be emailed directly to the Branch 5 attorney who reviewed the offer or, if one cannot be identified, the Branch Chief.


4. **Sample letters**. For sample letters accepting or rejecting a valid qualified offer see Exhibits 35.11.1-233 and 35.11.1-234. For sample letters accepting or rejecting an offer that is not a valid qualified offer see Exhibits 35.11.1-235 and 35.11.1-236.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part35/irm_35-010-001#addtoany "Show all")

A2A