---
url: "https://www.irs.gov/irm/part32/irm_32-004-002"
title: "32.4.2 Pre-Filing Agreements | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part32/irm_32-004-002#main-content)

- 32.4.2 [Pre-Filing Agreements](https://www.irs.gov/irm/part32/irm_32-004-002#idm140273572023856)
  - 32.4.2.1 [Reserved](https://www.irs.gov/irm/part32/irm_32-004-002#idm140273572080368)

# Part 32. Published Guidance and Other Guidance to Taxpayers

# Chapter 4. Special Pre-Filing Agreement Programs

# Section 2. Pre-Filing Agreements

* * *

## 32.4.2 Pre-Filing Agreements

**32.4.2.1** **(06-06-2005)**

### Reserved

1. Reserved


Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part32/irm_32-004-002#addtoany "Show all")

A2A