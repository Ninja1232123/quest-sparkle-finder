---
url: "https://www.irs.gov/irm/part39/irm_39-004-001"
title: "39.4.1 Matters Relating To Practice Before the IRS | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part39/irm_39-004-001#main-content)

- 39.4.1  [Matters Relating To Practice Before the IRS](https://www.irs.gov/irm/part39/irm_39-004-001#idm139912198203456)
  - 39.4.1.1  [Cases Originating with the Office of Professional Responsibility](https://www.irs.gov/irm/part39/irm_39-004-001#idm139912198206544)
  - 39.4.1.2  [Organizational and Attorney Responsibilities](https://www.irs.gov/irm/part39/irm_39-004-001#idm139912198177152)
  - 39.4.1.3  [Processing Litigation Cases by Area Counsel GLS](https://www.irs.gov/irm/part39/irm_39-004-001#idm139912171266768)
    - 39.4.1.3.1  [Summary Adjudication](https://www.irs.gov/irm/part39/irm_39-004-001#idm139912170708976)
    - 39.4.1.3.2  [Hearing Preparations](https://www.irs.gov/irm/part39/irm_39-004-001#idm139912170706672)
    - 39.4.1.3.3  [The Hearing](https://www.irs.gov/irm/part39/irm_39-004-001#idm139912170704512)
    - 39.4.1.3.4  [Proposed Findings and Conclusions](https://www.irs.gov/irm/part39/irm_39-004-001#idm139912171210448)
    - 39.4.1.3.5  [Appeals to the Secretary](https://www.irs.gov/irm/part39/irm_39-004-001#idm139912171208368)
    - 39.4.1.3.6  [Closing the Case](https://www.irs.gov/irm/part39/irm_39-004-001#idm139912171204528)
  - 39.4.1.4  [Area Counsel Advice and Litigation Support](https://www.irs.gov/irm/part39/irm_39-004-001#idm139912171202736)
  - 39.4.1.5  [Overview of Headquarters Branch Responsibilities](https://www.irs.gov/irm/part39/irm_39-004-001#idm139912198284208)
    - 39.4.1.5.1  [Coordination on Practice Issues Affecting Tax Administration or Circular 230-Related Guidance](https://www.irs.gov/irm/part39/irm_39-004-001#idm139912198277568)
  - 39.4.1.6  [Reference Materials](https://www.irs.gov/irm/part39/irm_39-004-001#idm139912198271984)
  - 39.4.1.7  [Cases Originating with the Joint Board for the Enrollment of Actuaries](https://www.irs.gov/irm/part39/irm_39-004-001#idm139912198263984)
  - 39.4.1.8  [Limited Practice by Tax Return Preparers](https://www.irs.gov/irm/part39/irm_39-004-001#idm139912169068704)
  - Exhibit  39.4.1-1  [Model Isolation Statement for Firms Practicing Before the Service (personal and substantial participation)](https://www.irs.gov/irm/part39/irm_39-004-001#idm139912169065696)

# Part 39. Chief Counsel Directives Manual General Legal Services

# Chapter 4. Practice Before the Internal Revenue Service

# Section 1. Matters Relating To Practice Before the IRS

* * *

## 39.4.1 Matters Relating To Practice Before the IRS

#### Manual Transmittal

April 11, 2022

#### Purpose

(1) This transmits revised CCDM 39.4.1, Practice Before the Internal Revenue Service; Matters Relating to Practice Before the IRS.

#### Background

This section is being revised to provide current policy and procedure concerning Matters Relating to Practice Before the IRS within the Office of Chief Counsel.

#### Material Changes

(1) CCDM 39.4.1.3 and related subsections were revised to reflect current procedures related to OPR case processing.

(2) CCDM 39.4.1.3 was revised for brevity and clarity, and paragraphs 39.4.1.3.3 - 39.4.1.3.4 were replaced by a reference to Circular 230 in 39.4.1.3(2) (Case Processing).

(3) CCDM 39.4.1.3.5 was renamed and revised to clarify the role of the GLS attorney when an appeal is filed with the Secretary.

(4) CCDM 39.4.1.3.6 was renamed and revised to reflect current case closing procedures.

(5) CCDM 39.4.1.3.7 - 39.4.1.3.9 were deleted.

(6) CCDM 39.4.1.6 was revised to reflect current citations to the Federal Register, Revenue Procedures, Forms and Publications.

(7) Minor typographical changes were made throughout the document.

#### Effect on Other Documents

This section supersedes CCDM 39.4.1, dated May 18, 2009.

#### Audience

Chief Counsel

#### Effective Date

(04-11-2022)

Mark Kaizen

Associate Chief Counsel

General Legal Services

**39.4.1.1** **(05-18-2009)**

### Cases Originating with the Office of Professional Responsibility

1. **Law Governing Practitioners.** Described below are the principal statutes controlling practitioners before the IRS.



1. The **Treasury Practice Statute**. Disciplinary authority over practitioners before the IRS is given to the Secretary of the Treasury by 31 U.S.C. § 330. The statute provides that, subject to 5 U.S.C. § 500, the Secretary may regulate the practice of representatives of persons before the Department of the Treasury.

2. The **Agency Practice Statute**. 5 U.S.C. § 500 permits attorneys in good standing before the highest court of a State, and certified public accountants duly qualified in a State, to practice before the IRS without enrollment. Section 500 does not limit the disciplinary authority of an agency over the individuals who appear in a representative capacity before the agency. 5 U.S.C. § 500(d)(2).


2. **Regulations**. The Secretary of the Treasury has promulgated regulations governing the practice of attorneys, certified public accountants, enrolled agents, enrolled actuaries, and certain others before the IRS. See Title 31, Code of Federal Regulations, Subtitle A, Part 10, issued in pamphlet form as Treasury Department Circular No. 230 ("Circular 230" ). The IRS’s Office of Professional Responsibility (OPR) administers and enforces Circular 230 under delegated authority of the Secretary of the Treasury.


**39.4.1.2** **(05-18-2009)**

### Organizational and Attorney Responsibilities

1. **General**. The Associate Chief Counsel, General Legal Services (GLS) advises and represents OPR. This section governs the handling of suspension and disbarment proceedings that OPR has referred to GLS and the handling of matters pertaining to limited practice by tax return preparers and the Joint Board for the Enrollment of Actuaries. See _CCDM 39.4.1.7_, Cases Originating with the Joint Board for the Enrollment of Actuaries; _CCDM 39.4.1.8_, Limited Practice by Tax Returns Preparers.

2. **Disclosure**. In connection with claimant representative matters, GLS Area Counsel, Branch Chiefs, and GLS attorneys assigned to matters under this section may disclose returns and return information as provided by IRC § 6103, e.g. 6103(l)(4). Novel, unclear, or sensitive disclosure issues must be coordinated with the Office of Associate Chief Counsel, Procedure & Administration (P&A).

3. **Litigation.**The litigation of disciplinary cases under Treasury Department Circular 230 is the responsibility of the Office of Associate Chief Counsel (GLS), performed primarily by attorneys in Area Counsel GLS offices. OPR refers these cases to GLS for litigation.


**39.4.1.3** **(04-11-2022)**

### Processing Litigation Cases by Area Counsel GLS

1. **Point of Contact**. Prior to OPR’s referral of a case to GLS for litigation, OPR will be the point of contact with the practitioner. After referral, GLS will have responsibility for all communication with the practitioner.

2. **Case Processing**. Once a case is referred to GLS for litigation, the assigned GLS attorney will process the case in accordance with the procedures set forth in Circular 230 and consistent with any applicable GLS case processing procedures and/or Memorandum of Understanding with OPR.

3. **Coordination**. Assigned GLS attorneys must discuss any novel, unclear, or sensitive issues, or any issue that may require a uniform approach, with their manager, and further action should be coordinated with GLS’s Claim, Labor and Personnel Law Branch (CLP). CLP will coordinate with PA on any issue that can be expected to impact a matter of tax administration.

4. **Technical Assistance**. When a GLS attorney requires tax law assistance in understanding the facts of, or developing positions concerning a case in litigation (or being considered for litigation) under Treasury Department Circular 230, the Office of Division Counsel, e.g., Small Business and Self Employed, will provide such assistance.


**39.4.1.3.1** **(04-11-2022)**

#### Summary Adjudication

1. After reviewing the evidentiary file and other information as appropriate, the GLS attorney will consider whether a Motion for Summary Adjudication to dispose of some or all of the issues in the case should be prepared and filed in accordance with 31 C.F.R § 10.68(a)(2). A decision not to file such a Motion, in any particular case, must be approved by the attorney’s supervisor.


**39.4.1.3.2** **(04-11-2022)**

#### Hearing Preparations

1. The GLS attorney will arrange a hearing date and place with the Administrative Law Judge (ALJ) and the practitioner’s representative (or practitioner, if appearing pro se). If an in-person hearing is scheduled, the GLS attorney is responsible for ensuring that a suitable hearing room is arranged for the hearing.


**39.4.1.3.3** **(04-11-2022)**

#### The Hearing

1. The Government has the burden of proof on all material allegations of the complaint. The GLS attorney will meet that burden by proving the allegations set forth in the complaint, in accordance with the standards of proof set forth in Circular 230. See 31 C.F.R. § 10.76(b).


**39.4.1.3.4** **(04-11-2022)**

#### Proposed Findings and Conclusions

1. After a hearing, the ALJ shall afford the parties a reasonable opportunity to submit proposed findings and conclusions of law. The ALJ will normally require proposed findings and conclusions to be filed after a set period after the receipt of the transcript. If any questions of law have been raised by the pleadings or at the hearing, the attorney will brief these issues. The GLS attorney will submit any reply briefs required by the ALJ.


**39.4.1.3.5** **(04-11-2022)**

#### Appeals to the Secretary

1. If an appeal is filed by the practitioner, the GLS office that handled the case will prepare briefs in opposition to the practitioner’s appeal.

2. If OPR determines that an adverse finding of fact or conclusion of law warrants the filing of an appeal, the assigned GLS attorney will prepare an appeal, a brief in support thereof, and any reply or supplemental briefs that are requested.

3. The GLS attorney will provide all appeals, briefs, and appeal responses to OPR, which will be responsible for serving the documents on the Appellate Authority. The GLS attorney will ensure that all pleadings are served on the practitioner and any practitioner representatives.

4. The GLS attorney is responsible for confirming that the necessary documentation for an appeal has been filed with the Appellate Authority delegated to decide appeals from decisions of ALJs under the Circular.


**39.4.1.3.6** **(04-11-2022)**

#### Closing the Case

1. At the conclusion of a case, GLS is responsible for ensuring that copies of the evidentiary file and all pleadings have been provided to OPR for OPR to maintain in its closed files as the official case file.


**39.4.1.4** **(08-11-2004)**

### Area Counsel Advice and Litigation Support

1. **Advice Unrelated to Imminent or Pending Litigation**. With respect to local matters and issues that arise with agency employees and components in their geographic area, Area Counsel attorneys will provide advice on the authorities specified in this section. These matters include actions under the rules of practice in Circular 230, the rules of limited practice in Rev. Proc. 2014-42, and, where issues under GLS jurisdiction are implicated, actions taken on electronic return originators and other electronic filing program participants. With respect to novel, unclear, or sensitive issues, Area Counsel will coordinate with the appropriate GLS branch.



### Note:



Area Counsel attorneys will, upon request, provide advice as to whether alleged facts constitute a violation of the rules of practice for which a practitioner can be disciplined. With respect to novel, unclear, or sensitive issues, or any issue that may require a uniform approach, Area Counsel will coordinate a response with CLP.

2. **Other Litigation Support**. With regard to matters under the enrollment provisions of Circular 230 or Rev. Proc. 2014-42, Area Counsel attorneys will provide litigation support to DOJ on cases filed in District Courts in their geographic areas. GLS generally does not lead in providing litigation support to DOJ regarding discipline in the e-file program. GLS will refer e-file cases to the appropriate Division Counsel office, but will provide assistance to Division Counsel on any GLS matter (e.g., e-file conduct rules drawn from or analogized from Circular 230).

3. For coordination requirements for matters involving tax administration or Circular 230-related guidance, see _CCDM 39.4.1.5.1_.


**39.4.1.5** **(05-18-2009)**

### Overview of Headquarters Branch Responsibilities

1. **Ethics and General Government Law Branch Responsibilities**. GLS’s Ethics and General Government Law Branch (EGG) provides advice to OPR and other Service personnel regarding practice before the IRS. Advice involving the interpretation of the regulations governing practice before the IRS (Circular 230) will be coordinated as specified in this section.

2. **Post-employment Practice Advice**. EGG is responsible for advice concerning post-employment practice by former Government employees, their partners, and their associates. Such advice includes but is not limited to advice on the Circular 230 isolation requirement for firms employing former officials of the Service and Counsel. See Exhibit 39.4.1-1, Model Isolation Statement for Firms Practicing Before the Service. Such advice would also include any issues arising under the Ethics in Government Act, or interpretation of provisions falling within 18 U.S.C. Part I, Ch. 11, or any issue affecting the duties of the Deputy Ethics Official responsibilities of the Associate Chief Counsel (GLS).

3. **Case Coordination**. GLS’s Claims, Labor and Personnel Branch (CLP) serves as the point of contact for coordination of OPR litigation.

4. **Litigation Support**. GLS will also support Department of Justice (DOJ) on appealed OPR cases not otherwise covered by Area Counsel.


**39.4.1.5.1** **(05-18-2009)**

#### Coordination on Practice Issues Affecting Tax Administration or Circular 230-Related Guidance

1. **Practice Issues Affecting Tax Administration**. EGG will coordinate any practice issues affecting matters of tax administration with the appropriate contact within the Office of Associate Chief Counsel, Procedure & Administration (P&A) or other affected function in the Office of Chief Counsel. For example, issues affecting the disclosure of tax return information under IRC § 6103 will be coordinated with P&A.

2. **Guidance**. P&A is responsible for published guidance, including regulations, related to Circular 230 and practice before the Internal Revenue Service. In drafting guidance related to Circular 230 and practice, when it can be expected that matters of interest to the Office of Associate Chief Counsel (GLS) are or will be involved, P&A will coordinate the guidance with the appropriate GLS branch. When advice or representation provided by GLS can be expected to impact a guidance project or create the need for a guidance project, the appropriate GLS branch will coordinate with P&A. In addition, when advice or representation provided by GLS involves a novel, unclear or sensitive issue that concerns matters of direct interest to P&A with respect to Circular 230 or related guidance, the appropriate GLS branch will coordinate the issue with P&A.


**39.4.1.6** **(04-11-2022)**

### Reference Materials

1. The statutes, regulations, official guidance, and other papers listed below are core reference materials for matters addressed by this section.



   - 31 U.S.C. § 330 (formerly 31 U.S.C. § 1026, 5 U.S.C. § 261, Act of July 7, 1884, ch. 334, § 3, 80 Stat. 378; the Treasury Practice statute)

   - 5 U.S.C. § 500 (the Agency Practice statute)

   - 29 U.S.C. §1242

   - 31 C.F.R. Part 10, Treasury Circular 230 (Cat. No. 16586R), as amended 79 Fed. Reg. 33685 (June 12, 2014)

   - 20 C.F.R. Part 901

   - Rev. Proc. 2014-42, (Annual Filing Season Program)

   - 26 C.F.R. Part 601, Subpart E Conference and Practice Requirements)

   - Rev. Proc. 68-29 (describing role of witnesses; superseded)

   - Form 2848, Power of Attorney and Declaration of Representative

   - Pub 947, Practice Before the IRS and Power of Attorney

   - Treasury Order No. 150-02

   - Treasury Order No. 107-04

   - General Counsel Order No. 9


**39.4.1.7** **(08-11-2004)**

### Cases Originating with the Joint Board for the Enrollment of Actuaries

1. **Composition of Joint Board**. The Joint Board for the Enrollment of Actuaries (Joint Board) is composed of five members — three appointed by the Secretary of the Treasury and two appointed by the Secretary of Labor. In addition, the Pension Benefit Guaranty Corporation has one representative with no voting power. The Executive Director of the Joint Board for the Enrollment of Actuaries is responsible for administering the enrolled actuary program and conducting disciplinary proceedings.

2. **Responsibilities of Joint Board**. Under 29 U.S.C. § 1242(a), the Joint Board is authorized to establish reasonable standards and qualifications for the enrollment of persons performing actuarial services with respect to the Employee Retirement Income Security Act of 1974 (ERISA). The Joint Board has adopted regulatory standards and qualifications for persons performing actuarial services covered by ERISA. The Joint Board enrolls individuals who satisfy such standards and qualifications.

3. **Disciplinary Action**. Under 29 U.S.C. § 1242(b), the Joint Board has disciplinary authority over enrolled individuals. The Joint Board may, after notice and an opportunity for a hearing, suspend or terminate the enrollment of an individual under this section if the Joint Board finds that such individual:



1. Has failed to discharge his duties under the Act, _or_

2. Does not satisfy the requirements for enrollment as in effect at the time of his enrollment


4. **Applicable Rules and Procedures**. Regulations governing the Joint Board’s enrollment and discipline of enrollees are published in 20 C.F.R. Part 901. The procedures for suspension and termination of enrolled actuary status resemble those in Circular 230.

5. **Litigation of Disciplinary Proceedings**. GLS litigates Joint Board disciplinary proceedings. These proceedings are comparatively rare. To the extent feasible, Joint Board disciplinary proceedings will be handled as if they were Circular 230 proceedings. Area Counsel will coordinate with CLP when a Joint Board case is submitted for litigation.

6. **Applicability of Circular 230**. Enrolled actuaries practicing before the Service are subject to Circular 230 as well as the Joint Board Regulations. Conduct leading to discipline under the Joint Board regulations is also likely to constitute grounds for discipline under Circular 230.

7. **Advice to Joint Board**. The Office of Chief Counsel may be asked to advise the Treasury representatives to the Joint Board. For example, in the past, the Ethics and General Government Law Branch has provided advice on general government law questions. Such advice will be coordinated with the Associate offices as necessary.


**39.4.1.8** **(04-11-2022)**

### Limited Practice by Tax Return Preparers

1. Rev. Proc. 2014-42, 2014 IRB 192, specifies the conditions under which an income tax return preparer who is not otherwise a practitioner has the privilege of limited practice. Rev. Proc. 81-38 also specifies the scope of such limited practice, and special rules that apply to those engaging in limited practice.

2. GLS Area Counsel will provide advice to Service personnel regarding the administration of Rev. Proc. 2014-42. With respect to novel, unclear, or sensitive issues, Area Counsel will coordinate a response with the appropriate GLS branch.

3. GLS will also support the Department of Justice (DOJ) when actions taken under Rev. Proc. 2014-42 are challenged in District Court.


**Exhibit 39.4.1-1**

### Model Isolation Statement for Firms Practicing Before the Service (personal and substantial participation)

| Director, Office of Professional Responsibility<br> Internal Revenue Service<br> 1111 Constitution Ave., N.W.<br> Washington, DC 20224 |
| --- |
|  |  |  |  |  |
|  | Re: | John Smith Private Letter Ruling<br> Offer in Compromise Frank Jones Estate<br> Smith and Jones Tax Shelter |
|  |  |  |  |  |
| Dear Sir: |
| This letter is to confirm that the above matters being handled by this firm are matters in which \_\_\_\_\_\_\_\_\_\_\_\_ participated personally and substantially during Government service. The firm will implement the following permanent screening measures, in accordance with section 10.25(c) of Treasury Department Circular No. 230, with respect to the above matters: |
|  | (1) no personnel of the firm or anyone acting on behalf of the firm will discuss these matters with \_\_\_\_\_\_\_\_\_\_\_\_ or in his/her presence; |
|  | (2) he/she will have no access to any files or documents concerning the above mattes; and |
|  | (3) no aid or assistance will be accepted from him/her directly or indirectly in these matters. |
|  |  |  | — _OPTIONAL PARAGRAPH_ — |
|  | In addition, in accordance with \[state Rule of Professional Conduct\], he/she will not share in any fees received by the firm with respect to these matters.1 |
| This statement will be retained by our firm and, upon request, provided to the office(s) of the Internal Revenue Service administering or enforcing Circular 230 Part 10.25 (c).<br> We declare under penalty of perjury that the foregoing is true and correct. Executed on (date). |
|  |  |  |  |  |
|  |  |  |  | \[Typed name of former employee\] \[under oath or affirmation\] |
|  | \\_\\_\\_\_\_\_\_\_\_\_\_\_\_\_ |  |
| \\_\\_\\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |
| 1 This **optional language** is not required under the Treasury practice regulations. it is included for the convenience of attorneys in jurisdiction in which rules of professional conduct prohibit the receipt of compensation directly related to the fee in the matter in which the attorney is disqualified. See Rule 1.11(a) of the ABA Model Rules of Professional Conduct and Comment (5) thereto. |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part39/irm_39-004-001#addtoany "Show all")

A2A