---
url: "https://www.irs.gov/irm/part1/irm_01-011-001"
title: "1.11.1 Internal Management Document (IMD) Program and Responsibilities | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-011-001#main-content)

- 1.11.1  [Internal Management Document (IMD) Program and Responsibilities](https://www.irs.gov/irm/part1/irm_01-011-001#id1)
  - 1.11.1.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-011-001#id2)
    - 1.11.1.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-011-001#id3)
    - 1.11.1.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-011-001#id4)
    - 1.11.1.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-011-001#id5)
    - 1.11.1.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-011-001#id6)
      - 1.11.1.1.4.1  [Program Controls](https://www.irs.gov/irm/part1/irm_01-011-001#id8)
    - 1.11.1.1.5  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-011-001#id9)
    - 1.11.1.1.6  [Related Resources](https://www.irs.gov/irm/part1/irm_01-011-001#id10)
  - 1.11.1.2  [Internal Management Documents (IMDs)](https://www.irs.gov/irm/part1/irm_01-011-001#id11)
    - 1.11.1.2.1  [Types of IMDs](https://www.irs.gov/irm/part1/irm_01-011-001#id13)
  - 1.11.1.3  [Instructions to Staff](https://www.irs.gov/irm/part1/irm_01-011-001#id14)
    - 1.11.1.3.1  [Transparency of Instructions to Staff](https://www.irs.gov/irm/part1/irm_01-011-001#id15)
      - 1.11.1.3.1.1  [Complying with E-FOIA](https://www.irs.gov/irm/part1/irm_01-011-001#id17)
      - 1.11.1.3.1.2  [E-FOIA Criteria for Instructions to Staff](https://www.irs.gov/irm/part1/irm_01-011-001#id18)
      - 1.11.1.3.1.3  [Disclosure Exemptions for Instructions to Staff](https://www.irs.gov/irm/part1/irm_01-011-001#id19)
  - 1.11.1.4  [IMD Approval](https://www.irs.gov/irm/part1/irm_01-011-001#id20)
  - 1.11.1.5  [IMD Numbering by Business Process](https://www.irs.gov/irm/part1/irm_01-011-001#id21)
    - 1.11.1.5.1  [Numbering IMDs](https://www.irs.gov/irm/part1/irm_01-011-001#id23)
  - 1.11.1.6  [IMD Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-011-001#id24)
    - 1.11.1.6.1  [IRS Business Unit Executives IMD Responsibilities](https://www.irs.gov/irm/part1/irm_01-011-001#id25)
    - 1.11.1.6.2  [SPDER IMD Program Management](https://www.irs.gov/irm/part1/irm_01-011-001#id26)
      - 1.11.1.6.2.1  [SPDER IMD Program Office](https://www.irs.gov/irm/part1/irm_01-011-001#id28)
    - 1.11.1.6.3  [M&P Offices of Publishing and Distribution](https://www.irs.gov/irm/part1/irm_01-011-001#id29)
    - 1.11.1.6.4  [IMD Oversight Council](https://www.irs.gov/irm/part1/irm_01-011-001#id30)
    - 1.11.1.6.5  [General Management Responsibilities](https://www.irs.gov/irm/part1/irm_01-011-001#id31)
    - 1.11.1.6.6  [Program Owners with IMD Oversight](https://www.irs.gov/irm/part1/irm_01-011-001#id32)
      - 1.11.1.6.6.1  [IMD Coordination](https://www.irs.gov/irm/part1/irm_01-011-001#id33)
        - 1.11.1.6.6.1.1  [IMD Coordinator](https://www.irs.gov/irm/part1/irm_01-011-001#id35)
        - 1.11.1.6.6.1.2  [IRM Coordinator](https://www.irs.gov/irm/part1/irm_01-011-001#id36)
        - 1.11.1.6.6.1.3  [IG Coordinator](https://www.irs.gov/irm/part1/irm_01-011-001#id37)
        - 1.11.1.6.6.1.4  [Policy Statement Coordinators](https://www.irs.gov/irm/part1/irm_01-011-001#id38)
        - 1.11.1.6.6.1.5  [Delegation Orders Coordinators](https://www.irs.gov/irm/part1/irm_01-011-001#id39)
    - 1.11.1.6.7  [IMD Authors](https://www.irs.gov/irm/part1/irm_01-011-001#id40)
  - Exhibit  1.11.1-1  [Glossary of Terms](https://www.irs.gov/irm/part1/irm_01-011-001#id41)
  - Exhibit  1.11.1-2  [IMD Websites](https://www.irs.gov/irm/part1/irm_01-011-001#id42)
  - Exhibit  1.11.1-3  [IMD Contacts and Resources](https://www.irs.gov/irm/part1/irm_01-011-001#id43)

# Part 1. Organization, Finance, and Management

# Chapter 11. Internal Management Documents System

# Section 1. Internal Management Document (IMD) Program and Responsibilities

* * *

## 1.11.1 Internal Management Document (IMD) Program and Responsibilities

#### Manual Transmittal

August 29, 2025

#### Purpose

(1) This transmits revised IRM 1.11.1, Internal Management Documents System, Internal Management Document (IMD) Program and Responsibilities.

#### Material Changes

(1) _IRM 1.11.1.1_, Program Scope and Objectives:

- Paragraph 2, added list items for “Delegation Orders (DO) coordinators” and “Policy Statement (PS) coordinator”, to identify all audience members.

- Paragraph 3, clarified policy owner as Director, Strategy and Business Solutions (SBS)- Research, Applied Analytics and Statistics (RAAS).

- Paragraph 4, clarified the program owner as the Office of Servicewide Policy, Directives and Electronic Resources (SPDER), within SBS-RAAS.


(2) _IRM 1.11.1.1.4_, Program Management and Review: changed description of “Annual Report on the Internal Management Documents (IMD) Program” to “Reports are issued to each head of office and each IMD coordinator. SPDER reviews each business unit’s IMD program activity, identifies any risks from non-compliance and makes recommendations for improvement”. The change in definition was made to reflect the current process of annual reporting.

(3) _IRM 1.11.1.2.1_, Types of IMDs, paragraph 1:

- Removed from table, “Operating Level Directives”, as these directives are now issued through memorandum.

- Removed from table, “Policy statements and delegation orders are often used in the IRM.”, as this description is provided within the table.

- Removed from table, “are official IRS statements of IRS values, objectives, and/or IRS principles.”, as definition has been updated.

- Added to table, “are official IRS statements of IRS values, objectives, and/or IRS principles.”, the new definition of Policy Statements.

- Added to table, “also referred to as Delegations of Authority,” to provide clarity on additional terms used to describe servicewide delegation orders.

- Updated Division/Function Delegation Orders to “Business Unit Delegation Orders” and updated its corresponding definition.


(4) _IRM 1.11.1.3_, Instructions to Staff, paragraph 3; added, This includes any supplemental or local guidance posted on the Knowledge Management or SERP platforms.

(5) _IRM 1.11.1.3.1_, Transparency of Instructions to Staff, paragraph 1; added, The IRS takes a proactive disclosure approach to FOIA by making most IMDs available for public viewing.

(6) _IRM 1.11.1.4_, IMD Approval, updated “Division/Function” to “Business Unit”, and updated its corresponding definition to reflect the current title and approval authority.

(7) _IRM 1.11.1.5_, IMD Numbering by Business Process: paragraph 1, Table row 10 within the Business Process Number column, changed business process category title from “Security, Privacy and Assurance” to “Security, Privacy, Assurance and Artificial Intelligence”. Updated adjacent Description of Content to include “Artificial Intelligence” term.

(8) _IRM 1.11.1.5.1_, Numbering IMDs: paragraph 1:

- Updated IMD Type “Division Delegation Orders” to “Business Unit Delegation Orders”, and updated the corresponding Example Number and Title.

- Updated the Example Number and Title for the IMD Type “IG”.


(9) _IRM 1.11.1.6_, IMD Roles and Responsibilities, paragraph 1:

- Added list item for “Delegation Orders (DO) coordinators”.

- Added list item for “Policy Statement (PS) coordinators”.


(10) _IRM 1.11.1.6.2.1_, SPDER IMD Program Office:

- Added to paragraph 1, list item to describe SPDERs training oversight within the IMD program: “Conducting training to authors on authoring, clearing and publishing IMDs”.

- Added to paragraph 1, list item to describe SPDERs role in building and maintaining an online version of the IRM: “Building and administering the IRM Online, an electronic resource for the IRM”.

- Added to paragraph 1, list item to describe SPDERs training oversight for the IRM Online: “Conducting training for on the IRM Online, its purpose, use and features.”

- Modified paragraph 1, list item “i” to clarify that SPDER submits requests for FOIA documents to be posted to the FOIA library on IRS.gov.

- Added to paragraph 2, list item “e”, the term “rescinded” as an options for document management.


(11) _IRM 1.11.1.6.3_, M&P Offices of Publishing and Distribution: paragraph 1, added “including the IRM” to specify the product being distributed.

(12) _IRM 1.11.1.6.5_, General Management Responsibility: paragraph 3, inserted “comments or” to clarify the type of responses subject to managers review.

(13) _IRM 1.11.1.6.6_, Program Owners with IMD Oversight:

- Paragraph 2, list item “a”, added “delegation order and policy statement” to define all documents IRS program offices administer.

- Paragraph 3, list item “e”, added “Refer to IRM Author Curriculum for recommendations.” with supporting link to IRM author curriculum web page to authoring resources.


(14) _IRM 1.11.1.6.6.1.1_, IMD Coordinator, paragraph 3, updated title of IRM 1.11.9 to Clearing and Approving the Internal Revenue Manual (IRM).

(15) _IRM 1.11.1.6.6.1.4_, Policy Statement Coordinators, added subsection to describe the responsibilities for policy statement coordinators.

(16) _IRM 1.11.1.6.6.1.5_, Delegation Orders Coordinators, added subsection to describe the responsibilities for delegation order coordinators.

(17) _IRM 1.11.1.6.7_, IMD Authors:

- Paragraph 1; table, Updated title of IRM 1.11.9 to “Clearing and Approving the Internal Revenue Manual (IRM)”.

- Paragraph 2; list item “c”, changed to “Refer to IRM Author Curriculum for the complete listing of recommended training courses”.

- Paragraph 3; list item “b”, added “by following IRM 1.11.2.5.3, Designate IRM Content as Official Use Only (OUO).”, to clarify instructions on how to properly mark OUO content.

- Paragraph 3; list item “c”, changed 7.1 to 8.1, representing the version of Arbortext software.

- Paragraph 4; changed “IMD” to “IRM”, to clarify that the section only applies to IRMs.

- Paragraph 4; list item “a”, Updated title of IRM 1.11.9 to “Clearing and Approving the Internal Revenue Manual (IRM)”.

- Paragraph 4; list item “c”, Updated “IMD clearance” to “IMD electronic clearance”, with hyperlink to the online application.


(18) _Exhibit 1.11.1-1_, Glossary of Terms:

- Changed “W&I” to “Taxpayer Services”, due to business unit name change.

- Added “Policy Owner” to terms column, and included the definition: “The program office responsible for the policy/policies published in this IRM section; normally the executive of the operation.”

- Changed description of “Program Owner” to “The program office that typically reports to the policy owner and is responsible for the administration, procedures and updates related to the program.”

- Updated definition of “Internal Controls” reference from “IRM 1.4.2.4.2, Determine Existing Controls” to “IRM 1.4.2.4, Control Activities”.


(19) Editorial changes made for clarity throughout:

- reviewed and updated grammar,

- email addresses,

- website links,

- plain language,

- position titles “Commissioner” and “Deputy Commissioner” became “IRS Commissioner” and “IRS Deputy Commissioner”,

- the term “See” was replaced with “Refer to”,

- passive voice phrasing changed to active voice phrasing,

- the term “his” was replaced with “their”,

- IRM references,

- business unit titles.


#### Effect on Other Documents

IRM 1.11.1 dated October 07, 2022, is superseded.

#### Audience

All personnel responsible for IMDs including IRS executives, managers, IMD coordinators, IRM coordinators, interim guidance (IG) coordinators, authors, and reviewers in all business units.

#### Effective Date

(08-29-2025)

Holly A. Donnelly

Director, Strategy and Business Solutions (SBS)

Research, Applied Analytics and Statistics (RAAS)

**1.11.1.1** **(08-29-2025)**

### Program Scope and Objectives

1. **Purpose.** This Internal Revenue Manual (IRM) section provides an overview of internal management documents (IMDs) and the IMD process. Specifically, IRM 1.11.1:



1. Defines IMDs, authorities and legal obligations relating to IMD.

2. Identifies IMD roles and responsibilities for IMD management.

3. Provides requirements and guidance for IMD management.

4. Includes a glossary of common IMD terms.

5. Lists IMD resources.


2. **Audience.** The audience for this IRM section includes:



   - IRS business unit executives and managers.

   - IRS management officials.

   - IMD originators/authors.

   - IMD/IRM coordinators.

   - Interim guidance (IG) coordinators.

   - Delegation order (DO) coordinators.

   - Policy statement (PS) coordinators.

   - Other personnel responsible for the administration of the IMD program.


3. **Policy Owner.** Director, Strategy and Business Solutions (SBS)- Research, Applied Analytics and Statistics (RAAS).

4. **Program Owner.** The Office of Servicewide Policy, Directives and Electronic Resources (SPDER) within SBS-RAAS oversees and manages the IMD process.

5. **Primary Stakeholders.** All business units are stakeholders regarding IMDs.

6. **Program Goals.** The goal of this program is to provide the business units with the foundation and structure needed to create and manage IMDs. The policies and processes in this IRM provide consistency throughout the IRS.

7. This IRM section is authored by the SPDER office. For more information, contact us:



   - E-mail at \*SPDER.

   - Website at IMD Community Home (click on "Contact Us/Staff" ).


**1.11.1.1.1** **(10-07-2022)**

#### Background

1. The IRS Restructuring and Reform Act of 1998 resulted in a complete restructuring and reformatting of the IRM to align with IRS business processes. One of the primary goals of IRS modernization was to restore and maintain the IRM as the single, official compilation of IRS policies, procedures, and guidelines. The IRM is the primary source of instructions to staff.

2. In 1999, the IRS formed the Office of Servicewide Policy, Directives and Electronic Resources (SPDER), formerly Servicewide Policy, Directives and Electronic Research. SPDER is responsible for designing, implementing, and monitoring a strategic approach to managing and setting Servicewide policy for IMDs.


**1.11.1.1.2** **(10-07-2022)**

#### Authority

1. The Commissioner of Internal Revenue (CIR) has authority under IRC 7803(a)(2)(A) and Treasury Order 150-10 to administer and enforce the Internal Revenue laws. The CIR provides subordinates certain authorities to act on their behalf by issuing delegations of authority. IRS executive chiefs and directors with the authority and responsibility for a program issue IMDs to administer and enforce the Internal Revenue laws.



### Note:



Throughout this IRM, the term "the Commissioner" refers to the CIR. The term "Deputy Commissioner" refers to the deputy of the (CIR).

2. Several laws define requirements pertaining to the issuance of IMDs. For example, federal agencies are required to document, publish, and maintain records of policies, authorities, procedures, and organizational operations. The table below identifies certain legal obligations:




| **Authorities** | **Obligations Relating to IMD** |
| :-: | :-: |
| Regulations prescribed by the Federal Records Act and the National Archives and Records Administration (36 CFR 1222). | Requires that programs, policies, and procedures of the agency are adequately documented (36 CFR 1222.22). |
| 44 USC 3101, Records Management by Federal Agencies:<br>[44 USC 3101](https://www.archives.gov/about/laws/fed-agencies.html) | Requires agencies to make and preserve records documenting organizational structure, functions, policies, decisions, procedures and essential transactions of the agency. |
| Freedom of Information Act (5 USC 552(a)(2)(C)):<br>[The Freedom of Information Act (FOIA)](https://www.justice.gov/oip/blog/foia-update-freedom-information-act-5-usc-sect-552-amended-public-law-no-104-231-110-stat) | Requires agencies to make available for public inspection (in accordance with published rules), in an electronic format (E-FOIA), administrative staff manuals and instructions to staff that affect a member of the public. Known as FOIA. |
| Federal Register Act (44 USC 1505):<br>[Federal Register and the Code of Federal Regulations](https://www.archives.gov/about/laws/cfr.html) | Section 1505(a) requires publication of three categories of documents in the Federal Register:<br> <br>   - (1) Proclamations and executive orders;<br>     <br>   - (2) Documents having general applicability and legal effect;<br>     <br>   - (3) Documents required to be published by Congress.<br>     <br> Section 1505(b) requires publication of documents authorized to be published by regulations, excluding comments and news items.<br> <br>### Example:<br>The Administrative Procedure Act (APA) (5 USC 553(b)) generally requires that the notice of proposed rule making for substantive rules be published in the Federal Register. Regulations covered by this requirement are commonly referred to as legislative regulations. |
| Open Government Directive M10-06 from the Office of Management and Budget:<br>[Open Government Directive](https://obamawhitehouse.archives.gov/open/documents/open-government-directive) | Directs executive departments and agencies to take specific actions to implement the principles of transparency, participation and collaboration set forth in the memorandum. The Attorney General's Memorandum on the Freedom of Information Act (FOIA) also underscores the government's commitment to transparency in government.<br>[The Freedom of Information Act (FOIA), memorandum for heads of executive departments and agencies](https://www.justice.gov/sites/default/files/ag/legacy/2009/06/24/foia-memo-march2009.pdf) |
| Restructuring and Reform Act of 1998, Public Law 105-206 (RRA 98 1203(b) violations):<br>[Internal Revenue Service Restructuring and Reform Act of 1998](https://www.govinfo.gov/app/details/PLAW-105publ206) | If employees do not follow policies or published administrative guidance (including the IRM) for the purposes of retaliating against or harassing a taxpayer, taxpayer representative, or other IRS employee adverse action could result. |

3. The IRM works as the foundation for fulfilling the legal obligations set forth in 5 USC 552(a)(2)(c), 44 USC 3101 and 36 CFR 1222 and is an essential component for tax administration and enterprise risk management.


**1.11.1.1.3** **(10-07-2022)**

#### Roles and Responsibilities

1. The following table lists the executives and their responsibilities for the IMD process:




| **Program Owners and Directors** | **Responsible for** |
| :-- | :-- |
| Director of Strategy and Business Solutions (SBS), RAAS | Program Manager for SPDER. |
| Director of SPDER | Oversight responsibility for the IMD program of the IRS |
| Program owners in each IRS business unit | Preparing, maintaining, and archiving IMDs affecting their respective programs. |
| Director, Media and Publications (M&P) | - Composing reviews involving numbering, formatting and processing the IRM for publication.<br>     <br>   - Planning, developing, coordinating, administering and evaluating the policies, systems, procedures and standards to meet IRS publishing needs.<br>     <br>   - Refer to IRM 1.11.5, Publishing the Internal Revenue Manual (IRM). |

2. Refer to _IRM 1.11.1.6.2_, SPDER IMD Program Management, for more information about program owner responsibilities.


**1.11.1.1.4** **(08-29-2025)**

#### Program Management and Review

1. SPDER manages the IMD program through the following reviews and reports:



   - **Annual Report on the Internal Management Documents (IMD) Program** \- Reports are issued to each head of office and each IMD coordinator. SPDER reviews each business unit’s IMD program activity, identifies any risks from non-compliance and makes recommendations for improvement.

   - **Annual IMD Program Assessment** \- An addendum to the above memorandum, this report provides the status Servicewide of the actions taken by each business unit on the identified areas of risk to the IMD program. SPDER shares a report for each business unit with the IMD executive and IMD coordinator and staff.


Refer to _IRM 1.11.1.6.2_, SPDER IMD Program Management, for more information about program owner responsibilities.



**1.11.1.1.4.1** **(10-07-2022)**

##### Program Controls

1. **IMD Certification** \- SPDER annually requests the heads of office certify the current status of their IRM, Servicewide delegation orders, policy statement content, IRM management and internal controls. SPDER compiles the results into a report for senior executives, managers, IMD coordinators, and staff. The report supports and improves IMD program management.


**1.11.1.1.5** **(10-07-2022)**

#### Terms and Acronyms

1. _Exhibit 1.11.1-1_, Glossary of Terms, contains a table of terms and definitions.


**1.11.1.1.6** **(10-05-2017)**

#### Related Resources

1. _Exhibit 1.11.1-2_, IMD Websites, contains IMD-related websites. _Exhibit 1.11.1-3_, IMD Contacts and Resources, contains additional IMD contacts and resources.


**1.11.1.2** **(09-04-2009)**

### Internal Management Documents (IMDs)

1. IMDs are official communications that designate authorities and/or provide instructions to staff for IRS officials and employees.



### Note:



The terms directives, internal directives, and instructions to staff are used interchangeably to describe IMDs.

2. IMDs are based on the following sources:




| **Primary Source** | **Includes** |
| --- | --- |
| Legal authorities | - Laws<br>     <br>   - Regulations<br>     <br>   - Court cases |
| Administrative guidance | - Notices and announcements<br>     <br>   - Revenue rulings<br>     <br>   - Revenue procedures |
| Business unit operations | - Policy statements<br>     <br>   - Delegations of authority<br>     <br>   - Functional statements |


**1.11.1.2.1** **(08-29-2025)**

#### Types of IMDs

1. The table includes types of IMDs, descriptions of their purpose, and related IRM sections that provide guidance on authoring and issuance.




| **Type of IMD** | **Description** | **Related IRM Section(s)** |
| :-- | :-- | :-- |
| Internal Revenue Manual (IRM) | The IRM serves as the single official source of **instructions to staff.**<br>   - It is based on and includes policies, delegated authorities, procedures, instructions, and guidelines relating to the organization, functions, administration, and operations of the IRS. | - IRM 1.11.2, Internal Revenue Manual (IRM) Process, describes the process for authoring and maintaining the IRM.<br>     <br>   - IRM 1.11.6, Using and Researching the Internal Revenue Manual (IRM), describes how to use and locate information in the IRM. |
| Servicewide Delegation Orders (DO) | Servicewide delegation orders, also referred to as Delegations of Authority, are specific delegations of authority issued by the Commissioner of Internal Revenue, or on their behalf by the Deputy Commissioner, to subordinate officials, with or without restrictions. | - IRM 1.11.4, Servicewide Delegation Order Process, describes the process of creating, revising, and revoking DOs.<br>     <br>   - Published Servicewide DOs are located in IRM 1.2.2, Servicewide Delegations of Authority. |
| Business unit Delegation Orders | A business unit delegation order is derived from a Servicewide delegation order. This delegation of authority is issued by the individuals granted authority by the Servicewide delegation order, to their subordinate officers or employees where the authority has been granted to the senior executive through a Servicewide delegation order. | - IRM 1.11.4, Servicewide Delegation Orders are the basis for business unit delegation orders.<br>     <br>   - Business unit delegation orders are published in the IRM 1.2.6X series. |
| Policy Statements (PS) | Policy statements are official IRS statements of IRS values, objectives, and/or IRS principles.<br> <br>1. They are authorized by the IRS Commissioner or IRS Deputy Commissioner<br>      <br>2. These statements can form the basis for procedures and instructions in the IRM. | - IRM 1.11.3, Servicewide Policy Statement Process, contains instructions on preparing, clearing, and publishing policy statements.<br>     <br>   - Published policy statements are located in IRM 1.2.1, Servicewide Policy Statements. |
| Interim Guidance (IG) | An official communication conveyed through memoranda or IRM procedural updates (IPUs) used by business units or program offices to convey immediate, emergency or temporary changes to operations or procedures for a defined effective period. | - IRM 1.11.10, Interim Guidance Process, describes IG standards and processing procedures.<br>     <br>   - IRM 1.11.8, Servicewide Electronic Research Program (SERP), describes IPU standards and processing procedures. |
| Operating Level Directives | These directives are instructions to staff issued by head of office executives. Examples include:<br> <br>   - Business unit delegation orders<br>     <br>   - Business unit operating policies | None |


**1.11.1.3** **(08-29-2025)**

### Instructions to Staff

1. The IRS designates the IRM as the single, official compilation of IRS policies, procedures, and guidelines. Program offices must place instructions to staff in the IRM, which employees use to carry out their responsibilities in administering tax laws, performing duties, and executing IRS operations. Refer to _IRM 1.11.1.2 (2)_, Internal Management Documents, for those sources.

2. IRS program offices must use interim guidance (IG), as defined in IRM 1.11.10, Interim Guidance Process, to convey new, changed, pilot and temporary procedure, or a deviation from procedure, to employees in situations where there is insufficient time to update and publish the IRM. Refer to IRM 1.11.2.2, IRM Standards.

3. IRS program offices can issue supplemental or local forms of guidance. Program offices are responsible for ensuring that all primary instructions to staff, related to supplemental or local guidance, are contained in the IRM. This includes any supplemental or local guidance posted on the Knowledge Management or SERP platforms. Refer to IRM 1.11.2.2.1, Supplemental Guidance.


**1.11.1.3.1** **(08-29-2025)**

#### Transparency of Instructions to Staff

1. The Freedom of Information Act (FOIA), 5 USC 552, provides public access to agency records unless protected from disclosure by an exemption under 5 USC 552(b). The IRS takes a proactive disclosure approach to FOIA by making most IMDs available for public viewing. FOIA, 5 USC 552(a)(2)(C) requires "administrative staff manuals and instructions to staff that affect a member of the public" be available to the public. FOIA, as amended in 1996, requires disclosure to the public in an electronic form and is known as the Electronic Freedom of Information Act (E-FOIA).

2. The IRS maintains the FOIA Library web page on [IRS.gov](https://www.irs.gov/). Administrative staff manuals and instructions to staff, such as the IRM, are posted to the [FOIA Library](https://www.irs.gov/privacy-disclosure/foia-library).



### Note:



Content marked official use only (OUO) is redacted prior to posting to the FOIA Library, as it is exempt from public disclosure under 5 USC 552(b). Refer to IRM 11.3.12.2.2, Official Use Only (OUO) Decision Tool for guidance on content that is marked OUO

3. Business units that issue instructions to staff outside of the IRM, such as IG, are responsible for identifying content that meet the conditions under FOIA and posting documents on the FOIA Library. Refer to _IRM 1.11.1.3.1.1_, Complying with E-FOIA, and _IRM 1.11.1.3.1.2_, E-FOIA Criteria, for Instructions to Staff.


**1.11.1.3.1.1** **(04-24-2014)**

##### Complying with E-FOIA

1. Media and Publications automatically posts the published IRM to the [FOIA Library](https://www.irs.gov/privacy-disclosure/foia-library) on IRS.gov. Content exempt from public disclosure under 5 USC 552(b), which is marked as OUO, is redacted prior to posting to the FOIA Library.

2. SPDER posts recently issued policy statements and Servicewide delegation orders to the FOIA Library on IRS.gov.

3. The program owner is responsible for ensuring that all other instructions to staff that meet E-FOIA criteria, including interim guidance memoranda and SERP IPUs, are timely uploaded to the IMD Tracking System for posting to the FOIA Library.

4. Refer to IRM 1.11.10.7, Distribute Interim Guidance, for specific actions that must be taken to comply and ensure instructions to staff meeting E-FOIA are posted to the FOIA Library.

5. A web-based E-FOIA Decision Tool is available on the Internal Management Documents Community site to assist users in determining whether guidance meets E-FOIA criteria and requires posting on the FOIA Library on IRS.gov.

6. Consult a disclosure advisor when uncertain if E-FOIA applies. Disclosure contacts are found at the Disclosure and Privacy Knowledge Base.


**1.11.1.3.1.2** **(04-24-2014)**

##### E-FOIA Criteria for Instructions to Staff

1. For IMDs to meet 5 USC 552(a)(2)(C) for disclosure to the public and posting to the FOIA Library on IRS.gov, the guidance must meet the following conditions:



1. Be procedural and communicate directions, guidelines, or standards to employees in the performance of their assigned duties,

2. Affect how a member of the public files, pays, complies with their tax requirements, or interacts with the IRS, and

3. Not be exempt from disclosure under 5 USC 552(b). Refer to _IRM 1.11.1.3.1.3_, Disclosure Exemptions for Instructions to Staff.


2. If the document restates procedures already available in full on the [FOIA Library](https://www.irs.gov/privacy-disclosure/foia-library), then it is not necessary to post the document.


**1.11.1.3.1.3** **(10-07-2022)**

##### Disclosure Exemptions for Instructions to Staff

1. Instructions to staff that affect a member of the public must be made public unless the information is exempt under 5 USC 552(b). IRM 11.3.13.5.2, Exemptions, lists the nine FOIA exemptions. Generally, only 5 USC 552(b)(7)(E) applies to instructions to staff. 5 USC 552(b)(7)(E) exempts content, which if disclosed could reasonably be expected to risk circumvention of the law by a member of the public. This content is designated by the IRS as official use only (OUO) and does not require disclosure.

2. If IMDs contain OUO information and non-OUO information, the OUO information is redacted (removed); the remaining non-OUO content is accessible to the public. Refer to IRM 11.3.12.2.1, Official Use Only.



### Note:



The author must properly mark OUO content, which is reviewed by the Office of Disclosure and approved by the official as outlined in Delegation Order 11-1, Administrative Control of Documents and Material found in IRM 1.2.2, Servicewide Delegations of Authority.


**1.11.1.4** **(10-07-2022)**

### IMD Approval

1. The table below lists IMD approval authorities and circumstances that permit re-delegation. Any delegation for approval authority must be in writing and kept by the delegating office. Refer to IRM 1.2.2, Servicewide Delegations of Authority for Delegation Order 1-69, Authorization to Approve an Internal Management Document (IMD).



### Caution:



When an IRM author changes an OUO designation or adds new OUO information, the individual authorized by Delegation Order 11-1 must approve that IRM. Refer to IRM 1.2.2, Servicewide Delegations of Authority for Delegation Order 11-1, Administrative Control of Documents and Material.

2. The table below lists the approval level for each IMD.




| _IMD Type_ | _Issuance Type_ | _OUO Designation_ | _Approval Level_ | _Redelegation Authority_ |
| :-: | :-: | :-: | :-: | :-: |
| - IRM<br>     <br>   - IG (IGM or SERP IPU)<br>     <br>   - Operating level directive | New or Revised | _With_ newly designated<br>_OR_<br> changed OUO content | An official as designated in Delegation Order 11-1, Administrative Control of Documents and Material, paragraph three (3)<br>_AND_<br> has program oversight of the IMD content | Not allowed per DO 11-1 and DO 1-69 |
| - IRM<br>     <br>   - Interim Guidance<br>     <br>   - Operating level directive | Revised | _De-designated_ OUO content | An official as designated in Delegation Order 11-1 paragraph six (6)<br>_AND_<br> has program oversight of the IMD content | Not allowed per DO 11-1 and DO 1-69 |
| - IRM<br>     <br>   - Interim Guidance<br>     <br>   - Operating level directive | New, Revised or Obsolesced | _Without_ newly designated<br>_OR_<br> changed OUO content | A member of the Senior Executive Service with program oversight of the IMD content | In writing to a supervisory manager with program oversight of the IMD content, per DO 1-69 |
| Servicewide Delegation Order | New, Revised, Rescinded or Obsolesced | NA | The IRS Commissioner or IRS Deputy Commissioner | Not allowed per DO 1-69 |
| Business Unit Delegation Order | New, Revised, Rescinded or Obsolesced | NA | The responsible business unit senior executive and National Taxpayer Advocate, reporting to the IRS Commissioner or IRS Deputy Commissioner | Not allowed per DO 1-69 |
| Servicewide Policy Statement | New, Revised, Rescinded or Obsolesced | NA | The IRS Commissioner or IRS Deputy Commissioner | Not allowed per DO 1-69 |


**1.11.1.5** **(08-29-2025)**

### IMD Numbering by Business Process

1. IRS business processes are categorized by a unique number for identifying the related IMD. The table below names and describes the IMD business processes. Each category is assigned a business process number.




| **Business Process Number** | **Business Process Category** | **Description of Content** |
| :-: | :-: | :-: |
| 1 | Organization, Finance, and Management | Strategic planning, budgeting, Servicewide policies, delegations of authority, and functional statements. |
| 2 | Information Technology | Development, implementation, and maintenance of IRS information systems. |
| 3 | Submission Processing | Processing of paper returns, electronic submissions, tax payments, and refunds. |
| 4 | Examining Process | Activities related to conducting examinations of small business, self-employed, large case, employee plans, exempt organizations, and government entities. |
| 5 | Collecting Process | Activities related to collecting delinquent taxes and securing delinquent tax returns. |
| 6 | Human Resources Management | Policies, guidelines, and procedures related to workforce issues such as training, hiring, personnel matters, labor relations, etc. |
| 7 | Rulings and Agreements | Pre-filing agreements, private letter rulings, technical advice, determination letters, and compliance programs. |
| 8 | Appeals | Administrative appeals processes involving taxpayers’ disputes with the IRS. |
| 9 | Criminal Investigation | Criminal violations of the Internal Revenue Code and related financial crimes. |
| 10 | Security, Privacy, Assurance and Artificial Intelligence | All security, safeguard, assurances, privacy information, and artificial intelligence. |
| 11 | Disclosure, Communications, and Liaison | Internal and external communications, governmental liaison and disclosure, legislative affairs, and public liaison activities. |
| 13 | Taxpayer Advocate Service | Processes and activities that assist taxpayers who encounter problems not resolved through normal IRS systemic and/or business processes. |
| 20 | Penalty and Interest | Assessment and abatement of penalties and interest. |
| 21 | Customer Account Services | Customer technical and account inquiries received via telephone, e-mail, other written correspondence, and walk-in service. |
| 22 | Taxpayer Education and Assistance | Processes and activities associated with customer outreach in the business units. |
| 25 | Special Topics | Processes and procedures that apply to and are used by employees of more than one business unit. |
| 30–39 | Chief Counsel Directives Manual (CCDM) | Processes and activities associated with the Office of the Chief Counsel. |


**1.11.1.5.1** **(08-29-2025)**

#### Numbering IMDs

1. The numbering structure identified above applies to certain IMDs. The table below identifies and describes the numbering schema for each type of IMD with an example.



### Note:



In these examples, each document belongs to the organization, finance, and management process, business process number 1. The location of '1' in the Example Number reflects where the business process number is found for each type of IMD.






| **IMD Type** | **Example Number** | **Title** |
| :-: | :-: | :-: |
| IRM | **1**.32.14 | Gainsharing Travel Savings Program |
| Delegation Order | DO-**1**-30 | Authorization and Approval of Official Travel within the United States |
| Policy Statement | P-**1**-48 | Reimbursement of Travel Expenses is Authorized for a Guest Attending an Awards Ceremony |
| Business Unit Delegation Orders | CFO **1**-2-1 | Order of Succession and Designation to Act as Chief Financial Officer |
| IG | RAAS-**01**-0122-0011 | Interim Guidance on Verifying IRS Toll-Free Phone Numbers |


**1.11.1.6** **(10-07-2022)**

### IMD Roles and Responsibilities

1. All business units share responsibility for managing IMDs. The information below describes the roles and responsibilities of:



   - IRS business unit executives

   - SPDER

   - M&P Offices of Publishing and Distribution

   - IMD Oversight Council

   - General management responsibilities

   - Program owners with IMD oversight

   - IMD coordinators

   - IRM coordinators

   - Delegation Orders (DO) coordinators

   - Policy Statement (PS) coordinators

   - IG coordinators

   - IRM authors


**1.11.1.6.1** **(10-05-2017)**

#### IRS Business Unit Executives IMD Responsibilities

1. Business unit executives are responsible for the content and management of IMDs affecting their programs. Executives are expected to establish an effective process to manage their IRM material and other instructions to staff. They must ensure that policies, authorities, procedures, and organizational operations for their business unit are documented and published per legal requirements. Refer to _IRM 1.11.1.1.2_, Authority, for legal authorities.

2. Executives must establish clear expectations to subordinate offices and empower their IMD staff. These expectations must promote:



1. Successful overall management of instructions to staff.

2. Employees’ ability to find critical information.

3. Adherence to IRM Chapter 1.11 requirements.

4. Mitigation of potential risks in the IMD program.

5. Internal control for programs.


3. To establish an effective IMD program:



1. Appoint an IMD coordinator who has the authority to manage the process on the leader's behalf.

2. Establish a network of employees to support the IMD coordinator within the embedded functions.

3. Develop and implement procedures and measures to ensure that IMDs are timely updated to reflect current operations, policies, procedures, and guidance.

4. Establish internal controls to make certain that IMDs are received and followed by appropriate personnel.

5. Ensure employees with IMD responsibilities are trained to perform their duties.


**1.11.1.6.2** **(08-29-2025)**

#### SPDER IMD Program Management

1. SPDER sets the policy for and oversees the IRS IMD process relating to the IRM, policy statements, delegation orders, and IG. SPDER’s IMD program responsibilities are:



1. Communicating policies, procedures, and information regarding the IMD process.

2. Serving as principal advisor to IRS personnel on IMD issues.

3. Leading the IMD Oversight Council and establishing other cross functional councils or steering committees to work on issues related to IMDs.

4. Coordinating with all business units to resolve IMD issues.

5. Participating in decisions related to publishing IMD materials.


2. SPDER manages online resources for the IMD community as described in the following table.




| **Description** | **Website Address** |
| --- | --- |
| **IMD Community of Practice site** \- provides information on current projects, special topics, and resource material | IMD Community of Practice |
| _IMD Electronic Clearance Tool_\- A SharePoint based system that streamlines the clearance, approval and archiving processes. | IMD Electronic Clearance |
| **IMD Tracking System** – A restricted database used by business unit IG coordinators to post and remove IGM and IPUs to and from the Search Interim Guidance page and if required to the FOIA library on IRS.gov. | IMD Tracking System |
| **IRM Online** – provides the IRM on a searchable database | IRM Online |
| **ReferenceNet** – provides Servicewide legal and tax research services to staff | Reference Net |
| _Search Interim Guidance Page_ \- A webpage that contains active IGMs, IPU, Servicewide DOs and PSs, | Search Interim Guidance |
| **SPDER IMD Community Site** – provides resource material to the IMD community | IMD Community Home |
| **VILLA (Virtual IMD Learning Library Application)** – provides short training modules about the IMD process as technical support for the IMD community | Virtual IMD Learning Library Application |
| **IMD Data and Quarterly Reports** | IMD Data |

3. Each year, SPDER conducts a review of the IMD process to assess the overall state of the IRM and other instructions to staff. SPDER shares the findings from these annual reviews with IRS leaders and the IMD community to recognize achievements and mitigate potential risks in the IMD program. SPDER posts the annual report on the IMD Program Reports SharePoint site IMD Program Reports.

4. Each year, SPDER facilitates the certification of every IRM section, Servicewide delegation order, and policy statement as “current as published,” “current with IG/IPU,” “in clearance,” or “not current,” and produces a report based on the findings. Refer to IRM 1.11.2.1.5, Program Controls.


**1.11.1.6.2.1** **(08-29-2025)**

##### SPDER IMD Program Office

1. The SPDER IMD program office is responsible for IMD process management. The SPDER IMD program office monitors and strives to enhance the IMD process relating to the IRM, policy statements, delegation orders, and IG by:



1. Establishing requirements and policy for the IMD process.

2. Identifying and implementing business process improvements for the IMD process.

3. Conducting training to authors on authoring, clearing and publishing IMDs.

4. Providing oversight through reviews and analysis of the IRM, at least annually.

5. Building and maintaining the IRM Online, an electronic resource for the IRM.

6. Conducting training for the IRM Online, its purpose, use and features.

7. Evaluating compliance with FOIA requirements.

8. Forwarding to OLS recently issued policy statements and Servicewide delegation orders for posting to the FOIA Library on IRS.gov.

9. Submitting to OLS recently issued IG meeting FOIA requirements for posting to the FOIA Library on IRS.gov.


2. Members of the SPDER IMD program office provide coordination, guidance, assistance, and training to all business units. They ensure conformance with IMD procedures by:



1. Developing and communicating uniform instructions and procedures related to the IMD process.

2. Maintaining current IMD process and procedures in the IRM.

3. Providing guidance and training to IMD/IRM coordinators, authors, and management officials.

4. Providing IRM Authoring software training.

5. Initiating or providing substantive review, evaluation, and coordination of new, revised, and rescinded policy statements and delegation orders prepared for the approval and signature of the IRS Commissioner and IRS Deputy Commissioner.

6. Providing virtual workshops and other forms of training when needed.


3. A listing of SPDER points of contact can be found on the IMD Contacts Listing.


**1.11.1.6.3** **(08-29-2025)**

#### M&P Offices of Publishing and Distribution

1. Media and Publications (M&P) IRM Team and distribution coordinators are responsible for publishing and distributing all IRS published products, including the IRM. Refer to IRM 1.1.13.6.1.3, Publishing, and IRM 1.1.13.6.1.4, Distribution.

2. The IRM Publishing Team is the initial contact for printing and publishing services for all media types. They are responsible for:



1. Reviewing and processing Form 1767, Publishing Service Requisition, to print and distribute IMD.

2. Administering the IRM Upload tool, which is used to submit IRMs for publication.

3. Administering the IRM composition and printing contract.

4. Managing the electronic IMD files in the Core Repository of Published Products (CROPP).

5. Establishing the annual IRM Filing Season Production Schedule.

6. Coordinating with SPDER to incorporate IRM program and customer requirements into the publishing system.

7. Distributing the electronic IMD files.

8. Publishing all non-OUO and redacted IRMs on IRS.gov.

9. Funding all publishing costs associated with the IRM.


3. M&P maintains a listing of its IRM team members as well as its distribution coordinators, who provide planning and distribution services for all IRS printed products, including the Internal Management Documents Distribution System (IMDDS). The listing is available at: Internal Revenue Manual Program.



### Reminder:



National IMDDS coordinators are listed at: National IMDDS Coordinators.


**1.11.1.6.4** **(11-01-2011)**

#### IMD Oversight Council

1. The IMD Oversight Council provides a strategic direction for identifying and recommending improvements to the IMD process relating to the IRM, policy statements, delegations of authority, and IG. The Council is responsible for:



1. Collaborating on and implementing strategies related to the IMD program.

2. Identifying IMD program needs such as training requirements, delivery of training, IRM content, etc.

3. Representing concerns from users of the IRM or other IMD related activities.

4. Promoting ownership and team building among its members.

5. Supporting the IRS goal to ensure the IRM is the official source of all procedures, policy, directives, delegations, and guidelines.

6. Monitoring and measuring progress achieving the IRM goals.


2. SPDER chairs the Council. Members include one or more representatives from each business unit along with representatives from the M&P IRM Team, and SERP. Business unit IMD coordinators are members of the Council.

3. The Council meetings provide a forum for this cross-agency body to make decisions related to the IMD process.


**1.11.1.6.5** **(08-29-2025)**

#### General Management Responsibilities

1. All IRS managers must ensure that their employees have access to the IMDs defining the policies and procedures necessary to perform their jobs. This begins with an understanding of the IRM.

2. Managers must ensure employees receive training on how to access and use the IRM (paper and electronic versions) and that employees understand:



   - Where to find IG or SERP updates.

   - How policy statements and delegation orders affect their duties.


3. It is the responsibility of all IRS managers to support the IMD program and require the use of applicable IRM sections. Managers encourage employees to provide feedback regarding the IRM to the authors.



### Note:



Managers choose whether IRM comments or feedback goes directly to the author or through the manager’s review.


**1.11.1.6.6** **(08-29-2025)**

#### Program Owners with IMD Oversight

1. A manager with IMD responsibilities supervises employees who issue IMDs.

2. IRS program offices responsible for establishing the internal instructions necessary to implement and manage a program area are **program owners**. They are responsible for:



1. Reviewing IRM, delegation order and policy statement content for accuracy and completeness on a yearly basis.

2. Analyzing issues that provoke a change to the IRM, such as new or revised legislation, court opinions, issuance of regulations, or changes in procedure that result from other factors (organizational, operational, technology, etc.).

3. Determining and prioritizing changes to the IRM.

4. Approving the issuance of instructions to staff, such as in IRMs, IG, and local procedures.

5. Complying with FOIA requirements for IG and other IMDs.

6. Ensuring adequate records management for all IMDs.

7. Responding to disagreements elevated from the clearance process.

8. Ensuring a good-faith effort to resolve disagreements that arise during clearance.


3. IRS managers who manage employees with IMD duties are responsible for:



1. Verifying that IMDs are issued and maintained in accordance with IRM 1.11.2, IRM 1.11.3, IRM 1.11.4, IRM 1.11.5, IRM 1.11.9, and IRM 1.11.10.

2. Ensuring IMDs reflect current operations and processes.

3. Communicating and promoting the importance of the IRM in office business goals.

4. Confirming IMDs comply with the E-FOIA requirements of electronic public availability and records management guidelines. Refer to _IRM 1.11.1.3.1_, Transparency of Instructions to Staff.

5. Ensuring IRM authors and/or coordinators have proper training. See IRM Author Curriculum for recommendations.

6. Ensuring internal control information is included in each IRM section.

7. Devoting adequate resources to support the IMD program.

8. Developing, as needed, internal procedures on managing instructions to staff and communicating them to staff.

9. Evaluating employees with collateral duties in support of the IMD program, including: IRM authors, IMD/IRM coordinators, IG coordinators, and other management officials, on their performance of these duties.


**1.11.1.6.6.1** **(10-07-2022)**

##### IMD Coordination

1. Business unit directors appoint coordinators to manage and support the IMD program within their business unit. Each office reporting to a business unit can designate an individual to serve as an IRM coordinator and/or IG coordinator for that office. These coordinators and other management officials, as needed, assist the IMD coordinator in the management of the IMD/IRM program.



### Note:



The number of coordinators established in a business unit depends on the structure of the business unit and the volume of IMD activity.

2. Management officials support IMD coordination and management of the IMD program. They provide assistance to:



   - Communicate and promote the importance of the IRM in office business goals.

   - Comply with legal requirements to document operations and promote transparency to the public.

   - Develop internal procedures on managing instructions to staff and communicating them to staff.


3. All employees with IMD responsibility should include these responsibilities in their work plans or commitments to ensure that this work is appropriately evaluated as part of their performance appraisal.


**1.11.1.6.6.1.1** **(10-07-2022)**

###### IMD Coordinator

1. IMD coordinators are members of the IMD Oversight Council and, as such, they are responsible for:



1. Serving as a business unit representative for employees managing and using IMDs.

2. Attending IMD Oversight Council meetings, workshops, and training classes.

3. Communicating information and guidance to business unit IRM coordinators, authors, and management officials.

4. Assisting with marketing and communications plans within their business units.

5. Participating in workgroups to address IMD related issues.


2. IMD coordinators are responsible for administering the business unit’s IMD program. These responsibilities include:



1. Coordinating the processing of IMDs, including: IRM materials, interim guidance memoranda, delegation orders, and policy statements.

2. Coordinating IRM review assignments from within and outside their business units (with IRM coordinators or subject matter experts).

3. Coordinating IMD certification for their business unit.

4. Facilitating elevated issues between IRM authors and reviewers.

5. Instituting mechanisms to ensure the IG is timely incorporated into the IRM.

6. Evaluating current IMDs to update and/or remove obsolete information.



      ### Note:



      The IMD coordinator shares responsibility for overseeing internal directives with each business unit. IRM coordinators designated within subordinate offices will assist them in this endeavor.

7. Monitoring the development of functional IMDs to ensure that they are authored and published correctly.

8. Providing business unit specific training to IRM coordinators and authors.

9. Communicating and educating business unit employees with Servicewide IMD/IRM changes and IMD resources to improve IMD/IRM products.



      ### Example:



      Alerting employees to updated instructions, new guidelines, and/or training material.


3. IMD coordinators are responsible for coordination and guidance. This is done by:



1. Managing IMD clearance requests originating within the business unit and those received from external business units.

2. Keeping IRM coordinators, IMD authors, and management officials informed of all instructions and guidelines issued by SPDER and Headquarters offices.

3. Ensuring, as a final reviewer of IMDs, that a completed package is assembled and forwarded for printing and distribution based on procedures outlined in IRM 1.11.2, Internal Revenue Manual (IRM) Process, IRM 1.11.9, Clearing and Approving the Internal Revenue Manual (IRM), and IRM 1.11.5, Publishing the Internal Revenue Manual (IRM).

4. Ensuring IG is cleared, numbered, and controlled.

5. Ensuring interim guidance memos meeting FOIA requirements are identified and published on IRS.gov. Refer to IRM 1.11.10, Interim Guidance Process, for detailed instructions.

6. Facilitating updates using the Editorial Update Process. Refer to IRM 1.11.2, Internal Revenue Manual (IRM) Process, for detailed instructions.


4. IMD coordinators are listed on the SPDER Internal Management Document site.


**1.11.1.6.6.1.2** **(10-07-2022)**

###### IRM Coordinator

1. IRM coordinators are responsible for providing guidance to IMD/IRM authors by:



1. Serving as the first point of contact for IMD/IRM authors under their respective areas.

2. Serving as the liaison between the authors, IG coordinator, and the business unit IMD coordinator.


2. IRM coordinators are responsible for providing assistance by:



1. Supporting the IMD coordinator on IMD/IRM issues.

2. Facilitating issues between IRM authors and reviewers.

3. Reviewing IRM packages for conformance with the format and procedures provided in IRM 1.11.2, Internal Revenue Manual (IRM) Process, and IRM 1.11.5, Publishing the Internal Revenue Manual (IRM), prior to forwarding to their IMD coordinator or authorized approver.


**1.11.1.6.6.1.3** **(10-07-2022)**

###### IG Coordinator

1. IG coordinators are responsible for:



1. Serving as a contact for IG originators under their respective areas.

2. Serving as the liaison between the authors and the business unit IMD coordinator.

3. Providing assistance to originators on IG standards, formats, and processing steps found in IRM 1.11.10, Interim Guidance Process, and organizational requirements.

4. Facilitating issues between originators and reviewers.

5. Monitoring IG to ensure it is current and timely incorporated into the related IRM, or appropriately reissued or obsolesced following IRM 1.11.10, Interim Guidance Process.

6. Posting interim guidance memoranda to the IG tracking system.


**1.11.1.6.6.1.4** **(08-29-2025)**

###### Policy Statement Coordinators

1. Policy Statement coordinators are responsible for:



1. Serving as the business unit POC for policy statements and providing technical guidance and support to the business unit IMD coordinator, authors, and other policy statement stakeholders.

2. Working with SPDER policy statements coordinator to identify and address business unit needs.

3. Facilitating calls with stakeholders to address questions or concerns related to policy statements.

4. Assisting authors with the preparation of policy statements and the related clearance packages.

5. Reviewing and provide feedback on policy statements packages at various stages of clearance.

6. Submitting complete policy statements packages to SPDER for review.

7. Establishing internal processes and managing the policy statements program for their respective business units.


**1.11.1.6.6.1.5** **(08-29-2025)**

###### Delegation Orders Coordinators

1. Delegation orders coordinators are responsible for:



1. Serving as the business unit POC for delegation orders and providing technical guidance and support to the business unit IMD coordinator, authors, and other delegation order stakeholders.

2. Working with SPDER delegation orders coordinator to identify and address business unit needs.

3. Facilitating calls with stakeholders to address questions or concerns related to delegation orders.

4. Assisting authors with the preparation of delegation orders and the related clearance packages.

5. Reviewing and provide feedback on delegation order packages at various stages of clearance.

6. Submitting complete Servicewide delegation orders packages to SPDER for review.

7. Establishing internal processes and managing the delegation orders program for their respective business units.


**1.11.1.6.7** **(08-29-2025)**

#### IMD Authors

1. IRM authors must follow the IMD process contained in the IRM. The following table lists the IMD IRM sections.




| **IRM** | **Title** | _Guidance_ |
| --- | --- | --- |
| IRM 1.11.1 | Internal Management Document (IMD) Program and Responsibilities | The IMD program, definitions and the roles and responsibilities of IRM authors, IMD/IRM coordinators and their managers. |
| IRM 1.11.2 | Internal Revenue Manual (IRM) Process | Describes the IRM authoring process and the procedures for creating or updating the IRM. |
| IRM 1.11.3 | Servicewide Policy Statement Process | Creating and revising Servicewide policy statements. |
| IRM 1.11.4 | Servicewide Delegation Order Processing | Creating and revising Servicewide delegation orders and divisional delegation orders. |
| IRM 1.11.5 | Publishing the Internal Revenue Manual (IRM) | The publishing and distribution processes. |
| IRM 1.11.8 | Servicewide Electronic Research Program (SERP) | Issuing SERP IPUs. Refer to IRM 1.11.8.7.1, Updating IRMs through an IRM Procedural Update (IPU). |
| IRM 1.11.9 | Clearing and Approving the Internal Revenue Manual (IRM) | Clearing IRMs and obtaining approvals. |
| IRM 1.11.10 | Interim Guidance Process | Authoring, issuing and clearing IGs and the rules for complying with the Freedom of Information Act (FOIA) requirements. |
| IRM 10.5.1 | Privacy Policy | The proper handling of sensitive but unclassified (SBU) information and personally identifiable information (PII). |
| IRM 11.3.12 | Designation of Documents | Processing IMDs and training materials containing OUO information. |

2. IRM authors must also:



1. Follow the IMD/IRM authoring rules and processes.

2. Contact the IMD/IRM/IG coordinator for training and guidance. IMD coordinators are listed under the Internal Management Documents (IMD) Contacts List on SPDER’s Internal Management Documents Community web page.

3. Attend IMD training courses. Refer to IRM Author Curriculum for the complete listing of recommended training courses.

4. Ensure the information in the IMD is current and accurate.

5. Collaborate with stakeholders when processes or procedures affect another business unit, group, or external stakeholder.


3. When creating or managing IRM content, the author must:



1. Prepare IRM content using the IRM authoring tool (Refer to IRM 1.11.2, Internal Revenue Manual (IRM) Process, for authoring instructions).

2. Identify and mark official use only (OUO) text that is embedded in an IRM section by following IRM 1.11.2.5.3, Designate IRM Content as Official Use Only (OUO).



      ### Caution:



      When changing OUO designation or adding new OUO material, ensure the change is cleared by the authority listed in Delegation Order 11-1 and signed by the official designated in Delegation Order 1-69.

3. Follow the rules in Arbortext 8.1 IRM authoring software to ensure the IRM is compliant with Section 508 of the Rehabilitation Act of 1973.


4. When clearing IRMs, the author must:



1. Follow procedures in IRM 1.11.9, Clearing and Approving the Internal Revenue Manual (IRM).

2. Coordinate with all stakeholders and resolve any stakeholder concerns.

3. Prepare an IMD electronic clearance package and secure approval (clearance) of the document through affected business units.

4. Send the document clearance records to the IRS Historical Research Library.


5. IMD/IRM authors must contact their business unit’s IMD Coordinator and follow IRM 1.11.5, Publishing the Internal Revenue Manual (IRM), for publishing an IRM. They must follow IRM 1.11.10, Interim Guidance Process, when determining publication requirements for IG.

6. IRM authors should include these collateral responsibilities in their work plan or commitments to ensure that this work is appropriately evaluated as part of their performance appraisal.

7. Contractors developing IMD materials are subject to the same requirements as any IMD originator/author. It is the responsibility of the contractor liaison to ensure the guidelines and processes are followed.


**Exhibit 1.11.1-1**

### Glossary of Terms

The table below defines some key terms used in the IMD process:

| **Term** | **Definition** |
| --- | --- |
| Affected Business Units | Business units whose policies or procedures are changed because of the originator's IMD procedures and revisions. Affected business units include:<br> <br>- the originator's business unit<br>  <br>- the mandatory reviewers<br>  <br>- other affected business units/offices/function |
| Audience | The employees responsible for action or who require knowledge about the program, process or activity. Identify the IRM primary user by job title, role, specific office or business unit. |
| Approving Official | The person who gives the final approval to implement the procedures, guidelines, or policy contained in an IMD. |
| Business Unit | The highest level operating division or office headed by an executive. |
| Clearance | The established, formal process for business units affected by an internal management document to review, comment, and approve that document to ensure it is complete, correct, and does not conflict with another policy, procedure, or process. |
| Core Repository of Published Products (CROPP) | A website that provides the extensible markup language (XML) version for the current published IRM section, and IRM portable document format (PDF) file(s) dating back to 1996. The CROPP can be accessed on the Electronic Publishing website. |
| De-designate | To determine that content no longer meets the criteria for an official use only (OUO) classification. |
| Delegation Order | Specific delegations of authority issued by the Commissioner of Internal Revenue, or on their behalf by the Deputy Commissioner of Internal Revenue, to subordinate officials, with or without restrictions. Refer to _IRM 1.11.1.2.1_, Types of IMDs. |
| Distribution | The act of delivering the IRM to its users either in hardcopy (paper) or electronic format (PDF). |
| E-FOIA Decision Tool | An "interactive" flowchart that helps determine if "instructions to staff," including IG, are made available to the public. The E-FOIA Decision tool is available on the IMD Community site. |
| Extensible Markup Language (XML) | The content markup language used in the IRM authoring tool that identifies the content type and maintains the required structure of the IRM format. |
| FOIA and E-FOIA | The Administrative Procedure Act (APA), 5 USC 551, et seq., requires that an agency keep the general public informed about its operations and record-keeping practices. Section 552 of the APA, known as the Freedom of Information Act (FOIA) is a law that provides public access to agency records unless protected from disclosure by an exemption or exclusion. PL 89-487 (1966) which was codified in 5 USC 552 by PL 90-23 (1967). For exemptions, Refer to IRM 11.3.13.5.2, Exemptions.<br> <br>### Note:<br>FOIA also requires disclosure to the public in an electronic form, referred to as the Electronic Freedom of Information Act (E-FOIA). |
| Form 13709, Privacy, Governmental Liaison and Disclosure (PGLD) Checklist for IMD and Training Materials | Form 13709 is submitted to PGLD to assist with ensuring review by the appropriate subject matter expert(s). |
| Form 1767, Publishing Services Requisition | Form 1767 is used to request the publishing, printing, and distribution of an IRM section. |
| Form 2061, Document Clearance Record | Form 2061 is used to facilitate review and clearance of IMDs. This form serves as a control, routing slip, and official record of review and clearance for all types of IMDs. |
| IMD Community | All personnel responsible for IMD in any capacity – managers, IMD coordinators, IRM coordinators, authors, reviewers, etc. |
| IMD Coordinator | An individual designated by a business unit executive to serve as a coordinator of IMD for the entire business unit. For a listing of IMD coordinators, refer to the SPDER website’s IMD Oversight Council listing. |
| Instructions to Staff | Guidelines and procedures issued by program owners. |
| Interim Guidance (IG) | An official communication conveyed through memoranda or IRM procedural updates (IPUs) used by business units or program offices to convey immediate, emergency or temporary changes to operations or procedures for a defined effective period. |
| Interim Guidance Memo | A type of interim guidance. |
| IG Coordinator | An individual designated by a business unit within each office to serve as liaison between originators of IG and the business unit IMD coordinator. They provide support to the IMD coordinator, IRM authors, and IG originators. |
| Internal Control | A tool routinely used by management or an integral component of a business unit’s management that provides unmodified assurance of achievement for the following objectives:<br> <br>1. Effectiveness and efficiency of operations.<br>   <br>2. Reliability of reporting for internal and external use.<br>   <br>3. Compliance with applicable laws and regulations.<br>   <br> Refer to IRM 1.4.2.4, Control Activities, for examples. |
| Internal Management Document (IMD) | An official communication that designates authorities and delineates instructions to staff for IRS officials and employees. Refer to _IRM 1.11.1.2.1_, Types of IMDs. |
| Internal Management Documents Distribution System (IMDDS) | The system that controls and manages the distribution of the IMDs of the IRS. |
| Internal Revenue Manual (IRM) | The primary source of official IRS policies, procedures, guidelines, and delegations. The IRM contains information available to the public and embedded official use only (OUO) information. |
| IRM Authoring Tool | Also referred to as Arbortext Editor or simply Arbortext. The tool used by IRM authors to create and maintain IRM content. |
| IRM Coordinator | An individual designated by a business unit within each office to serve as liaison between the IRM authors and the business unit IMD coordinator and to provide support to the IMD coordinator and IRM authors. |
| IRM Publishing Package | An organized packet of documents presented in a designated order and used to request publication of an IRM. Refer to IRM 1.11.5, Publishing the Internal Revenue Manual (IRM). |
| IRM Section | A standalone unit of the IRM that covers a single topic or substantive matter about a program, process or activity. |
| IRS Historical Research Library | A repository of IRS organizational history, IRMs from inception in 1952, including background and clearance information, both in electronic and paper format. The online resource is found at the IRS Historical Research Library. |
| National IMDDS Coordinators | Individuals who administer the distribution system for IMD and are the key contacts for IRM distribution. |
| Office of Servicewide Policy, Directives and Electronic Resources (SPDER) | SPDER manages the IMD program. |
| Official IRM File | The electronic IRM files and graphics used as the source files to deliver the IRM in both electronic and paper to internal and external users. The official IRM file is available in the CROPP. |
| Official Use Only (OUO) | Sensitive information not made available to the public because it meets a Freedom of Information Act exemption and there is a reasonable expectation that disclosure would harm tax administration or IRS operations, or when disclosure is specifically prohibited by law. Refer to IRM 11.3.12, Designation of Documents. |
| Originator | An individual, usually the IMD author. This person is the key contact to address any technical questions about content that occurs during the clearance process. |
| Portable Document Format (PDF) | The Adobe Acrobat computer file format used to create IRM graphics. |
| Policy Owner | The program office responsible for the policy/policies published in this IRM section; normally the executive of the operation. |
| Policy Statement | Policy statements generally advise IRS employees and the public of the IRS commitment to an ideal or value. They are authorized by the Commissioner or Deputy Commissioner. Refer to _IRM 1.11.1.2.1_, Types of IMDs. |
| Program Owner | The program office that typically reports to the policy owner and is responsible for the administration, procedures and updates related to the program. |
| Publish | To prepare and issue printed and electronic material (the IRM) for distribution to employees, vendors, and other users. The official IRM is "published" by a printing contractor who creates the final version and packages the material for distribution. |
| Reviewer | Employees from affected offices and business units who review IMDs for accuracy during the clearance process. |
| Section 508 | Section 508 of the Rehabilitation Act (29 USC 794d), as amended by the Workforce Investment Act of 1998 (PL 105-220), requires federal agencies to make their electronic and information technology accessible to people with disabilities. |
| Servicewide Electronic Research Program (SERP) | An electronic research source maintained by Taxpayer Services designed to provide access to current IRMs, updated with interim procedural guidance through IPUs and reference materials. Not all IRMs are on SERP. |
| SERP IRM Procedural Update (SERP IPU) | A type of interim guidance issued for IRMs on the SERP platform. |
| Subject Matter Expert (SME) | An Employee who is familiar with the policies and procedures contained in an IMD and can review that content for accuracy. |

**Exhibit 1.11.1-2**

### IMD Websites

(1) The following resources provide additional information and tools pertaining to procedures for issuing and maintaining IMD/IRM material:

| **Resource** | **Location** | **Description** |
| :-: | :-: | :-: |
| **Core Repository of Published Products (CROPP)** | Publishing + Distribution Find a Product | Houses the official IRM, including the electronic IRM files and graphics, used to deliver electronic and hardcopy IRM sections to sites internal and external to IRS.<br> Contains both Portable Document Format (PDF) and Extensible Markup Language (XML) versions for each IRM section. |
| _IMD Electronic Clearance Tool_ | IMD Electronic Clearance - Home (sharepoint.com) | A SharePoint based system that streamlines the clearance, approval and archiving processes. |
| **IMD Tracking System** | Search Interim Guidance (irs.gov) | Provides a database of recently published IG, policy statements, and delegation orders. |
| _IRM Decision Tool_ | IRM Decision Tool | An interactive flowchart to help determine if the information is instructions to staff and needs incorporated into the IRM. |
| **IRM Online** | IRM Online | Houses the currently effective Internal Revenue Manual (IRM) for research. |
| **IRM Upload Tool** | IRM Upload Tool | Supports the submission of IRM packages for publishing and the submission of source files used in the development of IRM graphics. |
| **IRS Published Product Notification** | List subscriptions - E-Notifications | Provides the option for any IRS employee to sign up to receive an e-mail notifying them when a revised IRS published product is issued. This feature is available from M&P's Product Catalog Information page for each individual IRM section, in the box entitled, "Availability." |
| **Link Creation Tool** | Link to IRM References on IRM Online | Assists document authors in creating hyperlinks to IRM Online content. The tool generates a URL that links directly to an IRM section or subsection hosted on IRM Online.<br> <br>### Note:<br>The tool does not validate the generated link. Users test the generated link to ensure the content exists. |
| **M&P IRM Program** | Internal Revenue Manual Program | Provides an overview of M&P IRM program along with links to related IRM publishing and distribution tools. |
| **Organizational IMD/IRM Websites** | Other Internal Management Documents | Houses IMD/IRM information pages for some business units who maintain their own pages. |
| **Publishing + Distribution Website** | Publishing and Distribution | Provides links to the official core repository of IRS products including the IRM, publishing production time frames for IRMs, IRM production information, FAQs, and other publishing information. |
| **ReferenceNet** | Reference Net | Provides Servicewide legal and tax research services to staff. |
| **SPDER IMD Training Website** | IMD Training | Provides a complete list of IRM-related training. |
| **SPDER IMD Website** | IMD Community Home | Provides IMD information and access to important memoranda relating to administration of the IMD program.<br> Provides access to training plans and information to strategically manage the IMD program. |
| **IMD Data and Program Reports** | IMD Program Reports | Provides IMD data reports categorized by business unit operation. |

**Exhibit 1.11.1-3**

### IMD Contacts and Resources

| **Resource** | **Location/URL** | **Description** |
| :-: | :-: | :-: |
| **IMD Community Mailing Lists** | IMD Community News | Subscribers receive e-mail alerts on topics related to the IMD program.<br> There is a separate mailing list available for managers of IMD authors or coordinators. |
| **SPDER IMD Team Members** | Contact SPDER | Contact information for members of SPDER's IMD Team. |
| **Members of the IMD Oversight Council** | IMD Council Membership | Includes business unit IMD/IRM coordinators, NTEU, members of the SPDER IMD Team, and the IRM Publishing Team. |
| **M&P IRM Publishing Team Members** | Internal Revenue Manual Program | Contact information for members of the IRM Publishing Team. |
| **XML/SGML Help Desk** | Knowledge Services XML Help Desk Website | The XML/SGML Help Desk provides answers to questions about XML/SGML and the IRM authoring tool. |
| **M&P National IMDDS Coordinators** | National IMDDS Coordinators | Contact information for M&P National Internal Management Document Distribution System (IMDDS). IMDDS is used to manage IRM distribution requirements. |
| **Document 12835, The IRM Style Guide** | Document 12835, IRM Style Guide | Document 12835 establishes standards and promotes consistency for the IRM. The style guide is intended to help IRM authors improve writing quality and increase the efficiency of the writing process. |
| **Form 15418, IRM Package Check Sheet** | Form 15418, IRM Package Check Sheet | Form 15418 is a check sheet used when forwarding an IRM publishing package. It ensures specific items are completed prior to forwarding for printing and distribution. |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-011-001#addtoany "Show all")

A2A