---
url: "https://www.irs.gov/irm/part1/irm_01-001-017"
title: "1.1.17 Facilities Management and Security Services | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-001-017#main-content)

- 1.1.17  [Facilities Management and Security Services](https://www.irs.gov/irm/part1/irm_01-001-017#idm139716129269280)
  - 1.1.17.1  [Facilities Management and Security Services (FMSS)](https://www.irs.gov/irm/part1/irm_01-001-017#idm139716129264224)
  - 1.1.17.2  [FMSS Order of Succession](https://www.irs.gov/irm/part1/irm_01-001-017#idm139716129296864)
  - 1.1.17.3  [Chief of Staff](https://www.irs.gov/irm/part1/irm_01-001-017#idm139716129291760)
  - 1.1.17.4  [Quality Assurance](https://www.irs.gov/irm/part1/irm_01-001-017#idm139716101069456)
  - 1.1.17.5  [Deputy Chief](https://www.irs.gov/irm/part1/irm_01-001-017#idm139716101056432)
    - 1.1.17.5.1  [Facilities Support](https://www.irs.gov/irm/part1/irm_01-001-017#idm139716101049584)
    - 1.1.17.5.2  [Operations](https://www.irs.gov/irm/part1/irm_01-001-017#idm139716101037184)
    - 1.1.17.5.3  [Project Management](https://www.irs.gov/irm/part1/irm_01-001-017#idm139716101021200)
    - 1.1.17.5.4  [Security](https://www.irs.gov/irm/part1/irm_01-001-017#idm139716100972496)

# Part 1. Organization, Finance, and Management

# Chapter 1. Organization and Staffing

# Section 17. Facilities Management and Security Services

* * *

## 1.1.17 Facilities Management and Security Services

#### Manual Transmittal

August 03, 2022

#### Purpose

(1) This transmits revised IRM 1.1.17, Facilities Management and Security Services (FMSS).

#### Background

This section contains the functional statements and responsibilities of the offices within FMSS.

#### Material Changes

(1) Changes are reflected in this IRM include:

1. Updated the Order of Succession at IRM 1.1.17.2.

2. Added the Employee Development Program to the Quality Assurance organization at IRM 1.1.17.4.

3. Added Puerto Rico Territory to Operations Mid-Atlantic at IRM 1.1.17.5.

4. Removed IRM 1.1.17.5.1 (2 a) Facilities Support no longer owns the Computer-Aided Design (CAD) program. The CAD program was moved to Project Management.

5. Removed IRM 1.1.17.5.1 (2 d and g) Facilities Support no longer oversees the Contracting Officer’s Representative (COR) for Logistics contracts.

6. Removed IRM 1.1.17.5.3 (10 d) Real Property IRS no longer has delegated authority.

7. Editorial changes made throughout the IRM for clarity. Reviewed and updated for plain language and grammar.


#### Effect on Other Documents

This IRM supersedes IRM 1.1.17 dated April 30, 2021.

#### Audience

Servicewide

#### Effective Date

(08-03-2022)

Richard L. Rodriguez

Chief

Facilities Management and Security Services

**1.1.17.1** **(04-30-2021)**

### Facilities Management and Security Services (FMSS)

1. The mission of FMSS is to be a strategic partner with our IRS customers, delivering a safe, secure, and optimal work environment that promotes effective tax administration.

2. To accomplish the mission, FMSS:



01. Formulates short and long-range program policies, strategies, and objectives for FMSS services to implement the overall IRS support strategy and vision.

02. Designs and develops administrative service programs for all internal IRS organizations.

03. Directs activities to build partnerships with internal stakeholders.

04. Coordinates with other top-level IRS executives to address cross-functional issues, develop strategies, ensure consistency of approach, and meet customer needs.

05. Ensures IRS management and employees are provided with standards and processes to protect lives, property, assets, and information.

06. Ensures alignment and compatibility of real estate actions within the IRS strategic plans and FMSS Business Plan.

07. Administers the IRS rent budget.

08. Formulates, executes, and monitors the FMSS financial plan.

09. Manages energy utilization and conservation efforts.

10. Develops and monitors business measurements that integrate budget and performance to balance the level of service with the level of available resources.

11. Develops strategies for improving functional service delivery, customer satisfaction, and employee satisfaction.

12. Ensures best practices are implemented throughout the function.

13. Develops and maintains external contacts, including General Services Administration (GSA), National Treasury Employees Union (NTEU), Federal Protective Services (FPS), Department of Homeland Security (DHS), and other professional facilities organizations.


3. FMSS supports the IRS by managing resources that enable business processes. FMSS has specific goals to facilitate the IRS mission. These goals are:



1. Invest in our employees.

2. Enhance strategic partnerships.

3. Advance data access, usability, and analytics.

4. Effectively manage facility operations.


4. The Chief, FMSS reports to the Deputy Commissioner Operations Support (DCOS) and is responsible for providing facilities and physical security support for the IRS, through these organizations:



1. Facilities Support

2. Operations East, Mid-Atlantic, and West

3. Project Management

4. Quality Assurance

5. Security


5. FMSS organizations provide Servicewide program development and direction for various products and business lines, including:



01. Building and Energy Management

02. Delegated Leaseholder Activities

03. Design, Engineering, and Architectural Services

04. Document Destruction Services

05. Environmental, Health, and Safety Services

06. Logistics Contract Management

07. Mail and Postal Meter Contract Management

08. Motor Vehicle Program Management

09. Personal Property Asset Management

10. Identification (ID) Media Management

11. Project Management and Execution

12. Real Estate Strategy and Portfolio Management

13. Plans, Procedures and Assessments

14. Physical Access Control Management

15. Space Management


**1.1.17.2** **(08-03-2022)**

### FMSS Order of Succession

1. The Office of the Chief, FMSS of the IRS maintains an updated continuity plan so that in the absence of the Chief, due to a domestic or foreign enemy attack on the United States, all hazards, emergencies, or other situations that may disrupt normal operations may be avoided, in accordance with Federal Continuity Directives 1 and 2 and IRM 10.6.1, Continuity Planning Requirements, for the IRS Business Units; thus, ensuring the continuity of the functions of the office.

2. The management officials who occupy these positions are authorized in order of succession to the position of Chief, FMSS:


    1st successor: Deputy Chief, FMSS


    2nd successor: Associate Director (AD), Security, FMSS


    3rd successor: Associate Director (AD), Operations East, FMSS


    4th successor: Associate Director (AD), Operations West, FMSS

3. This authority may not be redelegated.

4. Source of Authority: Servicewide Delegation Order 1-1, Treasury Order 150-10, 5 USC 3345-3349, and 31 CFR Part 18


**1.1.17.3** **(04-30-2021)**

### Chief of Staff

1. The Chief of Staff reports to the Chief, FMSS.

2. The Chief of Staff:



01. Conducts streamlining and process improvement studies within FMSS and research opportunities to improve business practices.

02. Ensures the FMSS Business Plan aligns with the FMSS and IRS Strategic Plans and ensures its implementation and success.

03. Identifies and coordinates FMSS special projects to target the specific needs of FMSS customers.

04. Liaises with IRS internal organizations providing services to FMSS for human resource management and communication needs.

05. Develops and oversees reorganizational changes as needed.

06. Coordinates, calculates, and initiates Special Act, Manager, Quality Step Increase, Higher Graded Duties, and Performance Awards for FMSS employees.

07. Maintains FMSS organizational chart and ensures adherence to Authorized Staffing Plan.

08. Formulates FMSS hiring plan and directs hiring/staffing.

09. Oversees human resources management functions (i.e., organizational change, performance management, succession planning, training, etc.).

10. Coordinates development of significant year-end reporting materials.

11. Establishes and executes action plans to mitigate risks.


**1.1.17.4** **(08-03-2022)**

### Quality Assurance

1. The AD, Quality Assurance reports to the Chief, FMSS.

2. Quality Assurance provides policy and operation reviews, analysis, and guidance for the Chief, FMSS and represents FMSS to external stakeholders in discussions related to internal controls, streamlining, and customer support. It includes the Program Review and Audit Section.

3. Quality Assurance staff:



1. Conducts quality reviews and analyses of FMSS programs to improve effectiveness.

2. Identifies program processes and controls that are not operating in accordance with policy, procedures, or other requirements and proposes measures to strengthen compliance.

3. Provides technical and analytical support to implement program improvements and corrective measures.

4. Addresses requests and inquiries from the Government Accountability Office (GAO), Treasury Inspector General for Tax Administration (TIGTA), the Chief Financial Officer (CFO), and other organizations auditing FMSS programs and implements IRS Audit policies.

5. Ensures Internal Management Documents (IMD) products (IRM, Policy Statements, Delegation Orders, etc.) are aligned and current and implements IRS IMD policies.

6. Gathers and reports FMSS performance measures and implements IRS Business Performance Management System (BPMS) policy.

7. Ensures FMSS considers risks to their mission areas and objectives and provides subject matter expertise about FMSS to the Enterprise Risk Management (ERM) program to help assess enterprise risks.

8. Oversees the Employee Development Program providing training event planning, coordination and reporting.


4. For specific policy information, see the following Servicewide policies:



01. IRM 1.4.2, Resource Guide for Managers, Monitoring and Improving Internal Control

02. IRM 1.4.3, Resource Guide for Managers, Financial Assurance Control Testing

03. IRM 1.4.31, Resource Guide for Managers, IRS Quality Assurance Program

04. IRM 1.4.32, Resource Guide for Managers, Internal Control Review Program

05. IRM 1.4.60, Resource Guide for Managers, Enterprise Risk Management (ERM) Program

06. IRM 1.5.1, Managing Statistics in a Balanced Measurement System, The IRS Balanced Performance Measurement System

07. IRM 1.11, Internal Management Documents System series

08. IRM 1.29.1, Audit Coordination Process, Authorities and Responsibilities

09. IRM 1.35.14, Financial Accounting, IRS Annual Financial Statement Audit

10. IRM 11.5.1, Legislative Affairs, Audit Process for General Accountability Office (GAO) and Treasury Inspector General for Tax Administration (TIGTA)

11. IRM 1.57.1, FMSS Quality Assurance Programs


**1.1.17.5** **(04-30-2021)**

### Deputy Chief

1. The Deputy Chief, FMSS manages these AD:



1. AD, Facilities Support

2. AD, Operations East

3. AD, Operations Mid-Atlantic

4. AD, Operations West

5. AD, Project Management

6. AD, Security


2. The AD:



1. Ensures programs within their control function properly and provide the necessary services to meet customer needs.

2. Manages FMSS Headquarters (HQ) Program Managers.

3. Manages FMSS Territory Managers (TM) responsible for field operations.


**1.1.17.5.1** **(08-03-2022)**

#### Facilities Support

1. Facilities Support manages key program areas for FMSS that potentially affect every IRS employee. Facilities Support provides facilities-related guidance and support for the entire IRS inventory, including managing operations for approximately 4.8 million square feet of space at delegated facilities, and FMSS oversight, direction, and technical support for the execution and operation of logistics programs.

2. The Facilities Support staff:



01. Maintains workplace safety and protects the environment from potential impact by IRS facilities and operations.

02. Manages facility energy usage through awareness, operational efficiency and conservation, and fulfills federal reporting requirements.

03. Manages the fleet of GSA vehicles for the IRS except for Criminal Investigation.

04. Oversees building management functions at the facilities where IRS has delegated authority for operations and maintenance by GSA.

05. Manages projects and long-term planning at IRS campus locations and major facilities.

06. Provides architectural and engineering design, evaluation, and consultation support services.

07. Oversees Logistics programs.

08. Administers the National Mail Services Contract and the National Postage Meter Contract and oversees mail operations at all non-campus sites.

09. Provides policy, oversight, and strategic planning for the IRS personal property assets.

10. Manages the nationwide Telework File Cabinet program.

11. Manages the Furniture Reasonable Accommodation (RA) program.

12. Coordinates development of significant year-end reporting materials.

13. Establishes and executes action plans to mitigate risks.


3. For specific policy information, see:



1. IRM 1.14.2, Facilities Management, Supply Purchasing Program

2. IRM 1.14.4, Facilities Management, Personal Property Management

3. IRM 1.14.5, Facilities Management, Occupational Health and Safety Program

4. IRM 1.14.7, Facilities Management, Motor Vehicle Fleet Management Program

5. IRM 1.14.12, Facilities Management, IRS Environmental Compliance Program

6. IRM 1.22.1, Mail and Transportation Management, Mail and Transportation Management Overview


**1.1.17.5.2** **(08-03-2022)**

#### Operations

1. The mission of the FMSS Operations is to implement the policies established by FMSS HQ organizations through their day-to-day activities and provide services to all IRS employees.

2. Operations consists of HQ and Field functions. The HQ staff includes the AD, program analysts, and staff assistants in Operations East, Mid-Atlantic, and West reporting to the FMSS Deputy Chief. The Field staff includes the TM, their Section Chiefs, and support staff reporting to the Operations AD in HQ.

3. Operations East includes the Andover, Atlanta, Covington, Memphis, and New York/New Jersey territories.

4. Operations Mid-Atlantic includes the New Carrollton, Washington DC and Puerto Rico territories.

5. Operations West includes the Austin, Fresno, Kansas City, Oakland, and Ogden territories.

6. The Operations staff:



01. Provides review and oversight, plans, organizes, coordinates, and directs a comprehensive facilities management and security services program that includes space planning and design, building and maintenance management, security, property management, mail management, and warehousing in conjunction with the FMSS HQ office.

02. Collaborates with the Chief and Deputy Chief, FMSS to develop and assign goals for territory managers, reviews and approves multi-year program plans developed by the territories and manages development and implementation of policy changes.

03. Manages business improvements, processes, and systems in support of their customers.

04. Formulates, executes, and monitors facilities management support funds in conjunction with the Chief, FMSS.

05. Collaborates with the GSA and DHS officials as well as other agencies to resolve FMSS issues affecting service delivery.

06. Coordinates workload demands among assigned field FMSS territories to ensure equitable service delivery to customers.

07. Conducts capacity requirement and workload analysis for field FMSS territories in their areas.

08. Ensures services at an acceptable cost to all customer segments and a solid business approach for the FMSS operations.

09. Ensures timely execution of program activities, determining appropriate program emphasis to achieve goals, managing territory resources, ensuring proper application of IRS and United States Government (USG) policies and regulations, and maintaining uniform standards.

10. Ensures successful integration and communication between field FMSS territories and the Business Unit for their areas assigned.

11. Coordinates development of significant year-end reporting materials.

12. Establishes and executes action plans to mitigate risks.


7. The TM:



1. Serves as principal advisor to executives and operating line managers, ensuring that all FMSS requirements are fully met and integrated into the overall management of the organizations served.

2. Establishes FMSS program objectives, ensures timely execution of program activities, determines appropriate program emphasis to achieve goals, manages territory resources, and ensures proper application of IRS and USG policies and regulations.

3. Prepares short and long-range work plans, budgets, goals, and objectives.

4. Serves as a local point of contact for all Business Units serviced by their territory.

5. Supervises and is responsible for the activities of sections dedicated to delivering assigned programs to customers.

6. Oversees the protection of IRS employees, visitors, facilities, critical business operations, and assets.

7. Coordinates development of significant year-end reporting materials.

8. Establishes and executes action plans to mitigate risks.


**1.1.17.5.3** **(08-03-2022)**

#### Project Management

01. Project Management:



    1. Provides FMSS oversight, direction, and technical support for the execution and operation of real estate projects and programs.


02. The Project Management staff:



    01. Establishes and communicates procedures for IRS real estate project delivery.

    02. Evaluates and processes Business Unit requirements for all real estate projects.

    03. Manages and coordinates the Project Investment Fund and final headquarters approval of project funding.

    04. Owns the Space, Time and Resources (STAR) automated tool to support FMSS and develops guidelines to support the STAR functionality.

    05. Coordinates IT funding of Space and Housing projects.

    06. Improves program effectiveness through data analysis and research.

    07. Coordinates development of significant year-end reporting materials.

    08. Establishes and executes action plans to mitigate risks.

    09. Provides financial guidance and resource management including budget formulation, development, and execution.

    10. Serves as FMSS liaison with the CFO.

    11. Formulates, submits, and presents the out-year project budget requirements to the CFO Program & Budget Advisory Committee and the IT Development/Modernization/Enhancement.

    12. Oversees the Computer-Aided Design (CAD) program for viewing/modifying facility floor plans and linking CAD drawings to Graphic Database Interface (GDI)


03. Workflow Analysis:



    1. Provides analysis to project management on process consolidation, process improvement, and oversight for FMSS projects and programs.

    2. Maintains and/or creates analysis tools through available software and coordinates data management.


04. Workflow Analysis Staff:



    1. Develops and maintains the National Workspace Standards and Taxpayer Assistance Center (TAC) standards.

    2. Manages and coordinates the Project Investment Fund and final headquarters approval of project funding with Project Management Staff.

    3. Reviews and coordinates FMSS support for Servicewide Information Technology (IT) projects.

    4. Manages the STAR automated tool to support FMSS and develops guidelines to support the STAR functionality.

    5. Develops requirements for FMSS initiatives covering projects for space reduction/relocation/renewal, furniture refreshment, alternate workspace, etc.

    6. Leads education and outreach efforts related to SharePoint control activities.

    7. Manages the Security+ tool.

    8. Manages the Pocket Commission ID tool.

    9. Manages and maintains SharePoint for FMSS organizations as the FMSS SharePoint Site Collection Administrators.


05. Data Management Solutions:



    1. Provides facilities data oversight, direction, and support to enterprise customers.

    2. Includes the following sections:



       > 1. Automation
       >
       >
       >            i. GDI
       >
       >
       >            ii. Business Systems Planning
       >
       >
       >            iii. Knowledge Incident/Problem Service and Asset Management (KISAM)
       >
       >        2. Computer Aided Facilities Management (CAFM)


06. Budget Office:



    1. Provides financial oversight, direction, and support to IRS facilities.


07. The Budget staff:



    1. Provides financial management and guidance through budget execution, budget formulation, and management of resources.

    2. Serves as FMSS Liaison with the Chief Financial Officer (CFO).

    3. Provides guidance, procedures, objectives, practices, and standards for financial management of IRS facilities.

    4. Provides FMSS employees with Fiscal Year End financial guidance and due dates.

    5. Manages two Financial Plans:



       > 1. Agencywide Support Services (AWSP)
       >
       >        2. Stewardship (STWD)

    6. Provides financial oversight for:



       > 1. Security Work Authorization (SWA)/Reimbursable Work Authorization (RWA)
       >
       >        2. Labor
       >
       >        3. Training
       >
       >        4. Motor pool
       >
       >        5. Printing
       >
       >        6. Travel
       >
       >        7. Procurement Awards


08. Rent:



    1. Reconciles the GSA rent bills, forecasts rent expenses for the current and future years, and tracks the inventory of IRS space holdings.

    2. Certifies GSA rent Intragovernmental Payment and Collection System (IPCS).


09. The Rent staff:



    1. Reviews Occupancy Agreements and updates rates, square footage, and building information in GDI accordingly.

    2. Issues a Monthly Acquisition and Release control to the Territories to ascertain the status of projects that result in acquisition or release of space.

    3. Validates rent charges and pursues corrections for billing errors with GSA.

    4. Tracks inventory of buildings and square footage in inventory.

    5. Analyzes the GSA Rent Estimate and compares the GSA estimate to the IRS estimate and makes the necessary updates in GDI.

    6. Prepares the Exhibit 54, Space Budget Justification that accompanies Treasury budget request to Office of Management and Budget.

    7. Partners with Portfolio Management and CAFM to ensure all building data is accurate.

    8. Provides reports and guidance to various Business Units.

    9. Prepares and processes funding documents for the rent budget.


10. Real Property:



    01. Provides oversight for managing the real property assets at the IRS.

    02. Develops policy and implements guidance, procedures, objectives, practices, and standards for the administration, management, and oversight of the IRS real property and space management programs.

    03. Develops and administers long-term space and housing strategy for campus and non-campus locations, including oversight and tracking of space reduction projects.

    04. Provides real property and space management Subject Matter Expert (SME) training and technical support to FMSS staff.

    05. Ensures that IRS real estate management practices are consistent with presidential directives, executive orders, federal laws, regulations, and policies.

    06. Represents IRS with Treasury, GSA, contractors, industry trade and professional organizations, and other stakeholders regarding the management of real estate and other cross-functional issues.

    07. Collaborates and communicates with internal FMSS program areas to identify gaps that impact their service to the IRS.

    08. Partners and coordinates with external service providers to develop effective solutions to help FMSS carry out its mission.

    09. Ensures FMSS meets its strategic goals and objectives by analyzing external mandates and influences.

    10. Provides primary customer support for Business Operating Division(s) (BOD) planning and hiring initiatives that require FMSS services.

    11. Assists in the resolution of issues, problems, and concerns and communicates directly with BOD customer representatives.

    12. Participates in BOD organizational development planning on long-range issues, such as space plans, funding issues, and customer requirements.

    13. Reviews FMSS strategic initiatives and recommend solutions that both support FMSS policies and procedures and BOD requirements.

    14. Serves as primary point of contact on corporate level projects.

    15. Serves as a communication conduit between each BOD and FMSS.

    16. Manages the Space Advisory Group (SAG) to broker challenges and solutions facing multiple BOD.


11. For specific policy information, see:



    1. IRM 1.14.6, Facilities Management, Real Property Management Program

    2. IRM 1.14.8, Facilities Management, Identifying Space Efficient Buildings

    3. IRM 1.14.9, Facilities Management, IRS Parking Program


**1.1.17.5.4** **(08-03-2022)**

#### Security

1. FMSS HQ Security develops and communicates security policies and procedures to provide a comprehensive, Servicewide program to protect IRS employees, visitors, facilities, critical business operations, and assets. Key policies and procedures are developed to:



1. Support and execute the Homeland Security Presidential Directive (HSPD)-12 Smart Identification and Pocket Commission Credentials programs.

2. Implement HSPD-12 with servicewide AIM office in compliance with OMB M-19-17, Federal Information Processing Standards (FIPS) 201-3, and National Institute of Standards and Technology (NIST) 800-116, Rev.1 standards for physical access control.

3. Adhere to the Interagency Security Committee (ISC) Risk Management Process.

4. Validate the IRS compliance with the Classified National Security Information (CNSI) program and National Industrial Security Program (NISP).


2. The Security staff establishes policies and procedures for:



1. Providing an appropriate level of physical security through application of ISC standards, to include guidelines for the use of guards, canine services, and security countermeasures at IRS facilities.

2. Providing physical access control to admit authorized personnel and prevent entry by unauthorized persons.

3. Controlling, issuing, and disposing of ID media to identify the bearer as a representative of the IRS.

4. Providing guidelines to IRS employees, contractors, and visitors for response to an emergency at an IRS occupied facility.

5. Reporting and notifying appropriate personnel of physical security related incidents in and around facilities occupied by IRS personnel.

6. Supporting stakeholder organizations to mitigate security risks associated with contractor access by identifying, assessing, and prioritizing the physical security risk to IRS facilities.

7. Managing, handling, and protecting CNSI by IRS employees and contractors.

8. Analyzing, coordinating, and monitoring training to enhance the professional development of physical security specialists.


3. For specific policy information, see:



01. IRM 1.4.6, Resource Guide for Managers, Managers Security Handbook

02. IRM 10.2.1, Physical Security Program, Physical Security

03. IRM 10.2.5, Physical Security Program, Identification Media

04. IRM 10.2.6, Physical Security Program, Pocket Commissions

05. IRM 10.2.8, Physical Security Program, Incident Reporting

06. IRM 10.2.9, Physical Security Program, Occupant Emergency Planning

07. IRM 10.2.11, Physical Security Program, Basic Physical Security Concepts

08. IRM 10.2.14, Physical Security Program, Methods of Providing Protection

09. IRM 10.2.15, Physical Security Program, Minimum Protection Standards (MPS)

10. IRM 10.2.18, Physical Security Program, Physical Access Control (PAC)

11. IRM 10.9.1, Classified National Security Information (CNSI)


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-001-017#addtoany "Show all")

A2A