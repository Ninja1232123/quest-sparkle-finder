---
url: "https://www.irs.gov/irm/part1/irm_01-018-004"
title: "1.18.4 Technology and program support | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-018-004#main-content)

- 1.18.4  [Technology and program support](https://www.irs.gov/irm/part1/irm_01-018-004#idm139932265074256)
  - 1.18.4.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-018-004#idm139932296816576)
    - 1.18.4.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-018-004#idm139932263456624)
    - 1.18.4.1.2  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-018-004#idm139932263454640)
    - 1.18.4.1.3  [Acronyms](https://www.irs.gov/irm/part1/irm_01-018-004#idm139932263451504)
    - 1.18.4.1.4  [Related Resources](https://www.irs.gov/irm/part1/irm_01-018-004#idm139932263587696)
  - 1.18.4.2  [Technology and Governance (T&G)](https://www.irs.gov/irm/part1/irm_01-018-004#idm139932263582640)
    - 1.18.4.2.1  [Information Technology Budgeting](https://www.irs.gov/irm/part1/irm_01-018-004#idm139932263577648)
    - 1.18.4.2.2  [Information Technology Application Development and Program Management](https://www.irs.gov/irm/part1/irm_01-018-004#idm139932263572672)
    - 1.18.4.2.3  [Computer Assisted Publishing System (CAPS) Management](https://www.irs.gov/irm/part1/irm_01-018-004#idm139932263565840)
    - 1.18.4.2.4  [Enterprise Logistics Information Technology (ELITE) Management](https://www.irs.gov/irm/part1/irm_01-018-004#idm139932260431216)
    - 1.18.4.2.5  [eXtensible Markup Language (XML) Support](https://www.irs.gov/irm/part1/irm_01-018-004#idm139932260428144)
    - 1.18.4.2.6  [Unified Work Requests (UWR) Submissions Processing](https://www.irs.gov/irm/part1/irm_01-018-004#idm139932260425616)
  - 1.18.4.3  [Distribution Program Support (DPS)](https://www.irs.gov/irm/part1/irm_01-018-004#idm139932260421552)
    - 1.18.4.3.1  [Media and Publications (M&P) Distribution Program Support](https://www.irs.gov/irm/part1/irm_01-018-004#idm139932260417760)
    - 1.18.4.3.2  [Media and Publication (M&P) Resource Center SharePoint Site Administration](https://www.irs.gov/irm/part1/irm_01-018-004#idm139932260407264)
    - 1.18.4.3.3  [IRS.gov Content Management](https://www.irs.gov/irm/part1/irm_01-018-004#idm139932260388832)
    - 1.18.4.3.4  [IRS.gov Help Desk Comments](https://www.irs.gov/irm/part1/irm_01-018-004#idm139932260385776)
  - 1.18.4.4  [Alternative Media Center (AMC)](https://www.irs.gov/irm/part1/irm_01-018-004#idm139932260377952)
    - 1.18.4.4.1  [Alternative Media Center (AMC) Products](https://www.irs.gov/irm/part1/irm_01-018-004#idm139932260376128)
    - 1.18.4.4.2  [AMC Services](https://www.irs.gov/irm/part1/irm_01-018-004#idm139932260302432)
    - 1.18.4.4.3  [Accessible Taxpayer Notices and Letters](https://www.irs.gov/irm/part1/irm_01-018-004#idm139932260274304)
    - 1.18.4.4.4  [AMC Marketing and Collaboration](https://www.irs.gov/irm/part1/irm_01-018-004#idm139932260267872)

# Part 1. Organization, Finance, and Management

# Chapter 18. Distribution

# Section 4. Technology and program support

* * *

## 1.18.4 Technology and program support

#### Manual Transmittal

September 18, 2024

#### Purpose

(1) This transmits revised IRM 1.18.4, Distribution, Technology and Program Support

#### Material Changes

(1) IRM 1.18.4.1, Updated title from Knowledge Services to Technology and program support because of reorganization.

(2) IRM 1.18.4.1.3, Acronyms, Updated acronyms and added Published Product Media Catalog (PPMC).

(3) IRM 1.18.4.2, Technology and Governance, Updated section name from BRSI to Technology and Governance. Also updated acronyms throughout section.

(4) IRM 1.18.4.3, Distribution Program Support, Updated section name from KSB to Distribution Program Support. Also updated acronyms throughout section.

(5) IRM 1.18.4.4.1, Alternative Media Center, Changed Multi-Languages table to Foreign Language Alternative Media. Updated acronyms throughout section.

(6) Made editorial changes throughout to:

- Update organizational information.

- Follow required document formatting, including Internal Controls and Material Changes.

- Reorganize the IRM after adding or removing any substantive content.

- Adhere to Plain Writing requirements.

- Made updates to organizational title Wage and Investment (W&I) to Taxpayer Services (TS) where applicable.


#### Effect on Other Documents

This update supersedes IRM 1.18.4 dated March 23, 2022

#### Audience

Media and Publications (M&P) employees

#### Effective Date

(09-18-2024)

Maria Cheeks

Director, Distribution

Taxpayer Services

**1.18.4.1** **(09-18-2024)**

### Program Scope and Objectives

1. Purpose: The manual describes policies and guidelines for Technology and program support Branch employees. The overall knowledge services and systems management support for Media and Publications, Publishing and Distribution resides with the Taxpayer Services chief.

2. Audience: This IRM is for the Technology and program support employees who provide services to all Publishing and Distribution electronic systems and applications.

3. Policy Owner: The Technology and program support Branch is aligned in Taxpayer Services (TPS)/Customer Assistance Relationships and Education (CARE)/Media and Publications (M&P)/Distribution (D).

4. Program Owner: Technology and program support Branch oversees and provides guidance for Publishing and Distribution electronic systems.


**1.18.4.1.1** **(01-25-2021)**

#### Background

1. Technology and program support Branch (TPS) provides knowledge services, business applications, and accessibility support for Publishing and Distribution programs. Technology and program support Branch works closely with IRS Information Technology (IT) to make sure that all Publishing and Distribution electronic systems and applications function to provide the highest quality electronic products and services available.


**1.18.4.1.2** **(09-18-2024)**

#### Roles and Responsibilities

1. Technology and program support Branch includes three sections:



   - Technology and Governance (T&G)

   - Distribution Program Support (DPS)

   - Alternative Media Center (AMC)


**1.18.4.1.3** **(09-18-2024)**

#### Acronyms

1. We use the following acronyms throughout the IRM.




| **Acronym** | **Definition** |
| --- | --- |
| AMC | Alternative Media Center |
| CAPS | Computer Assisted Publishing System |
| CARE | Customer Assistance Relationships and Education |
| CAS | Customer Accounts System |
| COR | Contracting Officer’s Representative |
| CROPP | Core Repository of Publishing Products |
| DPS | Distribution Program Support |
| ELITE | Enterprise Logistics Information Technology |
| GPO | Government Publishing Office |
| ICPP | Internal Content Publishing Process |
| IPP | Invoice Processing Platform |
|  |  |
| M&P | Media and Publications |
| NDC | National Distribution Center |
| OSMS | Order and Subscription Management Systems |
| POC | Point of Contact |
| PPMC | Published Product Media Catalog |
| PTS | Project Tracking System |
| SME | Subject-Matter Expert |
| T&G | Technology and Governance |
| TIPS | Technology Integration and Project Support |
| TPS | Technology and program support |
| UWR | Unified Work Request |
| WCAG | Web Content Accessibility Guidelines |
| WRMS | Work Request Management System |
| XML | eXtensible Markup Language |


**1.18.4.1.4** **(01-25-2021)**

#### Related Resources

1. Available resources include:



   - Electronic Publishing website - http://www.publish.no.irs.gov

   - Forms, Instructions, and Publications - https://www.irs.gov/forms-instructions

   - Internet Content Publishing Process - http://win.web.irs.gov/icp/ts\_icp.htm

   - TS/M&P Resource Center SharePoint - https://organization.ds.irsnet.gov/sites/ts-care-MP/default.aspx

   - SharePoint Email Address - ts.mp.sharepoint.admin@irs.gov

   - Accessible Forms and Publications - https://www.irs.gov/forms-pubs/accessible-irs-tax-products

   - Order and Subscription Management System - http://caps-as.enterprise.irs.gov/osms/views/homePage.xhtml


**1.18.4.2** **(09-18-2024)**

### Technology and Governance (T&G)

1. T&G section responsibilities include:



   - Information Technology Budgeting

   - Information Technology Application Development and Program Management

   - Computer Assisted Publishing System (CAPS) Management

   - Enterprise Logistics Information Technology (ELITE) Management

   - eXtensible Markup Language (XML) Support

   - Unified Work Requests (UWR) Submission Processing

   - IRS.gov Help Desk Comments Processing


**1.18.4.2.1** **(09-18-2024)**

#### Information Technology Budgeting

1. T&G analysts manage the IT budget for CAPS and ELITE in the Media and Publications (M&P) organization. In this capacity, they:



1. Gather and monitor IT requirements

2. Meet with management to review IT requirements and budget

3. Work with appropriate IT organizations, Technology Integration and Project Support (TIPS), and M&P division technology advisors to ensure that IT requirements and budget needs are properly communicated and that funds are available for annual maintenance costs and new purchases


2. They work closely with members of other organizations (e.g., Procurement, Accounting, IT) to resolve IT issues and problems using a combination of spreadsheets and online applications (including the IT Project Tracking System (PTS), Work Request Management System (WRMS), and the Invoice Processing Platform (IPP)) to ensure requirements are funded and requisitions are processed timely.


**1.18.4.2.2** **(09-18-2024)**

#### Information Technology Application Development and Program Management

1. T&G analysts provide IT solutions to serve the business needs of the M&P user community. They collaborate with business representatives to collect data and manage business, functional, and technical requirements. The analysts identify and resolve application issues and monitor the progress of all application development. T&G analysts use the CAPS M&P IT Request and Work Request systems as communication tools to facilitate these tasks.

2. T&G analysts coordinate application software procurements for the M&P organization, including new software and services, and ongoing maintenance contracts for existing components. The analysts submit Unified Work Requests (UWR) detailing necessary updates to IT via WRMS for tracking and coordination purposes. T&G analysts create requisitions in the Invoice Processing Platform (IPP) and prepare any required supporting documents.

3. T&G participates in and provides oversight for Federal Information Security Management Act (FISMA) activities for GSS-21 (CAPS-I) and ELITE. This includes facilitating meetings with various IT business units, CyberSecurity, and system development and test team members for the Security Assessment and Authorization certification process. T&G ensures compliance with FISMA requirements that includes:



1. Planning for system security

2. Reviewing and monitoring the security controls on a regular basis

3. Participating in system security testing annually

4. Developing and maintaining action plans for remediation of security weaknesses


**1.18.4.2.3** **(09-18-2024)**

#### Computer Assisted Publishing System (CAPS) Management

1. CAPS hosts locally-developed and Commercial Off-The-Shelf (COTS) software applications that support the design, composition, requisitioning, printing procurement, and job tracking for all IRS published products. These include the Core Repository of Published Products (CROPP), the Electronic Publishing website at http://www.publish.no.irs.gov, and "Page 1," which is a group of M&P intranet pages.

2. T&G analysts manage CAPS, including database and application software maintenance and administration. IT Enterprise Operations provides operational support for CAPS hardware and system infrastructure software (including installation, upgrade and maintenance, security administration, and monitoring).

3. Contractors perform most of the technical work on CAPS. T&G contracting officer’s representatives (CORs) provide support and oversight for the contract work performed.


**1.18.4.2.4** **(09-18-2024)**

#### Enterprise Logistics Information Technology (ELITE) Management

1. T&G analysts manage ELITE. Distribution employees use ELITE to manage distribution programs, forecast printed products, and manage National Distribution Center operations. Customer Accounts System (CAS) employees enter orders into a separate ELITE application.

2. T&G analysts work with other Distribution employees to develop ELITE requirements and manage its Total Information Processing Support Services contract. Contractors perform software maintenance and interpret requirements and program changes.


**1.18.4.2.5** **(09-18-2024)**

#### eXtensible Markup Language (XML) Support

1. Through contracted staff, T&G provides XML authoring and/or composition support for a wide range of IRS published products, including tax forms instructions, taxpayer information publications, the Internal Revenue Manual (IRM), the Internal Revenue Bulletin (IRB), tax topics, and revenue procedures. This includes help desk support for XML authors Servicewide who use Arbortext Editor software.


**1.18.4.2.6** **(09-18-2024)**

#### Unified Work Requests (UWR) Submissions Processing

1. T&G analysts manage UWR submissions from M&P to the IT organization by:



   - Receiving, reviewing, and validating completeness of submissions

   - Providing assistance to M&P initiators

   - Pre-coordinating requests with IT and TS TIPS

   - Submitting UWRs in WRMS

   - Tracking the status of submissions to ensure timely responses are provided to IT


**1.18.4.3** **(09-18-2024)**

### Distribution Program Support (DPS)

1. DPS section responsibilities include:



   - M&P Knowledge Management Program

   - M&P Resource Center SharePoint Site Administration

   - IRS.gov Content Management

   - Media and Publications (M&P) Publishing and Distribution Content Management


**1.18.4.3.1** **(09-18-2024)**

#### Media and Publications (M&P) Distribution Program Support

1. M&P’s Distribution Program Support incorporates the principles of knowledge retention, knowledge management, and knowledge sharing into the M&P administrative and production framework to leverage, share, and transfer the wealth of knowledge of M&P employees to their successors, thus aiding the future success of the M&P mission.

2. DPS designs, develops, tests, implements, and promotes tools to foster knowledge collection and sharing. The tools include:



   - After-action reviews

   - Knowledge and information-sharing templates

   - Publicly available and searchable knowledge repositories

   - Process maps and lessons learned articles

   - Other tools derived from private industry and federal government best practices


3. DPS uses knowledge management expertise to provide M&P with tools to promote a knowledge-sharing environment and helps other M&P functions by:



1. Facilitating after-action reviews

2. Collecting lessons learned

3. Interviewing management-selected current and departing employees

4. Developing process maps

5. Training new M&P employees on the tools and techniques of Knowledge Management (KM)

6. Consulting on KM activities throughout the organization

7. Researching and implementing other techniques as appropriate


4. DPS solicits and analyzes submissions from M&P employees for knowledge-sharing topics, derives and drafts knowledge articles for sharing on the M&P knowledge management website, and provides expertise and assistance regarding social collaboration.


**1.18.4.3.2** **(09-18-2024)**

#### Media and Publication (M&P) Resource Center SharePoint Site Administration

1. DPS section employees administer the M&P resource center SharePoint site at https://organization.ds.irsnet.gov/sites/ts-care-MP/default.aspx in collaboration with site administrators in M&P business units. This SharePoint site contains descriptive documents and references that M&P functions use in collaborative efforts throughout M&P and affords collaboration and repository functionality amongst all M&P functions. IT manages the SharePoint infrastructure (servers), provides governance policies and standards, and resolves application issues.

2. DPS leads a team of SharePoint site administrators that includes one or more employees from the Distribution, Publishing, and Tax Forms and Publications functions of M&P. This team recommends and implements overall site policies and enforces adherence to IRS SharePoint and Web standards. Each site administrator manages their function’s sub-sites, Web content, and document libraries within their organizational and program boundaries, and the DPS site collection administrator retains responsibility for the M&P SharePoint site homepage and other cross-organizational M&P content.

3. Administration responsibilities include:



01. Create, populate, and maintain user groups

02. Manage user access rights (e.g., granting and revoking user inclusion in policy groups during temporary assignments and revoking access rights for separated employees)

03. Collect, analyze, and report on Web statistics

04. Troubleshoot and resolve user issues and elevate to the IT Help Desk when appropriate

05. Respond quickly to website outages and work with IT to restore Web access

06. Analyze and respond to user requests for SharePoint objects, such as sub-sites, custom lists, and document libraries

07. Probe and resolve broken hyperlinks

08. Provide and control access to the DSTEST development and test environment

09. Analyze, test, approve, and launch custom Web functionality

10. Respond to inquiries directed to the team's e-mail box; \*TS Map SharePoint Admin at ts.mp.sharepoint.admin@irs.gov

11. Apply and manage appropriate site features to address user business requirements (SharePoint site settings)


4. Content responsibilities include:



1. Solicit or develop fresh content for announcements on the M&P Resource Center homepage

2. Develop and manage content for the main M&P site, collaborating with the Planning and Analysis branch of M&P

3. Develop and manage content for the M&P Career Services site, collaborating with the employment specialists in the Strategic Planning and Analysis offices of each function

4. Develop and manage content for specialized content on other M&P sub-sites that cross organizational boundaries

5. Develop and maintain keyword searches for site collection


5. The site collection administrator, a DPS section employee, also has other duties in addition to the content and administration duties listed earlier. Those additional duties include:



1. Represents M&P on IRS SharePoint governance forums

2. Serves as liaison to TS SharePoint nonexecutive councils

3. Maintains website collection registration

4. Manages site collection quotas and obtains Web resources from IT as appropriate

5. Maintains overall site design to preserve standardization, usability, and consistency throughout the organization

6. Collects, analyzes, and reports on overall Web usage and other statistics

7. Ensures that function site administrators have appropriate training in SharePoint and Section 508 accessibility issues and provides coaching and assistance


**1.18.4.3.3** **(09-18-2024)**

#### IRS.gov Content Management

1. DPS analysts use a content management application to administer Web content on IRS.gov for Distribution at https:// _www.irs.gov/forms-instructions_ in their roles. Working with creators/publishers and page stewards across the division, DPS analysts manage Distribution content to ensure the information is technically correct, remains current, and is updated timely or removed as appropriate. They also work with Online Services Web analysts and Content Area Administrators from other business units as needed to revise or remove content. Detailed guidelines, procedures, roles, and responsibilities for Taxpayer Services (TS) Internet content management are maintained in IRM 11.55.1, Internet Content Publishing Process (ICPP) Management Document.


**1.18.4.3.4** **(09-18-2024)**

#### IRS.gov Help Desk Comments

1. The DPS section provides a point-of-contact (POC) for the Publishing and Distribution functions for questions relating to content pages on IRS.gov. A TS POC listing is on TS’s Internal Content Publishing Process (ICPP) page at http://win.web.irs.gov/icp/ts\_icp.htm.

2. Any IRS.gov website user can submit an inquiry about the website by email, telephone call, or Web chat to the IRS.gov Help Desk (Help Desk). An inquiry can be a question, problem, or comment regarding the Web content and IRS programs. The Help Desk answers most inquiries received from the public within 24 hours.

3. When an inquiry reaches the Help Desk, DPS checks it against a repository of known issues, e.g., pre-recorded (pre-determined) responses and Frequently Asked Questions (FAQs). DPS escalates inquiries the Help Desk cannot address to the TS IRS.gov POC.

4. If the inquiry falls within TS’s purview, then DPS sends it to the TS POC assigned to respond to Help Desk emails.



### Note:



DPS forwards tax account-related inquiries that require interpretation of tax laws and procedures to the appropriate IRS function for response.





1. The POC determines which subject-matter expert (SME) within TS would be the most appropriate party to answer the questions and designates a response timeframe

2. The Help Desk determines the priority and designates a response timeframe

3. The TS POC forwards the email to the identified SME for response

4. The SME answers the inquiry and sends an e-mail back to the POC, who formats the response and sends it to the Help Desk with a copy to the TS organization mailbox

5. The TS POC keeps a copy of the e-mail in the personal folder


**1.18.4.4** **(09-18-2024)**

### Alternative Media Center (AMC)

1. The AMC provides alternative media resources to employees and taxpayers through publishing support for format selection, acquisition, production, and delivery of IRS products required in accessible file formats.


**1.18.4.4.1** **(09-18-2024)**

#### Alternative Media Center (AMC) Products

1. The AMC offers more than 1,800 alternative media formats of IRS published products. The items produced are a combination of public-facing and non-public-facing products.



### Note:



Non-public products include all items listed in public products.







**Public Products**






| **Product Type** | **Formats Available** |
| --- | --- |
| Tax Forms | Braille, e-Braille, large print, Section 508 compliant PDF and text |
| Tax Instructions | Accessible HTML, Braille, eBraille, e-Pub, large print and text |
| Tax Publications | Accessible HTML, Braille, e-Braille, e-Pub, large print and text |
| Taxpayer Notices (External) | Audio, Braille, eBraille, large print and text |







**Non-Public Products**






| **Product Type** | **Formats Available** |
| --- | --- |
| Documents | Accessible HTML, Braille, e-Braille, large print, Section 508 compliant PDF and text |
| Internal Forms | Braille, e-Braille, large print, Section 508 compliant PDF and text |
| Letters | Braille, e-Braille, large print, Section 508 compliant PDF and text |
| Notices (internal) | Braille, e-Braille, large print, Section 508 compliant PDF, audio and text |
| Training Publications | Accessible HTML, Braille, e-Braille, large print, Section 508 compliant PDF and text |








| **Foreign Language Alternative Media** |
| :-: |
| The following languages are available in alternative media formats. Additional languages may be available in the future. |
| **Alternative Media Format** | **Languages** |
| Braille, text, accessible HTML and audio | - English<br>     <br>   - Spanish |
| Large Print and Section 508 compliant PDF forms | - English<br>     <br>   - Spanish<br>     <br>   - Chinese - Traditional<br>     <br>   - Chinese - Simplified<br>     <br>   - Russian<br>     <br>   - Korean<br>     <br>   - Vietnamese |

2. Staff produces alternative media products in both electronic and hard copy formats through:



**Alternative Media Products**






| **Product Type** | **Products** |
| --- | --- |
| Government Publishing Office (GPO) Contracts | - Program 0106-S: Large Print Product<br>     <br>   - Program 1561-S: Section 508 Compliant PDF Files<br>     <br>   - Program 1582-S: Accessible Electronic Media and Document Accessibility Support<br>     <br>   - Program 3571-S: Braille Products<br>     <br>   - Program 3591-S: Braille Products (Ability One Program) |
| IRS-owned production facility | The AMC operates a production facility using high-speed embossers and printers to process Braille and large print orders. The facility is an on-demand operation that serves employees and taxpayers. In addition, AMC employees perform file management for these formats on multiple systems and applications including Enterprise Logistics Information Technology (ELITE), and the Published Product Media Catalog (PPMC), to ensure uninterrupted distribution of accessible media through mainstream channels. |
| Conversion Tools | AMC employees use conversion and transcription software to produce Braille, audio, text, and large print files. Remediation software is used to make PDF files comply with Section 508 of the Rehabilitation Act of 1973. |

3. AMC products can be ordered by employees and taxpayers.



**Products Available to Employees and Taxpayers**






| **Who can order...** | **How to order...** |
| --- | --- |
| Employees | - Download accessible media from the Product Catalog Information page at http://publish.no.irs.gov/catlg.html<br>     <br>   - Visit the Order page at http://amc.enterprise.irs.gov/order.html on the AMC intranet site<br>     <br>   - Contact the AMC Helpdesk at altmc@irs.gov<br>     <br>   - Use the Order and Subscription Management System (OSMS) at https://caps-as.enterprise.irs.gov/osms/views/homePage.xhtml |
| Taxpayers | - Download accessible tax products from the Accessibility pages at https://www.irs.gov/forms-pubs/accessible-irs-tax-products on IRS.gov<br>     <br>   - Request paper copies of Braille or large print tax products by calling the tax form toll-free telephone number at 800-829-3676<br>     <br>   - Receive notices in alternative formats<br>     <br>     <br>     <br>     1. The IRS process for receiving notices allows visually impaired taxpayers to request post-filing tax correspondence in Braille, large print, audio (mp3) or electronic formats. This includes notices about additional taxes or penalties owed.<br>        <br>     2. Taxpayers with a print disability can elect to receive IRS correspondence in their preferred alternative format by:<br>        <br>        <br>        <br>        1. Completing Form 9000, **Alternative Media Preference** and filing it with their tax return or by mailing it separately to the following address:<br>           <br>           <br>           <br>           > Department of the Treasury<br>           <br>           <br>           <br>           <br>           <br>           > Internal Revenue Service<br>           <br>           <br>           <br>           <br>           <br>           > Kansas City, MO 64999-0002<br>           <br>        2. Call the tax assistance number at (800)-829-1040<br>           <br>        3. Elect their alternative media preference using their online account |

4. AMC products are delivered based on the following turnaround times.



**AMC Deliverable Schedule**






| **Product** | **Deliverable Timeframe** |
| --- | --- |
| Braille and large print products (in production facility are embossed/printed) | 7 to 10 business days |
| Electronic files | Immediate download |
| **Products Requiring Conversion** |  |
| - Accessible HTML<br>     <br>   - Accessible MS Office files<br>     <br>   - Braille and e-Braille<br>     <br>   - Section 508 compliant PDF<br>     <br>   - Text<br>     <br>   - Large Print | - up to 3 weeks<br>     <br>   - up to 10 business days<br>     <br>   - 2 to 6 weeks<br>     <br>   - up to 10 business days<br>     <br>   - 2 to 4 weeks<br>     <br>   - up to 10 business days |


**1.18.4.4.2** **(03-23-2022)**

#### AMC Services

1. The AMC provides the following services:



1. _Accessibility Help Line_ \- IRS established an Accessibility Helpline to answer questions related to current and future accessibility services and tax information in alternative media formats (i.e., Braille, large print, audio, etc.) available to taxpayers with print disabilities. Taxpayers who need accessibility assistance can call 833-690-0598. Assistance for multilingual taxpayers is also available on the helpline via the Over-the-Phone Interpreter service. The new helpline does not have access to taxpayers’ IRS accounts. Those needing help with tax law, refunds or other account-related issues, should visit the Let Us Help You page.

2. **Customized accessibility solutions** \- The AMC works one-on-one with customers to meet their individual accessibility needs.

3. **Document Accessibility consulting** \- The AMC works with employees to ensure their electronic content is accessible by people with disabilities and meets the Web Content Accessibility Guidelines (WCAG) and Section 508 standards.

4. **Helpdesk services** \- The AMC Helpdesk staff is available to assist employees Monday through Friday from 8:00 AM to 4:00 PM ET by e-mail at altmc@irs.gov. Employees can place orders for alternative media, inquire about the status of orders or get technical support for making electronic content accessible. All incoming requests are assigned a ticket number and placed in a contact management database for tracking purposes.

5. **Review and remediation for Section 508 compliance**\- The AMC can make PDF files accessible for people using assistive technology and can review and add accessibility to Microsoft Office files including Word, Excel and PowerPoint. The AMC works with employees to review and remediate electronic content to meet the requirements in the WCAG and Section 508 standards.

6. **Training and tutorials**\- The AMC provides HowTube videos and training tools for authors in the Learn section on the AMC intranet site at http://amc.enterprise.irs.gov/. IRS employees can also take the following courses in the AMC Section 508 curriculum on the Integrated Talent Management platform.



      **AMC Section Curriculum**






      | **The 508 Course Curriculum** |
      | --- |
      | - 70100 - Introduction to Section 508 Curriculum<br>        <br>      - 70101 - Techniques for Creating Section 508 Compliant MS Word File<br>        <br>      - 70102 - Techniques for Creating Section 508 Compliant MS Excel Files<br>        <br>      - 70103 - Techniques for Creating Section 508 Compliant MS PowerPoint Files<br>        <br>      - 70104 - Techniques for Creating Section 508 Compliant PDFs using Adobe Acrobat - Basic<br>        <br>      - 70105 - Techniques for Creating Section 508 Compliant PDFs using Adobe Acrobat - Advanced<br>        <br>      - 70106 - Writing Alternative Text for Section 508 Compliance<br>        <br>      - 70107 - Using CommonLook PDF to Create Section 508 Compliant PDF files<br>        <br>      - 70110 – Providing Alternative Media for Taxpayers with Disabilities |

7. **Web Services** \- IRS employees can visit the AMC intranet site at http://amc.enterprise.irs.gov/ to request services, order alternative media and learn about the latest accessibility requirements, including tools to make electronic content compliant with Section 508.



      **Accessible Formats**






      | The Accessibility pages at https://www.irs.gov/forms-pubs/accessible-irs-tax-products on IRS.gov provide taxpayers with accessible tax products in the following formats: |
      | :-- |
      | - Section 508-compliant PDF files<br>        <br>      - Braille (e-Braille) and text tax forms, instructions and publications<br>        <br>      - Large print forms, instructions and publications<br>        <br>      - HTML format for tax instructions and publications<br>        <br>      - e-Pub format to view tax products on mobile devices |


2. IRS employees can request these services using the following methods:



1. Visit the Request Section at http://amc.enterprise.irs.gov/request.html on the AMC intranet site

2. Contact by email the AMC Helpdesk at altmc@irs.gov


**1.18.4.4.3** **(09-18-2024)**

#### Accessible Taxpayer Notices and Letters

1. Taxpayers can complete _Form 9000_, Alternative Media Preference, to choose to receive their IRS tax notices in Braille, large print, audio or electronic formats. This includes notices about additional taxes or penalties owed. Taxpayers can include the completed form with their tax return, call 800- 829-1040, elect it on their online account, or mail it as a standalone form to the IRS at the Address below to request their preferred format.



> Department of the Treasury - Internal Revenue Service - Kansas City, MO 64999-0002

2. If the taxpayer already received a notice or letter in print format and prefers it in Braille, large print, audio, or text, choose one of the three options below to request your preference.



1. The taxpayer can call the tax assistance number at 800-829-1040

2. The taxpayer or Customer Service Representative can fax the notice and a cover sheet to: Alternative Media Center, at 855-473-2006. On the cover sheet, write "Alternative Media Format" at the top and include taxpayer's name, address, daytime phone number and preferred alternative media format.

3. The taxpayer can mail their notice with a note stating their preferred format (Braille, large print, audio, or text) to: Internal Revenue Service, Alternative Media Center, 400 N. 8th St. Room G39, Richmond, VA 23219


3. Once the AMC receives your notice, it will take up to 15 business days to convert it to your preferred format and mail it back to you.


**1.18.4.4.4** **(09-18-2024)**

#### AMC Marketing and Collaboration

1. Promoting accessible tax products and developing partnerships with disability organizations to better understand taxpayer preferences.

2. Utilizing IRS social media accounts to provide continuous information to taxpayers about the accessible tax products available on IRS.gov.

3. Building relationships with advocacy groups who support people with disabilities and the aging population to better understand their needs.

4. Increasing focused outreach in underserved communities to engage with taxpayers and provide information about accessibility services provided by the IRS.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-018-004#addtoany "Show all")

A2A