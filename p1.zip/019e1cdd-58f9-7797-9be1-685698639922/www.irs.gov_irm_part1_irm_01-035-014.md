---
url: "https://www.irs.gov/irm/part1/irm_01-035-014"
title: "1.35.14 IRS Annual Financial Statement Audit | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-035-014#main-content)

- 1.35.14  [IRS Annual Financial Statement Audit](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410104000)
  - 1.35.14.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410015152)
    - 1.35.14.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955383123120)
    - 1.35.14.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955383121024)
    - 1.35.14.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410100112)
      - 1.35.14.1.3.1  [Commissioner](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955382542688)
      - 1.35.14.1.3.2  [Chief Operating Officer](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955382540736)
      - 1.35.14.1.3.3  [Management Controls Executive Steering Committee](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955382949184)
      - 1.35.14.1.3.4  [CFO and Deputy CFO](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955382945376)
      - 1.35.14.1.3.5  [Senior Associate CFO for Financial Management](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955383116560)
      - 1.35.14.1.3.6  [Senior Associate CFO for Financial Management, Policy and Data Analytics, Audit Coordination and Quality Control](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955382961088)
      - 1.35.14.1.3.7  [Associate CFO for Internal Controls](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410118848)
      - 1.35.14.1.3.8  [Associate CFO for Internal Controls, Assurance Review and Testing](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410115456)
      - 1.35.14.1.3.9  [Chief Risk Officer](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410095744)
      - 1.35.14.1.3.10  [Chief Risk Officer - Enterprise Audit Management (CRO-EAM)](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410094128)
      - 1.35.14.1.3.11  [Chief Information Officer](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410090512)
      - 1.35.14.1.3.12  [Associate Chief Information Officer, Cybersecurity](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410113312)
      - 1.35.14.1.3.13  [Associate Chief Information Officer, Strategy and Planning](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410110704)
      - 1.35.14.1.3.14  [Chief Counsel](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410104752)
      - 1.35.14.1.3.15  [Director, Office of Legislative Affairs](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955381707488)
      - 1.35.14.1.3.16  [All Business Units](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955381705760)
    - 1.35.14.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955381697824)
    - 1.35.14.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955381671808)
    - 1.35.14.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955381665440)
    - 1.35.14.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955381678112)
    - 1.35.14.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410126432)
    - 1.35.14.1.9  [Forms](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410084224)
  - 1.35.14.2  [Audit Components](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410074704)
    - 1.35.14.2.1  [Financial Management Audit Component](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410073232)
      - 1.35.14.2.1.1  [Corporate Accounting](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410070544)
      - 1.35.14.2.1.2  [Revenue Financial Accounting](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410068592)
      - 1.35.14.2.1.3  [Internal Controls](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410066784)
    - 1.35.14.2.2  [Information Security](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410064992)
  - 1.35.14.3  [Key Events/Products of the Financial Audit](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955414998960)
    - 1.35.14.3.1  [Protocol Document](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955414997136)
    - 1.35.14.3.2  [Audit Notification Letter](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955414995184)
    - 1.35.14.3.3  [Authority to Disclose Tax Information](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955414992128)
    - 1.35.14.3.4  [Prepared By Client Deliverables](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955414988848)
    - 1.35.14.3.5  [Audit Engagement Letter](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955414985408)
    - 1.35.14.3.6  [Audit Entrance Conference](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955414982352)
    - 1.35.14.3.7  [Program and Internal Controls Walkthroughs](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955414980544)
    - 1.35.14.3.8  [Client Profile](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955414978720)
    - 1.35.14.3.9  [Fraud Risk Factors Data Request](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955414975696)
    - 1.35.14.3.10  [Testing - Internal Control and Substantive](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955414973632)
    - 1.35.14.3.11  [Legal Representation Letter](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955414969968)
    - 1.35.14.3.12  [Delivery of Management’s Discussion and Analysis](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410061232)
    - 1.35.14.3.13  [Delivery of Financial Statements](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410058272)
    - 1.35.14.3.14  [Management Representation Letter](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410048992)
    - 1.35.14.3.15  [Exit Conference](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410046304)
    - 1.35.14.3.16  [Financial Statements and Audit Opinion Issued](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410042896)
    - 1.35.14.3.17  [Statement of Facts](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410035792)
    - 1.35.14.3.18  [Management Reports](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410031296)
    - 1.35.14.3.19  [180-day Reports to Congress](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410026368)
    - 1.35.14.3.20  [Recommendation and PCA Management](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955410022384)
    - 1.35.14.3.21  [Remediation Plans](https://www.irs.gov/irm/part1/irm_01-035-014#idm139955383103088)

# Part 1. Organization, Finance, and Management

# Chapter 35. Financial Accounting

# Section 14. IRS Annual Financial Statement Audit

* * *

## 1.35.14 IRS Annual Financial Statement Audit

#### Manual Transmittal

April 09, 2025

#### Purpose

(1) This transmits revised IRM 1.35.14, Financial Accounting, IRS Annual Financial Statement Audit.

#### Material Changes

(1) IRM 1.35.14.1, Program Scope and Objectives, updated for clarity and revised title for Senior Associate CFO for Financial Management.

(2) IRM 1.35.14.1.2, Authorities, revised.

(3) IRM 1.35.14.1.3, Responsibilities, revised titles for Senior Associate CFO for Financial Management and Policy and Data Analytics, Audit Coordination and Quality Control.

(4) IRM 1.35.14.1.3.5, Senior Associate CFO for Financial Management, clarified and revised titles for Senior Associate CFO for Financial Management, Corporate Accounting and Revenue Financial Accounting.

(5) IRM 1.35.14.1.6, Terms/Definitions, added planned corrective action and remediation plan.

(6) IRM 1.35.14.1.7, Acronyms, added COO, MC ESC, MW, REM, SD and SOF.

(7) IRM 1.35.14.1.8, Related Resources, updated.

(8) IRM 1.35.14.1.9, Forms, updated.

(9) IRM 1.35.14.2, Audit Components, revised.

(10) IRM 1.35.14.3.1, Protocol Document, added.

(11) IRM 1.35.14.3.3, Authority to Disclose Tax Information, added.

(12) IRM 1.35.14.3.8, Client Profile, added.

(13) IRM 1.35.14.3.17, Statement of Facts, added.

(14) IRM 1.35.14.3.19, 180-day Reports To Congress, revised.

(15) Prior IRM 1.35.14.3.16, Information Security Control Reports, section deleted.

(16) Prior IRM 1.35.14.3.17, 180-Day Information Security Control Reports’ Response, section deleted.

(17) Prior IRM 1.35.14.3.18.1, Management Report (FMA), section deleted.

(18) Prior IRM 1.35.14.3.18.2, Information Security Control Reports, section deleted.

(19) Prior IRM 1.35.14.3.19, Annual Open Audit Recommendation Update (Management Report), section deleted.

(20) Prior IRM 1.35.14.3.20, Open Audit Recommendation Update (Information Security Control Reports), section deleted.

(21) IRM 1.35.14.3.21, Remediation Plans, added.

(22) Throughout IRM - Made minor writing edits for clarity and precision and updated office names to correspond with organizational changes within CFO.

#### Effect on Other Documents

IRM 1.35.14, dated July 24, 2020, is superseded.

#### Audience

All business units.

#### Effective Date

(04-09-2025)

Teresa R. Hunter

Chief Financial Officer

**1.35.14.1** **(04-09-2025)**

### Program Scope and Objectives

1. Purpose:



1. This IRM contains an overview of the annual audit lifecycle of the IRS financial statements to provide business units with a general understanding of the overall process.

2. This IRM provides information and guidance on the audit process and responsibilities for all stakeholders throughout the audit lifecycle from the planning phase through the closure of planned corrective actions for recommendations.

3. This IRM also includes information related to the issuance of significant deficiencies, material weaknesses, remediation plans and the recordation of planned corrective actions (PCAs) in the Joint Audit Management Enterprise System (JAMES) as they relate to the IRS financial statement audit process.


2. Audience: Business unit employees responsible for financial statement audit activities.

3. Policy Owner: Chief Financial Officer (CFO), Senior Associate CFO for Financial Management.

4. Program Owner: CFO, Senior Associate CFO for Financial Management.

5. Primary Stakeholders: Business units that are involved with the financial statement audit.

6. Program Goals:



1. Secure unmodiﬁed audit opinion on the IRS ﬁnancial statements.

2. Cultivate a collaborative partnership between external oversight and IRS Officials to establish trust and confidence.

3. Facilitate the audit process, ensuring auditors have access to the people and information they need to conduct each audit, while at the same time resolving any issues that arise during the audit.

4. Ensure a consistent and repeatable audit process within the IRS and between the IRS and its oversight entities.

5. Mitigate audit findings and issues to minimize or eliminate auditor issuance of recommendations, significant deficiencies, material weaknesses or the need for remediation plans.


**1.35.14.1.1** **(07-24-2020)**

#### Background

1. The CFO Act of 1990, expanded by the Government Management Reform Act of 1994, authorizes the Government Accountability Office (GAO) to audit the IRS financial statements annually to determine whether (1) the financial statements are fairly presented and (2) IRS management maintained effective internal control over financial reporting. GAO also tests IRS’s compliance with selected provisions of applicable laws, regulations, contracts and grant agreements. The IRS’s FY 1992 financial statements were the first to be audited by GAO.

2. The IRS financial statement audit has implications beyond the IRS. The IRS’s financial statements roll up to the Department of the Treasury (Treasury) financial statements and Treasury's financial statements roll up to the governmentwide consolidated financial statements. An unfavorable audit opinion on the IRS financial statements impairs GAO's ability to rely on the Treasury and governmentwide financial statements to render an unmodified audit opinion for the federal government.

3. The GAO also reports annually on the status of new internal financial management audit (FMA) and/or information security (IS) control weaknesses and/or deficiencies identified during its audit of the financial statements and provides updates on IRS efforts toward previously reported GAO recommendations in management reports (Public and Limited Official Use (LOU)).

4. Obtaining an unmodified audit opinion demonstrates to Congress and the public that the IRS accurately accounts for tax revenue receipts, tax refunds and IRS appropriated funds.


**1.35.14.1.2** **(04-09-2025)**

#### Authorities

1. The authorities for this IRM include:



1. [Chief Financial Officers Act of 1990](https://www.congress.gov/bill/101st-congress/house-bill/5687/text)(Pub. L. No. 101-576)

2. [Federal Managers Financial Integrity Act of 1982](https://www.congress.gov/bill/97th-congress/house-bill/1526/text)(Pub. L. No. 97-255)

3. The Federal Financial Management Improvement Act of 1996 (FFMIA) [Omnibus Consolidated Appropriations Act, 1997](https://www.congress.gov/bill/104th-congress/house-bill/3610/text)(Pub. L. No. 104-208)

4. Good Accounting Obligation in Government Act of 2019 or the [GAO-IG Act](https://www.congress.gov/bill/115th-congress/senate-bill/2276/text)(Pub. L. No. 115-414)


**1.35.14.1.3** **(04-09-2025)**

#### Responsibilities

1. This section provides responsibilities for:



01. Commissioner

02. Chief Operating Officer (COO)

03. Management Controls Executive Steering Committee (MC ESC)

04. CFO and Deputy CFO

05. Senior Associate CFO for Financial Management

06. Senior Associate CFO for Financial Management, Policy and Data Analytics, Audit Coordination and Quality Control

07. Associate CFO for Internal Controls

08. Associate CFO for Internal Controls, Enterprise Assurance and Controls

09. Chief Risk Officer (CRO)

10. Chief Risk Officer, Enterprise Audit Management (CRO-EAM)

11. Chief Information Officer (CIO)

12. Associate Chief Information Officer (ACIO), Cybersecurity

13. Associate Chief Information Officer, Strategy and Planning

14. Chief Counsel

15. Director, Office of Legislative Affairs

16. All business units, including: audit liaisons and JAMES coordinators


**1.35.14.1.3.1** **(04-09-2025)**

##### Commissioner

1. The Commissioner has overall organizational responsibility for the annual IRS financial statement audit by concurring with the audit engagement letter, attesting to the management representation letter, responding to the draft audit and draft management reports, submitting the 180-day management responses to the appropriate congressional committees, and ensuring that audit recommendations are implemented.


**1.35.14.1.3.2** **(07-24-2020)**

##### Chief Operating Officer

1. The COO has organizational responsibility, on behalf of the Commissioner, for the annual IRS financial statement audit. The COO is also responsible for concurring with the audit engagement letter, attesting to the management representation letter and ensuring that recommendations are implemented.


**1.35.14.1.3.3** **(04-09-2025)**

##### Management Controls Executive Steering Committee

1. The MC ESC membership is comprised of key senior executive stakeholders, and its mission is to oversee management’s design, implementation and operation of the IRS internal control system by ensuring that all business units identify, address and correct internal control deficiencies and recognize the importance of their shared responsibility for designing and implementing strong internal controls.

2. The MC ESC’s objectives are to build a strong relationship between risk management and internal controls to ensure existing and new controls address identified risks effectively, ensure the remediation of existing control weaknesses and prevent new ones from arising, provide an unmodified statement of assurance that the IRS’s internal controls are in place and functioning effectively and achieve an unmodified opinion on the IRS financial statement audit.

3. The MC ESC also oversees processes to identify, remediate and close significant deficiencies (SD), material weaknesses (MW), remediation (REM) plans and other internal control issues, including identifying and documenting new SD’s, MW’s and/or REM plans; approving remediation plan actions for existing material weaknesses or FFMIA non-compliance; ensuring business units and program owners apply appropriate attention, commitment and resources to resolve control issues; authorizing engagement with GAO on the downgrade or closure of an existing SD, MW, or REM plan; and reviewing GAO and Treasury Inspector General for Tax Administration (TIGTA) identified management challenges and high-profile audits.


**1.35.14.1.3.4** **(04-09-2025)**

##### CFO and Deputy CFO

1. The CFO and the Deputy CFO are responsible for overseeing the financial statement audit.

2. The CFO and the Deputy CFO are also responsible for acknowledging and agreeing to the terms of the audit, as stated in the engagement letter; attesting to the management representation letter; signing the management reports; issuing the request for the legal representation response to Chief Counsel; ensuring that recommendations are implemented; ensuring that SD, MW and REM plans are created and worked (if applicable); and ensuring that existing MW and REM plans are updated and submitted on a quarterly basis to external stakeholders (as appropriate).


**1.35.14.1.3.5** **(04-09-2025)**

##### Senior Associate CFO for Financial Management

1. The Senior Associate CFO for Financial Management is responsible for managing an effective, efficient and responsive annual financial statement audit process for the IRS. This includes facilitating the audit opening and exit conferences, coordinating and delivering the financial statements and related notes to GAO; preparing the engagement letter, management representation letter, draft audit opinion response, management report responses and 180-day reports to Congress for the Commissioner’s signature and delivering the signed responses to external stakeholders (as appropriate).

2. The Senior Associate CFO for Financial Management also coordinates activities for the Corporate Accounting and Revenue Financial Accounting organizations. Key activities include managing audit deliverables, cycle memorandum updates, issuing the annual fraud risk factors data and legal representation letter requests, facilitating audit-related meetings, reporting to leadership on the audit status, ensuring corrective actions are developed to address recommendations, ensuring that SD, MW and REM plans are created and worked (if applicable) and ensuring that existing MW and REM plans are updated and submitted on a quarterly basis to external stakeholders (as appropriate).


**1.35.14.1.3.6** **(04-09-2025)**

##### Senior Associate CFO for Financial Management, Policy and Data Analytics, Audit Coordination and Quality Control

1. The Senior Associate CFO for Financial Management, Policy and Data Analytics, Audit Coordination and Quality Control (ACQC) section is responsible for the following overall financial statement audit activities:



01. Facilitating the audit opening and exit conferences between GAO and IRS senior management.

02. Coordinating, preparing and delivering the annual update to the client profile and fraud risk factors response to GAO.

03. Coordinating, preparing and delivering the engagement letter response to GAO.

04. Preparing and delivering the draft audit response to GAO.

05. Coordinating, preparing and delivering the draft audit report response to GAO.

06. Coordinating and managing JAMES-related activities for the financial statement audit, including creating SD, MW or REM plans, entering new recommendations, sending audit summary reports to the business units, approving PCA extension and closure requests, validating receipt and loading of reports, providing business unit guidance and reopening recommendations in JAMES.

07. Managing the GAO financial statement audit interagency agreement.

08. Reporting status of prior-year open recommendations, including those on any SD, MW, or REM plan to GAO.

09. Coordinating and managing both internal and external reporting on any SD, MW and REM plan.

10. Coordinating business unit updates to, and/or developing revised PCAs for, prior-year open recommendations.


2. The Senior Associate CFO for Financial Management, Policy and Data Analytics, Audit Coordination and Quality Control section is also responsible for the following activities for the FMA component of the financial statement audit:



1. Serving as the primary point of contact for the Corporate Accounting and Revenue Financial Accounting subcomponents of the audit, including providing financial/audit information and support to the IRS business units.

2. Securing IRS/GAO agreement on, monitoring timely delivery of, and updating the prepared by client (PBC) listing, as appropriate.

3. Conducting the IRS/GAO FMA status meetings.

4. Coordinating and responding to GAO on all FMA Matter for Further Consideration (MFC) responses.

5. Coordinating business unit developed PCAs for new recommendations identified in the draft management report.

6. Coordinating, preparing and delivering the draft management report response to GAO.

7. Preparing the review process and tracking delivery of the final 180-day management report response to the congressional committees.


3. The Senior Associate CFO for Financial Management, Policy and Data Analytics, Audit Coordination and Quality Control section is also responsible for the following activities for the Information Security (IS) component of the financial statement audit:



1. Developing, tracking and delivering the draft management report responses to GAO.

2. Developing, tracking and delivering the 180-day management report responses for the congressional committees.


**1.35.14.1.3.7** **(07-24-2020)**

##### Associate CFO for Internal Controls

1. The Associate CFO (ACFO) for Internal Controls is responsible for coordinating MC ESC activities on behalf of the COO; overseeing and monitoring IRS management’s assessment of its internal controls over financial reporting to verify compliance with Office of Management and Budget (OMB) Circular No. A-123, Management’s Responsibility for Enterprise Risk Management and Internal Control; and establishing program governance, defining scope of review and reporting on the internal controls over financial reporting.

2. The ACFO for Internal Controls also coordinates activities for the internal controls subcomponent of the audit. Key activities include managing audit deliverables, facilitating audit-related meetings, preparing and delivering the Management’s Discussion and Analysis (MD&A) that is incorporated into the audit report, ensuring corrective actions are developed to address internal control audit findings and preparing and delivering the management’s report on internal controls over financial reporting to GAO.


**1.35.14.1.3.8** **(07-24-2020)**

##### Associate CFO for Internal Controls, Assurance Review and Testing

1. The ACFO for Internal Controls, Assurance Review and Testing section is responsible for:



1. Serving as the primary point of contact for the internal control subcomponent of the audit.

2. Updating and/or securing IRS/GAO agreement on the internal control PBC listing, as appropriate.

3. Monitoring the timely delivery of the internal control PBC listing deliverables.

4. Preparing and delivering management’s report on internal control over financial reporting to GAO.


**1.35.14.1.3.9** **(07-24-2020)**

##### Chief Risk Officer

1. The CRO is responsible for the high-level oversight of all audit programs for the IRS.


**1.35.14.1.3.10** **(04-09-2025)**

##### Chief Risk Officer - Enterprise Audit Management (CRO-EAM)

1. The CRO-EAM is responsible for:



1. Receiving and disseminating the financial statement audit notification letter(s).

2. Coordinating and managing JAMES-related activities with Treasury and GAO, including notating GAO’s concurrence of recommendation closures in JAMES.

3. Performing quality assurance reviews regarding PCA implementations.


**1.35.14.1.3.11** **(04-09-2025)**

##### Chief Information Officer

1. The CIO is responsible for coordinating activities for the IS audit component. Key activities include managing audit deliverables, facilitating audit-related meetings, preparing responses to GAO reports related to IS and ensuring corrective actions are developed to address audit findings and reporting to management on the status of the IS audit components.


**1.35.14.1.3.12** **(04-09-2025)**

##### Associate Chief Information Officer, Cybersecurity

1. The ACIO, Cybersecurity is responsible for coordinating with information technology organizations and the Senior Associate CFO for Financial Management, Policy and Data Analytics, Audit Coordination and Quality Control, to ensure corrective actions, internal controls and mitigations are developed and implemented for audit findings, significant deficiencies, material weaknesses and remediation plans.

2. The ACIO, Cybersecurity, Cyber Threat Response and Remediation, Oversight and Strategic Management, Compliance, Assessment and Validation (CAV) is responsible for reviewing and validating corrective actions.


**1.35.14.1.3.13** **(04-09-2025)**

##### Associate Chief Information Officer, Strategy and Planning

1. The ACIO, Strategy and Planning, Business Planning and Risk Management, Program Oversight Coordination (PO) is responsible for:



1. Serving as the primary point of contact for the IS subcomponent of the audit.

2. Managing the timely delivery of the IS PBC deliverables.

3. Responding to all IS MFCs and submitting them to ACQC.

4. Coordinating and conducting the IRS/GAO IS audit status meetings, as needed.

5. Coordinating the review of the Statement of Facts within IT and providing comments or proposed changes to ACQC.

6. Coordinating the review of the draft management reports within IT and providing comments in response to ACQC.

7. Managing JAMES updates for information technology.

8. Coordinating the development of new corrective action plans for IS audit recommendations, as needed.


**1.35.14.1.3.14** **(09-04-2018)**

##### Chief Counsel

1. The Chief Counsel is responsible for preparing and delivering the legal representation letter to GAO.


**1.35.14.1.3.15** **(04-09-2025)**

##### Director, Office of Legislative Affairs

1. The director, Office of Legislative Affairs, is responsible for delivering the 180-day management report responses to the congressional committees after securing the response from the Commissioner.


**1.35.14.1.3.16** **(04-09-2025)**

##### All Business Units

1. All business units are responsible for:



01. Ensuring adequate internal controls related to processes and procedures are identified, developed, implemented and are working effectively, thereby ensuring accuracy and reliability in accounting and operating data and/or transaction flows.

02. Identifying audit liaisons, JAMES coordinators, and subject matter experts, as appropriate.

03. Providing input into the annual draft PBC roll-forward processes (FMA and IC subcomponents) and facilitating delivery of PBC items, as appropriate.

04. Providing input into the annual cycle memorandum update processes, as appropriate.

05. Facilitating and participating in GAO walkthroughs and site visits, as appropriate.

06. Attending audit meetings and conference calls, collaborating with other business units on cross-functional audit-related activities and providing support for all GAO testing, as appropriate.

07. Responding timely to GAO on all business unit specific questions and audit inquiry forms.

08. Responding timely to the Senior Associate CFO for Financial Management or CIO, as appropriate, on all business unit specific MFC responses.

09. Collaborating with the Senior Associate CFO for Financial Management or CIO, as appropriate, on the establishment and/or revision of MFCs and/or GAO audit recommendation PCAs.

10. Requesting that the appropriate office approve/enter PCA extensions, modify existing PCAs or add new PCAs for existing recommendations in JAMES.

11. Providing documentation and requesting the appropriate office validate closure of GAO audit recommendation PCAs in JAMES (based on Form 13872, Planned Corrective Action (PCA) Status Update for TIGTA/GAO/MW/SD/TAS/REM Reports, and supporting documentation).


**1.35.14.1.4** **(04-09-2025)**

#### Program Management and Review

1. Reports and tools used to manage the audit process are:



1. Current-year PBC listings.

2. Current-year MFC issues, responses and auditor conclusions.

3. Current-year walkthrough and site visit schedules.

4. GAO recommendations.

5. Current-year testing plans.


2. Program effectiveness is measured by:



1. Securing an unmodified audit opinion from GAO.

2. Securing GAO concurrence to close open recommendations.


**1.35.14.1.5** **(04-09-2025)**

#### Program Controls

1. The following controls are in place to ensure compliance with the financial statement audit program:



1. Receipt of Joint Committee on Taxation notification indicating that GAO has been granted access to taxpayer information.

2. Approved auditor access listings.

3. Centralized management of PBC listings and related processes.

4. Centralized management of requests for PBCs, Audit Inquiry Forms and MFCs.

5. Centralized review and approval of MFC responses.

6. Centralized review and approval of all completed PCAs for open recommendations and MFCs by the Senior Associate CFO for Financial Management, Policy and Data Analytics, Audit Coordination and Quality Control.

7. Centralized review and validation of all IS completed PCAs for open recommendations by the ACIO, Cybersecurity, CAV.

8. JAMES serves as an electronic repository for recommendation PCA documentation.

9. Status meetings with IRS stakeholders and GAO auditors as needed.


**1.35.14.1.6** **(04-09-2025)**

#### Terms/Definitions

1. The following terms and definitions apply to this program:



01. **Audit inquiry form** \- An official request from GAO for clarification or additional information.

02. **Audit opinion** \- A professional opinion offered by a qualified internal or external auditor at the close of an audit of financial records. The opinion describes the processes used during auditing, the standards used by the auditor and other relevant information. It indicates whether the auditor believes that the financial records inspected support the financial statements.

03. **Audit recommendation** \- The auditor's prescribed course of action to address issues that are not specified in the audit opinion but have been identified by the auditor as areas needing improvement (usually as a result of concerns around internal control).

04. **Cycle memorandum** \- A document used by GAO during the audit planning phase that details the understanding of processes and procedures in relation to transaction flows and related internal controls in key audit areas (also known as cycles).

05. **Internal control** \- A process for assuring achievement of an organization's objectives in operational effectiveness and efficiency, reliable financial reporting and compliance with laws, regulations and policies.

06. **Internal control testing** \- A process used by the auditors to assess whether internal controls are properly designed, placed in operation and operating effectively. These tests are conducted on a sample basis.

07. **Material weakness** \- A deficiency, or a combination of deficiencies, in internal control, such that there is a reasonable possibility that a material misstatement of the entity's financial statements will not be prevented or detected and corrected timely.

08. **Matter for further consideration** \- An official notification from GAO that identifies either an instance of non-conformance with internal control standards, IRM, standard operating procedures or other control guidance (internal control); a discrepancy in recorded dollar amounts (substantive); the unavailability of documentary support (missing documentation) or an incidence of non-compliance with laws and regulations (compliance).

09. **Planned corrective action** \- A description of how management will implement a recommendation to address audit findings.

10. **Prepared by client** \- A deliverable to the auditors, such as: policies, procedures, workpapers, reports, data extracts or other documentation) provided to the auditors during the course of field work.

11. **Remediation plan** \- A plan to achieve FFMIA compliance when an agency's annual review determines their financial management systems cannot prepare required financial statements and reports, cannot provide reliable and timely financial information for managing operations, and cannot account for assets, all in accordance with federal accounting standards and the United States Standard General Ledger.

12. **Significant deficiency** \- A deficiency, or a combination of deficiencies, in internal control that is less severe than a material weakness, yet important enough to merit attention by those charged with governance. A deficiency in internal control exists when the design or operation of a control does not allow management or employees, in the normal course of performing their assigned functions, to prevent, or detect and correct misstatements timely.

13. **Site visit** \- A planned trip by GAO to an IRS location to conduct walkthroughs, make observations or conduct field testing.

14. **Substantive testing** \- A process used by the auditors to assess the completeness, validity and/or accuracy of account balances and underlying classes of transactions. These tests are conducted on a sample basis.


**1.35.14.1.7** **(04-09-2025)**

#### Acronyms

1. The following acronyms apply to this program:




| **Acronym** | **Description** |
| --- | --- |
| ACFO | Associate Chief Financial Officer |
| AFR | Agency Financial Report |
| CFO | Chief Financial Officer |
| COO | Chief Operating Officer |
| EAM | Enterprise Audit Management |
| FFMIA | Federal Financial Management Improvement Act |
| FMA | Financial Management Audit |
| GAO | Government Accountability Office |
| IS | Information Security |
| IT | Information Technology |
| JAMES | Joint Audit Management Enterprise System |
| LOU | Limited Official Use |
| MC ESC | Management Controls Executive Steering Committee |
| MD&A | Management’s Discussion and Analysis |
| MFC | Matter for Further Consideration |
| MW | Material Weakness |
| OMB | Office of Management and Budget |
| PBC | Prepared By Client |
| PCA | Planned Corrective Action |
| REM | Remediation Plan |
| SD | Significant Deficiency |
| SOF | Statement of Facts |


**1.35.14.1.8** **(04-09-2025)**

#### Related Resources

1. OMB, Management’s Responsibility for Enterprise Risk Management and Internal Control, [Circular No. A-123](https://www.whitehouse.gov/omb/information-for-agencies/circulars/)

2. OMB, Financial Reporting Requirements, [Circular No. A-136](https://www.whitehouse.gov/omb/information-for-agencies/circulars/)

3. GAO, Standards for Internal Control in the Federal Government (known as the “Green Book”) [The Green Book](https://www.gao.gov/greenbook)

4. Federal Accounting Standards Advisory Board, Handbook of Accounting Standards and Other Pronouncements, [Handbook by Chapter](https://fasab.gov/accounting-standards/document-by-chapter/)


**1.35.14.1.9** **(04-09-2025)**

#### Forms

1. The following forms are used throughout this IRM:




| **Form Number** | **Title** |
| --- | --- |
| Form 13872 | Planned Corrective Action (PCA) Status Update for TIGTA/GAO/MW/SD/TAS/REM Reports |
| Form 15265 | IRS Financial Statement Audit Matter for Further Consideration (MFC) |
| Form 15265-A | Financial Statement Audit Matter for Further Consideration (MFC) Information System Security Controls |


**1.35.14.2** **(04-09-2025)**

### Audit Components

1. The IRS financial statement audit has two components - the FMA and the IS audit.

2. The GAO issues an audit opinion, later followed by two management reports, one that is publicly available and another that contains LOU information that is not made public.


**1.35.14.2.1** **(04-09-2025)**

#### Financial Management Audit Component

1. The FMA component focuses on IRS’s internal controls over its use of, and accounting for, its financial resources. The FMA is comprised of three components: corporate accounting, revenue financial accounting and internal control.

2. The Senior Associate CFO for Financial Management oversees the Corporate Accounting and Revenue Financial Accounting organizations, and the ACFO for Internal Controls oversees the Internal Controls organization.


**1.35.14.2.1.1** **(04-09-2025)**

##### Corporate Accounting

1. This component focuses on IRS’s use of its available financial resources (for example, appropriations received and user fees) to implement its mission and strategic plans.


**1.35.14.2.1.2** **(04-09-2025)**

##### Revenue Financial Accounting

1. This component focuses primarily on accounting for and reporting of taxes receivable on its balance sheet and tax collections and refunds reported on the statement of custodial activity.


**1.35.14.2.1.3** **(04-09-2025)**

##### Internal Controls

1. This component focuses on IRS controls for ensuring the preparation and fair presentation of financial statements that are free from material misstatement, whether due to fraud or error.


**1.35.14.2.2** **(04-09-2025)**

#### Information Security

1. This component focuses on IRS internal controls over its key financial and tax processing systems, and its information and interconnected networks to ensure the confidentiality, integrity and availability of financial and sensitive taxpayer information.

2. The CIO organization coordinates activities for the IS audit component.


**1.35.14.3** **(04-09-2025)**

### Key Events/Products of the Financial Audit

1. During the financial audit process, several key events must occur and GAO and/or IRS must develop products. Each of them has unique content, timeframes, participants and signature/date requirements.


**1.35.14.3.1** **(04-09-2025)**

#### Protocol Document

1. The purpose of this document is to provide an archive of agreed upon administrative guidelines/practices established between GAO and the Senior Associate CFO for Financial Management related to financial statement audit activities. This document will be jointly reviewed on an annual basis to determine if additions, deletions or modifications are needed.


**1.35.14.3.2** **(04-09-2025)**

#### Audit Notification Letter

1. In December, the GAO issues an audit notification letter to the IRS providing official notice that the financial statement audit is starting.

2. The letter provides the job assignment code and states that GAO has requested approval to access all records, files and tax return information needed to complete the audit from the Joint Committee on Taxation. If GAO already has secured an approval letter from the committee, the audit notification letter will reference that and the transmittal will include the letter from the committee.

3. The GAO sends the audit notification letter to CRO-EAM, who will send it to Audit Coordination and Quality Control.


**1.35.14.3.3** **(04-09-2025)**

#### Authority to Disclose Tax Information

1. In January, GAO receives approval to access all records, files and tax return information by sending a request to the Joint Committee on Taxation.

2. Once GAO has secured this approval, GAO forwards this approval to CRO-EAM.

3. CRO-EAM reviews the letter and, by memo, grants authority for the IRS to make such disclosures to GAO. CRO-EAM sends the memo to Audit Coordination and Quality Control.

4. Audit Coordination and Quality Control forwards the memo as needed.


**1.35.14.3.4** **(04-09-2025)**

#### Prepared By Client Deliverables

1. The Senior Associate CFO for Financial Management and the ACFO for Internal Controls update two lists of audit deliverables, the corporate/revenue PBC listing and the internal controls PBC listing, respectively. The two groups update the due dates and the descriptions from the prior year's PBC listings for the current audit year as well as other changes as needed to gain agreement from the affected IRS business units. Once the business units agree, the two groups forward their draft listings to GAO with the changes highlighted and facilitate any meetings that may be needed to finalize the listings.

2. Updates to these listings occur throughout the audit on an as needed basis. The appropriate IRS subject matter expert, GAO cycle team member and appropriate staff in Audit Coordination and Quality Control or Internal Control coordinate these changes.

3. For the IS audit component, the CIO organization creates a list of documents and files as GAO requests them. This list is referred to as the IS PBC listing.


**1.35.14.3.5** **(04-09-2025)**

#### Audit Engagement Letter

1. The GAO issues an audit engagement letter to the IRS between February and March that provides written objectives for the IRS financial statement audit.

2. The Senior Associate CFO for Financial Management receives the audit engagement letter and prepares the response. The response is signed by the Senior Associate CFO for Financial Management, CFO, COO, and the Commissioner.

3. The IRS issues a formal acknowledgement to GAO of the receipt of the audit engagement letter and agreement to the terms of the engagement outlined therein (as prescribed by Statements on Auditing Standards No. 122, Statements on Auditing Standards: Clarification and Recodification).


**1.35.14.3.6** **(07-24-2020)**

#### Audit Entrance Conference

1. A formal financial statement audit entrance conference occurs every March with GAO and IRS senior executives discussing the purpose and scope of the upcoming annual financial statement audit process.


**1.35.14.3.7** **(04-09-2025)**

#### Program and Internal Controls Walkthroughs

1. Throughout the fiscal year, IRS subject matter experts conduct meetings, conference calls and/or site visits with GAO to gain a basic understanding of how certain IRS programs and/or controls work.


**1.35.14.3.8** **(04-09-2025)**

#### Client Profile

1. This document is part of GAO’s workpapers that details the organizational structure and functions of the IRS. ACQC assists GAO with updating this document.

2. Annually, the document is circulated to IRS business units through the audit liaisons requesting updates. Audit Coordination and Quality Control consolidates those updates and acquires Senior Associate CFO for Financial Management review and approval.

3. Once approved, the document is sent back to GAO.


**1.35.14.3.9** **(09-04-2018)**

#### Fraud Risk Factors Data Request

1. The appropriate IRS senior executives provide updates to schedules and questions provided by GAO annually to help GAO understand what actions, policies, procedures and controls IRS has established to mitigate the risk of fraud and the potential of material misstatements in the financial statements. The audit requirements specifically addressed by this response are Auditing Standards Clarified 240 (risk of fraud) and 315 (material misstatement).


**1.35.14.3.10** **(09-04-2018)**

#### Testing - Internal Control and Substantive

1. The GAO performs internal control testing to determine whether IRS internal controls are properly designed and effectively implemented. They test various IRS financial reporting and information technology controls, including safeguarding of assets, segregation of duties, budget, compliance and operation controls. GAO then evaluates the results of its internal control testing to determine the extent of substantive control testing to perform. There is a direct relationship between the number of errors allowed during internal control testing for an audit area (for example, reimbursable revenue transactions, procurement disbursements) and the sample size of the subsequent substantive testing.

2. The GAO performs substantive testing to obtain evidence that provides reasonable assurance about whether the IRS financial statements are free of material misstatements. This involves testing IRS financial (appropriation and taxpayer-related) transactions and account balances to enable GAO to issue its audit report on IRS financial statements, internal controls and compliance with significant provisions of laws and regulations.

3. During this phase, GAO may issue MFCs to IRS, indicating potential problem areas for IRS response.


**1.35.14.3.11** **(04-09-2025)**

#### Legal Representation Letter

1. The Senior Associate CFO for Financial Management issues a request to the IRS Chief Counsel asking that he or she prepare a legal representation letter response to GAO.

2. The GAO provides the letter’s language and requires:



1. Disclosing any instances of known violations of laws and regulations that may have a direct and material effect on the presentation of the financial statements.

2. Providing information on pending or threatened litigation and claims or assessments above a specified threshold.

3. Providing information on unasserted claims and assessments that are probable of assertion and have a reasonable possibility of an unfavorable outcome for the IRS.


3. The Associate Chief Counsel (General Legal Services) issues the legal representation letter to GAO in early November.


**1.35.14.3.12** **(09-04-2018)**

#### Delivery of Management’s Discussion and Analysis

1. The IRS delivers the Management’s Discussion and Analysis (MD&A) to GAO in early November.

2. The MD&A summarizes the IRS organization, resources, performance, challenges, risks and actions the IRS has identified to mitigate risks.

3. The GAO incorporates the IRS MD&A into the audit report.


**1.35.14.3.13** **(09-04-2018)**

#### Delivery of Financial Statements

1. The IRS delivers its annual financial statements including the financial statements and related footnotes, required supplementary information and other information to GAO in early November.

2. The financial statements report the IRS’s financial position and results of operations, pursuant to the requirements of the CFO Act of 1990, the Government Management Reform Act of 1994 and the OMB Circular No. A-136, Financial Reporting Requirements. The integrity of the information included in the financial statements is the responsibility of IRS management.

3. The annual Agency Financial Report (AFR) includes:



1. MD&A

2. Financial statements and related footnotes

3. Required supplementary information

4. Other information


4. The principal financial statements include:



1. Balance Sheet

2. Statement of Net Cost

3. Statement of Changes in Net Position

4. Statement of Budgetary Resources

5. Statement of Custodial Activity

6. Related footnotes


5. The GAO’s audit report includes the IRS’s AFR.


**1.35.14.3.14** **(09-04-2018)**

#### Management Representation Letter

1. The IRS issues a written confirmation to GAO in early November that representations made to the auditors during the audit regarding the completeness and reliability of audit data are accurate as of the date of the letter. The letter is signed by the Senior Associate CFO for Financial Management, CFO, COO, and the Commissioner.

2. The management representations detailed in the letter cover a broad range of audit areas including financial statements, required supplementary information, other information, intra-governmental activities, internal control, fraud, compliance of financial management systems with FFMIA requirements, and budgetary and restricted funds.


**1.35.14.3.15** **(09-04-2018)**

#### Exit Conference

1. The GAO meets with the IRS senior executives at the end of the audit to convey:



1. Overarching issues identified during the audit.

2. Remaining audit timeline.

3. Overall message the audit opinion will contain.


**1.35.14.3.16** **(04-09-2025)**

#### Financial Statements and Audit Opinion Issued

1. At the completion of the IRS financial statement audit, GAO issues a draft report titled IRS's Fiscal Years 20XX and 20XX Financial Statements, which requests the agency’s response. The agency’s response takes the form of a letter from the Commissioner, which is prepared by Audit Coordination and Quality Control. After receiving the agency’s response, GAO issues the final report.

2. This report contains the:



1. IRS financial statements, notes, required supplementary information and other information.

2. MD&A.

3. Auditor's opinion on the fair presentation of the IRS financial statements, the effectiveness of IRS internal control over financial reporting, IRS compliance with laws and regulations and IRS financial systems compliance with FFMIA requirements. The auditors issue one of four opinions:


       (i) Unmodified -- Financial statements, including the accompanying notes, present fairly, in all material respects, the financial information.


       (ii) Qualified -- Except for the circumstances specified in the report, the statements present fairly the financial information.


       (iii) Adverse -- The auditor disagrees with the application of certain accounting principles and the financial statements do not present fairly the financial information.


       (iv) Disclaimer -- The auditor could not obtain enough evidential matter to express an audit opinion

4. Auditor's statement of any material weaknesses, significant deficiencies or management challenges.


**1.35.14.3.17** **(04-09-2025)**

#### Statement of Facts

1. After the audit opinion report has been published, the management report process typically begins in January with the development of the Statement of Facts (SOF) and concludes in May with the issuance of the final published management reports.

2. The SOF is a document that contains GAO’s preliminary audit findings.

3. In January, GAO issues a draft SOF to the Senior Associate CFO for Financial Management, Policy and Data Analytics, Audit Coordination and Quality Control. This draft provides the IRS with an opportunity to review and evaluate GAO’s conclusions for accuracy and concurrence prior to their publication in the management reports. The IRS is allowed approximately a week to review and provide feedback to GAO. Audit Coordination and Quality Control coordinates the review and response among the impacted business units.

4. After this process is complete, Audit Coordination and Quality Control assists the business units in developing PCAs in response to the draft recommendations in preparation for the receipt of the draft management reports.


**1.35.14.3.18** **(04-09-2025)**

#### Management Reports

1. GAO normally produces two management reports: one public and one limited official use (LOU). The GAO provides IRS with an exposure draft (restricted use only) of the upcoming management reports for review and comment between March and May. The draft reports identify new deficiencies in internal control that GAO observed during the latest audit of the IRS financial statements and recommendations for action.

2. The IRS has 30 days to respond formally to the draft report. The response package is created by Audit Coordination and Quality Control. The response comprises of a letter from the Commissioner with an enclosure that outlines GAO’s newly proposed recommendations along with IRS’s concurrence or disagreement. Thereafter, Audit Coordination and Quality Control works with the impacted business units to create PCAs with due dates, which will be reported to Congress in the enclosure to the 180-day Reports to Congress as described below.

3. The GAO issues its official management reports between April and June. In addition, the reports also include GAO’s assessment of IRS actions taken on open recommendations from prior years.

4. After the issuance of the final management reports by GAO, the Senior Associate CFO for Financial Management, Policy and Data Analytics, Audit Coordination and Quality Control, inputs the new recommendations, PCAs with projected due dates and responsible parties into JAMES.


**1.35.14.3.19** **(04-09-2025)**

#### 180-day Reports to Congress

1. 31 U.S.C. Section 720, Agency Reports, requires the IRS to send a management report response to congressional committee leadership within 180 days of GAO's issuance of its management report.

2. The response updates Congress on IRS’s efforts to address GAO's financial statement audit recommendations.

3. The response package is created by the Senior Associate CFO for Financial Management, Policy and Data Analytics, Audit Coordination and Quality Control. The response comprises of letters from the Commissioner with an enclosure that outlines GAO’s new recommendations along with IRS’s PCAs.

4. Once the response package has been signed by the Commissioner, Legislative Affairs will deliver it to Congress.


**1.35.14.3.20** **(04-09-2025)**

#### Recommendation and PCA Management

1. Recommendations and PCAs are tracked in JAMES, which is Treasury’s web-based system of record used for tracking findings, recommendations and PCAs emanating from TIGTA and GAO audit reports and also serves as the repository for audit documentation.

2. The Senior Associate CFO for Financial Management, Policy and Data Analytics, Audit Coordination and Quality Control, coordinates JAMES activities related to the financial statement audit as well as any related significant deficiencies, material weaknesses and/or remediation plans.

3. Business units are responsible for providing timely updates to the Senior Associate CFO for Financial Management, Policy and Data Analytics, Audit Coordination and Quality Control, to approve PCA additions, modifications, closures or extensions.

4. Senior Associate CFO for Financial Management, Policy and Data Analytics, Audit Coordination and Quality Control, also separately tracks recommendation and PCA information related to the financial statement audits and uses this information to provide a monthly status update to GAO.


**1.35.14.3.21** **(04-09-2025)**

#### Remediation Plans

1. Audit Coordination and Quality Control, and Internal Controls manage remediation plan processes with the approval of the MC ESC. This includes creating new and/or closing existing remediation plans as well as adding, modifying, tracking, updating, and reporting to stakeholders on recommendations, PCAs and related closure activities for all financial statement related remediation plans.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-035-014#addtoany "Show all")

A2A