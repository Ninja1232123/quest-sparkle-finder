---
url: "https://www.irs.gov/irm/part1/irm_01-014-007"
title: "1.14.7 Motor Vehicle Fleet Management Program | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-014-007#main-content)

- 1.14.7 [Motor Vehicle Fleet Management Program](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730281406304)
  - 1.14.7.1 [Program Scope](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730281360768)
    - 1.14.7.1.1 [Background](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730281157456)
    - 1.14.7.1.2 [Authority](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730304663008)
    - 1.14.7.1.3 [Responsibilities](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730281397360)
    - 1.14.7.1.4 [Program Objectives and Review](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730281125856)
    - 1.14.7.1.5 [Acronyms](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730281078320)
    - 1.14.7.1.6 [Related Resources](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730298650176)
  - 1.14.7.2 [Use of Government Motor Vehicles](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730281134960)
    - 1.14.7.2.1 [Unauthorized Use of Government Vehicles](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730295793792)
      - 1.14.7.2.1.1 [Disciplinary Action for Unauthorized Use of Government Vehicles](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730281408256)
    - 1.14.7.2.2 [Transportation Between Domicile and Place of Employment (Home-to-Work Use)](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730302386928)
      - 1.14.7.2.2.1 [Requirements for Home-to-Work Use](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730297557104)
      - 1.14.7.2.2.2 [Home-to-Work Requests](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730299658640)
      - 1.14.7.2.2.3 [Record Keeping and Reporting Requirements for Home-to-Work Vehicles](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730299678480)
    - 1.14.7.2.3 [Vehicle Identification](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730296465584)
      - 1.14.7.2.3.1 [Exemptions](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730302961808)
      - 1.14.7.2.3.2 [Registration and Inspection](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730296534112)
      - 1.14.7.2.3.3 [Vehicle Inspection](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730304353168)
      - 1.14.7.2.3.4 [Records](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730309339568)
    - 1.14.7.2.4 [Additional Equipment](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730292939280)
    - 1.14.7.2.5 [Fleet Vehicle Credit Card](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730286929920)
    - 1.14.7.2.6 [Employee Operator Responsibility](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730296953584)
    - 1.14.7.2.7 [Operator Licensing](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730306613216)
    - 1.14.7.2.8 [Motor Vehicle Safety and Prohibition of Texting While Driving](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730281128704)
      - 1.14.7.2.8.1 [Defensive Driving Training Requirements](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730302631488)
    - 1.14.7.2.9 [Accident Response and Reporting](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730310775312)
    - 1.14.7.2.10 [Liability and Insurance](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730290504128)
    - 1.14.7.2.11 [Storage and Parking of Government Motor Vehicles](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730306296400)
      - 1.14.7.2.11.1 [Parking Facilities](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730286514352)
      - 1.14.7.2.11.2 [Storage Contracts and Charges](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730281093872)
  - 1.14.7.3 [Acquisition & Disposition Guidelines](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730304967728)
    - 1.14.7.3.1 [General Provisions](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730281101312)
    - 1.14.7.3.2 [Vehicle Acquisition](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730298695776)
      - 1.14.7.3.2.1 [Interagency Motor Pool Services](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730293745664)
      - 1.14.7.3.2.2 [Acquisition by Purchase Authority and Restrictions](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730298696992)
      - 1.14.7.3.2.3 [Seized Motor Vehicle Standards](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730295865744)
      - 1.14.7.3.2.4 [Law Enforcement Vehicle Standards](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730290800864)
      - 1.14.7.3.2.5 [Vehicle Acquisitions Fuel Conservation and Alternative Fuel Requirements](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730293610656)
    - 1.14.7.3.3 [Standards for Vehicle Replacement](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730308079728)
      - 1.14.7.3.3.1 [Annual Vehicle Replacement](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730305296832)
      - 1.14.7.3.3.2 [Exceptions to Replacement Standards](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730297995376)
    - 1.14.7.3.4 [Book Value of IRS Motor Vehicles](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730306218096)
    - 1.14.7.3.5 [Accepting New Vehicles Warranty and Acceptance Procedures](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730302323760)
      - 1.14.7.3.5.1 [Pre-Delivery Inspection Deficiencies](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730298104560)
      - 1.14.7.3.5.2 [Acceptance Procedure](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730306046000)
      - 1.14.7.3.5.3 [Vehicle Maintenance and Warranty Repairs](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730297557472)
    - 1.14.7.3.6 [Transfer of Title](https://www.irs.gov/irm/part1/irm_01-014-007#idm139730289527360)

# Part 1. Organization, Finance, and Management

# Chapter 14. Facilities Management

# Section 7. Motor Vehicle Fleet Management Program

* * *

## 1.14.7 Motor Vehicle Fleet Management Program

#### Manual Transmittal

September 27, 2018

#### Purpose

(1) This transmits revised IRM 1.14.7, _Motor Vehicle Fleet Management Program_.

#### Material Changes

(1) On October 1, 2014, Real Estate and Facilities Management (REFM) merged with Physical Security and Emergency Preparedness (PSEP) to create Facilities Management and Security Services (FMSS). This IRM was updated to reflect editorial changes and changes to current organizational titles.

(2) As of January 1, 2017, the Internal Revenue Service (IRS) is instituting a requirement that the IRM addresses relevant internal controls. This will inform employees about the importance of and context for internal controls by describing the program objectives and officials charged with program management and oversight. Internal controls are the programs policies and procedures which ensure:

1. Mission and program objectives are clearly delineated and key terms defined.

2. Program goals are established and performance is measured to assess the efficient and effective mission and objective accomplishment.

3. Program and resources are protected against waste, fraud, abuse, mismanagement and misappropriation.

4. Program operations are in conformance with applicable laws and regulations.

5. Financial reporting is complete, current and accurate.

6. Reliable information is obtained and used for decision making and quality assurance.


(3) On October 1, 2017, a Memorandum of Understanding (MOU) was signed by Small Business/Self Employed (SB/SE) and FMSS, regarding Fleet Management. This IRM was updated to reflect program management changes agreed on in the MOU.

(4) The required Enterprise Learning Management System (ELMS) Defensive Driving course number was changed to 55111.

#### Effect on Other Documents

This IRM supersedes IRM 1.14.7, dated August 19, 2013.

#### Audience

Servicewide

#### Effective Date

(09-27-2018)

Richard L. Rodriguez

Chief

Facilities Management and Security Services

**1.14.7.1** **(09-27-2018)**

### Program Scope

1. **Purpose**: This IRM provides directives, authorities and responsibilities for the Motor Vehicle Fleet Management Program. The program is used by all IRS Business Units (BU) that operate government-owned or leased motor vehicles, as well as those employees who use personally-owned or rental vehicles for official government business

2. **Audience**: Servicewide.

3. **Policy Owner**: Chief, Facilities Management and Security Services (FMSS).

4. **Program Owner**: FMSS Chief, Environment, Health and Safety (EHS).

5. **Primary Stakeholders**: BU operating government owned/leased motor vehicles, FMSS Territory Managers (TM) and their personnel.


**1.14.7.1.1** **(09-27-2018)**

#### Background

1. IRM 1.14.7, _Motor Vehicle Fleet Management Program_, provides purpose, authorities, directives, and responsibilities for the Motor Vehicle Fleet Management Program. The program is used by all IRS BU that operate government-owned or leased motor vehicles, as well as those with employees who use personally-owned or rental vehicles for official government business.


**1.14.7.1.2** **(09-27-2018)**

#### Authority

1. The IRS Fleet Management Program is based on the following laws, regulations, Executive Orders (EO) and Treasury Directives (TD):



01. 31 United States Code (U.S.C) 1343 “Buying and leasing passenger motor vehicles and aircraft”

02. 31 U.S.C 1344 “Passenger Carrier Use”

03. 40 U.S.C 491 Chapter 5 Subchapter 6 “Motor Vehicle Pools and Transportation Systems”

04. 40 U.S.C Chapter 175, “Federal Management Regulation”, including Part 102-34, “Motor Vehicle Management”

05. Federal Management Regulation (FMR) Part 102-5 Home to Work Transportation

06. TD and Treasury Directive Publication (TDP) 74-01 - Motor Vehicle Management

07. TD and TDP 74-06 - Home-to-Work Transportation Controls

08. The Energy Policy Act of 1992, codified in relevant part in 42 USC Chapter 134, Subchapter I, “Energy Policy - Alternative Fuels - General”

09. Energy Policy Act of 2005

10. Energy Independence and Security Act (EISA) of 2007

11. EO 13513 “Federal Leadership on Reducing Text Messaging While Driving”


**1.14.7.1.3** **(09-27-2018)**

#### Responsibilities

1. IRM 1.14.7, _Motor Vehicle Fleet Management Program_, applies to each IRS BU that operates government-owned or leased motor vehicles, as well as those with employees who use personally-owned or rental vehicles for official government business.

2. IRS maintains two fleets of government-owned/leased motor vehicles:



1. The FMSS organization manages a motor pool fleet for BU across IRS. FMSS assigns a fleet program manager at the Headquarters (HQ) level and motor vehicle coordinators at the field level who serve as the main Points of Contact (POC) for the BU using motor vehicles, as well as external stakeholders.

2. Criminal Investigation (CI) BU manages a separate fleet for their employees and assigns their own fleet program managers.



      ### Note:



      For additional law enforcement fleet guidance, see CI IRM 9.1.4, _Criminal Investigation Mission and Strategies, Criminal Investigation Directives and Functional Delegations of Authority_ and IRM 9.11.3, _Fiscal and Personnel Matters, INVESTIGATIVE PROPERTY_.


3. An IRS BU that operates motor vehicles must:



01. Manage the vehicles in the organizational unit, including assigning vehicles and fleet credit cards, marshaling and arranging for vehicle preventive maintenance, repairs and recall work. Each BU must ensure that employees operating government-leased/owned vehicles are properly licensed to do so.

02. Follow instructions in IRM 1.14.7, _Motor Vehicle Fleet Management Program_, policies and directives issued by the fleet program managers, and General Services Administration (GSA) bulletins concerning fleet operations. Ensure that prior to taking possession of a vehicle, all motor vehicle operators read and comply with the requirements of this IRM.

03. Maintain and timely submit appropriate paperwork including: mileage/usage logs and home-to-work logs for each vehicle showing dates, times, mileage, and destination for each trip.

04. Submit vehicle mileage/usage logs and home-to-work logs to the local FMSS motor vehicle coordinator or fleet program manager monthly.

05. Retain vehicle mileage/usage logs and home-to-work logs for a period of two years after the date of disposal of the vehicle. These logs must be complete, legible, and available for inspection by appropriate officials when requested.

06. Implement all federal regulations, TD and IRS directives, procedures, and guidelines that apply to the administration of the IRS Motor Vehicle Fleet Management Program.

07. Determine and report current and future requirements for motor vehicles, related facilities, and accessory equipment to the local FMSS motor vehicle coordinator for vehicles in the FMSS-managed motor pool fleet or the fleet program manager for vehicles in the CI fleet.



       ### Note:



       For additional law enforcement fleet guidance, see CI IRM 9.1.4, _Criminal Investigation Mission and Strategies, Criminal Investigation Directives and Functional Delegations of Authority_ and IRM 9.11.3, _Fiscal and Personnel Matters, INVESTIGATIVE PROPERTY_.

08. Provide funds and facilities for maintaining, storing, parking, and operating IRS motor vehicles (including law enforcement vehicles), and for obtaining related supplies, services, and accessories.

09. Formulate maintenance, repair, and storage procedures for IRS-owned law enforcement vehicles and related equipment, as required.

10. Submit all information regarding vehicles to the appropriate personnel for entry into the Knowledge, Incident/Problem, Service Asset Management (KISAM) or Criminal Investigation Management Inventory System (CIMIS), within 10 days of acquisition, transfer, when disposal procedures are initiated, and at final disposition.

11. Devise, perform, and/or direct feasibility studies of motor vehicle use in their functions to ensure their employees and the IRS are provided the best possible transportation at the least cost to the government.

12. Implement the procedures and methods contained in IRM 1.14.7, _Motor Vehicle Fleet Management Program_, covering the acquisition of vehicles through transfer, forfeiture, seizure, exchange/sale, and disposition of automotive equipment.

13. Comply with the IRS requirements under the Energy Policy Act of 2005, Clean Air Act, Energy Independence and Security Act of 2007, relevant Executive Orders, and other federal, state, and local regulations as they apply to motor vehicles.


**1.14.7.1.4** **(09-27-2018)**

#### Program Objectives and Review

1. **Program Goals**: To ensure that all IRS leased/owned vehicles are obtained, operated and maintained in compliance with applicable federal state and treasury requirements.

2. **Program Reports**:



1. Annual Fleet Management Plan and Budget Narrative

2. Federal Automotive Statistical Tool (FAST) data call twice per year

3. Vehicle Allocation Methodology (VAM) performed no less than once every five years

4. EISA Green House Gas Fleet Assessment


3. **Program Effectiveness**: The program reports are reviewed to ensure compliance and effectiveness of the program.


**1.14.7.1.5** **(09-27-2018)**

#### Acronyms

1. The following acronyms are used throughout this IRM:




| **Acronym** | **Definition** |
| --- | --- |
| AFV | Alternative Fuel Vehicle |
| AM | Asset Manager |
| ASM | Assistant Secretary for Management |
| BU | Business Unit |
| CI | Criminal Investigation |
| CIMIS | Criminal Investigation Management Inventory System |
| DCFO | Deputy Chief Financial Officer |
| E-85 | Alternative Fuel |
| ECOMP | Employees Compensation Operations & Management Program |
| EHS | Environment, Health and Safety |
| EISA | Energy Independence and Security Act |
| ELMS | Enterprise Learning Management System |
| EO | Executive Order |
| EPAct | Energy Policy Act |
| ERC | Employee Resource Center |
| FAR | Federal Acquisition Regulation |
| FAST | Federal Automotive Statistical Tool |
| FMSS | Facilities Management and Security Services |
| FOB | Freight on Board |
| FOIA | Freedom of Information Act |
| GBL | Government Bill of Lading |
| GHG | Greenhouse Gas |
| GSA | General Services Administration |
| HQ | Headquarters |
| KISAM | Knowledge, Incident/Problem, Service Asset Management |
| MICC | Management Internal Controls and Compliance |
| MOU | Memorandum of Understanding |
| OAM | Office of Asset Management |
| PIH | Plug-in Hybrid |
| POC | Points of Contact |
| POD | Post of Duty |
| SB/SE | Small Business/Self Employed |
| SF | Standard Form |
| SUV | Sport Utility Vehicle |
| TD | Treasury Directive |
| TDP | Treasury Directive Publication |
| TIGTA | Treasury Inspector General for Tax Administration |
| TM | Territory Managers |
| U.S.C | United States Code |
| VAM | Vehicle Allocation Methodology |
| VIN | Vehicle Identification Number |


**1.14.7.1.6** **(09-27-2018)**

#### Related Resources

1. IRM 1.2.18.1.2 Policy Statement 9-85, _Luxury class vehicles excluded from motor vehicle fleet except for surveillance or undercover work_

2. IRM 1.14.4, _Personal Property Management_

3. IRM 1.32.1, _Servicewide Travel Policies and Procedures, Official IRS Local Travel Guide_

4. IRM 1.32.11, _Servicewide Travel Policies and Procedures, Official IRS City-to-City Travel Guide_

5. IRM 6.751.1, _Discipline and Disciplinary Actions, Discipline and Disciplinary Actions: Policies, Responsibilities, Authorities, and Guidance_

6. IRM 9.1.4, _Criminal Investigation Mission and Strategies, Criminal Investigation Directives and Functional Delegations of Authority_

7. IRM 9.11.3, _Fiscal and Personnel Matters, INVESTIGATIVE PROPERTY_


**1.14.7.2** **(09-27-2018)**

### Use of Government Motor Vehicles

1. IRS only authorizes employees to use government vehicles for official purposes (i.e., official use) to perform the mission of the IRS, which includes transportation:



1. Between places of official business.

2. As otherwise authorized by the approving official.


2. Examples of official business include an employee's transportation:



1. To a taxpayer's home or office.

2. To locate witnesses.

3. To courthouses and land record offices.

4. Between IRS Posts of Duty (POD).

5. To any other location where employees would be required to go in the performance of official duties.


### Note:

Employees may stop to purchase meals or other items necessary for health, welfare, or sustenance, **as long as these stops are along a point-to-point route and are without interference to their official business.**

3. IRS employees may also use government vehicles for transportation when in travel status to obtain meals, lodging, and to travel between place of lodging and place or area of employment and/or railroad, airport, and other terminals, if so authorized.

4. IRS employees in travel status may be permitted to use a government vehicle to return to their home or POD at the end of a workweek before traveling to the same or different temporary duty station the following week. However, such travel is governed by IRM 1.32.11, _Official IRS City to City Travel Guide_.

5. Transportation of the following categories of passengers is authorized when their presence contributes to the performance of official government business:



1. Federal, state, and local officials,

2. Accredited representatives of foreign governments,

3. Private citizens providing official assistance,

4. Contractors performing official business for the government,

5. Any person deemed essential to the completion of the mission.


### Note:

All contractors performing official duties for the government must have a certificate of liability available.

6. Enforcement vehicles are assigned to enforcement personnel in CI as a requirement to conduct enforcement duties. These duties include surveillance, intelligence gathering, arrests and raids, transportation of prisoners, and other activities normally expected of an enforcement assignment.

7. IRM 1.32.1, _Official IRS Local Travel Guide_ and IRM 1.32.11, _Official IRS City-to-City Travel Guide_, provide IRS policies for using government and personal vehicles during official travel.


**1.14.7.2.1** **(09-27-2018)**

#### Unauthorized Use of Government Vehicles

1. Unauthorized use of a government vehicle includes transporting personnel:



1. in excess of its normal capacity.

2. for the performance of personal business.

3. to any religious, sport, amusement, or recreational activity, except on official business.

4. on authorized leave while in travel status, except as necessary and authorized to travel in route to or from temporary POD and residence or official duty station.


2. Unauthorized use also includes operating or parking a government vehicle in violation of any federal, state, or municipal regulation. Drivers must operate vehicles in accordance with the laws of the local jurisdiction.


**1.14.7.2.1.1** **(09-27-2018)**

##### Disciplinary Action for Unauthorized Use of Government Vehicles

1. The IRS handles disciplinary action for unauthorized use in accordance with provisions of 31 USC, Section 1349, and IRM 6.751.1, _Discipline and Disciplinary Actions: Policies, Responsibilities, Authorities, and Guidance_, which specifies a minimum suspension of at least 30 days for anyone who uses or authorizes the use of a motor vehicle for other than official purposes. Also refer to IRS Document 11500, _Guide to Penalty Determinations_.

2. An employee’s immediate supervisor will report possible unauthorized use, presence of unauthorized persons in a vehicle, or personal misconduct to the Office of the Treasury Inspector General for Tax Administration (TIGTA).


**1.14.7.2.2** **(09-27-2018)**

#### Transportation Between Domicile and Place of Employment (Home-to-Work Use)

1. IRS employees may use a government owned or leased vehicle for transportation from place of employment to domicile and/or from domicile to place of employment **only when such use has been authorized consistent with 31 USC 1344 and TD 74-06, _Home-to-Work Transportation_**.

2. The 31 USC Section 1344 permits home-to-work transportation for the Secretary of the Treasury and for other employees when the Secretary authorizes the use of home-to-work transportation. The Secretary is the only official within the Department of the Treasury who may make a determination that authorizes the use of government vehicles for home-to-work transportation for employees. Prior approval is required.

3. TD 74-06, _Home-to-Work Transportation Controls_, prescribes home-to-work authorizations for IRS employees.


**1.14.7.2.2.1** **(09-27-2018)**

##### Requirements for Home-to-Work Use

1. Use of a motor vehicle between an IRS employee's residence and place of employment qualifies as transportation for an official purpose only when the Secretary of the Treasury determines that:



1. transportation between residence and various locations is required for performance of field work, in accordance with applicable regulations. These determinations will be for a maximum of two years or as determined by the Secretary.

2. transportation between residence and various locations is essential for safe and efficient performance of intelligence, counterintelligence, protective services, or criminal law enforcement duties. These determinations will be for a maximum of two years or as determined by the Secretary.

3. highly unusual circumstances, a clear and present danger, an emergency or other compelling operational considerations make this type of home-to-work transportation essential to conduct official business. These determinations are effective for not more than 15 calendar days, extendable for two 90 day periods at the discretion of the Secretary.


2. Commuting miles between the employee's residence and official duty station will not exceed 50 miles one way unless an exception is approved by the Secretary. Use of the home-to-work vehicle to commute will not exceed 49 percent of the total usage of the vehicle during the fiscal year.

3. Home-to-work transportation will only be authorized when such use will substantially increase the economy and efficiency of the government, and will not be authorized solely or principally for the comfort or convenience of the employee. Home-to-work transportation will be authorized only to complete those tasks necessary for the accomplishment of the IRS mission, and not authorized solely for the comfort or convenience of the employee.

4. Home-to-work authorizations will not be based on the grade or position of the employee.

5. Transit subsidies and other transit/parking benefits will be adjusted to take into account the use of home-to-work transportation.

6. The IRS will acquire vehicles for home-to-work use that are the most fuel efficient and lowest Greenhouse Gas (GHG) emitting necessary to execute mission requirements. The IRS will place Alternative Fuel Vehicles (AFV) where the appropriate alternative fuel is available. Home-to-work vehicles must be incorporated into the IRS vehicle allocation methodology.


**1.14.7.2.2.2** **(08-19-2013)**

##### Home-to-Work Requests

1. The IRS may only provide an employee with home-to-work transportation after a determination has been executed by the Secretary of the Treasury. The IRS Commissioner will determine which employees may be eligible to use home-to-work transportation and will submit requests for determinations and renewals in memorandum format to the office of the Deputy Chief Financial Officer (DCFO) and Office of Asset Management (OAM).

2. Each memorandum will:



1. explain the basis for the request. (i.e., include facts and circumstances that clearly demonstrate how the relevant statutory standard is met and how the use of a government vehicle will substantially increase the efficiency and economy or how it is essential to the conduct of government business)

2. describe the types and numbers of employees who will be authorized to use the motor vehicles as well as the situations in which they will be used.

3. describe how the bureau will conduct and document adequate training at least annually to home-to-work transportation employees on home-to-work transportation and applicable requirements for use of a government vehicle.

4. describe the reviews and administrative controls which will be relied on to mitigate risk of unauthorized use, abuse, loss, and theft of the vehicles and verify that home-to-work transportation is used solely for the purpose for which it is intended.

5. identify specific individuals to be responsible for conducting the reviews and emphasizing compliance with administrative controls.

6. provide a written statement of assurance that the requested home-to-work determinations are necessary to the IRS mission requirements and satisfy applicable statutes and regulations. This statement will include an affirmative statement that the necessary funding is approved and available to cover the costs required for the timeframe requested for home-to-work transportation. Execution of this statement of assurance cannot be delegated.


3. Each request will also provide a detailed business case, including but not limited to:



1. a cost-benefit analysis for using home-to-work transportation.

2. a justification that assesses the relative importance to the agency’s mission of authorizing home to work.

3. an explanation of why it is critical to the IRS mission that performance of duties begins at an employee’s residence rather than official duty station, if applicable.

4. examination of the record to determine the frequency with which response from home has been required, if applicable.


4. Home-to-work determinations must be submitted for the Secretary’s review no later than 90 days prior to expiration.


**1.14.7.2.2.3** **(08-19-2013)**

##### Record Keeping and Reporting Requirements for Home-to-Work Vehicles

1. IRS functions with employees authorized for home-to-work transportation will prepare, implement, and monitor a home-to-work transportation Management Internal Controls and Compliance (MICC) plan. The documentation pertaining to the plan will be made available for periodic review by DCFO and OAM staff.

2. The IRS function must maintain a list of active home-to-work transportation employees detailing:



1. Name and title of the employee

2. Vehicle information

3. Dates that home-to-work transportation is authorized, including approval date and expiration date

4. Location of residence, including distance between the residence and duty station

5. Type of home-to-work determination


3. The IRS function must maintain home-to-work transportation accident reports per vehicle, if any.

4. Employees using government-owned or leased vehicles for home-to-work transportation must maintain a vehicle usage log, including home-to-work transportation mileage, other mileage, fuel use, and maintenance. The IRS function to which the vehicle is assigned will retain the vehicle usage logs and make them available for review by the Department of the Treasury, GSA, or others as appropriate and necessary.

5. The appropriate IRS function will submit authorized home-to-work transportation reports quarterly to DCFO, OAM on each vehicle. The reports will include operational and commuting miles.

6. The provision of home-to-work transportation to an employee may result in “fringe benefit income” to the employee. IRS BU will track and report the taxable fringe benefits as appropriate.

7. Employees with home-to-work authorization will receive training on home-to-work transportation awareness and compliance with federal laws and regulations and sign a home-to-work certification annually. These certifications will be maintained by the appropriate IRS function.


**1.14.7.2.3** **(09-27-2018)**

#### Vehicle Identification

1. All IRS-owned or leased vehicles must use official US government tags unless exempted.

2. Official US government tags cannot be transferred to another IRS vehicle. The IRS may not sell or dispose of a vehicle without removing the tag. If a vehicle tag is lost, mutilated (needing replacement), or destroyed, the IRS BU using the vehicle must submit a written report to the FMSS motor vehicle coordinator or fleet program manager regarding the incident.


**1.14.7.2.3.1** **(09-27-2018)**

##### Exemptions

1. GSA will grant unlimited exemptions from the requirement to display official US government tags, shields, and other identification to IRS motor vehicles operated in the performance of investigative, law enforcement, or intelligence duties. GSA may provide interagency fleet vehicles to the IRS without signs or identifying media when the vehicles are to be used for those purposes.

2. The Secretary of the Treasury or designee may authorize a limited exemption from the requirement to display US government license plates and other identification on IRS-owned or leased motor vehicles. The exemption must state that identifying the motor vehicle would endanger the security of the vehicle occupants or otherwise compromise the IRS mission. The limited exemption may last from one day up to three years. If the requirement for exemption still exists beyond three years, the Department of the Treasury must re-certify the continued exemption. The IRS Commissioner or Deputy Commissioner must sign all requests for limited exemptions for IRS vehicles


**1.14.7.2.3.2** **(09-27-2018)**

##### Registration and Inspection

1. IRS owned or commercially leased vehicles exempted from identification requirements must be registered and inspected in accordance with the laws of the state, commonwealth, or US territory where they operate.

2. An IRS BU acquiring IRS owned or commercially leased vehicles, other than those exempted for use within the District of Columbia, must contact FMSS motor vehicle coordinator for registration and inspection information.


**1.14.7.2.3.3** **(08-19-2013)**

##### Vehicle Inspection

1. Motor vehicles owned or leased by the government must pass federally mandated emissions inspections in the jurisdictions in which they operate, when required by state motor vehicle or environmental departments. Unless the fees are waived, IRS must reimburse the state activity for the cost of these inspections.

2. Motor vehicles owned or leased by the government, whether they display government tags and identification or are exempted from displaying them, must comply with emission and mechanical inspection requirements of the state, commonwealth, US territory, or the District of Columbia where they operate.


**1.14.7.2.3.4** **(09-27-2018)**

##### Records

1. FMSS maintains a centralized record of vehicles in KISAM-Asset Manager (AM) for the FMSS managed fleet. CI maintains records of its vehicles in CIMIS. These records describe the motor vehicle, the tag number, the Vehicle Identification Number (VIN), and the storage location of each vehicle.


**1.14.7.2.4** **(08-19-2013)**

#### Additional Equipment

1. Offices may optionally equip government-owned and leased vehicles with safety flares, tire inflators, first aid kits, antennas, mobile two-way radios and other equipment deemed necessary for vehicle and operator safety. GSA permission is required. The IRS must remove any additional equipment or accessories before disposing of the vehicle. The IRS is responsible for repair of damage to the vehicle resulting from the installation and removal of equipment


**1.14.7.2.5** **(09-27-2018)**

#### Fleet Vehicle Credit Card

1. The GSA provides a fleet services credit card for all IRS vehicles.

2. Federal Acquisition Regulation (FAR) 13.1301 authorizes the government-wide commercial fleet service credit card for the purchase of fuel, maintenance and repair of government-owned or leased vehicles. Authorized transactions include:



1. purchase of regular unleaded gasoline, diesel fuel, or alternative fuel from service stations offering the lowest price.



      ### Note:



      Purchase of premium fuel is not authorized unless the vehicle requires it.

2. maintenance under $100 without prior approval including the purchase of oil changes, fluids, wiper blades, car washes, and other necessary maintenance and repair.

3. maintenance over $100, the purchase of tires and batteries, and body work requires prior approval from GSA Fleet at 1(866) 400-0411.


3. Fleet credit cards cannot be used for:



1. expenses for a personal vehicle while on government business.

2. payment of toll charges, fines, or registration fees.

3. storage fees.

4. purchase of food, beverages, or other items for personal use.


**1.14.7.2.6** **(09-27-2018)**

#### Employee Operator Responsibility

1. Each operator of a government-owned or leased motor vehicle or privately-owned vehicle used for official business must be furnished a copy of IRM 1.14.7, _Motor Vehicle Fleet Management Program_, by their manager and operate the vehicle accordingly. In addition, each driver should review the GSA document, [Guide to Your Fleet Vehicle PDF](https://www.gsa.gov/cdnstatic/18-00556_508.pdf).

2. Any employee using a government-owned, leased, or rental vehicle is responsible for exercising reasonable diligence in the care of the vehicle and its contents, including:



1. Reviewing the proper procedures in operating the vehicle.

2. Driving defensively and safely obeying all federal, state and local traffic laws and regulations.

3. Safeguarding the vehicle, fleet credit card, keys, and any government property contained within the vehicle against damage, theft, or misuse.

4. Reporting lost, damaged, or stolen license plates and/or fleet credit cards immediately to their manager and their motor vehicle coordinator.

5. Carrying a valid operator’s license at all times.

6. Using seat belts when operating or when a passenger of a government-owned or leased vehicle.

7. Completing the vehicle mileage/usage log legibly for each trip.

8. Not smoking in the vehicle.

9. Using alternative fuel (E-85) when available in AFV in compliance with Executive Order 13423. Law enforcement vehicle operators should use alternative fuel to the maximum extent possible.


**1.14.7.2.7** **(09-27-2018)**

#### Operator Licensing

1. Managers must ascertain that employees under their supervision who operate motor vehicles for official purposes are properly licensed.

2. Federal employees who operate a government owned or leased vehicle, rental, or privately-owned motor vehicle for the IRS, are required to:



1. possess valid state/international licenses for the class of vehicle they operate. Employees must notify their manager if their driver’s license is suspended, revoked, canceled, or they have been otherwise disqualified from holding licenses.

2. receive manager’s approval to operate the vehicle.

3. be at least 18 years old.

4. have their driving records validated by the state and/or national driver register upon employment and whenever management deems it advisable to review. International-licensed drivers are exempt. This validation is delegated to local managers and supervisors and may be delegated down, as deemed appropriate.


3. In the event the employee’s driver’s license is suspended or revoked, they must notify the manager immediately no later than 10 days from the notice of suspension or revocation.

4. Employees who operate a government-owned or leased vehicle are required to self certify on the vehicle usage log that they have a valid driver’s license for the class of vehicle they operate.


**1.14.7.2.8** **(09-27-2018)**

#### Motor Vehicle Safety and Prohibition of Texting While Driving

1. Employees are strongly discouraged from the use of hand-held wireless devices while operating motor vehicles on official business.

2. Vehicle operators are responsible for accident prevention and must obey all motor vehicle traffic laws of the state and local jurisdiction, including those governing the use of seat belts and the use of wireless devices while driving, except when the duties of their position require otherwise.

3. EO 13513, _Federal Leadership on Reducing Text Messaging While Driving_, bans federal employees who are operating motor vehicles from text messaging when:



1. driving a government owned or leased vehicle.

2. driving a personal vehicle on official government business.


4. Federal employees are prohibited from driving any vehicle (personal or government) when using electronic equipment supplied by the government (such as a Blackberry).

5. As defined by EO 13513, "driving" means operating a motor vehicle on an active roadway with the motor running, including while temporarily stationary because of traffic, a traffic light or stop sign, or otherwise. It does not include operating a motor vehicle with or without the motor running when one has pulled over to the side, or off an active roadway and has halted in a location where one can safely remain stationary.

6. As defined by EO 13513, texting includes reading from or entering data into any handheld or other electronic device for the purpose of text messaging, emailing, obtaining navigational information, or engaging in any other form of electronic data retrieval or communication. The IRS does not consider the following actions texting for the purposes of IRM 1.14.7.



### Note:



These actions may still violate state or local law in some jurisdictions



:



1. Using a Bluetooth or interacting with voice command systems on the employee’s phone, Blackberry, navigational equipment, or other electronic device.

2. Turning a phone, navigational system, radio, or other electronic or vehicle equipment on or off.

3. Interacting or activating any functions of a radio; speaking, viewing or listening to a navigational system; or listening or replying to emails using non-tactile means (i.e., verbal interaction).

4. Using law enforcement radios, computers, or other electronic equipment by law enforcement officers to obtain directions or other information using non-tactile means (i.e., verbal interaction).

5. Using assistive devices, equipment, or technology needed for the employee to operate their vehicle when such assistive devices, equipment or technology are authorized by state or local law.


**1.14.7.2.8.1** **(09-27-2018)**

##### Defensive Driving Training Requirements

1. Employees operating government-owned or leased vehicles must complete the defensive driving training listed below on an annual basis, and self-certify completion of the requirements by checking a box on the vehicle usage log. Managers of employees who operate government-owned or leased vehicles must ensure annual educational requirements are met.



1. The ELMS course 55111, _Defensive Driving_ or equivalent defensive driving course.

2. The ELMS course 44024, _IRS Prohibition on Texting While Driving_, to meet the requirements of EO 13513.


2. In addition to drivers of government-owned and leased vehicles, the following employees will also be required to annually complete the ELMS course 44024, _IRS Prohibition on Texting While Driving_.



1. Drivers who use personal vehicles for official government business.

2. Employees who use a government-provided Blackberry.

3. Travel cardholders who may rent a vehicle while on official government travel.


3. Vehicle operators who are ticketed for moving violations or involved in accidents while driving a government owned or leased vehicle are required to complete the ELMS course 55111, _Defensive Driving_, or equivalent, prior to being permitted to continue driving a government vehicle. The employee’s manager would add this course to the employee’s learning plan and oversee its completion.


**1.14.7.2.9** **(09-27-2018)**

#### Accident Response and Reporting

1. Employees must report accidents that occur on official business in a government-owned or leased vehicle, rental, or personally-owned vehicle to their supervisor and the Employee Resource Center (ERC) immediately.

2. If an employee is involved in an accident while in a government-owned or leased vehicle, or in a privately-owned vehicle while on official government business, the employee must:



1. take steps to prevent another accident.

2. call for emergency services, if necessary.

3. contact their manager or manager’s designee and OS GetServices about the accident immediately.

4. obtain the facts (registration, insurance, witnesses), but not provide personal auto insurance information. Report that they are a federal employee, driving for their employer and that the federal government is self-insured.

5. not sign or make a statement as to responsibility or fault for the accident.

6. ask any witnesses to complete Standard Form (SF)-94, [Statement of Witness](https://www.gsa.gov/reference/forms?search_keyword=SF94).

7. obtain a copy of the police report.

8. complete SF-91, Motor Vehicle Accident Report.


3. Once complete, the employee’s manager must send the original SF-91, including copies of the police report, and the SF-94 from witnesses to the FMSS motor vehicle coordinator or appropriate fleet manager and the local safety officer within 48 hours. The safety officer must forward a copy of each SF-91 to the IRS Claims Manager, Office of Chief Counsel, General Legal Services (CC:GLS:CLP), 1111 Constitution Avenue, NW - Room 6404, Washington, DC 20024.

4. If the employee is filing a worker’s compensation claim, the employee or manager must enter the incident into the Employees Compensation Operations & Management Program (ECOMP). If the employee is not filing a claim, the safety officer must enter the incident.

5. If an employee suffers a personal injury, they may refer to the ERC website, "Guide to Workers’ Compensation Procedures" . The employee or their manager may also call the IRS Workers’ Compensation Center (WCC) for assistance or information about the correct Department of Labor forms to complete.

6. In accordance with IRM 1.14.4, _Personal Property Management_, the appropriate IRS function must complete a Form 1933, Report of Survey for damage in excess of $1,500 to government vehicles when GSA has assessed IRS for the repair cost, and IRS has determined that damage is not the result of negligence or willful act of a third party (person other than IRS employee).

7. The employee driving the vehicle must provide a non-federal driver or passenger who is injured or has property damage and wishes to file a claim (e.g., Tort Claim) with Form 5646, Claim for Damage, Injury or Death and the contact information for the IRS Claims Manager. A non-federal driver or passenger may contact the local safety officer for additional information.

8. If an employee suffers damage to their personal vehicle, or it is likely that a third party will seek compensation for property damage or personal injuries, the employee or their manager must contact the IRS Claims Manager.


**1.14.7.2.10** **(09-27-2018)**

#### Liability and Insurance

1. IRS must assume liability for most damages to a government-leased vehicle, including if the damage is caused through an IRS employee negligence or improper operation of the vehicle. See CFR 41 101-39.405 and 406 for more information.

2. Supervisors and managers must inform employees that they are encouraged, but not required, to obtain personal liability insurance containing an appropriate rider before operating any motor vehicle, government or privately owned, on official business. The employee’s insurance representative can provide information on an appropriate rider to a non-business policy. Employees obtaining this type of insurance do so at their own expense.


**1.14.7.2.11** **(09-27-2018)**

#### Storage and Parking of Government Motor Vehicles

1. Employees using vehicles for official business, whether leased, rented, privately or government owned, marked or unmarked, are subject to all ordinances such as restricted zones, no parking zones, and double-parking restrictions. Violation of a parking ordinance generally is the personal responsibility of the driver of the vehicle. The IRS will request a local jurisdiction to rescind or cancel a citation, only in those situations where compelling reasons exist, and the employee furnishes a justification. In these cases, the local FMSS territory manager or appropriate fleet manager will sign the written request.


**1.14.7.2.11.1** **(08-19-2013)**

##### Parking Facilities

1. IRS is responsible for the cost of any IRS-owned or leased vehicle stored at other than a designated storage point. Before procuring parking accommodations in urban centers, the business unit official is encouraged to contact the appropriate GSA regional office to determine the availability of government owned or controlled parking space.

2. Vehicle operators must park IRS-owned or leased vehicles in a manner that will minimize the possibility of loss or damage. IRS owned or leased vehicles must be parked and stored in a manner which will minimize the possibility of loss or damage. Priorities, in the following order, are suggested for parking, if available:



1. Assigned parking in a federal building or other space occupied by IRS;

2. Street parking or other free parking within a reasonable distance from the place where duty is performed;

3. Other federal or state agencies in the vicinity if a request for space is approved;

4. At or near an IRS employee’s residence when authorized; and

5. A commercial parking facility, if authorized.


3. Employees with home-to-work authority must make their vehicle available to other members of their organizational unit during any extended absence (such as for training missions or vacations). If a supervisor allows a vehicle to remain at a home-to-work location, it must be secured and not left unattended in an open parking lot or in on-street parking.


**1.14.7.2.11.2** **(08-19-2013)**

##### Storage Contracts and Charges

1. IRS procurement executes contracts for commercial storage or parking services for government-owned or leased vehicles.

2. Such expenses incurred for all government-owned or leased vehicles while the employee is on official travel are payable from travel appropriations. Employees must claim and identify these charges separately on a travel voucher through the IRS e-travel system, Concur®.

3. Vehicle operators must not use government-issued fleet credit cards for parking or overnight storage expenses. They may use the traveler’s government travel card or cash for payment per IRM 1.32.1 and IRM 1.32.11.

4. The IRS must store surplus vehicles awaiting final disposition in a government facility.


**1.14.7.3** **(09-27-2018)**

### Acquisition & Disposition Guidelines

1. This subsection IRM 1.14.7.3, _Acquisition & Disposition Guidelines_, should be used by property officers and officials of IRS responsible for obtaining and terminating interagency motor pool and other vehicle support services and for the acquisition, accountability, and disposition of IRS owned and leased motor vehicles.


**1.14.7.3.1** **(09-27-2018)**

#### General Provisions

1. To the maximum extent possible, motor vehicle support is obtained from interagency motor pools.

2. FMSS manages the acquisition, replacement, and disposition process for the vehicles in its fleet. IRS functions using motor vehicles must coordinate with FMSS to process the necessary acquisitions, replacements, and disposals of GSA vehicles (except CI). CI is responsible for administering acquisitions, replacements, and disposals for its fleet within the same general framework outlined in IRM 1.14.7.3.


**1.14.7.3.2** **(09-27-2018)**

#### Vehicle Acquisition

1. GSA Vehicles - Interagency Motor Pool Systems - The IRS participates in GSA Interagency Motor Pool Systems to lease vehicles for employee use.

2. GSA Vehicles – Purchase - GSA is the mandatory source for purchasing vehicles.

3. Commercial Rented Motor Vehicles - Employees may use commercially rented vehicles for performing official travel only when:



1. an IRS-owned or leased vehicle is not available.

2. suitable public transportation is not available.


4. Commercially Leased vehicles - The IRS may lease motor vehicles commercially to augment the fleet only when the number of vehicles acquired through purchase, transfer, forfeiture, and GSA is insufficient. The IRS must submit a memorandum to the Treasury Deputy Chief Financial Officer justifying this requirement.

5. Use of Government or Personally-Owned Vehicles – The GSA, to the extent of their capabilities, provides user agencies with motor vehicles for administrative travel. The IRS will provide GSA vehicles, to the extent they are available, for its employees who require vehicles for official purposes. IRM 1.32.1, _Servicewide Financial Policies & Procedures, Official IRS Local Travel Guide_ and IRM 1.32.11, _Servicewide Financial Policies and Procedures, Official IRS City-to-City Travel Guide_ contain criteria for use of government vehicles and privately-owned vehicles, as well as determining reimbursement rates for use of a privately-owned vehicle on official business.


**1.14.7.3.2.1** **(09-27-2018)**

##### Interagency Motor Pool Services

1. The IRS fleets managed by FMSS lease vehicles from the GSA Interagency Fleet Management System motor pool:



1. Based on GSA mileage requirements, IRS assigns GSA vehicles in priority order from highest mileage vehicles to those driven a minimum of 7,200 miles per year in metropolitan areas or 12,000 miles per year in rural areas. The IRS does not normally assign GSA vehicles when the total annual mileage is less, except in unusual circumstances where no other options exist to meet transportation needs. Offices using vehicles for occasional travel and not meeting the mileage requirements must consider “pool” use of GSA vehicles.

2. All vehicles in the FMSS-managed vehicles, except Fuel Compliance pick-up trucks, are required to be “pool” use (assigned to one or more IRS offices rather than a specific employee). If pool use of a specified vehicle in the FMSS-managed fleet is not practical due to installed equipment or specific usage requirements, the IRS office using the vehicle must provide a written explanation of the need for excluding the vehicle from the program rotation requirements to the FMSS motor vehicle coordinator.


2. EO 10579, Relations Relating to the Establishment and Operation of Interagency Motor-Vehicle Pools and Systems, exempts any motor vehicle regularly used by an agency in the performance of investigative law enforcement or intelligence duties from inclusion in interagency motor vehicle pools. This exemption is available if the head of the agency determines that exclusive control of such vehicles is essential to the effective performance of such duties. The Department of the Treasury has determined that motor vehicles operated by Criminal Investigation division, Special Agents, meet the EO 10579 conditions.


**1.14.7.3.2.2** **(08-19-2013)**

##### Acquisition by Purchase – Authority and Restrictions

1. Vehicle Purchase Limitations - Congressional authority for the purchase of new law-enforcement vehicles is contained in the annual appropriation language and applies only to passenger vehicles. CI Headquarters purchases vehicles with funds allocated specifically for that purpose. Funds available for such purpose, however, cannot be obligated until the Secretary of the Treasury, through the Assistant Secretary for Management, certifies that the purchase is consistent with departmental vehicle management principles covered in Treasury Order 102-22.

2. Methods and Procedures - 41 CFR 101-26.5 outlines methods for obtaining new motor vehicles


**1.14.7.3.2.3** **(09-27-2018)**

##### Seized Motor Vehicle Standards

1. Passenger carrying vehicles – The IRS has set the following standards for accepting seized passenger vehicles in the IRS enforcement fleet based on study, analysis, and experience of use of seized vehicles:



1. Age - The current and three preceding model years

2. Mileage - Not exceeding 40,000

3. Make – Any make and model, except those covered in IRM 1.2.18.1.2, Policy Statement 9-85, _Luxury class vehicles excluded from motor vehicle fleet except for surveillance or undercover work_, for replacement of inferior vehicles as operations necessitate, to the extent they do not exceed the current fleet allocation.

4. Body - Sedans, station wagons, hatchbacks, vans, SUV and light-duty trucks

5. Requirements and dollar limits - Before acquisition, each vehicle must be subject to a safety, mechanical, and body inspection by a competent mechanic and a written estimate obtained of the cost to bring the vehicle into fleet operable condition. No seized vehicle will be acquired where the cost estimate to put into service exceeds 25% of the vehicle's current appraised value.

6. Fuel economy - Preference is given to vehicles with better fuel economy and vehicles that use renewable energy or are hybrids.


2. Exception to Standards - Any seized passenger vehicle which does not meet the preceding standards and is desired for use in the IRS enforcement fleet because of condition, color, make, or other characteristic, may be applied for and acquired if approved by CI in accordance with applicable delegation orders.

3. Seized Truck Standards - CI will apply national standards to determine under what conditions to acquire seized and forfeited trucks.

4. Motorcycles – The IRS will not bring motorcycles into the enforcement fleet.


**1.14.7.3.2.4** **(08-19-2013)**

##### Law Enforcement Vehicle Standards

1. An "enforcement type" vehicle is a standard vehicle equipped with certain extra features and accessories so that the vehicle will not be readily recognizable as a government-owned vehicle. It will be equipped with certain extra features to provide maximum safety to the driver and the public and with equipment to ensure speed, stamina, and durability to perform under adverse driving conditions. This is not the “police-type vehicle” usually identified with police work.


**1.14.7.3.2.5** **(09-27-2018)**

##### Vehicle Acquisitions — Fuel Conservation and Alternative Fuel Requirements

1. In accordance with the Energy Policy Act (EPAct) of 2005, IRS will acquire AFV unless no infrastructure is available in the area where a vehicle will be located. Drivers must use alternative fuel in all AFV unless the IRS obtains a Department of Energy (DOE) waiver, as required by EPAct 2005 Section 701. Where applicable and to the maximum extent possible, law enforcement vehicles will conform to the preceding provisions.

2. The IRS will not place hybrid vehicles in locations where alternative fuel infrastructure is available to support AFV.

3. The use of Plug-in Hybrid (PIH) vehicles will be required by all federal agencies when they become commercially available at a cost reasonably comparable to non-PIH vehicles, on the basis of life-cycle cost.

4. To meet the requirements set forth by the Energy Policy Acts of 1999 and 2005, EO 13423, and the Energy Independence Act (EISA) of 2007 and to comply with the energy conservation, minimum fuel efficiency, alternative fuel use, and GHG emission reduction standards, all Treasury bureaus including the IRS must:



1. Select vehicles that achieve maximum fuel efficiency.

2. Limit vehicle body size, engine size, and optional equipment to what is essential to meet the IRS mission (Class I and Class II sedans for non-law enforcement; Class III, mid-size sedans for law enforcement).

3. Lease or purchase large (Class IV) sedans or Sport Utility Vehicles (SUV) only when the Treasury Office of Asset Management approves such vehicles as essential to the agency’s mission

4. Lease or purchase vehicles that do not meet the low-GHG emission ratings only if the Treasury Assistant Secretary for Management (ASM) approves these vehicles pursuant to exemption requirements. These requests must state why IRS cannot perform its mission with a low-GHG emitting vehicle and be signed at a level no lower than IRS Deputy Commissioner.

5. Submit a lease versus purchase analysis not later than March 30th of each year for purchased vehicles.

6. Ensure all law enforcement vehicles are properly classified by category LE I, LE II, or LE III, as prescribed in GSA Bulletin FMR B-33.


5. The IRS must submit a justification memorandum to the ASM to increase fleet size. The justification should include the reason for requesting additional vehicle, the category/type of vehicle, primary use, and any special requirements.


**1.14.7.3.3** **(08-19-2013)**

#### Standards for Vehicle Replacement

1. The current GSA minimum replacement standards for government leased vehicles are as follows:



|     |     |     |
| --- | --- | --- |
| **Vehicle Category** | **Fuel Type** | **Years/Miles** |
| Passenger Vehicles | Gasoline or AFV | 3 years and 36,000 miles |
| 4 years and 24,000 miles |
| 5 years and any miles |
| Any years and 75,000 miles |
| Hybrid | 5 years and any miles |
| Light Trucks, 4 x 2 | Non-Diesel | 7 years or 65,000 miles |
| Diesel | 8 years or 150,000 miles |
| Hybrid | 7 years and any miles |
| Light Trucks, 4 x 4 | Non-Diesel | 7 years or 60,000 miles |
| Diesel | 8 years or 150,000 miles |
| Hybrid | 7 years and any miles |
| Medium Trucks, 4 x 2 or 4 x 4 | Non-Diesel | 10 years or 100,000 miles |
| Diesel | 10 years or 150,000 miles |
| Heavy Trucks, 4 x 2, 4 x 4, 6 x 4 or 6 x 6 | Non-Diesel | 12 years or 100,000 miles |
| Diesel | 12 years or 250,000 miles |

2. The current GSA minimum replacement standards for government owned vehicles are as follows:



|     |     |
| --- | --- |
| Vehicle category | Years/Miles |
| Sedans/Station Wagons | 3 years or 60000 miles |
| Trucks less than 12500 pounds GVWR\* | 6 years or 50000 miles |
| 12500-23999 pounds GVWR | 7 years or 60000 miles |
| 24000 pounds GVWR and over | 9 years or 80000 miles |
| 4 or 6 wheel drive motor vehicle | 6 years or 40000 miles |



\*Gross Vehicle Weight Rating


**1.14.7.3.3.1** **(09-27-2018)**

##### Annual Vehicle Replacement

1. GSA leased vehicle replacement worksheets will be sent to the Fleet Program Manager to review and approve replacement requirements.

2. Business units requesting replacement vehicles must provide the following for each replacement requested:



1. Written acknowledgement of the need.

2. Justification of any requirement changes.


3. Business units requesting replacement vehicles which do not meet the GHG score, (i.e., sport utility vehicles or cargo vans) must submit a business case justification of why this type of vehicle is requested. The justification packet must be approved by the IRS Commissioner and submitted to the Department of the Treasury ASM no later than September 30th to receive a functional needs waiver for vehicles to be issued in the subsequent fiscal year.


**1.14.7.3.3.2** **(08-19-2013)**

##### Exceptions to Replacement Standards

1. If a vehicle needs body or mechanical repairs that exceed the fair market value of the motor vehicle GSA may replace it without regard to the minimum replacement standards above (see 41 CFR 102-34.260).

2. When a vehicle is damaged beyond economical repair, survey action is required before disposition. To avoid duplicating accident investigation file materials, survey files may make cross-reference to them. For additional information, see IRM 1.14.4, _Personal Property Management_.


**1.14.7.3.4** **(09-27-2018)**

#### Book Value of IRS Motor Vehicles

1. The book value of a motor vehicle is determined as follows:



1. Purchases - the book value of a vehicle purchased new is its cost as shown on the purchase order and invoice, which included transportation costs to the first delivery destination.

2. Other acquisitions - the book value of all other vehicles acquired by IRS must be the appraised value, as indicated in the acquisition document.


**1.14.7.3.5** **(09-27-2018)**

#### Accepting New Vehicles – Warranty and Acceptance Procedures

1. The GSA publication _Motor Vehicle Warranty, Delivery, and Acceptance Guide_, contains detailed procedures relating to warranty, delivery, and acceptance of motor vehicles by government agencies.


**1.14.7.3.5.1** **(09-27-2018)**

##### Pre-Delivery Inspection Deficiencies

1. Each new vehicle purchased has been inspected at the factory in accordance with GSA requirements. Field activities must spot check new vehicles upon receipt to ensure that factory inspections have been adequately performed. Any deficiencies observed are to be reported to the local FMSS Motor Vehicle Coordinator as soon as noted.


**1.14.7.3.5.2** **(09-27-2018)**

##### Acceptance Procedure

1. The following procedures are to be followed from the time a new vehicle is received until service under warranty is required. Contact your local FMSS Motor Vehicle Coordinator if any damage is discovered while performing the initial vehicle inspection.



1. While carrier damage is not a warranty item, it is the focus of the first inspection to be performed when the new vehicle is delivered. This is a general check for damage or missing parts.

2. If the vehicle was purchased Freight on Board (FOB) destination, correction of any deficiency attributable to the carrier is still the responsibility of the manufacturer, and their appropriate office must be notified.

3. If the vehicle was purchased fob. origin, then the government deals directly with the carrier. Any damage or missing parts must be noted on the Government Bill of Lading (GBL) before the document is signed. The carrier must be given the opportunity to inspect the vehicle without unreasonable delay before the vehicle is repaired. After the vehicle is repaired, the repair invoice amount will be deducted from the carrier’s invoice when IRS is billed for transportation charges. If the damage appears to be so extensive that the repair cost would exceed the transportation cost or repair of the vehicle seems uneconomical, the property officer or authorized representative may refuse to sign for, and refuse delivery of, the vehicle.

4. The receiving office will forward a copy of the receiving report to their local FMSS Motor Vehicle Coordinator.


**1.14.7.3.5.3** **(08-19-2013)**

##### Vehicle Maintenance and Warranty Repairs

1. All personnel involved in acceptance and operation of motor vehicles must comply with the following maintenance and warranty provisions:



1. If the vehicle is still within the manufacturer’s warranty period, it must be taken to the nearest authorized dealer for the make of vehicle for repair at no cost to the government. The warranty/guarantee for purchased IRS vehicles is as stated in the GSA contract of purchase for the applicable year. Expenditures for repairs during the warranty period must be subject to administrative review at all levels

2. The IRS must use recycled products when available, as long as they meet manufacturer warranty requirements. These may include re-refined motor oil, and recycled antifreeze.

3. The vehicle operators must maintain fuel and mileage records and evaluate the cause of any significant change in miles per gallon of fuel used by a vehicle


**1.14.7.3.6** **(08-19-2013)**

#### Transfer of Title

1. Whenever the IRS disposes of a motor vehicle other than by transfer to another federal agency, title is transferred by means of SF-97, _Certificate of Release of a Motor Vehicle_.

2. **Numbering Series -** The Certificates for Release should be sequentially numbered, using the office code number as a prefix, separated by a hyphen, to the series of numbers assigned to avoid duplication.

3. **Signing -** Employees authorized to dispose of property are authorized to sign SF-97 and SF 97-A, _Agency Record Copy of the United States Government Certificate of Release of a Motor Vehicle_, in connection with the release of government-owned motor vehicles.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-014-007#addtoany "Show all")

A2A