---
url: "https://www.irs.gov/irm/part1/irm_01-055-002"
title: "1.55.2 Organizational Changes | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-055-002#main-content)

- 1.55.2  [Organizational Changes](https://www.irs.gov/irm/part1/irm_01-055-002#id1)
  - 1.55.2.1  [Program Scope and Objective](https://www.irs.gov/irm/part1/irm_01-055-002#id2)
    - 1.55.2.1.1  [Authority](https://www.irs.gov/irm/part1/irm_01-055-002#id4)
    - 1.55.2.1.2  [Background](https://www.irs.gov/irm/part1/irm_01-055-002#id5)
    - 1.55.2.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-055-002#id6)
    - 1.55.2.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-055-002#id7)
    - 1.55.2.1.5  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-055-002#id8)
    - 1.55.2.1.6  [Related Resources](https://www.irs.gov/irm/part1/irm_01-055-002#id9)
  - 1.55.2.2  [Policy](https://www.irs.gov/irm/part1/irm_01-055-002#id10)
  - 1.55.2.3  [Submission of Proposals and Procedures](https://www.irs.gov/irm/part1/irm_01-055-002#id11)
    - 1.55.2.3.1  [Inclusions for Reorganization Proposals](https://www.irs.gov/irm/part1/irm_01-055-002#id13)
  - 1.55.2.4  [Change Request (Form 15012)](https://www.irs.gov/irm/part1/irm_01-055-002#id14)
    - 1.55.2.4.1  [Categories](https://www.irs.gov/irm/part1/irm_01-055-002#id15)
      - 1.55.2.4.1.1  [Category A](https://www.irs.gov/irm/part1/irm_01-055-002#id16)
        - 1.55.2.4.1.1.1  [Category A - Instructions](https://www.irs.gov/irm/part1/irm_01-055-002#id18)
        - 1.55.2.4.1.1.2  [Category A - Implementation](https://www.irs.gov/irm/part1/irm_01-055-002#id19)
      - 1.55.2.4.1.2  [Category B](https://www.irs.gov/irm/part1/irm_01-055-002#id20)
      - 1.55.2.4.1.3  [Category C](https://www.irs.gov/irm/part1/irm_01-055-002#id21)
  - 1.55.2.5  [Responsibilities of Functions](https://www.irs.gov/irm/part1/irm_01-055-002#id22)
    - 1.55.2.5.1  [Initiating or Originating Office](https://www.irs.gov/irm/part1/irm_01-055-002#id24)
    - 1.55.2.5.2  [Taxpayer Services Capital Management and Oversight (CMO)](https://www.irs.gov/irm/part1/irm_01-055-002#id25)
    - 1.55.2.5.3  [Learning and Education (L&E)](https://www.irs.gov/irm/part1/irm_01-055-002#id26)
    - 1.55.2.5.4  [Taxpayer Services (TS) Finance](https://www.irs.gov/irm/part1/irm_01-055-002#id27)
    - 1.55.2.5.5  [Business Systems Modernization (BSM)](https://www.irs.gov/irm/part1/irm_01-055-002#id28)
    - 1.55.2.5.6  [Originator](https://www.irs.gov/irm/part1/irm_01-055-002#id29)
  - 1.55.2.6  [Changes Requiring the Taxpayer Services (TS) Chief's Approval](https://www.irs.gov/irm/part1/irm_01-055-002#id30)
  - 1.55.2.7  [Changes Requiring the IRS Commissioner's Approval](https://www.irs.gov/irm/part1/irm_01-055-002#id31)
  - 1.55.2.8  [Approval](https://www.irs.gov/irm/part1/irm_01-055-002#id32)
  - 1.55.2.9  [Implementation](https://www.irs.gov/irm/part1/irm_01-055-002#id33)
    - 1.55.2.9.1  [Implementation Responsibilities](https://www.irs.gov/irm/part1/irm_01-055-002#id35)
  - 1.55.2.10  [Evaluation](https://www.irs.gov/irm/part1/irm_01-055-002#id36)
  - Exhibit  1.55.2-1  [Example of an Organization Chart](https://www.irs.gov/irm/part1/irm_01-055-002#id37)
  - Exhibit  1.55.2-2  [Example of a Summary of Changes Template](https://www.irs.gov/irm/part1/irm_01-055-002#id38)
  - Exhibit  1.55.2-3  [Example of a Costing Template](https://www.irs.gov/irm/part1/irm_01-055-002#id39)
  - Exhibit  1.55.2-4  [Category A (Streamline) Flow Chart](https://www.irs.gov/irm/part1/irm_01-055-002#id40)
  - Exhibit  1.55.2-5  [Category B & C Flow Chart](https://www.irs.gov/irm/part1/irm_01-055-002#id41)
  - Exhibit  1.55.2-6  [Category C Change Checklist](https://www.irs.gov/irm/part1/irm_01-055-002#id42)
  - Exhibit  1.55.2-7  [Taxpayer Services Change Request (TS-CR Form 15012)](https://www.irs.gov/irm/part1/irm_01-055-002#id43)

# Part 1. Organization, Finance, and Management

# Chapter 55. Wage and Investment

# Section 2. Organizational Changes

* * *

## 1.55.2 Organizational Changes

#### Manual Transmittal

August 28, 2025

#### Purpose

(1) This transmits revised IRM 1.55.2, _Taxpayer Services, Organizational Changes_.

#### Material Changes

(1) IRM 1.55.2.1 - Updated program owner for this IRM. Added program goals.

(2) IRM 1.55.2.1.1 - Added Authority

(3) IRM 1.55.2.1.4 - Added Program Management and Review

(4) IRM 1.55.2.1.5 - Added terms and acronyms applicable to this IRM.

(5) IRM 1.55.2.4.1.2 - Added an additional note to clarify position description changes.

(6) IRM 1.55.2.4.1.3 - Removed reference to Equity, Diversity, and Inclusion per January 2025 Executive Order.

(7) IRM 1.55.2.9.1(7) - Removed paragraph- Diversity, Equity, Inclusion, and Accessibility; removed references related to diversity per January 2025 Executive Order.

(8) Exhibit 1.55.2-3 - Updated example of a costing template.

(9) Exhibit 1.55.2-4 - Updated Category A Flow Chart.

(10) Exhibit 1.55.2-5 - Updated Category B & C Flow Chart.

(11) Exhibit 1.55.2-6 - Updated Category C Checklist.

(12) Exhibit 1.55.2-7 - Updated Form 15012. Added web address to IRS Published Product Catalog.

(13) Extensive editorial and format changes (e.g., changing bullet lists to alpha and/or numeric lists) were made throughout this IRM section. Organizational, formal titles, and related resources were updated throughout.

#### Effect on Other Documents

This IRM revision supersedes the IRM 1.55.2 dated November 29, 2018.

#### Audience

Program Management employees within Customer Assistance, Relationships and Education (CARE), Customer Account Services (CAS), Return Integrity and Compliance Services (RICS), and Headquarters (HQs) organizations in the Taxpayer Services (TS) Division preparing requests for organizational change.

#### Effective Date

(08-28-2025)

LaFondra N. Barlow

Acting Director, Capital Management and Oversight

Operations Support

Taxpayer Services Division

**1.55.2.1** **(08-28-2025)**

### Program Scope and Objective

1. IRM 1.55.2, Taxpayer Services, Organizational Changes, provides an overview and procedures for requesting organizational changes to and for the Taxpayer Services Division (TS) organizational structure.

2. **Purpose:** The purpose of this IRM Section is to establish policies and procedures to govern the review and approval of proposed organizational changes within the Taxpayer Services Division. The review, concurrence and approval process for the request will depend on the scope and magnitude of the recommended changes.

3. **Audience:** Program Management employees within Customer Assistance, Relationships and Education, Customer Account Services, Return Integrity and Compliance Services, and Headquarters organizations in the Taxpayer Services Division preparing change requests.

4. **Policy Owner:** Director, Capital Management and Oversight (CMO)

5. **Program Owner:** Workforce Planning (WP)

6. **Primary Stakeholders:** Program management and leadership staffs within Customer Assistance, Relationships and Education (CARE), Customer Account Services (CAS), Return Integrity and Compliance Services (RICS), and Headquarters (HQs) organizations in the Taxpayer Services (TS) Division.

7. **Program Goals:** The goals of the TS Division parallel the IRS strategic goals to provide service to all taxpayers and increase productivity through a quality work environment. This is accomplished by:



   - Attracting, retaining, and empowering a highly skilled workforce and develop a culture that is better equipped to deliver results for taxpayers.

   - Continuing partnerships to tackle common challenges, generate cost savings and share leading practices.

   - Supporting employee development with training opportunities and clear career paths.

   - Enhancing succession planning and knowledge transfer processes.


8. The TS Division will gauge progress in achieving these goals through measures and objectives that have been established for all the TS Operating Units. Our measures continue to be refined as programs and priorities evolve.


**1.55.2.1.1** **(08-28-2025)**

#### Authority

1. TS Workforce Planning is guided by following:



   - IRM 1.1.4, _Organizational Planning_

   - IRM 6.511.1, _Position Management and Classification Policy and Operational Guidance_


2. Treasury Directive 21-01, Organizational Changes


**1.55.2.1.2** **(11-29-2018)**

#### Background

1. The following guidance is intended to serve as a framework for managing our organizational change process. It outlines the responsibilities of key officials and provides detailed procedures for processing and evaluating proposals that may originate from many sources (both internal and external to TS). The "goal" of this decision-driven process is to ensure that all proposals to realign elements of the new organization are properly added, planned, implemented, and evaluated.

2. Managers are responsible for ensuring sound organizational structures by continually evaluating the effectiveness and efficiency of their business units. Managers are encouraged to streamline and maintain as "flat" an organization as possible.

3. Once a decision is made to modify the current structure, it should be communicated and implemented in a manner that:



   - Supports the strategic vision

   - Minimizes disruption to business operations

   - Ensures the continuity of essential employee services


**1.55.2.1.3** **(11-29-2018)**

#### Roles and Responsibilities

1. The Director, Capital Management and Oversight (CMO) is responsible for overseeing the governing policy for TS organizational changes.

2. The Branch Chief, Workforce Planning (WP) is responsible for:



   - Establishing policies, procedures, standards, and controls for TS organizational changes.

   - Ensuring compliance with the procedures.

   - Monitoring, tracking, reviewing, assessing, and implementing organizational changes.


**1.55.2.1.4** **(08-28-2025)**

#### Program Management and Review

1. Organizational Changes encompasses a structured approach organizational design, including planning and implementation of changes.

2. The formal process for submitting, tracking, and approving change request is through e-trak, this ensures that all changes are properly documented and reviewed prior to implementation.

3. Workforce Planning utilizes various tools and resources to ensure the proposed organizational structures aligns with the IRS mission and objectives. These tools and resources include but is not limited to:



   - HRConnect

   - IRS Human Resources Reporting Center

   - e-trak

   - Standard Position Description Library


**1.55.2.1.5** **(08-28-2025)**

#### Terms and Acronyms

1. Definitions are added to establish common terminology in TS:




| **Term** | **Definition** |
| :-: | :-: |
| Approving Official | The management official authorized to approve/disapprove implementation of a proposed reorganization in TS. |
| Branch Chief | A title of address for the senior manager of Workforce Planning. |
| Chief | A title of address for the head of TS Division. |
| Director | A title of address for the head of a unit reporting to the TS Chief and/or an individual reporting to the head of the unit. The title "Director" is usually reserved for executives or board covered positions. Areas will be headed by directors and will be titled.<br> <br>### Example:<br>Director, Area 4 Fresno or Field Director, Austin-Submission Processing. |
| Function | All or a clearly definable group of activities performed to achieve an organization's mission. A concise statement about the purpose of an organization expressed in terms of what the organization produces and for whom. |
| Organization Chart | A diagram of boxes that shows the management titles of each organization and unit. Each box should contain the number of positions by pay plan, series, grade, bargaining unit status, position number, and span of control (SOC). The organization chart establishes the reporting relationships of organizations by lines between superior and subordinate organizations. |
| Organizational Design | A process concerned with establishing and/or changing a group of functions, reporting relationships, and workflow to achieve its mission and goals. Organizational design decisions are documented in the form of organizational charts and mission, and functional statements. |
| Realignment | Employees in a single organization are moved to a new organization within their business or functional unit, and there is no change in that organization’s mission or function. A realignment does not result in any impact to the employees' current position or status, e.g., series, grade, and/or work schedule. |
| Reorganization | A change to an organization that generally eliminates, adds, or realigns the functions or duties of an organization; specifically changes the mission, function, or organizational structure, including geographical boundaries and jurisdiction, reporting lines, office names, and managerial titles. |
| Reorganization Proposal | The written description and justification for a desired reorganization including the business case for the change, and other pertinent facts essential for the reviewing and approving officials to make an informed decision. |
| Point of Contact | Individual or office assigned primary responsibility for the development and coordination of the reorganization proposal. |
| Position Management | The structuring of positions into the most efficient and effective organization to accomplish the mission. Position Management is concerned with such issues as job design, career ladder development, ratio of supervisors to subordinates (SOC), excessive use of deputies and assistants, types of positions, contracting possibilities, and cost/benefit analysis. |
| Transfer of Function | The transfer of all or part of an existing function from one organization to another. |
| Unit | Any organizational component. |

2. Campus manager title includes the following:



1. **Field Director:** Head of office delegated authority to oversee the overall planning, direction, timely execution of a variety of programs, the assignment, development and clearance of goals and objectives for subordinate organizations.

2. **Operations Manager:** Level of management responsible for all programs under the jurisdiction of the field director; a campus expert that is called upon to participate in policy and decision-making activities.

3. **Department Manager:** Level of management responsible for developing and implementing necessary plans and schedules for the accomplishment of organizational objectives.

4. **Team Manager/Section Chief:** Level of management responsible for directing, assigning, and reviewing the work of subordinate employees, planning, scheduling, and coordinating work operations.


3. The following acronyms appear throughout this IRM:




| **Acronym** | **Term** |
| :-: | :-: |
| BSM | Business Systems Modernization |
| CARE | Customer Assistance, Relationships, and Education |
| CAS | Customer Account Services |
| CMO | Capital Management and Oversight |
| FTE | Full Time Equivalent |
| GS | General Schedule |
| HCO | Human Capital Office |
| OpSB | Operations Strategy Board |
| OS | Operations Support |
| PAR | Personnel Action Request |
| PMO | Program Management Office |
| RICS | Return Integrity and Compliance Services |
| ROC | Request for Organizational Change |
| SOC | Span of Control |
| WP | Workforce Planning |
| TS | Taxpayer Services |
| TS-CR | Taxpayer Services Change Request |


**1.55.2.1.6** **(11-29-2018)**

#### Related Resources

1. The following lists the primary sources of guidance on organizational changes:



   - IRM 1.1.4, _Organizational Planning_

   - IRM 1.1.13, _Taxpayer Services_

   - IRM 6.511.1, _Position Management and Classification Policy and Operational Guidance_


**1.55.2.2** **(06-17-2015)**

### Policy

1. The following principles govern organizational design within the TS Operating Division. Organizational structures should be designed to:



1. Establish business practices, which provide the highest level of customer service at the lowest possible cost.

2. Reduce overhead expenses by encouraging the use of collocated facilities, shared office space, consolidating support services, and eliminating functional duplication.

3. Flatten existing organizational structures by eliminating fragmentation and empowering employees engaged in providing direct service to the customer.

4. Eliminate unnecessary supervisory positions and organizational levels.

5. Utilize the talents and capabilities of all employees.


**1.55.2.3** **(11-29-2018)**

### Submission of Proposals and Procedures

1. There are three categories of reorganization, Category "A" , "B" and "C" . The content of the reorganization proposal package varies depending on the category of the request.

2. Any individual in TS may submit a reorganization proposal through the appropriate channels. However, each functional unit has procedures and processes in place that centralize this function.


**1.55.2.3.1** **(11-29-2018)**

#### Inclusions for Reorganization Proposals

01. The following are components of reorganization proposals:

02. **Statement of purpose or need:** Describes the changes being proposed and the result that the organizational change is expected to achieve. Proposed changes should support the strategic direction, vision, goals and objectives of TS.

03. **Proposed changes and the rationale behind those changes:** Include and/or address (but are not limited to) the following:



    1. Budgetary costs and benefits (including subsequent years).

    2. Number of executive/managerial positions needed.

    3. Overall effect on GS-301/343 staffing.

    4. Number of GS-14s, GS-15s, and senior manager (SM) positions.

    5. SOC and grade structure.

    6. Employee labor relations issues.

    7. Effective date of the change.


04. **Stakeholder Engagement:** Identify stakeholder engagement and what coordination went into the proposal during the early planning stages of the reorganization.

05. **Change Request Form:** See _Exhibit 1.55.2-7_ _Form 15012, **Taxpayer Services Change Request (TS-CR)**._ The form is also located on the IRS Published Product Catalog.

06. **Organization Charts:** Include appropriate information based on category.



    1. **"Category A" :** Campus operations should include a copy of their Current Approved Organization Chart that reflects a 12-18 month period; if a Current Approved Organization Chart has not been established, you must submit your last quarterly working organization chart. In addition, a proposed organization chart must be provided. Headquarters (HQ) operations should include a copy of their Current Approved Organization Chart. In addition, a proposed organization chart must be provided.

    2. **"Category B"** : Prepare organization charts, both current and proposed, that describe in detail the current and proposed organization. See _Exhibit 1.55.2-1_, _Example of an Organization Chart_.

    3. **"Category C"**: Prepare organization charts, both current and proposed, that describe in detail the current and proposed organization. See _Exhibit 1.55.2-1_, _Example of an Organization Chart_.


07. **Organization Code Request Form:** Located on the TS WP SharePoint site.

08. _Summary of Change:_ Prepare staffing charts that reflect the difference between the current and proposed staffing. List the position titles, series, and grades, showing the current and proposed staffing numbers and the net change, in column format. Highlight staffing increases or variance from existing staffing guides and justify differences. Located on the TS WP SharePoint site.



    ### Note:



    This component is optional. Similar information is captured in the costing worksheet.

09. **Mission and Functional Statements:** Provide current and proposed mission and functional statements. Mission and functional statements must be in accordance with IRM 1.1.13, _Taxpayer Services_, and account for all impacted functions.

10. **Costing Worksheet**(Cost and benefit analysis)**:** Compute benefits and/or dollar savings anticipated. Organizational change should result in a more efficient organization in addition to reduced costs. See _Exhibit 1.55.2-3_, _Example of a Costing Worksheet_. The Costing Worksheet is located on the TS WP SharePoint site. List and analyze the following:



    - Costs

    - Staffing

    - Benefits (particularly cost savings for personnel and support services)


### Example:

Space, equipment, relocation, telecommunications, supplies, etc.

|     |
| --- |
| **_Notes:_**<br>    1. Also analyze other tangible costs and benefits and separate by budget line item and address base cost adjustments, one-time costs, and revised operating costs. Explain or propose how additional information cost will be funded and identify when the funds will be required. Address whether additions or changes will increase or decrease the authorized staffing pattern (ASP); information is required by the reviewers and approving official to determine the availability or commitment of funds.<br>       <br>    2. Costing worksheets must be updated annually. |

11. **Impact and Implementation Statement:** Provide a schedule for implementation that illustrates when proposed change(s) will go into effect. Highlight milestones essential to successfully accomplishing the organizational change.

12. **Issues:** Describe the issues to be resolved and propose how they are to be resolved.



    ### Example:



    Financial codes, Work Planning and Control (WP&C), personnel and office codes, etc.


**1.55.2.4** **(11-29-2018)**

### Change Request (Form 15012)

1. Form 15012, _**TS Change Request (TS-CR)**_, provides a standard format to aid in processing, controlling, and coordinating internally generated proposals.

2. The TS-CR will serve as the change control vehicle for documenting final decisions.

3. For an example of the form and instructions, see _Exhibit 1.55.2-7_, _**TS Change Request (TS-CR)****Form**._

4. Specific instructions for completing the TS-CR Form 15012 for each category and routing of requests for management review and approval are found in the following subsections.



### Reminder:



The Form 15012 is not an appropriate vehicle for accommodating the personal preferences or needs of individual employees, such as work/group assignments, post of duty designations, etc. Such should be handled through normal management channels in conformance with applicable human resource policies and procedures.


**1.55.2.4.1** **(11-29-2018)**

#### Categories

1. The proposed organizational change should be classified in one of three categories: "A" , "B" , or "C" , based on the nature, scope and expected impact.



1. **Category A –** Apply to the simplest of requests to realign. If no adverse employee contact, consider cost neutral.

2. **Category B –** Apply to significant changes, which alter reporting relationships or involve multiple business functions, e.g., CARE, CAS, and RICS, within one business operating division (BOD), e.g., TS, that will require approval by the division Chief. These changes must be presented to the Operations Strategy Board (OpSB).

3. **Category C –** Apply to major changes, which alter reporting relationships or involve multiple BODs, such as, Small Business/Self-Employed (SB/SE), Large Business and International (LB&I), and Tax Exempt/Government Entities (TE/GE), that will require approval by the IRS Commissioner. These changes must be presented to the OpSB and concurred with by the TS Chief.


2. The following subsections are general descriptions of each category and can serve as a guide for determining approval levels and the extent of pre-decisional coordination that may be required.


**1.55.2.4.1.1** **(06-17-2015)**

##### Category A

1. "Category A" proposals affect very limited components of the overall organization and costs are sustained within the approved work plan/work schedule (campuses) or within the full-time equivalent (FTE) allocation (headquarters).

2. In "Category A" proposals, the campus director or HQ Director certifies that the change will have no known impact on other offices or programs and does not violate existing labor/management agreements.

3. Following are examples of "Category A" changes:



1. Establish new or temporary teams to accommodate new hires if funding was previously authorized by TS Finance

2. Reassign or realign employees or groups of employees to other groups or territories

3. Collapse or combine existing teams, departments, groups, or territories

4. Eliminate vacant positions no longer needed

5. Change names of groups, teams, departments, etc.

6. Capture the results of applicable position classification audits


**1.55.2.4.1.1.1** **(11-29-2018)**

###### Category A - Instructions

1. Complete the TS-CR Form 15012, Category A designation in accordance with the TS-CR template instructions; see _Exhibit 1.55.2-7_, _**Taxpayer Services Change Request (TS-CR Form 15012)**._

2. Prepare the proposed organization chart.

3. Complete the costing template located on the TS WP SharePoint site.

4. Complete the Organization Code Request Form (Org. A Form) located on the TS WP SharePoint site.

5. The originator will review and perfect the package.

6. The originator will obtain the director's approval and transmit via e-Trak; then, package and deliver to TS Finance to obtain concurrence.

7. The Branch Chief, WP will review and obtain the Directors, Capital Management and Oversight and Taxpayer Services Operations Support’s concurrence, securing the organization code/naming convention, and if applicable discuss employee impact and implementation issues.


**1.55.2.4.1.1.2** **(11-29-2018)**

###### Category A - Implementation

1. CMO,WP notifies the originator when the new organizational codes are issued, and implementation of the change can begin.



### Note:



Implementation should not begin until notification is received from CMO.

2. The approving director, or their staff, is responsible for coordinating necessary personnel action requests (PARs) and ensuring system changes (i.e., Integrated Collection System (ICS), Examination Return Control System (ERCS), Procurement for Public Sector (PPS), and ConcurGov) are initiated and completed timely.

3. The approving director, or their staff, is responsible for converting the "proposed" chart to the "approved" version.

4. Upon completion of the conversion, send a copy of the current approved structure to TS CMO for the master file.



### Note:



To ensure the financial system is updated, please allow ample time after organizational codes are established, before submitting PARs, i.e., two pay periods.


**1.55.2.4.1.2** **(08-28-2025)**

##### Category B

1. "Category B" proposals are significant organizational changes that involve or affect multiple business units or functions within one BOD.

2. These proposals add additional positions not previously funded, incur additional costs, or involve changes in types of positions, grade/series, program activities, work processes, or geographic locations. These types of changes require concurrence of the TS OpSB, executive directorate, or the TS Senior Leadership Team (SLT), and the approval of the TS Chief.



### Note:



Exception of presentation of Category B CRs will be for those organizations that are funding changes within their own allocations.

3. Examples of "Category B" requests may include:



   - Increase in the number of higher grades (GS-14 and GS-15 non-supervisory).

   - Increase in the numbers of overhead or staff positions (deputy, staff assistants, and series 343/301).

   - Upgrade of position or positions, not preceded by desk audit or grade structure change.

   - Decrease in the supervisor to employee ratios (span of control) below the minimal acceptable level.

   - Creation of additional management layers.

   - Transfer of management and program responsibility from one operating function to another.



     ### Example:



     Transfer Business System Planning (BSP) from CMO to Business Modernization Office (BMO).





     ### Note:



     Position description updates based on recertification/reclassification that do not alter the title, series, and grade of the position will not require a change request. The updates may be accomplished with pen and ink changes to the organizational chart.


4. "Category B" proposals must receive concurrence of the director of the function, the Director, CMO, and the Director, TS OS prior to approval by the Chief, TS.

5. Implementation dates and schedules will be established by the TS Chief in consultation with the functional directors. Major workforce impact should be coordinated with the Director, CMO.


**1.55.2.4.1.3** **(08-28-2025)**

##### Category C

1. "Category C" proposals are major organizational changes in which the scope and impact directly affect other BODs, e.g., SB/SE, LB&I, and TE/GE. _Exhibit 1.55.2-5._, _Category B & C Flow Chart_.

2. "Category C" proposals require prior approval by the IRS Commissioner in consultation and coordination with executives in other affected BODs. These changes may require coordination with several staff offices such as:



   - Program Execution Office (PEO) and Workforce Restructuring Services (WRS)

   - Facilities Management and Security Services (FMSS)

   - Communication and Liaison (C&L)

   - Legislative Affairs

   - Information Technology (IT)

   - Chief Financial Officer (CFO)


In addition, changes may require review and concurrence of Human Capital Board (HCB).



3. Only the TS Chief can make designation of "Category C" (and related recommendations).

4. Schedules and timetables for implementation require full coordination with all operating areas and support organizations.


**1.55.2.5** **(06-17-2015)**

### Responsibilities of Functions

1. Responsibilities are assigned in the following manner. These responsibilities may occur during the planning, proposal, or implementation phase.


**1.55.2.5.1** **(11-29-2018)**

#### Initiating or Originating Office

1. Depending on the category of the reorganization, the initiating office may be involved in any or all of the following:



1. Coordinates with appropriate officials such as the PMO, TS Finance, and CMO functions for assistance in planning the reorganization

2. Prepares the proposal following procedures established in this IRM or as referenced on the TS-CR Form 15012

3. Ensures the organizational change package has been vetted with TS Finance prior to obtaining director’s approval

4. Ensures coordination with officials with vested interest in the proposal, i.e., bargaining units and partnerships as appropriate

5. Consults with TS CMO, TS Finance, and the Human Resources (Consultant) specialist during the developmental stages of change request

6. Implements or assists in the implementation of the approved organization change proposal

7. Coordinates with Real Estate and Facilities Management and Information Technology staff to address space, property, telecommunications, computer needs, distribution/mail system changes, and security requirements

8. Provides an approved copy of the complete proposal to CMO WP and loads the approved package into e-Trak


**1.55.2.5.2** **(11-29-2018)**

#### Taxpayer Services Capital Management and Oversight (CMO)

1. Depending on the category of the reorganization, TS Capital Management and Oversight (CMO) may be involved in any or all of the following:



01. Reviews the proposal for completeness and accuracy of required documentation.

02. Ensures assignment and coordination of organizational structure and cost center codes.

03. Ensures employee impact issues are addressed.



       ### Note:



       Workforce Relations and Performance Management (WRPM) determines and assesses implementation and impact on bargaining unit employees, ensuring compliance with IRS/National Treasury Employees Union (NTEU) National Agreement provisions and/or negotiates a memorandum of understanding (MOU) as appropriate.

04. Ensures position management and classification issues are addressed and coordinated with responsible officials.

05. Coordinates review with staff offices such as PMO, TS Finance, WP, WRPM, and Learning and Education (L&E).

06. Conducts an analysis of the proposal.

07. Provides guidance on personnel, training, and local Labor Relations' actions.

08. Recommends approval/disapproval of package prior to submission to the TS SLT or TS OpSB for input and TS Chief for approval.

09. Coordinates with FMSS to ensure personnel payroll updating, organizational titles, series, and occupational changes are made.

10. Maintains and updates organizational charts.

11. Coordinates change with the Director, TS OS.

12. Monitors analyst (series 301/343) and high grade (GS-14, GS-15, and SM) positions.

13. Ensures organizational change includes organizational charts along with information to show the organization title, supervisory position title, supervisory position (reports to), organizational symbols, mission, and functional statements, and functions that report to that supervisory position that were included with the change request supporting information to the Workforce Planning Office for the purpose of updating IRM 1.1.13, Taxpayer Services Division.


**1.55.2.5.3** **(06-17-2015)**

#### Learning and Education (L&E)

1. Learning and Education (L&E):



1. Assesses current training needs of the business unit(s)

2. Forecasts future training needs

3. Coordinates budget allocations


**1.55.2.5.4** **(06-17-2015)**

#### Taxpayer Services (TS) Finance

1. The TS Finance office:



1. Maintains correct financial codes, and ensures payroll is correctly charged

2. Provides advice and assistance on financial structures

3. Coordinates changes to financial systems and officially notifies all affected financial offices

4. Reviews, assesses, concurs and consults with the originator on the financial impact of all change request before the director approves the change


**1.55.2.5.5** **(11-29-2018)**

#### Business Systems Modernization (BSM)

1. Business Systems Modernization (BSM) reviews organizational changes, if appropriate, and determines if administrative and business systems are updated as necessary.


**1.55.2.5.6** **(08-28-2025)**

#### Originator

1. The Originator:



1. Prepares and implements the reorganization proposal, obtains review by approving officials, and forwards the proposal to the Branch Chief, Finance, WP, and, if necessary, consults with BSM

2. Ensures business needs are addressed, and all required documentation is included with submission


**1.55.2.6** **(11-29-2018)**

### Changes Requiring the Taxpayer Services (TS) Chief's Approval

1. All "Category B" organizational changes must be presented to the TS OpSB or TS SLT for concurrence and approved by the TS Chief.

2. The business unit director (e.g., CARE, CAS, RICS), the Director, TS CMO and the Director, TS OS will review/concur with the proposals prior to the review of the TS Chief, or TS Deputy Chief. See _Exhibit 1.55.2-5_, _Category B & C Flow Chart_.

3. All proposed changes (listed below) to functions, offices, branches, operations, departments, teams, sections or units below the Director’s level are required in writing including:



   - Establishment

   - Realignment

   - Abolishment

   - Transfer


**1.55.2.7** **(11-29-2018)**

### Changes Requiring the IRS Commissioner's Approval

1. The following changes must be approved in advance by the IRS Commissioner because these changes may affect our internal and external customers, budget, personnel, and mission essential programs:



   - Establishment, realignment, abolishment, or transfer of division

   - Establishment, realignment, abolishment, or transfer of director level organizations

   - Establishment, realignment, abolishment, or transfer of areas

   - Changes in IRS management of SES and /or critical pay positions as part of a formal reorganization

   - Changes resulting in Directed Reassignments outside the commuting area (unless there is a mobility agreement and /or job establishment (must be encumbered position))

   - Changes requiring adverse action, the use of mitigating strategies, or resulting in a reduction in force (e.g., negative impact to employee, displaced employees)


2. It is imperative to coordinate proposed changes with executives and representatives in other divisions.

3. The TS Chief must coordinate and concur with the request for change before forwarding it to the IRS Commissioner/Deputy Commissioner. All proposed changes are required in writing and must address the business case.


**1.55.2.8** **(11-29-2018)**

### Approval

1. "**Category A**" proposals must be routed through normal managerial channels to the campus or headquarters (HQ) Director; Branch Chief; Finance; Director, CMO; and Director, TS OS for approval and concurrence.

2. "**Category B**" proposals must be routed through normal managerial channels to the campus or HQ Director; Branch Chief, Finance; Director, CMO; and Director, TS OS prior to submission to the TS OpSB, TS SLT, TS Chief, or TS Deputy Chief for approval.

3. "**Category C**" proposals must be routed through normal managerial channels through the campus or HQ Director; Branch Chief, Finance; Director, TS CMO; and Director, TS OS prior to submission to the TS OpSB, TS SLT, TS Chief and, the IRS Commissioner for approval.


**1.55.2.9** **(06-17-2015)**

### Implementation

1. Once approved in writing, the implementing official, as agreed or designated by the approving official, may begin implementation.

2. Management should allow at least six weeks to complete the implementation phase of a "Category B" or "Category C" proposal. This time will allow proper notification of offices and functions with vested interest in the reorganization. Implementation responsibilities are listed in the following subsection.



### Note:



Category A changes are not as broad in scope or impact and may take significantly less time to implement. See _IRM 1.55.2.4.1.1.1_, _Category A Instructions_, for more information.


**1.55.2.9.1** **(08-28-2025)**

#### Implementation Responsibilities

1. **Implementing Office/Official/Contact Point:**



1. Notifies support personnel and other functions to take necessary actions

2. Coordinates Labor Relations/Employee Relations (LR/ER) issues with WRPM

3. Coordinates talent, human resources and position management issues with WP

4. Revises the IRM and other governing directives

5. Ensures actions are accomplished


2. **CMO:**



1. Ensures correct financial coding and coordinates all changes with the Chief Financial Officer staff; the financial codes are then forwarded to Human Resources Shared Services (HRSS), Philadelphia Payroll Center

2. Coordinates change to the financial systems and notifies unit financial offices


3. **HRSS, Philadelphia Payroll Center:**



1. Updates organizational titles and structure codes in personnel systems

2. Adds, changes, or deletes organizational codes in personnel systems codes; updates report formats and reports distribution list

3. Notifies appropriate Employment Operations Associate Director when to implement changes


4. **HRSS, Employment Office (Servicing) and Servicewide HCO:**



1. Makes needed personnel changes

2. Provides guidance on employee impact

3. Obtains special authorities, if necessary



      ### Example:



      Waivers and/or extensions


5. **CMO, WRPM Liaison:**



1. Determines labor relations implications

2. Prepares notification to the union and coordinates union bargaining proposal

3. Assists in negotiations on the impact or implementation of the reorganization


6. **CMO, WP:**



1. Reviews change proposals for completeness and ensures change addresses the business case

2. Addresses mitigation strategies (reassignments, Voluntary Early Retirement Authority (VERA)/Voluntary Separation Incentive Payment (VSIP), placement programs, out placement options)

3. Coordinates with all that have vested interest (e.g., when the CR is approved, provides TS Finance with a copy of the approval)

4. Adds new organizational chart to TS CMO shared site


7. **TS Learning and Education:**



1. Determines the training needs and, if necessary, arranges reprogramming or supplementing the training budget to meet the needs

2. Arranges for the distribution of training materials and writes guidelines


**1.55.2.10** **(06-17-2015)**

### Evaluation

1. To determine whether a given reorganization is effective, it may be necessary for the approving official to request an evaluation. At the time of approval, the approving official decides when, how, and by whom the proposed evaluation plan will be carried out.


**Exhibit 1.55.2-1**

### Example of an Organization Chart

The preferred formats for organizational charts are Microsoft PowerPoint, Microsoft Word, and Microsoft Visio.

![This is an Image: 37989007.gif](https://www.irs.gov/pub/xml_bc/37989007.gif)

> Exhibit 1.55.2-1, Example of an Organization ChartThis is an illustration of an example of an organization chart and includes the components outlined below.Top center, a box denotes the Office of the Director with the total number of employees shown to the right (46). Listed within this organizational component are the positions therein and the number, to the left, of each staff year allocated for the position, including: 1 position, IR-1035-01 Dir PD# 94873 NBU1 position, GS-1035-14 Public Affairs Spec PD# 94890 NBU1 position, GS-0343-12 Staff Asst PD# 92671 NBU1 position, GS-0318-08 Secretary PD# 92394 NBUBelow these positions, the total ratio is shown for manager and employees, including direct reports (1:6); to the right, the total number of employees (7) is shown.The highest-level organizational component referenced above for this example displays lines or dependencies to three lower-level organizational components including: Group 1Group 2Group 3Descriptions of these and other organizational components are detailed belowGroup 1 organization entries include: 1 position, IR-1035-03 Sup Pub Aff Spec PD# 96219 NBU1 position, GS-1035-14 Public Affairs Spec PD# 94890 NBU2 positions, GS-1035-14 Sr Comm. Analyst PD# 93139 BU6 positions, GS-1035-13 Comm. Analyst PD# 93409 BU1 position, GS-0343-11 Prog/Mgmt Analyst PD# 92762 NBUThe total ratio for managers and employees shown is 1:10; the total number of employees for this component is 11.Group 2 organization entries include: 1 position, IR-1035-03 Sup Pub Aff Spec PD# 96219 NBU3 positions, GS-1035-14 Sr Comm. Analyst PD# 93139 BU6 positions, GS-1035-13 Comm. Analyst PD# 93409 BU1 positions, GS-0344-07 Mgmt Asst (OA) PD# 93075 NBUThe total ratio for managers and employees shown is 1:10; the total number of employees for this component is 11.Group 3 organization entries include: 1 position, IR-1035-01 Sup Pub Aff Spec PD# 94873 NBU1 position, GS-0343-14 Sr Prog /Mgmt Analyst PD# 90000 BU1 position, GS-0343-13 Prog Mgmt Analyst PD# 90000 BU1 position, GS-1035-14 Sr Comm. Analyst PD# 93139 BU3 positions, GS-1035-13 Comm. Analyst PD# 93409 BU1 position, GS-1035-09 Comm. Analyst PD# 92133 BU1 position, GS-0344-07 Mgmt Asst PD# 93075 NBUThe total ratio for managers and employees shown is 1:9; the total number of employees for this component is 10.The organizational entry for Group 3 also includes a direct report component, Group 3B, detailed below.Group 3B organization entries include: 1 position, IR-1035-05 Sup Pub Aff Spec PD# 92125 NBU10 positions, GS-1035-11 Comm. Analyst PD# 92132 BUThe total ratio for managers and employees shown is 1:10; the total number of employees for this component is 11.

[Please click here for the text description of the image.](https://www.irs.gov/media/129926 "")

**Exhibit 1.55.2-2**

### Example of a Summary of Changes Template

![This is an Image: 37989008.gif](https://www.irs.gov/pub/xml_bc/37989008.gif)

> The graphic shows an example of a completed summary of changes template. Below the graphic are instructions for completing the template based on the 7 items labeled on the template.

[Please click here for the text description of the image.](https://www.irs.gov/media/129931 "")

The information below provides description for the above graphic as well as instructions for completion of the template.

**Instructions for Summary of Changes Template**

1\. **Name of Agency or Staff Office** \- Enter the name of the agency or staff office.

2\. **Grades** \- List by grade for all units and/or functions identified.

3\. **Current**\- Enter a summary of current FTEs for all units and/or functions identified.

4\. **Proposed** \- Enter a summary of proposed FTEs for all units and/or functions identified.

5\. **Variance** \- Enter the difference between proposed and current FTEs.

6\. **Annual Costs** \- Enter a summary of current annual costs, proposed annual costs, and difference between current and proposed annual costs for the Current fiscal year (FY). Cost should be broken down by "Salary and Benefits" and "Other" . "Other" includes travel, supplies, and equipment costs related to the identified FTEs.

### Note:

A reduction in FTEs and salary and benefit costs usually results in a reduction in "Other" costs.

7\. **Supervisor/Employee Ratio** \- Enter a summary of current Supervisor to Employee Ratio and proposed Supervisor to Employee Ratio.

### Note:

The numbers should equal the actual staff years before and after the proposed reorganization. Assume that all Senior Executive Service (SES) and senior level positions are filled when completing the FTE information.

**Exhibit 1.55.2-3**

### Example of a Costing Template

FY 2025 Position Costing Template Instructions

See the TS WP SharePoint site for all worksheets, spreadsheets, and additional information referenced below for salary tables not included in this exhibit.

**General Instructions:** The worksheet needs to be filled out for each Organizational Change Request following the specific instructions below. Salary Tables provide a representative salary rate for each position at step five of the grade or mid-level of the pay band for each of the geographic localities, please do not adjust. In addition, spreadsheets used for these purposes calculate the total annual salary for the current and proposed organization, along with benefits, and the variance between the current and proposed organizations.

**Specific Instructions:**

1. Provide the financial information only for the area(s) affected by the request.

2. In cell **A4** of the worksheet, type in requesting organization's name. The worksheet allows the user to select a location for this item.

3. In Cell **B5**, select (from the drop-down list) the geographic location of the organization. This is used to determine average salaries based on locality pay. The default is **Rest of US** for multiple locations or for areas not listed.

4. In Cell **B6**, select (from the drop-down menu) the date the organizational change is effective. Leave blank if not effective until the next fiscal year.

5. Provide the current (Columns **B** through **F**) and proposed (Columns **J** through **N**) total number of positions by pay band and grade level only for the area(s) affected by the request.

6. Once complete, print the Worksheet spreadsheet and include it in the Organizational Change Package for review and signature.


![This is an Image: 37989021.gif](https://www.irs.gov/pub/xml_bc/37989021.gif)

> Use the preceding instructions for this form as supplemental descriptive information for this graphic; the information below describes the remainder of the Costing Template in detail.The worksheet is segmented into a fillable table with self-calculating cells; the information in the preceding instructions describes the primary fields. The detailed portion, in table form, is displayed in matrix form, including rows and columns.A central item (or cell) in the upper left portion of the table denotes Grade Summary, describing the rows and columns included.Rows include the following entries: ES (Executive)AD (Critical Pay)SLIR-01IR-02IR-03IR-04IR-05IR-06IR-07IR-08IR-09IR-10IR-11IR-12IR-13GS 15GS 14GS 13GS 12GS 11GS 10GS 9GS 8GS 7GS 6GS 5GS 4GS 3GS 2GS 1Columns include two primary, high-level columns for: Current OrganizationProposed OrganizationVarianceComponents, or sub-columns, of the Current Organization portion include: Number of Positions, which includes sub-columns for Full-Time Perm, Seasonal, Intermittent, P and Q.Average Salary of GradeTotal Annual SalaryTemp SalaryComponents, or sub-columns, of the Proposed Organization portion include: Number of Positions, which includes sub-columns for Full-Time Perm, Seasonal, Intermittent, P and QAverage Salary of GradeTotal Annual SalaryTemp SalaryComponents, or sub-columns, of the Variance portion include: Number of Positions, including additional sub-columns for Full-Time Perm, Seasonal, Intermittent, P and QTotal Annual SalaryFollowing the matrix/table data referenced above, additional fillable fields, also self-calculated, include: Total Annual Salary DollarsTotal Benefits (30% of Salary $'s)Total Positions and Labor DollarsStep 5 of Grade at Location specified in cell B5Part-time (P) and (Q) and Seasonal salary computed at 50%; Intermittent computed at 25%.Current Fiscal Year Information, calculated from the table described aboveFollowing Fiscal Year Information, calculated from the table described aboveASP Adjustment, calculated from the table described aboveComponents of the Current Fiscal Year Information include Perm FTETemp FTEPerm Salary Cost (11SP)Temp Salary Cost (11ST)Benefit Cost (12LA)Total Amount Needed to Cover Organizational Change Request in Current FYComponents of the Following Fiscal Year Information include Perm FTETemp FTEPerm Salary Cost (11SP)Temp Salary Cost (11ST)Benefit Cost (12LA)Total Amount to Base Transfer in Following FYComponent of the ASP Adjustment include Total Amount to Adjust in Current FY

[Please click here for the text description of the image.](https://www.irs.gov/media/440931 "")

**Exhibit 1.55.2-4**

### Category A (Streamline) Flow Chart

![This is an Image: 37989022.gif](https://www.irs.gov/pub/xml_bc/37989022.gif)

> Exhibit 1.55.2-4, Category A (Streamline) Flow ChartThis information describes the Category A (Streamline) Flow Chart. Note: All documents must be loaded into e-Trak and updated (including approvals).It is recommended that the originator(s) consult with Workforce Planning (WP), Organizational Design Team, TS Finance, and Workforce Relations Planning Management (WRPM) during the developmental stages of all change requests.The Change Request will not be implemented until concurred and approved by the appropriate official(s).The TS HCO will notify the initiator when new codes are issued and coordinate implementation.The first flow chart item is: Originator consults with WP and TS Finance and finalizes package.The single connector: The originator obtains the director's approval and routes request via e-Trak to TS Finance (time starts when the package enters e-Trak).The single connector to: TS Finance reviews, concurs, or non-concurs. This action entails two outcomes outlined below-Concur and Non-Concur. If no (non-concur), TS Finance discusses decision with the originator and returns package.If yes (concur), TS HCO reviews, concurs, or non-concurs. Forwards to the Director, CMO for signature. This action entails two outcomes outlined below-Concur and Non-Concur.If no (non-concur), TS HCO discusses decision with the originator and returns package.If yes (concur), Implement change

[Please click here for the text description of the image.](https://www.irs.gov/media/440936 "")

**Exhibit 1.55.2-5**

### Category B & C Flow Chart

![This is an Image: 37989023.gif](https://www.irs.gov/pub/xml_bc/37989023.gif)

> Exhibit 1.55.2-5, Category B & C Flow ChartThis text describes the Category B & C Flow Chart. Note: All documents must be loaded into e-Trak and updated (including approvals).It is recommended that the originator(s) consult with Workforce Planning (WP) Organizational Design Team, TS Finance, and Workforce Relations Planning Management during the developmental stages of all change requests.The Change Request will not be implemented until concurred and approved by the appropriate official(s).The Organizational Design Team will notify the Originator(s) to coordinate close-out and implementation. Categories B and C begin with the same four initial actions. The first flow chart item is: Originator reviews, consults with WP and TS Finance and finalizes the package.The single connector: Originator obtains the director's approval and routes request via e-Trak to TS Finance.The single connector to: TS Finance reviews, concurs, or non-concurs; decision will be discussed with the originator. If non-concurred package returned.The single connector to: TS CMO reviews, concurs or non- concurs; obtains signature of the Director, CMO. Decision will be discussed with the originator. If non- concurred package returned.The single connector to: Proposal presented to the Operations Strategy Board (OpSB).Category B:If Cat. B Proposal approved by TS Chief. This action entails two outcomes outlined below-if TS Chief does not approve and if TS Chief does approve.If TS Chief does not approve the Cat. B Proposal, then the Originator reviews, consults with WP and TS Finance and finalizes the package.If TS Chief does approve the Cat. B Proposal, then a copy of the approved CR is forwarded to TS HCO and the change is implemented.The final flow chart item is: Implement change proposal. Category C:If Cat. C Proposal concurred by TS Chief. This action entails two outcomes outlined below-if TS Chief does not concur and if TS Chief does concur.If TS Commissioner does not concur with Cat. C Proposal, then the originator reviews, consults with WP and TS Finance and finalizes the package.If TS Chief does concur with Cat. C Proposal, then the proposal is sent for IRS Commissioner approval. This action entails two outcomes outlined below-if IRS Commissioner does not approve and if IRS Commissioner does approve.If IRS Commissioner does not approve the Cat. C Proposal, then the Originator reviews, consults with WP and TS Finance and finalizes the package.If IRS Commissioner does approve the Cat. C Proposal, then a copy of the approved CR is forwarded to TS HCO and the change is implemented.The final flow chart item is: Implement change proposal.

[Please click here for the text description of the image.](https://www.irs.gov/media/440941 "")

**Exhibit 1.55.2-6**

### Category C Change Checklist

The Category C Change Checklist

![This is an Image: 37989017.gif](https://www.irs.gov/pub/xml_bc/37989017.gif)

> Category C Change ChecklistCategory C Change Checklist, page 1 of 4Check box (blank field). Section title - Description of Initiative: Ensure you thoroughly address the purpose of the organizational change. This justification can be extracted from form 15012, Taxpayer Services Change Request. Include or address the following:How will this change enhance the mission?Does this change align with the Strategic Plan?Will this change improve organizational goals and objectives, efficiencies?Will the change save money or is it cost effective?Clearly address business need and the expected outcomes.Check box (blank field). Section title - Justification (of Proposed Changes): This description can also be extracted from form 15012. Management should clearly describe the following:Explain the differences between proposed change, address the current and proposed structure.State the advantages of the proposed change. Address all position management concerns such as the span of control, authorized staffing patterns (ASP) and allocations.Highlight advantages of the proposed change.Explain if change improve accountability, eliminated duplication or address if it impacted customers and/or internal or external stakeholders.Check box (blank field). Section title - Current Structure(s): Management must describe the current structure(s) of the organization(s) impacted by the proposed change. Please address the following:Include the current number of positions, including vacancies, within the impacted organizations(s).Number of bargaining and/or non-bargaining employees.Note: This section will need to clearly describe the current organizational structures and comprehensive position listings that will be included as attachments.Example: The current XYZ (Business or Organizational Unit) high-level organizational structure is outlined in Attachment A. There is currently a total of XXX positions, including XXX vacancies, within the XYZ organization. There are XXX bargaining unit and XXX non-bargaining unit employees within the XYZ organization. A detailed organizational structure, which includes a comprehensive listing of the occupations and grade level currently with the XYZ organization is outlined in Attachment B.Check box (blank field). Section title - Proposed Structure(s): In this section management must describe the proposed structure(s) of the organization(s) impacted by the proposed change. Please address the following:Describe the new and /or impacted organizational structures.Address the types of positions, changes in span of control, any impact on authorized staffing patterns.Capture if there are any increases or decreased in employee, manager or executive positions, changes in reporting requirements, etc.

[Please click here for the text description of the image.](https://www.irs.gov/media/213186 "")

![This is an Image: 37989018.gif](https://www.irs.gov/pub/xml_bc/37989018.gif)

> Category C Change Checklist, page 2 of 4Example:The proposed high-level ABC structure, with the XYZ realignment added, is outlined in Attachment C. A detailed XYZ organizational structure, which includes a comprehensive listing of the occupations and grade levels in the proposed organization, is outlined in Attachment D. The proposed organizational structure will increase the number of positions reporting directly to Manager/Executive A by 6 positions, for a total of 15 positions. In addition, the change will result in a change in title for the Manager/Executive A, from Current Title, to New Title. With this, 220 employees will be realigned intact, 2 frontline management positions will be eliminated, and 1 new senior management position is being established.Check box (blank field). Section title - Realigned Organization (if applicable): In this section management should describe the new and/or restructured organization(s). Management should address the following:How will the change benefit the organization.Identify the benefits and describe if these benefits will improve or change processes or cultures.Identify products, programs, or services that will benefit or change.Address accountability issues (who, what and when).Check box (blank field). Section title - Impact on Employees, Mangers, Executive, Authorized Personnel Ceilings, Grades, and/or Span of Control. In this section management should address the following:Impact the proposed change will have on the workforce and/or position management controls.Implementation or mitigation strategies if an that will be used to address staffing and placement implications.- Directed reassignments within or outside the commuting area- Transfer of function- Grade or pay retention- Reduction in Force (RIF), Voluntary Early Retirement Authority (VERA), Voluntary Separation Incentive Payment (VSIP), job swaps, etc.Impact the proposed change will have on employee engagement.Check box (blank field). Section title - Challenges and Risks. In this section, management should consider the following:Effect the change will have on other organizations or agencies.Identify associated risks, e.g., disruption of workforce, duplication of service, scheduling issues, transfer of work, etc., and proposed strategies for addressing each risk.Address any stakeholder engagement that has already taken place.Check box (blank field). Section title - Functional Statements: In this section management should identify and address whether or not a new or revised functional statement will be required. This information can be extracted from internal source document or IRM 1.1.13.

[Please click here for the text description of the image.](https://www.irs.gov/media/213191 "")

![This is an Image: 37989019.gif](https://www.irs.gov/pub/xml_bc/37989019.gif)

> Category C Change Checklist page 3 of 4Check box (blank field). Section title - Possible controversies with Member of Congress, Employee Unions, the Public, Other agencies, or Other Special Interest Groups: In this section, management should address any anticipated controversies and define what the Service intends to do to address and/or mitigate the controversies. Check box (blank field). Section title - Cost/Benefit Analysis (if applicable). To complete this section, management should coordinate with our Finance Office to address the following:Identify and analyze costs, savings and benefits.Address all savings derived from mitigation strategies, e.g., VERA/VSIP, relocation allowances, etc.) and support costs (e.g. space, equipment, telecommunications, supplies).Separate costs by budget line items. Explain or propose how additional costs will be funded and the point in time when funds will be required. Check box (blank field). Section title - Communications. When completing this section, management must coordinate with our internal communications office.Describe the communications strategy, any communications that have taken place, and/or that are scheduled to be released relative to the proposed change. Include formal communications strategy with brief explanation, including a copy of the formal communications plan and any formal notice(s) to the National Treasury Employees Union, and/or any other critical communications. Check box (blank field). Section title - Legal Requirement or Conditions Applicable to the Change: When completing this section, management should address the following, if applicable:Describe any legal requirements, or compliance obligations, mandating or influencing the need for the proposed change.Identify any changes to delegations of authority, internal revenue manuals, etc., that will come because of the proposed change.Address compliance with A-123 internal controls, IRS Operating Plan, and budgetary and financial activities planned and/or underway.Capture any deficiencies identified. Must be addressed and provide the corrective actions that are planned and/or underway.Note: include a reference to each Attachment, with a brief explanation, which should include financial and organizational crosswalks, and the Mass Update Module (MUM) that will affect the organizational change in the personnel and related systems, as applicable.Check box (blank field). Section title - Organizational Change Tracking: In this section, management should address the following:Measures that are in place to track and monitor implementation.Highlight any system or processes being used to monitor and track the updating of all financial systems, employee systems, etc.

[Please click here for the text description of the image.](https://www.irs.gov/media/213196 "")

![This is an Image: 37989020.gif](https://www.irs.gov/pub/xml_bc/37989020.gif)

> Category C Change Checklist page 4 of 4Address if personnel actions are processed and accounted for in a timely manner, etc.Discuss how the change is being tracked and what type of method or tool being used to monitor and track change.Note: Include a reference to each attachment, with a brief explanation, which should include implementation plan, deliverables, responsible parties, and timeliness.Check box (blank field). Section title - Evaluation. In this section, management addresses the evaluation of the change. This is a critical piece in the change process and management should consider the following:Describe how, when, and by whom the effect of the organizational change will be evaluated and timeline for completion.Evaluation criteria should be consistent with the scope, purpose, and effect of the change identified in the organizational change proposal.

[Please click here for the text description of the image.](https://www.irs.gov/media/213201 "")

**Exhibit 1.55.2-7**

### Taxpayer Services Change Request (TS-CR Form 15012)

Form 15012, Taxpayer Services Change Request is available via the IRS Published Product Catalog.

![This is an Image: 37989024.gif](https://www.irs.gov/pub/xml_bc/37989024.gif)

> Taxpayer Services Change Request (TS-CR)Taxpayer Services Change Request (TS-CR Form 15012), first pageControl Number (fill in) - Administrative Use OnlyPurpose/Description of Proposed ChangePurpose (fill in)Description (fill in)Affected Offices/Systems3 columns, including: Offices (fill in)Business Systems (fill in)Administrative Systems (fill in)TS-CR CATEGORY (mark which one applies)First row, in 3 columns: Category ANo impact on other offices or programs and does not violate existing labor/management agreements.Right most blank for denoting if this is the appropriate category. Second row, in 3 columns: Category BSignificant impact involving multiple programs, processes, or locations. Note: Must be presented to the Operations Strategy Board (OpSB) and approved by the TS Chief or TS Deputy Chief.Right most blank for denoting if this is the appropriate category. Third row, in 3 columns: Category CMajor impact affecting other Business Operating Divisions.Note: Must be presented to OpSB, concurred with by the TS Chief and approved by IRS CommissionerRight most blank for denoting if this is the appropriate category.

[Please click here for the text description of the image.](https://www.irs.gov/media/440946 "")

![This is an Image: 37989016.gif](https://www.irs.gov/pub/xml_bc/37989016.gif)

> Taxpayer Services Change Request (TS-CR Form 15012), continued on second pageThree columns: Originator Name (fill in)Position/Title (fill in)Org. Symbols (fill in)Below, two columns: E-Mail Address (fill in)Telephone (fill in)Three columns: Contact Point Name (fill in)Position/Title (fill in)Org. Symbols (fill in)Below, two columns: E-Mail Address (fill in)Telephone (fill in)Approval/ConcurrenceThis portion of the form includes 5 columns: Category; the first segment is for Category ATitle, including fill in for the first row for Originating Operating Unit Director (approve), followed by, Chief, Finance (concur), Director, Human Capital Office (concur), Director, Strategy & Finance (concur)Concur (fill in)Approve (fill in)Signature/Date (fill in)Category; the second segment is for Category BTitle, including fill in for the first row for Originating Operating Unit Director (concur), followed by, Chief, Finance (concur), Director, Human Capital Office (concur), Director, Strategy & Finance (concur), TS Chief (approve)Concur (fill in)Approve (fill in)Signature/Date (fill in)Category; the third segment is for Category CTitle, including fill in for the first row for Originating Operating Unit Director (concur), followed by, Chief, Finance (concur), Director, Human Capital Office (concur), Director, Strategy & Finance (concur), TS Chief (concur), IRS Commissioner (approve)Concur (fill in)Approve (fill in)Signature/Date (fill in)Required Attachments Current Org ChartProposed Org ChartMission and Functional statements of impacted units and functionsSummary of Change (see appendix B) (Optional)Cost/Benefit AnalysisNote: Refer all questions to Workforce Planning Organizational Design Team. For detail procedures, roles and responsibilities see IRM 1.55.2. Use e-Trak to submit the entire request for organizational change; this is also a vehicle to keep all vested parties abreast of the status.

[Please click here for the text description of the image.](https://www.irs.gov/media/129956 "")

**INSTRUCTIONS**

The **“Purpose”** includes a brief statement outlining the operational statement or programmatic reasons for the proposed change. Organizational change proposals should directly support the mission, strategic vision, goals and objectives of TS.

Identify the business need and the result that the organizational change is expected to achieve. Ensure the changes relate to the mission and are directly supported by mission, Strategic Vision, Concept of Operations (CONOPs), goals and objectives.

The **“Description”** summarizes the proposed change and expected impacts, including the following:

- total number of affected employees’ series, grade, title, and location

- budgetary costs and/or savings (including subsequent years)

- changes in the number of executive/managerial positions, span-of-control, and grade structure changes

- labor relations issues that could require discussions or negotiations with National Treasury Employees Union (NTEU).


**“Affected Office and Systems”** identifies other organizational components (both within and outside TS), business, operational, and/or administrative systems that would be affected.

- Examples of operational and administrative systems that could require realignment include the following:


♦ Automated Underreporter System (AUR)


♦ Enterprise Electronic Fax (EEFax)


♦ EntelliTrak for Communication & Correspondence (e-Trak)


♦ Integrated Data Retrieval System (IDRS)


♦ IRS Travel System -- ConcurGov


♦ Procurement for Public Sector (PPS)


♦ HR Connect


♦ Single Entry Time Reporting (SETR)


♦ Work Planning and Control System (WP&C)


### Note:

These systems may require realignments to approval path and user profiles. Links to other systems should also be identified.

The **“Originator”** field identifies data for the sponsoring manger or executive. The “Originator” must be either a director or a direct report. That is, while Territory Managers may propose or initiate a TS-CR, the “Originator” should be no less than one level below the Operating unit Director level.

### Example:

Functional Director, CARE, SPEC; Director, Area 1

The **“Contact Point”** field identifies data for the individual employee assigned primary responsibility for development and coordination of the TS-CR. This contact will serve as the originating Director’s liaison with HCO and all other offices included in the routing, concurrence, and implementation stages of the approval process. The contact, who may be a manager or staff analyst, should have complete knowledge and understanding of the proposal and direct access to the sponsoring executive.

The **“Approval/Concurrence”**field establishes separate routing paths for concurrence/approval of the three different categories ("A" , "B" , and "C" ).

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-055-002#addtoany "Show all")

A2A