---
url: "https://www.irs.gov/irm/part1/irm_01-018-002"
title: "1.18.2 Forecasting Requirements | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-018-002#main-content)

- 1.18.2  [Forecasting Requirements](https://www.irs.gov/irm/part1/irm_01-018-002#idm140508554491088)
  - 1.18.2.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-018-002#idm140508525688752)
    - 1.18.2.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-018-002#idm140508525685504)
    - 1.18.2.1.2  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-018-002#idm140508558743760)
    - 1.18.2.1.3  [Related Resources](https://www.irs.gov/irm/part1/irm_01-018-002#idm140508558740464)
    - 1.18.2.1.4  [Acronyms](https://www.irs.gov/irm/part1/irm_01-018-002#idm140508525746976)
  - 1.18.2.2  [Tax Products Distribution](https://www.irs.gov/irm/part1/irm_01-018-002#idm140508558732832)
  - 1.18.2.3  [Specialty Requirements Programs](https://www.irs.gov/irm/part1/irm_01-018-002#idm140508558729232)
  - 1.18.2.4  [Annual Order (AO) and Campus Annual Order (CAO) Programs](https://www.irs.gov/irm/part1/irm_01-018-002#idm140508525779168)
  - 1.18.2.5  [Monitor Reorder Point (MRP) Program](https://www.irs.gov/irm/part1/irm_01-018-002#idm140508525774496)
    - 1.18.2.5.1  [Stock Resupply Process](https://www.irs.gov/irm/part1/irm_01-018-002#idm140508525773472)
      - 1.18.2.5.1.1  [The Survey Process](https://www.irs.gov/irm/part1/irm_01-018-002#idm140508525771472)
      - 1.18.2.5.1.2  [Stock Transfers](https://www.irs.gov/irm/part1/irm_01-018-002#idm140508525826608)
      - 1.18.2.5.1.3  [Reprint Requests](https://www.irs.gov/irm/part1/irm_01-018-002#idm140508525823744)
      - 1.18.2.5.1.4  [Electronic Form 2040](https://www.irs.gov/irm/part1/irm_01-018-002#idm140508525819072)
      - 1.18.2.5.1.5  [Warehousing and Inventory Control](https://www.irs.gov/irm/part1/irm_01-018-002#idm140508553863952)
    - 1.18.2.5.2  [Product Reference Material for Ordering](https://www.irs.gov/irm/part1/irm_01-018-002#idm140508553856128)
    - 1.18.2.5.3  [Informational Tools](https://www.irs.gov/irm/part1/irm_01-018-002#idm140508553851440)
  - 1.18.2.6  [Envelope Program](https://www.irs.gov/irm/part1/irm_01-018-002#idm140508525571856)
  - 1.18.2.7  [Internal Management Documents Distribution System (IMDDS)](https://www.irs.gov/irm/part1/irm_01-018-002#idm140508525568704)
  - 1.18.2.8  [Training Publications Distribution System (TPDS)](https://www.irs.gov/irm/part1/irm_01-018-002#idm140508525566480)
    - 1.18.2.8.1  [Ordering Training Material](https://www.irs.gov/irm/part1/irm_01-018-002#idm140508525564272)

# Part 1. Organization, Finance, and Management

# Chapter 18. Distribution

# Section 2. Forecasting Requirements

* * *

## 1.18.2 Forecasting Requirements

#### Manual Transmittal

January 21, 2025

#### Purpose

(1) This transmits revised text of the IRM 1.18.2, Distribution, Forecasting Requirements.

#### Material Changes

(1) IRM 1.18.2 revised throughout to update organizational title Wage and Investment to Taxpayer Services.

#### Effect on Other Documents

This supersedes IRM 1.18.2 dated October 13, 2023..

#### Audience

All IRS Employees

#### Effective Date

(01-21-2025)

Maria Cheeks

Director, Distribution

Taxpayer Services

**1.18.2.1** **(11-20-2020)**

### Program Scope and Objectives

1. Purpose: The IRM describes the role of the Forecasting Requirements (FR) section in the Distribution Requirements Branch (DRB) in determining quantity requirements and methods of distribution for all public and internal IRS published products.

2. Audience: The procedure applies to all IRS employees, especially those in Media and Publications, Distribution and the Forecasting Requirements section.

3. Policy Owner: Director, Distribution, Media and Publications, Customer Assistance, Relationships and Education (CARE).

4. Program Owner: Distribution Requirements Branch is the program office responsible for determining requirements and methods of distributing IRS published products externally and internally.

5. Policy Stakeholders: Correspondence Production Sites (CPS), National Distribution Center (NDC), Stakeholder Partnerships, Education & Communication (SPEC), Field Assistance (FA), Publishing, Tax Forms & Publications (TF&P), Learning & Education (L&E), Tax Forms Distribution Program Section (TFDPS), Postal & Transport Policy (PTP), and all IRS offices.


**1.18.2.1.1** **(10-14-2022)**

#### Background

1. Forecasting involves determining quantity requirements and methods of distribution for all public and internal IRS published products. The overall policy, design and management of the IRS forecasting requirements programs and systems resides with the Director, Distribution (D)/ Distribution Requirements Branch (DRB)/ and Forecasting Requirements (FR) Section. The primary forecasting distribution programs are:



   - Tax Products

   - Specialty Program

   - Annual Order (AO)

   - Campus Annual Order (CAO)

   - Monitor Reorder Point (MRP)

   - Internal Management Documents Distribution System (IMDDS)

   - Training Publications Distribution System (TPDS)

   - Envelope Program


**1.18.2.1.2** **(11-20-2020)**

#### Roles and Responsibilities

1. The Director of the Distribution division approves and authorizes the policy in this IRM

2. The chief of the Distribution Requirements Branch oversees the execution of policy in this IRM.

3. The chief of the Forecasting Requirements section in the Distribution Requirements Branch oversees the daily work of the Forecasting Requirements employees executing the tasks described in this IRM.

4. The employees in the Forecasting Requirements section perform all tasks described in this IRM.


**1.18.2.1.3** **(10-14-2022)**

#### Related Resources

1. Available resources are:



   - Publishing Services Request (PSR)

   - CAPS Authorized List of Approvers

   - M&P Page 1

   - Publishing and Distribution Electronic Publishing Catalog

   - Order Subscription Management System (OSMS)

   - Publishing Distribution Services

   - TPDS Course Catalog Document 6398-A

   - Addresses for Training Order Point Numbers (OPN)


**1.18.2.1.4** **(10-14-2022)**

#### Acronyms

1. The following acronyms are used throughout this IRM section.




| **Acronym** | **Definition** |
| --- | --- |
| AO | Annual Order |
| CAO | Campus Annual Order |
| CARE | Customer Assistance Relationships and Education |
| CPS | Correspondence Production Services |
| D | Distribution |
| DRB | Distribution Requirements Branch |
| ELITE | Enterprise Logistics Information Technology |
| EOS | Envelope Order Summary |
| ESN | Electronic Status Notice |
| FA | Field Assistance |
| FR | Forecasting Requirements |
| IMDDS | Internal Management Documents Distribution System |
| IRM | Internal Revenue Manual |
| L&E | Learning and Education |
| M&P | Media & Publication |
| MRP | Monitor Reorder Point |
| NDC | National Distribution Center |
| OPN | Order Point Number |
| OSMS | Order Subscription Management System |
| PSD | Publishing Services Data system |
| PSDS | Publishing Services Distribution System |
| PSR | Publishing Services Request |
| PTP | Postal & Transport Policy |
| SPEC | Stakeholder Partnerships, Education & Communication |
| TAC | Taxpayer Assistance Center |
| TS | Taxpayer Services |
| TF&P | Tax Forms and Publications |
| TFDPS | Tax Forms Distribution Program Section |
| TFOP | Tax Forms Outlet Program |
| TPDS | Training Publications Distribution Systems |
| VITA | Volunteer Income Tax Assistance |


**1.18.2.2** **(10-14-2022)**

### Tax Products Distribution

1. The FR section closely monitors, plans, coordinates, controls and executes the distribution of tax products to IRS offices, outlet partners and the public. Tax forms, instructions and publications are the primary method for the public to meet their filing requirements. Each tax product is the result of new or revised legislation, regulations or rulings, court decisions and public feedback.

2. The FR section determines distribution requirements for most tax products that originate in the Tax Forms and Publications (TF&P) division of M&P. This program does not include tax products developed for direct mail outs. FR analysts gather and monitor tax products requirements from several sources including the Correspondence Production Services (CPS) sites, the National Distribution Center (NDC), and programs maintained in the Tax Forms Distribution Program Section (TFDPS).


**1.18.2.3** **(10-13-2023)**

### Specialty Requirements Programs

1. Some seasonal distribution programs coincide with the tax products peak season distribution. These programs include, but are not limited to:



   - Volunteer Income Tax Assistance (VITA) Distribution

   - Marketing-Promotional Products Distribution

   - Tax Forms Outlet Program (TFOP)

   - Taxpayer Assistance Center (TAC)


2. These products may ship directly from a print contractor to the end user or to the NDC for redistribution. M&P’s Publishing division and IRS product originators must establish shipping requirements during the product planning phase.


**1.18.2.4** **(10-13-2023)**

### Annual Order (AO) and Campus Annual Order (CAO) Programs

1. AO and CAO program analysts determine print requirements and distribute large volume of printed products with consistent usage to Campus, CPS sites and NDC warehouses. AO and CAO products support program workloads for Submission Processing, Accounts Management, Compliance, and Correspondence processing operations.

2. CAO Products are for internal use only, and are stocked at CPS sites and Campus Warehouses. The same products are now stocked at the NDC to support the seven non-submission processing campus customers whose warehouses shutdown.

3. AO products are for internal and public use and are stocked at the campuses and CPS and NDC warehouses.

4. Campus customers order stock from their local warehouse for AO and CAO products.

5. Field offices and the public order from the NDC.


**1.18.2.5** **(10-14-2022)**

### Monitor Reorder Point (MRP) Program

1. The MRP program consists of products with low or inconsistent usage. Customers are IRS offices, including the campuses, order MRP products from the NDC to request stock on an as-needed basis.


**1.18.2.5.1** **(11-20-2020)**

#### Stock Resupply Process

1. Stock Resupply involves several phases. FR staff survey, transfer and/or reprint products based on formalized production schedules or when a product’s balance on hand is below the reorder point.


**1.18.2.5.1.1** **(10-13-2023)**

##### The Survey Process

1. FR Analysts conduct an inventory review in April each year for AO and CAO program products to replenish another 12 months of inventory for the NDC, CPS sites and Campus warehouses.

2. Usage and balance on hand data are generated from two different inventory systems. The NDC usage data is added manually into a master spreadsheet by the FR Analyst to create print quantity forecasts for each warehouse location.

3. The FR Analyst coordinates with the Campus and CPS site Forms Coordinators to provide the necessary upon request:



   - Contact the campus customer using area to determine program changes that have or could have an impact usage to a specific product.

   - Determine the accuracy of their balance on hand (warehouse and in the using area).

   - Validate the FR Analyst print quantity forecast.


4. The FR Analyst contacts the NDC Logistics Team to validate current warehouse and the line inventory.


**1.18.2.5.1.2** **(10-14-2022)**

##### Stock Transfers

1. If shortages of stock occur between survey periods, campuses, the CPS sites, and the NDC can request a transfer by submitting Form 15093, Warehouse Resupply and Stock Transfer Request. FR analysts resolve transfer requests within 48 hours. When a transfer is not possible, the FR analyst requests a reprint. See IRM 1.18.2.5.1.3 for additional information on reprint requests.



### Note:



Campuses, the CPS, and the NDC will complete transfers within 48 hours of receiving the request. The FR analyst closes out the TFORDERs within 48 hours after completing the transfer request.


**1.18.2.5.1.3** **(10-14-2022)**

##### Reprint Requests

1. FR Analysts request reprints through the Product Business Originators on an as-needed basis to replenish stock levels for Campus, CPS sites and the NDC warehouse. Originating offices have two available options to request reprints:



1. Submit request online using the Publishing Services Request (PSR) system at http://caps-as.enterprise.irs.gov/psr/app

2. Submit a completed Form 1767, Publishing Services Requisition, with authorized business and funding approvals, to the Publishing function in M&P


### Note:

See http://publish.no.irs.gov/appls/pst01c2.html for a list of authorized approvers.

2. The originator's duties include monitoring their print requisition status and ensuring the technical content has not changed.


**1.18.2.5.1.4** **(10-14-2022)**

##### Electronic Form 2040

1. FR Analysts must input all requirements for printed materials warehoused at the campuses, the CPS, and the NDC using the electronic Form 2040, Distribution/Shipping List application. The application interfaces with the Publishing Services Data system (PSD) which helps track the status and progress of shipments. The FR Analyst must list all locations receiving stock on the 2040 this includes IRS offices, outlet partner, contractor and other governmental agencies. The 2040 application uses both specific and generic order points number for address information.



### Exception:



Do not enter IRM distribution envelopes on Form 2040.

2. Form 2040 is required for departmental random copies, also known as blue labels, for all IRS printed products shipping to campus warehouses or the NDC. Refer to Publishing Procedure 181 or Distribution Procedure 126, available on M&P Page 1 at http://publish.no.irs.gov/ephome.html, for the number of samples to order.


**1.18.2.5.1.5** **(11-20-2020)**

##### Warehousing and Inventory Control

1. Campuses, the CPS, and the NDC should establish receiving and inventory control methods that ensure:



1. Quality products are distributed

2. Sufficient stock is available to meet customer needs

3. Government printing costs are kept low


2. Campuses, the CPS, and the NDC should establish procedures that provide accurate records for:



   - Product receipts

   - Quality review of products

   - Stock issues

   - Keeping records consistent with the Electronic Status Notice (ESN) system

   - Stock disposals

   - Transaction history that provides an audit trail

   - Transfer requests

   - Requirements planning

   - Matching local OPNs with IMDDS records


**1.18.2.5.2** **(11-20-2020)**

#### Product Reference Material for Ordering

1. Product information is available on the Publishing and Distribution Electronic Publishing website Catalog tab at http://publish.no.irs.gov/catlg.html. The product information provided at the site includes:



   - Catalog Number

   - Publishing Analyst

   - Distribution Analyst

   - Revision Information

   - Originating Office/Product Originator


2. Offices can order NDC-stocked materials using the Order and Subscription Management System (OSMS) at http://caps-as.enterprise.irs.gov/osms/views/homePage.xhtml. The OSMS also contains an online catalog to search for NDC-stocked products.


**1.18.2.5.3** **(10-14-2022)**

#### Informational Tools

1. The Form 2040 application and the Publishing Services Distribution System (PSDS) databases provide Publishing and Distribution employees with the latest information on shipping, delivery, and the status of reprints of printed materials.

2. Shipping, delivery, and availability of printed material information Is also posted on the Publishing Distribution website Services tab at http://publish.no.irs.gov/servc.html.


**1.18.2.6** **(10-13-2023)**

### Envelope Program

1. The Envelope Program consists of large volume preprinted address versions and parent standard envelopes to support taxpayer correspondence or internal use. These are only available for campus internal ordering

2. FR analysts manage parent and version envelope inventory at the NDC to support seven campus The FR Analyst reviews usage and determines print quantity requirements three times a year. The FR Analyst completes the Envelope Order Summary (EOS) spreadsheet and submits the order quantity to the Envelope Publishing Team for stock replenishment.

3. The FR Analysts provide Publishing and Campus customer support whenever necessary involving customer ordering, inventory, new version envelope creation, etc.


**1.18.2.7** **(10-13-2023)**

### Internal Management Documents Distribution System (IMDDS)

1. The IMDDS Program automatically distributes IRMs to offices who sign up in OSMS.

2. Receiving IRS offices must maintain and update their IMDDS subscriptions via OSMS at https://caps-as.enterprise.irs.gov/osms/views/homePage.xhtml.


**1.18.2.8** **(11-20-2020)**

### Training Publications Distribution System (TPDS)

1. The TPDS is designed to support IRS training needs. TPDS consists of course materials (multiple products) and individual products. Items are printed commercially and/or by print-on-demand at the NDC. The NDC provides order fulfillment and print-on-demand services to Learning and Education (L&E) for TPDS material.


**1.18.2.8.1** **(11-20-2020)**

#### Ordering Training Material

1. The two types of TPDS orders are course and product orders:



   - Course orders are requests for complete sets of specific course materials

   - Product orders are requests for individual products


2. Document 6398-A, Training Course Catalog, is a complete listing of TPDS courses customers can order from the NDC. Distribution updates Doc. 6398-A daily, and it is available electronically on M&P’s website at http://publish.no.irs.gov/pubsys/training/training.html#tab=tab6. When placing a course order, refer to the document to obtain the course catalog number. Using the course catalog number will ensure that all materials associated with a particular course are sent to the requestor.

3. To order TPDS products, the requestor must use a TPDS order point number. A listing of TPDS order point numbers is posted on the Publishing and Distribution website at http://publish.no.irs.gov/distsys/imdds/trainopn.html. Customers must place all TPDS orders using the OSMS at http://caps-as.enterprise.irs.gov/osms/views/homePage.xhtml.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-018-002#addtoany "Show all")

A2A