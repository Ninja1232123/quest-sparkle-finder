---
url: "https://www.irs.gov/irm/part1/irm_01-032-005"
title: "1.32.5 International Travel Office Procedures | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-032-005#main-content)

- 1.32.5  [International Travel Office Procedures](https://www.irs.gov/irm/part1/irm_01-032-005#idm139736994211712)
  - 1.32.5.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-032-005#idm139736994235312)
    - 1.32.5.1.1  [Authority](https://www.irs.gov/irm/part1/irm_01-032-005#idm139736994227104)
    - 1.32.5.1.2  [Responsibilities of the International Travel Office](https://www.irs.gov/irm/part1/irm_01-032-005#idm139736994224784)
    - 1.32.5.1.3  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-032-005#idm139736994218624)
    - 1.32.5.1.4  [Program Controls - Passport Tracker](https://www.irs.gov/irm/part1/irm_01-032-005#idm139736994215968)
    - 1.32.5.1.5  [Terms/Definitions/Acronyms](https://www.irs.gov/irm/part1/irm_01-032-005#idm139736994019584)
    - 1.32.5.1.6  [Related Resources](https://www.irs.gov/irm/part1/irm_01-032-005#idm139736994010112)
  - 1.32.5.2  [Responsibilities of International Travelers](https://www.irs.gov/irm/part1/irm_01-032-005#idm139736993999280)
    - 1.32.5.2.1  [Criminal Investigation (CI) Travelers](https://www.irs.gov/irm/part1/irm_01-032-005#idm139736993992416)
    - 1.32.5.2.2  [Chief Counsel Travelers](https://www.irs.gov/irm/part1/irm_01-032-005#idm139736993989200)
  - 1.32.5.3  [Required Documents for Official Travel](https://www.irs.gov/irm/part1/irm_01-032-005#idm139736993987536)
    - 1.32.5.3.1  [Form 1321 - Authorization for Official Travel](https://www.irs.gov/irm/part1/irm_01-032-005#idm139736993984048)
    - 1.32.5.3.2  [Electronic Country Clearance (eCC)](https://www.irs.gov/irm/part1/irm_01-032-005#idm139736993941248)
  - 1.32.5.4  [Official and Diplomatic Passports](https://www.irs.gov/irm/part1/irm_01-032-005#idm139736993937776)
    - 1.32.5.4.1  [Request Initial Official Passport from Within Washington D.C. Metro Area](https://www.irs.gov/irm/part1/irm_01-032-005#idm139736993929664)
    - 1.32.5.4.2  [Request Initial Official Passport from Outside Washington D.C. Metro Area](https://www.irs.gov/irm/part1/irm_01-032-005#idm139736993919584)
    - 1.32.5.4.3  [Official Passport (DS-82) Renewal Request](https://www.irs.gov/irm/part1/irm_01-032-005#idm139736993903088)
    - 1.32.5.4.4  [Passport Photos](https://www.irs.gov/irm/part1/irm_01-032-005#idm139736993895776)
    - 1.32.5.4.5  [Diplomatic Passport](https://www.irs.gov/irm/part1/irm_01-032-005#idm139736993892944)
    - 1.32.5.4.6  [Visas](https://www.irs.gov/irm/part1/irm_01-032-005#idm139736993885824)

# Part 1. Organization, Finance, and Management

# Chapter 32. Servicewide Travel Policies and Procedures

# Section 5. International Travel Office Procedures

* * *

## 1.32.5 International Travel Office Procedures

#### Manual Transmittal

May 27, 2022

#### Purpose

(1) This transmits revised IRM 1.32.5, Servicewide Travel Policies and Procedures, International Travel Office Procedures.

#### Material Changes

(1) Changed Policy Owner from Director, LB&I Office of Program and Business Solutions, Resource Solutions to LB&I Policy under the Strategy, Policy and Governance office in the Assistant Deputy Commissioner Compliance Integration organization in IRM 1.32.5.1(4).

(2) Updated training name from High Threat Security Overseas Seminar (HTSOS) to Completion of Counter Threat Awareness Training (CTAT) in IRM 1.32.5.2(7).

(3) The number of days required to process the approved Form 1321 was changed from 30 to 45 days for the following IRMs if no Visa is required:

- IRM 1.32.5.3.1(3)(a)

- IRM 1.32.5.3.1(4)(a)


(4) The number of days required to process the approved Form 1321 was changed from 45 to 55 days for the following IRMs if Visa is required:

- IRM 1.32.5.3.1(3)(b)

- IRM 1.32.5.3.1(4)(b)


(5) The timeframe for State Department approval was changed from 5 to 15 days in the tables in IRM 1.32.5.3.1(5) for new and renewed passports.

(6) The amount of time to process a new and renewed passport has changed from 5-6 weeks to 8-12 weeks for the following IRMs:

- IRM 1.32.5.4.1(1)(a)

- IRM 1.32.5.4.1(2)(a)

- IRM 1.32.5.4.2(3)(a)

- IRM 1.32.5.4.2(4)(a)

- IRM 1.32.5.4.3(4)(a)


(7) Updated DOS mailing address for IRM 1.32.5.4.2(4)(h).

(8) Editorial corrections and updates made throughout.

#### Effect on Other Documents

IRM 1.32.5, dated July 13, 2021, is superseded.

#### Audience

All operating divisions and functions

#### Effective Date

(05-27-2022)

Theodore D. Setzer

Assistant Deputy Commissioner Compliance Integration

Large Business & International Division (LB&I)

**1.32.5.1** **(05-27-2022)**

### Program Scope and Objectives

1. The International Travel Office (Travel Office or ITO) is situated within the Large Business & International (LB&I) division under the Director, Resource Solutions - Finance, Customer Support - Budget and ITO (SE:LB&I:PBS:RS:FIN:CS).

2. **Purpose**: The Travel Office staff supports the IRS mission as the primary contact for securing official passports, visas, State Department electronic country clearances (eCC), and Form 1321, Authorization for Official Travel, for IRS personnel traveling overseas. Criminal Investigation (CI) also performs some of these functions. The Travel Office provides travelers with guidance on completing the necessary travel documents for international travel including the Form 1321, as well as visa and passport applications.

3. **Audience**: All operating divisions and functions.

4. **Policy Owner**: LB&I Policy under the Strategy, Policy and Governance office in the Assistant Deputy Commissioner Compliance Integration organization.

5. **Program Owner**: Customer Support - Budget and ITO office within the LB&I Office of Program and Business Solutions, Resource Solutions.

6. **Primary Stakeholders**: IRS employees who travel abroad.


**1.32.5.1.1** **(10-28-2019)**

#### Authority

1. This office has the sole authority to approve all travel outside the United States for Internal Revenue Service business, except for the office of Chief Counsel. Employees of the Chief Counsel Office organize their travel through the Chief Counsel’s Travel Office. See IRM 1.2.2.2.8, Delegation Order 1-8, (formerly DO-48, Rev. 15), Approval of Foreign Travel.


**1.32.5.1.2** **(10-28-2019)**

#### Responsibilities of the International Travel Office

1. The Travel Office travel coordinators’ responsibilities include but are not limited to:



1. Obtaining, renewing and tracking official and diplomatic passports

2. Providing guidance to travelers for passports, visas and other travel related information

3. Taking passport and visa photos for travelers located in the Washington, DC metro area

4. Processing visa requests

5. Coordinating with the courier service for passport and visa delivery to foreign embassies and the Department of State

6. Obtaining approvals from the Department of State for eCC requests

7. Updating the Passport Tracker system (see _IRM 1.32.5.1.4_)

8. Providing completed and approved travel documents to travelers


**1.32.5.1.3** **(10-28-2019)**

#### Program Management and Review

1. The Travel Office manager will receive and review the foreign travel request including the authorization and approve Form 1321 and the itinerary uploaded in the electronic travel system. The Travel Office does not process requests for First-Class or Business-Class travel.

2. The Travel Office manager assigns the requests to the travel coordinators.

3. Per Document 12990, Records Control Schedule 26, Item 44 (Job No. N1-58-07-10), all financial transactions such as Form 1321s, must be retained by the LB&I International Travel Office for 6 years and 3 months. The records retention and disposition is in accordance with the approved authority from the National Archives and Records Administration (NARA).


**1.32.5.1.4** **(10-28-2019)**

#### Program Controls - Passport Tracker

1. The Passport Tracker system is a SharePoint-driven database that maintains official and diplomatic passport information, as well as all related travel records.

2. The Passport Tracker system also maintains the official passport details such as issue date, date of expiration, etc. A log is maintained within the system that provides the dates in which the passport is released from and returned to the International Travel Office. Passport Tracker also maintains Personally Identifiable Information (PII), such as date of birth, place of birth, etc.

3. The database is used to generate reports such as a list of expiring passports, which allows the Travel Office to notify the travelers to start the passport renewal process. Passport Tracker contains PII and access is limited to International Travel Office personnel.


**1.32.5.1.5** **(07-13-2021)**

#### Terms/Definitions/Acronyms

1. The following table contains commonly used acronyms for this program:



**Acronyms**






| **Acronym** | **Definition** |
| --- | --- |
| CI | Criminal Investigation |
| eCC | Electronic Country Clearance |
| ITO | International Travel Office |
| PII | Personally Identifiable Information |


**1.32.5.1.6** **(05-27-2022)**

#### Related Resources

1. See the International Travel Office website for the most current international travel procedures, updates, and contact information at: https://irssource.web.irs.gov/LBI/SitePages/ITP.aspx .

2. For immunization information, see the Center for Disease Control’s Traveler’s Health web site at: http://wwwnc.cdc.gov/travel.



1. Review immunization requirements prior to making travel arrangements as some immunizations require shots over several weeks. Official travel related costs that are not reimbursed by the travelers’ health insurance are reimbursable travel expenses on the travel voucher in the electronic travel system. The travel card may be used for this type of expense.

2. Employees in the Washington, D.C. metro area may get their immunizations at Department of State facilities in Washington D.C. upon approval of Form 1321, Authorization for Official Travel. For hours of operation and information, please contact the Department of State at [https://travel.state.gov/content/travel/en/international-travel/before-you-go/your-health-abroad.html](https://travel.state.gov/content/travel/en/international-travel/before-you-go/your-health-abroad.html).

3. Employees stationed outside the Washington D.C. area should contact personal physicians or a travel immunization clinic for immunizations.


3. For government travel rules, see:



1. IRM 1.32.11, Official IRS City-to-City Travel Guide

2. Foreign per diem rates: [https://aoprals.state.gov/web920/per\_diem.asp](https://www.irs.gov/irm/part1/irm_01-032-005)


4. Other resources:



1. See the Department of State Travel Warnings & Consular Affairs website at [http://travel.state.gov/content/travel/en.html](http://travel.state.gov/content/travel/en.html) for worldwide travel alerts and warnings.

2. See the Oanda Foreign Currency Converter at [http://www.oanda.com/currency](http://www.oanda.com/currency) for the most up-to-date foreign currency rates for conversion.


**1.32.5.2** **(05-27-2022)**

### Responsibilities of International Travelers

1. Travelers must complete Form 1321, Authorization for Official Travel. If the traveler is not an executive, their supervisor and an executive must approve the Form 1321 before it is submitted. If the traveler is an executive, the supervisor of the executive must approve the Form 1321 before it is submitted. Travelers are required to include the completed Form 1321 in travel authorizations and vouchers within the electronic travel system. Form 15098, Foreign Travel Documentation Checklist, must also be uploaded to the voucher. The traveler is to also obtain supervisory approval of foreign travel authorizations and vouchers.

2. **For LB&I only**: After the Form 1321 is signed by first level executive, it must also be signed by the LB&I commissioner, LB&I deputy commissioner or the LB&I program manager over Strategic Programs in Section 4 before submission to the International Travel Office as an attachment to the travel authorization in the electronic travel system. The signature of the LB&I commissioner, LB&I deputy commissioner, the LB&I program manager over Strategic Programs or an approved delegate confirms a business justification for the trip exists and ensures coordination of international tax administration activities in LB&I. Approval from the LB&I commissioner, LB&I deputy commissioner or the LB&I program manager over Strategic Programs can take up to 5 days.

3. Travelers will work with the travel vendor to make flight and hotel reservations when booked outside of the electronic travel system.

4. Travelers may contact the Employee Resource Center (ERC) or the travel vendor with questions about travel reservations.

5. Travelers may also contact the ERC with questions about travel authorizations and vouchers.

6. Travelers must understand the cyber security requirements before taking a government laptop or PDA overseas. See IRM 10.8.1.3.1.18.

7. Completion of Counter Threat Awareness Training (CTAT) provided by the State Department is required for international travelers. Once this training is completed, it does not need to be completed again for 6 years.


**1.32.5.2.1** **(10-28-2019)**

#### Criminal Investigation (CI) Travelers

1. IRM 9.11.2.4 provides administrative procedures governing foreign travel for Criminal Investigation (CI) travelers. In addition, CI employs travel coordinators to provide assistance to its travelers. However, Form 1321, Authorization for Official Travel, must be signed by the International Travel Office manager prior to any foreign travel.

2. When CI travelers upload the approved Form 1321 and the travel itinerary into the electronic travel system, the documents will be routed to the Travel Office. The Travel Office manager will review and approve the authorization and retain an electronic copy of the approved Form 1321.

3. The CI travel coordinator will secure electronic country clearance (eCC). The eCC will be sent to the Travel Office with the final Form 1321 for approval. An executed copy of Form 1321 will be returned to the CI travel coordinator and/or CI traveler.


**1.32.5.2.2** **(05-27-2022)**

#### Chief Counsel Travelers

1. CCDM 30.5.2.5 provides guidelines to Chief Counsel employees for official travel outside the continental United States.


**1.32.5.3** **(10-28-2019)**

### Required Documents for Official Travel

1. IRS employees must possess an official passport or diplomatic passport, electronic country clearance (eCC) and an approved Form 1321 in order to travel internationally.



### Note:



An approved Form 1321 is a pre-requisite to traveling internationally. **No one should depart on international travel without possessing an approved Form 1321. By definition, an approved Form 1321 includes the signature of the authorizing official in Section 5 of the form**. A signature in Section 5 means that the State Department has cleared your travel to the country of your destination and all other requirements for your travel have been met. If the form has not been signed in Section 5, the employee has not been cleared to travel and should not do so.


**1.32.5.3.1** **(05-27-2022)**

#### Form 1321 - Authorization for Official Travel

1. IRS travelers may not leave the United States for official travel without an approved Form 1321, Authorization for Official Travel. See CCDM 30.5.2.5 for Chief Counsel exceptions.

2. Form 1321 must be used to obtain authorization for:



   - Official foreign travel

   - An exemption from the requirement to use a government credit card

   - Travel with a laptop or PDA - see IRM 10.8.1.3.1.18


3. For all IRS employees except CI and Chief Counsel, travelers are to upload the approved Form 1321 and itinerary (if applicable) into the electronic travel system using the following time frames:



1. 45 days in advance of travel if they already have an official passport

2. 55 days in advance of travel if they need to apply for an official passport

3. Add 15 additional days to these time frames if a visa is needed. See IRM 1.32.5.4.6.


When travel requests are submitted based on the encouraged timeframes, the Travel Office team will ensure travelers are notified of the status of their request within 10 days of their travel date.



4. The cut-off dates for submission of international authorizations for all IRS employees (except CI and Chief Counsel) are as follows:



1. **Authorizations submitted less than 10 days prior to the date of travel**: Even if no visa is required or the traveler already has a visa, a request for travel submitted less than **10 days** from the travel date **will generally not be processed** because there would not be adequate time to secure the necessary approval and provide the documents to the traveler for an orderly travel event. Travel authorizations that do not require processing of a visa should be submitted 45 days in advance.

2. **Authorizations submitted at least 10 days prior to travel with a visa requirement:** If a visa is required for the travel and a visa application is submitted to the Travel Office at least **10 days** prior to travel, the visa application will be sent on to the appropriate embassy for processing, but it cannot be guaranteed that it will be secured in time for travel. Travel authorizations with a need for processing a visa should be submitted 55 days in advance.


5. Travel Office timeframes for the approval and processing of Form 1321 for all IRS employees (except CI and Chief Counsel):



**Form 1321 Processing Timeframes When No Visa is Necessary**






| **Step** | **Action** | **Timeframe** |
| --- | --- | --- |
| 1. | Traveler summits authorization with Form 1321 in the electronic travel system. | At least 45 days prior to travel departure date |
| 2, | ITO manager reviews authorization and Form 1321 for accuracy. | 2 days |
| 3. | ITO team receives Form 1321 and requests country clearance (eCC) form the State Department. | 7 days |
| 4. | State Department processes eCC request. | 15 days |
| 5. | ITO team receives and forwards approved eCC with Form 1321 to ITO manager for signature. | 2 days |
| 6. | ITO manager signs Form 1321 in Section 5 after eCC is approved. | 2 days |
| 7 | Approved Form 1321 is returned to traveler. | 2 days |
| 8 | Travel documents are delivered to traveler. | 10 days prior to travel departure date |







**Form 1321 Processing Timeframes When a Visa is Necessary**






| **Step** | **Action** | **Timeframe** |
| --- | --- | --- |
| 1. | ITO team receives, reviews and submits visa application and official passport to the embassy for processing. | 55 days |
| 2. | Traveler submits authorization with Form 1321 in the electronic travel system. | 30 days prior to the travel departure date |
| 3. | ITO manager reviews authorization and Form 1321 for accuracy. | 2 days |
| 4, | ITO team receives Form 1321 and requests country clearance (eCC) form the State Department. | 7 days |
| 5. | State Department processes eCC request. | 15 days |
| 6. | ITO team receives and forwards approved eCC with Form 1321 to ITO manager for signature. | 2 days |
| 7. | ITO manager signs Form 1321 in Section 5 after eCC is approved. | 2 days |
| 8. | Approved Form 1321 is provided to traveler. | 2 days |
| 9. | Travel documents are delivered to traveler. | 10 days prior to travel departure date |


**1.32.5.3.2** **(10-28-2019)**

#### Electronic Country Clearance (eCC)

1. The U.S. State Department Electronic Country Clearance (eCC) is an electronic information system that allows online submission and processing of unclassified country clearance requests for travelers from any approved U.S. Government agency or organization traveling abroad on official business.

2. An eCC is required for all foreign official travel.

3. Form 1321 and travel Itinerary are used to obtain the eCC. Once approved the Travel Office will notify the traveler when the eCC has been secured.

4. After the eCC has been secured, travelers must notify the Travel Office of any flight or lodging changes including any personal travel changes. A new eCC will be required.


**1.32.5.4** **(05-27-2022)**

### Official and Diplomatic Passports

1. IRS employees must use an official passport for all official travel. Per IRM 1.32.11.5.5(5), employees may be authorized to use a personal passport on rare occasions when safety or other circumstances require it. The LB&I Commissioner or Deputy Commissioner will evaluate the circumstances on an individual basis and, when warranted, authorize in writing the use of a personal passport. Requests for use of a personal passport should be made via memorandum from the first level executive of the traveler, or a higher-level official, to the LB&I Commissioner. The memorandum shall include a signature line for approval. The following sections detail procedures to obtain an official passport for IRS employees who are located within the Washington D.C. metro area and in other areas.

2. Official Passports MAY NOT be used for personal travel including personal travel in conjunction with official travel.

3. Official passports must be returned within 10 days of completion of travel or immediately upon cancellation of travel to the IRS International Travel Office. If the traveler is a frequent traveler, and any necessary visa is already obtained for an upcoming travel destination, the traveler may retain the official passport until completion of such travel if he or she obtains approval from the Travel Office manager via e-mail. This approval exempts the traveler from having to return the passport to the Travel Office within 10 days of completion of a trip.

4. Mail official passport(s) and/or applications with photos via United Parcel Service (UPS) or Federal Express (FedEx). See the Travel Office website for the most current mailing address.

5. United States Postal Service (USPS) mail is NOT recommended for sending passports or photos as certain USPS mail items are required to go through x-ray machines at the mail processing center and the machines may destroy these items.

6. Use the shipping rules that govern personally identifiable information when mailing travel documents.

7. Contact the Travel Office for further guidance. (See Travel Office website: https://irssource.web.irs.gov/LBI/SitePages/ITP.aspx .)

8. If an official passport is lost, please follow instructions in IRM 10.5.4 **to report the loss**and notify the Travel Office manager of the loss via e-mail.


**1.32.5.4.1** **(05-27-2022)**

#### Request Initial Official Passport from Within Washington D.C. Metro Area

1. To apply for an official passport when the traveler’s personal passports (current or expired) were issued within the prior 15 years:



1. This process can take from 8 to 12 weeks.

2. Travelers are required to complete and print TDF 70 Information Sheet and [Form DS-82](https://eforms.state.gov/Forms/ds82.PDF), U.S. Passport Renewal Application for Eligible Individuals.

3. A traveler must submit both the TDF 70 Information Sheet and Form DS-82, along with two 2” X 2” passport photos, and the traveler’s personal passport to the International Travel Office. See the Travel Office website for the most current mailing addresses.

4. The Travel Office will submit these documents to the State Department for processing. Upon completion, the Travel Office will notify the traveler when the documents are ready for pick up.


2. To apply for an official passport when the traveler does not have a personal passport, or the personal passport was issued over 15 years ago:



1. This process can take from 8 to 12 weeks.

2. Travelers are required to contact the Travel Office for an appointment and complete the TDF 70 Information Sheet and [Form DS-11](https://eforms.state.gov/Forms/ds11.PDF), Application for a U.S. Passport.



      ### Note:



      Do not sign Form DS-11 until you are before a passport acceptance agent.

3. The coordinator will execute the oath and sign Form DS-11 and provide the Form TDF 70.02.1 which waives the fee for the official passport.

4. The Travel Office will submit these documents to the State Department. After the documents have been processed, they will be returned to the traveler.


**1.32.5.4.2** **(05-27-2022)**

#### Request Initial Official Passport from Outside Washington D.C. Metro Area

1. The Travel Office can only provide first-time passport services to travelers located in the Washington D. C. metro area because [Form DS-11](https://eforms.state.gov/Forms/ds11.PDF), Application for a U.S. Passport, must be signed under oath in the presence of an acceptance agent. Travelers located outside of the Washington DC metro area will complete the passport process at a local post office, passport agency, or county clerk’s office.

2. Travelers must complete the TDF 70 Information Sheet and submit the form to the Travel Office. The Travel Office will create, sign, and return Form TDF 70-02.1 to the travelers. Travelers must obtain and submit passport photos as part of the passport application to the local passport agency. The cost of passport photos is a reimbursable expense on the travel voucher. The travel card may be used for this type of expense.

3. Applying for an Official Passport when your personal passport (current or expired) was issued within the last 15 years:



1. This process can take from 8 to 12 weeks.

2. Travelers are required to complete the TDF 70 Information Sheet and [Form DS-82](https://eforms.state.gov/Forms/ds82.PDF), U.S. Passport Renewal Application for Eligible Individuals.

3. A traveler must submit both the TDF 70 Information Sheet and Form DS-82, along with two 2” X 2” passport photos, and the traveler’s personal passport to the Travel Office. See the Travel Office website for the most current mailing address. Travelers should use UPS or FedEx to avoid damage to their photos during the mail screening process.

4. After receiving all required documents, the Travel Office will process the passport application. The passport and any related documents will be shipped to the traveler via FedEx.


4. If the traveler does not have a personal passport, or the personal passport was issued over 15 years ago:



1. This process may take more than 12 weeks.

2. Travelers may obtain official passports without having a personal passport.

3. Travelers are required to prepare and return the TDF 70 Information Sheet to the Travel Office. See the Travel Office website for the most current mailing address.

4. The travel coordinator will send Form TDF 70.02.1 to the traveler, which entitles the traveler to a no-fee official passport.

5. Travelers are also required to complete [Form DS-11](https://eforms.state.gov/Forms/ds11.PDF), Application for a U.S. Passport, that will be signed in the presence of the passport acceptance agent.

6. Travelers must apply in person before a passport acceptance agent (at a post office, passport agency, or county clerk’s office and submit Form DS 11, Application for a U.S. Passport, along with the Form TDF 70.02.1 fee waiver, proof of U.S. Citizenship (certified birth or naturalization certificate), an official picture ID, and two 2” X 2” passport photos.

7. The acceptance agent will have the traveler sign the DS-11 under oath. Travelers may be asked to pay a processing fee which is a reimbursable travel voucher expense.

8. Travelers must ask the acceptance agent to mail the information to:


       U.S. Department of State, Special Issuance Agency


       CA/PPT/SIA


       44132 Mercure Circle


       Sterling, VA 20166

9. The U.S. Department of State will forward the passport to the Travel Office. The Travel Office will notify and ship to the traveler the passport and any related documents via FedEx.


**1.32.5.4.3** **(05-27-2022)**

#### Official Passport (DS-82) Renewal Request

1. The Travel Office will send email notifications to travelers whose official passports will expire within 6 months. The State Department advises not to travel to a foreign country with less than six months remaining on a passport.

2. Official passports must be renewed if travelers anticipate future foreign travel prior to the six month expiration of the passport. Travelers that do not anticipate future travel should notify the Travel Office.

3. If the official passport expired more than 5 years ago, travelers must apply for an official passport as if they are applying for the first time.

4. To renew an official passport that has expired within 5 years prior or will expire in 6 months:



1. This process can take from 8 to 12 weeks.

2. Travelers are required to complete the TDF 70 Information Sheet and [Form DS-82](https://eforms.state.gov/Forms/ds82.pdf), U.S. Passport Renewal Application for Eligible Individuals.

3. Travelers must submit both the TDF 70 Information Sheet and Form DS-82, along with two 2” X 2” passport photos to the Travel Office. See the Travel Office website for the most current mailing address. Travelers should use UPS or FedEx to avoid damage to their photos during the mail screening process.

4. After receiving all required documents, the Travel Office will process the traveler’s passport renewal application. The Travel Office will inform the traveler when their official passport has been renewed.


**1.32.5.4.4** **(06-16-2016)**

#### Passport Photos

1. Travelers outside of the Washington DC metro area need to obtain two 2” X 2” inch passport photographs with a white or off-white background. The photograph cost is a reimbursable travel voucher expense.

2. By appointment only, employees in the Washington DC metro area may use the Travel Office’s services to have their official passport and visa photos taken. To schedule an appointment, contact the Travel Office.


**1.32.5.4.5** **(06-16-2016)**

#### Diplomatic Passport

1. Diplomatic passports are required for the top management positions of each IRS overseas post.

2. With minimal differences, the process for obtaining a diplomatic passport is the similar to the process of obtaining an official passport. When a diplomatic passport is issued, any valid official passport is cancelled as one cannot have both at the same time.

3. The following documents are necessary to process a request for a diplomatic passport:



1. Unexpired personal or official passport

2. A signed [Form DS-82](https://eforms.state.gov/Forms/ds82.PDF), Application for Passport Renewal

3. TDF 70 Information Sheet ) requesting issuance of a diplomatic passport

4. Two 2” X 2” passport photos

5. A letter of orders from the LB&I deputy commissioner, or his/her delegate, outlining the need for an official or diplomatic passport. This is also referred to as the permanent change of station travel authorization.


4. For further guidance, see the Travel Office website.


**1.32.5.4.6** **(06-16-2016)**

#### Visas

1. The Travel Office obtains visas for travelers when required for official travel. The Travel Office will determine the need for a visa. If needed, the traveler will be contacted to provide the necessary application forms for the country (or countries) in question. In most cases, the travelers will be required to complete and return the visa application to the Travel Office. The Travel Office will process the visa application and notify the traveler when the visa is received.

2. For further guidance, see the Travel Office website.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-032-005#addtoany "Show all")

A2A