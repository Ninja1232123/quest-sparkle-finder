---
url: "https://www.irs.gov/irm/part1/irm_01-056-001"
title: "1.56.1 LB&I Policy Office Processes and Procedures | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-056-001#main-content)

- 1.56.1  [LB&I Policy Office Processes and Procedures](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367910256)
  - 1.56.1.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367586032)
    - 1.56.1.1.1  [Background and Mission](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367609776)
    - 1.56.1.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367637936)
    - 1.56.1.1.3  [Roles and Responsibilities of LB&I Policy](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367634192)
      - 1.56.1.1.3.1  [Role of Policy Analysts and Subject Matter Experts](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367096656)
      - 1.56.1.1.3.2  [Additional Roles and Responsibilities for Subject Matter Practice Areas](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367554672)
    - 1.56.1.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367550384)
    - 1.56.1.1.5  [Acronyms](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367654832)
    - 1.56.1.1.6  [Related Resources](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367543008)
  - 1.56.1.2  [Policy Development Cycle and Process](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367946816)
    - 1.56.1.2.1  [Initiate: Identify Needs](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367646384)
    - 1.56.1.2.2  [Initiate: Submit Policy Development Requests](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367644784)
      - 1.56.1.2.2.1  [Assigning and Scoring a Request](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367921488)
      - 1.56.1.2.2.2  [SPG Management Review and Acceptance of Request](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367918080)
      - 1.56.1.2.2.3  [Submitter Notifications](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367933488)
    - 1.56.1.2.3  [Review: Document and Research](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367931152)
    - 1.56.1.2.4  [Review: Create/Develop/Draft the Policy](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367908320)
    - 1.56.1.2.5  [Review: Informal Review (Consult with Appropriate Stakeholders)](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367903104)
      - 1.56.1.2.5.1  [Informal Review Guidelines for Originators](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367898832)
      - 1.56.1.2.5.2  [Guidance for Reviewers](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367824112)
    - 1.56.1.2.6  [Approve: Formal Clearance](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367819920)
      - 1.56.1.2.6.1  [Guidelines for Practice Area IMD Coordinators](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367810560)
    - 1.56.1.2.7  [Approve: Management Approval](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367400208)
    - 1.56.1.2.8  [Implementation](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367395104)
      - 1.56.1.2.8.1  [Communications](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367629680)
    - 1.56.1.2.9  [Post-Issuance Monitoring](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367613792)
  - 1.56.1.3  [Internal Management Document Policy](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367973408)
    - 1.56.1.3.1  [IRM Ownership](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367961968)
    - 1.56.1.3.2  [Signature Authority](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367959664)
      - 1.56.1.3.2.1  [Signature for Editorial Updates](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367582400)
    - 1.56.1.3.3  [Directive Transition](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367579936)
    - 1.56.1.3.4  [Informational Resources](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367574400)
    - 1.56.1.3.5  [IMD Reviews from Other Divisions](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367569712)
  - 1.56.1.4  [Other Policy Office Procedures - Requests and Inquiries](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367562512)
    - 1.56.1.4.1  [Procedures for Assigner Point of Contact and Analysts](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367605872)
    - 1.56.1.4.2  [Getting it Right Together (GIRT) Inquiries](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367600944)
    - 1.56.1.4.3  [Mailbox Inquiries](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367598128)
    - 1.56.1.4.4  [Knowledge Base Inquiries](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367596336)
  - 1.56.1.5  [Knowledge Base Virtual Library Procedures](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367594352)
  - Exhibit  1.56.1-1  [Aspects to Consider in Developing a Communications Plan](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367362672)
  - Exhibit  1.56.1-2  [Email Guidelines](https://www.irs.gov/irm/part1/irm_01-056-001#idm140389367283360)

# Part 1. Organization, Finance, and Management

# Chapter 56. Large Business and International

# Section 1. LB&I Policy Office Processes and Procedures

* * *

## 1.56.1 LB&I Policy Office Processes and Procedures

#### Manual Transmittal

July 13, 2022

#### Purpose

(1) This transmits revised IRM 1.56.1, Large Business and International, LB&I Policy Office Processes and Procedures.

#### Material Changes

(1) This IRM has been expanded to include the following:

- IRM 1.56.1.2 Policy Development Cycle

- IRM 1.56.1.4, Other Policy Office Procedures - Requests and Inquiries

- IRM 1.56.1.5, Knowledge Base Virtual Library Procedures


(2) Added more detail to IRM 1.56.1.1, Program Scope and Objectives, including new subsections on background, authority, program management and acronyms.

(3) Added clarification regarding Official Use Only approval to IRM 1.56.1.3.2, Signature Authority.

(4) Added new subsection 1.56.1.3.6, IMD Reviews from Other Divisions, which includes reviewer guidelines.

(5) Added new exhibits related to communications.

| **Exhibit** | **Title** |
| --- | --- |
| 1.56.1-1 | Aspects to Consider in Developing a Communications Plan |
| 1.56.1-2 | Email Guidelines |

(6) Editorial corrections have been made throughout.

#### Effect on Other Documents

This IRM supersedes IRM 1.56.1 dated August 13, 2021.

#### Audience

Primarily LB&I employees but may be of interest to other business units who work with LB&I on joint projects.

#### Effective Date

(07-13-2022)

Theodore D. Setzer

Assistant Deputy Commissioner Compliance Integration

Large Business and International Division

**1.56.1.1** **(07-13-2022)**

### Program Scope and Objectives

1. **Purpose**: This IRM outlines the model for managing LB&I internal management documents (or IMDs), the policy development process, and other Policy Office procedures. .

2. **Audience**: LB&I employees at all levels within the organization and employees of other business units who work with LB&I on joint projects.

3. **Policy Owner**: Assistant Deputy Commissioner Compliance Integration

4. **Program Owner**: Director, Strategy, Policy and Governance

5. **Primary Stakeholders**: Stakeholders include all LB&I employees at all levels within the organization.


**1.56.1.1.1** **(07-13-2022)**

#### Background and Mission

1. The LB&I Policy Office became operational on February 16, 2020, and resides within the Strategy, Policy and Governance (SPG) function in the office of the Assistant Deputy Commissioner Compliance Integration (ADCCI).

2. The mission of the LB&I Policy Office is to:



1. Apply a consistent approach to policy decisions for LB&I operations to ensure they align with LB&I strategic goals and objectives.

2. Define and document LB&I policies and monitor LB&I operations to assess adherence to LB&I policies and quality standards.

3. Ensure all policy decisions are coordinated/vetted with internal and external stakeholders, as appropriate.

4. Ensure policy and guidance are issued timely.


**1.56.1.1.2** **(07-13-2022)**

#### Authority

1. Authority is received from many sources including but not limited to Government Accountability Office (GAO), Office of Management and Budget (OMB), Office of Personnel Management, Treasury, IRS and LB&I.

2. The following laws apply to IMD management:



   - 44 USC 3101, Records Management by Federal Agencies, requires federal agencies to make and preserve records documenting organizational structure, functions, policies, decisions, procedures and essential transactions of the agency.

   - The Freedom of Information Act (FOIA), 5 USC 552 (a)(2)(C), provides public access to agency administrative staff manuals and instructions to staff affecting a member of the public unless protected from disclosure by an exemption under 5 USC 552(b).


**1.56.1.1.3** **(07-13-2022)**

#### Roles and Responsibilities of LB&I Policy

1. A dedicated LB&I policy function improves the IRM update and interim guidance (IG) approval processes. Any instructions to staff will be cleared for publication through one of the LB&I IMD coordinators in ADCCI. This follows Servicewide procedures. The IMD author must contact the IMD coordinator at the beginning of any IMD project for advice and guidance. For example, the IMD coordinator assists IRM authors with interim guidance format and requests new IRM sections from the Servicewide Policy Directives and Electronic Resources (SPDER) office, which oversees IMD procedures. See IRM 1.11.1.6.7.1 for a full description of IMD coordinator responsibilities.

2. LB&I Policy Office analysts and practice area subject matter experts (SMEs) ensure that policies impacting LB&I are disseminated throughout the IRS and to the public, if applicable. The LB&I Policy Office serves as liaison with other business unit policy offices and the lead for all matters related to other business unit policy offices.


**1.56.1.1.3.1** **(07-13-2022)**

##### Role of Policy Analysts and Subject Matter Experts

1. The following roles in the LB&I IRM/IMD process are defined as follows:



|     |     |     |
| --- | --- | --- |
| **Role Title** | **Duties described** | **Responsible Party** |
| Subject Matter Expert (SME) | Role includes subject matter expertise, ensuring the accuracy of technical content, handling inquiries, communications, facilitating change requests, gathering feedback from stakeholders, etc. **Contributor role**– provide feedback and suggests necessary content changes to the IRM author. May author procedures under the policies. | May be either a Policy Office or Practice Area analyst, depending on subject matter. |
| Content Author | Responsible for IRM and other guidance currency. Receives SME suggestions, creates content using Arbortext, and finalizes all content including informal reviews contained in the policy change/development job aids. Performs IRM/IMD clearance before sending to IMD coordinator for approval process. Receives approved content and leads implementation. | Policy Office Analyst |
| IMD Coordinator | SME for all IMD processes. Compiles and tracks routing on all IMD content ready for executive approval. Also performs final review and assessment and submits to Publishing. | LB&I Policy IMD Coordinator |


**1.56.1.1.3.2** **(07-13-2022)**

##### Additional Roles and Responsibilities for Subject Matter Practice Areas

1. Subject Matter Practice Area management should ensure that technical content change requests presented to the LB&I Policy Office analyst for consideration have been appropriately vetted within the practice area. Documentation of such internal agreement should be provided in the policy change/development request.

2. The LB&I Policy Office analyst assigned as IRM author must be informed at the earliest possible time if an external audit such as TIGTA or GAO, or a matter under consideration by the Taxpayer Advocate, could result in a needed policy change or IRM content update. The LB&I Policy Office analyst should be included in the review of any agreed upon actions by a subject matter practice area before the subject matter practice area obligates LB&I to any IRM content plans of action. Contact the LB&I Policy Office through the LB&I Policy Gateway and Create a Request.

3. Instructions to taxpayers are not IRM content. Subject matter practice areas, their SMEs or LB&I Policy Office analysts should coordinate this type of content with the appropriate counsel or other function.


**1.56.1.1.4** **(07-13-2022)**

#### Program Management and Review

1. Most policy work is managed by the Policy Office through the LB&I Policy Gateway. The LB&I Policy Gateway is a SharePoint site that:



   - Allows for capture, tracking, management, assignment and reporting on LB&I policy requests while providing a centralized tool to monitor status.

   - Allows for capture of historical responses to allow research and aid in consistent responses.

   - Provides operational reporting to manage work assignments.

   - Standardizes most Policy Office work in one location.


2. Policy work is monitored using the Manager’s Dashboard in the LB&I Policy Gateway.

3. The Lead Policy Analyst assigned a request must update the status of a request in a timely manner and ensure the requests are closed when completed.


**1.56.1.1.5** **(07-13-2022)**

#### Acronyms

1. See the table below for a list of acronyms used in this IRM.




| **Acronym** | **Definition** |
| --- | --- |
| ADCCI | Assistant Deputy Commissioner Compliance Integration |
| ATG | Audit Technique Guide |
| C&L | Communications and Liaison |
| GAO | Government Accountability Office |
| GIRT | Getting It Right Together |
| IG | Interim Guidance |
| IMD | Internal Management Document |
| KB | Knowledge Base |
| OMB | Office of Management and Budget |
| POC | Point of Contact |
| SPDER | Servicewide Policy Directives and Electronic Resources |
| SME | Subject Matter Expert |
| SPG | Strategy Policy and Governance |
| TIGTA | Treasury Inspector General for Tax Administration |


**1.56.1.1.6** **(07-13-2022)**

#### Related Resources

1. Link to Policy Office Gateway: https://program.ds.irsnet.gov/sites/LBIPOLICYGATEWAY/\_layouts/15/start.aspx#/

2. LB&I Policy Office Virtual Library page: https://portal.ds.irsnet.gov/sites/vl011/lists/comppolicysupport/landingview.aspx


**1.56.1.2** **(07-13-2022)**

### Policy Development Cycle and Process

1. Effective policy processes follow defined cycles. For the LB&I Policy Office, this has been further defined into a policy cycle:




| **Step** | **Breakdown/Description** |
| --- | --- |
| Initiate | - Identify needs<br>     <br>   - Submit policy change/development request<br>     <br>   - Assign and score<br>     <br>   - Management review and acceptance |
| Review | - Research<br>     <br>   - Create/develop/draft<br>     <br>   - Informal Review |
| Approve | - Formal clearance<br>     <br>   - Management approval |
| Implement | - Issue, publish<br>     <br>   - Consider supplemental material |
| Monitor | - Remain agile<br>     <br>   - Follow up<br>     <br>   - Review, revise as needed |


**1.56.1.2.1** **(07-13-2022)**

#### Initiate: Identify Needs

1. New policies may be developed in anticipation of a need (e.g. new strategy such as LB&I POD strategy) or in response to a need (e.g. IRS provides new guidance on governance). LB&I Policy teams and practice area SMEs/program administrators constantly assess activities, responsibilities, and the internal and external environments to identify the need for new policies and procedures and/or updates to existing policies and procedures. The LB&I Policy process depends on careful and deliberate consideration of all policy development requests.


**1.56.1.2.2** **(07-13-2022)**

#### Initiate: Submit Policy Development Requests

1. LB&I uses a centralized policy development process. Projects or efforts that involve potential new guidance or changes to existing guidance must have a related policy development request on the LB&I Policy Gateway at the beginning of the project.

2. The term **policy development request** includes:



   - A request to begin development of a policy on guidance that does not currently exist, **or**

   - A request to change an existing policy.


3. An IRM author, SME or manager will submit a policy development request as soon as they identify a need for a new policy or a change in policy. SMEs who want to make changes or develop new guidance should discuss with their assigned LB&I Policy Office analyst and enter a policy development request before beginning informal or formal socialization of guidance text.

4. All requests are required to be submitted via the LB&I Policy Gateway "Create a Request" tile. Requesters should coordinate policy development requests through their practice area IMD analyst or copy them on the submission. Policy Office analysts can assist submitters with their request as needed.

5. LB&I Policy Office managers and analysts may consult and pre-plan with customers before a policy development request is submitted; however, actual development work may not begin until a policy development request has been submitted and accepted on the LB&I Policy Gateway. Early coordination and collaboration with the Policy Office will facilitate timely issuance of guidance.

6. Examples of potential policy development requests include (but are not limited to):



   - Changes to existing IRM to incorporate paperless processes.

   - Updates or clarifications of IRM content.

   - New IRM needed because a new law or examination approach has come into existence.

   - A short-term (less than two years) temporary guidance memo needed to deviate from an existing procedure in the IRM.

   - Establishment of a project team that will involve new or changed guidance.

   - Review of a new practice unit or job aid to determine if any of the content is IRM material.

   - Revisions or updates to reflect published guidance and other counsel advice.

   - Guidance defining required parameters on LB&I employee usage of technology tools such as video conferencing, digital signatures, etc.


**1.56.1.2.2.1** **(07-13-2022)**

##### Assigning and Scoring a Request

1. After the policy development request is submitted, it will be assigned to Policy Office analysts to research and score the request for cost and impact. This process will help prioritize requests. The initial scoring and due diligence should be completed promptly and efficiently. Exhaustive research is not required at this point.

2. When scoring and initial research is complete, a matrix with four quadrants is available on the LB&I Policy Gateway for Policy Office analysts and management to graphically illustrate the scoring. Policy Office analysts should consider this when making their recommendation on whether to accept the request. Once completed, the initial considerations are forwarded to the Policy Office team managers for review and consideration.


**1.56.1.2.2.2** **(07-13-2022)**

##### SPG Management Review and Acceptance of Request

1. Each Policy Office team manager should review the request, analyst notes and scoring, and enter a recommendation on the Policy Team Review form. They will consider available resources when recommending or approving team assignments.

2. Development requests that represent introduction of a new policy, a substantial change to existing policy, or that require augmentation or reallocation of resources among Policy teams will be routed to the SPG Director for review and concurrence before work is started.

3. The SPG Director or Assistant Deputy Commissioner - Compliance Integration may choose to review a request and decide whether to accept regardless of other recommendations.

4. The SPG Director and management may hold meetings as needed to discuss requests and make acceptance determinations. They will decide team and analyst assignments using the following considerations:




| **Team and Analyst Assignments** |
| --- |
| Part I - Staffing Considerations |
| 1. Affected IRM or subject matter has a policy analyst or team assigned as lead.<br>      <br>2. Submitting practice area has a policy analyst assigned.<br>      <br>3. Either 1) or 2) applies but the logical team placement has no resources available to receive the work.<br>      <br>4. New IRM or subject matter does not have a policy analyst or team assigned.<br>      <br>5. Other. |
| Part II - Available Resources |
| 1. Using the scoring graph, discuss whether the requested completion date from the submitter is reasonable or set a new completion date and document the reason.<br>      <br>2. Using current work commitments and available resources on the teams, discuss whether the requested start date is reasonable and achievable for the assigned team.<br>      <br>3. Determine a start date. |


**1.56.1.2.2.3** **(07-13-2022)**

##### Submitter Notifications

1. The Policy Office team manager is responsible for notifying the assigned Policy Office analyst of their new work and the submitter of the determination. This should be completed within 3-5 business days after acceptance.

2. If a request will be declined, the Policy Office team manager will offer to discuss with the submitter.


**1.56.1.2.3** **(07-13-2022)**

#### Review: Document and Research

1. The assigned Policy Office analyst will begin work on the new or changes to the IRM/IMD. They will use the Policy Team Review form on the LB&I Policy Gateway to contemporaneously document actions for each process step.

2. The intent of the policy development process and Policy Team Review form is to document the who, what, when, where and why details as work progresses. Thorough documentation will create an official record of each change so that we can benefit from past experience and not duplicate work.

3. The Policy Office analyst will identify SMEs and other stakeholders and define their roles.. They are responsible for establishing working groups, coordinating with SMEs and impacted stakeholders as needed and documenting interactions.

4. Policy Office analysts must retain their work product and create an easy-to-follow audit path for future reference. This is important documentation not only for Policy Office purposes to explain and defend its decisions but may also be reviewed by GAO/TIGTA .The policy analyst will ensure the policy follows required steps for proper development, documentation, coordination, approval, and communication and that all documentation is included on the LB&I Policy Gateway. See the Policy Gateway User Guide for more details.

5. The LB&I Policy Office analyst should research the policy development request. Suggestions and references are available on the Policy Team Review Form. In general, the Policy Office analyst should consider and determine the following as applicable (not all inclusive):



   - Determine if there are OMB, Treasury or IRS policies on the subject matter that need to be considered.

   - Gather information from current sources to ensure accuracy and currency.

   - Determine if other BODs are developing policy around the same issue and identify any differences.

   - Gather existing policies, templates or examples that will help in the development of the policy.

   - Identify the SMEs.

   - Identify the policy stakeholders.


**1.56.1.2.4** **(07-13-2022)**

#### Review: Create/Develop/Draft the Policy

1. Follow plain language guidance when drafting the policy. Ensure that the wording, length and complexity of the policy are appropriate for those who will be expected to implement it.

2. The LB&I Policy Office analyst is the lead author who writes or changes draft content. No letterhead or other formal indications are to be used for this initial drafting and review.

3. Plans that may need to be developed to support the policy are:



   - Communications plan (see IRM 1.56.1.2.12)

   - Implementation plan

   - Technology assessment and agreement

   - Training plan

   - Monitoring plan


**1.56.1.2.5** **(07-13-2022)**

#### Review: Informal Review (Consult with Appropriate Stakeholders)

1. Policies are most effective when those affected by the policy are consulted and involved in the development of the policy. The LB&I Policy Office analyst and practice area SMEs will hold working group sessions to ensure that SMEs are included in discussions and development of policies. The Policy Office analyst and SME(s) should develop a plan for circulating draft policy to stakeholders (as identified in 1.56.1.2.3) for informal comments and review as part of the authoring process..

2. The purpose of informal review is to ensure that all relevant details are included to arrive at a document that is ready for formal review and clearance. Informal review should be limited to key SMEs and stakeholders within a defined period. Policy Office analysts should consider soliciting informal comments on an IMD if the document is significantly rewritten or is introducing new concepts.

3. The Policy Office analyst will document impacts to stakeholders and resolve conflicts between groups of stakeholders at the lowest level possible and elevate issues as needed.


**1.56.1.2.5.1** **(07-13-2022)**

##### Informal Review Guidelines for Originators

1. The following guidelines are for the analyst originating the informal review:



1. Send requests to practice area IMD coordinators or specific SMEs.

2. Send a PDF copy without a letterhead and add a draft watermark.

3. Clearly state in the email that the request is for informal review. Do not use the term "clearance" because clearance is a separate step that comes later in the process.

4. Provide a standard response template and clear instructions for reviewers.

5. Provide a specific response date. The review period is generally 14 days, although this can vary depending on the subject matter, length of document and timeline.


**1.56.1.2.5.2** **(07-13-2022)**

##### Guidance for Reviewers

1. The following guidelines are for reviewers who are asked to provide feedback on a document:



1. Use the response template to provide feedback and do not modify the template.

2. Do not use the PDF comment or sticky note feature to edit in the document.

3. Focus on the document **content** in the review. The author will update the draft and correct grammatical or spelling errors prior to formal clearance.


**1.56.1.2.6** **(07-13-2022)**

#### Approve: Formal Clearance

1. Formal clearance is the process of circulating a final draft to end users and other stakeholders for review and comment. LB&I uses the SPDER E-Clearance tool to circulate IRMs for formal clearance.

2. The following are guidelines for LB&I Policy Office analysts coordinating formal clearance:



1. For IG memorandum clearance procedures, see IRM 1.11.10.5.3, Clearance and Approval of Interim Guidance Memoranda. LB&I Policy Office analysts are to send the IG memorandum without letterhead and add a draft watermark so that reviewers do not mistake a clearance document for an approved document.

2. For IRMs, follow IRM 1.11.9.5, Clearance Submission Guidelines.


3. See IRM 1.56.1.2.6.1, Guidelines for Practice Area IMD Coordinators, for receiving both informal review and formal clearance requests.

4. Reviewers will follow IRM 1.11.9.7, Guidelines for Reviewers, and the guidelines in _IRM 1.56.1.2.5.2_, Guidance for Reviewers.

5. See IRM 1.11.9.7.1, Review Assessment and Reviewer’s Signature, for details on how to submit a review assessment. In addition, reviewers are required to use the E-Clearance tool to input or attach their comments. For multiple comments, Word and Excel feedback matrices are available for download on the Add Comment screen in E-Clearance system. **Do not**use a Word document with markup. Such documents will not be accepted.



### Note:



Do not use a "Do Not Concur" assessment for editorial comments. A "Do Not Concur" assessment should only be used for major substantive disagreements with the IRM content.

6. During clearance, Policy Office analysts will consider all formal feedback and with team manager input make changes to the policy under development.


**1.56.1.2.6.1** **(07-13-2022)**

##### Guidelines for Practice Area IMD Coordinators

1. Requests for formal clearance are generally sent to practice area IMD coordinators. The following are guidelines for managing reviews that apply to both informal review and formal clearance for practice area IMD coordinators.



1. Ensure that the request is forwarded to an adequate number of reviewers who will be following the guidance in their day-to-day work. For LB&I to effectively make changes or develop new guidance, feedback from those who will be carrying out the work is essential. Comments from end-users – frontline managers and employees – are encouraged.

2. Send all comments received from reviewers as is.

3. Reviewer’s name and position title should be provided to facilitate follow-up discussion.


**1.56.1.2.7** **(07-13-2022)**

#### Approve: Management Approval

1. LB&I Policy Office analysts, in consultation with management, should determine what level of approval is required. Generally, interim guidance memos and IRMs are approved by the Assistant Deputy Commissioner Compliance Integration. See _IRM 1.56.1.3.2_, Signature Authority, to determine approval level.

2. When feasible, an implementation/effective date should be proposed for 15-45 days after the IRM/IMD is approved to allow for implementation, communication and training.

3. For IRMs, prepare the final approval package on the E-Clearance system according to IRM 1.11.9.10, Final Stages of the Clearance Process.

4. The Policy Office analyst should include sufficient background information in any routing emails or documents so that each approver can access background documentation related to the final product. One way to do this is to include the Policy Gateway request link in the final package. The link provides historical and collaboration information in one place.

5. Update the policy with any feedback from the approving authority. Any substantial changes based on comments on the E-Clearance system should be documented on the Policy Team Review form for future reference.


**1.56.1.2.8** **(07-13-2022)**

#### Implementation

1. Implementation involves the following activities:



1. Issuance of the document

2. Writing articles or emails to announce the issuance (see IRM 1.56.1.2.8.1)

3. Developing job aids or supplemental material, if needed

4. Developing training, if applicable

5. Ensuring that points of contact are in place to answer questions.

6. Ascertaining the need for any other teams or people for support.


The LB&I Policy Office analyst should verify the proposed implementation/effective date and adjust if necessary.



2. Issuance procedures depend on the type of document to be issued. After approval, IRMs are given a final review and assessment by the LB&I IMD coordinator per IRM 1.11.9.10.2, Final Review by IRM/IRM Coordinator. The coordinator will then submit the IRM to Media and Publications for publishing.

3. Interim Guidance memos are posted to the IMD Tracking System and linked to IRM Online. See IRM 1.11.10.5.4, Distributing Interim Guidance Memoranda. They may also be posted to the FOIA Library on IRS.gov if they meet E-FOIA criteria. See IRM 1.11.1.3.1.2, E-FOIA Criteria for Instructions to Staff.

4. Procedures and supplemental material (e.g., job aids and web pages) are often necessary to support internal policies. Consider whether there is clear guidance on how the policy will be implemented and by whom. See IRM 1.11.2.2.1, Supplemental Sources of Guidance, for more information. If supplemental material is required:



   - Determine if a job aid or supplemental instruction should be updated or is required.

   - Assign responsibility for writing the supplemental procedures.

   - Determine the stakeholder review process

   - Determine the approval process

   - Document the action item and due dates


5. LB&I Policy Office analysts must complete all documentation requirements (in accordance with the user guide) in the Policy Gateway before closing the policy development request.


**1.56.1.2.8.1** **(07-13-2022)**

##### Communications

1. The responsibility for communications and other implementation strategies depends on program ownership. In situations where LB&I Policy is not the SME, the Policy Office analyst must inform the SME practice area clearly and early that they are responsible for implementing communications or other strategies. If the LB&I Policy Office is the SME, then they will be responsible for implementation.

2. For Policy-owned programs, the Policy Office analyst will determine the final communication strategy then coordinate with the LB&I Communication and Strategy team analyst to determine the communication approach (e.g., Frontline News, external communication).The following are the roles of the LB&I Policy Office and Communications & Liaison staff with respect to communications for these programs.




| **Position** | **Role(s)** |
| --- | --- |
| Policy Office Analyst | - Develops communication plan while working on the actual guidance<br>     <br>   - Drafts communication and send to C&L for editing<br>     <br>   - After editing, sends proposed communication to Policy Office team manager and SPG Director for final approval. |
| LB&I Communications and Strategy Team Consultant | - Works with Policy Office to determine scope of communication, target audience, frequency and appropriate communications channels.<br>     <br>   - Works with LB&I Communications Web/User Experience to coordinating posting of content on IRSSource or IRS.gov (if applicable).<br>     <br>   - Edits draft communications from Policy Office<br>     <br>   - Finalizes and publishes content in appropriate communications products. |
| Policy Office Team Manager | - Reviews and approves communication plan and drafts. |
| SPG Director | - Reviews and may provide final approval of communication plan and actual communications as needed.. |


**1.56.1.2.9** **(07-13-2022)**

#### Post-Issuance Monitoring

1. The LB&I IMD coordinators monitor LB&I IMD documents for currency. They conduct IRM/IMD status reviews as part of the annual Servicewide IMD certification process. Expiration dates for IG memoranda are monitored on the IMD Tracking System.

2. Policy analysts and SMEs should evaluate impact and feedback from end users and other stakeholders.


**1.56.1.3** **(07-13-2022)**

### Internal Management Document Policy

1. IMDs are any official communication of IRS policies, instructions to staff, guidelines or procedures. IMDs include the Internal Revenue Manual (or IRM), delegation orders, policy statements, and commissioner memoranda. This IRM addresses IRM ownership, IMD approval levels and appropriateness of IRM content. The goal is to improve the timeliness and the control of LB&I IMDs and the consistency of IMD procedures.

2. The IRM is the primary, official source of instructions to staff. "IRM content" or "IRM" as used throughout this document includes content that falls into one of the following categories:




| **Category** | **Description** |
| --- | --- |
| Delegations of Authority | In general, the power to give orders or make decisions. Delegation orders are issued by the Commissioner of Internal Revenue (or on the Commissioner's behalf), to subordinates, with or without restriction or redelegation. |
| Guidelines | Directions employees use to determine a course of action or explanations that help employees make judgments based on facts. |
| Interim Guidance (IG) | A memorandum or IRM procedural update used to convey immediate, emergency or temporary changes to operations or procedures. |
| Policy Statement | A statement concerning an important ideal or value that guides IRS in administering the internal revenue laws and forms the basis for IRM procedures. |
| Procedures | A process, series of instructions to follow, or a sequence of steps that establishes a standard based on rule or policy. |



    For more information on IRM content scope and content placement for LB&I see IRM 4.51.2, LB&I Administrative Guidance.




**1.56.1.3.1** **(08-13-2021)**

#### IRM Ownership

1. Ownership of LB&I’s IRMs has been transferred to ADCCI. Practice areas have designated SMEs for each IRM transferred. LB&I IMD coordinators maintain a list of these SMEs. The practice areas should inform LB&I Policy of any SME changes by creating a request on the Policy Gateway site.


**1.56.1.3.2** **(07-13-2022)**

#### Signature Authority

1. For guidance affecting more than one practice area or IRM section, the signature authority has moved from the LB&I Commissioner to the Assistant Deputy Commissioner Compliance Integration. Signature authority for interim guidance affecting only one practice area has moved from the LB&I Commissioner to the Director overseeing the program. "One practice area" is defined as guidance impacting only the direct downstream footprint of an LB&I Practice Area Director. In these cases, the LB&I Policy Office will pre-review the guidance and determine the scope and impact on the practice areas. This change aligns with Servicewide policy that the program director is the signatory for interim guidance and is ultimately responsible for the content.

2. The designation of Official Use Only content must be approved by a director-level official according to Delegation Order 11-1. If a specialized IRM or IG memo (whose primary SME is in a practice area outside of ADCCI) has OUO content, the director of that practice area must sign Form 2061, Document Clearance Record, or add a review assessment in E-Clearance to approve the OUO designation.



### Note:



If a separate Form 2061 is signed, it may be uploaded into the E-Clearance system.

3. At the discretion of the LB&I Commissioner, guidance may be signed at a higher level. See IRM 1.11.10.2, Interim Guidance Standards, paragraph (7).


**1.56.1.3.2.1** **(08-13-2021)**

##### Signature for Editorial Updates

1. The editorial update process, as defined in IRM 1.11.2.8, is a streamlined way of making corrections to titles, website address citations and typographical errors that do not affect the meaning of the content. This process requires clearance and approval only by the author’s management chain. The ADCCI Director for Strategy, Policy, and Governance will have the authority to initiate and approve editorial changes to any LB&I IRM, regardless of signatory approver. This practice will help maintain a more accurate and timelier IRM.


**1.56.1.3.3** **(07-13-2022)**

#### Directive Transition

1. Historically, the former LB&I industries used to provide issue-related guidance in the form of an "Industry Director Directive." Over time, these directives transformed into "LB&I Directives" that were approved by the LB&I Commissioner.

2. LB&I no longer uses this industry directive format as was set forth in former IRM 4.51.2.6, Developing Administrative Guidance – LMSB Directives. All LB&I IRM guidance will be issued as interim guidance memos, per IRM 1.11.10, Interim Guidance Process, if not incorporated directly into the IRM. See IRM 4.51.2, LB&I Administrative Guidance, for more information and examples of what is considered "IRM guidance" .

3. Practice area and Policy Office analysts will evaluate all existing directives for relevancy and incorporate appropriate guidance into the IRM. Outdated guidance will be made obsolete and informational material will be housed elsewhere, such as practice units or audit technique guides (ATGs). The LB&I Policy Office will coordinate this process.



### Note:



See _IRM 1.56.1.3.4_ for placement of information contained in directives that does not meet the definition of IRM material.


**1.56.1.3.4** **(08-13-2021)**

#### Informational Resources

1. Some LB&I IRMs and LB&I directives contain information that does not fall into one of the instructions to staff categories above. Such content will be placed into an informational resource such as a practice unit, virtual library book or an ATG.

2. The Policy Office does not own, author, publish, or approve audit technique guides, practice units, or other informational resources. These functions are carried out by various practice areas across LB&I. The role of the policy function is to ensure content is placed in the appropriate place and that these types of resources do not contain instructions to staff that should be placed in the IRM. Policy Office analysts will review IRM content to ensure it is housed in the appropriate place and move content between formats as necessary.

3. See IRM 4.51.2, LB&I Administrative Guidance, for more information on informational resources.


**1.56.1.3.5** **(07-13-2022)**

#### IMD Reviews from Other Divisions

1. The Policy Office, through the \*LB&I IMD Coordinator mailbox, receives draft IRMs and other IMDs from other BODs for review and clearance. These reviews have deadlines, usually 30 days from receipt. The LB&I IMD coordinators keep a log of IMD review requests on the LB&I Policy Gateway. Depending on the subject matter, the LB&I IMD coordinator will send the IMD to one or more SMEs. An SME could be an analyst or specialist within any of the practice areas, PBS or ADCCI. Each LB&I practice area and function has an IMD coordinator, who serves as a contact point for IMD reviews pertaining to their function.

2. The LB&I IMD co-coordinators serve as a conduit between the originator and the SME. The LB&I IMD coordinator’s role is to make sure that the request is sent to the appropriate SME and that responses are complete.

3. Guidelines for reviewers are found in IRM 1.11.9.7. Reviewers are reminded to focus on the changed content. The author is under no obligation to consider comments on unchanged content. Such feedback should be submitted outside of the clearance process per IRM 1.11.6.6, Providing Feedback About an IRM Section - Outside of Clearance.

4. See IRM 1.11.9.7.1, Review Assessment and Reviewer’s Signature, for details on how to submit a review assessment. For IRMs, reviewers are required either to input their comments into the E-Clearance tool or use a feedback matrix that be uploaded into the E-Clearance system. **Do not**use a Word document with markup. Such documents are hard for authors to work with.



### Note:



Do not use a "Do not Concur" assessment for editorial comments. A "Do Not Concur" assessment should only be used for major substantive disagreements with the IRM content.


**1.56.1.4** **(07-13-2022)**

### Other Policy Office Procedures - Requests and Inquiries

1. Customer service is important to the Policy Office thus timely responses are imperative.

2. Inquiries come in via the following channels:



1. "Create a Request" entered on the LB&I Policy Gateway. This is the preferred method for submitting inquiries.

2. Feedback from Getting it Right Together (GIRT).

3. Emails from "Contact an Expert" or "Page Feedback" from the Exam Procedures Knowledge Base.

4. Emails from "Contact an Expert" or "Page Feedback" from the Policy Office book on the Virtual Library.


**1.56.1.4.1** **(07-13-2022)**

#### Procedures for Assigner Point of Contact and Analysts

1. The assigner point of contact (POC) monitors, works and assigns requests from the LB&I Policy Gateway. See Policy Gateway Operating Guide for details.

2. The POC will:



1. Check the assigner dashboard at least once a day and work/assign as appropriate.

2. Retain a copy of any all-employee communications (emails, Frontline news, etc.) from the LB&I Policy Office into the "Policy Email Communications" folder in the \*LB&I Policy Office mailbox for archive.


3. Policy Office analysts will work to provide a response within 7-10 business days. If more time is needed, the analyst will advise the POC or the submitter. If Policy Office analysts receive emails directly to their personal work email address related to policy topics, they will ask the submitter to enter the request directly on the LB&I Policy Gateway. Policy Office analysts may refer to LB&I Policy Research Center for previously answered inquiries


**1.56.1.4.2** **(07-13-2022)**

#### Getting it Right Together (GIRT) Inquiries

1. The mailbox receives an email from Nintex@spmail.ds.irs.gov (managed by LB&I Communications) that assigns an action to take. The POC will review those inquiries designated as “Assign for Action,” create a request in the LB&I Policy Gateway and assign to an analyst to respond. The analyst will follow the response language using the "Policy Team Inquiry Response Template." The submitter will automatically receive an email response. The analyst will also respond in the Policy Gateway on the "Policy Response Form" . LB&I Policy and LB&I Communications will be blind copied with the response to close the feedback out.


**1.56.1.4.3** **(07-13-2022)**

#### Mailbox Inquiries

1. Because the Policy Office mailboxes are being phased out for routine inquiries, the POC should review and handle any emails received in those mailboxes to ensure no important emails are missed.


**1.56.1.4.4** **(07-13-2022)**

#### Knowledge Base Inquiries

1. Employees having questions on the LB&I Exam Procedures Knowledge Base and Policy Office Book are directed to post their questions using the LB&I Policy Gateway.


**1.56.1.5** **(07-13-2022)**

### Knowledge Base Virtual Library Procedures

1. This subsection contains guidelines for updating and maintaining LB&I Policy Office’s Exam Procedures Knowledge Base (KB) and the Policy Office book on the Virtual Library.

2. The Exam Procedures KB is located at: https://portal.ds.irsnet.gov/sites/vl051/Pages/default.aspx

3. The LB&I Policy Office is responsible for the content of the following books:



   - Research

   - Planning the Exam

   - Information Gathering

   - Technical Issue Development

   - Issue Resolution Tools.

   - Report Writing and Unagreed Issues

   - Case File Administration


4. Designated SMEs are responsible for ensuring the content is up-to-date and set a time, at least once a year, to review and refresh their assigned pages. At times, certain pages will be updated or added on an ad-hoc basis, such as the Interim Guidance Memorandums page. Therefore, not all pages have the same expiration date and require the SMEs to develop their own schedule to monitor the expiration dates.

5. Each page is set to have the review period of **12 months**, except for four pages under the Policy Office book (IRMs, IG Memos, Delegation Orders, and FAQs), which are set to have the review period of **six months**due to the nature of their content. The page is considered "expired" if the page is not reviewed timely and the published date is not refreshed. To summarize:




| **Review Period** | **Pages** | **Book/KB** | **When to Update** |
| --- | --- | --- | --- |
| 6 months | - LB&I IRMs<br>     <br>   - IG Memos<br>     <br>   - Delegation Orders<br>     <br>   - FAQs | Policy Book | Before the 6-month expiration date or within 5 days after the related new document is published. |
| 12 months | All other pages | Policy Book | Before the 12-month expiration date or when needed. |
| 12 months | All pages | Exam Procedures Knowledge Base | Before the 12-month expiration date or when needed. |

6. If a new question needs to be added to the FAQs, determine the topic and follow the current FAQ format with the question and answer. Contact the policy analyst in charge of FAQs for more information on posting a new FAQ.


**Exhibit 1.56.1-1**

### Aspects to Consider in Developing a Communications Plan

The following are aspects to consider before developing a communications plan. These should clearly be communicated with our C&L Communications and Strategy team analyst as early as possible. Use the LB&I Policy Communications Plan check sheet.

1. Audience



   - Who is affected?

   - How many are affected?

   - Who else might need to know?


2. Timing



   - When did planning begin?

   - When will this begin to take effect?

   - When does it end, or is it an ongoing effort?


3. Policy or project description (what is happening)



   - What do those who are affected need to know?

   - What do those who are affected need to do?

   - What are the coordinators doing to help those who are affected?


4. End state



   - What will be different – how will people be affected?

   - How and when will we measure success?


5. Justification



   - Why is this happening?

   - How is it an improvement?

   - What’s in it for those who are affected?


6. Resources



   - What web pages, documents and/or training materials (if any) are related to this?

   - What web support (if any) will you need?


**Exhibit 1.56.1-2**

### Email Guidelines

LB&I Policy Office communications via email and e-newsletter products (e.g., Frontline News, Managers’ News Brief) should include the following aspects and be written "to" the recipient:

- The headline (e-newsletter) or subject line (email) should capture the reader’s attention and summarize the essence of the message in about 25 words or less.

- The first few sentences of the message should cover the _who_ (is affected), _what_ (is happening or has happened) and _when_ (it happened or will happen). There should be one or two sentences that contain all-inclusive information and discuss how it impacts the audience (may include who the communication is from).

- The message should include any/all links to the source document and other applicable information, so readers can easily refer to detailed information provided elsewhere.

- Use bullet or numbered lists (if warranted) to highlight key aspects in a few short points.

- Put the bottom line up front – most important info placed at the beginning of the message.

- End with a one-sentence conclusion (if warranted).


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-056-001#addtoany "Show all")

A2A