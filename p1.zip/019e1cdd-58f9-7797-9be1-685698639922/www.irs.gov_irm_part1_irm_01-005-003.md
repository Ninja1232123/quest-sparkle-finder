---
url: "https://www.irs.gov/irm/part1/irm_01-005-003"
title: "1.5.3 Manager’s Self-Certification and the Independent Review Process | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-005-003#main-content)

- 1.5.3  [Manager’s Self-Certification and the Independent Review Process](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426380298192)
  - 1.5.3.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350264416)
    - 1.5.3.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350250624)
    - 1.5.3.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350247472)
    - 1.5.3.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350244432)
    - 1.5.3.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350305744)
    - 1.5.3.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350303440)
    - 1.5.3.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350301232)
    - 1.5.3.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426351186976)
  - 1.5.3.2  [Section 1204 Program Responsibilities](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426351151808)
    - 1.5.3.2.1  [Human Capital Office Program Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426351150096)
    - 1.5.3.2.2  [Section 1204 Business Unit Program Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426351122944)
    - 1.5.3.2.3  [Statistics of Income, General Legal Services, and the Human Capital Office Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426351103392)
  - 1.5.3.3  [Retention Standard for the Fair and Equitable Treatment of Taxpayers](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350958400)
    - 1.5.3.3.1  [National Treasury Employees Union Requirements Related to Section 1204](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350919728)
    - 1.5.3.3.2  [Manager Discussions](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350913584)
    - 1.5.3.3.3  [Retention Standard Behaviors](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350909120)
    - 1.5.3.3.4  [Retention Standard Documentation](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350900128)
    - 1.5.3.3.5  [Retention Standard Non-Compliance](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350861760)
  - 1.5.3.4  [Section 1204 Quarterly Certification Requirements](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350846304)
    - 1.5.3.4.1  [Due Dates](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350826240)
    - 1.5.3.4.2  [Acting Managers](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350820960)
    - 1.5.3.4.3  [Manager's Quarterly Certification Review Components](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350814112)
    - 1.5.3.4.4  [Identifying and Addressing Records of Tax Enforcement Results Violations](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350782960)
    - 1.5.3.4.5  [Counting and Reporting Records of Tax Enforcement Results Violations](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350767824)
    - 1.5.3.4.6  [Non-Compliance with the Retention Standard](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350746624)
    - 1.5.3.4.7  [Integrated Talent Management (ITM) Self-Certification](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350722736)
      - 1.5.3.4.7.1  [ITM Self-Certification Checklist](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350719136)
      - 1.5.3.4.7.2  [Frequently Asked Questions for Quarterly Certifications](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350713360)
    - 1.5.3.4.8  [Quarterly Certification Memorandum of Record](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350684704)
  - 1.5.3.5  [HCO Independent Review Process](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350678176)
    - 1.5.3.5.1  [Independent Review Assistance](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350672336)
    - 1.5.3.5.2  [Manager and Employee Selection](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350666496)
    - 1.5.3.5.3  [Independent Review Methodology](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350661712)
    - 1.5.3.5.4  [Independent Review Procedures](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350657312)
    - 1.5.3.5.5  [Redacted Information/Need-to-Know](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350642656)
    - 1.5.3.5.6  [Independent Review Results](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350633568)
  - 1.5.3.6  [Annual Treasury Inspector General for Tax Administration Audit](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350629056)
  - 1.5.3.7  [Records Retention](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350617760)
  - 1.5.3.8  [Mandatory Section 1204 Training](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350613664)
  - 1.5.3.9  [HR Connect Indicator](https://www.irs.gov/irm/part1/irm_01-005-003#idm140426350606192)

# Part 1. Organization, Finance, and Management

# Chapter 5. Managing Statistics in a Balanced Measurement System

# Section 3. Managers Self-Certification and the Independent Review Process

* * *

## 1.5.3 Manager’s Self-Certification and the Independent Review Process

#### Manual Transmittal

October 17, 2022

#### Purpose

(1) This transmits revised IRM 1.5.3, Managing Statistics in a Balanced Measurement System, Manager’s Self-Certification and Independent Review Process.

#### Material Changes

(1) Section 1204 program ownership is updated to reflect the Human Capital Office.

(2) This revision includes process updates for the Quarterly Certification using Integrated Talent Management, the Independent Review and minor editorial changes throughout:

1. IRM 1.5.3.1.4, Program Management and Review is new.

2. IRM 1.5.3.4, Section 1204 Quarterly Certification Requirements eliminates the use of Section 1204 forms (M, MV, N, NV, O, OV, T, and TV) and provides updates for the Quarterly Certification using Integrated Talent Management.

3. IRM 1.5.3.5, HCO Independent Review Process reflects HCO program ownership, eliminates the Independent Review team, virtual reviews, manager and EPF checklists and related changes.


#### Effect on Other Documents

IRM 1.5.3, Manager’s Self-Certification and the Independent Review dated May 19, 2017, is superseded.

#### Audience

IRS Section 1204 Executives, Managers, and Employees

#### Effective Date

(10-17-2022)

Kevin Q. McIver

IRS Human Capital Officer

**1.5.3.1** **(10-17-2022)**

### Program Scope and Objectives

1. Purpose: This IRM provides guidance and instructions for Section 1204 Manager’s Self-Certification and the Human Capital Office (HCO) Independent Review process designed to support IRS’ compliance with the Reform and Restructuring Act of 1998 (RRA ‘98):



1. Section 1204(a) prohibits the IRS from using any Records of Tax Enforcement Results (ROTERs) to evaluate employees or to impose or suggest production quotas or goals.

2. Section 1204(b) requires that employees be evaluated using the fair and equitable treatment of taxpayers as a performance standard.

3. Section 1204(c) requires each appropriate supervisor to self-certify quarterly whether ROTERs were used in a prohibited manner.


2. Audience: The IRS business units subject to RRA ‘98 which includes these organizations:



1. The Independent Office of Appeals (Appeals)

2. Criminal Investigation (CI)

3. Large Business and International (LB&I)

4. Small Business and Self-Employed SB/SE)

5. Taxpayer Advocate Service (TAS)

6. Tax Exempt and Government Entities (TE/GE)

7. Wage and Investment (W&I)


.



3. Policy Owner: The HCO administers the Section 1204 program and monitors IRS compliance with RRA 98 through:



1. Section 1204 Manager’s Quarterly Self-Certification Reporting.

2. Annual HCO Independent Reviews.

3. Coordination with the Treasury Inspector General for Tax Administration (TIGTA) for the annual “Statutory Audit of Compliance with Legal Guidelines Restricting Use of Records of Tax Enforcement Results.”


4. Primary Stakeholders: This policy and procedures apply to the seven IRS business units that are subject to RRA ‘98 compliance.

5. Program Goals: The Section 1204 program is designed to identify and correct:



1. ROTER violations.

2. Instances of non-compliance with the retention standard for the fair and equitable treatment of taxpayers.

3. Certification process violations.


**1.5.3.1.1** **(10-17-2022)**

#### Background

1. The Section 1204 program is based on RRA ‘98, which requires the IRS to ensure that managers do not evaluate enforcement employees using ROTERs or base employee successes on meeting ROTER goals and quotas.

2. Section 1204 requires certain managers to complete quarterly self-certifications. It also requires the IRS to establish a retention standard for all employees that supports the "fair and equitable treatment of taxpayers."

3. Section 1204 provides guidance on the appropriate use of statistics by managers and employees throughout the IRS.


**1.5.3.1.2** **(10-17-2022)**

#### Authorities

1. [Internal Revenue Service Restructuring and Reform Act of 1998](http://www.gpo.gov/fdsys/pkg/PLAW-105publ206/html/PLAW-105publ206.htm)

2. Regulation 801 of 26 CFR

3. IRM 6.430.1,HCO's Performance Management


**1.5.3.1.3** **(10-17-2022)**

#### Responsibilities

1. The IRS Section 1204 program requires the cooperation and assistance of many IRS organizations.

2. **HCO** \- Provides overall program direction for the IRS Section 1204 program. Provides human capital strategies and tools for recruiting, hiring, developing, retaining, and training a highly-skilled and high-performing workforce to support IRS mission accomplishments.

3. **IRS business units** \- Implement the Section 1204 program in their respective areas, provides managers quarterly self-certification reporting, and assists the HCO in various program aspects, such as the HCO Independent Review. The IRS business units subject to RRA ‘98 Section 1204 include:



1. Appeals

2. CI

3. LB&I

4. SB/SE

5. TAS

6. TE/GE

7. W&I


4. **Statistics of Income (SOI)** \- Identifies selection criteria and managers for the HCO Independent Review.

5. **General Legal Services (GLS)** \- Reviews and confirms ROTERs identified in the TIGTA audit and HCO Independent Review. Also provides guidance in response to HCO questions concerning Section 1204 law.

6. **Treasury Inspector General for Tax Administration (TIGTA)** \- Completes the annual “Statutory Audit of Compliance with Legal Guidelines Restricting the Use of Records of Tax Enforcement Results.”


**1.5.3.1.4** **(10-17-2022)**

#### Program Management and Review

1. Section 1204 program information and current status is located on the IRS Source under Job Resources under Policies.

2. Section 1204 program component information, such as quarterly certification, is included on the HCO Section 1204 SharePoint site.


**1.5.3.1.5** **(10-17-2022)**

#### **Program Controls**

1. Access to Section 1204 program information on the HCO SharePoint site is protected by limiting access to the folder to those individuals that manage the program.


**1.5.3.1.6** **(10-17-2022)**

#### Terms/Definitions

01. **Appropriate Supervisor** \- The Section 1204 executive in a business unit that directly or indirectly supervises one or more Section 1204 employees. An appropriate supervisor can identify additional appropriate supervisors.

02. **Bargaining Unit (BU) employee** \- An employee covered by the 2022 National Agreement with the National Treasury Employees Union (NTEU).

03. **Employee Performance File (EPF)**\- A file maintained by the employee's immediate supervisor consisting only of performance-related documents covering the past four years.

04. **HR Connect** \- The IRS human resources system of record, owned and operated by the Department of the Treasury. Human resources practitioners, managers and employees use HR Connect to perform a wide array of transactions at various stages of an employee’s life cycle. Supervisors use HR Connect to manage human capital and better use organizational data for strategic decision making.

05. **HR Connect Indicator**\- The HR Connect indicator identifies Section 1204 managers and employees within the HR Connect system.

06. **Integrated Talent Management (ITM)** \- The IRS system of record for training which gives employees and managers a better opportunity to develop, support and promote career development which:



    1. Maintains employee learning and teaching histories.

    2. Launches online courses.

    3. Tracks completion of assigned curriculum and requirements.

    4. Offers development and delivery of course evaluations.

    5. Provides data reporting.


07. **Manager** \- Is a position that:



    1. Directs the work of an organization through subordinate supervisors.

    2. Is accountable for the success of specific line or staff functions.

    3. Monitors and evaluates the progress of the organization toward meeting goals.

    4. Makes adjustments in objectives, work plans, schedules, and resource commitments.

    5. Serves as head or assistant head of a major organization within a bureau.

    6. Directs a specialized program of marked difficulty, responsibility, and national significance.


08. **Non-Bargaining Unit (NBU) employee** \- An employee who is not covered by the 2022 National Agreement with the National Treasury Employees Union (NTEU).



    ### Example:



    Executives, managers and management officials

09. **Non-Section 1204 Employee** \- An employee who is not engaged in Section 1204 activity related to tax administration.

10. **Business Units** \- For the IRS, includes:



    1. Operating divisions such as LB&I, SB/SE, TE/GE, and W&I

    2. Functional offices such as TAS, Appeals, and CI


11. **Performance Plan** \- The document that communicates to the employee what performance is expected and how the employee is rated for the appraisal period. The performance plan includes:



    1. Retention standard for the fair and equitable treatment of taxpayers

    2. Critical job elements (CJEs) and performance aspects for BU and NBU employees

    3. Responsibilities and commitments for managers and management officials


12. **Records of Tax Enforcement Results (ROTERs)** \- Are data, statistics, and compilations of information or other numerical or quantitative recordations of the tax enforcement results reached in one or more cases. Examples of ROTERs include, but are not limited to:



    01. Number of liens filed.

    02. Number of levies served.

    03. Number of seizures executed.

    04. Number of fraud referrals.

    05. Dollars per hour.

    06. Dollars per return.

    07. Total dollars assessed/collected.

    08. Percentage of agreed cases.

    09. Number of "full paid" cases.

    10. Number of prosecutions recommended.

    11. Percentage of Taxpayer Advocate cases where relief was granted.

    12. Amount of revenue protected.

    13. No change rate.


13. **Retention Standard for the Fair and Equitable Treatment of Taxpayers****(Retention Standard)**\- An IRS employee performance standard based on Section 1204(b), which requires that employees be evaluated on the fair and equitable treatment provided to taxpayers and behaviors that meet or do not meet the standard.

14. **Section 1204 Employee**\- An employee or manager of an employee (all levels of management) who exercises judgment in recommending or determining whether or how the IRS should pursue enforcement of tax laws, or an employee whose duties involve providing direction and/or guidance for field programs involving Section 1204 work activities, including IRM guidance. The work activity performed, not the employee’s title, location, or business unit, identifies whether an employee should be considered a Section 1204 employee.



    ### Note:



    While many of the divisions in the Services and Enforcement organization are subject to Section 1204, there are offices that are not subject to Section 1204, such as the Whistleblower’s Office.

15. **Section 1204 Indicator** \- The identifier used within the HR Connect system to differentiate Section 1204 managers and employees from all other IRS managers and employees. The indicator is used to determine the Section 1204 population at a given point in time.



    ### Note:



    In HR Connect, the label “Section 1204 designation” is referred throughout this IRM as “Section 1204 indicator”.

16. **Section 1204 Organizational Unit** \- A unit or office within a business unit that includes at least one employee who conducts Section 1204 activities.

17. **Section 1204 Manager** \- A manager/supervisor at any level who supervises one or more Section 1204 employees.

18. **Section 1204 Program Manager** \- Administers the Section 1204 program in his/her organization.

19. **Supervisor** \- An employee that accomplishes work through the direction of other employees, exercising both technical and administrative supervision over subordinates.



    ### Note:



    Also see the definition of Manager at _IRM 1.5.3.1.6 (7), Definitions, Manager’s Self-Certification and the Independent Review Process._

20. **Tax Enforcement Result (TER)** \- The outcome produced by an employee’s exercise of judgment in recommending or determining whether or how the IRS should pursue enforcement of the tax laws. A TER includes but is not limited to:



    01. Lien filed.

    02. Levy served.

    03. Seizure executed.

    04. Amount - tax or penalties assessed.

    05. Amount - tax or penalties collected.

    06. Fraud referral.

    07. Revenue protected.

    08. Type of case closure (agreed, no change, full paid, abatement).

    09. Prosecution recommended (indictment/conviction).

    10. Type of relief provided.


**1.5.3.1.7** **(10-17-2022)**

#### Acronyms

1. The following table lists acronyms and their descriptions used in this IRM:




| **ACRONYMS**<br> This is a two column table of acronyms used in the IRM. The first column lists the acronym. The second column lists the description. |
| :-: |
| **Acronym** | **Description** |
| :-: | :-: |
| Appeals | Independent Office of Appeals |
| BU | Bargaining Unit |
| CI | Criminal Investigation |
| CJEs | Critical Job Elements |
| EPF | Employee Performance File |
| FETT | Fair and Equitable Treatment of Taxpayers (Retention Standard) |
| GLS | General Legal Services |
| IDR(s) | Individual Document Request(s) |
| HCO | Human Capital Office |
| IRM | Internal Revenue Manual |
| ITM | Integrated Talent Management |
| LB&I | Large Business and International |
| NBU | Non-Bargaining Unit |
| NTEU | National Treasury Employees Union |
| RAAS | Research, Applied Analytics and Statistics |
| ROTER(s) | Records of Tax Enforcement Result(s) |
| RRA ‘98 | Restructuring and Reform Act of 1998 |
| SB/SE | Small Business/Self Employed |
| SES | Senior Executive Service |
| SOI | Statistics of Income |
| TAS | Taxpayer Advocate Service |
| TE/GE | Tax Exempt and Government Entities |
| TER(s) | Tax Enforcement Result(s) |
| TIGTA | Treasury Inspector General for Tax Administration |
| W&I | Wage and Investment |


**1.5.3.2** **(05-19-2017)**

### Section 1204 Program Responsibilities

1. The IRS Section 1204 program requires the cooperation and assistance of many IRS organizations.


**1.5.3.2.1** **(10-17-2022)**

#### Human Capital Office Program Roles and Responsibilities

1. The HCO has overall administrative responsibility for assisting the IRS in meeting the Section 1204 requirements.

2. **HCO Program Oversight** functions include:



1. Developing the Section 1204 project timeline and program plan.



      ### Note:



      The plan identifies yearly tasks, new projects, due dates, and points of contact to conduct the HCO Independent Review; coordinates quarterly certification reporting; and determines whether there is a need to develop or update policy.

2. Updating IRM guidance on Section 1204 instructions.

3. Developing ITM training for Section 1204 managers and employees. See _IRM 1.5.3.8, Mandatory Section 1204 Training_.

4. Providing program manager training materials on Section 1204 quarterly certification and Independent Review topics.

5. Maintaining a Section 1204 SharePoint site with references for training, quarterly certification memoranda, Independent Review memoranda, new program policy, frequently asked questions, and program updates.

6. Collaborating with other business units to identify best practices and program improvements.


3. **HCO Independent Review** functions may include:



1. Leading the Independent Review process and establishing an annual review plan to monitor compliance with the Section 1204 certification reporting.

2. Collaborating with SOI to prepare the sampling methodology and scope to select the annual HCO Independent Review managers.

3. Preparing the annual Engagement Memorandum to all Section 1204 business units to notify and solicit program manager assistance with the Independent Review.

4. Handling the Independent Review components.

5. Conducting the Independent Reviews and documenting the results by business unit, which is forwarded to Section 1204 program managers.

6. Obtaining GLS concurrence and validation of potential ROTERs.

7. Notifying the business unit, reporting the number of Section 1204(a) ROTER violations, Section 1204(b) instances of non-compliance with the fair and equitable treatment of taxpayers retention standard and Section 1204(c) findings of incorrect or missing quarterly certifications identified during the Independent Review.

8. Documenting review results in a Memorandum of Record.


4. **HCO Quarterly Self-Certification** functions include:



1. Maintaining the list of Section 1204 organizational contacts including the Section 1204 program managers and appropriate supervisors.

2. Developing the managers' quarterly self-certification schedule.

3. Preparing and issuing quarterly reporting instructions, as needed.

4. Preparing quarterly HCO memoranda of record summarizing results, reasons, and actions based on business unit submissions.



      ### Note:



      The quarterly memoranda of record are submitted for internal review and routing no later than 15 days after the quarterly certification due dates posted on the IRS Source, Policies, Section 1204 site.


5. **The Section 1204 Program Managers Workgroup**:



1. Provides a more corporate approach to address program challenges.

2. Provides consistent communications across the IRS.

3. Enhances problem-solving among all stakeholders (the HCO and the business units).

4. Identifies issues with corporate-wide impact.

5. Develops draft recommendations for appropriate SES consideration and approval.

6. Assists with the development of corporate communications.


6. **HCO TIGTA Audit Liaison**functions include:



1. Coordinating with Section 1204 business units to respond to the annual TIGTA “Statutory Audit of Compliance with Legal Guidelines Restricting the Use of Records of Tax Enforcement Results” document requests.

2. Scheduling the opening and closing conferences.

3. Obtaining GLS concurrence for potential Section 1204(a) ROTER violations identified during the TIGTA audit.

4. Addressing audit findings and recommendations with Section 1204 program managers and the respective business units.

5. Preparing the HCO response memorandum to TIGTA findings and recommendations based on input from the business units.

6. Providing final audit reports to the Section 1204 program managers.


7. **HCO Office of HR Strategy** functions include developing and updating annual mandatory Section 1204 training content, including test-out questions.


**1.5.3.2.2** **(05-19-2017)**

#### Section 1204 Business Unit Program Roles and Responsibilities

1. The **highest level appropriate supervisor**in the business unit is responsible for implementing the Section 1204 program including:



1. Identifying a Section 1204 program manager and/or functional coordinators for their organization.

2. Advising all executives and managers of Section 1204 requirements.

3. Interpreting Section 1204 policy and providing general technical guidance and direction to Section 1204 executives and managers.

4. Providing input to the HCO on needed updates to IRM guidance on Section 1204.

5. Developing and presenting Section 1204 training for their organizations.

6. Coordinating managers' quarterly self-certifications and reporting activities.

7. Providing technical advice to Section 1204 managers for the quarterly certification reporting.

8. Participating in the HCO Section 1204 workgroup.

9. Supporting the annual TIGTA audit through direct contact with managers to fulfill requests for documents and responses to various inquiries.


2. **Section 1204 program managers** administer the Section 1204 program in their organization and:



01. Represent the seven IRS business units subject to the Section 1204 Program including: Appeals, CI, LB&I, SB/SE, TAS, TE/GE, and W&I.

02. Identify functional Section 1204 coordinators if not identified by the appropriate supervisors.

03. Serve as the primary contact from the business units to the HCO staff on Section 1204 issues.

04. Provide Section 1204 guidance and direction to their business unit and to their Section 1204 coordinators.

05. Provide their business unit with Section 1204 updates such as oversight reviews, organizational IRM revisions, training updates, managers' self-certification activity, and the annual Independent Review.

06. Inform the HCO when there is a change in Section 1204 program manager or appropriate supervisors as needed.

07. Provide guidance to Section 1204 coordinators in researching technical questions and resolving organizational Section 1204 issues.

08. Support the annual Independent Review process by participating in reviews, answering selected manager questions, and addressing findings.

09. Direct questions with IRS-wide impact or legal implications to the HCO organization, for guidance.

10. Maintain a list of Section 1204 coordinators for their organization.

11. Provide assistance for Section 1204 managers' quarterly certification, including reminding managers to verify that the Section 1204 HR Connect indicator has been reviewed and updated, as needed.

12. Provide assistance for the annual TIGTA audit by working with Section 1204 coordinators to provide requested documents, reports, responses to questions and to assist with the interview scheduling as needed.


3. **Section 1204 coordinators** serve as liaisons to their organization's Section 1204 program manager and provide guidance and direction to their immediate offices. There is at least one coordinator for each business unit. There may be more coordinators depending on the size, complexity, and variety of operations in each area. Section 1204 coordinators:



1. Support Section 1204 managers at all levels with managers' quarterly self-certification and reporting activity.

2. Provide Section 1204 managers with appropriate guidance and direction.

3. Schedule Section 1204 training and briefings, as appropriate.

4. Support the annual Independent Review process.

5. Validate the classification of managers and employees as either Section 1204 or non-Section 1204 within HR Connect.

6. Support the annual TIGTA audit through direct contact with managers to fulfill requests for documents and responses to various inquiries.


**1.5.3.2.3** **(05-19-2017)**

#### Statistics of Income, General Legal Services, and the Human Capital Office Roles and Responsibilities

1. **Statistics of Income (SOI), Research, Applied Analytics and Statistics (RAAS)** assists in the annual HCO Independent Review by:



1. Selecting the annual statistically valid sample for the review.

2. Developing and maintaining procedures for selecting samples of managers.

3. Working with the HCO to gather all information necessary to implement the sample selection procedures.

4. Selecting a sample of managers to be included in the review.

5. Assisting the HCO with the proper interpretation of results.


2. **General Legal Services (GLS)**assists the HCO with the Section 1204 program by:



1. Confirming ROTERs identified during the HCO Independent Review.

2. Providing opinions on technical questions regarding the Section 1204 program.

3. Confirming ROTER findings from TIGTA audits.



      ### Note:



      The HCO is responsible for verifying potential Section 1204 violations and ROTERs discovered during the Independent Review and TIGTA’s annual audit. All identified ROTERs are forwarded to GLS along with the copies of the violations for review and comment. GLS determines whether or not ROTER violations occurred and provides comments or a determination document to the HCO which supports its conclusion. The HCO shares confirmed ROTER violations with the affected business unit’s program manager. See _IRM 1.5.3.4.4_, Identifying and Addressing ROTER Violations.


3. **Human Capital Office (HCO)** Section 1204 management responsibilities include:



1. Establishing and managing the IRS performance management program and identifying HR Connect enhancements and improvements, as needed.

2. Developing and implementing performance management policy within the parameters and policies of the Department of the Treasury Performance Management System.

3. Aligning the procedures with the Section 1204 program with the procedures in the IRM 6.430 series, Performance Management.

4. Launching Section 1204 annual mandatory training.

5. Updating newly hired managers' and employees' ITM learning plans with Section 1204 mandatory training, as appropriate.


**1.5.3.3** **(10-17-2022)**

### Retention Standard for the Fair and Equitable Treatment of Taxpayers

1. The IRS retention standard for the fair and equitable treatment of taxpayers is based on RRA 98 Section 1204(b) - The IRS shall use fair and equitable treatment of taxpayers as one of the standards for evaluating employee performance.

2. 26 CFR 801.3, Measuring Employee Performance, states:




| **REGULATION §801.3 - MEASURING EMPLOYEE PERFORMANCE**<br> This two-column table provides information on measuring employee performance as written in Regulation §801.3. The first column lists the paragraph heading and the second column provides the corresponding details in the paragraph. |
| :-: |
| **In general** | All employees of the IRS will be evaluated according to the critical elements and standards, or such other performance criteria as may be established for their positions. In accordance with the requirements of 5 USC 4312, 4313, and 9508, and Section 1201 of the Act, the performance criteria for each position, as are appropriate to that position, will be composed of elements that support the organizational measures of Customer Satisfaction, Employee Satisfaction, and Business Results; however, such organizational measures will not directly determine the evaluation of individual employees. |
| **Fair and equitable treatment of taxpayers** | In addition to all other criteria required to be used in the evaluation of employee performance, all employees of the IRS will be evaluated on whether they provided fair and equitable treatment to taxpayers. |
| **Senior Executive Service and special positions** | Employees in the Senior Executive Service will be rated in accordance with the requirements of 5 USC 4312 and 4313, and employees selected to fill positions under 5 USC 9503 will be evaluated pursuant to work plans, employment agreements, performance agreements, or similar documents entered into between the IRS and the employee. |
| **General workforce** | The performance evaluation system for all other employees will:<br> <br>1. Establish one or more retention standards for each employee related to the work of the employee and expressed in terms of individual performance<br>      <br>2. Require periodic determinations of whether each employee meets, or does not meet, the established retention standards<br>      <br>3. Require that action be taken in accordance with applicable laws and regulations, with respect to an employee whose performance does not meet the established retention standards<br>      <br>4. Establish goals or objectives for individual performance consistent with the IRS performance planning procedures<br>      <br>5. Use such goals and objectives to make performance distinctions among employees or groups of employees<br>      <br>6. Use performance assessments as a basis for granting employee awards, adjusting an employee’s rate of basic pay, and other appropriate personnel actions, in accordance with applicable laws and regulations |
| **Limitations** | 1. No employee of the IRS may use records of tax enforcement results (as defined in §801.6) to evaluate any other employee or to impose or suggest production quotas or goals for any employee. (i) For purposes of the limitation contained in this paragraph (e), the term employee has the meaning as defined in 5 USC 2105(a). (ii) For purposes of the limitation contained in this paragraph (e), evaluate includes any process used to appraise or measure an employee’s performance for purposes of providing the following: (A) Any required or requested performance rating. (B) A recommendation for an award covered by Chapter 45 of title 5; 5 USC 5384; or Section 1201(a) of the Act. (C) An assessment of an employee’s qualifications for promotion, reassignment or other change in duties. (D) An assessment of an employee’s eligibility for incentives, allowances or bonuses. (E) Ranking of employees for release/recall and reductions in force.<br>      <br>2. Employees who are responsible for exercising judgment with respect to tax enforcement results in cases concerning one or more taxpayers may be evaluated on work done on such cases only in the context of their critical elements and standards.<br>      <br>3. Performance measures based in whole or in part on quantity measures will not be used to evaluate the performance of any non-supervisory employee who is responsible for exercising judgment with respect to tax enforcement results (as defined in §801.6). TD 9227, 70 FR 60215, Oct. 17, 2005. Redesignated and amended by TD 9426, 73 FR 60628, Oct. 14, 2008. |

3. The retention standard for the fair and equitable treatment of taxpayers appears in all IRS employees’ performance plans including:



1. BU

2. NBU

3. Management Official

4. Manager

5. Executive (SES)


4. At the beginning of the performance period, employees acknowledge the receipt of the fair and equitable treatment of taxpayers retention standard by signing one of the appropriate documents:



1. Form 6774 - Receipt of Critical Job Elements and Fair and Equitable Treatment of Taxpayers Retention Standard

2. SES Performance Management System - Executive Performance Agreement

3. Form 12450-A - Manager Performance Agreement

4. Form 12450-B - Management Official Performance Agreement

5. Form 12450-D - Management/Program Analyst Performance Agreement


5. Employees must acknowledge receipt of their retention standard each year even if their performance standards have not changed from the prior year.



### Note:



While not specifically a Section 1204 program requirement, according to IRM 6.430, _Performance Management_, acknowledgement and the receipt of the retention standard must occur within 30 days from the beginning of the rating period.

6. The manager files the signed retention standard acknowledgement in the EPF. In some cases, employee acknowledgement of the retention standard as a performance standard is documented in HR Connect or ITM, however, the EPF is the official record.

7. At the end of the performance period, the manager rates the employee's retention standard performance as:



1. "Met"

2. "Not Met"

3. "Not Applicable"


8. The employee signs the retention standard performance rating and the manager files the appropriate form in the EPF. Employee acknowledgement of the retention standard rating is documented on the employee's appraisal/performance agreement in HR Connect; however, the EPF is the official record. Appraisal/performance agreement forms used to document an employees' retention standard rating include:



1. Form 6850-BU - Bargaining Unit Performance Appraisal and Recognition Request (HR Connect)

2. Form 6850-NBU - Non-Bargaining Unit Performance Appraisal (HR Connect)

3. Form 12450-A - Manager Performance Agreement (HR Connect)

4. Form 12450-B - Management Official Performance Agreement (HR Connect)

5. Form 12450-D - Management/Program Analyst Performance Agreement (HR Connect)

6. SES Performance Management System - Executive Performance Agreement


9. Both the acknowledgement of receipt and the performance rating of the retention standard are filed in the EPF and retained for four years.


**1.5.3.3.1** **(10-17-2022)**

#### National Treasury Employees Union Requirements Related to Section 1204

1. Successive memoranda of understanding between the IRS (Employer) and the National Treasury Employees Union (NTEU) establish a set of ratings to measure the employee’s performance against the retention standard.

2. The 2022 National Agreement, Article 12, Performance Appraisal System, Section 2 provides definitions of the performance appraisal system. See Document 11678.

3. The 2022 National Agreement Article 12, Section 4, Performance Appraisals, states that ratings of record will be prepared within thirty (30) days of the end of the month in which the appraisal is due.

4. The 2022 National Agreement, Article 12, Section 8, Use of Statistics, states that the:



1. Use of statistics by the employer for the purpose of rating critical job elements will be in accordance with 26 CFR Part 801.

2. Employer has determined that it will not use records of tax enforcement results to evaluate employees or to impose or suggest production quotas or goals on employees. Rather, employees will be evaluated according to their CJEs and standards or such other performance criteria as may be established for their positions. Employees who are responsible for exercising judgment with respect to tax enforcement results in cases concerning one or more taxpayers may be evaluated on work done on such cases only in the context of their CJEs and standards.

3. Employer has determined that performance measures based in whole or in part on quantity measures will not be used to evaluate the performance of any employee who is responsible for exercising judgment with respect to tax enforcement results.


**1.5.3.3.2** **(02-05-2015)**

#### Manager Discussions

1. The retention standard is used to make certain that all employees make a good faith effort in the fair and equitable treatment of taxpayers. The manager must coach an employee on how to prevent an occurrence of unacceptable customer treatment and the importance of adhering to the fair and equitable treatment of taxpayers retention standard. Infrequent lapses that are inadvertent or unavoidable acts should not result in a "Not Met" rating.

2. An employee's receipt and acknowledgement of the fair and equitable treatment of taxpayers retention standard means that the manager has discussed the retention standard, including identifying:



1. Behaviors that allow the employee to meet the retention standard.

2. Circumstances that may result in a determination that the employee does not meet the retention standard.

3. Potential impact of not meeting the retention standard.


**1.5.3.3.3** **(11-23-2010)**

#### Retention Standard Behaviors

1. Examples of employee behaviors that **meet** the retention standard include:



1. Responds to taxpayers in a timely manner.

2. Discusses specific taxpayer cases with other employees on a "need-to-know" basis only.

3. Responds verbally or in writing with appropriate tone, courtesy and respect, and states facts accurately.

4. Advises customers of full personal impact, such as interest and penalty accumulation, when the taxpayer advises they cannot pay their liability in full.


2. Examples of employee behaviors that **fail to meet**the retention standard include:



1. Fails to respond in a timely manner to taxpayers.

2. Discusses specific taxpayer information with others who do not have an official "need to know."

3. Responds verbally or in writing with a tone or wording which is discriminatory, discourteous, disrespectful, intimidating, and/or which misstates facts.


3. Managers should develop additional examples specific to the roles and responsibilities of employees they supervise.

4. The employee retention standard behaviors are monitored by reviewing case files, Integrated Data Retrieval System (IDRS) actions, telephone calls, and/or feedback received from taxpayers and other outside sources.


**1.5.3.3.4** **(05-19-2017)**

#### Retention Standard Documentation

1. Managers must prepare a narrative justification for retention standard ratings of "Not Met."

2. Managers do not prepare a narrative justification for retention standard ratings of "Met" or "Not Applicable."

3. The retention standard is incorporated into the following annual employee performance plans:




| **EMPLOYEE RECEIPT and ACKNOWLEDGEMENT**<br> This two-column table presents receipt and acknowledgement of the Retention Standard. The first column lists the retention standard documentation and the second column lists the actions. |
| :-: |
| **Retention Standard Documentation** | **Actions** |
| :-: | :-: |
| Form 6774, _Receipt of Critical Job Elements and Fair and Equitable Treatment of Taxpayers Retention Standard_ | Employee's and supervisor's signatures and dates signed on Form 6774 indicate employee receipt and acknowledgement of the retention standard, which is filed in the EPF. |
| Form 12450-A, _Manager Performance Agreement_ | Signatures and dates of employee, rating official, and reviewing official in Part 1, Critical Performance Expectations, indicate employee receipt and acknowledgement of the retention standard, which is filed in the EPF. |
| Form 12450-B, _Management Official Performance Agreement_ |
| Form 12450-D, _Management/Program Analyst Performance Agreement_ |
| SES Performance Management System - Executive Performance Agreement | Signatures and dates of employee, rating official, and reviewing official in Part 1, Consultation, indicate employee receipt and acknowledgement of the retention standard, which is filed in the EPF. |

4. The retention standard is ****applicable**** to Section 1204 employees who interact with taxpayers or who set policy regarding interactions with taxpayers. The retention standard must be checked and signed on the employee's annual appraisal, which is filed in the EPF.




| **COMPLETING RETENTION STANDARD RATINGS ON PERFORMANCE APPRAISAL FORMS**<br> This two-column table lists performance forms used for the retention standard. The first column lists the forms and the second column the corresponding actions. |
| :-: |
| **Appraisal Form** | **Actions** |
| Form 6850-BU, _Bargaining Unit Performance Appraisal and Recognition Request_ | The rater checks the retention standard rating - "Not Applicable," "Met," or "Not Met." The rater, reviewing official, and employee sign and date the appraisal. |
| Form 6850-NBU, _Non-Bargaining Unit Performance Appraisal_ | The rater checks the retention standard rating - "Not Applicable," "Met," or "Not Met." The rating official, reviewing official, and employee sign and date the appraisal. |
| Form 12450-A, _Manager Performance Agreement_ | The rating official checks Part III, Retention Standard rating - "Not Applicable," "Met," or "Not Met." The rating official, reviewing official, and employee sign and date the appraisal. |
| Form 12450-B, _Management Official Performance Agreement_ |
| Form 12450-D, _Management/Program Analyst Performance Agreement_ |
| _SES Performance Management System - Executive Performance Agreement_ | The rating official checks Part VIII, Additional Mandated Element(s), "Met," or "Not Met." The rating official, reviewing official, and employee sign and date the appraisal. |

5. At the end of the performance period, if the retention standard is not applicable, mark the "Not Applicable" box. A non-Section 1204 employee is rated "Not Applicable" for the retention standard.

6. During the Independent Review, the review team verifies that managers have retained signed and dated copies of the retention standard:



1. Receipt and acknowledgement.

2. Performance rating.



      ### Note:



      If there is an electronic or digital signature that contains a date, that date constitutes the date on the form for Section 1204 purposes.


**1.5.3.3.5** **(10-17-2022)**

#### Retention Standard Non-Compliance

1. Managerial Section 1204(b) retention standard non-compliance occurs if/when:



1. The documentation (either acknowledgement or rating) is not in the EPF and/or does not exist for the fiscal year of review



      ### Note:



      The current year's Independent Review looks at the Form 6774 acknowledgement documentation. If the Form 6774, Receipt of Critical Job Elements and Fair and Equitable Treatment of Taxpayers Retention Standard is missing or does not exist for a selected employee, a Section 1204(b) instance of non-compliance is noted for the manager.

2. The documentation does not contain all appropriate signatures and dates.

3. The retention standard rating is unchecked in the annual performance document (annual rating of record).


2. Retention standard non-compliance is counted for the manager when the conditions listed in the paragraph above occur. The manager must identify and correct non-compliance during the quarterly certification process review.



### Note:



Section 1204(b) noncompliance is not reported during the (Integrated Talent Management (ITM) quarterly certification process.





### Note:



Section 1204 (b) instances of non-compliance must be identified and corrected upon discovery.

3. Managerial Section 1204(b) retention standard non-compliance occurs when the following documents do not exist or are missing the appropriate information as described.



1. Form 6774, Receipt of Critical Job Elements and Fair and Equitable Treatment of Taxpayers Retention Standard

2. Form 6850-BU, Bargaining Unit Performance Appraisal and Recognition Request

3. Form 6850-NBU, Non-Bargaining Unit Performance Appraisal

4. Form 12450-A, Manager Performance Agreement

5. Form 12450-B, Management Official Performance Agreement

6. Form 12450-D, Management/Program Analyst Performance Agreement

7. SES Performance Management System - Executive Performance Agreement


### Note:

One goal of performance management is to obtain timely acknowledgement and rating of performance elements, standards, responsibilities and commitments. There are circumstances such as family medical leave, military service, etc., in which acknowledgement (beginning of the performance period) and ratings (end of the performance period) cannot be obtained. In these cases, managers must document the mitigating circumstances and obtain acknowledgement or provide ratings as soon as practical. The managerial self-certification process requires a quarterly review of EPFs including a review of employee acknowledgement and ratings. See _IRM 1.5.3.4.7.1_, _Self-Certification Checklist_.

### Note:

Another goal of performance management is to ensure an official performance document exists. Per 6.430.2.2.4.3 (10-05-2017), Finalizing the CJE Performance Plan, Proxy signatures are not permitted on official performance documentation. Therefore, when a Reviewing Official or Rating Official signs the performance document as a proxy in HRConnect, the permanent manager of record should print the performance document, obtain manual signatures for the proxies and place the hard copy in the EPF.

**1.5.3.4** **(10-17-2022)**

### Section 1204 Quarterly Certification Requirements

01. Section 1204(a) prohibits the use of ROTERs to evaluate employees or to impose or suggest production quotas for those employees.

02. Section 1204(c) requires each appropriate supervisor to certify quarterly whether or not tax enforcement results were used in a manner prohibited by Section 1204(a).

03. The HCO develops and issues certification guidance to Section 1204 program managers and updates the quarterly certification process as necessary. The quarterly certification is completed through the ITM system.

04. Managers assess their compliance with Section 1204 requirements during their quarterly certification reviews.

05. The Section 1204 managers required to complete the quarterly certification include:



    1. Heads of business units

    2. Appropriate supervisors

    3. Next level managers, those between the front-line manager and appropriate supervisor

    4. Front line managers

    5. Acting managers

    6. Acting supervisors


06. The IRS business units required to submit managers' quarterly self-certifications include:



    1. Appeals

    2. CI

    3. LB&I

    4. SB/SE

    5. TAS

    6. TE/GE

    7. W&I


07. For the quarterly certification process, the above listed IRS business units determine whether:



    1. Section 1204 activities are performed in their organization.

    2. Section 1204 activity guidance or direction is required and has been provided.


08. Organizations involved in Section 1204 activities or in providing guidance and direction for these activities follow the required quarterly Section 1204 certification process and identify/update Section 1204 appropriate supervisors.

09. The business units are responsible for Section 1204 program implementation in their respective areas. Section 1204 program managers and coordinators in each Section 1204 business organization are available to provide guidance to managers regarding Section 1204 issues, including the certification process.

10. Organizations that are not involved with Section 1204 activities (non-Section 1204 organizations) maintain an awareness of Section 1204 requirements through the retention standard and compliance with Section 1204(b); however, non-Section 1204 organizations do not submit quarterly certifications or participate in the HCO Independent Review. The retention standard appears on all performance documents and is acknowledged at the beginning of the performance period. At the end of the performance period, non-Section 1204 managers and employees are rated as "Not Applicable."

11. During the first quarter of each fiscal year, quarterly throughout the year, as part of the certification process, and when staffing changes occur, business units designated as Section 1204 re-evaluate the status of their organization to:



    1. Identify the subordinate organizations where Section 1204 activity takes place.

    2. Review HR Connect and verify that Section 1204 managers and employees are identified with the Section 1204 indicator.



       ### Note:



       Validation of the Section 1204 indicator is necessary to identify the Section 1204 population of managers and employees for required training, the annual TIGTA audit, the Independent Review, NTEU notifications, and HCO activities, as necessary.


12. Beginning with first-line Section 1204 managers, all levels of management (including appropriate supervisors) must conduct a quarterly review to determine whether they:



    1. Used ROTERs to evaluate employees or to impose or suggest production quotas or goals.

    2. Evaluated all employees using the fair and equitable treatment of taxpayers as a performance standard.


13. **Section 1204 managers** must complete the self-certification to summarize their findings.

14. The ITM quarterly certification process assigns the certification to managers with the HR Connect indicator or may be selected through the ITM training catalog.


**1.5.3.4.1** **(10-17-2022)**

#### Due Dates

1. The Section 1204 quarterly self-certifications are based on the fiscal year. Quarterly submissions are due to the HCO from the business units 45 calendar days after the end of each quarter. Reporting quarters are:



1. 1st Quarter: Reporting for October, November, and December.

2. 2nd Quarter: Reporting for January, February, and March.

3. 3rd Quarter: Reporting for April, May, and June.

4. 4th Quarter: Reporting for July, August, and September.


2. When the 45th calendar day falls on a weekend, either a Friday or Monday due date is determined. Unusual weather or other events may also change established due dates. HCO develops the annual reporting schedule and sends quarterly reminders and Leader’s Alerts for specific due dates.


**1.5.3.4.2** **(10-17-2022)**

#### Acting Managers

1. Acting supervisors and managers may self-certify in their acting roles.

2. During the quarter, one or more employees may serve as acting managers for a group or organization. Each acting manager should discuss with the permanent manager, the activities completed during the assignment period to determine if 1204 certification is warranted for the acting manager. See Exhibit 1.5.3-2.

3. Some activities that may require quarterly certification include but are not limited to, preparing a performance document, providing case feedback or reviewing enforcement actions for approval.

4. Some activities that may not require quarterly certifications may include but are not limited to, attending a meeting, approving SETR, Form 5081 or leave requests, consolidating monthly reports, etc.



### Note:



When a manager completes any Section 1204 activities they are required to complete a quarterly certification.

5. More than one acting manager maybe required to complete the quarterly certification for the same group, since the certification is based on individual accountability.

6. Acting managers should access ITM, search by catalog # or certification title (i.e. Section 1204 Quarterly Certification 2Q) and complete the certification for the appropriate quarter. See Exhibit 1.5.3-3.

7. Section 1204 proxies are delegations of responsibility for the certification process.



### Note:



Proxies for a manager’s Section 1204 self-certification are not permitted given that self-certification requires personal knowledge of the identified and reported violations.


**1.5.3.4.3** **(10-17-2022)**

#### Manager's Quarterly Certification Review Components

1. Managers should review all documents in the EPFs of newly assigned employees (includes transferees within the IRS, new hires, and probationary employees).



### Note:



Past Independent Reviews have shown that employees' EPFs were a significant source of Section 1204(a) violations. Any Section 1204 violation identified during the self-review, Independent Review or the TIGTA audit should be reported in the quarterly certification.

2. New managers and managers moving to a new group should review EPFs for all employees.



### Note:



The manager must immediately correct the violation and this information must be reported on the next quarterly certification.

3. During the quarterly self-certification review, managers review a variety of documents, such as meeting minutes, employee files, program reviews, and case reviews.

4. All Section 1204 managers, including appropriate supervisors, review their management activities for the entire quarter and complete a self-certification for the quarter. The self-certification identifies whether managers used ROTERs in a manner prohibited by Section 1204(a).



### Note:



Although the 1204 managers are no longer required to certify to Section 1204(b), they are still required to evaluate employees using the fair and equitable treatment of taxpayers, following the guidance of IRM 6.430. 2 Performance Management Program for Evaluating Bargaining Unit and Non-Bargaining Unit Employees Assigned to Critical Job Elements (CJEs).

5. Quarterly reviews cover 100 percent of a Section 1204 manager’s verbal and written communications in:



1. Employee evaluations as defined in Regulation §801.3(e)(1)(ii).

2. Other documented input, such as workload reviews and individual case reviews.

3. Verbal communications, such as meetings and employee discussions.

4. Written documents, such as program guidance, business/program reviews, and meeting minutes.


6. The following items should be included in the manager's self-certification review:



01. EPFs - contain employee performance information.

02. Employee evaluations - contain employee ratings and performance feedback.

03. Employee Section 1204 status in HR Connect.

04. Employee Section 1204 mandatory training status, especially for new hires who may have missed the ITM annual training cycle.

05. Retention Standard - completed form and briefed employee to include retention standard behavior discussion, especially for employees with rating periods beginning during the quarter.

06. Operational reviews, business reviews, and visitation reports - contain information on operational strengths and weaknesses to facilitate discussion and feedback between the manager and the employee. These reviews include internal controls, best practices, and identify areas for improvement with corrective and follow-up actions.

07. Employee Drop Files (EDF) - contain employee conduct and other documentation not related to performance.

08. Grievances and hearing narratives.

09. Comments/reports offered by the NTEU.

10. Group discussions.

11. Meeting minutes - contains group, branch, territory, area, division, or director meetings.

12. Local guidance memoranda.

13. Other items, such as filed copies of email and voice mail messages.


7. Employee performance files, evaluations, and other documented reviews include the following:



01. Performance agreements.

02. Retention Standard for the Fair and Equitable Treatment of Taxpayers.

03. Performance appraisals - (managers must check the retention standard rating and managers/employees must sign and date the appraisal).

04. Self-Assessments.

05. Recognition/award recommendations.

06. Midyear reviews/assessments.

07. Narrative feedback to evaluations.

08. Time sheet reviews.

09. Workload reviews.

10. Individual case reviews.

11. Operational reviews/business reviews (managers’ EPFs).

12. Assessments for promotion/reassignment, incentives/allowances/bonuses, release/recall, and reductions in force.


8. Managers review the EPFs for the retention standard to verify that:



1. Employees received and acknowledged the retention standard at the beginning of the performance rating period.

2. The rater assigned a retention standard rating.

3. Employees (also identified as the "rated" ) and managers such as the rater, rating official, and reviewing official signed the performance appraisal.


9. During the quarterly self-certification review, managers will review documents that are signed and finalized within the quarter of the review. Managers should review the following retention standard forms:



1. Form 6774, Receipt of Critical Job Elements and Fair and Equitable Treatment of Taxpayers Retention Standard. Employee's and supervisor's signatures and dates on the original form filed in the EPF indicates the employee receipt of Form 6774.

2. TDF 35-07, SES Performance Management System - Executive Performance. Signatures of the employee, rating official, and reviewing official in Part 1, Consultation, indicates employee acknowledgement of the retention standard. The rating official checks Part VIII for a retention standard rating of "Met " or "Not Met." The rating official, reviewing official, and the employee sign and date the agreement.

3. Form 12450-A, Manager Performance Agreement. Signatures of the employee, rating official, and reviewing official in Part 1, Critical Performance Expectations, indicates employee acknowledgement of the retention standard. The rating official checks Part III for a retention standard rating of "Not Applicable," "Met," or "Not Met." The rating official, reviewing official, and employee sign and date the agreement.

4. Form 12450-B, Management Official Performance Agreement. Signatures of the employee, rating official, and reviewing official in Part 1, Critical Performance Expectations, indicates employee acknowledgement of the retention standard. The rating official checks Part III for a retention standard rating of "Not Applicable," "Met," or "Not Met." The rating official, reviewing official, and employee sign and date the agreement.

5. Form 12450-D, Management/Program Analyst Performance Agreement. Signatures of the employee, rating official, and reviewing official in Part 1, Critical Performance Expectations, indicates employee acknowledgement of the retention standard. The rating official checks Part III for a retention standard rating of "Not Applicable," "Met," or "Not Met." The rating official, reviewing official, and employee sign and date the agreement.

6. Form 6850-BU, Bargaining Unit Performance Appraisal and Recognition Request. The rater checks the retention standard rating of "Not Applicable," "Met," or "Not Met." The rating official, reviewing official, and employee sign and date the appraisal.

7. Form 6850-NBU, Non-Bargaining Unit Performance Appraisal. The rater checks the retention standard rating of "Not Applicable," "Met," or "Not Met." The rating official, reviewing official, and employee sign and date the appraisal.


**1.5.3.4.4** **(05-19-2017)**

#### Identifying and Addressing Records of Tax Enforcement Results Violations

1. Records of Tax Enforcement Results (ROTER) violations include any verbal or written use of a ROTER to evaluate an employee or to impose or suggest a production quota or goal with respect to such an employee.

2. If ROTER violations are identified during the quarterly self-certification review process, the manager:



1. Corrects verbal ROTER violations by retracting the violation(s) and providing the recipients with the corrected information.

2. Corrects written ROTER violations by retracting the violation(s) and the documentation containing the violation(s) such as meeting minutes, appraisals, employees' self-assessments and mid-year or progress reviews. After correction, the manager shares revised documentation with the appropriate recipients.



      ### Note:



      Although using ROTERs in self-assessments does not violate RRA 98, Section 1204, to dispel even the appearance of impropriety, employees should not be permitted to use ROTERs in self-assessments according to IRM 6.430.3.4.2.2, _Using Records of Tax Enforcement Results (ROTERs) in Self-Assessments_. See IRM 1.5.2.11.2, _Prohibited Use of ROTERs_, and (4) below.





      ### Note:



      Managers may never consider ROTERs in self-assessments for BU or NBU employees. If a BU employee includes a ROTER, the manager should explain why the employee should not use it and ask them to remove it. If an NBU employee includes a ROTER, the manager should direct the employee to revise the document removing the ROTER. The manager should date and make note of the request for his/her records.

3. Considers whether the numerical rating for a particular job element will change when removing a ROTER violation from a performance appraisal. Managers should consult Labor Relations staff, as appropriate.


3. If managers identify the prohibited use of ROTERs at times other than the quarterly certification reviews, they correct the violation immediately and report it during the next quarterly self-certification cycle. This includes ROTERs identified through:



1. Independent Reviews.

2. TIGTA Section 1204 Audit Reviews.



      ### Note:



      TIGTA potential ROTER violations are verified by GLS. When GLS concurs with the ROTER finding, the manager must report it on the next quarterly self-certification.

3. Operational reviews conducted internally by business units.

4. Quarterly Self-Certification Reviews.


4. A manager or next level reviewer may identify a ROTER in a proposed narrative of an employee's self-assessment, appraisal, or award nomination during the routine review process. If the document is not final, the manager or next level reviewer should return it to the originator with instructions to revise the ROTER immediately. In this case, the identification of a ROTER would not be reported as a violation during the quarterly self-certification process.

5. If a manager issues an employee appraisal in final form which includes a ROTER, the first-level manager (rater/rating official) and second-level manager (reviewing official) must each identify it as a violation in their next quarterly self-certification.



### Note:



Before signing, reviewing officials can prevent violations by conducting a thorough review of the evaluation.

6. If a manager inadvertently quotes a ROTER as a program goal during a meeting but corrects the statement during the discussion, this is not counted as a violation.


**1.5.3.4.5** **(10-17-2022)**

#### Counting and Reporting Records of Tax Enforcement Results Violations

1. Section 1204 managers report ROTER violations through the ITM certification by answering “Yes” to question 1 or 2. Managers should retain copies of documentation with violations and corrective actions for future reviews conducted by TIGTA, the HCO, or the business unit.



### Note:



If a manager answers yes to either question, ITM will automatically send an e-mail of the incident to the appropriate IRS 1204 program manager(s). The 1204 program manager for that business unit will contact the manager and review the facts to determine if a 1204(a) violation has occurred and provide further instructions to the manager accordingly.

2. If a Section 1204 manager identifies a ROTER violation from a previous manager, the current manager reports the violation on their next self-certification. For educational awareness and corrective action, the appropriate supervisor or designee advises the previous manager and their supervisor of the violation.

3. If an employee evaluation contains a Section 1204 violation and was signed by the rater’s reviewing official, two violations are reported. The rater created the initial violation and the reviewing official propagated it, creating a second violation by failing to detect and correct the rater’s initial violation and subsequently approving the performance document. The rater and the reviewing official report the violation on each of their next self-certifications.

4. Violations identified in a document signed by both the first-level and second-level managers are reported as separate violations, with each violation counted individually for each manager. For example, if a performance document contained two ROTERs, each level of management would separately report two violations on their self-certification, for a total of four violations from the incident. The corrective action will be appropriately identified for each manager.

5. Verbal ROTERs confirmed in writing are counted as two violations.



### Example:



If a group manager verbally uses a ROTER to suggest a production goal during a group meeting and documents the statement in minutes distributed to all group employees, these are identified as two violations, the verbal communication and the documentation in the minutes. Although provided to all employees, the minutes represent one violation.

6. A document including one ROTER violation that is posted to a website or distributed to an email group code is counted as one violation. If the manager included two ROTERs in the document and distributed them similarly, this would constitute two violations.

7. In summary, ROTER violations are counted as follows:




| **COUNTING ROTER VIOLATIONS**<br> This two-column table identifies how to count ROTER violations. The first column lists types of ROTERs, and the second column explains how to count them. |
| :-: |
| **Types of ROTERs** | **How to Count** |
| :-: | :-: |
| Multiple ROTERs in one document | Count total number of ROTERs in document as violations |
| One ROTER going to multiple individuals | Count as one violation |
| One ROTER with multiple managers' signatures on a document | Count total number of managers signatures as violations |
| Multiple ROTERs and multiple managers signatures on a document | Count total number of violations times the number of signatures |
| Verbal ROTER versus written ROTER | Verbal ROTERs are counted the same as written ROTERs |
| Verbal ROTERs confirmed in writing | Count total number of verbal ROTERs plus the written ROTERs |


**1.5.3.4.6** **(10-17-2022)**

#### Non-Compliance with the Retention Standard

1. Non-compliance with Section 1204(b) Fair and Equitable Treatment of Taxpayers Retention Standard is identified through the:



1. Independent Review.

2. Independent Reviews conducted by the business units.

3. Annual TIGTA Section 1204 audit.


2. Section 1204(b) non-compliance for the retention standard occurs on:



1. Form 6774, Receipt of Critical Job Elements and Fair and Equitable Treatment of Taxpayers Retention Standard.

2. Form 6850-BU, Bargaining Unit Performance Appraisal and Recognition Request

3. Form 6850-NBU, Non Bargaining Unit Performance Appraisal

4. Form 12450-A, Manager Performance Agreement

5. Form 12450-B, Management Official Performance Agreement

6. Form 12450-D, Management/Program Analyst Performance Agreement

7. SES Performance Management System - Executive Performance Agreement


3. Section 1204(b) non-compliance for the retention standard occurs if/when the:



1. Documentation (either acknowledgement or rating) is not contained in the employee file and/or does not exist for the fiscal year.

2. Documentation does not contain all signatures and dates (employee, manager, and next level manager).

3. Retention standard rating is unchecked in the annual performance document (annual rating of record).



      ### Note:



      Original (pen-and-ink) or digital signatures (signed electronically in HR Connect under ePerformance) are required on the documents filed in the EPF to avoid a Section 1204(b) instance of non-compliance. If there is a digital signature that contains a date, that date constitutes the date on the form for Section 1204 purposes.


4. Instances of retention standard non-compliance occur when there is a:



1. Failure to share the retention standard and obtain employee, manager, and next level manager signatures and dates.

2. Failure to correctly evaluate the employee on the retention standard as "Met," "Not Met," or "Not Applicable."

3. Failure to retain copies of employee retention standard acknowledgement and rating documentation in the EPF.


5. Depending on the type of Section 1204(b) non-compliance identified, the manager either:



1. Completes and shares with the employee the retention standard document.

2. Updates the appraisal document and shares the updated document with the employee.


6. Each instance of retention standard non-compliance is considered as one Section 1204(b) finding, regardless of the number of manager signatures.

7. Managers must take corrective action when Section 1204(b) instances of retention standard non-compliance are identified in:



1. Independent Reviews.

2. TIGTA audits.



      ### Note:



      Potential Section 1204(b) non-compliance identified in the annual TIGTA audit is reported unless the audit finding conflicts with IRM guidance.

3. Business unit independent reviews


8. Timeliness of receipt/acknowledgement (sharing) and evaluation (rating) for the performance standard is not a Section 1204 requirement. This means that retention standard acknowledgement and evaluation documents signed 30 days after the beginning of the performance period and 30 days after the end of the performance period are not counted as Section 1204(b) instances of non-compliance for self-certification reporting.



### Note:



While timeliness is not specifically a requirement for Section 1204, it is not intended to circumvent performance management requirements.

9. Performance management requires the timely acknowledgement and evaluation of performance standards.



1. For CJE employees, IRM 6.430.2.2.4.2, Sharing and Discussing the CJE Performance Plan, states that the supervisor must meet with the employee within 30 days of the beginning of the employee's appraisal period or when the employee is assigned to a new position that is expected to last at least 60 days or longer (e.g. temporary promotion, detail). This time frame makes certain that the employee has sufficient time to understand the supervisor's expectations for job performance and what performance is needed to achieve a specific rating.

2. For managers, management officials and confidential management/program analysts, IRM 6.430.3.2.1, Starting the Performance Appraisal Cycle, states that except in rare circumstances such as when the employee is on extended sick leave, the supervisor must meet with the employee within the first 30 days of the beginning of an employee's appraisal period, or when the employee is assigned to a new position for at least 60 days (e.g., temporary promotions, details), to review responsibilities and establish commitments or objectives and discuss the retention standard for the fair and equitable treatment of taxpayers. The performance appraisal cycle for managers, management officials, and confidential management/program analysts is based on the fiscal year and normally begins October 1.

3. IRM 6.430.2.4.2.1, Performance Appraisal Due Dates, states that the supervisor must complete the employee's annual appraisal for both bargaining unit and non bargaining unit employees within the scheduled time limits shown in the 2022 National Agreement, provided the employee has been observed for 60 days or more against his or her signed performance plan during the appraisal period.


**1.5.3.4.7** **(10-17-2022)**

#### Integrated Talent Management (ITM) Self-Certification

1. After completing their quarterly review, Section 1204 managers at all levels (including appropriate supervisors) complete the ITM Quarterly certification.

2. The manager’s quarterly certification is assigned through ITM:



1. Managers must retain the completed ITM training certification for audit and review purposes.

2. Managers are required to retain quarterly self-certifications for two years.


**1.5.3.4.7.1** **(10-17-2022)**

##### ITM Self-Certification Checklist

1. Section 1204 managers who were assigned to their position during the quarter will complete the self-certification for the work unit for the entire quarter. Leaders Alert guidance will announce the opening and closing of the ITM window for certification. When the certification is self-assigned before the systemic assignment, it creates duplicate entries on the ITM Completion reports.

2. For the quarterly self-certification process, Section 1204 managers should review:



1. All Section 1204 employees who are assigned to them as of the last day of the quarter .

2. All evaluations and EPFs for their employees.

3. All management activities such as meeting minutes and memoranda for the entire quarter for their immediate office.

4. The status of the HR Connect Section 1204 indicator for their employees.

5. The Section 1204 training status of new hires.

6. The Retention Standard behavior discussion status, especially for employees whose rating periods began during the quarter.


**1.5.3.4.7.2** **(10-17-2022)**

##### **Frequently Asked Questions for Quarterly Certifications**

1. _**Do I report violations that I didn't make?**_



   - Although it's called a "self-certification," you are certifying your business unit's compliance with Section 1204 rules, which includes anything prepared by acting managers or former managers relating to the business unit you now supervise.


2. _**As a new manager what should I do for the quarterly certification?**_



   - All new managers and managers moving to a new group or receiving a new employee should review the EPF(s) for the employee(s) and correct and report all Section 1204(a) violations. Regulation 801 and IRM violations that you discover must also be corrected, but are not reported on the Section 1204 quarterly certification


3. _**How far back do I go in reporting prior quarter violations discovered now?**_



   - Normally, it's the current fiscal year plus one previous year.


4. _**How do I report violations that occurred in a previous quarter?**_



   - Violations are reported when discovered, even those from previous quarters in the fiscal year.


5. _**What is the earliest that I can complete and sign the quarterly certification?**_



   - The opening day of the ITM certification window is the earliest you can certify for a quarter. A Leader’s Alert will be issued by HCO each quarter providing the ITM assignment date and due date.


6. _**What if I didn’t catch a violation during a previous ITM certification window?**_



   - Report your violation in the next ITM quarterly certification.


7. _**What if I am absent during the ITM certification window? Can my next level manager certify for me?**_



   - Section 1204(c) states that managers must certify to the Commissioner that they did not use ROTERs therefore your next level manager cannot certify for you. Complete your review and report ROTER violations in the next certification cycle.


8. _**If a Personnel Action Request (PAR) was cut for an employee to act as the manager, would the employee certify? What about circumstances where a PAR was not cut to serve as an acting manager?**_



   - If a PAR was cut for the employee to act as the manager, the employee should certify.

   - If a PAR was not cut for the employee to act as the manager, and the Acting manager (employee) and the Manager agree that the employee provided substantive assignments, reviews, direction and/or guidance that could have implied or suggested production goals or quotas in the workload, then the employee should certify.

   - If a PAR was not cut on the employee to act as the manager, and the Acting manager (employee) and the Manager agree that the employee did not provide substantive assignments, reviews, direction and/or guidance that could have implied or suggested production goals or quotas in the workload, then the employee does NOT NEED to certify.


**1204 Acting Managers-Decision Table**

|     |     |     |
| --- | --- | --- |
| **Circumstance:** | **Certify** | **Do Not Certify** |
| PAR was cut for Acting assignment | X |  |
| PAR was not cut but Acting Manager provided substantive assignments, reviews, direction and/or guidance to employee or work group (Acting Manager and Manager need to discuss to determine) | X |  |
| PAR was not cut and Acting Manager DID NOT provide substantive assignments, reviews, direction and/or guidance to employee or work group |  | X |

**1.5.3.4.8** **(10-17-2022)**

#### Quarterly Certification Memorandum of Record

1. The HCO prepares a quarterly memorandum of record based on the certification results provided by the Section 1204 business units.

2. This memorandum provides the quarterly certification summary of the IRS' compliance with RRA 98 Section 1204 and includes a comparison with activity for the fiscal year (FY). The Section 1204 appropriate supervisors, identified in an attachment, provide quarterly certification data to indicate their business unit's compliance with the requirements of RRA 98.

3. The HCO package for the quarterly memorandum includes a/an:



1. Quarterly memorandum of record summarizing business unit findings.

2. Summary identifying ROTER violations by business units per quarter and FY total.

3. Appropriate supervisors list containing the highest level appropriate supervisors for the business unit.

4. Form 13839-A, Note to Reviewer (For Signature Package), providing background, issues to be aware of, prior history, legal authority, and any additional information.

5. Form 14074, Action Routing Sheet, identifying the signature requested, reviewers, and comments.


4. This memorandum is routed for signature, as delegated by the IRS Commissioner, filed, and stored on the Section 1204 SharePoint site and IRS Source under Policies, Section 1204.


**1.5.3.5** **(10-17-2022)**

### HCO Independent Review Process

1. The Section 1204 Independent Review monitors current year compliance with Section 1204 of the IRS Restructuring and Reform Act of 1998 and related policy for:



1. Section 1204(a) use of enforcement statistics.

2. Section 1204(b) retention standard for the fair and equitable treatment of taxpayers.

3. HR Connect Section 1204 indicator status.

4. IRM violations in employee evaluations and self-assessments.

5. IRM 1.5.1.6(1)(e), Performance Measures Quick Reference, prohibits comparisons between business units.



      ### Note:



      These violations are often found in group meeting minutes and in the sharing of quantity/quality data reports with managers.


2. Business units are encouraged to complete their own independent reviews to complement the Independent Review.


**1.5.3.5.1** **(10-17-2022)**

#### Independent Review Assistance

1. The Section 1204 Independent Review validates the IRS’ compliance with RRA ‘98 and is supported by assistance from:



1. IRS business unit Section 1204 Program Managers

2. Statistics of Income (SOI), RAAS

3. General Legal Services (GLS)


2. The HCO determines the review period for the Independent Review process as needed. The review examines HR Connect extracts for manager and employee documentation to identify:



1. ROTER violations.

2. Retention standard instances of non-compliance.

3. HR Connect Section 1204 status.


**1.5.3.5.2** **(10-17-2022)**

#### Manager and Employee Selection

1. The HCO downloads the HR Connect Section 1204 indicator report to identify the population for the review period.

2. The HCO provides SOI with a listing of the managers for the last three years to eliminate those managers from the sample.

3. The HR Connect report is used to randomly select:



1. Section 1204 Managers. SOI selects a sufficient number of Section 1204 managers to allow for replacements if managers have changed and are not eligible for selection.


4. SOI provides the results of the sampling to the HCO. The random sampling includes a sufficient number of manager names for the HCO to select and determine the actual number of managers that will be included in the review.

5. Using the HR Connect report, the HCO selects employees reporting to each manager that SOI selected.


**1.5.3.5.3** **(10-17-2022)**

#### Independent Review Methodology

1. The HCO prepares SharePoint folders and organizes the Independent Review information.

2. The review methodology may include:



1. Analyzing HR Connect performance documents to determine if there are Section 1204(a) violations, if ROTERs were mentioned in any evaluative documents, or if any quotas or goals for tax enforcement results were imposed or suggested.

2. Analyzing all evaluative documents to determine if managers were in compliance with Section 1204(b) and that employees signed for receipt of and were evaluated on a retention standard governing the fair and equitable treatment of taxpayers, as applicable.

3. Analyzing employee evaluative documentation self-assessments and other written guidance to identify IRM policy violations and Regulation 801 violations for TERs, ROTERs, and unallowable comparisons.


**1.5.3.5.4** **(10-17-2022)**

#### Independent Review Procedures

1. Manager and employee files for Section 1204(a) violations and Section 1204(b) instances of non-compliance with the retention standard address:



1. Employee items for review (within the review period) are based on the date finalized, which is usually when the employee signed the documentation.



      ### Note:



      There may be additional appraisals other than the annual appraisal, such as mid-year appraisals, departure appraisals, and/or appraisals for job applications

2. Signatures and dates of the employee, manager, and next level reviewer signatures must appear in order to avoid a Section 1204(b) instance of non-compliance. If any signature is missing, it counts as an instance of non-compliance.

3. Retention standard ratings of "Met" , "Not Met" or "Not Applicable" . One box must be checked.


2. Review findings must be clearly identified as:



1. Section 1204(a) ROTER violations.

2. Section 1204(b) retention standard non-compliance.


3. Independent Review reports highlight the potential violation and/or instance of non-compliance and indicates violations or instances of non-compliance.

4. Verify the potential violation and/or instance of non-compliance with the EPF.

5. Retain documents for findings such as:



1. Form 6774, Receipt of Critical Job Elements and Fair and Equitable Treatment of Taxpayers Retention Standard, if the retention standard is not signed and dated by the employee and the manager.

2. Form 6850-BU, Bargaining Unit Performance Appraisal and Recognition Request, or Form 6850-NBU, Non Bargaining Unit Performance Appraisal, if the retention standard is not evaluated or is not signed and dated by the employee, manager, and next level reviewer.

3. Manager's employee appraisal narrative containing ROTER, Regulation 801, or IRM policy violations.

4. Missing manager's quarterly self-certifications.


6. Findings must be documented and cite the issue, law, and conclusion for ROTERs.

7. The HCO summarizes the results for each selected manager in an electronic spreadsheet and provides the review findings to the Section 1204 program managers for their business units. This summary is used by the business units to discuss findings with managers and develop or update guidance for their business unit.



### Example:



The review summary for W&I is provided to the W&I Section 1204 Program Manager.

8. The HCO submits potential ROTERs referred to GLS for review and concurrence. If GLS verifies that the potential ROTERs are actual ROTER violations, managers should correct the ROTER and record it on the next quarterly certification.

9. A summary of all findings by business unit is prepared for each business unit’s highest level appropriate supervisor when completed.



### Example:



A summary email is sent to the National Chief of Appeals with copies to the Deputy Chief, Area Directors, and the Appeals Section 1204 Program Manager.


**1.5.3.5.5** **(10-17-2022)**

#### Redacted Information/Need-to-Know

1. Pursuant to IRC 6103(h)(1) and 552A(b)(1) of the Privacy Act, the Independent Review may examine tax information and information covered by the Privacy Act to the extent that they have a "need-to-know" in order to discharge their tax administration duties.

2. Grand Jury investigation information related to the identification of the subject must be redacted manually from the hard copy document. Redacted information includes:



1. Name.

2. Address.

3. "Doing Business As (DBA)" identification.

4. Social Security Number.

5. Date of Birth.

6. Known associates.

7. Other personally identifiable information.

8. Sensitive non-performance-related personnel issues.


3. Sensitive information that cannot be disclosed for the Independent Review includes:



1. Ongoing criminal investigations.

2. Informant agreements and related documents.

3. Information concerning undercover operations.


4. EPF, performance appraisal documents, and other supervisory documents are required documents that must be sanitized or purged of any sensitive investigation-specific information and made available for the Independent Review.


**1.5.3.5.6** **(10-17-2022)**

#### Independent Review Results

1. HCO consolidates Independent Review findings by business unit.

2. The HCO provides the heads of business units with the specific HCO Independent Review results. This allows the business units to develop corrective action plans and complete them for any identified:



1. Section 1204(a) ROTER violations.

2. Section 1204(b) retention standard instances of non-compliance.

3. Section 1204(c) manager's self-certifications.


3. The summary of business unit findings is provided to each of the Section 1204 program managers.


**1.5.3.6** **(10-17-2022)**

### Annual Treasury Inspector General for Tax Administration Audit

1. TIGTA is required under IRC Section 7803(d)(1)(2000) to evaluate annually whether the IRS complies with restrictions on the use of enforcement statistics under RRA 98 Section 1204.

2. The TIGTA review determines whether the IRS complies with:



1. Section 1204(a), which prohibits the IRS from using any ROTER to evaluate employees or to impose or suggest production quotas or goals.

2. Section 1204(b), which requires that employees be evaluated using the fair and equitable treatment of taxpayers as a performance standard.

3. Section 1204(c), which requires each Section 1204 appropriate supervisor to self-certify quarterly whether ROTERs were used in a prohibited manner and whether their employees have signed to acknowledge receipt of and have been evaluated on the retention standard.


3. TIGTA compiles an annual report of the IRS compliance with RRA ‘98 that includes the business units selected for review, the results of the TIGTA review, and recommendations based on their findings.

4. HCO TIGTA audit liaison responsibilities include:



1. Coordinating with all impacted business units to respond to the annual TIGTA audit including TIGTA’s information and data requests.

2. Scheduling the opening and closing conferences.

3. Validating TIGTA potential ROTERs findings with GLS.

4. Addressing audit recommendations.

5. Providing final audit reports to the Section 1204 program managers.


5. Business unit audit responsibilities include:



1. Participating in TIGTA audit conferences.

2. Responding to individual document requests (IDRs).

3. Addressing audit findings and preparing corrective actions, as appropriate.

4. Reporting verified Section 1204(a) violations and Section 1204(b) instances of non-compliance on the manager's next quarterly certification.


**1.5.3.7** **(10-17-2022)**

### Records Retention

1. Section 1204 managers are required to retain the following records:



1. Employee receipt/acknowledgement of the retention standard (four years).

2. Employee performance ratings of the retention standard (four years).

3. Quarterly Section 1204(c) certifications (three years).


2. All Section 1204-related documentation, including quarterly certification and independent review documents, should be considered temporary records and must be closed out at the end of the fiscal year and destroyed three years after closure.


**1.5.3.8** **(10-17-2022)**

### Mandatory Section 1204 Training

1. The HCO provides mandatory RRA 98 Section 1204 training for managers and employees annually through ITM based on HR Connect Section 1204 status.


    Managers are encouraged to review the HR Connect status of their employees at least quarterly.

2. The training is designed specifically for Section 1204 managers and employees and is based on IRM 1.5.2, _Uses of Section 1204 Statistics,_ and this IRM.

3. Training topics may include:



1. RRA 98 Section 1204 and Regulation 801 requirements.

2. TERs and ROTERs.

3. Retention standard for the fair and equitable treatment of taxpayers (Retention Standard).

4. Use of quantity and quality measures.

5. HR Connect Section 1204 Indicator.


4. The annual Section 1204 mandatory training is scheduled and automatically assigned to Section 1204-indentifed managers' and employees' learning plans.

5. Section 1204 mandatory briefing completion status is monitored.


**1.5.3.9** **(10-17-2022)**

### HR Connect Indicator

1. The HR Connect indicator identifies Section 1204 managers and employees. Instructions for assigning and verifying HR Connect indicator status are available on the IRS Source page under Policies, under the RRA ’98 Section 1204 Program.



1. Refer to the link for the instructions for Section 1204 managers.

2. Refer to the link for the instructions for Section 1204 employees.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-005-003#addtoany "Show all")

A2A