---
url: "https://www.irs.gov/irm/part1/irm_01-001-026"
title: "1.1.26 Whistleblower Office | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-001-026#main-content)

- 1.1.26  [Whistleblower Office](https://www.irs.gov/irm/part1/irm_01-001-026#idm140190085168080)
  - 1.1.26.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-001-026#idm140190113554848)
    - 1.1.26.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-001-026#idm140190113562176)
    - 1.1.26.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-001-026#idm140190113559920)
    - 1.1.26.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-001-026#idm140190085170064)
      - 1.1.26.1.3.1  [Whistleblower Office](https://www.irs.gov/irm/part1/irm_01-001-026#idm140190086586208)
      - 1.1.26.1.3.2  [Claim Administration](https://www.irs.gov/irm/part1/irm_01-001-026#idm140190085146256)
        - 1.1.26.1.3.2.1  [Claim Administration Teams](https://www.irs.gov/irm/part1/irm_01-001-026#idm140190085184864)
      - 1.1.26.1.3.3  [Claim Operation Support](https://www.irs.gov/irm/part1/irm_01-001-026#idm140190085177680)
        - 1.1.26.1.3.3.1  [Initial Claim Evaluation Teams](https://www.irs.gov/irm/part1/irm_01-001-026#idm140190085165168)
          - 1.1.26.1.3.3.1.1  [ICE Intake](https://www.irs.gov/irm/part1/irm_01-001-026#idm140190085163248)
          - 1.1.26.1.3.3.1.2  [ICE Support](https://www.irs.gov/irm/part1/irm_01-001-026#idm140190085158608)
        - 1.1.26.1.3.3.2  [Initial Claim Analysis Team](https://www.irs.gov/irm/part1/irm_01-001-026#idm140190085141424)
        - 1.1.26.1.3.3.3  [Litigation, Monitoring and Notifications](https://www.irs.gov/irm/part1/irm_01-001-026#idm140190085139008)
      - 1.1.26.1.3.4  [Strategic Planning and Program Operations](https://www.irs.gov/irm/part1/irm_01-001-026#idm140190085134544)
        - 1.1.26.1.3.4.1  [Data Analysis and Reporting](https://www.irs.gov/irm/part1/irm_01-001-026#idm140190085126000)
        - 1.1.26.1.3.4.2  [Operation Program Support](https://www.irs.gov/irm/part1/irm_01-001-026#idm140190085121920)
    - 1.1.26.1.4  [Program Reports](https://www.irs.gov/irm/part1/irm_01-001-026#idm140190085117376)
    - 1.1.26.1.5  [Terms](https://www.irs.gov/irm/part1/irm_01-001-026#idm140190085115456)
    - 1.1.26.1.6  [Acronyms](https://www.irs.gov/irm/part1/irm_01-001-026#idm140190085293232)
    - 1.1.26.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-001-026#idm140190085290096)

# Part 1. Organization, Finance, and Management

# Chapter 1. Organization and Staffing

# Section 26. Whistleblower Office

* * *

## 1.1.26 Whistleblower Office

#### Manual Transmittal

July 16, 2025

#### Purpose

(1) This transmits revised IRM 1.1.26, _Organization and Staffing, Whistleblower Office_.

#### Background

This IRM describes the Whistleblower Office, its structure and responsibilities.

#### Material Changes

(1) IRM 1.1.26.1.2 (2): Added statement to cite IRC 6103 (k)(13)(B) for the Whistleblower Office disclosures.

(2) IRM 1.1.26.1.3.1(1): Updated last sentence to indicate that IRC 7623 (b) awards are mandatory provided certain criteria is met.

(3) IRM 1.1.26.1.3.1(5): Added additional direct reports to the Director, Whistleblower Office.

(4) IRM 1.1.26.1.3.2(2): Updated statement to describe Claim Administration responsibilities due to the Whistleblower Office’s reorganization structure.

(5) IRM 1.1.26.1.3.2.1: Updated title from Case Development and Oversight (CDO) to Claim Administration (CA) due to the Whistleblower Office’s reorganization structure. Changed references to CDO throughout the section and clarified CA Teams’ responsibilities.

(6) IRM 1.1.26.1.3.2.2: Removed IRM 1.1.26.1.3.2.2, Award Recommendation and Coordination subsection due to the Whistleblower Office’s reorganization structure.

(7) IRM 1.1.26.1.3.2.3: Renumbered to IRM 1.1.26.1.3.3.3, Litigation, Monitoring and Notifications due to the Whistleblower Office’s reorganization structure.

(8) IRM 1.1.26.1.3.3: Added a new subsection to outline Claim Operation Support structure.

(9) IRM 1.1.26.1.3.3.1: Previously IRM 1.1.26.1.3.4, Initial Claim Evaluation. The title was updated to Initial Claim Evaluation Teams. The content was revised for clarity and reflect the Whistleblower Office’s reorganization structure.

(10) IRM 1.1.26.1.3.3.1.1: Added a new subsection to outline the ICE Intake Team structure and responsibilities to reflect the Whistleblower Office’s reorganization structure.

(11) IRM 1.1.26.1.3.3.1.2: Added a new subsection to outline the ICE Support Team structure and responsibilities to reflect the Whistleblower Office’s reorganization structure.

(12) IRM 1.1.26.1.3.3.2: Added a new subsection to outline the Initial Claim Analysis Team structure and responsibilities.

(13) IRM 1.1.26.1.3.3.3: Previously IRM 1.1.26.1.3.2.3, Litigation, Monitoring and Notifications. This section outlines the Litigation, Monitoring, and Notifications Team structure and responsibilities. The content was revised for clarity and to reflect the Whistleblower Office’s reorganization structure.

(14) IRM 1.1.26.1.3.4: Previously IRM 1.1.26.1.3.3, Strategic Planning and Program Operations. The IRM was renumbered due to Whistleblower Office’s reorganization. The content was revised for clarity and to reflect the team’s structure and responsibilities.

(15) IRM 1.1.26.1.3.4.1: Added a new subsection to outline the Data Analysis and Reporting Team structure and responsibilities.

(16) IRM 1.1.26.1.3.4.2: Added a new subsection to outline the Operation Program Support Team structure and responsibilities.

(17) IRM 1.1.26.1.3.3.1: Previous IRM 1.1.26.1.3.3.1, Quality Assurance and Data Reporting was removed due to the Whistleblower Office’s reorganization structure. Its responsibilities are outlined in IRM 1.1.26.1.3.4.2, Operation Program Support.

#### Effect on Other Documents

IRM 1.1.26, dated January 15, 2025, is superseded.

#### Audience

All Divisions and Functions

#### Effective Date

(07-16-2025)

John W. Hinman

Director, Whistleblower Office

**1.1.26.1** **(01-11-2018)**

### Program Scope and Objectives

1. _Purpose:_ This IRM section describes the organization and staffing of the Whistleblower Office.

2. _Audience:_ Servicewide.

3. _Policy Owner:_ Director, Whistleblower Office is the policy owner of this program.

4. _Program Owner:_ Director, Whistleblower Office is the program office responsible for oversight over this program.


**1.1.26.1.1** **(01-11-2018)**

#### Background

1. On December 20, 2006, the Tax Relief and Health Care Act of 2006 (the Act) was enacted. Section 406 of the Act amends Internal Revenue Code (IRC) 7623 concerning the payment of awards to whistleblowers. The amendment made significant changes to the IRS award program and also required the establishment of a Whistleblower Office within the Internal Revenue Service that has responsibility for the administration of the award program. The 2006 amendments re-designated the prior IRC 7623 as IRC 7623(a), added new provisions as IRC 7623(b), and included program administration requirements that were not incorporated into the Internal Revenue Code.


**1.1.26.1.2** **(07-16-2025)**

#### Authority

1. The Whistleblower Office administers the Whistleblower Program governing payment of awards under IRC 7623.

2. The Whistleblower Office makes mandatory disclosures required by IRC 6103 (k) (13) (B).


**1.1.26.1.3** **(11-07-2023)**

#### Responsibilities

1. The Whistleblower Office:



1. Reviews and evaluates claims for an award filed by whistleblowers.

2. Coordinates whistleblower claims with other functions within the IRS.

3. Monitors claims throughout the life of each claim, including through the investigation, examination, appeals, collection process, and award issuance.

4. Evaluates the contribution of the information brought forward by the whistleblower.

5. Makes a determination about the appropriateness of an award including the applicable award percentage, amounts attributable, and collected proceeds.

6. Facilitates communication with external and internal customers and stakeholders concerning the Whistleblower Program.


**1.1.26.1.3.1** **(07-16-2025)**

##### Whistleblower Office

1. The Whistleblower Office was established as a result of enactment of the Tax Relief and Health Care Act of 2006 (the Act), signed into law on December 20, 2006. Section 406 of the Act amended IRC 7623 concerning the payment of awards. The prior statutory authority to pay awards was reassigned as IRC 7623(a) and a new IRC 7623(b) was added. Additional provisions in Section 406 of the Act required establishment of a Whistleblower Office within the IRS to address award program administration issues. The IRC 7623(a) awards remain as a discretionary program while awards under IRC 7623(b) are mandatory provided certain criteria is met.

2. The Director, who reports to the Commissioner and to the Chief Tax Compliance Officer, has primary supervisory responsibility for the Whistleblower Office, including oversight and control of all policy decisions and implementation.

3. The mission of the Whistleblower Office is to effectively administer the Whistleblower Program by ensuring:



1. IRS compliance functions receive and consider specific, timely, and credible whistleblower claims that identify non-compliance with tax laws or other laws the IRS is authorized to administer, enforce, or investigate;

2. Whistleblowers receive required notifications timely; and

3. Awards are fairly determined and timely paid.


4. To accomplish the mission, the Director:



01. Coordinates with operating divisions, Criminal Investigation, and Counsel.

02. Defines and communicates key performance goals.

03. Analyzes Whistleblower Program trends to drive policy and outreach strategies.

04. Develops clear process standards within the Whistleblower Program.

05. Develops and fosters working relationships with partner organizations.

06. Conducts outreach activities with external stakeholders to educate and guide actions to improve submissions.

07. Develops educational strategies and designs curriculum focusing on developing Whistleblower Office key competencies.

08. Develops and directs the implementation of office policy and procedures.

09. Monitors performance goals.

10. Sets policy pertaining to whistleblower claims.

11. Provides technical guidance.

12. Conducts a study each year and reports to Congress on the use of IRC 7623 and any legislative or administrative recommendations for IRC 7623.

13. Monitors and maintains the Whistleblower Office e-mail inbox.

14. Acts as a liaison for Freedom of Information Act requests.

15. Acts as a liaison with Congress for the Whistleblower Office.


5. The following report to the Director, Whistleblower Office.



1. Associate Director, Claim Administration

2. Associate Director, Claim Operation Support

3. Associate Director, Strategic Planning and Program Operations

4. Technical Advisor

5. Executive Assistant


**1.1.26.1.3.2** **(07-16-2025)**

##### Claim Administration

1. The Associate Director, Claim Administration (CA), reports to the Director, Whistleblower Office.

2. CA provides oversight of claim administration activity and coordination with the operating divisions.

3. To accomplish its mission, CA:



1. Approves award determinations or makes recommendations for Director approval according to delegated authority.

2. Reviews and evaluates the activities of CA teams to measure the achievement of Whistleblower Program objectives.

3. Coordinates with other internal and external functions to improve operations, provide a customer forum, and build alliances.

4. Works with practitioners, industry stakeholders, and government agencies.

5. Identifies and coordinates on emerging and unique issues.


**1.1.26.1.3.2.1** **(07-16-2025)**

###### Claim Administration Teams

1. Claim Administration (CA) is composed of four teams and the CA Managers report to the Associate Director, CA.

2. To accomplish its mission, CA Teams:



1. Evaluate submissions filed by whistleblowers for awards.

2. Refer whistleblower claims to operating divisions as appropriate.

3. Provide coordination with the operating divisions to ensure whistleblower submissions are evaluated in a timely manner and in accordance with established policy and procedures.

4. Monitor the whistleblower claims through examination, investigation, assessment and collection of proceeds.

5. Review the operating divisions' examination results (including criminal investigation) to evaluate the whistleblower's contribution and performs award calculations in order to recommend an award percentage and amount pursuant to IRC 7623.

6. Prepare and issue award determination letters.

7. Act as liaison for the Whistleblower Office and the operating divisions.


**1.1.26.1.3.3** **(07-16-2025)**

##### Claim Operation Support

1. The Associate Director, Claim Operation Support (COS), reports to the Director, Whistleblower Office.

2. COS provides oversight of the activities performed by Initial Claim Analysis (ICA), Litigation, Monitoring and Notifications (LMN), and Initial Claim Evaluation (ICE) teams. The four COS Managers report to the Associate Director, COS.

3. To accomplish its mission, COS:



1. Oversees whistleblower claim intake and initial analysis.

2. Oversees whistleblower claims in litigation.

3. Ensures compliance with statutory requirements by notifying whistleblowers when claims are referred, monitoring and notifying whistleblowers when payments are made, and responding to whistleblowers' written requests about the status and stage of claims.

4. Supports whistleblower claim monitoring and award processing.


**1.1.26.1.3.3.1** **(07-16-2025)**

###### Initial Claim Evaluation Teams

1. Effective September 8, 2024, the Whistleblower Office implemented a new organizational structure which included the realignment of the Initial Claim Evaluation (ICE) team, from Small Business/Self-Employed (SB/SE) to the Whistleblower Office, and expanded from one to two ICE teams: ICE Intake and ICE Support.


**1.1.26.1.3.3.1.1** **(07-16-2025)**

###### ICE Intake

1. The ICE Intake Manager reports to the Associate Director, COS.

2. To accomplish its mission, ICE intake:



1. Receives and processes correspondence from whistleblowers.

2. Completes initial Form 211 processing and routes claim for initial analysis and operating division’s consideration.

3. Issues letters such as acknowledgment, rejection, denial, and statutorily required referral notification letters.

4. Establishes controls when claims are selected and routes administrative claim files to the appropriate field operations.


**1.1.26.1.3.3.1.2** **(07-16-2025)**

###### ICE Support

1. The ICE Support Manager reports to the Associate Director, COS.

2. To accomplish its mission, ICE Support:



1. Receives and performs initial reviews of Forms 11369.

2. Monitors accounts for collected proceeds and refund statute dates.

3. Prepares award calculation worksheet as applicable.

4. Assists in whistleblower’s tax compliance verification as applicable.

5. Responds to general whistleblower related correspondence and phone calls.

6. Coordinates with Corporate Performance and Budget Execution Office requesting funds to pay approved awards.

7. Supports records management of administrative claim files.


**1.1.26.1.3.3.2** **(07-16-2025)**

###### Initial Claim Analysis Team

1. The Initial Claim Analysis (ICA) Manager reports to the Associate Director, COS.

2. To accomplish its mission, ICA will analyze the information submitted by whistleblowers in support of a claim for award, identifying and prioritizing referral of credible, specific, actionable claims that align with the enterprise strategic priorities and goals, and reject claims that do not include actionable allegations.


**1.1.26.1.3.3.3** **(07-16-2025)**

###### Litigation, Monitoring and Notifications

1. The Litigation, Monitoring, and Notifications (LMN) Manager reports to the Associate Director, COS.

2. To accomplish its responsibilities, LMN:



1. Provides litigation support and coordinates with Counsel on all matters related to petitioned award determinations.

2. Assists in award computations for complex claims.

3. Monitors target taxpayers for proceeds related to whistleblower claims.

4. Issues statutorily required payment notification letters.


**1.1.26.1.3.4** **(07-16-2025)**

##### Strategic Planning and Program Operations

1. The Associate Director, Strategic Planning and Program Operations (SPPO) reports to the Director, Whistleblower Office.

2. SPPO provides oversight of administration of budget, personnel, staffing activities, and strategic planning for the Whistleblower Office.

3. SPPO provides oversight of the activities performed by Data Analysis and Reporting (DAR) and Operation Program Support (OPS) teams.

4. To accomplish its responsibilities, SPPO:



1. Coordinates strategic objectives and plans for the Director, Whistleblower Office.

2. Oversees the financial resources of the Whistleblower Office including tracking resource usage against targets and establishing financial policies, procedures, and controls in accordance with overall IRS guidelines and procedures.

3. Oversees risk management activities.

4. Supports educational strategies and serves as key advisor for the Whistleblower Program education and training activities.

5. Supports the Whistleblower Office with workforce forecasting, recruitment planning and identification, and resolution of division-wide labor management issues.

6. Provides strategy and oversight for all internal and external communications affecting Whistleblower Office, including marketing and media relations.

7. Oversees the Whistleblower Office’s claim management system and other technology tools and resources.

8. Oversees the Whistleblower Office compliance with federal tax and information filing requirements for whistleblower award payments.

9. Authorizes release of funds for purposes of paying a whistleblower award under IRC 7623 in accordance with delegated authority.


**1.1.26.1.3.4.1** **(07-16-2025)**

###### Data Analysis and Reporting

1. The Data Analysis and Reporting (DAR) Manager reports to the Associate Director, SPPO.

2. To accomplish its responsibilities, DAR:



1. Develops data collection requirements, conducts data validations, and performs data analysis in order to measure program results and monitor key performance metrics.

2. Completes Whistleblower Program federal tax and information filing requirements for whistleblower award payments.

3. Supports claim management system record and functionality.


**1.1.26.1.3.4.2** **(07-16-2025)**

###### Operation Program Support

1. The Operation Program Support (OPS) manager reports to the Associate Director, SPPO.

2. To accomplish its responsibilities, OPS:



1. Develops and issues policy and procedural guidance for the Whistleblower Office.

2. Analyzes and assesses Whistleblower Office training needs and implements training solutions.

3. Performs quality assurance reviews to ensure Whistleblower Office and operating division personnel follow applicable policy and procedures when working whistleblower claims.

4. Identifies quality improvement opportunities.


**1.1.26.1.4** **(11-07-2023)**

#### Program Reports

1. The Whistleblower Office must conduct a study annually and report to Congress on the use of IRC 7623, including an analysis of the use of such section during the preceding year and the results of such use, and any legislative or administrative recommendations regarding the provisions of such section and its application.


**1.1.26.1.5** **(01-11-2018)**

#### Terms

1. For a list of terms used throughout the Whistleblower Program, see IRM 25.2.1.1.3, _Terms,_ and IRM 25.2.2.1.4, _Terms_.


**1.1.26.1.6** **(01-11-2018)**

#### Acronyms

1. For a list of acronyms used throughout the Whistleblower Program, see IRM 25.2.1.1.4, _Acronyms,_ and IRM 25.2.2.1.5, _Acronyms_.


**1.1.26.1.7** **(11-07-2023)**

#### Related Resources

1. The following resources provide additional information on the Whistleblower Office:



   - Whistleblower Office intranet website - https://irsgov.sharepoint.com/sites/WO.

   - IRS.gov public website - [https://www.irs.gov/compliance/whistleblower-office](https://www.irs.gov/compliance/whistleblower-office).

   - IRM 25.2.1, _General Operating Division Guidance for Working Whistleblower Claims_.

   - IRM 25.2.2, _Whistleblower Awards_.

   - Pub 5251, [The Whistleblower Claim Process](https://www.irs.gov/pub/irs-pdf/p5251.pdf).


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-001-026#addtoany "Show all")

A2A