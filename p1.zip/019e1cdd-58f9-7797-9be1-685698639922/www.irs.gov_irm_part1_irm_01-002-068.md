---
url: "https://www.irs.gov/irm/part1/irm_01-002-068"
title: "1.2.68 Division Delegations of Authority for Tax Exempt and Government Entities (TE/GE) | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-002-068#main-content)

- 1.2.68  [Division Delegations of Authority for Tax Exempt and Government Entities (TE/GE)](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457028759936)
  - 1.2.68.1  [Introduction to Division Delegations of Authority for TE/GE](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457028764000)
    - 1.2.68.1.1  [General Principles](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457028687840)
  - 1.2.68.2  [Current TE/GE Division Delegations of Authority](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457028684720)
    - 1.2.68.2.1  [Delegation Order TEGE 1-1-1, Order of Succession and Designation to Act as Commissioner, Tax Exempt and Government Entities Division and Other Top-Level Executives](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457028682064)
    - 1.2.68.2.2  [Delegation Order TEGE 1-7-1, To Authorize Attendance at Meetings at Government Expense](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026992352)
    - 1.2.68.2.3  [Delegation Order TEGE 1-23-1, Authority to Sign Thirty Day Letters](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026983280)
    - 1.2.68.2.4  [Delegation Order TEGE 1-23-2, Authority to Sign Claim Disallowance Notices](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026975200)
    - 1.2.68.2.5  [Delegation Order TEGE 1-53-1, Withholding Compensation Due Personnel](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026968096)
    - 1.2.68.2.6  [Delegation Order TEGE 1-66-1, Execute Settlement Agreements in Equal Employment Opportunity Matters](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026958992)
    - 1.2.68.2.7  [Delegation Order TEGE 6-3-1, Delegation of Authority in Labor-Management Relations Matters](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026406064)
    - 1.2.68.2.8  [Delegation Order TEGE 6-22-1, Authority to Approve Monetary and Time-Off Performance Awards, Performance Bonuses, Individual and Group Special Act Awards, Managers’ Awards, Bilingual Awards, Honorary Awards, Employee Suggestion Awards, Informal Recognition, and Quality Step Increases](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026396928)
    - 1.2.68.2.9  [Delegation Order TEGE 7-1-1, Issuance of Determination Letters relating to Employee Plans](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026373824)
    - 1.2.68.2.10  [Delegation Order TEGE 7-2-1, Authority to Issue Exempt Organization Determination Letters](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026362256)
    - 1.2.68.2.11  [Delegation Order TEGE 7-4-1, Authority to Extend the Correction Period and the Allowable Distribution Period Relating to Private Foundation Matters](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026352672)
    - 1.2.68.2.12  [Delegation Order TEGE 7-7-1 (Rev. 1), Delegation of Authority for Waiver of Excise Taxes Imposed Under Section 4971(b) of the Internal Revenue Code](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026345072)
    - 1.2.68.2.13  [Delegation Order TEGE 7-15-1, Revocation of Exemption of Certain Governmental Plans or Church Plans that have engaged in Prohibited Transactions](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026334464)
    - 1.2.68.2.14  [Delegation Order TEGE 7-16-1, Amendment of Employee Plans after the Expiration of the Remedial Amendment Period](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026326720)
    - 1.2.68.2.15  [Delegation Order TEGE 11-2-1, Delegation of Authority to Permit Disclosure of Tax Information and to Permit Testimony or the Production of Documents](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026318736)
  - 1.2.68.3  [Rescinded TE/GE Division Delegations of Authority](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026307056)
    - 1.2.68.3.1  [Delegation Order TE/GE Order No. 1 (Rev. 1), Delegation of Authority in Settlement of Tort Claims, Claims under the Small Claims Act, and Claims Made by an Employee of the Internal Revenue Service for Damage to or Loss of Personal Property Incident to Service](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026304704)
    - 1.2.68.3.2  [Delegation Order TE/GE Order No. 2 (Rev. 1), Delegation of Authority to Require Record Keeping](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026300560)
    - 1.2.68.3.3  [Delegation Order TE/GE Order No. 4 (Rev. 1), Delegation of Authority for Agreements Treated as Determinations](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026296816)
    - 1.2.68.3.4  [Delegation Order TE/GE Order No. 5 (Rev. 1), Delegation of Authority for Tours of Duty](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026293088)
    - 1.2.68.3.5  [Delegation Order TE/GE Order No. 6 (Rev. 1), Delegation of Authority to Execute Consents Fixing the Period of Limitations on Assessment or Collection Under Provisions of the 1939, 1954 and 1986 Internal Revenue Code](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026289296)
    - 1.2.68.3.6  [Delegation Order TE/GE Order No. 10 (Rev. 3), Delegation of Authority to Authorize or Approve Travel, Travel Advances, and Transportation Services, and to Approve Travel Vouchers](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026285024)
    - 1.2.68.3.7  [Delegation Order TE/GE Order No. 11 (Rev. 2), Delegation of Authority to Enter Into and Approve Closing Agreements Concerning Internal Revenue Tax Liability](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026277776)
    - 1.2.68.3.8  [Delegation Order TE/GE Order No. 12 (Rev. 1), Furnishing Special Statistical Studies, Compilations, Return and Return Information, Training, and Training Aids](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026273952)
    - 1.2.68.3.9  [Delegation Order TE/GE Order No. 13 (Rev. 2), Delegation of Authority to Charge Absence and Leave](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026268320)
    - 1.2.68.3.10  [Delegation Order TE/GE Order No. 17 (Rev. 1), Issuance of Examination Reports](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026264656)
    - 1.2.68.3.11  [Delegation Order TE/GE Order No. 19 (Rev. 1), Church Tax Inquiries and Examinations](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026260960)
    - 1.2.68.3.12  [Delegation Order TE/GE Order No. 22 (Rev. 1), Requests for Variance from Minimum Funding Standards or Waiver of Accumulated Funding Deficiency](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026257248)
    - 1.2.68.3.13  [Delegation Order TE/GE Order No. 26 (Rev. 1), Delegation of Authority for Authority to Designate Qualified General Assistance Programs Described in Section 51(d)(6) of the Internal Revenue Code](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026253152)
    - 1.2.68.3.14  [Delegation Order TE/GE Order No. 27 (Rev. 1), Delegation of Authority to Grant Case by Case Exemptions to the Financial Conflict of Interest Provision in 18 USC Subsection 208(a)](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026248576)
    - 1.2.68.3.15  [Delegation Order TE/GE Order No. 28 (Rev. 2), Delegation of Authority to Authorize Travel Not at Government Expense](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026244016)
    - 1.2.68.3.16  [Delegation Order TE/GE Order No. 29 (Rev. 1), Delegation of Authority to Abate Interest Due to IRS Error or Delay](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026238544)
    - 1.2.68.3.17  [Delegation Order TE/GE Order No. 30 (Rev. 1), Voluntary Correction Program](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026234640)
    - 1.2.68.3.18  [Delegation Order TE/GE Order No. 31 (Rev. 1), Delegation of Authority Overtime](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026230880)
    - 1.2.68.3.19  [Delegation Order TE/GE Order No. 32, Delegation of Authority for Certification of Time and Attendance](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026226976)
    - 1.2.68.3.20  [Delegation Order TE/GE Order No. 33 (Rev. 1), Authorization to Engage in Outside Employment, Business, and Other Activities](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026223136)
    - 1.2.68.3.21  [Delegation Order TE/GE Order No. 35, Authority to Issue Notices of Deficiency or Execute Agreements to Rescind Notices of Deficiency](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026219296)
    - 1.2.68.3.22  [Delegation Order TE/GE Order No. 38 (Rev. 1), Determination if Plan Amendment is Reasonable and Has De Minimis Effect on Plan Liability](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026215360)
    - 1.2.68.3.23  [Delegation Order TE/GE Order No. 39 (Rev. 1), Extension of Amortization Period of Plans](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026211536)
    - 1.2.68.3.24  [Delegation Order TE/GE Order No. 40, Delegation of Authority to Approve Superior Qualification Appointments](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026207808)
    - 1.2.68.3.25  [Delegation Order TE/GE Order No. 42, Delegation of Authority to Review/Approve the Instructor Allowance Certification of an Instructor who Meets the Criteria to receive a Six-Percent Retention Allowance](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026203248)
    - 1.2.68.3.26  [Delegation Order TE/GE Order No. 44 (Rev. 1), Delegation of Authority to Reimbursement for Actual Expenses](https://www.irs.gov/irm/part1/irm_01-002-068#idm140457026198784)

# Part 1. Organization, Finance, and Management

# Chapter 2. Servicewide Policies and Authorities

# Section 68. Division Delegations of Authority for Tax Exempt and Government Entities (TE/GE)

* * *

## 1.2.68 Division Delegations of Authority for Tax Exempt and Government Entities (TE/GE)

#### Manual Transmittal

September 22, 2022

#### Purpose

(1) This transmits new IRM 1.2.68, Servicewide Policies and Authorities, Division Delegations of Authority for Tax Exempt and Government Entities (TE/GE).

#### Material Changes

(1) IRM 1.2.68.1, Introduction to Division Delegations of Authority for TE/GE, has been established to document content appropriate for the first issuance of this IRM.

(2) IRM 1.2.68.2 documents current TE/GE divisional delegation orders.

(3) IRM 1.2.68.3 documents the removal of rescinded TE/GE divisional delegation orders.

#### Effect on Other Documents

This IRM supersedes any prior TE/GE Divisional Delegations of Authority not included herein.

#### Audience

Tax Exempt and Government Entities

#### Effective Date

(09-22-2022)

Edward Killen

Deputy Commissioner

Tax Exempt and Government Entities

**1.2.68.1** **(09-22-2022)**

### Introduction to Division Delegations of Authority for TE/GE

1. This IRM contains delegation orders (DO) for the Tax Exempt and Government Entities (TE/GE) Division. Distribution of this IRM includes all persons with a need for any of the authorities or information in this section. All approved TE/GE division delegation orders are listed in numerical order. Rescinded Division Delegation Orders for TE/GE are retained in this IRM for documentation and audit purposes and follow current delegation orders.

2. Each TE/GE delegation order is based on a Servicewide delegation order. Servicewide delegations of authority and can be found in IRM 1.2.2, Servicewide Delegations of Authority. A Portable Document Format (PDF) version of this IRM can be obtained through the Electronic Publishing web site at http://publish.no.irs.gov. Additional information on the delegation order process can be found in IRM 1.11.4, Servicewide Delegation Order Process.

3. The format and numbering are consistent with guidance from Servicewide Policy, Directives and Electronic Resources (SPDER). For example, delegation order TEGE 1-23-2 shows:



   - TE/GE: the organization issuing the redelegation order

   - 1-23: the related Servicewide delegation order

   - 2: the sequential number to indicate that more than one redelegation can be issued for each Servicewide delegation order.


**1.2.68.1.1** **(09-22-2022)**

#### General Principles

1. TE/GE division delegation orders are issued only at the operating division (business unit commissioner) level.

2. If any delegation order may have been inadvertently omitted from this IRM Section, it is still considered official and in full force and effect. Direct any questions regarding current division DOs, including revisions or issuance of new division DOs, to the TE/GE Internal Management Document (IMD) Coordinator at \*TE/GE IMD SPOC.

3. Authority should be delegated directly to the lowest level expected to take final action. Delegating authority to the lowest level for action means that: Every intervening supervisory position above the lowest level, including the Commissioner, has the same authority.


**1.2.68.2** **(09-22-2022)**

### Current TE/GE Division Delegations of Authority

1. Current TE/GE division delegation orders are listed in numerical sequence. New or revised TE/GE division delegation orders approved after this IRM revision can be found at [https://www.irs.gov/privacy-disclosure/recently-approved-division-function-delegation-orders](https://www.irs.gov/privacy-disclosure/recently-approved-division-function-delegation-orders); all documents are maintained on the website until the next IRM revision.


**1.2.68.2.1** **(06-02-2022)**

#### Delegation Order TEGE 1-1-1, Order of Succession and Designation to Act as Commissioner, Tax Exempt and Government Entities Division and Other Top-Level Executives

01. **Order of Succession and Designation to Act as Commissioner, Tax Exempt and Government Entities Division and Other Top-Level Executives**

02. **Authority:** To act and perform the functions of the Commissioner of the Tax Exempt and Government Entities (TE/GE) Division of the Internal Revenue Service in the absence of the Division Commissioner due to an enemy attack on the United States, disability, other emergency or vacancy/absence in the office; thus, ensuring the continuity of the functions of the office.



    ### Note:



    This authority only applies to officials in permanent positions.

03. **Delegated to:** The following officials are authorized in the specific sequence listed.



    - Deputy Commissioner, TE/GE

    - Director, Exempt Organizations and Government Entities

    - Director, Employee Plans


04. **Redelegation:** This authority may not be redelegated.

05. **Authority:** To act in the absence of the Director, Exempt Organizations and Government Entities (EO/GE), TE/GE Division.




     The management officials who occupy the positions listed below are authorized in order of succession to the position of Director, EO/GE, TE/GE Division.




     The official named as successor will be vested with all of the authority given the Director, EO/GE, TE/GE Division until relieved of the responsibility.



    ### Note:



    This authority only applies to officials in permanent positions.

06. **Delegated to:**



    - Director, Examinations, EO/GE

    - Director, Rulings and Agreements, EO/GE

    - Director, Government Entities, EO/GE


07. **Redelegation:** This authority may not be redelegated.

08. **Authority:** To act in the absence of the Director, Employee Plans, TE/GE Division.




     The management officials who occupy the positions listed below are authorized in order of succession to the position of Director, Employee Plans, TE/GE Division.




     The official named as successor will be vested with all of the authority given the Director, Employee Plans, TE/GE Division until relieved of the responsibility.



    ### Note:



    This authority only applies to officials in permanent positions.

09. **Delegated to:**



    - Director, Examinations, EP

    - Director, Rulings and Agreements, EP

    - Manager, Program Management Office, EP


10. **Redelegation:** This authority may not be redelegated.

11. **Authority:** To act in the absence of the Director, Compliance Planning and Classification (CP&C), TE/GE Division.




     The management officials who occupy the positions listed below are authorized in order of succession to the position of Director, CP&C, TE/GE Division.




     The official named as successor will be vested with all of the authority given the Director, CP&C, TE/GE Division until relieved of the responsibility.



    ### Note:



    This authority only applies to officials in permanent positions.

12. **Delegated to:**



    - Manager, Issue ID and Special Review, CP&C

    - Manager, Planning & Monitoring, CP&C

    - Manager, Classification and Case Assignment, CP&C


13. **Redelegation:** This authority may not be redelegated.

14. **Authority:** To act in the absence of the Director, Shared Services, TE/GE Division.




     The management officials who occupy the positions listed below are authorized in order of succession to the position of Director, Shared Services, TE/GE Division.




     The official named as successor will be vested with all of the authority given the Director, Shared Services, TE/GE Division until relieved of the responsibility.



    ### Note:



    This authority only applies to officials in permanent positions.

15. **Delegated to:**



    - Manager, Human & Capital Resources, Shared Services

    - Manager, Business Systems Planning, Shared Services

    - Manager, Communication & Liaison, Shared Services


16. **Redelegation:** This authority may not be redelegated.

17. **Sources of Authority:** Servicewide Delegation Order 1-1 (Rev. 3), dated September 2, 2014, and Servicewide Delegation Order 1-2, dated August 29, 1996.

18. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

19. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.2.2** **(07-07-2022)**

#### Delegation Order TEGE 1-7-1, To Authorize Attendance at Meetings at Government Expense

1. **To Authorize Attendance at Meetings at Government Expense**

2. **Authority:** The authority to authorize the attendance of employees at meetings of scientific or professional societies; municipal, state, federal, or international organizations; Congress; and law enforcement or other groups; and to authorize or approve attendance of employees at meetings held by employee groups, organizations, or associations.

3. **Delegated to:**



   - Director, Exempt Organizations and Government Entities;

   - Director, Employee Plans;

   - Director, Compliance Planning and Classification; and

   - Director, Shared Services.


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 1-7, dated April 7, 2003.

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes TE/GE Divisional Delegation Order 7 (Rev. 1), dated December 5, 1999.

7. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities


**1.2.68.2.3** **(06-24-2022)**

#### Delegation Order TEGE 1-23-1, Authority to Sign Thirty Day Letters

1. **Authority to Sign Thirty Day Letters**

2. **Authority:** The authority to sign and send to the taxpayer preliminary or 30-day letters with respect to matters under their jurisdiction.

3. **Delegated to:**



   - Managers of: Revenue Agents; Tax Compliance Officers; Tax Examining Technicians; Tax Law Specialists; Federal, State, and Local Government Specialists; Indian Tribal Governments Specialists

   - Reviewers in Mandatory Review groups


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 1-23, dated November 8, 2000.

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

7. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.2.4** **(06-24-2022)**

#### Delegation Order TEGE 1-23-2, Authority to Sign Claim Disallowance Notices

1. **Authority to Sign Claim Disallowance Notices**

2. **Authority:** The authority to sign and to send to taxpayers, by registered or certified mail, notices of disallowance of refund claims.

3. **Delegated to:** TE/GE Reviewers in Mandatory Review Groups.

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 1-23, dated November 8, 2000.

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

7. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.2.5** **(07-15-2022)**

#### Delegation Order TEGE 1-53-1, Withholding Compensation Due Personnel

1. **Withholding Compensation Due Personnel**

2. **Authority:** The authority to make administrative determination of the amount of an erroneous payment, based on a statement of findings of fact, and to arrange with the employee the method of repayment and the amounts to be collected or deducted from the gross pay of the individual.

3. **Delegated to:**



   - Director, Exempt Organizations and Government Entities;

   - Director, Employee Plans;

   - Director, Compliance Planning and Classification; and

   - Director, Shared Services.


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 1-53, dated October 31, 1987.

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes TE/GE Divisional Delegation Order 8 (Rev. 1), dated December 5, 1999.

7. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.2.6** **(08-08-2022)**

#### Delegation Order TEGE 1-66-1, Execute Settlement Agreements in Equal Employment Opportunity Matters

1. **Execute Settlement Agreements in Equal Employment Opportunity Matters**

2. **Authority:** The authority to on behalf of the Internal Revenue Service agree to take or refrain from taking actions including but not limited to personnel actions resulting in backpay or other equitable relief attendant to such actions, as well as the payment of compensatory damages and attorney’s fees, for the purpose of settling claims of violations of Equal Employment Opportunity (EEO) laws or regulations applicable to the IRS as described in 29 CFR Part 1614 with respect to claims which arise out of, relate to, or concern the respective activities or functions administered by the delegated officials, after consultation with a Deputy Commissioner to the extent required.



### Note:



The consultation referred to in this Paragraph is required in any case involving (i) a class,(ii) a potentially precedent - setting issue, (iii) the payment of monies in excess of $100,000, or (iv) any other circumstance that, in the judgment of the official, warrants referral to a Deputy Commissioner.

3. **Delegated to:**



1. for settlements resulting in the payment of money to the complainant where the total value of the agreed upon payments exceeds $100,000, no redelegation is permitted;

2. for settlements resulting in the payment of money to the complainant where the total value of the agreed upon payments exceeds $10,000, but is not more than $100,000, redelegation is limited to members of the Executive Service;

3. for settlements resulting in the payment of money to the complainant where the total value of the agreed upon payments is $10,000 or less, redelegation is permitted to any employee in a second‐level managerial position and any employee in a first‐level managerial position who reports directly to a member of the Executive Service;

4. the authority to execute settlements that do not involve the payment of any money to the complainant may be redelegated to any manager or supervisor.


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 1-66, dated March 26, 2018.

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes TE/GE Divisional Delegation Order 43, dated January 26, 2004.

7. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.2.7** **(08-09-2022)**

#### Delegation Order TEGE 6-3-1, Delegation of Authority in Labor-Management Relations Matters

1. **Delegation of Authority in Labor-Management Relations Matters**

2. **Authority:** The authority to:



1. Negotiate basic agreements after prior consultation with the Director, Human Resources Division, and/or Director, Strategic Human Resources or his/her designee;

2. Negotiate local supplemental agreements subject to the terms of any controlling master agreement; and

3. Consult, as appropriate, regarding local issues affecting only the immediate appointing office.


3. **Delegated to:** Director, Shared Services.

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 6-3, dated October 4, 1990.

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes TE/GE Divisional Delegation Order 41, dated October 17, 2003.

7. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.2.8** **(05-31-2022)**

#### Delegation Order TEGE 6-22-1, Authority to Approve Monetary and Time-Off Performance Awards, Performance Bonuses, Individual and Group Special Act Awards, Managers’ Awards, Bilingual Awards, Honorary Awards, Employee Suggestion Awards, Informal Recognition, and Quality Step Increases

01. **Authority to Approve Monetary and Time-Off Performance Awards, Performance Bonuses, Individual and Group Special Act Awards, Managers’ Awards, Bilingual Awards, Honorary Awards, Employee Suggestion Awards, Informal Recognition, and Quality Step Increases**

02. **Authority:** To approve



    1. Performance Awards1 not to exceed the lesser of $10,000 or 10%2 of the employee’s annual rate of basic pay (which must include any applicable locality payment under 5 Code of Federal Regulations (CFR) Part 531);



       > 1\. Exception: Bargaining unit employees’ performance awards are approved per the relevant National Agreement and the National Performance Awards Agreement (NPAA), in effect at the time of the awards payout, and are not subject to any other approvals except employee misconduct screening, tax compliance screening, and tax compliance review. These awards must be initiated, approved, or adjusted in compliance with NPAA program requirements.





       > 2\. The 10% limit is imposed by 5 USC 4505a(a)(2)(A). However, the Code permits exceptions up to not more than 20% of the annual rate of basic pay. See IRM 6.451.1, Awards and Recognition, for information on requesting exceptions to the 10% limit.

    2. Special Act, Service, or Superior Accomplishment Awards not to exceed $10,000;

    3. Employee Suggestion Awards not to exceed $10,000; and,

    4. Group Awards in an amount not to exceed $50,000 for the group, provided that no individual employee in the group is granted more than $10,000.


03. **Delegated to:** Supervisors no lower than three levels above that of the employee being recommended (where that level exists in an organization).

04. **Redelegation:** This authority may not be redelegated.

05. **Authority:** To approve:



    1. Performance Awards not to exceed the lesser of $3,500 or 10% of the employee’s annual rate of basic pay (which must include any applicable locality payment under 5 CFR Part 531);

    2. Individual Performance Bonuses for employees rated in the IRS Payband System per current IR Performance Bonus guidance;

    3. Special Act, Service, or Superior Accomplishment Awards not to exceed $3,500;

    4. Group Awards in an amount not to exceed $20,000 for the group, provided that no individual in the group is granted more than $3,500;

    5. Managers’ Awards from $251 to $500;

    6. Employee Suggestion Awards not to exceed $3,500; and

    7. Bilingual Awards in amounts permitted by IRS policy and applicable negotiated agreements.


06. Supervisors no lower than two levels above that of the employee being recommended (where that level exists in an organization).

07. **Redelegation:** This authority may not be redelegated.

08. **Authority:** To approve Quality Step Increases

09. **Delegated to:** Managers not lower than a member of the SES or SES-in-Waiting (SIW).

10. **Redelegation:** This authority may not be redelegated.

11. **Source of Authority:** Servicewide Delegation Order 6-22, dated June 28, 2019.

12. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes TE/GE Divisional Delegation Order 9 (Rev. 1), dated December 5, 1999.

13. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.2.9** **(04-17-2020)**

#### Delegation Order TEGE 7-1-1, Issuance of Determination Letters relating to Employee Plans

01. **Issuance of Determination Letters relating to Employee Plans**

02. **Authority:** To issue favorable determination letters and, where the facts so indicate, notices of proposed adverse determination in accordance with the currently applicable revenue procedure that sets forth the procedures of the various offices of the Internal Revenue Service for issuing determination letters on the qualified status of pension, profit-sharing, stock bonus, annuity, and employee stock ownership plans (ESOPs) under sections 401, 403(a), 409 and 4975(e)(7) of the Internal Revenue Code of 1986, and the status for exemption of any related trusts or custodial accounts under section 501(a), provided that the determination does not involve application of section 502 (feeder organizations) or section 511 (unrelated business income).

03. **Delegated to:** Internal Revenue Agent, GS–5, or Tax Law Specialist, GS–11.

04. **Redelegation:** This authority may not be redelegated.

05. **Authority:** To issue final adverse determination letters, provided that: (1) with respect to the notice of proposed adverse determination, the U.S. Tax Court has not issued a contrary judgment under the declaratory judgment procedure described in section 7476 of the Code, (2) technical advice has not been received indicating that a final adverse determination letter should not be issued, and (3) if the TE/GE Division Commissioner has required pre-issuance review of final adverse determination letters, such issuance has been approved.

06. **Delegated to:** Manager, EP Technical; Manager, EP Examinations Mandatory Review; Manager, EP Determinations Quality Assurance; and EP Area Managers.

07. **Redelegation:** This authority may not be redelegated.

08. **Source of Authority:** Servicewide Delegation Order 7-1 (Rev. 1), dated October 12, 2018.

09. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes TE/GE Divisional Delegation Order 14, dated December 5, 1999.

10. Signed: Tamera L. Ripperda, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.2.10** **(09-24-2020)**

#### Delegation Order TEGE 7-2-1, Authority to Issue Exempt Organization Determination Letters

1. **Authority to Issue Exempt Organization Determination Letters**

2. **Authority:** To issue determination letters based on the provisions of the Code, Regulations, Treasury decisions, or on a ruling, opinion, or court decision and pertaining to the following:



1. The exempt status of organizations under section 501(a) (other than under section 401 (a)) and 521 except in the case of an organization under the jurisdiction of Appeals.

2. An organization’s status under section 507, 508, 509, 4940(d)(2), 4942(g)(2), 4942(j)(3), 4945(f), 4945(g), 4947, 4948, 6033 and eligibility to receive deductible contributions under sections 170(c)(2) through 170(c)(5).

3. Withholding of information from public inspection under section 6104(a)(1)(D).


3. **Delegated to:** Exempt Organizations Specialist, Grade–11.

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 7-2 (Rev. 2), dated April 6, 2020.

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes TE/GE Divisional Delegation Order 18 (Rev. 2), dated December 5, 1999.

7. Signed: Tamera L. Ripperda, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.2.11** **(09-24-2020)**

#### Delegation Order TEGE 7-4-1, Authority to Extend the Correction Period and the Allowable Distribution Period Relating to Private Foundation Matters

1. **Authority to Extend the Correction Period and the Allowable Distribution Period Relating to Private Foundation Matters**

2. **Authority:** To extend the correction period for acts of self-dealing under IRC 4941, failures to distribute income under IRC 4942, excess business holdings under IRC 4943, investments which jeopardize charitable purpose under IRC 4944 and taxable expenditures under IRC 4945; and to extend the allowable distribution period for failures to distribute income under IRC 4942.

3. **Delegated to:** Exempt Organizations Group Managers.

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 7-4 (Rev. 1), dated October 12, 2018.

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes TE/GE Divisional Delegation Order 20 (Rev. 1), dated December 5, 1999.

7. Signed: Tamera L. Ripperda, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.2.12** **(07-14-2017)**

#### Delegation Order TEGE 7-7-1 (Rev. 1), Delegation of Authority for Waiver of Excise Taxes Imposed Under Section 4971(b) of the Internal Revenue Code

01. **Delegation of Authority for Waiver of Excise Taxes Imposed Under Section 4971(b) of the Internal Revenue Code**

02. **Authority:** To waive all or part of the 100% excise tax imposed under IRC 4971(b) for waivers of the additional tax liability resulting from an accumulated funding deficiency of less than $50 million.

03. **Delegated to:** Director, EP Examinations and Director, EP Rulings and Agreements.

04. **Redelegation:** This authority may not be redelegated.

05. **Authority:** To waive all or part of the 100% excise tax imposed under IRC 4971(b) for waivers of the additional tax liability resulting from an accumulated funding deficiency of $5 million or less.

06. **Delegated to:** EP Examinations Area Managers and the Manager, EP Technical

07. **Redelegation:** This authority may not be redelegated.

08. **Source of Authority:** Servicewide Delegation Order 7-7 (Rev. 1), dated July 13, 2017.

09. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes TE/GE Delegation Order 7-7-1, dated March 18, 2008.

10. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.2.13** **(09-24-2020)**

#### Delegation Order TEGE 7-15-1, Revocation of Exemption of Certain Governmental Plans or Church Plans that have engaged in Prohibited Transactions

1. **Revocation of Exemption of Certain Governmental Plans or Church Plans that have engaged in Prohibited Transactions**

2. **Authority:** To determine that a governmental plan or church plan referred to in section 4975(g)(2) or (3) of the Code has engaged in a prohibited transaction under section 503 and to notify such plan in writing of the revocation of exemption and of the requalification for exemption after the plan establishes that it will not knowingly again engage in a prohibited transaction and that it also satisfies all applicable requirements of section 401(a).

3. **Delegated to:** For revocation to Director, EP Examinations; for requalification to Director, EP Rulings & Agreements.

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 7-15 (formerly DO-7-1c), dated June 15, 2020.

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes TE/GE Divisional Delegation Order 15 (Rev. 1), dated December 5, 1999.

7. Signed: Tamera L. Ripperda, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.2.14** **(09-24-2020)**

#### Delegation Order TEGE 7-16-1, Amendment of Employee Plans after the Expiration of the Remedial Amendment Period

1. **Amendment of Employee Plans after the Expiration of the Remedial Amendment Period**

2. **Authority:** To allow a plan to be amended after the expiration of its remedial amendment period described in section 401(b) of the Code for any plan year in which a request for a determination letter is made or is pending with the Service, and for the plan year prior to the plan year in which the plan is submitted for a determination letter if the plan is submitted by the end of the time for filing the tax return of the employer (including extensions) for the taxable year of the employer beginning with or within that prior plan year, provided that the following conditions are met: (1) the plan is retroactively amended to comply with the qualification requirements as of the time the defect in the plan arose, and (2) employee benefit rights are retroactively restored to the levels they would have been at had the plan been in compliance with the qualification requirements from the date the defect in the plan arose.

3. **Delegated to:** EP Determinations Area Managers.

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 7-16, dated December 20, 2018.

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes TE/GE Divisional Delegation Order 16 (Rev. 1), dated December 5, 1999.

7. Signed: Tamera L. Ripperda, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.2.15** **(08-09-2022)**

#### Delegation Order TEGE 11-2-1, Delegation of Authority to Permit Disclosure of Tax Information and to Permit Testimony or the Production of Documents

1. **Delegation of Authority to Permit Disclosure of Tax Information and to Permit Testimony or the Production of Documents**

2. **Authority:** To permit the disclosure of returns and return information and to permit testimony or the production of documents under the authority vested in the Commissioner of Internal Revenue and the Chief Counsel to act in matters officially before their respective functions, as described in D.O. 11-2 (Rev. 3), Exhibit 1.2.2-2 (03-07-2017) is redelegated as follows:

3. **Delegated to:**



> .01 The authority described in IRC sections 6103(h)(2) and 6103(h)(3)(A) to make certain disclosures to the Department of Justice is redelegated to TE/GE Group Managers.





> .02 The authority described in IRC section 6103(l)(1)(B) to make certain disclosures to the Social Security Administration for administration of section 1131 of the Social Security Act (ERISA), is redelegated to:
>
>    - Employee Plans Group Managers
>
>    - TE/GE employees to the extent necessary to perform their official duties





> .03 The authority described in IRC section 6103(l)(2) to make certain disclosures to the Department of Labor and the Pension Benefit Guaranty Corporation is redelegated to TE/GE Group Managers responsible for ERISA matters.
>
> ### Note:
>
> The authority to disclose does not require that the approving official transmit the information. Assuming that the proper official under this order has approved the disclosure, through either a separate written agreement or on a case-by-case basis, the transmittal can be made by appropriate staff of the office involved. Under both procedures, the authorizing official’s approval should be documented in writing.

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 11-2 (Rev. 3), dated March 7, 2017.

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes TE/GE Divisional Delegation Order 21 (Rev. 1), dated December 5, 1999.

7. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.3** **(09-22-2022)**

### Rescinded TE/GE Division Delegations of Authority

1. TE/GE Rescinded Division Delegation Orders approved after this revision of the IRM can be found at: [https://www.irs.gov/uac/recently-approved-division-function-delegation-orders](https://www.irs.gov/uac/recently-approved-division-function-delegation-orders); all documents are maintained on the web site until the next IRM revision.


**1.2.68.3.1** **(05-25-2022)**

#### Delegation Order TE/GE Order No. 1 (Rev. 1), Delegation of Authority in Settlement of Tort Claims, Claims under the Small Claims Act, and Claims Made by an Employee of the Internal Revenue Service for Damage to or Loss of Personal Property Incident to Service

1. **Delegation of Authority in Settlement of Tort Claims, Claims under the Small Claims Act, and Claims Made by an Employee of the Internal Revenue Service for Damage to or Loss of Personal Property Incident to Service**

2. This TE/GE divisional delegation order is rescinded. The authority to consider, ascertain, adjust, and determine under 31 USC 3723 claims for reimbursement of bank charges arising out of erroneous Service levies and out of Direct Debit Installment Agreement processing errors are already at the lowest level for the TE/GE Division as stated in Servicewide Delegation Order 1-4 (Rev. 1), dated January 13, 2011.

3. This order rescinds TE/GE Divisional Delegation Order 1 (Rev. 1), dated December 5, 1999.

4. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.3.2** **(05-25-2022)**

#### Delegation Order TE/GE Order No. 2 (Rev. 1), Delegation of Authority to Require Record Keeping

1. **Delegation of Authority to Require Record Keeping**

2. This TE/GE divisional delegation order is rescinded. The authority to require any person, by notice served them, to keep records reflecting whether or not the person is liable for tax is at the lowest level for the TE/GE Division as stated in Servicewide Delegation Order 4-37 (Rev. 1), Recordkeeping Requirement, dated January 30, 2012.

3. This order rescinds TE/GE Divisional Delegation Order 2 (Rev. 1), dated December 5, 1999.

4. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.3.3** **(07-15-2022)**

#### Delegation Order TE/GE Order No. 4 (Rev. 1), Delegation of Authority for Agreements Treated as Determinations

1. **Delegation of Authority for Agreements Treated as Determinations**

2. This TE/GE divisional delegation order is rescinded. The authority to enter into agreements treated as determinations under IRC section 1313(a)(4) is at the lowest authority level as stated in Servicewide Delegation Order 4-5, Agreements Treated as Determinations, dated May 12, 1997.

3. This order rescinds TE/GE Divisional Delegation Order 4 (Rev. 1), dated December 5, 1999.

4. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.3.4** **(07-14-2022)**

#### Delegation Order TE/GE Order No. 5 (Rev. 1), Delegation of Authority for Tours of Duty

1. **Delegation of Authority for Tours of Duty**

2. This TE/GE divisional delegation order is rescinded. The authority to approve tours of duty (TODs) (including flexible and compressed work schedules) and variances to the TOD for operating conditions (i.e., a basic 40-hour workweek on five days other than Monday through Friday when necessitated by operating requirements); religious conviction; or educational purposes is at the lowest authority level as stated in Servicewide Delegation Order 6-11 (Rev. 2), Hours of Work, dated June 28, 2021.

3. This order rescinds TE/GE Divisional Delegation Order 5 (Rev. 1), dated December 5, 1999.

4. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.3.5** **(07-15-2022)**

#### Delegation Order TE/GE Order No. 6 (Rev. 1), Delegation of Authority to Execute Consents Fixing the Period of Limitations on Assessment or Collection Under Provisions of the 1939, 1954 and 1986 Internal Revenue Code

1. **Delegation of Authority to Execute Consents Fixing the Period of Limitations on Assessment or Collection Under Provisions of the 1939, 1954 and 1986 Internal Revenue Code**

2. This TE/GE divisional delegation order is rescinded. The authority to sign agreements extending the period of limitations on assessment except agreements to extend the period of limitations on the assessment of the Trust Fund Recovery Penalty or agreements to extend the period of limitations on assessment submitted in connection with an offer in compromise is at the lowest authority level as stated in Servicewide Delegation Order 25-2 (Rev. 3), Authority to Execute Agreements to Extend the Period of Limitations on Assessment or Collection and to Accept Form 900, Tax Collection Waiver, dated March 28, 2019.

3. This order rescinds TE/GE Divisional Delegation Order 6 (Rev. 1), dated December 5, 1999.

4. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.3.6** **(07-15-2022)**

#### Delegation Order TE/GE Order No. 10 (Rev. 3), Delegation of Authority to Authorize or Approve Travel, Travel Advances, and Transportation Services, and to Approve Travel Vouchers

1. **Delegation of Authority to Authorize or Approve Travel, Travel Advances, and Transportation Services, and to Approve Travel Vouchers**

2. This TE/GE divisional delegation order is rescinded. The authority to authorize and approve official travel (including travel authorizations, travel advances, travel vouchers and travel and transportation payments for emergency purposes) for travel within the United States and its territories and possessions in accordance with the Federal Travel Regulation, IRM 1.32.1, IRS Local Travel Guide; and IRM 1.32.11, IRS City-to-City Travel Guide is at the lowest authority level (managers) as stated in Servicewide Delegation Order 1-30 (Rev. 2), Authorization and Approval of Official Travel within the United States, dated September 25, 2019.

3. The authority to approve the use of non-contract air carriers rather than contract air carriers between city-pairs when justified in accordance with the Federal Travel Regulation and IRM 1.32.11, Official IRS City-to-City Travel Guide is at the lowest authority level (managers) as stated in Servicewide Delegation Order 1-35 (Rev. 2), Authority to Approve the Use of Non-Contract Air Carriers, dated June 5, 2012.

4. The authority to authorize official invitational travel and approve associated travel vouchers in accordance with the Federal Travel Regulation and IRM 1.32.1, Official IRS Travel Guide is at the lowest authority level (Deputy Division Commissioner) as stated in Servicewide Delegation Order 1-10 (Rev. 1), Invitational Travel, dated November 28, 2011, (formerly DO 1-36, dated April 7, 2003) for:



1. Individuals either not employed or employed intermittently in the Government as consultants or experts and paid on a daily basis when actually employed.

2. Individuals serving without pay or at a rate of $1 per year when acting in a capacity that is directly related to or in connection with official activities of the Government.


5. This order rescinds TE/GE Divisional Delegation Order 10 (Rev. 3), dated May 20, 2009.

6. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.3.7** **(08-24-2022)**

#### Delegation Order TE/GE Order No. 11 (Rev. 2), Delegation of Authority to Enter Into and Approve Closing Agreements Concerning Internal Revenue Tax Liability

1. **Delegation of Authority to Enter Into and Approve Closing Agreements Concerning Internal Revenue Tax Liability**

2. This TE/GE divisional delegation order is rescinded. The authority to enter into and approve a written agreement is at the lowest level for the TE/GE Division as stated in Servicewide Delegation Order 8-3, Closing Agreements Concerning Internal Revenue Tax Liability, dated August 18, 1997.

3. This order rescinds TE/GE Divisional Delegation Order 11 (Rev. 2), dated December 6, 1999.

4. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.3.8** **(05-31-2022)**

#### Delegation Order TE/GE Order No. 12 (Rev. 1), Furnishing Special Statistical Studies, Compilations, Return and Return Information, Training, and Training Aids

1. **Furnishing Special Statistical Studies, Compilations, Return and Return Information, Training, and Training Aids**

2. This TE/GE divisional delegation order is rescinded. The authority to enter into contracts to furnish information on a reimbursable basis under 26 USC 6103 is already at the lowest level for the TE/GE Division as stated in Servicewide Delegation Order 1-13 dated April 3, 1991. Upon written request by any person and agreement by such person to pay the cost of work to be performed, the \[Chief Inspector or the Assistant Commissioner\] having functional responsibility over the resources to be utilized in filling this request may authorize the providing of services or the furnishing of return and return information upon determination by the Commissioner or his/her delegate that information to be furnished is disclosable under 26 USC 6103. Any return or return information (as defined in 26 USC 6103(b)(1) and (2)) provided under this paragraph is subject to disclosure laws, regulations, and internal operating instructions covering 26 USC 6103. Joint authorization may be appropriate if filling the request requires utilization of resources in more than one functional area.



### Note:



This authority is also delegated to Assistant Deputy Commissioners, Division Commissioners; equivalent-level Director of Strategy, Research and Program Planning; or equivalent position under the jurisdiction of the Division Commissioner. This authority may not be redelegated below the level of Division Director or equivalent level position.

3. This order rescinds TE/GE Divisional Delegation Order 12 (Rev. 1), dated December 5, 1999.

4. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.3.9** **(07-15-2022)**

#### Delegation Order TE/GE Order No. 13 (Rev. 2), Delegation of Authority to Charge Absence and Leave

1. **Delegation of Authority to Charge Absence and Leave**

2. This TE/GE divisional delegation order is rescinded. The authority to charge and approve absence and leave (all types) is at the lowest authority level as stated in Servicewide Delegation Order 6-12 (Rev. 2), Absence and Leave, dated February 1, 2021.

3. This order rescinds TE/GE Divisional Delegation Order 13 (Rev. 2), dated December 5, 1999.

4. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.3.10** **(11-28-2021)**

#### Delegation Order TE/GE Order No. 17 (Rev. 1), Issuance of Examination Reports

1. **Issuance of Examination Reports**

2. This TE/GE divisional delegation order is rescinded. The authority to issue examination reports is inherent in the standard position descriptions for revenue agents and tax law specialists (e.g., an employee plans internal revenue agent "performs independent examinations of employee plans" ). The Servicewide Delegation Order 7-1e (the source authority to TE/GE-17 (Rev. 1)) was rescinded effective December 20, 2018.

3. This order rescinds TE/GE Divisional Delegation Order 17 (Rev. 1), dated December 5, 1999.

4. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.3.11** **(11-28-2021)**

#### Delegation Order TE/GE Order No. 19 (Rev. 1), Church Tax Inquiries and Examinations

1. **Church Tax Inquiries and Examinations**

2. This TE/GE divisional delegation order is rescinded. Servicewide Delegation Order 7-3 (Rev. 2) dated June 23, 2020, directly delegated the authority to the lowest level and therefore, the TE/GE Divisional Delegation Order is not needed.

3. This order rescinds TE/GE Divisional Delegation Order 19 (Rev. 1), dated December 5, 1999.

4. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.3.12** **(11-28-2021)**

#### Delegation Order TE/GE Order No. 22 (Rev. 1), Requests for Variance from Minimum Funding Standards or Waiver of Accumulated Funding Deficiency

1. **Requests for Variance from Minimum Funding Standards or Waiver of Accumulated Funding Deficiency**

2. This TE/GE divisional delegation order is rescinded. On January 2, 2015, the work listed in Delegation Order 7-5 (formerly DO-159, Rev. 6) was moved to Chief Counsel as part of the TE/GE-Chief Counsel realignment and is covered under Chief Counsel authority in Delegation Order 30-7, Delegation of Legal Authority to the Office of Chief Counsel, dated November 20, 2014. Therefore, Delegation Order 7-5 (the source authority for TE/GE-22 (Rev. 1)) was rescinded effective November 29, 2018.

3. This order rescinds TE/GE Divisional Delegation Order 22 (Rev. 1), dated December 5, 1999.

4. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.3.13** **(08-03-2022)**

#### Delegation Order TE/GE Order No. 26 (Rev. 1), Delegation of Authority for Authority to Designate Qualified General Assistance Programs Described in Section 51(d)(6) of the Internal Revenue Code

1. **Delegation of Authority for Authority to Designate Qualified General Assistance Programs Described in Section 51(d)(6) of the Internal Revenue Code**

2. This TE/GE divisional delegation order is rescinded. The authority from which TE/GE Delegation Order 26 (Rev. 1) was derived, Commissioner’s Delegation Order No. 181 (Rev. 1), dated October 31, 1987, which converted to Delegation Order 4-38 dated October 12, 2010, no longer included a provision for a General Assistance Program Determination. The Servicewide Delegation Order 4-38, Delegation of Authority for Authority to Designate Qualified General Assistance Programs Described in Section 51(d)(6) of the Internal Revenue Code, was rescinded by Steven T. Miller, Deputy Commissioner for Services and Enforcement on September 19, 2012. Without a Servicewide authority, the divisional delegation order cannot exist.

3. Therefore, this order rescinds TE/GE Divisional Delegation Order 26 (Rev. 1), dated December 5, 1999.

4. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.3.14** **(07-22-2022)**

#### Delegation Order TE/GE Order No. 27 (Rev. 1), Delegation of Authority to Grant Case by Case Exemptions to the Financial Conflict of Interest Provision in 18 USC Subsection 208(a)

1. **Delegation of Authority to Grant Case by Case Exemptions to the Financial Conflict of Interest Provision in 18 USC Subsection 208(a)**

2. This TE/GE divisional delegation order is rescinded. The authority is to make written determinations under 18 USC subsection 208(b)(1) that the financial interest of an employee is not so substantial as to be deemed likely to affect the integrity of the services which the Government may expect from such employee if the employee participates personally and substantially in a matter in which the employee has a financial interest. Such determinations may be made only with the coordination and affirmative legal opinion of the Deputy Ethics Official or delegate, who is responsible for assuring compliance with the waiver procedures at 5 CFR Part 2640 (Subpart C) is at the lowest authority level as stated in Servicewide Delegation Order 1-21, Authorization to Grant Case by Case Exemptions to the Financial Conflict of Interest Provision in 18 USC Subsection 208(a) dated October 2, 2003.

3. This order rescinds TE/GE Divisional Delegation Order 27 (Rev. 1), dated December 5, 1999.

4. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.3.15** **(08-03-2022)**

#### Delegation Order TE/GE Order No. 28 (Rev. 2), Delegation of Authority to Authorize Travel Not at Government Expense

1. **Delegation of Authority to Authorize Travel Not at Government Expense**

2. This TE/GE divisional delegation order is rescinded. The authority to approve “requests to participate in or attend tax forums and continuing professional education programs where reasonable expenses for travel, lodging, and meals are to be paid or reimbursed by any state, county, or municipal agency or by a 501(c)(3) organization must be approved by the Deputy Commissioner, TE/GE, after General Legal Services has conducted a conflict of interest analysis” is not based on a Servicewide Delegation Order, but based on an Official IRS Travel Guide, IRM 1.32.1.2.7, dated September 1, 2006, which has been deleted from IRM 1.32.1, Servicewide Financial Policies and Procedures, Official IRS Local Travel Guide, dated February 7, 2012. The authority from which TE/GE DO 28 (Rev. 2) derived its authority no longer exists, therefore, the TE/GE Divisional Delegation Order cannot exist.

3. Therefore, this order rescinds TE/GE Divisional Delegation Order 28 (Rev. 2), dated May 3, 2007.

4. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.3.16** **(07-15-2022)**

#### Delegation Order TE/GE Order No. 29 (Rev. 1), Delegation of Authority to Abate Interest Due to IRS Error or Delay

1. **Delegation of Authority to Abate Interest Due to IRS Error or Delay**

2. This TE/GE divisional delegation order is rescinded. The authority to abate assessed and unassessed interest attributable to unreasonable error or delay by the IRS when the amount of interest to be abated does not exceed $2,500 is at the lowest authority level as stated in Servicewide Delegation Order 20-1 (Rev. 2), Abatement of Interest, dated October 25, 2012.

3. This order rescinds TE/GE Divisional Delegation Order 29 (Rev. 1), dated December 5, 1999.

4. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.3.17** **(11-28-2021)**

#### Delegation Order TE/GE Order No. 30 (Rev. 1), Voluntary Correction Program

1. **Voluntary Correction Program**

2. This TE/GE divisional delegation order is rescinded. Servicewide Delegation Order 7-12 (Rev. 1), dated October 18, 2019, directly delegated the authority to the lowest level and therefore, the TE/GE Divisional Delegation Order is not needed.

3. This order rescinds TE/GE Divisional Delegation Order 30 (Rev. 1), dated December 5, 1999.

4. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.3.18** **(08-03-2022)**

#### Delegation Order TE/GE Order No. 31 (Rev. 1), Delegation of Authority Overtime

1. **Delegation of Authority Overtime**

2. This TE/GE divisional delegation order is rescinded. The authority to order or approve the performance of paid overtime duty, work on holidays, and performance of overtime duty for which compensatory time off will be granted in lieu of overtime pay is at the lowest authority level as stated in Servicewide Delegation Order 6-23 (Rev. 1), Authority 7, Delegations of Authority to Accomplish Pay Administration, dated December 10, 2020.

3. This order rescinds TE/GE Divisional Delegation Order 31 (Rev. 1), dated December 5, 1999.

4. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.3.19** **(07-15-2022)**

#### Delegation Order TE/GE Order No. 32, Delegation of Authority for Certification of Time and Attendance

1. **Delegation of Authority for Certification of Time and Attendance**

2. This TE/GE divisional delegation order is rescinded. The authority to charge and approve absence and leave (all types) is at the lowest authority level as stated in Servicewide Delegation Order 6-13 (Rev. 2), Authority to Certify Time and Attendance Records, dated March 12, 2020.

3. This order rescinds TE/GE Divisional Delegation Order 32, dated December 5, 1999.

4. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.3.20** **(08-03-2022)**

#### Delegation Order TE/GE Order No. 33 (Rev. 1), Authorization to Engage in Outside Employment, Business, and Other Activities

1. **Authorization to Engage in Outside Employment, Business, and Other Activities**

2. This TE/GE divisional delegation order is rescinded. The authority to approve requests to engage in permitted Outside Employment or Business Activities is at the lowest authority level as stated in Servicewide Delegation Order 6-4 (Rev. 1), dated November 18, 2020.

3. This order rescinds TE/GE Divisional Delegation Order 33 (Rev. 1), dated December 5, 1999.

4. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.3.21** **(07-15-2022)**

#### Delegation Order TE/GE Order No. 35, Authority to Issue Notices of Deficiency or Execute Agreements to Rescind Notices of Deficiency

1. **Authority to Issue Notices of Deficiency or Execute Agreements to Rescind Notices of Deficiency**

2. This TE/GE divisional delegation order is rescinded. The authority to sign and send to the taxpayer by registered or certified mail any notice of deficiency is at the lowest authority level as stated in Servicewide Delegation Order 4-8 (Rev. 2), Authority to Issue Notices of Deficiency or Execute Agreements to Rescind Notices of Deficiency, dated December 7, 2020.

3. This order rescinds TE/GE Divisional Delegation Order 35, dated December 14, 2001.

4. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.3.22** **(11-28-2021)**

#### Delegation Order TE/GE Order No. 38 (Rev. 1), Determination if Plan Amendment is Reasonable and Has De Minimis Effect on Plan Liability

1. **Determination if Plan Amendment is Reasonable and Has De Minimis Effect on Plan Liability**

2. This TE/GE divisional delegation order is rescinded. Servicewide Delegation Order 7-9 (Rev. 1), dated February 14, 2019, directly delegated the authority to the lowest level and therefore, the TE/GE Divisional Delegation Order is not needed.

3. This order rescinds TE/GE Divisional Delegation Order 38 (Rev. 1), dated December 14, 2001.

4. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.3.23** **(11-28-2021)**

#### Delegation Order TE/GE Order No. 39 (Rev. 1), Extension of Amortization Period of Plans

1. **Extension of Amortization Period of Plans**

2. This TE/GE divisional delegation order is rescinded. Servicewide Delegation Order 7-10 (Rev. 1), dated February 14, 2019, directly delegated the authority to the lowest level and therefore, the TE/GE Divisional Delegation Order is not needed.

3. This order rescinds TE/GE Divisional Delegation Order 39 (Rev. 1), dated December 14, 2001.

4. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.3.24** **(08-08-2022)**

#### Delegation Order TE/GE Order No. 40, Delegation of Authority to Approve Superior Qualification Appointments

1. **Delegation of Authority to Approve Superior Qualification Appointments**

2. This TE/GE divisional delegation order is rescinded. The authority to approve an appointment made at a rate above the minimum rate of the appropriate General Schedule because of the superior qualifications of a candidate or the special need of the agency for the candidate’s services is at the lowest authority level as stated in Servicewide Delegation Order 6-23, (Rev. 1), Delegations of Authority to Accomplish Pay Administration, dated December 10, 2020, Authority 20, and may not be re-delegated.

3. This order rescinds TE/GE Divisional Delegation Order 40, issued May 5, 2002 and effective October 1, 2000.

4. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.3.25** **(08-08-2022)**

#### Delegation Order TE/GE Order No. 42, Delegation of Authority to Review/Approve the Instructor Allowance Certification of an Instructor who Meets the Criteria to receive a Six-Percent Retention Allowance

1. **Delegation of Authority to Review/Approve the Instructor Allowance Certification of an Instructor who Meets the Criteria to receive a Six-Percent Retention Allowance**

2. This TE/GE divisional delegation order is rescinded. The authority to approve “approve 6% Instructor Retention Allowances for eligible instructors who have completed a training assignment outside the employee’s normal commuting area” is not based on a Servicewide Delegation Order but based on an authority in the Strategic Human Resources Policy # 32, in accordance with the IRS and NTEU National Agreement, Article 30, Subsection 6B, dated 8/2002. The authority from which TE/GE DO 42 derived its authority was removed from the National Agreement in 2009 and no longer exists, therefore, the TE/GE Divisional Delegation Order cannot exist.

3. This order rescinds TE/GE Divisional Delegation Order 42, dated May 23, 2003.

4. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


**1.2.68.3.26** **(08-03-2022)**

#### Delegation Order TE/GE Order No. 44 (Rev. 1), Delegation of Authority to Reimbursement for Actual Expenses

1. **Delegation of Authority to Reimbursement for Actual Expenses**

2. This TE/GE divisional delegation order is rescinded. The authority to authorize and approve reimbursement for subsistence on an actual expense basis in accordance with the Federal Travel Regulation and IRM 1.32.11, Official IRS City-to-City Travel Guide is at the lowest authority level as stated in Servicewide Delegation Order 1-5 (Rev. 2), Reimbursement for Actual Expenses, dated August 14, 2012.

3. This order rescinds TE/GE Divisional Delegation Order 44 (Rev. 1), dated October 4, 2007.

4. Signed: Sunita B. Lough, Commissioner, Tax Exempt and Government Entities Division


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-002-068#addtoany "Show all")

A2A