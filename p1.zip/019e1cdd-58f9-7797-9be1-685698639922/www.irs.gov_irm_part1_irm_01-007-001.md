---
url: "https://www.irs.gov/irm/part1/irm_01-007-001"
title: "1.7.1 Servicewide Research for Tax Administration | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-007-001#main-content)

- 1.7.1  [Servicewide Research for Tax Administration](https://www.irs.gov/irm/part1/irm_01-007-001#idm139833528699104)
  - 1.7.1.1  [Purpose Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-007-001#idm139833555713680)
    - 1.7.1.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-007-001#idm139833555755152)
    - 1.7.1.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-007-001#idm139833560683984)
    - 1.7.1.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-007-001#idm139833555685232)
    - 1.7.1.1.4  [Program Measures and Controls](https://www.irs.gov/irm/part1/irm_01-007-001#idm139833555692912)
    - 1.7.1.1.5  [Terms/Definitions/Acronyms](https://www.irs.gov/irm/part1/irm_01-007-001#idm139833555689248)
    - 1.7.1.1.6  [Related Resources](https://www.irs.gov/irm/part1/irm_01-007-001#idm139833555671424)
  - 1.7.1.2  [IRS Research Program Management, Oversight and Coordination](https://www.irs.gov/irm/part1/irm_01-007-001#idm139833555667760)
    - 1.7.1.2.1  [Data and Analytics Strategic Integration Board Purpose and Scope](https://www.irs.gov/irm/part1/irm_01-007-001#idm139833555678288)
      - 1.7.1.2.1.1  [Data and Analytics Strategic Integration Board (DASIB) Membership](https://www.irs.gov/irm/part1/irm_01-007-001#idm139833526246368)
      - 1.7.1.2.1.2  [Data and Analytics Strategic Integration Board (DASIB) Logistics](https://www.irs.gov/irm/part1/irm_01-007-001#idm139833555822448)
    - 1.7.1.2.2  [Data and Analytics Advisory Group (DAAG) Purpose and Scope](https://www.irs.gov/irm/part1/irm_01-007-001#idm139833527921056)
      - 1.7.1.2.2.1  [Data and Analytics Advisory Group (DAAG) Membership](https://www.irs.gov/irm/part1/irm_01-007-001#idm139833528004816)
      - 1.7.1.2.2.2  [Data and Analytics Advisory Group (DAAG) Logistics](https://www.irs.gov/irm/part1/irm_01-007-001#idm139833527504576)
    - 1.7.1.2.3  [Research Directors Coordinating Council (RDCC) Purpose and Scope](https://www.irs.gov/irm/part1/irm_01-007-001#idm139833527601136)
      - 1.7.1.2.3.1  [RDCC Membership](https://www.irs.gov/irm/part1/irm_01-007-001#idm139833527595968)
      - 1.7.1.2.3.2  [RDCC Logistics](https://www.irs.gov/irm/part1/irm_01-007-001#idm139833527911568)
    - 1.7.1.2.4  [Data and Analytics Project Repository](https://www.irs.gov/irm/part1/irm_01-007-001#idm139833527909360)
    - 1.7.1.2.5  [Communities of Practice (CoP)](https://www.irs.gov/irm/part1/irm_01-007-001#idm139833527906192)
  - 1.7.1.3  [Research Data Standards and Scope](https://www.irs.gov/irm/part1/irm_01-007-001#idm139833527901232)
    - 1.7.1.3.1  [Data Standards](https://www.irs.gov/irm/part1/irm_01-007-001#idm139833528835536)
  - 1.7.1.4  [Retention of Research Studies](https://www.irs.gov/irm/part1/irm_01-007-001#idm139833528830000)

# Part 1. Organization, Finance, and Management

# Chapter 7. Research and Analysis for Tax Administration

# Section 1. Servicewide Research for Tax Administration

* * *

## 1.7.1 Servicewide Research for Tax Administration

#### Manual Transmittal

February 28, 2025

#### Purpose

(1) This transmits revised IRM 1.7.1, Research and Analysis for Tax Administration, Servicewide Research for Tax Administration.

#### Material Changes

(1) Changed Chief Research and Analytics Officer, Acting to Chief Data and Analytics Officer throughout the document to reflect the correct title.

(2) Changed Wage & Investment (W&I) to Taxpayer Services (TS) throughout the document to reflect the correct organizational title.

(3) IRM 1.7.1.1.6(1) – _Related Resources_ Updated the D&A Project Repository and Business Unit News links.

(4) IRM 1.7.1.2(5) – _IRS Research Program Management, Oversight and Coordination_ Updated the D&A Project Repository link.

(5) IRM 1.7.1.2.1.2(1) – _Data and Analytics Strategic Integration Board (DASIB) Logistics_ Updated the meeting reoccurrence.

(6) IRM 1.7.1.2.5(3) – _Community of Practice (CoP)_ added CoP mailbox for all inquiries.

#### Effect on Other Documents

This IRM supersedes IRM 1.7.1 dated August 12, 2020

#### Audience

Employees from all IRS organizations who conduct research.

#### Effective Date

(02-28-2025)

Barry W. Johnson

Chief Data and Analytics Officer

**1.7.1.1** **(02-28-2025)**

### Purpose Scope and Objectives

1. **Purpose:** This IRM provides information on research in the IRS, the research community, research standards and coordination and governance.

2. **Audience:** All IRS employees involved in research and analysis of IRS data.

3. **Policy Owner:** Research Applied Analytics and Statistics (RAAS).

4. **Program Owner:** Chief Data and Analytics Officer, RAAS.

5. **Primary Stakeholders:**



   - Research and analysis program offices and staff within RAAS

   - Large Business and International (LB&I)

   - Small Business/Self-Employed (SB/SE)

   - Tax Exempt & Government Entities (TE/GE)

   - Taxpayer Services (TS)

   - Criminal Investigation (CI)

   - Human Capital Office (HCO)

   - Office of the National Taxpayer Advocate (TAS)

   - Office of Online Services (OLS)


**1.7.1.1.1** **(08-12-2020)**

#### Background

1. Until the 1990s, research in IRS consisted of a headquarters Research Division and several smaller research offices serving functional Assistant Commissioners. The functional research units supported the field operations of those functions, and the Research Division focused on Servicewide issues, emerging technologies, and supporting the functional research units. An Analysis and Studies Division, operating under the Chief of Management and Administration, focused on human resources studies.

2. By the mid-1990s, all research units merged with the Research Division to become Compliance Research. District Offices of Research and Analysis (DORAs) were created to facilitate research of local compliance issues. Headquarters Compliance Research was split; part became the National Office Research and Analysis (NORA) Branch (which guided and coordinated the DORAs), another part became the Applied Research Branch, and the remainder became a Planning and Budget Branch. Although the DORAs reported to the District Directors, they received much direction from NORA.

3. When IRS was reorganized in 2000 into four major operating divisions and other additional functions, the DORAs were assigned to the various operating divisions, and NORA reverted to the NHQ Office of Research. After the reorganization, NHQ Research, the Office of Program Evaluation and Risk Analysis, the Statistics of Income Division, the National Research Program, and Servicewide Policy, Directives and Electronic Research were grouped together in the new Research, Analysis, and Statistics (RAS) organization.

4. In 2001, the Director of Research, Analysis, and Statistics (RAS) created the Servicewide Research Council (SRC). The SRC served as a forum for sharing information, coordinating crosscutting actions and resolving procedural issues that affect the execution of research and analysis across operating divisions. Additionally, the SRC served as a vehicle to reach mutual agreement on the use of common assets/projects intended to serve the entire research community, and also as the forum for resolving other issues related to research and analysis affecting high impact cross-divisional projects and initiatives. The SRC remained in effect until 2012.

5. In 2015, the Acting Director of RAS created a new Research & Analytics Planning and Coordination governance structure to replace the Servicewide Research Council. The mission of this new coordinating governance structure was similar to the SRC, however, the new governance structure enhanced the SRC by developing two new Councils of executives, namely the Research Directors Coordinating Council (RDCC) and the Research Policy and Planning (RP&P) Committee. Further, unlike the previous SRC, the new Research and Analytics Planning and Coordination governance structure also included a crowd-sourcing component, since the IRS Commissioner felt that one critical piece to the success of this new coordination model was to ensure that employees’ opinions related to better coordination, communication, and planning were included in the model.

6. In 2015, the Commissioner recognized a need to bring together the Research, Analysis and Statistics Organization and the Office of Compliance Analytics to foster better collaboration of research efforts across the service. In November 2016, Research, Applied Analytics, and Statistics (RAAS) officially stood up as an organization.

7. In 2019, the Data and Analytics (D&A) Operating Model was established to position the organization to better leverage both data and analytics to drive operations. Through the D&A Operating Model, the Data and Analytics Strategic Integration Board (DASIB) and the Data and Analytics Advisory Group (DAAG) were created to bring together cross-functional working groups of D&A leaders and staff from across the Service to analyze the current state, define the target state, and develop strategies to enable the Service to achieve D&A goals. With the new D&A governing structure, the RP&P and the RDCC were decommissioned and the RDCC became one of the advisory councils within the DAAG.


**1.7.1.1.2** **(08-12-2020)**

#### Authority

1. Policy Statement 1-3 governs IRS research activities. The guidance in this IRM section conforms with Policy Statement 1-3 establishing the foundation for research in the IRS; the collection and analysis of data related to Service operations and strategic goals is essential in sound planning, management and evaluation of Service programs and activities. Studies, tests and research activities are conducted within the headquarter research function, RAAS, and within the operating divisions. See IRM 1.2.1.2.3.


**1.7.1.1.3** **(08-12-2020)**

#### Roles and Responsibilities

1. RAAS has general program oversight of research activities in IRS.

2. Chief, Data and Analytics Officer in RAAS is responsible for coordination of research within the IRS and research conducted within the RAAS organization.

3. Senior executives in each organization are responsible for conducting and managing research within their organizations.

4. Data and Analytics Strategic Integration Board (DASIB) develops and communicates enterprise D&A strategy and provides strategic oversight and direction of the approved D&A investments.

5. Data and Analytics Advisory Group (DAAG) facilitates the execution of the D&A strategy and accelerates analytcal outcomes through enterprise integration.

6. RAAS, Project Management Office (PMO) is responsible for managing the Data and Analytics project repository, which is an online inventory system of all IRS research projects.

7. IRS Research Community - Employees who work in the research community throughout the IRS are responsible for following the data standards described in _IRM 1.7.1.3.1_, Data Standards.


**1.7.1.1.4** **(08-12-2020)**

#### Program Measures and Controls

1. IRS Data and Analytics (D&A) repository is used to catalog IRS research project inventory.

2. IRS research data standards in _IRM 1.7.1.3.1_ are used to ensure consistent data research within the IRS. Research staff within the IRS and contractors must use tested, validated and documented data to ensure analysis is proper, reliable and accomplished in accordance with stakeholder and customer expectations. Research staff must also ensure that standards are in place and followed that limit and control access to taxpayer data and protect taxpayer privacy. IRS research staff are to follow data standards in _IRM 1.7.1.3.1_.


**1.7.1.1.5** **(08-12-2020)**

#### Terms/Definitions/Acronyms

1. The following are common terms used in this IRM section:




| Acronym | Term |
| --- | --- |
| CoE | Center of Excellence |
| CoP | Community of Practice |
| PMO | Project Management Office |
| D&A | Data and Analytics |
| RAS | Research, Analysis, and Statistics |
| RAAS | Research, Applied Analytics and Statistics |
| SRC | Servicewide Research Council |
| SOI | Statistics of Income |
| DASIB | Data and Analytics Strategic Integration Board |
| DAAG | Data and Analytics Advisory Group |


**1.7.1.1.6** **(08-12-2020)**

#### Related Resources

1. The following are related resources:



   - Data and Analytics (D&A) Project Repository - Project Repository (sharepoint.com)

   - Business Unit News - Business Unit News (sharepoint.com)


**1.7.1.2** **(08-12-2020)**

### IRS Research Program Management, Oversight and Coordination

1. Research and analysis of tax administration data is essential to planning, management and evaluation of IRS programs and activities. Research projects, studies, and tests support effective and efficient decision making in the IRS and assist in improving performance and in meeting strategic goals.

2. The research community is composed of the RAAS organization and research and analysis offices contained in each of the four operating divisions (LB&I, SB/SE, TE/GE,TS), as well as research functions embedded in CI, TAS, HCO, and OLS.

3. The RAAS organization oversees, coordinates Servicewide and operating divisions research studies projects and tests. RAAS typically focuses on data and research across the IRS operating divisions and functions and on taxpayer segments covering two or more of the operating divisions, longer timeframes, and/or support initiatives having a Servicewide impact. See IRM 1.1.18 for more information about the Office of RAAS.

4. Research offices within the operating divisions and functions generally focus on issues relevant to their respective customer bases and taxpayer segments.

5. All IRS research projects are listed on the Data and Analytics (D&A) Project Repository at Project Repository (sharepoint.com). The repository houses an inventory of all active research projects and studies and prior studies since 2016. It is accessible to all personnel in the IRS and provides a communication vehicle for sharing types of projects and programs that the research community is conducting in support of the IRS mission. See _IRM 1.7.1.2.4_ on the D&A Project Repository.

6. Projects, studies, and tests are encouraged throughout the research community to support data-driven decisions. There are several commonalities among the research methodologies and tools used within the community and are represented in the list below. These include, but are not limited to:



   - The use of surveys and focus groups

   - Analyses of taxpayer characteristics

   - Forecasting of data to identify emerging trends and issues

   - Behavioral research

   - The creation of models using internal and external data

   - The development of workload selection models


7. The Data and Analytics Strategic Integration Board (DASIB) mission is to promote and enhance the application of data and analytics solutions to improve IRS operations and mission effectiveness. See _IRM 1.7.1.2.1_, Data and Analytics Strategic Integration Board (DASIB).

8. The Data and Analytics Advisory Group (DAAG) mission is to promote and execute integrated operations and provide cross-organizational perspectives to further the enterprise D&A strategy. See _IRM 1.7.1.2.2_, Data and Analytics Advisory Group (DAAG).


**1.7.1.2.1** **(08-12-2020)**

#### Data and Analytics Strategic Integration Board Purpose and Scope

1. The DASIB promotes and enhances the application of data and analytics solutions to improve IRS operations and mission effectiveness. The DASIB integrates relevant organizational perspectives to set strategic priorities and make investment recommendations for data and analytics; facilitates knowledge sharing and enhances leadership visibility into data and analytics products and activities; and directs and approves standards to enhance the accessibility and usability of data and analytics Service-wide.

2. The following are the expectations and duties of the DASIB:



|     |     |
| --- | --- |
| _Expectation_ | _Duties_ |
| Data Strategy & Communication: | - Develops and communicates the enterprise D&A strategy and priorities<br>     <br>   - Conducts an annual D&A environmental scan and refreshes the D&A strategy on an event-driven basis<br>     <br>   - Monitors organizational progress against D&A strategy |
| Data Investment Reviews & Oversight: | - Reviews and recommends D&A budget investment requests<br>     <br>   - Coordinates with CFO and IT on prioritized requests<br>     <br>   - Monitors the performance of D&A investment |
| IRS Leadership Alignment: | - Reports organizational progress on key D&A efforts, including strategies, investments, and projects, to the IRS Commissioner and Deputy Commissioners as needed |
| Ratification of DAAG Decisions: | - The functions listed in IRM 1.7.1.2.2(2) are executed primarily by the DAAG, but the DASIB retains the responsibility to review and ratify decisions as needed |


**1.7.1.2.1.1** **(08-12-2020)**

##### Data and Analytics Strategic Integration Board (DASIB) Membership

1. Responsibilities are performed through the distinct roles of the Co-Chairs and members of the DASIB:



   - _Co-Chairs_ – The Co-Chairs are responsible for coordinating the meeting schedule, soliciting topics for inclusion, preparing the meeting agenda, securing and posting pre-read documents, preparing the meeting notes, and tracking progress of assigned action items. The Co-Chairs also lead the development of the D&A strategy and annual investment reviews and provide oversight to the DAAG.

   - _Members_ – Members represent the D&A needs of their respective organizations to contribute to the D&A strategy and related DASIB decisions. This includes contributing to policy and standards approvals, participating in the investment review process, and communicating D&A outcomes within their respective organizations.


2. The DASIB core membership is comprised of the following members:



   - Commissioner, Taxpayer Services

   - Commissioner, Small Business/Self-Employed

   - Commissioner, Tax Exempt and Government Entities

   - Commissioner, Large Business and International

   - Chief, Criminal Investigation

   - Chief Research and Analytics Officer

   - Chief Information Officer


3. The following organizational representatives may also participate in the DASIB in an advisory role:



   - Chief Financial Officer

   - Chief Privacy Officer

   - Chief Risk Officer

   - Chief Human Capital Officer

   - National Taxpayer Advocate


**1.7.1.2.1.2** **(08-12-2020)**

##### Data and Analytics Strategic Integration Board (DASIB) Logistics

1. The DASIB meets every one-two months, with the ability to transition to quarterly meetings.

2. The operations of the DASIB are co-chaired by the Chief Data and Analytics Officer (CDAO) and a rotating BOD Commissioner.

3. The Co-Chairs coordinate DASIB meetings and the PMO, in RAAS, maintains meeting minutes.

4. Core members are expected to attend meetings in person or via telephone conference. As needed, deputies or appropriate leadership may serve as a proxy for a DASIB member.

5. A quorum of four core members is required for conducting a meeting. Proxies should be prepared to act on behalf of the member.

6. Only members or a member’s designated proxy may attend meetings, though others may be included to address specific issues.

7. The group will strive to achieve decisions by consensus. If consensus cannot be achieved, decisions may be made by a simple majority of the core membership.


**1.7.1.2.2** **(08-12-2020)**

#### Data and Analytics Advisory Group (DAAG) Purpose and Scope

1. The DAAG’s purpose is to promote and execute integrated operations and provide cross-organizational perspective to further the enterprise of D&A strategy.

2. The following are the expectations and duties to be performed by the DAAG:



|     |     |
| --- | --- |
| _Expectations_ | _Duties_ |
| D&A Strategy Development | - Supports the DASIB in developing and annually refreshing the enterprise D&A strategy as well as identifying strategic priorities<br>     <br>   - Provides support to D&A providers in aligning program execution to the D&A strategy |
| D&A Talent and Training Priorities Development | - Identifies needed D&A skills and develops position descriptions<br>     <br>   - Supports the standup and coordination of Communities of Practice (CoPs) and Centers of Excellence (CoEs) across the IRS<br>     <br>   - Supports the development of cross-organizational, prioritized skills through the CoPs and CoEs<br>     <br>   - Develops and executes plans to acquire D&A staffing resources |
| D&A Investment Reviews | - Supports the DASIB investment review and integration process to validate the technical merits and business value of investment requests |
| Design and Outcome Reviews | - Conducts integrated planning and design reviews for analytics projects meeting criteria defined in Section I to ensure alignment to D&A Strategy<br>     <br>   - Conducts outcome reviews for work meeting criteria defined in Section III to capture lessons learned and integrate findings into relevant knowledge management resources |
| Resource Sharing Decisions | - Creates transparency into resources and capabilities to facilitate coordination of resources across organizations |
| D&A Capability Needs Decisions | - Determines needed enterprise D&A capabilities and develops the corresponding business case(s) |
| Knowledge Sharing and Information Management | - Coordinates development and maintenance of central D&A knowledge and information repositories<br>     <br>   - Coordinates CoPs and CoEs to promote and manage key information areas |


**1.7.1.2.2.1** **(08-12-2020)**

##### Data and Analytics Advisory Group (DAAG) Membership

1. The DAAG is composed of research and analytics, data management, and key business operations leadership from across the Business Operating Divisions (BODs), Criminal Investigation (CI), and Research, Applied Analytics, and Statistics (RAAS), along with designated representatives from Information Technology (IT). The membership is outlined in IRM 1.7.1.2.2.1(2). Members represent the D&A needs of their organization to contribute to policy and standards development, conduct and participate in activities and provide inputs to the D&A strategy and related DASIB decisions.

2. Membership



   - Director, Collections Operations (SBSE)

   - Director, Examination Operations (SBSE)

   - Director, CAS (TS)

   - Director, RICS (TS)

   - ADC, Compliance Integration (LB&I)

   - Director, Government Entities & Shared Services (TEGE)

   - Director, Strategy (CI)

   - Director, Strategy & Business Solutions (RAAS)

   - ACIO, Application Development (IT)

   - ACIO, Enterprise Services (IT)

   - Director, Data Management Division (RAAS)

   - Director, Data Exploration and Testing (RAAS)


**1.7.1.2.2.2** **(08-12-2020)**

##### Data and Analytics Advisory Group (DAAG) Logistics

1. The DAAG meets on a monthly basis.

2. The operations of the DAAG are directed by an annually rotating Chair. The Chair is designated by the DASIB with consultation from the members of the DAAG. The Chair leads the DAAG by coordinating the meeting schedule, soliciting topics for inclusion, preparing the meeting agenda, securing and posting pre-read documents, preparing the meeting notes, and tracking progress of assigned action items.

3. The DAAG has the authority to create sub-councils with additional members as necessary to address integrated D&A needs. The sub-councils act as working groups to perform specific functions within the DAAG. Approval authority for work performed or products created within sub-councils remains with the DAAG. As needed, the DAAG reviews established sub-councils to reevaluate their utility and determine if they should continue.

4. The Chair coordinates the DAAG meetings and the PMO, in RAAS, maintains meeting minutes.

5. Core members are expected to attend meetings in person or via telephone conference. As needed, deputies or appropriate leadership may serve as a proxy for a DAAG member.

6. A quorum of six voting members (including at least one representative each from RAAS, Services & Enforcement, and IT) is required to conduct a meeting.


**1.7.1.2.3** **(08-12-2020)**

#### Research Directors Coordinating Council (RDCC) Purpose and Scope

1. The RDCC is comprised of directors and executives from each of the operating and division research program offices.

2. The primary focus of the Council is to contribute to the coordination of research activities throughout the IRS, share best practices and research results and to drive D&A community improvements. The Council contributes and monitors new projects to improve the infrastructure of the research community. The RDCC council will:



1. Facilitate servicewide research collaboration

2. Improve research methodologies for data driven research

3. Support priority projects (i.e., allocate resources)

4. Identify and drive infrastructure projects in the D&A Community

5. Foster research communities of practice to encourage employee development


**1.7.1.2.3.1** **(08-12-2020)**

##### RDCC Membership

1. RDCC consists of research directors in the operating division and functions:



01. Chief Research and Analytics Officer

02. Research Director, Criminal Investigation

03. Research Director, Large and International Business

04. Research Director, Small Business/Self Employed

05. Research Director, Tax Exempt and Government Entities

06. Research Director, Taxpayer Services

07. Research Director, Human Capital Office

08. Executive Officer, Office of On-Line Services

09. Senior Research Advisor to the National Taxpayer Advocate

10. Director, RAAS, Statistics of Income Division

11. Director, RAAS, Data Management Division

12. Director, RAAS, Data Exploration and Testing Division

13. Director, RAAS, Strategy and Business Solutions Division

14. Director, RAAS, Knowledge Development and Application Division


**1.7.1.2.3.2** **(08-12-2020)**

##### RDCC Logistics

1. The RDCC meets regularly to coordinate ongoing and new research activity in the IRS.

2. The RDCC meetings will rotate among members and host organizations will coordinate the agenda and maintain meeting minutes.


**1.7.1.2.4** **(08-12-2020)**

#### Data and Analytics Project Repository

1. The Data and Analytics project repository is a centralized database that is to contain all active and completed research projects and programs since 2016. The repository was created in support of the Research & Analytics Planning & Coordination model which was established and approved in 2015 to drive greater collaboration with and better service for the research community.

2. The project repository is accessible to all personnel in the IRS and, therefore, provides a communication vehicle for sharing types of projects and programs that the research community is conducting in support of the IRS mission.

3. The Project Management Office manages access to the D&A project repository.


**1.7.1.2.5** **(08-12-2020)**

#### Communities of Practice (CoP)

1. In 2015, the IRS established the Research & Analytics Planning & Coordination model to drive greater collaboration with and better service for customers. A key area that emerged as essential in establishing a successful Planning & Coordination model was continued improvement of R&A community capabilities. The R&A Communities of Practice were established to support this goal.

2. The CoPs have three core tenets:



   - Leverage the existing body of knowledge into an appropriate CoP

   - Build relationships and strengthen ties between CoP members

   - Organize and execute specific projects that will produce tools and lessons learned within the broader IRS D&A community


3. RAAS coordinates D&A CoPs. Requests for further information should be submitted directly to irs.data.analytics.community.of.practice2@irs.gov.


**1.7.1.3** **(08-12-2020)**

### Research Data Standards and Scope

1. It is important for the research community to conduct research in a manner consistent with IRS policy and best practices. Using tested, validated and documented data is a critical step in ensuring that research is proper, reliable, and accomplished in accordance with stakeholder and customer expectations. Research staff must also ensure that safeguards are in place and followed that limit and control access to taxpayer data and protect taxpayer privacy.

2. Data standards cover all data from internal or external sources used in any research activity.

3. Foundational research data systems such as the Compliance Research Information System (CRIS), the Compliance Data Warehouse (CDW) and the Enforcement Revenue Information System (ERIS) should be certified on a regular basis and at a minimum annually.

4. Data standards were developed by the prior Servicewide Research Council with representatives from the operating divisions and Criminal Investigation and in consultations with data management, privacy, and security experts. In 2017, RP&P committee concurred with the data standards in _IRM 1.7.1.3.1_ dated 8-15-2004. The RDCC will periodically review the data standards for compliance with IRS procedures and best practices.

5. Research managers are responsible for ensuring compliance with the research data standards contained in _IRM 1.7.1.3.1_, Data Standards.


**1.7.1.3.1** **(02-21-2018)**

#### Data Standards

1. The following standards are required to be followed for all IRS research projects and data:



   - The use of taxpayer data is restricted to authorized personnel for approved research projects

   - Taxpayer privacy must be safeguarded

   - The data used in a research project must be validated

   - Any known or potential limitations in the data used in a research project must be properly disclosed

   - Any data used in a research project must be obtained, utilized, stored, disseminated and transported in accordance with the Internal Revenue Manual

   - Related documentation (data dictionary, record layout, sampling plan, data validation documentation, syntax and other computer code) must be made available to any research site requesting data

   - All data used in a research project and under the control of research, whether stored on computer or archived on magnetic media, must be destroyed in a timely manner in accordance with Document 12990, Records Control Schedule (item 27) (formerly IRM 1.15.27, Records Control Schedule for Compliance Research).


**1.7.1.4** **(02-21-2018)**

### Retention of Research Studies

1. All completed and final research studies are to be retained in accordance with the retention policy of each Research function.

2. Each Research program office is required to review the research document or documents including text, spreadsheets, charts, presentations, databases, tables or other documentation for official use only (OUO) and personally identifiable information (PII) and designate the document accordingly.

3. Follow Document 12990, Records Control Schedule Item 25 for SOI and Item 27 for Research.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-007-001#addtoany "Show all")

A2A