---
url: "https://www.irs.gov/irm/part1/irm_01-025-004r"
title: "1.25.4 Processing Circular 230 Disciplinary Cases | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-025-004r#main-content)

- 1.25.4  [Processing Circular 230 Disciplinary Cases](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385104472736)
  - 1.25.4.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385104496320)
    - 1.25.4.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385104488752)
    - 1.25.4.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385104485072)
    - 1.25.4.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385104482624)
    - 1.25.4.1.4  [Acronyms](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385104480944)
  - 1.25.4.2  [Overview](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385104439280)
  - 1.25.4.3  [Referrals to the Office of Professional Responsibility](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103896880)
  - 1.25.4.4  [Other Cases Received in OPR](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103882896)
  - 1.25.4.5  [Communication to Practitioners and their Representatives](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103872096)
  - 1.25.4.6  [Sorting and Controlling Incoming Mail](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103864576)
  - 1.25.4.7  [Intake](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103852752)
    - 1.25.4.7.1  [Correspondence](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103834512)
    - 1.25.4.7.2  [Cases](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103824528)
    - 1.25.4.7.3  [Case File Assembly](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103812544)
      - 1.25.4.7.3.1  [Case File Paper Work: Disclosure](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103783664)
      - 1.25.4.7.3.2  [Case File Paper Work: Protection of Evidence](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103775936)
      - 1.25.4.7.3.3  [Case File Paper Work: Neat and Legible](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103769024)
    - 1.25.4.7.4  [Case Assignment](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103761264)
  - 1.25.4.8  [Initial Case Review](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103759072)
  - 1.25.4.9  [Case Development](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103711600)
  - 1.25.4.10  [Case Investigation](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103704576)
    - 1.25.4.10.1  [Procedures for Bar and Board Notices](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103703632)
    - 1.25.4.10.2  [Procedures for Reinstatement Requests](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103690944)
    - 1.25.4.10.3  [Procedures for Misrepresentation of Credentials](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103677296)
    - 1.25.4.10.4  [Procedures for Criminal Convictions and Injunctions](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103668224)
    - 1.25.4.10.5  [Procedures for Limited Practice by Unenrolled Tax Return Preparers](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103651504)
      - 1.25.4.10.5.1  [Processing Ineligibility Determinations](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103649232)
      - 1.25.4.10.5.2  [Processing Appeals of Ineligibility Determinations](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103641888)
      - 1.25.4.10.5.3  [Reinstatement](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103635728)
    - 1.25.4.10.6  [Procedures for Enrollment Appeals](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103633536)
    - 1.25.4.10.7  [Procedures for 10.82 Cases (Expedited Suspensions)](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103617824)
      - 1.25.4.10.7.1  [Procedures for Cases Forwarded to GLS for Litigation (10.60 Hearing)](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103587952)
    - 1.25.4.10.8  [Procedures for 10.60 Disciplinary Cases (Conduct, Compliance, Hybrid)](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103529328)
      - 1.25.4.10.8.1  [Procedures for Cases Forwarded to GLS for Litigation (10.60 Hearing)](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103473744)
    - 1.25.4.10.9  [Procedures for Publicity](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103406048)
      - 1.25.4.10.9.1  [Press Releases and Business Unit News Articles](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103403328)
      - 1.25.4.10.9.2  [OPR Intranet Website](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103391968)
      - 1.25.4.10.9.3  [Internal Review Bulletin](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103388448)
    - 1.25.4.10.10  [Procedures for Title 31 Monetary Penalty](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103381888)
      - 1.25.4.10.10.1  [Processing and Notification of A Circular 230 Monetary Penalty](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103378224)
      - 1.25.4.10.10.2  [Processing Title 31 Monetary Penalties Resulting From Settlement](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103373888)
      - 1.25.4.10.10.3  [Processing Title 31 Monetary Sanction Imposed by Final Agency Decision](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103359024)
    - 1.25.4.10.11  [Procedures for Processing Practitioner File Requests in Disciplinary Cases](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103345584)
      - 1.25.4.10.11.1  [Relevant Authorities](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103340016)
      - 1.25.4.10.11.2  [Identifying the Source of Authority to Process Practitioner Requests](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103328400)
      - 1.25.4.10.11.3  [Categorizing the Request Type](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103318368)
      - 1.25.4.10.11.4  [Timeframes and Metrics](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103312800)
  - 1.25.4.11  [Closing Cases / Correspondence](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103306512)
  - 1.25.4.12  [Outgoing Correspondence](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103255472)
  - 1.25.4.13  [Closed Cases / Correspondence](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103250816)
  - 1.25.4.14  [Case and Correspondence Management System](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103247840)
  - 1.25.4.15  [Formal Case Review Process](https://www.irs.gov/irm/part1/irm_01-025-004r#idm140385103240016)

# Part 1. Organization, Finance, and Management

# Chapter 25. Practice Before the Service

# Section 4. Processing Circular 230 Disciplinary Cases

* * *

## 1.25.4 Processing Circular 230 Disciplinary Cases

#### Manual Transmittal

July 26, 2024

#### Purpose

(1) This transmits new IRM 1.25.4, _Practice Before the Service_, _Processing Circular 230 Disciplinary Cases_.

#### Material Changes

(1) This Internal Revenue Manual (IRM) describes the uniform guidelines and techniques for processing disciplinary cases in the Office of Professional Responsibility (OPR). The purpose of these guidelines is to promote consistent application of the disciplinary rules under Circular 230 and of any sanctions that may be proposed. They are intended to assist in conducting investigations, developing issues, organizing case files, and making appropriate recommendations for discipline and sanctions. The professional judgment of the employee, however, is still paramount in determining the appropriate scope and depth of the investigation.

#### Effect on Other Documents

Some of the text contained in obsolete IRM 1.25.3, _Case Development & Licensure (CD&L)_, is revised and incorporated into this IRM.

#### Audience

All OPR Employees

#### Effective Date

(07-26-2024)

Stephen A. Whitlock

Director

Office of Professional Responsibility

**1.25.4.1** **(07-26-2024)**

### Program Scope and Objectives

1. **Purpose:** This section provides technical information to employees of the Office of Professional Responsibility (OPR) and is used for establishing, evaluating and assessing the effectiveness of program operations within the Business unit.

2. **Audience:** This section applies to the OPR’s employees.

3. **Policy Owner:** The Director, OPR, is primarily responsible for administering and enforcing Treasury Department Circular No. 230, _Regulations Governing Practice before the Internal Revenue Service_ (“Regulations” or “Circular 230”). The Director, Return Preparer Office (RPO), is responsible under Circular 230 for the policies and administration of the enrolled practitioner program. See IRM 1.25.2, _Practitioner Enrollment_, for more information.

4. **Program Owner:** The Director, OPR, is responsible for overseeing matters related to the conduct of practitioners and others before the IRS and for discipline, including disciplinary proceedings and sanctions.


**1.25.4.1.1** **(07-26-2024)**

#### Background

1. The OPR undertakes investigations and institutes proceedings pursuant to Title 31, United States Code section 330 and the implementing regulations in Treasury Department Circular No. 230. The OPR remains independent from the Title 26-based enforcement components of the IRS. The main objective of the OPR’s activities is to ensure that those who practice before the IRS on behalf of taxpayers have good character and reputation and the necessary qualifications and competency to provide valuable service to clients and assist them in presenting their cases or other matters to the IRS. The underlying issue in Circular 230 investigations and proceedings is the individual’s “fitness to practice” before the IRS.

2. Since 2012, the RPO, rather than the OPR, has operated the IRS program for the enrollment of individuals as enrolled agents, enrolled retirement plan agents and enrolled actuaries. The RPO processes applications for enrollment or reenrollment, administers the Special Enrollment Examination for enrolled agents, oversees compliance with continuing education requirements, and approves applications to become an IRS recognized continuing education provider.


**1.25.4.1.2** **(07-26-2024)**

#### Authority

1. The OPR’s Authority is listed in IRM 1.25.1.3I, _Authorities Relating to Practice_.


**1.25.4.1.3** **(07-26-2024)**

#### Roles and Responsibilities

1. The Director, OPR, is the executive responsible for this program.


**1.25.4.1.4** **(07-26-2024)**

#### Acronyms

1. The following table lists the acronyms used throughout this IRM section.



|     |     |
| --- | --- |
| **Acronym** | **Definition** |
| AA | Appellate Authority |
| ALERTS | Automated Labor and Employee Relations Tracking System |
| ALJ | Administrative Law Judge |
| BOD | Business Operating Division |
| BUN | Business Unit News |
| C&D | Cease & Desist |
| CAF | Centralized Authorization File |
| CCMS | Case and Correspondence Management System |
| CPA | Certified Public Accountant |
| DDA | Deferred Disciplinary Agreement |
| DOJ | Department of Justice |
| EA | Enrolled Agent |
| EAP&M | Enrolled Agent Policy & Management |
| EIN | Employer Identification Number |
| EUP | Employee User Portal |
| FAD | Final Agency Decision |
| FOIA | Freedom of Information Act |
| FRC | Federal Records Center |
| GLS | General Legal Services |
| IRB | Internal Revenue Bulletin |
| IRC | Internal Revenue Code |
| IRM | Internal Revenue Manual |
| IRS | Internal Revenue Service |
| LAB | Legal Analysis Branch |
| NoD | Notice of Denial |
| NoR | Notice of Revocation |
| O&M | Operations & Management Branch |
| OPR | Office of Professional Responsibility |
| OSC | Order to Show Cause |
| PACER | Public Access to Court Electronic Records |
| PGLD | Privacy Governmental Liaison and Disclosure |
| POA | Power of Attorney |
| PTIN | Preparer Tax Identification Number |
| RPC | Return Preparer Coordinator |
| RPO | Return Preparer Office |
| SSN | Social Security Number |
| TIGTA | Treasury Inspector General for Tax Administration |
| TPPS | Tax Professional Preparer Tax Identification Number (PTIN) System |
| TS | Taxpayer Services |
| USC | United States Code |
| XP | Expedited Suspension |


**1.25.4.2** **(06-29-2016)**

### Overview

1. The Office of Professional Responsibility (OPR) is responsible for reviewing, investigating and resolving alleged violations of the professional standards of competence, conduct and integrity by tax practitioners who represent, or otherwise practice on behalf of, taxpayers before the Internal Revenue Service (IRS). In particular, OPR is responsible for identifying and resolving alleged violations of the applicable professional standards enumerated by Treasury Department Circular No. 230, _Regulations Governing Practice before the Internal Revenue Service_ ("Circular 230" or "Regulations" ). These allegations are submitted to OPR by IRS employees, state-licensing authorities, and others. OPR oversees "practice" before the IRS. Evidence of a person practicing before the IRS includes, but is not limited to:



1. A valid Power of Attorney (POA) listed on the Centralized Authorization File (CAF).

2. A copy of a POA provided by the complainant or Treasury Inspector General for Tax Administration (TIGTA).

3. Evidence of written advice provided to a taxpayer.

4. Evidence or observations from an IRS employee that the practitioner was representing clients before the IRS.


This IRM chapter describes the uniform guidelines and techniques for processing disciplinary cases in OPR. The purpose of these guidelines is to promote consistent application of the disciplinary rules under Circular 230 and of any sanctions that may be proposed. The guidelines are intended to assist in conducting investigations, developing issues, organizing case files, and making appropriate recommendations for discipline and sanctions. The professional judgment of the employee is used in determining the appropriate scope and depth of an investigation.



### Note:

As used in this chapter, "practitioner" means attorneys, certified public accountants (CPAs), enrolled agents (EAs), enrolled retirement plan agents, enrolled actuaries, appraisers, and other individuals subject to the regulations governing practice in Circular 230.

2. OPR Front Office:



1. Screens all correspondence and referrals received in OPR.


3. OPR’s Legal Analysis Branch (LAB):



01. Receives, reviews and investigates evidence of alleged misconduct by individuals covered by the Regulations.

02. Evaluates allegations to determine whether the action constitutes disreputable or incompetent conduct, or otherwise reflect violations of the Regulations.

03. When warranted, proposes and negotiates a level of discipline commensurate with the misconduct.

04. In the absence of a Reprimand or a voluntary settlement, initiates disciplinary proceedings before Administrative Law Judges (ALJs).

05. Initiates or responds to appeals of ALJ disciplinary decisions.

06. Pursuant to Delegation Order 25-16 (Rev. 2) (See IRM 1.2.2.15.16), receives, processes, and investigates referrals or allegations of misconduct under Rev. Proc. 81-38 and representational misconduct under Rev. Proc. 2014-42.

07. Serves as the Appellate Authority (AA) for enrollment appeals from the Return Preparer Office (RPO).

08. Interprets the Conference and Practice Requirements contained in 26 C.F.R. Part 601, Subpart E.

09. Acts in an advisory capacity with respect to IRS oversight and compliance initiatives for practitioners.

10. Manages the OPR referral mailbox.


4. OPR’s Operations & Management (O&M) Branch:



1. Coordinates all postings of disciplinary actions.

2. Receives and reviews criminal convictions and injunctions for possible action under the Regulations.


**1.25.4.3** **(06-29-2016)**

### Referrals to the Office of Professional Responsibility

1. Referrals are sent to OPR on Form 8484, _Suspected Practitioner Misconduct Report for the Office of Professional Responsibility_, via mail, fax, or email to the designated OPR mailbox.



1. The mailbox is checked several times a day to ensure that all incoming email is processed in a timely manner. Generally, a response to email is made within 24 hours of receipt in the OPR mailbox.

2. Any email appearing to be spam will be sent to \*spam@irs.gov.


2. Types of referrals include:



1. RPO flags a case to indicate that it is a referral for OPR. Additionally, RPO will provide any associated case documents (including Form 14157 referring a practitioner who potentially violated Circular 230).

2. TIGTA or Criminal Investigation (CI) submits an investigative memorandum referring a practitioner who potentially violated Circular 230.

3. The Tax Division of the Department of Justice (DOJ) informs OPR of a court order permanently enjoining a practitioner from preparing and filing tax returns or other documents or submissions to the IRS on behalf of taxpayers and from representing any taxpayer before the IRS. These referrals from DOJ are typically sent to OPR by email.

4. Business Operating Divisions (BODs) submit Form 8484 referring a practitioner who potentially violated Circular 230.

5. OPR may open a case on a practitioner who has lost his / her license, for cause based on a public informant or a notice from the licensing authority.


3. Under section 10.53, if an officer or employee of the IRS has reason to believe that a practitioner has violated Circular 230, the officer or employee must promptly make a written report of the suspected violation to the Director of OPR. See IRM 20.1.6.12.3, _Referral to the Office of Professional Responsibility._ Referrals are mandatory following the assessment of any Internal Revenue Code (IRC) 6694(b) penalty, e.g., a willful attempt to understate the liability for tax. The referral should be made regardless of any appeal taken by the practitioner. A referral must also be made when any of the following penalties are assessed or sanctions imposed:



1. Section 6700 - Promoting abusive tax shelters

2. Section 6701(a) - Aiding and abetting understatement of a tax liability

3. Section 7407 - Injunction of a tax return preparer

4. Section 7408 - Injunction restraining specified conduct relating to tax shelters and reportable transactions


Discretionary referrals are assessments of civil penalties prescribed by the following IRC sections:



1. Section 6692 - Accuracy related penalty

2. Section 6694(a) - Understatement of liability due to an unreasonable position

3. Section 6695 - (a) Failure to furnish copy of return; (b) Failure to sign return; (d) Failure to keep a copy of tax return or list of taxpayer

4. Section 6702 - Frivolous tax returns or submissions


### Note:

If any of the above penalty assessments appear to become a pattern across taxpayers, tax issues, or tax years, a referral should be made with regard to the practitioner involved.

**1.25.4.4** **(06-29-2016)**

### **Other Cases Received in OPR**

01. A practitioner’s appeal of RPO’s Notice of Revocation (NoR) of Preparer Tax Identification Number (PTIN) due to an injunction. An appeal may be submitted to OPR within 30 calendar days of the stamped date on RPO’s NoR.

02. A practitioner’s appeal of RPO’s decision to deny or potentially deny his / her _Application for Enrollment to Practice before the IRS_ (Form 23) or _Application for Renewal of Enrollment to Practice before the IRS_ (Form 8554). An appeal may be submitted to RPO within 30 calendar days of the stamped date on RPO’s Notice of Denial (NoD).

03. A practitioner’s appeal of RPO’s decision to deny a request to waive mandatory Continuing Professional Education requirements in connection with Enrollment to practice. An appeal may be submitted to RPO within 30 calendar days of the stamped date on RPO’s NoD.

04. A former employee’s appeal of RPO’s decision to deny a request to waive the Special Enrollment Exam. An appeal may be submitted to RPO within 30 calendar days of the stamped date on RPO’s NoD.

05. A former employee’s appeal of RPO’s decision to deny full Enrollment without examination. An appeal may be submitted to RPO within 30 calendar days of the stamped date on RPO’s NoD.

06. A practitioner’s request to OPR to be reinstated to practice, following a period of suspension or disbarment, directly.

07. A practitioner’s request to institute a proceeding under §10.60 of Circular 230 pursuant to §10.82(g).

08. The IRS CAF Unit’s submission of information regarding a practitioner’s misrepresentation of credentials.

09. A BOD’s referral, or information received by OPR from another source, about an unenrolled tax return preparer that indicates the preparer may have engaged in conduct that would render the preparer ineligible for limited practice under Rev. Proc. 81-38 and Rev. Proc. 2014-42 (may be subject to a referral to RPO).

10. An unenrolled return preparer’s appeal of OPR’s determination, made under Rev. Proc. 81-38, that the preparer is ineligible for limited practice, by submitting an appeal to OPR within 30 calendar days of the stamped date on the Determination of Ineligibility to Practice before the IRS.


**1.25.4.5** **(06-29-2016)**

### Communication to Practitioners and their Representatives

1. OPR is committed to providing prompt, professional and quality service to practitioners, IRS employees and members of the public.

2. Quality service means adopting business practices that ensure the provisions of Circular 230 are applied fairly and that the rights of practitioners are respected and protected, while at the same time ensuring that the interests of the IRS and the protection of the public are considered.

3. Interactions and correspondence with a practitioner or his / her representative must be courteous and professional.

4. All cases will be worked timely and efficiently with case objectives being accomplished in the manner least intrusive and burdensome to the practitioner.

5. Adhere to timeframes established for completing actions on a case. Any delays in the investigation will be discussed with management and the practitioner or his / her representative notified. Delays and extensions will also be documented in OPR’s Case and Correspondence Management System (CCMS).

6. Prompt decisions are an essential part of providing quality service to tax practitioners. It is important that all employees monitor closely the progress of supervised employees’ work for which they are responsible. Managers will devote a substantial amount of their time to assure promptness in completing work. Managers will regularly, frequently and personally ascertain, from each of their employees, the status of work, estimated completion dates, progress made, and any reasons for delay.

7. Employees must document all contact and communications with a practitioner or his / her representative. Communications include telephone calls and conferences.

8. All written communications and work products, including correspondence, email, research memorandums, and recommendations must be maintained in the case file and uploaded to CCMS.

9. Requests for information filed pursuant to the Freedom of Information Act (FOIA) or IRC 6103 will be processed expeditiously and as much as feasible within established statutory or administrative timeframes.


**1.25.4.6** **(06-29-2016)**

### Sorting and Controlling Incoming Mail

1. Incoming mail is date-stamped same day (weekend correspondence is stamped the next business day). Staple the original envelope to the back of the correspondence.

2. Review and screen all mail to determine if it belongs in OPR.

3. Acknowledge all Form 3210, _Document Transmittal_, received by signing for receipt and mailing one copy back to the originator.

4. For referrals / complaints, send an acknowledgement letter to the referent / complainant confirming receipt. External complaints will be acknowledged by letter (unless frivolous or repetitive of a complaint already received and acknowledged), and internal referrals (from IRS and other Treasury Department employees) will be acknowledged by email.

5. Route any misdirected mail (non-OPR) to the appropriate IRS functional area, via Form 3210.

6. Any misdirected Form 14157, _Return Preparer Complaint_, from IRS personnel or taxpayers will be referred to RPO. RPO tracks the receipt and ultimate distribution of these forms. The below addresses will be used to forward misdirected electronic or paper 14157 forms:



1. Email to \*RPO Referrals, or

2. First class mail:


       Return Preparer Office


       401 W. Peachtree Street NW


       ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡


       Atlanta, GA 30308


7. Any misdirected Form 14157-A, _Tax Return Preparer Fraud or Misconduct Affidavit_, from IRS personnel or taxpayers will be sent to Accounts Management. The below address will be used to forward misdirected electronic or paper 14157-A forms:



1. Internal Revenue Service


       AM – Preparer Complaints


       5333 Getwell Road


       ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡


       Memphis, TN 38118


**1.25.4.7** **(06-29-2016)**

### Intake

1. The Intake Process is the first step in the lifecycle of a case.

2. Review all mail addressed to a specific OPR employee or to the Director of OPR to determine how to proceed. This includes researching CCMS and legacy OPR systems (e-trak and DPACTS) .




| **If -** | **Then -** |
| --- | --- |
| It is a correspondence item regarding an open case. | - Input an activity / event to show the correspondence was received and forward the correspondence to the assigned employee. |
| It is a referral / complaint and we currently have an open case on the practitioner. | - The new referral is entered into CCMS as a new case.<br>     <br>   - Upload a copy of the referral into the new case.<br>     <br>   - Associate the related case(s) and / or correspondence in CCMS.<br>     <br>   - Immediately close the new case.<br>     <br>   - The referral is given directly to the employee currently working the open case. |
| It is a referral / complaint, we do not currently have an open case on the practitioner and there is no prior case. | - Open a new case in CCMS. |
| It is a referral / complaint, we do not currently have an open case on the practitioner but there is a prior closed case. | - Open a new case in CCMS.<br>     <br>   - Associate the related case(s) and / or correspondence in CCMS.<br>     <br>   - Pull the prior case file(s) from either the file room or the Federal Records Center (FRC) and associate it with the new case file. |
| It is a bar or board notice. | - Open a new correspondence in CCMS. |
| It is a reinstatement request. | - Open a new case in CCMS.<br>     <br>   - Associate the related case(s) and / or correspondence in CCMS.<br>     <br>   - Assign the new case to the employee who worked the prior case, if the employee is still with the office.<br>     <br>   - Pull the prior case file(s) from either the file room or the FRC and associate it with the new case file. |
| Multiple practitioners are listed in the referral / complaint. | - Open a new case for each Circular 230 practitioner listed.<br>     <br>   - If applicable, associate the related case(s) and / or correspondence in CCMS.<br>     <br>   - If applicable, pull the prior case file(s) from either the file room or the FRC and associate it with the new case file. |


**1.25.4.7.1** **(06-29-2016)**

#### Correspondence

1. Upon receipt, enter the referral or comparable information into CCMS.

2. Upload all correspondence documents into CCMS.

3. Correspondence will be categorized into one of the following types:



1. Bar and Board Notices - A notification from a State Board of Accountancy or State Bar advising that a CPA or attorney has lost his / her state license, for cause.

2. 6103 / FOIA Request - _6103 Request_: A written request from a practitioner, a practitioner’s authorized representative, or both for tax and other information related to OPR’s investigation or inquiry into the practitioner’s conduct or tax compliance. A section 6103 request can include the practitioner’s own tax information as well as the information of third-party taxpayers (e.g., clients or former clients of the practitioner). A section 6103 request must conform to OPR’s standard section 6103 letter, available for the use of OPR personnel on the office’s share drive and accessible by practitioners and their authorized representatives on IRS.gov/. _FOIA Request_: A written request pursuant to the Freedom of Information Act (5 USC 552) for copies of non-exempt agency records. For example, members of the public, researchers, or the daily tax-news services can use the FOIA to request OPR statistics regarding Circular 230 disciplinary matters. FOIA requests are properly filed with Privacy, Governmental Liaison and Disclosure (PGLD). When a FOIA request involves OPR records, PGLD coordinates the processing of the request with OPR, in particular: OPR conducts a search for records responsive to the request, provides the results to PGLD, and proposes any withholding of information as exempt under one or more of the FOIA’s nine exemptions. Practitioners and their representatives should not use the FOIA to request records in connection with an OPR investigation or proceeding concerning the practitioner. See IRM 1.25.4.10.11, _Procedures for Processing Practitioner File Requests in Disciplinary Cases_, for additional information about handling FOIA and IRC 6103 access requests.

3. CAF Modification Request - A practitioner or unenrolled return preparer who was sent a CAF Notification letter but did not respond within the 10-day timeframe and is requesting to have their CAF reinstated.

4. Director’s Correspondence

5. Other- Non Case Related


**1.25.4.7.2** **(06-29-2016)**

#### Cases

1. Upon receipt, enter the referral information into CCMS.

2. Upload the referral and all supporting documents into CCMS.

3. Cases will be categorized into one of the following types:



01. Conduct - Allegation(s) of tax-practice misconduct (behavior) in violation of Circular 230.

02. Compliance - Case involving a practitioner’s personal tax noncompliance issues, relating to filing requirements (unfiled returns) or taxes due (evasion or attempted evasion of assessment or payment of personal or business taxes).

03. Hybrid - Part Conduct and part Compliance. Allegations of both misconduct (behavior) and personal / business tax noncompliance issues.

04. Expedited Suspension (XP) - Involves one or more of the five bases in §10.82(b) of Circular 230 for which an XP proceeding may be instituted: 1. Loss of license to practice law or loss of CPA or actuary license, when for cause (misconduct); 2. Convicted of a federal tax crime, a crime involving dishonesty or breach of trust, or any felony; 3. Sanctioned by a court (including an injunction) for taking frivolous positions or causing delay; 4. Failure to file practitioner’s own personal tax returns for 4 of the last 5 tax years (or five of the last seven quarters, in the case of employment-tax returns for practitioner’s business); or 5. Violated conditions on reinstatement that were imposed when the individual was reinstated to practice (after being suspended or disbarred from practice).

05. Enrollment Appeal - A practitioner appeals RPO’s decision to deny their Enrollment application or renewal.

06. Limited Practice - An unlicensed, unenrolled return preparer’s misconduct under Rev. Proc. 81-38 and Rev. Proc. 2014-42 that may be cause for loss of limited-practice rights (i.e., a formal determination by OPR of the return preparer’s ineligibility to represent a taxpayer in an audit of a tax return that the unenrolled return preparer prepared for the client and signed as the preparer).

07. Limited Practice Appeal - An unlicensed, unenrolled return preparer appeals OPR’s determination that the return preparer is ineligible for limited practice.

08. Limited Practice Reinstatement - An unlicensed, unenrolled return preparer looking to have his or her limited-practice rights reinstated after being determined ineligible for limited practice.

09. Reinstatement - A practitioner petitioning to be reinstated after being suspended or disbarred.

10. 10.60 Request - A practitioner requesting a 10.60 Hearing pursuant to §10.82(g).


4. 10.60 Request, Appeal, and Reinstatement cases are considered priority cases. They receive priority consideration and require expedited processing. Priority cases will be entered into CCMS and assigned same day.


**1.25.4.7.3** **(06-29-2016)**

#### Case File Assembly

1. Uniform guidelines exist for how case files are assembled.



   - This helps ensure that a case receives proper and timely managerial review, and reduces administrative delays.

   - A properly assembled case file promotes quality and consistency in employee work product, and provides transparency for IRS leadership as to case development and investigative techniques.

   - A well-organized case file allows employees to demonstrate a quality work product.


2. Cases are put in the appropriate colored case folder:



   - Referrals from TIGTA - Blue Folders

   - XP Cases - Red Folders

   - Reinstatements - Brown Folders

   - Appeals - Yellow Folders

   - All other cases - Green Folders


3. The file will be labeled in the following format: LAST NAME (all caps), First Name, Middle Initial and the case / correspondence number in bold.



### Example:



Example: SMITH, John M. 2012-00000





    Multiple file folders will be marked on the front cover as File Number X of Y (e.g., “1 of 4”).


4. Assemble cases in reverse, chronological order.




| **Interior Left-Hand Panel**<br>**Intake and Correspondence Documents** | **Interior Right-Hand Panel**<br>**Work Product Documents** |
| :-: | :-: |
| - Correspondence includes: Letters and emails to the practitioners and / or their representative, as well as internal correspondence– i.e., emails to OPR management or IRS field personnel. Place these items in reverse chronological order with most recent on top.<br>     <br>   - All closed cases must contain a printout of any CAF, Practitioner Preparer Tax Identification Number (PTIN) System (TPPS), Enrolled Agent Policy & Management (EAP&M), and IRS _e-file_ notifications on top of the Correspondence section. When applicable, TIGTA Form OI 2076, _Referral Memorandum_, must also be included on top.<br>     <br>   - Referral / Form 8484 or external complaint; on the bottom. | - Work product includes: case research, Integrated Data Retrieval System (IDRS) printouts, Powers of Attorney, any notes from phone calls / conferences.<br>     <br>   - All files submitted for review or closure must contain a recent CCMS Activity / Event printout on top. |





### Note:



During the gathering of documents, if there is not enough room in the case file, divide the file into two separate files. File 1 consists of the Intake and Correspondence Documents and File 2 will consist of the Work Product Documents file.

5. During the lifecycle of a case:



01. Hole punch and affix items to the folder (no loose documents EXCEPT the most recent draft of any correspondence to be reviewed and the original correspondence to be signed).

02. If any part of the case file needs to be divided and labeled use a tabbed index sheet- Oldest documentation on the bottom, newest documentation on the top. Make a notation on each tab of what the section includes (e.g. reinstatement, tax compliance, etc.).

03. Conduct Cases: Check for tax non-compliance. If no issues exist, place the transcripts on the bottom to show you have considered the issue.

04. Tax Non-Compliance Cases: 1. Section out income taxes and business and employment taxes separately. Earliest year or tax period on the bottom and the most current year or tax period on the top. 2. Each time transcripts are updated, the most recent update goes in the case file and the prior one can be shredded or put in a burn box. 3. Where returns are not filed, show facts supporting the practitioner had a filing requirement.

05. All memorandums, notes, etc. will be dated and contain name of author.

06. Small documents will be stapled to standard size paper and affixed to the case file.

07. CCMS Activity / Events sheet: Place on the right side of the case file, on top of all work papers. This document provides a road map to the case and the work papers that follow.

08. Include / Retain drafts of any documents edited by management until the case is in the closure process. During the closure process, discard any old drafts from the case file.

09. Include the final disposition- Soft-letter, reprimand, censure, suspension, disbarment, or ALJ / AA final decision on the left side; always scan and upload these to CCMS.

10. Additional items may be added on top of the final disposition, such as: a TIGTA coversheet, transmittal forms, email notifications to the CAF Unit, e-file, EAP&M and TPPS notifying them of the disposition, and any other items needed to close the case.


**1.25.4.7.3.1** **(06-29-2016)**

##### Case File Paper Work: Disclosure

1. Confidential information related to the case file must be secured from unauthorized disclosure. All IRS employees are responsible for the security of Federal government property and sensitive taxpayer information. See IRM 10.5.1, _Privacy Policy_, for handling instructions and IRM 11.3, _Disclosure of Official Information_.



1. Documents containing return information (as defined in section 6103) or other personally identifiable information and transmitted electronically must be encrypted.

2. Documents in paper format must be protected from authorized disclosure.


2. The protection of confidential tax data and taxpayer privacy extends to paper documents, computer data and portable media storage devices. Employees working offsite are responsible for protecting taxpayer data from improper disclosure, for storing and disposing of sensitive documents according to security protocols, and for ensuring that unauthorized persons do not overhear discussions with practitioners or their representatives.

3. Documents and other information may only be disclosed or released as authorized or required by applicable provisions of IRC 6103, the FOIA, or the Privacy Act of 1974 (5 USC 552a). See IRM 1.25.4.10.11, _Procedures for Processing Practitioner File Requests in Disciplinary Cases_, for additional information about disclosure of OPR records under FOIA and IRC 6103.

4. Refer any questions involving disclosure of official information to your manager or the Disclosure Office.


**1.25.4.7.3.2** **(06-29-2016)**

##### Case File Paper Work: Protection of Evidence

1. All documents in the case file are official government records, as well as potential evidence in an administrative hearing or any subsequent Federal District Court proceeding. They must be protected and maintained in their original, unaltered condition. Never write or use a highlighter pen on any documents received from a practitioner, his / her representative, or any third party. Even a minor pencil notation can render a document inadmissible due to the alteration. If an employee needs a work copy of a document, make a photocopy and return the original to the case file.

2. All written communication pertinent to the investigation is part of the official investigation, and must be maintained in the practitioner’s case file. This may include:



1. Assignment and Administrative Processing Sheets

2. Employee / Manager Memorandums

3. Correspondence

4. Emails

5. Research Results

6. Conference Notes

7. Written Recommendations


3. Under no circumstance will an employee dispose of or separate any case documents from the administrative file. This does not include tax transcripts that have been replaced by updated tax transcripts.


**1.25.4.7.3.3** **(06-29-2016)**

##### Case File Paper Work: Neat and Legible

1. Employees, managers, and other government agencies, may need to use the file after the investigation is closed. The work papers in the case file are an important aspect of the overall quality of case work.

2. The following are reasons that the work papers should be neat and legible:



1. Case review by management. Disorganized work papers adversely reflect on the professionalism of the employee.

2. Possible use in an administrative hearing or court of law. Poorly prepared work papers negatively impact credibility.

3. Possible FOIA request by practitioner.

4. Potential reviews or uses by TIGTA, Government Accountability Office or other IRS functions, including the Taxpayer Advocate Services.


3. The following will help ensure that work papers are legible and professionally prepared:



1. Use a computer to minimize illegible handwritten paperwork.

2. Use spell-check and grammar-check functions to proofread work papers.

3. Do not overuse acronyms or abbreviations and avoid IRS jargon on correspondence to taxpayers or their representatives. Spell out the abbreviation or acronym the first time it is used.

4. During interviews, or conferences, it is preferable to take notes manually. Afterwards, the notes will be typed verbatim and the original handwritten version stapled to the typed version. For evidentiary purposes, the original manually written notes must be preserved.


**1.25.4.7.4** **(06-29-2016)**

#### Case Assignment

1. The Branch Chief will assign Limited Practice Appeals, and practitioner demands for a 10.60 complaint submitted pursuant to 10.82(g).

2. All other assignments will be made by the Section Manager.


**1.25.4.8** **(06-29-2016)**

### Initial Case Review

1. A completeness check is done to ensure the referral includes the appropriate information and to confirm the source or basis. This includes, but is not limited to:



   - Verification of license(s) (CPA, Attorney, EA)

   - PTIN #

   - CAF #

   - Social Security Number (SSN) / Employer Identification Number (EIN)

   - Tax Compliance Check

   - History of practice before the IRS

   - Subject matter of the complaint


Copies of all research will be printed and placed in the case file.



2. Upon initial review:



1. If the referral or complaint is incomplete (i.e., it needs additional information from the referent), contact the referent immediately to request additional information. If additional information is not received, submit the case for closure.

2. If the referral or complaint does not meet OPR Parameters and there is no further action required, submit the case for closure.

3. If the referral or complaint does not meet OPR Parameters and it needs to be referred to another BOD, send an internal transmittal memorandum, along with the case memorandum and a copy of the referral or complaint to the appropriate BOD Analyst and submit the case for closure.

4. If the referral or complaint does meet OPR Parameters but also needs to be referred to another BOD, send an internal transmittal memorandum, along with the case memorandum and a copy of the referral or complaint to the appropriate BOD Analyst.




      | **If the complaint alleges-** | **Then send to-** |
      | --- | --- |
      | - Physically abusive behavior<br>        <br>      - Criminal behavior<br>        <br>      - Forgery<br>        <br>      - Preparer diverted a refund<br>        <br>      - Impersonation of an IRS employee<br>        <br>      - Misuse of Treasury logo<br>        <br>      - Submission of False Form 2848, _Power of Attorney and Declaration of Representative_<br>        <br>      - Misrepresentation of Credentials (See IRM 1.25.4.10.3, _Procedures for Misrepresentation of Credentials_)<br>        <br>      - Theft of refund<br>        <br>        <br>        <br>        ### Note:<br>        <br>        <br>        <br>        If the allegation involves only the theft of a taxpayer refund (Public Money), these referrals continue to go to TIGTA. These allegations are investigated / prosecuted under Title 18 USC 641 and do not involve DOJ Tax.<br>        <br>      - Diversion of Payments (payments intended for IRS or due to taxpayer)<br>        <br>      - Individuals who fraudulently represent that they are authorized to represent before the IRS<br>        <br>      - Threats made by individuals against facilities or personnel | TIGTA |
      | - A tax or refund scam ($50,000 or under)<br>        <br>      - Identify Theft (used another’s ID to commit a secondary crime)<br>        <br>      - PTIN stolen<br>        <br>      - Received someone else’s tax information | Office of Privacy and Information Protection |
      | - Tax Fraud and there is evidence of a criminal investigation<br>        <br>      - Identity Theft (preparer stole ID)<br>        <br>      - False / Fake W-2’s<br>        <br>      - Tax Scam (over $50,000)<br>        <br>      - Criminal tax violations of Title 26<br>        <br>        <br>        <br>        ### Note:<br>        <br>        <br>        <br>        If the refund theft is associated with any fraudulent return or false claim, such as a preparer providing the taxpayer with a return copy reflecting one refund amount and then actually files a return with an inflated refund amount, these should be referred to CI. These may be investigated under Title 18 USC 287 or under Title 26; but, both must be worked through DOJ Tax. | CI |
      | - Preparer kept the taxpayers records<br>        <br>      - Fraudulent deductions were taken on the return<br>        <br>      - Refund Anticipation Loan issues<br>        <br>      - Electronic Return Originator issues<br>        <br>      - Quality of service issues<br>        <br>      - Fee disputes<br>        <br>      - Firm or company is conducting itself inappropriately<br>        <br>      - Fraudulent Tax Return Preparation<br>        <br>        <br>        <br>        ### Note:<br>        <br>        <br>        <br>        When a tax practitioner, or any individual subject to Circular 230 may be using multiple business entities or complex transactions, or other similar arrangements to potentially divert income from assessment and / or payment of any tax, or as part of a pattern of abusive tax avoidance send to SB/SE using Form 14624, _Office of Professional Responsibility (OPR) Referral_. Refer to SB/SE’s Interim Guidance.) | SB/SE, Return Preparer Coordinators (RPC’s) in Planning and Special Programs |
      | - Free file complaint<br>        <br>      - Refund Anticipation Loan fees charged by an Accounting firm | Taxpayer Services (TS) |
      | - Tax evasion and an award is requested | Whistleblower |
      | - Individual tax issues such as liens and levies, penalty abatement request, or missing Forms 1099 / W-2<br>        <br>      - W-2 Complaint (ADP) / W-2 Corrected problems or issues<br>        <br>      - Form 1099 problems or issues<br>        <br>      - Request for copy of amended return<br>        <br>      - Request for the abatement of interest and penalties | TS |
      | - E-file Issues<br>        <br>      - Return e-filed without consent<br>        <br>      - Refund Anticipation Loan<br>        <br>      - False Return prepared by e-file provider<br>        <br>      - Form 8453, _U.S. Individual Income Tax Transmittal for an IRS e-file Return_ | E-file Provider Program |
      | - Ghost Preparers (Compensated return preparers who fail to identify themselves or fail to identify themselves properly on a tax return)<br>        <br>      - Tax Preparation Non-Compliance<br>        <br>      - Theft of Refund<br>        <br>      - PTIN violations<br>        <br>      - Return Preparer misconduct, such as failure to: remit employment taxes, provide services for which the client was charged, provide copies of returns, or return original records | RPO |





      ### Note:



      No referrals will leave OPR without management approval.

5. If the referral is complete, the following case data, if applicable, will be entered into CCMS: Date of Birth, Taxpayer Identification Number (TIN) (Individual- SSN / Business-EIN), Practitioner Designation, PTIN / PTIN Status, Case Violations, Other Names, Contact Information, Address Information, CAF Information, Associated Businesses, Other Contacts.


**1.25.4.9** **(06-29-2016)**

### Case Development

1. Although Intake will have completed an initial jurisdictional check, it is the employee’s responsibility to review and verify the basis for OPR jurisdiction.

2. Upon receipt of a new case, review the complaint to re-verify that OPR has jurisdiction over the practitioner, as well as the alleged misconduct.



1. Check the practitioner’s professional license status and whether the practitioner has practiced before the IRS.

2. Analyze the complaint / referral for any violation of Circular 230 and review the allegation(s) in the complaint / referral, to determine whether the conduct complained of is regulated or proscribed by Circular 230.

3. For tax-compliance issues, verify tax compliance by determining whether the practitioner: 1. Has filed all Federal tax and information returns that the practitioner is required to file, and 2. Has paid or remitted all Federal taxes for which the practitioner is liable, or is responsible for depositing.


3. If OPR does not have jurisdiction, or if there is no apparent Circular 230 violation or potential violation, the case will be closed.

4. If OPR has jurisdiction, and the referral or complaint appears to present facts indicating one or more violations of Circular 230, develop an investigative plan of action. The plan will identify the facts and evidence relevant to each element of the violations to be investigated. The plan will also identify additional evidence or information needed to determine whether the alleged violations warrant discipline.


**1.25.4.10** **(06-29-2016)**

### Case Investigation

1. OPR investigates, analyzes, and proposes appropriate dispositions, including sanctions, with respect to violations of the Regulations.


**1.25.4.10.1** **(06-29-2016)**

#### Procedures for Bar and Board Notices

01. The notice is placed in a manila case folder and sent to management for assignment.

02. The manager assigns the correspondence to an employee.

03. Upon receipt of the physical case file, review the case information.

04. Obtain additional documents or other information that may be necessary to determine if a case should be opened on the practitioner, including, for example:



    - The individual’s CAF status (if any).

    - Relevant source material located through Internet research (such as the individual’s or associated firm’s commercial website).

    - Professional directories, like Martindale-Hubbell and the National Directory of Certified Public Accountants.

    - State bar- or board-specific rules of professional responsibility or conduct, disciplinary procedures, and guidance for bar/board members or the public.

    - Background or explanatory information provided by bar or board personnel when contacted.


       Add the documentation to the file folder, and upload a copy to CCMS. Notate the file with (or otherwise enter) the details of telephonic inquiries.


05. If it is determined a case should not be opened on the practitioner, the correspondence will be closed. Prior to closing the correspondence case, action to update the CAF may be necessary.

06. If the individual does not have an active CAF designation as an attorney or CPA, no action is necessary.

07. If the individual has an active CAF designation as an attorney or CPA, but no longer has the corresponding license(s), then the CAF designation is invalid and the CAF record should be updated.



    1. An individual whose license to practice law or certified public accountancy has lapsed or who has otherwise lost whatever license(s) he or she had as an attorney or CPA is not authorized to practice before the IRS as an attorney or CPA, even though the loss of license was other than for “cause” (illegal, unethical, or unprofessional conduct).

    2. These individuals will be sent a letter informing them of OPR’s intention to limit their power-of-attorney privileges, subject to a credible showing in a timely written response to the letter as to why CAF status should not be changed.

    3. Absent a response or an adequate rebuttal, the CAF Unit will be notified to update the CAF to reflect that the individual is ineligible to represent taxpayers as an attorney or CPA, as applicable.


08. If it is determined a case should be opened on the practitioner, the correspondence will be closed and opened as a new case in CCMS.

09. The manila case folder is transferred to a green or red case folder and the closed correspondence is associated with the new case via the Related Case tab in CCMS.

10. The new case file is returned to the employee to continue to work the case.


**1.25.4.10.2** **(06-29-2016)**

#### Procedures for Reinstatement Requests

1. Practitioners who are suspended or disbarred may request (petition for) reinstatement of their ability to practice before the IRS when:



   - The petitioners have abided by the terms of the disciplinary sanctions imposed on them.

   - The minimum time period of ineligibility to practice has been satisfied, whether under a suspension or disbarment agreement, an ALJ decision, or pursuant to an expedited suspension under section 10.82 of Circular 230.

   - Any sentence resulting from a criminal conviction, or a period of suspension / disbarment from state practice, has been served, and the individual has been reinstated by the respective state board or bar.

   - The petitioner has been tax compliant after being sanctioned under Circular 230, and is otherwise compliant with Circular 230.


2. Practitioner Reinstatement Requests will be processed on an expedited basis.

3. Review the practitioner’s reinstatement request and the prior case file. If necessary, communicate immediately with the practitioner (or their representative) to request additional information necessary to reach a Preliminary Reinstatement Recommendation.

4. Information considered when making the reinstatement decision may include, but is not limited to:



   - Current licensure status with state agencies.

   - State Board and Bar reinstatement status, which is validated using state-agency websites, if suspended via a §10.82 XP disciplinary process.

   - Conditions for reinstatement set forth in a suspension / disbarment agreement.

   - Minimum length of suspension / disbarment required prior to any reinstatement as prescribed in a disciplinary agreement (5 years in the case of disbarment).

   - A review of CCMS for misconduct subsequent to the suspension / disbarment date (e.g., attempts to “practice”).

   - Practitioner’s current tax compliance status, which is validated using IDRS.

   - Status of a sentence following criminal convictions or status of any probationary periods, which are determined using various court websites and systems (e.g., Public Access to Court Electronic Records (PACER)).

   - Completion of any other non-OPR disciplinary action or sanction.


5. If reinstatement is granted:



1. Notify the IRS CAF Unit by email to update a practitioner’s eligibility to represent taxpayers.

2. Only notify EAP&M by email to update an EA’s eligibility to practice.

3. Update the practitioner’s eligibility to practice status to the OPR intranet database after reinstatement is granted.

4. Only if requested by the practitioner, publish the reinstatement in the Internal Revenue Bulletin (IRB).


**1.25.4.10.3** **(06-29-2016)**

#### Procedures for Misrepresentation of Credentials

1. In situations involving false Forms 2848 on which a practitioner (or someone purporting to be a practitioner) misrepresents the individual’s credentials, request a CAF 77. A practitioner suspended or disbarred from practice before the IRS (and thus unauthorized to represent any taxpayers) may, for example, misrepresent on a Form 2848 that the practitioner is authorized to practice, or a practitioner who is a CPA but not an attorney may misrepresent on a Form 2848 that the practitioner has both credentials. Contact the TIGTA Special Agent-in-Charge (SAC) for the practitioner’s location only if the initial referral to OPR did not come from TIGTA. This notification will allow TIGTA to:



   - Determine whether an investigation is already pending.

   - Determine whether or not an investigation will be initiated on this matter.


2. The TIGTA SAC or Assistant SAC will then advise of the above, which informs whether a Cease & Desist (C&D) Letter should be sent.



   - If a C&D Letter should be sent, indicate that the addressee must stop misrepresenting himself / herself and advise them that the CAF Unit will be notified accordingly.

   - If no further action should be taken, close the case.


3. The practitioner has 10 calendar days to respond to the C&D Letter.

4. If the practitioner doesn’t respond to the C&D Letter, or it is determined there is no basis for delaying action based on any response:



   - Notify the IRS CAF Unit that it may no longer process Forms 2848 either: appointing the practitioner as a representative, or on which the practitioner has declared a certain practitioner designation.

   - Notify IRS field personnel assigned to work on the taxpayer matter identified on the Form 2848 that the individual is not authorized to represent taxpayers, and that they should not honor any Forms 2848 from the individual.

   - Notify the EAP&M by email to update an EA’s status.

   - Post the practitioner to the OPR intranet database.


**1.25.4.10.4** **(06-29-2016)**

#### Procedures for Criminal Convictions and Injunctions

1. OPR receives information regarding a criminal conviction (such as a tax conviction) or a permanent injunction prohibiting tax return preparation and / or representation of any taxpayers before the IRS.



1. Criminal Convictions are received quarterly per an understanding with CI, which provides sentencing information from their Criminal Investigation Management Information System database involving crimes associated with practitioners. OPR learns of other convictions in the form of press releases that are matched against CI’s list.

2. Injunctions are forwarded in real time by the Lead Development Center and are also received contemporaneously in the form of press releases by DOJ.


2. Open cases involving criminal convictions and injunctions if the subject is a Circular 230 practitioner.

3. For Injunctions (All Preparation):



   - If an unlicensed, unenrolled return preparer (i.e., is NOT an attorney, CPA, enrolled person, or appraiser) has a PTIN, refer the case to RPO and close the case.

   - If an unlicensed, unenrolled return preparer does not have a PTIN, add the unenrolled return preparer to the Prevent PTIN Upload Report (injunctions only) and close the case.

   - If a Circular 230 practitioner (i.e., is an attorney, CPA, enrolled person, or appraiser) has a PTIN, send the practitioner a PTIN Notification Letter, e.g., Proposed Revocation.


      1\. If the practitioner fails to respond to the notice within 10 calendar days, or responds in agreement that OPR’s information is accurate, revoke the practitioner’s PTIN in TPPS and forward all related information for LAB processing / case intake.


      2\. If the practitioner disputes the accuracy of OPR’s information, forward all documentation to LAB for case processing / intake.

   - If a Circular 230 practitioner has no PTIN, add the practitioner to the Prevent PTIN Upload Report (for injunctions only) and forward the case to LAB for processing / case intake.


4. For Injunctions (Preparation and Representation):



   - If an unlicensed, unenrolled return preparer has a PTIN and a CAF number, and is enjoined from preparation AND representation, send the practitioner a CAF Notification Letter, e.g,. Proposed Revocation.


      1\. If the unenrolled return preparer fails to respond to the notice within 10 calendar days, or responds in agreement that OPR’s information is accurate, notify the IRS CAF Unit by email to update the preparer’s status and refer the order to RPO to revoke the preparer’s PTIN in TPPS.


      2\. If the practitioner disputes the accuracy of OPR’s information, forward all documentation to LAB for case processing / intake.

   - If a Circular 230 practitioner has a PTIN and a CAF number, is enjoined from preparation AND representation, and the injunction orders the practitioner suspended or disbarred from practice before the IRS and the order provides for the revocation of the practitioner’s CAF number(s) and PTIN, revoke the practitioner’s PTIN in TPPS (or refer the injunction to RPO to revoke the PTIN), notify the IRS CAF Unit to update the practitioner’s CAF status, notify the EAP&M by email to update an EA’s status, and forward all related information to LAB for processing / case intake. LAB will send the suspended or disbarred practitioner a letter informing the practitioner of the suspension or disbarment and the other actions taken by OPR pursuant to the injunction.

   - If a Circular 230 practitioner has a PTIN and a CAF number, is enjoined from preparation AND representation, and the injunction permanently enjoins the practitioner from preparation and representation, but does not order the practitioner suspended or disbarred from practice before the IRS and does not provide for the revocation of the practitioner’s CAF number(s) and PTIN, send the practitioner a PTIN/CAF Notification Letter, e.g,. Proposed Revocation.


      1\. If the practitioner fails to respond to the notice within 10 calendar days, or responds in agreement that OPR’s information is accurate, notify the IRS CAF Unit by email to update a practitioner’s status, notify the EAP&M by email to update an EA’s status, revoke the practitioner’s PTIN in TPPS (or refer the injunction to RPO to revoke the practitioner’s PTIN), and forward all related information to LAB for processing / case intake.


      2\. If the practitioner disputes the accuracy of OPR’s information, forward all documentation to LAB for case processing / intake.


5. For Tax Convictions:



   - If the preparer is unlicensed and unenrolled, close the case without action.

   - If the preparer is licensed or enrolled, refer the case to LAB for processing / case intake.


**1.25.4.10.5** **(06-29-2016)**

#### Procedures for Limited Practice by Unenrolled Tax Return Preparers

1. Participants in the Annual Filing Season Program under Rev. Proc. 2014-42 are, in their limited practice before the IRS, subject to the duties and restrictions in Subpart B of Circular 230 and the incompetence and disreputable conduct provisions of §10.51(a). OPR will process alleged violations accordingly.


**1.25.4.10.5.1** **(06-29-2016)**

##### Processing Ineligibility Determinations

1. Review the referral, background material, and supporting evidence.

2. Prepare a recommendation and, if appropriate, a Notice of Proposed Determination of Ineligibility and Letter of Transmittal.

3. The unenrolled return preparer has 30 calendar days from the date of service to respond to the Notice of Proposed Determination of Ineligibility, unless the time for filing is extended based on the preparer’s request.

4. If the unenrolled return preparer requests a conference (under section 10.02 of Rev. Proc. 81-38), schedule, as soon as possible, a conference at a time convenient to the unenrolled return preparer and OPR.

5. After any conference, and after any receipt from the unenrolled return preparer of additional information as discussed during the conference (or the deadline has passed), review the evidence in the case file as a whole to determine whether to proceed with an ineligibility determination.

6. Draft either a Determination of Ineligibility or Determination Regarding Eligibility (as appropriate), and a Letter of Transmittal to the unenrolled return preparer and to the preparer’s representative (if applicable).

7. Assuming a preparer is determined ineligible for limited practice, then after expiration of the 30 day period for filing an appeal:



1. Notify the IRS CAF Unit by email to update the unenrolled return preparer’s status as a prospective representative.

2. Update the unenrolled return preparer’s status to the OPR intranet database and the IRB.


**1.25.4.10.5.2** **(06-29-2016)**

##### Processing Appeals of Ineligibility Determinations

1. An unenrolled return preparer served with a Determination of Ineligibility must appeal the Determination within 30 calendar days. An appeal must be written and signed by the preparer and includes the preparer’s reasons for appeal.

2. Under Rev. Proc. 81-38, an unenrolled return preparer may request, as part of an appeal, a conference. If the unenrolled return preparer requests a conference, schedule, as soon as possible, a conference at a time convenient to the unenrolled return preparer and OPR. If a request for a conference is not made in the appeal, or the unenrolled return preparer’s appeal is untimely, the unenrolled return preparer will be deemed to have waived the right to a conference.

3. After a conference (if any), make a preliminary determination on the appeal, incorporating into the record any additional information received from the unenrolled return preparer. The Director of OPR will grant or deny the appeal.

4. After the Decision on Appeal is rendered:



1. If applicable, notify the IRS CAF Unit by email of an update to an unenrolled return preparer’s status as a prospective representative.

2. Update the unenrolled return preparer’s status to the OPR intranet database and the IRB.


**1.25.4.10.5.3** **(06-29-2016)**

##### Reinstatement

1. Rev. Proc. 81-38 entitles an unenrolled return preparer to request reinstatement of the privilege of limited practice after one year following the effective date of the Determination of Ineligibility or Decision on Appeal, whichever is later. Per the revenue procedure, any decision as to reinstatement "will consider the nature of the violation that resulted in ineligibility, the period of ineligibility, and the preparer's current adherence to the standards of ethics and conduct established by this revenue procedure in evaluating the request for reinstatement to limited practice."


**1.25.4.10.6** **(06-29-2016)**

#### Procedures for Enrollment Appeals

1. RPO makes initial contact with the applicant notifying them of RPO’s decision to deny / limit enrollment. The applicant chooses whether to appeal the denial or limitation of their EA status.

2. For all appeals, review the appeal and supporting evidence, to include:



   - RPO’s Determination Memorandum

   - Applicant’s Appeal

   - Any correspondence exchanged between the applicant and RPO

   - Research on IDRS and Employee User Portal (EUP) databases for information on applicant's tax filing and payment history

   - Research professional licenses and verifying status

   - If applicable, judgment of criminal conviction or order of injunction


3. For Former Employee appeals, review the appeal and supporting evidence, to include:



   - Standard Position Description(s) of position(s) held by Former Employee

   - Employment History

   - TIGTA Results

   - ALERTS (Automated Labor and Employee Relations Tracking System). As an IRS database in which information about labor- and employee-relations cases is maintained, ALERTS is a potential source of information for OPR’s use in reviewing Former Employee appeals.


4. For EA appeals, review the appeal and supporting evidence, to include:



   - Form 23, _Application for Enrollment to Practice Before the Internal Revenue Service_


5. If the appeal package is not complete, either:



1. Return the case file to RPO for further development and submit the case for closure.

2. Contact RPO or applicant immediately by telephone or email for additional information.


6. Make a preliminary determination on the appeal, incorporating any additional information received from RPO or the applicant into the record. Determine whether the RPO decision is supported by the record. Do not overturn or disturb on appeal RPO's decision on the enrollment application unless the decision was the result of an abuse of discretion; that is, the decision was based on an erroneous interpretation of the law, on factual findings that are not supported by substantial evidence, or represents an unreasonable judgment in weighing relevant factors.

7. A copy of the final Letter of Transmittal and Decision on Appeal will be sent to:


    Return Preparer Office


    Attention: Director


    Internal Revenue Service


    1111 Constitution Avenue, NW


    ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡


    Washington, DC 20224


**1.25.4.10.7** **(06-29-2016)**

#### Procedures for 10.82 Cases (Expedited Suspensions)

1. For practitioners, section 10.82 expedites the due process procedures detailed in section 10.60 of Circular 230 for specific kinds of legal or ethical misconduct (10.82(b)(1)-(5)), generally reflected in independent third-party adjudications such as those of a court or a state disciplinary authority.

2. Practitioners subject to section 10.82 are served with an Order to Show Cause (OSC) why that practitioner should not be indefinitely suspended from practice before the IRS. Practitioners are given an opportunity to respond to the allegations in writing, and to request a conference. Practitioners found to be in violation of section 10.82, who have been served with an OSC, may be suspended from practice before the IRS. Suspended practitioners have two years to demand the filing of a §10.60 complaint with an ALJ. Suspensions imposed under section 10.82 are indefinite and remain effective until either:



1. OPR lifts the suspension by granting a practitioner’s request for reinstatement; or

2. The suspension is lifted or modified by an ALJ in a subsequent proceeding brought pursuant to section 10.60 of Circular 230.


3. Review whether an XP Proceeding and indefinite suspension is appropriate based upon the nature of and facts underlying the independent third-party determination or other XP basis under section 10.82(b). This review includes:



   - Reading any transmittal and / or referral memorandums or comments;

   - Reviewing the supporting evidence for the XP Proceeding;

   - Ensuring for cases involving a loss of license under section 10.82(b)(1), that any orders, decisions, finding of facts, etc., issued by the corresponding licensing authority are in the case file. This includes researching any loss of license in a reciprocal jurisdiction and / or contacting any licensing authorities if there are concerns that a loss of license was not for cause;

   - Ensuring for cases involving convictions under section 10.82(b)(2), that any plea agreements, judgments, sentencing memorandum, etc., issued by the presiding court are in the case file;

   - Ensuring for cases involving section 10.82(b)(3), that any documents supporting the section 10.79(d) conditions purportedly violated are in the case file;

   - Ensuring for cases involving section 10.82(b)(4), that any judgments, orders, stipulations, etc., of the court are in the case file;

   - Ensuring for 10.82(b)(5) cases that current tax transcripts are in the case file;

   - Checking for additional conduct potentially in violation of section 10.82 such as loss of other professional licenses for cause, criminal convictions for either Title 26 violations or crimes involving fraud or dishonesty, or noncompliance with tax-return-filing requirements;



     ### Note:



     Gather the supporting documentation necessary to substantiate any supplemental violations outside of section 10.82 should the practitioner subsequently request a section 10.60 administrative complaint pursuant to section 10.82(g) after an Order for Indefinite Suspension is issued.

   - Checking the practitioner’s individual, business and / or employment tax compliance, this includes checking for other business entities with which the practitioner is or may be associated;

   - Reviewing the case for any miscellaneous civil penalties assessed against the practitioner by running an IMFOLI report in IDRS or contacting a RPC, this includes requesting penalty files where appropriate;

   - Investigating the practitioner’s return preparation activities;

   - Confirming via IDRS the practitioner’s INOLE / 26 USC 6212 address;

   - If the XP is based on the loss of a state license, check for the submission of any Forms 2848 where the practitioner falsely asserted membership in good standing in a State Bar and / or State Board of Accountancy. Part of this search should involve a check to determine if the practitioner has multiple CAF numbers; and

   - Check CCMS and legacy OPR systems for prior cases involving the same practitioner and OPR’s [Search for disciplined tax professionals](https://www.irs.gov/tax-professionals/search-for-disciplined-tax-professionals), for prior discipline.



     ### Note:



     The above are not all-inclusive, but are meant to provide a framework for investigating possible ancillary Circular 230 misconduct, including tax noncompliance that is not a basis for suspension under section 10.82(b)(5). Employees are encouraged to develop each case based on the relevant facts and circumstances.


4. Continue with the XP Proceeding by:



   - Drafting an OSC that alleges facts supporting all appropriate section 10.82(b) paragraphs with relevant documents attached as exhibits to the draft OSC. For example, any OSC based on 10.82(b)(2), should allege whether the crime involved was a Title 26 violation, was a crime involving dishonesty or breach of trust, and / or was a felony for which the conduct involved renders the practitioner unfit to practice before the IRS.

   - Drafting a Letter of Transmittal to the practitioner for the OSC.

   - Drafting a file memorandum supporting the recommendation to pursue an XP Proceeding and why an injunction is an appropriate basis for an XP Proceeding.

   - Both documents, along with the _Rights and Responsibilities_ document are mailed to the practitioner.


5. The practitioner has 30 calendar days from the date of service to respond to the OSC, unless the time for filing is extended.



### Note:



Extensions will be granted rarely in 10.82(b) cases.

6. If the practitioner responds to the OSC and requests a conference (under section 10.82(e)), as soon as possible, attempt to schedule a conference at a time convenient to the practitioner and OPR. If a request for a conference is not made in the response, or the practitioner’s response is not otherwise timely, the practitioner will be deemed to have waived the right to a conference.

7. After any conference, and with the benefit of any additional information the practitioner timely provides as agreed during the conference, determine:



   - If an Order for Indefinite Suspension is appropriate.

   - If there is not enough information, based on the evidence in the case file, to issue an Order for Indefinite Suspension.

   - If the practitioner has shown good cause why the practitioner should not be indefinitely suspended.


8. Draft an Order for Indefinite Suspension or an Order Regarding Indefinite Suspension (as appropriate), a Letter of Transmittal to practitioner and to practitioner’s representative (if present), and a supporting file memorandum with the procedural history and relevant facts outlined.

9. The Order for Indefinite Suspension or Order Regarding Indefinite Suspension and the Letter of Transmittal, along with the _Guidance on Restrictions During Suspension or Disbarment_ (when suspension is imposed) are mailed to the practitioner.



1. Notify the IRS CAF Unit by email to update a practitioner’s status.

2. Notify the EAP&M by email to update an EA’s status.

3. Update the practitioner’s disciplinary action to the OPR intranet database.

4. Publish the practitioner’s disciplinary action in the IRB.


**1.25.4.10.7.1** **(06-29-2016)**

##### Procedures for Cases Forwarded to GLS for Litigation (10.60 Hearing)

01. When a request for a section 10.60 Proceeding pursuant to section 10.82(g) of Circular 230 is made to OPR, a new case is opened in CCMS. If possible, the employee who worked the XP Case, or the Attorney that attended the XP Case conference with a Paralegal, will be assigned the section 10.82(g) request for a section 10.62 Complaint.

02. Immediately determine if the section 10.82(g) request is timely. Once an Order for Indefinite Suspension has been mailed, the practitioner has two years from the action effective date to request in writing a section 10.60 Proceeding / 10.62 Complaint pursuant to section 10.82(g) of Circular 230.



    - If the 10.60 Request is timely, OPR has 60 calendar days from the date of receipt to prepare and coordinate with General Legal Services (GLS) for filing and service of the requested section 10.62 Complaint.

    - If the 10.60 Request is received after the deadline (i.e., is submitted more than 2 years after the effective date of the practitioner’s expedited suspension), the request will not normally be honored. However, any request believed to be untimely should immediately be discussed with management. If there is concurrence that the request is untimely and should not otherwise be honored, draft a letter to the practitioner advising that the demand for a 10.60 proceeding will not be honored because it is untimely.


03. With a timely 10.60 Request, immediately email a 10.60 Request Notification to management, the GLS Branch Chief, and the appropriate GLS Counsel. The email notification must include the 10.60 Request Received Date (i.e., the OPR stamped received date).



    ### Note:



    The Memorandum of Understanding (MOU) between OPR and GLS provides that OPR performs litigation support and acts as the point of contact for GLS. An Attorney from GLS litigates the case.

04. Develop and submit the draft Complaint, draft GLS Matrix, and a Cover Memorandum for approval within 20 calendar days of the 10.60 Request Received Date. If the draft Complaint cannot be submitted for approval within the first 20 calendar days, immediately notify management. If management agrees, submit the draft GLS Matrix and Cover Memorandum as soon as they are ready within the 20 calendar day period, and submit the draft Complaint no later than a date specified by the Section Manager.

05. Ensure that the original XP Case file contains all of the information and documentation required to successfully defend the Order of Indefinite Suspension pursuant to section 10.82. If any necessary documentation or information is missing (e.g., State Board / State Bar decisions, correspondence, copies of tax returns) immediately take appropriate action(s) to obtain the missing documents / information as soon as possible.

06. Research for other Circular 230 violations not associated with the original Order of Indefinite Suspension:



    - Check the status of the practitioner’s professional credentials.

    - Check PACER for criminal convictions.

    - Check for civil penalties on IMFOLI.

    - Check CCMS and legacy OPR systems for referrals / allegations subsequent to the Order of Indefinite Suspension.

    - Check for DOJ Injunctions.

    - Run a tax non-compliance check for individual and business returns (with a search for business entities).

    - Check the practitioner’s return preparation and PTIN status.


07. If a potentially new Circular 230 issue is discovered, immediately take action to obtain supporting documents as soon as possible (i.e., ESTAB requests and email requests to IRS personnel). Assess the documentation to determine whether there is proof to support a new allegation. If there is proof, OPR will inform GLS of the discovery of the new allegation.



    1. If there is a lack of information or material issues remain unsolved, use section 10.20 to expeditiously direct the practitioner’s attention to these issues with specific requests for information. Consider the available information, unresolved issues, and the practitioner’s response to determine whether pursuing a new allegation is warranted. Consultation with management is required.

    2. If or when there is proof to support a new allegation, determine whether to include the new allegation in the draft Complaint. This decision depends on whether a supplemental allegation can be developed and included in the final Complaint before the 60 calendar day filing deadline.



       ### Note:



       A minimum 10 calendar day response time should be provided to the practitioner whenever possible. This may be extended depending on the extent of the alleged violation(s).

    3. If the projected due date for the practitioner’s response to the new allegation falls at least one week before the 60 calendar day filing deadline, include the new allegation in the draft Complaint.

    4. If the projected due date for the practitioner’s response to the new allegation falls later that one week before the 60 calendar day filing deadline, do not include the new allegation in the draft Complaint. Prepare the draft Complaint based only on the original Order of Indefinite Suspension.


08. Organize the original XP case file documentation into a six-panel red case folder. The six-panel red case folder will be kept at OPR and used throughout the 10.60 Request case. Documents not relevant to the original XP Case and the current 10.60 Request may be retained in the original XP case file. The six-panel red case folder is organized as follows starting with panel 1 on the inside of the left cover of the case file:



    - Panel 1: OPR memorandums and internal documentation and correspondence (not to the practitioner or to GLS).

    - Panel 2: Correspondence to / from the Practitioner (including email exchanges).

    - Panel 3: Correspondence between OPR and GLS, including the transmittal memorandum and matrix (as well as email exchanges).

    - Panel 4: Formal litigation documents from GLS (all legal documents and documents filed with the ALJ).

    - Panel 5: Documented proof of jurisdiction.

    - Panel 6: OPR's documentary evidence to prove all elements of the violation(s) alleged (e.g., tax transcripts, referrals, TIGTA reports, and results of case investigation). Panel 6 is effectively the draft evidentiary file without redactions, without a redaction key, and without Panels 2 and 5.


09. If OPR decides to pursue a new Circular 230 allegation with the intent to include it in the final Complaint as a supplemental allegation, attempt to mail a Supplemental Allegation Letter within two weeks of the 10.60 Request OPR Received Date. The Supplemental Allegation Letter should instruct the practitioner to respond directly to OPR and, whenever possible, the letter should provide the practitioner a minimum of 10 calendar days to respond.



    - If the draft Complaint was submitted to GLS without the supplemental allegation, begin revising the draft Complaint to include the supplemental allegations.


10. Complete development of the draft Complaint and the draft GLS Matrix. The GLS Matrix must list the documents OPR will use as the "Evidentiary File." This includes all jurisdictional documents, procedural correspondence with the practitioner, and documents evidencing the elements of the alleged violation(s). The list of documents effectively covers Panels 2, 5, and 6 of the six-panel red case folder.

11. Submit the draft Complaint, draft GLS Matrix, and a Cover Memorandum for approval within 20 calendar days of the 10.60 Request Received Date. The Director must approve any draft Complaint or Revised Complaint prior to sending to the GLS Attorney.

12. Email the approved draft Complaint, draft GLS Matrix, and the Cover Memorandum to the GLS Attorney.

13. Prepare the evidentiary file in a two-panel green folder containing copies of the entire six-panel red folder, except for documents that are covered under the Privacy Act exemptions, such as attorney-work product, attorney-client, and deliberative process privileges, or, are immaterial or irrelevant. Effectively, Panels 1 and 3 of the OPR Six-Panel Red Case File are excluded. In practice, the evidentiary file will provide all documents listed in the GLS Matrix as OPR’s Evidentiary File.



    - For tax compliance allegations, all tax transcripts must be printed within two weeks of the expected filing date of the Complaint. Certify hardcopies of EUP transcripts through use of a seal. Be sure the Director is available in order to have the official transcripts certified in a timely manner.


14. Prepare a total of four evidentiary files (3 redacted and 1 un-redacted). Provide two of the redacted files to the GLS Attorney at least three business days prior to the 60 calendar day deadline. Under section 10.63(d), the practitioner is entitled to receive the evidence on which the complaint is based (a redacted copy of the evidentiary file) within ten calendar days of filing the Complaint. The two remaining evidentiary files (1 redacted, and 1 un-redacted) stay with OPR. Redactions should be should be in both italics and brackets.

15. Complete the final Complaint (or Revised Complaint), final GLS Matrix, and a Cover Memorandum. Upon receipt of the Director’s approval and no later than three business days prior to the 60 calendar day deadline:



    - Email the approved final Complaint (or Revised Complaint), final GLS Matrix, and a Cover Memorandum to the GLS Attorney.

    - Mail two of the redacted evidentiary files to the GLS Attorney (via certified mail, overnight delivery with return receipt requested).

    - Email the redaction key for the evidentiary files to the GLS Attorney.


16. The practitioner has 30 calendar days to respond. Subsequent action will depend on whether the practitioner timely files a proper response.



    - If the practitioner does not file a proper response (pursuant to section 10.64(b)) within 30 calendar days of service and does not request an extension of time from the ALJ, a Motion for Default Judgment may be warranted and can be filed with the ALJ, and served on the practitioner.

    - If the practitioner files a proper response (pursuant to section 10.64(b)) to the Complaint within 30 calendar days of service, or within an extension period as provided by the ALJ, then, in lieu of a motion for default decision, discovery may be appropriate, such as in anticipation of a Motion for Summary Adjudication. Section 10.66 provides that OPR may file a reply, but that, without a reply, any new matters raised in the response are deemed denied.


17. If the case proceeds to hearing, at the conclusion of discovery, the ALJ will schedule an evidentiary hearing date no later than 180 calendar days after the time for filing a response has elapsed. Hearings are formal events, and recorded by a court reporter with the testimony of all witnesses taken under oath. OPR will set up the court reporter.

18. If a hearing is held, the ALJ will set a briefing schedule in consultation with the parties. OPR will assist with the drafting of any post-hearing briefs. Within 180 calendar days after the conclusion of the hearing and the receipt of any post-hearing briefs (proposed finding of facts and conclusions of law) timely submitted by the parties, the ALJ should enter a Preliminary Decision and Order. With an entered decision, the ALJ will also forward the ALJ’s judicial file to OPR. An ALJ’s file constitutes an official administrative record. OPR is responsible for producing the entire official administrative record if there is a request for an appeal to the AA. The AA should only review information presented to the ALJ that is part of the official record. The ALJ administrative file should never be altered in any way.

19. If a Motion for Summary Adjudication is filed, the ALJ should rule on the motion within 60 calendar days after the party in opposition files a written response, or after 90 calendar days if no written response is filed.

20. After the ALJ Decision, as a courtesy, immediately prepare for the practitioner a letter detailing the procedures for appeal including the _Rights and Responsibilities_ document, along with a copy of the ALJ Decision. A copy of the _Guidance on Restrictions During Suspension or Disbarment_ will be provided if the ALJ Decision imposed either a suspension or disbarment and the practitioner does not appeal timely.

21. Either party has 30 calendar days from the date the ALJ decision is served on the parties (section 10.77(b)) to appeal by filing a Notice of Appeal (NoA) and supporting brief with the Treasury AA. The AA makes the final agency decision (FAD).

22. If the practitioner (the respondent in the proceeding) appeals the ALJ Decision, the practitioner will serve a copy of the NoA and brief on OPR. Upon receipt, OPR transmits the copies to HQ GLS, the appropriate GLS Area Counsel, and OPR’s Director.

23. The assigned OPR attorney should immediately transmit a copy of the practitioner’s NoA and supporting brief to the Legal Processing Division of CC:P&A (LPD) (effectively, the Counsel Service Desk for the AA). Bring one additional copy of the Letter of Transmittal to be time and date stamped as proof of filing the practitioner’s appeal with the LPD and provide GLS a copy of the time and date stamped Letter of Transmittal as proof of filing, if requested.

24. The response brief for OPR must be filed with LPD within 30 calendar days after OPR is served with the practitioner’s NoA. If OPR has already received the ALJ’s case file (Administrative Record), proceed to copy the Administrative Record and submit it with the practitioner’s NoA and brief to LPD.

25. Prepare the Proof of Service, the Administrative Record (if not previously submitted), and a Letter of Transmittal to accompany the response brief. Deliver the documents to LPD. Bring one additional copy of the Letter of Transmittal to be time and date stamped as proof of filing the responsive brief with the LPD and provide GLS a copy of the time and date stamped Letter of Transmittal as proof of filing, if requested.

26. At the same time as the response brief is filed with the LPD for transmission to the AA, OPR serves a copy of the response brief on the practitioner or, if the practitioner is represented, the practitioners representative. Retain in the case file one copy of all documents filed with the AA.

27. For an OPR appeal, the NoA, brief, Proof of Service, and Administrative Record (from the ALJ’s file), along with a Letter of Transmittal, are delivered to the LPD.

28. At the same time as OPR’s NoA and supporting brief are filed with LPD for transmission to the AA, OPR serves a copy of the NoA, brief, and administrative file on the practitioner or, if the practitioner is represented, on the practitioner’s representative.

29. The practitioner has 30 calendar days to file a reply brief. Immediately upon receipt of the practitioner’s reply brief OPR will transmit it to HQ GLS and the appropriate GLS Area Counsel. OPR will also immediately deliver the practitioner’s brief to LPD. OPR will bring one additional copy of the Letter of Transmittal to be time and date stamped as proof of filing the practitioner’s reply brief with LPD. OPR will provide GLS a copy of the time and date stamped Letter of Transmittal as proof of filing, if requested. OPR retains in the case file one copy of all documents filed with the AA.

30. In accordance with section 10.78 of Circular 230, the AA should issue a Decision on Appeal within 180 calendar days after receipt of the appeal. The AA’s Decision on Appeal constitutes the FAD when issued.

31. While the AA Decision on Appeal may be appealed by the practitioner to a Federal District Court, OPR proceeds with announcing the sanction in the IRB and updating the practitioner’s practice status.

32. Should the practitioner disagree with the AA’s Decision on Appeal, a complaint may be filed in Federal District Court. The Federal District Court reviews the entire administrative record. The proceeding is not a new trial. The Administrative Procedure Act contains provisions governing the proceeding (Refer to 5 USC 551-559, 702). After the AA issues a Decision on Appeal, the AA will also forward the appellate case file to OPR. An AA’s file constitutes an official administrative record of the Agency. OPR is responsible for producing the entire official administrative record if a complaint is filed in Federal District Court.

33. The ALJ decision becomes a FAD if neither party appeals within 30 calendar days from the date of the ALJ decision. If either party appeals to the AA, then the AA Decision on Appeal becomes the FAD when issued.

34. After a FAD:



    - When applicable, prepare a press release and / or Business Unit News (BUN) article.

    - Draft a Letter of Transmittal to the practitioner that summarizes the FAD, along with a copy of the ALJ decision, or the ALJ and AA decisions, and a copy of the _Guidance on Restrictions During Suspension or Disbarment_ should a suspension or disbarment be imposed.

    - Per OPR / GLS MOU, GLS should return to OPR all evidentiary materials upon the issuance of a FAD.

    - Only if appropriate (cases involving suspensions or disbarments), notify the IRS CAF Unit to update the practitioner’s status.

    - Only if appropriate (cases involving suspensions or disbarments), notify the EAP&M to update an EA’s status.

    - Update the practitioner’s disciplinary action to the OPR intranet database.

    - Publish the practitioner’s disciplinary action in the IRB.

    - Post the finalized press release to OPR’s _OPR Press_ webpage on IRS.gov/.

    - Post the finalized BUN to the OPR’s _Business Units News_ webpage on OPR’s internal website and IRWeb’s homepage under _News From the Business Units_.


**1.25.4.10.8** **(06-29-2016)**

#### Procedures for 10.60 Disciplinary Cases (Conduct, Compliance, Hybrid)

01. Disciplinary Cases that include both practitioner personal tax compliance and issues of misconduct in practice before the IRS are considered Hybrid Cases. If the potential Circular 230 violations of a case are confined to personal tax compliance (within section 10.51(a)(6)), then the case is a Compliance Case. If the potential violations do not include failures of personal tax compliance, then the case is a Conduct Case.

02. Section 10.60 Disciplinary Cases conclude in one of three ways:



    - OPR determines that non-disciplinary action is appropriate and closes the case accordingly.

    - The practitioner offers, and OPR accepts, a proposed disciplinary action under section 10.61(b)(1) to settle the case.

    - OPR refers the case to GLS for filing of an administrative complaint with an ALJ, who decides the case (with any appeal decided by the AA).


03. Review the case information by conducting a First-Level Case Investigation.



    - Review the referral and accompanying evidence.

    - Determine if additional cases should be opened against any other practitioners mentioned in the referral. If other practitioners are found, additional cases may be opened.

    - Confirm the practitioner’s SSN.

    - Confirm the practitioner’s INOLE / 26 USC 6212 address.

    - Check CCMS and legacy OPR systems for prior cases involving the practitioner, as well as the OPR internal database for prior discipline.

    - Run a comprehensive report in Accurint with the practitioner’s SSN that excludes family members, neighbors, and associates (unless necessary) to minimize third-party information in the case file.

    - Confirm a nexus between the practitioner and Circular 230.

    - Determine that the individual is or appears to be a Circular 230 practitioner - an attorney, CPA, enrolled professional, appraiser, or unenrolled return preparer subject to Circular 230.

    - Check for a PTIN and return preparation activity (RPVUE - IMF and BMF returns prepared in the current and three prior years).

    - Search IDRS RPINK to find all practitioner CAF numbers. The practitioner’s address history in Accurint may be used to verify additional CAF numbers. CFINK and CFINKH reports are printed for each CAF number.

    - Research professional licenses and verifying the status of each. The practitioner’s address history in Accurint should be used to check for both attorney and CPA licenses in each state where the practitioner resided.

    - Notify the person making the referral (if an internal source) regarding the case assignment. If the referral is external, then contact the person making the referral only to verify or seek additional information.


04. Conduct a Second-Level Case Investigation by gathering documentation necessary to investigate / substantiate the original allegations as well as searching for additional violations not alleged to OPR. Such research may include:



    - For civil penalty referrals, request the examiner’s workpapers and copies of the underlying tax returns, and verify the assessment of the civil penalty(ies) in IDRS IMFOLT;

    - For allegations of loss of professional license or for criminal tax or felony convictions, request copies of the orders or judgments;

    - Check for other civil penalties assessed against the practitioner; for example, run an IDRS IMFOLI and IMFOLT search, and then research the penalty reference code, or contact a RPC (this includes requesting penalty files where appropriate);

    - For allegations of unauthorized practice, research CAF records and request copies of the Forms 2848 filed with the IRS;

    - Verify the tax non-compliance issues that were referred and conduct further research for additional tax non-compliance.


05. A baseline tax compliance check includes, but is not limited to, the following:



    - Check the practitioner’s IMFOLI for unfiled Forms 1040 and IRS prepared substitutes for return (SFRs) under the authority of IRC 6020(b). You must verify a filing requirement for each unfiled return and verify each unfiled return with IMFOLT for years with SFRs, to see if the practitioner either accepted the SFR or subsequently filed a return amending the SFR.

    - Treat unaccepted or un-amended SFRs as unfiled returns.

    - Check the practitioner’s IMF and BMF accounts for outstanding balances, not currently under an installment agreement or an offer in compromise. For indications of an ability to pay, review several recent years of tax return data (EUP / TDS - Tax Return Transcripts for the three most recent years, also check IDRS TRDBV for prior years beyond the three), as to trends regarding total income, expenses, or gross receipts. Chart the number of returns prepared per year with both PTIN and EIN to track business activity.

    - Print five prior years of either EUP Wage and Income Transcripts or IDRS IRPTR Transcripts.

    - Search for business entities owned or controlled by the practitioner.

    - Use NAMEE to search for EINs for businesses listed on the practitioner’s Accurint report. Run an additional Accurint business entity report with the practitioner’s name and location (state).

    - Check EUP Wage and Income Transcripts (or IDRS IRPTR Transcripts) for connections to business entities, such as K1s, Forms 1099, and Forms W-2.

    - Check for entity information the practitioner self-reported on a PTIN application using IDRS RPVUE with definer ’P’.

    - Check CAF histories (using CFINKH) for evidence of business entities.

    - For EINs, with possible practitioner ownership or control, print out BMFOLE to determine the practitioner’s relationship to the entity, as well as BMFOLI to check for unfiled returns and possible civil penalties.

    - Investigate the practitioner’s return-preparation activity in connection with all business entities. This expands the RPVUE research (current and 3 prior years for both IMF and BMF returns) to include each EIN linked to the practitioner.

    - Run the OPR-IAT tool to search for late-filed returns with both the practitioner’s SSN and all linked EINs. IAT allows the manual entry of 2 EINs with each report. For practitioners with > 2 EINs, run the IAT tool multiple times.


06. Review the conduct and / or compliance allegations, applicable law, and the scope of the available supporting documentation to determine whether to proceed with further case investigation and development based on the severity of the alleged misconduct (both the past harm or risk of future harm to both taxpayers and to the tax system) and the extent to which the documentation tends to prove the allegations.

07. If it is determined that either the conduct and / or compliance allegations are not potential violations of Circular 230, the violations are not actionable, or the violations do not warrant a Circular 230 sanction or a Deferred Disciplinary Agreement (DDA), one of the following courses of action should be taken:



    - A non-disciplinary case closing, such as closing without sanction and without further action (or returning the case to the field for any Title 26 consideration).

    - If sufficient information is received, developed, and reviewed, a determination may be made that with regard to the allegations a non-disciplinary closure action should be taken, such as sending an initial Soft Letter (soliciting a response) should be sent to the practitioner, followed by a closing Soft Letter (which acknowledges the practitioner’s response, if any, to the initial letter).

    - Splitting the conduct and compliance issues, then proceeding with two different letters. For example, the conduct allegations may close with an initial and then final Soft Letter or with a Reprimand (after an allegation or pre-allegation letter), while the compliance issues may merit moving forward toward a section 10.60 disciplinary proceeding.

    - If the practitioner cures or offers satisfactory mitigation for any tax non-compliance identified in a letter from OPR to the practitioner that provides, for example, a 60-day opportunity for the practitioner to remedy the return-filing and / or tax-payment delinquencies, send a closing letter for the tax compliance allegations. Either continue investigating any conduct allegations or, if those allegations were also resolved by the practitioner’s response, then include appropriate closing language for the conduct allegations within the tax-compliance closing letter.


08. If it is determined that the allegations in a referral or complaint are potential violations of Circular 230 and are actionable, one of the following courses of action should be taken:



    1. Pre-Allegation Letter: If the case requires further investigation and an Allegation Letter is not expected to be drafted for 60 calendar days or more, consider drafting a Pre-Allegation Letter. If the practitioner has correctable lapses in tax compliance, such as outstanding balances or unfiled returns, then language from a standard 60 Day Letter should be included within the Pre-Allegation Letter (in essence affording the practitioner 60 days to correct delinquencies).

    2. Section 10.20 Letter: If information is missing from the case file that is material to whether a violation occurred, and unavailable through IRS sources, draft a Section 10.20 request letter to the practitioner for the needed information. If the Section 10.20 information request is the first correspondence from OPR to the practitioner, 60 Day Letter language can be added for any compliance problems.

    3. Allegation Letter: If the investigation, including after review of any information responsive to a Section 10.60 information request, indicates a sanction is warranted, draft an Allegation Letter reciting potential violations of Circular 230 with specific facts supporting each alleged violation.


09. If the practitioner:



    - Retains Counsel: Obtain a Form 2848 appointing the representative for the Circular 230 matter, or obtain a letter of representation if the case does not involve any tax non-compliance on the practitioner’s part.

    - Requests additional time to respond to a Section 10.20 information request or to provide documents: One extension may be granted, up to 30 calendar days, from any specified deadline. Communicate in writing the new deadline by either fax or email.


10. A practitioner has 30 calendar days to respond to the Allegation Letter. If the Allegation Letter is the first contact with the practitioner and it includes 60 Day Letter language in regard to tax noncompliance, the practitioner should still be directed to provide a response to both the conduct and tax-compliance issues raised in the letter within the usual 30 day period; however, a second, follow-up date should be set after 60 calendar days for the practitioner to resolve / cure the tax-compliance delinquencies.

11. If the practitioner responds to the Allegation Letter and requests a conference, schedule a conference at a time convenient to the practitioner and OPR. Generally, conferences should occur no later than 30 calendar days from the deadline to respond to the Allegation Letter. During the conference:



    - Open by describing the nature and basis of the proceeding, the practitioner’s rights and responsibilities, and ask the practitioner to present any oral response to the conduct and tax-compliance allegations.

    - Ask the practitioner questions in an attempt to better understand the circumstances surrounding the allegations.

    - For all claims or statements made by the practitioner during the conference that were not already included in a written response to OPR, request that the practitioner submit the new information in a supplemental written response and provide supporting documentation.

    - Set a deadline for the practitioner to provide a supplemental response and any additional information. Deadlines should be confirmed in writing (email or fax) to the practitioner immediately after the conference and should not exceed 30 calendar days from the date of the conference, absent management approval.

    - If the practitioner’s tax non-compliance (unfiled returns or unpaid balances) remains unresolved at the time of the conference, inquire as to the reasons for the delay and set a deadline for the practitioner to address the issues.


12. If additional time is granted during the conference for the practitioner to provide further documentation, or to cure the tax non-compliance, the deadline should not exceed 30 calendar days for the response and 60 calendar days to cure the compliance.

13. After an Allegation Letter is mailed, and a conference is offered or held, review the allegations based on the evidence in the case file and:



    - Determine if a sanction or DDA may be appropriate.

    - Determine if there is not enough information to support a sanction or DDA.


14. If the practitioner has not offered a settlement under section 10.61(b)(1), after an Allegation Letter and an opportunity for a conference, contact the practitioner to encourage such an offer and:



    - Outline the various closing options available for the case.

    - Set a deadline for the practitioner to make an offer, if an offer is not presented during the conversation.

    - Communicate that any offers must be sent in writing and set a deadline for such submission.

    - If the practitioner does not submit a settlement proposal by the deadline, or within 30 calendar days after a conference if a deadline was not set, or if the practitioner does not respond, prepare the case for forwarding to GLS.


15. If the practitioner has made an offer to resolve the case under section 10.61(b)(1), make a written recommendation, through any assigned reviewer and the Section Manager, to the Director recommending whether the practitioner’s offer is appropriate or not appropriate for OPR to accept. If the practitioner’s offer is not appropriate, then propose in the recommendation a counter-offer.



    - Draft the settlement agreement, reflecting either the practitioner’s offer (if recommended for acceptance) or the proposed OPR counter-offer.

    - Draft a Letter of Transmittal to the practitioner that notates a 15 calendar-day deadline to accept the settlement agreement.



      ### Note:



      Draft settlement agreements involving suspensions or disbarments ordinarily should contain conditions for reinstatement to practice that are customized to the practitioner’s situation.


16. If the practitioner accepts the draft agreement, then the practitioner should sign the settlement agreement and mail the original back to OPR. The Agreement is not final or effective until signed by the OPR Director.

17. The Director reviews and countersigns the agreement. A copy of the fully executed agreement is mailed to the practitioner under a Letter of Transmittal. Also enclose the _Guidance on Restrictions During Suspension or Disbarment_ if the agreement involves either an immediate agreed-upon suspension or disbarment or the agreement is a DDA (in which any discipline is deferred) that includes a sanction of suspension or disbarment for a default of the agreement. The original signed agreement is kept with the case file.

18. If the settlement agreement provides for immediate suspension or disbarment from practice or otherwise results in a change to the practitioner’s CAF status:



    - Notify the IRS CAF Unit by email to update the practitioner’s status.

    - Notify the EAP&M by email to update an EA’s status.

    - Update the practitioner’s disciplinary action to the OPR intranet database.

    - Publish the practitioner’s disciplinary action in the IRB.


19. If the practitioner and OPR are unsuccessful in negotiating an acceptable disposition, then refer the case to GLS.


**1.25.4.10.8.1** **(06-29-2016)**

##### Procedures for Cases Forwarded to GLS for Litigation (10.60 Hearing)

01. If settlement cannot be reached, a complaint, described in section 10.62, will be filed to initiate an administrative hearing before an ALJ. Attorneys from the IRS Office of Chief Counsel - GLS file the administrative complaint and represents OPR at an administrative hearing before the ALJ. The ALJ issues a decision that may be appealed by either OPR or the practitioner to the Treasury AA, who will then render the FAD.

02. The MOU between OPR and GLS provides that OPR performs litigation support and the assigned OPR attorney acts as the OPR point of contact for GLS. GLS litigates the case.

03. OPR will consider settlement negotiations with a practitioner throughout the 10.60 hearing process.

04. A final check should be completed of the existing allegations, as detailed in the Allegation Letter, and a final check done for additional Circular 230 misconduct outside the scope of the original case. Request and obtain supporting documents for any possible supplemental Circular 230 misconduct. If additional provable misconduct is discovered, a superseding Allegation Letter must be sent to the practitioner in order to provide proper notice and opportunity to respond.

05. For tax-compliance allegations, update the compliance history by checking both the existing allegations (of unfiled returns and balances) as well as any recent filing requirements of the practitioner not reflected in the Allegation Letter. Tax transcripts should be checked within two weeks after sending the file to GLS for recent filings or other account activity. Additional counts of tax non-compliance (for other tax years or quarters), of the same basic type previously included in the Allegation Letter, may be included for the first time in the GLS Last Chance Letter to provide the practitioner notice and opportunity to respond before the additional allegations are included in the Administrative Complaint.

06. If substantial recent tax non-compliance is found, such as involving business entities with which the practitioner is associated, then a superseding Allegation Letter must be sent. Generally, for cases that at the time of the Allegation Letter were limited to conduct as a practitioner, a superseding allegation letter is mandatory to newly raise any tax-compliance allegations.

07. Prepare the case file for GLS. Review the original case file, particularly the file memorandum, and determine whether all supporting documentation for the proceeding is present. If not, supplement the file as soon as possible.

08. Organize the original case file into a six-panel red case folder. The six-panel red case folder will be kept at OPR and used throughout the 10.60 process. Documents not relevant to the allegations in the 10.60 proceeding may be retained in the original green case file . The six-panel red case folder is organized as follows starting with panel 1 on the inside of the left cover of the case file:



    - Panel 1: OPR memorandums and internal documentation and correspondence (not to the practitioner or to GLS).

    - Panel 2: Correspondence to / from the Practitioner (including email exchanges).

    - Panel 3: Correspondence between OPR and GLS, including the transmittal memorandum and matrix (as well as email exchanges).

    - Panel 4: Formal litigation documents from GLS (all legal documents and documents filed with the ALJ).

    - Panel 5: Documented proof of jurisdiction.

    - Panel 6: OPR's documentary evidence to prove all elements of the violation(s) alleged (e.g., tax transcripts, referrals, TIGTA reports, and results of case investigation). Panel 6 is effectively the draft evidentiary file without redactions, without a redaction key, and without Panels 2 and 5.


09. Prepares the appropriate GLS documents by drafting a GLS Cover Memorandum, GLS Matrix, and draft Administrative Complaint.



    1. The GLS Cover Memorandum should be addressed to the GLS Area Counsel for the region in which the practitioner resides.

    2. The GLS Matrix must list the documents that will be used as the evidentiary file, including: all jurisdictional documents, correspondence with the practitioner, and documents evidencing the elements of the alleged misconduct. The list of documents in the GLS Matrix is a draft version of the evidentiary file to be produced after the counts in the Administrative Complaint are finalized with GLS.

    3. Use the practitioner’s INOLE / 26 USC 6212 address for proper service of the Administrative Complaint.

    4. Case numbers for GLS complaints are provided by OPR’s O&M Branch. O&M maintains a litigation log and assigns a unique number to each complaint.



       ### Note:



       Case numbers are only assigned immediately prior to the filing of a complaint. Draft complaints are sent to GLS without case numbers.


10. After the GLS documents are approved by the Director of OPR, email the GLS documents (GLS Cover Memorandum (signed by the Director), GLS Matrix, and the draft Administrative Complaint) to the appropriate GLS Area Counsel and GLS Branch Chief (Claims, Labor and Personnel Law Branch). Hard copies of the GLS Matrix and Cover Memorandum are mailed to the appropriate GLS Area Counsel.

11. All future documents and correspondence in the case will be sent from OPR to the GLS attorney assigned to the case.

12. Prepare the GLS case file in a two-panel green folder by copying relevant documents from OPR’s six-panel red case folder. All original documents remain with OPR. Make two copies of the GLS case file. One copy will be kept as proof of what documents were sent to GLS.

13. Ship, per IRS procedures (See IRM 1.22.3, _Addressing and Packaging_), one copy of the green GLS case file to GLS.



    1. If additional conduct in apparent violation of Circular 230 is discovered during the final check, and a superseding Allegation Letter was not mailed, discuss with GLS the need for such conduct to be included in the GLS Last Chance Letter.

    2. The draft Administrative Complaint is subject to editing and reediting, and certain counts in the draft Administrative Complaint ultimately may be excluded from the final version, such as if sufficient evidence to support the count or counts is not available, or because other hazards of litigation are anticipated.



       ### Note:



       All changes from the draft Administrative Complaint must be sent for Director concurrence.


14. No later than seven calendar days after the initial 28 day review period and after receipt of any supplemental information GLS requests from OPR, GLS sends a Last Chance Settlement Letter to the practitioner outlining the proposed counts to be included in the Administrative Complaint. The practitioner has 21 calendar days to respond to the letter.



    1. Additional allegations, such as recent tax non-compliance may be included in the Last Chance Settlement Letter for the first time to meet the notice and response requirements of section 10.60(c) (see paragraph 1, above).

    2. Per the GLS-OPR MOU, any grant of an extension of time to respond to the GLS Last Chance Letter must be approved by OPR.


15. If the practitioner responds to the Last Chance Settlement Letter and proposes a settlement, the settlement proposal will be duly considered. A determination will be made to accept, reject, or make a counter-offer. The Matrix should include a short section prescribing a settlement range for GLS to work within during negotiations with a practitioner and reach a tentative agreement, subject to OPR’s acceptance and to finalization.



    1. A settlement reached between the parties is reduced to a written agreement.

    2. OPR’s Director signs the written settlement agreement after the practitioner has signed the agreement. Once signed by the Director, associate the original agreement with the file and prepare a Letter of Transmittal to the practitioner summarizing the terms of the agreement, along with a copy of the fully executed agreement and the _Guidance on Restrictions During Suspension or Disbarment_ (if applicable).


16. Begin preparing the evidentiary file if:



    1. The practitioner responds to the Last Chance Settlement Letter and offers mitigation as to certain proposed counts but does not make a settlement offer

    2. The practitioner responds to the Last Chance Settlement Letter and denies the allegations, but does not establish the absence of violations or offer sufficient mitigation as to the lack of willful violations, and the practitioner does not propose a settlement offer.

    3. The practitioner does not respond to the Last Chance Settlement Letter.

    4. Despite a settlement offer, and any counter-offers, a settlement is not reached.


17. The evidentiary file must be completed within 10 calendar days of filing the original complaint. It is a copy of the entire six-panel red folder, except for documents that are exempt from disclosure under applicable law, such as attorney-work product, pre-decisional material protected by the deliberative-process privilege, or immaterial or irrelevant information in relation to the proceeding. In practice, the evidentiary file will provide all documents listed in the GLS Matrix as OPR’s Evidentiary File.

18. In a two-panel green folder, copy all relevant documents. All original documents remain with OPR. Per section 10.72(d)(3)(iv), redact all relevant third-party tax return information or other identifying information from the evidentiary file and code each redaction. A key to the redaction codes must be provided separately to allow the practitioner to decipher the codes. The ALJ will also use the redaction codes, if third-party tax information is to be included in the Decision.

19. Two copies of the evidentiary file are mailed to GLS and an email is sent with the redaction key. One copy is for GLS and the second is for the practitioner. The formal evidentiary file must be provided by GLS to the practitioner within 10 calendar days of filing the Complaint. Retain one unredacted and one redacted copy of the entire evidentiary file.

20. The expiration of the 21-day response period for the practitioner to reply to the GLS Last Chance Letter will ordinarily result in filing with the presiding ALJ the finalized complaint. The practitioner has 30 calendar days to respond to the complaint from the date of service on the practitioner.

21. If the practitioner does not file a proper response (pursuant to section 10.64(b)) within 30 calendar days of service of the complaint and does not request an extension of time from the ALJ, GLS files a Motion for Default Judgment with the ALJ, and serves the Motion for Default Judgment on the practitioner. The content of the motion is coordinated with OPR.



    ### Note:



    Paragraphs 21 through 27 include descriptions of procedures, motions and ALJ actions that are typical in OPR cases before ALJs. These descriptions are intended to illustrate the process and identify the role of OPR in these proceedings, and should not be read as binding upon the ALJ or as establishing the rights and obligations of parties before the ALJ.

22. If the practitioner files a proper response (pursuant to section 10.64(b)) to the Complaint within 30 calendar days of service, or within an extension period as provided by the ALJ:



    - GLS and OPR discuss the practitioner’s response as soon as possible and any questions raised by the response, including whether a deposition may be necessary in anticipation of a Motion for Summary Adjudication.

    - Section 10.66 provides that OPR may file a reply, but that, without a reply, any new matters raised in the response are deemed denied.


23. After a pre-hearing conference call with GLS and the practitioner (or representative), the ALJ will issue a Prehearing Conference Report and Scheduling Order. If a deposition of the practitioner is desirable, it will be discussed at the prehearing conference. The Scheduling Order will outline the timeframes for the matter to move forward, including any deposition, with the goal of holding a hearing within 180 calendar days from the time the practitioner’s response was due.

24. If the case proceeds to hearing, at the conclusion of discovery, the ALJ will schedule an evidentiary hearing date no later than 180 calendar days after the time for filing a response has elapsed. Hearings are formal events, and recorded by a court reporter with the testimony of all witnesses taken under oath. OPR will set up the court reporter.

25. If a hearing is held, the ALJ will set a briefing schedule in consultation with the parties. OPR will assist with the drafting of any post-hearing briefs. Within 180 calendar days after the conclusion of the hearing and the receipt of any post-hearing briefs (proposed finding of facts and conclusions of law) timely submitted by the parties, the ALJ should enter a Preliminary Decision and Order. With an entered decision, the ALJ will also forward the ALJ’s judicial file to OPR. An ALJ’s file constitutes an official administrative record. OPR is responsible for producing the entire official administrative record if there is a request for an appeal to the AA. The AA should only review information presented to the ALJ that is part of the official record. The ALJ administrative file should never be altered in any way.

26. If the ALJ grants a Motion for Default Judgment under section 10.64(d), in circumstances where the practitioner failed to properly respond, then a Default Decision will be entered by the ALJ. The ALJ serves a copy of the Default Decision on GLS and the practitioner. GLS will provide OPR with a copy.

27. If a Motion for Summary Adjudication is filed, the ALJ should rule on the motion within 60 calendar days after the party in opposition files a written response, or after 90 calendar days if no written response is filed.

28. After the ALJ Decision, as a courtesy, immediately prepare for the practitioner a letter detailing the procedures for appeal including the _Rights and Responsibilities_ document, along with a copy of the ALJ Decision. A copy of the _Guidance on Restrictions During Suspension or Disbarment_ will be provided if the ALJ Decision imposed either a suspension or disbarment and the practitioner does not appeal timely.

29. Either party has 30 calendar days from the date of the ALJ decision is served on the parties (section 10.77(b)) to appeal by filing a Notice of Appeal (NoA) and supporting brief with the Treasury AA. An AA, through a series of delegations from Treasury, General Counsel, and Chief Counsel, is designated to review and independently decide appeals from ALJ decisions in OPR cases. The AA makes the FAD.



    - The NoA must include a brief that states exceptions to the ALJ’s decision and supporting reasons for such exceptions.

    - Per the OPR-GLS MOU, GLS provides assistance to OPR during any appeal. OPR maintains responsibility for filing all documents associated with an appeal with the AA.


30. If the practitioner (the respondent in the proceeding) appeals the ALJ Decision, the practitioner will serve a copy of the NoA and brief on OPR. Upon receipt, OPR transmits the copies to HQ GLS, the appropriate GLS Area Counsel, and OPR’s Director.

31. The assigned OPR attorney should immediately transmit a copy of the practitioner’s NoA and supporting brief to the Legal Processing Division of CC:P&A (LPD) (effectively, the Counsel Service Desk for the AA). Bring one additional copy of the Letter of Transmittal to be time and date stamped as proof of filing the practitioner’s appeal with the LPD and provide GLS a copy of the time and date stamped Letter of Transmittal as proof of filing, if requested.

32. GLS, in consultation with OPR, drafts OPR’s response brief. The brief must be filed with LPD within 30 calendar days after OPR is served with the practitioner’s NoA. If OPR has already received the ALJ’s case file (Administrative Record), proceed to copy the Administrative Record and submit it with the practitioner’s NoA and brief to LPD.

33. Prepare the Proof of Service, the Administrative Record (if not previously submitted), and a Letter of Transmittal to accompany the response brief. Deliver the documents to LPD. Bring one additional copy of the Letter of Transmittal to be time and date stamped as proof of filing the responsive brief with the LPD and provide GLS a copy of the time and date stamped Letter of Transmittal as proof of filing, if requested.

34. At the same time as the response brief is filed with the LPD for transmission to the AA, OPR serves a copy of the response brief on the practitioner or, if the practitioner is represented, the practitioners representative. Retain in the case file one copy of all documents filed with the AA.

35. If OPR, in consultation with GLS, decides to appeal, then GLS, with assistance from OPR, drafts the NoA and brief. Compile the Proof of Service, the Administrative Record (from the ALJ’s file), and a Letter of Transmittal. Deliver the entire package to the LPD. Bring one additional copy of the Letter of Transmittal to be time and date stamped as proof of filing OPR’s appeal with the LPD and provide GLS a copy of the time and date stamped Letter of Transmittal as proof of filing, if requested.

36. At the same time as OPR’s NoA and supporting brief are filed with LPD for transmission to the AA, OPR serves a copy of the NoA, brief, and administrative file on the practitioner or, if the practitioner is represented, on the practitioner’s representative.

37. The practitioner has 30 calendar days to file a reply brief. Immediately upon receipt of the practitioner’s reply brief OPR will transmit it to HQ GLS and the appropriate GLS Area Counsel. OPR will also immediately deliver the practitioner’s brief to LPD. OPR will bring one additional copy of the Letter of Transmittal to be time and date stamped as proof of filing the practitioner’s reply brief with LPD. OPR will provide GLS a copy of the time and date stamped Letter of Transmittal as proof of filing, if requested. OPR retains in the case file one copy of all documents filed with the AA.

38. In accordance with section 10.78 of Circular 230, the AA should issue a Decision on Appeal within 180 calendar days after receipt of the appeal. The AA’s Decision on Appeal constitutes the FAD when issued.

39. While the AA Decision on Appeal may be appealed by the practitioner to a Federal District Court, OPR proceeds with announcing the sanction in the IRB and updating the practitioner’s practice status.

40. Should the practitioner disagree with the AA’s Decision on Appeal, a complaint may be filed in Federal District Court. The Federal District Court reviews the entire administrative record. The proceeding is not a new trial. The Administrative Procedure Act contains provisions governing the proceeding (Refer to 5 USC 551-559, 702). After the AA issues a Decision on Appeal, the AA will also forward the appellate case file to OPR. An AA’s file constitutes an official administrative record of the Agency. OPR is responsible for producing the entire official administrative record if a complaint is filed in Federal District Court.

41. The ALJ decision becomes a FAD if neither party appeals within 30 calendar days from the date of the ALJ decision. If either party appeals to the AA, then the AA Decision on Appeal becomes the FAD when issued.

42. After a FAD:



    - When applicable, prepare a press release and / or BUN article.

    - Draft a Letter of Transmittal to the practitioner that summarizes the FAD, along with a copy of the ALJ decision, or the ALJ and AA decisions, and a copy of the _Guidance on Restrictions During Suspension or Disbarment_ should a suspension or disbarment be imposed.

    - Per OPR / GLS MOU, GLS should return to OPR all evidentiary materials upon the issuance of a FAD.

    - Only if appropriate (cases involving suspensions or disbarments), notify the IRS CAF Unit to update the practitioner’s status.

    - Only if appropriate (cases involving suspensions or disbarments), notify the EAP&M to update an EA’s status.

    - Update the practitioner’s disciplinary action to the OPR intranet database.

    - Publish the practitioner’s disciplinary action in the IRB.

    - Post the finalized press release to OPR’s _OPR Press_ webpage on IRS.gov/.

    - Post the finalized BUN to the OPR’s _Business Units News_ webpage on OPR’s internal website and IRWeb’s homepage under _News From the Business Units_.


**1.25.4.10.9** **(06-29-2016)**

#### Procedures for Publicity

1. OPR conducts the publicity process following the conclusion of every case to ensure significant results are shared and explained to Internal Stakeholders, the Practitioner Community and the public. Based upon the type of case, there are five kinds of publicity actions that can take place: press releases, BUN articles, OPR intranet updates, IRS.gov/ posts, and notifications via OPR’s Bulletin (i.e., IRB posts). For any case, one action or any combination of the five, may be taken depending on OPR’s guidelines and the Director’s discretion.


**1.25.4.10.9.1** **(06-29-2016)**

##### Press Releases and Business Unit News Articles

1. In order to ensure timely and relevant publicity, it is imperative that the Office of the Director be notified of all ALJ and AA decisions immediately upon receipt. For noteworthy cases, the Director will request a preliminary draft press release.

2. For press releases, consent agreements, suspensions, disbarments, or practitioner reinstatements are the only potential instances when publicity may be issued. For BUN articles, consent agreements in which a press release has been negotiated and practitioner reinstatements are the only instances when publicity may be issued. Both are given the following requirements:



   - If the practitioner does not agree to a consent-agreement result being published (for a non-adjudicated case), a press release will not be issued.

   - If the practitioner agrees to a press release during settlement negotiations, the Director will determine the appropriate press release action. In this instance, the press release is provided to the practitioner or his / her representative for approval or further negotiation.

   - If a case has been adjudicated, the Director will make the decision to issue a press release based on relevance of the case to other practitioners and the public.


3. It is imperative that the press release being drafted after a FAD contain only disclosable information, under section 6103 and Circular 230. If a press release is being negotiated pursuant to a negotiated settlement, the extent of disclosure may be broader than in a nonconsensual case, but regardless the BUN should not exceed the information agreed to for the press release.

4. If a press release negotiated with the practitioner will include tax information of the practitioner that is not publicly available as a matter of law, the settlement must include a separate written disclosure consent addressing only the disclosure. The separate disclosure consent can be an exhibit or attachment to the substantive settlement agreement. See 26 CFR 301.6103(c)-1.



### Note:



Remember that the practitioner can only consent to the disclosure of the practitioner’s own return information. The practitioner cannot consent to the disclosure of the return information of any other taxpayer, including the practitioner’s clients whose return information may be in the practitioner’s case file.

5. The Director will collaborate with Media Relations to publish the final press release.

6. The finalized press release is posted to OPR’s [News and guidance](https://www.irs.gov/tax-professionals/news-and-guidance-from-opr) on IRS.gov/ and sent out via OPR’s Bulletin.

7. The finalized BUN article is posted to OPR’s _Business Units News_ webpage on OPR’s internal website. The article is also posted on IRWeb’s homepage under _News From the Business Units_.


**1.25.4.10.9.2** **(06-29-2016)**

##### OPR Intranet Website

1. Upon closure of a case that results in a suspension, disbarment, reinstatement, CAF Notification Letter, or C&D Letter, notify the IRS CAF Unit and EAP&M (for EA’s only) by email to update the practitioner’s eligibility status.



### Note:



CAF and EAP&M are not notified of censures.

2. Update a practitioner’s eligibility to the OPR intranet database.


**1.25.4.10.9.3** **(06-29-2016)**

##### Internal Review Bulletin

1. Upon closure of a case that results in a suspension, disbarment, censure, or reinstatement (if requested by the practitioner), include the practitioner in an IRB submission.

2. All closed case files with sanctions are reviewed by the designated IRB coordinator within OPR and included in the IRB. In preparing for the IRB posting:



1. Pull the sanction date, court orders and background documentation from each closed file.

2. Photocopy the relevant information and maintain it as supporting documentation for the IRB posting.

3. Using the information from the case file, complete the IRB format for each case where a practitioner was sanctioned.

4. Forward the proposed listing for review and approval.

5. Once approved, forward the listing to Media and Publications for inclusion in the IRB.


3. Post the finalized IRB to OPR’s [Disciplinary sanctions - Internal Revenue Bulletin](https://www.irs.gov/tax-professionals/disciplinary-sanctions-internal-revenue-bulletin) webpage on IRS.gov/ and send out via OPR’s Bulletin.


**1.25.4.10.10** **(06-29-2016)**

#### Procedures for Title 31 Monetary Penalty

1. The American Jobs Creation Act of 2004 provided the IRS with the authority to impose a monetary penalty against any individual who practices before the IRS for a violation of Circular 230, as well as authority to impose a monetary penalty on a firm or other entity or employer on whose behalf the individual was acting (as an employee, member, agent, or the like) when the violation was committed. Before the 2004 Act, there was only the statutory authority to censure or to suspend or disbar a practitioner from practice before the IRS. With the enactment of the penalty provision, a monetary penalty is available to be used in conjunction with, or in lieu of, censure, suspension, or disbarment of a practitioner. As to an employer, firm, or other entity, liability for a monetary penalty exists if the entity knew or reasonably should have known of the practitioner’s conduct in violation of Circular 230. The amount of a penalty imposed on an individual or an entity - or the combined amount of both penalties - cannot exceed the gross income derived (or to be derived) from the prohibited conduct. Imposition of a monetary penalty is discretionary, and OPR determines whether a case is appropriate for seeking a monetary penalty on a case-by-case basis. If a penalty is imposed, payment or collection of the penalty is processed as a Title 31 USC recovery. Notice 2007-39 (2007-1 C.B. 1243) provides additional guidance concerning monetary penalties.


**1.25.4.10.10.1** **(06-29-2016)**

##### Processing and Notification of A Circular 230 Monetary Penalty

1. Provide instructions to the practitioner on how and where to remit the penalty, discussed below.



   - Notify the Automated Non-Master File (ANMF) function that a monetary penalty has been imposed.

   - Ensure that notices are issued.

   - Update the Title 31 History section on the ANMF.

   - Initiate the process to calculate any interest, it owed.


2. Prior to being assigned cases for processing, obtain access to ANMF by submitting an OL5081 for the ANMF-TCC-RESEARCH GROUP ORACLE to receive research access as well as capability to update the Title 31 penalties account histories.


**1.25.4.10.10.2** **(06-29-2016)**

##### Processing Title 31 Monetary Penalties Resulting From Settlement

1. There are two types of settlement agreements relevant to this section:



1. Individuals: A settlement agreement regarding a matter involving the misconduct of an individual, when the agreement includes provisions regarding monetary sanction under 31 USC 330. These agreements will be signed by the individuals against whom the sanctions are being imposed. The critical identifying numbers for these cases are SSNs and PTINs.

2. Firms: A settlement agreement pertaining to a firm's liability under 31 USC 330 for misconduct of individuals acting on behalf of the firm. These agreements will be signed by individuals acting on behalf of the firm and with the authority to bind the firm. The identifying numbers for these settlements are EINs.


2. Settlement agreements are drafted when the parties appear to be agreeable to settlement without further litigation. Draft agreements are provided first to the individuals and firms involved in the matter for their signatures. After being signed and returned, the documents are final only when they are signed by the Director, OPR.

3. Agreements are not final until all necessary signatures are received, but individuals and firms are to be encouraged to submit the remittance along with their signed agreement. Remittances cannot be processed until the agreement is final.

4. Once all signatures are in place, if a remittance did not accompany the draft agreement, secure from the practitioner, firm or other entity which has agreed to a monetary penalty as part of a settlement a check or money order made out to the United States Treasury in the agreed amount of the monetary penalty.



1. When a remittance is received, a Form 3244-A, _Payment Posting Voucher - Examination_, should be prepared and the penalty recorded as Tax Class 4.

2. Prepare a transmittal memorandum that includes basic information such as the amount of the penalty, and the full name and address and other identifying information of the individuals, firms or other entities involved including SSNs and EINs as applicable.


5. The transmittal memorandum along with a copy of the signed agreement should be transmitted as indicated below. The fax cover sheet should instruct that the settlement agreement be routed to the Accounting Branch for assessment.


    ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡


    ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡



### Note:



The penalty imposed will be recorded as an ANMF assessment for Tax Class 4, MFT 28 and Abstract Number 147.

6. Using a method of overnight delivery, transmit the payment, Form 3210 and the related Form 3244-A to the address indicated below. See IRM 1.22.3 , _Addressing and Packaging_. The check or money order shall be accompanied by a copy of the transmittal memorandum.


    Internal Revenue Service


    201 West River Center Blvd.


    ≡ ≡ ≡ ≡ ≡


    ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡


    Covington, KY 41011



### Note:



If a remittance must be held overnight, it will be stored securely in a locked cabinet.

7. Follow up with respect to the above remittance by regularly checking the relevant ANMF account to ensure that there has not been a dishonored check or money order. If ANMF shows that the check or money order has been dishonored, then the matter needs to continue to be handled as if it were imposed by a FAD.


**1.25.4.10.10.3** **(06-29-2016)**

##### Processing Title 31 Monetary Sanction Imposed by Final Agency Decision

1. Upon obtaining a FAD imposing a monetary sanction:



1. Draft and send a First Notice addressed to the practitioner, firm or entity.

2. The First Notice will be mailed or otherwise delivered to the practitioner, firm or entity at the address used in the FAD (or more recent, if the address has been updated). Alert the practitioner, firm or entity that, pursuant to the FAD (referenced and provided as an attachment) the amount of the monetary sanctioned determined in the FAD is due and must be remitted to OPR.

3. After a notice is mailed, update the ANMF Account history section to reflect the mailing of a notice and / or any other collection activity that occurs.


2. The stub on the notice will indicate that the remittance should be mailed or delivered to the appropriate OPR address, either in the National Headquarters building or elsewhere, if applicable. Monitor the account to ensure payment is received.

3. When in receipt of the remittance, use express overnight delivery to transmit the payment, Form 3210 and the related Form 3244-A to the address indicated below. See IRM 1.22.3, _Addressing and Packaging_. The check or money order shall be accompanied by a copy of a transmittal memorandum identical to that which would be used in an agreed case and will include a copy of the FAD.


    Internal Revenue Service


    201 West River Center Blvd.


    ≡ ≡ ≡ ≡ ≡


    ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡


    Covington, KY 41011



### Note:



If a remittance must be held overnight, it will be stored securely in a locked cabinet.

4. When the monetary payment is not received by the anticipated due date, contact OPR's Special Counsel to the Director who will coordinate with the Office of Chief Counsel in providing advice regarding the amount of interest due.

5. Interest will be calculated pursuant to 31 USC 3717. Use Form 3465, _Adjustment Request_, and direct to the Kansas City Submission Processing Campus (\*ITS KCSPC Non-Master File Team).

6. In the event the practitioner or firm is uncooperative in remitting payment, generate follow-up notices every 30 calendar days until a Fourth Notice.

7. Alert the Director for facilitating the consideration of all available options in protecting the interest of the United States Government including but not limited to:



   - A demand letter (31 USC 3711)

   - An administrative offset (26 USC 6402)

   - The United States Treasury Department's Cross-Servicing Program (31 CFR Part 285)

   - Referral to the Department of Justice (31 USC 3711 and 31 CFR Part 285.12(c))


**1.25.4.10.11** **(06-29-2016)**

#### Procedures for Processing Practitioner File Requests in Disciplinary Cases

1. The Office of Privacy Governmental Liaison and Disclosure (PGLD) processes all FOIA requests for records maintained by OPR. OPR personnel remain accountable for searching for, and making disclosure recommendations as to, the records maintained in OPR, for PGLD’s final determination.

2. Requests from practitioners, or their representatives, for the OPR administrative file, will be handled directly by OPR under the disclosure authority it has been delegated pursuant to IRC 6103(l)(4) and IRC 6103(e)(1)(A)(i) and (e)(7).

3. There are two important distinctions between FOIA and IRC 6103:



1. FOIA does not give practitioners or their representatives access to the tax information of third parties without consent; IRC 6103(l)(4) does, to the extent relevant and material to use in, or preparation for, a Circular 230 proceeding.

2. FOIA requestors obtain information free from restrictions on subsequent disclosure whereas requests involving third-party tax information under 6103(l)(4) have restrictions (as discussed below). Practitioners, and representatives, who receive third-party tax information pursuant to section 6103(l)(4) are subject to penalty for unauthorized disclosures of the information provided by OPR. Applicable penalties (under IRC 7213 and 7431) are specified in OPR's standard section 6103 letter described in IRM 1.25.4.7.1(3)(b), which is accessible to practitioners and their representatives on IRS.gov/. By signing the letter, practitioners and their representatives acknowledge that the penalties may apply to unauthorized disclosure of a taxpayer's return or return information.


**1.25.4.10.11.1** **(06-29-2016)**

##### Relevant Authorities

1. Freedom of Information Act: 5 USC 552. FOIA requires federal agencies to disclose records sought by written request (i.e., by a FOIA request) unless a FOIA exemption applies. There are a handful of FOIA exemptions that are often applicable in OPR cases, but of most significant note in the context of practitioner requests for files is:



   - 5 USC 552(b)(3): Records exempted from disclosure by statute provided that the statute requires withholding and leaves no discretion to disclose or establishes the criteria for withholding.

   - Section 6103 is such a statute; it is referred to as a "withholding statute."


2. Title 26 USC 6103(e): "Disclosure to persons having material interest.-- (1) In general.--The return of a person shall, upon written request, be open to inspection by or disclosure to-- (A) in the case of the return of an individual-- (i) that individual…" Key Practical Points for 6103(e): Under subsection (e)(7) of section 6103, persons having a material interest in a return also have a material interest in associated "return information." For compliance cases under section 10.51(a)(6) of Circular 230, practitioners, and their representatives (upon submission of a properly executed Form 2848), are entitled under IRC 6103(e)(7) to the practitioner’s own return information, unless a determination is made that disclosure would seriously impair tax administration. They do not need to, nor should they, invoke the provisions of FOIA. OPR, like all BODs, has delegated authority under IRC 6103(e) to respond to a taxpayer’s request for his / her own tax records. To the extent that practitioners with OPR cases pending obtain their own return information from OPR, they are free to re-disclose that information as they wish.



### Note:



Remember that 6103(e)(1)(A)(i) and 6103(e)(7) do not authorize disclosure of any third party return information.

3. Title 26 USC 6103(l)(4): "Disclosure of returns and return information for use in personnel or claimant representative matters.--The Secretary may disclose returns and return information-- \* \* \* (ii) to any person, or to the duly authorized legal representative of such person, whose rights are or may be affected by an administrative action or proceeding under section 330 of title 31, United States Code, solely for use in the action or proceeding, or in preparation for the action or proceeding, but only to the extent that the Secretary determines that such returns or return information is or may be relevant and material to the action or proceeding; …" Key Practical Points for 6103(l)(4): To the extent that a practitioner’s pending Circular 230 case involves third-party tax information (as it almost inevitably will when the case involves the practitioner’s alleged misconduct as an advisor, return preparer or representative of others), 6103(l)(4), not FOIA, is the mechanism for producing material from the OPR administrative file to the practitioner (or the practitioner’s representative). All recipients of 6103(l)(4) information receive this information with limitations on its re-disclosure. As part of a request for the information, practitioners and representatives must acknowledge, in writing and under their signatures, the restrictions and the civil and criminal penalties for improper disclosure.

4. Circular 230, section 10.63(d): "Service of evidence in support of complaint. Within 10 days of serving the complaint, copies of the evidence in support of the complaint must be served on the respondent in any manner described in paragraphs (a)(2) and (3) of this section." Key Practical Points for section 10.63(d): As provided in Circular 230, practitioners who are parties to an ALJ hearing have a right to the relevant, non-privileged, documents in their case. OPR intends to make 10.63(d) documents available as soon as the practitioner wants them, while the practitioner’s matter is still pending with OPR on a pre-complaint basis. It is the expectation of Treasury that Circular 230 proceedings are, in practical effect, "open file" to an accused practitioner. OPR expects to withhold documents rarely - and those documents will likely be items protected by the work product doctrine or other evidentiary privilege. Notwithstanding this transparency policy, the acknowledgement discussed in paragraph (3) above must be obtained by OPR before making any third-party tax information available to a practitioner or the representative, and the case must still be active, i.e., the practitioner still has a need for the material to defend in the Circular 230 disciplinary proceeding. Requests for third-party tax information made after an OPR case has been closed (irrespective of the manner in which closure has occurred) are FOIA or Privacy Act requests and should be referred to PGLD immediately upon receipt.


**1.25.4.10.11.2** **(06-29-2016)**

##### Identifying the Source of Authority to Process Practitioner Requests

1. In order to determine whether a request should be processed under the FOIA (and therefore controlled by PGLD) or section 6103 (and therefore handled directly by OPR), first look to the essence of the case that is the subject of the request and initiate a response according to how the essence of the case matches the most relevant authority governing production. There are four general request types, as follows:



1. Requests from practitioners in the context of a specific OPR case pertaining to the practitioner, resulting from a referral based on the practitioner's representation / work for third parties on tax matters. Examples: Cases under section 10.22, 10.29, 10.34, or 10.51(a)(4) or (7). Typical documents prevalent in the file are client tax returns and return information. These kinds of requests will be processed by OPR under section 6103(l)(4) with no involvement of PGLD.

2. Requests in the context of a specific OPR case involving a referral concerning the practitioner's own tax obligations, i.e., potential violation of section 10.51(a)(6). Typical documents prevalent in the file in these cases are the IDRS transcripts for the practitioner’s tax accounts, as well as copies of, or original, tax returns. These requests will be processed under section 6103(e)(1)(A)(i) and (e)(7) with no involvement of PGLD.

3. Requests in specific OPR cases involving Circular 230 misconduct that is non-taxpayer specific, such as violations of section 10.30 or 10.51(a)(12). Documents in these files can include, for example, copies of advertisements, copies of a practitioner’s fee arrangements, or referral information from IRS employees regarding behavior unrelated to a specific taxpayer or tax matter. These requests will be processed by PGLD under the FOIA. OPR assists in the search for, and provides disclosure recommendations about, the responsive records. These types of cases are expected to be rare as compared to the first two categories.

4. "Generic" FOIA requests. These are requests from members of the public that invoke the FOIA as the basis for the request. Requests in this category can still be practitioner-specific. Thus, OPR might receive FOIA requests from persons requesting derogatory information on practitioners investigated or disciplined under Circular 230 and who are party opponents in other administrative or judicial proceedings involving the requesters. Alternatively, "generic" requests can go beyond a single OPR open or closed case and seek more macro-level information about OPR operations or the disciplinary process. An example of the first type would be a request for "documents pertaining to any discipline of my former tax advisor \[whom I am now suing\]," while a request for "information regarding any discipline of practitioners who reside in the zip codes of 22207 and 90210," illustrates the second type of request.



      ### Note:



      Subpoenas duces tecum or summonses are handled by Chief Counsel’s Office. These should be directed to OPR’s Special Counsel immediately upon receipt for referral to Counsel.





       "Generic" requests are processed by PGLD under FOIA. OPR assists in the search for, and making disclosure recommendations about, the responsive records. Generally, members of the public will not be granted access to information of other individuals due to FOIA’s privacy exemptions, but each request must be analyzed on a case-by-case basis. To the extent that members of the public are interested in statistical or programmatic information that provides insight into OPR’s performance as a BOD without disclosing individuals’ identities or personal data, OPR will make the maximum information available for release.



**1.25.4.10.11.3** **(06-29-2016)**

##### Categorizing the Request Type

1. When a request for information comes in from a practitioner (or representative) on that practitioner’s case, determine which of the first three categories above is controlling by conferring with management, as needed. Requests from third parties regarding a specific case will be processed as a "Generic FOIA" (category 4) request. Requests for OPR documents outside the context of a particular case will be directed to staff on a case-by-case basis for handling as a FOIA. Production of records in response to the request will go forward as provided above, depending upon the category.

2. With respect to FOIA requests, these must be promptly sent to PGLD for control. PGLD needs the incoming request immediately, to determine if it is a perfected request and, if so, will in turn assign a disclosure specialist who will control the case and contact OPR.

3. After management review, FOIA requests should be scanned from hardcopy and sent promptly to:


    IRS FOIA Request


    IRS-GLDS Support Services


    4800 Buford Highway


    ≡ ≡ ≡ ≡ ≡ ≡ ≡


    Chamblee, GA 30341


    ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡


**1.25.4.10.11.4** **(06-29-2016)**

##### Timeframes and Metrics

1. FOIA contains statutory response times. Consistent with principles of transparency, respond to administrative-file requests under 6103(e)(1)(A)(i) and (e)(7), or 6103(l)(4), in a comparable timeframe, barring unusual circumstances. If a delay is unavoidable, notify and consult with management at the earliest possible time.

2. The following timeframes apply to production of practitioners’ requests for case files.

3. When a practitioner requests the contents of his / her file, a copy of the request should be immediately scanned and emailed to the Section Manager and to Special Counsel to the Director.

4. For document requests in the two categories described above in IRM 1.25.4.10.11.2(1)(a) and (b), have the entire contents of the file reproduced and make initial evaluations regarding material that should be withheld pursuant to a privilege within five business days of OPR’s receipt of the practitioner’s request.

5. Consultation with Special Counsel should occur as necessary. The proposed response, complete with Letter of Transmittal, should be submitted to the Director within 15 business days of receipt of the request. The final response should be sent within 20 business days of receipt of the request.

6. For requests in the two categories described above in IRM 1.25.4.10.11.2(1)(c) and (d), a copy of the request should be immediately scanned and emailed to the appropriate Section Manager and to Special Counsel. The request should be transmitted to PGLD within one business day of receipt. For these requests, PGLD is operating under its own, strictly defined timeframes. With these requests, OPR’s responses should be made within deadlines prescribed by PGLD (unless extended by agreement of OPR and PGLD). For FOIA requests, agency responses generally must be made within 20 business days.


**1.25.4.11** **(06-29-2016)**

### Closing Cases / Correspondence

1. The Closure Process is the final step in the life cycle of a disciplinary case / correspondence.

2. Management must approve the case / correspondence for closure.

3. If a practitioner was notified about a referral or possible violation of Circular 230, upon case closure, the practitioner is entitled to a closing letter.

4. If a case is being referred to another IRS BOD, a transmittal memorandum needs to be sent along with a copy of the case memorandum and a copy of the referral.

5. For all TIGTA referred cases, Form OI 2076, _Referral Memorandum_, is completed and returned to the Special Agent-In-Charge. Our disposition is noted in section 17 (‘Nature of Action Taken’) and explained in section 18 (’ALERTS Issue code and Description’). Since Form 2076 was designed for employee conduct cases, OPR dispositions will not necessarily be listed within section 17. Therefore, please select, “Other” and for ALERTS code, explain the action we took (e.g., Closed without Sanction, Cease and Desist Letter).

6. | Update a practitioner’s eligibility status by notifying CAF via email if a case is closed as… | Update a practitioner’s eligibility status by notifying EAP&M (epp@irs.gov) via email if a case is closed as… | Add a practitioner’s eligibility status to the IRB if a case is closed as… | Add a practitioner’s eligibility status to the OPR intranet database if a case is closed as... |
| --- | --- | --- | --- |
| - **Deceased**<br>     <br>     <br>      Closed without action<br>     <br>   - **Expedited Suspension (XP)** Suspended, or Default Suspension<br>     <br>   - **Alternative to Discipline** CAF Notification, and / or Cease and Desist Letter<br>     <br>   - **Negotiated Agreement (Consent)** Resignation, Suspension, or Disbarment<br>     <br>   - **GLS - Negotiated Agreement** Suspension, or Disbarment<br>     <br>   - **ALJ – Decision** Suspension, or Disbarment<br>     <br>   - **Treasury Appellate Authority** Suspension, or Disbarment<br>     <br>   - **Decision Entered (Reinstatements)** Granted<br>     <br>   - **RP 81-38 Determination Default**<br>     <br>     <br>      Ineligible, or Ineligible, after response / conference<br>     <br>   - **RP 81-38 Reinstatement Decision** Granted<br>     <br>   - **DOJ (Injunction)** CAF Notification | - **Deceased** Closed without action<br>     <br>   - **Expedited Suspension (XP)** Suspended, or Default Suspension<br>     <br>   - **Negotiated Agreement (Consent)** Suspension, or Disbarment<br>     <br>   - **GLS - Negotiated Agreement** Suspension, or Disbarment<br>     <br>   - **ALJ – Decision** Suspension, or Disbarment<br>     <br>   - **Treasury Appellate Authority** Suspension, or Disbarment<br>     <br>   - **Decision Entered (Reinstatement Request)** Granted<br>     <br>   - **DOJ (Injunction)**CAF Notification | - **Expedited Suspension (XP)** Suspended, or Default Suspension<br>     <br>   - **Negotiated Agreement (Consent)** Censure, Suspension, or Disbarment<br>     <br>   - **GLS - Negotiated Agreement** Censure, Suspension, or Disbarment<br>     <br>   - **ALJ – Decision** Censure, Suspension, or Disbarment<br>     <br>   - **Treasury Appellate Authority** Censure, Suspension, or Disbarment<br>     <br>   - **Decision Entered (Reinstatement Request)** Granted –Publish in the IRB, if the practitioner sent in a request for publication<br>     <br>   - **RP 81-38 Determination** Default Ineligible, or Ineligible, after response / conference<br>     <br>   - **RP 81-38 Reinstatement Decision** Granted– _Publish in the IRB, if the practitioner sent in a request for publication_ | - **Expedited Suspension (XP)** Suspended, or Default Suspension<br>     <br>   - **Alternative to Discipline**<br>     <br>     <br>      CAF Notification, and / or Cease and Desist Letter<br>     <br>   - **Negotiated Agreement (Consent)** Censure, Suspension, or Disbarment<br>     <br>   - **GLS - Negotiated Agreement** Censure, Suspension, or Disbarment<br>     <br>   - **ALJ – Decision** Censure, Suspension, or Disbarment<br>     <br>   - **Treasury Appellate Authority** Censure, Suspension, Disbarment<br>     <br>   - **Decision Entered (Reinstatement Request)** Granted<br>     <br>   - **RP 81-38 Determination** Default Ineligible, or Ineligible, after response / conference<br>     <br>   - **RP 81-38 Reinstatement Decision** Granted |


**1.25.4.12** **(06-29-2016)**

### Outgoing Correspondence

1. All correspondence should follow the IRS Correspondence Manual (IRM 1.10.1, _IRS Correspondence Manual_) and the IRS Communications Style Guide.

2. All outgoing correspondence should be uploaded in CCMS and a copy placed in the case file.

3. All outgoing correspondence will be mailed both regular and certified mail. The certified mail card is copied and scanned for the physical file and uploaded in CCMS. A corresponding CCMS entry indicating both the tracking number and date mailed should be created.

4. All green Return Receipts are scanned and uploaded to CCMS.

5. All returned mail should not be opened. The envelope is scanned (double sided), uploaded to CCMS, and forwarded to the employee working the case. The envelope is maintained in the case file.


**1.25.4.13** **(06-29-2016)**

### Closed Cases / Correspondence

1. Closed case files should be placed in the file room.

2. OPR’s record retention policy for case files can be found in Document 12990, _Records Control Schedules_.


**1.25.4.14** **(06-29-2016)**

### Case and Correspondence Management System

1. Every complaint or referral will be entered in the automated case tracking system.

2. All major activity on the case will be entered in the databases "Activity / Events" tab. The activity records should provide a complete case history. Information recorded in the system should include, but is not limited to:



01. Work performed.

02. Research activities.

03. Date, time, place of conferences.

04. Summaries of telephone conversations.

05. Contacts with practitioner, representative and third parties.

06. Causes for any delays in completing the investigation (e.g., lack of cooperation by the practitioner and / or representative).

07. Internal causes for delays in completing the investigation (training, details, vacations, etc.).

08. Managerial involvement, including discussions about case development and quality, and the dates of formal workload review.

09. Collateral requests and referrals (e.g., to or from TIGTA).

10. Dates of requests for internal source documents (CAF77, IDRS).

11. Summary when case is submitted for closure.


**1.25.4.15** **(06-29-2016)**

### Formal Case Review Process

1. The formal case review process is a uniform case review methodology for use by managers in OPR’s LAB when conducting reviews of casework performed by LAB employees.

2. Case reviews have been and will remain a major component of the employee’s annual appraisal. The case review process is designed to ensure employees receive specific and timely feedback regarding their handling of cases during the rating period. For evaluation purposes, the process seeks to implement a procedure to review a defined number of cases; and management seeks to furnish informative documentation to employees that effectively describes what they are doing well and / or areas where improvement may be needed.

3. The process ensures all employees will have at least the same number and types of cases (open and closed) selected for review. In addition, it establishes generally when the reviews will be conducted and covered with the employees during the rating period. The Case Review Memorandum to be used for feedback to the employees will be structured and consistent across the Management Team. It will ensure employees are knowledgeable on how their casework is evaluated.

4. Managers will perform Quarterly Case Reviews for each employee for three of the four quarters during the rating period. Each review will be made up of four cases, picked at random, which will include three open cases and one closed case. After the random selection of cases for Quarterly Review, management will provide no less than 10 business days’ written notice to the employee of the upcoming review, along with a list of the cases (identified by case number) that will be reviewed. In addition, managers will perform one Full Case Review during the rating period for each employee that covers all open cases assigned to the employee in CCMS. This will take place as close to the employees mid-year as possible. Management will provide no less than 10 business days’ written notice to the employee(s) of the upcoming review, along with a list of the cases (identified by case number) that will be reviewed.



### Note:



The Full Case Review is in addition to a quarterly review that managers perform with their employees in order to ensure the number of hardcopy case files match those assigned to employees in CCMS.

5. The Quarterly Case Review consists of management:



1. Writing out a separate case review memorandum on each case and evaluating the employees Critical Job Elements (CJEs).



      ### Note:



      Each CJE may not be applicable to all case reviews.

2. Creating a new "Activity / Event" into CCMS. This includes selecting the "Quarterly Case Review" drop-down and entering any "next steps" needed on the case.



      ### Note:



      CCMS entries are for case information only (not to document performance issues).

3. For a Quarterly Case Review to be deemed complete, the managers must meet and discuss each of the four cases with their employees within two weeks of completing the review.


6. The Full Case Review consists of management:



1. Meeting with their employees to go over each case in their inventory, involving a dialogue and / or feedback between the manager and employee during the review process.

2. Writing a "general overview" memorandum on the review.

3. Creating a new "Activity / Event" into CCMS. This includes selecting the "Full Case Review" drop-down and entering in any "next steps" needed on the case.



      ### Note:



      CCMS entries are for case information only (not to document performance issues).

4. For a Full Case Review to be deemed complete, management must provide a copy of the memorandum their employees within two weeks of completing the review.


7. Management will use the results of each employees Quarterly Case Review and Full Case Review each as an aspect of their annual appraisal.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-025-004r#addtoany "Show all")

A2A