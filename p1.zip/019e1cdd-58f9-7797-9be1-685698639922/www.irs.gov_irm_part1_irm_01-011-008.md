---
url: "https://www.irs.gov/irm/part1/irm_01-011-008"
title: "1.11.8 Servicewide Electronic Research Program (SERP) | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-011-008#main-content)

- 1.11.8  [Servicewide Electronic Research Program (SERP)](https://www.irs.gov/irm/part1/irm_01-011-008#idm140285018595184)
  - 1.11.8.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284990167760)
    - 1.11.8.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284989877696)
    - 1.11.8.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284990178304)
    - 1.11.8.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284990044288)
      - 1.11.8.1.3.1  [Requirements for Hosting Content on the SERP Website](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284990042608)
      - 1.11.8.1.3.2  [Responsibilities of SERP](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284990982688)
    - 1.11.8.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-011-008#idm140285018365376)
    - 1.11.8.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284990106448)
    - 1.11.8.1.6  [Terms/Definitions/Acronyms](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284990102224)
    - 1.11.8.1.7  [Resources](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284991456752)
    - 1.11.8.1.8  [Contacting SERP](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284991451488)
  - 1.11.8.2  [Content Owner](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284990069568)
  - 1.11.8.3  [Authorized Submitter](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284989806288)
  - 1.11.8.4  [SERP IRM Author Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284990976560)
    - 1.11.8.4.1  [New IRM Authors](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284990204208)
  - 1.11.8.5  [Section 508 Compliant Content](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284990162448)
  - 1.11.8.6  [Adding Content to the SERP Website](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284990155248)
    - 1.11.8.6.1  [Adding IRMs](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284990154288)
    - 1.11.8.6.2  [Adding Alerts](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284989968512)
      - 1.11.8.6.2.1  [SERP Alerts with Disaster Criteria](https://www.irs.gov/irm/part1/irm_01-011-008#idm140285018509920)
    - 1.11.8.6.3  [Adding Homepage Items](https://www.irs.gov/irm/part1/irm_01-011-008#idm140285018502624)
    - 1.11.8.6.4  [Adding Content to SERP](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284991551952)
    - 1.11.8.6.5  [Adding Job Aids](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284991547408)
  - 1.11.8.7  [Updating Content on the SERP Website](https://www.irs.gov/irm/part1/irm_01-011-008#idm140285018344832)
    - 1.11.8.7.1  [Updating IRMs Through an IRM Procedural Update (IPU)](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284990060800)
      - 1.11.8.7.1.1  [Issuing an IPU (Interim Guidance)](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284990094256)
      - 1.11.8.7.1.2  [Reissuing IPUs (Interim Guidance)](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284991421840)
      - 1.11.8.7.1.3  [IRM Authoring Tool - Updating Your IRM XML File for IPU Submission](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284991408128)
      - 1.11.8.7.1.4  [SERP IRM Procedural Update (IPU) Submission Form](https://www.irs.gov/irm/part1/irm_01-011-008#idm140285018430224)
    - 1.11.8.7.2  [Updating Alerts](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284991512432)
    - 1.11.8.7.3  [Updating All Other Content](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284991505280)
  - 1.11.8.8  [Removing Content from the SERP Website](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284991502560)
    - 1.11.8.8.1  [Removing IRMs](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284991500800)
    - 1.11.8.8.2  [Removing Alerts](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284990927472)
    - 1.11.8.8.3  [Removing All Other Content](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284990924672)
  - 1.11.8.9  [SERP Posting Information](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284990922400)
    - 1.11.8.9.1  [SERP Numbering Scheme and Function Identification](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284990920672)
    - 1.11.8.9.2  [Time Frames for Posting to SERP](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284989935152)
  - 1.11.8.10  [SERP Feedback - Author/Content Owner Responsibilities](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284989925424)
    - 1.11.8.10.1  [Feedback Reports](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284990031920)
  - 1.11.8.11  [Content Certification Process](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284990026304)
  - Exhibit  1.11.8-1  [Example of a Flowchart with a Non-Compliant Alternative Text (Does Not Meet Section 508 Requirements)](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284990019056)
  - Exhibit  1.11.8-2  [Example of a Flowchart with a Compliant Alternative Text (Meets Section 508 Requirements)](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284990016416)
  - Exhibit  1.11.8-3  [Example of a Section 508 Non-Compliant Table](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284990004592)
  - Exhibit  1.11.8-4  [Example of Section 508 Compliant Table](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284990001920)
  - Exhibit  1.11.8-5  [Example of a Computer Screen Display with a Non-Compliant Alternative Text (Does Not Meet Section 508 Requirements)](https://www.irs.gov/irm/part1/irm_01-011-008#idm140285023358160)
  - Exhibit  1.11.8-6  [Example of a Computer Screen Display with a Compliant Alternative Text (Meets Section 508 Requirements)](https://www.irs.gov/irm/part1/irm_01-011-008#idm140285023355552)
  - Exhibit  1.11.8-7  [SERP Citation Standards](https://www.irs.gov/irm/part1/irm_01-011-008#idm140285023352176)
  - Exhibit  1.11.8-8  [Scenarios for Start-Up IPUs](https://www.irs.gov/irm/part1/irm_01-011-008#idm140285023313616)
  - Exhibit  1.11.8-9  [Updating the Effect on Other Documents](https://www.irs.gov/irm/part1/irm_01-011-008#idm140284990613152)

# Part 1. Organization, Finance, and Management

# Chapter 11. Internal Management Documents System

# Section 8. Servicewide Electronic Research Program (SERP)

* * *

## 1.11.8 Servicewide Electronic Research Program (SERP)

#### Manual Transmittal

October 10, 2024

#### Purpose

(1) This transmits revised IRM 1.11.8, Internal Management Documents System, Servicewide Electronic Research Program (SERP).

#### Material Changes

(1) IRM 1.11.8 - Editorial changes made throughout the IRM. Reviewed and updated Wage and Investment to Taxpayer Services, Signature name, plain language, grammar, IRM titles, website addresses, and IRM references.

#### Effect on Other Documents

IRM 1.11.8 effective December 04, 2023, is superseded.

#### Audience

Servicewide Tax/Policy/Program Analysts who host content on SERP.

#### Effective Date

(10-10-2024)

LuCinda J Comegys

Director, Accounts Management

Taxpayer Services Division

**1.11.8.1** **(10-10-2024)**

### Program Scope and Objectives

1. **Overview:** The Servicewide Electronic Research Program (SERP) is an electronic research source designed to provide employees with access to IRMs, updated with interim procedural guidance, as well as other reference materials. SERP provides employees with notification of IRM changes and current procedures.

2. **Purpose:** This IRM provides business units, their employees and management with information about SERP as an electronic research source and customers of SERP with requirements for hosting content on the SERP website. To access SERP:



   - Go to: http://serp.enterprise.irs.gov/homepage.html in a Web browser, or

   - Click on SERP under **Technical Tools** on the IRS Source at https://irsgov.sharepoint.com/sites/IRSSource.


3. **Audience:**Servicewide Tax/Policy/Program Analysts who host content on SERP.



### Note:



SERP hosts IRMs by request based on end-user need. Not all IRMs are on SERP. Visit http://serp.enterprise.irs.gov/content/irms/irms.html to identify the IRMs currently available on SERP. IRMs not available on SERP are found at: [http://irm.web.irs.gov](http://irm.web.irs.gov/).

4. **Policy Owner:** Director of Accounts Management

5. **Program Owner:** SERP Communication Program (SCP), Technical Assistance & Stakeholder Communication (TASC), Accounts Management (AM), Taxpayer Services (TS).

6. **Primary Stakeholders:** SERP works closely with authors of technical information (such as IRMs), Media & Publications, Alternative Media Center, local site coordinators, and other areas throughout the IRS to ensure the most current information is available. SERP primarily works with program managers, officials and IMD coordinators across TS and SBSE.

7. **Program Goals:** SERP provides many operating/functional divisions a research service for a variety of topics including:



   - IRMs and IRM Procedural Updates (IPUs)

   - Correspondex Integrated Data Retrieval System (IDRS) letters

   - Document 6209

   - Forms

   - Publications

   - Information alerts

   - Job aids

   - Supplemental information documents developed by authorized submitters

   - Who/Where Information

   - Links to organizational specific portals


**1.11.8.1.1** **(06-02-2023)**

#### Background

1. SERP is designed to provide employees from all IRS functions intranet access to IRMs and other reference materials, and to retrieve frequently referenced documents required to perform their jobs. SERP reports to the Program Manager, Technical Assistance & Stakeholder Communication (TASC).

2. The SERP staff creates web pages using content provided by the customer. The benefits of hosting content on the SERP website include:



   - SERP analysts make real-time updates to information; procedural updates are usually made by the next business day.

   - SERP ensures content is accessible for all users in compliance with Section 508 of the Rehabilitation Act, [29 USC § 794d](https://www.ecfr.gov/current/title-29/part-1614/section-1614.203#p-1614.203(d)(4)).

   - SERP receives over a million hits daily with approximately 60,000 visitors each month (based on unique IP addresses observed monthly) allowing content to receive maximum exposure.

   - SERP’s Web servers are among the most reliable and receive 800-1500 searches per minute.


**1.11.8.1.2** **(09-28-2021)**

#### Authority

1. Authorities relevant to the SERP website content include the following:



   - Section 508 of the Rehabilitation Act, [29 USC § 794d](https://www.ecfr.gov/current/title-29/part-1614/section-1614.203#p-1614.203(d)(4)); see "Web Content Accessibility Guidelines" at [https://www.irs.gov/accessibility](https://www.irs.gov/accessibility)

   - E-FOIA criteria, under [5 USC § 552(a)(2)(C)](https://uscode.house.gov/view.xhtml?req=(title:5%20section:552%20edition:prelim)%20OR%20(granuleid:USC-prelim-title5-section552)&f=treesort&edition=prelim&num=0&jumpTo=true); see "About the FOIA Library" at [https://www.irs.gov/privacy-disclosure/foia-library](https://www.irs.gov/privacy-disclosure/foia-library)

   - Taxpayer Bill of Rights, see [https://www.irs.gov/taxpayer-bill-of-rights](https://www.irs.gov/taxpayer-bill-of-rights)


**1.11.8.1.3** **(03-16-2017)**

#### Roles and Responsibilities

1. This subsection provides information about who is responsible for the activities described in the IRM.


**1.11.8.1.3.1** **(06-02-2023)**

##### Requirements for Hosting Content on the SERP Website

1. To host content on the SERP website the content owner (see _IRM 1.11.8.2_, Content Owner) must:



1. Ensure the accuracy of the information.

2. Use SERP IPUs to issue interim updates to IRMs.

3. Incorporate SERP IPUs into the published IRM within the effective period of the IPU. See _IRM 1.11.8.7.1_(2), Updating IRMs through an IRM Procedural Update (IPU).

4. Annually certify the content is current and accurate through the Content Certification Process. See _IRM 1.11.8.11_, Content Certification Process.

5. Ensure content is kept current through Media and Publications revisions and through the IRM Procedural Update (IPU) process. See _IRM 1.11.8.7_, Updating Content on the SERP Website.



      ### Note:



      An IPU revises or corrects existing IRM information on SERP only. All other IRM formats, including the published version available to the public, are not updated. However, if the interim guidance (i.e., SERP IPU) meets E-FOIA criteria, the IPU is forwarded for posting in the [FOIA Library](https://www.irs.gov/privacy-disclosure/foia-library) on www.irs.gov. See _IRM 1.11.8.7.1_, Updating IRMs through an IRM Procedural Update (IPU), for additional information.

6. Respond to feedback using the SERP Feedback system.


2. Authorized submitters or IRM authors are the only individuals authorized to submit content to SERP.

3. Initiators must obtain approval from the authorized submitter. See _IRM 1.11.8.3_, Authorized Submitter.

4. For Accounts Management, all local job aids are forwarded to the Process Improvement (PI) Specialist to forward to Process Improvement/Customer Accuracy (PICA) for Policy & Procedures IMF (PPI), Policy & Procedures BMF (PPB), and Identity Protection Strategy & Oversight (IPSO) approval to post on SERP. See IRM 21.10.1.2.7.1, AM IRM Procedural Update/SERP Alert/News Release Filtering and Distribution and IRM 1.4.16.7.5, Process Improvement (PI) Specialist Roles and Responsibilities, for additional information.


**1.11.8.1.3.2** **(03-16-2017)**

##### Responsibilities of SERP

1. The objectives of SERP are to:



1. Keep a liaison with operating/functional divisions to ensure they are familiar with SERP procedures.

2. Work with the program owners and authors who host their content on SERP to timely issue procedural updates (IPUs), alerts and job aids.

3. Communicate with end-users through a feedback process to ensure their needs are met.

4. Act as liaison between authors of technical documents and end-users to ensure the information available is accurate.

5. Provide employees with prompt access to the information required to perform their jobs.


**1.11.8.1.4** **(11-24-2020)**

#### Program Management and Review

1. SERP Communication Program (SCP), under the guidance of Technical Assistance & Stakeholder Communication (TASC), has responsibility for ensuring content hosted on the SERP site is current and accurate. All content is reviewed annually and certified by the program owner of the content. See _IRM 1.11.8.11_, Content Certification Process.


**1.11.8.1.5** **(09-28-2021)**

#### Program Controls

1. All IRM authors and content owners must gain access to the SERP Feedback system, see _IRM 1.11.8.10_, SERP Feedback - Author/Content Owner Responsibilities.

2. IRM authors and content owners submitting SERP Alerts or IPUs (via SERP submission forms) must contact SERP via email and provide their profile information, see _IRM 1.11.8.3_(4), Authorized Submitter. Their manager may also send an email stating they are approved to submit content for the area shown in their request.

3. Authorized submitters who are not the primary content owner (such as a back-up or other designated submitter) must have their manager send an email stating they are approved to submit content. See _IRM 1.11.8.3_, Authorized Submitter.


**1.11.8.1.6** **(07-02-2018)**

#### Terms/Definitions/Acronyms

1. Common terms and acronyms used throughout this section:



**Table of Defined Terms**






| **Term or Acronym** | **Definition** |
| --- | --- |
| Alert, or SERP Alert | Alerts notify users of system problems and "need to know" information that does not change procedures or guidelines in the IRM. New alerts are posted on the SERP homepage under "Today’s News" . |
| Alternative Text (Alt Text) | Line-by-line text descriptions which make graphics and other content accessible for all users. |
| Arbortext Editor | Extensible Markup Language (XML) editing software required for maintaining and updating IRM files. The current version is Arbortext 7.1 |
| Authorized Submitter | Person authorized to submit or update information on the SERP website. |
| Content Certification Process | Annual process where content owners review and certify the information on SERP is current and accurate. |
| Content Owner | Person assigned specific topic information located on the SERP website; IRMs, alerts, job aids, etc. |
| E-FOIA - Electronic Freedom of Information Act | E-FOIA, which amended FOIA in 1996, essentially requires government agencies to make certain internal information available through FOIA, available in electronic form. SERP has a process in place to ensure IPU content that meets FOIA criteria is forwarded for posting in the FOIA Library on www.irs.gov |
| FOIA - Freedom of Information Act | FOIA gives any person the right to access federal agency records or information. FOIA is based on the presumption that the government and its information belong to the people. |
| HTML - Hyper Text Markup Language | The standard markup language used for documents on the World Wide Web. SERP staff converts content provided in various file formats (.xml, .pdf, .docx) to HTML pages read by browsers and viewed by users of the SERP website |
| IMD - Internal Management Document | The official communications that designate authorities and disseminate policy, procedures and instructions to staff to internal and external stakeholders (e.g., the IRM). |
| IMD Coordinator | Designated person for an organization or function that oversees the publication of documents (IRMs etc.) for the organization. |
| IPU - IRM Procedural Update | IRM update (interim guidance which revises or corrects the existing IRM) submitted for posting on SERP. New IPUs are posted on the SERP homepage under "Today’s News" . |
| Job Aid | Technical research information not found in an IPU or alert. |
| MT - Manual Transmittal | The MT is the beginning section of the IRM and communicates information about the revisions made to the IRM. The MT provides a historical record and description of substantive changes to procedures, processes and programs. |
| MTIPU - IPU Manual Transmittal | The MTIPU communicates information about the material changes made with the IPU. It provides a consolidated list of all IPU changes made since the last publication of the IRM. |
| Portal | Various technical content pages grouped together by topics relevant to specific organizations or programs. |
| Section 508 | Section 508 of the Rehabilitation Act (29 USC 794d) ensures SERP content is accessible for all users. |
| SERP - Servicewide Electronic Research Program | An electronic research source designed to provide access to current procedural guidance and reference materials. |
| SPDER - Servicewide Policy, Directives and Electronic Research | Provides electronic tax law research; oversees internal management document process; communicates directives and policies. |
| XML - Extensible Markup Language | Language used to write and update IRMs; the file type is .xml. |


**1.11.8.1.7** **(07-02-2018)**

#### Resources

1. The following lists the primary sources of guidance for SERP program activities.



   - IRM 1.11.2, Internal Revenue Manual (IRM) Process

   - IRM 1.11.5, Publishing the Internal Revenue Manual (IRM)

   - IRM 1.11.7, Taxpayer Services Internal Management Documents Program

   - IRM 1.11.9, Clearing and Approving the Internal Revenue Manual (IRM)

   - IRM 1.11.10, Interim Guidance Process

   - SERP Feedback Guide for Content Owners

   - SERP Submission Form User Guide

   - SERP E-FOIA Decision Tool


**1.11.8.1.8** **(03-16-2017)**

#### Contacting SERP

1. There are various ways to contact the SERP staff depending on your role. Please use the following table as a guide:



**Methods of Contacting SERP**






| **Method** | **User Role** | **Purpose** |
| --- | --- | --- |
| SERP Feedback | SERP Users | - Use the SERP Feedback System to input feedback about information on SERP including IRMs.<br>     <br>   - Use SERP Feedback to identify corrections or request changes to the IRM and other hosted content on SERP.<br>     <br>   - Do not use the Feedback system to ask questions that should be answered by chain of command or to rebut an employee review. |
| Contact SERP | SERP Users, Content Owners, and Authorized Submitters | - Use to contact the SERP staff with questions or problems about site content or usability.<br>     <br>   - Do not use for technical/policy-related questions or concerns about IRM content or other issues that should be addressed by SERP Feedback. |
| SERP Mailbox | Content Owners, and Authorized Submitters | Use to communicate with the SERP staff about IPU/Alert submissions or to request editorial changes to IRMs and other content (e.g., typographical errors, fix broken links, etc.). |


**1.11.8.2** **(10-06-2017)**

### Content Owner

1. Content owners:



1. Have content on SERP (IRM, job aid, contact listing).

2. "Own" the content.

3. Ensure content is accurate and current by issuing interim guidance and annual updates.

4. Provide responses to SERP Feedback.


2. Hosting material on SERP is optional for various business units, however, the content owner must adhere to SERP requirements if placing material on SERP. See _IRM 1.11.8.1.3.1_, Requirements for Hosting Content on the SERP Website.

3. The IRM program manager must approve the posting of IRMs not currently on SERP. The IMD coordinator is copied on any email solicitations to add IRMs.

4. Only Authorized Submitters can submit requests for changes to content on SERP. See _IRM 1.11.8.3_, Authorized Submitter, for more information about becoming an Authorized Submitter.

5. Any changes (temporary or permanent) to the actual ownership of the content are reported to SERP via the \*CTR ODN SERP SECT mailbox.

6. A resource for information is the SERP Author Resources page. The Author Resources page has:



   - Current news about SERP

   - SERP Submission Form and User Guide

   - Extensible Markup Language (XML) References

   - SERP References such as SERP contact info and email address

   - SERP Feedback References such as the Feedback Guide for Content Owners

   - IRMs pertinent to the SERP process and regulations

   - Links to other useful websites


**1.11.8.3** **(04-23-2020)**

### Authorized Submitter

1. An authorized submitter is authorized to submit content changes or additions to SERP. IRM authors as well as their direct managers and senior analysts are automatically considered authorized submitters. See _IRM 1.11.8.7_, Updating Content on the SERP Website. An authorized submitter is not the same as the approving official. These individuals are not automatically the official authorized to approve content changes. Contact your organization to determine who is authorized to approve IPUs. See IRM 1.11.10.6, Approve Interim Guidance or other content changes posted on SERP.



### Note:



Organizations may designate other authorized submitters as needed.

2. Only authorized submitters can request to post new information or to change existing information on SERP.

3. New IRM authors or program owners needing to issue alerts or IPUs must contact SERP staff to provide their user profile information shown below, before they can use the Submission Form.

4. Send an email to \*CTR ODN SERP SECT with the following information:



   - Your name as it should appear on the alert or IPU

   - Your SEID

   - Your org symbols

   - Your BOD (TS, SBSE, etc.)

   - Your business telephone number


IRM Authors must include:


   - The IRM(s) you author

   - The name of your IMD coordinator


Alternate authors or program owners must include:


   - IRM(s) or program(s) you are assigned

   - Manager name

   - Manager title

   - Your manager must forward an email to the SERP staff approving you to submit alerts or IPUs for the IRM or program you have listed


5. Once added, any changes/updates (temporary or permanent) to an authorized submitter's information are emailed to \*CTR ODN SERP SECT with changes to the information shown above noted.


**1.11.8.4** **(07-15-2022)**

### SERP IRM Author Roles and Responsibilities

1. SERP IRM authors must adhere to the following policies:




| _For_ | _See_ |
| --- | --- |
| IRM Authoring | IRM 1.11.2, Internal Revenue Manual (IRM) Process |
| IRM Clearance | IRM 1.11.9, Clearing and Approving the Internal Revenue Manual (IRM) |
| IRM Publishing | IRM 1.11.5, Publishing the Internal Revenue Manual (IRM) |
| IPU Clearance and Approval | IRM 1.11.10, Interim Guidance Process |

2. In addition, SERP IRM authors must take the following actions when issuing IPUs:




| Action: | Reference: |
| --- | --- |
| a) Use the current Arbortext IRM Authoring Software to write and edit IRM procedures.<br> <br>### Reminder:<br>Authors can obtain the latest published IRM from the Electronic Publishing website through the IRM Numerical Index at http://publish.no.irs.gov/pubsys/irm/numind.html. Use this file to update the first IPU revision after the IRM published date. | IRM 1.11.8.7.1.3, IRM Authoring Tool - Updating Your IRM XML File for IPU Submission.<br> <br>### Note:<br>Contact your Internal Management Document (IMD) coordinator for Arbortext software training. Visit the Knowledge Services Help Desk at xmlhelpdesk.web.irs.gov for answers to Frequently Asked Questions or email \*TS MPM XMLSGMLHELP with questions/problems. |
| b)<br> <br>   - Ensure all procedures/instructions included in the IRM reflect the current operating environment and business practices.<br>     <br>   - Verify IRM procedures are correct and do not contradict existing procedures, processes or laws. | IRM 1.11.2, Internal Revenue Manual (IRM) Process<br> IRM 1.11.10.3.1.2, SERP IRM Procedural Updates (IPUs) |
| c)<br> <br>   - Share changes with authors whose IRM sections are impacted by the new guidance.<br>     <br>   - Update references/cross-references.<br>     <br>   - Ensure content is free of PII, FTI, and is properly fictionalized. | IRM 1.11.2.5.1, Prepare to Write or Revise the IRM<br> IRM 1.11.2.5.6, Fictitious Identifying Information |
| d) Make certain procedures follow plain language standards and do not duplicate other IRM procedures. | [Plain Language](https://www.plainlanguage.gov/) website |
| e) Tag all official-use-only (OUO) information properly. If the change(s) include OUO content, obtain approval from the Program Director. | IRM 1.2.2.11.1, Delegation Order 11-1, Administrative Control of Documents and Material<br> IRM 1.2.2.2.53, Delegation Order 1-69 (New), Authorization to Approve an Internal Management Document (IMD)<br> IRM 1.11.10.5.1, Evaluate Interim Guidance for E-FOIA |
| f) Evaluate and identify content that meets E-FOIA criteria.<br> <br>### Note:<br>The SERP E-FOIA Decision Tool is available to assist IRM authors in determining whether E-FOIA applies to any of their changes. | IRM 1.11.10.5.1, Evaluate Interim Guidance for E-FOIA<br> Freedom of Information Act (FOIA) [5 USC § 552(a)(2)(C)](http://www.irs.gov/uac/IRS-Freedom-of-Information) |
| g) Use only local procedures authorized by headquarters, (e.g., memos, desk guides).<br> <br>### Note:<br>Local procedures that affect how the public files, pays or interacts with the IRS must be evaluated for posting in the FOIA Library at [https://www.irs.gov/privacy-disclosure/recent-interim-guidance-to-staff](https://www.irs.gov/privacy-disclosure/recent-interim-guidance-to-staff). | IRM 1.11.2.2.3, Local Procedures |
| h) Use correct reference citations for citing law (e.g., United States Code, Code of Federal Regulations, Revenue Procedures, Revenue Rulings, etc.). | IRM 1.11.2.5.8.2, Cite Legal Sources<br>_Exhibit 1.11.8-7_, SERP Citation Standards |
| i) Confirm graphics adhere to Section 508. | _IRM 1.11.8.5_, Section 508 Compliant Content |
| j) Clear and obtain approval for IPUs following either the emergency or standard clearance process. | IRM 1.11.10.6, Clear and Obtain Approval for Interim Guidance:<br> <br>   - Emergency Clearance and Approval Process for Interim Guidance, see IRM 1.11.10.6.2<br>     <br>   - Non-emergency Clearance and Approval Process for Interim Guidance, see IRM 1.11.10.6.1 |
| k) Follow the publishing and clearance process to incorporate interim guidance.<br> <br>### Caution:<br>IPUs on SERP are not a substitute for republishing IRMs. Do not submit an IPU revising an entire IRM that has not republished in the last 12 months. | IRM 1.11.10.9, Incorporate into the IRM, Reissue, or Obsolesce Interim Guidance<br> IRM 1.11.10.9.1, Incorporate Interim Guidance into the IRM<br> <br>### Reminder:<br>If an IPU is issued between the time when the IRM is sent to Publishing and when it becomes effective and posts to SERP, incorporate the IPU information into the SERP IRM after the published version becomes effective. See _Exhibit 1.11.8-8_, Scenarios for Start-Up IPUs, for more information. |

3. A resource for information is the SERP Author Resources page. The Author Resources page has:



   - Current news about SERP

   - SERP Submission Form, User Guide, and Training

   - XML References such as XML Instructions, FAQs, and the Quick Reference Guide

   - SERP References such as SERP contact info, the SERP email address, and the Authorized Submitter Form

   - SERP Feedback References such as the Author/Content Owner Instructions and a Quick Reference Guide for Feedback Responses

   - IRMs pertinent to the SERP process and regulations

   - Links to other useful websites


**1.11.8.4.1** **(09-28-2021)**

#### New IRM Authors

1. New IRM authors must:



1. Complete an "Add Me" request in SERP Feedback to access the system and respond to SERP Feedback about the IRM. See _IRM 1.11.8.10_, SERP Feedback - Author/Content Owner Responsibilities.



      ### Note:



      SERP uses the information provided to create a profile in the SERP Submission Form, see below.

2. Read the SERP Submission Form User Guide before using the SERP Submission Form application to submit IRM Procedural Updates (IPUs). See _IRM 1.11.8.7.1_, Updating IRMs through an IRM Procedural Update (IPU).

3. Participate in the annual IRM certification to ensure current and accurate information is being hosted on SERP. See _IRM 1.11.8.11_, Content Certification Process.

4. Follow _IRM 1.11.8.4_, SERP IRM Author Roles and Responsibilities.


**1.11.8.5** **(06-02-2023)**

### Section 508 Compliant Content

1. Content hosted on SERP is compliant with Section 508 (e.g., IRMs, alerts, job aids, etc.) and ensures information on the SERP website is accessible to people with disabilities.

2. All content submitted to SERP for posting to the SERP website must meet Section 508 compliance requirements before submitting to SERP.

3. To ensure Section 508 compliance and optimal usability, SERP determines the final format of submitted content. If it is determined the content is better in an alternative format (i.e., html page), SERP takes the responsibility of programming the content not the submitter. SERP makes every effort to ensure the content is presented in its most usable form for the SERP platform.

4. Tables within an IRM must have a header row with no embedded (sub-) headers, columns or rows and cannot have merged or split cells.

5. 508 compliant graphics (including images and/or screen captures) require a text alternative that serves the same purpose. Graphics should include an alternative text (line-by-line text). Line-by-line text may be used in lieu of graphics. See _Exhibit 1.11.8-1_ through _Exhibit 1.11.8-6_ for examples of compliant alternative text.



### Reminder:



Publishing only accepts graphics in .pdf format. See IRM 1.11.2.5.7, Graphics.

6. Refer to the Information Resources Accessibility Program (IRAP) website or the Alternative Media Center (AMC) for more information on Section 508.


**1.11.8.6** **(01-01-2008)**

### Adding Content to the SERP Website

1. Submitters must follow the instructions listed in the following subsections for the type of content adding to the SERP website.


**1.11.8.6.1** **(09-28-2021)**

#### Adding IRMs

1. To post an IRM currently not on SERP, the IRM author must:



1. Obtain approval from your program manager.

2. Inform your organization’s IMD coordinator.

3. Send an email to the SERP mailbox \*CTR ODN SERP SECT and request the IRM is added to the SERP website.

4. Follow the instructions in _IRM 1.11.8.3_, Authorized Submitter, to notify SERP if someone other than the IRM author may submit alerts or update the IRM.

5. Complete an "Add Me" request in SERP Feedback to access the system and respond to SERP Feedback about the IRM. See _IRM 1.11.8.10_, SERP Feedback - Author/Content Owner Responsibilities.



      ### Note:



      SERP uses the information provided to create a profile in the SERP Submission Form.


2. After a SERP approved IRM is published, the SERP staff downloads the IRM files directly from the Electronic Publishing website and converts the files to HTML for posting to SERP. This is transparent to IRM authors.

3. Upon completion of the above, the SERP staff notifies the author the IRM is posted on SERP.


**1.11.8.6.2** **(12-06-2022)**

#### Adding Alerts

01. An alert presents information that does not change current procedures or guidelines in the IRM.

02. An alert must not have procedures or instructions to staff that affect the public, which are not already posted on [www.irs.gov](http://www.irs.gov/).

03. An alert expires one year from the date it is issued or when the topic is no longer needed, whichever is earlier. It is the content owner’s responsibility to monitor the status and notify SERP to rescind an alert.

04. Use alerts to notify users of system problems, changes, and information (e.g., disaster assistance information) that does not require an IRM procedure/instruction change.

05. Secure necessary approvals for information provided in the alert, if required. Input the "Approving Official" name and "Title" as applicable. Contact your organization to determine who is authorized to approve alerts or other content changes posted on SERP.



    ### Note:



    Alerts submitted for expedite posting must have managerial approval.

06. You must be added to the SERP database before you can submit an alert request. Instructions on how to gain access are found in the SERP Submission Form User Guide as well as in _IRM 1.11.8.3_, Authorized Submitter.

07. Complete and submit an alert request by accessing the [SERP Submission Form](https://serplxauinitiatetest.web.irs.gov/AUInitiate/Controller), and selecting the 'New Alert' link on the navigational bar.

08. Detailed instructions are found on the tab titled 'New Alert' in the SERP Submission Form User Guide.

09. Once the form is completed, click "Save" to activate the "Submit" button and the "Add File" button. The record is assigned a temporary tracking number, and the record is added to your list of ACTIVE records on the MY INPUTS page.

10. If you need to attach a file, follow the guidelines in the Files/Attachments link under the "New Alert" tab of the Submission Form User Guide.



    - Name your file following the naming conventions outlined in the Submission Form User Guide.

    - Click the "Add File" button and browse to select the file.

    - Repeat the "Add File" steps to submit more than one file.


11. Click "E-mail" to send an email to an approver/reviewer or other co-worker needing to look at this alert before submitting.



    ### Note:



    Alerts submitted for expedite posting must have managerial approval.

12. Insert email address(s).

13. The subject line is auto populated with the alert’s temporary tracking number. You may add to the subject if necessary.

14. The body of the email includes a link to the alert record. If your organization requires review of the alert submission prior to sending it to SERP, your recipients can view the record and the attachments; however, they cannot make changes to this record or the attachments. If they need to make changes to the alert or the attachments take the following actions:



    - Attach a Word document with the alert content and/or the uploaded documents to the email for the recipient to edit.

    - The recipient copies and pastes the items needing to be changed from the record view into the email.

    - The recipient opens the uploaded files from the links in the record view and saves them to their desktop for editing. Once edited, the recipient attaches the changed items to the email and returns it to you to make the changes before submitting the alert for posting.


15. When you are ready to submit your alert to SERP, click the 'Submit' button. The form validates your input and provides error messages for any missed fields. Click ‘OK’ to close the message, then go back to the missing item and input the information before submitting the form. The following are possible validation messages:



    - "Please enter a Subject"

    - "Please select the Audience"

    - "You did not answer the question - Was this Alert the result of SERP feedback?"

    - "Enter Feedback Control Number"

    - "No portals have been checked. Select OK to continue Submit or Cancel"

    - "Please select the Master File"

    - "You are responsible for obtaining all approvals needed for this Alert"


### Note:

Incomplete forms could delay the posting of the alert. See _IRM 1.11.8.9.2_, Time Frames for Posting to SERP.

16. When all inputs are validated a warning box displays stating, "Submission will be posted within 48 hours; Are you sure you want to submit the form?" If you click 'OK' the system:



    - Removes the temporary tracking number and assigns the record the posting number.

    - Moves the record to your list of SUBMITTED records on the MY INPUTS page.

    - Submits the record and any attachments to the database for SERP to process and post to the website.


17. The 'Cancel' button displays "The form will remain under My Inputs as Active" , click ‘OK’ and the system returns you to your ‘Saved’ form.

18. To update a prior alert with new information, or “rescind” an alert, see _IRM 1.11.8.7.2_, Updating Alerts.


**1.11.8.6.2.1** **(12-04-2023)**

##### SERP Alerts with Disaster Criteria

1. All SERP Alerts with disaster criteria must be coordinated with the Disaster Program Office to prevent duplication and assure consistency. Employees issuing SERP Alerts with disaster criteria must contact the Disaster Program Office analyst listed on the Disaster Assistance and Emergency Relief Staff website. Disaster criteria may include one or more of the following words:



   - Disaster

   - Emergency

   - Federal Emergency Management Agency (FEMA)

   - Fire

   - Flooding

   - Hurricanes

   - -O Freeze

   - -S Freeze

   - Severe Storms

   - Tornadoes

   - Tragedy


2. When you complete the SERP Alert Submission Form, include in the "Notes/Special Instructions for the SERP Staff" whether the Disaster Program Office was contacted.


**1.11.8.6.3** **(03-24-2016)**

#### Adding Homepage Items

1. The primary purpose of the SERP homepage is to post daily _IRM Procedural Updates_ (IPUs), _Alerts_, _Priority News_ and miscellaneous SERP topic updates.

2. The SERP homepage also provides users with _brief_ information, which does not require an update or alert.



### Example:



The Technical Communication Team has redesigned its website. Check out the new features.

3. To submit items for the homepage, an authorized submitter can send a written request via email to \*CTR ODN SERP SECT.

4. SERP homepage items are posted for one day. Upon request, SERP may move a homepage item to Priority News where it can remain for 14 calendar days. If there is a need for a Priority News item to remain for more than 14 calendar days, include a justification with your request.


**1.11.8.6.4** **(05-22-2014)**

#### Adding Content to SERP

1. To submit a request to add content (other than an alert or IPU), an authorized submitter can send the request via email to \*CTR ODN SERP SECT. A member of the SERP staff contacts you to discuss the details. For information on submitting job aids, see _IRM 1.11.8.6.5_, Adding Job Aids.

2. If approved, the SERP staff provides the content owner with SERP requirements and, upon concurrence, places the content on SERP.

3. Items are added by the program owner or designated authorized submitter.



### Note:



It is the content owner’s responsibility to ensure the content was cleared following all organizational and IRM requirements.

4. The SERP staff notifies the content owner once the content has posted to SERP.


**1.11.8.6.5** **(06-02-2023)**

#### Adding Job Aids

01. Job aids are documents or content posted on SERP that are not in the IRM, but rather assist in following the IRM by combining multiple instructions or providing other details about the procedures.



    ### Note:



    All procedural/instructional information, or "instructions to staff" , **must** exist in the published IRM or in official interim guidance (IPU).

02. Do not include local procedures in a job aid. See _IRM 1.11.8.4_(2)d), SERP IRM Author Roles and Responsibilities.



    ### Note:



    For Accounts Management, all local job aids are forwarded to the Process Improvement (PI) Specialist to forward to Process Improvement/Customer Accuracy (PICA) for Policy & Procedures IMF (PPI), Policy & Procedures BMF (PPB), and Identity Protection Strategy & Oversight (IPSO) approval to post on SERP. See IRM 21.10.1.2.7.1, AM IRM Procedural Update/SERP Alert/News Release Filtering and Distribution and IRM 1.4.16.7.5, Process Improvement (PI) Specialist Roles and Responsibilities, for additional information.

03. All job aids (e.g., exhibits, charts, graphs) must meet Section 508 compliance before forwarding to SERP. See _IRM 1.11.8.5_, Section 508 Compliant Content, for more information.



    ### Note:



    SERP is a web page platform (.htm, .html etc.) and will usually convert large format documents such as PowerPoint, Word, and PDF into user-friendly HTML pages. SERP will reformat documents into HTML pages only after accessibility concerns are met (i.e., 508 compliance). For best results, SERP should be included as soon as possible in the design process.

04. Job aids must follow disclosure requirements. Fictionalize taxpayer name, address, and tax information (e.g., identity, exemptions, money amounts). More information on fictionalizing content is found in IRM 1.11.2.5.6, Fictitious Identifying Information and IRM 6.410.1.3.10, Disclosure Requirements.

05. Graphics must be submitted with alternative text.

06. Job aids can only be added by the content owner.



    ### Note:



    It is the content owner’s responsibility to ensure the content was cleared following all organizational and IRM requirements.

07. Job aids with IRM references must be reviewed and updated with current IRM references each time procedures change in the IRM.

08. Locally prepared job aids must be submitted to the Business Operating Division (BOD) analysts for approval.

09. Submit job aids via email to \*CTR ODN SERP SECT. A member of the SERP staff contacts you to discuss the details.

10. If approved, the SERP staff provides the content owners with the SERP requirements and, upon concurrence, places the content on SERP.


**1.11.8.7** **(01-26-2015)**

### Updating Content on the SERP Website

1. This section provides instructions to IRM authors and authorized submitters for updating IRMs posted on SERP, alerts, and other content.

2. SERP IPU process requires clearing updates following IRM requirements and ensures users have the most current information.

3. Content on SERP must be annually certified as current and accurate.

4. IRM Authors must use IRM Procedural Updates (IPUs) to issue interim guidance. If the program owner uses interim guidance memoranda, they must issue a corresponding IPU to ensure the revised procedures are accessible to SERP users.


**1.11.8.7.1** **(12-06-2022)**

#### Updating IRMs Through an IRM Procedural Update (IPU)

1. An IPU revises or corrects existing IRM information on the SERP IRM only. No other IRM formats, including the published version available to the public are updated.



### Exception:



If the author identifies an IPU as meeting E-FOIA through the IPU Submission Form, the SERP staff prepares a Content Publishing Request and a Word version of the IPU’s changes, then, sends this to the author’s IG/IMD coordinator for processing and forwarding to SPDER for posting to the [FOIA Library](https://www.irs.gov/privacy-disclosure/foia-library) on www.irs.gov. More information on E-FOIA is found at Freedom of Information Act (FOIA) (5 USC § 552(a)(2)(C)) and in IRM 1.11.10.4, Evaluate Interim Guidance for E-FOIA.

2. Business units must incorporate IG into the next revision of the published IRM section(s) through Media and Publications (M&P) within two years from the issuance date or sooner, if required by the business unit. IRMs published annually must continue to incorporate interim guidance and publish each year.



### Note:



Refer to the policy and procedures set by the Office of Servicewide Policy, Directives and Electronic Research (SPDER) in IRM 1.11.2, Internal Revenue Manual (IRM) Process and IRM 1.11.10.2, Interim Guidance Standards.

3. If an IPU is not incorporated into the published version of an IRM within the effective period, the IRM may be removed from SERP. See _IRM 1.11.8.7.1.2_, Reissuing IPUs (Interim Guidance).

4. IRMs are posted to SERP based on the IRM's Effective Date and not the IRM's published date. Authors can issue an IPU for an IRM as soon as the new revision of the IRM has posted on SERP.



### Example:



IRM 21.1.1 is effective on 10/01/2021. The author can submit an IPU to SERP any time after the new revision (effective date 10/01/2021) for IRM 21.1.1 has posted on SERP.

5. If you issue an IPU after the IRM was sent to Publishing but before the new revision posts, you may need to keep two versions of the XML file. The first XML file is what was sent to Publishing and the second XML is what is currently on SERP - sometimes called a "working copy" If updates are needed during this time, issue an IPU with edits made to the XML file currently on SERP.

6. SERP posts the newly published IRM version on the effective date or shortly thereafter.



   - If you made updates prior to the new revision posting on SERP, and/or need to make more updates after the IRM is published, submit an IPU and in the Notes section of the Submission Form, state the IPU should post after the new IRM revision posts.

   - If you issued updates in an IPU during publishing and you do not need to make any other updates, you may email your XML file to SERP stating it is an "overlay" for posting after the new IRM revision posts.

   - See Exhibit 1.11.8-8, Scenarios for Start-Up IPUs, for more guidance on how to submit updates before and after the IRM is published.


7. SERP’s IRM retention system allows you to access all versions of the IRM with the corresponding dates for each IPU and any IRM revisions published by Media & Publications. Users can view IPUs by the calendar year the IPU was issued.



### Note:



More information on researching IPUs through the retention system is on the Researching IRMs and IPUs tutorial located on the Learning Tab on the SERP website.

8. When issuing an IPU the author needs to obtain concurrence by reviewers, approval by management or responsible designated official, use the IRM Authoring software (Arbortext Editor) to revise the IRM file, and finally complete the SERP IRM Update Submission Form to submit the IRM update to SERP. See _IRM 1.11.8.7.1.1_, Issuing an IPU (Interim Guidance).


**1.11.8.7.1.1** **(03-17-2023)**

##### Issuing an IPU (Interim Guidance)

1. SERP IPUs are a form of interim guidance. IPUs must follow the interim guidance procedures as stated in IRM 1.11.10.3.1.2, SERP IRM Procedural Updates (IPUs).

2. To update the IRM on SERP through an IPU:



1. Revise your IRM in the IRM Authoring software (Arbortext Editor). See _IRM 1.11.8.7.1.3_, IRM Authoring Tool - Updating Your IRM XML File for IPU Submission.

2. Forward the changed procedural content for review and concurrence. Follow procedures in IRM 1.11.10.5, Clear Interim Guidance.

3. Obtain approval for the change you are making following your organization or program office guidance. Follow procedures in IRM 1.11.10.6, Approve Interim Guidance.

4. Determine if any of the changes within the updated file meet E-FOIA criteria using the SERP E-FOIA Decision Tool located within the SERP Submission Form, New Update.



      ### Note:



      The E-FOIA decision tool is a resource to aid in making a proper FOIA determination. Instructions to employees that affect a member of the public must be electronically available to the public according to the Freedom of Information Act (FOIA) [5 USC 552(a)(2)(C)](http://www.irs.gov/uac/IRS-Freedom-of-Information). IRM 11.3.7, Freedom of Information Act Reading Room Operations, provides more information on the law.

5. Complete and submit an IPU request by accessing the SERP Submission Form and selecting the 'New Update' link on the navigational bar. See _IRM 1.11.8.7.1.4_, SERP IRM Procedural Update (IPU) Submission Form, for specific information about completing the form.


3. IPUs cannot be "rescinded" ; if you are removing temporary guidance, please submit a new IPU even if the intent is to revert to prior instructions.

4. IPUs cannot be "revised" ; if you are revising or changing information included in a prior IPU, please submit a new IPU. If you need to reissue an IPU that is over two years old, see _IRM 1.11.8.7.1.2_, Reissuing IPUs (Interim Guidance).

5. An IPU is not required for editorial corrections (e.g., grammatical, spelling, punctuation and broken links). Contact the SERP Office to make corrections via email at \*CTR ODN SERP SECT. See IRM 1.11.2.8, Editorial Update Process, for a list of other changes that may be considered editorial in nature.



### Exception:



Updates to rates, telephone numbers, websites/references or any other information that impacts taxpayers are considered substantive changes and should be submitted as an IPU.





### Note:



Editorial changes are made to the "current" IRM version in the SERP database. There are no corrections made to the "archive" or historical version which reflects content as it was issued in prior lPU(s) or published versions.

6. Use a single statement to summarize multiple editorial changes throughout an IPU. Specify the reason and type of change, not each specific change location. Place this information in the last paragraph in the list of material changes. Do not update the subsection date if the only changes are editorial. See IRM 1.11.2.6.1.3(2) 7), Manual Transmittal Material Changes and IRM 1.11.2.5.2.1, Determine the Subsection Date, for more information.

7. Documentation of the IRM changes including the approval of the changes and any significant comments received from reviewers must be retained for historical record keeping purposes. The author should save a .pdf file of the track changes and/or emails documenting the approvals.


**1.11.8.7.1.2** **(12-04-2023)**

##### Reissuing IPUs (Interim Guidance)

1. IPUs (interim guidance) must be incorporated into the next revision of the published IRM section(s) through Media and Publications (M&P) within two years from the issuance date or sooner, if required by the business unit. IRMs which are published annually must incorporate IPUs annually.

2. Generally, permanent interim guidance must be incorporated into the IRM before the expiration date. Rarely, for continuity of operations, an IPU may be reissued when the content is unchanged and still valid. Examples include:



   - Pending legislation, NTEU negotiations, rulings or guidance from Counsel impacting the IRM.

   - Filing season IRM publishing delays.

   - Delays in resolving issues that surfaced during the IRM clearance process.

   - Extension of a pilot program.

   - Extension of temporary guidance.


3. A new IPU must be submitted to reissue an IPU. Multiple IPUs may be reissued in a single IPU. The reissuance of an IPU requires the approval of the relevant program director and the Director of SPDER. See IRM 1.11.10.9.2, Reissue Interim Guidance.

4. If the request is approved, the issuing business unit must:



1. Forward approval emails to the SERP mailbox, \*CTR ODN SERP SECT.

2. Review the changes listed in the original IPU(s) to determine if they are all still valid. Any changes that are not present in an original IPU cannot be reissued.

3. Edit the XML file.



      > 1. Update ONLY the material changes section to reflect the reissued IPU(s).
      >
      >       2. The text of the material changes should list each change from the original IPU(s) which are being reissued.
      >
      >       3. Before each change, enter: "Reissuing IPU 2XUXXXX dated MM-DD-YYYY for IRM X.XX.XX. These procedures will be incorporated into a published copy of the IRM by MM-DD-YYYY" .
      >
      >       4. If multiple IPUs are being reissued, list each one separately in the material changes.
      >
      >       5. Do not update any subsection dates.
      >
      >
      >
      >          ### Note:
      >
      >
      >
      >          New interim guidance cannot be included in the same IPU. Submit a separate IPU for new interim guidance following normal procedures.

4. Complete the Submission Form using normal procedures. Reissued guidance will receive a new date and IPU number.



      > 1. In the subject line, enter "Reissuing IPU(s)" .


**1.11.8.7.1.3** **(07-15-2022)**

##### IRM Authoring Tool - Updating Your IRM XML File for IPU Submission

1. To issue a SERP IPU, use the current IRM Authoring Tool to make your changes. Update the Manual Transmittal (MT) to document substantive procedural changes in your IRM. Take the following actions:




| Action: | Additional Information: |
| --- | --- |
| Use the "Change Tracking" feature in the IRM Authoring Tool to show your changes. Do not accept tracked changes before sending your file to SERP. | Tracked changes display as follows when the IPU is posted on SERP:<br> <br>   - Revised text is highlighted yellow<br>     <br>   - Deleted text is deleted<br>     <br>   - Highlighting from previously updated text (such as from a prior IPU) is removed |
| Verify linked content is correctly formatted:<br> <br>   - Use "citation" tags to identify links to IRMs, Forms, Publications, Documents, Computer Paragraph (CP) Notices, Letters, etc.<br>     <br>     <br>     <br>     ### Exception:<br>     <br>     <br>     <br>     Links point to the most recent year or revision available in the Product Catalog. To link to a prior year revision of a Form, Publication, Letter, etc. you must insert an "anchor" tag and provide the URL for the applicable revision/year.<br>     <br>   - Use "seealso" tags to cross-reference subsections within the same IRM.<br>     <br>   - Use "anchor " or "a" tags and the URL to create links to other content such as: share point sites, www.irs.gov, etc.. | SERP creates links by matching "word patterns" even without tags being present, however it saves time to edit your file with tags since they are required when republishing your IRM.<br> See IRM 1.11.2.5.8.5, Create Hyperlinks, and follow the IRM Citation Standards in _Exhibit 1.11.8-7_.<br> <br>### Note:<br>When linking to legal references provide links to content that is accessible to all users. For example, a publicly available source for legal references is the Code of Federal Regulations (eCFR) at [https://www.ecfr.gov](https://www.ecfr.gov/). |
| Do **not** update the**Manual Transmittal**date. | SERP edits the Manual Transmittal date with the effective date of the IPU before uploading the IRM on SERP. |
| Update the **Purpose** to "This transmits revised IRM X.X.X, Chapter title, Section title" or similar statement. | See IRM 1.11.2.6.1.2, Manual Transmittal Purpose. |
| Update the **Material Changes** paragraphs to list all significant changes made with this IPU. List either "IRM" or "Exhibit" with the entire IRM reference where the change occurs followed by a brief, but thorough description of the change. Include a reason for the change (e.g., language clarification, legislation change). See IRM 1.11.2.6.1.3, Manual Transmittal Material Changes.<br> <br>### Example:<br>IRM 21.6.3.5(6) Clarified the use of Form 8862 to figure the credit or refund.<br>### Example:<br>Exhibit 21.6.3-1 Added other credits to table. | SERP inserts the IPU number and date at the beginning of each material change paragraph.<br> <br>### Reminder:<br>When revising your file for the first IPU after republishing, remove all previous material changes from the published IRM version and list your significant changes for the current IPU only. When issuing subsequent IPUs, accept all tracked changes from the previous IPU/XML file, then continue listing the changes for each subsequent IPU. |
| Update the **Effect on Other Documents** to state the IPU supersedes the last published IRM. Each time an IPU is issued, update the Effect on Other Documents to add the IPU control number(s) and the issuance date(s). See _Exhibit 1.11.8-9_ Updating the Effect on Other Documents. | See IRM 1.11.2.6.1.4, Effect on Other Documents, and IRM 1.11.7.4.3.1(5), Updating the Manual Transmittal when Issuing an IPU, for other considerations. |
| Update the **Signature** (name and title) of the program director or authorizing official if your organization has changed leadership since the last publication of the IRM. | Do not issue an IPU if the **only** change is the Signature. Use IPUs for procedural updates only. |
| **Do not** change the **Effective Date** of the IRM. | The effective date reflects the date the entire IRM becomes effective. Only change the effective date when your IRM is republished. |
| For each subsection with revised content edit the subsection date to the" wildcard date" (MM-DD-YYYY) format.<br> <br>   - Using Change Tracking, delete the current date, _including the parenthesis_<br>     <br>   - Type (MM-DD-YYYY) _immediately after_ the deleted date and include the parenthesis.<br>     <br>   - Do not add a space between the deleted date and (MM-DD-YYYY)<br>     <br> See _Figure 1.11.8-1_ below.<br> <br>### Caution:<br>Include the parentheses around the subsection date **(**MM-DD-YYYY**)** to avoid "completeness errors" .<br>### Note:<br>New subsections already have the subsection date formatted (MM-DD-YYYY) with tracked changes. | SERP replaces all subsection dates edited (MM-DD-YYYY) with the effective date of the IPU.<br> <br>### Note:<br>IRM subsections on SERP have two dates displayed:<br>   - The first date is the previous effective date of the subsection. This is usually the publishing date or the previous IPU date.<br>     <br>   - The second date is the most recent update received from the author.<br>     <br>     <br>      For subsections with changed content the second date, highlighted in yellow, is the date of the current IPU.<br>     <br>   - For subsections not affected by the current IPU, the second date is not highlighted. |





**Figure 1.11.8-1**

![This is an Image: 50463073.gif](https://www.irs.gov/pub/xml_bc/50463073.gif)





> This figure shows an example of the correct format to use when changing the subsection date.Using Change Tracking, delete previous date, including the parenthesis (03-30-2010). Then, enter (MM-DD-YYYY), being sure to include the parenthesis.







[Please click here for the text description of the image.](https://www.irs.gov/media/129541 "")

2. After making the changes to your file, use Arbortext Tools to run "Validate Cross References" and run "Check Completeness" . Correct any context errors, missing elements, invalid references, etc. prior to submitting your XML file to SERP.

3. Attach the revised IRM XML file to the SERP Submission Form using the "Add File" button. Activate the "Add File" button by clicking the "Save" button once all applicable fields are completed. See _IRM 1.11.8.7.1.4_, SERP IRM Procedural Update (IPU) Submission Form.

4. After processing, SERP returns the XML file back to the author via email with the changes tracked and edits as shown in the (1) table above. It is the author’s responsibility to accept all tracked changes in the XML file after it is returned.



### Note:



Authors may need to keep two separate IRM files during the period when the analyst is making changes to the current year IRM and updating for the annual IRM revision. See _Exhibit 1.11.8-8_, Scenarios for Start-up IPUs, for other considerations


**1.11.8.7.1.4** **(07-15-2022)**

##### SERP IRM Procedural Update (IPU) Submission Form

01. The SERP Submission Form is used to document information about an IPU and to assist authorized submitters in determining whether the Update meets E-FOIA criteria, under IRC 5 USC 552(a)(2)(C).

02. SERP staff must add you to the SERP database before you can submit an IPU. Instructions on how to request access are found in the SERP Submission Form User Guide as well as in _IRM 1.11.8.3_, Authorized Submitter.

03. For each IPU, the authorized submitter:



    1. Accesses the SERP IPU Submission Form by going to the Author Resources page on the SERP website and clicking on the "SERP Submission Form Login" link. You are automatically logged into the SERP Submission Form application.

    2. Next, click on the "New Update" link on the navigational bar.

    3. Determines if the changes affect taxpayers and if FOIA applies by answering the questions on the form. See [5 USC § 552(a)(2)(C)](http://www.irs.gov/uac/IRS-Freedom-of-Information). The [SERP E-FOIA Decision Tool](http://serp.enterprise.irs.gov/databases/local-sites-other.dr/author-resources/efoia-decision-tool.html) is another resource.



       ### Note:



       If the IRM author determines the IPU meets E-FOIA criteria, SERP creates a second IPU for E-FOIA purposes, which includes only the identified changes that meet E-FOIA. The E-FOIA IPU is sent to the organization's IG coordinator for posting to the [FOIA Library](https://www.irs.gov/privacy-disclosure/foia-library) on www.irs.gov.

    4. Completes all fields in the Submission Form. Find detailed instructions on the tab titled "New Update" in the SERP Submission Form User Guide.

    5. Clicks "Save" to activate the "Add File" button, the "Submit" button and the "Email" button. Clicking the "Save" button also assigns the record a temporary tracking number, adds the record to your list of ACTIVE records on the MY INPUTS page, and allows you to create an optional email to send to an approver/reviewer or co-worker prior to submission. The system retains the saved IPU in the MY INPUTS page and does not submit to SERP until you click the submit button.

    6. Attaches the IRM XML file and any related files such as graphics, change pages, etc., following the guidelines found in the Files/Attachments link under the **New Update** tab of the Submission Form User Guide. To attach file(s):


    1. Name your file following the naming conventions outlined in the Submission Form User Guide.

    2. Click the "Add File" button and browse to select the file.

    3. Add a description of the file content (optional)

    4. Repeat the "Add File" steps to submit more than one file.


04. When submitting graphics with your XML file, you must include the graphic "file filename" in the "Description" box on the form and attach a clean copy of the graphic in .pdf format. Do not submit change pages as a graphic.



    ### Note:



    While SERP accepts graphic files in other formats, Publishing accepts graphics in .pdf format only. See IRM 1.11.2.5.7, Graphics, for more information.





    ### Reminder:



    Graphics must include alternative text for 508 Compliance. See _IRM 1.11.8.5_, Section 508 Compliant Content.

05. Before you submit your IPU to SERP, submit the changes for review and obtain approval of the approving official following your organization’s guidelines. See IRM 1.11.10.5, Clear Interim Guidance and IRM 1.11.10.6, Approve Interim Guidance.



    ### Reminder:



    Documentation of the IRM changes including the clearance/approval of the changes and any significant comments received from reviewers must be retained for historical record keeping purposes. The author and/or the program manager or designee should save a .pdf file of the track changes and/or emails documenting the approvals.

06. If your organization requires review of the IPU submission prior to sending it to SERP, use the Submission Form to email a link to the draft IPU and attached XML file, or word document, with the changes.



    1. Click "Email" .

    2. Insert email address(s).

    3. Add attachments or other content to the body of the email. You may add to the subject if you need anything other than the auto populated IPU temporary tracking number.

    4. Click "Send" as normal.


The body of the sent email includes a link to the IPU record. The link also allows recipients to track the progress of the Submission Form. Recipients can view the record and the attachments; however, they cannot make changes to this record or the attachments. If changes are needed to take the following actions:



    - Attach a separate word document with the IPU content and/or the uploaded documents to the email for the recipient to review.

    - The recipient copies and pastes the items needing to be changed from the IPU record into the email.

    - The recipient opens the uploaded files from the links in the IPU record and saves them to their desktop for editing. Once edited they need to attach the changed items to the email and return it to you to make the changes before submitting the IPU for posting.


07. Attach the approved XML file including any final changes or edits to the Submission Form using "Add File" . Use the "Remove" button to delete any files that no longer need to be attached.

08. When you are ready to submit your IPU to SERP, click the "Submit" button. The form validates your input and gives a message for any missing fields. Click "OK" to close the message, then go back to the missing item and input the information before submitting the form. The following are possible validation messages you could receive:



    - "Please enter a Subject"

    - "Please select the Audience"

    - "You did not answer the question - Was this IPU the result of SERP feedback?"

    - "Enter Feedback Control Number (if applicable)"

    - "Please select the Master File"

    - "You are responsible for obtaining all approvals needed for this IPU"


### Note:

Incomplete forms or attachments could delay the posting of the IPU. See _IRM 1.11.8.9.2_, _Time Frames for Posting to SERP_. If an IPU needs to be expedited through the SERP process (posted quicker than the normal processing time frame), contact SERP management directly to provide justification and authorization from the program manager.

09. When all inputs are validated, a warning box displays: "Submission will be posted within 48 hours; Are you sure you want to submit the form?" If you click "OK" the system:



    - Removes the temporary tracking number and assigns the record the posting number.

    - Moves the record to your list of SUBMITTED records on the MY INPUTS page.

    - Submits the record and any attachments to the database for SERP to process and post to the website.


10. If you click "Cancel" a message displays, "The form will remain under My Inputs as Active." Click "OK" to return to your "Saved" form.


**1.11.8.7.2** **(12-06-2022)**

#### Updating Alerts

1. You may request revision of an alert if content needs updating with new information. The revised alert shows the new information highlighted in yellow.

2. SERP does not allow supplemental alerts with a reference to a prior alert on the same topic/issue. All information must be in one alert for a given topic/issue. If you need to communicate more information about the alert topic, or revise the contents of an alert, see (4) below to request a revised alert.

3. SERP Alerts expire one year from the date they are issued or when the topic is no longer needed, whichever is earlier. It is the content owner’s responsibility to monitor the status and notify SERP to rescind an alert.



### Note:



If the alert is over one year old, and the topic is still needed, the alert must be rescinded and then reissued as a new alert.





### Reminder:



You cannot rescind any alert by simply issuing a new alert. The first alert must be marked "Rescinded" and posted on SERP, so it is clear to the end user which alert has the most current information.

4. To revise or rescind an alert:



1. Send an email request to: \*CTR ODN SERP SECT.

2. Notate in the email, the alert number and if it is being revised or rescinded

3. If the alert is being revised, include the updated content with changes highlighted


**1.11.8.7.3** **(10-22-2018)**

#### Updating All Other Content

1. If content pages need updating with new information, the content owner must send a revised copy and show the new information highlighted in yellow.

2. To update content pages, submit revisions to SERP via email to: \*CTR ODN SERP SECT.

3. The SERP staff notifies the content owner when the updated content posts to SERP.


**1.11.8.8** **(11-24-2020)**

### Removing Content from the SERP Website

1. This section provides instructions to IRM authors and authorized submitters for removing IRMs, alerts, and other content posted on SERP.


**1.11.8.8.1** **(12-06-2021)**

#### Removing IRMs

1. Send IRM removal requests to the SERP mailbox at \*CTR ODN SERP SECT. SERP does not consider removal requests from persons or parties not affiliated with IRM or content ownership. Upon receiving a removal request, SERP provides the author/requestor with an impact statement, which includes "hit counts" and number of linked materials/pages. Authors/Requestors evaluate the impact statement to determine if removal is prudent.

2. If the author/requestor decides to proceed with removal of an IRM, take the following actions:



1. Obtain executive approval from the operating division.

2. Notify affected offices of the intent to remove.

3. Allow a 90-day grace period prior to removal, to address comments or feedback, and to allow time to resolve other impacted content, i.e., authors with IRMs that cross-reference the removed SERP content need to update links.


### Note:

SERP directs any comments or feedback concerning removal of a specific IRM to the author/requestor.

3. After the 90-day period, if the IRM still needs removal, SERP posts a Priority News item similar to the following: _Effective (date) - Per the IRM author's request, IRM X.X.X will be removed from the SERP website. You can view a listing of all removed IRMs on the_ IRMs Removed from SERP _page_.

4. SERP removes the IRM and emails the author/requestor confirming IRM is removed from the SERP website.



### Reminder:



Removing an IRM from SERP does not remove it from the M&P IRM Index, IRM Online, IRS.gov, etc. If obsoleting an IRM section, see IRM 1.11.2.9, Rules to Obsolete an IRM Section.


**1.11.8.8.2** **(11-24-2020)**

#### Removing Alerts

1. SERP Alerts are not removed from the website as the content provides historical information. When the content is no longer valid (or has expired) the alert is "rescinded" .

2. To rescind an alert, send an email to the SERP section mailbox at \*CTR ODN SERP SECT and request the alert is rescinded.

3. SERP marks the alert page as "Rescinded" and posts a notification on the SERP homepage.


**1.11.8.8.3** **(11-24-2020)**

#### Removing All Other Content

1. To remove any other content/pages from SERP send an email to the SERP section mailbox at \*CTR ODN SERP SECT with your request.

2. The SERP analyst assigned to the type of content or page/portal location works with the requestor to remove the content.


**1.11.8.9** **(11-24-2020)**

### SERP Posting Information

1. This subsection has information about SERP numbering and timeframes.


**1.11.8.9.1** **(12-06-2021)**

#### SERP Numbering Scheme and Function Identification

1. Upon submission, alerts and IPUs are given a unique control number.



   - The first two digits are the calendar year.

   - The third character, A or U, shows whether it's an alert (A) or an IPU (U).

   - The remaining numbers are the SERP control number.


2. To allow users to quickly identify whether an alert or IPU is relevant, SERP uses the following codes to identify the affected function.




| **Function** | **Code** |
| :-: | :-: |
| Accounts Management | AM |
| Compliances Services | C |
| Customer Assistance Relationship and Education (CARE) | CA |
| Field Collection | FC |
| Return Integrity & Compliance Services (RICS) | R |
| Submission Processing | SP |
| Tax Exempt and Government Entities (TE/GE) | T |
| Taxpayer Advocate Service | TA |
| Other | O |
| All | ALL |


**1.11.8.9.2** **(01-03-2012)**

#### Time Frames for Posting to SERP

1. Allow the following time frames when submitting items for posting.




| **Item Content** | **Time Frame** |
| :-: | :-: |
| IRM Procedural Update (IPU) | If received by 3:00 p.m. EST/EDT (Eastern Time Zone), the IPU should post on the next workday's Homepage and applicable portals. |
| Alerts | If received by 3:00 p.m. EST/EDT, the alert should post on the next workday's Homepage and applicable portals. |
| Other content | Generally, posts within 24-48 hours depending on the type of information received. |


**1.11.8.10** **(09-28-2021)**

### SERP Feedback - Author/Content Owner Responsibilities

1. The SERP Feedback system allows users to submit feedback concerning IRMs and other technical content on the SERP website, including corrections and changes addressed by the IRM author/content owner. The system provides IRM authors/content owners’ access to user feedback to review the feedback and provide a response. A complete Feedback Guide for Content Owners is available on the Author Resources page.



### Note:



The "Contact SERP" feature located on the SERP home page is for submitting questions or reporting issues about SERP website functionality. "Contact SERP" is not intended for technical or policy-related questions or concerns about IRM content or other issues addressed through SERP Feedback.

2. Authors/content owners new to SERP Feedback can get access by clicking the Author/Content Owner login and completing an "Add Me" request with required information needed for their system profile. Refer to the Feedback Guide for Content Owners System Access for detailed instructions.

3. When responding to SERP Feedback, an IRM author/content owner must:



1. Provide an appropriate response within 45 calendar days. See IRM 1.11.2.5.1.3, Respond to Requested IRM Changes, if the change is related to an IRM.



      ### Exception:



      IRM 3 authors have seven calendar days to respond to feedback per Submission Processing policy.

2. Provide a time frame for IRM update or issue resolution.

3. Respond courteously to duplicate feedback. SERP pre-screens for duplicates before assigning, however multiple feedback submitted is a measure of how important the issue is for users. When responding to duplicate feedback, reference the feedback number and date of the original feedback.



      ### Note:



      Feedback that affects multiple IRMs is not considered duplicate if the feedback applies to different subsections and is submitted under separate URLs.

4. If unable to provide a response before the due date request an extension. On the "Feedback" tab, select the feedback to extend, select "Contact SERP" tab. Then select the "Request Extension" radio button, in the message field input the justification and click "Send" . SERP may grant a onetime 30-calendar day extension.


4. Feedback allows content owners to take other actions to resolve feedbacks:



1. Reassign feedback if needed on the "Feedback" tab using the "Reassign" tab with the name of the new feedback owner.



      ### Note:



      The new feedback owner receives email notification about the reassigned feedback.

2. If the feedback was incorrectly assigned and the content owner is unknown, on the "Feedback" tab use the "Return" tab to return the feedback to SERP to reassign.

3. Use the "Contact SERP" tab to request editorial changes such as spelling, grammar, and punctuation errors or to fix broken links. See _IRM 1.11.8.7.1.1_(5) Issuing an IPU (Interim Guidance), for more information about editorial changes.

4. Use "Contact SERP" for questions about the feedback SERP would answer. Contact the submitter directly for more information or to clarify the issue.

5. Use the "Content Management" tab to reassign SERP content pages (not IRMs) either temporarily or permanently, to another content owner. See Feedback Guide for Content Owners Content Management Tab for detailed instructions.



      ### Note:



      The new content owner receives email notification about the assigned content.

6. If the IRM author or alternate changes, contact SERP Feedback administrators or click the link in the "Content Management" tab and provide the name of the new author/alternate, with a cc to your manager. If adding or changing the author or alternate for an IRM with currently assigned feedback, please provide the ID number for any feedback that needs reassigning.



      ### Note:



      The new author receives email notifications about the assigned IRM and any new or reassigned feedback.


**1.11.8.10.1** **(09-28-2021)**

#### Feedback Reports

1. Access reports for the SERP Feedback system through the "Reports" link at the top left of the content owner page.

2. Feedback Reports are searched using the status "Filter" and type of "Search" in various combinations. To create a report:



1. Select a status filter (Open, Assigned, Closed or No status filter) and/or beginning and ending date. Status filters and dates are optional.

2. Select the type of search (IRM, ID number, Submitter SEID, Assigned SEID, etc.). You may only select one search type for each report. Enter the applicable search or the text you wish to find in the URL, Feedback or Response.

3. Click "Search" .


3. The system displays the results for all feedback matching the search. Click on the ID number to view the individual feedback and response. View the web page for the feedback using the link button to the right of the feedback.



### Note:



See Feedback Guide for Content Owners Reports for more information and search examples.


**1.11.8.11** **(09-28-2021)**

### Content Certification Process

1. A content certification process is used to ensure content is compliant and to keep the SERP website current.

2. Each year, IRM authors/content owners with content hosted on SERP are notified via email of certification actions.



1. IRM authors/content owners must certify the SERP content is accurate and current using the "Certification" tab in Feedback. See Feedback Guide for Content Owners Certification Tab for detailed instructions.

2. Managers of IRM authors/content owners receive a past due email if there is no response from the IRM authors/content owners within the 21-day time frame.


### Note:

The recipient of the certification email must respond even if they are no longer the IRM author/content owner. The certification requests the name of the new IRM author/content owner (if known).

3. If there is no response from the IRM author/content owner or their manager to the content certification request, the IRM/content is subject to removal from the SERP website.



### Note:



IRM authors/content owners, management, and IMD coordinators receive a notice of intent to remove content prior to removal of the IRM/content.

4. If an IPU was issued and it is within the effective period of the IPU, and the updated IRM content is accurate and current as issued, certify the IRM. See _IRM 1.11.8.7.1_ (2) and (3), Updating IRMs through an IRM Procedural Update (IPU), for the definition of "effective period" .


**Exhibit 1.11.8-1**

### Example of a Flowchart with a Non-Compliant Alternative Text (Does Not Meet Section 508 Requirements)

The following is an example of a flowchart with a non-compliant Alternative Text. A flowchart is non-compliant if the Alternative Text is not present or a detailed description of each flowchart box and line being shown is not given.

![This is an Image: 50463061.gif](https://www.irs.gov/pub/xml_bc/50463061.gif)

> Below is an example of a flowchart with a non-compliant Alternative Text.

[Please click here for the text description of the image.](https://www.irs.gov/media/129556 "")

**Exhibit 1.11.8-2**

### Example of a Flowchart with a Compliant Alternative Text (Meets Section 508 Requirements)

The following is an example of a flowchart with a compliant Alternative Text. A flowchart is compliant if the Alternative Text is present and provides a detailed description of each flowchart box and line being shown or a detailed description of the flowchart is provided in the text immediately preceding (before) or following (after) the flowchart.

![This is an Image: 50463062.gif](https://www.irs.gov/pub/xml_bc/50463062.gif)

> Below is an example of an Alternative Text that could be used to make the flowchart compliant.

[Please click here for the text description of the image.](https://www.irs.gov/media/129561 "")

**Start Here**

This is the start of the flowchart.

**Process 1**

Will you owe $1,000 or more after subtracting income tax withholding and credits from your total tax? (Do not subtract any estimated tax payments.)

If yes, continue to process 2.

If no, continue to process 3.

**Process 2**

Will your income tax withholding and credits be at least 90 percent of the tax shown on your tax return?

If yes, continue to process 3.

If no, continue to process 4.

**Process 3**

You are not required to pay estimated tax. (END)

**Process 4**

Will your income tax withholding and credits be at least 100 percent of the tax shown on your tax return?

If yes, continue to process 3.

If no, continue to process 5.

**Process 5**

You must make estimated tax payments by the required due dates. (END)

**End**

This is the ending of the flowchart.

**Exhibit 1.11.8-3**

### Example of a Section 508 Non-Compliant Table

The following is an example of a Section 508 non-compliant table. Graphics are non-compliant if alternative text is not present, or a detailed description of the graphic content is not provided. Never present tabular data in graphic form. If the data is a form or worksheet, re-create it as a table in XML or use citation tags to link directly to the form.

![This is an Image: 50463063.gif](https://www.irs.gov/pub/xml_bc/50463063.gif)

> Example of a Section 508 non-compliant table.

[Please click here for the text description of the image.](https://www.irs.gov/media/129566 "")

**Exhibit 1.11.8-4**

### Example of Section 508 Compliant Table

The following is an example of a table that is Section 508 compliant.

### Note:

For Section 508 compliance, designate a Header Row and ensure the Table tag summary attribute is complete. Merged and split cells are not 508 compliant.

| **Line** | **Description** |
| --- | --- |
| 12\. Add line 11 to line 3. | 10,872.35 |
| 13\. Subtract line 12 from line 9. If negative, enter 0. | 177.93 |
| 14\. Compute interest on the amount on line 13 from the date on line 1 to the date on line 2. Remember to adjust the principal for debits and credits applied during this period. | .92 |
| 15\. Add line 14 to the ending principal amount from the last computation as of the date on line 2. | 178.85 |
| 16\. Add line 12 to line 15. | 11,051.20 |
| 17\. Compute interest on line 16 from the date on line 2 to the 23C date of your adjustment (or to the full paid date, if earlier). Remember to adjust the principal for debits and credits applied during this period. | 54.48 |
| 18\. Total interest computed<br> a. If no waiver period used, enter the amount from line 6, then skip to line 19.<br> b. If waiver period used, add lines 8, 14, and 17. | 1,137.44 |
| 19\. Net total of all TC 19X, TC 33X, and TC 34X posted to the module. | 591.76 |
| 20\. Subtract line 19 from the entry on line 18a or 18b. Use brackets { } if the result is less than zero. | 545.68 |
| 21\. If line 20 is negative { }, input TC 341. If positive, input TC 340 for the amount on line 20. | 545.68 |

### Note:

If you need to determine the actual amount of interest waived when there is a waiver period involved, use two separate worksheets. First compute interest as though there is no waiver period. Then, compute again using the waiver period. The difference between lines 18a and 18b is the actual amount of interest waived.

**Exhibit 1.11.8-5**

### Example of a Computer Screen Display with a Non-Compliant Alternative Text (Does Not Meet Section 508 Requirements)

This is an example of a Section 508 non-compliant screen shot of IDRS. An IDRS screen shot is non-compliant if Alternative Text is not present, or a detailed description of content being shown is not given.

![This is an Image: 50463085.gif](https://www.irs.gov/pub/xml_bc/50463085.gif)

> Below is an example of a Section 508 non-compliant screen shot of IDRS.

[Please click here for the text description of the image.](https://www.irs.gov/media/183706 "")

**Exhibit 1.11.8-6**

### Example of a Computer Screen Display with a Compliant Alternative Text (Meets Section 508 Requirements)

![This is an Image: 50463086.gif](https://www.irs.gov/pub/xml_bc/50463086.gif)

> This document is a computer screen shot of Command Code CFINK Response Screen - Taxpayer Information. The following is a description of the screen display.Note: The response screen displays titles in columns, followed by a separator, with the corresponding field values in columns directly below.CFINK nnn-nnn-nnnnvNAME: vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvN/C: vvvv(blank)MF TAXPRD PLN RN/C REP-NUMBER SIGNDATE SDLN FORM LV RCTS AUTHS------------------------------------------------------------------------------------------------------------------------------Row 7 nn yyymm nnn vvvv nnnn-nnnnna mm-dd-yyyy nn-nnnn-nn-nnn-nnx nnnn a aa aaaa

[Please click here for the text description of the image.](https://www.irs.gov/media/183711 "")

**Exhibit 1.11.8-7**

### SERP Citation Standards

The following table includes examples of citations and the required format. for identifying links to IRMs, Forms, Publications, Documents, Computer Paragraph (CP) Notices, Letters, etc.

| **Citation** | **Required Format** |
| :-: | :-: |
| CP | CP plus blank space plus CP number.<br> <br>### Example:<br>CP 503 or CP 575A<br>### Note:<br>CP should appear in front of each CP listed in the content. For example: List CP 503/504 as CP 503, CP 504. |
| Document | Document plus one blank space plus document number.<br> <br>### Example:<br>Document 1492 |
| Document 6209 | ### Example:<br>Document 6209, Section XX, Title |
| Exhibit | Exhibit plus one blank space plus Exhibit number.<br> <br>### Example:<br>Exhibit 1.11.8-7<br>### Note:<br>If using citation tags, the tag type is "IRM" . The word "IRM" auto-populates inside the citation tag; edit the tag content to the exhibit format as shown above. If you are referencing an exhibit in an IRM Online do not use a citation tag. Use an "anchor" tag and provide the exhibit URL. |
| Figure | Figure plus one blank space plus figure number.<br> <br>### Example:<br>Figure 1.11.8-2 |
| Form | Form plus one blank space plus form number.<br> <br>### Example:<br>Form 1120<br>### Note:<br>"Form" should appear in front of each form listed. For example, Forms 1120/1120-F, should be Form 1120, Form 1120-F.<br>### Reminder:<br>Use the form number from the M&P Product catalog page, not the wording on the form itself. |
| Internal Revenue Code (IRC) | IRC plus one blank space plus IRC number.<br> <br>### Example:<br>IRC 6.2 |
| IRM | IRM plus one blank space plus IRM number.<br> <br>### Example:<br>IRM 1.11.8 |
| Job Aid | Job Aid plus one blank space plus title.<br> <br>### Example:<br>Job Aid Alternative Minimum Tax |
| Letter | Letter plus one blank space plus letter number.<br> <br>### Example:<br>Letter 685C |
| Notice | Notice plus one blank space plus notice number.<br> <br>### Example:<br>Notice 7517 |
| Publication | Pub. plus one blank space plus publication number.<br> <br>### Example:<br>Pub. 17 |
| Revenue Procedure | Rev. plus one blank space plus Proc. plus one blank space revenue procedure number.<br> <br>### Example:<br>Rev. Proc. 99-10 |
| Revenue Ruling | Rev. plus one blank space plus Rul. plus one blank space plus revenue ruling number.<br> <br>### Example:<br>Rev. Rul. 99-40 |
| Schedules | Schedule plus one blank space plus schedule letter.<br> <br>### Example:<br>Schedule C<br>### Note:<br>"Schedule" should appear in front of each schedule listed. |
| Technical Communication Document (TCD) | Technical Communication Document plus one blank space plus TCD number or TCD plus one blank space plus TCD number.<br> <br>### Example:<br>TCD 0103<br>### Note:<br>TCD number is a four-digit format. |

**Exhibit 1.11.8-8**

### Scenarios for Start-Up IPUs

Describes actions needed when an IPU is issued during the time an IRM is republished.

| **Scenario** | **Action(s) Required by Author** | **Action(s) Required by SERP** |
| --- | --- | --- |
| No updates (IPUs) after the XML file was sent to Publishing. | No action required. | SERP downloads the XML file from Publishing site and this file is used to update the SERP IRM and Archives.<br> <br>### Example:<br>21P0001 |
| Update(s) issued after the XML file was sent to Publishing BUT before the new revision posted on SERP. | Author takes the following actions:<br> <br>- Downloads XML file from Publishing site.<br>  <br>- Adds the update(s) to the published version.<br>  <br>- Lists the update(s) in the Material Changes.<br>  <br>- Revises the "Effect on other Documents" to include any IPU numbers previously issued. See _IRM 1.11.8.7.1.3_, _IRM Authoring Tool - Updating Your IRM XML File for IPU Submission_.<br>  <br>- Edits the subsection date(s) to reflect the last IPU date for the updated content.<br>  <br>- Accepts all tracked changes and saves file.<br>  <br>- Emails the file to the SERP mailbox (\*CTR ODN SERP SECT) with instructions to overlay the published version with the updated file. | SERP downloads the XML file from Publishing site and adds it to the SERP Archives.<br> <br>### Example:<br>21P0001<br> AND<br> SERP creates a second file with the "overlay" which is used to update the SERP IRM and Archives.<br> <br>### Example:<br>21S0001 |
| Update(s) issued after the XML file was sent to Publishing BUT before the new revision posted on SERP.<br> AND<br> New update(s) are issued after the new revision has posted on SERP. | Author takes the following actions:<br> PART 1<br> <br>- Downloads XML file from Publishing site.<br>  <br>- Adds the update(s) to the published version.<br>  <br>- Lists the update(s) in the Material Changes.<br>  <br>- Revises the "Effect on other Documents" to include any IPU numbers previously issued. See _IRM 1.11.8.7.1.3_, _IRM Authoring Tool - Updating Your IRM XML File for IPU Submission_.<br>  <br>- Edits the subsection date(s) to reflect the last IPU date for the updated content.<br>  <br>- Accepts all tracked changes and saves file.<br>  <br> PART 2<br> <br>- Inserts new updates to the saved file with tracked changes turned on.<br>  <br>- Lists the new updates in the Material Changes.<br>  <br>- Ensures the changed subsection dates are edited with (MM-DD-YYYY), See _IRM 1.11.8.7.1.3_, _IRM Authoring Tool - Updating Your IRM XML File for IPU Submission_, for correct format.<br>  <br>- Uses the SERP Submission Form to request an IPU update to the SERP IRM, following _IRM 1.11.8.7.1.1_, _Issuing an IPU (Interim Guidance)_.<br>  <br>- Attaches the updated file to the SERP Submission Form. | SERP downloads the XML file from Publishing site and adds it to the SERP Archives.<br> <br>### Example:<br>21P0001<br> AND<br> Processes the IPU and attached XML file to update the SERP IRM and Archives.<br> <br>### Example:<br>21U0001<br>### Note:<br>If this occurs at the end of a calendar year, the IPU may be renumbered.<br>### Example:<br>IPU 21U2345 is submitted on December 22, 2021, and is held for processing until after January 1, 2022 (or after the effective date of the published IRM). The IPU is renumbered to 22U0001. |
| Update(s) are being issued after the new revision has posted on SERP. | Author takes the following actions:<br> <br>- Downloads XML file from Publishing site.<br>  <br>- Inserts updates to the saved file with tracked changes turned on.<br>  <br>- Deletes the previous updates from the Material Changes, if applicable.<br>  <br>- Lists the updates in the Material Changes that are being issued with the IPU.<br>  <br>- Ensures the changed subsection dates are edited with (MM-DD-YYYY), See _IRM 1.11.8.7.1.3_, _IRM Authoring Tool - Updating Your IRM XML File for IPU Submission_, for correct format.<br>  <br>- Uses the SERP Submission Form to request an IPU update to the SERP IRM, following _IRM 1.11.8.7.1.1_, _Issuing an IPU (Interim Guidance)_.<br>  <br>- Attaches the updated file to the SERP Submission Form. | SERP downloads the XML file from Publishing site and adds it to the SERP Archives.<br> <br>### Example:<br>21P0001<br> AND<br> Processes the IPU and attached XML file to update the SERP IRM and Archives.<br> <br>### Example:<br>21U0001<br>### Note:<br>If this occurs at the end of a calendar year, the IPU is usually renumbered.<br>### Example:<br>IPU 21U2345 is submitted on December 22, 2021, and is held for processing until after January 1, 2022 (or after the effective date of the published IRM). The IPU is renumbered to 22U0001. |

**Exhibit 1.11.8-9**

### Updating the Effect on Other Documents

The following table describes examples of editing the Effect on Other Documents prior to issuing an IPU.

| Action: | Edit the text as follows: | Example: |
| --- | --- | --- |
| When the first IPU is issued | IRM X.X.X dated \[enter MT Date of last published IRM\] (effective \[enter Effective Date of last published IRM\]) is superseded. | IRM 5.1.30 dated August 10, 2021 (effective October 1, 2021) is superseded. |
| When the second IPU is issued | IRM X.X.X dated \[enter MT Date of last published IRM\] (effective \[enter Effective Date of last published IRM\]) is superseded. The following IRM Procedural Update (IPU), issued on \[enter date of first IPU\], has been incorporated into this IRM: \[enter IPU control number\]. | IRM 4.19.1 dated December 4, 2021 (effective January 1, 2022) is superseded. The following IRM Procedural Update (IPU), issued on March 22, 2022, has been incorporated into this IRM: 22U0108. |
| When any subsequent IPUs are issued | IRM X.X.X dated \[enter MT Date of last published IRM\] (effective \[enter Effective Date of last published IRM\]) is superseded. The following IRM Procedural Updates (IPUs), issued from \[enter date of first IPU\] through \[enter date of last IPU\], have been incorporated into this IRM: \[enter IPU control numbers\]. | IRM 21.1.5 dated September 21, 2021 (effective October 1, 2021) is superseded. The following IRM Procedural Updates (IPUs), issued from November 16, 2021 through May 17, 2022, have been incorporated into this IRM: 21U1116, 21U1187, 21U1277, 22U0094, 22U0178, 22U1518, and 22U1598. |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-011-008#addtoany "Show all")

A2A