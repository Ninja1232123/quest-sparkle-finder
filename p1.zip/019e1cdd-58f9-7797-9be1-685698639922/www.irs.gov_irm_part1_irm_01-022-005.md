---
url: "https://www.irs.gov/irm/part1/irm_01-022-005"
title: "1.22.5 Mail Operations | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-022-005#main-content)

- 1.22.5  [Mail Operations](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010346081536)
  - 1.22.5.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010365647360)
    - 1.22.5.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010365556176)
    - 1.22.5.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010365642528)
    - 1.22.5.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010331915520)
    - 1.22.5.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010332002496)
    - 1.22.5.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010331999920)
    - 1.22.5.1.6  [Frequently Used Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010331996256)
    - 1.22.5.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010331845376)
  - 1.22.5.2  [Mail Operation Relationships](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010365570816)
  - 1.22.5.3  [Definitions of Mailrooms and Mail Operations](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010365566800)
  - 1.22.5.4  [Processing Incoming Mail](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010365653056)
    - 1.22.5.4.1  [USPS Accountable Mail](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010332748000)
    - 1.22.5.4.2  [USPS First-Class Mail](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010332745408)
    - 1.22.5.4.3  [Small Package Carrier (SPC) Letters and Packages](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010332743552)
    - 1.22.5.4.4  [Courier (Messenger) Mail](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010332741584)
    - 1.22.5.4.5  [Freight Shipments](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010332739856)
  - 1.22.5.5  [Postage Due Mail/Collect On Delivery](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010332737952)
  - 1.22.5.6  [Form 3210, Document Transmittal](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010332735504)
  - 1.22.5.7  [Remittance Mail](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010332733152)
  - 1.22.5.8  [Handling Personal Mail](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010332731440)
  - 1.22.5.9  [Consolidating Mail](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010331761696)
    - 1.22.5.9.1  [Opening Internal Management Documents Distribution System (IMDDS)/Consolidated Mail](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010331757872)
  - 1.22.5.10  [Acceptable Mail/Shipping Services](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010331751408)
  - 1.22.5.11  [Guidance on Telework Employee Mail](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010331740896)
    - 1.22.5.11.1  [Home as Post-Of-Duty (HaP) Employees](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010360542608)
    - 1.22.5.11.2  [Remote Work Employees](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010360527296)
  - 1.22.5.12  [Processing Outgoing Mail](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010360521440)
  - 1.22.5.13  [Undeliverable (UD) Mail and Address Updates](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010360514432)
    - 1.22.5.13.1  [Treatment of Undeliverable First-Class Mail](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010331907872)
    - 1.22.5.13.2  [Change of Address (COA)](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010331903904)
    - 1.22.5.13.3  [Handling Undeliverable Mail](https://www.irs.gov/irm/part1/irm_01-022-005#idm140010331900976)

# Part 1. Organization, Finance, and Management

# Chapter 22. Mail and Transportation Management

# Section 5. Mail Operations

* * *

## 1.22.5 Mail Operations

#### Manual Transmittal

December 13, 2024

#### Purpose

(1) This transmits revised IRM 1.22.5, Mail and Transportation Management, Mail Operations.

#### Material Changes

(1) IRM 1.22.5 revised throughout to update organizational title Wage and Investment to Taxpayer Services.

#### Effect on Other Documents

IRM 1.22.5, Mail Operations, dated October 13, 2023 is superseded. This IRM incorporates Interim Guidance IGM WI-01-1022-0004, Formalizing Procedures for Certified Mail, dated October 3, 2022.

#### Audience

IRS Employees

#### Effective Date

(12-13-2024)

Maria Cheeks

Director, Distribution

Taxpayer Services

**1.22.5.1** **(01-14-2021)**

### Program Scope and Objectives

1. Purpose: This section describes IRS Mail Operations and Types of Mailrooms.

2. Audience: Information in this section is for all IRS employees who make Mail and Transportation Management decisions.

3. Policy Owner: The responsibility of administering the IRS Mail and Transportation Management program falls under the direction of the Commissioner, Taxpayer Services (TS).

4. Program Owner: Technology and Program Support (TPS) is the program office responsible for overseeing and providing guidance for the Mail and Transportation Management.

5. Primary Stakeholders:



   - IRS Business Units

   - Technology and Program Support

   - Postal and Transport Policy

   - All employees who use mailing and shipping services or are involved in the process for incoming and outgoing taxpayer correspondence.


**1.22.5.1.1** **(08-13-2018)**

#### Background

1. Mail consists of letters, memoranda, telecommunications, post cards, documents, forms, packages, publications, computer tapes and tax data (returns and remittances).

2. Mail and packages originate from many sources, including:



   - United States Postal Service (USPS)

   - Small package carrier (SPC)

   - Local carrier

   - Freight company


3. Mail and packages should be prepared and shipped based upon the contents, location of origin and location of destination.


**1.22.5.1.2** **(01-14-2021)**

#### Authority

1. [Treas. Reg.§ 301.6212-2(b)](https://www.ecfr.gov/current/title-26/chapter-I/subchapter-F/part-301/subpart-ECFR10a5878a3fd0526/subject-group-ECFR0e115b4049e57e2/section-301.6212-2)

2. Revenue Procedure 2010-16, 2010-1 C.B 664

3. [31 CFR 362, Declaration of Valuables Under the Government Losses in Shipment Act](https://www.ecfr.gov/current/title-31/subtitle-B/chapter-II/subchapter-A/part-362)

4. [39 CFR 310, Enforcement of the Private Express Statues](https://www.ecfr.gov/current/title-39/chapter-I/subchapter-E/part-310)

5. [39 CFR 320, Suspension of the Private Express Statues 41 CFR 102-192. 155, Public Contracts and Property Management Regulations](https://www.ecfr.gov/current/title-39/chapter-I/subchapter-E/part-320?toc=1)


**1.22.5.1.3** **(10-12-2021)**

#### Roles and Responsibilities

1. Taxpayer Services(TS)/Media and Publications (M&P)/Technology and Program Support (TPS) provides guidance and support to the affected stakeholders, including expense verification, adjustments and reconciliation.

2. Postal and Transport Policy (PTP):



1. Develops and evaluates policies, systems, procedures and standards for mail and transportation services

2. Serves as Contracting Officer Representatives (CORs) on Mail and Transportation contracts and Tenders of Service

3. Stewardship of the Private Delivery Service (PDS) application process


3. Facilities Management and Security Services (FMSS)/Office of the Deputy Director Facilities Support/Logistics:



1. Oversees the operation of the Mail Management program.

2. Establishes a Territory Point of Contact (TPOC) who provides mail management program guidance for mailroom operations and mail services within their Territory.

3. Coordinates Servicewide field office mailroom operations and mail delivery services

4. Serves as the COR for the National Mailroom Services Contract, and the National Postal Meter Contract

5. Communicates changes in policy to field offices

6. Provides TPOCs with training and education


4. Business Operating Divisions (BOD) assign Local Points of Contact (LPOC) in IRS Field offices that are not serviced by the Primary Mail Contractor. The LPOC serves as the primary contact for the FMSS Mail Program TPOC.


**1.22.5.1.4** **(01-14-2021)**

#### Program Management and Review

1. Effective use of the Mail Transportation program services requires a coordination of efforts between the PTP Office, FMSS HQ Mail Program Office TPOCs, and field office LPOCs.

2. This IRM describes the different types of mail operations and delivery methods used by the IRS. These descriptions apply to incoming and outgoing mail. The PTP section gauges the effectiveness of the descriptions and their use based on feedback from customers, and program owners. During review and publishing of the IRM, PTP revises, adds, or removes sections based in part on this feedback, as well as USPS policy changes.


**1.22.5.1.5** **(10-13-2023)**

#### Program Controls

1. The following forms and reports are used for control of the program:



   - Form 9814, Request for Mail/Shipping Service

   - Form 10580-A, Postage Purchase/Expenditure Report, is used for the reconciliation of postage meter expenditures

   - USPS Official Mail Accounting System Statement of Usage Report

   - IRS Service Central, formerly OS GetServices, requests


**1.22.5.1.6** **(10-13-2023)**

#### Frequently Used Terms and Acronyms

1. The following charts contain defined terms and acronyms used throughout this IRM:



**Frequently Used Terms and Definitions**






| **Term** | **Definition** |
| --- | --- |
| Accessorial Charges | Extra charges for services offered by carriers to enhance the movement of shipments or freight (i.e. inside delivery, redelivery and reconsignment). |
| Accountable Mail | Mail that requires the signature of the addressee or addressee’s agent upon receipt to supply evidence of delivery and/or for compensation of loss or damage. This applies to both USPS mail and SPC shipments. |
| Mail | Consists of letters, memoranda, post cards, documents, forms packages, publications, computer tapes and tax data (returns and remittances.) |
| National Change of Address (NCOA) | A USPS product that contains permanent Change-of-Address (COA) records and includes the names and addresses of individuals, families, and businesses who have filed a COA. The product enables licensed mailers to process mailing lists and update them with the new addresses before mailing. The official product name is NCOALink. |
| Private Delivery Carriers | Operate under a contract and refers to a company that owns the vehicles used to transport its own goods. |
| Official Mail | Mail is sent by U.S. Government agencies that relates solely to the business of the U.S. Government, authorized by law to be transported in the mail without prepayment of postage. |
| Small Parcel Shipments | Individual packages weighing less than 150 lbs. and shipped in either your own packaging or carrier supplied envelopes or boxes. The total shipment weight, to a single destination, should be more than 13 ounces but less than 750 lbs. |









**Acronyms**






| **Acronym** | **Definition** |
| --- | --- |
| BOD | Business Operating Division |
| COA | Change of Address |
| CAMS | Certified Automated Mailing System |
| CORs | Contracting Officer’s Representatives |
| FMSS | Facilities Management and Security Services |
| HaP | Home as Post of Duty |
| IMDDS | Internal Management Document Distribution System |
| LPOC | Local Point of Contact |
| LSS-ADR | Locator Services System - Address Research |
| M&P | Media and Publications |
| NCOA | National Change of Address |
| OMAS | Official Mail Accounting System |
| PDS | Private Delivery Service |
| PII | Personally Identifiable Information |
| POD | Post of Duty |
| PS | Postal Service |
| PTP | Postal and Transport Policy |
| SBU | Sensitive But Unclassified |
| SPC | Small Package Carrier |
| TS | Taxpayer Services |
| TPS | Technology and Program Support |
| TPOC | Territory Point of Contact |
| UD | Undeliverable |
| UPS | United Parcel Services |
| USPS | United States Postal Service |


**1.22.5.1.7** **(01-14-2021)**

#### Related Resources

1. Related resources include:



   - Revenue Procedure 2010-16, 2010-1 C.B. 664

   - Counsel Advice - Updating Taxpayer Addresses Using Change of Address Labels

   - Executed MOU, Home as Post-of-Duty

   - Interim Guidance on the IRS Future of Work (FOW) Remote Work Project


**1.22.5.2** **(01-14-2021)**

### Mail Operation Relationships

1. This section discusses the relationships between the Technology and Program Support (TPS) of Taxpayer and Services (TS) and IRS representatives in the overall Mail Management Program.

2. The success of the Mail Management Program is dependent on Postal and Transport (PTP) Section employees, Facilities Management and Security Services (FMSS) Analysts, Territory Points of Contact (TPOCs) and field office Mail Program Local Points of Contact (LPOCs).

3. Mailroom operations reside with the Business Operating Division (BOD) in the Submission Processing Center/Campus environments and with FMSS in non-Campus environments. The responsibility for mail operations guidance and direction for all of the IRS resides with FMSS Facilities Support.

4. Centralizing responsibility and supporting an active liaison with the USPS and SPC will ensure the Mail Management Program’s efficiency. TPOCs have the knowledge and familiarity with mail and all the available services, so that the most cost-effective and reliable methods are used.


**1.22.5.3** **(10-12-2021)**

### Definitions of Mailrooms and Mail Operations

1. The mailroom’s physical location is where employees receive, open and distribute mail. It is also the central location where the outgoing mail is processed and consolidated for pickup.

2. There are four main types of IRS mailrooms:



**Mailrooms and Functions**






| **Mailrooms** | **Functions** |
| --- | --- |
| Submission Processing Center/Campus mailrooms | Staffed by IRS employees and provide mail service for the Center/Campus and all locations assigned to the Center/Campus. In this type of mailroom:<br> <br>   - The staff will typically serve multiple buildings<br>     <br>   - USPS mail is prepared using a postage metering system<br>     <br>   - Mail for SPCs will be prepared using **Form 9814, Request for Mail/Shipping Service**. The form is available at: https://publish.no.irs.gov/cat12cgi?request=CAT1&catum=22023<br>     <br>### Note:<br>Open mail addressed to Submission Processing Center/Campus Operations in Receipt and Control or other designated areas before distribution within the building(s). See **IRM 1.22.3.2.1, Unique Zip Code Addresses** at http://irm.web.irs.gov/Part1/Chapter22/Section3/IRM1.22.3.aspx for a listing of addresses served by a Center/Campus mailroom. |
| Contract Mailrooms | Found in field office locations with 250 or more employees and staffed by contractor personnel monitored by FMSS. In this type of mailroom:<br> <br>   - USPS mail is prepared using a postage meter<br>     <br>   - Mail for SPCs will be prepared using **Form 9814, Request for Mail/Shipping Service** |
| Shared Mailrooms | Found in smaller Posts-of-Duty (POD) with 20 - 250 employees. The mailroom is the designated location that serves all IRS occupied space within the building. Mailroom duties are assigned/shared by the occupying IRS business units and are the responsibility of all occupants regardless of grade or position. In this type of mailroom:<br> <br>   - USPS mail is prepared using a postage meter<br>     <br>   - Mail for the SPC will have an electronic shipping label generated through the SPC website. Employees creating their own shipping labels must still be aware of the shipping instructions contained on page 2 of **Form 9814, Request for Mail/Shipping Service.** |
| POD Mailrooms | PODs with less than 20 employees generally will not have an enclosed mailroom. In this type of location:<br> <br>   - USPS mail is prepared using a postage meter or postage stamps.<br>     <br>   - Mail for the SPC will have an electronic shipping label generated through the SPC website. Employees creating their own shipping labels must still be aware of the shipping instructions contained on page 2 of **Form 9814, Request for Mail/Shipping Service.**<br>     <br>### Note:<br>A designated BOD office space may include a mail/copy area. The POD mailroom is the location where delivery and processing of all POD mail occurs. Offices that have a separate mail/copy area will not be assigned an additional postal meter, SPC drop-off or pick-up. |

3. Mail operations and functions include receiving, opening, date stamping, sorting, routing, controlling and following up on delayed mail shipments. The LPOC opens incoming mail according to local procedure and sorts to the extent possible. When there is insufficient information to sort the mail piece, the LPOC or designee contacts the TPOC or local designee to assist in identifying an intended recipient. Mail erroneously delivered to any IRS office with a different address from the IRS location (e.g., addressed to XYZ Corp), should not be opened. Promptly return the misdirected mail to the carrier, whether USPS or SPC and bring to the attention of the LPOC/TPOC.

4. Mandated by the Deputy Commissioner of the IRS in 2001, all mail is to be opened in a centralized mail room or in the official designated mail opening area.


**1.22.5.4** **(01-14-2021)**

### Processing Incoming Mail

1. Opening mail in centralized mail rooms or officially designated mail opening areas provides for the safety and security of all employees.

2. There are several types of incoming mail:



   - USPS Accountable Mail

   - USPS First-Class Mail/Packages

   - SPC Letters and Packages

   - Courier (Messenger) Mail

   - Freight Shipments


### Note:

Each type of mail must be received, counted, logged, and/or sorted.

**1.22.5.4.1** **(01-14-2021)**

#### USPS Accountable Mail

1. USPS delivers Accountable Mail (e.g., Registered, Certified and Return Receipt Mail) to the addressee or the addressee's authorized representative. The employee or mail contractor receiving the mail will verify its receipt by signing and dating the PS (Postal Service) Form 3811, Domestic Return Receipt. A copy of this form will be kept by the mailroom.

2. Upon receipt of the Registered and/or Certified Mail, the receipts attached to the mail piece are removed, date stamped and sent to the Post Office. The envelope is held in the mail area for the addressee or the designee's signature.


**1.22.5.4.2** **(01-14-2021)**

#### USPS First-Class Mail

1. USPS delivery of all First-Class Mail is dependent on the type of delivery route associated with a particular address. USPS delivers to street addresses, Post Office (P.O.) Boxes, cluster mailboxes, door slots, or wall mounted centralized mailboxes.


**1.22.5.4.3** **(10-12-2021)**

#### Small Package Carrier (SPC) Letters and Packages

1. SPC deliveries are accountable mail. The SPC will deliver incoming packages and letters to the POD mailroom. The employee or mail contractor will verify receipt of the letters and/or packages by signing the SPC delivery pad. Employees should not accept letters and/or packages from a SPC without signing for receipt of delivery.


**1.22.5.4.4** **(01-14-2021)**

#### Courier (Messenger) Mail

1. Courier deliveries are accountable mail and require a signature by the employee who verifies and receives the delivery.


**1.22.5.4.5** **(01-14-2021)**

#### Freight Shipments

1. Shipments made via a freight carrier are more controlled. If building security permits, the shipment may be delivered directly to the individual floor/room/suite as an "inside delivery." The driver will drop the shipment at the dock or inside the first door if there is no "inside delivery" .


**1.22.5.5** **(10-12-2021)**

### Postage Due Mail/Collect On Delivery

1. "Postage Due" or "Collect on Delivery" mail will be refused when a carrier tries to deliver such mail. The carrier will endorse the mail item returned for additional postage and return the mail item to the sender.

2. If an IRS office receives mail from another IRS office with postage due, the mail will be accepted and any postage due must be paid through an Official Mail Accounting System (OMAS) postage due account.


**1.22.5.6** **(01-14-2021)**

### Form 3210, Document Transmittal

1. All mail accompanied by a Form 3210, Document Transmittal, will be received and forwarded to the recipient. The recipient will check the contents against the transmittal document, verify and sign/date the form.

2. The recipient will return a signed acknowledgement copy of the transmittal to the sending office via EEFax or scan/email.


**1.22.5.7** **(01-14-2021)**

### Remittance Mail

1. Remittance mail should be forwarded in accordance with established Business Operating Division (BOD) procedures.


**1.22.5.8** **(10-12-2021)**

### Handling Personal Mail

1. The personal use of mail products and/or services by IRS employees is _not_ allowed.



1. Personal use includes the mailing of job applications, resumes or similar material that do not meet the definition of Official Mail.



      ### Note:



      Official Mail is mail sent by agencies of the U.S. Government and contains matter related exclusively to the business of the United States that is authorized by law to be transmitted in the mail without the prepayment of postage.

2. A Government travel card bill is a personal matter and Government funds cannot be used to mail such payment.

3. Personal mail is not allowed to be sent or received by IRS mailrooms.

4. For further information, go to:


> - Handling Personal Mail intranet page,
>
>    - [41 CFR 102-192, Mail Management](https://www.ecfr.gov/current/title-41/subtitle-C/chapter-102/subchapter-G/part-102-192)
>
>    - Document 12011, Internal Revenue Ethics Handbook

**1.22.5.9** **(01-14-2021)**

### Consolidating Mail

1. Sort and consolidate multiple pieces of mail sent to one address into a suitable envelope or package and ship using one of the following methods:



1. SPC ground for such items as large envelopes and/or packages containing individual letters, forms, books, reports, manuals, newsletters, flyers, or printed products

2. Delivery for packages that only include remittances and payments


2. Place the term ‘Consolidated Shipment’ on the address label when sending a consolidated shipment.


**1.22.5.9.1** **(01-14-2021)**

#### Opening Internal Management Documents Distribution System (IMDDS)/Consolidated Mail

1. The IMDDS is a method used to distribute IRMs and other miscellaneous products directly to an IRS office.

2. IMDDS consolidates all products delivered to an IRS office.



1. Shipments will come consolidated in a box(es) addressed to the building if a product is to be distributed to multiple order points

2. IMDDS shipments are recognizable by the name "IMDDS Coordinator" in the return address

3. The box(es) are opened in the designated mail opening location and the inner contents will be distributed, as labeled, to the individual(s) or group(s)


3. Consolidated mail is much like IMDDS shipments but is limited to receipt by larger locations.



1. A consolidated mail shipment will contain several envelopes/packages addressed to locations throughout the building(s)

2. A consolidated mail shipment contains "Consolidated Shipment" in the address line

3. A consolidated mail shipment opened in the designated mail opening location and the inner contents distributed, as labeled, to the individual(s) or group(s)


**1.22.5.10** **(10-12-2021)**

### Acceptable Mail/Shipping Services

1. When possible, documents and correspondence should be sent via EEFax or scanned and transmitted via secure email to eliminate agency shipping/mailing cost.

2. The USPS is the primary carrier for official correspondence and packages going to taxpayers. The Private Express Statutes gives the USPS the exclusive right to carry letters for compensation, with certain limited exceptions.

3. Correspondence and packages shipped between IRS offices and _containing processed remittances_ will use the following shipping guidelines as defined in the instructions for Form 9814, Request for Mailing/Shipping Services.



1. Thirteen ounces or less will be shipped via USPS

2. More than 13 ounces will be sent using a SPC ground service

3. If shipping more than 25 boxes or over 750 pounds to one destination, freight options must be considered to determine the most cost-effective method.


4. Complete the following to determine the most cost-effective method:



1. Fill out Form 14680, Freight Services Request.

2. Click ‘Submit Form by Email’ option on the top right corner of the form


5. SPC air shipping services will be used by exception only such as:



1. Packages that include unprocessed remittances and payments

2. Documents, forms or correspondence on imminent statute cases within 30 calendar days of statute expiration date

3. Tax court cases scheduled for trial within 15 calendar days


### Note:

Items such as personnel ranking packages and training material should always use ground services.

**1.22.5.11** **(01-14-2021)**

### Guidance on Telework Employee Mail

1. Due to security concerns, employees teleworking must never receive correspondence directly from taxpayers at their residence.

2. Employees on Telework schedule who regularly report to their POD at least once a week will receive mail and packages at their POD.

3. Employees on Telework should plan to send mail and packages on the days they report to their regular POD or another IRS location. If the mailing cannot wait until the employee is in the office, the employee must deposit the mail or package in a secure carrier receptacle (e.g., drop box) or at an authorized shipping outlet.



### Caution:



Security and disclosure concerns prohibit the mailing of official correspondence from an employee’s residential mailbox.


**1.22.5.11.1** **(10-12-2021)**

#### Home as Post-Of-Duty (HaP) Employees

1. Employer and Employees responsibilities for Incoming Mail



**Incoming Mail Responsibilities**






| **Employer** | **Employees** |
| --- | --- |
| IRS will determine the administrative address where the receipt and processing of an employee’s mail occurs. Once received, the employer will determine the most effective and efficient means to forward the mail to the employee, including but not limited to secure email, eFax, SharePoint, or private delivery carrier. | Employees must follow all current IRS requirements regarding mail and the protection of sensitive information. |
| The Employer will send mail to the employee’s home that includes Personally Identifiable Information (PII) and /or Sensitive but Unclassified (SBU) information by a private delivery carrier with delivery confirmation-signature required at the home. | For purposes of receiving mail from outside the IRS, employees in the HaP program will not use their home address as their mailing address. IRS will provide employees with an IRS administrative address where all mail addressed to the employee will be handled. |
|  | Employees are prohibited from signing a release that permits private delivery carriers to leave PII and/or SBU shipments unattended on a porch, doorstep, or other location outside the home. |
|  | Employees have access to the private delivery carrier service, such as United Parcel Service (UPS) My Choice which enables monitoring of package delivery. Employees will be required to sign-up for the service to receive pre-delivery notification of incoming packages. |

2. For Outgoing Mail:



1. When employees must send outgoing correspondence, they may use email if such usage is appropriate, and in accordance with IRM 1.10.3, Standard for Using Email, which prohibits including taxpayer, PII, and/or SBU information in emails without the use of encryption.

2. The employees must send all taxpayer correspondence via USPS. Employees will use existing office procedures to procure postage stamps for mailing. The administrative office address assigned to the employee must be used as the return address for outgoing mail. The mail must be hand-delivered to a USPS carrier, deposited in a secure receptacle, or hand delivered to a clerk at a USPS walk-in counter.

3. Use a private delivery carrier such as UPS when shipping to an IRS administrative address or another federal/state agency. To generate shipping labels electronically on the designated private delivery carrier’s website, employees must register with the IRS Postal and Transport Policy Section by submitting an IRS Service Central, formerly OS GetServices, request. Deliver outgoing packages to a UPS store or deposit in a secure UPS drop box. The employee must obtain pre-approval from their supervisor and the IRS Postal and Transport section to schedule private delivery carrier residential pick ups.

4. Employees may not leave mail or packages unsecured on a porch, doorstep, or other location outside their home.


**1.22.5.11.2** **(10-13-2023)**

#### Remote Work Employees

1. As defined in the Interim Guidance on the IRS Future of Work (FOW) Remote Work Project, employee mail responsibilities are:



1. Employees are prohibited from sending or using their home address as a mailing or return address for official mail to or from non-IRS sources. When mailing to non-IRS sources, employees must use an IRS office address as the return address.

2. Official mail from external (non-IRS) sources must be routed through an IRS office, prior to forwarding it to the official \[remote\] worksite. Exception: Office supplies or equipment originating external to IRS (for example, Office Depot) and ordered by the office credit card holder may be mailed directly to the participant’s official worksite. By signing the RWA, Project participants acknowledge written consent to use the personal address for this purpose.

3. The United States Postal Service (USPS) is the primary carrier for all correspondence between the IRS and the public. See IRM 1.22.2 - United States Postal Service (USPS) Classes of Mail, USPS Additional Services and Small Package Carrier (SPC) Services.

4. Outgoing mail must be transported to an IRS facility, be deposited in a secure USPS receptacle or hand-delivered to a clerk at a USPS walk-in counter.

5. See IRM 1.22.5, Mail and Transportation, Mail Operations, and IRM 10.5.1, Privacy Policy, for shipping procedures for personally identifiable information.


**1.22.5.12** **(10-13-2023)**

### Processing Outgoing Mail

1. Include a mail delivery code (e.g., mail stop, office symbols and/or room number) in the return address of any envelope or label on all outgoing mail to identify the sending office in the event the item is returned.

2. All outgoing mail is to be taken to the mailroom to be sorted, consolidated, packaged as necessary and postage applied for mailing or shipping by the USPS or other authorized carrier.

3. Employees teleworking should plan to send mail on the days they report to their regular POD or another IRS location. If the mail cannot wait until the employee is in the office, the employee must deposit the mail or package in a secure carrier receptacle (e.g., drop box) or at an authorized shipping outlet.



### Note:



Security and disclosure concerns prohibit the mailing of official correspondence from an employee's residential mailbox.

4. USPS Certified Mail and Certified Mail Return Receipt Mail must be sent using the Certified Automated Mailing System (CAMS). To gain access to CAMS, employees must register with the IRS Postal and Transport Policy Section by submitting an IRS Service Central, formerly OS GetServices, request. CAMS allows users to print labels and track Certified Mail and Certified Mail Return Receipts supporting letter size envelopes and flat (large) envelopes from desktops. Using CAMS will allow employees to:



   - Print USPS compliant Certified Mail Barcodes.

   - Print summary manifest list acceptable to USPS as Proof of Mailing.

   - Upload a hard-copy USPS stamped manifest (PS Form 3877 equivalent/automate USPS Firm Mailing Book) and be associated to job type and/or mail piece ID.

   - View images of Certified Mail and Return Receipt records up to 10 years or delivery and signature status. The image must clearly show the name, address of the intended receipt and all signatures.


**1.22.5.13** **(01-14-2021)**

### Undeliverable (UD) Mail and Address Updates

1. Undeliverable (UD) mail is any IRS outgoing mail piece that the USPS cannot deliver to a specified, domestic address or to a valid forwarding address.

2. Foreign postal services are not obligated to return mail if it cannot be delivered within their areas of delivery.

3. Reasons for non-delivery may include:



1. Incomplete, illegible, or incorrect address

2. Forwarding order expired

3. Addressee is not at address (unknown, moved, or deceased)

4. Attempted not known, unable to forward

5. Not deliverable as addressed - return to sender

6. Box closed unable to forward


**1.22.5.13.1** **(01-14-2021)**

#### Treatment of Undeliverable First-Class Mail

1. USPS only provides mail forwarding orders for a period of 12 months, after which time the order will expire. For six months immediately following expiration, mail sent to the taxpayer at the old address will be returned to the sender with a yellow label showing the new address, and the reason for non-delivery.

2. USPS sends all UD First Class Mail to the IRS return address on the mail piece unless IRS indicates the mail piece may be securely destroyed.

3. The address on the yellow label is the taxpayer’s current address of record in the USPS system.

4. The taxpayer provided the USPS with a Change of Address (COA) that differs from the address used by the IRS.

5. Foreign postal services do not notify a mailer that a change in address has occurred.


**1.22.5.13.2** **(01-14-2021)**

#### Change of Address (COA)

1. IRS and USPS each have their own COA processes with safeguards to prevent identity theft and misuse of address information. As a result, address data on individuals between the two may differ. An address may be changed by information received from the United States Postal Service, National Change of Address database (NCOA database). As provided in Treas. Reg.§ 301.6212-2(b)(2), an address obtained from the NCOA database becomes the taxpayer's last known address unless the taxpayer provides clear and concise notification of a change of address (as set out in Rev. Proc. 2010–16) or the Service properly processes a taxpayer's federal income tax return with a different address.


**1.22.5.13.3** **(10-12-2021)**

#### Handling Undeliverable Mail

1. Upon receipt of any UD mail piece with an affixed USPS Yellow Label, an IRS office should examine and appropriately research, as follows:



1. If the taxpayer’s name printed in the letter and what is shown on the “Yellow Label” are exactly the same, update the taxpayer address to the “Yellow Label” address.

2. If the taxpayer’s mailing address differs from the “Yellow Label” and the name printed on the “Yellow Label” is an exact match to the correspondence, update the taxpayer’s mailing address to the “Yellow Label” address. Reissue the correspondence to the taxpayer’s updated mailing address.

3. If the taxpayer first name is like that on the “Yellow Label”, but the last name is an exact match, confirm whether IRS records show any other taxpayers with similar first names and the exact same last name at the same address. If not, update the taxpayer address. Otherwise, do not update the taxpayer address.

4. In all other cases do not update the taxpayer address.


2. Where the business unit requires further efforts to obtain a current address, actions may be initiated that include, but are not limited to:



   - Using the Locator Services System - Address Research (LSS-ADR) to issue Letter 2797, We Need Your Assistance in Updating Your Address Information, commonly known as “R U There?” to obtain the taxpayer’s current mailing address, if applicable, or

   - Preparing/issuing IDRS Letter 2788C, Undeliverable Mail - New Address Verification to request verification and provide the appropriate change of address form. Include a copy of the appropriate Form 8822, Change of Address, when returning correspondence.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-022-005#addtoany "Show all")

A2A