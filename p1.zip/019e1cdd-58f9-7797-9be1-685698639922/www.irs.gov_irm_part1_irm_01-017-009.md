---
url: "https://www.irs.gov/irm/part1/irm_01-017-009"
title: "1.17.9 User Guide for Requesting Published Products and Services | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-017-009#main-content)

- 1.17.9  [User Guide for Requesting Published Products and Services](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993644764224)
  - 1.17.9.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612092288)
    - 1.17.9.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993616199728)
    - 1.17.9.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993616197504)
    - 1.17.9.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612262464)
    - 1.17.9.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612123440)
    - 1.17.9.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612016608)
    - 1.17.9.1.6  [Terms/Definitions/Acronyms](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993611991280)
    - 1.17.9.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612225952)
  - 1.17.9.2  [Interim Procedures: Creating/Revising Non-Tax Forms with Social Security Numbers (SSNs) or Taxpayer Identification Numbers (TINs)](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993616177552)
  - 1.17.9.3  [Services Offered by Publishing](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612233488)
    - 1.17.9.3.1  [Product Consultation and Planning](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612227856)
    - 1.17.9.3.2  [Graphic Design Services](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612014288)
    - 1.17.9.3.3  [Composition of Tax Products](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612009984)
    - 1.17.9.3.4  [Composition of Internal and Non-Tax Public Use Forms](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612186496)
    - 1.17.9.3.5  [Procurement of All Published Products](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612161824)
    - 1.17.9.3.6  [Distribution of Published Products to an Audience](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612157760)
      - 1.17.9.3.6.1  [Email Subscriptions](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612003072)
    - 1.17.9.3.7  [Posting Products to the Internet and Intranet](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612000256)
      - 1.17.9.3.7.1  [Posting Files to IRS.gov](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993616210240)
    - 1.17.9.3.8  [Production/Cost Tracking of All Published Products](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993616186032)
    - 1.17.9.3.9  [Obtaining Photocopying](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993616182848)
    - 1.17.9.3.10  [Language Translation Services](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612106080)
      - 1.17.9.3.10.1  [Requesting Product Translations](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612102448)
  - 1.17.9.4  [Products Offered by Publishing](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612096400)
  - 1.17.9.5  [When to Contact Publishing](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612114960)
  - 1.17.9.6  [Importance of Standards and Submitting a Publishing Services Request](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612174576)
    - 1.17.9.6.1  [Submitting a Form 1767 for Publishing Services](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612257984)
    - 1.17.9.6.2  [PSR Submission Flow](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612254192)
    - 1.17.9.6.3  [Timeframes to Design, Print, and Distribute a Published Product](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612247792)
  - 1.17.9.7  [Roles and Responsibilities When Publishing a Product](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612241584)
    - 1.17.9.7.1  [Publishing's Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612239248)
      - 1.17.9.7.1.1  [Officially Published Products](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612236592)
      - 1.17.9.7.1.2  [Production Sources](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993644183888)
      - 1.17.9.7.1.3  [Version Control](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993644178608)
      - 1.17.9.7.1.4  [Online Catalog Page](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993644176384)
    - 1.17.9.7.2  [Responsibilities of Product Content Owners/Originators](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993644171856)
      - 1.17.9.7.2.1  [Reprinting Existing Published Products](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993644165360)
      - 1.17.9.7.2.2  [Revising Existing Published Products](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993644162816)
      - 1.17.9.7.2.3  [Obsoleting Published Products](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993644158192)
      - 1.17.9.7.2.4  [Submitting Justification to Post Public-Use Non-Tax Products to IRS.gov](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993644152368)
      - 1.17.9.7.2.5  [Section 508 Compliance](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993644147600)
    - 1.17.9.7.3  [Responsibilities of Executive Heads of Office](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993644136880)
  - 1.17.9.8  [Special Publishing Circumstances](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993644129392)
    - 1.17.9.8.1  [OMB Numbers for Public Use Forms](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993644124400)
    - 1.17.9.8.2  [Paperwork Reduction Act (PRA) Notice](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612066608)
    - 1.17.9.8.3  [Privacy Act](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612064688)
  - 1.17.9.9  [Color Copier Purchases](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612061856)
    - 1.17.9.9.1  [Requesting High-Speed, Color-Copier Duplicators or Specialty Copiers](https://www.irs.gov/irm/part1/irm_01-017-009#idm139993612059792)

# Part 1. Organization, Finance, and Management

# Chapter 17. Publishing

# Section 9. User Guide for Requesting Published Products and Services

* * *

## 1.17.9 User Guide for Requesting Published Products and Services

#### Manual Transmittal

June 20, 2025

#### Purpose

(1) This transmits revised IRM 1.17.9, _Publishing, User Guide for Requesting Published Products and Services_.

#### Material Changes

(1) IRM 1.17.9.1, _Program Scope and Objectives_ \- Added Internal Controls content.

(2) IRM 1.17.9.1.1, _Authority_ \- Inserted content to describe authority for this IRM section. Renumbered all subsequent subsections of this IRM to align numerically after adding the new IRM 1.17.9.1 and IRM 1.17.9.1.1.

(3) IRM 1.17.9.2, _Interim Procedures: Creating/Revising Non-Tax Forms with Social Security Numbers (SSNs) or Taxpayer Identification Numbers (TINs)_ \- Added content to incorporate Interim Guidance PGLD 10-1123-0006, New Procedures for Creating and Revising IRS Products that Contain Social Security Numbers (SSNs) and/or Tax Identification Numbers (TINs).

(4) IRM 1.17.9.3, _Services Offered by Publishing_ – Clarified that Publishing works through the Linguistic Policy, Tools and Services Section of the Tax Forms & Publications function to translate products.

(5) IRM 1.17.9.3.10, _Language Translation Services_ – Added a note that informs product owners that all non-English language products must have an English language version.

(6) IRM 1.17.9.3.10.1, _Requesting Product Translations_ \- Added and expanded language from previous IRM 1.17.8.4.2.6, _Letter Language Translations_, that now outlines who determines if a product is needed in non-English languages; how to request translation services; a reference to IRM 22.31.1, _Multilingual Initiatives, IRS Language Services_; a list of languages that Media & Publications supports; and what to do if a needed language isn’t on that list.

(7) IRM 1.17.9.5(4), _Importance of Standards and Submitting a Publishing Services Request_ – Renumbered to IRM 1.17.9.6(4) and replaced Figure 1.17.9-2, Publishing Services Request Online Form, with a new graphic that includes the “Translation Service” check box.

(8) IRM 1.17.9.5(5), _Importance of Standards and Submitting a Publishing Services Request_ \- Renumbered to IRM 1.17.9.6(5) and added language to the “Translation Services” bullet in the list of PSR fields that explains that the check box only appears with certain “Product Types” and what additional paperwork is needed to request translation services.

(9) IRM 1.17.9.5.3(5), _Timeframes to Design, Print, and Distribute a Published Product_ – Renumbered to IRM 1.17.9.6.3(5) and added a reference to IRM 22.31.1, _Multilingual Initiatives, IRS Language Services_, so product requesters factor the timeframe for translation into their expected schedule.

(10) IRM 1.17.9.5.3(6), _Timeframes to Design, Print, and Distribute a Published Product_ – Renumbered to IRM 117.9.6.3(6) after adding IRM 1.17.9.1 and IRM 1.17.9.2 and new content for IRM 1.17.9.6.3(5).

(11) IRM 1.17.9.6.2.2(2), _Revising Existing Products_ – Renamed to “Revising Existing Published Products” and renumbered to IRM 1.17.9.7.2.2(2). Also added a note to remind product owners that if they revise their English-language product, they must also revise the non-English language version(s) of that product.

(12) IRM 1.17.9.6.2.3(2), _Obsoleting Published Products_ – Renumbered to IRM 1.17.9.7.2.3(2) and added a note to remind product owners that if they obsolete their English language product, they must also obsolete the non-English language version(s) of that product.

(13) IRM 1.17.9.7.1, _OMB Numbers for Public Use Forms_ – Renumbered to IRM 1.17.9.8.1 and updated the table to remind originators to take the same actions with their English-language and non-English language product(s).

(14) Made updates to reflect accurate links and email addresses throughout.

(15) Confirmed that "accessibility" in the text refers to either Section 508 or generic access and not to executive orders related to DEI.

#### Effect on Other Documents

Supersedes IRM 1.17.9, _Publishing, User Guide for Requesting Published Products and Services_ dated August 10, 2023. This IRM incorporates Interim Guidance Memorandum PGLD 10-1123-0006, New Procedures for Creating and Revising IRS Products that Contain Social Security Numbers (SSNs) and/or Tax Identification Numbers (TINs), dated November 15, 2023.

#### Audience

All IRS employees, contractors, and vendors who design, publish, or distribute electronic products for internal or external audiences.

#### Effective Date

(06-20-2025)

William A. Moses

Director, Publishing

Media & Publications Division

**1.17.9.1** **(06-20-2025)**

### Program Scope and Objectives

1. **Purpose.** This section provides overview information to Publishing's customers on the services and products that Publishing offers, how to submit a request for service, and special considerations for publishing products. Publishing's established systems are a one-stop location the agency can use to save time, money, and resources when obtaining published products.

2. **Audience.**The audience for this IRM is IRS employees Servicewide.

3. **Policy Owner.** The Director of Publishing owns the policies contained herein.

4. **Program Owner.** Taxpayer Services, Customer Assistance Relationships and Education, Media & Publications, Publishing is responsible for the administration, procedures, and updates related to the program.

5. **Primary Stakeholders.** Tax Forms & Publications in Media & Publications, CARE, Taxpayer Services; Chief Financial Officer of the IRS; Distribution in Media & Publications, CARE, Taxpayer Services; IRS organizations servicewide.

6. **Contact Information.** The Director of Publishing in Media & Publications in CARE, Taxpayer Services.


**1.17.9.1.1** **(06-20-2025)**

#### Background

1. Publishing’s mission is to plan and produce or procure all IRS print and electronic communications products used by the public to comply with tax filing requirements and obligations and used internally within the IRS for tax administration. The Publishing function (also known as "Publishing" ) under Media & Publications (M&P) within Taxpayer Services develops and delivers published products in electronic, paper, and other alternative formats for internal (employees) and external (taxpayers) use.


**1.17.9.1.2** **(06-20-2025)**

#### Authority

1. Publishing's authority as the official IRS Publisher is documented in IRM 1.17.1, _Publishing - Overview of Publishing Authorities, Roles and Responsibilities, and Organizational Structure_.


**1.17.9.1.3** **(06-20-2025)**

#### Roles and Responsibilities

1. The roles and responsibilities of all publishing processes' stakeholders is outlined in IRM 1.17.1, _Publishing - Overview of Publishing Authorities, Roles and Responsibilities, and Organizational Structure_, and _IRM 1.17.9.6_, _Roles and Responsibilities when Publishing a Product_.


**1.17.9.1.4** **(06-20-2025)**

#### Program Management and Review

1. **Program Reports.** Balanced measures for tax and non-tax products.

2. **Program Effectiveness.** The Computer Assisted Publishing System (CAPS) has reporting capabilities that enable management and employees to monitor and track delivery of Publishing products and services.


**1.17.9.1.5** **(06-20-2025)**

#### Program Controls

1. The Computer Assisted Publishing System (CAPS) has reporting capabilities that enable management and employees to monitor and track delivery of Publishing products and services.


**1.17.9.1.6** **(06-20-2025)**

#### Terms/Definitions/Acronyms

1. This IRM section uses the following terms and acronyms to describe the involved processes and resources.



**Defined Terms**






| Term | Definition |
| --- | --- |
| Form | A product with spaces to store information. |
| Product | An item produced for any audience that requires cataloging and revision control to ensure proper usage and context of IRS published content. |
| Publish | Most products intended to be read by persons outside of the IRS. |
| Service | Something done on behalf of others. |







**Acronyms**






| Acronym | Definition |
| --- | --- |
| ATG | Audit Techniques Guides |
| BOD | Business Operating Division |
| C&L | Communications & Liaison |
| CAPS | Computer Assisted Publishing System |
| CMS | Content Management System |
| CROPP | Core Repository of Published Products |
| ESN | Electronic Status Notice |
| GPO | Government Publishing Office |
| GSA | General Services Administration |
| HTML | Hyper-text mark-up language |
| LPTS | Linguistic Policy, Tools and Services |
| NDC | National Distribution Center |
| OLS | Online Services |
| PDF | Portable Document File |
| PRA | Paperwork Reduction Act |
| PSD | Publishing Services Data System |
| PSR | Publishing Service Request |
| TAC | Taxpayer Assistance Center |
| TIN | Taxpayer Identification Number |
| WCMS | Web Content Management System |


**1.17.9.1.7** **(06-20-2025)**

#### Related Resources

1. Document 12687, _Getting Your Information Published at the IRS_

2. Document 12616, _Design Guidelines for IRS Internal and Non-Tax Public Use Forms_

3. IRM 1.17.7, _Use of the Official IRS Seal, IRS Logo, Program Logos and Internal Logos_

4. IRM 1.17.1, _Publishing, Overview of Publishing Authorities, Roles and Responsibilities, and Organizational Structure_

5. IRM 22.31.1, _Multilingual Initiatives, IRS Language Services_

6. IRM 1.17.2, _Publishing - Publishing Systems and Programs_

7. IRM 1.17.3, _Publishing - Tax Products Program_

8. IRM 1.17.10, _Publishing - IRS Published Product Identification_


**1.17.9.2** **(06-20-2025)**

### Interim Procedures: Creating/Revising Non-Tax Forms with Social Security Numbers (SSNs) or Taxpayer Identification Numbers (TINs)

1. Publishing’s Non-Tax Forms staff will not process a Publishing Services Request (PSR) for new forms containing SSNs, or revised forms where a change to a TIN field was made, until verification of a signed Form 14132, _Social Security Number Retention Justification for Forms, Letters, Notices, and Systems_, is provided. To get verification, the product originator in the business operating division must complete the following prior to submitting a PSR:



   - Send the most recent revision of Form 14132 via email to Privacy, Governmental Liaison and Disclosure (PGLD) at the PGLD website to request signed approval. Electronically attach the signed Form 14132 to the PSR.

   - This interim guidance is effective until November 14, 2025, or until this IRM topic is revised, whichever is sooner.


**1.17.9.3** **(06-20-2025)**

### Services Offered by Publishing

1. Publishing employees offer innovative solutions to meet the IRS business needs of all stakeholders through the following services:



   - Product Consultation and Planning

   - Graphic Design Services

   - Composition of Tax Products

   - Composition of Internal and Non-tax Public Use Forms

   - Procurement of Published Products

   - Distribution of Published Products to General and Specific Audiences

   - Posting Products to the Intranet and Internet

   - Production/Cost Tracking of All Published Products

   - Photocopying

   - Language Translation Services through the Linguistic Policy, Tools and Services Section of the Tax Forms & Publications function


**1.17.9.3.1** **(02-19-2013)**

#### Product Consultation and Planning

1. Customers needing assistance with planning a product or campaign of any size can consult with Publishing about where to start the process, production schedules and cost estimates, or other related matters. The M&P Publishing’s publishing specialists are the best points of contact to provide analysis, advice, consultation, and education on technical publishing issues; including reviewing post-production impact/problems, problem-solving, promoting products and services, and information-sharing. Locate your assigned publishing specialist on the IRS Intranet at the Publishing intranet site.


**1.17.9.3.2** **(07-29-2020)**

#### Graphic Design Services

1. Publishing’s visual information specialists create the visual presentation of text and/or artwork to reflect the IRS mission and key messages. This includes developing, designing, and delivering final graphic design of products. Products created by Publishing’s visual information specialists will automatically comply with IRM 1.17.7, _Use of the Official IRS Seal, IRS Logo, Program Logos and Internal Logos_, as well as any IRS design standards.

2. M&P has the right to incorporate all required elements for IRS Design Standards compliance on all products submitted to Publishing or commercial design vendors.

3. Only an approved visual information specialist can apply or alter such design elements to products or provide such design elements to outside vendors. Information about graphic design services is posted at: the Design Services page on the Publishing website.


**1.17.9.3.3** **(08-21-2018)**

#### Composition of Tax Products

1. Publishing provides electronic text and page layout composition services to support the creation and revision of major tax products (e.g., forms, instructions, publications, and notices). Tax law specialists in M&P’s Tax Forms & Publications (TF&P) division issue these tax products as product content owners/originators on behalf of specific IRS business units. The Electronic Composition section of Publishing provides the layout and composition services.

2. The Electronic Composition section of Publishing does not provide composition services for any product not assigned to a tax law specialist from TF&P as the product content owners/originators. Rather, an outside vendor, or direct sources available within Publishing based on the characteristics of the product, will provide the composition services to create products not originating in TF&P.

3. Composition costs to create or update products not assigned to an M&P tax law specialist as the product content owners/originators are charged and requested using the Publishing Services Request (PSR) posted to the intranet at the Publishing webpage. For non-electronic production and distribution, the product content owners/originators may need to provide another PSR to procure the services. See IRM 1.17.9.5, _Importance of Standards and Submitting a Publishing Services Request_, for PSR instructions.


**1.17.9.3.4** **(10-15-2015)**

#### Composition of Internal and Non-Tax Public Use Forms

1. Publishing provides composition, user functionality, and Section 508 accessibility services to support creation and revision of Internal and Non-Tax Public Use Forms. See IRM 1.17.8.5.1.3.1, _Public-Use Forms,_ for more information on public use form types other than tax forms. The Publishing Services branch provides this service but does not provide services for tax forms or other forms that the Electronic Composition section designs/creates.

2. Customers can use the PSR application to request services needed to create or update forms. These services follow the design guidelines set forth by Document 12616, _Design Guidelines for IRS Internal and Non-Tax Public Use Forms_.

3. User-functionality includes scripting/programing added to the form that allows the form to meet user needs. Publishing adds functionality to forms upon request of the form owner or as a recommendation of the form designer. Samples of functionality include:



   - Validating data entered into a field

   - Expanding fields to fit data entered

   - Adding/deleting rows in a table

   - Hiding/showing information based on a selection

   - Auto populating fields based on data entered/selected


**1.17.9.3.5** **(02-19-2013)**

#### Procurement of All Published Products

1. Publishing is mandated to procure published products and related services through the Government Publishing Office (GPO).

2. The GPO helps the IRS with securing printing and publishing by obtaining the best price possible using the best vendors within the printing and publishing industries and within the GPO. The results are lower pricing and faster delivery times.

3. The GPO provides a fair, open, competitive bidding process on all procurements managed on behalf of the IRS.

4. The GPO manages contracts that cover a broad spectrum of printing and publishing services and are available to fit most any IRS publishing request (regardless of quantity and scope of service), with most procurements obtained through the private sector.

5. The volume of printing and publishing the federal government requires allows the GPO to obtain lower pricing than what is currently available to the public.


**1.17.9.3.6** **(08-21-2018)**

#### Distribution of Published Products to an Audience

1. Publishing can distribute published products in the following ways:



   - Customers can supply names and addresses, preferably from an Excel spreadsheet;

   - Publishing can assist in the creation of a customized distribution list that includes multiple IRS offices or areas;

   - Products available for distribution to all IRS employees can be warehoused and ordered from the National Distribution Center (NDC); and/or

   - We can publish products electronically through the Intranet/Internet.


2. In addition, Communications & Liaison (C&L) can help develop a communication strategy when published products need to reach an external audience or have Servicewide impact. C&L helps to ensure that a product:



   - Is aligned with key IRS messages;

   - Reaches the intended audience; and

   - Is clear and effective.


3. Consult either a publishing specialist at Find a publishing specialist on the Publishing website, or Document 12687, _Getting Your Information Published at the IRS_, posted online at the Publishing catalog page for further instructions on establishing an audience.


**1.17.9.3.6.1** **(02-19-2013)**

##### Email Subscriptions

1. Publishing can coordinate with Distribution to automatically add products to available subscriptions systems that can show in the catalog system when we add or revise a product. This subscription method allows the product content owners/originators the option to do full interagency or external stakeholder distributions immediately after producing a product. Requestors subscribe to an email system to request a product and to receive notification when new products are available.

2. In addition, Publishing provides a notification system that will inform a user when a new electronic revision of a product is available as soon as it is released into the Publishing catalog system. This notification provides the user with the most current version to download from the Publishing catalog system at the Publishing catalog page.


**1.17.9.3.7** **(08-10-2023)**

#### Posting Products to the Internet and Intranet

1. Publishing posts and catalogs finished internal products in the Core Repository of Published Products (CROPP), which makes them electronically accessible from the Publishing Catalog.

2. Publishing posts and catalogs finished external products in the CROPP and the Content Management System (CMS), which makes them electronically accessible from both the Publishing Catalog and [the IRS website](https://www.irs.gov/irm/part1/www.irs.gov.).

3. Publishing must approve public use non-tax products prior to posting them to [the IRS website](https://www.irs.gov/irm/part1/www.irs.gov.). See _IRM 1.17.9.3.7.1_, _Posting Files to IRS.gov_, below for the approval process.

4. Posted products are available for use and accessible from the Publishing Catalog within 24 to 72 hours of a publishing specialist posting and updating the catalog information.

5. IRS Web page content managers should link to finished products in the CROPP. Instructions for creating the link are posted at the CROPP page on the Publishing website.

6. Any product posted to the CROPP should be compliant with Section 508 of the Rehabilitation Act.


**1.17.9.3.7.1** **(08-21-2018)**

##### Posting Files to IRS.gov

1. Online Services (OLS) and Publishing work together to post files on IRS.gov. Such files are referred to as “static files.” This collaboration and oversight enables the Service to maintain greater consistency of all posted products by to ensure that:



   - The number and type of files and content posted on IRS.gov are managed effectively, reducing outdated and duplicative content;

   - We consolidate and manage posting requests solely between OLS, Publishing, and the Business/Functional Representatives; and

   - All employees understand the process for posting official static files versus miscellaneous static files.


2. There are four primary stakeholders involved in posting files to IRS.gov:



   - Product Content Owners/Originators – Produce content and ensure that such content meets the criteria for posting either by Publishing or OLS.

   - Business/Functional Coordinators – Review files for their respective business operating divisions (BODs) and guide product content owners/originators about whether to post new requests via Publishing or OLS.

   - Publishing – Publishing Specialists and Visual Information Specialists develop and post official cataloged products per IRM 1.17.1, _Publishing, Overview of Publishing Authorities, Roles and Responsibilities, and Organizational Structure_. Product content owners/originators submit a Publishing Services Request (PSR) to develop and publish a product.

   - Online Services – Webmasters post miscellaneous static files to IRS.gov.


3. When we develop a file with the intent of posting it to IRS.gov, consider the following: Should it be an official static file - that is, a catalogued, numbered product used by the public. See **IRM 1.17.8.3** _**Submitting Products to Publishing**_ for guidelines. If the answer is:



   - "Yes," then we classify the file as a "publication." (See IRM 1.17.8.4, _Types of Published Products_ and **IRM 1.17.8.5.6.1**, _**Publication Types**_.) Publications typically have a wide-ranging audience, can have multiple revisions over time, and require development by Publishing for proper tracking. Product content owners/originators must submit a PSR. A PSR initiates development of the publication and ensures it meets IRS design standards and conforms to Section 508 accessibility requirements.

   - "No," then this is most likely a miscellaneous static file. (See **IRM 1.17.8.5.12**, _**Miscellaneous Products**_.) These types of files may be Word, PowerPoint, Excel, or Portable Document File (PDF) files. We typically produce these files one-time and have a limited audience. Business/functional owners/representatives must submit a Web Content Management System (WCMS) support request to have the product posted to IRS.gov. Any file posted to IRS.gov must also be compliant with Section 508 of the Rehabilitation Act.

   - "Unsure," then the business/functional coordinator for the BOD should review the file, and if necessary, consult with Publishing/OLS to make further determinations.


**1.17.9.3.8** **(08-10-2023)**

#### Production/Cost Tracking of All Published Products

1. Publishing maintains all published product procurement information using a database called the Publishing Services Data (PSD) system.

2. Only publishing specialists can access PSD.

3. Publishing specialists use PSD to store production information such as version control, vendor information, print quantity, status codes, and GPO data.

4. PSD also stores cost-tracking information, such as obligations and commitments.


**1.17.9.3.9** **(08-21-2018)**

#### Obtaining Photocopying

1. Publishing specialists can use a contracted vendor via publishing procurement vehicles to assist requestors that have a large volume of photocopying, request color copies and have no access to a color copier, or need unavailable binding.

2. To request photocopies, submit a PSR as instructed in _IRM 1.17.9.6_ to request a new product.

3. On the “New Product Request” screen in the PSR system, the requestor must select Photocopying as the Product Type for photocopying services.

4. Requestors that have any questions about available photocopying services should consult with their publishing specialist at Find a publishing specialist on the Publishing website.


**1.17.9.3.10** **(06-20-2025)**

#### Language Translation Services

1. Product content owners/originators may have products that need to comply with the Multilingual Initiative (MLI), to support Executive Order 13166, or may have source documents that require translation into English. All translation services requests are the responsibility of the product content owners/originators. For products requiring any translation services, please see IRM 22.31.1, _Multilingual Initiative, IRS Language Services_.



### Note:



All products published in languages other than English must have an English version. For example, an originator cannot have a product that's only available as a Korean language product, or as a Spanish language product.


**1.17.9.3.10.1** **(06-20-2025)**

##### Requesting Product Translations

1. The originator determines if a product is needed in languages other than English.

2. Use a PSR to submit requests to translate products to the Linguistic Policy, Tools and Services (LPTS) Office, depending on whether the letter is considered "vital" or "non-vital." See IRM 22.31.1, _Multilingual Initiatives, IRS Language Services_, for specific instructions.

3. To submit a translation request, the originator must check the "Translation Service" box (which appears when certain "Product Types" are selected) when in the PSR application and attach a completed Form 14078, _Request for Translation and/or Quality Review of Non-Vital Documents_ along with the final English version of the final source document (meaning, it's gone through all appropriate reviews by stakeholders including, but not limited to the Office of Management and Budget (\*OMB Unit), Privacy, Governmental Liaison, and Disclosure (if the product asks for a Social Security Number or Taxpayer Identification Number), Office of Taxpayer Correspondence) to the PSR.

4. Publishing and LPTS supports the following languages: Arabic, Bengali, Chinese-Simplified, Chinese-Traditional, French, German, Gujarati, Haitian Creole, Hebrew, Italian, Japanese, Khmer, Korean, Persian/Farsi, Polish, Portuguese, Punjabi, Russian, Somalia, Spanish, Tagalog, Urdu, and Vietnamese.

5. If you need products in other languages, please contact your publishing specialist to determine availability and turnaround times.


**1.17.9.4** **(07-22-2019)**

### Products Offered by Publishing

1. Publishing offers a variety of products tailored for specific purposes. We list some of the published products below:



   - Brochures and pamphlets (for taxpayers and/or employees)

   - Conference materials

   - Documents and booklets (for employees)

   - Envelopes (for taxpayers and/or employees)

   - Forms (for taxpayer and/or employee administrative use)

   - Internal Revenue Manual

   - Internal Revenue Bulletin

   - Notices (to taxpayers)

   - Posters (for taxpayers and/or employees)

   - Publications (for taxpayers and the public)

   - Tax Forms (for tax preparation)

   - Templates for PowerPoints, agendas, etc.

   - Taxpayer Assistance Center (TAC) office signage

   - Training Documents

   - External Customer Service Satisfaction surveys

   - Other items as needed, except for promotional items


2. A memorandum to all managers, posted on the IRS Intranet at the HCO website and dated August 19, 2011, from the deputy commissioners stated that all promotional items must receive a deputy commissioner’s approval prior to being purchased.


**1.17.9.5** **(07-22-2019)**

### When to Contact Publishing

1. All product content owners/originators needing to publish and/or post new or revised information on IRS.gov must submit a PSR, follow the publishing process, and meet IRS Design Standards and Guidelines and a professional format review defined by Media & Publications. All IRS product development should include the Media & Publications team of visual information specialist and publishing specialist for the product design, development, printing, posting and/or delivery, including when product content owners/originators are working with vendors.

2. A requester should contact Publishing as soon as the need for services arises for product(s) to support any mission, campaign, or event. Requesters new to the publishing process should consult with a publishing specialist about when and how to complete a Publishing Services Request (PSR) to start the publishing process. Requesters can view the list of publishing specialists on the IRS Intranet at Find a publishing specialist on the Publishing website.

3. The requester should have the following information available when meeting with a publishing specialist:



   - A draft of product text, and alternative text for screen reader users, provided to Publishing at time of product request. Requestors should consult Document 12687, _Getting Your Information Published at the IRS_, for tips on writing product content, including adhering to Plain Writing and Section 508 standards.

   - A requestor requiring design services for a product should submit draft text contents in one of the following electronic formats: Microsoft (MS) Word, MS Excel, MS PowerPoint, MS Notepad or MS WordPad. Publishing will not accept text draft contents in MS Publisher.

   - A requestor may submit any photographs or illustrations to Publishing to be used in published products. However, the requestor is securing all copyrights where applicable (see IRM 1.17.8.5, _Copyright and Copyrighted Material_).

   - The intent of the product(s).

   - An identified audience or group of end-users.

   - A delivery date for the item to be at specific destinations or in the end-user’s hands.

   - Confirmation from C&L about key messages for internal products with Servicewide impact or all external products.

   - An identified business approver. This is an authorized manager or executive who validates that there is a legitimate need for the product(s).

   - An identified funding approver. This is an authorized manager or executive who allows funds to be committed for the product(s).

   - Requester, business approver, and funding approver can act in only one capacity per PSR.

   - Lists of current authorized business and funding approvers is available at: Approvers List for PSR on the Publishing website.


4. Requestors should consult with Publishing before they contract with a market research firm regarding a product to be designed, printed or posted to any IRS website (internal or external). This ensures the products comply with all Federal rules and regulations, including Section 508 of the Rehabilitation Act.


**1.17.9.6** **(06-20-2025)**

### Importance of Standards and Submitting a Publishing Services Request

01. Once the requestor has all or most of the useful information about the published products and has consulted with the publishing specialist, follow the steps below to begin your Publishing Services Request (PSR). For more detailed instructions, refer to Document 12821, _A Requester's Guide for Using the Publishing Services Request Application PSR_ at PSR Requestors Guide on the Publishing website.



    ### Note:



    An incorrect “Product Type” can delay your job. If you are unsure about the correct “Product Type”, then contact an M&P publishing specialist. For a specific PSR question, email the \*PSR Helpdesk at \*PSRhelpdesk@irs.gov.





    ### Note:



    Do not use the PSR application to submit IRMs

02. **STEP 1:** Create the content for your product in an approved electronic format. To comply with Section 508 standards, also supply proper alternative text for screen reader users. Submit the content along with your PSR.

03. **STEP 2:** To submit an online request, go to the PSR application on the Publishing website. You will see a screen (_Figure 1.17.9-1_) with three buttons customers choose from to select the type of service needed from the PSR.



    **Figure 1.17.9-1**

    ![This is an Image: 59991001.gif](https://www.irs.gov/pub/xml_bc/59991001.gif)





    > These are the three buttons customers choose from to select the type of service needed from the PSR.







    [Please click here for the text description of the image.](https://www.irs.gov/media/129851 "")

04. **STEP 3:** Select the action type for your request.



    - _Request a New Product_ — select this option for one-time requests and non- catalogued products that do not currently exist

    - _Revise an Existing Product_ — select this option for existing catalogued products that require a revision

    - _Reprint an Existing Product_ — select this option to reprint existing catalogued products that do not include revisions


You will see a screen (_Figure 1.17.9-2_) with the PSR Online Form.



**Figure 1.17.9-2**

![This is an Image: 59991002.gif](https://www.irs.gov/pub/xml_bc/59991002.gif)

> This is the fill-in area to enter data for the PSR.

[Please click here for the text description of the image.](https://www.irs.gov/media/129856 "")

05. **STEP 4:** Complete the following fields shown in _Figure 1.17.9-2_.



    - Requestor

    - Operating Division\*

    - Requestor Office Symbols

    - Product Title

    - Product Type\*

    - Translation Services - For certain Product Types, an additional field for selecting Translation Services will appear. If you select this box, you will need to attach a completed Form 14078, _Request for Translation and/or Quality Review of Non-Vital Documents_, and the final, locked-in English content of your product.

    - Product Information - Include the purpose of the product, the intended audience(s), and how often the product may be revised.

    - Requested Delivery Date

    - Estimate Needed

    - Requestor Notes

    - Approving Official\*

    - Funding Approver\*



      ### Note:



      \\* Use the drop-down box to select an option.


06. **STEP 5:** Select the "Create Request" button (_Figure 1.17.9-3_).



    **Figure 1.17.9-3**

    ![This is an Image: 59991003.gif](https://www.irs.gov/pub/xml_bc/59991003.gif)





    > This is the “Create Request” button to use once all fill-in data is complete for the PSR.







    [Please click here for the text description of the image.](https://www.irs.gov/media/129861 "")





     After hitting the “Create Request” button, you will see the following screen (_Figure 1.17.9-4_).




    **Figure 1.17.9-4**

    ![This is an Image: 59991004.gif](https://www.irs.gov/pub/xml_bc/59991004.gif)





    > This is the window that appears after clicking the “Create Request” button.







    [Please click here for the text description of the image.](https://www.irs.gov/media/129866 "")

07. **STEP 6:** To upload an attachment:



    1. Browse for a file on your computer, choose the proper file, and select the "Attach" button (_Figure 1.17.9-5_).



       ### Note:



       You may attach multiple files to your request.





       **Figure 1.17.9-5**

       ![This is an Image: 59991005.gif](https://www.irs.gov/pub/xml_bc/59991005.gif)





       > This is the Attach button customers use to attach files to their Publishing Services Request.







       [Please click here for the text description of the image.](https://www.irs.gov/media/129871 "")

    2. After you find all attachments, click the "Done" button (_Figure 1.17.9-6_).



       **Figure 1.17.9-6**

       ![This is an Image: 59991006.gif](https://www.irs.gov/pub/xml_bc/59991006.gif)





       > This is the Done button customers use to confirm that the selected files should be attached to their Publishing Services Request.







       [Please click here for the text description of the image.](https://www.irs.gov/media/129876 "")

    3. You will receive a confirmation (_Figure 1.17.9-7_) that looks like this:



       **Figure 1.17.9-7**

       ![This is an Image: 59991007.gif](https://www.irs.gov/pub/xml_bc/59991007.gif)





       > This is an image of the screen that customers receive to confirm their Publishing Services Request and includes their PSR number for future reference.







       [Please click here for the text description of the image.](https://www.irs.gov/media/129881 "")


08. **STEP 7:** After you submit a request, the system routes the request to the following for approval:



    - Approving Official

    - Funding Approver


09. Once a request is approved and funded, your publishing specialist can process the order.

10. To view the status of your request at any time:



    1. Go to: PSR status screen on the PSR application

    2. Select the "Check Status of Your Requests" button.



       **Figure 1.17.9-8**

       ![This is an Image: 59991008.gif](https://www.irs.gov/pub/xml_bc/59991008.gif)





       > This is an image of the button customers choose to check the status of their Publishing Services Requests.







       [Please click here for the text description of the image.](https://www.irs.gov/media/129886 "")

    3. A list of current and previous PSRs submitted will appear. See _Figure 1.17.9-9_.



       **Figure 1.17.9-9**

       ![This is an Image: 59991009.gif](https://www.irs.gov/pub/xml_bc/59991009.gif)





       > This is the list showing current and previous PSRs assigned to the requesting customer.







       [Please click here for the text description of the image.](https://www.irs.gov/media/129891 "")


11. For questions or comments, help is available at the PSR Help page in the PSR application.

12. Once the product is processed and published, email your [records specialist](https://irsgov.sharepoint.com/sites/ETD-KMT-KB003/SitePages/RecordsManagement/RecordsRolesandResponsibilities/RolesandResponsibilitiesforRecordsSpecialists.aspx) in the Records and Information Management (RIM) program office at [the Records Management email address](mailto:p.rim@irs.gov) to schedule the newly created document for retention and disposition. All IRS records, including published products, are required to be scheduled for proper retention and disposition as approved by the National Archives and Records Administration (NARA).


**1.17.9.6.1** **(11-28-2022)**

#### Submitting a Form 1767 for Publishing Services

1. Form 1767, _Publishing Service Requisition_, is a paper form previously used to request publishing services prior to the online PSR application. The online PSR application has replaced the use of the Form 1767 for most requests. Only use Form 1767 when the online PSR application is not available, or cannot meet customer’s requirements, as directed by a publishing specialist.



### Example:



You must use a paper Form 1767 to submit an IRM for publication.


**1.17.9.6.2** **(07-29-2020)**

#### PSR Submission Flow

1. After a PSR is submitted, it travels to the email inboxes of an approving official and a funding approver designated during the submission process. When the requestor (product content owner/originator) clicks the “Done” button, as shown in Step 6 in _IRM 1.17.9.6_ (7)2), the PSR system will transfer the request in the following order:



> Approving Official and Publishing Estimate (if applicable) → Funding Approver → Publishing

2. The requestor will receive email messages as a PSR is sent, approved, or denied while it is routed to the approving official and funding approver. The requestor can edit the PSR request during this process if it is necessary.

3. Once both the approving official and funding approver sign the PSR, then the request goes to Publishing. The requestor will receive an email message that the PSR is in route to Publishing and will soon be assigned. When Publishing receives the PSR, it will contain a 7-digit requisition number that will appear in the subject line of the email message and on the PSR itself.

4. When Publishing receives the PSR, it will go in one of a series of email in-boxes within Publishing based on the requestor’s business unit profile and/or product type.

5. Within 1-3 business days, a gatekeeper reviews the PSR and routes it to an assigned publishing specialist.

6. Once a publishing specialist receives the request, they will contact the requestor to obtain any information needed to complete the request.


**1.17.9.6.3** **(06-20-2025)**

#### Timeframes to Design, Print, and Distribute a Published Product

1. Production timeframes will depend on the product and the amount of preparation needed to produce it.

2. For customer-provided files that are production-ready, reprints, or suitable for the type of product, it can take as little as 1 to 10 business days for production and distribution.

3. For customer-provided files that are NOT production-ready, or do not meet IRS design standards or Section 508 compliance for the type of product, the request may require design services and production preparation and can take up to several weeks or months to design, print, and distribute.

4. Contact your publishing specialist at the publishing specialist list on the Publishing website for factors that may determine a more accurate timeline based on your situation.

5. If translation services are requested, see IRM 22.31.1, _Multilingual Initiatives, IRS Language Services_, for additional information and general timeframes.

6. If you are planning a conference that requires tent cards, agendas, signage, brochures, name badges, posters, or other published items, then please consult with your publishing specialist.


**1.17.9.7** **(02-19-2013)**

### Roles and Responsibilities When Publishing a Product

1. Other specific roles and responsibilities appear below for the listed entities when publishing a product:



   - Publishing Function

   - Requestors/Originators

   - Heads of Office


**1.17.9.7.1** **(08-21-2018)**

#### Publishing's Roles and Responsibilities

1. The Publishing Function is the official publisher for the IRS. As required by federal regulations (see USC Title 44, Section 501), the Government Publishing Office (GPO) receives or monitors all government printing. Publishing is the IRS representative for the GPO Office and the only approved IRS entity to procure/purchases any design, printing and imaging services on behalf of the IRS.

2. If a requester or purchaser has doubts about procuring/purchasing a product under a GPO program, then they should contact an M&P publishing specialist at the publishing specialist list on the Publishing website for assistance.


**1.17.9.7.1.1** **(11-28-2022)**

##### Officially Published Products

1. Only the Publishing Function can publish officially published products for the Service. A published product is an official IRS product when it contains a catalog number and product identifier issued by Publishing, is approved for publishing by the product content owner/originator, is issued as an active item or revision by Publishing, and is available on Publishing’s Catalog page.

2. Official published products are available through Publishing’s electronic Catalog Page for easy accessibility.

3. We design official published products according to Publishing’s design and forms standards for consistency and readability.

4. Product originators must submit IRS products to Publishing for them to become official IRS published products. Exceptions may be:



   - One-time use products with minimal distribution, such as meeting agendas and minutes, retirement flyers, data call spreadsheets, interoffice communications,

   - Electronic products that do not convey official policy, and are intended for use within a working group for collaboration and/or reference, such as an individual’s desk guide, a working group’s internal files stored on SharePoint, or the group’s recommendation report to their management, and

   - Web pages for internal or public use that:


> - Are for information only and do not convey official policy or data,
>
>    - Present information or data in a user-friendly online manner that is or will be available in an official published product,
>
>    - Will not need to be available for future reference, or
>
>    - Convey policy that is available to the public in an online archive that is linked from the webpage.

5. See the chart below to determine what to submit to Publishing as a published product.




| **If** | **Then** |
| --- | --- |
| The product may be used or referenced to support a legal position | Submit the product, along with a Publishing Services Request (PSR), to Publishing to produce an official, numbered IRS product. |
| The product will be distributed to the public or otherwise outside the IRS at a quantity more than ten | Submit the product, along with a Publishing Services Request (PSR), to Publishing to produce an official numbered IRS product. |
| IRS employees must fill in information on the product and/or sign and return | Submit the product, along with a Publishing Services Request (PSR), to Publishing to produce an official numbered IRS product. |
| The product will be revised, reissued, or reprinted periodically (e.g., newsletters, statistical charts, etc.) | Submit the product, along with a Publishing Services Request (PSR), to Publishing to produce an official numbered IRS product. |
| The product needs to be accessible to others outside the originating office | Submit the product, along with a Publishing Services Request (PSR), to Publishing to produce an official numbered IRS product. |
| The product requires graphic design services only, with no paper or electronic publishing services, and does not meet any of the previous criteria | Submit the product, along with a PSR, to Publishing to obtain graphic design services. |
| The product is for one-time, low-volume use (e.g., meeting agenda, retirement flyer, etc.) | You may produce and distribute the product without involving Publishing. |

6. See IRM 1.17.10, _IRS Published Product Identification_, for information on how we number published products and how that identification appears on the product.


**1.17.9.7.1.2** **(08-21-2018)**

##### Production Sources

1. Publishing must consider each customer’s publishing requirements and determine the proper source for production, the process or processes to be used, the types of materials and supplies required, and end use of the product.

2. Source determination will focus on economic, schedule, and service requirements. Typical production sources are:



   - Other Government In-Plant Printing - Work produced by any other government printing facility, such as the Department of the Treasury, General Services Administration (GSA), and the Federal Prison Industries, Inc. A list of authorized printing plants appears in the Government Printing and Binding Regulations.

   - Main Government Publishing Office - Work produced in-house at GPO, individually bid out for commercial printing, placed by agencies on direct deal contracts authorized by GPO, or placed by GPO on term contracts.

   - GPO Regional Printing Procurement Office (GPO-RPPO) - Work individually bid out for commercial printing, placed by agency on direct-deal contracts authorized by GPO-RPPO, or placed by GPO-RPPO on term contracts.

   - Commercial Sources - Printing work procured directly by IRS personnel from commercial suppliers, following all the necessary regulations such as Title 44, Federal Acquisition Regulations (FAR), Treasury Procurement Regulations (TPR), and IRS procurement procedures.


**1.17.9.7.1.3** **(02-19-2013)**

##### Version Control

1. Publishing uses the Electronic Status Notice (ESN) system to manage versions of a published products that appear on the electronic catalog page.

2. Previous versions of a published product are archived on the Publishing Catalog Page.


**1.17.9.7.1.4** **(08-21-2018)**

##### Online Catalog Page

1. Publishing catalogs all official products on the electronic Catalog Page. The Catalog Page offers access to:



   - E-subscriptions of published products

   - Product and contact information

   - Section 508-compliant files

   - Previous revisions

   - "What’s New" lists of products published in the last two weeks

   - Quick links to Commonly Used Forms


**1.17.9.7.2** **(11-28-2022)**

#### Responsibilities of Product Content Owners/Originators

1. This section describes the responsibilities of product content owners/originators for products Publishing produces.

2. The product content owners/originators must notify Publishing when their contact information changes (telephone number/office symbols).

3. Prior to retiring or leaving their position, product content owners/originators must notify Publishing of the contact information (name, telephone number, and office symbols) of the new product content owner/originator who is replacing them.

4. The product content owners/originators can contact Publishing at any time to get a listing of all products for which they are identified as the originator.

5. Product content owners/originators are responsible for ensuring all products meeting the definition of a record as defined in IRM 1.15.2, _Types of Records and Their Life Cycles_, are scheduled for retention and disposition with the RIM program office by emailing [\*Records Management](mailto:p.rim@irs.gov).


**1.17.9.7.2.1** **(07-29-2020)**

##### Reprinting Existing Published Products

1. Product content owners/originators must use their own publishing funding for their requests to restock products at the National Distribution Center (NDC) when stock reaches a level requiring it to be replaced.

2. We can reprint products not stocked at the NDC with either the product content owner’s/originator’s publishing funding or the requester’s publishing funding.


**1.17.9.7.2.2** **(06-20-2025)**

##### Revising Existing Published Products

1. The product content owners/originators are updating products for changes.

2. The product content owners/originators must notify Publishing whenever a product changes owners.



### Note:



If your English-language product is available in other languages, once your English language content is finalized, you must also submit a PSR to revise your product's non-English language version(s). Attach a completed Form 14078, _Request for Translation and/or Quality Review of Non-Vital Documents_, to your PSR and the final English content. See IRM 22.31.1, _Multilingual Initiatives, IRS Language Services_, for more information about Translation Services.


**1.17.9.7.2.3** **(06-20-2025)**

##### Obsoleting Published Products

1. It is the product content owner’s/originator’s responsibility to request that we make a product obsolete once it is no longer useful or replaced. The originating office must place a form or other published product in either an active, obsolete, or historical status.

2. The product content owners/originators must submit a PSR to have Publishing make the product obsolete. The originating office must submit a PSR to Publishing and provide an explanation for the product’s obsolescence. The originator must also show what has replaced the form (a new form, a new process, a website, etc.).



### Note:



If your product is available in languages other than English, you must also submit PSRs to obsolete those language products.

3. Publishing, through periodic reviews, may request to have dormant products made obsolete due to no known product content owner/originator or lack of revision or reprint activity for an extended time period.

4. If an item is dormant, Publishing can make the item obsolete, with a Publishing branch manager’s approval.

5. Some products have predetermined obsolescence dates specified in the original requisition; publishing specialists may routinely obsolete these products at the proper time.


**1.17.9.7.2.4** **(02-19-2013)**

##### Submitting Justification to Post Public-Use Non-Tax Products to IRS.gov

1. The product content owners/originators of a public-use non-tax product must submit written justification to Publishing to post a public-use form or publication to the IRS website. The written justification should contain the following information:



   - Product description;

   - Explanation as to why it should be available on the IRS website;

   - Intended audience; and

   - Other pertinent information.


2. The originator’s business approver must approve the justification and email it to the assigned publishing specialist. The publishing specialist will then forward the written or email approval of his or her branch chief. If the branch chief disapproves the request, the publishing specialist will notify the originator and, if necessary, request the IRS.gov gatekeeper to remove older posted revisions of the product from the IRS website.


**1.17.9.7.2.5** **(07-22-2019)**

##### Section 508 Compliance

1. IRS published products must comply with Section 508 of the Workforce Rehabilitation Act of 1973, and all amendments, to be accessible by taxpayers and employees with disabilities.

2. When submitting a Publishing Services Request, the product content owner’s/originator’s responsibilities are:



1. If providing a final file, then the originator must ensure that the final PDF (or other format) file is compliant. Materials that do not meet these requirements will delay the production of the product. Product content owners/originators can create a Section 508-compliant PDF by creating a Word, Excel, PowerPoint, InDesign, etc. file that will create a compliant PDF file. See **Section 508 Tools for Authors** at the Alternative Media website.

2. If authoring in a Publishing-developed application, such as Arbortext for IRM, special instructions are available from your publishing specialist.

3. If providing materials for Publishing to create the product file, then the materials must include the following to allow Publishing to efficiently produce a Section 508-compliant final file.


1. Use Microsoft Office built-in hierarchical heading roles, list styles and table styles when creating content.

2. Links in text must describe where the link goes ("Enter a Publishing Services Request" instead of "Click here" ) or alternative text for the link must be provided.

3. All non-text, such as photos, drawings, charts, workflows, etc., must have alternative text provided.


3. Publishing specialists will:



1. Work through the IRS Alternative Media Center for Section 508 review and remediation;

2. Work through a Section 508 contractor to have Section 508 attributes added/remediated;

3. Add/remediate Section 508 attributes internally;

4. Develop an alternative format other than PDF (For example, hyper-text mark-up language (HTML) is one possible alternative format.); or

5. Ensure that we post compliant files to the Core Repository of Published Products (CROPP).


**1.17.9.7.3** **(11-28-2022)**

#### Responsibilities of Executive Heads of Office

1. Each Operating Division Commissioner and other Executive Heads of Office must determine printing and publishing needs of their respective areas, including the following:



   - Make sure printing and publishing activity is legal and necessary and contains only matters relating to government business (See United States Code Title 44)

   - Incorporate agency style, format, and graphic standards

   - Use established publishing standards, including relevant regulations, product numbering, Section 508 compliance, and lead times

   - Obtain required tax form product clearances through the Tax Products Coordinating Committee

   - Notify Publishing of any research affecting printed products to avoid program delays and duplication

   - Include Publishing in plans for joint publications with other agencies

   - Obtain production of items through the proper Publishing Office

   - Use a suitable national item before creating new products for local use

   - Ensure that locally created items are developed within the framework of nationally prescribed practices and standards

   - Identify and classify sensitive material requiring handling as either "Limited Official Use" , "Official Use Only," "Controlled Unclassified Information," or "Sensitive But Unclassified"


2. Ensure that all created items meeting the definition of records are scheduled for proper retention and disposition as approved by NARA.


**1.17.9.8** **(07-29-2020)**

### Special Publishing Circumstances

1. There are special publishing circumstances that may affect some published products. Check with your publishing specialist at the publishing specialist list on the Publishing website to see if these or other circumstances may apply to your product:



   - Office of Management and Budget Numbers for Public-Use Forms

   - Paperwork Reduction Act (PRA) Notice

   - Privacy Act

   - Color Copier Purchases


2. Audit Techniques Guides (ATGs) help IRS examiners during audits by providing insight into issues and accounting methods unique to specific industries. While ATGs provide guidance primarily for IRS employees, they are also useful to small business owners and tax professionals who prepare returns. Product content owners needing to post new or revised ATGs on IRS.gov must submit a PSR and follow the ATG process and format defined by Media & Publications.


**1.17.9.8.1** **(06-20-2025)**

#### OMB Numbers for Public Use Forms

1. An Office of Management and Budget (OMB) number is required when collecting information from 10 or more members of the public in a 12-month period. The OMB number is required for completing the Privacy Impact Assessment (PIA) template.

2. M&P’s Tax Forms & Publications (TF&P) OMB Unit, or the OMB directly, must provide OMB numbers or exemptions.

3. The publishing specialist designing the public use form will email it to the IRS OMB office to verify if an OMB number or exemption is required and will copy the form owners/originators of a public-use form on this email. Alternatively, the publishing specialist will notify the form owners/originators of a public-use form that an OMB number or exemption is required and will then refer the form owners/originators to the TF&P OMB Unit section to start the review process.

4. It is the responsibility of the form product content owner/originator to obtain the OMB number or an exemption.

5. It is the responsibility of the form product content owner/originator to allow for a suitable timeframe for OMB approval or exemption.

6. A public-use form provided to a publishing specialist for release must have the OMB number included or notification of an exemption by written justification from the TF&P OMB Unit or OMB. Publishing will not post a public-use form that does not have either an OMB number or a written justified exemption to [the IRS internet site](https://www.irs.gov/irm/part1/www.irs.gov) or the IRS CROPP.

7. Publishing will not post for external or internal release public-use forms not containing either an OMB number or an exemption from the IRS' M&P TF&P OMB unit.

8. Originator responsibilities for publishing IRS products appear in the chart below.



**When assuming ownership of an IRS published product, the originator has the following responsibilities:**






| **Originator Responsibility** | **Rationale** | **Originator Actions** |
| --- | --- | --- |
| Creating and Revising Published Products | The product content owner/originator is the subject-matter expert for a published product’s content and is keeping content current. Remember to submit PSRs for non-English language versions of your product, if applicable. Attach a completed Form 14078, _Request for Translation and/or Quality Review of Non-Vital Documents_, and the finalized English content of your product. | Submit an online Publishing Services Request at the PSR page on the Publishing website to create or revise a published product. |
| Notifying Managers of Ownership Changes | If you plan to retire, leave the service, or accept another position, you must notify your manager and ask for a new originator to accept ownership of your product. | Contact your manager and ask to reassign the published product to another employee. |
| Notifying Publishing of Ownership Changes | If you plan to retire, leave the service, or accept another position, you must notify Publishing of the new author of the product. Failure to notify Publishing may result in continuous use of outdated products by customers. | Email your publishing specialist at the Find your publishing specialist list on the Publishing website with the new originator’s name, phone number, and office symbols. |
| Obsoleting Published Products | If a product should no longer be available to customers or is replaced by another product, you must notify Publishing that the product is obsolete so that the product’s file can be removed from the Product Catalog Information page. Failure to notify Publishing may result in continuous electronic use of outdated products by customers. Remember to also obsolete non-English versions of your product(s), as applicable. | Submit an online Publishing Services Request to revise (obsolete) a published product.<br> <br>### Reminder:<br>You cannot use the online PSR application to revise (obsolete) IRMs. See IRM 1.11.2, _Internal Revenue Manual (IRM) Process_ for more information. |
| Obtaining OMB Numbers for Public-Use Forms | An OMB number is required when collecting information from 10 or more members of the public in a 12-month period. The OMB number is used in completing the Privacy Impact Assessment (PIA) template. Forms are the vehicle the Federal Government uses to collect information from the public.<br> <br>### Note:<br>Publishing will not post to [the IRS internet](https://publish.no.irs.gov/catlg.html#tab=tab1) forms that do not contain an OMB number or have an exemption from OMB. | **To obtain an OMB number or contact the OMB section, send an email to one of the following email addresses**: the OMB unit or the OMB section. You can find information on the **OMB Clearance Office within TF&P** at the IRS OMB Clearance office website. |


**1.17.9.8.2** **(02-19-2013)**

#### Paperwork Reduction Act (PRA) Notice

1. Forms requiring information from the public are subject to the Paperwork Reduction Act (PRA) and must contain Privacy Act and PRA Notice text. Forms requiring information for internal use, and used only by federal employees, are not subject to the PRA and do not require Privacy and PRA Notice text.


**1.17.9.8.3** **(07-29-2020)**

#### Privacy Act

1. Forms requiring a taxpayer to provide personal information protected by the Privacy Act, including tax information or an identification number (e.g., social security number, employer identification number, or individual taxpayer identification number) must contain a Privacy Act statement customized for the particular form. The Office of Disclosure should review and approve the Privacy Act statement text before the form draft is supplied to Publishing. For detailed guidance, see IRM 10.5.6.4.2, _Notice to Individuals Asked to Supply Information (Privacy Act Notice)_.


**1.17.9.9** **(02-19-2013)**

### Color Copier Purchases

1. Publishing does not provide acquisition/purchasing services for color office copiers. Obtain color office copiers from your local Support Services offices. Support Services functions help customers consistent with normal procurement support activity for other office equipment. Color office copiers are machines that produce less than 100 copies per minute. These copiers are not managed under the printing environment criteria set by the Department of the Treasury.


**1.17.9.9.1** **(08-21-2018)**

#### Requesting High-Speed, Color-Copier Duplicators or Specialty Copiers

1. All high-speed, color-copier duplicator and specialty-copier equipment must have Publishing and the Department of the Treasury Department approval prior to installation. Such prior approval applies to rented, leased, and purchased copier equipment.

2. You must coordinate local requests through the local Support Services area and forward the local requests to the Publishing Services Branch.

3. Prepare and submit the following information in the prescribed order:



   - Office location and exact location of existing equipment;

   - Analysis of existing workload, including monthly volume for the past 12 months;

   - Statement of expected program changes that would have significant effects on the future workload;

   - List of equipment to be replaced, including its features and general condition;

   - A justification for any copier features requested (see Form 13884, _Color Copier Purchase Justification_);

   - Cost-benefit analysis of the proposed system versus the existing system; and

   - If selecting other than the least-expensive copier, then you must give the reasons.


4. After the national coordinator reviews and accepts the request, Publishing will forward the request to the Department of the Treasury for approval or disapproval, as required by _Department of the Treasury Directives Manual_ Chapter TDP-70, Section 05, Chapter 5. Publishing will send written approval or disapproval of copier requests to the requesting office. Normal turnaround times through Publishing and Treasury, if everything is in order, would be 30 days.

5. Until approval is received, an individual delegated procurement authority cannot make formal or informal obligation or commitment to the intended equipment vendor. Inform the vendor that Publishing approval is required, and under no circumstances is the vendor’s national representative to intervene by directly contacting Publishing. If further information is needed, then Publishing will contact the vendor.

6. Failure to get this approval prior to installation could constitute an unauthorized procurement.

7. Publishing will file a copy of the approval in the proper procurement file.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-017-009#addtoany "Show all")

A2A