---
url: "https://www.irs.gov/irm/part1/irm_01-014-012"
title: "1.14.12 IRS Environmental Compliance Program | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-014-012#main-content)

- 1.14.12  [IRS Environmental Compliance Program](https://www.irs.gov/irm/part1/irm_01-014-012#idm140447710851280)
  - 1.14.12.1  [Program Scope](https://www.irs.gov/irm/part1/irm_01-014-012#idm140447711008944)
    - 1.14.12.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-014-012#idm140447738050400)
    - 1.14.12.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-014-012#idm140447738048080)
    - 1.14.12.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-014-012#idm140447707751648)
    - 1.14.12.1.4  [Program Objectives and Review](https://www.irs.gov/irm/part1/irm_01-014-012#idm140447711012304)
    - 1.14.12.1.5  [Acronyms](https://www.irs.gov/irm/part1/irm_01-014-012#idm140447711001808)
    - 1.14.12.1.6  [Related Resources](https://www.irs.gov/irm/part1/irm_01-014-012#idm140447737941056)
  - 1.14.12.2  [Policy](https://www.irs.gov/irm/part1/irm_01-014-012#idm140447737938096)

# Part 1. Organization, Finance, and Management

# Chapter 14. Facilities Management

# Section 12. IRS Environmental Compliance Program

* * *

## 1.14.12 IRS Environmental Compliance Program

#### Manual Transmittal

August 22, 2022

#### Purpose

(1) This transmits revised IRM 1.14.12, IRS Environmental Compliance Program.

#### Material Changes

(1) This IRM provides purpose, authorities, directives, and responsibilities for compliance with environmental regulations and other requirements.

(2) Administrative revisions due to changes in titles, Executive Orders (EO) and Treasury Directives (TD).

(3) Changes to the requirements for periodic Environment, Health and Safety (EHS) reviews of delegated facilities.

(4) Addition of the requirement for procurement actions to obtain an EHS review of contract documents prior to publication or execution.

(5) EO 13834 Efficient Federal Operations (07/17/2018) has been revoked.

(6) Removes the Deputy Commissioner for Operational Support (DCOS) responsibility to exempt IRS law enforcement activities and related personnel, resources, and facilities, from the provision of EO 13834, to the extent he or she determines necessary to protect undercover operations from unauthorized disclosure.

#### Effect on Other Documents

This supersedes IRM 1.14.12 dated May 10, 2017.

#### Audience

All IRS Organizations

#### Effective Date

(08-22-2022)

Richard L. Rodriguez

Chief

Facilities Management and Security Services

**1.14.12.1** **(08-22-2022)**

### Program Scope

1. **Purpose**: The purpose of the IRS Environmental Compliance Program is to ensure the IRS:



1. Obtains and maintains compliance with applicable federal, state, and local environmental regulations.

2. Develops controls to prevent incidents that could have a negative impact on the environment.

3. Promotes continual improvement in environmental performance and stewardship throughout the organization.


2. The objectives of the IRS Environmental Compliance Program are to:



1. Promote a proactive environmental compliance and protection program that supports the IRS mission.

2. Ensure that all employees and managers comply with IRS environmental rules, regulations, and policies.

3. Prevent incidents at IRS facilities that have the potential to damage the environment or jeopardize the health and safety of IRS employees or the surrounding community.


3. **Audience**: IRS employees and contractors engaged in any activity that has the potential to affect the environment.

4. **Policy Owner**: Chief, Facilities Management and Security Services (FMSS)

5. **Program Owner**: FMSS Chief, Environment, Health and Safety (EHS)

6. **Primary Stakeholders**: FMSS Territory Managers (TM) and their personnel.


**1.14.12.1.1** **(08-22-2022)**

#### Background

1. The Environmental Protection Agency (EPA) and state agencies that have been given primacy over environmental protection have statutory authority over federal facilities’ compliance with federal, state, and local environmental statutes. This IRM expresses the IRS’ intention to fully comply with all applicable federal, state, and local laws governing environmental protection and quality.


**1.14.12.1.2** **(08-22-2022)**

#### Authority

1. 40 Code of Federal Regulations (CFR), Chapter 1, Environmental Protection Agency

2. 41 CFR, 102-74, Facility Management

3. TD 75-09, Environmental, Energy, and Sustainability Management

4. IRS Servicewide Policy Statement, 1-235, Environment, Health and Safety Policy

5. State and local environmental regulations. The major federal environmental statutes contain waivers of sovereign immunity that require IRS facilities to comply with state and local substantive and procedural requirements. The most stringent applicable requirement must be followed.


**1.14.12.1.3** **(08-22-2022)**

#### Responsibilities

1. The Chief, FMSS, is designated as the Senior Environmental Official (SEO) and is responsible for:



1. Overall management, administration, implementation, and evaluation of the Environmental Compliance Program.

2. Ensuring operations of buildings with delegated authority are conducted in accordance with all applicable environmental regulations.

3. Designating the FMSS National Energy Program Manager to oversee the implementation of the energy program.

4. Ensuring adequate staff, resources, and funding to implement an effective environmental compliance program at all operational levels.

5. Establishing procedures to ensure effective implementation of the agency policy and program.

6. Developing goals, objectives, and measures for improving IRS environmental compliance program performance.


2. FMSS TM, responsibilities include:



1. Establishing and managing environmental compliance programs, which meet IRS policies and federal, state, and local regulations, in their servicing areas.

2. Providing resources and organizational support for correcting environmental hazards.

3. Promoting environmental compliance programs and information.


3. Managers and Supervisors responsibilities include:



1. Ensuring that employees and contractors under their supervision receive environmental compliance training relevant to their job tasks.

2. Ensuring incidents that may impact the environment are reported.

3. Cooperating with the territory FMSS environmental coordinator, Headquarters, EHS staff, and/or federal, state, or local regulatory compliance officers performing an inspection or investigation.


4. IRS Contracting Officers, Contracting Specialist Staff shall:



1. Ensure they seek an EHS review per Procedure Guidance and Information (PGI) 1023.70.


5. IRS Purchase Card Holders shall:



1. Ensure they seek an EHS review per the Purchase Card Guide.


6. All IRS employees will:



1. Perform duties in a manner that does not create environmental harm or hazards for themselves, their fellow employees, or the larger community in which the facility is located.

2. Comply with IRS environmental policies and procedures.

3. Report incidents, accidents and near misses that may have a negative effect on the environment.


**1.14.12.1.4** **(08-22-2022)**

#### Program Objectives and Review

1. **Program Goals**: To ensure that all IRS operations are performed in compliance with applicable federal, state, and local environmental regulations.

2. **Program Reports**: In order to ensure IRS facilities are in compliance with applicable federal, state and local EHS laws and regulations, FMSS EHS Headquarters (HQ) staff will conduct periodic EHS reviews at delegated facilities and when needed at non-delegated facilities.

3. **Program Effectiveness**: The EHS review reports are used to judge program effectiveness and to develop and implement corrective actions on instances of non-compliance or where programs are deemed weak which may lead to a non-compliance.

4. **Program Database Review**: The EHS HQ Staff conducts semi-annual reviews with field personnel who have been assigned environmental duties to ensure early identification of potential instances of non-compliance.

5. **Procurement Review**: The EHS HQ Staff will support IRS and Treasury procurement personnel in complying with the Department of Treasury Acquisition Procedure Subpart 1023.70 and the Internal Revenue Service Acquisition Procedure; Procedure Guidance and Information (PGI) 1023.70 which requires contracting officials to request an EHS review of all contracts except those listed in the PGI 1023.70 as not requiring a review.

6. Purchase Card Review: The EHS HQ Staff will support IRS and Treasury procurement personnel in complying with the Purchase Card Guide requirement for certain purchases to undergo EHS review.yes


**1.14.12.1.5** **(08-22-2022)**

#### Acronyms

1. |     |     |
| --- | --- |
| **Acronym** | **Definition** |
| CFR | Code of Federal Regulations |
| DCOS | Deputy Commissioner for Operations Support |
| EHS | Environment, Health and Safety |
| EO | Executive Orders |
| EPA | Environmental Protection Agency |
| FMSS | Facilities Management and Security Services |
| HQ | Headquarters |
| IRSAP | Internal Revenue Service Acquisition Procedure |
| PGI | Procedures, Guidance, and Information |
| SEO | Senior Environmental Official |
| TD | Treasury Directive |


**1.14.12.1.6** **(08-22-2022)**

#### Related Resources

1. IRM 1.2.1, Servicewide Policies and Authorities, Servicewide Policy Statements

2. IRM 1.14.4, Personal Property Management

3. IRM 1.14.5, Occupational Health and Safety Program

4. IRM 10.2.9, Occupant Emergency Planning


**1.14.12.2** **(08-22-2022)**

### Policy

1. This section establishes the IRS guidance for compliance with environmental regulations, EO and TD.

2. IRS Servicewide Policy Statement 1-235, Environment, Health and Safety Policy, found in IRM 1.2.1, Servicewide Policy Statements is applicable across all IRS activities and operations. This section provides specific environmental guidance for implementing the policy.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-014-012#addtoany "Show all")

A2A