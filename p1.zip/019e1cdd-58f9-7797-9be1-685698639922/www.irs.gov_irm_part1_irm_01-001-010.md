---
url: "https://www.irs.gov/irm/part1/irm_01-001-010"
title: "1.1.10 Office of Civil Rights and Compliance | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-001-010#main-content)

- 1.1.10  [Office of Civil Rights and Compliance](https://www.irs.gov/irm/part1/irm_01-001-010#id1)
  - 1.1.10.1  [Civil Rights and Compliance](https://www.irs.gov/irm/part1/irm_01-001-010#id2)

# Part 1. Organization, Finance, and Management

# Chapter 1. Organization and Staffing

# Section 10. Office of Civil Rights and Compliance

* * *

## 1.1.10 Office of Civil Rights and Compliance

#### Manual Transmittal

September 11, 2025

#### Purpose

(1) This transmits revised IRM 1.1.10, Organization and Staffing, Office of Civil Rights and Compliance.

#### Material Changes

(1) This section contains the responsibilities and functional statements for the National Headquarters Office of Civil Rights and Compliance. The changes result from realignments of IRS programs and offices to comply with Executive Order 14151 and related OPM memoranda.

#### Effect on Other Documents

IRM 1.1.10 dated February 25, 2015, is superseded.

#### Audience

All business units

#### Effective Date

(09-11-2025)

Alan S. Pearlman

Acting Deputy Chief Operating Officer

**1.1.10.1** **(09-11-2025)**

### Civil Rights and Compliance

1. The mission of Office of Civil Rights and Compliance (OCRC) is to drive innovative outcomes and better business results by furthering the IRS’s commitment to non-discrimination and the implementation of programs to prevent discrimination against employees, customers and other stakeholders.

2. To accomplish its mission, OCRC administers the following programs:



1. Anti-Harassment

2. Disability Services

3. Equal Employment Opportunity

4. Taxpayer Civil Rights


3. For more information about the aforementioned programs, see IRM 1.20, Equal Employment Opportunity.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-001-010#addtoany "Show all")

A2A