---
url: "https://www.irs.gov/irm/part1/irm_01-017-007"
title: "1.17.7 Use of the Official IRS Seal, IRS Logo, and IRS Endorsed Program Identifiers | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-017-007#main-content)

- 1.17.7  [Use of the Official IRS Seal, IRS Logo, and IRS Endorsed Program Identifiers](https://www.irs.gov/irm/part1/irm_01-017-007#id1)
  - 1.17.7.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-017-007#id2)
    - 1.17.7.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-017-007#id4)
    - 1.17.7.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-017-007#id5)
    - 1.17.7.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-017-007#id6)
    - 1.17.7.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-017-007#id7)
    - 1.17.7.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-017-007#id8)
    - 1.17.7.1.6  [Terms/Definitions/Acronyms](https://www.irs.gov/irm/part1/irm_01-017-007#id9)
    - 1.17.7.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-017-007#id10)
  - 1.17.7.2  [IRS Design Standards](https://www.irs.gov/irm/part1/irm_01-017-007#id11)
    - 1.17.7.2.1  [Importance of Standards](https://www.irs.gov/irm/part1/irm_01-017-007#id13)
    - 1.17.7.2.2  [Enforcement of Standards](https://www.irs.gov/irm/part1/irm_01-017-007#id14)
    - 1.17.7.2.3  [Management and Ownership](https://www.irs.gov/irm/part1/irm_01-017-007#id15)
    - 1.17.7.2.4  [Legal Authority](https://www.irs.gov/irm/part1/irm_01-017-007#id16)
  - 1.17.7.3  [Required Design Elements](https://www.irs.gov/irm/part1/irm_01-017-007#id17)
    - 1.17.7.3.1  [IRS Symbol, IRS Logo, and Official Seal](https://www.irs.gov/irm/part1/irm_01-017-007#id18)
      - 1.17.7.3.1.1  [IRS Symbol](https://www.irs.gov/irm/part1/irm_01-017-007#id19)
      - 1.17.7.3.1.2  [IRS Logo](https://www.irs.gov/irm/part1/irm_01-017-007#id20)
        - 1.17.7.3.1.2.1  [Components of the Official IRS Logo](https://www.irs.gov/irm/part1/irm_01-017-007#id22)
        - 1.17.7.3.1.2.2  [IRS Logo Misuse](https://www.irs.gov/irm/part1/irm_01-017-007#id23)
        - 1.17.7.3.1.2.3  [IRS Logo Lock-Ups](https://www.irs.gov/irm/part1/irm_01-017-007#id24)
      - 1.17.7.3.1.3  [IRS Endorsed Program Identifier](https://www.irs.gov/irm/part1/irm_01-017-007#id25)
        - 1.17.7.3.1.3.1  [IRS Endorsed Program Identifier Configurations and Proportions](https://www.irs.gov/irm/part1/irm_01-017-007#id27)
      - 1.17.7.3.1.4  [Official IRS Seal](https://www.irs.gov/irm/part1/irm_01-017-007#id28)
    - 1.17.7.3.2  [Official U.S. Department of the Treasury Seal and Flag](https://www.irs.gov/irm/part1/irm_01-017-007#id29)
      - 1.17.7.3.2.1  [Official U.S. Department of the Treasury Seal](https://www.irs.gov/irm/part1/irm_01-017-007#id31)
      - 1.17.7.3.2.2  [Official U.S. Department of the Treasury Flag](https://www.irs.gov/irm/part1/irm_01-017-007#id32)
    - 1.17.7.3.3  [Official Font Usage](https://www.irs.gov/irm/part1/irm_01-017-007#id33)
      - 1.17.7.3.3.1  [IRS Standard Fonts](https://www.irs.gov/irm/part1/irm_01-017-007#id35)
    - 1.17.7.3.4  [IRS Wayfinder Identifier System](https://www.irs.gov/irm/part1/irm_01-017-007#id36)
      - 1.17.7.3.4.1  [IRS Historical Internal Logos](https://www.irs.gov/irm/part1/irm_01-017-007#id38)
    - 1.17.7.3.5  [Product Identification](https://www.irs.gov/irm/part1/irm_01-017-007#id39)
      - 1.17.7.3.5.1  [Product Identifier Components](https://www.irs.gov/irm/part1/irm_01-017-007#id41)
      - 1.17.7.3.5.2  [External vs. Internal Product Identification](https://www.irs.gov/irm/part1/irm_01-017-007#id42)
      - 1.17.7.3.5.3  [Product Identification Placement](https://www.irs.gov/irm/part1/irm_01-017-007#id43)
      - 1.17.7.3.5.4  [IRS Historical Product Identification](https://www.irs.gov/irm/part1/irm_01-017-007#id44)
    - 1.17.7.3.6  [Color System](https://www.irs.gov/irm/part1/irm_01-017-007#id45)
      - 1.17.7.3.6.1  [External Color Usage Guidelines](https://www.irs.gov/irm/part1/irm_01-017-007#id47)
      - 1.17.7.3.6.2  [Internal Color Usage Guidelines](https://www.irs.gov/irm/part1/irm_01-017-007#id48)
  - 1.17.7.4  [Section 508 Compliance](https://www.irs.gov/irm/part1/irm_01-017-007#id49)
  - 1.17.7.5  [Optional Style Elements](https://www.irs.gov/irm/part1/irm_01-017-007#id50)
    - 1.17.7.5.1  [IRS Iconic Shapes and Icons](https://www.irs.gov/irm/part1/irm_01-017-007#id51)
    - 1.17.7.5.2  [Photography](https://www.irs.gov/irm/part1/irm_01-017-007#id52)
    - 1.17.7.5.3  [Templates](https://www.irs.gov/irm/part1/irm_01-017-007#id53)
    - 1.17.7.5.4  [Charts and Graphs](https://www.irs.gov/irm/part1/irm_01-017-007#id54)
    - 1.17.7.5.5  [Illustrations](https://www.irs.gov/irm/part1/irm_01-017-007#id55)
    - 1.17.7.5.6  [Urchin Tracking Module (UTM) Parameters](https://www.irs.gov/irm/part1/irm_01-017-007#id56)
    - 1.17.7.5.7  [Vanity URLs](https://www.irs.gov/irm/part1/irm_01-017-007#id57)
    - 1.17.7.5.8  [Quick Response (QR) Codes](https://www.irs.gov/irm/part1/irm_01-017-007#id58)
      - 1.17.7.5.8.1  [How the Audience Uses QR Codes](https://www.irs.gov/irm/part1/irm_01-017-007#id60)
      - 1.17.7.5.8.2  [Target URLs for QR Codes](https://www.irs.gov/irm/part1/irm_01-017-007#id61)
      - 1.17.7.5.8.3  [Creation of QR Codes](https://www.irs.gov/irm/part1/irm_01-017-007#id62)
  - 1.17.7.6  [Internal Identifier Requests](https://www.irs.gov/irm/part1/irm_01-017-007#id63)
    - 1.17.7.6.1  [IRS Endorsed Program Identifiers](https://www.irs.gov/irm/part1/irm_01-017-007#id64)
      - 1.17.7.6.1.1  [Creation or Revision of IRS Endorsed Program Identifiers](https://www.irs.gov/irm/part1/irm_01-017-007#id66)
      - 1.17.7.6.1.2  [Approval Process for IRS Endorsed Program Identifiers](https://www.irs.gov/irm/part1/irm_01-017-007#id67)
    - 1.17.7.6.2  [Law Enforcement Badge](https://www.irs.gov/irm/part1/irm_01-017-007#id68)
    - 1.17.7.6.3  [Affiliated Employee Organizations](https://www.irs.gov/irm/part1/irm_01-017-007#id69)
  - 1.17.7.7  [IRS Website Standards](https://www.irs.gov/irm/part1/irm_01-017-007#id70)
    - 1.17.7.7.1  [IRS Web Link](https://www.irs.gov/irm/part1/irm_01-017-007#id72)
  - 1.17.7.8  [IRS Television and Video Production Standards](https://www.irs.gov/irm/part1/irm_01-017-007#id73)
  - 1.17.7.9  [Taxpayer Assistance Center (TAC) Design Guidelines](https://www.irs.gov/irm/part1/irm_01-017-007#id74)
    - 1.17.7.9.1  [IRS Logo and Taxpayer Assistance Center Identification Text](https://www.irs.gov/irm/part1/irm_01-017-007#id76)
  - 1.17.7.10  [Employee Recognition Award Design Standards](https://www.irs.gov/irm/part1/irm_01-017-007#id77)
  - 1.17.7.11  [Business Card Design Standards](https://www.irs.gov/irm/part1/irm_01-017-007#id78)
  - 1.17.7.12  [Convention Banner Design Standards](https://www.irs.gov/irm/part1/irm_01-017-007#id79)
  - 1.17.7.13  [Requirements for External Contractors/Vendors](https://www.irs.gov/irm/part1/irm_01-017-007#id80)
  - 1.17.7.14  [Independent Organizations within the IRS Design Guidelines](https://www.irs.gov/irm/part1/irm_01-017-007#id81)
  - 1.17.7.15  [IRS Forms Design](https://www.irs.gov/irm/part1/irm_01-017-007#id82)
  - 1.17.7.16  [Frequently Asked Questions (FAQs)](https://www.irs.gov/irm/part1/irm_01-017-007#id83)
  - 1.17.7.17  [Resources](https://www.irs.gov/irm/part1/irm_01-017-007#id84)

# Part 1. Organization, Finance, and Management

# Chapter 17. Publishing

# Section 7. Use of the Official IRS Seal, IRS Logo, and IRS Endorsed Program Identifiers

* * *

## 1.17.7 Use of the Official IRS Seal, IRS Logo, and IRS Endorsed Program Identifiers

#### Manual Transmittal

September 02, 2025

#### Purpose

(1) This transmits revised IRM 1.17.7, _Publishing, Use of the Official IRS Seal, IRS Logo, and IRS Endorsed Program Identifiers_.

#### Material Changes

(1) IRM 1.17.7 - Revised terminology to change “Program Logos and Internal Logos” to “IRS Endorsed Program Identifiers,” which is more accurate terminology.

(2) IRM 1.17.7 - Updated “IRS Design Office” to “IRS Design Services office” throughout.

(3) IRM 1.17.7 - Updated title for Document 12749 throughout to “ONE IRS Design Standards & Guidelines” for accuracy with published product title.

(4) IRM 1.17.7 - Added “ONE” to each reference to published IRS Design Standards & Guidelines to establish consistent and accurate terminology.

(5) IRM 1.17.7 - Added “IRS Design Services office” throughout to each mention of visual information specialists to identify the authorized graphic design support for all IRS published products.

(6) IRM 1.17.7 - Updated “IRS Wayfinding System” to “IRS Wayfinder Identifier system” throughout to establish more accurate terminology.

(7) IRM 1.17.7 - Updated capitalization of “IRS Logo, IRS Seal and IRS Symbol,” and changed terminology throughout to rename “program logos and internal logos” to “IRS Endorsed Program Identifiers” and general references to “logos” to “identifiers” for accuracy.

(8) IRM 1.17.7.1, _Program Scope and Objectives_ \- Reformatted to conform to Internal Controls template.

(9) IRM 1.17.7.1.1(3), _Background_ \- Updated to clarify the historic partnership between C&L and IRS Design Services office in M&P.

(10) IRM 1.17.7.1.1(4), _Background_ \- Revised to more clearly describe Document 12749.

(11) IRM 1.17.7.1.3, _IRS Values_ \- Removed to adhere to DEI requirements. All subsequent subsections are renumbered after removing 1.17.7.1.3.

(12) IRM 1.17.7.1.3, _Terms/Definitions/Acronyms_ \- Updated to include the elements of the IRS Logo.

(13) IRM 1.17.7.1.4, _IRS Design Standards_ \- Renumbered to IRM 1.17.7.2 and added content to identify responsibility for IRS social media content and design.

(14) IRM 1.17.7.1.6, _Enforcement of Standards_ \- Renumbered to IRM 1.17.7.2.2 after reformatting Internal Controls. Also, revised content clarifies the specific subject matter policies and expertise that the IRS Design Services office in M&P provides.

(15) IRM 1.17.7.1.7(2), _Management and Ownership_ \- Renumbered to IRM 1.17.7.2.3(2). Also removed “in partnership with C&L” to accurately identify responsibility for managing the IRS visual design program.

(16) IRM 1.17.7.1.8(4), _Legal Authority_ \- Renumbered to IRM 1.17.7.2.4(4) and added examples of IRS symbols the guidance impacts.

(17) IRM 1.17.7.2.1(1), _IRS Symbol, Logo, and Official Seal_ \- Renumbered to IRM 1.17.7.3.1(1) and revised to clarify personnel authorized to apply design elements to IRS products and identify responsibility for IRS social media content and design.

(18) IRM 1.17.7.2(2), _Required Design Elements_ \- Renumbered to IRM 1.17.7.3(2) and changed “Iconic Shape” to “Iconography” because iconography extends beyond shapes to include a wide range of visual symbols.

(19) IRM 1.17.7.2.1.1(1), _IRS Symbol_ \- Renumbered to IRM 1.17.7.3.1.1(1). Also clarified to clearly identify responsibility for using the IRS Symbol and identify responsibility for IRS social media content and design.

(20) IRM 1.17.7.2.1.2(2), _IRS Logo_ \- Renumbered to IRM 1.17.7.3.1.2(2) and removed reference to plans to incorporate IRS logo in previously excepted products.

(21) IRM 1.17.7.2.1.3, _Official IRS Seal_ \- Renumbered to IRM 1.17.7.3.1.4 after revising Internal Controls and adding new subsection IRS 1.17.7.3.1.3, _IRS Endorsed Program Identifier_.

(22) IRM 1.17.7.2.2(1), _Enforcement of Standards_ \- Added language to include printed and digital published materials.

(23) IRM 1.17.7.2.2(2), _Official U.S. Department of the Treasury Seal and Flag_ \- Renumbered to IRM 1.17.7.3.2(2) and removed contact phone number. We removed all mentions of telephone numbers.

(24) IRM 1.17.7.2.2.1(3), _Official U.S. Department of the Treasury Seal_ \- Renumbered to IRM 1.17.7.3.2.1(3) and replaced the term “equity” with “fairness” to adhere to Diversity, Equity and Inclusion (DEI) executive order requirements.

(25) IRM 1.17.7.2.3(4), _Management and Ownership_ \- Updated to clarify the identifiers M&P owns and manages.

(26) IRM 1.17.7.2.5.1, _Product Identifier Components_ \- Renumbered to IRM 1.17.7.3.5.1 and revised to include how to display the content (in bold).

(27) IRM 1.17.7.2.6(1), _Color System_ \- Renumbered to IRM 1.17.7.3.6(1) and revised content clarifies the color palette guidance outlined in Document 12749, ONE IRS Design Standards & Guidelines.

(28) IRM 1.17.7.2.6.1(2), _External Color Usage Guidelines_ \- Renumbered to IRM 1.17.7.3.6.1(2) and revised content provides additional color palette options and guidance for external published products as outlined in Document 12749, ONE IRS Design Standards & Guidelines.

(29) IRM 1.17.7.2.6.2(3), _Internal Color Usage Guidelines_ \- Renumbered to IRM 1.17.7.3.6.2(3) and removed content to clarify design standards guidelines.

(30) IRM 1.17.7.3.1(2), _IRS Symbol, Logo, and Official Seal_ \- Updated URL to a shorter link and removed telephone number that is no longer in service. We removed all mentions of the telephone number.

(31) IRM 1.17.7.3.1(3), _IRS Symbol, Logo, and Official Seal_ \- Revised content to more clearly explain the strong restriction on logo creation by any entity other than the IRS Design Services Office.

(32) IRM 1.17.7.3.1.2(3), _IRS Logo_ \- Added historical context of IRS Logo creation and revised content to reflect the transition from wayfinding format to a new lock-up configuration.

(33) IRM 1.17.7.3.1.2(4), _IRS Logo_ \- Added content to describe the rationale and goals for the IRS design standards and guidelines and to identify responsibility for IRS social media content and design.

(34) IRM 1.17.7.3.1.2.1, _Components of the Official IRS Logo_ \- Added content to describe the approved components of the official IRS Logo and to identify responsibility for IRS social media content and design.

(35) IRM 1.17.7.3.1.2.2, _IRS Logo Misuse_ \- Added content to provide examples and prohibition of IRS Logo Misuse and to identify responsibility for IRS social media content and design.

(36) IRM 1.17.7.3.1.2.3, _IRS Logo Lockups_ \- Inserted content to describe IRS Logo Lockups and their use. Changed wayfinding to new wording for BOD and program identifiers. Also replaced images of co-branding IRS Logo with another logo in two formats to reflect new lock-up configuration.

(37) IRM 1.17.7.3.1.3, _IRS Endorsed Program Identifier_ \- Added content to describe and define the IRS Endorsed Program Identifier.

(38) IRM 1.17.7.3.1.3.1, _IRS Endorsed Program Identifier Configurations and Proportions_ \- Added content to describe the formatting for IRS Endorsed program identifiers.

(39) IRM 1.17.7.3.4(2), _IRS Wayfinder Identifier System_ \- Updated Figure 1.17.7-7 to reflect the new BOD wayfinder.

(40) IRM 1.17.7.4.6, _Campaign Parameters_\- Revised title to “Urchin Tracking Module (UTM) Parameters,” which is more accurate terminology.

(41) IRM 1.17.7.4.7, _Friendly URLs_ \- Revised to change title from “Friendly” to “Vanity,” which is more accurate terminology.

(42) IRM 1.17.7.4.7(4) and (5), _Friendly URLs_ \- Removed because instructions for requesting friendly URLs has changed.

(43) IRM 1.17.7.4.8, _Quick Response (QR) Codes_ \- Renumbered to IRM 1.17.7.5.8 and updated to replace outdated information.

(44) IRM 1.17.7.4.8.1, _QR Codes Use on Cataloged (Numbered) IRS Published Products_ \- Removed content and Figure 1.17.7-12 because the information about vertical and horizontal directions no longer applies.

(45) IRM 1.17.7.4.8.2, _How the Audience Uses QR Codes_ \- Renumbered to IRM 1.17.7.5.8.1 after removing previous content with that subsection number.

(46) IRM 1.17.7.4.8.3, _Target URLs for QR Codes_ \- Renumbered to IRM 1.17.7.5.8.2 after removing previous IRM 1.17.7.4.8.1.

(47) IRM 1.17.7.4.8.3(2), _Target URLs for QR Codes_ \- Renumbered to IRM 1.17.7.5.8.2(2) and updated to clarify mandatory requirement to encourage customer use of QR codes.

(48) IRM 1.17.7.4.8.4, _QR Code Format_ \- Removed content and previous Figure 1.17.7-13, IRS QR Code Styles, because formatting of QR codes has changed.

(49) IRM 1.17.7.4.8.5, _Creation of QR Codes_ \- Renumbered to IRM 1.17.7.5.8.3 after removing previous sections IRM 1.17.7.4.8.1 and 1.17.7.4.8.4.

(50) IRM 1.17.7.5, _Logos_ \- Renumbered to IRM 1.17.7.6 and renamed to “ _Internal Identifier Requests_.” Also updated content to clarify guidance about prohibiting internal and external logos. Refer also to _IRM 1.17.7.6_, _IRS Endorsed Program Identifiers_.

(51) IRM 1.17.7.5.1, _Endorsed Logos_ \- Renamed to clarify content topic guidance and renumbered to IRM 1.17.7.6.1. Also updated content to reflect guidance on IRS Endorsed Program Identifiers. Changed all mentions of endorsed logos to IRS Endorsed Program Identifiers.

(52) IRM 1.17.7.5.1(4), _IRS Iconic Shapes and Icons_ \- Revised content provides specific reference documentation.

(53) IRM 1.17.7.5.1.1, _Creation or Revision of Endorsed Logos_ \- Renamed to _Creation or Revision of IRS Endorsed Program Identifiers_ and renumbered to IRM 1.17.7.6.1.1. Also updated content to clarify related policies.

(54) IRM 1.17.7.5.1.2, _Approval Process for Endorsed Logos_ \- Renamed to replace “Logos” with “IRS Endorsed Program Identifiers” and renumbered to IRM 1.17.7.6.1.2. Also updated content to reflect current requirements.

(55) IRM 1.17.7.5.2, _Law Enforcement Badge_ \- Renumbered to IRM 1.17.7.6.2 and updated to clarify the distinctions related to CI branding and how to obtain CI graphics and branding.

(56) IRM 1.17.7.5.2(1), _Photography_ \- Added guidance content and removed the term “diversity” to adhere to DEI executive order requirements.

(57) IRM 1.17.7.5.2(5), _Photography_ \- Updated URL to a more “evergreen” format.

(58) IRM 1.17.7.5.3, _Templates_ \- Added content to include details about templates and the restrictions for copying logos or images.

(59) IRM 1.17.7.5.4(2), _Charts and Graphs_ \- Provided content with specific reference documentation.

(60) IRM 1.17.7.5.6(1), _Urchin Tracking Module (UTM) Parameters_ \- Added content to explain what UTM parameters are and why they may benefit a marketing campaign.

(61) IRM 1.17.7.5.6(2), _Urchin Tracking Module (UTM) Parameters_ \- Added a hyperlinked reference to Document 14494 for detailed information on UTM parameters.

(62) IRM 1.17.7.5.7(1), _Vanity URLs_ \- Revised to better explain what Vanity URLs are and why they may be useful.

(63) IRM 1.17.7.5.7(2), _Vanity URLs_ \- Revised to add a hyperlinked reference to Document 14494-A for detailed information on Vanity URLs.

(64) IRM 1.17.7.5.7(3), _Vanity URLs_ \- Removed to delete unnecessary information.

(65) IRM 1.17.7.6, _IRS Website Standards_ \- Renumbered to IRM 1.17.7.7 and revised content to clarify that Media & Publications designs internal IRS websites and Online Services (OLS) designs IRS public-facing websites.

(66) IRM 1.17.7.7, _IRS Television Standards_ \- Renumbered to IRM 1.17.7.8 and renamed to IRS Television and Video Production Standards. Also revised content to provide specific reference documentation.

(67) IRM 1.17.7.8(2), _Taxpayer Assistance Center (TAC) Design Guidelines_ \- Renumbered to IRM 1.17.7.9, and revised content provides specific reference documentation. Also updated URL for the IRS Design Services Office.

(68) IRM 1.17.7.10, _Business Card Design Standards_ \- Renumbered to IRM 1.17.7.11, and revised content provides specific reference documentation.

(69) IRM 1.17.7.12, _Social Media Design Standards_ \- Removed from this IRM and published in IRM 11.1.3, _Communications, Contact with the Public and the Media_. Renumbered subsequent sections after removing 1.17.7.12.

(70) IRM 1.17.7.12, _Requirements for Commercial Design Vendors_\- Renamed to “ _Requirements for External Contractors/Vendors_” and renumbered to IRM 1.17.7.13. Also updated content to reflect more concise guidance for design vendors and revised content to include new Product Identification information and reference to responsibility for IRS social media content and design.

(71) IRM 1.17.7.14, _Independent Organizations within the IRS Design Guidelines_ \- Added content to explain why only two organizations within the IRS have independent design standards representing independent organizations within IRS.

(72) IRM 1.17.7.14, _Frequently Asked Questions (FAQs)_ – Renumbered to IRM 1.17.7.16 after adding new subsections IRM 1.17.7.14, Independent Organizations within the IRS Design Guidelines and IRM 1.17.7.15, IRS Forms Design.

(73) IRM 1.17.7.14, _IRS Forms Design_ \- Renumbered to IRM 1.17.7.15 and added content to describe IRS forms design guidance.

(74) IRM 1.17.7.16, _Frequently Asked Questions (FAQs)_ – Updated all questions to reflect universal changes to titles and URLs.

(75) Made editorial changes throughout this IRM section to update URLs, conform to Plain Writing, and establish consistent and accurate terminology.

(76) Updated this IRM to comply with January 2025 Executive Orders and OPM guidance.

#### Effect on Other Documents

This supersedes IRM 1.17.7, _Publishing, Use of the Official IRS Seal, IRS Logo, Program Logos, and Internal Logos_, dated August 8, 2023.

#### Audience

All IRS employees, contractors, and vendors who design, publish, or distribute print and/or electronic internal/external material funded by appropriations from the IRS budget.

#### Effective Date

(09-02-2025)

William A. Moses

Director, Publishing

Media & Publications Division

**1.17.7.1** **(09-02-2025)**

### Program Scope and Objectives

1. **Purpose.** Publishing’s mission is to plan and produce or procure all IRS print and electronic communications products used by the public to comply with tax filing requirements and obligations and used internally within IRS for tax administration. This section discusses the background, terminology, IRS values, importance and enforcement of standards, management and ownership, and legal authority for use of the Official IRS Symbol, IRS Seal, and IRS Logo, as well as program and internal identifiers.

2. **Audience.**The audience for this IRM is IRS employees Servicewide.

3. **Policy Owner.** The Director of Publishing owns the policies contained herein.

4. **Program Owner.** Taxpayer Services, Customer Assistance Relationships and Education, Media & Publications, Publishing is responsible for the administration, procedures, and updates related to the program.

5. **Primary Stakeholders.** Tax Forms & Publications in Media & Publications, CARE, Taxpayer Services; and Distribution in Media & Publications, CARE, Taxpayer Services; IRS organizations servicewide.

6. **Contact Information.** The Director of Publishing in Media & Publications in CARE, Taxpayer Services.


**1.17.7.1.1** **(09-02-2025)**

#### Background

1. Over the last several decades, the IRS organized and managed various logos and brand images that identified IRS products and services. The last reorganization of the IRS in 1998, mandated by Public Law 105–206, established preliminary standards for creating and using IRS published products. This does not include IRS.gov or other digital application products.

2. When there is a lack of clearly defined standards, the IRS has historically used the Treasury or IRS seals inappropriately by modifying the size, color, shape, content, or purpose of the seal. The IRS Seal and the IRS Logo have occasionally appeared on published products interchangeably and incorrectly.

3. In 2004, the Communications & Liaison (C&L) Executive agreed to serve as the ONE IRS Design Management Project Sponsor - to champion the project at the highest level of the IRS and communicate effectively to IRS executives and key stakeholders. To date, Media & Publications (M&P) and Communications & Liaison (C&L) continue to promote ONE IRS Design Standards to ensure IRS properly addresses the IRS Logo, IRS Seal, and any approved internal IRS Identifiers. The ONE IRS Design Management Project gave the IRS Design Services office ownership and enforcement over management of the IRS Seal, IRS Logo, and any approved IRS identifiers.

4. The Publishing function in M&P created Document 12749, _ONE IRS Design Standards & Guidelines_, to provide uniform and clear IRS visual communication standards for IRS product owners/originators. Document 12749 describes key branding elements and guidelines for use of design, and will help communicate the messages, maintain integrity, and fulfill the mission of IRS design standards.

5. IRM 1.17.7 includes critical design standards identified in Document 12749 and additional standards/guidelines implemented and approved for use by the IRS Design staff and approved stakeholders.

6. This update provides the IRS Design staff and stakeholders with prevailing language that supports IRS design standards and educates users on existing design guidelines and standards for various products used internally and externally.


**1.17.7.1.2** **(09-02-2025)**

#### Authority

1. Publishing’s authority as the official IRS publisher is documented in IRM 1.17.9.6, _Roles and Responsibilities When Publishing a Product_.


**1.17.7.1.3** **(09-02-2025)**

#### Roles and Responsibilities

1. This section explains the graphic design responsibilities associated with being a published product originator and the roles and responsibilities of all involved in the IRS graphic design processes.


**1.17.7.1.4** **(09-02-2025)**

#### Program Management and Review

1. **Program Reports.** Balanced measures for tax and non-tax products.

2. **Program Effectiveness.** The Computer Assisted Publishing System (CAPS) has reporting capabilities that enable management and employees to monitor and track delivery of Publishing products and services.


**1.17.7.1.5** **(09-02-2025)**

#### Program Controls

1. The Computer Assisted Publishing System (CAPS) has reporting capabilities that enable management and employees to monitor and track delivery of Publishing products and services.


**1.17.7.1.6** **(09-02-2025)**

#### Terms/Definitions/Acronyms

1. The terminology included in this section clarifies terms that may not be generally known within the IRS.



**Defined Terms**






| Term | Definition |
| --- | --- |
| Business Operating Division (BOD) | Aligned under the IRS Commissioner, the IRS is divided into business operating divisions. Examples of BODs include: Chief Counsel, Communications & Liaison, Taxpayer Services, and Facilities Management and Security Services. |
| Business Operating Division Entity (BOD Entity) | The official name of any office within a BOD that has a manager and physical location in the executive directory. |
| Contractor | Any non-governmental commercial business that provides goods and services, specifically design-related goods and services, based on a contractual agreement and a structured fee as determined through the Government Publishing Office (GPO). |
| IRS Design Services Office | The only office within the IRS that maintains IRS Design Standards. The IRS Design Services Office is located within the M&P organization and handles the development, creation, and facilitation of graphic design services requested by IRS business operating divisions, organizations, and programs. |
| Design Standards | These set guidelines and requirements for designing all IRS published products used internally and externally. These standards are published in Document 12999, _One Look. One Voice. One IRS_, posted online at https://publish.no.irs.gov/getpdf.cgi?catnum=58057, and provide clear and concise descriptions for how approved IRS Design Services office visual information specialists must apply graphic elements (i.e., color, fonts, images, etc.) used to design a product. |
| Document | A published product intended for internal-use only by IRS employees and identified numerically starting with Document number “5001”. The content is generally for informational or administrative purposes. Documents are not generally distributed to the public. |
| Envelope | A product used to hold or mail other products. We produce envelopes in various standard and customized sizes and customers can order them through the Envelope Program. You can order envelopes online using Form 9880, _FY 2023 Envelope Order_ or Document 9589, _Envelope Ordering Information_, and/or directly from the contractor, through your publishing specialist, using a government purchase card. |
| Form | A product used as a data collection instrument, printed or electronically reproduced, with space for filling in information, descriptive material or addresses. All forms must include instructions for use. Forms are the principal contact between the IRS and taxpayers and are the most frequently used published products by IRS employees. Publishing has the authority to stop the use of any unofficial form or published product that was not produced through M&P. When we identify an unofficial product, Publishing will advise the BOD’s representative to request assistance from Publishing to bring such items into compliance. |
| IRS Logo | The letters forming “IRS” always combined with the eagle symbol. |
| IRS Product Identifier | Product-specific information that includes the product type, revision date, and catalog information (See _Figure@Exhibit 1.17.7-9_, _Product Identifier_). The Product Identifier distinguishes products and versions from one another for ordering and cataloging purposes. All official IRS-sanctioned products must have an IRS Product Identifier and be maintained in Publishing’s Core Repository of Published Products. |
| IRS Seal | The official IRS identification with the words “Internal Revenue Service” and “Treasury” encircling the official shield. The IRS Seal should never appear in conjunction with the IRS Logo. See _Figure@Exhibit 1.17.7-5_, _Official IRS Seal_. |
| IRS Symbol | Also known as the "IRS Eagle." The IRS Symbol is made up of the IRS Eagle alone, not accompanied by the acronym “IRS” in its approved logo fixed positions (See _Figure 1.17.7-1_, _IRS Symbol_). |
| IRS Wayfinder Identifier System | An internal identification system that incorporates the names of the BOD, a horizontal line, and BOD Entity (See _Figure@Exhibit 1.17.7-8_, _IRS Wayfinder Identifier System Configuration Examples_). The Wayfinder Identifier system creates a consistent yet effective way for all IRS offices to identify themselves without the use of individual logos. The IRS Logo appears to the left of the BOD or BOD entity text. Effective January 1, 2010, the IRS Wayfinder Identifier system replaced the use of all logos used to represent a BOD, office program, project, task force, or other entity within a BOD. |
| Letter | Public-use products sent directly to taxpayers. All letters must carry a signature and advise the taxpayer where to direct inquiries (unless a contact stuffer is enclosed). |
| Logo | A graphic mark or emblem commonly used by government agencies, commercial enterprises, private-sector organizations, and individuals to aid and promote instant public recognition. The IRS Logo consists of the IRS Symbol and acronym IRS. See _IRM 1.17.7.3.1_, _IRS Logo_. |
| Media & Publications (M&P) | The M&P office officially manages the IRS Logo, IRS Seal, and all approved IRS Identifiers Servicewide. M&P catalogues the IRS Logo, IRS Seal, and all approved IRS identities to establish a library for approved IRS Design Services office visual information specialists. |
| Notice | A product the IRS sends if it believes a taxpayer owes additional tax, is due a larger refund, or if there is a question about a tax return or a need for additional information. |
| Post | All cataloged published products must be available (posted) for users via the Intranet or Internet. Trained visual information and publishing specialists are authorized to post files to make them electronically available to users. |
| Product | An item produced in electronic or hard copy format and used by external or internal users to request, capture, inform, instruct, or provide information. This does not include IRS.gov or other digital application products. |
| Product Content Owners/Originators | The person within the IRS who requests the creation of a product, provides content for a product, and helps determine the audience for and intent of a product. |
| Publication | A product that is primarily for public use but can also be used by IRS employees. A publication can be either tax or non-tax related. |
| Publish | The act or result of creating a product and making it available to more than one person in print or electronic format.<br> <br>### Note:<br>Only Publishing employees can procure and publish printed products (see IRM 1.17.1.1.1(3)). |
| Publishing Services Request (PSR) | The official electronic request for all IRS publishing and graphic design services. Product content owners/originators can submit a PSR for a service request at https://publish.no.irs.gov/psrl.html. Publishing cannot complete any requests without an approved PSR. |
| Publishing Specialists | Staff that works with the product content owners/originators, IRS Design Services Office, C&L, Distribution, and other internal and external stakeholders to coordinate, procure, and distribute published products. |
| Stakeholder | All individuals and organizations that are actively involved in the completion of a publishing project. Stakeholders consist of internal and external product content owners/originators as well as end users. |
| Treasury Seal | The official seal used on IRS products only when the Department of the Treasury is the primary owner of the content. The seal does not contain the words “Internal Revenue Service.” The Treasury Seal is never used on a single product in conjunction with the IRS Logo or Official IRS Seal. See _Figure@Exhibit 1.17.7-6_, _Official Department of the Treasury Seal_. |
| Visual Information Specialist | A trained graphic designer who is approved to develop and design printed and multimedia products. A IRS Design Services office visual information specialist is the subject-matter expert (SME) for all graphic design inquiries and requests and must be contacted upon the creation, revision, or obsolescence of an IRS design product. The IRS Design Services Office develops qualifications for approved IRS Design Services office visual information specialists. |


**1.17.7.1.7** **(09-02-2025)**

#### Related Resources

1. Document 12687, _Getting Your Information Published at the IRS_

2. Document 12616, _Design Guidelines for IRS Internal and Non-Tax Public Use Forms_

3. IRM 1.17.7, _Use of the Official IRS Seal, IRS Logo, Program Logos and Internal Logos_

4. IRM 1.17.1, _Publishing, Overview of Publishing Authorities, Roles and Responsibilities, and Organizational Structure_


**1.17.7.2** **(10-12-2021)**

### IRS Design Standards

1. The IRS Design Standards ensure that the IRS is clearly identified when an IRS designer uses unique images and typography to draw attention to a product or service. Applying these standards allows the IRS to maintain a consistent appearance in a variety of print and electronic communications. Although all IRS published products must reflect the IRS Design Standards, only approved IRS Design Services office visual information specialists can use and apply the standards to products. The customer, or product content owners/originators, must submit a Publishing Services Request (PSR) to meet with a IRS Design Services office visual information specialist and initiate design services. Document 12999, _One Look. One Voice. One IRS_, provides an overview of the design standards. Information IRS employees need to know about IRS Design Standards is posted online at: https://publish.no.irs.gov/pubsys/design/stand.html.

2. IRS Communications & Liaison’s (C&L) Social Media team defines editorial and design standards for all IRS social media accounts and maintains creative control of all social media content on behalf of the IRS. For information refer to IRM 11.1.3, _Communications, Contact with the Public and the Media_.


**1.17.7.2.1** **(12-11-2012)**

#### Importance of Standards

1. Every IRS written communication presented to internal and external audiences provides an opportunity to affirm and strengthen knowledge and understanding of the unique character and mission of the IRS.

2. The focus of graphic identity is very often a symbol or logo. However, an identity system is much more than the use of a symbol.

3. A comprehensive graphic system is a structure for communicating and presenting information logically, clearly, and cohesively. Adhering to commonly accepted standards is advantageous for the entire IRS and allows the IRS to produce clear and understandable products in both print and electronic format.

4. Implementation of standards develops greater awareness of the IRS and enables the IRS to convey a distinct identity through its products and programs where appropriate.

5. IRS Design Standards increase efficiency to help all stakeholders save time, money, and resources when developing published products.


**1.17.7.2.2** **(09-02-2025)**

#### Enforcement of Standards

1. Anyone producing printed or digital materials for the IRS, including IRS employees, must adhere to the policies in IRM 1.17.7, guidelines in Document 12749, _IRS Design Standards & Guidelines_, as well as other publishing/posting requirements issued by M&P and C&L’s communication policies, tools, and processes. This does not include IRS.gov and its authenticated and unauthenticated applications and products (ex. Individual Online Account, Business Tax Account, Tax Pro Account, Tax Withholding Estimator, Where's my Refund, etc.). See IRM 2.25.101, _IRS.gov Web Content Management Procedures_.

2. M&P will contact any product content owners/originators or owner if a product does not comply with the guidance set forth in IRM 1.17.7. M&P will work with each customer to resolve discrepancies.

3. All IRS employees, contractors, and service providers must abide by all established standards and report any misuse immediately to M&P.

4. M&P has the right to refuse to publish, post, create, design, alter, adjust, fix, or authorize the use of any product that does not comply with the standards set forth in IRM 1.17.7.

5. Failure to comply with or knowingly violate IRS Design Standards, or using the IRS Logo, IRS Seal, or any IRS Identifiers in an unethical way, are subject to any of the legal ramifications denoted in _IRM 1.17.7.2_, _Legal Authority_.


**1.17.7.2.3** **(09-02-2025)**

#### Management and Ownership

1. M&P is the steward of graphic elements for the entire IRS. This stewardship includes the ownership and management of all IRS Design Standards, the IRS Seal, IRS Logo, internal IRS Wayfinder system, endorsed IRS program identifiers, and the law enforcement badge, as well as IRS organizational identities.

2. M&P shares stewardship of the IRS Design Standards with the U.S. Department of the Treasury, and manages the IRS’s visual design program.

3. All official logos and identity variations are cataloged to establish a library of IRS products for use by approved IRS Design Services office visual information specialists.

4. The IRS owns the IRS Seal, IRS Logo, endorsed IRS Endorsed Program Identifiers, and all identifiers using the IRS Wayfinder Identifier system, and the law enforcement badge.


**1.17.7.2.4** **(09-02-2025)**

#### Legal Authority

1. Treasury Directive 73–04 (09–11–2001) requires that appropriate controls be placed on the use of seals and other official insignia of the department and its bureaus.

2. M&P manages and enforces the rules concerning all IRS design standards and guidelines, including logos and identifiers. See Document 12749, _IRS Design Standards & Guidelines_, and Document 12999, _One Look. One Voice. One IRS_, for additional information. IRS.gov-specific design standards are included in IRS Website Design Standards at https://online-design-guide-master-pl.irslabs.org/getting-started.

3. Title 18 USC 701, enacted June 25, 1948, governs the use of IRS seals and insignias. This statute reads as follows: “Whoever manufactures, sells, or possesses any badge, identification card, or other insignia of the design prescribed by the head of any department or agency of the United States for use by any officer or employee thereof, or any colorable imitation thereof, or photographs, prints, or in any other manner makes or executes any engraving, photograph, print, or impression in the likeness of any such badge, identification card, or other insignia, or any colorable imitation thereof, except as authorized under regulations made pursuant to law, must be fined under this title or imprisoned not more than six months, or both.”

4. IRS employees are subject to the Standards of Ethical Conduct at 5 CFR Part 2635.702. The reselling of items bearing the IRS symbols (including the IRS Symbol, IRS Logo, and IRS Seal) to non-IRS personnel, the use of such an item to coerce a benefit, and the use of an item in a way that creates the appearance that the IRS endorses or sanctions a private activity are all examples of employee conduct that would violate the Standards of Ethical Conduct.

5. Seals and devices of the federal government, departments, bureaus, and independent agencies are not in the public domain, and cannot be used for other than official business without specific authorization of the agency involved. Visit the Joint Committee on Printing link for more information: [https://www.hhs.gov/web/policies-and-standards/web-policies/logo-contractors/index.html](https://www.hhs.gov/web/policies-and-standards/web-policies/logo-contractors/index.html).

6. Per 18 U.S. Code, subsection 1017, Whoever fraudulently or wrongfully affixes or impresses the seal of any department or agency of the United States, to or upon any certificate, instrument, commission, document, or paper or with knowledge of its fraudulent character, with wrongful or fraudulent intent, uses, buys, procures, sells, or transfers to another any such certificate, instrument, commission, document, or paper, to which or upon which said seal has been so fraudulently affixed or impressed, shall be fined under this title or imprisoned not more than five years, or both.


**1.17.7.3** **(09-02-2025)**

### Required Design Elements

1. When end-users interact with an IRS product, the IRS has a commitment to ensure that the experience instills trust and consistency. To visually achieve this goal, all products must contain required design elements that support the concept of ONE IRS. These primary design elements include:



   - IRS Symbol, IRS Logo, and IRS Seal

   - Official fonts

   - IRS Wayfinder Identifier system (Optional)

   - Product Identifier

   - Color system


2. To further support the concept of ONE IRS for published products, the IRS Design standards include the following style elements as optional graphic elements to enhance the user’s experience, usability, and comprehension. Optional style elements may originate from:



   - Iconography

   - Photography

   - Templates

   - Charts and Graphs

   - Illustrations


3. Imagery used in this IRM, a published product, or on any website related to IRS Design Standards must not be copied, altered, or in any other way used or reproduced in another published product.


**1.17.7.3.1** **(09-02-2025)**

#### IRS Symbol, IRS Logo, and Official Seal

1. M&P has the right to incorporate all required elements for ONE IRS design compliance on all products submitted to Publishing. Detailed information on the application of such design elements is published in Document 12749, _ONE IRS Design Standards & Guidelines_. C&L’s Social Media team defines editorial and design standards for all IRS social media accounts and maintains creative control of all social media content on behalf of the IRS. For information refer to IRM 11.1.3, _Communications, Contact with the Public and the Media_.

2. Contact the IRS Design Services office at https://publish.no.irs.gov/pubsys/design to work with an approved IRS Design Services office visual information specialist for the proper application of the IRS Symbol, IRS Logo, or IRS Seal.

3. No new development of logos or use of old logos for any IRS staff, work group, program, or business operating division are allowed. The ONE IRS Design Standards & Guidelines accommodate all parties of the IRS to identify themselves using the IRS Wayfinder Identifier system.

4. Policy prohibits use of the IRS Logo, IRS Symbol, and IRS Seal on non-monetary specialty items (Trinkets, gifts, giveaways, mementos, or other tangible products such as pens, mouse pads, mugs, glasses, and lanyards, etc.), for employee recognition, retirement, and/or any other gift whether purchased using IRS funds or purchased using personal funds. The IRS Logo, IRS Symbol, and IRS Seal remain the IRS identities of the IRS with strict usage guidelines for official IRS products only. The IRS Employee Recognition Program is the method and process for creating official work-related awards. For information about the Awards Program, visit: https://irsgov.sharepoint.com/sites/EmployeeResources/SitePages/AwardsRecognition.aspx.


**1.17.7.3.1.1** **(12-11-2012)**

##### IRS Symbol

1. The IRS Symbol, or the IRS Eagle, is the graphic element that represents the IRS. See _Figure 1.17.7-1_, _IRS Symbol_ for additional information. The IRS Symbol may appear without the “IRS” acronym for a specific design purpose and only if applied by an approved IRS Design Services office visual information specialist and other IRS offices with their own professional designers, visual information specialists, web designers, UX designers and other professionally trained visual design discipline positions and should apply such design elements to products in compliance with this IRM and Document 12749, _ONE IRS Design Standards & Guidelines_. C&L’s Social Media team defines editorial and design standards for all IRS social media accounts and maintains creative control of all social media content on behalf of the IRS. For information refer to IRM 11.1.3, _Communications, Contact with the Public and the Media_.



### Note:



The IRS Symbol is a common identity for IRS employees; however, the symbol alone may not be easily recognizable to the taxpayer. The IRS Eagle is describable from its three basic parts.

2. The IRS Eagle itself represents the United States. The scales of justice instill the idea that the IRS’s operations will be conducted in a fair and honest way. The decorative olive branch fills out the left side of the symbol and represents peace and conciliation. Justice, fairness, honesty, peace, and conciliation may be key messages that are reflected in some designs.



**Figure 1.17.7-1**

![This is an Image: 53478001.gif](https://www.irs.gov/pub/xml_bc/53478001.gif)





> IRS SymbolFigure 1.17.7-1 is the IRS Symbol, which is an eagle.







[Please click here for the text description of the image.](https://www.irs.gov/media/129771 "")

3. Contact the IRS Design Services office and work with an approved IRS Design Services office visual information specialist for proper application of the IRS Symbol, IRS Logo, or IRS Seal.


**1.17.7.3.1.2** **(09-02-2025)**

##### IRS Logo

1. The IRS Logo consists of the letters forming “IRS” always combined with the eagle symbol. See _Figure 1.17.7-2_. The IRS Logo must appear on all published products with the following exceptions:



   - Tax forms

   - Tax-related forms



     ### Note:



     Example - Form 23, _Application for Enrollment to Practice Before the Internal Revenue Service_

   - Internal forms

   - Letters

   - IRS letterhead


**Figure 1.17.7-2**

![This is an Image: 53478002.gif](https://www.irs.gov/pub/xml_bc/53478002.gif)

> IRS LogoFigure 1.17.7-2 shows the IRS Logo, which consists of the IRS Eagle with the acronym "IRS" underneath it.

[Please click here for the text description of the image.](https://www.irs.gov/media/129776 "")

2. There is only one official IRS Logo approved by the IRS Commissioner. No new logos for any IRS staff, workgroup, program, or business operating division are allowed. All IRS BODS, sections, and programs must only use the wayfinder system. Contact the IRS Design Services office and work with an approved IRS Design Services office visual information specialist for the proper application of the IRS Symbol, IRS Logo, or IRS Seal.

3. The original IRS Eagle logomark design originated in 1965. The IRS Eagle logomark, commonly referred to as "the eagle" is the cornerstone of the brand identity of the Internal Revenue Service. To date, the commissioner of the IRS, along with all IRS Business Operating Division executives, approved the use of the Official IRS Logo as the only logo to endorse the IRS for internal and external communications. No other logo requests are approved or granted.

4. In supporting the overall philosophy of the ONE IRS Design Standards & Guidelines, all IRS digital and print communications products must reflect the IRS Logo appropriately and in a consistent manner. Also, in accordance and alignment with _Executive Office of the President, M-23-2, 9/22/2023 Memorandum for Heads of Executive Departments and Agencies, Subject: Delivering a Digital-First Public Experience_, adherence to ONE IRS Design Standards & Guidelines includes the following elements:



1. Consistent Visual Design and IRS Brand Identity - Members of the public depend on the federal government for authoritative and trustworthy information and services that they cannot get from any other entity. It is critical that the public knows when they are accessing information from the federal government, using a federal government service, or communicating with someone who represents the federal government. Trust in federal government information and services depends on the public’s ability to distinguish between government and non-governmental entities and information. Clear and consistent use of an agency’s brand identity and the visual design of its websites and digital services helps the public identify official federal government entities, information, and services. This includes consistent and standardized use of everything that comprises the look and feel of an agency’s product or service (such as a logo or seal, color palette, typeface, imagery, voice and tone, or product or service name). Design systems are tools for standardizing and maintaining brand identity and ensuring a consistent look and feel across channels, including websites and digital services.

2. Apply IRS Brand Design Consistently - Agencies should ensure that websites and digital services use appropriate brand identity in a consistent manner, including when an agency uses a third-party website or Web application to communicate. IRS websites and digital services should have a consistent look and feel that is aligned with IRS design and branding guidelines. Agencies should establish internal control processes to ensure that all public-facing websites and digital services are checked for consistency prior to public release. C&L’s Social Media team defines editorial and design standards for all IRS social media accounts and maintains creative control of all social media content on behalf of the IRS. For information refer to IRM 11.1.3, _Communications, Contact with the Public and the Media_.

3. See also IRM 2.25.101, _IRS.gov Web Content Management Procedures_.


**1.17.7.3.1.2.1** **(09-02-2025)**

###### Components of the Official IRS Logo

1. We provide the IRS Eagle for use in two formats—vertical and horizontal. The proportions of logomark to logotype are different within the vertical and horizontal versions, remain constant for each unit, and **_do not_**change in reductions or enlargements.

2. The IRS Logo plays an important role in verifying the authenticity of all printed, digital, electronic, and Web-based IRS visual communications.

3. Never use the IRS Logo as an illustration, as part of an illustration, or partnered with other images, photos, or drawings as artwork/illustration. It is absolutely prohibited for anyone in the IRS or vendor/contractors to apply the IRS Logo in any way other than as the official standalone IRS Logo/Branding with the required proper clear space margins as outlined in the IRS Logo Configuration and Proportions section in Document 12749, _ONE IRS Design Standards & Guidelines_. C&L’s Social Media team defines editorial and design standards for all IRS social media accounts and maintains creative control of all social media content on behalf of the IRS. For information and direction, refer to IRM 11.1.3, _Communications, Contact with the Public and the Media_


**1.17.7.3.1.2.2** **(09-02-2025)**

###### IRS Logo Misuse

1. Consistent and accurate presentation of the IRS Logo reinforces awareness of our brand and ensures the protection of the IRS organization identity. Use of the IRS Logo on printed, digital, Web, electronic or any other means unless following IRM 1.17.7 and the ONE IRS Design Standards & Guidelines in Document 12749 is prohibited. C&L’s Social Media team defines editorial and design standards for all IRS social media accounts and maintains creative control of all social media content on behalf of the IRS. For information and direction, refer to IRM 11.1.3, _Communications, Contact with the Public and the Media_.

2. All IRS BODs must follow these guidelines and standards, and only use the official IRS Logo files according to established ONE IRS Design Standards & Guidelines. There are no exceptions permitting anyone to use the IRS Logo in any other way, including the Do Not list below.

3. Not following the IRS Logo guidelines and doing any one or more of the Abuse of IRS Logo actions listed below undermines the very benefits that consistent branding provides to an organization. It is important for all IRS leadership and employees to preserve the integrity of the IRS Logo.

4. Abuse of the IRS Logo include, but are not limited to:



1. **Do not** use the IRS Logo as an illustration or artwork on any IRS communications



      > - Do not **incorporate** the IRS Logo with other design, images, photos, artwork, text, or anything other elements or visuals.
      >
      >       - Do not **separate** the IRS Logo to combine the IRS Eagle logomark or IRS logotype with other design, images, photos, artwork, text, or any other elements or visuals.
      >
      >       - Do not **incorporate** the IRS logo on other companies’/organization’s packaging, products, merchandise, or any other art, photos, or drawings not originated by the IRS as a visual illustration or visual message used on printed, electronic, Web, or any other communication vehicles.
      >
      >       - Do not **incorporate** the IRS Logo with any other visual elements beyond what is allowed in IRM 1.17.7 and Document 12749.

2. **Do not**alter any elements of the IRS Logo.



      > - Do not **create** new customized visuals that incorporate the IRS logo.
      >
      >       - Do not **subtract, add, crop, or extract** any individual parts of the IRS Logo or only use a portion of the IRS.
      >
      >       - Do not **alter**the IRS Logo’s orientation.
      >
      >       - Do not **use** the IRS Eagle logomark without the IRS logotype.
      >
      >       - Do not **redraw**the IRS Logo in any way.
      >
      >       - Do not **change** the font of the IRS Logo.

3. **Do not**customize the IRS Logo.



      > - Do not **outline, emboss, shade, or tint** the IRS Logo.
      >
      >       - Do not **apply** a drop shadow to the IRS Logo.
      >
      >       - Do not **change** the color of the IRS Logo.
      >
      >       - Do not **add** a texture or material asset to the IRS Logo.
      >
      >       - Do not **animate** individual parts of the IRS Logo.
      >
      >       - Do not **change scale, skew, tilt or rotate** the IRS Logo.
      >
      >       - Do not **change** the arrangement of the IRS Logo.
      >
      >       - Do not **change** the arrangement of the preferred IRS Logo lockup.

4. **Do not**place the IRS Logo improperly.



      > - Do not **place** the IRS Logo where any parts of the IRS Logo is hidden behind another visual, graphic, object, or text.
      >
      >       - Do not **stretch, squeeze, distort, or angle** the IRS Logo.
      >
      >       - Do not **place** the IRS logo on a noisy or busy background.
      >
      >       - Do not **place** the IRS logo on any non-IRS official products, such as other companies/organization’s packaging, bottles, boxes, containers, products, merchandise, or any other art, photos, or drawings not originated by the IRS.


**1.17.7.3.1.2.3** **(09-02-2025)**

###### IRS Logo Lock-Ups

01. The IRS Design Services Office manages versions of our IRS Logo in a lock-up configuration. Only an IRS Design Services Office visual information specialist is permitted to create an IRS Logo Lock-up and provide the file for use. The IRS Logo Lock-up is a combination of both the logotype and a logomark.

02. There is only one official IRS Logo approved by the IRS commissioner and no new logos are allowed. All IRS BODs and programs must only use a lock-up in lieu of a new logo. No new logos for any IRS staff, workgroup, program, or Business Operating Division are allowed. All IRS BODS, sections, and programs must only use the Wayfinder Identifier system. For the sake of maintaining consistency in all mediums, no one should take apart or alter the lock-up.

03. IRS Logo lock-ups follow the same general rules for color, configurations, application, and proportions, as outlined in the IRS Logo, Color and IRS Logo, and Configuration and Proportions sections of the _ONE IRS Design Standards & Guidelines_ Document 12749.

04. Only an IRS Design Services Office visual information specialist is permitted to create a IRS Logo Lock-up and provide the file for use.

05. IRS Logo Lock-ups include:



    - Business Operating Division Wayfinder Identifier (BOD Lock-up)

    - IRS Endorsed Program Identifier (Program Lock-up)

    - Patriotic Identifier (Patriotic Lock-up)

    - Co-branding with External Partnerships (Co-branding Lock-up)


**Figure 1.17.7-3**

![This is an Image: 53478003.gif](https://www.irs.gov/pub/xml_bc/53478003.gif)

> Logo Lock-upsIRS has four Logo Lockups: 1. Business Operating Division Wayfinder Identifier (BOD Lock-up), 2. The IRS Endorsed Program Identifier (Program Lock-up), 3. Patriotic Identifier (Patriotic Lock-up), 4. Co-branding (Partnerships Lock-up) reflecting BOD, Program, Patriotic, and Co-branding identifiers

[Please click here for the text description of the image.](https://www.irs.gov/media/129786 "")

06. Business Operating Division Wayfinder Identifier (BOD Lock-up) - When creating materials for internal communication within the IRS, product originators must follow an established visual system and hierarchy of naming for Business Operating Division (BOD) and BOD Entity to simplify identifying the origin of materials. The IRS Wayfinder lock-up identifier is the solution for ALL new logo inquiries. (NO EXCEPTIONS)

07. The IRS Endorsed Program Identifier (Program Lock-up) - The IRS Endorsed Program Identifier is a high-visibility, non-departmental, non-sectional identifier used for internal and external program communications. These identifiers are reserved for public-facing, high-profile programs such as Electronic-Filing (e-File), Direct File, Electronic Federal Tax Payment System (EFTPS), Continued Education (CE), or Earned Income Tax Credit (EITC). The scope of the IRS Endorsed Program Identifier is intentionally limited and must relate to initiatives with broad implications for the IRS and its public image. Additionally, these identifiers must support programs that provide services or assistance to the general public. Business operating divisions, branches, sections, and organizations are not permitted to continue using existing internal logos or create new logos of any kind. Customers must meet eligibility criteria determined by the IRS Design Services office to use the IRS Endorsed Program Identifier. Those deemed ineligible can still access Wayfinder Identifier options.

08. Patriotic Identifier (Patriotic Lock-up) - We developed patriotic symbols for use in conjunction with the IRS Logo to enhance messaging to the target audience. Patriotic Identifier elements include the U.S. flag, the U.S. map, the heart and the handshake. The US map is appropriate for nationwide programs and initiatives. The heart is appropriate for applications that show appreciation for volunteers. The US flag is appropriate for military materials. The handshake co-branding is appropriate for partnerships, such as materials that support tax preparers. All IRS Logo Lock-ups to create these IRS identifiers must follow the same general rules for color, configurations, application, and proportions as outlined in the _ONE IRS Design Standards & Guidelines_ Document 12749, in the IRS Logo, Color and IRS Logo, and Configuration and Proportions sections.

09. Co-branding with External Partnerships - When there is a need to brand the IRS in conjunction with external organizations, product orginators and partners should use the Co-branding with External Partnerships IRS Logo Lock-up. See Figure 1.17.7-4. There are two approved configurations available for use outlined in the _ONE IRS Design Standards & Guidelines_ Document 12749. Federal agencies or IRS external partnerships should only use one of two IRS approved lock-up configurations available for use. Co-branding IRS Lock-ups follow the same general rules for color, configurations, application, and proportions found in Document 12749, _ONE IRS Design Standards & Guidelines_. Only an IRS Design Services office visual information specialist is permitted to create Co-branding with External Partnerships Lock-ups and provide the file for use.

10. Before proceeding with co-branding on printed and digital materials, obtain approval from external partners to use their logo(s), brand mark(s), or Identity graphics. Follow any agreements in place for guidance on how to use a partner’s logo(s), brand mark(s), or Identity graphic. The partner’s logo(s), brand mark(s), or Identity graphic should adhere to the partner's brand standards. You must obtain a vector file (EPS, PDF, SVG, AI) or high-resolution file of the external partner's logo(s), brand mark(s), or Identity graphics, and NO ONE other than a IRS Design Services office visual information specialist should develop Co-Branding Lock-ups.

11. **Figure 1.17.7-4**

    ![This is an Image: 53478004.gif](https://www.irs.gov/pub/xml_bc/53478004.gif)





    > Co-Branding with External PartnershipsGraphic displays co-branding with images of the IRS and e-file logos either side-by-side or on top and bottom, separated by a line.







    [Please click here for the text description of the image.](https://www.irs.gov/media/129791 "")


**1.17.7.3.1.3** **(09-02-2025)**

##### IRS Endorsed Program Identifier

1. The IRS Endorsed Program Identifier is a high-visibility, non-departmental, non-sectional, non-organizational logo for both internal and external communications. IRS Endorsed Program Identifiers are for public-facing, high profile, and high-level programs such as Electronic-Filing (e-File), Electronic Federal Tax Payment System (EFTPS), Continued Education, (CE) or Earned Income Tax Credit (EITC). The overall scope of the IRS Endorsed Program Identifier is intentionally small in scope and limited in application. The IRS Endorsed Program Identifier is offered in three deliverable formats and colors: bordered, borderless, and with the "Approved IRS Program" tagline (bordered and borderless) and in black, white, and IRS blue.

2. IRS Endorsed Program Identifiers must be related to initiatives with Servicewide implications for the IRS and its public image. In addition, an IRS Endorsed Program Identifier must support an initiative or program that provides a service or assistance to the general-public. Business operating divisions, branches, sections, and organizations may not continue using the old existing internal logos and may not create new logos of any kind.

3. Approved endorsed IRS program Identifiers are set up using the IRS Symbol and are therefore not co-branded alongside the IRS Logo. For more details on the specific approved endorsed IRS Program Identifiers see Document 12749, _ONE IRS Design Standards & Guidelines_, at DesignStandards.


**1.17.7.3.1.3.1** **(09-02-2025)**

###### IRS Endorsed Program Identifier Configurations and Proportions

1. To ensure proper reproduction, all versions of the IRS Endorsed Program Identifier are measured units. The IRS Endorsed Program Identifier is always scaled in proportion, with the smallest usable size allowable for the unit shown to the right.

2. Never reduce the bordered unit below 53 points in height, or the borderless unit to less than 39 points in height. The proportions must remain constant in all applications and never separated or repositioned. The height or width of the entire IRS Program Identifier is scalable according to these guidelines but must respect size minimums and aspect ratios. Internal spacing between individual elements is 6 pt. It is vital to preserve the integrity of the IRS Logo within the IRS Endorsed Program Identifier.


**1.17.7.3.1.4** **(10-15-2015)**

##### Official IRS Seal

1. On January 28, 1968, the U.S. Department of the Treasury issued an executive order pertaining to the use of the IRS Seal for official purposes. This executive order also defined special circumstances warranting the use of the official IRS Seal. Consequently, the official IRS Seal consists of elements similar to the Treasury Seal, as shown in _Figure 1.17.7-5_, _Official IRS Seal_.

2. The IRS Seal may not be used interchangeably with the IRS Logo for the following reasons:



1. The IRS Seal represents the history, tradition, and mission of the IRS.

2. The IRS Seal, like that of many other government agencies, does not have a distinct visual presence and is not immediately identifiable, particularly when reproduced at smaller sizes.


3. The IRS Seal is only used on published products related or pertaining to:



   - Building signage

   - Formal documents, such as graduation from IRS/Treasury sponsored programs, and legal documents

   - Major media and high-profile initiatives

   - IRS letterhead

   - Official communications to the public from the Office of the Commissioner

   - Other official, historical, or ceremonial materials, including retirement certificates


**Figure 1.17.7-5**

![This is an Image: 53478005.gif](https://www.irs.gov/pub/xml_bc/53478005.gif)

> Official IRS SealFigure 1.17.7-5 shows the Official IRS Seal. The Official IRS Seal is circular and has a double ring line around it. The seal contains the word "Treasury" in all capital letters on the top portion and the words "Internal Revenue Service" in all capital letters on the bottom separated by stars between the two department names. Inside is a crest with a chevron and 13 stars inside the chevron. The justice scales are above the chevron and a key is below the chevron within the crest.

[Please click here for the text description of the image.](https://www.irs.gov/media/129796 "")

4. The IRS Seal is based on the U.S. Department of the Treasury Seal. It differs in the surrounding that reads on top, “Treasury,” between two stars, and around the bottom, “Internal Revenue Service.” A description of the U.S. Treasury Seal is in _IRM 1.17.7.3.2_, _Official U.S. Department of the Treasury Seal and Flag_.

5. The Official IRS Seal may not appear on promotional products such as bags, mugs, pens, tee-shirts, or other articles of clothing. Customers must contact the IRS Design Services Office to determine if an item would be acceptable.

6. BODs, divisions, branches, sections, other organizations, and program and project staff may not continue to design, alter, or use their own seals. This prohibition includes using seals that contain elements of the IRS Seal and U.S. Department of the Treasury Seal.

7. The IRS Seal must never appear together on a product that also contains the IRS Logo or Treasury seal.

8. Contact the IRS Design Services Office and work with a IRS Design Services office visual information specialist for the proper application of the IRS Symbol, IRS Logo or IRS Seal.


**1.17.7.3.2** **(09-02-2025)**

#### Official U.S. Department of the Treasury Seal and Flag

1. The U.S. Department of the Treasury has specific requirements for proper use of the Treasury Seal and Flag. Only a IRS Design Services Office visual information specialist may apply design elements to products. Detailed information on the application of design elements is published in Document 12749, _ONE IRS Design Standards & Guidelines_.

2. Contact an IRS Design Services office visual information specialist for the proper application of the Treasury Seal or Flag.


**1.17.7.3.2.1** **(10-15-2015)**

##### Official U.S. Department of the Treasury Seal

1. The Treasury Seal appears on IRS products only if the U.S. Department of the Treasury is the primary owner of the content. For additional information, see _Figure 1.17.7-6_, _Official Department of the Treasury Seal_.

2. The Treasury Seal is comprised of several elements. One element of the Treasury seal is a shield with a chevron of 13 stars representing the original 13 states. The surrounding text reads “The Department of the Treasury 1789.” The balanced scales above the chevron represent justice and fairness in managing federal funds. The key below the chevron signifies the official authority of, and trust in, the Department’s safekeeping of the Nation’s funds. Justice, fairness, authority, and trust may be key messages that are reflected in some designs.

3. Use of the Treasury seal must follow the standards in Document 12749, _ONE IRS Design Standards & Guidelines_.

4. The IRS Seal or IRS Logo may not appear on the same product as the Treasury Seal appears.



**Figure 1.17.7-6**

![This is an Image: 53478006.gif](https://www.irs.gov/pub/xml_bc/53478006.gif)





> Official Department of the Treasury SealFigure 1.17.7-6 shows the Treasury Seal. The Treasury Seal is circular and has a bold ring line around it. The seal contains the words "The Department of the Treasury" in all CAPS on the top portion and the year "1789" on the bottom. Inside is a crest with “Internal Revenue Service" in all capital letters on the bottom, separated by stars between the two department names. Inside is the crest with a chevron and 13 stars inside the chevron. The justice scales are above the chevron, and a key is below the chevron within the crest.







[Please click here for the text description of the image.](https://www.irs.gov/media/441256 "")


**1.17.7.3.2.2** **(10-15-2015)**

##### Official U.S. Department of the Treasury Flag

1. It is Department of the Treasury and IRS policy that the Treasury Flag may fly in reception rooms and lobbies of buildings where Treasury bureaus and offices are the sole occupants. The Treasury Flag must fly, with the United States flag, on buildings or the grounds of buildings where Treasury bureaus and offices are the sole occupants. The Treasury Flag can never appear in print on an IRS product, as the Treasury Flag is used for display only in buildings. Additional guidance on use of the Treasury Flag appears in Treasury Directive 73–03, dated October 30, 2008.



**Figure 1.17.7-7**

![This is an Image: 53478007.gif](https://www.irs.gov/pub/xml_bc/53478007.gif)





> Official Department of the Treasury FlagThe Treasury Flag has a background of Irish green with a shield resting upon an eagle. The eagle holds a scroll in its beak with the words "The Department of the Treasury." The obverse side of the scroll is Old Glory Blue with black shadows, and the letters are white. The reverse side of the scroll is white with dark gray, gray, and light gray shadows. The eagle faces to its right with its claws holding another scroll containing the numerals "1789" in white. The shield background, which is yellow with brown outlines and yellow-orange shadows, contains a chevron of blue crested by 13 white stars. It is flanked by an oak branch on the right and an olive branch on the left. Beneath the chevron is a traditional Treasury key in white with light gray shadows. Above the chevron are balances in white with light gray shadows pivoting upon an old glory blue anchor with the ring at the top. Flags intended for indoor display have a gold fringe.







[Please click here for the text description of the image.](https://www.irs.gov/media/441261 "")


**1.17.7.3.3** **(12-11-2012)**

#### Official Font Usage

1. Official IRS fonts are clearly legible, professional in appearance, and must appear in all print publications to preserve the identity of the organization. Identified standard fonts appear throughout the IRS on various products to provide continuity and consistency in support of the design standards.


**1.17.7.3.3.1** **(08-11-2023)**

##### IRS Standard Fonts

1. Official IRS standard fonts include the Helvetica and Times Roman font families. Times Roman is legible and highly recommended for text-heavy documents or publications.

2. The Times New Roman font is recommended as a substitute for the Times family of fonts in Web use due to its cross-compatibility with different computers.

3. The Arial font is the official sans serif font that may substitute for the Helvetica family of fonts in Web-based applications. You may also use the Public Sans font family for Web-based applications and information. Use the Noto Sans font family when creating multilingual products.

4. The primary IRS typeface is the Helvetica font family.

5. Publishing considers additional fonts for instances when visual impact, differentiation, or variety is desired. Alternate fonts must appear in headlines and prominent copy lines for impact. Never use alternate fonts as a replacement for Helvetica and/or Times in body copy or heavy text.

6. Do not use fonts that look similar to Helvetica and Times.

7. Further information regarding additional font options for IRS is published in Document 12749, _ONE IRS Design Standards & Guidelines_.


**1.17.7.3.4** **(09-02-2025)**

#### IRS Wayfinder Identifier System

1. The IRS Wayfinder Identifier system creates a consistent yet effective way for all IRS offices to identify themselves without the use of individual logos. When creating materials for internal communications, products must follow the Wayfinder Identifier system to simplify the identification of the origin of materials.

2. The Wayfinder Identifier system has two basic configurations, as depicted in _Figure 1.17.7-8_, _Wayfinder Identifier System Configuration Examples_. Configuration A uses only the BOD name. Configuration B includes both the BOD name and BOD entity name.



**Figure 1.17.7-8**

![This is an Image: 53478008.gif](https://www.irs.gov/pub/xml_bc/53478008.gif)





> IRS Wayfinder Identifier System Configuration ExamplesThe IRS Wayfinder Identifier system includes text and other elements that create a consistent, effective way for all IRS offices to identify themselves.







[Please click here for the text description of the image.](https://www.irs.gov/media/129816 "")

3. Published products must adhere to the following typographic guidelines:



   - Never interchange the order and placement of the BOD name and the name of the BOD entity.

   - Never subordinate the BOD to the BOD entities.

   - Never use acronyms.

   - Use ampersands (&) in place of “and” to shorten titles.

   - Keep the punctuation on the top line if an ampersand (&) or slash (/) falls near a line break. Do not begin a line with punctuation.

   - Never break a hyphenated word.

   - Break BOD names of 40 characters or more into two lines when used with a BOD-entity name. Insert line breaks as naturally as possible, with no line exceeding 40 characters.

   - Place the line break for best readability when line breaks are needed.

   - Ensure the line of the sub-organization name is 30 characters or less.

   - Use the guidelines above for inserting line breaks for all names as needed.


4. Colors used for all parts of the IRS Wayfinder Identifier system are black, white, or IRS Blue, the primary IRS color. It is at the discretion of the IRS Design Services office visual information specialist, giving consideration for the design concept, to provide a final color selection.

5. Only approved IRS Design Services office visual information specialists can apply the IRS Wayfinder Identifier system as described above and in Document 12749, _ONE IRS Design Standards & Guidelines_.


**1.17.7.3.4.1** **(08-05-2022)**

##### IRS Historical Internal Logos

1. In 2001, C&L allowed the use of internal slogans and logos to enable IRS divisions to build morale and unit cohesion during the initial phases of operations after modernization. For external purposes; however, the IRS Logo and official IRS Seal were to appear in all cases.

2. The intent was to ensure that the IRS maintained only one external graphic identity. Over time, many internal logos appeared inappropriately on products externally, such as fax cover sheets, presentations, and e-mail signatures. This caused concern about the IRS’s image portrayed to the public.

3. As of January 2010, no internal logos previously used to represent BODs or sub-organizations of the IRS may appear on any print or electronic published products for internal or external use.

4. As described in Document 12749, _ONE IRS Design Standards & Guidelines_, an organization within the IRS may not create or use logos to identify themselves as a BOD, division, branch office, or section. ONE IRS Design Standards prohibit creating, revising, or altering new internal logos for BODs, divisions, branch offices, or sections. No new logos for any IRS staff, workgroup, program, project, new initiative, branch, division, or business operating division are allowed.


**1.17.7.3.5** **(09-02-2025)**

#### Product Identification

1. Product identification must appear on all official IRS products in print and electronic format. The Product Identifier distinguishes products and revisions from one another for cataloging and ordering purposes.

2. The IRS Product Identifier must appear on all:



   - Documents

   - Forms

   - Instructions

   - Internal Revenue Manuals (IRMs)

   - Miscellaneous Products (One-Time Use)

   - Notices

   - Publications

   - Tax Packages

   - Training Products


3. Customers can obtain an official Product Identifier number by submitting a PSR at PSRApp.

4. Both the IRS Logo and Product Identifier must appear on all IRS products.


**1.17.7.3.5.1** **(09-02-2025)**

##### Product Identifier Components

1. The Product Identifier consists of several elements that are typically displayed on products in a single text line. The elements are:



   - Product type

   - Product number

   - Revision date

   - Catalog number

   - The words “Department of the Treasury”

   - The words “Internal Revenue Service” (in bold)

   - The Intranet website address IRS intranet or the external website address [www.irs.gov](https://www.irs.gov/irm/part1/www.irs.gov)

   - Miscellaneous products may carry the requisition number in place of some of the information mentioned above


2. An approved IRS Design Services office visual information specialist places Product Identifiers in a consistent manner on products using graphic design techniques and in accordance with Document 12749, _ONE IRS Design Standards & Guidelines_.

3. Only a IRS Design Services office visual information specialist from the IRS Design Services Office may place or edit Product Identifiers on products.

4. Any other designated official who wishes to place or edit identifiers on products must seek approval from the IRS Design Services Office or the director of the Publishing function.

5. If Publishing approves an exception, then the designated official must provide the IRS Design Services Office with a new file to ensure the proper file management.



**Figure 1.17.7-9**

![This is an Image: 53478009.gif](https://www.irs.gov/pub/xml_bc/53478009.gif)





> Product IdentifierFigure 1.17.7-9 shows two images. The image on the top is the External IRS Product Identifier. The image on the bottom is the Internal IRS Product Identifier.







[Please click here for the text description of the image.](https://www.irs.gov/media/129821 "")


**1.17.7.3.5.2** **(12-11-2012)**

##### External vs. Internal Product Identification

1. External Product Identifiers appear on items created for the public and include the external website address. External products include:



   - Forms

   - Instructions

   - Miscellaneous products

   - Notices

   - Publications

   - Tax packages

   - Tax-related forms


2. Internal Product Identifiers appear on items created to communicate with IRS staff and include the intranet website address. Internal products include:



   - Documents

   - Internal forms

   - Miscellaneous products

   - Training products


**1.17.7.3.5.3** **(10-15-2015)**

##### Product Identification Placement

1. The IRS Product Identifier must appear on the bottom back of a product whenever possible. For one-sided printing, we center the product identifier at the bottom front of a product as shown in Figure 1.17.7-10. Product Identifier placement must follow the guidelines in Document 12749, _ONE IRS Design Standards & Guidelines_, and described in this IRM.



**Figure 1.17.7-10**

![This is an Image: 53478010.gif](https://www.irs.gov/pub/xml_bc/53478010.gif)





> Placement of Old IRS SignatureThe graphic shows example of previously published image that includes the old IRS Signature.







[Please click here for the text description of the image.](https://www.irs.gov/media/129826 "")

2. The IRS Product Identifier must appear on products made from substrates other than paper such as computer disks and packaging. Product content owners/originators may contact the IRS Design Services Office for answers to any questions regarding which non-print products require the use of this identification.

3. For published products created prior to 2009, Publishing must apply a current Product Identifier to any reprints or revisions for that product as time and budgetary constraints allow.


**1.17.7.3.5.4** **(10-15-2015)**

##### IRS Historical Product Identification

1. To view how publications produced by M&P may have used the old IRS Product Identifier or the old IRS Signature, see _Figure 1.17.7-11_. Publishing must update products produced with Product Identifiers prior to 2009 to meet current standards should they be submitted for reprint or revision.



**Figure 1.17.7-11**

![This is an Image: 53478011.gif](https://www.irs.gov/pub/xml_bc/53478011.gif)





> Old IRS Product Identifier and Old IRS SignatureFigure 1.17.7-11 shows two images. The image on the left is the old IRS Product Identifier. The image on the right is the old IRS Signature. The old IRS Product Identifier consists of a one-column, four-row table with line separators at the top and bottom of each row and no side borders. The first row contains the IRS Symbol (eagle) followed by the acronym "IRS". The second row contains the words "Department of the Treasury" stacked with the words "Internal Revenue Service" (bolded). The third row contains the Publishing website "publishing.no.irs.gov". The fourth row contains the word "Document" and the ID number (1234) followed by the revision date (01-2009) stacked with words "Catalog Number" and the product catalog number (12345X). The old IRS Signature consists of a one-column, three-row table with line separators at the top and bottom of each row and no side borders. The first row contains the IRS Symbol (eagle) followed by the acronym "IRS". The second row contains the words "Department of the Treasury" stacked with the words "Internal Revenue Service" (bolded). The third row contains the IRS.gov website "www.irs.gov".







[Please click here for the text description of the image.](https://www.irs.gov/media/129831 "")


**1.17.7.3.6** **(09-02-2025)**

#### Color System

1. The IRS Color System is built around the identifying color pairing of Pantone Matching System (PMS) 301C (IRS Blue) and the accent color, Process Cyan. IRS Blue is widely recognized and associated with the IRS and is the only color (other than black or white) that is acceptable for use in the IRS Logo, Symbol and Wayfinder Identifier system. Only an IRS Design Services office visual information specialist has the authority to apply other colors following the Color Palette guidance outlined in Document 12749, _ONE IRS Design Standards & Guidelines_.

2. Four other color pairs are allowed for use as a secondary color treatment for any business operating division and their offices.

3. A third level of color treatment consists of tonal ranges established from a preset color palette. Selections from the third level can appear in conjunction with IRS Blue or the secondary level of colors at the discretion of the approved IRS Design Services office visual information specialist.


**1.17.7.3.6.1** **(09-02-2025)**

##### External Color Usage Guidelines

1. External color usage is defined as materials and communication that represent the IRS to the public and external partners.

2. The primary identifying colors IRS Blue (PMS 301C) and the accent color Process Cyan or, from the patriotic color palette, PMS 282C and accent PMS 193C, appear on most IRS materials and communications. Only an IRS Design Services office visual information specialist has the authority to apply other colors following the Color Palette guidance outlined in Document 12749, _ONE IRS Design Standards & Guidelines_.

3. Publishing must select, from the full IRS color palette, additional colors that best convey the purpose and message of the material and communication. For more information see Document 12749, _ONE IRS Design Standards & Guidelines_ and Document 13416, _IRS Design Standards Book 2 - Patriotic Branding_.


**1.17.7.3.6.2** **(09-02-2025)**

##### Internal Color Usage Guidelines

1. Internal color usage is defined as the colors used on materials and communications between IRS business operating divisions.

2. The identifying color, PMS 301C blue, and the accent color Process Cyan, may appear in materials and communication for internal use.

3. Additional colors that best convey the purpose and message of the material and communication must be part of the full IRS color palette.

4. Only approved IRS Design Services office visual information specialists can appropriately apply the IRS Color System to published products. Further information regarding the IRS Color System is in Document 12749, _ONE IRS Design Standards & Guidelines_.


**1.17.7.4** **(12-11-2012)**

### Section 508 Compliance

1. Section 508 of the Rehabilitation Act of 1973 requires federal agencies to develop, procure, maintain, or use electronic and information technology to make accessible all information provided to individuals with no disabilities to those with disabilities or impairments.

2. The IRS must ensure that all readers, viewers, and users of IRS products, internally and externally, with disabilities have comparable access to and use of information and data provided to individuals without disabilities, unless an undue burden would be imposed on the IRS.

3. The IRS Design Services Office is not responsible but may assist with identifying when graphic content needs to be made Section 508 compliant. IRS Design Services office visual information specialists, publishing specialists, and the Alternative Media Center will work to make applicable products Section 508 compliant.

4. If any product will be made available to the public through IRS.gov, it must be fully accessible. See IRM 2.25.101.4.4, _IRS.gov Accessibility Standards_ at IRSAccessibilityStandards.


**1.17.7.5** **(12-11-2012)**

### Optional Style Elements

1. To further support the concept of ONE IRS for published products, the ONE IRS Design Standards & Guidelines include the following style elements as optional graphic elements to enhance the user’s experience, usability, and comprehension.

2. Optional style elements are options for use at the IRS Design Services office visual information specialist’s discretion and/or by customer request. Ultimately, the approved IRS Design Services office visual information specialist will determine the appropriateness of use with consideration for existing guidelines and the overall concept of the design.


**1.17.7.5.1** **(09-02-2025)**

#### IRS Iconic Shapes and Icons

1. An iconic shape derived from the outline of the IRS Eagle (Symbol) for use as a graphic element is illustrated below in _Figure 1.17.7-12_. The shape can appear in creative ways such as:



   - A shape independently;

   - A frame for photographs or certain images; or

   - A repeating pattern.


2. The IRS iconic shape cannot serve as a frame or background for:



   - The name of a BOD, division, program, office, project, person, or organization;

   - The acronym for a BOD, division, program, office, project, person, or organization; or

   - The IRS Logo


3. A library of icons uses the iconic shape as a frame for consistency. These icons are universal in nature and can represent any office throughout the IRS. Icons bring an added dimension of illustration to a layout and can help attract attention to any object or element. Icons should clearly support the intended message and should be easily translated and understood.



**Figure 1.17.7-12**

![This is an Image: 53478012.gif](https://www.irs.gov/pub/xml_bc/53478012.gif)





> Examples of IRS Iconic Shape Use as IconsA library of icons that use the iconic shape as frame for consistency. These icons are universal and can be used for any office throughout the IRS.







[Please click here for the text description of the image.](https://www.irs.gov/media/129836 "")

4. Only approved IRS Design Services office visual information specialists can apply the IRS iconic shape as described above. Please consult with a IRS Design Services office visual information specialist for specific usage of IRS iconic shapes as described in Document 12749, _ONE IRS Design Standards & Guidelines_ and Document 12749-A-1, _ONE IRS Design Standards & Guidelines: IRS Icon Creation Design Standards_.


**1.17.7.5.2** **(09-02-2025)**

#### Photography

1. Use clean, uncluttered, graphic photography with bold or monochromatic color whenever possible. Subject matter must emphasize uniqueness, collaboration, innovation, knowledge, thoughtfulness and other key descriptors of the IRS. Lighting must be clean and without heavy shadows for a friendly and engaging look.

2. All photography used in IRS published products must be the sole property of the IRS. Refer to IRM 1.17.8.6, _Copyright and Copyrighted Material_, regarding ownership and copyright concerns.

3. The IRS Design Services office has the right to refuse the use of any photography that has not been legally obtained or is not owned by the IRS.

4. Any photography provided must be high resolution, include the requirements described above, and complement the overall concept of the design. An IRS Design Services office visual information specialist will determine if provided photography is appropriate for use.

5. An IRS employee and, at times, outside vendors must use Form 14483-A, _Model/Photo Release_, posted online at ModelPhotoReleaseForm, to state their acceptance and agreement with the use of their likeness, photos, or images in an IRS product.


**1.17.7.5.3** **(09-02-2025)**

#### Templates

1. IRS standardized templates are available in several easy-to-use product formats (such as PowerPoint and Word) to help the user efficiently create internal miscellaneous materials. The required fonts, colors, and IRS authorized logo are included in each file to ensure a professional and consistent look across a wide range of internal products.

2. Template specifications are outlined in Document 12749, _ONE IRS Design Standards & Guidelines_. Visit the IRS Design website at IRSDesignWebsite for access to the template files.

3. Copying of the IRS Logo and graphics from these templates to use in other products is not permitted.


**1.17.7.5.4** **(09-02-2025)**

#### Charts and Graphs

1. Chart and graph format specifications are outlined in Document 12749, _IRS Design Standards & Guidelines_. Contact the IRS Design Services office for instructions on how IRS Design Services office visual information specialists will format charts and graphs.

2. To maintain clarity and consistency throughout the organization, all charts created for use in IRS materials must follow the format of the examples shown in the IRS design standards and guidelines. Adherence to the color hierarchy and values shown will ensure maximum readability. Please consult with a IRS Design Services office visual information specialist for specific usage, per Document 12749, _ONE IRS Design Standards & Guidelines_ and Document 12749-A-2, _ONE IRS Design Standards & Guidelines: IRS Tables & Graphs_.


**1.17.7.5.5** **(10-15-2015)**

#### Illustrations

1. Illustrations include non-photographic images, sketches, drawings, and clip art, whether created by hand or electronically. Format specifications are outlined in Document 12749, _IRS Design Standards & Guidelines_. Contact the IRS Design Services Office for instructions on how IRS Design Services office visual information specialists will format approved Illustrations.


**1.17.7.5.6** **(09-02-2025)**

#### Urchin Tracking Module (UTM) Parameters

1. UTM parameters (also known as campaign parameters, tracking parameters) is a snippet of text added to the end of the destination URL to track the metrics and performance of a specific marketing campaign.

2. By adding UTM parameters to the destination URLs you use in your marketing campaigns, you can collect information about the overall efficacy of those campaigns, and also better understand where the campaigns are most effective. UTM parameters can contain up to five parameters: campaign, source, medium, content, and term.

3. To learn more about UTM parameters and how they could benefit you, reference Document 14494, _How to Request UTM URLs_ at RequestUTMURLs for additional information.


**1.17.7.5.7** **(09-02-2025)**

#### Vanity URLs

1. A vanity URL (also know as a friendly URL) is a type of custom URL meant not only to be more memorable and readable than a typical URL, but also easier for customers to access and engage with. These custom URLs primarily maximize the impact of their URLs by creating a lasting and strong impression with the customer from the start. A vanity URL looks like a simple URL that is easy to remember. However, it is actually an embedded link that, once clicked, redirects to a more complex, longer URL. For example, “IRS.gov/account” is a vanity URL. When typed into the browser it navigates to [https://www.irs.gov/payments/your-online-account](https://www.irs.gov/payments/online-account-for-individuals).

2. To learn more about Vanity URLs and how they could benefit you, reference Document 14494-A, _How to Request a Vanity URL_, at RequestVanityURL for additional information.


**1.17.7.5.8** **(09-02-2025)**

#### Quick Response (QR) Codes

1. The IRS uses QR codes to expand on the IRS strategic goal of improving service to make voluntary compliance easier and the objective to provide taxpayers with targeted, timely guidance and outreach.

2. IRS Design Services office visual information specialists can guide the product content owners/originators about when and how best to apply QR codes.


**1.17.7.5.8.1** **(09-02-2025)**

##### How the Audience Uses QR Codes

1. Audiences scan the QR code using their smart device, and the stored information in the code directs them to a website, video, text, contact information, and more.

2. QR codes appear on a variety of published products to allow the user to easily access Web content (i.e., a Web page; YouTube video, etc.).



### Note:



Examples of published products include an office poster, a bus shelter ad, a tax publication, or a form.

3. QR codes are most often posted on traditional advertising/marketing media, e.g., print advertisements or collateral, signage, handouts, etc. The codes must be in context with the advertising or marketing promotion, e.g., an EITC bus shelter ad with a QR code linking to [www.irs.gov/eitc](https://www.irs.gov/irm/part1/www.irs.gov/eitc), the target URL for the QR code. The printed product must also reference the target URL. This allows individuals the ability to access the same content using a Web browser.


**1.17.7.5.8.2** **(09-02-2025)**

##### Target URLs for QR Codes

1. Ideally, the target URL should be a mobile-optimized website. A mobile-optimized website recognizes the device you are viewing the site with (i.e., smartphone, tablet, laptop, etc.) and serves up a customized version of the site that works best with the equipment you are using. While it is optimal to have a QR code direct the audience to a mobile-enabled site, the priority should be to direct the audience to the information they can use.

2. The QR code design must incorporate a message encouraging the customer to use the QR code. Messaging similar to “Scan this QR code with your smart device to view more information about EITC online.” is one example of a QR code message.

3. Content at the target URL must be easy to understand and written for the target audience. The entire reason to use a QR code is to connect with individuals first, then provide an easy way to access more details if they choose. If an individual’s first experience with an IRS QR code is too technical (or fails), customers will be less likely to scan another IRS QR code in the future.


**1.17.7.5.8.3** **(08-11-2023)**

##### Creation of QR Codes

1. A IRS Design Services office visual information specialist from the IRS Design Services Office must create all QR codes used on cataloged products. Publishing will create and maintain all QR Codes produced for cataloged products.



1. All QR codes require testing using mobile devices running the iOS, the Android OS, or other applicable software.


**1.17.7.6** **(09-02-2025)**

### Internal Identifier Requests

1. The IRS has one official logo. Logos, unique branding graphics, or any other customized visual identifications are not allowed for or by any IRS BOD or organization. This includes the use of typography, images, graphics, symbols or icons, or anything composed to represent the name of the organization, program, project, or any other component of the IRS.

2. Creation of any internal logos from any level in the IRS is prohibited. Customers seeking internal logos must follow the IRS Wayfinder Identifier system and instead use a BOD identifier, which the IRS Design Services office created for all IRS offices to identify themselves without the use of individual logos. When creating materials for internal communications, products must follow the IRS Wayfinder Identifier system to simplify identification of the origin of materials. See IRM 1.17.7.2.4, IRS Wayfinder Identifier System, for more information.

3. Media & Publications will deny all external logo requests from any level in the IRS organization and will direct requestors to follow the IRS Wayfinder Identifier system using an External Program Identifier created for all IRS offices to identify themselves without the use of individual logos. When creating materials for internal communications, products must follow the IRS Wayfinder Identifier system to simplify the identification of the origin of materials. See _IRM 1.17.7.3.4_, IRS Wayfinder Identifier System, for more information.


**1.17.7.6.1** **(09-02-2025)**

#### IRS Endorsed Program Identifiers

1. The IRS endorsed program identifier is a high-visibility, non-departmental, non-sectional, non-organizational graphic for **external** communications. IRS endorsed program identifiers are for public-facing, high profile, and high-level programs, such as Electronic Filing (e-File), Continued Education (CE), or Earned Income Tax Credit (EITC). The overall scope of the IRS Endorsed Program Identifier is intentionally limited in application. The IRS Endorsed Program Identifier is not to be used by an individual, project team, program or office within IRS that does not meet the criteria above. See

2. Only a IRS Design Services office visual information specialist from the IRS Design Services Office may develop an IRS Endorsed Program Identifier, and only when the request meets the strict IRS Endorsed Program Identifier criteria. Contact the IRS Design Services Office at PublishingWebsite to work with an approved IRS Design Services office visual information specialist for the proper application of the IRS Endorsed Program Identifier.

3. **Figure 1.17.7-13**

![This is an Image: 53478013.gif](https://www.irs.gov/pub/xml_bc/53478013.gif)





> Examples of Endorsed IRS Program IdentifierFigure 1.17.7-13 shows two Endorsed IRS Identifiers. The first Identifier on top is the e-file Identifier. The e-file Identifier contains the words "IRS e-file" with a horizontal lightning bolt acting as the dash between the letter ″e″ and the word "file". The second Identifier is the Electronic Federal Tax Payment System (EFTPS) Identifier. The EFTPS Identifier has a square fading from bottom right to top left corner of the letter E in the acronym EFTPS (next to it in bold) and the words "Electronic Federal Tax Payment System" in a smaller font under the acronym.







[Please click here for the text description of the image.](https://www.irs.gov/media/129841 "")


**1.17.7.6.1.1** **(09-02-2025)**

##### Creation or Revision of IRS Endorsed Program Identifiers

1. M&P’s IRS Design Services Office is the only IRS offices permitted to produce or procure new IRS Endorsed Program Identifiers, and requests are reviewed on a case-by-case basis. M&P’s IRS Design Services Office works collaboratively to ensure that IRS Endorsed Program Identifier development and production adheres to established standards.

2. No other business unit, organization, or entity within the IRS, or third party contracted by the IRS, may design, develop, or produce IRS Endorsed Program Identifiers.

3. If any IRS organization is using any logo other than the ONE IRS Logo, the IRS Wayfinder Identifier System BOD Identifier, or an approved IRS Endorsed Program Identifier, then M&P Publishing will send a memorandum to an executive in the affected business unit requesting immediate discontinued use of said logo, graphic, or branding element.

4. No new logos for any IRS staff, workgroup, program, project, new initiative, branch, division, or business operating division are allowed.


**1.17.7.6.1.2** **(09-02-2025)**

##### Approval Process for IRS Endorsed Program Identifiers

1. If M&P has determined that an IRS endorsed program identifier is warranted, then the associated business unit must follow these approval process steps for new IRS Endorsed Program Identifier external use:



1. Submit a PSR at PSRApplication for graphic design services.

2. If the requested IRS endorsed program identifier is approved, then the requesting office must work closely with the IRS Design Services Office in accordance with the minimum established criteria for a new or revised IRS endorsed program identifier.

3. The design is cataloged and distributed to IRS Design Services office visual information specialists throughout M&P and other IRS organizations based on the IRS standardized format for IRS endorsed program identifiers.


**1.17.7.6.2** **(09-02-2025)**

#### Law Enforcement Badge

1. The Law Enforcement Badge is the identification the Criminal Investigations (CI) division uses. The Law Enforcement Badge incorporates common features of other law enforcement badges and includes an embedded IRS Seal. See _Figure 1.17.7-14_ to view a sample Law Enforcement Badge.

2. CI is the law enforcement division of the IRS. In early 2021, the IRS Commissioner approved a branding identity and set of standards found in Document 13458, _Criminal Investigation Branding Standards_, at CI Branding Standards.

3. The Criminal Investigation Branding Standards establish CI’s control over their branding system, and it describes proper use of and processes for applying CI’s branding elements. Topics covered in the branding standards include, but are not limited to



   - The CI Logo guidelines

   - Pairing the CI Logo with the IRS Logo, as well as other approved internal and external logos.

   - The CI Logo replaces the Special IRS Badge, CI’s approved visual symbol for internal and external products.

   - Approved branding fonts and font replacements.

   - 41 approved CI colors in the primary, secondary, and tertiary color palettes.

   - Standardized design elements that help create a cohesive brand.


:



4. To request the design services for CI products, please fill out and submit Form 13437 at RequestCIDesignServices.

5. All official IRS products (including CI official published products) in hard copy and electronic format must include the IRS Product Identifier, which distinguishes products and revisions from one another for cataloging and ordering purposes. CI customers can obtain an official Product Identifier number by submitting a PSR at PSRApplication.

6. No other business unit or entity in the IRS or Treasury may use the CI Law Enforcement Badge without contacting the IRS Design Services Office and receiving explicit written permission from CI.



**Figure 1.17.7-14**

![This is an Image: 53478014.gif](https://www.irs.gov/pub/xml_bc/53478014.gif)





> Law Enforcement BadgeFigure 1.17.7-14 shows the Law Enforcement Badge worn by Criminal Investigations Special Agents. The badge is gold and shaped like a crest and contains the words "Criminal Investigations" on top followed by the words "Department of the Treasury" in all capital letters. The letters ″U″ and ″S″ are separated by the Official IRS Seal. Below the seal and the letters ″U″ and ″S″ is the text "Special Agent".







[Please click here for the text description of the image.](https://www.irs.gov/media/129846 "")


**1.17.7.6.3** **(12-11-2012)**

#### Affiliated Employee Organizations

1. An affiliated employee organization is an organization that holds or hosts events or meetings on a regular basis for employees of the IRS.

2. Affiliated employee organizations are prohibited from using any of the IRS Logos, Seals, IRS Wayfinder Identifier System, or color palette identities; however, employee organizations may use the letters IRS or spell out “Internal Revenue Service” and reference the IRS in body copy.

3. An affiliated employee organization may design and use their own logo on their own products. Such development is independent from the involvement of the IRS Design Services Office.


**1.17.7.7** **(09-02-2025)**

### IRS Website Standards

1. The IRS’s Online Design Guide standards are only for our public-facing digital services (including IRS.gov and our transactional digital products). These standards do not, generally, apply to IRS Source or other internal systems, which are beyond the OLS purview. All IRS websites, internal and external, should reflect the ONE IRS Design Standards & Guidelines listed in Document 12749 and be designed only by approved IRS Design Services office visual information specialists and OLS web design experts. For more information on IRS public-facing online design guidelines go to: OLSWebDesign. For more information on publishing content to IRS.gov and the associated standards see IRM 2.25.101, _IRS.gov Web Content Management Procedures_.


**1.17.7.7.1** **(10-15-2015)**

#### IRS Web Link

1. Publishing created the IRS Web Link image for IRS partners for placement on their websites to ensure a consistent link identifier to the official IRS website at [https://www.irs.gov](https://www.irs.gov/). Figure 1.17.7-15 depicts the IRS Web Link.

2. The IRS Web Link is only for use on partners’ websites and may never appear on printed materials.

3. Should a partner decide to use the Web widget, the encoded link must correctly connect to the official IRS website at [https://www.irs.gov](https://www.irs.gov/).

4. The IRS partner is not required to use the IRS Web link graphic and may simply use the official IRS website as a text-only reference.

5. A minimum of 10 pixels and a maximum of 20 pixels of clear space must appear around the entire image when placed on a partner’s website. If the Web Link is used on a webpage with any other logos, then the mandatory clear space must be doubled.

6. The IRS Web Link may never be rotated, stretched, distorted, reduced, enlarged, or edited in any way.

7. The IRS Web Link must only appear in the Web-safe color #0066CC. Otherwise, solid black and reversed in white is acceptable.



**Figure 1.17.7-15**

![This is an Image: 53478015.gif](https://www.irs.gov/pub/xml_bc/53478015.gif)





> IRS Web LinkThe IRS Web Link image created for IRS partners for placement on their websites to ensure a consistent link to the official IRS website.







[Please click here for the text description of the image.](https://www.irs.gov/media/441266 "")


**1.17.7.8** **(12-11-2012)**

### IRS Television and Video Production Standards

1. IRS TV and IRS video production should reflect the ONE IRS Design Standards & Guidelines listed in IRM 1.17.7. Please consult with a IRS Design Services office visual information specialist for specific usage, per Document 12749, _ONE IRS Design Services & Guidelines_ and Document 12749-A-8, _ONE IRS Design Standards & Guidelines: IRS TV and Video Production Standards._


**1.17.7.9** **(09-02-2025)**

### Taxpayer Assistance Center (TAC) Design Guidelines

1. The Taxpayer Assistance Centers (TACs) are located in various cities in the United States to serve taxpayers. Publishing creates and prints the many products the TACs use and has set a design standard for the collection of signs, the kiosk interface, and other products used in the office.

2. All TAC signs and product development must comply with specific design standards. Please consult with a IRS Design Services office visual information specialist for specific usage, per Document 12749, _ONE IRS Design Standards & Guidelines_ and Document 12749-A-6, _ONE IRS Design Standards & Guidelines: IRS Taxpayer Assistance Center (TAC)_.

3. For more info on the types and installation of TAC Office signage, refer to IRM 1.4.11.4.3, _Use of Signs/Posters in TACs_.

4. For assistance with applying TAC sign and product design standards and guidelines, contact Publishing's IRS Design Services at PublishingWebsite.


**1.17.7.9.1** **(08-11-2023)**

#### IRS Logo and Taxpayer Assistance Center Identification Text

1. The IRS Logo and the words "Taxpayer Assistance Center" must appear on all publications used in the TACs. When the text, "Taxpayer Assistance Center" is used separately from the logo on a publication (welcome sign, office hours sign, etc.), the IRS Logo can appear by itself in either its vertical or horizontal orientation. The IRS Logo should be proportional to the headline text and may be aligned where appropriate. For detailed specifications on using the IRS Logo and Taxpayer Assistance Center wayfinder, refer to Document 12749, _ONE IRS Design Standards & Guidelines_, on the intranet at IRSDesignStandards. An IRS Design Services office visual information specialist must always apply the IRS Logo and TAC wayfinder to TAC signage and products.


**1.17.7.10** **(10-15-2015)**

### Employee Recognition Award Design Standards

1. The IRS Employee Recognition Program (ERP) is an honorary recognition program established to enhance employee engagement and make the IRS the employer of choice. It provides an exclusive, diverse set of awards at all levels within the organization and standardizes the awards and the criteria on which they are granted.

2. The recognition tools within this program provide an easy and effective way for supervisors, managers, and peers to recognize and reward employees. Business units can use these tools to customize items to meet specific recognition needs. These recognition tools replace award certificates and other recognition items (such as plaques and trophies) that business units typically created. For more details on the program, including eligibility requirements and the nomination process, visit the Awards & Recognition site at IRSAwardsandRecognition.


**1.17.7.11** **(09-02-2025)**

### Business Card Design Standards

1. All IRS business cards must follow specific layout and design formats that use the IRS design standards as well as other requirements issued by M&P. Related design guidelines, as well as other requirements issued by M&P and C&L, are included in Document 12749, _ONE IRS Design Standards & Guidelines_ and Document 12749-A-4, _ONE IRS Design Standards & Guidelines: IRS Business Cards_.


**1.17.7.12** **(10-15-2015)**

### Convention Banner Design Standards

1. The IRS sponsors several annual conventions, such as the IRS Nationwide Tax Forums. IRS representatives also attend tax-related events, targeted to both the taxpayer and internally to IRS employees. For some convention participants, these events may be the only time they encounter a physical IRS presence. Using IRS design standards and guidelines at these events will help create a unified IRS brand, deliver messaging and information clearly, and leave a positive impression.

2. All IRS booth materials share specific design elements as specified in Document 12749, _ONE IRS Design Standards & Guidelines_. These design elements include the use of:



   - The IRS Logo

   - IRS Blue (PMS 301) as the dominant color, and other colors

   - The Wayfinder Identifier Systems (to reference a specific business operating division within the IRS)

   - IRS icons designed by an approved visual information specialist in the IRS Design Services Office

   - Photography with a minimum resolution of 150 dots per inch (dpi).


3. Publishing has developed templates for a standing banner and a three-sided fabric booth display to streamline the design process. These templates are available in multiple visual themes.

4. Contact a visual information specialist in the IRS Design Services Office for assistance in selecting the theme and design process that makes the best use of available space for your display area.


**1.17.7.13** **(09-02-2025)**

### Requirements for External Contractors/Vendors

1. Any external contractor/vendor providing graphic design services for the IRS and developing official IRS published products must obtain and comply with all ONE IRS Design Standards to ensure delivery of high-quality designed products that uphold ONE IRS Design Standards & Guidelines.

2. All IRS employees working with, or intending to work with, an external contractor/vendor providing graphic design services for the IRS and developing official IRS published products must involve the IRS Design Services Office early in the product development process. Submit a Publishing Services Request at PSRApplication at the start of any project. C&L’s Social Media team defines editorial and design standards for all IRS social media accounts and maintains creative control of all social media content on behalf of the IRS. For information and direction, refer to IRM 11.1.3, _Communications, Contact with the Public and the Media_.

3. An IRS Design Services Office visual information specialist must remain actively involved with the entire contract process, including writing the vending contract, during the design and development process, and when necessary to provide resources needed for the contractor/vendor to deliver a product that meets ONE IRS Design Standards, such as:



   - Document 12749, _ONE IRS Design Standards & Guidelines_;

   - Document 12749-A, _ONE IRS Logo and Product Identifier - Reference Guide_; and

   - Document 14533, _Internal Guidance for the Development of Official IRS Published Products by External Contractors/Vendors_

   - Pub 5928, _External Contractors/Vendors Guidance for the Development of Official IRS Published Products_

   - Compliant-ready files for required IRS design elements, colors, and specifications.


4. IRS employees must use Form 14483, _IRS Logo and Identifier Release_, to request permission from the IRS Design Services office to use these graphic elements. A third-party non-IRS employee, such as an external contractor/vendor providing graphic design services for the IRS and developing official IRS published products, must partner with an IRS point of contact who is responsible for the procurement to submit this form. The contractor/vendor’s IRS employee point of contact must ensure that the contractor/vendor providing graphic design services for the IRS and developing official IRS published products adheres to all M&P Publishing requirements and IRS design standards.


**1.17.7.14** **(09-02-2025)**

### Independent Organizations within the IRS Design Guidelines

1. The following two independent organizations within the IRS have an exception to publish their own branding guidelines. Although they are independent organizations within the IRS, they worked in partnership with the IRS Design Services office to define, agree upon, and develop their specific design standards, specifically when ONE IRS visual design elements are being incorporated or altered, such as the IRS Eagle, ONE IRS Logo, IRS Seal, or other official IRS owned design elements. Independent organizations who have developed their own visual design standards are responsible for designing, developing, revising, and enforcing and the overall communication and management within their independent organization. When using the IRS logo and/or producing official IRS published, electronic, digital, and Web products, independent organizations are still held to the same high level of accountability to ONE IRS Design Standards & Guidelines requirements for publishing an official cataloged product, specifically following proper usage guidelines for Product Identifiers and IRS logo as outlined in Document 12749, as are all IRS BODs, divisions, branches, sections, other organizations, and programs and projects within the IRS.



   - Criminal Investigation Branding Standards, Document 13458

   - Taxpayer Advocate Service (TAS) Design


**1.17.7.15** **(09-02-2025)**

### IRS Forms Design

1. The IRS has form design standards and guidelines, for IRS tax forms and internal forms, that covers point sizes, rule weights and what the weights mean, fonts to be used, and other information critical in IRS' efforts to standardize product design. Contact a IRS forms design specialist in M&P for all forms design and development inquiries.



   - Design Guidelines for IRS Internal and Non-Tax Public Use Forms, Document 12616

   - Design Guidelines for Tax Forms Document 13463


**1.17.7.16** **(09-02-2025)**

### Frequently Asked Questions (FAQs)

1. **Question**: Can I or anyone else have access to graphical elements, such as the IRS Eagle, approved seals, fonts, color palettes, IRS BOD identifier, and product identifier files? And can I apply these elements to IRS published products? **Answer**: Only an approved IRS Design Services office visual information specialist or approved outside design contractor/vendor can. If the IRS point of contact needs to send files to a design vendor, they must consult with the IRS Design Services Office for the approved files and process.

2. **Question**: Can I create an internal logo for my office, my team, or my project? **Answer**: No. Please use the BOD Wayfinder Identifier system standards. For more information visit the BOD Wayfinder Identifier system at [https://irsgov.sharepoint.com/sit es/SHOTSMainSite/\_layouts/15/stream.aspx?id=%2Fsites%2FSHOTSMainSite%2FSHOTs%20Videos%2FPublishing%20Services%2FDesign%20Services%2FDesign%20Services%20%2D%20Wayfinder%2Emp4&referrer=StreamWebApp%2EWeb&referrerScenario=AddressBarCopied%2Eview](https://irsgov.sharepoint.com/sit%20es/SHOTSMainSite/_layouts/15/stream.aspx?id=%2Fsites%2FSHOTSMainSite%2FSHOTs%20Videos%2FPublishing%20Services%2FDesign%20Services%2FDesign%20Services%20%2D%20Wayfinder%2Emp4&referrer=StreamWebApp%2EWeb&referrerScenario=AddressBarCopied%2Eview). Also review section _IRM 1.17.7.3.1_ of this IRM.

3. **Question**: I already have desktop publishing software on my computer. Can I create my own graphics and logos for published products? **Answer**: The IRS graphic elements approved for use were specifically designed to meet the technical and visual needs of the organization. Only an approved IRS Design Services office visual information specialist or approved outside design contractor/vendor can create graphics. The IRS Design Services office must approve logos prior to use.

4. **Question**: What information do I need to start a design request of a published product? **Answer**: Submit a Publishing Services Request (PSR) at PSRApplication and include the following essential information to ensure that the designed message is clear and effective for the end-user: message and content to be conveyed with product, type of product requested, target audience for product, and proposed usage. C&L should review content with widespread impact for taxpayers and/or employees, and content must adhere to Plain Writing standards. Refer to Document 12687, _Getting Your Information Published at the IRS_, for specific guidance.

5. **Question**: What is a creative brief and how is it used? **Answer**: A creative brief is a document that serves as a guide for a design project and can include objectives, messages to convey, tone, target audience, mandatory elements, timeline, and budget. The IRS Design Services Office uses the brief to develop design deliverables.

6. **Question**: Who are my M&P points of contact for:



   - General design and publishing questions - **Answer**: Publishing specialists (PublishingSpecialistList)

   - Specific design questions - **Answer**: IRS Design Services Office (IRSDesignServicesOffice)

   - Procurement or print production - **Answer**: Publishing specialists (PublishingSpecialistList)


7. **Question**. Am I able to use the IRS Logo on non-monetary specialty items (Trinkets, gifts, giveaways, mementos, or other tangible products such as pens, mouse pads, mugs, glasses, and lanyards, etc.), for employee recognition, retirement and/or any other gift? **Answer**. No. Policy prohibits use of the IRS Logo, symbol, and seal on trinket items purchased using IRS funds nor items purchased using personal funds. The IRS Logo, IRS Symbol, and IRS Seal remain the identities of the IRS with strict usage guidelines for official IRS products only. The IRS Awards Program is the method and process for creating official work-related awards. For information about the IRS Awards Program, visit: IRSAwardsProgram.

8. **Question**. Can the IRS Design Services Office edit my Word templates? **Answer**. No. The IRS Design Services Office provides Design Word templates at DesignWordTemplates for your use on (non-published) internal products. You must be able to use Word. The IRS Design Services Office staff will not edit your Word documents that you created with these templates.

9. **Question**. Can I turn my PowerPoint presentation into an official published product, a book, or a publication as-is? **Answer**. No. PowerPoint is not an industry standard publishing software. Please submit a Publishing Services Request (PSR) at PSRApplication and a visual information specialist from the IRS Design Services office will partner with you to design, develop, and publish professional IRS products.


**1.17.7.17** **(07-27-2020)**

### Resources

1. Further IRS Design Standards information is available in:



   - Document 12999, _One Look. One Voice. One IRS_ \- Information IRS employees need to know about IRS Design Standards

   - Online information is posted at: IRSDesignStandards


### Note:

Only an IRS Design Services office visual information specialist should apply these design elements.

2. You may direct questions to the IRS Design Services office section chief at IRSDesignServicesOffice.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-017-007#addtoany "Show all")

A2A