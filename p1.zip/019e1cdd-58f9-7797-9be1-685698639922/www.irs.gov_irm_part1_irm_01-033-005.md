---
url: "https://www.irs.gov/irm/part1/irm_01-033-005"
title: "1.33.5 Managerial Costing | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-033-005#main-content)

- 1.33.5  [Managerial Costing](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050096763584)
  - 1.33.5.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050131226528)
    - 1.33.5.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050131223344)
    - 1.33.5.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050131218096)
    - 1.33.5.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050097560848)
      - 1.33.5.1.3.1  [CFO and Deputy CFO](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050097556208)
      - 1.33.5.1.3.2  [Associate CFO and Deputy Associate CFO for Corporate Budget](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050097554624)
      - 1.33.5.1.3.3  [Cost and User Fees Office](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050097550672)
      - 1.33.5.1.3.4  [Financial Management Systems Office](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050097705936)
      - 1.33.5.1.3.5  [Financial Reporting and Analysis Office](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050097704176)
      - 1.33.5.1.3.6  [Business Units](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050097702432)
    - 1.33.5.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050097696000)
    - 1.33.5.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050097692416)
    - 1.33.5.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050097687520)
    - 1.33.5.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050099343632)
    - 1.33.5.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050099329440)
    - 1.33.5.1.9  [Cost versus Budget](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050099320176)
  - 1.33.5.2  [Cost Accounting Standards](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050099309280)
    - 1.33.5.2.1  [Requirement for Cost Accounting](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050099305024)
    - 1.33.5.2.2  [Responsibility Segments](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050099299616)
    - 1.33.5.2.3  [Full Cost Recognition](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050099289408)
      - 1.33.5.2.3.1  [Direct Costs](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050099286512)
      - 1.33.5.2.3.2  [Indirect Costs](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050099279328)
    - 1.33.5.2.4  [Inter-entity Costs Recognition](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050099265248)
    - 1.33.5.2.5  [Cost Allocation Methodologies](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050099260592)
      - 1.33.5.2.5.1  [Selection of a Costing Assignment Technique](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050099257072)
      - 1.33.5.2.5.2  [Assessment Cycles in the Integrated Financial System](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050099245792)
      - 1.33.5.2.5.3  [Calculating Cost Outside of the Cost Module](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050098811328)
  - 1.33.5.3  [Overhead Rate](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050098808976)
  - 1.33.5.4  [Cost Reporting](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050098805888)
    - 1.33.5.4.1  [Internal Users](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050098803536)
      - 1.33.5.4.1.1  [Preparation of Internal Cost Reports](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050098799456)
      - 1.33.5.4.1.2  [Cost Reporting](https://www.irs.gov/irm/part1/irm_01-033-005#idm140050098797488)

# Part 1. Organization, Finance, and Management

# Chapter 33. Strategic Planning, Budgeting and Performance Management Process

# Section 5. Managerial Costing

* * *

## 1.33.5 Managerial Costing

#### Manual Transmittal

October 18, 2024

#### Purpose

(1) This transmits new IRM 1.33.5, Strategic Planning, Budgeting and Performance Management Process, Managerial Costing.

#### Material Changes

(1) IRM 1.33.5.2.2 (4)(a), W&I updated with Taxpayer Services.

#### Effect on Other Documents

IRM 1.33.5, dated October 19, 2023, is superseded.

#### Audience

Business unit finance offices and employees responsible for managing programs and cost activities.

#### Effective Date

(10-18-2024)

Teresa R. Hunter

Chief Financial Officer

**1.33.5.1** **(10-19-2023)**

### Program Scope and Objectives

1. Purpose: To provide policies and procedures for cost recognition, managerial costing methods and reporting.

2. Audience: Business unit and finance staff

3. Policy Owner: CFO

4. Program Owner: Cost and User Fees office

5. Primary Stakeholders: IRS and business units finance community

6. Program Goals: To ensure internal controls are implemented and assist offices in applying managerial costing policies.


**1.33.5.1.1** **(10-19-2023)**

#### Background

1. The CFO Act of 1990 requires agency officers to develop and maintain an integrated agency accounting and financial management system, including financial reporting and internal controls for reporting cost information. In October 1990, the Secretary of the Treasury, the director of the Office of Management and Budget (OMB) and the Comptroller General established the Federal Accounting Standards Advisory Board (FASAB) by a memorandum of understanding (MOU). The FASAB is responsible for promulgating the government’s accounting standards. These standards are recognized as generally accepted accounting principles (GAAP) for the federal government.

2. In July 1995, FASAB issued Statement of Federal Financial Accounting Standards (SFFAS) 4, Managerial Cost Accounting Standards and Concepts. This statement contains the concepts and standards for accumulating, calculating and reporting internal cost data.

3. In April 1995, FASAB issued Statement of Federal Financial Accounting Concepts (SFFAC) 2, Entity and Display, which describes the items that should be included in federal financial reports. OMB Circular A-136, Financial Reporting Requirements, establishes federal financial reporting guidance for executive branch departments, agencies and entities required to submit audited financial statements, interim financial reports and performance and accountability reports (PAR) or agency financial reports (AFR).

4. In May 2018, FASAB issued SFFAS 55, Amending Inter-Entity Cost Provisions. This statement revised Interpretation 6, Accounting for Imputed Intra-Departmental Costs: An Interpretation of SFFAS 4, and rescinded SFFAS 30, Inter-Entity Cost Implementation. Revised SFFAS 4 provides for the continued recognition of significant inter-entity costs by business-type activities.


**1.33.5.1.2** **(10-19-2023)**

#### Authorities

1. The authorities for this IRM include:



1. [Chief Financial Officers Act of 1990,](https://www.congress.gov/bill/101st-congress/house-bill/5687) Pub. L. No. 101-576

2. [The Government Management Reform Act of 1994,](https://www.congress.gov/bill/103rd-congress/senate-bill/2170) Pub. L. No. 103-356

3. [Federal Financial Management Improvement Act of 1996 (FFMIA),](https://www.congress.gov/bill/104th-congress/house-bill/4319) Pub. L. No. 104-208

4. [Government Performance and Results Modernization Act of 2010,](https://www.congress.gov/bill/111th-congress/house-bill/2142) Pub. L. No. 111-352, which amended the Government Performance and Results Act of 1993 (GPRA), Pub. L. No. 103-62


**1.33.5.1.3** **(10-19-2023)**

#### Responsibilities

1. This section provides responsibilities for the:



1. CFO and Deputy CFO

2. Associate CFO and Deputy Associate CFO for Corporate Budget

3. Cost and User Fees office

4. Financial Management Systems office

5. Financial Reporting and Analysis office

6. Business units


**1.33.5.1.3.1** **(10-19-2023)**

##### CFO and Deputy CFO

1. The CFO and Deputy CFO oversee policies and controls for managerial costing.


**1.33.5.1.3.2** **(10-19-2023)**

##### Associate CFO and Deputy Associate CFO for Corporate Budget

1. The Associate CFO and Deputy Associate CFO for Corporate Budget are responsible for:



1. Ensuring policies, procedures, standards and controls for managerial costing are in place.

2. Overseeing and monitoring financial management system operations.

3. Providing financial systems modernization development support.

4. Ensuring system integrity and compliance with managerial costing standards and internal controls.


**1.33.5.1.3.3** **(10-19-2023)**

##### Cost and User Fees Office

1. The Cost and User Fees office is responsible for:



1. Managing the Managerial Costing program and compliance with applicable authorities.

2. Developing, communicating and updating costing policies.

3. Providing agency corporate overhead rate annually.

4. Coordinating the development of cost reporting with the business units and reviewing their costing allocation methods.

5. Developing and maintaining cost-based performance measures.

6. Overseeing the Cost Section operations, developing procedures for internal controls, segregation of duties, and documenting supervisory reviews.


**1.33.5.1.3.4** **(10-19-2023)**

##### Financial Management Systems Office

1. The Financial Management Systems office is responsible for managing administrative financial systems application security, providing quality assurance and support for critical Integrated Financial System (IFS) operations and maintenance activities.


**1.33.5.1.3.5** **(10-19-2023)**

##### Financial Reporting and Analysis Office

1. The Financial Reporting and Analysis office is responsible for preparing the audited financial statements.


**1.33.5.1.3.6** **(10-19-2023)**

##### Business Units

1. The business units are responsible for:



1. Implementing and maintaining their managerial costing program.

2. Setting guidelines to identify direct labor and benefits for application of the corporate overhead rate.

3. Recording and reporting costs timely and properly in IFS.

4. Implementing periodic reviews of cost accounting data in IFS for accuracy.

5. Ensuring cost data aligns with current organizational structure, programs, projects and activities.

6. Defining, measuring and quantifying outputs for their responsibly segments.

7. Identifying cost benefit analysis activities that can be aligned with outputs and collaborating with the Cost and User Fees office in developing and updating cost products.

8. Informing the Cost and User Fees office of organizational changes that may affect their cost allocations.

9. Reviewing secondary cost allocation methodologies with the Cost and User Fees office annually and obtaining approval from their management for significant changes.


**1.33.5.1.4** **(10-19-2023)**

#### Program Management and Review

1. Program reports are used for collecting and measuring data needed for the program objective and include:



1. Assessment cycles for secondary cost allocations

2. Internal control processes for financial assurance control testing


2. Program effectiveness is measured monthly after assessment cycles are completed and cost is fully allocated to the operational divisions.


**1.33.5.1.5** **(10-19-2023)**

#### Program Controls

1. The following controls are in place to ensure proper costing:



1. Business units obtain the necessary level of approval and propose allocation methodology changes to the Cost and User Fees office.

2. The Cost and User Fees office validates that allocation and organizational changes are accurately entered into IFS and reviews the results.

3. Accountants use a password protected report that is reviewed and approved as a mechanism to control the monthly cost allocation process and ensure the accuracy of cycle execution.

4. Separate roles and responsibilities are established for preparers, reviewers and approvers.

5. Reports are saved on a shared-drive with access limited to users with the appropriate job requirements.


**1.33.5.1.6** **(10-19-2023)**

#### Terms/Definitions

1. The following terms and definitions apply to this program.



01. **Allocation** \- A process that reassigns costs to cost centers that use resources from other cost centers that incurred the costs.

02. **Assessment cycles** \- The order of execution in which certain costs are allocated to programs. Assignment cycles follow a step process and some cycles use the results of previous assessment cycles.

03. **Causal relationship** \- A connection between two activities where the cost of one activity changes or affects the cost of another activity.

04. **Corporate overhead rate** \- The rate calculated annually by the Cost and User Fees office and applied to directly identified labor and benefits to determine the full cost of providing goods or services.

05. **Costs** \- The monetary value of resources used in performing activities, or in acquiring or producing goods and services.

06. **Cost assignment** \- A process that associates costs with activities, products or services. Costs can be assigned to processes, programs and business units using direct tracing, cause-and-effect and allocation methods.

07. **Cost center**\- An IFS data element used to represent a clearly defined location where costs are incurred. A cost center represents the lowest level in the organizational hierarchy and is usually linked to a Treasury Integrated Management Information System (TIMIS) code for labor expenses. Cost centers can also be established for non-labor expenses.

08. **Cost element** \- A classification of the type of expense incurred.

09. **Cost driver** \- The basis used to allocate the costs of financial resources. Examples of cost drivers include square footage, number of full-time equivalents (FTEs), service calls answered, tax cases closed and labor dollars.

10. **Cost-effectiveness** \- The economic benefit of producing good results without spending a lot of financial resources.

11. **Cost object** \- A product, service or activity where costs are accumulated or measured. A cost object can be a customer, product or a group of employees that benefit from work activities.

12. **Direct costs** \- Costs incurred directly by programs due to their budget execution. These include salaries, benefits, consulting, materials, supplies, etc.

13. **Efficiency** \- A performance measure that associates outputs to inputs and is often expressed by the output cost per unit.

14. **Fiscal year** \- A twelve-month period used by an organization for budgeting, accounting and financial reporting. The federal government’s fiscal year begins on October 1 and ends on September 30.

15. **Full cost** \- All costs used in generating activities, products and services, including direct, indirect and imputed costs.

16. **Functional area** \- An IFS data element that represents an activity, such as submission processing or field examination.

17. **Imputed costs** \- Unreimbursed costs required to be recognized by accounting standards.

18. **Indirect costs** \- Costs of resources that are jointly or commonly used and cannot be reasonably identified and charged to a specific activity.

19. **Inter-entity costs** \- Cost of benefits, goods and services received by the IRS from other federal agencies, bureaus or departments.

20. **Integrated Financial System (IFS)** \- The IRS’s administrative accounting system. IFS has four modules: budget control system (BCS), materials management (MM), financial accounting (FI) and controlling (CO).

21. **Integrated Financial System Procurement for Public Sector (IFS/PPS)** \- The IRS’s procurement system that provides a way to create, input and track requisitions. This includes requesting, funding, awarding orders, performing receipt and acceptance, accruing liabilities and processing payments.

22. **Inter-entity costs**\- Costs for post employee benefits received from OPM including employees’ pensions, and health and life insurance benefits for separated employees

23. **Internal order code (IOC)** \- An IFS data element that collects cost and revenue data for a specific project or activity in IFS.

24. **Intra-departmental costs**\- Financial services received from Treasury including payments and collections made by the Bureau of the Fiscal Service on behalf of the IRS.

25. **Intra-entity cost assignments** \- The cost of supporting services and intermediate products assigned among IRS business units.

26. **Managerial costing** \- The process of recording, recognizing, measuring, analyzing, interpreting and communicating cost information.

27. **Outputs** \- The products or services generated from the use of resources. Outputs are measured in units. Examples include tax returns processed, phone calls answered, IT tickets processed and cases closed.

28. **Primary cost element** \- An account in the IFS CO module that has a corresponding general ledger account for expenses posted to a cost center for its operating budget.

29. **Program or program area** \- A group of similar activities in support of the IRS’s main strategic goals.

30. **Responsibility segment** \- A significant IRS component that carries out a mission, performs services or produces goods, and can be clearly distinguished from other segments.

31. **Secondary cost element** \- Elements used only in the IFS CO module for internal costing allocation of indirect expenses. They represent categories of expenses that are independent from external or financial reporting requirements.

32. **Support costs** \- The costs incurred by Appeals, Chief Counsel and TAS and allocated to operational units that work directly with taxpayers.

33. **Sustaining costs** \- The costs incurred by business units that support IRS Servicewide operations.


**1.33.5.1.7** **(10-19-2023)**

#### Acronyms

1. The following acronyms apply to this program.




| **Acronyms** |
| :-: |
| FASAB | Federal Accounting Standards Advisory Board |
| FM | Funds Management |
| FTE | Full Time Equivalent |
| GAAP | Generally Accepted Accounting Principles |
| GAO | U.S. Government Accountability Office |
| IFS | Integrated Financial System |
| IFS CO | IFS Cost for Customers |
| OMB | Office of Management and Budget |
| SFFAC | Statement of Federal Financial Accounting Concepts |
| SFFAS | Statement of Federal Financial Accounting Standards |


**1.33.5.1.8** **(10-19-2023)**

#### Related Resources

1. The related resources for this IRM include:



1. [FASAB, SFFAC 1,](https://fasab.gov/accounting-standards/document-by-chapter/) Objectives of Federal Financial Reporting

2. [FASAB, SFFAC 2,](https://fasab.gov/accounting-standards/document-by-chapter/) Entity and Display

3. [FASAB, SFFAS 4,](https://fasab.gov/accounting-standards/document-by-chapter/) Managerial Cost Accounting Concepts and Standards for the Federal Government

4. [FASAB, SFFAS 55,](https://fasab.gov/accounting-standards/document-by-chapter/) Amending Inter-Entity Cost Provisions

5. [OMB Circular A-11,](https://obamawhitehouse.archives.gov/omb/circulars_a11_current_year_a11_toc/) Preparation, Submission and Execution of the Budget

6. [OMB Circular A-136,](https://obamawhitehouse.archives.gov/omb/circulars_default) Financial Reporting Requirements

7. [Cost Estimating and Assessment Guide: Best Practices for Developing and Managing Program Costs \| U.S. GAO,](https://gaoinnovations.gov/cost-guide) GAO Cost Estimating and Assessment Guide


**1.33.5.1.9** **(10-19-2023)**

#### Cost versus Budget

1. The IRS uses cost information, as required by [SFFAS 4: Managerial Cost Accounting Standards and Concepts](https://fasab.gov/accounting-standards/document-by-chapter/), to report the cost of activities, programs and services to internal and external stakeholders. It is also used in analyzing and evaluating operating performance, supporting decision-making when allocating resources and modifying programs.

2. Managerial costing follows GAAP and records costs using the accrual method of accounting.

3. The IFS integrates several modules to collect financial transactions. Cost data is recorded under the IFS CO module. Costs are recorded when expenses are paid or accrued without regard to the fiscal year when the obligations, commitments and disbursements happened. The CO module also includes imputed costs, depreciation, amortization and costs allocated to programs using costing methods.

4. The CO module is used for:



1. Reporting cost analysis of programs and services to report to internal management, Congress, Treasury, OMB, TIGTA and GAO.

2. Reporting the cost of user fees and trust funds.

3. Determining the corporate overhead rate.

4. Calculating cost benefit analyses and cost-based performance measures for products, services and activities.

5. Reporting on savings from discontinuing programs or activities.


5. Budgetary accounting focuses on inputs and outlays for the year and expenditures are generally recorded using the cash method of accounting.

6. Funds management data for budgeting purposes is recorded in the FM module. The FM module contains obligations, commitments and disbursements for the current budget period. It does not contain imputed costs, depreciation and amortization. The FM module also includes the unit cost rates (UCRs), the 3-Year Rolling Forecast (3YRF) and the status of available funds (SOAF). The budget expenditures are aligned by funding responsibilities.

7. Refer to IRM 1.33.4, Financial Operating Guidelines, for the use of budget data and authorities.

8. Refer to Key Budget Tools for the Unit Cost Rate (UCR) Calculator to estimate the cost of initiatives

9. Refer to IRM 1.33.3, Reimbursable Operating Guidelines, for reimbursable agreements policies.


**1.33.5.2** **(10-19-2023)**

### Cost Accounting Standards

1. The IRS follows the standards established in [SFFAS 4, Managerial Cost Accounting Standards and Concepts](https://fasab.gov/accounting-standards/document-by-chapter/), for recording and reporting costs. The standards are:



1. Requirement for managerial costing

2. Responsibility segments

3. Full cost recognition

4. Inter-entity costs recognition

5. Cost allocation methodologies


**1.33.5.2.1** **(10-19-2023)**

#### Requirement for Cost Accounting

1. The standard requires the IRS to establish accounting procedures and processes to accumulate and report costs regularly and consistently.

2. Business units and finance offices are required to:



1. Follow guidelines issued by CFO and their finance offices to record costs timely, accurately and systematically to the correct budgeted resources.

2. Use the Financial Management Code Handbook, published by Corporate Budget, to determine the finance codes and internal order structure for proper recording and reporting of cost for the fiscal year.

3. Use TIMIS to update their organizational structure to record labor and non-labor cost to the correct cost center, spending and allotment office, and financial plan.

4. Coordinate with CFO, HCO and their finance offices to determine the correct accounting string to be used in traveling, timekeeping, procurement, and other financial systems that interface with IFS.

5. Use the correct internal order code to track the cost of projects and activities and monitor cost charged regularly.


**1.33.5.2.2** **(10-18-2024)**

#### Responsibility Segments

1. This standard requires the IRS to define and establish responsibility segments. The IRS records costs by organizational structure, lines of responsibilities and mission, products and services delivered, budget accounts and funding authorities.

2. The purpose of segmentation is to:



1. Determine and report the costs of products, services and activities that each segment delivers.

2. Facilitate cost control and management.

3. Compare costs across different responsibility segments.

4. Optimize the use of IRS’s resources.

5. Facilitate comparison of financial and non-financial data for performance measures.


3. A responsibility segment represents a group of business unit functional areas responsible for providing a specific category of services to taxpayers.

4. Cost segmentation is based on the business units’ financial plans. For purpose of managing, allocating and reporting costs, the business units are organized under three major cost categories.



1. **Operational:** Units that provide taxpayer assistance and education, filing and accounting service, and compliance activities, and that administer tax credit programs. These units are CI, LB&I, SB/SE, TE/GE and Taxpayer Services.

2. **Support:** Top level units that mainly support operational units in providing goods and services to the public. These units are Appeals, Chief Counsel and TAS.

3. **Agency sustaining:**Units or offices that provide Servicewide products, services and activities. These are FMSS, C&L, CFO, HCO, PGLD, IT, and Executive Leadership and Direction.


**1.33.5.2.3** **(10-19-2023)**

#### Full Cost Recognition

1. This standard requires the IRS to recognize the full costs, direct and indirect, of responsibility segments, products, services and activities.

2. Full cost reporting is required for managing and establishing reimbursable activities, implementing user fees, and developing internal reports and cost studies.

3. The Cost and User Fees office maintains a detailed flow chart of the methodology used to allocate direct and indirect costs to responsibility segments. Refer to the Cycle Run-Order Methodology.


**1.33.5.2.3.1** **(10-19-2023)**

##### Direct Costs

1. Direct costs are expenses that can be directly traced to a program, activity, product or service. Direct costs generally result from the business units executing their budgets and include:



1. Salaries and other benefits for employees that work directly on products, services and activities.

2. Materials, and supplies used in outputs including postage and printing.

3. Travel, relocation and training.

4. Consulting.

5. Enforcement expenses.

6. Automated data processing (ADP) or IT.

7. Equipment and facilities.

8. Imputed costs for goods or services received from other government agencies.

9. Rent is traceable to business units and office space and generally is allocated as a secondary cost.


2. Costs for specific products and services are treated as direct costs when the cost can readily be identified.

3. Direct costs are recorded to general ledger accounts that correspond to budget and commitment line items.


**1.33.5.2.3.2** **(10-19-2023)**

##### Indirect Costs

1. Indirect costs are sustaining and support costs allocated to other business units. High-level costs allocated within operational and support units is also considered indirect costs. In general, indirect costs are resources used by two or more business units, cross-functional or centralized processes and include:



1. General management and administration

2. Rent, security, utilities and maintenance

3. Procurement and contracting

4. Financial management and accounting

5. Information technology

6. Research, analytical and statistical

7. Human resources and personnel


2. Indirect costs are recorded and allocated periodically in IFS by the Cost and User Fees Cost Section in collaboration with the business units. Secondary costs are allocated in IFS through cost assessment cycles to secondary costs elements that represent expense categories that do not correspond to general ledger accounts or budget line items.



1. See Financial Management Code Handbook CO-1 tab for listing of secondary cost elements.

2. See Financial Management Code Handbook CO-2 tab for the Assessment Cycle Run-Order Methodology


3. **Agency sustaining costs** represent the costs of centralized, Servicewide operations provided by CFO, C&L, Executive Leadership and Direction, FMSS, HCO, IT, PGLD.



1. Agency sustaining costs can either be directly assigned or allocated to other business units.

2. When sustaining costs cannot directly be assigned, causal relationships are used to allocate costs.

3. Causal relationships assign resource costs to the support business unit’s activities and services and then assign those costs to the operating units that consume the services.

4. Sustaining costs are allocated to products and services using pro-rata allocations when establishing a causal relationship is not possible.

5. Pro-rata allocations use cost drives including FTEs, square footage, on-rolls head counts or business unit direct costs.

6. Business units can also group costs into pools with similar characteristics for cost allocations.

7. Cost drivers and methodologies need to be consistent throughout the year to facilitate cost comparisons.


4. **Support costs** represents the costs of Appeals, Chief Counsel and TAS. These business units provide services that mainly benefit taxpayers and the public. These costs are allocated only to operational business units using a causal relationship or pro-rata distribution. The cost allocation drivers are determined by the business units and are similar to the drivers used for allocation of agency sustaining costs


**1.33.5.2.4** **(10-19-2023)**

#### Inter-entity Costs Recognition

1. This standard requires the IRS to recognize the full cost of services from other federal agencies even when the IRS is not required to reimburse the other agency.

2. The Financial Reporting and Analysis office, in collaboration with the business units, works with other agencies to obtain the necessary information for the IRS to record imputed costs.

3. Business unit's full cost includes the full cost of goods and services received from other federal agencies regardless of the source of funding.

4. The IRS records imputed costs using the financial data provided by the agency providing the services or by reasonable estimates when data is not available.

5. The IRS recognizes intra-departmental and inter-entity costs.

6. Recognition of imputed costs is limited to identifiable; material amounts that are a reasonable integral or necessary part of the IRS’s products or services.


**1.33.5.2.5** **(10-19-2023)**

#### Cost Allocation Methodologies

1. The purpose of this standard is to establish principles for selecting a costing allocation methodology (or methodologies) in the following order of preference:



1. Tracing costs directly wherever economically feasible

2. Assigning costs on a cause-and-effect basis

3. Allocating costs on a reasonable and consistent basis


**1.33.5.2.5.1** **(10-19-2023)**

##### Selection of a Costing Assignment Technique

1. The Cost and User Fees office works with the business units to select the most appropriate cost accounting technique for their unit’s activities, types of resources, products and services. Business units can select to allocate their costs using:



1. Direct tracing

2. Cause-and-effect

3. Pro-rata


2. Business units are required to select techniques that are reasonable, consistent and based on the best data available using the following cost drivers:



01. Square footage

02. Statistical figures

03. Labor dollars

04. Number of FTE

05. Employee head count

06. Calculated percentages

07. Hours charged

08. Cases closed

09. Calls answered

10. Returns processed


3. **Changes in Allocations and Costing Methods:**Allocation methods may be revised during the fiscal year. The materiality of the change determines the levels of approval and may include:



1. Business unit finance

2. Cost and User Fees office


**1.33.5.2.5.2** **(10-19-2023)**

##### Assessment Cycles in the Integrated Financial System

1. IFS cost assessment cycles allocate sustaining and support costs that have not been assigned by direct tracing methods. An assessment cycle run identifies the type of expense, allocation method and cost drivers. The main assessment cycles are:



1. Rent, building costs, high level finance, and technology to all business units.

2. Shared services support and other agency sustaining costs to support and operational units.

3. Support costs to operational units.

4. Administrative costs within each support and operational unit.


2. Transfer of costs occurs at the lowest cost center level and the IFS CO module uses primary and secondary cost elements to reclassify costs among units. See also _IRM 1.33.5.2.3.2,_ Indirect Costs.


**1.33.5.2.5.3** **(08-24-2021)**

##### Calculating Cost Outside of the Cost Module

1. The Cost and User Fees office calculates the corporate overhead rate annually. The rate calculation is based on cost accounting data from the latest audited financial statement data and is calculated by dividing indirect costs by direct costs

2. When indirect costs are not identifiable in IFS, the overhead rate is applied to directly identified labor and benefits to arrive at full cost.


**1.33.5.3** **(10-19-2023)**

### Overhead Rate

1. The overhead rate includes indirect costs which are the costs of resources that are jointly or commonly consumed by two or more business units but are not specifically identifiable to a single product or service.

2. Indirect costs include cost for sustaining divisions that support Servicewide operations.


**1.33.5.4** **(10-19-2023)**

### Cost Reporting

1. [SFFAC 1, Objectives of Federal Financial Reporting](https://fasab.gov/accounting-standards/document-by-chapter/), states that information about operating performance, including the costs of programs and outputs and outcomes achieved, is an essential element of financial reports. managerial costing provides information for internal users, including financial accounting, budgetary accounting, and operational/program management. managerial costing also provides information for external users, including financial auditors, OMB, Treasury and Congress. See also _IRM 1.33.5.1.9,_ Cost versus Budget.


**1.33.5.4.1** **(10-19-2023)**

#### Internal Users

1. Cost information communicated outside of the IRS must be reviewed by the CFO Cost and User Fees office to ensure its accuracy and appropriate disclosures.

2. Internal cost reporting should be tailored specifically to meet management's needs. The form and content of internal cost reports prepared for each business unit should provide full cost information to program managers.

3. When cost accounting reports are used to justify budget requirements, imputed costs and inter-entity costs should be excluded. When preparing internal reports such as cost-based performance measurers, imputed costs should be included in the report to arrive at full cost, but it should be footnoted as a disclosure.

4. The Enforcement Revenue Information System (ERIS) is the system of record when using enforcement revenue as a factor in performing calculations and analyses. The Cost and User Fees office obtains the annual Total Enforcement Revenue Collected (TERC) file from Research, Applied Analytics & Statistics (RAAS) that includes revenue collection for major program categories. ERIS is the data source for the TERC file.


**1.33.5.4.1.1** **(10-19-2023)**

##### Preparation of Internal Cost Reports

1. Custodial funds not related to the IRS appropriated budget or non-appropriated revenues are accounted for in IFS and excluded when performing cost analysis. These funds include the Highway Trust Fund, Health Insurance Reform Implementation Fund and the Judgment Fund. The Cost and User Fees office maintains a fiscal year listing of trust fund exclusions.


**1.33.5.4.1.2** **(10-19-2023)**

##### Cost Reporting

1. Cost-based performance measures, commonly referred to as cost studies, are completed annually for the IRS’s major examination and collection enforcement programs in collaboration with frontline program management and RAAS. A cost study is a cost-benefit analysis that is part of the IRS programs’ accounting practices.

2. A cost-benefit analysis considers only one program at a time and compares the monetary costs and benefits (enforcement revenue) of a program. The outcome measures of the studies are collections/cost ratio, cost per dollar of tax collected and cost per case worked by the program.

3. A cost-benefit analysis will not determine if a program is having a significant net effect on desired outcomes. Tax compliance or economic values, other than cost, must be analyzed in determining program efficiencies and policy choices.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-033-005#addtoany "Show all")

A2A