---
url: "https://www.irs.gov/irm/part1/irm_01-017-001"
title: "1.17.1 Overview of Publishing Authorities, Roles and Responsibilities, and Organizational Structure | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-017-001#main-content)

- 1.17.1  [Overview of Publishing Authorities, Roles and Responsibilities, and Organizational Structure](https://www.irs.gov/irm/part1/irm_01-017-001#id1)
  - 1.17.1.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-017-001#id2)
    - 1.17.1.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-017-001#id3)
    - 1.17.1.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-017-001#id4)
    - 1.17.1.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-017-001#id5)
      - 1.17.1.1.3.1  [Responsibilities of Executive Heads of Office](https://www.irs.gov/irm/part1/irm_01-017-001#id7)
    - 1.17.1.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-017-001#id8)
    - 1.17.1.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-017-001#id9)
    - 1.17.1.1.6  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-017-001#id10)
    - 1.17.1.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-017-001#id11)
  - 1.17.1.2  [Organizational Structure and Functions](https://www.irs.gov/irm/part1/irm_01-017-001#id12)
    - 1.17.1.2.1  [Organizational Overviews](https://www.irs.gov/irm/part1/irm_01-017-001#id14)

# Part 1. Organization, Finance, and Management

# Chapter 17. Publishing

# Section 1. Overview of Publishing Authorities, Roles and Responsibilities, and Organizational Structure

* * *

## 1.17.1 Overview of Publishing Authorities, Roles and Responsibilities, and Organizational Structure

#### Manual Transmittal

August 27, 2025

#### Purpose

(1) This transmits revised IRM 1.17.1, _Publishing - Overview of Publishing Authorities, Roles and Responsibilities, and Organizational Structure_.

#### Material Changes

(1) Updated to incorporate Internal Controls information per IRM 1.11.2.2.4(4).

(2) Updated to reflect new program owner/Publishing director in Signature.

#### Effect on Other Documents

This supersedes IRM 1.17.1 dated September 26, 2024.

#### Audience

All IRS employees, contractors, and vendors who design, publish, or distribute print and/or electronic internal/external material.

#### Effective Date

(08-27-2025)

Tracey Quamie

Director, Publishing

Media & Publications Division

**1.17.1.1** **(08-27-2025)**

### Program Scope and Objectives

1. **Purpose**: Publishing’s mission is to plan and produce or procure all IRS print and electronic communications products used by the public to comply with tax filing requirements and obligations and used internally within IRS for tax administration.

2. **Audience**: The audience for this IRM is IRS employees Servicewide.

3. **Policy Owner**: The Director of Publishing owns the policies contained herein.

4. **Program Owner.** Taxpayer Services (TS), Customer Assistance Relationships and Education (CARE), Media & Publications (M&P), Publishing is responsible for the administration, procedures, and updates related to the program.

5. **Primary Stakeholders.** Tax Forms & Publications (TF&P) in M&P, CARE, TS; Chief Financial Officer of the IRS; Distribution in M&P, CARE, TS; IRS organizations servicewide. In M&P, the TF&P and Distribution functions are areas that these procedures affect that have input to the procedures. The effects may include a change in workflow, additional duties, changes in established time frames, and similar issues.

6. **Contact Information.** The Director of Publishing in M&P in CARE, TS.

7. **Program Goals**: Publishing’s authority encompasses integrated design, technical specification writing, production planning, acquisition and delivery/distribution coordination, to provide the highest quality products and services. We use all available print, electronic and accessible media and technology to accomplish this mission.


**1.17.1.1.1** **(08-27-2025)**

#### Background

1. Publishing’s mission is to plan and produce or procure all IRS print and electronic communications products used by the public to comply with tax filing requirements and obligations and used internally within the IRS for tax administration. The Publishing function (also known as "Publishing" ) under Media & Publications (M&P) within Taxpayer Services develops and delivers published products in electronic, paper, and other alternative formats for internal (employees) and external (taxpayers) use.


**1.17.1.1.2** **(08-27-2025)**

#### Authority

1. This documents Publishing’s authority as the official IRS Publisher. United States Code (USC) Title 44 states that the U.S. Government Publishing Office (GPO) is to perform all printing, binding, and blank-book work for the Federal Government. In addition, USC Title 44 grants the Congressional Joint Committee on Printing (JCP) the authority to regulate printing, duplicating, and distribution of products by Federal Government agencies, including the IRS.

2. The JCP publishes regulations for the Federal Government to ensure compliance with the law. Only the JCP has authority to allow exceptions to the Government Printing and Binding Regulations.

3. Government Printing and Binding Regulations require heads of department-level agencies of the Federal Government to maintain under their direct supervision a central printing and publications management organization. This authority at the Department of Treasury is vested in its Printing and Graphics Division, which is responsible for the management of the Treasury-wide printing program. The Director, Printing and Graphics Division, represents the Department of Treasury on matters submitted to the JCP, and oversees the related regulations for Treasury bureaus and agencies through the following policies:



   - Treasury Directive (TD) 78-01 delegates the authority for central printing and publications management for the IRS to the IRS Commissioner.

   - TD 78-02 delegates the authority of the bureau’s copy management program to the IRS Commissioner.

   - The authority for central printing and publications management and the copy management program for all functions and Business Operating Divisions of the IRS falls under the authority of the Commissioner, Taxpayer Services (TS) and is assigned to the M&P Publishing function. M&P Publishing is the only organization authorized to produce or procure printing and publishing services for the IRS. The IRS Office of Procurement is not authorized to procure printing or publishing services.

   - See IRM 1.1.13, _Organization and Staffing - Taxpayer Services_, for more information on TS's organizational structure.


**1.17.1.1.3** **(07-13-2023)**

#### Roles and Responsibilities

1. The M&P Publishing function:



   - Designs and maintains the Service’s publishing programs and systems.

   - Produces or procures all Servicewide print and electronic communications products for dissemination.

   - Serves as the liaison with the Department of Treasury’s Printing and Graphics Division on matters covered under Congressional JCP administration.

   - Approves or denies requests for color copiers (specialty) and high-speed (more than 100 impressions per minute) black and white copiers prior to the procurement process. Requests for regular-speed black and white copiers or multifunctional devices that scan, print, or fax fall under the Information Technology organization.

   - Coordinates the procurement of digital copying services.

   - Partners with internal and external stakeholders to communicate and distribute informational and instructional products to appropriate audiences.

   - The IRS Design office in Publishing is the authority for overseeing and managing all IRS visual design elements, including the use, placement and guidance of the IRS logo and seal and all visual branding elements within IRS.


**1.17.1.1.3.1** **(07-13-2023)**

##### Responsibilities of Executive Heads of Office

1. Each operating division commissioner and other executive head of office must determine printing and publishing needs of their respective areas including the following:



   - Make sure printing and publishing activity is legal and necessary and contains only matters relating to government business (See USC Title 44).

   - Incorporate agency style, format, and graphics standards.

   - Ensure that content submitted conforms to Plain Writing standards.

   - Use established publishing standards, including appropriate regulations, product numbering, Section 508 compliance, and lead times.

   - Obtain required tax form product clearances from Tax Forms & Publications.

   - Notify Publishing of any research affecting printed products, to avoid program delays and duplication.

   - Include Publishing in plans for joint publications with other agencies.

   - Obtain production of items through the appropriate Publishing office.

   - Use a suitable national item before creating new products for local use.

   - Ensure that locally created items are developed within the framework of nationally prescribed practices and standards.

   - Identify and classify sensitive material requiring handling as either "Controlled Unclassified Information" (CUI), "Limited Official Use" (LOU), "Official Use Only" (OUO), or “Personally Identifiable Information” (PII).

   - Ensure that services obtained through IRS Procurement do not include printing and copying services, unless approved before-hand by the Publishing director.


**1.17.1.1.4** **(09-26-2024)**

#### Program Management and Review

1. **Program Reports.** Balanced measures for tax and non-tax products.

2. **Program Effectiveness.** The Computer Assisted Publishing System (CAPS) has reporting capabilities that enable management and employees to monitor and track delivery of Publishing products and services.


**1.17.1.1.5** **(09-26-2024)**

#### Program Controls

1. CAPS has reporting capabilities that enable management and employees to monitor and track delivery of Publishing products and services.


**1.17.1.1.6** **(08-27-2025)**

#### Terms and Acronyms

1. This IRM section uses the following terms and acronyms to describe the involved processes and resources.



**Defined Terms**






| Term | Definition |
| --- | --- |
| Form | A product with spaces to store information. |
| Product | An item produced for any audience that requires cataloging and revision control to ensure proper usage and context of IRS published content. |
| Publish | Producing products intended for use or reading by persons inside (employees) or outside (public/customers) of the IRS. |
| Service | Something done on behalf of others. |







**Acronyms**






| Acronym | Definition |
| --- | --- |
| CAPS | Computer Assisted Publishing System |
| GPO | Government Publishing Office |


**1.17.1.1.7** **(09-26-2024)**

#### Related Resources

1. Document 12687, _Getting Your Information Published at the IRS_

2. Document 12616, _Design Guidelines for IRS Internal and Non-Tax Public Use Forms_

3. IRM 1.17.7, _Use of the Official IRS Seal, IRS Logo, Program Logos and Internal Logos_

4. IRM 1.17.1, _Publishing, Overview of Publishing Authorities, Roles and Responsibilities, and Organizational Structure_

5. IRM 22.31.1, _Multilingual Initiatives, IRS Language Services_

6. IRM 1.17.2, _Publishing - Publishing Systems and Programs_

7. IRM 1.17.3, _Publishing - Tax Products Program_

8. IRM 1.17.10, _Publishing - IRS Published Product Identification_


**1.17.1.2** **(07-13-2023)**

### Organizational Structure and Functions

1. The Director of Publishing reports directly to the M&P Director.

2. The following managers report to the Publishing Director:



   - Chief, E-Publishing Branch

   - Chief, Tax Products Branch

   - Chief, Publishing Services Branch

   - Chief, Strategic Planning and Analysis Branch


**1.17.1.2.1** **(07-12-2019)**

#### Organizational Overviews

1. Strategic Planning & Analysis:



   - Provides program management expertise to ensure that Publishing accomplishes its mission; and

   - Provides oversight of business practices, information systems, and reporting of infrastructure support over Publishing's annual budget, all hiring and personnel actions, technical systems management, training, and reporting responsibilities.


2. E-Publishing Branch:



   - Provides oversight of specialized electronic publishing, the electronic composition of tax products, and agencywide design services and standards for all print and electronic products; and

   - Consists of the IRS Design Office, Electronic Composition, and Content Services sections.


3. Tax Products Branch:



   - Provides publishing support for all tax products required by the IRS;

   - Manages coordination of the design, composition, acquisition, or production and dissemination of all tax product lines, including electronic media as well as hard-copy printing; and

   - Provides internal and external support for all substitute tax forms and schedules filed with the IRS and other government agencies, that software developers and form designers reproduced.


4. Publishing Services Branch:



   - Provides publishing support for all internal and tax-related/nontax-related products for the IRS; and

   - Manages coordination of the design, composition, acquisition, or production and dissemination of all non-tax product lines, including electronic media and hard-copy printing.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-017-001#addtoany "Show all")

A2A