---
url: "https://www.irs.gov/irm/part1/irm_01-057-001"
title: "1.57.1 FMSS Quality Assurance Programs | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-057-001#main-content)

- 1.57.1  [FMSS Quality Assurance Programs](https://www.irs.gov/irm/part1/irm_01-057-001#idm140073925186384)
  - 1.57.1.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-057-001#idm140073953705360)
    - 1.57.1.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-057-001#idm140073953698880)
    - 1.57.1.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-057-001#idm140073953692592)
    - 1.57.1.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-057-001#idm140073953677040)
    - 1.57.1.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-057-001#idm140073953785424)
    - 1.57.1.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-057-001#idm140073953772224)
    - 1.57.1.1.6  [Terms/Definitions/Acronyms](https://www.irs.gov/irm/part1/irm_01-057-001#idm140073953767152)
    - 1.57.1.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-057-001#idm140073953717728)
  - 1.57.1.2  [Improvement Focused QAR Projects](https://www.irs.gov/irm/part1/irm_01-057-001#idm140073953709344)
    - 1.57.1.2.1  [Improvement Focused QAR Project - Conducting Discovery](https://www.irs.gov/irm/part1/irm_01-057-001#idm140073958619536)
    - 1.57.1.2.2  [Improvement Focused QAR Project - Developing and Proposing Solutions](https://www.irs.gov/irm/part1/irm_01-057-001#idm140073958614576)
    - 1.57.1.2.3  [Improvement Focused QAR Project - Evaluating Solutions](https://www.irs.gov/irm/part1/irm_01-057-001#idm140073958610160)
    - 1.57.1.2.4  [Improvement Focused QAR Project - Oversight](https://www.irs.gov/irm/part1/irm_01-057-001#idm140073958607312)
  - 1.57.1.3  [Monitoring Focused QAR Projects](https://www.irs.gov/irm/part1/irm_01-057-001#idm140073958602960)
    - 1.57.1.3.1  [Monitoring Focused QAR Project - Planning](https://www.irs.gov/irm/part1/irm_01-057-001#idm140073958599296)
    - 1.57.1.3.2  [Monitoring Focused QAR Project - Testing and Reporting Results](https://www.irs.gov/irm/part1/irm_01-057-001#idm140073958596112)
    - 1.57.1.3.3  [Monitoring Focused QAR Project - Oversight](https://www.irs.gov/irm/part1/irm_01-057-001#idm140073958590992)
  - 1.57.1.4  [Audit Oversight Program](https://www.irs.gov/irm/part1/irm_01-057-001#idm140073958586128)
  - 1.57.1.5  [Internal Management Documents (IMD)](https://www.irs.gov/irm/part1/irm_01-057-001#idm140073958579872)
  - 1.57.1.6  [Enterprise Risk Management (ERM) Program](https://www.irs.gov/irm/part1/irm_01-057-001#idm140073958576080)
  - 1.57.1.7  [QualityPro Program](https://www.irs.gov/irm/part1/irm_01-057-001#idm140073958573024)
  - 1.57.1.8  [Field Review Program (FRP)](https://www.irs.gov/irm/part1/irm_01-057-001#idm140073958570576)
  - 1.57.1.9  [Employee Development Program - Conducting and Managing Employee Training and Development in FMSS](https://www.irs.gov/irm/part1/irm_01-057-001#idm140073958561312)

# Part 1. Organization, Finance, and Management

# Chapter 57. Facilities Management and Security Services Quality Assurance

# Section 1. FMSS Quality Assurance Programs

* * *

## 1.57.1 FMSS Quality Assurance Programs

#### Manual Transmittal

July 31, 2024

#### Purpose

(1) This transmittal revises IRM 1.57.1, Facilities Management and Security Services (FMSS) Quality Assurance (QA) Programs.

#### Material Changes

(1) This IRM was updated to reflect current organizational titles, scope, definitions, responsibilities, and authorized use.

(2) _IRM 1.57.1.1.1_, Background: Updated for QA to include centralize administrative support and oversight for training efforts across FMSS.

(3) _IRM 1.57.1.1.3_, Responsibilities: Updated program names for Audit and Review and Employee Development (ED) offices.

(4) _IRM 1.57.1.1.4_, Program Management and Review: Updated to include newly established ED reports.

(5) _IRM 1.57.1.1.5_, Program Controls: Updated for ED and remove controls for BPMS which is no longer under QA.

(6) _IRM 1.57.1.1.6_, Terms/Definitions/Acronyms: Added and updated terms and acronyms for IRM clarity.

(7) _IRM 1.57.1.1.7_, Related Resources: Added IRM 1.4.1.6, Employee Development and IRM 6.410.1, Learning and Education (L&E) Policy. Removed IRM 1.5.1.

(8) _IRM 1.57.1.2.1_, Improvement Focused QAR Project - Conducting Discovery: Retitled subsection to better reflect content. Added Form 15265, IRS Financial Statement Audit Matter for Further Consideration, reference.

(9) _IRM 1.57.1.2.3_, Improvement Focused QAR Project - Evaluating Solutions: Retitled subsection to better reflect content and added note to managers.

(10) _IRM 1.57.1.2.4_, Improvement Focused QAR Project - Oversight: Retitled subsection to better reflect content and updated list of documents reviewed and sources.

(11) _IRM 1.57.1.3_, Monitoring Focused QAR Projects: Retitled subsection to better reflect content and updated procedures.

(12) _IRM 1.57.1.3.1_, Monitoring Focused QAR Projects - Planning: Retitled subsection to better reflect content.

(13) _IRM 1.57.1.3.2_, Monitoring Focused QAR Project - Testing and Reporting Results: Retitled subsection to better reflect content.

(14) _IRM 1.57.1.3.3_, Monitoring Focused QAR Project - Oversight: Retitled subsection to better reflect content.

(15) _IRM 1.57.1.4_, Audit Oversight Program: Retitled subsection to better reflect content. Removed IRM references from this subsection because they are listed in Related Resource section.

(16) _IRM 1.57.1.5_, Internal Management Documents (IMD): Updated definition of IMD to align with definition from IRM 1.11.9, Clearing and Approving the Internal Revenue Manual (IRM). Removed IRM references from this subsection because they are listed in Related Resource section. Retitled subsection to better reflect content.

(17) _IRM 1.57.1.6_, Enterprise Risk Management (ERM) Program: Removed responsibilities for the Measures Team and the section on QA support for the Business Management Performance System since those responsibilities were transferred to another office. Retitled subsection to better reflect content.

(18) _IRM 1.57.1.7_, QualityPro Program: Added section for newly created QualityPro program.

(19) _IRM 1.57.1.8_, Field Review Program: Added section for newly created Field Review program.

(20) _IRM 1.57.1.9_, Employee Development Program Conducting and Managing Employee Training and Development in FMSS: Added section for newly created Employee Development program.

#### Effect on Other Documents

This IRM supersedes IRM 1.57.1 dated April 12, 2021.

#### Audience

Facilities Management and Security Services

#### Effective Date

(07-31-2024)

Richard L. Rodriguez

Chief

Facilities Management and Security Services

**1.57.1.1** **(07-31-2024)**

### Program Scope and Objectives

1. **Purpose:** The purpose of this IRM is to provide directives, authorities, and responsibilities for Facilities Management and Security Services (FMSS) Quality Assurance (QA) programs (Audit, Internal Management Documents (IMD), Employee Development (ED), Quality Assurance Review (QAR), QualityPro, Field Review, and Enterprise Risk Management (ERM)). The program goals are to improve FMSS program processes, monitor program adherence to guidance, and implement IRS policy.

2. **Audience:** FMSS managers and employees.

3. **Policy Owner:** Chief, FMSS.

4. **Program Owner:** FMSS Associate Director (AD), QA.

5. **Primary Stakeholders:** FMSS managers and staff.


**1.57.1.1.1** **(07-31-2024)**

#### Background

1. This IRM section provides clarification on the role of the QA organization within FMSS.

2. QA partners with FMSS program owners to:



1. Improve program effectiveness by conducting reviews and analyses.

2. Identify program processes and controls that are not operating in accordance with policy, procedures, or other requirements.

3. Provide technical and analytical support to implement program improvements and corrective measures.

4. Address requests and inquiries from the Government Accountability Office (GAO), Treasury Inspector General for Tax Administration (TIGTA), the Chief Financial Officer (CFO), and other organizations auditing FMSS programs.

5. Ensure IMDs (IRM, Policy Statements, Delegation Orders, etc.) are aligned and current.

6. Maintain the Risk Register and Key Risk Indicators (KRI), collect and report FMSS risk identification and assessment activities, and facilitate integration of risk in the decision-making process.

7. Centralize administrative support and oversight for training efforts across FMSS while enabling executive management oversight.


**1.57.1.1.2** **(07-31-2024)**

#### Authority

01. 31 USC 720 (b), Agency Reports.

02. [Executive Order No. 11348](https://www.archives.gov/federal-register/codification/executive-order/11348.html), Providing Guidance for the Further Training of Government Employees.

03. [GAO-19-55G](https://www.gao.gov/products/gao-19-55g), GAO’s Agency Protocols.

04. [GAO-14-704G](https://www.gao.gov/products/gao-14-704g), Standards for Internal Control in the Federal Government.

05. [OMB Circular No. A-50](https://obamawhitehouse.archives.gov/omb/circulars_a050/), Audit Follow-up.

06. OMB Circular No. A-123, (revised) dated July 15, 2016, [Management’s Responsibility for Enterprise Risk Management and Internal Control](https://obamawhitehouse.archives.gov/sites/default/files/omb/memoranda/2016/m-16-17.pdf).

07. [Public Law 97-255](https://obamawhitehouse.archives.gov/omb/financial_fmfia1982), Federal Managers’ Financial Integrity Act (FMFIA) of 1982.

08. [Treasury Directive 40-04](https://home.treasury.gov/about/general-information/orders-and-directives/td40-04), Treasury Internal Control Program.

09. [Treasury Directive 12-70](https://home.treasury.gov/about/general-information/orders-and-directives/td12-70), Policy and Guidance for Conference Approval, Planning, and Reporting.

10. 5 USC 41, Training.

11. The Commissioner of Internal Revenue has authority under [Treasury Order 150-10](https://home.treasury.gov/about/general-information/orders-and-directives/treasury-order-150-10) to administer and enforce the Internal Revenue laws. The Commissioner provides subordinates certain authorities to act on his behalf by issuing Delegations of Authority. IRS directors throughout the IRS, with the authority and responsibility for a program, issue IMDs to administer and enforce the Internal Revenue laws.


**1.57.1.1.3** **(07-31-2024)**

#### Responsibilities

1. The Chief, FMSS is authorized to prescribe QA programs within FMSS.

2. The AD, QA is responsible for planning, developing, implementing, evaluating, and controlling the QA programs.

3. The Section Chief, Audit and Review, is responsible for planning, developing, implementing, managing, and evaluating the Quality Assurance Review (QAR), QualityPro, Audit, ERM programs, and ensuring applicable IRS policies and procedures are followed.

4. The Section Chief, Employee Development, is responsible for planning, developing, implementing, managing, and evaluating FMSS’s Employee Development and IMD programs, and ensuring applicable IRS policies and procedures are followed.

5. FMSS program owners are responsible for:



1. Responding to requests and inquiries from QA personnel.

2. Cooperating with QA personnel to improve the accountability and operation of FMSS programs, strengthen controls, and address deficiencies.

3. Identifying areas within their programs that could benefit from a QA review to improve the accountability and operation of FMSS programs, strengthen controls, address deficiencies, and submitting a request to \*FMSS QAR Suggestions or \*FMSS QualityPro.


6. QA project leads are accountable for planning, implementing, and completing QA program reviews.

7. QA employees are responsible for following the procedures outlined in this IRM.


**1.57.1.1.4** **(07-31-2024)**

#### Program Management and Review

1. The QA program reports include:




| **Report** | **Description** |
| :-: | :-: |
| Open Audit and Planned Corrective Actions (PCA) Reports | A monthly report that identifies the status of open GAO and TIGTA audits, recommendations, and corrective actions. |
| Field Review Program (FRP) Report | An annual report that identifies the status of selected controls at an IRS facility. FRP report(s) are completed no later than September 30 every year. |
| Training Needs Assessment (TNA) | An annual planning process that identifies training needs and then progresses through various levels of approval for inclusion into the final IRS Annual Training Plan. The TNA is due to Human Capital Office (HCO) by September 15 every year. |
| Mandatory Briefings Report | A training completion report showing incomplete annual mandatory training. This report is sent to managers when requested. |
| Leadership Training Report | A training completion report showing incomplete mandatory leadership training. This report is sent to managers when requested. |

2. QA uses performance metrics to measure the effectiveness of reviews and, when possible, improvements made in response to QA recommendations.

3. Employee Development Program performance is measured by indicators such as the number of employees trained, events conducted, and training budget expenditures.


**1.57.1.1.5** **(07-31-2024)**

#### Program Controls

1. Management maintains continuous oversight of projects and program activities through regular project status meetings and status reporting.

2. A documentation trail of reviews, approvals, coordination activities, and key decisions is maintained in compliance with policy for each QA program.

3. The status of audits, corrective actions, audit inquiries, and requests are tracked; program risks and mitigations are documented and reviewed/updated periodically; and a documentation trail on issues, actions, and resolutions is retained.

4. Access to program documentation, reports and information is centralized and stored on a SharePoint site with access limited to authorized personnel.

5. The Employee Development Program follows the requirements of Treasury Directive 12-70, Policy and Guidance for Conference Approval, Planning, and Reporting, when requesting approval and coordination of employee training events. The Human Capital Office (HCO) provides feedback on submission accuracy which the manager uses as developmental opportunities for staff while improving product quality.

6. The Employee Development Program manages the payment of vendors and other federal agencies using a multi-level signature process to ensure accountability. The program uses the Servicewide Training and Events Tracking System (STETS) which is the system of record allowing the program to maintain records on the coordination of events and approval process.


**1.57.1.1.6** **(07-31-2024)**

#### Terms/Definitions/Acronyms

1. The following terms and definitions apply to this IRM section:



01. **Action Plan** – A detailed plan outlining actions needed to reach one or more goals.

02. **Audit** – An assessment of FMSS program activities performed by the Government Accountability Office (GAO), Treasury Inspector General for Tax Administration (TIGTA), Chief Financial Officer (CFO), or a federal organization.

03. **Data Collection Instrument (DCI)** – A form or spreadsheet used to document testing results when multiple records, observations, transactions, or cases are tested in a monitoring focused QAR. The DCI identifies the specific guidance tested and the testing results.

04. **Engagement Letter** – A notification of a planned review sent by QA to affected staff.

05. **Guidance** – The source of criteria or standards against which a program is tested in a monitoring focused QAR.

06. **Internal Management Document (IMD)** – An official communication that designates policies, authorities, and delivers instructions to IRS officials and employees.

07. **Key Risk Indicators (KRI)** – A metric that provides early warning of events that could negatively affect a program’s ability to accomplish its objectives.

08. **Matter for Further Consideration (MFC)** – A notification from GAO that identifies an instance of non-conformance with internal control standards, provisions of the Internal Revenue Manual, or other applicable guidance.

09. **Planned Corrective Actions (PCA)** – A detailed description of how management plans to implement a recommendation to address the audit finding(s). The PCA also identifies due date(s) and responsible official(s).

10. **Program Owner** – A manager with primary responsibility for establishing policies and procedures and/or managing a program.

11. **Project Status Report** – A periodic report of progress on a QAR project delivered by the project lead to management.

12. **Quality Assurance Review (QAR)** – An evaluation of a program or business processes.

13. **QualityPro** – A data-based review application that measures quality by monitoring the effectiveness of policies and procedures.

14. **Risk Register** – A template for business units to document and report risk information in a standardized format to the Office of the Chief Risk Officer (OCRO) for enterprise risk assessment updates.

15. **Stakeholders** – Organizations or persons with program policy responsibilities or with a vested interest in a program.

16. **Summary of Analysis (SOA)** – A document that identifies the causes for the issues under review and proposes solutions for improvement.

17. **Testing Approach** – A planning document that identifies the methodology that will be used to evaluate program processes during a monitoring focused QAR.

18. **Testing Summary** – A document that describes testing performed and results in a monitoring focused QAR.


2. The following table provides acronyms that are used throughout this IRM section:




| **Acronym** | **Term** |
| :-: | :-: |
| AD | Associate Director |
| CFO | Chief Financial Officer |
| DCI | Data Collection Instrument |
| EAM | Enterprise Audit Management |
| ERM | Enterprise Risk Management |
| FMSS | Facilities Management and Security Services |
| FRP | Field Review Program |
| GAO | Government Accountability Office |
| HCO | Human Capital Office |
| IG | Interim Guidance |
| IMD | Internal Management Document(s) |
| ITM | Integrated Talent Management |
| KRI | Key Risk Indicators |
| MFC | Matter for Further Consideration |
| OCRO | Office of the Chief Risk Officer |
| PCA | Planned Corrective Action |
| QA | Quality Assurance |
| QAR | Quality Assurance Review |
| RAAS | Research, Applied Analytics and Statistics |
| SME | Subject Matter Experts |
| SOA | Summary of Analysis |
| SOP | Standard Operating Procedures |
| SPDER | Servicewide Policy, Directives and Electronic Resources |
| STETS | Servicewide Training and Events Tracking System |
| TDQAS | Training Development Quality Assurance System |
| TIGTA | Treasury Inspector General for Tax Administration |
| TNA | Training Needs Assessment |


**1.57.1.1.7** **(07-31-2024)**

#### Related Resources

01. IRM 1.4.1.6, Employee Development

02. IRM 1.4.2, Monitoring and Improving Internal Control

03. IRM 1.4.3, Financial Assurance Control Testing

04. IRM 1.4.31, IRS Quality Assurance Review Program

05. IRM 1.4.32, Internal Control Review Program

06. IRM 1.4.60, Enterprise Risk Management (ERM) Program

07. IRM 1.11.1, Internal Management Document (IMD) Program and Responsibilities

08. IRM 1.11.2, Internal Revenue Manual (IRM) Process

09. IRM 1.11.3, Servicewide Policy Statement Process

10. IRM 1.11.4, Servicewide Delegation Order Process

11. IRM 1.11.5, Publishing the Internal Revenue Manual (IRM)

12. IRM 1.11.9, Clearing and Approving the Internal Revenue Manual (IRM)

13. IRM 1.11.10, Interim Guidance Process

14. IRM 1.29.1, Authorities and Responsibilities

15. IRM 1.35.14, IRS Annual Financial Statement Audit

16. IRM 6.410.1, Learning and Education (L&E) Policy


**1.57.1.2** **(07-31-2024)**

### Improvement Focused QAR Projects

1. In an improvement focused QAR project, program processes are reviewed to identify underlying causes for issues and opportunities to improve efficiency and effectiveness.

2. The Section Chief, Audit and Review designates a project lead and team for each improvement-focused QAR project.

3. The designated Audit and Review project team completes the activities identified in _IRM 1.57.1.2.1_ through _IRM 1.57.1.2.4_.


**1.57.1.2.1** **(07-31-2024)**

#### Improvement Focused QAR Project - Conducting Discovery

1. Obtain an understanding of the operation of program processes, policies, practices, program risks and mitigations as well as prior audit findings and any other program concerns that apply to the project’s objectives sufficient to identify underlying and contributing causes. Document applicable program processes. Key sources for information include:



1. Audit reports, Form 15265, IRS Financial Statement Audit Matters for Further Consideration (MFC), corrective action documentation

2. IRM, Standard Operating Procedures (SOP), desk guides, program documents

3. Training courses

4. Subject Matter Experts (SME)

5. Other historical and current material that may be relevant to the project objectives


**1.57.1.2.2** **(07-31-2024)**

#### Improvement Focused QAR Project - Developing and Proposing Solutions

1. Analyze the information gathered during discovery and prepare a Summary of Analysis (SOA) documenting the results of the analysis and the proposed solution(s). The SOA should include:



1. Objective of the review

2. Background

3. Identification of root or contributing causes

4. Proposed solution(s)


2. Support the implementation of the solution in consultation with the program owner and stakeholders.


**1.57.1.2.3** **(07-31-2024)**

#### Improvement Focused QAR Project - Evaluating Solutions

1. Soon after the solution is implemented, evaluate the operation of the solution(s) and identify and document any recommended adjustments or follow-on actions, as necessary.



### Note:



At management’s discretion and after sufficient processing activity has occurred, the program may also be subject to monitoring-focused QARs to assess effectiveness over time.


**1.57.1.2.4** **(07-31-2024)**

#### Improvement Focused QAR Project - Oversight

1. The project lead submits project status reports to management and attends recurring oversight meetings at management’s discretion throughout the QAR project.

2. The project lead uploads the following final QAR project records to the review team’s SharePoint site with access limited to authorized personnel designated by the manager:



1. List of documents reviewed and sources

2. SOA

3. Action plan, as necessary


**1.57.1.3** **(07-31-2024)**

### Monitoring Focused QAR Projects

1. In a monitoring focused QAR, program processes are reviewed to determine if policies, procedures, and controls were implemented effectively and, as necessary, identify corrective measures.

2. The Section Chief, Audit and Review designates a project lead and team for each monitoring focused QAR project.

3. The designated Audit and Review project team completes the activities identified in _IRM 1.57.1.3.1_ through _IRM 1.57.1.3.3_.


**1.57.1.3.1** **(07-31-2024)**

#### Monitoring Focused QAR Project - Planning

1. Develop an understanding of the program under review and any recent program improvements by reviewing program documentation, studies, guidance, processing documents, and discussing program operation with the SME, as necessary.

2. Develop a Testing Approach and Data Collection Instrument (DCI) to document the testing plan and test results.



### Note:



A Testing Summary may be prepared when results from several DCIs will need to be consolidated or when using a DCI is not efficient.


**1.57.1.3.2** **(07-31-2024)**

#### Monitoring Focused QAR Project - Testing and Reporting Results

1. Test program adherence to guidance. Testing techniques include:



1. Direct physical inspection and observations

2. Document reviews

3. Inquiries (e.g., interviews, written inquiries, questionnaires)

4. Sampling, which uses statistical methods (e.g., Excel random number feature) to select items for testing and to interpret testing results, used in conjunction with the above-mentioned techniques

5. Analytical reviews (e.g., computations, data comparisons, variance analyses, data matching)


2. Report testing results to program owners and finalize a written report identifying review objectives, guidance used as testing criteria, scope and methodology, results, and any recommended actions.


**1.57.1.3.3** **(07-31-2024)**

#### Monitoring Focused QAR Project - Oversight

1. The project lead will submit project status reports to management and attend recurring oversight meetings at management’s discretion throughout the QAR project.

2. The project lead will upload the following final QAR records to the review team’s SharePoint site with access limited to authorized personnel designated by the manager:



1. List of documents that support analysis, findings or recommendations, cross-references to the location of the documents and source

2. Testing Approach

3. DCI or Testing Summary

4. QAR Report


**1.57.1.4** **(07-31-2024)**

### Audit Oversight Program

1. The GAO, TIGTA, CFO, and federal organizations (e.g., Department of Treasury, Office of Personnel Management) conduct audits, reviews and inspections of FMSS programs and operations (collectively referred to as "audits" in this IRM).

2. The following organizations establish IRS Audit oversight policies:



1. Office of the Chief Risk Officer, Enterprise Audit Management (TIGTA, GAO, and federal agency audits, except for the IRS Financial Statement Audit)

2. CFO, Financial Management (IRS Financial Statement Audit), and Internal Control (IRS QA Program, Assurance Review Testing, Internal Control Reviews)


3. The Audit Team is responsible for managing FMSS’s implementation of the Audit oversight program. This includes:



1. Coordinating information and access requests with affected functions and areas.

2. Providing management and program owners analysis and insight on audit issues.

3. Monitoring and reporting on the status of audits and planned corrective actions.


**1.57.1.5** **(07-31-2024)**

### Internal Management Documents (IMD)

1. IMDs are official communications which designate policies, authorities, and instructions to IRS officials and employees. IMDs include IRMs, interim guidance (IG), policy statements (PS), and delegation orders (DO).

2. The Office of Servicewide Policy, Directives and Electronic Resources (SPDER), within the Research, Applied Analytics and Statistics (RAAS) organization establishes IRS IMD policy.

3. The IMD Team is responsible for managing FMSS’s implementation of the IMD program. IMD coordinators manage program activities, including acting as a clearing house for all IMD products, verifying all IMD products are current and providing support to IMD authors.

4. The IMD Team follows applicable IRS policies and FMSS SOP.


**1.57.1.6** **(07-31-2024)**

### Enterprise Risk Management (ERM) Program

1. The IRS developed the ERM Program in 2014 to provide an IRS-wide approach to risk management and foster a risk-aware culture. The program helps IRS units incorporate risk management principles in the decision-making process.

2. The OCRO organization established the IRS ERM policy.

3. QA is responsible for managing the FMSS implementation of the ERM program in accordance with IRM 1.4.60, Enterprise Risk Management Program. This includes maintaining the Risk Register and Key Risk Indicators, collecting and reporting FMSS risk identification and assessment activities, and facilitating the integration of risk in the decision-making process.


**1.57.1.7** **(07-31-2024)**

### QualityPro Program

1. The QualityPro application measures quality in support of the FMSS mission by monitoring the effectiveness of policies, procedures, and internal controls, and improving interdepartmental communication, processes, and performance.

2. The QualityPro Team is responsible for overseeing the QualityPro program, including providing support and guidance to implement program guidance, quality control over QualityPro DCIs and analysis of program results and reports.


**1.57.1.8** **(07-31-2024)**

### Field Review Program (FRP)

1. The Field Review Program (FRP) Team conducts site visits to IRS facilities to monitor the implementation of IRS policies, procedures, and internal controls in support of the FMSS mission. Each site visit consists of four phases: pre-visit planning, conducting the review, reporting results, and monitoring planned corrective actions.

2. Pre-visit Planning



   - Send out an engagement letter to affected Associate Directors and local personnel identifying the locations QA plans to visit, the visit dates, and visiting team members.

   - Coordinate logistics, request access, and obtain planning information from local site personnel.


3. Conducting the Review



   - Complete onsite inspections and observations to assess the local implementation of policies.

   - Conduct an exit briefing to present results and observations.


4. Reporting Results



   - Send a draft report to local personnel on the results of the review along with a formal request for review and written response, and a request for planned corrective actions.



     ### Note:



     Local management’s response to the draft report must formally address in writing all findings in the report. The response must express explicit agreement, partial agreement or non-agreement with each finding and include planned corrective actions with specific due dates for findings that are agreed to or partially agreed to. Also, the reasoning for partial agreement and non-agreement to findings should be explained as part of the response.

   - Finalize the report and send to the Chief and Deputy Chief, FMSS, Associate Director of the affected Operational Areas and the Associate Director, Security.


5. Monitoring Planned Corrective Actions (PCA)



   - Track completion of planned corrective actions and gather available documentation for verification purposes.


**1.57.1.9** **(07-31-2024)**

### Employee Development Program - Conducting and Managing Employee Training and Development in FMSS

1. The QA Employee Development Program works with FMSS program owners to analyze current training availabilities and identify performance gaps. This planning phase of the training cycle results in the annual FMSS Training Needs Assessment (TNA) which feeds into the IRS Annual Training Plan. Once approved at the executive level, the TNA is inputted into the Servicewide Training and Events Tracking System (STETS).

2. During the coordination phase of training, Employee Development secures classroom space, training materials, qualified instructors, and where needed, hotel room blocks. Once the event is fully coordinated and marked ready in STETS, official reporting instructions are sent to all participants.

3. Employee Development functional area leads work with the event POCs and instructor cadre before, during, and after the execution of training to ensure course materials have been updated and instructor preparations have been finalized. Once the training is complete, Employee Development works with the instructors to ensure the training has been properly recorded into Integrated Talent Management (ITM), as required.

4. Employee Development’s final activity in support of the training cycle is evaluating training courses to identify course improvement opportunities and determine the overall value that training is adding to business results and the FMSS mission. Employee Development follows procedures outlined in the instructional design model known as Training Development Quality Assurance System (TDQAS) to administer training evaluations. Speciﬁc procedures address the evaluation of learner reactions and achievement, and the evaluation of job performance and organizational impact. Adherence to TDQAS processes ensures consistency in the overall quality of our training systems and products.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-057-001#addtoany "Show all")

A2A