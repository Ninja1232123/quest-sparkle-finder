---
url: "https://www.irs.gov/irm/part1/irm_01-001-008"
title: "1.1.8 Taxpayer Advocate Service | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-001-008#main-content)

- 1.1.8  [Taxpayer Advocate Service](https://www.irs.gov/irm/part1/irm_01-001-008#id1)
  - 1.1.8.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-001-008#id2)
    - 1.1.8.1.1  [Authority](https://www.irs.gov/irm/part1/irm_01-001-008#id4)
    - 1.1.8.1.2  [Program Objectives and Review](https://www.irs.gov/irm/part1/irm_01-001-008#id5)
    - 1.1.8.1.3  [Terms](https://www.irs.gov/irm/part1/irm_01-001-008#id6)
    - 1.1.8.1.4  [Acronyms](https://www.irs.gov/irm/part1/irm_01-001-008#id7)
    - 1.1.8.1.5  [Related Resources](https://www.irs.gov/irm/part1/irm_01-001-008#id8)
  - 1.1.8.2  [Office of the Taxpayer Advocate](https://www.irs.gov/irm/part1/irm_01-001-008#id9)
  - 1.1.8.3  [National Taxpayer Advocate](https://www.irs.gov/irm/part1/irm_01-001-008#id10)
    - 1.1.8.3.1  [Deputy National Taxpayer Advocate](https://www.irs.gov/irm/part1/irm_01-001-008#id11)
      - 1.1.8.3.1.1  [Executive Director, Case Advocacy](https://www.irs.gov/irm/part1/irm_01-001-008#id12)
        - 1.1.8.3.1.1.1  [Deputy Executive Directors, Case Advocacy](https://www.irs.gov/irm/part1/irm_01-001-008#id14)
      - 1.1.8.3.1.2  [Executive Director, Case Advocacy, Intake and Technical Support](https://www.irs.gov/irm/part1/irm_01-001-008#id15)
        - 1.1.8.3.1.2.1  [Centralized Case Intake](https://www.irs.gov/irm/part1/irm_01-001-008#id16)
          - 1.1.8.3.1.2.1.1  [NTA Toll-Free Operations](https://www.irs.gov/irm/part1/irm_01-001-008#id18)
        - 1.1.8.3.1.2.2  [Deputy ITS, Technical Support](https://www.irs.gov/irm/part1/irm_01-001-008#id19)
          - 1.1.8.3.1.2.2.1  [Internal Technical Advisor Program](https://www.irs.gov/irm/part1/irm_01-001-008#id21)
          - 1.1.8.3.1.2.2.2  [Technical Analysis and Guidance](https://www.irs.gov/irm/part1/irm_01-001-008#id22)
          - 1.1.8.3.1.2.2.3  [Business Assessment](https://www.irs.gov/irm/part1/irm_01-001-008#id23)
          - 1.1.8.3.1.2.2.4  [Quality Review Program](https://www.irs.gov/irm/part1/irm_01-001-008#id24)
      - 1.1.8.3.1.3  [Executive Director, Operations Support](https://www.irs.gov/irm/part1/irm_01-001-008#id25)
        - 1.1.8.3.1.3.1  [Deputy Operations Support](https://www.irs.gov/irm/part1/irm_01-001-008#id26)
          - 1.1.8.3.1.3.1.1  [Learning & Education](https://www.irs.gov/irm/part1/irm_01-001-008#id28)
          - 1.1.8.3.1.3.1.2  [Case Advocate Training Support](https://www.irs.gov/irm/part1/irm_01-001-008#id29)
          - 1.1.8.3.1.3.1.3  [Leadership Development & Support Office](https://www.irs.gov/irm/part1/irm_01-001-008#id30)
        - 1.1.8.3.1.3.2  [Financial Operations](https://www.irs.gov/irm/part1/irm_01-001-008#id31)
        - 1.1.8.3.1.3.3  [Business Systems Planning (BSP)](https://www.irs.gov/irm/part1/irm_01-001-008#id32)
          - 1.1.8.3.1.3.3.1  [TAS Solutions and Development](https://www.irs.gov/irm/part1/irm_01-001-008#id34)
          - 1.1.8.3.1.3.3.2  [TAS Systems Operations and Support](https://www.irs.gov/irm/part1/irm_01-001-008#id35)
        - 1.1.8.3.1.3.4  [Communications, Stakeholder Liaison & Online Services (CSO)](https://www.irs.gov/irm/part1/irm_01-001-008#id36)
          - 1.1.8.3.1.3.4.1  [Marketing & Communications (M&C)](https://www.irs.gov/irm/part1/irm_01-001-008#id38)
          - 1.1.8.3.1.3.4.2  [Multimedia & Technology (M&T)](https://www.irs.gov/irm/part1/irm_01-001-008#id39)
    - 1.1.8.3.2  [Executive Director, Systemic Advocacy](https://www.irs.gov/irm/part1/irm_01-001-008#id40)
      - 1.1.8.3.2.1  [Deputy Director for Systemic Advocacy, Proactive Advocacy](https://www.irs.gov/irm/part1/irm_01-001-008#id41)
        - 1.1.8.3.2.1.1  [Advocacy Implementation & Evaluation](https://www.irs.gov/irm/part1/irm_01-001-008#id43)
        - 1.1.8.3.2.1.2  [Research & Analysis](https://www.irs.gov/irm/part1/irm_01-001-008#id44)
      - 1.1.8.3.2.2  [Deputy Director for Systemic Advocacy, Technical Advocacy](https://www.irs.gov/irm/part1/irm_01-001-008#id45)
        - 1.1.8.3.2.2.1  [Taxpayer Advocacy Panel](https://www.irs.gov/irm/part1/irm_01-001-008#id47)
      - 1.1.8.3.2.3  [Advocacy Efforts Group](https://www.irs.gov/irm/part1/irm_01-001-008#id48)
      - 1.1.8.3.2.4  [TAS Attorney Advisors](https://www.irs.gov/irm/part1/irm_01-001-008#id49)
    - 1.1.8.3.3  [Low Income Taxpayer Clinic Program Office](https://www.irs.gov/irm/part1/irm_01-001-008#id50)
    - 1.1.8.3.4  [Senior Advisor to the NTA](https://www.irs.gov/irm/part1/irm_01-001-008#id51)
    - 1.1.8.3.5  [Senior Advisor to the NTA - Research](https://www.irs.gov/irm/part1/irm_01-001-008#id52)
  - 1.1.8.4  [Division Counsel/Associate Chief Counsel (National Taxpayer Advocate Program)](https://www.irs.gov/irm/part1/irm_01-001-008#id53)

# Part 1. Organization, Finance, and Management

# Chapter 1. Organization and Staffing

# Section 8. Taxpayer Advocate Service

* * *

## 1.1.8 Taxpayer Advocate Service

#### Manual Transmittal

July 29, 2025

#### Purpose

(1) This transmits revised IRM 1.1.8, Organization and Staffing, Taxpayer Advocate Service. This IRM section provides the organizational structure of the Taxpayer Advocate Service.

#### Material Changes

(1) IRM 1.1.8 Updated to comply with January 2025 Executive Orders and OPM guidance.

(2) IRM 1.1.8 3.1(d) Added Office of Civil Rights and Compliance (OCRC).

(3) IRM 1.1.8.3.1.4 Removed previous subsection to comply with January 2025 Executive Orders and OPM guidance.

#### Effect on Other Documents

This supersedes IRM 1.1.8, dated June 7, 2024.

#### Audience

All IRS employees

#### Effective Date

(07-29-2025)

Erin M. Collins

National Taxpayer Advocate

**1.1.8.1** **(11-04-2022)**

### Program Scope and Objectives

1. _Purpose_: This IRM section provides the organizational structure of the Taxpayer Advocate Service (TAS).

2. _Audience_: This IRM is intended for all IRS employees.

3. _Policy Owner_: The Deputy National Taxpayer Advocate (DNTA).

4. _Program Owner_: The National Taxpayer Advocate (NTA).


**1.1.8.1.1** **(06-07-2024)**

#### Authority

1. TAS employees have both statutory authorities and delegated authorities when advocating for taxpayers.

2. Statutory authorities for TAS are found in Internal Revenue Code (IRC) 7803(c) and IRC 7811.

3. Delegated authorities are granted to the NTA by the Commissioner and, when appropriate, redelegated by the NTA to TAS employees. Delegated authorities allow TAS employees to resolve certain issues in the same manner as other functions within the IRS, exercising the same authorities that are routine in nature. IRM 1.2.2.13, Delegations of Authority for Taxpayer Advocate Service Activities, details the authorities of TAS employees. IRM 13.1.4, TAS Authorities, provides extensive details about the scope of TAS’s authorities.

4. When TAS employees do not have authority to take actions on a case, an Operations Assistance Request (OAR) is typically used. See IRM 13.1.19, Advocating with Operations Assistance Requests (OARs).

5. Local Taxpayer Advocates (LTAs) are granted the authority to issue, modify, or rescind Taxpayer Assistance Orders (TAOs). See IRM 1.2.2.13.1, Delegation Order 13-1 (Rev. 1), Authority to Issue, Modify or Rescind Taxpayer Assistance Orders, and IRM 13.1.20, TAS Taxpayer Assistance Orders (TAOs).


**1.1.8.1.2** **(11-04-2022)**

#### Program Objectives and Review

1. The objective of this IRM is to provide a road map of TAS resources. See IRM 13.1.1, Taxpayer Advocate Guiding Principles of the Office of the Taxpayer Advocate, for a detailed discussion of the evolution, mission, authority, and guiding principles of TAS.

2. For an overview of TAS see the TAS Organizational Chart.


**1.1.8.1.3** **(06-07-2024)**

#### Terms

1. The following table provides a list of terms used throughout this IRM.




| Term | Definition |
| --- | --- |
| Advocacy | The willingness and ability to see the situation from a taxpayer’s perspective, advocate for the taxpayer’s rights, advocate for solutions to identified problems, and assist IRS leadership in integrating taxpayer’s rights and perspective into tax administration |
| Case Advocacy | The TAS function whose primary purpose is to assist taxpayers who are experiencing economic harm, who are seeking help in resolving tax problems that have not been resolved through normal channels, or who believe that an IRS system or procedure is not working as it should. (This could include Intake Advocates, Case Advocates, Lead Intake Advocates, Lead Case Advocates, Taxpayer Advocate Group Managers, LTAs, etc.) |
| Immediate Intervention | Immediate Intervention is used by TAS to address issues that arise in the following circumstances:<br> <br>   - Result of an operation issue that causes immediate, significant harm to multiple taxpayers and demands an urgent response;<br>     <br>   - Cannot be quickly resolved through the normal corrective process;<br>     <br>   - Have clear sources of the problems; and<br>     <br>   - Are highly visible and sensitive locally, area-wide, or nationally.<br>     <br> The goal of an Immediate Intervention is to bring relief quickly to affected taxpayers. |
| Impartiality | An unbiased assessment of the taxpayer’s situation based on tax law. |
| Independence | The ability to objectively advocate for the taxpayer separately and without influence from the IRS. |
| Operations Assistance Request (OAR) | Conveys a recommendation or request that the IRS act to resolve a taxpayer’s problem(s) when TAS lacks the statutory or delegated authority to resolve a taxpayer’s problem(s). |
| Systemic Advocacy | The TAS function whose purpose is to identify areas in which groups of taxpayers are experiencing problems with the IRS and to the extent possible, propose administrative or legislative changes to resolve or mitigate those problems. |
| Systemic Advocacy Management System (SAMS) | The web-based portal that taxpayers, tax professionals, academic/research institutions, IRS/Counsel/Appeals/TAS employees, and others use to submit systemic issues to TAS to explore, investigate, and make recommendations when appropriate. |
| Taxpayer Assistance Order (TAO) | A statutory tool used by TAS to order the IRS to take certain actions as permitted by law, cease certain actions or refrain from taking certain actions. See IRC 7811, Treasury Regulation 301.7811-1, and IRM 13.1.20, TAS Taxpayer Assistance Orders (TAOs). |
| Taxpayer Bill of Rights (TBOR) | The TBOR is the framework for effective tax administration setting forth rights that already existed in the tax code, putting them in simple language and grouping them into 10 fundamental rights applicable to all taxpayers. Employees are responsible for being familiar with and acting in accord with taxpayer rights. See IRC 7803(a)(3), Execution of Duties in Accord with Taxpayer Rights. For additional information about the TBOR, see https://www.irs.gov/taxpayer-bill-of-rights. |


**1.1.8.1.4** **(07-29-2025)**

#### Acronyms

1. The following table provides a list of acronyms and definitions used throughout this IRM.




| Acronym | Definition |
| --- | --- |
| ARC | Annual Report to Congress |
| BA | Business Assessment |
| BSP | Business Systems Planning |
| CATS | Case Advocate Training Support |
| CCI | Centralized Case Intake |
| CCNTA | Division Counsel/Associate Chief Counsel (National Taxpayer Advocate Program) |
| CSO | Communications, Stakeholder Liaison & Online Services |
| DC LTA | District of Columbia Local Taxpayer Advocate |
| DEDSA-PA | Deputy Director for Systemic Advocacy, Proactive Advocacy |
| DEDSA-TA | Deputy Director for Systemic Advocacy, Technical Advocacy |
| Deputy | Deputy Executive Director Case Advocacy |
| Deputy ITS, Technical Support | Deputy Executive Director Case Advocacy, Intake and Technical Support, Technical Support |
| DNTA | Deputy National Taxpayer Advocate |
| EDCA | Executive Director Case Advocacy |
| EDCA-ITS | Executive Director Case Advocacy, Intake and Technical Support |
|  |  |
| EDSA | Executive Director Systemic Advocacy |
| EEO | Equal Employment Opportunity |
| IDRS | Integrated Data Retrieval System |
| IMD | Internal Management Document |
| IRC | Internal Revenue Code |
| IRM | Internal Revenue Manual |
| IRS | Internal Revenue Service |
| ITAP | Internal Technical Advisor Program |
| JRC | June Objectives Report to Congress |
| L&E | Learning & Education |
| LDS | Leadership Development & Support |
| LITC | Low Income Taxpayer Clinic |
| LTA | Local Taxpayer Advocate |
| M&C | Marketing & Communications |
| M&T | Multimedia & Technology |
| N/A | Not Applicable |
| NTA | National Taxpayer Advocate |
| OAR | Operations Assistance Request |
| QRP | Quality Review Program |
| R&A | Research & Analysis |
| SA | Systemic Advocacy |
| SAMS | Systemic Advocacy Management System |
| SPOC | Single Point of Contact |
| TAG | Technical Analysis and Guidance |
| TAMIS | Taxpayer Advocate Management Information System |
| TAO | Taxpayer Assistance Order |
| TAP | Taxpayer Advocacy Panel |
| TAS | Taxpayer Advocate Service |
| TBOR | Taxpayer Bill of Rights |
| TSD | TAS Solutions and Development |
| W&I | Wage & Investment |


**1.1.8.1.5** **(11-04-2022)**

#### Related Resources

1. Below is a list of resources employees may use in conjunction with this IRM:



1. IRM 1.2.2.13, Delegations of Authorities for Taxpayer Advocate Service Activities.

2. IRM 13.1, Taxpayer Advocate Case Procedures.

3. IRM 13.1.1, Taxpayer Advocate Guiding Principles of the Office of the Taxpayer Advocate.

4. IRM 13.2, Systemic Advocacy.

5. IRM 13.2.8, National Taxpayer Advocate’s Annual Reports to Congress (ARC).

6. IRM 13.6, Taxpayer Advocate Service Communications.

7. IRM 13.7, Taxpayer Advocacy Panel Program.

8. TAS Organizational Chart.


**1.1.8.2** **(11-04-2022)**

### Office of the Taxpayer Advocate

1. IRC 7803(c)(2)(A) provides that it is the function of the Office of the Taxpayer Advocate to:



1. Assist taxpayers in resolving problems with the IRS.

2. Identify areas in which taxpayers have problems in dealings with the IRS.

3. To the extent possible, propose changes in the administrative practices of the IRS to mitigate problems identified in _IRM 1.1.8.2 (1)_(a).

4. Identify potential legislative changes which may be appropriate to mitigate such problems.


**1.1.8.3** **(11-04-2022)**

### National Taxpayer Advocate

1. The NTA is appointed by the Secretary of the Treasury, following consultation with the IRS Commissioner. The NTA, an independent voice inside the IRS, reports directly to the Commissioner and reports to Congress on areas of the tax law that impose significant burdens on taxpayers or the IRS, including potential legislative changes. The NTA serves as the advocate for taxpayers within the IRS and before Congress.

2. To ensure both independence and impartiality on the part of TAS employees when dealing with tax-related concerns, all TAS employees report directly to the NTA, or delegate. See IRC 7803(c)(4)(A)(i).

3. The NTA is required by IRC 7803(c)(2)(B) to provide two annual reports directly to Congress without any prior review or comment from the Commissioner, the Secretary of the Treasury, the Oversight Board, any other officer or employee of the Department of the Treasury, or the Office of Management and Budget. See IRM 13.2.8, National Taxpayer Advocate’s Annual Reports to Congress (ARC).



1. The first report contains objectives of the Office of the Taxpayer Advocate for the fiscal year beginning in that calendar year. This report is to provide the objectives of the office and contain full and substantive analysis including statistical information for the objectives and is due no later than June 30 each calendar year.

2. The second report is on the activities of the NTA during the fiscal year ending that calendar year and is due no later than December 31 each calendar year. Among other things, the activities report must identify the initiatives the Office of the Taxpayer Advocate has taken to improve taxpayer services and IRS responsiveness, contain recommendations received from individuals who have the authority to issue a TAO, describe in detail the progress made in implementing these recommendations, contain a summary of the 10 most serious problems which taxpayers face in dealing with the IRS, include recommendations for such administrative and legislative actions as may be appropriate to resolve such problems, identify areas of the tax law that impose significant compliance burdens on taxpayers or the IRS, including specific recommendations for remedying these problems, identify the 10 most litigated issues for each category of taxpayers, including recommendations for mitigating such disputes, and include other such information as the NTA may deem advisable.


4. Per IRC 7803(c)(2)(C), the NTA shall:



1. Monitor the coverage and geographic allocation of local offices of taxpayer advocates.

2. Develop guidance to be distributed to all IRS offices and employees outlining the criteria for referral of taxpayer inquiries to local offices of taxpayer advocates. See IRM 13.1.7, Taxpayer Advocate Service (TAS) Case Criteria.

3. Ensure that the local telephone number for each local office of the taxpayer advocate is published and available to taxpayers.

4. In conjunction with the Commissioner, develop career paths for LTAs choosing to make a career in the Office of the Taxpayer Advocate.


5. Per IRC 7803(c)(2)(D), the NTA, or her delegate, has the responsibility and authority to:



1. Appoint LTAs and make available at lease one such advocate for each state.

2. Evaluate and take personnel actions (including dismissal) with respect to any employee of any local office of a taxpayer advocate.


6. Reporting to the NTA are:



1. Deputy National Taxpayer Advocate

2. Executive Director Systemic Advocacy

3. Low Income Taxpayer Clinic Program Office Director

4. Senior Advisor to the NTA

5. Senior Advisor to the NTA - Research


**1.1.8.3.1** **(07-29-2025)**

#### Deputy National Taxpayer Advocate

1. The Deputy National Taxpayer Advocate (DNTA) manages the day-to-day operations of the TAS organization and participates in activities regarding the modernization of the IRS. The DNTA reports directly to the NTA. The DNTA's responsibilities include representing and acting on behalf of the NTA, managing the day-to-day operations of TAS including:



1. Executive Director, Case Advocacy

2. Executive Director, Case Advocacy, Intake and Technical Support

3. Executive Director, Operations Support

4. Office of Civil Rights and Compliance (OCRC)


2. The DNTA is also responsible for implementing and following the Commissioner's Continuity Program policies, and developing, exercising, implementing, maintaining, and carrying out viable continuity plans.


**1.1.8.3.1.1** **(06-07-2024)**

##### Executive Director, Case Advocacy

1. The Executive Director, Case Advocacy (EDCA) reports directly to the DNTA and has the primary responsibility for assisting taxpayers in resolving problems with the IRS and helping to identify areas in which taxpayers have problems in dealings with the IRS. To do this, EDCA provides a strategic vision for Case Advocacy employees, leadership and oversight with a focus on employee engagement. See IRM 13.1, Taxpayer Advocate Case Procedures.

2. Case Advocacy leads, oversees, and delivers critical programs for taxpayer casework including congressional cases, outreach, local congressional relations, integration of case and systemic advocacy, and customer satisfaction. The success of these programs is critical to carrying out the responsibilities of the NTA as enumerated in IRC 7803(c).

3. The EDCA organization is made up of 75 LTA Offices which are organized into eight Area Offices.

4. The Assistant EDCA East, has responsibility and oversight of Areas 1, 2, 3, and 4.

5. The Assistant EDCA West has responsibility and oversight of Areas 5, 6, 7, and 8.


**1.1.8.3.1.1.1** **(06-07-2024)**

###### Deputy Executive Directors, Case Advocacy

1. Each of the eight Area offices are led by a Deputy Executive Director, Case Advocacy (Deputy) and provide program guidance and direction to LTAs, who report directly to the Deputies. The Deputy offices are responsible for:



1. Allocating resources properly within their area.

2. Identifying IRS systemic issues at the field level and raising them to the EDSA to influence IRS tax administration.

3. Working with Operating Divisions or Functional Unit analysts to identify systemic and procedural problems impacting taxpayers.

4. Providing input to the Reports to Congress.

5. Providing managerial oversight to local offices.


2. The Deputies are also responsible for reviewing and evaluating the program in their respective areas. They ensure that the program is conducted in accordance with national guidelines and instructions and that LTAs are carrying out their responsibilities.


**1.1.8.3.1.2** **(06-07-2024)**

##### Executive Director, Case Advocacy, Intake and Technical Support

1. The Executive Director, Case Advocacy, Intake and Technical Support (EDCA-ITS) provides leadership and delivers critical support programs that are essential to carrying out the responsibilities of the Office of the Taxpayer Advocate. EDCA-ITS provides intake assistance as well as technical support and procedural guidance to Case Advocates. It works with Case Advocacy to provide service to taxpayers. It also collaborates with Systemic Advocacy and works with IRS operating divisions to address systemic issues and to improve procedures for resolving taxpayer issues. EDCA-ITS has responsibility for all guidance and case-related policy and guidance, case technical advisors, as well as the Centralized Case Intake (CCI) telephone function.

2. The EDCA-ITS is responsible for providing leadership and direction to:



1. CCI

2. NTA Toll-Free Operations

3. Deputy ITS, Technical Support


**1.1.8.3.1.2.1** **(06-07-2024)**

###### Centralized Case Intake

1. CCI is staffed by Intake Advocates who receive transferred calls from Wage & Investment (W&I) assistors and the IRS Toll-Free line of taxpayers seeking assistance from TAS. They are typically the first contact taxpayers have with a TAS employee. They conduct in-depth interviews during those calls to determine the correct disposition of taxpayer issues. Their primary focus and goal is to assist taxpayers at the earliest possible moment, while reserving the skills and experience of Case Advocates to focus on the most complex cases. They assist taxpayers with self-help options, tax actions where possible to resolve the issue up-front, create cases after validating the taxpayer meets TAS criteria (see IRM 13.1.7), or refer the taxpayer to the appropriate IRS operating division for assistance.


**1.1.8.3.1.2.1.1** **(06-07-2024)**

###### NTA Toll-Free Operations

1. W&I Accounts Management assigns employees who are responsible for answering incoming calls on the NTA’s Toll-Free Intake Line (877-777-4778).

2. The CCI function provides policy and guidance to NTA assistors who answer incoming calls on the NTA Toll-Free Intake Line.

3. For additional information, see IRM 13.3.1, NTA Toll-Free Procedures.


**1.1.8.3.1.2.2** **(06-07-2024)**

###### Deputy ITS, Technical Support

1. The Deputy ITS, Technical Support is responsible for all guidance and case-related policy and guidance and case technical advisors. Technical Support assists Case Advocacy and other organizations in TAS by helping resolve complex cases, providing data and analysis of case inventory, and issuing technical guidance.

2. The Deputy ITS, Technical Support is responsible for providing leadership and direction to:



1. Internal Technical Advisor Program (ITAP)

2. Technical Analysis and Guidance (TAG)

3. Business Assessment (BA)

4. Quality Review Program (QRP)


**1.1.8.3.1.2.2.1** **(06-07-2024)**

###### Internal Technical Advisor Program

1. ITAP is comprised of Revenue Agent Technical Advisors, Revenue Officer Technical Advisors, and Account Technical Advisors, who are responsible for resolving the most technically or procedurally complex or sensitive case-related issues. ITAP performs case reviews and provides timely, case-specific technical guidance to Case Advocates in the areas of Collection, Exam, and Account issues.

2. ITAP develops and provides issue specific training to TAS employees based on the needs of the requesting office or area.

3. For additional information on ITAP, see IRM 13.1.12, Internal Technical Advisor Program.


**1.1.8.3.1.2.2.2** **(06-07-2024)**

###### Technical Analysis and Guidance

1. TAG develops, issues, and maintains the policies and procedures used by Case Advocacy employees and performs data analysis and reporting on TAS’s casework. It issues guidance through the IRM, Internal Guidance Memos, delegation orders, and other internal resources. It provides data and analysis to other headquarters offices for town hall meetings, Reports to Congress, Systemic Advocacy issues, and to Case Advocacy for issues impacting TAS inventories.

2. TAG develops and maintains the following tools used by Case Advocacy employees:



1. Internal Revenue Manuals

2. Internal Guidance Memorandums

3. Case Assistance by Issue Code

4. Question Resolution Information System

5. Case Advocacy Technical Library


3. TAG provides TAS leadership with case related data from the Taxpayer Advocate Management Information System (TAMIS) and information regarding trends and emerging issues within TAS casework.

4. Reporting to the Director, TAG are:



1. Chief Policy, Accounts

2. Chief Policy, Compliance


**1.1.8.3.1.2.2.3** **(06-07-2024)**

###### Business Assessment

1. BA leads TAS’s performance management, including reporting of TAS’s business results and balanced measures (customer satisfaction, employee engagement, and quality). It oversees TAS’s fiscal year operational plan, and coordinates continuity and contingency planning. BA also tracks and reports performance trends ( _e.g._, monthly business results reports, town hall materials).


**1.1.8.3.1.2.2.4** **(06-07-2024)**

###### Quality Review Program

1. QRP measures organizational performance meeting prescribed quality attributes, which are based on IRM procedures and other official guidance. The attributes focus on resolving taxpayer issues, protecting and informing taxpayers of their rights, keeping taxpayers informed, and identifying systemic issues that will assist IRS leadership in integrating the taxpayer’s perspective into tax administration.

2. QRP measures the organization performance for Case Advocacy casework and Systemic Advocacy projects and measures the accuracy of TAMIS data TAS uses for external and internal reporting. TAS uses quality review results to assess effectiveness in advocating for taxpayers and making improvements TAS’s case procedures.


**1.1.8.3.1.3** **(06-07-2024)**

##### Executive Director, Operations Support

1. The Executive Director, Operations Support is responsible for providing direction and leadership to:



1. Deputy Operations Support

2. Financial Operations

3. Business Systems Planning (BSP)

4. Communications, Stakeholder Liaison & Online Services (CSO)


**1.1.8.3.1.3.1** **(06-07-2024)**

###### Deputy Operations Support

1. The Deputy Operations Support is responsible for providing direction and leadership to:



1. Learning & Education (L&E)

2. Case Advocate Training Support (CATS)

3. Leadership Development & Support Office (LDSO)


**1.1.8.3.1.3.1.1** **(06-07-2024)**

###### Learning & Education

1. L&E oversees the development and delivery of all TAS-specific training. This includes administration and support for Integrated Talent Management course documentation and reports, and coordination with IRS’s Human Capital Office training component.

2. L&E oversees the development and delivery of the training programs for newly hired Case and Intake Advocates.


**1.1.8.3.1.3.1.2** **(06-07-2024)**

###### Case Advocate Training Support

1. CATS supports the development and delivery of the training program for newly hired Case Advocates by providing classroom and on-the-job instructors.

2. When performing TAS case work these CATS positions are equivalent to the following Case Advocacy positions:



   - Lead Case Advocacy Training Specialist (LCAT) is equivalent to an LCA.

   - CATS Frontline Manager is equivalent to a Taxpayer Advocate Group Manager.

   - CATS Director is equivalent to a Senior Local Taxpayer Advocate.


3. Although the CATS positions have different titles, these positions use the same IRS position descriptions as LTAs, TAGMs, and LCAs, respectively. Thus, CATS employees exercise the same delegations of authority to perform specific actions on taxpayer accounts. They also use the same Integrated Data Retrieval System (IDRS) command codes and are subject to the same security requirements in IDRS, TAMIS, and other IRS programs/systems.


**1.1.8.3.1.3.1.3** **(06-07-2024)**

###### Leadership Development & Support Office

1. The LDSO offers an array of programs and resources in support of employees’ professional self-development goals. LDSO programs include:




| Program Name | Program Description |
| --- | --- |
| Coaching Program | Pairs employees with certified coaches to help identify personal and career goals, remove obstacles, and implement a plan of action for success. |
| Leadership Readiness Programs: | Designed to identify and develop high-potential, motivated employees for all management levels. Programs include:<br> <br>   - Intake Leadership Development Program<br>     <br>   - Leading Leaders Readiness Program<br>     <br>   - Executive Readiness Program<br>     <br>   - Candidate Development Program support |
| Leadership Succession Review | Structured to identify opportunities and goals; used for leadership succession plan and personal growth. |
| Mentor Program | Enables each participant to grow, learn, transform, and accomplish goals for development. A good mentoring relationship provides benefits to the mentor, the protégé, and the organization. |
| Mock Interview Program/Career Pathing | Supports employees at all career levels by providing mock interviews and using both private sector and government best practices to identify leadership attributes. |
| Operations Specialist - Aspiring Analyst Program | Designed to identify and develop high-potential, motivated employees interested in becoming an analyst. |
| Professional Development Resources | Provides education of the many career development and investment resources, such as LinkedIn Learning, Percipio, and the Career Learning Plan. |
| TAS Detail Opportunities Program | LDSO supports leadership in the posting of all non-bargaining unit detail opportunities by helping define the knowledge, skills, and abilities required for the detail, and actively promotes all detail postings to TAS employees. |


**1.1.8.3.1.3.2** **(06-07-2024)**

###### Financial Operations

1. Financial Operations manages the human resources and financial services for TAS. It formulates and executes the TAS centralized financial plan, which includes funding for salaries, benefits, awards, overtime, travel, training, supplies, services, and contracts.

2. The human resources function provides a full range of programs and services covering hiring, pay administration, special hiring programs, position classification/position management, employee performance and development (ePerformance), HR Connect reporting, Personnel Action Requests, CareerConnector templates, and report writing.


**1.1.8.3.1.3.3** **(06-07-2024)**

###### Business Systems Planning (BSP)

1. The BSP office represents the interests of TAS in partnerships with IRS Information Technology and other operating divisions to develop strategies, integrate technology, and enhance business processes to improve TAS’s ability to advocate.

2. The Director, BSP is responsible for providing direction and leadership to:



1. TAS Solutions and Development (TSD)

2. TAS Systems Operations and Support


**1.1.8.3.1.3.3.1** **(06-07-2024)**

###### TAS Solutions and Development

1. TSD leverages technology tools to automate and improve the efficiency of TAS business processes. It partners with TAS staff to deliver solutions to complex business needs. The group supports collaboration tools ( _e.g._, SharePoint), data reporting systems ( _e.g._, Business Objects and Tableau), and information security and privacy compliance activities for TAS systems.

2. TSD partners with other TAS functions to deliver electronic resources such as the Taxpayer Advocate Service Information System, Welcome Screen, the Case Assistance by Issue Code tool, and the Case Advocacy Technical Library.

3. TSD ensures TAS meets it Federal Information Security Management Act security requirements for TAMIS and SAMS.


**1.1.8.3.1.3.3.2** **(06-07-2024)**

###### TAS Systems Operations and Support

1. TAS Systems Operations and Support supports the maintenance and updates to TAMIS and SAMS. It ensures TAS employees have access to IRS systems and tools such as Integrated Automation Technologies, the Report Generation Software, the Correspondence Imaging System, and the Accounts Management System. If provides end-user support for technology equipment and software, including laptops, operating systems, software, printers, telecom products, and shared data storage.


**1.1.8.3.1.3.4** **(06-07-2024)**

###### Communications, Stakeholder Liaison & Online Services (CSO)

1. CSO is responsible for all internal and external TAS communications, coordination and implementation strategies for communication campaigns and management of TAS digital platforms. CSO also manages TAS design and writing standards and oversees all video products and production. CSO communication programs, projects, products, and platforms include:



|     |     |
| --- | --- |
| Program | Additional Information |
| TAS digital media | - [https://taxpayeradvocate.irs.gov/](https://taxpayeradvocate.irs.gov/)<br>     <br>   - [https://www.irs.gov/taxpayer-advocate](https://www.irs.gov/taxpayer-advocate)<br>     <br>   - [https://www.litctoolkit.com/](https://www.litctoolkit.com/)<br>     <br>   - [https://www.improveirs.org](https://www.improveirs.org/)<br>     <br>   - TAS social media platforms (Facebook, Twitter, YouTube, and Linked In)<br>     <br>   - Multimedia - videos, data visualization, graphics - internal and external<br>     <br>   - TAS Welcome Screen |
| Local and National Outreach Program Oversight | - Outreach materials and publications - internal and external, including congressional outreach |
| Congressional Affairs Program |  |
| ARC and Objectives Report to Congress | - Media Outreach |
| TAS education/awareness internally and externally | - Marketing campaigns<br>     <br>   - News releases<br>     <br>   - Communication vehicle/products<br>     <br>   - Communication and Project Strategies<br>     <br>   - TAS video programs<br>     <br>   - TBOR Outreach<br>     <br>   - IRS Nationwide Tax Forums |

2. CSO is also responsible for providing leadership and direction to:



1. Marketing & Communications (M&C)

2. Multimedia & Technology (M&T)


3. For additional information, see IRM 13.6, Taxpayer Advocate Service Communications.


**1.1.8.3.1.3.4.1** **(06-07-2024)**

###### Marketing & Communications (M&C)

1. M&C is responsible for internal, external, and congressional outreach strategies and materials, including coordinating Problem Solving Day events and directing the Congressional Affairs Program and conference.

2. M&C oversees educational and awareness campaigns for key issues such as taxpayer rights, TAS advocacy, and emerging and recently enacted tax laws.

3. M&C has oversight of the design, publication, and outreach for the NTA’s Reports to Congress and manages the design and writing standards for TAS to ensure communications are consistent, visually compelling, and easy to understand.


**1.1.8.3.1.3.4.2** **(06-07-2024)**

###### Multimedia & Technology (M&T)

1. M&T manages development and content for all internal websites, external TAS websites, the LITC website, internal and external websites for TAP, and cloud server hosting.

2. M&T manages audio and video messages and social media messaging.


**1.1.8.3.2** **(06-07-2024)**

#### Executive Director, Systemic Advocacy

1. The EDSA has responsibility for the TAS programs that address systemic problems within the IRS, including management of the NTA’s Reports to Congress and the technical liaison program. SA also serves as the TAS liaison for issues covering IRS policy and procedures, negotiating changes impacting IRS internal guidance as published in various internal management documents and distributed to taxpayers through correspondence.

2. SA identifies, studies and seeks to resolve problems, both proactively and reactively, that affect groups of taxpayers, including problems that affect individuals, businesses, or other types of entities.

3. SA helps to coordinate and produce the Annual Report to Congress (ARC) and the June Objectives Report to Congress (JRC). In addition, SA tracks the responses of the IRS to the recommendations contained within the ARC. See IRM 13.2.8, National Taxpayer Advocate’s Annual Reports to Congress (ARC).

4. SA collaborates with the IRS on various task forces, Executive Steering Committees, etc.

5. SA develops networks and builds relationships with IRS stakeholders to advocate using data and case examples to help drive change.

6. SA works closely with the Executive Director Case Advocacy, Intake and Technical Support (EDCA-ITS) and others in TAS on the technical aspects of issues.

7. The EDSA is also responsible for providing leadership and direction to:



1. Deputy Director for Systemic Advocacy, Proactive Advocacy (DEDSA-PA)

2. Deputy Director for Systemic Advocacy, Technical Advocacy (DEDSA-TA)

3. TAS Attorney Advisors

4. Taxpayer Advocacy Panel


8. For more information, see IRM 13.2, Systemic Advocacy.


**1.1.8.3.2.1** **(06-07-2024)**

##### Deputy Director for Systemic Advocacy, Proactive Advocacy

1. The DEDSA-PA is responsible for proactively identifying systemic problems and advocating for their resolution. This is accomplished by:



1. Managing and coordinating both NTA’s Reports to Congress for timely release through collaboration with various IRS functions and internal TAS stakeholders, and tracking the IRS responses to the recommendations identified in the ARC and publishing updates to the [ARC Recommendations Tracker](https://www.taxpayeradvocate.irs.gov/arc-recommendations-tracker/) about the inventory of the IRS's actions taken, partially taken, or not taken in response to recommendations made in the most serious problems section of the ARC. See IRM 13.2.8, National Taxpayer Advocate’s Annual Reports to Congress (ARC);

2. Ensuring issues submitted through the Systemic Advocacy Management System (SAMS) are evaluated and resolved timely, or when appropriate, elevated for monitoring or further research, and acknowledging TAS has received the submission, contacting the submitter when clarification is needed, and informing the submitter of the disposition once it is closed; and

3. Ensuring TAS reviews all official communications ( _e.g._, IRMs, letters, notices, publications, guidance documents, forms and training materials) provided to taxpayers and employees. The goal is to ensure the communications protect/respect taxpayer rights and minimizes taxpayer burden while interacting with the IRS.


2. The DEDSA-PA is also responsible for providing leadership and direction to:



   - Annual Report to Congress/Objectives Report to Congress Program Managers

   - Advocacy Efforts

   - Advocacy Implementation & Evaluation

   - Research & Analysis


**1.1.8.3.2.1.1** **(06-07-2024)**

###### Advocacy Implementation & Evaluation

1. Advocacy Implementation & Evaluation includes two groups that advocate for changes in IRS guidance, policy, and procedures.



1. Internal Management Document (IMD)/Single Point of Contact (SPOC) is responsible for the coordination, development, clearance, publication, and obsolescence of TAS IMD products, such as IRMs and Interim Guidance. They also coordinate with IRS operating divisions on external IMD product clearance and revisions recommendations.

2. Systemic Issue Review and Evaluation manages the issues submitted to SAMS. The group evaluates each submission to validate the issue, and if appropriate, funnels the issue to other staff who work on resolving the problem. The submitter is informed of the issue’s disposition when the issue is closed. See IRM 13.2.3, Evaluating and Reviewing Systemic Issues.


**1.1.8.3.2.1.2** **(06-07-2024)**

###### Research & Analysis

1. Research & Analysis (R&A) conducts research studies on various taxpayer issues or topics. R&A operates as an advisory function providing a structured approach to problem solving and data analysis. The staff also contributes to the mission of TAS by providing statistical information and research support for the Reports to Congress, NTA congressional testimony, systemic advocacy projects, NTA blogs, web postings, and various task force efforts.

2. The R&A staff represents TAS in committees and work groups, develops projections, designs and implements surveys, and consults with employees about research-related issues.


**1.1.8.3.2.2** **(06-07-2024)**

##### Deputy Director for Systemic Advocacy, Technical Advocacy

1. The DEDSA-TA advocates for the resolution of systemic problems through its work on IMD/SPOC reviews, Reports to Congress teams, advocacy projects, and other collaborative efforts. There are three technical groups - Collection, Examination, and Processing. Each works with the IRS to resolve the problems specific to its area of expertise, makes recommendations for policies and procedure changes to protect taxpayer rights and improve tax administration, negotiates policy and procedural changes, tracks the IRS implementation of negotiated changes, and follows up with the IRS as needed. If the problems demand an urgent resolution because they are causing immediate and significant harm to multiple taxpayers, then Technical Accuracy will open an immediate intervention. See _IRM 1.1.8.1.3_, for a definition of immediate intervention. Less urgent issues use an advocacy project. The DEDSA-TA is also responsible for providing leadership and direction to:



1. SA Collection Technical Advocacy Team which specializes in collection issues.

2. SA Exam Technical Advocacy Team which specializes in examination issues.

3. SA Processing Technical Advocacy Team which specializes in campus processing issues.

4. Taxpayer Advocacy Panel (TAP).


**1.1.8.3.2.2.1** **(11-04-2022)**

###### Taxpayer Advocacy Panel

1. The TAP is a Federal Advisory Committee of citizen volunteers who are demographically and geographically diverse; to the extent possible, members represent every state, the District of Columbia, and Puerto Rico. In addition, the TAP seeks to include at least one member representing international taxpayers (U.S. citizens working, living, or doing business abroad).

2. TAP volunteers listen to taxpayers’ concerns, identify taxpayers’ issues, and make suggestions for improving IRS customer service and responsiveness to taxpayer needs. TAP provides a national forum to listen to concerns from taxpayers’ and works with TAS and the IRS to identify issues that would benefit from citizen input.

3. For more information on TAP processes, see IRM 13.7.1, Taxpayer Advocacy Panel Program.


**1.1.8.3.2.3** **(06-07-2024)**

##### Advocacy Efforts Group

1. Advocacy Efforts staff is responsible for operational reviews and coordinates the cross-functional Director review and issue treatment decision of SAMS submissions.

2. The Advocacy Efforts staff coordinates the revisions to the SA IRM for project work and organizes the submission of data from SA program leaders for the Systemic Trends and Analysis Report.


**1.1.8.3.2.4** **(06-07-2024)**

##### TAS Attorney Advisors

1. TAS Attorney Advisors provide independent advice and guidance to the NTA and TAS on a wide variety of issues. While TAS Attorney Advisors work closely with CCNTA on various projects, the group is not part of the IRS Office of Chief Counsel and can advocate for positions differing from the Office of Chief Counsel.

2. TAS Attorney Advisors can help provide employees with the correct interpretation of the law. However, for an official legal opinion to resolve a particular problem with the TAS Attorney Advisors to obtain an opinion from the IRS Office of Chief Counsel.

3. TAS Attorney Advisors research and draft the Annual Report to Congress, develop the Purple Book of Legislative Recommendations, and compile the Most Litigated Issues report. TAS Attorney advisors also review and comment on guidance, policies and procedures, technical manuals, IRS letters, IRS forms, and other IRS actions. TAS Attorney Advisors may assist with Case Advocacy cases, Systemic Advocacy issues and projects, and may assist with drafting or reviewing of Taxpayer Assistance Orders, Operations Assistance Requests, and Taxpayer Advocate Directives. TAS Attorney Advisors engage with external stakeholders, including at conferences and meetings, by making presentations, receiving feedback, and discussing issues in tax administration. TAS Attorney Advisors research and prepare responses to constituent and other inquiries from Congress and other legislative agencies (Office of Management and Budget, Government Accountability Office, _etc._).


**1.1.8.3.3** **(06-07-2024)**

#### Low Income Taxpayer Clinic Program Office

1. The LITC Program Office provides guidance, assistance, and oversight to LITCs that are awarded federal grants administered by TAS. LITCs assist individuals whose income is below a certain level who need to resolve tax problems with the IRS. They also provide education, outreach, and information on taxpayer rights to individuals who speak English as a second language. LITCs represent taxpayers in disputes before the IRS and courts and help taxpayers respond to IRS notices and correct account problems. Services are offered for free or a small fee. LITCs are independent from the IRS and TAS. See IRM 13.8.1, Low Income Taxpayer Clinic Program Operating Procedures, on the LITC Program Office functions.

2. LTA offices assist the LITC Program Office through regular contact and yearly visits to the clinics to which they are assigned. LTA staff, Systemic Advocacy employees, and clinicians sometimes work together to resolve individual taxpayer issues or identify and address systemic issues impacting taxpayers.


**1.1.8.3.4** **(06-07-2024)**

#### Senior Advisor to the NTA

1. The Senior Advisor to the NTA serves as the NTA’s principal advisor on policy and strategic issues, serves as the NTA’s principal liaison with senior IRS personnel in coordinating NTA reports to Congress, and manages congressional affairs, media relations, and the NTA’s relationships with key stakeholders. This individual also manages the development and content of the NTA’s Purple Book of legislative recommendations that the NTA submits to Congress each year as part of the NTA Annual Report.


**1.1.8.3.5** **(06-07-2024)**

#### Senior Advisor to the NTA - Research

1. The Senior Advisor to the NTA for research acts as a liaison between TAS and other IRS research functions, interprets research reports from sources inside and outside the IRS, provides advice to TAS leadership on developing methodologies to conduct research initiatives, provides oversight for the research and data verification occurring in conjunction with the ARC and JRC, including working with other IRS functions to resolve data verification, and develops the yearly TAS research agenda in consultation with the NTA.


**1.1.8.4** **(06-07-2024)**

### Division Counsel/Associate Chief Counsel (National Taxpayer Advocate Program)

1. The Division Counsel/Associate Chief Counsel (National Taxpayer Advocate Program) (CCNTA) and staff are employed by the Office of Chief Counsel to provide legal advice and support to the NTA and TAS headquarters employees.

2. CCNTA advises the NTA and TAS about the scope of TAS’s statutory or delegated authority; issues involving TAS legislative proposals or any other matter related to the NTA’s Reports to Congress; and the issuance of Counsel guidance, legislative proposals, regulations, and other advice that impacts areas of interest to the NTA and TAS.

3. CCNTA is responsible for legal interpretations of the following assigned sections of the Internal Revenue Code: 7526 (low income taxpayer clinics), 7803(a)(3) (taxpayer rights), 7803(c) (Office of the Taxpayer Advocate, including reports to Congress, confidentiality, Taxpayer Advocate Directives), and 7811 (taxpayer assistance orders).

4. Under IRC 7803(b)(2), Counsel is responsible for interpreting the Internal Revenue Code. If TAS employees need an official legal opinion to resolve a TAS case or systemic issue, they should work with the TAS Attorney Advisors to obtain an opinion from the Office of Chief Counsel. See IRM 13.1.10.2, Obtaining Legal Advice from Chief Counsel. But see _IRM 1.1.8.3.2.4_, TAS Attorney Advisors, for details about when to use the TAS Attorney Advisors.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-001-008#addtoany "Show all")

A2A