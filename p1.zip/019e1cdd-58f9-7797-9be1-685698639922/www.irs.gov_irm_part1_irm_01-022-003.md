---
url: "https://www.irs.gov/irm/part1/irm_01-022-003"
title: "1.22.3 Addressing and Packaging | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-022-003#main-content)

- 1.22.3  [Addressing and Packaging](https://www.irs.gov/irm/part1/irm_01-022-003#idm140285178337616)
  - 1.22.3.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-022-003#idm140285177533952)
    - 1.22.3.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-022-003#idm140285178248960)
    - 1.22.3.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-022-003#idm140285148538288)
    - 1.22.3.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-022-003#idm140285148649216)
    - 1.22.3.1.4  [Frequently Used Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-022-003#idm140285178427888)
    - 1.22.3.1.5  [Related Resources](https://www.irs.gov/irm/part1/irm_01-022-003#idm140285148561728)
  - 1.22.3.2  [IRS Addressing Standards](https://www.irs.gov/irm/part1/irm_01-022-003#idm140285178470992)
    - 1.22.3.2.1  [Types of IRS Addresses](https://www.irs.gov/irm/part1/irm_01-022-003#idm140285178468688)
    - 1.22.3.2.2  [National Office Mailroom Addressing](https://www.irs.gov/irm/part1/irm_01-022-003#idm140285148800800)
  - 1.22.3.3  [Addressing Requirements](https://www.irs.gov/irm/part1/irm_01-022-003#idm140285144021904)
    - 1.22.3.3.1  [ZIP Codes](https://www.irs.gov/irm/part1/irm_01-022-003#idm140285148630640)
    - 1.22.3.3.2  [Return Address](https://www.irs.gov/irm/part1/irm_01-022-003#idm140285148666928)
  - 1.22.3.4  [Addressing Standards for International Mail](https://www.irs.gov/irm/part1/irm_01-022-003#idm140285177267488)
  - 1.22.3.5  [Business Reply Mail (BRM)](https://www.irs.gov/irm/part1/irm_01-022-003#idm140285143881088)
    - 1.22.3.5.1  [Establishing a Business Reply Mail (BRM) Account](https://www.irs.gov/irm/part1/irm_01-022-003#idm140285148962672)
    - 1.22.3.5.2  [Reporting Requirements](https://www.irs.gov/irm/part1/irm_01-022-003#idm140285148975808)
  - 1.22.3.6  [Avoid Common Addressing Errors](https://www.irs.gov/irm/part1/irm_01-022-003#idm140285148958064)
  - 1.22.3.7  [Proper Packaging/Mailing Guidelines](https://www.irs.gov/irm/part1/irm_01-022-003#idm140285148967616)
  - 1.22.3.8  [Requirements for Shipping Personally Identifiable Information (PII)](https://www.irs.gov/irm/part1/irm_01-022-003#idm140285148891440)
  - 1.22.3.9  [Standard Mail/Shipping Supplies](https://www.irs.gov/irm/part1/irm_01-022-003#idm140285148884592)

# Part 1. Organization, Finance, and Management

# Chapter 22. Mail and Transportation Management

# Section 3. Addressing and Packaging

* * *

## 1.22.3 Addressing and Packaging

#### Manual Transmittal

December 09, 2024

#### Purpose

(1) This transmits revised IRM 1.22.3, Mail and Transportation Management, Addressing and Packaging.

#### Material Changes

(1) **IRM 1.22.3** revised throughout to update organizational title Wage and Investment to Taxpayers Services.

#### Effect on Other Documents

IRM 1.22.3, Mail and Transportation Management, Addressing and Packaging, dated and effective November 14, 2022, is superseded.

#### Audience

IRS Employees

#### Effective Date

(12-09-2024)

Maria Cheeks

Acting Director, Distribution

Taxpayer Services

**1.22.3.1** **(01-14-2021)**

### Program Scope and Objectives

1. Purpose: This section of the IRM describes mailing and shipping requirements for IRS offices. It includes the various types of IRS addresses.

2. Audience: All IRS employees, and those responsible for making decisions in either mail or transportation management.

3. Policy Owner: The responsibility of administering the IRS mail and transportation management program falls under the direction of the Commissioner, Taxpayer Services (TS).

4. Program Owner: Technology and Program Support (TPS) is the program office responsible for overseeing and providing guidance for the Mail and Transportation Management.

5. Primary Stakeholders:



> - IRS Business Units
>
>    - Technology and Program Support
>
>    - Postal and Transportation Policy
>
>    - All employees using mailing and shipping services

6. Program Goals: To provide the IRS standards and requirements to properly mail or ship items using the US Postal Service or Small Package Carrier (SPC).


**1.22.3.1.1** **(08-10-2018)**

#### Background

1. Address accuracy affects the speed and handling of IRS mail and small packages. Using complete, correct and properly formatted address information is critical to timely and safe delivery.


**1.22.3.1.2** **(01-14-2021)**

#### Authority

1. [41 CFR 102-192](https://www.ecfr.gov/current/title-41/subtitle-C/chapter-102/subchapter-G/part-102-192), Mail Management

2. Policy Statement 1-113, Postage-paid envelopes furnished with third party inquiries

3. IRM 1.2.1, Servicewide Policies and Authorities, Servicewide Policy Statements

4. IRM 10.5.1, Privacy and Information Protection, Privacy Policy


**1.22.3.1.3** **(01-14-2021)**

#### Roles and Responsibilities

1. Taxpayer Services(TS)/Media and Publications (M&P)/Technology and Program Support (TPS) provides guidance and support to the affected stakeholders, including expense verification, adjustments, and reconciliation.

2. Postal and Transport (PTP):



> 1. Develops and evaluates policies, systems, procedures and standards for mail and transportation services
>
> 2. Serves as Contracting Officer Representatives (CORs) on Mail and Transportation contracts and Tenders of Service
>
> 3. Has stewardship of the Private Delivery Service application process

3. Facilities Management and Security Services (FMSS)/Office of the Deputy Director Facilities Support/Logistics:



> 1. Oversees the operation of the Mail Management program.
>
> 2. Establishes a Territory Point of Contact (TPOC) who provides mail management program guidance for mailroom operations and mail services within their Territory.
>
> 3. Coordinates Servicewide field office mailroom operations and mail delivery services
>
> 4. Serves as the Contracting Officer’s Representatives (COR) for the National Mailroom Services Contract, and the National Postal Meter Contract
>
> 5. Communicates changes in policy to field offices
>
> 6. Provides TPOCs with training and education

4. Business Operating Divisions (BOD) assign Local Points of Contact (LPOC) in IRS Field offices that are not serviced by the Primary Mail Contractor, The LPOC serves as the primary contact for the FMSS Mail Program TPOC.


**1.22.3.1.4** **(11-14-2022)**

#### Frequently Used Terms and Acronyms

1. **Terms** \- The following chart contains mail terms and their definitions used throughout this IRM .



**Terms**






| **Term** | **Definition** |
| --- | --- |
| Mail | Correspondence that consists of letters, memoranda, post cards, documents, forms, packages, publications, computer tapes and tax data (returns and remittances). |
| Official Mail | Mail sent by U.S. Government agencies that relates solely to the business of the U.S. Government, authorized by law to be transported in the mail without prepayment of postage. |
| Penalty Mail | Official Mail sent without the prepayment of postage by U.S. Government Agencies. Mail must have the endorsement words “Official Business/Penalty for Private Use $300” printed on the mail. |
| Business Reply Mail (BRM) | A service that allows customers to send a reply via First-Class Mail without affixing postage. The IRS pays the postage and a per piece handling fee only for the pieces returned. |
| Unique Zip Code | A three-digit ZIP Code prefix assigned to a company, government agency with sufficient mail volume (e.g., 005, 192, 555) along with all possible five-digit ZIP Codes created from the three-digit prefix (00501, 19299, 55555) |

2. **Acronyms -**The following chart is a list of Acronyms and their definitions used throughout this IRM.



**Acronyms**






| **Acronym** | **Definition** |
| --- | --- |
| AA | Armed Forces America |
| AE | Armed Forces Europe |
| AP | Armed Forces Pacific |
| APO | Air/Army Post Office |
| BFC | Beckley Finance Center |
| BOD | Business Operating Division |
| BRM | Business Reply Mail |
| CMO | Capital Management & Oversight |
| CMR | Consolidated Mailroom |
| COR | Contracting Officer’s Representative |
| DMM | Domestic Mail Manual |
| FPO | Fleet Post Office |
| IMM | International Mail Manual |
| OLMA | Office Locations and Mailing Addresses |
| OMAS | Official Mail Accounting System |
| PII | Personally Identifiable Information |
| PSC | Personal Service Center |
| PTP | Postal and Transport Policy |
| TS | Taxpayer Services |
| TPS | Technology and Program Support |
| SPC | Small Package Carrier |
| TPOC | Territory Point of Contact |
| USPS | United States Postal Service |
| ZIP | Zone Improvement Plan |


**1.22.3.1.5** **(11-14-2022)**

#### Related Resources

1. Related resources include:



> - IRM 1.22.1, Mail and Transportation Management Overview
>
>    - IRM 10.5.1.6.9.3, Shipping
>
>    - Document 12534, Mail Desk Guide for Territory Point-of-Contact
>
>    - Document 13011, Envelope User Guide
>
>    - Document 13056, Shipping Procedures for Personally Identifiable Information (PII)
>
>    - [USPS Domestic Mail Manual (DMM)](https://pe.usps.com/text/DMM300/DMM300_landing.htm)
>
>    - [USPS International Mail Manual (IMM](https://pe.usps.com/text/imm/welcome.htm))
>
>    - [USPS Publication 25](https://about.usps.com/publications/pub25/welcome.htm), Designing Letter and Reply Mail
>
>    - [USPS Publication 28](https://pe.usps.com/text/pub28/welcome.htm), Postal Addressing Standards
>
>    - USPS web site at: [http://www.usps.com](http://www.usps.com/)
>
>    - Office Locations and Mailing Addresses (OLMA)


**1.22.3.2** **(08-10-2018)**

### IRS Addressing Standards

1. IRS addressing standards contain the required elements to properly format a complete delivery address and describe the types of addresses used by the IRS.

2. All mailing lists and address files should be reviewed for accuracy and updated at least four times a year by the list owner.


**1.22.3.2.1** **(11-14-2022)**

#### Types of IRS Addresses

1. The IRS utilizes various types of addresses:



> 1. **Street Address** \- Used to receive First-Class Mail, bulk mail, Small Package Carrier (SPC) shipments and freight deliveries
>
> 2. **IRS Unique ZIP Code Address**\- Used for general and revenue bearing mail from the public. The unique ZIP Code aids the United States Postal Service (USPS) in processing large volumes of taxpayer mail. Mail or deliveries from the IRS and other sources (besides the taxpayer) will utilize the street address. This includes all classes of USPS mail, SPC and freight deliveries
>
> 3. **P.O. Box Addresses** \- Typically used by a specific function within an office. The address usually receives First-Class Mail. P.O. Box addresses may only be used for USPS deliveries
>
> 4. **Lock Box Addresses**\- P.O. Boxes established by commercial banks to accelerate the handling and deposit of tax payments

2. Street Address - The street address for each Campus/Submission Processing Center/Accounts Management Center is shown below. All general administrative mail and/or SPC deliveries from IRS and other sources should utilize the following street addresses:



**Street Addresses**





|     |     |
| --- | --- |
| Internal Revenue Service<br> 310 Lowell St<br> Andover MA 01810-4544 | Internal Revenue Service<br> 4800 Buford Hwy<br> Atlanta GA 39901-0001 |
| Internal Revenue Service<br> 3651 S Interstate 35<br> Austin TX 78741-7855 | Internal Revenue Service<br> 7940 Kentucky Dr<br> Florence KY 41042-2915 |
| Internal Revenue Service<br> 3211 S Northpointe Dr<br> Fresno CA 93725-1959 | Internal Revenue Service<br> 1040 Waverly Ave<br> Holtsville NY 11742-1129 |
| Internal Revenue Service<br> 333 W Pershing Rd<br> Kansas City MO 64108-4302 | Internal Revenue Service<br> 5333 Getwell Rd<br> Memphis TN 38118-7701 |
| Internal Revenue Service<br> 1973 Rulon White Blvd<br> Ogden UT 84201-1000 | Internal Revenue Service<br> 2970 Market St<br> Philadelphia PA 19104-5002 |

3. Unique Zip Code Address - Each Campus/Submission Processing Center/Accounts Management Center has an assigned (3 line) unique ZIP Code address. The following addresses are ONLY to be used for taxpayer correspondence or remittances mailed through the USPS:



**Unique ZIP Code Addresses**





|     |     |
| --- | --- |
| Internal Revenue Service<br> Customer Service Center<br> Andover MA 05501 | Internal Revenue Service<br> Customer Service Center<br> Atlanta GA 39901 |
| Department of the Treasury<br> Internal Revenue Service<br> Austin TX 73301 | Internal Revenue Service<br> Customer Service Center<br> Cincinnati OH 45999 |
| Department of the Treasury<br> Internal Revenue Service<br> Fresno CA 93888 | Internal Revenue Service<br> Customer Service Center<br> Holtsville NY 00501 |
| Department of the Treasury<br> Internal Revenue Service<br> Kansas City MO 64999 | Internal Revenue Service<br> Customer Service Center<br> Memphis TN 37501 |
| Department of the Treasury<br> Internal Revenue Service<br> Ogden UT 84201 | Internal Revenue Service<br> Customer Service Center<br> Philadelphia PA 19255 |

4. The satellite locations listed below should not receive direct deliveries. All mail and packages being sent to a Campus/Submission Processing Center/Accounts Management Center building will bear the central street address for the Campus/Submission Processing Center.



**Campus/Submission Processing Center Central Street Address**






| Campus/Submission Processing Center Central Street Address | Off-Site Satellite Locations (Use the Central Street Address on the Left) |  |
| --- | --- | --- |
| Internal Revenue Service<br> 310 Lowell St<br> Andover MA 01810 | _900 Chelmsford St_<br>_Lowell MA 01851_ |  |
| Internal Revenue Service<br> 3651 S Interstate 35<br> Austin TX 78741 | _1821 Directors Blvd_<br>_Austin TX 78744_ | _4175 Freiderich Ln_<br>_Austin TX 78744_ |
|  | _2101 Saint Elmo Rd_ _Ste 400_<br>_Austin TX 78744_ | _5015 S IH35_<br>_Austin TX 78744_ |
| Internal Revenue Service<br> 7949 Kentucky Dr<br> Florence KY 41011 | _333 Scott Center_<br>_Covington KY 41011_ | _300 Madison Ave_<br>_Covington KY 41011_ |
| Internal Revenue Service<br> 5045 E Butler Ave<br> Fresno CA 93727 | _855 M St_<br>_Fresno CA 93721_ | _1325 Broadway St_<br>_Fresno CA 93721_ |
|  | _4967 E Kings Canyon Ave_<br>_Fresno CA 93727_ |  |
| Internal Revenue Service<br> 1973 Rulon White Blvd<br> Ogden UT 84201 | _1160 W 1200 S_<br>_Ogden UT 84201_ | _1125 W 12th St_<br>_Ogden UT 84201_ |
|  | _105 23rd St_<br>_Ogden UT 84401_ | _2365 Lincoln Ave_<br>_Ogden UT 84401_ |
|  | _2262 Wall Ave_<br>_Ogden UT 84401_ | _2484 S Washington Blvd_<br>_Ogden UT 84401_ |


**1.22.3.2.2** **(08-10-2018)**

#### National Office Mailroom Addressing

1. IRS contracts with an off-site mail processing facility to mitigate contamination risk to headquarters operations. As a result, all USPS and SPC mail/packages destined for the Washington, DC Metro area must be addressed as follows:



> Name and Title
>
> IRS, \[Organizational Symbols\]
>
> \[Building Symbol and Room or Workstation Number\]
>
> 1111 CONSTITUTION AVE NW
>
> WASHINGTON DC 20224

2. The following Washington, DC Metro Offices are serviced by this contract:




| **Building Symbols** | **Location** |
| :-: | :-: |
| K | 77 K St NE, Washington, DC |
| IR | 1111 Constitution Ave NW, Washington, DC |
| NC | 999 N Capital St NE, Washington, DC |
| NCFB | 5000 Ellin Rd, Lanham, MD |

3. The off-site mail processing facility sorts and delivers mail and packages to the above Washington, DC metro offices twice daily. All mail and packages will be delivered to the destination within one workday of arrival at the off-site mail processing facility.


**1.22.3.3** **(01-14-2021)**

### Addressing Requirements

1. Addressing requirements have been established to ensure consistent and proper addressing of mail and packages, which helps ensure timely processing and delivery. The following address practices should be used to address USPS mail:



> 1. The address should be typed, or machine printed in dark ink on a light background, using a simple font type (e.g., San Serif, Arial or Helvetica) in 10 or 12 point
>
> 2. The address should be single spaced and left aligned
>
> 3. The address should use all uppercase letters and no punctuation

2. Address Elements - All mail delivery addresses must contain at least the following elements:



> - Customer or Recipient
>
>    - Delivery Address Line
>
>    - Last Line (City State ZIP Code)

3. Additional address elements may be used depending on the type of address. Standard addresses contain a minimum of three lines of address data.



**Standard Address**






| **Address Element** | **Definition** |
| :-: | --- |
| **Recipient** | Intended recipient's name. |
| **Delivery Address Line** | Street number and name, pre- and post-directional address unit designator or P.O. Box number, suite/apartment number, etc. Dual addresses (both a street address and a P.O. Box number) should not be used |
| **Destination** | City State and ZIP Code (+4 if known) |







**Business Address**






| **Address Element** | **Definition** |
| --- | --- |
| **Attention** | Intended recipient's name/title |
| **Organizational Unit** | Group, department, division, unit/mail stop |
| **Business/Firm Name** | Name of business, firm, organization, or agency.<br> Delivery Address - Street number and name, pre- and post directional address unit designator or P.O. Box number, suite, floor, or room |
| **Destination** | City State and ZIP Code (+4 if known) |







**Overseas Military Address**






| **Address Element** | **Definition** |
| --- | --- |
| **Recipient** | Service member's rank and full name |
| **Delivery Address** | Include the ship name unit number, Consolidated Mailroom (CMR) or Personnel Service Center (PSC) number, and box number, if assigned |
| **Destination** | Air/Army Post Office (APO) or Fleet Post Office (FPO), ("city" designation) and the appropriate two-letter "state" abbreviation, Armed Forces of the America (AA), Armed Forces Europe (AE), or Armed Forces in the Pacific (AP), followed by the ZIP Code (+4 if known) |







### Caution:



Do not include the name of the city and country to ensure the item is handled in the military mail system and not the international mail system. Additional information specific to each Service Branch can be found at: [https://www.usps.com/ship/apo-fpo-dpo.htm](https://www.usps.com/ship/apo-fpo-dpo.htm)


**1.22.3.3.1** **(08-10-2018)**

#### ZIP Codes

1. The ZIP (Zone Improvement Plan) Codes are 9-digit geographical codes that identify postal delivery areas within the United States, its possessions, and territories. The numbered coding system facilitates efficient mail distribution and delivery.

2. The most complete ZIP Code is a 9-digit number consisting of 5 digits, a hyphen and 4 digits, described as "ZIP+4." A required "dash" or "hyphen" separates the first five digits (ZIP Code) from the +4 (last four digits).

3. The +4 digits following the 5-digit ZIP Code:



> 1. May identify multiple blocks, a group of streets, several office buildings, or a small geographic area
>
> 2. May identify one floor of an office building, one side of a street, specific departments in a firm, or a group of P.O. Boxes





**Sample of the 9-Digit ZIP Code - 53092-5450**






| **Sectional Center** | **Delivery Area** | **Delivery Sector** | **Delivery Segment** |
| :-: | :-: | :-: | :-: |
| **530** | **92** | **54** | **50** |

4. There are several types of ZIP+4 Codes used by the IRS. All serve to help USPS to expedite the delivery of mail. They all have specific purposes.



> 1. There are ZIP+4 Codes assigned to represent specific companies, agencies, or organizations, called FIRM. This type of ZIP+4 Code applies when using Courtesy Reply Mail (E-25 CR) envelopes and for return addresses
>
> 2. Unique ZIP+4 Codes are exclusive to a single firm, government agency, etc. IRS uses these for taxpayer remittances
>
> 3. There are special ZIP+4 Codes that are assigned for Business Reply Mail (BRM). These are unique and used only for BRM envelopes, as determined when this ZIP Code was requested

5. These ZIP+4 Codes are specific. If any of the following occurs, a new ZIP+4 Code needs to be established:



> - The address changes
>
>    - The mail size (e.g., letter, post card, flat, etc.) changes
>
>    - The mail weight (e.g., 1 ounce, 2 ounce) changes
>
>    - The mail is being returned from international rather than domestic locations


**1.22.3.3.2** **(08-10-2018)**

#### Return Address

1. All Official Penalty Mail must include a complete agency return address located in the upper left corner of the mail piece.



### Note:



It is important to include a suite or mailroom number with a mail stop or personal identifier in the address. This will help ensure that return mail pieces will be forwarded to the appropriate destination.

2. All Official Penalty Mail must bear the preprinted phrases Official Business and Penalty for Private Use, $300 placed in the return address area. The penalty statement must not be hand or typewritten.



### Example:





**\\_\\_\\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_**


**Official Business**


**Penalty for Private Use, $300**

3. BRM - ZIP+4 is to be used only in the mailing/delivery address of the BRM mail piece (E-25 BR envelope or BRM label). DO NOT use this BRM unique ZIP+4 in the return address.


**1.22.3.4** **(01-14-2021)**

### Addressing Standards for International Mail

1. International address formats should follow the standards and practices of the destination country. Following are general guidelines:



> 1. The recipient line should contain the complete name of the addressee
>
> 2. The complete delivery address must be typed or legibly written in English using all uppercase
>
> 3. The city destination must appear in capital letters together with the correct postal code number or delivery zone number, if any
>
> 4. An address in a foreign language is permitted if the name of the city, province and country are also indicated in English
>
> 5. Foreign postal codes (numeric and/or alpha) should be placed on the line immediately above the country name; some countries prefer that the postal code follow the name, others prefer it to precede the city or town name
>
> 6. The last line must contain only the country name (no abbreviations)
>
>
>
>       ### Example:
>
>
>
>
>
>
>
>
>
>       |     |     |
>       | --- | --- |
>       | MR THOMAS CLARK<br> 117 LONGFORD WAY<br> LONDON WIP 6HQ<br> ENGLAND | MS C P APPLE<br> APARTADO 3068<br> 46807 PUERTO VALLARTA JALISCO<br> MEXICO |

2. Foreign post offices can return mail pieces that do not contain complete sender and addressee information.

3. Certified Mail is not available internationally.

4. Domestic Registered Mail items are handled separately from all other mail and are stored in a secure area. However, International Registered Mail is handled in accordance with the internal procedures of the destination country and does not guarantee the same security as domestic Registered Mail.

5. Postal Service (PS) Form 2865, Return Receipt for International Mail (Avid de Reception), provides evidence of delivery for registered items or Priority Mail International insured parcels. PS Form 2865 (pink card) is attached at the time of mailing and removed and signed at the point of delivery. Return receipts are completed in the country of destination in accordance with its internal regulations, which may require the addressee's signature except under special circumstances.



### Note:



Some countries limit the use of Return Receipts. Specific mailing conditions for the countries and localities can be found in the USPS International Mail Manual (IMM), Individual Country Listings.

6. Some countries may require a PS F2976, Customs Declaration CN 22 form. This form may be required for packages weighing over 1 pound even if the package contains only documents. If this form is required, contact a USPS office.



### Note:



Some countries such as Puerto Rico, Guam, and US Virgin Islands are considered domestic. For a list of countries that are considered domestic and their mailing requirements, see section 608 of the [Domestic Mail Manual (DMM)](http://pe.usps.gov/text/dmm300/608.htm)


**1.22.3.5** **(01-14-2021)**

### Business Reply Mail (BRM)

1. BRM allows customers to send a reply via First-Class Mail without affixing postage. The IRS pays the postage and a per piece handling fee only for the pieces returned. Clerks at the delivery Post Office calculate the amount due and then bill the IRS' Official Mail Accounting System (OMAS) account.

2. IRS furnishes a "Postage and Fees Paid" (Penalty BRM) letter size envelope when requesting information for the convenience of the Government. BRM envelopes must not be used to request information required by law (e.g., remittance mail, liability mail and collection notices).

3. BRM can be domestic or international. BRM sent within the United States and its territories must use a domestic mail permit. International BRM accounts must be established when sent to a foreign country.

4. BRM is subject to strict standards on formatting, markings and addressing. Printed or handwritten alterations are not allowed on BRM envelopes or labels.

5. A BRM account must be established for each type of BRM mail piece (e.g., 1-ounce envelopes, 2-ounce envelopes, post cards, labels for flats, etc.). Since BRM mail pieces are preprinted, this limits the weight of the mail that can be sent in each BRM mail piece.

6. All BRM postage and fees are managed by the Postal and Transport Policy (PTP) Section and funded through the annual postal budget.

7. BRM envelopes cannot be used as a label on a larger envelope (flat), package or box. A custom-designed "Business Reply Label" must be used for this purpose. A separate BRM permit account cannot be established for the specific use with the BRM label.

8. IRS uses two types of BRM permits:



**Types of BRM Permits**






| **Type** | **Definition** |
| --- | --- |
| Basic BRM Permit | For accounts that receive less than 850 returned BRM pieces per year:<br> <br>1. This account requires annual permit fee for a corporate style permit<br>      <br>2. Postage cost is First-Class rate, plus a per piece handling fee |
| Qualified BRM Permit | For accounts that receive 850 or more returned BRM pieces per year:<br> <br>1. This account requires an annual permit fee and an annual accounting fee<br>      <br>2. Postage cost is the First-Class rate, plus a reduced per piece handling fee |


**1.22.3.5.1** **(01-14-2021)**

#### Establishing a Business Reply Mail (BRM) Account

1. The USPS assigns to the IRS, BRM Permit 12686. This permit applies to IRS offices when it is issued an account by its local Post Office.

2. To establish a BRM account, the Territory Point of Contact (TPOC) or a PTP section employee will assist the Business Unit or other applicant in the application process. The following information is required:



> 1. Address where the BRM is to be returned
>
> 2. Size of the mail piece (e.g., envelope, post card, flat) and weight (e.g., 1 ounce, 2 ounce)
>
> 3. Estimated annual return volume

3. A PTP section employee will prepare the PS Form 3615, Mailing Permit Application and Customer Profile, and submit it to the USPS Business Mail Entry Unit, local Post Office, and USPS Mail Design Analyst via fax.

4. USPS will establish the account, assign a ZIP+ 4 Code, and provide approved requested artwork to the PTP Section, who in turn will provide it to the TPOC and/or customer.


**1.22.3.5.2** **(01-14-2021)**

#### Reporting Requirements

1. Individual field offices are not required to track or report BRM volume or costs. BRM postage costs are reported to the Beckley Finance Center (BFC) by the Capital Management & Oversight (CMO) organization, monthly.


**1.22.3.6** **(08-10-2018)**

### Avoid Common Addressing Errors

1. Common addressing errors can be costly and affect the timeliness of the delivery.

2. To avoid the common addressing mistakes, use USPS approved abbreviations for:



> 1. Street designator, such as AVE for Avenue, ST for Street, RD for Road and CT for Court
>
> 2. Directional indicator, such as N for North or S for South
>
> 3. Secondary street indicator, such as APT for Apartment, BLDG for Building, RM for Room or STE for Suite
>
> 4. State, such as TX for Texas, CA for California, MO for Missouri, or IL for Illinois

3. Spell out the complete city name. Do not use abbreviations such as LA for Los Angeles or NYC for New York City.

4. Use the correct ZIP Code. For more information on ZIP Codes, access the following link: [http://www.usps.com](http://www.usps.com/)

5. Do not use a P.O. Box address when the item is being sent by a SPC.


**1.22.3.7** **(08-10-2018)**

### Proper Packaging/Mailing Guidelines

1. Packaging often determines what services (USPS, SPC, or Freight) are available as well as the cost of the service.

2. Use a standard letter size envelope and mail via USPS when feasible. USPS is the least expensive service for mail weighing 13 ounces or less. Detailed information on envelope selection and use can be found in Document 13011, Envelope User Guide.


**1.22.3.8** **(11-14-2022)**

### Requirements for Shipping Personally Identifiable Information (PII)

1. Mail/Packages being sent through a SPC or mail courier must:



> 1. Contain a Form 3210, Document Transmittal.
>
> 2. Be double boxed or double wrapped in such a way that if the outer package became damaged during transit the inner wrapping/protection will protect the contents from disclosure
>
> 3. Include a duplicate shipping label on the inner package
>
> 4. Be monitored to ensure that each shipment is properly and timely received and acknowledged

2. Mail/Packages being sent via USPS do not need additional protection, such as double wrapping. Mail/Packages containing PII are not required to be shipped using expedite or air services. Ground shipping is the preferred method of transportation.

3. Detailed information and instructions for shipping PII can be found in:



> 1. IRM 10.5.1.6.9.3, Shipping
>
> 2. Document 13056, Shipping Procedures for Personally Identifiable Information.


**1.22.3.9** **(11-14-2022)**

### Standard Mail/Shipping Supplies

1. Each office has supplies for shipping via USPS or SPC ground services. Items listed below can be purchased from the office's supply budget. Recommended supplies include:



> 1. Standard letter envelopes
>
> 2. Two-inch clear packaging tape
>
> 3. Packing material such as Kraft paper, newspaper or bubble wrap used for wrapping and cushioning contents
>
> 4. Black or opaque medium weight garbage bags used for double wrapping
>
> 5. Various sizes of corrugated cardboard boxes
>
> 6. Use a rigid box with flaps intact
>
> 7. If using an old box, ensure the box is undamaged and strong enough to support the contents through the rigors of shipping
>
> 8. When using a previously used box, remove or cover old address labels and delivery markings from the box

2. TS purchases a bulk order of shipping supplies that are stored and distributed through the National Distribution Center (NDC). These supplies are free to shippers and can be ordered through the Order and Subscription Management System (OSMS) in multiples of 25. The supplies include:



> 1. Shipping boxes in commonly used sizes
>
> 2. Kraft bubble mailers
>
> 3. Tear-Proof Polyethylene Mailers

3. Information on the ground shipping supplies available can be found at: http://publish.no.irs.gov/mailtran/PmTPhome.html#tab=tab5.

4. When using express or SPC air shipping services, outer packaging can be obtained from USPS or the SPC. There are various sizes available for order:



> 1. Air Letter - Appropriate for letters, business correspondence, urgent documents, and electronic media
>
> 2. Air Pak - Made from tear-resistant material and is ideal for flat, unbreakable items such as large reports and bulky documents
>
> 3. Air Box - Various sizes are available and can protect up to ten pounds (e.g., two reams of paper)
>
> 4. Internal Security Packs - UPS provides inner packing supplies that meet the requirements in IRM 10.5.1.6.9.3, Shipping. Information on the UPS internal security packs is available at http://publish.no.irs.gov/mailtran/upspk508.pdf


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-022-003#addtoany "Show all")

A2A