---
url: "https://www.irs.gov/irm/part1/irm_01-015-002"
title: "1.15.2 Types of Records and Their Life Cycles | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-015-002#main-content)

- 1.15.2  [Types of Records and Their Life Cycles](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261454507920)
  - 1.15.2.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261482713856)
    - 1.15.2.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261454505136)
    - 1.15.2.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261482113440)
    - 1.15.2.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261454656560)
    - 1.15.2.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261482103520)
    - 1.15.2.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261454579824)
    - 1.15.2.1.6  [Acronyms and Terms](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261454577344)
    - 1.15.2.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261454187440)
  - 1.15.2.2  [Definition of Records](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261454182208)
  - 1.15.2.3  [Types of Records](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261454131552)
    - 1.15.2.3.1  [Essential (Vital) Records](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261487110048)
    - 1.15.2.3.2  [Personal Documents](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261482179200)
    - 1.15.2.3.3  [Non-Record Material](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261453924160)
    - 1.15.2.3.4  [Electronic Records](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261453918304)
    - 1.15.2.3.5  [Microfilm/Microfiche](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261453796752)
  - 1.15.2.4  [Records Created in Telework/Alternative Workplace Situations](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261453792416)
  - 1.15.2.5  [Stages of the Records Life Cycle](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261454625328)
    - 1.15.2.5.1  [Records Creation - Stage One](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261454621952)
    - 1.15.2.5.2  [Maintaining and Using Records - Stage Two](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261454618384)
    - 1.15.2.5.3  [Records Disposition - Third and Final Stage of the Records Life Cycle](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261482127408)
    - 1.15.2.5.4  [Exceptions to the Rule](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261454597328)
  - 1.15.2.6  [Where can I find the Records Control Schedules?](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261453831488)
  - 1.15.2.7  [Retrieving Schedules Electronically](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261453826016)
  - 1.15.2.8  [Calculating the Retention Period](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261453692912)
  - 1.15.2.9  [Obtaining Disposition Authority](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261453688480)
  - Exhibit  1.15.2-1  [Records Control Schedules in IRS Document 12990](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261453705072)
  - Exhibit  1.15.2-2  [General Records Schedules in Document 12829](https://www.irs.gov/irm/part1/irm_01-015-002#idm140261453748960)

# Part 1. Organization, Finance, and Management

# Chapter 15. Records and Information Management

# Section 2. Types of Records and Their Life Cycles

* * *

## 1.15.2 Types of Records and Their Life Cycles

#### Manual Transmittal

January 09, 2025

#### Purpose

(1) This transmits revised IRM 1.15.2, Records and Information Management, Types of Records and Their Life Cycles.

#### Material Changes

(1) Exhibit 1.15.2-1 - Records Control Schedules in IRS Document 12990 - Updated the content to reflect the organizational name change from Wage and Investment (W&I) to Taxpayer Services (TS).

(2) IRM references, website links, editorial updates and word revisions, in compliance with the IRS Style Guide, were made throughout this IRM section.

#### Effect on Other Documents

IRM 1.15.2, dated October 18, 2023, is superseded.

#### Audience

All IRS divisions and functions.

#### Effective Date

(01-09-2025)

Michael J. Oser

Acting Director, Identity and Records Protection (IRP)

Privacy, Governmental Liaison and Disclosure (PGLD)

**1.15.2.1** **(08-03-2017)**

### Program Scope and Objectives

1. This section explains and describes the various classifications or categories of record and non-record material, regardless of media or recordkeeping system. It also covers the life cycle of records, which begins when you create or receive records, and usually ends when you destroy or transfer records to the National Archives and Records Administration (NARA).

2. **Purpose:** In keeping with the Federal Records Act of 1950, as amended, and pursuant to Title 44, United States Code (USC) 3102, the IRS established a records management program - renamed Records and Information Management (RIM) Program - to ensure the economical and efficient management of its records. The program provides for the application, on a continuing basis, of sound management practices and techniques in the creation, maintenance, retrieval, preservation, and disposition of all records. All IRS records are required under statute to be efficiently managed until final disposition.

3. **Audience:** These procedures apply to **all** IRS employees and contractors.

4. **Policy Owner:** Director, Identity and Records Protection - Records and Information Management (RIM).

5. **Program Owner:** The Records and Information Management (RIM) Program, under Privacy, Governmental Liaison and Disclosure (PGLD) is the program office responsible for oversight of the Servicewide records management policy.

6. **Primary Stakeholders:** The Records and Information Management (RIM) Program office, under PGLD, promotes responsible recordkeeping practices for IRS employees and contractors to follow in accordance with federal laws, regulations, and procedures.


**1.15.2.1.1** **(08-03-2017)**

#### Background

1. Major goals of the program are to furnish accurate and complete information when required to manage and operate the organization, and to provide information and records storage at the lowest possible cost. The mission of the RIM Program is to provide guidance and oversee related functions and processes which ensure that IRS records are available where and when they are needed, to whom they are needed, for only as long as they are needed, in order to conduct business, adequately document IRS activities, and protect the interests of the federal government and American taxpayers.


**1.15.2.1.2** **(10-18-2023)**

#### Authority

1. 44 USC 3301, Definition of records

2. 36 Code of Federal Regulations (CFR) Chapter XII, Subchapter B - 1222.14, What are nonrecord materials?

3. 36 CFR Chapter XII, Subchapter B - 1222.20, How are personal files defined and managed?

4. 36 CFR Chapter XII, Subchapter B - 1223, Managing Vital Records

5. 36 CFR Chapter XII, Subchapter B - 1222.26, What are the general recordkeeping requirements for agency programs?

6. 36 CFR Chapter XII, Subchapter B - 1234, Facility Standards for Records Storage Facilities

7. 36 CFR Chapter XII, Subchapter B - 1236, Electronic Records Management

8. [5 USC Appendix 2 - Federal Advisory Committee Act](https://www.govinfo.gov/content/pkg/USCODE-2012-title5/pdf/USCODE-2012-title5-app-federalad.pdf)

9. [National Archives and Records Administration (NARA) Essential Records Guide](https://www.archives.gov/records-mgmt/essential-records/essential-records-guide)


**1.15.2.1.3** **(08-03-2017)**

#### Responsibilities

1. This IRM is used by **all** IRS employees and contractors to ensure compliance with paper and electronic records management requirements.


**1.15.2.1.4** **(10-18-2023)**

#### Program Management and Review

1. The RIM Program is evaluated using the following reviews and reports:



   - **Records Management Self-Assessment (RMSA)**: The annual RMSA asks questions that assess compliance with records management statutes and regulations, as well as NARA policies and guidance.

   - **Federal Electronic Records and Email Management Reporting**: This report not only evaluates federal agency email management, it also seeks to assess the current state of all electronic records management at federal agencies (including email and permanent electronic records).

   - **Senior Agency Official for Records Management (SAORM) Annual Report**: This report gathers data on agency progress towards the goals of the OMB/NARA Update to Transition to Electronic Records memo (M-23-07) and other important records management initiatives as identified by NARA.

   - **Form 14377, Records and Information Management Virtual Program Review Self Assessment Checklist**: This checklist is utilized as a self-assessment tool to assist the field site offices with records management policies and procedures. In addition, it measures RIM goals to stimulate better fiscal management.

   - **Form 14377-A, IRS Records and Information Management (RIM) Evaluation Checklist**: PGLD requires all business unit information resource coordinator (IRC) contacts to complete this form on a quarterly basis. The purpose of the form is to ensure and document IRS recordkeeping compliance as defined by NARA. Completing the Form 14377-A identifies to PGLD:IRP:RIM potential gaps for training opportunities to assist the business unit with their recordkeeping responsibilities.


**1.15.2.1.5** **(10-18-2023)**

#### Program Controls

1. **Records Management Mandatory Briefing**: Every IRS employee and contractor must protect the information they handle daily to carry out their job responsibilities. They must annually take the Records Management Mandatory Briefing Integrated Talent Management (ITM) course #62965, Records Management Awareness, to ensure IRS records management is efficient, effective, and compliant with all applicable records management laws and regulations.


**1.15.2.1.6** **(02-11-2021)**

#### Acronyms and Terms

1. The table lists commonly used acronyms and terms:




| **Acronym** | **Term** |
| --- | --- |
| CFR | Code of Federal Regulations |
| COOP | Continuity of Operations |
| FACA | Federal Advisory Committee Act |
| GAO | Government Accountability Office |
| GRS | General Records Schedules, Document 12829 |
| HCO | Human Capital Office |
| NARA | National Archives and Records Administration |
| PGLD | Privacy, Governmental Liaison and Disclosure |
| RCS | Records Control Schedules, Document 12990 |
| RIM | Records and Information Management |
| USC | United States Code |


**1.15.2.1.7** **(08-03-2017)**

#### Related Resources

1. Employees will find helpful information on the following sites:



   - Records and Information Management SharePoint

   - [44 USC 3301](https://www.archives.gov/about/laws/disposal-of-records.html#def), Definition of a record

   - [36 CFR Chapter XII Subchapter B](https://www.govinfo.gov/content/pkg/CFR-2011-title36-vol3/pdf/CFR-2011-title36-vol3-chapXII-subchapB.pdf), Records Management codes

   - Document 12829, General Records Schedules

   - Document 12990, IRS Records Control Schedules


**1.15.2.2** **(08-11-2015)**

### Definition of Records

1. According to 44 United States Code (USC) Section 3301, the term “record” includes all recorded information, regardless of form or characteristics, made or received by a federal agency under federal law or in connection with the transaction of public business and preserved or appropriate for preservation by that agency or its legitimate successor as evidence of the organization, functions, policies, decisions, procedures, operations, or other activities of the United States Government or because of the informational value of data in them.


**1.15.2.3** **(10-18-2023)**

### Types of Records

1. All IRS records are scheduled as either "Temporary" or "Permanent" . These are considered a record's disposition.



1. **Temporary Records** must be retained for a determinable period of time or until a specific act or event is completed. They should not be preserved indefinitely. NARA must approve temporary records dispositions prior to any records destruction.



      ### Example:



      Individual tax returns (the Form 1040 series) are temporary records which are eligible to be destroyed six (6) years after the end of the processing year, unless extended due to an Open Balance Due - Collection Statute Expiration Date. Refer to Document 12990, Records Control Schedule (RCS) 29, Item 56, Income Tax Returns Filed by Individuals, Partnerships and Fiduciaries and Item 64, Open Balance Due-Collection Statute Expiration Date (CSED) Extracts.

2. **Permanent Records** are appraised by NARA as having significant historical or other value warranting their continued preservation by NARA beyond the time they are needed for administrative, legal, or fiscal purposes. Permanent records document the organization and functions of the IRS, contain fundamental information on programs or activities within the IRS, or are important in the long term to protect the rights and interests of the IRS, the federal government, or its citizens.



      ### Example:



      Organizational studies documenting changes in the way the IRS does business are permanent records and should be preserved for eventual transfer to NARA.


2. Different record types/formats, non-record information and materials are described in the subsections _IRM 1.15.2.3.1_ through _IRM 1.15.2.3.5_:



1. Essential (Vital) Records

2. Personal Documents

3. Non-Record Material

4. Electronic Records

5. Microfilm/Microfiche


**1.15.2.3.1** **(10-18-2023)**

#### Essential (Vital) Records

1. Essential Records (also referred to as Vital Records) are those records considered essential to the continued operation of the IRS before, during and after an emergency or disaster. They can also be records essential to protecting the legal and financial rights and interests of the IRS and the individuals directly affected by its activities. Essential Records will be typically identified in the course of continuity of operations (COOP) carried out in the context of IRS emergency management. This type of Essential Records planning is mandatory. See [36 Code of Federal Regulations (CFR) Part 1223](https://www.govinfo.gov/content/pkg/CFR-2011-title36-vol3/pdf/CFR-2011-title36-vol3-chapXII-subchapB.pdf), Managing Vital Records and [NARA’s Essential Records Guide](https://www.archives.gov/records-mgmt/essential-records/essential-records-guide).

2. IRS Essential Records include:



   - Mission statements in an emergency

   - Plans and programs for carrying out the mission

   - Statements of delegations of authority and of succession to command

   - Staffing assignments

   - Information about IRS employees' payroll, fiscal records, property, and activities including contractual agreements and IRS legal binding documents

   - Copies of basic legislation, regulations, and procedures

   - The Master File


3. The Servicewide IRS Records Officer (also referred to as the IRS Records Officer) and Records Specialists, as well as Facilities Management and Security Services (FMSS), and Privacy, Governmental Liaison and Disclosure (PGLD) personnel are involved in assisting the Office of Continuity Operations with continuity of operations planning and with developing the Essential Records program. Essential Records are divided into two categories:



1. Emergency Operating Records (e.g., delegations of authority, building plans, equipment inventories, system documentation); and

2. Rights and Interest Records (e.g., payroll, retirement, insurance, social security, accounts receivable records, contracts).


4. The Servicewide Records and Information Management (RIM) staff deals with both types of Essential Records to ensure they are appropriately identified and scheduled, and will:



1. Work with functional areas in IRS Headquarters to transfer applicable records to IRS COOP identified ready sites and/or new storage locations to ensure the continuation of the IRS business in COOP-defined crises (e.g., man-made or natural disaster) as appropriate;

2. When applicable, conduct an annual inspection of the emergency operating records at the storage locations to verify the inventory and implement any needed updates (the transfer of new records or destruction of eligible records at these sites) accordingly; and

3. Annually monitor the activity of these records and update as necessary.


5. In carrying out the Essential Records program, it is important that:



1. IRS employees understand their responsibilities in identifying and protecting those records that specify how the IRS will operate in case of an emergency or disaster;

2. Designation of, and the records themselves, are correct and complete; and

3. The records, originals or copies, are protected, accessible and immediately usable as needed.


### Note:

The designation or use of duplicate copies versus the original record where permitted allows for destruction or deletion of obsolete duplicates when replaced by updated copies, whereas the original records must be retained for the period specified in the IRS RCS. Timely "cycling" or replacement of obsolete with current documents, is critical to the Essential Records program and the successful implementation of the Recovery Plan, successful mitigation of the event, and operations in the event of an emergency or disaster.

**1.15.2.3.2** **(02-11-2021)**

#### Personal Documents

1. Personal documents are documentary materials belonging to an employee that are not used to conduct IRS business. They are of a personal nature and relate solely to an individual's personal and private affairs or are used exclusively for their convenience. They may refer to or comment on the subject matter of IRS business, provided they are not used to conduct that business. Personal documents should be marked as such and should be kept separate from IRS records. See [36 CFR Part 1222.20](https://www.govinfo.gov/content/pkg/CFR-2011-title36-vol3/pdf/CFR-2011-title36-vol3-chapXII-subchapB.pdf), How are personal files defined and managed.



### Example:



Documents an employee accumulated and brought into government service from a prior position, i.e., Standard Form 50, Notification of Personnel Actions, personal copies of job applications, previous work files, and references files.





### Example:



Various materials brought to or accumulated in the office that relate solely to family matters, outside business pursuits, professional activities. Such items could consist of family/personal correspondence, volunteer or community service records, literature from professional organizations, and manuscripts or drafts of articles and books.

2. Work-related items, such as diaries, journals, notes, personal calendars, and appointment schedules, that are not prepared, received, or used in the process of transacting IRS business. Although these materials contain work-related information, they are personal documents if they are claimed as such and are for the employee's exclusive use and/or convenience.



### Exception:



Calendars or schedules of the Commissioner or the Deputy Commissioner, or other IRS senior executive positions which document daily, official activities are historical (permanent) records. Refer to Document 12990, Records Control Schedules, RCS 8, Administrative and Organizational Records for more information.


**1.15.2.3.3** **(08-03-2017)**

#### Non-Record Material

1. Non-record material is a term used for documents that are not included with the definition of "records" . All such materials serve purposes other than "records" purposes. See [36 CFR Part 1222.14](https://www.govinfo.gov/content/pkg/CFR-2011-title36-vol3/pdf/CFR-2011-title36-vol3-chapXII-subchapB.pdf), What are nonrecord materials.



### Example:



Library and museum material created or acquired and maintained solely for reference or exhibition purposes. Copies of correspondence


("suspense" or "follow-up" ), drafts of letters, memoranda or reports, information notes that do not represent significant, basic steps in the preparation of the record copies, and machine-readable data, which are maintained only for convenience or reference.





### Example:



Extra copies of correspondence, stocks of publications and processed documents, and machine-readable data, which are maintained only for convenience or reference.





### Caution:



Only the Servicewide IRS Records Officer or the Records Specialist has the final determination on record or non-record status. Direct any inquiries to the IRS Records Office at \*Records Management mailbox.


**1.15.2.3.4** **(02-11-2021)**

#### Electronic Records

1. Electronic records are records that are stored in a form that only a computer can process. Electronic records are also called machine-readable records. These records are defined as numeric, graphic, audio and textual information, recorded on any medium (e.g., magnetic, tape, optical disk, or CD-ROM) and which satisfy the overall definition of a record. Review [36 CFR Part 1236](https://www.govinfo.gov/content/pkg/CFR-2011-title36-vol3/pdf/CFR-2011-title36-vol3-chapXII-subchapB.pdf), Electronic Records Management.

2. This definition applies to all electronic information systems, including individual laptop and desktop computers, regardless of storage media, in network or stand-alone configurations.



### Note:



IRM 1.15.6, Managing Electronic Records covers the creation, maintenance and use, and disposition of federal records created by individuals using IRS electronic information systems, laptops and desktop computers, including electronic mail (email) applications.


**1.15.2.3.5** **(10-18-2023)**

#### Microfilm/Microfiche

1. Microfilm is a film bearing a miniature photographic copy of printed or other graphic matter, usually of a document, newspaper, or book pages, etc., made for a library, archive, or repository. Microfiche is a sheet of flat film, 105 x 148 mm in size, the same size as the international standard for paper size ISO A6. It carries a matrix of micro images. All microfiche is read with its text parallel to the long side of the fiche. Along the top of the fiche a title may be recorded for visual identification and reference purposes.

2. For records management purposes, microform records are treated like hardcopy (analog records). However, agencies must store microform records under specific conditions that will ensure their preservation for their authorized retention period, and unlike hardcopy, the destruction method is incineration, not shredding or shredding/pulping. Review [36 CFR Part 1238](https://www.govinfo.gov/content/pkg/CFR-2011-title36-vol3/pdf/CFR-2011-title36-vol3-chapXII-subchapB.pdf), Microforms Records Management for microform format standards, storage, use and disposition requirements.


**1.15.2.4** **(10-18-2023)**

### Records Created in Telework/Alternative Workplace Situations

1. As the IRS establishes more offsite or satellite work locations and work-at-home situations, the emphasis on proper IRS records management, irrespective of location, is appropriate. Regardless of their location, federal records are subject to the disposition authorities in Document 12990, Records Control Schedules and in Document 12829, General Records Schedules.

2. Employees are encouraged to maintain and refer to these Records Control Schedules for all disposition matters related to records created and/or managed within their function or organization.



### Reminder:



Employees must consult RIM Headquarters staff or their local servicing Records Specialist or function regarding records series that are not covered by a published IRS Records Control Schedule. These records may be unscheduled and require NARA authorities before any final disposition, such as destruction, may take place. Submit questions or requests for scheduling to \*Records Management.


**1.15.2.5** **(10-18-2023)**

### Stages of the Records Life Cycle

1. There are three stages of a records life cycle:



1. Stage One - Records Creation

2. Stage Two - Maintaining and Using Records

3. Stage Three - Records Disposition


**1.15.2.5.1** **(10-18-2023)**

#### Records Creation - Stage One

1. A document that is made or received in the transaction of IRS business and provides evidence of the organization, function, policies, decisions, procedures, operations, or other IRS activities is a record.

2. Multiple copies of the same document, including messages created or received on email systems, may all have record status depending upon the administrative requirements of the information or data which they contain.



### Example:



A general request for inventory information on equipment and software sent to multiple offices for response by a specific due date. A requisition maintained by the purchasing officer, as well as, the Procurement office. An IRS Form 1040, Individual Income Tax Return, an original which is stored in Files Activity, and a copy in the Collection or Examination case file. Combined Federal Campaign (CFC) documents for tracking and payroll purposes.


**1.15.2.5.2** **(02-11-2021)**

#### Maintaining and Using Records - Stage Two

1. Employees maintain and use records for the organization's current work, according to approved records disposition authorities, which are published in Document 12990, Records Control Schedules and in Document 12829, General Records Schedules. Any action which involves storing, retrieving, and handling records kept in an office for current use is considered the second stage of the records life cycle.


**1.15.2.5.3** **(10-18-2023)**

#### Records Disposition - Third and Final Stage of the Records Life Cycle

1. A Records Control Schedule (RCS) is a listing of records series which provides mandatory instructions for what to do with records no longer needed for current business. The comprehensive IRS RCS comes from two sources:



1. NARA-approved records disposition authorities for IRS program-specific records published in Document 12990, and

2. NARA's General Records Schedules for records series common to most federal agencies published in Document 12829.


2. All new/updated RCS disposition requests must be reviewed and approved by the IRS Records Officer and NARA prior to implementation and use by the IRS. Therefore, IRS staff are reminded not to develop or revise records retention instructions for organizational and functional (i.e., program) operations without first consulting the Servicewide RIM Program.

3. All RCS apply to records that will or may accumulate in an office, and they provide a legal disposition authority for:



1. Continued retention and preservation of records of historical value;

2. Systematic retirement of records to a Records Center; and

3. The destruction or other disposal of records no longer having sufficient administrative, legal, research or other value warranting their further retention.



      ### Note:



      Destruction is the action taken regarding records no longer needed and usually consists of burning, pulping, shredding, or discarding with other waste material according to specific requirements established by the IRS Office of Privacy under the Office of Privacy, Governmental Liaison and Disclosure (PGLD).


4. Use of Records Control Schedules and their instructions is mandatory under 44 USC 3303a(b) and is applied on a continuing basis.

5. Records series common to most federal agencies are published in Document 12829, General Records Schedules and include disposition instructions for IRS Federal Advisory Committee (FAC) business.



1. Records management/retention requirements for FAC business are covered under [General Records Schedule (GRS) 6.2](https://www.archives.gov/records-mgmt/grs.html), Federal Advisory Committee Records.

2. Substantive (permanent) records created by committee members include correspondence documenting decisions, discussions, or actions relating to the work of the committee, including email, exchanged between one or more committee members and/or agency committee staff (such as Designated Federal Officer, DFO). A DFO is assigned to each committee to ensure compliance with FACA, and any other applicable laws and regulations; calls, attends, and adjourns committee meetings; approves agendas; and maintains committee records. These records must be transferred to NARA when records are fifteen (15) years old or upon termination of the committee, whichever is sooner.

3. Excluded from this sub-set of substantive committee member communications are temporary records relating to purely logistical or administrative aspects of committee activities, such as meeting planning (e.g., location, administrative issues and other meeting arrangements). These records (including emails) can be deleted when no longer needed, and do not require copying the committee mailbox.

4. Refer to IRM 1.15.6, Managing Electronic Records, for more information on FAC email recordkeeping requirements and management of committee organizational mailboxes.


**1.15.2.5.4** **(10-18-2023)**

#### Exceptions to the Rule

1. Some of the exceptions to applying the authorized dispositions for records are listed in the table below:




| **If the records are** | **Then** |
| --- | --- |
| Involved in unsettled claims or actions by or against the IRS | Do not destroy. Consult Records Management employees or email \*Records Management. |
| Needed for a longer retention period | Do not destroy. Consult Records Management employees or email \*Records Management. |
| Needed for internal audit purposes | Do not destroy. Consult Records Management employees or email \*Records Management. |
| Under litigation hold | Do not destroy. Consult Chief Counsel attorney who issued the hold. |


**1.15.2.6** **(02-11-2021)**

### Where can I find the Records Control Schedules?

1. Records Control Schedules are available for each IRS major function. These schedules are published in Document 12990. See _Exhibit 1.15.2-1_.

2. NARA also produces a set of Records Control Schedules, more commonly known as General Records Schedules (GRS). The GRS cover records series that are common to most federal agencies. IRS uses most of the GRS disposal authorities to meet its administrative records requirements with some minor modification to certain series to comply with various Government Accountability Office (GAO) and Department of the Treasury specific requirements. The GRS are published in Document 12829. See _Exhibit 1.15.2-2_.



### Caution:



The RCS and the GRS are mandatory. IRS employees are urged to ensure that they use the most recent version of the RCS when applying records disposition instructions. Unless there is an approved IRS RCS covering the same series of record, the GRS authority must be applied. Check with your local records manager to make sure that you are using the current version of the GRS and to be certain there is no IRS authority for which a deviation from the GRS has been approved.

3. Records retention guidelines are also issued by GAO and the Office of Personnel Management (OPM) for financial and personnel records respectively. Where appropriate, their schedules have been incorporated into the IRS schedules. However, the IRS Human Capital Office (HCO) or the Office of the Chief Financial Officer (CFO) may have to consult these schedules for specific instructions for some fiscal and personnel record requirements, when necessary.


**1.15.2.7** **(02-11-2021)**

### Retrieving Schedules Electronically

1. All Records Control Schedules are available through Electronic Publishing via the IRS intranet by using the search feature to Find a Product, or from the Records and Information Management SharePoint.


**1.15.2.8** **(10-18-2023)**

### Calculating the Retention Period

1. The retention period starts at the end of the calendar year or month, respectively, in which the records were created. If the records are arranged by fiscal year, list year, processing year, program year, or some standardized time period, then the retention period begins with the close of that period in which the records were created.

2. Cutoff periods are often set forth in the Records Control Schedules. Cutoffs are used to break or end files at regular intervals (usually at the close of a fiscal or calendar year) to facilitate their disposal or transfer in complete blocks, and to establish a new files collection.



### Example:



Time and Attendance records - Approved Disposition: Destroy when three (3) years old. Records created in calendar year 2023 from January through December would be eligible for disposal January 2027.





### Note:



The Records and Information Management SharePoint has two disposal calculation charts--Calendar and Fiscal Year--for use in determining when records should be destroyed.


**1.15.2.9** **(10-18-2023)**

### Obtaining Disposition Authority

1. To obtain a disposition for an unscheduled record series, a written request or recommendation sent through your Records Specialist to the IRS Records Officer is required or your request can be submitted via \*Records Management. Your office must have primary control or authority for the records series for which you are requesting disposition authority. Your request must include the following information:



1. Identity and location of the offices that create or maintain the records;

2. Title and description of each record series/collection;

3. Form numbers and titles, if any;

4. A recommended retention period;

5. A statement justifying destruction of the records, including any applicable laws, statutes, or regulations requiring said retention or destruction; and

6. Such information as the location of other copies which are maintained, either in your office or another office and a proposed disposition authority for these records as well.



      ### Example:



      Office of Primary Responsibility:



      **Retire** to a Records Center when five (5) years old.

      **Destroy** when ten (10) years old.


      All other offices/Copies: **Destroy** when three (3) years old.


2. To revise an existing disposition authority, your written request to the IRS Records Officer, via your Records Specialist should explain why the revision is necessary, and provide the reason or justification (see Example below), particularly if the proposed revision is a request for a decrease in the currently approved retention.



### Example:



Recycling Investment Tax Act (RITA) Case Files - Various documents relating to the collection of taxes, including applications for reduced withholding which contains purchase and selling contracts, invoices, copies of tax returns, (Form 1040-NR, Form 1120-F, or Form 1065), work papers and withholding certificates. (Job No. N–1–58–88–5, Item 6)




(1) **Cut off** files annually.


(2) **Retire** to a Records Center one (1) year after case is closed.


(3) **Destroy** six (6) years after case is closed.



**_Reason:_** Changes to this Disposition Authority are required due to recent changes in the statutory retention period.

3. Questions? Contact your local Records Specialist or the Servicewide Records and Information Management staff (OS:PGLD:IRP:RIM) via \*Records Management.


**Exhibit 1.15.2-1**

### Records Control Schedules in IRS Document 12990

- RCS 8 - Administrative and Organizational Records

- RCS 9 - Taxpayer Advocate

- RCS 10 - Independent Office of Appeals

- RCS 11 - IRS Practitioner Enrollment, Professional Responsibility, and Agent Practices

- RCS 12 - Personnel Security Records

- RCS 13 - Chief Counsel

- RCS 14 - Associate Chief Counsel

- RCS 15 - Regional/District Counsel

- RCS 16 - Chief Financial Officer (CFO) and Accountable Officer Records

- RCS 17 - Information Technology

- RCS 18 - Enterprise Computing Center - Detroit

- RCS 19 - Enterprise Computing Center - Martinsburg (ECC-MTB)

- RCS 20 - Administration/Organization Support Operational Records

- RCS 21 - Strategic Planning Division

- RCS 22 - Tax Administration - Compliance

- RCS 23 - Tax Administration - Examination

- RCS 24 - Tax Administration - Tax Exempt and Government Entities (TEGE)

- RCS 25 - IRS Statistics of Income (SOI) Division

- RCS 26 - Tax Administration - Large Business and International (LB&I)

- RCS 27 - Compliance Research

- RCS 28 - Tax Administration - Collection

- RCS 29 - Tax Administration - Taxpayer Services (TS) Records (formerly Wage and Investment (W&I))

- RCS 30 - Criminal Investigation (CI) Records

- RCS 31 - Customer Service

- RCS 32 - IRS Electronic Tax Administration (ETA)

- RCS 33 - Legislative Affairs

- RCS 34 - Communications

- RCS 35 - IRS Tax Administration Systems - Electronic (Obsolete)

- RCS 36 - IRS Permanent Records INDEX

- RCS 37 - Economic Stabilization Program


**Exhibit 1.15.2-2**

### General Records Schedules in Document 12829

- **GRS 1.0 - Finance**

- GRS 1.1 - Financial Management and Reporting Records

- GRS 1.2 - Grant and Cooperative Agreement Records

- GRS 1.3 - Budgeting Records

- **GRS 2.0 - Human Resources**

- GRS 2.1 - Employee Acquisition Records

- GRS 2.2 - Employee Management Records

- GRS 2.3 - Employee Relations Records

- GRS 2.4 - Employee Compensation and Benefits Records

- GRS 2.5 - Employee Separation Records

- GRS 2.6 - Employee Training Records

- GRS 2.7 - Employee Health and Safety Records

- GRS 2.8 - Employee Ethics Records

- **GRS 3.0 - Technology**

- GRS 3.1 - General Technology Management Records

- GRS 3.2 - Information Systems Security Records

- **GRS 4.0 - Information Management**

- GRS 4.1 - Records Management Records

- GRS 4.2 - Information Access and Protection Records

- GRS 4.3 - _(Rescinded)_

- GRS 4.4 - Library Records

- **GRS 5.0 - General Operations Support**

- GRS 5.1 - Common Office Records

- GRS 5.2 - Transitory and Intermediary Records

- GRS 5.3 - Continuity and Emergency Planning Records

- GRS 5.4 - Facility, Equipment, Vehicle, Property, and Supply Records

- GRS 5.5 - Mail, Printing, and Telecommunication Service Management Records

- GRS 5.6 - Security Records

- GRS 5.7 - Administrative Management and Oversight Records

- GRS 5.8 - Administrative Help Desk Records

- **GRS 6.0 - Mission Support**

- GRS 6.1 - Email Managed Under a Capstone Approach

- GRS 6.2 - Federal Advisory Committee Records

- GRS 6.3 - Information Technology Records

- GRS 6.4 - Public Affairs Records

- GRS 6.5 - Public Customer Service Records


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-015-002#addtoany "Show all")

A2A