---
url: "https://www.irs.gov/irm/part1/irm_01-017-008"
title: "1.17.8 Internal and Public Use Non-Tax Products | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-017-008#main-content)

- 1.17.8  [Internal and Public Use Non-Tax Products](https://www.irs.gov/irm/part1/irm_01-017-008#id1)
  - 1.17.8.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-017-008#id2)
    - 1.17.8.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-017-008#id4)
    - 1.17.8.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-017-008#id5)
    - 1.17.8.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-017-008#id6)
    - 1.17.8.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-017-008#id7)
    - 1.17.8.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-017-008#id8)
    - 1.17.8.1.6  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-017-008#id9)
    - 1.17.8.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-017-008#id10)
  - 1.17.8.2  [Interim Procedures: Creating/Revising Non-Tax Forms with Social Security Numbers (SSNs) or Taxpayer Identification Numbers (TINs)](https://www.irs.gov/irm/part1/irm_01-017-008#id11)
  - 1.17.8.3  [Official Internal Revenue Service (IRS) Published Products](https://www.irs.gov/irm/part1/irm_01-017-008#id12)
  - 1.17.8.4  [Product Request Status](https://www.irs.gov/irm/part1/irm_01-017-008#id13)
    - 1.17.8.4.1  [Obsolescence of Products](https://www.irs.gov/irm/part1/irm_01-017-008#id15)
    - 1.17.8.4.2  [Graphic Design Standards](https://www.irs.gov/irm/part1/irm_01-017-008#id16)
    - 1.17.8.4.3  [Products Requiring Security Handling](https://www.irs.gov/irm/part1/irm_01-017-008#id17)
  - 1.17.8.5  [Types of Published Products](https://www.irs.gov/irm/part1/irm_01-017-008#id18)
    - 1.17.8.5.1  [Forms](https://www.irs.gov/irm/part1/irm_01-017-008#id19)
      - 1.17.8.5.1.1  [New or Revised - General Forms](https://www.irs.gov/irm/part1/irm_01-017-008#id21)
      - 1.17.8.5.1.2  [New, Revised, or Reprinted - Tax-Related Forms](https://www.irs.gov/irm/part1/irm_01-017-008#id22)
      - 1.17.8.5.1.3  [New or Revised - General Administrative and Internal-Use Forms](https://www.irs.gov/irm/part1/irm_01-017-008#id23)
    - 1.17.8.5.2  [Letters](https://www.irs.gov/irm/part1/irm_01-017-008#id24)
      - 1.17.8.5.2.1  [Types of Letters](https://www.irs.gov/irm/part1/irm_01-017-008#id26)
      - 1.17.8.5.2.2  [Letters Numbering Series](https://www.irs.gov/irm/part1/irm_01-017-008#id27)
      - 1.17.8.5.2.3  [Public-Use Form Letter Suffixes](https://www.irs.gov/irm/part1/irm_01-017-008#id28)
      - 1.17.8.5.2.4  [Signature Requirements](https://www.irs.gov/irm/part1/irm_01-017-008#id29)
      - 1.17.8.5.2.5  [Form Letter Format Requirements](https://www.irs.gov/irm/part1/irm_01-017-008#id30)
      - 1.17.8.5.2.6  [Production Schedule for Form Letters](https://www.irs.gov/irm/part1/irm_01-017-008#id31)
      - 1.17.8.5.2.7  [Posting Letters to the Core Repository of Published Products (CROPP)](https://www.irs.gov/irm/part1/irm_01-017-008#id32)
    - 1.17.8.5.3  [Envelopes](https://www.irs.gov/irm/part1/irm_01-017-008#id33)
      - 1.17.8.5.3.1  [Envelope Numbering](https://www.irs.gov/irm/part1/irm_01-017-008#id34)
      - 1.17.8.5.3.2  [Envelope Types](https://www.irs.gov/irm/part1/irm_01-017-008#id35)
        - 1.17.8.5.3.2.1  [General-Purpose Envelopes](https://www.irs.gov/irm/part1/irm_01-017-008#id37)
        - 1.17.8.5.3.2.2  [Special-Purpose Envelopes](https://www.irs.gov/irm/part1/irm_01-017-008#id38)
      - 1.17.8.5.3.3  [Providing Taxpayers with Envelopes](https://www.irs.gov/irm/part1/irm_01-017-008#id39)
      - 1.17.8.5.3.4  [Envelope Responsibilities and Funding](https://www.irs.gov/irm/part1/irm_01-017-008#id40)
        - 1.17.8.5.3.4.1  [Publishing Responsibilities](https://www.irs.gov/irm/part1/irm_01-017-008#id42)
        - 1.17.8.5.3.4.2  [Customer Responsibilities](https://www.irs.gov/irm/part1/irm_01-017-008#id43)
        - 1.17.8.5.3.4.3  [Envelope Funding](https://www.irs.gov/irm/part1/irm_01-017-008#id44)
      - 1.17.8.5.3.5  [Envelope Size Formats](https://www.irs.gov/irm/part1/irm_01-017-008#id45)
        - 1.17.8.5.3.5.1  [4-3/8 Inches by 9-3/4 Inches Envelopes](https://www.irs.gov/irm/part1/irm_01-017-008#id47)
        - 1.17.8.5.3.5.2  [6 Inches by 9-3/4 Inches Envelopes](https://www.irs.gov/irm/part1/irm_01-017-008#id48)
        - 1.17.8.5.3.5.3  [9 Inches by 12 Inches Envelopes](https://www.irs.gov/irm/part1/irm_01-017-008#id49)
      - 1.17.8.5.3.6  [Envelope Standards](https://www.irs.gov/irm/part1/irm_01-017-008#id50)
      - 1.17.8.5.3.7  [Use of Window Envelopes](https://www.irs.gov/irm/part1/irm_01-017-008#id51)
      - 1.17.8.5.3.8  [Envelope Printing](https://www.irs.gov/irm/part1/irm_01-017-008#id52)
        - 1.17.8.5.3.8.1  [United States Postal Service (USPS) Requirements](https://www.irs.gov/irm/part1/irm_01-017-008#id54)
        - 1.17.8.5.3.8.2  [Bulk Supplies](https://www.irs.gov/irm/part1/irm_01-017-008#id55)
        - 1.17.8.5.3.8.3  [IRS Areas and Territories](https://www.irs.gov/irm/part1/irm_01-017-008#id56)
        - 1.17.8.5.3.8.4  [General Envelope Specifications](https://www.irs.gov/irm/part1/irm_01-017-008#id57)
        - 1.17.8.5.3.8.5  [Envelope Specification Sheet](https://www.irs.gov/irm/part1/irm_01-017-008#id58)
        - 1.17.8.5.3.8.6  [Envelope Specifications Review](https://www.irs.gov/irm/part1/irm_01-017-008#id59)
      - 1.17.8.5.3.9  [Envelope Contracts](https://www.irs.gov/irm/part1/irm_01-017-008#id60)
        - 1.17.8.5.3.9.1  [Delinquent Deliveries](https://www.irs.gov/irm/part1/irm_01-017-008#id62)
        - 1.17.8.5.3.9.2  [Quality Control](https://www.irs.gov/irm/part1/irm_01-017-008#id63)
      - 1.17.8.5.3.10  [Requisitioning New or Revised Envelopes](https://www.irs.gov/irm/part1/irm_01-017-008#id64)
        - 1.17.8.5.3.10.1  [Headquarters Offices](https://www.irs.gov/irm/part1/irm_01-017-008#id66)
        - 1.17.8.5.3.10.2  [Field Offices](https://www.irs.gov/irm/part1/irm_01-017-008#id67)
        - 1.17.8.5.3.10.3  [Lead Time](https://www.irs.gov/irm/part1/irm_01-017-008#id68)
        - 1.17.8.5.3.10.4  [Procurement Cycles](https://www.irs.gov/irm/part1/irm_01-017-008#id69)
        - 1.17.8.5.3.10.5  [Envelope Reference Information](https://www.irs.gov/irm/part1/irm_01-017-008#id70)
    - 1.17.8.5.4  [Internal Revenue Manual (IRM)](https://www.irs.gov/irm/part1/irm_01-017-008#id71)
    - 1.17.8.5.5  [Letterhead](https://www.irs.gov/irm/part1/irm_01-017-008#id72)
    - 1.17.8.5.6  [Training Products](https://www.irs.gov/irm/part1/irm_01-017-008#id73)
      - 1.17.8.5.6.1  [Training Products Numbering](https://www.irs.gov/irm/part1/irm_01-017-008#id75)
    - 1.17.8.5.7  [Promotional Items Guidelines](https://www.irs.gov/irm/part1/irm_01-017-008#id76)
  - 1.17.8.6  [Copyright and Copyrighted Material](https://www.irs.gov/irm/part1/irm_01-017-008#id77)
    - 1.17.8.6.1  [Requirements for Publishing Copyrighted Material](https://www.irs.gov/irm/part1/irm_01-017-008#id78)
    - 1.17.8.6.2  [Term of Copyright](https://www.irs.gov/irm/part1/irm_01-017-008#id79)
    - 1.17.8.6.3  [Notice of Copyright](https://www.irs.gov/irm/part1/irm_01-017-008#id80)
    - 1.17.8.6.4  [Elements of a Notice of Copyright](https://www.irs.gov/irm/part1/irm_01-017-008#id81)
    - 1.17.8.6.5  [Exceptions to Notice of Copyright Usage](https://www.irs.gov/irm/part1/irm_01-017-008#id82)
    - 1.17.8.6.6  ["Fair Use" of Copyrighted Material](https://www.irs.gov/irm/part1/irm_01-017-008#id83)
    - 1.17.8.6.7  [Factors for Determining "Fair Use"](https://www.irs.gov/irm/part1/irm_01-017-008#id84)
    - 1.17.8.6.8  [Copyright Infringement](https://www.irs.gov/irm/part1/irm_01-017-008#id85)
    - 1.17.8.6.9  [Credit Lines](https://www.irs.gov/irm/part1/irm_01-017-008#id86)
      - 1.17.8.6.9.1  [Credit Lines Restrictions](https://www.irs.gov/irm/part1/irm_01-017-008#id88)
  - 1.17.8.7  [Procurement Vehicles](https://www.irs.gov/irm/part1/irm_01-017-008#id89)
    - 1.17.8.7.1  [Simplified Purchase Agreements](https://www.irs.gov/irm/part1/irm_01-017-008#id91)
    - 1.17.8.7.2  [Term Contracts](https://www.irs.gov/irm/part1/irm_01-017-008#id92)
    - 1.17.8.7.3  [One-Time Bids](https://www.irs.gov/irm/part1/irm_01-017-008#id93)
  - 1.17.8.8  [Availability of Internal-Use Products to the Public](https://www.irs.gov/irm/part1/irm_01-017-008#id94)
  - 1.17.8.9  [Use of Templates for Product Development](https://www.irs.gov/irm/part1/irm_01-017-008#id95)
    - 1.17.8.9.1  [Downloadable Templates](https://www.irs.gov/irm/part1/irm_01-017-008#id97)
    - 1.17.8.9.2  [Non-downloadable Templates](https://www.irs.gov/irm/part1/irm_01-017-008#id98)

# Part 1. Organization, Finance, and Management

# Chapter 17. Publishing

# Section 8. Internal and Public Use Non-Tax Products

* * *

## 1.17.8 Internal and Public Use Non-Tax Products

#### Manual Transmittal

December 17, 2025

#### Purpose

(1) This transmits revised IRM 1.17.8, _Publishing, Internal and Public Use Non-Tax Products_.

#### Material Changes

(1) Updated Signature to reflect current Publishing director and program owner.

(2) IRM 1.17.8.1, _Program Scope and Objectives_ \- Added subsections on Background, Authority, Roles and Responsibilities, Program Management and Review, Program Controls, Terms and Acronyms and Related Resources to follow established Internal Controls format for IRMs.

(3) IRM 1.17.8.2, _Creating/Revising Non-Tax Forms with Social Security Numbers (SSNs) or Taxpayer Identification Numbers (TINs)_ \- Moved previous interim procedures content from 1.17.8.1 to place here in 1.17.8.2.

(4) 1.17.8.4.6.1(2), _Training Products Numbering_ \- Updated to change “ELMS” to “ITM” and deleted “5-digit” because PPMC now allows the inclusion of an alpha character following the five-digit Base Training Course Number (ie. 12345A-101). Training is no longer limited to the 5-digit course number.

(5) Made editorial changes throughout to update hyperlinks.

#### Effect on Other Documents

IRM 1.17.8, _Publishing, Internal and Public Use Non-Tax Products_, dated October 16, 2024, is superseded.

#### Audience

All IRS employees, contractors, and vendors who design, publish, or distribute printed and/or electronic internal/external material.

#### Effective Date

(12-17-2025)

Tracey K. Quamie

Director, Publishing

Media & Publications Division

**1.17.8.1** **(12-17-2025)**

### Program Scope and Objectives

1. **Purpose:** Publishing’s mission is to plan and produce or procure all IRS print and electronic communications products used by the public to comply with tax filing requirements and obligations and used internally within IRS for tax administration. The Publishing function (also known as "Publishing" ) under Media & Publications (M&P) within the Taxpayer Services Division develops and delivers published products in electronic, paper, and other alternative formats for internal (employees) and external (taxpayers) use. This section sets forth the standards for published product IDs, including the numbering series, guidelines for assigning IDs within each series, revision dates, and how the product identification appears on each type of product. Product originators must request and obtain approval for exceptions to these standards through the Publishing Division.

2. **Audience:**The audience for this IRM is IRS employees Servicewide.

3. **Policy Owner:** The Director of Publishing owns the policies contained herein.

4. **Program Owner:** Taxpayer Services (TS), Customer Assistance Relationships and Education (CARE), Media & Publications (M&P), Publishing is responsible for the administration, procedures, and updates related to the program.

5. **Primary Stakeholders:** Tax Forms & Publications in M&P, CARE, TS; Chief Financial Officer of the IRS; Distribution in M&P, CARE, TS; IRS organizations servicewide.

6. **Contact Information:** The Director of Publishing in M&P, CARE, TS.


**1.17.8.1.1** **(12-17-2025)**

#### Background

1. Publishing’s mission is to plan and produce or procure all IRS print and electronic communications products used by the public to comply with tax filing requirements and obligations and used internally within the IRS for tax administration. The Publishing function (also known as "Publishing" ) under Media & Publications (M&P) within Taxpayer Services develops and delivers published products in electronic, paper, and other alternative formats for internal (employees) and external (taxpayers) use.


**1.17.8.1.2** **(12-17-2025)**

#### Authority

1. Publishing’s authority as the official IRS publisher is documented in IRM 1.17.9.7, _Roles and Responsibilities When Publishing a Product_.


**1.17.8.1.3** **(12-17-2025)**

#### Roles and Responsibilities

1. This section explains the responsibilities associated with being a published product originator and the roles and responsibilities of all involved in the published product processes.


**1.17.8.1.4** **(12-17-2025)**

#### Program Management and Review

1. **Program Reports.** Balanced measures for tax and non-tax products.

2. **Program Effectiveness.** The Computer Assisted Publishing System (CAPS) has reporting capabilities that enable management and employees to monitor and track delivery of Publishing products and services.


**1.17.8.1.5** **(12-17-2025)**

#### Program Controls

1. The Computer Assisted Publishing System (CAPS) has reporting capabilities that enable management and employees to monitor and track delivery of Publishing products and services.


**1.17.8.1.6** **(12-17-2025)**

#### Terms and Acronyms

1. This IRM section uses the following terms and acronyms to describe the involved processes and resources.




| **Acronym** | **Definition** |
| --- | --- |
| ACES | Administrative Corporate Education System |
| ADP | Automated Data Processing |
| AMC | Alternative Media Center |
| ATG | Audit Technique Guide |
| BOD | Business Operating Division |
| BRM | Business Reply Mail |
| C&L | Communications & Liaison |
| CAPS | Computer Assisted Publishing System |
| CARE | Customer Assistance Relationships and Education |
| CJE | Critical Job Elements |
| CMS | Content Management System |
| CP | Computer Paragraph Notices |
| CPM | Composition Process Management |
| CPS | Correspondence Production Services |
| CROPP | Core Repository of Published Products |
| CRX | Correspondex Letters |
| ESN | Electronic Status Notice |
| GAO | Government Accountability Office |
| GII | Generalized IDRS Interface |
| GPO | Government Publishing Office |
| GSA | General Services Administration |
| HTML | Hyper-text mark-up language |
| IAT | Integrated Automation Technology |
| ID | Identification |
| IDRS | Integrated Data Retrieval System |
| IDEA | Integrated Digital Experience Act |
| IRB | Internal Revenue Bulletin |
| IRM | Internal Revenue Manual |
| ISO | International Standards Organization |
| ITM | Integrated Talent Management |
| JCP | Joint Committee on Printing |
| L&E | Learning and Education |
| LEM | Law Enforcement Manual |
| LPTS | Linguistic Policy, Tools and Services |
| NARA | National Archives and Records Administration |
| NDC | National Distribution Center |
| NR | Non-Resident |
| OCPO | Office of the Chief Procurement Officer |
| OGA | Other Government Agency |
| OLS | Online Services |
| OMB | Office of Management and Budget |
| OUO | Official Use Only |
| PDF | Portable Document File |
| PII | Personally Identifiable Information |
| PPMC | Published Product Media Catalog |
| PRA | Paperwork Reduction Act |
| PSD | Publishing Services Data System |
| PSR | Publishing Service Request |
| PTVI | Product Title Version Identifier |
| SBU | Sensitive but Unclassified |
| SERP | Servicewide Electronic Research Program |
| SNIP | Servicewide Notice Information Program |
| SSN | Social Security Number |
| TAC | Taxpayer Assistance Center |
| TAS | Taxpayer Advocate Service |
| TCS | Taxpayer Correspondence Services |
| TF&P | Tax Forms & Publications |
| TIC | Tax Item Classification |
| TIN | Taxpayer Identification Number |
| TPDS | Training Products Distribution System |
| TS | Taxpayer Services |
| USPS | United States Postal Service |
| VIS | Visual Information Specialist |
| WCMS | Web Content Management System |


**1.17.8.1.7** **(12-17-2025)**

#### Related Resources

1. Document 12687, _Getting Your Information Published at the IRS_

2. Document 12616, _Design Guidelines for IRS Internal and Non-Tax Public Use Forms_

3. IRM 1.17.7, _Use of the Official IRS Seal, IRS Logo, Program Logos and Internal Logos_

4. IRM 1.17.1, _Publishing, Overview of Publishing Authorities, Roles and Responsibilities, and Organizational Structure_

5. IRM 22.31.1, _Multilingual Initiatives, IRS Language Services_


**1.17.8.2** **(12-17-2025)**

### **Interim Procedures: Creating/Revising Non-Tax Forms with Social Security Numbers (SSNs) or Taxpayer Identification Numbers (TINs)**

1. Publishing’s Non-Tax Forms staff will not process a Publishing Service Request (PSR) for new forms containing SSNs, or revised forms where a change to a TIN field was made, until verification of a signed Form 14132, _Social Security Number Retention Justification for Forms, Letters, Notices, and Systems_, is provided. To get verification, the product originator in the business operating division must complete the following prior to submitting a PSR:



   - Send the most recent revision of Form 14132 via email to Privacy, Governmental Liaison and Disclosure to request signed approval. Electronically attach the signed Form 14132 to the PSR.

   - This interim guidance is effective until November 14, 2025, or until this IRM topic is revised, whichever is sooner.


**1.17.8.3** **(08-07-2023)**

### Official Internal Revenue Service (IRS) Published Products

1. In addition to tax products, the IRS produces a variety of tax-related public use, internal use, and non-tax products. These products are used both internally by IRS employees and externally by other agencies, taxpayers, or other public groups and entities.

2. Product originators must submit new products to Publishing to obtain product and catalog numbers before the products can be used for official IRS business. See IRM 1.17.9.6.1.1, _Officially Published Products_, for what needs to be a numbered product and IRM 1.17.10, _Published Product Identification_, for product numbering standards. Publishing posts final products in electronic format to the Core Repository of Published Products (CROPP) and makes electronic products available in various versions and formats through the Catalog page. Only Publishing can post official IRS published products to the Intranet and to IRS.gov. After your product is posted, it can be printed and distributed or used in its electronic format.


**1.17.8.4** **(11-18-2022)**

### Product Request Status

1. Publishing designates requests submitted for product publication with a production status of either new, revised, reprint, obsolete, or historical (tax products only). Published products have an item status of new, canceled, active, obsolete, or historical (tax products only). See IRM 1.17.10.4.2, _Item ID Status._ Individual product revisions have a revision status of new, canceled, active, obsolete, or prior revision (tax products only). See IRM 1.17.10.5.3, _Revision Status_.


**1.17.8.4.1** **(11-18-2022)**

#### Obsolescence of Products

1. The originating office is responsible for placing a form or other published product in either an active, obsolete, or historical status. Refer to IRM 1.17.9.6.2.3, _Obsoleting Published Products_, for details.


**1.17.8.4.2** **(07-23-2020)**

#### Graphic Design Standards

1. The IRS Design Services office provides graphic design services to help customers develop products that follow IRS design standards. IRS Design maintains and updates all elements of the standards and can meet customers' graphic design needs using both skilled in-house designers and contract services. In addition to new publications, a visual information specialist from Design should always review products being revised or reprinted to ensure the product meets current IRS design standards. To learn more about design standards, see IRM 1.17.7, _Publishing, Use of the Official IRS Seal, IRS Logo, Program Logos, and Internal Logos_, or visit the IRS Design Services office website.


**1.17.8.4.3** **(10-15-2015)**

#### Products Requiring Security Handling

1. Products that require secure handling may contain Sensitive but Unclassified (SBU) material. SBU material includes data formerly designated as Official Use Only (OUO) or Personally Identifiable Information (PII).

2. Secure handling is required if the product originator requests it; and/or in the instances described in (3) and (4) below.

3. If the product has been marked on the cover or any later pages with the terms:



   - Sensitive but Unclassified (SBU)

   - Official Use Only (OUO)

   - Personally Identifiable Information (PII)


4. If the item being printed, posted, or distributed allows or contains any of the following:



   - allows access to a restricted, monitored, sealed, or closed off area

   - allows access or navigation through a computer system(s) and/or database(s)

   - confirms payment to or from the IRS (such as Form 809 receipts)

   - includes a sample that may contain real taxpayer data (such as tax packages, stimulus samples, or mail-to or distribution lists)

   - is any official form of identification (such as Smart ID Badges, pocket commission cards, etc.)

   - records private or sensitive data; or is used as an official control log

   - contains data that, if released on or before a certain date, may allow for an advantage (monetarily, knowledge, or names)

   - causes possible harm to self, personal injury or injury to others, or death

   - is an Internal Revenue Manual (IRM) marked as "OUO" or containing pound signs (#) in either the left or right portion of the margin (Content online that is restricted information is denoted with the not equal sign (≠))

   - is a Law Enforcement Manual (LEM), which are now all deemed obsolete.


5. Keep all related items identified for secure handling, including manuscripts, copy, proofs, compact discs (CDs), samples, etc., locked in a file drawer or cabinet except when working the job. If you leave your work area, lock up all materials pertaining to the job. Never (except in emergency evacuations) leave secure materials unattended. Lock them away during non-work hours such as evenings, holidays, and weekends.

6. All products requiring secure handling must be marked with a "Y" under the security handling field in Electronic Status Notice (ESN) on the main product information page.

7. Store history folders for products requiring secure handling, such as pocket commissions and parking decals, in a designated locked file cabinet. This applies also to IRM and LEM materials.

8. All security products that are housed in the National Distribution Center (NDC) must be stored in a secure environment. The NDC uses a fully enclosed steel cage. If you have a product that is a security item and will be stored at the NDC, consult with the distribution analyst to ensure the item will be properly secured.


**1.17.8.5** **(11-18-2022)**

### Types of Published Products

1. This section discusses the following types of published products:



   - documents

   - envelopes

   - forms

   - instructions

   - Internal Revenue Manuals (IRMs)

   - letterhead

   - letters

   - miscellaneous products

   - notices

   - other government agency products

   - publications

   - templates

   - training products


2. Refer to IRM 1.17.10.4.4, _Item Types_, for information on each of these types of published products.

3. Additional information on IRS published products and publishing services is available from M&P’s Electronic Publishing website.


**1.17.8.5.1** **(11-18-2022)**

#### Forms

1. This section has guidelines for submitting General, Tax-Related, General Administrative or Internal Use forms. For more information on Forms, see IRM 1.17.10.4.4.2, _Forms_. For instructions on submitting a Publishing Services Request, see IRM 1.17.9.5, _Importance of Standards and Submitting a Publishing Services Request_.


**1.17.8.5.1.1** **(11-18-2022)**

##### New or Revised - General Forms

1. Organizations requiring new forms or revisions to existing forms (other than tax forms) must:



   - develop complete procedures and instructions governing the use of the form

   - secure necessary internal and external clearances

   - prepare a draft of the proposed new form or revised copy of an existing form

   - attach an electronic file of the draft form to the PSR when submitting to Publishing

   - contact their records specialist listed at [records specialist](https://irsgov.sharepoint.com/sites/ETD-KMT-KB003/SitePages/RecordsManagement/RecordsRolesandResponsibilities/RolesandResponsibilitiesforRecordsSpecialists.aspx.aspx), located in the Records and Information Management (RIM) program office, by emailing \*Records Management<p.rim@irs.gov> to schedule the new form for retention and disposition as required by the National Archives and Records Administration (NARA)


**1.17.8.5.1.2** **(11-18-2022)**

##### New, Revised, or Reprinted - Tax-Related Forms

1. To create a new tax-related form, or revise or reprint an existing one, form originators must submit drafts of new or revised tax-related forms and requests for reprints of existing forms to Publishing by initiating a PSR. Include procedures or instructions that relate to the use of the form.

2. Form originators must contact their [records specialist](https://irsgov.sharepoint.com/sites/ETD-KMT-KB003/SitePages/RecordsManagement/RecordsRolesandResponsibilities/RolesandResponsibilitiesforRecordsSpecialists.aspx.aspx) via email to \*records management<p.rim@irs.gov> to schedule the new tax-related form for NARA-approved retention and disposition.


**1.17.8.5.1.3** **(11-18-2022)**

##### New or Revised - General Administrative and Internal-Use Forms

1. Follow these steps when publishing a new or revised internal-use form:



1. clear internal-use forms within originating office prior to submitting to Publishing

2. submit draft of new or revised form to Publishing by initiating a PSR and include any procedures or instructions relating to the use of the form

3. email [Records management staff](https://www.irs.gov/irm/part1/p.rim@irs.gov) at \*records management<p.rim@irs.gov> to schedule the new internal-use form for NARA-approved retention and disposition


2. Publishing, after receiving the PSR, will:



1. design the forms to meet IRS design standards following Document 12616, _Design Guidelines for IRS Internal and Non-Tax Public Use Forms_, within Publishing

2. develop functionality required to make the form user-friendly in an electronic workflow

3. make the forms meet Section 508 accessibility requirements

4. work with the originator to have all tasks done on the form approved

5. apply document rights to allow users of Adobe Reader to be able to save and sign the forms


**1.17.8.5.2** **(11-19-2012)**

#### Letters

1. Letters are public-use products sent directly to taxpayers. See IRM 1.17.10.4.4.3, _Letters_, for the definition of the letter series and letter types.


**1.17.8.5.2.1** **(07-23-2020)**

##### Types of Letters

1. M&P publishes Form Letters, Survey Letters, and Correspondex Letters. Form letters follow M&P design standards. Survey letters relate to specific surveys, in most cases, and are generated by a vendor. Survey letters go to the Taxpayer Correspondence Service (TCS) for content review but are approved by the OMB. Correspondex letters are computer-generated from the Integrated Data Retrieval System (IDRS). The suffix C identifies these letters, and they are viewable from the Numerical Index on the Servicewide Electronic Research Program (SERP) website, but not available on the Electronic Publishing website as PDF fillable letters. A direct link to an IDRS letter in the Numeric Index appears in the Functional Description of the letter from the Publishing Catalog page.


**1.17.8.5.2.2** **(11-19-2012)**

##### Letters Numbering Series

1. Publishing uses the letter series for numbering all public-use form letters prescribed by each Headquarters office for use in IRS correspondence. The identification of this correspondence consists of the word "Letter" followed by a one- to four-digit number. Letters, when they are intended for distribution to 10 or more entities, must carry this number series. Refer to IRM 1.17.10.4, _Item IDs_, for letter numbering standards.

2. Each number issued under this series will be unique to a single purpose or subject, but more than one version of that item may be available. No change is required in the text, format, physical characteristics, date of issue, or revision date of letters in this series without prior approval from the originating office.


**1.17.8.5.2.3** **(10-15-2015)**

##### Public-Use Form Letter Suffixes

1. The suffix "C" , a capital letter C only, with no punctuation, identifies public-use form letters generated from the Integrated Data Retrieval System (IDRS). For these letters, the campus or area determines the choice of manual signature and title. The suffix (C-SP), capital letter C and capital letters SP separated by a hyphen and enclosed in parentheses, identifies Spanish-language public-use letters generated from the IDRS. See IRM 1.17.10.4, _Item IDs_, for letter numbering.


**1.17.8.5.2.4** **(11-18-2022)**

##### Signature Requirements

1. Letters require a signature unless Chief Counsel has approved that the content of the letter does not require a signature. The Office of Taxpayer Correspondence provides the Chief Counsel approval to Publishing to authorize a letter without a signature.

2. When the letter requires a signature, the originator will determine signature title requirements. When a specific signature title appears on the letter, you must use that signature, unless an authorized official re-delegates the signature authority. The letter originator will determine whether a facsimile signature can be preprinted on the letter or if a hand-stamped or actual signature is required.

3. The publishing specialist must provide signature instructions for each letter in the corresponding Electronic Status Notice (ESN) record.


**1.17.8.5.2.5** **(07-19-2019)**

##### Form Letter Format Requirements

1. The M&P organization is responsible for format and design of all public-use form letters. Format and design include typeface, margins, and page and text layout. Letter format templates are available on Publishing’s Intranet site.

2. To create or revise digital or paper taxpayer correspondence, all requests must be submitted using the green, "Request Services" button on the Taxpayer Correspondence Service’s (TCS) website. The TCS will assist with product development and publishing.


**1.17.8.5.2.6** **(10-16-2024)**

##### Production Schedule for Form Letters

1. Publishing composes and processes letters in the order approved copy is received from the TCS.

2. Note requests for expedited composition, print and/or posting services on the PSR when submitting the request. The letter originator should also contact the letter program publishing specialist directly to request expedited services. The publishing specialist will work to meet the scheduling needs of the originating office.


**1.17.8.5.2.7** **(10-16-2024)**

##### Posting Letters to the Core Repository of Published Products (CROPP)

1. All numbered published products are posted to Publishing’s Core Repository of Published Products (CROPP). IRS published products become "official" products only when they contain a catalog number and product identifier issued by Publishing, are approved for publishing by the product content owner/originator, are issued as an active item or revision by Publishing, and are available on Publishing’s Catalog page. A product’s "official" status can become relevant during court proceedings and legal challenges.

2. Publishing posts numbered letters, except for Correspondex (CRX) letters, to the CROPP. CRX letters are generated and used on the Integrated Data Retrieval System (IDRS) and posted to the Servicewide Electronic Research Program (SERP) site.


**1.17.8.5.3** **(11-19-2012)**

#### Envelopes

1. Envelopes are vehicles used to mail printed products to IRS employees and the public. To learn more about Publishing’s envelope program, go to the Envelope program page of Publishing’s website.



### Note:



Blank and/or non-standard envelopes are not ordered through the IRS envelope program. Consult an envelope program specialist for additional information.


**1.17.8.5.3.1** **(11-18-2022)**

##### Envelope Numbering

1. A number is assigned to each IRS envelope for identification and inventory purposes. See IRM 1.17.10.4, _Item IDs_, IRM 1.17.10.4.6.7, _Envelope Suffixes_, and IRM 1.17.10.7.4, _Envelope Product Titles_, for details on Envelope identification. An example of an envelope number would be "Envelope 130 (Rev. 10-1994)." The number prints in the lower right corner on the back of the envelope.

2. Some envelopes are available with the window on the right to accommodate address areas that are on the right; other envelopes have windows on the left. We identify envelopes that can be ordered with either a right or left window with either an "L" for left window or "R" for right window. This designation follows the envelope number, for example "Envelope 125-L (Rev.10-1994)." Ordering offices should ensure that the envelopes ordered have the matching window position for the items being mailed.



### Note:



IRS letterhead has the address portion of letters and form letters on the left.


**1.17.8.5.3.2** **(11-19-2012)**

##### Envelope Types

1. Publishing produces two types of envelopes:



   - general purpose

   - special purpose


**1.17.8.5.3.2.1** **(11-19-2012)**

###### General-Purpose Envelopes

1. General-purpose envelopes are used to mail many types of miscellaneous letters and pamphlets, for which no particular envelope is prescribed as a mailing vehicle. When using a general-purpose envelope, carefully select the appropriate size.


**1.17.8.5.3.2.2** **(11-19-2012)**

###### Special-Purpose Envelopes

1. Special-purpose envelopes are developed when a general-purpose envelope cannot be used because of unusual size, unusual address location, special construction requirements, special printing requirements, or other such reasons. Special instructions for using this type of envelope are in the status notice information for that envelope.



### Note:



In emergency situations, general-purpose and special-purpose envelopes may be used interchangeably. However, consult Publishing before making any large-volume substitutions.

2. If a form, letter, or notice cannot be designed to fit a general-purpose window envelope, and it is not feasible to use a non-window general-purpose envelope, then a special-purpose window envelope may be developed. Publishing will determine the necessity for a new window envelope by weighing the cost of addressing non-window envelopes against the additional cost of procuring the special purpose window envelope and the administrative cost associated with adding another special purpose envelope to the system.


**1.17.8.5.3.3** **(11-19-2012)**

##### Providing Taxpayers with Envelopes

1. There are conditions where the IRS may benefit from providing taxpayers with envelopes for use in transacting official business. A courtesy reply envelope (Envelope 25-CR, Envelope - Courtesy reply, General purpose, Tri-fold) is available to serve this purpose.

2. The IRS may furnish postage and fees paid business reply mail (BRM) envelopes in tax liability investigations only when the IRS requires information that the taxpayer does not legally have to provide. When information is solicited from a third party (not representing the taxpayer), or in administrative investigations requiring information from an employee reference, etc., the IRS may furnish a BRM envelope.

3. Persons responding to correspondence relating to their tax liability, when they are legally bound to provide the required information, should not receive business reply mail envelopes.

4. See IRM 1.2.1.2.20, _Policy Statement 1-113, Postage-Paid Envelopes Furnished with Third Party Inquiries_, for additional information.


**1.17.8.5.3.4** **(11-19-2012)**

##### Envelope Responsibilities and Funding

1. This section provides instructions and other information related to the IRS envelope program responsibilities and funding.


**1.17.8.5.3.4.1** **(11-19-2012)**

###### Publishing Responsibilities

1. Publishing is responsible for planning and administering the envelope program for the IRS. These responsibilities include, but are not limited to, administering fixed-price printing contracts through the Government Publishing Office (GPO). Publishing will develop envelope specifications for these contracts. The contracts will serve as the procurement vehicle for most IRS envelope needs.


**1.17.8.5.3.4.2** **(10-15-2015)**

###### Customer Responsibilities

1. Customers must review their envelope needs carefully prior to placing an order. The customer must confirm that funding is available before placing an envelope order. Customers must order envelopes from one of the following sources:



   - IRS Office Envelope Contract

   - IRS Mail Processing Center Envelope Contract

   - PSR – Publishing Services Request submitted to Publishing for new, revised or specialty envelopes


**1.17.8.5.3.4.3** **(11-18-2022)**

###### Envelope Funding

1. Publishing, as shown in the table below, will fund the envelope requirements for M&P Distribution (Correspondence Production Services (CPS) sites and the National Distribution Center (NDC), Submission Processing and Accounts Management Campuses, Customer Service Centers, Computing Centers, and other high-volume mailing sites. These offices will assign a suitable person and backup person to serve as the envelope coordinator for that office. Publishing will process a PSR for each office at the beginning of the fiscal year, authorizing the person designated to request envelope purchases on behalf of that office. Publishing will set the funding aside in stewardship accounts from initial printing allocations.

2. For low-volume envelope users, such as area and territory offices, the ordering office will fund, via the use of a government purchase card, requirements of envelopes listed below.




| **Envelopes Funded and Procured by Publishing for High-Volume Users** | **Envelopes Funded and Procured by Ordering Office for Low-Volume Users** |
| --- | --- |
| Envelope 19, Envelope 20, Envelope 25-BR | Envelope 19, Envelope 20 |
| Envelope 25-CR, Envelope 44, Envelope 44-B | Envelope 25-BR, Envelope 25-CR |
| Envelope 47, Envelope 73 | Envelope 44, Envelope 44-B |
| Envelope 125-L, Envelope 125-R | Envelope 47, Envelope 125-L |
| Envelope 130, Envelope 142 | Envelope 125-R, Envelope 130 |
| Envelope 178, Envelope 182-W, Envelope 199 | Envelope 178 |
| Envelope 200-A, Envelope 205, Envelope 207 | Envelope 200-A, Envelope 207 |
| Envelope 208, Envelope 209, Envelope 211 | Envelope 214, Envelope 215 |
| Envelope 212, Envelope 213 |  |


**1.17.8.5.3.5** **(08-20-2018)**

##### Envelope Size Formats

1. The three most common sizes for envelopes are:



   - 4-3/8 inches by 9-3/4 inches (letter size or tri-fold)

   - 6 inches by 9-3/4 inches (bi-fold)

   - 9 inches by 12 inches (flat)


2. There can be other envelope sizes for specific purposes. Offices in the Washington, DC metropolitan area and in field locations can reference the IRS Office Envelope Contract price link for additional information about selecting the appropriate envelope for a particular mailing situation. Additional mail and envelope reference information is also posted on the Postal and Transport Policy program site.

3. As envelope size increases, so does the cost to purchase. Therefore, customers must always use the smallest envelope that satisfies the intended purpose.


**1.17.8.5.3.5.1** **(11-18-2022)**

###### 4-3/8 Inches by 9-3/4 Inches Envelopes

1. The United States Postal Service (USPS) specifies the use of a 4-3/8" x 9-3/4" envelope for mailing one or eight folded single sheets of letter size (8-1/2" x 11") paper. General-purpose envelopes, such as the Envelope 178 and Envelope 130, may be used for this type of mailing.

2. You must use a 4-3/8" x 9-3/4" envelope as the mailer with an unfolded 3 7/8" x 8 7/8" or similar size envelope enclosed as the return envelope when a return envelope must be included in letter-sized mailings. General-purpose envelopes, such as Envelope 130 or Envelope 178, may be used as a mailer in these instances, and Envelope 205, Envelope 73, Envelope 25-BR, or Envelope 25-CR may be used as a return envelope as appropriate.


**1.17.8.5.3.5.2** **(07-23-2020)**

###### 6 Inches by 9-3/4 Inches Envelopes

1. The use of 6" x 9-3/4" envelopes is warranted when multiple (usually 8 to 15) 8-1/2" x 11" sheets tri-folded are too thick to fit in a 4-3/8" x 9-3/4" envelope. The 6" x 9-3/4" envelope allows the sheets to be folded only in half to fit in the envelope (therefore referred to as bi-fold envelopes).


**1.17.8.5.3.5.3** **(08-20-2018)**

###### 9 Inches by 12 Inches Envelopes

1. The use of 9" x 12" envelopes is warranted when multiple (usually more than 15) 8-1/2" x 11" sheets bi-folded are too thick to fit in a 6" x 9-3/4" envelope. The 9" x 12" envelope allows the sheets to be inserted flat into the envelope (hence they are referred to as flats).

2. The IRS, like other entities, must pay a postage surcharge on large, flats-sized envelopes. You should **not** use envelopes larger than 6-1/8” by 11-1/2” to mail anything that can be folded and mailed in a letter-sized envelope like the Envelope 130, or a bi-fold envelope such as the Envelope 200-A.


**1.17.8.5.3.6** **(07-23-2020)**

##### Envelope Standards

1. IRS envelopes are developed and manufactured to conform to provisions of the USPS postal regulations.

2. Maximum standardization is a primary objective of the IRS’ envelope program. The requestor must carefully consider the use of existing envelopes before a new or revised envelope is created.

3. New forms, letters, and notices that will be mailed must be designed to be compatible with existing general-purpose envelopes. The address area should correspond to the window position of general-purpose window envelopes, such as Envelope 178. Use Document 7468, _Print Alignment Template_, to assist with the proper alignment of the various elements on correspondence.


**1.17.8.5.3.7** **(08-20-2018)**

##### Use of Window Envelopes

1. Publishing encourages the use of window envelopes, as it eliminates handwriting, or printing and placing an address label on the face of the envelope. Mailing addresses printed from IRS systems, such as IDRS, are more accurate and not prone to transcription errors.

2. Some IRS envelopes, such as the Envelope 178, are designed with a "Bus" style or oversized window. These larger windows allow for display of not only the mailing address on the correspondence, but also the return address printed above it as well.

3. Single-window envelopes or non-window envelopes require that the return address be printed on the face of the envelope. If the return address changes, then these envelopes must be disposed of, which is a costly waste of printing funds.

4. While we encourage using these window envelopes to display the return address, you must take great care to ensure that the return address is compliant with IRS addressing standards and USPS postal regulations for the proper format and content of the address. For more information, visit the Postal and Transport Policy program site.


**1.17.8.5.3.8** **(11-19-2012)**

##### Envelope Printing

1. IRS envelopes have specific typographical and printing requirements. These requirements affect envelope quality, security, price, and usability.


**1.17.8.5.3.8.1** **(11-19-2012)**

###### United States Postal Service (USPS) Requirements

1. The USPS requires that address lines and other text on government envelopes be printed in dark colored ink. All IRS envelopes will be printed in black ink (except as required by the USPS for specialty envelopes).


**1.17.8.5.3.8.2** **(11-19-2012)**

###### Bulk Supplies

1. High-volume envelope users have identified contact persons to place envelope orders. These contacts have specification sheets for all envelopes. These sheets are the official envelope format and show printing locations along with address change line and routing information. The ordering offices must use the specification sheet as manuscript for placing print orders.


**1.17.8.5.3.8.3** **(08-20-2018)**

###### IRS Areas and Territories

1. The IRS Office Envelope Contract requires the contractor to set one or more address lines in Helvetica or Helvetica Bold typefaces as designated on the order. To ensure accurate printing, ordering offices must use the Online Envelope Ordering System or provide a properly completed Form 9880 (for current Fiscal Year), _Envelope Order_.

2. If Helvetica is not available, then Arial is an acceptable substitute.


**1.17.8.5.3.8.4** **(10-15-2015)**

###### General Envelope Specifications

1. All IRS envelopes are printed with a security tint on the inside. This tint is designed to prevent disclosure of information on the contents of the envelope. The requestor must refer any envelope stock without a security tint to the envelope program specialist for disposition instructions.


**1.17.8.5.3.8.5** **(11-18-2022)**

###### Envelope Specification Sheet

1. Specification sheets for existing envelopes are cataloged and available in the Core Repository of Published Products (CROPP). These specification sheets include the technical specifications and printing requirements for each IRS envelope. The envelope print contractor uses this information to custom-print IRS envelopes.

2. Printing specifications for individual envelopes appear on its respective specification sheet. Go to Publishing’s product catalog information page and enter the words "envelope" and "specification" in the title search to obtain a listing of current envelope speciﬁcation sheets.

3. Envelope specification sheets are forms and use dual serial suffixes in the product ID. See IRM 1.17.10.4.4.2, _Forms_, and IRM 1.17.10.4.6.2.2, _Dual Serial Suffixes_, for more information.


**1.17.8.5.3.8.6** **(11-19-2012)**

###### Envelope Specifications Review

1. Publishing will review specifications on an ongoing basis to obtain the most economical and efficient use of IRS envelopes by eliminating unnecessary envelopes and identifying envelopes not suited for their current use.

2. The envelope program specialist will review envelope specifications with the objective of standardizing size, use, construction, and paper stock.

3. Using information obtained from the specifications review, Publishing will prepare new or revised specifications for inclusion in IRS envelope contracts. Publishing will cancel obsolete envelopes and will notify stakeholders affected by any changes.


**1.17.8.5.3.9** **(11-18-2022)**

##### Envelope Contracts

1. The IRS works in conjunction with the Government Publishing Office (GPO) to award term contracts to commercial envelope printing companies. These contracts provide exclusive use by all IRS ordering offices. Washington, DC metropolitan area and field offices use the IRS Office Envelope Contract. High-volume mailers, such as the Correspondence Production (CPS) sites and campuses, use the IRS Mail Processing Center Envelope Contract.

2. When a new IRS Office Envelope Contract is awarded, Publishing posts the availability and contractor information on the Envelope program website. Publishing will make available revisions of Form 9880 and Document 9589 for the appropriate fiscal year via download from the envelope contract website.

3. Form 9880 must be completed electronically; it cannot be handwritten. Document 9589 provides line-by-line instructions for completing the Form 9880. In lieu of using Form 9880 to order envelopes, we recommend use of the Web-based ordering system. Customers submit requests for order processing approvals via email. Additional information is posted about the online envelope ordering system.

4. Publishing provides information concerning use of the IRS Mail Processing Center Envelope Contract to envelope coordinators at each IRS campus, CPS site, and computing center office for their use. See the current list of IRS Center envelope coordinators.


**1.17.8.5.3.9.1** **(10-15-2015)**

###### Delinquent Deliveries

1. Delinquent envelope deliveries cause serious problems, result in costly delays, and often require rescheduling of complex operations. Enforcing the contract delivery terms is one of the most important phases of envelope program administration. Take the following actions to ensure that the IRS receives all envelope orders on-time and in compliance with contract schedules.



   - Establish an order follow-up method to provide notice of a delinquent envelope order. Accomplish this by noting the scheduled delivery date for each envelope order on a calendar and checking daily to determine which orders are delinquent.

   - If the ordering person is not the recipient of the order, make sure the receiver gets a copy of the order so they know what they should receive. The receiver should sign and date the Form 9880 and return a copy of the form to the ordering person. Annotate any discrepancies between what was ordered and what was received on the Form 9880. If the online ordering system is used in lieu of the Form 9880, then convey the same information by email.

   - The ordering person must immediately notify the envelope program specialist of any delinquent envelope order. After appropriate information is obtained, the program specialist will determine the best course of action to resolve the discrepancy in the best interest of the IRS, while adhering to federal procurement regulations.


**1.17.8.5.3.9.2** **(11-19-2012)**

###### Quality Control

1. Monitoring the quality of envelopes received to ensure that the IRS is getting a quality product, manufactured according to the terms and specifications of the contract, is another important aspect of contract enforcement. The employee responsible for receiving the delivery should check each shipment for the following items:



   - position of bar codes and sharpness of printing

   - accuracy of printed addresses

   - fonts, sizes, and spacing according to the envelope specification sheet

   - ink color and consistency of coverage

   - color and quality of paper stock

   - general construction of envelope

   - durability and labeling of shipping containers


2. Customers should handle poor quality envelopes or envelopes not meeting specifications as follows:



   - notify the envelope program specialist immediately for problem resolution. Designated envelope coordinators must also complete a Form 6282, _Envelope Trouble Report_, and forward it to the envelope program specialist.

   - after obtaining appropriate information, the envelope program specialist will determine the best course of action to resolve the discrepancy, while adhering to federal procurement regulations. This may include negotiation by the GPO for a reduced price if the envelopes are usable by the IRS.

   - if it is determined that an order should be rejected, the envelope program specialist will work with the GPO contracting officer to request correction of the defect(s) or replacement of the envelopes. Publishing must afford a reasonable amount of time to the contractor to complete the corrective action.


**1.17.8.5.3.10** **(11-19-2012)**

##### Requisitioning New or Revised Envelopes

1. When creating new or revised envelopes, you must consider several factors, including lead time, ordering cycles, quality control, and other factors. The requisitioning procedures are in the sections that follow.


**1.17.8.5.3.10.1** **(11-19-2012)**

###### Headquarters Offices

1. Headquarters offices requesting a new envelope, or desiring to revise an existing envelope, must submit a completed PSR. The following must accompany the PSR:



   - proposed envelope specifications

   - estimated annual requirements

   - recommended distribution patterns

   - description or samples of material to be mailed

   - a copy of the processing procedure

   - information regarding automatic envelope handling equipment to be used


**1.17.8.5.3.10.2** **(11-19-2012)**

###### Field Offices

1. Field offices, such as areas or territories, requiring a new or revised envelope should submit a request by memorandum to their Headquarters counterpart.

2. If the Headquarters counterpart concurs with this request, then they will requisition the new or revised envelope. Publishing will determine the services required to produce the envelope.


**1.17.8.5.3.10.3** **(08-20-2018)**

###### Lead Time

1. Factors such as quantity ordered, procurement source, type of construction, manufacturer’s workload, requirements survey, cost, and the type of equipment used to manufacture the envelopes makes ordering lead time for envelopes critical.

2. Lead time must be computed from the day Publishing receives the envelope requisition. Lead times listed below are accurate for most planning purposes.



   - allow 30 workdays production time for the printing of envelopes on the IRS Mail Processing Center Envelope Contract for high-volume users.

   - allow 15 workdays production time for printing of envelopes on the IRS Office Envelope Contract for low-volume users.

   - allow 45 workdays for quantities of envelopes not covered on the GPO term contracts.


**1.17.8.5.3.10.4** **(11-18-2022)**

###### Procurement Cycles

1. Procurement of envelopes for high volume users (Submission Processing campuses, CPS sites, computing centers, etc.) will occur three times per fiscal year. This will allow the print contractor to group orders of like envelopes to increase print runs and reduce the cost of envelopes. It will also reduce the warehouse space needed to maintain adequate supplies of envelopes on hand.

2. An explanation of this cycled ordering procedure is posted on the Envelope program website. Contractors are expecting to receive orders for these items at the times specified. Minimize off-cycle ordering as much as possible.

3. Field Offices and low-volume users may procure envelopes at any time using the IRS Office Envelope Contract. Customers must follow local business unit office procedures for the use of a government purchase card. Further information is provided at the Envelope program page of Publishing’s website.


**1.17.8.5.3.10.5** **(08-20-2018)**

###### Envelope Reference Information

1. IRM 3.13.62, _Campus Document Services - Media Transport and Control_, provides a complete cross-referenced listing of envelopes used with various printed products (forms, notices, and publications). This IRM may serve as a quick reference source for envelopes and forms mailing information. Customers should double-check information with the appropriate envelope and form product catalog information for complete accuracy.


**1.17.8.5.4** **(11-18-2022)**

#### Internal Revenue Manual (IRM)

1. The IRM is the official source of IRS policies and procedures (instructions to staff). The IRM contains directions employees need to carry out their job duties in administering tax laws or other agency obligations. For additional information, refer to IRM 1.17.10.4.4.9, _Internal Revenue Manual_.

2. IRM numbers, catalog numbers, and part, chapter and section titles identify the IRM. Refer to IRM 1.17.10.4, _Item IDs_ for details. You can access Portable Document Format (PDF) and Extensible Markup Language (XML) files for IRMs from within the IRM Numerical Index.

3. The Index contains links to product information, PDF files, and XML files for all active IRM sections. The IRM Numerical Index is updated automatically as IRM sections are published.


**1.17.8.5.5** **(08-20-2018)**

#### Letterhead

1. Preprinted letterhead is usable for official IRS correspondence, both internal and external. Standardized stationery provides a consistent image to the public, thus assuring taxpayers that IRS correspondence is official, legitimate, and professionally prepared.

2. The standards for letterhead stationery, as well as notepads, are in accordance with IRM 1.10.1, _Office of the Commissioner Internal Revenue, IRS Correspondence Manual_, and the Government Printing and Binding Regulations issued by the Joint Committee on Printing (JCP). The Director, Executive Secretariat, and Office of the Commissioner must approve all proposals for new letterhead stationery and notepads.

3. These guidelines create a standardized appearance in letterhead stationery and also apply to notepads.




| **Trim Size** | **Stock – External Use Only** | **Stock – Internal Use Only** | **Ink\*** |
| --- | --- | --- | --- |
| 8-1/2” x 11” | 20# White Recycled 25% Rag Bond (JCP G-45) | 20# White Writing | Green – Pantone Matching System (PMS) 349 |
| 8-1/2” x 11” | Must have Eagle Watermark with Stars | 20# White Writing | Green – Pantone Matching System (PMS) 349 |





### Note:



\\* IRS Taxpayer Advocate Service (TAS) is the only exception to green (PMS 349) ink. TAS letterhead may print black and one color.

4. Packing: All letterhead stationery is shrink-wrapped in units of 500 and stored in the National Distribution Center (NDC). Customers must order letterhead in units of 100.

5. Distribution: M&P’s Distribution organization monitors supply level. For information on obtaining official letterhead through M&P, see IRM 1.17.2.3.7, _Letterhead/Stationery Program_.

6. Printing: All letterhead stationery prints the IRS logo, title of Heads of Office, the business unit/functional division, and the Washington DC address (except for the Chief of the Taxpayer Services division; the TS general letterhead will carry the Atlanta address). Taxpayer Advocate Service letterhead must also print the required “operates independently” statement in the masthead. To access Word templates for internal correspondence only, go to the templates page of the Publishing website.


**1.17.8.5.6** **(08-07-2023)**

#### Training Products

1. Learning and Education (L&E) develops training products supported through the Integrated Talent Management (ITM) system. This includes Training Products Distribution System (TPDS) products and Automated Data Processing (ADP) products used at IRS campuses.

2. Training products are sometimes published as one-time pilot materials that will be used in the development of subsequent ITM courses.

3. Product originators must submit a PSR and the training materials, along with a Form 9123, _TPDS Catalog Change Request_, to Publishing for production.


**1.17.8.5.6.1** **(11-18-2022)**

##### Training Products Numbering

1. The following types of numbers identify training products and courses:



   - ITM course number

   - course catalog number

   - item number

   - item catalog number


2. Obtaining a new ITM official course number is the responsibility of the product originator. L&E uses the course number to deliver training, build classes, plan resources, and give employees credit for attendance. Some courses still have the older 4-digit Administrative Corporate Education System (ACES) number and are still valid courses as they are revised year-to-year.

3. The course catalog number, assigned by M&P’s TPDS Distribution contact, is the identifier used to order all training products required for a class. The course catalog number assigned will be between 80000-82999 plus one alpha character.

4. Publishing uses the item number to identify each product in a course. This number uses the ITM course number as the base number, followed by a hyphen and three numeric digits. See Training Base ID in IRM 1.17.10.4.5, _Item Base ID_, for details. Obtaining item numbers is the responsibility of the Product Originator. For guidance with selecting proper ITM course item numbers, please contact one of Publishing’s training team members.

5. The item catalog number identifies a specific product. All IRS product types use this unique number for identification in the Core Repository of Published Products (CROPP). This item number, like the course catalog number, contains five numeric digits followed by one alpha character.


**1.17.8.5.7** **(10-16-2024)**

#### Promotional Items Guidelines

1. IRM 6.410.10.36(1) specifies that “A business unit may not purchase any promotional items or mementos that include logos or customized slogans. This includes mementos, pens, mouse pads, mugs, and lanyards unique to an organization or event.”

2. Per IRM 6.410.10.2(17), the Human Capital Officer defines a promotional item as "An article of merchandise used in marketing and communications programs. It is often branded with a logo or motto, used to promote an office, idea, or image, and provided as a memento of an event. The article may have an association with an event or be provided independently as a marketing tool.”

3. The Publishing Promotional Products Program defines promotional items as:



   - Promotional Products – Items such as pens, mouse pads, mugs, lanyards, keychains, apparel, or similar products. These products usually have a customized logos or slogans printed, embroidered, or otherwise affixed to them.

   - Event Products – Items that are requested for a conference, convention, meeting, training seminar, workshop, retreat, or symposium. The deputy commissioner must approve events item requests.

   - Commemorative Products – These items include any object kept as a reminder of a person, place, or event. This includes award trophies, speakers’ gifts, and any other item that commemorates an event.


4. IRM 1.17.7 , _Publishing - Use of the Official IRS Seal, IRS Logo, Program Logos, and Internal Logos_, contains additional restrictions on how only qualified employees in the IRS Graphic Design Services office can apply the IRS logo, seal, and Treasury seal. Use of the IRS symbol (the eagle), the logo, the seal, or the Treasury seal are also prohibited whether or not government or personal funds are used.

5. Exceptions - Any IRS office that wants an exception to this policy (IRM 6.410.10.36) must obtain approval from their deputy commissioner.


**1.17.8.6** **(08-07-2023)**

### Copyright and Copyrighted Material

1. Copyright protection provides copyright owners a bundle of exclusive rights, including the right to authorize others to reproduce, transform, or distribute their copyrighted material.

2. Copyright protection arises automatically once an original work of authorship is fixed in a tangible medium of expression now known or later developed.

3. Copyright protection does not extend to any idea, procedure, process, system, method of operations, concept, principle, or discovery, regardless of the form in which it is described, explained, illustrated, or embodied in such work.

4. The IRS will not knowingly include copyrighted material in their publications or other works without the license or written permission of the copyright owner.

5. Because of the complexity of the Copyright Act, product originators will follow the safest course by obtaining written permission from the copyright owner, to avoid possible lawsuits due to copyright infringement. See _IRM 1.17.8.6.8_, _Copyright Infringement_.

6. Do not copyright materials developed by contractors at taxpayer expense.


**1.17.8.6.1** **(11-19-2012)**

#### Requirements for Publishing Copyrighted Material

1. All originators who want to include previously published material (in whole or in part) in government publications must do the following:



   - find out if the material is copyrighted and who owns the copyright

   - get written permission from the copyright owner to print the material

   - the permission statement must clearly define the specific material and its use, including any restrictions or limitations

   - submit the original of the permission statement to Publishing, along with the PSR for printing and the material to be printed


**1.17.8.6.2** **(11-19-2012)**

#### Term of Copyright

1. For works created on or after January 1, 1978, copyright protection endures for a term of the life of the author plus 70 years, as cited in 17 USC 302.

2. For anonymous works, pseudonymous works, and works made for hire, the copyright term is 95 years from the date of first publication, or 120 years from the date of its creation, whichever is earlier, as cited in 17 USC 302.

3. For works created before January 1, 1978, copyright protection endures for a term of 28 years from the date it originally was secured, with the ability to renew for another 67 years, as cited by 17 USC 304(a).


**1.17.8.6.3** **(11-19-2012)**

#### Notice of Copyright

1. A Notice of Copyright, while not required for works first published after March 1, 1989, informs the public that the work to which it is affixed is protected by copyright. A proper notice of copyright also serves to restrict a defense based on innocent infringement in mitigation of actual or statutory damages, as cited in 17 USC 102.


**1.17.8.6.4** **(11-19-2012)**

#### Elements of a Notice of Copyright

1. A notice of copyright as provided by 17 USC 401, consists of the following three elements:



   - symbol © (the letter C in a circle), the word "Copyright" , or the abbreviation "Copr."

   - year of first publication of the work

   - name of the owner of copyright in the work, an abbreviation by which the name can be recognized, or a generally known alternative designation of the owner


These elements must appear in such a manner and location as to give reasonable notice of copyright on all publicly distributed copies when a government publication includes copyrighted materials.



**1.17.8.6.5** **(08-19-2016)**

#### Exceptions to Notice of Copyright Usage

1. Government publications that are prepared by Government Officers or employees as part of their official duties are not subject to copyright protection. See 17 USC 105.

2. Thus, government publications prepared by the Government Officers or employees as part of their official duties and that do not include copyrighted materials, should not include a copyright notice.


**1.17.8.6.6** **(08-07-2023)**

#### "Fair Use" of Copyrighted Material

1. "Fair use" allows the following uses of copyrighted material by other than the copyright owner.



   - courts recognize that certain limited uses of copyrighted material may occur without the copyright owner’s permission.

   - copyright is not infringed when reasonable portions are used for purposes of criticism, comment, news reporting, teaching, scholarship, or research. See 17 USC 107.


2. "Fair Use," however, is not defined in the statute and it does not provide a bright–line rule, which brings clarity to a law or regulation that could be read in two (or more) ways (Often a bright line is established when the need for a simple decision outweighs the need to weigh both sides of a particular issue.), for determining what is or is not a "Fair Use." Rather, "Fair Use" identifies four non-exclusive factors that require evaluation on a case-by-case basis. See _IRM 1.17.8.6_, _Copyright and Copyrighted Material_.


**1.17.8.6.7** **(11-19-2012)**

#### Factors for Determining "Fair Use"

1. Consider the following factors when determining whether the use of a work is a "fair use" :



   - purpose and character of the use, including whether such use is of a commercial nature or is for nonprofit, educational purposes

   - nature of the copyrighted work

   - amount and substantiality of the portion used in relation to the copyrighted work as a whole

   - effect of the use on the potential market for or value of the copyrighted work, as cited in 17 USC 107


**1.17.8.6.8** **(11-19-2012)**

#### Copyright Infringement

1. A copyright is infringed whenever any of the exclusive rights of a copyright owner is practiced without permission by another. Exclusive rights include copying, reproducing, printing, reprinting, publishing, exhibiting, translating, vending (all or portions of the copyrighted work), and, in some instances, oral delivery of performance of the work.



   - Where a copyright is infringed by or for the Government with its authorization or consent, the copyright owner’s exclusive remedy is to sue against the United States in the US Court of Federal Claims for damages or injunctive relief, as cited in 28 USC 1498(b).

   - If the owner is successful in a damages suit, court-imposed statutory damages can range from $750 to $30,000, as cited in 17 USC 504(c)(1).

   - If the infringement is determined willful, damages may lie against the United States up to $150,000, at the Court’s discretion, as cited in 17 USC 504(c)(2).


**1.17.8.6.9** **(11-19-2012)**

#### Credit Lines

1. Credit lines are courtesy acknowledgments for contributed materials not copyrighted or loaned by non-governmental parties.


**1.17.8.6.9.1** **(11-19-2012)**

##### Credit Lines Restrictions

1. Do not use credit lines if the material is purchased for government use.

2. Give credit in a single undisplayed paragraph if a single, non-governmental source provides different types of material for use in one item.


**1.17.8.7** **(08-19-2016)**

### Procurement Vehicles

1. Procure acquisitions other than print and electronic communications products through the IRS Office of the Chief Procurement Officer (OCPO). **Procurement is not authorized to purchase printing services**.

2. Publishing has a variety of procurement vehicles available to meet customer needs and requirements. The procurement processes used include:



   - simplified purchase agreements

   - term contracts

   - one-time bids


**1.17.8.7.1** **(11-19-2012)**

#### Simplified Purchase Agreements

1. Simplified purchase agreements are streamlined publishing procurement vehicles that the Government Publishing Office (GPO) authorizes. Using simplified purchase agreements, publishing specialists can help customers acquire printing and publishing services from commercial printing vendors by directly placing orders or soliciting competitive quotes.


**1.17.8.7.2** **(11-19-2012)**

#### Term Contracts

1. Publishing establishes term contracts for products purchased on a repetitive basis. The GPO writes, awards, and administers these contracts. GPO awards term contracts to publishing vendors who provide the best line-item prices for the covered services.


**1.17.8.7.3** **(07-19-2019)**

#### One-Time Bids

1. Published products that are not suited to other procurement vehicles are procurable using a one-time bid. Publishing specialists forward product requirements to the GPO, where the requirements are advertised to potential vendors. GPO awards the production contract to the lowest bidder who is considered responsive and responsible.


**1.17.8.8** **(11-19-2012)**

### Availability of Internal-Use Products to the Public

1. Follow guidelines in IRM 11.3.12, _Disclosure of Official Information - Designation of Documents_, and obtain originator approval when providing official documents intended for internal use to persons outside the Treasury Department.


**1.17.8.9** **(08-13-2021)**

### Use of Templates for Product Development

1. Content providers have the option to develop certain published products using pre-approved templates. There are two types of templates: downloadable and non-downloadable.


**1.17.8.9.1** **(08-13-2021)**

#### Downloadable Templates

1. Content providers have the option to develop certain published products using pre-approved templates. Visit the IRS Design Servces intranet site to access the available templates. There are two types of templates: downloadable and non-downloadable.

2. Products best suited for downloadable templates are usually single-use items used for one-time events. These products include:



   - agendas

   - bi-folds

   - certificates

   - flyers

   - information sheets

   - name tags

   - PowerPoint presentations (standard and wide)

   - reports

   - table tents


### Note:

Do not use downloadable templates available from the IRS Design Services Office website to produce official IRS published products that have a publication, document or form number and are posted to the IRS Published Products Catalog. However, customers may use the downloadable template for Miscellaneous one-time use products.

**1.17.8.9.2** **(08-13-2021)**

#### Non-downloadable Templates

1. IRS employees Servicewide can use the non-downloadable templates supplied by Publishing. Submit a Publishing Services Request (PSR) for these products and await further instructions. Products best suited for non-downloadable templates can be officially numbered items and items that will be archived and/or referenced for later use. These products include:



   - newsletters

   - generic one-page template

   - generic multi-page template

   - critical job elements (CJEs)

   - job aid templates

   - audit techniques guides (ATGs)


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-017-008#addtoany "Show all")

A2A