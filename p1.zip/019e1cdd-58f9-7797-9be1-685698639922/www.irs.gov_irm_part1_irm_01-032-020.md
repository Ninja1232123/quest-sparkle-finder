---
url: "https://www.irs.gov/irm/part1/irm_01-032-020"
title: "1.32.20 Using Appropriated Funds to Purchase Meals and Light Refreshments | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-032-020#main-content)

- 1.32.20  [Using Appropriated Funds to Purchase Meals and Light Refreshments](https://www.irs.gov/irm/part1/irm_01-032-020#id1)
  - 1.32.20.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-032-020#id2)
    - 1.32.20.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-032-020#id3)
    - 1.32.20.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-032-020#id4)
    - 1.32.20.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-032-020#id5)
      - 1.32.20.1.3.1  [Commissioner](https://www.irs.gov/irm/part1/irm_01-032-020#id7)
      - 1.32.20.1.3.2  [Chief Operating Officer, Chief Tax Compliance Officer, Chief Taxpayer Services and Chief Information Officer](https://www.irs.gov/irm/part1/irm_01-032-020#id8)
      - 1.32.20.1.3.3  [Chief Counsel](https://www.irs.gov/irm/part1/irm_01-032-020#id9)
      - 1.32.20.1.3.4  [CFO and Deputy CFO](https://www.irs.gov/irm/part1/irm_01-032-020#id10)
      - 1.32.20.1.3.5  [Senior Associate CFO for Financial Management](https://www.irs.gov/irm/part1/irm_01-032-020#id11)
      - 1.32.20.1.3.6  [Associate CFO for Corporate Accounting](https://www.irs.gov/irm/part1/irm_01-032-020#id12)
      - 1.32.20.1.3.7  [Travel Management](https://www.irs.gov/irm/part1/irm_01-032-020#id13)
      - 1.32.20.1.3.8  [Travel Review](https://www.irs.gov/irm/part1/irm_01-032-020#id14)
      - 1.32.20.1.3.9  [Business Units](https://www.irs.gov/irm/part1/irm_01-032-020#id15)
    - 1.32.20.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-032-020#id16)
    - 1.32.20.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-032-020#id17)
    - 1.32.20.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-032-020#id18)
    - 1.32.20.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-032-020#id19)
    - 1.32.20.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-032-020#id20)
  - 1.32.20.2  [General Rules](https://www.irs.gov/irm/part1/irm_01-032-020#id21)
  - 1.32.20.3  [Determining the Nature of the Event](https://www.irs.gov/irm/part1/irm_01-032-020#id22)
  - 1.32.20.4  [Award Ceremony Requirements](https://www.irs.gov/irm/part1/irm_01-032-020#id23)
  - 1.32.20.5  [Formal Conference Requirements](https://www.irs.gov/irm/part1/irm_01-032-020#id24)
  - 1.32.20.6  [Training Event Requirements](https://www.irs.gov/irm/part1/irm_01-032-020#id25)
  - 1.32.20.7  [Approval and Documentation](https://www.irs.gov/irm/part1/irm_01-032-020#id26)
  - 1.32.20.8  [Per Diem Adjustment for IRS-Furnished Meals or Light Refreshments](https://www.irs.gov/irm/part1/irm_01-032-020#id27)
  - 1.32.20.9  [Taxability of Meals](https://www.irs.gov/irm/part1/irm_01-032-020#id28)

# Part 1. Organization, Finance, and Management

# Chapter 32. Servicewide Travel Policies and Procedures

# Section 20. Using Appropriated Funds to Purchase Meals and Light Refreshments

* * *

## 1.32.20 Using Appropriated Funds to Purchase Meals and Light Refreshments

#### Manual Transmittal

August 14, 2025

#### Purpose

(1) This transmits revised IRM 1.32.20, Servicewide Travel Policies and Procedures, Using Appropriated Funds to Purchase Meals and Light Refreshments.

#### Material Changes

(1) IRM 1.32.20.1.1(2)(a-d), Background, updated approval authorities per 2024 reorganization.

(2) IRM 1.32.20.1.3(1)(a-h), Responsibilities, updated responsibility titles per 2024 reorganization.

(3) IRM 1.32.20.1.3.1(1), Commissioner, updated approval authority.

(4) IRM 1.32.20.1.3.2(1), Chief Operating Officer, Chief Tax Compliance Officer, Chief Taxpayer Services and Chief Information Officer, updated to add approval authority per 2024 reorganization.

(5) IRM 1.32.20.1.3.4(1)(a-b), CFO and Deputy CFO, updated responsibility per Delegation Order (DO) 1-68, Authorization and Approval to Use Appropriated Funds to Purchase Meals and Light Refreshments.

(6) IRM 1.32.20.1.3.5(1)(a-c), Senior Associate CFO for Financial Management, updated approval authorities per DO 1-68, Authorization and Approval to Use Appropriated Funds to Purchase Meals and Light Refreshments.

(7) IRM 1.32.20.1.3.6(1)(a-c), Associate CFO for Corporate Accounting, added approval authority per DO 1-68, Authorization and Approval to Use Appropriated Funds to Purchase Meals and Light Refreshments.

(8) IRM 1.32.20.1.3.7(1), Travel Management, updated to read The director, Travel Management, is responsible for reviewing business unit requests for the purchase of meals or light refreshments and forwarding Form 14676, Meals and Light Refreshments Request, to the Associate CFO for Corporate Accounting.

(9) IRM 1.32.20.1.3.8(e), Travel Review, updated to read Notifying the business unit of the approval or disapproval of the request to purchase meals or light refreshments and providing a copy of the final documents.

(10) IRM 1.32.20.1.3.9(1)(a-c), Business Units, added (a) Requesting approval to purchase meals or light refreshments by completing Form 14676, Meals and Light Refreshments Request, approved by the business unit Division Commissioner/Chief/Head of Office or their Deputy, (b) Obtaining approval from their business unit budget office to ensure availability of funds and (c) Forwarding the completed Form 14676, Meals and Light Refreshments Request, with appropriate attachments/documentation, no later than 30 days before the event start date to Travel Review at \*CFO-FM-Travel Review@irs.gov.

(11) IRM 1.32.20.1.5(1), Program Controls, Delegation of Authority, updated per DO 1-68, Authorization and Approval to Use Appropriated Funds to Purchase Meals and Light Refreshments.

(12) IRM 1.32.20.1.6(5), Terms and Definitions, Light Refreshments, updated to read Includes, but is not limited to: coffee, tea, milk, juice, soft drinks, ice cream, donuts, bagels, muffins, fruit, vegetable trays, meat and cheese trays (charcuterie style), pretzels, cookies, chips, cake, paper plates, paper napkins and disposable utensils, table cloths and cups. The following items will not be approved: chicken, hot dogs, pizza and any item that could be classified as a meal.

(13) IRM 1.32.20.1.6(9), Terms and Definitions, Training, updated to read A planned, prepared and coordinated program, course, curriculum, subject or program of instruction or education that improves individual and/or organizational performance and helps achieve the IRS mission and performance goals. Requestor must include reporting instructions indicating a Purpose Code Training (T) in line of accounting.

(14) IRM 1.32.20.2(2), General Rules, updated to read Light Refreshments includes, but is not limited to: coffee, tea, milk, juice, soft drinks, ice cream, donuts, bagels, muffins, fruit, vegetable trays, meat and cheese trays (charcuterie style), pretzels, cookies, chips, cake, paper plates, paper napkins and disposable utensils, table cloths and cups. The following items will not be approved: chicken, hot dogs, pizza and any item that could be classified as a meal.

(15) IRM 1.32.20.2(3), General Rules, updated to read Business units should exercise prudence when purchasing meals or light refreshments. If the location of the training/conference provides access to meals, coffee shops, cafeterias or snack bars, business units must utilize these options rather than submitting a request for light refreshments. Requestor must obtain approval from their business unit budget office to ensure availability of funds prior to submitting to the Travel Review office. The amount spent on meals or light refreshments must be reasonable in relation to the nature, size and overall cost of the event. If employees are in travel status, they do not need to reduce their meals and incidental expenses (M&IE) allowance for any light refreshments provided.

(16) IRM 1.32.20.3(1), Determining the Nature of the Event, updated to read The business unit hosting the event should first determine if the event meets the basic criteria for training or awards ceremonies as explained in this IRM. If not, the business unit should determine if it fits the criteria for a formal meeting or conference.

(17) IRM 1.32.20.4(1), Award Ceremony Requirements, updated to read Generally, only items classified as light refreshments are appropriate at an award ceremony. The light refreshments must enhance the recognition of the award recipients as determined by the appropriate IRS official. Business units must exercise prudence when using appropriated funds to purchase light refreshments for awards ceremonies. Business units must limit award ceremonies to no more than two per fiscal year per department and/or location.

(18) IRM 1.32.20.4(3), Award Ceremony Requirements, updated to read The GAO Comptroller General decisions have emphasized that the purposes of award ceremonies are to foster public recognition of employees’ meritorious performance and allow other employees to honor and congratulate their colleagues. In accordance with GEIAA, the event must meet all of the following criteria to be considered an award ceremony. Award ceremonies must be related to recognition of employees, who among other things, have made contributions to the efficiency, economy, or other improvement government operations. Required documentation from requestor must include specific award type, recipient names and program agenda to include speakers.

(19) IRM 1.32.20.4(3), Award Ceremony Requirements, removed (a) and combined with paragraph (3).

(20) IRM 1.32.20.5(2), Formal Conference Requirements, added new bullet to read If the location of the training/conference provides access to meals, coffee shops, cafeterias or snack bars, business units must utilize these options rather than submitting a request for light refreshments. The physical address of conference location must be provided.

(21) IRM 1.32.20.5(3), Formal Conference Requirements, added new bullet to read More than 50% of the participants must be in city-to-city travel status with a copy of the roster, including participants names and assigned PODs, and reporting instructions included.

(22) IRM 1.32.20.6(1), Training Event Requirements, added new bullet to read More than 50% of the participants must be in city-to-city travel status with a copy of the roster, including participants names and assigned PODs, and reporting instructions included. Reporting instructions must indicate a Purpose Code Training (T) in line of accounting.

(23) IRM 1.32.20.6(1)(a-g), Training Event Requirements, updated bullet list to alpha list.

(24) IRM 1.32.20.6(1)(f), Training Event Requirements, added (f) When the location of the training/conference provides access to meals, coffee shops, cafeterias or snack bars, business units must utilize these options rather than submitting a request for light refreshments. The physical address of the training event location must be provided.

(25) IRM 1.32.20.6(1)(g), Training Event Requirements, added (g) When meals or light refreshments are required due to an Inter-Agency Agreement (IAA), with another agency (i.e. State Department, etc), a copy of the most recent agreement must be provided.

(26) IRM 1.32.20.6(2), Training Event Requirements, updated to read Training that meets the requirements detailed in the Office of Personnel Management Training Policy Handbook, and 5 USC Section 4101 et seq, [GETA](https://www.govinfo.gov/content/pkg/USCODE-2011-title5/pdf/USCODE-2011-title5-partIII-subpartC-chap41.pdf). Serving meals and light refreshments is generally only permissible if it is necessary in order for employees to obtain the full benefit of the training. See IRM 1.32.20.6, Training Event Requirements, for additional information.

(27) IRM 1.32.20.7, Special Emphasis Program Requirements, prior section deleted to comply with executive order.

(28) IRM 1.32.20.7(1)(a-d), Approval and Documentation, updated approval authorities per 2024 reorganization.

(29) IRM 1.32.20.7(3), Approval and Documentation, updated to read Business units requesting approval to purchase meals or light refreshments should complete Form 14676, Meals and Light Refreshments Request, obtain approval from their business unit budget office and submit no later than 30 days before the event start date to allow enough time for approval by the appropriate approving official. See (1)(a-d) above.

(30) IRM 1.32.20.7(4), Approval and Documentation, updated to read After Form 14676, Meals and Light Refreshments Request, has been approved the request form should be forwarded to \*CFO-FM-Travel Review@irs.gov. Travel Management will review the request and coordinate obtaining the appropriate signature per DO 1-68, Authorization and Approval to Use Appropriated Funds to Purchase Meals and Light Refreshments.

(31) This revision includes changes throughout the document for the following:

1. Updated office names and responsibilities per IRS 2024 reorganization.

2. Updated links and references.

3. Updated the CFO office names and responsibilities per CFO reorganization.


#### Effect on Other Documents

IRM 1.32.20, dated April 29, 2022, is superseded.

#### Audience

All business units

#### Effective Date

(08-14-2025)

Anthony S. Chavez

Acting Chief Financial Officer

**1.32.20.1** **(04-15-2020)**

### Program Scope and Objectives

1. Purpose: This IRM provides IRS policies and procedures for business units requesting approval to use appropriated funds to purchase meals or light refreshments for events that the IRS sponsors or hosts.

2. Audience: All business units

3. Policy Owner: CFO, Financial Management

4. Program Owner: CFO, Financial Management, Travel Management office, develops and maintains this IRM.

5. Primary Stakeholders: The primary stakeholders are IRS business units that host or sponsor events and use appropriated funds to purchase meals or light refreshments for event participants.

6. Program Goals: To track and monitor funds appropriated and used to purchase light refreshments at events that IRS sponsors or hosts. The IRS has a responsibility to act as a careful steward of taxpayer dollars, ensuring that federal funds are used for purposes that are appropriate, cost effective and important to the IRS’s core mission. Business units must exercise the same care in purchasing meals or light refreshments that a prudent person would exercise if incurring these expenses on personal business.


**1.32.20.1.1** **(08-14-2025)**

#### Background

1. The Comptroller General has identified statutory authorities that permit the use of appropriated funds to pay for meals and light refreshments in limited circumstances for IRS-sponsored events. The Government Accountability Office (GAO) publishes the Principles of Federal Appropriations Law, referred to as the "Red Book," which serves as a detailed fiscal law guide covering those areas of law in which the Comptroller General renders decisions. The Red Book provides detailed guidance regarding the availability and use of federal funds.

2. As a general rule, the IRS may not use appropriated funds to furnish meals or light refreshments for federal employees or private sector individuals. Exceptions to this rule must be specifically authorized under statute and approved per Delegation Order 1-68, Authorization and Approval to Use Appropriated Funds to Purchase Meals and Light Refreshments, as follows:



1. IRS Commissioner for amounts $20,000 or more but less than $50,000.

2. Chief Tax Compliance Officer, Chief Taxpayer Services, Chief Operating Officer and Chief Information Officer for amounts $2,500 or more but less than $20,000.

3. Senior Associate CFO for Financial Management for amounts $1,500 or more but less than $2,500.

4. Associate CFO for Corporate Accounting for amounts less than $1,500.


3. This IRM outlines the specific requirements addressing specific circumstances where federal agencies may request approval to use appropriated funds to purchase meals or light refreshments for government-sponsored events.


**1.32.20.1.2** **(04-29-2022)**

#### Authorities

1. 5 United States Code (USC) 4101-4118 et seq., [Government Employees Training Act (GETA)](https://www.govinfo.gov/content/pkg/USCODE-2011-title5/pdf/USCODE-2011-title5-partIII-subpartC-chap41.pdf)

2. 5 USC 4501-06, [Government Employees Incentive Awards Act (GEIAA)](https://www.govinfo.gov/content/pkg/USCODE-2020-title5/pdf/USCODE-2020-title5.pdf)

3. 26 USC 61, [Gross Income Defined](https://www.law.cornell.edu/uscode/text/26/61)

4. 26 USC 119, [Meals and Lodging Furnished for the Convenience of the Employer](https://www.law.cornell.edu/uscode/text/26/119)

5. Federal Regulations (CFR) 301-304, [Federal Travel Regulation (FTR)](https://www.ecfr.gov/current/title-41/subtitle-F/chapter-301)

6. GAO, Principles of Federal Appropriations Law, Chapter 3 (4th ed) (GAO Report No. GAO-17-797SP), Section C5, [Food](https://www.gao.gov/assets/2019-11/687162.pdf)


**1.32.20.1.3** **(08-14-2025)**

#### Responsibilities

1. This section provides responsibilities for:



1. Commissioner

2. Chief Operating Officer, Chief Tax Compliance Officer, Chief Taxpayer Services and Chief Information Officer

3. Chief Counsel

4. CFO and Deputy CFO

5. Senior Associate CFO for Financial Management

6. Associate CFO for Corporate Accounting

7. Travel Management

8. Travel Review

9. Business units


**1.32.20.1.3.1** **(08-14-2025)**

##### Commissioner

1. The Commissioner is responsible for authorizing and approving requests for the purchase of meals or light refreshments for amounts $20,000 or more but less than $50,000.


**1.32.20.1.3.2** **(08-14-2025)**

##### Chief Operating Officer, Chief Tax Compliance Officer, Chief Taxpayer Services and Chief Information Officer

1. The Chief Operating Office, Chief Tax Compliance Office, Chief Taxpayer Services, Chief Information Officer, or the appropriate Head of Office is responsible for authorizing and approving requests for amounts $2,500 or more but less than $20,000.


**1.32.20.1.3.3** **(04-15-2020)**

##### Chief Counsel

1. The Chief Counsel is responsible for:



1. Reviewing and approving all Chief Counsel requests for the purchase of meals and light refreshments at any cost.

2. Reviewing and providing written opinions and concurrence on requests for light refreshments when special circumstances exist.


**1.32.20.1.3.4** **(08-14-2025)**

##### CFO and Deputy CFO

1. The CFO and Deputy CFO are responsible for:



1. Reviewing and approving the policy on using appropriated funds to purchase meals or light refreshments.

2. Reviewing and submitting requests for the purchase of meals or light refreshments and forwarding Form 14676, Meals and Light Refreshments Request, to the appropriate approving official for amounts $2,500 or greater.


**1.32.20.1.3.5** **(08-14-2025)**

##### Senior Associate CFO for Financial Management

1. The Senior Associate CFO for Financial Management is responsible for:



1. Establishing and ensuring compliance with policies, procedures, standards and controls for using appropriated funds to purchase meals or light refreshments.

2. Reviewing business unit requests for the purchase of meals or light refreshments and forwarding Form 14676, Meals and Light Refreshments Request, to the Deputy CFO.

3. Authorizing and approving requests for amounts $1,500 or more but less than $2,500.


**1.32.20.1.3.6** **(08-14-2025)**

##### Associate CFO for Corporate Accounting

1. The Associate CFO for Corporate Accounting is responsible for:



1. Establishing and ensuring compliance with policies, procedures, standards and controls for using appropriated funds to purchase meals or light refreshments.

2. Reviewing business unit requests for the purchase of meals or light refreshments and forwarding Form 14676, Meals and Light Refreshments Request, to the Senior Associate CFO for Financial Management.

3. Authorizing and approving requests for amounts less than $1,500.


**1.32.20.1.3.7** **(08-14-2025)**

##### Travel Management

1. The director, Travel Management, is responsible for reviewing business unit requests for the purchase of meals or light refreshments and forwarding Form 14676, Meals and Light Refreshments Request, to the Associate CFO for Corporate Accounting.


**1.32.20.1.3.8** **(08-14-2025)**

##### Travel Review

1. Travel Policy and Review is responsible for:



1. Establishing and providing guidance to business units to request approval to purchase meals or light refreshments.

2. Educating business unit staff on the process and procedures for business units to request approval to purchase meals or light refreshments.

3. Authoring IRM 1.32.20, Using Appropriated Funds to Purchase Meals and Light Refreshments, and Form 14676, Meals and Light Refreshments Request.

4. Reviewing business unit requests for the purchase of meals or light refreshments and forwarding Form 14676, Meals and Light Refreshments Request, to the director, Travel Management.

5. Notifying the business unit of the approval or disapproval of the request to purchase meals or light refreshments and providing a copy of the final documents.

6. Maintaining a log that includes all requests for the use of appropriated funds to purchase meals or light refreshments and the disposition of each request.


**1.32.20.1.3.9** **(08-14-2025)**

##### Business Units

1. The business units are responsible for:



1. Requesting approval to purchase meals or light refreshments by completing Form 14676, Meals and Light Refreshments Request, approved by the business unit Division Commissioner/Chief/Head of Office or their Deputy.

2. Obtaining approval from their business unit budget office to ensure availability of funds.

3. Forwarding the completed Form 14676, Meals and Light Refreshments Request, with appropriate attachments/documentation, no later than 30 days before the event start date to Travel Review at \*CFO-FM-Travel Review@irs.gov.

4. Ensuring the approvals for the purchase of meals or light refreshments are properly documented and the documentation is maintained for a period of six years for inspection by TIGTA or other interested parties.


**1.32.20.1.4** **(04-15-2020)**

#### Program Management and Review

1. Internal controls are established to ensure the use of appropriated funds for meals and light refreshments are managed effectively.

2. Program Reports: Government purchases must meet all requirements of law, executive orders, regulations and all other applicable IRS procedures. Travel Review uses reports obtained from the Integrated Financial System to manage funds for meals and light refreshments to ensure compliance.

3. Program Effectiveness: Throughout the year, program effectiveness is measured through 100% review of Form 14676, Meals and Light Refreshments Request, to ensure accuracy and compliance with this IRM and the FTR. If the business units and reviewing officials determine the requests for meals and light refreshments are not accurate and compliant, the requests will be disapproved.


**1.32.20.1.5** **(08-14-2025)**

#### Program Controls

1. Several program controls are in place to ensure compliance with this IRM. They include, but are not limited to, the controls listed below:




| Control | Control Method |
| --- | --- |
| Delegation of Authority | IRS Commissioner for amounts $20,000 or more but less than $50,000 • Chief Tax Compliance Officer, Chief Taxpayer Services, Chief Operating Officer and Chief Information Officer for amounts $2,500 or more but less than $20,000 • Senior Associate CFO for Financial Management for amounts $1,500 or more but less than $2,500 • Associate CFO for Corporate Accounting for amounts less than $1,500. |
| Separation of Duties | Separate roles are established for the individuals, positions and offices that review and approve requests. |
| Documentation Reviews | Travel Review, the director of Travel Management and Associate CFO for Corporate Accounting conduct reviews of all documentation for purchasing meals and light refreshments of $1,500 or more are approved or elevated for higher level approval. Under $1,500 is approved by the Associate CFO for Corporate Accounting with no higher level review required. |
| Document Retention | Event coordinators/hosts are responsible for ensuring the event is properly documented and must have these records available for inspection by TIGTA or other interested parties for a period of six years. |


**1.32.20.1.6** **(08-14-2025)**

#### Terms/Definitions

1. The following terms and definitions apply to this program:

2. **Conference -** A pre-arranged formal event with at least some of the following characteristics: designated participants and/or registration; a published substantive agenda and scheduled speakers or discussion panels on a particular topic; and incurred IRS expenses (other than the salaries of attendees), such as expenses for refreshments, meals or travel (including transportation, lodging, or other expenses authorized under the FTR). A conference may include, but is not limited to, a retreat, convention, seminar or symposium. A conference typically is not a:



   - Routine operational meeting

   - Law enforcement activity

   - Mission-critical core function activity

   - Bureau’s response to an emergency or recovery activity related to a catastrophic event

   - Testing activity (including the planning, scheduling and conducting)

   - Technical assistance/operational review site visit


3. **Event -**An all-inclusive term to include a conference, meeting, training occurrence, award ceremony or other similar gathering that involves expenses of the attendees, such as for travel, meals or refreshments.

4. **Event coordinator -** An individual or office responsible for coordinating an event.

5. **Light refreshments -**Includes, but is not limited to: coffee, tea, milk, juice, soft drinks, ice cream, donuts, bagels, muffins, fruit, vegetable trays, meat and cheese trays (charcuterie style), pretzels, cookies, chips, cake, paper plates, paper napkins and disposable utensils, table cloths and cups. The following items will not be approved: chicken, hot dogs, pizza and any item that could be classified as a meal.

6. **Meal -**A quantity of food that equals a full serving of breakfast, lunch or dinner.

7. **Official station -** The location where the employee is officially assigned to perform their regular duties. The geographic limits of the official station are the corporate limits of the city or town where the employee is located, or, if not in an incorporated city or town, the reservation, station or other established area having definite boundaries where the employee is located, not to exceed 50-miles from the building or street where the employee is normally assigned. If the employee’s work involves recurring travel or varies on a recurring basis, the location where the work activities of the employee’s position of record is based is considered the regular place of work.

8. **Training -** A planned, prepared and coordinated program, course, curriculum, subject or program of instruction or education that improves individual and/or organizational performance and helps achieve the IRS mission and performance goals. The requestor must include reporting instructions indicating a Purpose Code Training (T) in line of accounting.


**1.32.20.1.7** **(04-29-2022)**

#### Acronyms

1. The following acronyms apply to this program:




| Acronyms | Description |
| :-: | :-: |
| CFR | Code of Federal Regulations |
| FTR | Federal Travel Regulation |
| GAO | Government Accountability Office |
| GEIAA | Government Employees' Incentive Awards Act |
| GETA | Government Employees Training Act |
| M&IE | Meals and Incidental Expenses |
| USC | United States Code |


**1.32.20.1.8** **(04-15-2020)**

#### Related Resources

1. IRM 1.32.10, Reporting on Event-Related Spending

2. IRM 1.32.11, IRS City-to-City Travel Guide

3. IRM 1.33.4, Financial Operating Guidelines

4. IRM 6.410.1, Learning and Education Policy

5. IRM 6.451.1, Employee Performance and Utilization - Awards and Recognition


**1.32.20.2** **(08-14-2025)**

### General Rules

1. The Comptroller General has identified statutory authorities that permit the use of appropriated funds to pay for meals or light refreshments at IRS-sponsored events in the following circumstances:



1. Formal conferences that meet the requirements detailed in IRM 1.32.20.5, Formal Conference Requirements, and 5 USC Section 4110, [Expenses of Attendance at Meetings.](https://www.govinfo.gov/content/pkg/USCODE-2020-title5/pdf/USCODE-2020-title5.pdf)

2. Training that meets the requirements detailed in the Office of Personnel Management Training Policy Handbook, and 5 USC Section 4101 et seq, [GETA](https://www.govinfo.gov/content/pkg/USCODE-2011-title5/pdf/USCODE-2011-title5-partIII-subpartC-chap41.pdf). Serving meals and light refreshments is generally only permissible if it is necessary in order for employees to obtain the full benefit of the training. See IRM 1.32.20.6, Training Event Requirements, for additional information.

3. Award ceremonies that meet the requirements detailed in IRM 6.451.1.21, Award Presentation Ceremonies, and 5 USC 4501-06, [GEIAA](https://www.govinfo.gov/content/pkg/USCODE-2011-title5/pdf/USCODE-2011-title5.pdf). Agencies may provide light refreshments at an award ceremony when employees are publicly recognized for special acts and achievements. See IRM 1.32.20.4, Award Ceremony Requirements, for more information.


2. Light refreshments includes, but is not limited to: coffee, tea, milk, juice, soft drinks, ice cream, donuts, bagels, muffins, fruit, vegetable trays, meat and cheese trays (charcuterie style), pretzels, cookies, chips, cake, paper plates, paper napkins and disposable utensils, table cloths and cups. The following items will not be approved: chicken, hot dogs, pizza and any item that could be classified as a meal.

3. Business units should exercise prudence when purchasing meals or light refreshments. If the location of the training/conference provides access to meals, coffee shops, cafeterias or snack bars, business units must utilize these options rather than submitting a request for light refreshments. The requestor must obtain approval from their business unit budget office to ensure availability of funds prior to submitting to the Travel Review office. The amount spent on meals or light refreshments must be reasonable in relation to the nature, size and overall cost of the event. If employees are in travel status, they do not need to reduce their meals and incidental expenses (M&IE) allowance for any light refreshments provided.

4. When holding an event in a hotel or similar facility, a business unit cannot contract to pay for meals or light refreshments and allow the facility to provide the conference rooms or support at no cost to the government. In other words, the hotel is not allowed to provide a free conference room (″comp″ a room) in exchange for the IRS purchasing meals or light refreshments.

5. The IRS cannot use appropriated funds to pay for meals or light refreshments at preliminary or evening social gatherings or during breaks to merely facilitate social interaction or to improve the attendance of participants.

6. The IRS is generally prohibited from using appropriated funds to pay for meals or light refreshments at day-to-day internal business meetings.



1. Day-to-day business meetings involve discussions of IRS internal procedures or operations. Attendance at routine IRS-sponsored meetings is generally subject to the prohibition on furnishing meals to employees at their official duty stations.

2. The presence of a mealtime speaker between meeting segments to discuss business, management and day-to-day operations does not provide an adequate basis for providing meals or light refreshments.


**1.32.20.3** **(08-14-2025)**

### Determining the Nature of the Event

1. The business unit hosting the event should first determine if the event meets the basic criteria for training or awards ceremonies as explained in this IRM. If not, the business unit should determine if it fits the criteria for a formal meeting or conference.

2. To determine if meals or light refreshments are authorized, the business units may consult with General Legal Services, HCO or with the CFO Travel Review office for advice on the nature of an event.

3. Event coordinators/hosts are responsible for obtaining the appropriate approval and ensuring the event is properly documented (for example, invitation letters, registration forms, sign-in agendas) and must have these records available for inspection by TIGTA or other interested parties for a period of six years.


**1.32.20.4** **(08-14-2025)**

### Award Ceremony Requirements

1. Generally, only items classified as light refreshments are appropriate at an award ceremony. The light refreshments must enhance the recognition of the award recipients as determined by the appropriate IRS official. Business units must exercise prudence when using appropriated funds to purchase light refreshments for awards ceremonies. Business units must limit award ceremonies to no more than two per fiscal year per department and/or location.

2. The GEIAA permits agencies to incur necessary expenses for the honorary recognition of federal employees under established awards programs.

3. The GAO Comptroller General decisions have emphasized that the purposes of award ceremonies are to foster public recognition of employees’ meritorious performance and allow other employees to honor and congratulate their colleagues. In accordance with GEIAA, the event must meet all of the following criteria to be considered an award ceremony. Award ceremonies must be related to recognition of employees, who among other things, have made contributions to the efficiency, economy, or other improvement to government operations. Required documentation from the requestor must include the specific award type, recipient names and the program agenda to include speakers.



1. The awards must recognize special acts or achievements (participation awards do not qualify).

2. The award recipients must be publicly recognized.


4. The GAO Comptroller General decisions do not authorize providing meals or light refreshments to recognize employees for their achievements in connection with an event or function that is primarily designed to achieve other agency objectives.


**1.32.20.5** **(08-14-2025)**

### Formal Conference Requirements

1. The IRS may be able to use appropriated funds to pay for meals or light refreshments at conferences, provided that the event meets the following requirements..

2. The event:



   - Must include registration, published substantive agendas and scheduled speakers.

   - Must involve topical matters of interest to and participation of multiple agencies and/or non-governmental participants.

   - Cannot be a routine event that covers day-to-day IRS operations.

   - If the location of the training/conference provides access to meals, coffee shops, cafeterias or snack bars, business units must utilize these options rather than submitting a request for light refreshments. The physical address of conference location must be provided.


3. In addition:



   - The meal must be incidental to the event.

   - The meal must be part of an event that includes formal presentations and functions separate from when the meal is served.

   - Attendance during the meal service must be required to ensure the audience’s full participation.

   - More than 50% of the participants must be in city-to-city travel status with a copy of the roster, including participants names and assigned PODs, and reporting instructions included.


4. The quantity of the meals or light refreshments provided must be commensurate with the scale of the conference. Business units must exercise prudence when using appropriated funds to purchase meals or light refreshments for formal conferences. Generally, the cost per person may not exceed 25% of the per diem rate for applicable meals based on the geographic location of the conference.



> Example: There are 100 attendees scheduled to attend a conference in Little Rock, Arkansas. The M&IE rate for this location is $55 per day. The maximum amount paid for a meal should not exceed $1,375 per day ($55 times .25 equals $13.75; times 100 equals $1,375).


**1.32.20.6** **(08-14-2025)**

### Training Event Requirements

1. Training that meets the requirements detailed in the Office of Personnel Management Training Policy Handbook, and 5 USC Section 41 et seq, [GETA](https://www.govinfo.gov/content/pkg/USCODE-2011-title5/pdf/USCODE-2011-title5-partIII-subpartC-chap41.pdf). Serving meals and light refreshments is generally only permissible if it is necessary in order for employees to obtain the full benefit of the training. See IRM 1.32.20.6 , Training Event Requirements, for additional information. the event must meet all of the following criteria:



1. The announced purpose of the training must be educational or instructional.

2. More than half of the time must be scheduled for an organized exchange of information between presenters and audience.

3. The content of the event must be relevant to improving individual/organizational performance.

4. Developmental benefits must be derived by attendance.

5. More than 50% of the participants must be in city-to-city travel status with a copy of the roster, including participants names and assigned PODs, and reporting instructions included. Reporting instructions must indicate a Purpose Code Training (T) in line of accounting.

6. When the location of the training/conference provides access to meals, coffee shops, cafeterias or snack bars, business units must utilize these options rather than submitting a request for light refreshments. The physical address of the training event location must be provided.

7. When meals or light refreshments are required due to an Inter-Agency Agreement (IAA), with another agency (i.e. State Department, etc), a copy of the most recent agreement must be provided.


2. Training that meets the requirements detailed in the Office of Personnel Management Training Policy Handbook, and 5 USC Section 4101 et seq, [GETA](https://www.govinfo.gov/content/pkg/USCODE-2011-title5/pdf/USCODE-2011-title5-partIII-subpartC-chap41.pdf). Serving meals and light refreshments is generally only permissible if it is necessary in order for employees to obtain the full benefit of the training. See IRM 1.32.20.6, Training Event Requirements, for additional information.


**1.32.20.7** **(08-14-2025)**

### Approval and Documentation

1. Requests to use appropriated funds to purchase meals or light refreshments must be approved in advance of the event by the:



1. IRS Commissioner for amounts $20,000 or more but less than $50,000.

2. Chief Tax Compliance Officer, Chief Taxpayer Services, Chief Operating Officer and Chief Information Officer for amounts $2,500 or more but less than $20,000.

3. Senior Associate CFO for Financial Management for amounts $1,500 or more but less than $2,500.

4. Associate CFO for Corporate Accounting for amounts less than $1,500.


2. To facilitate the request/approval process, Frequently Asked Questions have been developed and posted to the Manager’s Corner to assist business units with requesting approval to purchase meals or light refreshments.

3. Business units requesting approval to purchase meals or light refreshments should complete Form 14676, Meals and Light Refreshments Request, obtain approval from their business unit budget office and submit no later than 30 days before the event start date to allow enough time for approval by the appropriate approving official. See (1)(a-d) above.

4. After Form 14676, Meals and Light Refreshments Request, has been approved the request form should be forwarded to Travel Review at \*CFO-FM-Travel Review@irs.gov. Travel Management will review the request and coordinate obtaining the signature of the appropriate official per DO 1-68, Authorization and Approval to Use Appropriated Funds to Purchase Meals and Light Refreshments.

5. Business units are responsible for obtaining the appropriate event spending and training event approvals through the Servicewide Training and Event Tracking System as published on HCO’s Servicewide Training & Event Management website.

6. Some hotel contracts include refreshments and/or lodging and require the acceptance of contractual terms and conditions that are subject to IRS procurement processes and procedures.

7. Business units should ensure that the event is properly documented with, for example, invitation letters, registration forms, sign-in agendas, and letters/memoranda documenting how much was spent for the event, including the actual costs incurred for any light refreshments or meals served. These records must be available for inspection by TIGTA or other interested parties for a period of six years.


**1.32.20.8** **(04-15-2020)**

### Per Diem Adjustment for IRS-Furnished Meals or Light Refreshments

1. In accordance with the FTR, when the IRS furnishes meals or light refreshments, an attendee in travel status must make the following adjustments for claimed M&IE:



1. If the IRS furnishes meals, the attendee must deduct the appropriate amount from the claimed M&IE.

2. If the IRS furnishes light refreshments, the attendee does not need to adjust or reduce the M&IE amount.


2. [FTR 41 CFR 301–11.17 through 11.19](https://www.ecfr.gov/current/title-41/subtitle-F/chapter-301), provides additional information on this requirement, including exceptions.


**1.32.20.9** **(04-15-2020)**

### Taxability of Meals

1. Meals furnished by the IRS may be taxable to the employee when a trip is less than 24 hours without overnight lodging. Business units need to consider the potential tax implications of providing meals to employees at their official stations prior to providing such meals.

2. See IRS Publication 15-B, [Employer's Tax Guide to Fringe Benefits](https://www.irs.gov/publications/p15b), for guidance on the tax treatment of employer-provided meals and on the circumstances in which meals may be excluded from income.

3. The business unit event coordinator is responsible for reporting taxable meals furnished to IRS employees to Travel Management. The event coordinator can contact the Travel Operations help desk at \*CFO BFC Help Desk.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-032-020#addtoany "Show all")

A2A