---
url: "https://www.irs.gov/irm/part1/irm_01-001-016"
title: "1.1.16 Small Business/Self-Employed Division | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-001-016#main-content)

- 1.1.16  [Small Business/Self-Employed Division](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897369920)
  - 1.1.16.1  [The Small Business/Self Employed Division Commissioner and Deputy Commissioner](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897904208)
    - 1.1.16.1.1  [Mission of the Small Business/Self Employed Division](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897896064)
  - 1.1.16.2  [Office of Fraud Enforcement (OFE)](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897886656)
  - 1.1.16.3  [Collection](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897869024)
    - 1.1.16.3.1  [Field Collection](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897856848)
      - 1.1.16.3.1.1  [Field Collection Area](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897843648)
        - 1.1.16.3.1.1.1  [Field Collection Territories](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897833344)
      - 1.1.16.3.1.2  [Director, Civil Enforcement Advice and Support Operations](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897825984)
        - 1.1.16.3.1.2.1  [Advisory](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897822928)
        - 1.1.16.3.1.2.2  [Property Appraisal and Liquidation Specialist](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897812848)
    - 1.1.16.3.2  [Planning and Performance Analysis](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897809280)
      - 1.1.16.3.2.1  [Enterprise Reports and Plans](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897801520)
      - 1.1.16.3.2.2  [Campus Reports and Plans](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897796000)
      - 1.1.16.3.2.3  [Collection Data Assurance and Specialty Reports and Plans](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897788736)
      - 1.1.16.3.2.4  [Field and Specialty (INS) Reports and Plans](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897779040)
      - 1.1.16.3.2.5  [Private Debt Collection Operations](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897769936)
    - 1.1.16.3.3  [Headquarters Collection](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897761040)
      - 1.1.16.3.3.1  [Collection Policy](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897747216)
        - 1.1.16.3.3.1.1  [Global Strategic Compliance](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897730240)
        - 1.1.16.3.3.1.2  [Enforcement](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897712816)
        - 1.1.16.3.3.1.3  [Campus Policy](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897705920)
        - 1.1.16.3.3.1.4  [Offer in Compromise](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897696784)
        - 1.1.16.3.3.1.5  [Employment Tax Policy](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897685840)
        - 1.1.16.3.3.1.6  [Insolvency](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897294144)
        - 1.1.16.3.3.1.7  [Case Resolution Alternatives](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897287360)
        - 1.1.16.3.3.1.8  [Campus Operations](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897282768)
        - 1.1.16.3.3.1.9  [Oversight Coordination and Support Office](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897269888)
      - 1.1.16.3.3.2  [Collection Inventory Delivery and Selection](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897261744)
        - 1.1.16.3.3.2.1  [Nonfiler Inventory and Analysis](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897243920)
          - 1.1.16.3.3.2.1.1  [Campus Nonfiler Support](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897235888)
        - 1.1.16.3.3.2.2  [Strategic Analysis and Modeling](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897227568)
        - 1.1.16.3.3.2.3  [Collection Case Delivery](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897220224)
          - 1.1.16.3.3.2.3.1  [Automated Lien and ENTITY Customer Support](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897211664)
        - 1.1.16.3.3.2.4  [Automated Programs](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897204656)
        - 1.1.16.3.3.2.5  [Collection Analytics, Routing and Selection](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897196416)
        - 1.1.16.3.3.2.6  [ACS Systems and Inventory](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897188464)
        - 1.1.16.3.3.2.7  [Collection Innovation and Implementation Office](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897182176)
      - 1.1.16.3.3.3  [Quality and Technical Support](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897174992)
        - 1.1.16.3.3.3.1  [Collection Quality](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897167200)
        - 1.1.16.3.3.3.2  [Collection Automation Support & Security](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897147264)
        - 1.1.16.3.3.3.3  [Joint Operations Center](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897137152)
    - 1.1.16.3.4  [Campus Collection](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897115584)
      - 1.1.16.3.4.1  [Campus Collection Operations](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897107424)
        - 1.1.16.3.4.1.1  [Campus Collection Operations Managers](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897100688)
          - 1.1.16.3.4.1.1.1  [Centralized Lien Operation](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897087696)
    - 1.1.16.3.5  [Specialty Collection-Offer in Compromise](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897085328)
      - 1.1.16.3.5.1  [Offer in Compromise](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897081600)
    - 1.1.16.3.6  [Specialty Collection Insolvency](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897078592)
      - 1.1.16.3.6.1  [Insolvency](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897070400)
  - 1.1.16.4  [Office of Promoter Investigations (OPI)](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897063360)
  - 1.1.16.5  [Examination](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897050208)
    - 1.1.16.5.1  [Field Examination](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897039904)
      - 1.1.16.5.1.1  [Field Examination Areas](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897028336)
        - 1.1.16.5.1.1.1  [Field Examination Territories](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897018944)
          - 1.1.16.5.1.1.1.1  [Technical Services Territories](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388897011680)
    - 1.1.16.5.2  [Campus Examination and Automated Underreporter (AUR)](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896996240)
      - 1.1.16.5.2.1  [Campus Examination and Automated Underreporter (AUR) Operations](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896986384)
    - 1.1.16.5.3  [Specialty Examination](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896978096)
      - 1.1.16.5.3.1  [Excise Tax Examination](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896968880)
        - 1.1.16.5.3.1.1  [Excise Tax Examination Territories](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896957904)
      - 1.1.16.5.3.2  [Estate and Gift Tax Examination](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896950224)
        - 1.1.16.5.3.2.1  [Estate and Gift Tax Examination Territories](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896938928)
      - 1.1.16.5.3.3  [Employment Tax Examination](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896931520)
        - 1.1.16.5.3.3.1  [Employment Tax Territories](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896918896)
      - 1.1.16.5.3.4  [Bank Secrecy Act (BSA) Examination](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896906192)
        - 1.1.16.5.3.4.1  [BSA Examination Territories](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896897296)
        - 1.1.16.5.3.4.2  [BSA Currency Transactions Reporting (CTR) Operations](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896889968)
    - 1.1.16.5.4  [Performance Planning and Analysis](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896883968)
      - 1.1.16.5.4.1  [Field and Specialty Examination Workload Planning and Analysis (FSWPA)](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896873248)
      - 1.1.16.5.4.2  [Campus Examination and Document Matching Workload Planning and Analysis (CEDWPA)](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896867872)
      - 1.1.16.5.4.3  [Examination Data Management (EDM)](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896862208)
      - 1.1.16.5.4.4  [Examination GAO/TIGTA and Information Technology Management (GTIT)](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896856672)
    - 1.1.16.5.5  [Examination Headquarters](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896849616)
      - 1.1.16.5.5.1  [Examination Field and Campus Policy](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896840048)
        - 1.1.16.5.5.1.1  [Field Examination General Processes](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896830624)
        - 1.1.16.5.5.1.2  [Field Examination Special Processes](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896824288)
        - 1.1.16.5.5.1.3  [IMF/AUR Policy](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896818432)
        - 1.1.16.5.5.1.4  [BMF Document Matching](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896812160)
        - 1.1.16.5.5.1.5  [Campus Exam and Field Support](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896805120)
      - 1.1.16.5.5.2  [Specialty Examination Policy](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896798384)
        - 1.1.16.5.5.2.1  [Bank Secrecy Act (BSA) Policy](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896789728)
        - 1.1.16.5.5.2.2  [Employment Tax Policy](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896781344)
        - 1.1.16.5.5.2.3  [Estate and Gift Tax Policy](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896773392)
        - 1.1.16.5.5.2.4  [Excise Tax Policy](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896764448)
      - 1.1.16.5.5.3  [Exam Case Selection](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896756848)
        - 1.1.16.5.5.3.1  [Field Case Selection](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896748064)
        - 1.1.16.5.5.3.2  [Campus Case Selection](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896741504)
        - 1.1.16.5.5.3.3  [Document Matching Analysis and Case Selection](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896735552)
        - 1.1.16.5.5.3.4  [Bank Secrecy Act (BSA) Case Selection](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896728000)
        - 1.1.16.5.5.3.5  [Employment and Estate & Gift Case Selection](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896720288)
          - 1.1.16.5.5.3.5.1  [Employment Workload Selection and Delivery](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896716816)
          - 1.1.16.5.5.3.5.2  [Estate and Gift Workload Selection and Delivery](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896709024)
        - 1.1.16.5.5.3.6  [Excise Case Selection](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896701104)
          - 1.1.16.5.5.3.6.1  [Excise Workload Selection and Delivery](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896698320)
          - 1.1.16.5.5.3.6.2  [Joint Operations Center (JOC)](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896690592)
      - 1.1.16.5.5.4  [Exam Quality and Technical Support](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896684016)
        - 1.1.16.5.5.4.1  [Technical Support Group 1](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896674080)
        - 1.1.16.5.5.4.2  [Technical Support Group 2](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896667952)
        - 1.1.16.5.5.4.3  [Technical Support Group 3](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896661696)
        - 1.1.16.5.5.4.4  [Technical Support Group 4](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896654688)
        - 1.1.16.5.5.4.5  [Campus Exam Quality](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896648304)
        - 1.1.16.5.5.4.6  [Field and Specialty Exam Quality](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896640496)
    - 1.1.16.5.6  [Examination Customer Coordination and Innovation Office](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896633696)
  - 1.1.16.6  [Operations Support](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896620448)
    - 1.1.16.6.1  [Technology Solutions](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896615984)
      - 1.1.16.6.1.1  [Collection Systems & Projects](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896609472)
      - 1.1.16.6.1.2  [Capital Planning & Investment Control](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896604832)
      - 1.1.16.6.1.3  [Business Data Solutions](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896600576)
      - 1.1.16.6.1.4  [Business Systems Planning](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896596752)
      - 1.1.16.6.1.5  [Report Generation Software Support & Correspondence Examination Automation Support](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896592768)
      - 1.1.16.6.1.6  [Examination Systems & Projects](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896588064)
      - 1.1.16.6.1.7  [Project Management Office](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896583360)
      - 1.1.16.6.1.8  [Business Modernization Support](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896579552)
    - 1.1.16.6.2  [Business Support Office](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896575584)
      - 1.1.16.6.2.1  [Workforce and Program Analysis](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896564928)
      - 1.1.16.6.2.2  [Support Resources & Analysis](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896559136)
      - 1.1.16.6.2.3  [Budget and Contract Oversight](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896552880)
      - 1.1.16.6.2.4  [Office of Servicewide Penalties](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896546688)
      - 1.1.16.6.2.5  [Office of Servicewide Interest](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896541568)
    - 1.1.16.6.3  [SB/SE Human Capital Office](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896535968)
      - 1.1.16.6.3.1  [Collection Training](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896522432)
      - 1.1.16.6.3.2  [Operations Support & Cross-Functional Training](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896513088)
      - 1.1.16.6.3.3  [Examination Training](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896502688)
      - 1.1.16.6.3.4  [Organizational Support & Continuity of Operations](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896493984)
      - 1.1.16.6.3.5  [Workforce Management](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896483312)
      - 1.1.16.6.3.6  [Leadership Development & Support Office](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896476432)
    - 1.1.16.6.4  [Business Development Office](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896458896)
      - 1.1.16.6.4.1  [Strategy](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896452384)
      - 1.1.16.6.4.2  [Oversight Liaison (includes TIGTA/GAO)](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896445744)
      - 1.1.16.6.4.3  [Research](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896427488)
      - 1.1.16.6.4.4  [Knowledge Management](https://www.irs.gov/irm/part1/irm_01-001-016#idm140388896416880)

# Part 1. Organization, Finance, and Management

# Chapter 1. Organization and Staffing

# Section 16. Small Business/Self-Employed Division

* * *

## 1.1.16 Small Business/Self-Employed Division

#### Manual Transmittal

April 07, 2025

#### Purpose

(1) This transmits revised IRM 1.1.16, Organization and Staffing, Small Business/Self-Employed Division.

#### Material Changes

(1) IRM 1.1.16 has been revised to reflect the current organizational structure of the SB/SE Division. The IRM was revised to update the division's functional statements since the last published IRM, dated 03/15/2022. Revisions to the functional statements are detailed below.

(2) IRM 1.1.16.1: Revised to reflect the SB/SE Division Commissioner and Deputy Commissioner.

(3) IRM 1.1.16.1(1): Revised to reflect Division Commissioner and Deputy Commissioner of SB/SE.

(4) IRM 1.1.16.1(3): Revised actions to accomplish mission.

(5) IRM 1.1.16.1(4) Revised Reports to information

(6) IRM 1.1.16.1(5): Updated link for the SB/SE Organizational Chart.

(7) IRM 1.1.16.2: Houses the Office of Fraud Enforcement (OFE) function. Revisions to the OFE functional statements are as follows:

1. IRM 1.1.16.2(2): Reports to Information changed to Deputy Commissioner, SB/SE.

2. IRM 1.1.16.2(3): Added Director, OFE.

3. IRM 1.1.16.2(4): Revised to include that Fraud Enforcement Policy Office, Fraud Enforcement Office Policy Office 2, and Fraud Enforcement Field Office report to the Director, OFE.

4. IRM 1.1.16.2(5): Revised actions to accomplish mission.

5. IRM 1.1.16.2(6): Deputy Director title revised to Program Manager and revised Reports to information.

6. IRM 1.1.16.2(7): Revised Reports to information.

7. IRM 1.1.16.2(8): Added structure for the FEA groups.


(8) IRM 1.1.16.3: Houses the Collection function. Revisions to the Collection functional statements are as follows:

01. IRM 1.1.16.3(2): Reports to Information changed to Deputy Commissioner, SB/SE .

02. IRM 1.1.16.3.1: Revised Mission Statement.

03. IRM 1.1.16.3.1(3): Revised action to accomplish mission.

04. IRM 1.1.16.3.1.1(1): Revised Mission Statement.

05. IRM 1.1.16.3.1.1(3): Program manager title revised to Field Compliance Managers/Territory Managers.

06. IRM 1.1.16.3.1.1(4): Program manager title revised to Field Compliance Managers/Territory Managers.

07. IRM 1.1.16.3.1.1.1(2): Program manager title revised to Field Compliance Manager/Territory Manager.

08. IRM 1.1.16.3.1.1.1(3): Program manager title revised to Field Compliance Manager/Territory Manager.

09. IRM 1.1.16.3.3(3): Revised action to accomplishment mission.

10. IRM 1.1.16.3.3.1(4): Added Program Manager, Oversight Coordination and Support Office.

11. IRM 1.1.16.3.3.1.1(3): Deleted Remittance processing and Passport certification.

12. IRM 1.1.16.3.3.1.2(3): Revised actions to accomplish mission.

13. IRM 1.1.16.3.3.1.3(1): Revised Mission Statement to include the programs that Campus Policy supports.

14. IRM 1.1.16.3.3.1.3(3): Revised action to accomplish mission.

15. IRM 1.1.16.3.3.1.4(3): Revised action to accomplish mission to provide clarity.

16. IRM 1.1.16.3.3.1.5(3) Revised action to accomplish mission to provide clarity.

17. IRM 1.1.16.3.3.1.6(1): Revised Mission Statement to include additional program responsibility.

18. IRM 1.1.16.3.3.1.6(3): Revised action to accomplish mission to provide clarity.

19. IRM 1.1.16.3.3.1.8(3): Revised action to accomplish mission to provide clarity.

20. IRM 1.1.16.3.3.1.9: Added Oversight Coordination and Support Office.

21. IRM 1.1.16.3.3.2.3(1): Revised Mission Statement to provide clarity.

22. IRM 1.1.16.3.3.2.7: Added Collection Innovation and Implementation Office.

23. IRM 1.1.16.3.4(2): Revised Reports to Information.

24. IRM 1.1.16.3.5(2): Revised Reports to Information.

25. IRM 1.1.16.3.6(3): Revised the names of the Territories.

26. IRM 1.1.16.3.6.1(3): Revised action to accomplish mission.


(9) IRM 1.1.16.4: Houses the Office of Promoter Investigations (OPI) function. Revisions to the OPI functional statements are as follows:

1. IRM 1.1.16.4(2): Reports to Information changed to Deputy Commissioner, SB/SE.

2. IRM 1.1.16.4(3): Revised action to accomplish mission.

3. IRM 1.1.16.4(4): Added Policy and Technical Support Teams 3,4 and 5.

4. IRM 1.1.16.4(5): Added Lead Development Center, Workload Selection 2.


(10) IRM 1.1.16.5: Houses the Examination function. Revisions to the Examination functional statements are as follows:

01. IRM 1.1.16.5(2): Reports to Information changed to Deputy Commissioner, SB/SE.

02. IRM 1.1.16.5(4): Revised to add Program Manager to the title and Program Manager, Examination Customer Coordination and Innovation Office.

03. IRM 1.1.16.5.1(2): Revised Reports to Information.

04. IRM 1.1.16.5.2(2): Revised Reports to Information.

05. IRM 1.1.16.5.3(2): Revised Reports to Information.

06. IRM 1.1.16.5.3.1(4): Revised Reports to Information.

07. IRM 1.1.16.5.3.2(4): Revised Reports to Information.

08. IRM 1.1.16.5.3.3(4): Revised Reports to Information.

09. IRM 1.1.16.5.5(2): Revised Reports to Information.

10. IRM 1.1.16.5.5.2(4): Revised Reports to Information.

11. IRM 1.1.16.5.5.2.5: Removed Excise Fuel Tax Policy.

12. IRM 1.1.16.5.5.3(4): Exam Case Selection- revised manager title reporting to Director, Exam Case Selection.

13. IRM 1.1.16.5.5.3.3: Changed title from Information Return Case Selection to Document Matching Analysis and Case Selection.

14. IRM 1.1.16.5.5.3.3(1): Revised Mission Statement to include Document Matching Analysis and Case Selection.

15. IRM 1.1.16.5.5.3.3(2): Revised Program Manager title to Document Matching Analysis and Case Selection.

16. IRM 1.1.16.5.5.3.3(3): Revised Program Manager title to Document Matching Analysis and Case Selection.

17. IRM 1.1.16.5.5.4(1): Revised Mission Statement.

18. IRM 1.1.16.5.5.4(3): Revised actions to accomplish mission.

19. IRM 1.1.16.5.5.4(4): Revised Reports to Information.

20. IRM 1.1.16.5.5.4.1: Changed title from Offshore and Entities Team to Technical Support Group 1.

21. IRM 1.1.16.5.5.4.1(1): Revised Mission Statement.

22. IRM 1.1.16.5.5.4.1(2): Revised Reports to Information.

23. IRM 1.1.16.5.5.4.1(3): Revised Program Manager title and actions to accomplish mission.

24. IRM 1.1.16.5.5.4.2: Revised title from Technical Legislative Implementation to Technical Support Group 2.

25. IRM 1.1.16.5.5.4.2(1): Revised Mission Statement.

26. IRM 1.1.16.5.5.4.2(2): Revised Program Manager title to Program Manager, Technical Support Group 2.

27. IRM 1.1.16.5.5.4.2(3): Revised Program Manager title and actions to accomplish mission.

28. IRM 1.1.16.5.5.4.3: Revised title to Technical Support Group 3.

29. IRM 1.1.16.5.5.4.3(1): Revised Mission Statement.

30. IRM 1.1.16.5.5.4.3(2): Revised Program Manager title to Program Manager, Technical Support Group 3.

31. IRM 1.1.16.5.5.4.3(3): Revised Program Manager title and actions to accomplish mission.

32. IRM 1.1.16.5.5.4.4: Added Technical Support Group 4.

33. IRM 1.1.16.5.5.4.6: Revised actions to accomplish mission.

34. IRM 1.1.16.5.6: Added Examination Customer Coordination and Innovation Office.


(11) IRM 1.1.16.6: Houses the Operations Support function. Revisions to the Operations Support functional statements are as follows:

01. IRM 1.1.16.6(2): Reports to Information changed to Deputy Commissioner, SB/SE.

02. IRM 1.1.16.6(4): Revised Reports to Information.

03. IRM 1.1.16.6.1(3): Revised Reports to Information.

04. IRM 1.1.16.6.1.2(3): Added Reports to Information.

05. IRM 1.1.16.6.1.3: Added Reports to Information.

06. IRM 1.1.16.6.1.5: Revised title to Report Generation Software Support & Correspondence Examination Automation Support.

07. IRM 1.1.16.6.1.5(1): Revised mission statement.

08. IRM 1.1.16.6.1.5(2): Revised Reports to Information.

09. IRM 1.1.16.6.1.5(3): Revised Reports to Information.

10. IRM 1.1.16.6.1.6: Revised Reports to Information.

11. IRM 1.1.16.6.1.7: Revised Reports to Information.

12. IRM 1.1.16.6.1.8: Added Business Modernization Support.

13. IRM 1.1.16.6.2(3): Revised actions to accomplish mission.

14. IRM 1.1.16.6.2(4): Revised Reports to Information.

15. IRM 1.1.16.6.2.1(1): Revised title to Workforce and Program Analysis.

16. IRM 1.1.16.6.2.1(2): Revised Reports to Information.

17. IRM 1.1.16.6.2.1(3): Revised Manager title and actions to accomplish mission.

18. IRM 1.1.16.6.2.1(4): Revised Reports to Information.

19. IRM 1.1.16.6.2.2: Revised title to Support Resources & Analysis.

20. IRM 1.1.16.6.2.2(1): Revised Mission Statement.

21. IRM 1.1.16.6.2.2(2): Revised Reports to Information.

22. IRM 1.1.16.6.2.2(3): Revised Program Manager title and actions to accomplish mission.

23. IRM 1.1.16.6.2.2(4) Revised Reports to Information.

24. IRM 1.1.16.6.2.3: Revised title to Budget and Contract Oversight.

25. IRM 1.1.16.6.2.3(1): Revised Mission Statement.

26. IRM 1.1.16.6.2.3(2): Revised Reports to Information.

27. IRM 1.1.16.6.2.3(3): Revised actions to accomplish mission.

28. IRM 1.1.16.6.2.3(4): Revised Reports to Information.

29. IRM 1.1.16.6.2.4(3): Revised action to accomplish mission.

30. IRM 1.1.16.6.2.5(3): Revised action to accomplish mission.

31. IRM 1.1.16.6.2.5(4): Revised Reports to Information.

32. IRM 1.1.16.6.3: Added SB/SE to the Director title.

33. IRM 1.1.16.6.3(1): Added SB/SE to the Director title.

34. IRM 1.1.16.6.3(2): Revised Reports to information.

35. IRM 1.1.16.6.3(3): Added SB/SE to the Director title.

36. IRM 1.1.16.6.3(4): Added SB/SE to the Director title.

37. IRM 1.1.16.6.3(5): Added SB/SE to the Director title.

38. IRM 1.1.16.6.3.1(2): Revised Reports to Information.

39. IRM 1.1.16.6.3.1(4): Added Collection Training Groups 4 and 5.

40. IRM 1.1.16.6.3.2(2): Revised Report to Information.

41. IRM 1.1.16.6.3.2(4): Revised Reports to Information.

42. IRM 1.1.16.6.3.3(2): Revised Reports to Information.

43. IRM 1.1.16.6.3.3(4): Added Examination Training Teams 4 and 5.

44. IRM 1.1.16.6.3.4(2): Revised Reports to Information.

45. IRM 1.1.16.6.3.4(4) Added Corporate Share Support.

46. IRM 1.1.16.6.3.5(2): Revised Reports to Information.

47. IRM 1.1.16.6.3.5(4): Added Hiring Support Team 4.

48. IRM 1.1.16.6.3.6(2): Revised Reports to Information.

49. IRM 1.1.16.6.3.6(4): Added LDSO Support Teams 1 and 2.

50. IRM 1.1.16.6.4(4): Revised Reports to Information.

51. IRM 1.1.16.6.4.1(2): Revised Manager title to Functional Chief.

52. IRM 1.1.16.6.4.1(3): Revised Manager title to Functional Chief.

53. IRM 1.1.16.6.4.1(4): Added Groups 1 and 2.

54. IRM 1.1.16.6.4.2(2): Revised Manager title to Function Chief.

55. IRM 1.1.16.6.4.2(3) Revised Manager title to Functional Chief.

56. IRM 1.1.16.6.4.2(4) Revised Manager title to Functional Chief.

57. IRM 1.1.16.6.4.2(5): Revised Manager title to Functional Chief.

58. IRM 1.1.16.6.4.2(6): Revised Reports to Information and added Audit Liaison.

59. IRM 1.1.16.6.4.3 (2): Revised Manager title to Functional Chief.

60. IRM 1.1.16.6.4.3(3): Revised Manager title to Functional Chief.

61. IRM 1.1.16.6.4.3(4): Revised Reports to information.

62. IRM 1.1.16.6.4.4: Added Knowledge Management.


(12) Editorial changes were made throughout the IRM to add clarity, update citations, and replace W&I with Taxpayer Services.

#### Effect on Other Documents

IRM 1.1.16 dated March 15, 2022, is superseded.

#### Audience

SB/SE Division

#### Effective Date

(04-07-2025)

Michelle Haines

Director, Human Capital Office

SB/SE Division

**1.1.16.1** **(04-07-2025)**

### The Small Business/Self Employed Division Commissioner and Deputy Commissioner

1. The Division Commissioner and Deputy Commissioner of Small Business and Self Employed (SB/SE) report to the Chief Tax Compliance Officer and are responsible for planning, managing, directing, leading, and executing nationwide activities for SB/SE.

2. SB/SE taxpayers are defined as individuals filing schedules for sole proprietor businesses, rental/flow-through income, farm income, and/or employee business expenses as well as all other businesses with assets under $10 million. The SB/SE division also has responsibility for estate, gift, fiduciary, excise, and most employment tax returns.

3. SB/SE processes and serves:



   - About 26.8 million employment tax returns

   - About 1.1 million excise tax return filers

   - About 250,000 gift tax filers

   - About 27,000 estate return filers


4. There are five SB/SE Operating Units that are direct reports:



   - Collection

   - Examination

   - Operations Support

   - Office of Fraud Enforcement

   - Office of Promoter Investigations


5. The organization chart that displays the new SB/SE structure can be viewed at: SBSE Org Chart. This IRM has been revised to reflect those changes to the functional statements for SB/SE. The IRM is available to all IRS employees.


**1.1.16.1.1** **(06-01-2016)**

#### Mission of the Small Business/Self Employed Division

1. The mission of the Small Business/Self Employed Division is to help small business and self-employed taxpayers understand and meet their tax obligations, while applying the tax law with integrity and fairness to all. The division is commonly referred to as SB/SE.

2. To accomplish its mission, the SB/SE Division:



01. Applies the Internal Revenue Code with integrity and fairness, while enforcing compliance through the examination of returns, collection of delinquent taxes, and the securing of delinquent tax returns.

02. Provides Servicewide coordination of policy and procedure concerning the administration of the penalty and interest programs to ensure consistent application of the law.

03. Strives to improve SB/SE taxpayer compliance through innovative initiatives to effectively reduce the underreporting, underpayment and non-filing tax gaps, with the goal that all SB/SE taxpayers pay their fair share.

04. Maintains a “customer first” focus by timely and accurately responding to SB/SE customer inquiries and by routinely conducting ongoing research programs that support the development of strategies which address SB/SE taxpayer needs.

05. Improves voluntary compliance by helping SB/SE taxpayers understand and meet their filing and payment responsibilities. Strategies include the use of outreach, seminars, workshops, websites, risk-based compliance strategies and plain language publications.

06. Provides strategic leadership by partnering with other federal agencies, financial institutions, tax preparers, community groups, trade organizations, state and local authorities, and others to provide one-stop multi-agency tax information, education services and assistance to SB/SE customers and practitioners.

07. Drives improvement in business practices and technology.

08. Provides technical advice and assistance to Service personnel regarding federal tax law and regulations affecting SB/SE customers.

09. Develops and implements SB/SE measures that balance customer satisfaction, employee satisfaction, and business results.

10. Provides a link across the IRS to ensure taxpayer burden reduction continues to be a priority and is incorporated within decision-making frameworks advocating for and being a liaison to external stakeholders.


3. This IRM section also contains the mission statements for all IRS operations located within the SB/SE division.


**1.1.16.2** **(04-07-2025)**

### Office of Fraud Enforcement (OFE)

1. The mission of the Office of Fraud Enforcement is to promote compliance through strengthening IRS response to fraud and mitigating emerging threats. This includes:



   - Improving fraud detection and development to address areas of high fraud/risk non-compliance

   - Cultivating internal and external partnerships to identify new treatment streams to enhance enforcement

   - Pursuing civil fraud penalties and recommending criminal cases that will lead to prosecutions where appropriate


2. The Director, Office of Fraud Enforcement, reports to the Deputy Commissioner, SB/SE.

3. To accomplish the mission, the Director, OFE:



   - Provides oversight and direction for fraud policy and operations Servicewide in coordination with impacted business operating divisions.

   - Assists in identifying indicators of fraud, developing enforcement recommendations and criminal fraud referrals to IRS Criminal Investigation, and pursuing civil fraud penalty assertions, and other treatment streams to improve filing and payment compliance with current and emerging issues, when appropriate.

   - Leverages partnerships with internal and external stakeholders to identify and develop leads related to fraud and other high risk non-compliance areas to be shared with the applicable Business Operating Division’s case selection function for consideration in the case selection process.

   - Collaborates with other operating divisions and functions to increase fraud awareness though outreach and education and to support fraud objectives.

   - Initiates and conducts research projects to identify emerging threats and high-risk areas of non-compliance through data analytics. Proposals for implementing a Campaign or Compliance Initiative Project are submitted to the applicable BOD case selection function for consideration.


4. The following program managers report to the Director, OFE:



   - Fraud Enforcement Policy Office

   - Fraud Enforcement Office Policy Office 2

   - Fraud Enforcement Field Office


5. The Fraud Enforcement Policy Office develops policies and procedures for security clearance and legislative and advocacy proposals for fraud mitigation strategies for the Emerging Threats and Data Analytics division. The Fraud Enforcement Front Office Policy Office 2 focuses on the traditional policy role of hiring, data, reporting, etc.

6. The following managers report to the Program Manager, Fraud Enforcement Policy Office:



   - Manager, Emerging Threats Mitigation Team

   - Manager, Emerging Threats Mitigation Team 2

   - Manager, Data Analytics Group

   - Manager, Data Analytics Group 2


7. The following managers report to the Program Manager, Fraud Enforcement Field Office:



   - Manager, Fraud Enforcement Advisor Group 1

   - Manager, Fraud Enforcement Advisor Group 2

   - Manager, Fraud Enforcement Advisor Group 3

   - Manager, Fraud Enforcement Advisor Group 4

   - Manager, Fraud Enforcement Advisor Group 5

   - Manager, Fraud Enforcement Advisor Group 6

   - Manager, Fraud Enforcement Advisor Group 7


8. The FEA groups are comprised of Revenue Agents and Revenue Officers


**1.1.16.3** **(04-07-2025)**

### Collection

1. The mission of Collection is to provide SB/SE taxpayers with top quality pre and post-filing services by helping them understand and comply with all applicable tax laws and by applying the tax laws with integrity and fairness.

2. The Director, Collection reports to the Deputy Commissioner, SB/SE.

3. To accomplish the mission, the Director, Collection:



01. Ensures that the Collection mission, principles and vision remain current and support the IRS mission.

02. Enforces filing & payment requirements of the Internal Revenue laws.

03. Collects payments on unpaid accounts, determines and analyzes why accounts become delinquent, prevents accounts from becoming delinquent, and secures delinquent returns.

04. Directs and oversees special projects and project initiatives.

05. Collaborates with Research to plan and conduct research studies related to Collection activities.

06. Improves business practices and technology in order to provide quality customer assistance.

07. Manages issues affecting compliance across Business Units (BU), works with other BUs to develop and implement consistent and fair treatment of all taxpayers.

08. Provides continuous oversight, coordination and supports the Area Operating Unit (OU) Directors within Collection by ensuring that the appropriate integrated mechanisms are in place to jointly implement and deliver programs, and to manage operations within Collection.

09. Is responsible for Collection’s Business Continuity Plan in the event of an emergency.

10. Facilitates Servicewide Collection training programs.

11. Facilitates IRS employee safety programs.


4. The following executives report to the Director, Collection:



   - Director, Field Collection

   - Director, Planning and Performance Analysis

   - Director, Headquarters Collection

   - Director, Campus Collection

   - Director, Specialty Collection-Offer in Compromise

   - Director, Specialty Collection-Insolvency


**1.1.16.3.1** **(04-07-2025)**

#### Field Collection

1. The mission of Field Collection is to provide SB/SE taxpayers in each Area with top quality pre and post-filing services by helping them understand and comply with all applicable tax laws and by applying the tax laws with integrity and fairness. Primary objectives include:



   - Taking necessary and applicable actions to appropriately and efficiently resolve Collection inventory.

   - Per established Collection IRM guidelines, selecting the highest priority work for potential assignment to ensure fairness in case selection,

   - Carrying out the duties, responsibilities, and activities of Field Collection with professionalism and courtesy to all taxpayers.

   - Providing employees with the tools, resources and training required to perform their jobs.


2. The Director, Field Collection reports to the Director, Collection.

3. To accomplish the mission, Director, Field Collection:



1. Plans, executes and monitors Field Collection activities across all of Field Collection nationwide.

2. Administers all federal tax laws concerning filing and payment compliance applicable to SB/SE and other assigned taxpayers.

3. Oversees IRS’ primary civil enforcement activities executed in the field and ensures the maintenance of an effective deterrent level of field presence in the community by Revenue Officers.

4. Ensures adherence to the Taxpayer Bill of Rights and consistency and fairness in the treatment of all taxpayers.

5. Ensures mission statement and priorities are delivered by completing operational reviews of subordinates and by requiring the completion of reviews by all levels of management in Field Collection.

6. Prepares operational business plans and allocates SB/SE resources based on data driven analysis to best serve our customers' needs.

7. Leads collaborative efforts and initiatives with the Department of Justice Tax Division, IRS Criminal Investigation, and IRS Counsel to encourage greater compliance by business and individual taxpayers.

8. Facilitates Servicewide Field Collection training programs.

9. Monitors and manages training and travel budgets.


4. The following executives report to the Director, Field Collection:



   - Area Director, North Atlantic

   - Area Director, Central

   - Area Director, South Atlantic

   - Area Director, Gulf States

   - Area Director, Southwest

   - Area Director, Northwest

   - Director, Civil Enforcement Advice & Support Operations


**1.1.16.3.1.1** **(04-07-2025)**

##### Field Collection Area

1. The mission of the Field Collection areas is to provide SB/SE taxpayers with top quality services by helping them understand and comply with all applicable tax laws and by applying the tax laws with integrity and fairness. Primary objectives include: Taking necessary and applicable actions to appropriately and efficiently resolve Collection inventory, per established Collection IRM guidelines selecting the highest priority work for potential assignment to ensure fairness in case selection, carrying out the duties, responsibilities, and activities of Field Collection with professionalism and courtesy to all taxpayers, and providing employees with the tools, resources and training required to perform their jobs.

2. To accomplish the mission, each Area Director, Field Collection:



01. Prepares operational business plans and allocates SB/SE resources to meet customer needs.

02. Oversees compliance and enforcement processes in Field Collection, with emphasis on payment requirements, delinquent return compliance and delinquent prevention and investigation processing.

03. Plans, executes and monitors Field Collection activities in their respective IRS field offices.

04. Administers all federal tax laws concerning filing and payment compliance applicable to SB/SE and other assigned taxpayers.

05. Coordinates market segment compliance strategies and alternative treatments to effectively leverage resources and to achieve optimum compliance results.

06. Ensures consistency in treatment of all taxpayers.

07. Serves as Director, Field Collection’s representative for Taxpayer Advocate matters and performs congressional and outside stakeholder liaison responsibilities within the Area.

08. Develops best practices and elevates them for analysis and possible nationwide implementation.

09. Assumes designated role in the Business Continuity Plan for the execution of emergency procedures and coordination with the Senior Commissioner’s Representative, Communications & Stakeholder Outreach (CSO), and other operating units in the event of an emergency.

10. Facilitates Servicewide Field Collection training programs.

11. Monitors and manages training and travel budgets.


3. The following managers report to the Area Directors, Field Collection: Field Compliance Managers/Territory Managers, Field Collection Territories.

4. The following managers report to the Field Compliance Managers/Territory Managers, Field Collection Territories: Supervisory Revenue Officers.


**1.1.16.3.1.1.1** **(04-07-2025)**

###### Field Collection Territories

1. The mission of Field Collection territories is to provide SB/SE taxpayers in each of the territories top quality services by helping them understand and comply with all applicable tax laws and by applying the tax laws with integrity and fairness.

2. Each Field Compliance Manager/Territory Manager reports to an Area Director, Field Collection.

3. To accomplish the mission, each Field Compliance Manager/Territory Manager, Field Collection:



1. Markets best practices. Identifies and resolves emerging compliance issues at the local level; develops and delivers mission-oriented services and strategies to improve customer service, consistency, and efficiency.

2. Conducts education and outreach with internal and external stakeholders.

3. Applies fair and equitable treatment for non-compliance with the tone and timing of interactions appropriate to the non-compliance of the taxpayer.

4. Provides technical advice to the Area Director, Field Collection in all facets of field collection activities; provides clarity on policies of the Internal Revenue Service and provides clear interpretation of federal laws and regulations.

5. Coordinates and controls territory collection activities to achieve uniform compliance with directives and effective utilization of personnel; ensures a smooth flow of information, directives, and intra-territory communications to provide for preparation and submission of statistical and administrative reports.

6. Facilitates Servicewide Field Collection training programs.

7. Facilitates IRS employee safety programs.


**1.1.16.3.1.2** **(11-16-2018)**

##### Director, Civil Enforcement Advice and Support Operations

1. The mission of Civil Enforcement Advice and Support Operations is to provide expert technical advice and support in a collaborative and efficient environment so Field Collection personnel may confidently employ complex enforcement techniques and to provide world class service to taxpayers to help resolve complex tax compliance issues/matters.

2. Civil Enforcement Advice and Support Operations is comprised of the Advisory and Property Appraisal and Liquidations Specialist Operations.

3. The Director, Civil Enforcement Advice and Support Operations, reports to the Director, Field Collection.


**1.1.16.3.1.2.1** **(11-16-2018)**

###### Advisory

1. The mission of Advisory is two-fold:



1. To provide technical guidance, review, and assistance to Field Collection on the most complex cases and actions they take and by helping them understand and comply with all applicable tax laws and policies.

2. To provide prompt and high-quality support to individuals and businesses on complex lien related issues so they can understand and comply with tax laws when their case is not assigned to any other Collection personnel.


2. The four Advisory territories report to the Director, Civil Enforcement Advice and Support Operations.

3. To accomplish the mission, the advisory territories:



1. Prepare operational plans and allocate field collection resources to meet customer needs.

2. Prepare procedures, assist Collection Policy in IRM instructions and provide technical guidance, advice and assistance for programs and activities, such as field collection enforcement activity, bankruptcy and insolvency casework and processing, collateral agreements and collection cash management and interest, jeopardy and termination assessments, collection waivers, estate and gift tax and liens.

3. Plan, execute and monitor Field Collection activities in their respective IRS field offices. Provide expert technical advice and assistance to Field Collection groups throughout the assigned area in lien priority issues, estate and gift tax issues, managing and monitoring all suit activity in the area, including coordination with Counsel.

4. Provide technical advice on field enforcement issues.

5. Coordinate with Collection Policy to develop compliance strategies that reflect local population characteristics, needs, and behavior patterns, with the aim of improving voluntary compliance and customer service.

6. Administer all federal tax laws concerning filing and payment compliance applicable to SB/SE and other assigned taxpayers. Coordinate market segment compliance strategies and alternative treatments to effectively leverage resources and to achieve optimum compliance results. Ensure consistency in treatment of all taxpayers.

7. Work with CSO to improve voluntary compliance by providing input to the design, development, and implementation of programs that assist SB/SE customers in understanding their tax responsibilities and complying with all tax laws.

8. Develop best practices and share with Collection Policy for analysis and possible nationwide implementation.

9. Establish applications and computer/automation support for liens, bankruptcies, trust fund recovery and other special programs.


**1.1.16.3.1.2.2** **(11-16-2018)**

###### Property Appraisal and Liquidation Specialist

1. The mission of the Property Appraisal & Liquidation Specialist (PALS) program is to assist field Revenue Officers in the appraisal of real, personal and intangible property for equity determinations on Collection cases. Additionally, the mission of the PALS program is to secure, market and sell (liquidate) seized, acquired, redeemed and judicially foreclosed real, personal and intangible property.

2. The PALS Program Manager, reports to the Director, Civil Enforcement Advice and Support Operations.

3. The PALS program consists of group managers that report to the PALS Program Manager. Each group consists of PALS employees along with support personnel.


**1.1.16.3.2** **(11-16-2018)**

#### Planning and Performance Analysis

1. The mission of Planning and Performance Analysis is to lead in the development of both enterprise-level and program-level Collection Plans and to deliver Collection management information reports.

2. The Director, Planning and Performance Analysis, reports to the Director, Collection and is responsible for the formation of all Collection work plans in conjunction with program owners and executives, management of the Collection Activity Reports system, and monitoring, management of the Collection Activity Reports system, and monitoring of performance indicators.

3. To accomplish the mission, the Director, Planning and Performance Analysis:



1. Coordinates program work plans across Collection stakeholders.

2. Develops the Enterprise Collection work plan.

3. Consolidates data on enterprise performance.

4. Coordinates and provides analysis and reports on indicators.


4. The following managers report to Director, Planning and Performance Analysis:



1. Manager, Enterprise Reports and Plans

2. Manager, Campus Reports and Plans

3. Manager, Collection Data Assurance and Specialty Reports and Plans

4. Manager, Field and Specialty (ADV & INS) Reports and Plans


**1.1.16.3.2.1** **(11-16-2018)**

##### Enterprise Reports and Plans

1. The mission of Enterprise Reports and Plans is to lead the development and subsequent monitoring of an enterprise-level Collection plan to help ensure delivery of the plan goals, and to support the Collection Program by reporting high level performance results required by internal and external stakeholders.

2. The Manager, Enterprise Reports and Plans, reports to the Director, Planning and Performance Analysis.

3. To accomplish their mission, the Manager, Enterprise Reports and Plans:



1. Coordinates the development of an enterprise-level work plan, covering all Collection programs, resources, and key performance metrics including coverage and efficiency;

2. Monitors and reports on the enterprise-level work plan; provides governance and analytical support to Collection program staff;

3. Coordinates the creation, analysis and publication of several enterprise-level reports for internal and external use; including the Business Level Measures (BLM) / Oversight Board (OSB) and Treasury Target Submission Templates and

4. Facilitates and communicates general trend analysis to explain program performance and enterprise impacts.


**1.1.16.3.2.2** **(11-16-2018)**

##### Campus Reports and Plans

1. The mission of Campus Reports and Plans is to assist in developing Campus Collection work plans for the ACS, ACS Support, Centralized Case Processing (CCP) and Compliance Services Collection Operations (CSCO). They also monitor progress toward operation work plan goals and provide ongoing analysis to identify potential risks to work plan delivery.

2. The Manager, Campus Reports and Plans, reports to the Director, Planning and Performance Analysis.

3. To accomplish their mission, the Manager Campus Reports and Plans:



1. Provides historical data to create work plans;

2. Assists with development of Campus Collection and CCP work plans covering certain programs, resources, and key performance metrics;

3. Collaborates with necessary Collection staff to develop and consolidate other Campus work plans;

4. Monitors and reports on Campus Collection and CCP work plans; provides governance and analytical support to Collection program staff;

5. Supports Collection by delivering accurate performance reports and data to key Collection executives, analysts, and supervisors;

6. Creates, analyzes, and publishes site and program level reports for internal use

7. Supports and conducts Campus program trend analysis to explain program performance and enterprise impacts; and

8. Controls the issuance of new OFP codes to the Campus Collection Operations to be used for inventory management.


**1.1.16.3.2.3** **(04-07-2025)**

##### Collection Data Assurance and Specialty Reports and Plans

1. The mission of Collection Data Assurance & Specialty Reports and Plans is to ensure the integrity of data used to prepare reports; to provide excellent customer service, to create, analyze, distribute, and monitor access to reports and handle ad hoc information/data requests. They also assist with the development of work plans for the Specialty Collection Offer in Compromise and Specialty Collection Insolvency functions.

2. The Manager, Collection Data Assurance & Specialty Reports and Plans, reports to the Director, Planning and Performance Analysis.

3. To accomplish their mission, the Manager, Collection Data Assurance & Specialty Reports and Plans:



01. Provides excellent customer service by delivering critical decision-making information to executives and employees of Collection functions, TAS and TIGTA/GAO Audit Program, as well as, providing education and support, where appropriate

02. Supports Collection by delivering accurate performance reports and data to Collection executives, analysts, and supervisors for time-appropriate decision making

03. Ensures integrity of data used to prepare reports

04. Provides subject matter expertise in the program areas of: Collection Time Reporting System (CTRS); Business Objects, Collection Activity Reports (CAR), TSIGNs, and TDI Closing Codes

05. Responds to ad hoc requests from TIGTA, GAO, FOIA requests, media releases, the IRS Oversight Board, IRS Commissioner and for testimony and reports to Congress

06. Provides clear and timely documentation while coordinating procedural guidelines and policies for IRM 5.2.1, Collection Time Reporting System (CTRS) and IRM 5.2.4, Collection Reports.

07. Maintains the Collection Activity Reports (CAR), which are based on IDRS and Master File data

08. Controls and maintains the following for Servicewide Collection: TSIGNS (aka collection assignment numbers), TDI closing codes, Installment Agreement (IA) Originator codes, as well as, control and assignment of Designated Payment Codes (DPC)

09. Builds data bases and spreadsheets to maximize resources

10. Automates and streamlines the report process on a continuous cycle


**1.1.16.3.2.4** **(04-07-2025)**

##### Field and Specialty (INS) Reports and Plans

1. The mission of Field & Specialty Reports and Plans is to develop work plans for Field Collection (FC) (National and Areas), Civil Enforcement Advice and Support Operations (CEASO), Specialty Collection Insolvency (SCI) and Specialty Collection Officer in Compromise (SCOIC); produce and deliver National and Area Field Collection management information reports; and to track and analyze FC, CEASO, SCI and SCOIC progress in meeting targets.

2. The Manager, Field & Specialty Reports and Plans, reports to the Director, Planning & Performance Analysis.

3. To accomplish their mission, the Manager, Field & Specialty Reports and Plans:



01. Provides excellent customer service by delivering critical decision-making information to executives and employees of Collection Functions, TAS and TIGTA/GAO Audit Program, as well as, providing education and support, where appropriate;

02. Supports Collection by delivering accurate performance reports and data to key Collection executives, analysts, and supervisors;

03. Ensures integrity of data used to prepare reports;

04. Collaborates with Field Collection, CEASO, SCI, and SCOIC staff to develop annual work plans;

05. Creates, analyzes, and distributes reports for Field Collection, CEASO, SCI and SCOIC programs;

06. Responds to ad hoc requests from TIGTA, GAO, FOIA request, media release, IRS Oversight Board, IRS Commissioner and for testimony and reports to Congress;

07. Provides a multitude of high-level reports which monitor and analyze National and Area Field Collection, CEASO, SCI, and SCOIC performance improvement projects;

08. Monitors and reports on Field Collection, CEASO, SCI and SCOIC performance indicators;

09. Builds databases and spreadsheets to maximize resources; and

10. Automates and streamlines the report process on a continuous cycle.


**1.1.16.3.2.5** **(11-16-2018)**

##### Private Debt Collection Operations

1. The mission of Private Debt Collection Operations is to provide business input on program-related activities of the Private Debt Collection initiative.

2. The Manager, Private Debt Collection Operations, reports to the Director, Planning & Performance Analysis.

3. To accomplish their mission, the Manager, Private Debt Collection Operations:



01. Handles all workload and policy issues as cases are released to the Private Collection Agencies (PCAs);

02. Coordinates with Information Technology (IT) to address technology needs, monitor system performance and to develop and update documentation;

03. Creates and maintains Private Debt Collection policy guides;

04. Creates and maintains Private Debt Collection training materials;

05. Oversees all Contracting Officer Representative (COR) activities for the Private Debt Collection initiative;

06. Oversees and monitors the compliance status of all PCAs;

07. Conducts remote and onsite reviews of PCAs to ensure quality and compliance with contracts;

08. Manages PCA contract administration and serves as a liaison to Privacy, Government Liaison & Disclosure (PGLD);

09. Coordinates with the operating units (including ACS, Accounts Management, etc.) to address complex case questions; and

10. Performs internal quality reviews of IRS Private Debt Collection systems and actions.


**1.1.16.3.3** **(04-07-2025)**

#### Headquarters Collection

1. The mission of Headquarters Collection is to provide corporate-wide guidance, coordination, and support on all aspects of the collection process. Headquarters Collection uses data driven technology and strategies to deliver collection cases that will improve voluntary compliance, increase revenue, and improve productivity.

2. The Director of Headquarters Collection, reports to the Director, Collection.

3. To accomplish the mission, the Director of Headquarters Collection:




| HQ Collection Responsibilities |
| --- |
| Examines current Collection policies and procedures to identify processes that can be simplified and streamlined. |
| Directs and oversees special projects and initiatives. |
| Coordinates market segment compliance strategies and alternative treatments to effectively leverage resources and to achieve optimum compliance results. |
| Oversees program coordination for Field Collection. |
| Develops and coordinates strategies to apply appropriate treatment for non-compliance. |
| Identifies trends and develops strategies designed to address the needs of SB/SE taxpayers through a comprehensive approach to include education, outreach and enforcement. |
| Plans, develops and implements programs, guidelines, procedures and IRM instructions, as well as provides technical guidance and assistance for Field Collection and Campus programs. |
| Provides input to the SB/SE Division Commissioner, Deputy Commissioner, and the CFO for resource planning and budget formulation and execution. |
| Plans, designs, implements and maintains management information systems or inventory selection systems. |
| Provides standard policy and program direction for selection of cases and delivery of inventory for Collection. |
| Sets direct assignment criteria for priority and routing of work. |
| Provides Embedded Quality (EQ) data and analysis to internal and external stakeholders on a regular basis. |
| Develops annual National Quality Review System (NQRS) sampling plan. |
| Provides user support for IDRS security administration. |

4. The following directors report to the Director, Headquarters Collection:



   - Director, Collection Policy

   - Director, Collection Inventory Delivery & Selection

   - Director, Collection Quality & Technical Support


**1.1.16.3.3.1** **(04-07-2025)**

##### Collection Policy

1. Collection Policy designs strategic Servicewide guidance that is accurate, consistent, and timely. Through stakeholder collaboration these blueprints guide our workforce in accomplishing the IRS mission.

2. The Director, Collection Policy, reports to the Director, Headquarters Collection and is responsible for leadership in the design, development, and delivery of policies, which impact Field Collection and Campus programs.

3. To accomplish the mission, the Director, Collection Policy:




| Collection Policy Responsibilities |
| --- |
| Oversees program coordination for Field Collection and Campus programs. |
| Documents and coordinates procedural guidelines and policies. |
| Develops and delivers mission-oriented services and strategies. |
| Identifies and resolves emerging issues, and actively improves processes with a keen focus on customer service. |
| Develops and coordinates strategies to apply appropriate treatment for non-compliance. |
| Communicates new or revised policies and their impact on field and campus operations. |
| Identifies emerging business practices, tax issues, customer behavior, and potential areas of non-compliance. |
| Provides input to the SB/SE Division Strategic Plan. |
| Coordinates with other operating divisions as well as other SB/SE functional units to provide support and guidance. |
| Identifies trends and develops strategies designed to address the needs of SB/SE taxpayers through a comprehensive approach to include education, outreach, and enforcement. |
| Coordinates with Chief Counsel to review interpretive guidance including revenue procedures, initiates requests for counsel opinions, and initiates policy changes to improve tax compliance. |
| Plans, develops, and implements programs, guidelines, procedures, and IRM instructions, as well as provides technical guidance and assistance for Field Collection and Campus programs. |
| Reviews legislation to determine the impact on Collection. |
| Develops and recommends new legislative changes. |

4. The following managers report to the Director, Collection Policy:



   - Program Manager, Global Strategic Compliance

   - Program Manager, Enforcement

   - Program Manager, Campus Policy

   - Program Manager, Offers In Compromise

   - Program Manager, Employment Tax Policy

   - Program Manager, Insolvency

   - Program Manager, Case Resolution Alternatives

   - Program Manager, Campus Operations

   - Program Manager, Oversight Coordination and Support Office


**1.1.16.3.3.1.1** **(04-07-2025)**

###### Global Strategic Compliance

1. The mission of Global Strategic Compliance is to provide Servicewide policy guidance on certain specialty collection case types.

2. The Program Manager, Global Strategic Compliance, reports to the Director, Collection Policy.

3. To accomplish the mission, the program manager, Global Strategic Compliance:



1. Designs and provides content for training related to these programs.

2. Develops and coordinates policy and procedural guidance by conducting relevant program reviews.

3. Interacts with appropriate stakeholders to ensure the Servicewide collection perspective is considered when policy guidance is developed.

4. Ensures Servicewide collection policy, programs and workload priorities are coordinated and consistent across organizational boundaries.

5. Participates in external stakeholder activities to include GAO and TIGTA audits and MSPs.

6. Evaluates recommendations and develops policies and strategies to address stakeholder concerns.

7. Develops policy for the following collection programs and their related sub programs:




      | Collection Programs |
      | --- |
      | Abusive Tax Avoidance Transactions (ATAT) |
      | International Collection |
      | Collection fraud referrals |
      | Whistleblower |
      | Group manager handbook (Field Collection) |
      | Federal tax checks |
      | Miscellaneous collection procedures |
      | Cases requiring special handling |
      | Petition for remittance |
      | Offshore voluntary disclosure initiatives |
      | Frivolous tax arguments |
      | Disaster Guidelines (Field Collection) |
      | Remittance processing (Field Collection) |
      | Courtesy investigations (Field Collection) |
      | Disclosure (Field Collection) |
      | Taxpayer representation (Field Collection) |
      | Safety, security and control (Field Collection) |
      | Decedent estates and estates taxes |


**1.1.16.3.3.1.2** **(04-07-2025)**

###### Enforcement

1. The mission of Enforcement is to provide Servicewide policy guidance on collection and enforcement processes.

2. The Program Manager, Enforcement, reports to the Director, Collection Policy.

3. To accomplish the mission, the Program Manager, Enforcement:



1. Oversees the development and delivery of policy and procedural guidance for a variety of Field Collection, Campus Collection, and Servicewide programs, to include: Notice of Levy (Campus and Field Collection, Notices of Federal Tax Liens (NFTLs) and lien certificates, suits by and against the government (Field Collection and Advisory)), seizure and sale (Servicewide), summons (Servicewide) and third party contacts.

2. Develops and coordinates policy and procedural guidance by conducting relevant program reviews.

3. Develops training for various collection procedures and processes.

4. Ensures that the field and campus perspectives are considered when policy guidance is developed through interaction with appropriate field collection and campus contacts.

5. Collaborates to ensure field collection policy, programs including Campus functions, and workload priorities are consistently coordinated across organizational boundaries.

6. Participates in external stakeholder activities to include GAO and TIGTA audits, DOJ and Counsel concerns, and MSPs.

7. Evaluates recommendations and develops policies and strategies to address stakeholder concerns.


**1.1.16.3.3.1.3** **(04-07-2025)**

###### Campus Policy

1. The mission of Campus Policy is to provide Servicewide collection policy guidance for the following programs:



   - Automated Collection System Support (ACSS)

   - Adjustments (Field Collection)

   - Centralized Case Processing (CCP)

   - Centralized Lien Operations (CLO)

   - Collection Due Process and Collection Appeals Program (Campus and Field Collection)

   - eGuides


2. The Program Manager, Campus Policy, reports to the Director, Collection Policy.

3. To accomplish the mission, the Program Manager, Campus Policy:



1. Provides policy guidance and advice on complex, technical issues.

2. Coordinates with Campuses to implement established policies.

3. Develops and coordinates policy and procedural guidance by conducting relevant program reviews.

4. Interacts with appropriate stakeholders to ensure the Servicewide collection perspective is considered when policy guidance is developed.

5. Ensures Servicewide collection policy, programs and workload priorities are coordinated and consistent across organizational boundaries.

6. Participates in external stakeholder activities to include GAO and TIGTA audits and MSPs.

7. Evaluates recommendations and develops policies and strategies to address stakeholder concerns.


**1.1.16.3.3.1.4** **(04-07-2025)**

###### Offer in Compromise

1. The mission of Offer in Compromise is to provide Servicewide policy guidance on Offers in Compromise (OIC) and Allowable Living Expense (ALE) standards

2. The Program Manager for Offers in Compromise, reports to the Director, Collection Policy.

3. To accomplish the mission, the Program Manager, Offers in Compromise (OIC):




| Offer in Compromise Responsibilities |
| --- |
| Develops and delivers mission-oriented services and strategies to improve customer service, consistency, and efficiency |
| Conducts outreach with internal and external stakeholders. |
| Provides technical advice to the Director, Specialty Collection OIC in all facets of OIC activities, provides technical advice to the Director, Field Collection, provides clarity on policies of the Internal Revenue Service and provides clear interpretation of federal laws and regulations. |
| Coordinates effective use of personnel and ensures smooth flow of information, directions and intra-territory communication. |
| Coordinates policy implementation for Revenue Officer taxpayer contact and Field Collection financial analysis. |
| Designs and provides content for training related to OIC. |
| Oversees and assesses OIC policy related to taxpayer compliance and behavior. |
| Develops and coordinates OIC policy and procedural guidance by conducting relevant program reviews. |
| Develops policy and procedures for Allowable Living Expenses (ALE). |
| Participates in external stakeholder activities to include GAO and TIGTA audits and MSPs. |
| Evaluates recommendations and develops policies and strategies to address stakeholder concerns. |


**1.1.16.3.3.1.5** **(04-07-2025)**

###### Employment Tax Policy

1. The mission of Employment Tax Policy is to provide Servicewide policy guidance on the collection of employment taxes.

2. The Program Manager, Employment Tax, reports to the Director, Collection Policy.

3. To accomplish the mission, the Program Manager, Employment Tax:



1. Develops and coordinates policy and procedural guidance by conducting relevant program and operational reviews.

2. Conducts outreach with internal and external stakeholders to ensure the Servicewide collection perspective is considered when policy guidance is developed.

3. Ensures Servicewide collection policy, programs, and workload priorities are coordinated and consistent across organizational boundaries.

4. Participates in external stakeholder activities to include GAO and TIGTA audits and MSPs.

5. Evaluates recommendations and develops policies and strategies to address stakeholder concerns.

6. Oversees development of policies and procedures related to the collection of employment tax, which includes the design and content of training for the following programs:




      | Employment Tax Programs |
      | --- |
      | Trust Fund Recovery Penalty (TFRP) (Campus and Field Collection) |
      | Federal Tax Deposit (FTD) Alerts |
      | Third party payer (TPP) arrangements (which include payroll service providers (PSPs), reporting agents (RA’s) and professional employer organizations (PEOs) |
      | COVID-19 employer tax credits and social security tax deferrals |
      | Limited liability companies (LLCs) |
      | In-business repeater and pyramiding taxpayers |
      | Disqualified employment tax levy (DETL) procedures |
      | Restitution-based assessments (Campus and Field) |
      | IRC section 965 liabilities |
      | Bipartisan Budget Act of 2015 collection tax underpayments from partnerships/partners |
      | Government agencies and federal employees |


**1.1.16.3.3.1.6** **(04-07-2025)**

###### Insolvency

1. The mission of Insolvency is to provide Servicewide policy guidance on insolvency and bankruptcy related procedures, provide support to both internal and external customers with insolvency related automation and programs, and develop and implement Servicewide policy and strategy for bankruptcy topics. In addition, this group develops, designs, and delivers service-wide policy guidance on passport related procedures and topics.

2. The Program Manager, Insolvency, reports to the Director, Collection Policy.

3. To accomplish the mission, the Program Manager, Insolvency:



1. Enables IRS to participate as a creditor and keep IRS in compliance with requirements of bankruptcy code.

2. Reviews legislation to determine the impact on insolvency, bankruptcy and passport programs, and develops and recommends new legislative changes.

3. Develops and coordinates application and understanding of the insolvency, bankruptcy, and passport processes.

4. Develops and coordinates insolvency and passport policy and procedural guidance by conducting relevant program reviews.

5. Develops training and analytical techniques to support the insolvency, bankruptcy, and passport processes.

6. Provides policy guidance and advice on complex, technical programs related to insolvency, bankruptcy, and passport.

7. Employs Automated Insolvency System, Automated Proof of Claim and other software programs to develop new reports and other documents for program management.


**1.1.16.3.3.1.7** **(04-07-2025)**

###### Case Resolution Alternatives

1. The mission of Case Resolution Alternatives is to provide Servicewide policy guidance on alternative collection case resolution processes.

2. The Program Manager, Case Resolution Alternatives, reports to the Director, Collection Policy.

3. To accomplish the mission, the Program Manager, Case Resolution Alternatives:



1. Coordinates policy implementation for alternative case resolution procedures.

2. Develops policy for financial analysis, Installment Agreements and Currently Not Collectable (CNC) accounts.

3. Designs and provides content for training related to these programs.

4. Oversees and assesses case resolution policy related to taxpayer compliance.


**1.1.16.3.3.1.8** **(04-07-2025)**

###### Campus Operations

1. The mission of Campus Operations (CO) is to provide guidance, administration, coordination and oversight for all Campus Collection customers related to our organization’s operational, technical and quality needs.

2. The Campus Operations Program Manager, reports to the Director, Collection Policy.

3. To accomplish the mission, the Program Manager, Campus Operations:




| Campus Operations Responsibilities |
| --- |
| Works with Planning & Performance Analysis and Campus Nonfiler Support teams to coordinate the CSCO Balance Due and Nonfiler work planning, monitoring, and program delivery. |
| Works with Joint Operations Center (JOC) and Campus Nonfiler Support to establish and monitor phone schedules for ASFR, A6020(b), Refund Hold and Withholding Compliance (WHC). |
| Works closely with Campus Collection directorships and operations in each campus as primary contact and support for CSCO Balance Due programs which includes responding to program, inventory and resource issues and participating in regular Campus Collection calls to discuss volumes, quality, rates, overage and average days in inventory. |
| Works with the Product Line Analysts (PLA) for CSCO, ASFR and their related product lines. |
| Works with all applicable CSCO program IRM authors to establish or update procedures. |
| Monitors campus balance due inventory. |
| Distributes corporate GII exceptions. |
| Works with AMS staff and programmers for changes or updates to CSCO Balance Due underreporting via Maintenance Update Request (MUR) or Unified Work Request (UWR). |
| Coordinates with Planning & Performance Analysis and Campus Nonfiler Support teams to develop and implement the CSCO Balance Due campus work plans. |
| Provides guidance on technical issues, conducts program reviews, and monitors workloads to ensure processing goals are met. |
| Coordinates with the CFO office and tax exempt federal, state and local organizations on complex, technical issues concerning government agency issues/concerns. |
| Program areas include federal contractor compliance program, Federal Agency Delinquency (FAD) and state and local government compliance programs, manual refunds, including duplicate manual refunds (DMER) and erroneous refund (ERRF), combat zone, hostages and wrongful detainees, and CSCO balance due program. |
| Participates in GAO and TIGTA audits and evaluates recommendations and employee suggestions concerning campus operations procedural changes for the Collection program areas listed above. |


**1.1.16.3.3.1.9** **(04-07-2025)**

###### Oversight Coordination and Support Office

1. The mission of the Oversight Coordination and Support Office is to ensure that SB/SE Collection is responsive to all GAO and TIGTA audits, and coordinates between functional offices and across BODs as needed. This office also supports, coordinates and tracks all SB/SE Collection efforts in addressing matters of oversight, quality assurance, internal control and risk.

2. The Program Manager, Oversight Coordination and Support Office, reports to the Director, Collection Policy.

3. To accomplish the mission, the Program Manager, Oversight Coordination and Support Office:



1. Reviews GAO and TIGTA audits received from the Office of Audit Coordination (OAC) to determine appropriate SB/SE Collection involvement and ownership within SB/SE Collection functions.

2. Supports the SB/SE Collection functional audit owners to ensure audit responses are complete, timely and accurate.

3. Assists the functional units with writing appropriate responses to audit reports including appropriate corrective action responses to the audit recommendations.

4. Tracks all SB/SE Collection planned corrective actions (PCAs), ensuring timely and accurate completion.

5. Serves as the functional liaison for matters relating to the Taxpayer Advocate Service including the National Taxpayer Advocate’s Annual Reports and Most Serious Problems.

6. Serves as the functional liaison for legislative implementation and development of Collection legislative proposals and request for published guidance.

7. Facilitates Collection’s interactions with the International Debt Management Committee and the Tax Debt Management Network.


**1.1.16.3.3.2** **(04-07-2025)**

##### Collection Inventory Delivery and Selection

1. The mission of the office of Collection Inventory Delivery & Selection (CIDS) is to use technology and strategies to select and route collection cases for efficient and effective resolution, oversee programs, policy, and systems for various aspects of Collection, provide end user tools to help manage and process cases, all in an effort to improve productivity, increase revenue, and improve taxpayer voluntary compliance.

2. The Director, Collection Inventory Delivery & Selection, reports to the Director, Headquarters Collection.

3. To accomplish the mission, the Director, Collection Inventory Delivery & Selection:



1. Maintains an ongoing quantitative review program of field and campus operations at the national, field area and field territory level to evaluate programs and provide assistance.

2. Develops input data for the Commissioner’s Quarterly Business Performance Review (QBPR) and quarterly presentations to the IRS Oversight Board.

3. Provides input to the Commissioner, SB/SE Collection and the CFO for resource planning and budget formulation and execution.

4. Coordinates with the office of Collection Technology Solutions and Information Technology (IT) to develop and maintain automated systems support.

5. Provides standard policy and program direction for selection of cases and delivery of inventory for Collection.

6. Sets direct assignment criteria for priority and routing of work.

7. Plans, designs, and maintains management information systems or inventory selection systems from:




      | Management Information and Inventory Selection Systems |
      | --- |
      | Master file |
      | Integrated Data Retrieval System (IDRS) |
      | Automated Lien System (ALS) |
      | Inventory Delivery System (IDS) |
      | Automated Collection System (ACS) |
      | Integrated Collection System (ICS) |
      | Entity |
      | Automated Substitute for Return (ASFR) |
      | Automated 6020(b) |


4. The following managers report to the Director, Collection Inventory Delivery & Selection:



   - Program Manager, Nonfiler Inventory and Analysis (NIA)

   - Program Manager, Strategic Analysis and Modeling (SAM)

   - Program Manager, Collection Case Delivery(CCD)

   - Program Manager, Automated Programs (AP)

   - Program Manager, Collection Analytics, Routing and Selection (CARS)

   - Program Manager, ACS Systems & Inventory

   - Program Manager, Collection Innovation and Implementation Office


**1.1.16.3.3.2.1** **(04-07-2025)**

###### Nonfiler Inventory and Analysis

1. The mission of Nonfiler Inventory and Analysis (NIA) is to provide Servicewide policy guidance on SB/SE and Taxpayer Services delinquent taxpayers, Nonfiler TDI return delinquency case selection, and inventory analysis on processes related to Campus Return Delinquency programs and inventories for taxpayers who are delinquent in filing tax returns. Develop and implement program policies, strategies and objectives on return delinquency programs. Provide analysis through various reports to the Director, Collection Inventory Delivery & Selection.

2. The Program Manager, NIA, reports to the Director, Collection Inventory Delivery & Selection.

3. To accomplish the mission, the Program Manager, NIA:



1. Oversees program coordination for automated nonfiler system and Campus procedures related to Compliance nonfiler programs.

2. Provides continuous oversight and coordination of policy and inventory analysis for the Servicewide Collection return delinquency programs and processes, to include ASFR and A6020(b) and the Withholding Compliance Program (WHC).

3. Identifies trends and develops strategies designed to address the needs of SB/SE and Taxpayer Services delinquent taxpayers through a comprehensive approach to include education, outreach and enforcement.

4. Develops policy and manages selection of delinquent returns for Compliance functions.

5. Develops processes and analysis to identify delinquent filers.

6. Reviews and analyzes program progress against enterprise plans and identifies areas for improvement.

7. Provides input to the SB/SE Collection Strategic Plan.


4. The Manager, Campus Nonfiler Support (CNS) reports to the Program Manager, NIA.


**1.1.16.3.3.2.1.1** **(11-16-2018)**

###### Campus Nonfiler Support

1. The mission of Campus Nonfiler Support (CNS) is to oversee and facilitate Campus procedures related to nonfiler programs as well as to provide support to Campus return delinquency programs. CNS provides oversight and coordination of programs for taxpayers who are delinquent in filing tax returns including IMF and BMF return delinquency, delinquent return refund hold, ASFR, and A6020(b). Additionally, CNS supports the Campus components of the withholding compliance and nonfiler backup withholding programs.

2. The Manager, Campus Nonfiler Support (CNS), reports to the Program Manager, Nonfiler Inventory and Analysis (NIA).

3. To accomplish the mission, the Manager CNS:



   - Supports NIA with overall Collection filing compliance programs.

   - Provides Campus policy for delinquent return programs.

   - Conducts Campus reviews on nonfiler programs.

   - Oversees IRMs, notices and letters on nonfiler programs.

   - Responds to employee suggestions and SERP feedback on nonfiler programs.

   - Oversees Campus Collection clerical procedures.

   - Provides program oversight and coordination for Campus policies, procedures and guidelines.

   - Develops processes to identify delinquent filers.

   - Identifies trends and develops strategies to address delinquent taxpayers.

   - Reviews and analyzes program progress against enterprise plans and identifies areas for improvement.

   - Provides input to the SB/SE Collection strategic plan.


**1.1.16.3.3.2.2** **(04-07-2025)**

###### Strategic Analysis and Modeling

1. The mission of Strategic Analysis and Modeling (SAM) is to provide Servicewide statistical analysis of collection data, evaluate the performance of the collection predictive models and develop new models, create and implement a data strategy in collaboration with Compliance Data Warehouse to enhance collection data available for research.

2. The Program Manager, SAM, reports to the Director, Collection Inventory Delivery & Selection.

3. To accomplish the mission, the Program Manager, SAM:



1. Provides ongoing performance evaluation and refinement of predictive models in the IDS.

2. Designs, implements and evaluates new collection models and tools to support enhanced taxpayer compliance.

3. Assists the nonfiler program to develop and enhance workload selection tools.

4. Provides analysis to directors to enable them to make data-driven decisions.

5. Evaluates Servicewide Collection programs and develops, tests and enhances case routing and assignment strategies.

6. Assists in the development and implementation of a collection workload optimization program.

7. Supports existing Servicewide Collection data warehouses to enable analysis and data driven decisions.

8. Actively looks for new methodologies and technologies in risk management and decision analytics to improve organization performance.


**1.1.16.3.3.2.3** **(04-07-2025)**

###### Collection Case Delivery

1. The mission of Collection Case Delivery (CCD) is to provide standard program direction for delivery of inventory for collection, set direct assignment criteria to route and deliver collection work, and provide user friendly computer applications to Collection. Our primary objectives include developing, deploying and monitoring the systemic delivery and prioritization of collection inventory to ensure proper alignment with current business priorities, guaranteeing inventory and case related information are available, and promoting fairness of case selection in Field Collection by incorporating data driven methods to prioritize inventory. Further, CCD ensures timely and accurate lien information, provides customer service and support for the Entity Case Management System (ENTITY), Automated Lien System (ALS), and Integrated Collection System (ICS) and coordinates with other programs to provide policy guidance that ensures overall business objectives are met.

2. The Program Manager, CCD, reports to the Director, Collection Inventory Delivery & Selection.

3. To accomplish the mission, the Program Manager, CCD:



1. Supplies cases based on consistent risk scoring/priority selection criteria.

2. Partners with IT to display inventory and case related information.

3. Implements assignment criteria for routing of collection work, and monitors workload as it pertains to the assignment of collection cases.

4. Maintains and supports the ALS/ENTITY and ICS systems.

5. Coordinates and supports ongoing maintenance and end-user needs with Technology Solutions (TS), IT and other developers for ALS/ENTITY and ICS.

6. Documents and coordinates procedural guidelines and policies for ALS/ENTITY and ICS.

7. Assists in the development and delivery of training for ALS/ENTITY and ICS.

8. Supports various collection initiatives through the development and delivery of inventory related queries and reports to provide customers with analytical data to inform recommendations and enable educated decisions.


4. The Manager, Automated Lien and ENTITY Customer Support (ALECS) reports to the Program Manager, CCD.


**1.1.16.3.3.2.3.1** **(04-07-2025)**

###### Automated Lien and ENTITY Customer Support

1. The mission of Automated Lien and ENTITY Customer Support (ALECS) is to provide complete customer support for the Automated Lien System (ALS) and ENTITY Case Management System (ENTITY), ensuring that our customers have the tools necessary to improve productivity and meet all legal requirements for lien filings while promoting efficient delivery and management of collection inventory.

2. The Manager, Automated Lien and ENTITY Customer Support group (ALECS), reports to the Program Manager, Collection Case Delivery (CCD).

3. To accomplish the mission, the Manager, ALECS:



1. Ensures that all system user guides and related documentation are maintained, current and accurate.

2. Ensures timely and effective development and delivery of ALS and ENTITY related training material and customer outreach.

3. Ensures prompt and accurate resolution of help tickets via the Entity help desk and the Automated Lien System (ALS) inbox.

4. Maintains and enhances the ALS and Entity SharePoint sites to ensure users have access to the latest ALS and ENTITY related documentation.

5. Coordinates programming changes and enhancements with Technology Solutions.

6. Ensures timely and effective testing of all application programming changes and enhancements prior to release.

7. Provides timely assistance to Field Collection administrative professional staff to ensure timely end of month processing.


**1.1.16.3.3.2.4** **(06-01-2016)**

###### Automated Programs

1. The mission of Automated Programs (AP) is to identify and use streamlined automated levy and offset processing to efficiently collect delinquent taxes at all levels of the collection enterprise.

2. The Program Manager, AP, reports to the Director, Collection Inventory Delivery & Selection.

3. To accomplish the mission, the Program Manager, AP administers end-to-end oversight to include program development, establishment of policy, training, communications and problem resolution for automated levy programs:




| Automated Levy Programs |
| --- |
| Federal Payment Levy Program (FPLP) |
| State Income Tax Levy Program (SITLP) |
| Alaska Permanent Fund Dividend Program (AKPFD) |
| Federal Employee/Retiree Delinquency Initiative (FERDI) |
| Municipal Tax Levy Program (MTLP) |


**1.1.16.3.3.2.5** **(11-16-2018)**

###### Collection Analytics, Routing and Selection

1. The mission of Collection Analytics, Routing and Selection (CARS) is to analyze and manage IRS Collection business rules to implement policy and executive direction for the collection inventory. CARS develops and leverages business intelligence, decision analytics, predictive modeling and business rules management software to maintain the Inventory Delivery System (IDS) and the Tax Delinquent Account (TDA) and Tax Delinquent Investigation (TDI) programs. In addition, CARS develops business rules and requirements for the Unpaid Assessments system to identify and assign inventory for Private Debt Collection (PDC). CARS ensures that collection inventory is placed in the most effective treatment stream at the appropriate time.

2. The Program Manager, CARS, reports to the Director, Collection Inventory Delivery & Selection.

3. To accomplish the mission, the Program Manager, CARS:



1. Supplies cases based on consistent business routing rules and case selection criteria.

2. Develops standardized program direction and implements assignment criteria for routing of collection work, and monitor workload as it pertains to the assignment of collection cases.

3. Implements policies related to case identification, selection, and priority.

4. Coordinates with stakeholders to determine the impact resource or procedural changes will have on workload and collection results.

5. Evaluates and develops new automated inventory delivery systems (tools) while continuously enhancing existing automated inventory delivery systems.

6. Coordinates ongoing maintenance and end-user needs with IT and other developers for TDA/TDI Analysis and IDS.

7. Coordinates ongoing maintenance and end-user needs with IT and other developers for the unpaid assessments related to Private Debt Collection.

8. Documents and coordinates procedural guidelines and policies implemented systemically in TDA/TDI Analysis and IDS.


**1.1.16.3.3.2.6** **(06-01-2016)**

###### ACS Systems and Inventory

1. The mission of ACS Systems & Inventory (ACSSI) is to ensure accuracy and efficiency in the delivery and selection of ACS cases throughout the IRS enterprise, and to maintain the integrity and stability of the ACS system, making certain that it runs at optimum level at all times.

2. The Manager, ACS Systems & Inventory, reports to the Director, Collection Inventory Delivery & Selection.

3. To accomplish the mission, the Manager, ACS Systems & Inventory:



1. Maintains oversight of ACS inventory selection.

2. Maintains oversight of ACS inventory processing (including priority metrics (Trust Fund, HINF, FERDI, LB&I & Large Dollar)).

3. Provides enhancement and maintenance of the ACS system (including ACS Predictive Dialer).

4. Maintains oversight of ACS system security.

5. Is the point of contact for ACS call sites on issues involving inventory processing and system matters.


**1.1.16.3.3.2.7** **(04-07-2025)**

###### Collection Innovation and Implementation Office

1. The mission of Collection Innovation and Implementation Office is to identify and lead projects that support the Integrated Digital Experience Act (IDEA), Taxpayer First Act (TFA), Inflation Reduction Act (IRA), and the Transformation & Strategy Office to help taxpayers meet their tax obligations and improve both the taxpayer and employee experience.

2. The Program Manager, Collection Innovation and Implementation Office, reports to the Director, Collection Inventory Delivery & Selection.

3. To accomplish the mission, the Program Manager, Collection Innovation and Implementation Office:



1. Maintains all Collection data sources, including validation and system monitoring.

2. Prepares or coordinates responses to all data and information requests relative to the performance of SB/SE Collection.

3. Coordinates with stakeholders Servicewide to capture and document business requirements for the digital platforms.

4. Prepares and submits annual and ad hoc unified work requests for Collection organizations to sustain and enhance functionality of the digital and non-digital platforms to Technology Solutions.

5. Supports, coordinates and tracks all SB/SE Collection IT needs.

6. Coordinates system/application and equipment rollouts.

7. Coordinates various IT activities, initiatives, and needs with SB/SE Operations Support-Technology Solutions.


**1.1.16.3.3.3** **(04-07-2025)**

##### Quality and Technical Support

1. The mission of Quality and Technical Support is to monitor program compliance through the Embedded Quality and National Quality review systems for Field Collection and Campus Collection functions; provide headquarters technical, functional and operational support of various collection and information technology programs including telephone operations, in Collection campuses.

2. The Director, Quality and Technical Support, reports to the Director, Headquarters Collection.

3. To accomplish the mission, the Director, Quality and Technical Support:



1. Through the Collection Quality program, oversees the Field Collection Embedded Quality program and maintains an ongoing qualitative review of field operations at the national, field area and territory level, evaluating programs and providing assistance. Additionally, oversees the administration of the quality measurement system for Campus Operations, and maintains the integrity of the data in the Embedded Quality Review System (EQRS) for diagnostic campus national reviews.

2. Provides guidance and support for policy and procedures relating to Field Collection automation programs to ensure consistent delivery that meets the needs of Field Collection (FC) through the Collection Automation Support & Security (CASS) program.

3. Provides guidance and support for telephone operations, technology management and automated inventory processing for SB/SE Campus Collection, SB/SE Campus Examination and Taxpayer Services Refundable Credit Examination through the Joint Operations Center.


4. The following program managers report to the Director, Collection Quality & Technical Support:



   - Program Manager, Collection Quality

   - Program Manager, Collection Automation Support & Security (CASS)

   - Program Manager, Joint Operations Center (JOC)


**1.1.16.3.3.3.1** **(04-07-2025)**

###### Collection Quality

1. The mission of Collection Quality is to administer the quality measurement system for Campus Operations by monitoring case work or telephone contacts and maintaining the integrity of the data in the Embedded Quality Review System (EQRS) for diagnostic campus national reviews. It is also responsible for monitoring program compliance through the EQRS and National Quality Review System (NQRS) for Field Collection, which includes Field Collection, Offer-in-Compromise, Advisory, and Insolvency.

2. The Program Manager, Collection Quality, reports to the Director, Collection Quality & Technical Support.

3. To accomplish the Collection Quality mission for Campus Collection responsibilities the Collection Quality Program Manager:



1. Develops and maintains the framework for organizational performance measurement.

2. Works in conjunction with Accounts Management to maintain database coding consistency.

3. Provides Attribute coding direction and guidance to quality reviewers based on Internal Revenue Manual (IRM) requirements.

4. Monitors EQ program adherence including coding of reviews and the sampling process.

5. Coordinates with IRM authors to clarify and update procedural requirements.

6. Provides expert support and assistance to organizational performance initiatives.

7. Develops and implements procedures and methodologies for ongoing analysis, assessment, and monitoring of division performance.

8. Coordinates with the National Support Staff (NSS) to execute systemic adjustments and updates as systems and procedures change.

9. Coordinates with the Joint Operation Center to ensure that the contact recording system is functional and resolves daily issues.


4. To accomplish the Collection Quality mission for Field Collection responsibilities the Collection Quality Program Manager:




| Collection Quality for Field Collection Responsibilities |
| --- |
| Coordinates with Technology Solutions and Information Technology to maintain the current EQ systems, as well as to identify, develop, and deliver future enhancements. |
| Maintains EQ technical reference materials and ensures they accurately reflect current law, policy, and procedure. |
| Coordinates with other SB/SE quality program managers to issue consistent guidance and development of training material. |
| Coordinates with Technology Solutions to establish guidelines for accessing and monitoring the system to ensure that appropriate access privileges and security levels are maintained. |
| Provides analysis to identify factors influencing EQ scores. |
| Provides improvement recommendations to the Field Collection operations, defined above. |
| Provides EQ data and/or analysis to other internal and/or external stake holders on a recurring and ad hoc basis. |
| Develops annual NQRS sampling plans for each Field Collection program defined above. |
| Manages the NQRS groups to ensure the national sampling plan is met and statistically valid. |
| Establishes baselines to measure, monitor, and improve reviewer accuracy and consistency. |
| Develops and delivers EQ training materials and classes in coordination with L&E and other stakeholders. |
| Maintains the Field Collection portion of the EQ site and EQ issues log. |

5. The following employees report to the Collection Quality Program Manager:



   - Senior analysts

   - Campus Quality group managers

   - Field Quality group manager

   - Product Line analysts


**1.1.16.3.3.3.2** **(04-07-2025)**

###### Collection Automation Support & Security

1. The mission of Collection Automation Support and Security (CASS) is to provide guidance and support for policy and procedures relating to Field Collection automation programs to ensure consistent delivery that meets the needs of Field Collection (FC).

2. The CASS Program Manager, reports to the Director, Collection Quality & Technical Support.

3. To accomplish the mission, the Program Manager, CASS:



1. Works with FC leadership to manage the development, delivery, implementation, and maintenance of CASS initiatives.

2. Monitors balancing errors resulting from ICS actions to ensure accuracy, resolve system conflicts, and recommend efficiencies when opportunities arise.

3. Compiles, validates and processes data submitted by FC for the End of Month (EOM) time reports.

4. Provides support, assistance, technical expertise, and oversight for SB/SE locator services and Servicewide contracts for credit reports and electronic court records services.

5. Provides user support for the Integrated Data Retrieval System (IDRS), security administration to ensure the integrity of the Integrated Data Retrieval System (IDRS) and other modernized systems of taxpayer records, and protection of taxpayers' right to privacy to ensure trust in the Internal Revenue Service.

6. Provides user support, technical expertise, security administration, training, and recommends enhancements for the Automated Trust Fund Recovery (ATFR) system.

7. Coordinates with IT on the maintenance and delivery of Field Collection end-user needs as it relates to proprietary software.

8. Provides end user training and support for Collection automation programs.

9. Coordinates with (IT on the maintenance and delivery of Field Collection end-user needs as it relates to proprietary software.


4. The following managers report to the Program Manager, Collection Automation Support and Security:



   - FAS group managers

   - IDRS Data Security group manager

   - IQA group managers


**1.1.16.3.3.3.3** **(04-07-2025)**

###### Joint Operations Center

1. The mission of Joint Operations Center is to provide guidance and support for telephone operations, technology management and automated inventory processing for SB/SE Campus Collection, SB/SE Campus Examination and Taxpayer Services Refundable Credit Examination Operation (RCEO).

2. The JOC Program Manager, reports to the Director, Collection Quality & Technical Support.

3. The JOC Liaison has three areas of responsibility: telephone operations, technology management and tool development. Telephone operations take the organization vision, as defined in the Strategic Plan, and ensures telephone operations are compliant. To accomplish this, the JOC Liaison:




| Joint Operations Center Responsibilities |
| --- |
| Serves as a liaison between the call sites, JOC, SB/SE Campus Collection, SB/SE Campus Examination/AUR and Taxpayer Services RICS RCEO. |
| Coordinates emerging issues with the JOC and Accounts Management. |
| Partners with program management in the development of work plans and work plan schedules. |
| Oversees call routing, telephone forecasting and scheduling, performance analysis and system support. |
| Monitors telephone performance and makes adjustments to meet or exceed performance measures. |
| Evaluates the effectiveness of existing automated self-service applications and develops enhancements as appropriate. |
| Provides oversight of telephone system infrastructure. |
| Partners with site campus management to provide training to telephone system analysts and gatekeepers. |
| Represents Compliance and external stakeholders in the determination of IT work requests and delivery schedules. |
| Implements and troubleshoots all telephone innovation, such as contact recording and E-Workforce Management (eWFM). |
| Provides input to strategic plan and operating priorities development. |
| Executes AWS semi-annual telephone model. |
| Coordinates the scheduling of non-telephone activities ensuring consistent delivery of telephone service. |

4. The Technology Management Team (TMT) supports SB/SE Campus Collection and Taxpayer Services RICS RECO functions by providing one centralized location to efficiently support, manage and maintain modernization efforts. TMT accomplishes this by:



1. Improving efficiency and casework quality by increasing awareness of automated tools and providing access to that automation.

2. Exploring available alternatives and looking for opportunities to leverage technology solutions to best address any gaps within existing systems.

3. Providing leadership in multi-functional teams to support business operational priorities.

4. Supporting in the development and prioritization for all system enhancements.

5. Serving as functional point of contact to ensure adherence to all FISMA related activities.

6. Coordinating with Technology Solutions and related IT organizations.

7. Advocating Compliance technology needs.


5. The Tool Development Team supports SB/SE Campus and Taxpayer Services RICS RCEO programs through the automation of work processes and data analysis. To accomplish this, the tool development team:



1. Uses a variety of applications, including Generalized IDRS Interface (GII), VB.net and SQL to create tools that replicate case processing activities.

2. Provides tools for SB/SE and Taxpayer Services RICS functions and many other organizations.

3. Partners with requesting organizations in the development of business requirements, testing and training.

4. Performs IDRS data captures and analysis as requested.

5. Ensures all PII and SBU data is protected in accordance with established security requirements.

6. Ensures only authorized users have access to the tools and data.


**1.1.16.3.4** **(04-07-2025)**

#### Campus Collection

1. The mission of the Campus Collection Operations is to help America’s taxpayers understand and meet their tax responsibilities by applying the tax law with integrity and fairness.

2. The Director of Campus Collection, reports to the Director, Collection.

3. To accomplish the mission, the Director, Campus Collection:



1. Manages and implements strategies pertaining to Collection programs (e.g., Automated Collection System (ACS), Compliance Services Collection Operations (CSCO), Nonfiler programs) and Area Office support while balancing cross-functional objectives.

2. Identifies trends and conducts analysis of data for Campus/ACS sites to determine risk-based strategies, develop best practices, and provide input to campus operations for action.

3. Partners with Headquarters Collection and Planning & Performance Analysis in formulating short-and long-term program strategies, policy guidance, and work plan objectives.


4. The following executive positions report to the Director, Campus Collection:



   - Director, Collection Operations Andover

   - Director, Collection Operations Atlanta

   - Director, Collection Operations Fresno

   - Director, Collection Operations Kansas City

   - Director, Collection Operations Philadelphia


**1.1.16.3.4.1** **(04-07-2025)**

##### Campus Collection Operations

1. The mission of the Automated Collection System (ACS) and Compliance Services Collection Operations (CSCO) is to help America's taxpayers understand and meet their tax responsibilities by applying the tax law with integrity and fairness. This is accomplished by effectively managing the remote collection programs and centralized case and lien processing, and by ensuring timely, accurate case actions on all collection cases.

2. The Directors in Andover, Atlanta, Fresno, Kansas City and Philadelphia report to the Director, Campus Collection.

3. Each Campus Collection Director is responsible for managing the day-to-day operations of all activities for CSCO and ACS. CSCO and ACS collect taxpayer accounts in balance due status, and secure delinquent returns.

4. To accomplish the mission, the Campus Collection Operations Director:



1. Manage and implement strategies pertaining to Collection and programs (e.g., Automated Collection System (ACS), Compliance Services Collection Operations(CSCO), Nonfiler programs, Centralized Case Processing and Centralized Lien Operation) and Area Office support while balancing cross-functional objectives.

2. Coordinate program activities with the Director, Campus Collection to prepare Servicewide policies, establish criteria for selection and receipt of cases, address cross-functional issues, develop strategies, and ensure consistency of approach.

3. Direct statistical analysis and evaluation of the elements comprising Compliance's balanced measures.

4. Ensure that key managers operate as an effective management team and that all management functions are handled in an equitable and responsive manner to meet the needs of taxpayers, coach subordinate managers, and assist in the resolution of complex issues.

5. Direct the development of activities to build leveraged partnerships and collaborate with stakeholders to increase taxpayer knowledge and clarify tax code issues.


**1.1.16.3.4.1.1** **(04-07-2025)**

###### Campus Collection Operations Managers

1. The mission of Operations managers is to help America's taxpayers meet their tax obligations by applying the tax law with integrity and fairness.

2. The Operations managers are responsible for a number of programs that help them accomplish this mission. Some of the major programs are:




| Campus Collection Operations Programs |
| --- |
| Automated Collection System (ACS) |
| Automated Collection System Support (ACSS) |
| Delinquent Return (TDI) Program |
| Balance Due (TDA) Program |
| Installment Agreement (IA) Programs |
| NonFiler Programs (e.g. Automated Substitute for Return (ASFR) |
| Centralized Case Processing (CCP) |
| Withholding Compliance |
| Centralized Lien Operation (CLO) |
| Trust Fund Recovery Penalty (TFRP) |
| Restitution Based Assessments (RBA) |

3. To accomplish its mission, Operations managers:



1. Manage remote Collection activities including telephone and correspondence transactions.

2. Respond to taxpayer calls concerning taxpayer delinquent accounts and investigations.

3. Work with taxpayers to establish a payment plan to ensure tax liabilities are met.

4. Secure delinquent tax returns and calculate taxes owed.

5. Process lien transactions for balance due accounts.


**1.1.16.3.4.1.1.1** **(04-07-2025)**

###### Centralized Lien Operation

1. Centralized Lien Operation, located at the Cincinnati Campus, processes requests for liens and lien releases for all stakeholders.

2. This includes printing the liens and releases, preparing the billing vouchers for each county and input of recording information to the Automated Lien System (ALS). All counties now receive payment through the ALS/IFS interface.


**1.1.16.3.5** **(04-07-2025)**

#### Specialty Collection-Offer in Compromise

1. This mission of Specialty Collection-Offer in Compromise is to process and evaluate offers from taxpayers who have an inability to pay their tax debt in full.

2. The following managers report to the Director, Specialty Collection-Offer in Compromise:



   - Territory Managers, Field OIC (Territories 1 and 2)

   - Operations Manager, Brookhaven OIC

   - Operations Manager, Memphis OIC


**1.1.16.3.5.1** **(04-07-2025)**

##### Offer in Compromise

1. An Offer in Compromise (OIC) is an agreement between a taxpayer and the government that settles a tax liability for payment of less than the full amount owed. Specialty Collection-Offer in Compromise works all OICs for the IRS.

2. All OICs are received and processed at one of two centralized sites. Cases meeting complex criteria are transferred to the Field after initial processing and case building.

3. Monitoring Offer in Compromise (MOIC) receives and monitors all offers accepted by Centralized Offer in Compromise (COIC), field offer specialists, Appeals, Examination and Department of Justice (DOJ).


**1.1.16.3.6** **(04-07-2025)**

#### Specialty Collection Insolvency

1. The mission of Specialty Collection Insolvency is to:



1. Provide exceptional service related to the application of tax law in connection with bankruptcy proceedings for all stakeholders, while protecting the government’s interest within the United States Bankruptcy courts and ensuring taxpayers understand and comply with all applicable tax laws with integrity and fairness to all.

2. Provide insolvent and other taxpayers top quality post-filing services by helping them understand and comply with all applicable tax laws and by applying the tax laws with integrity and fairness. This includes effectively managing Specialty Collection Insolvency programs to ensure timely, accurate case actions on all assigned cases.


2. The Director, Specialty Collection Insolvency, reports to the Director of Collection.

3. The following Territory Managers report to the Director, Specialty Collection Insolvency:



   - Territory Manager – Centralized Insolvency Operation

   - Territory Manager – Northeast

   - Territory Manager - South Atlantic

   - Territory Manager - Midwest

   - Territory Manager – Gulf States

   - Territory Manager – Great Plains

   - Territory Manager – Western


**1.1.16.3.6.1** **(04-07-2025)**

##### Insolvency

1. The mission of the Insolvency Territories is to ensure that taxpayers who file bankruptcy under the Federal Bankruptcy Code are adequately protected and that Internal Revenue Service tax debts receive appropriate and fair treatment consistent with the Federal Bankruptcy Code laws.

2. The Insolvency program managers, report to the Director, Specialty Collection Insolvency.

3. To accomplish the mission, each program manager:



1. Oversees all field and campus activities involving Chapter 7, 9, 11, 12, 13, 15, and receivership bankruptcy petitions in the Federal Bankruptcy Courts in the geographic site territory.

2. Protects the Government's position and rights of the debtor in adjudication of all insolvency cases including post-discharge and post-dismissal actions.

3. Coordinates with local Bankruptcy courts, trustees, Area Counsel, SB/SE and other operating divisions on insolvency cases as needed.

4. Monitors insolvency programs to ensure compliance with the Bankruptcy Code Compliance program.

5. Conducts outreach and provides a local forum for improving customer service for external insolvency stakeholders.

6. Coordinates and controls territory collection activities to achieve uniform compliance with directives and effective utilization of personnel.

7. ensures a smooth flow of information, directives, and intra-territory communications to provide for preparation and submission of statistical and administrative reports.


**1.1.16.4** **(04-07-2025)**

### Office of Promoter Investigations (OPI)

1. The mission of Office of Promoter Investigations (OPI) is to strengthen the IRS response to promoters and enablers of abusive tax avoidance transactions by detecting and ending the promotion, organization, and sale of abusive tax transactions. This would include:



1. Identifying promoters and enablers, including return preparers of abusive tax avoidance transactions.

2. Coordinating Servicewide enforcement activities against promoters and enablers who are responsible for abusive tax transactions, and against participants who use these transactions for illegal tax avoidance.

3. Cultivating internal and external partnerships to identify abusive tax transactions and their promoters and enablers to enhance enforcement.


2. The Director, Office of Promoter Investigations reports to the Deputy Commissioner, SB/SE

3. To accomplish the mission the Director, OPI:



1. Ensures proper identification of abusive promoters and preparers to protect the integrity of the tax system.

2. Improves detection of promoted tax avoidance through new technology and data analytics to combat sophisticated evasion techniques.

3. Provides guidance and recommends improvement opportunities to promoter and abusive return preparer investigations.


4. The following Program Managers report to the Director, OPI:



   - Data Analytics Team

   - Lead Development Center

   - Policy and Technical Support Team 1

   - Policy and Technical Support Team 2

   - Policy and Technical Support Team 3

   - Policy and Technical Support Team 4

   - Policy and Technical Support Team 5


5. The following managers report to the Program Manager, Lead Development Center



   - Lead Development Center, Workload Selection

   - Lead Development Center, Workload Selection 2

   - Lead Development Center, Abusive Transaction Support Unit (ATSU)


**1.1.16.5** **(04-07-2025)**

### Examination

1. The mission of Examination is to provide Small Business and Self-Employed (SB/SE) taxpayers top quality service by helping them understand and meet tax responsibilities and by applying the tax law with integrity and fairness.

2. The Director and Deputy Director, Examination, report to the Deputy Commissioner, SB/SE.

3. To accomplish the mission, the Director and Deputy Director, Examination:



1. Formulates short-range and long-range program strategies, policies, and objectives specific to SB/SE taxpayers.

2. Partners with Communications to design, develop, and implement programs, including pre-filing, filing, and post-filing educational activities to assist SB/SE customers in understanding and complying with all tax laws.

3. Monitors trends affecting SB/SE compliance and responds to changes in taxpayer needs in those areas.

4. Improves business practices and technology in order to provide quality customer assistance.

5. Manages issues affecting compliance across operating divisions, works with other divisions to develop and implement consistent and fair treatment of all taxpayers.

6. Ensures Mission Statement and priorities are delivered by completing operational reviews of subordinates and by requiring the completion of reviews by all levels of management in Examination.

7. Provides quality customer service in responding to both internal (field and administrative) and external (taxpayer and Congressional) inquires.


4. The following directors and program manager report to the Director and Deputy Director, Examination:



   - Director, Field Examination

   - Director, Campus Examination/AUR

   - Director, Specialty Examination

   - Director, Planning and Performance Analysis Examination

   - Director, Examination Headquarters

   - Program Manager, Examination Customer Coordination and Innovation Office


**1.1.16.5.1** **(04-07-2025)**

#### Field Examination

1. The mission of the Field Examination is to provide SB/SE taxpayers in each of the seven field areas top quality post-filing services by helping them understand and comply with all applicable tax laws and by applying the tax laws with integrity and fairness. This includes effectively managing field examination programs to ensure timely, and accurate case actions on all examination cases.

2. The Director, Field Examination, reports to the Director and Deputy Director, Examination.

3. To accomplish the mission, the Director, Field Examination:



1. Advises the Director, Examination on all issues involving the delivery of Field Examination strategic plans and programs.

2. Ensures that Field Examination mission, principles and vision remain current and support the IRS mission.

3. Coordinates with Examination HQ to develop compliance strategies that reflect local population characteristics, needs, and behavior patterns, with the aim of improving voluntary compliance and customer service.

4. Coordinates implementation strategies in the treatment of risk-based compliance with Examination HQ.

5. Manages issues affecting compliance within Examination and across Business Units (BU) and works with other BUs to develop and implement consistent and fair treatment of all taxpayers.

6. Provides continuous oversight, coordination and supports each of the area directors by ensuring that appropriate integrated mechanisms are in place to jointly implement and deliver programs and to manage operations within Field Examination.

7. Ensures Mission Statement and priorities are delivered by completing operational reviews of the seven areas and Technical Services and by requiring the completion of reviews by all levels of management in Field Examination.

8. Provides quality customer service in responding to both internal (field and administrative) and external (taxpayer and Congressional) inquiries.


4. The following Area Directors, report to the Director, Field Examination:



   - Area Director, Examination Central Area

   - Area Director, Examination North Atlantic Area

   - Area Director, Examination South Atlantic Area

   - Area Director, Examination Gulf States Area

   - Area Director, Examination Southwest Area

   - Area Director, Examination Western Area

   - Area Director, Examination Midwest Area


**1.1.16.5.1.1** **(11-16-2018)**

##### Field Examination Areas

1. The mission of the Field Examination Areas is to provide SB/SE taxpayers in each territory top quality post-filing services by helping them understand and comply with all applicable tax laws and by applying the tax laws with integrity and fairness.

2. Each Area Director, Field Examination reports to the Director, Field Examination.

3. To accomplish the mission each Field Examination Area Director:



1. Exercises executive oversight of the operations within their Examination Area.

2. Prepares operational plans, conducts operational reviews, and allocates SB/SE resources to achieve objectives and meet customer needs.

3. Identifies and develops best practices and elevates them for analysis and possible nationwide implementation.

4. Administers all federal tax laws applicable to SB/SE taxpayers and alternative treatments to effectively leverage resources and to achieve optimum compliance results and ensure consistency in treatment of SB/SE taxpayers.

5. Works with Communication to improve voluntary compliance by providing input to the design, development, and implementation of programs that assist SB/SE customers in understanding their tax responsibilities and complying with all tax laws.

6. Serves as the Director, Field Examination representative for Taxpayer Advocate matters and performs congressional and outside stakeholder liaison responsibilities within the Area.

7. Ensures Mission Statement and priorities are delivered by completing operational reviews of each territory.

8. Provides quality customer service in responding to both internal (field and administrative) and external (taxpayer and Congressional) inquiries.

9. Area directors in Examination Central Area, South Atlantic Area, Western and Midwest Area also exercise executive oversight over their respective Technical Services territory.


4. The following managers report to the Area Directors, Field Examination:



   - Territory Managers, Field Examination-Areas Field

   - Territory Managers, Field Examination-Areas, Planning and Special Programs

   - Territory Managers, Field Examination-Areas, Technical Services


**1.1.16.5.1.1.1** **(06-01-2016)**

###### Field Examination Territories

1. The mission of the Field Examination Territories is to provide SB/SE taxpayers in each territory top quality post-filing services by helping them understand and comply with all applicable tax laws and by applying the tax laws with integrity and fairness.

2. Each Territory Manager, Field Examination-Area, reports to an Area Director, Field Examination.

3. To accomplish the mission each Territory Manager, Field Examination-Area:



1. Identifies and resolves emerging examination issues at the local level and coordinates with the necessary Business Units and functions to work the issues.

2. Develops and delivers mission-oriented services and strategies to improve customer service, consistency, and efficiency.

3. Works with group managers and employees to develop and share best practices.

4. Delivers examination strategies in coordination with Communications to integrate education and outreach.

5. Delivers and coordinates strategies to apply appropriate treatment for non- compliance with the tone, treatment and timing of interaction appropriate to the non-compliance risk posed by the taxpayer.

6. Provides technical advice to the Area Director, Field Examination in all facets of compliance activities; seeks clear policy and interpretation of federal law and regulations from Exam Policy and provides it as needed to customers.

7. Coordinates and controls territory examination activities to achieve uniform compliance with directives and effective utilization of personnel and ensures a smooth flow of information, directives, and intra-territory communications to provide for preparation and submission of statistical and administrative reports.


**1.1.16.5.1.1.1.1** **(04-07-2025)**

###### Technical Services Territories

1. The mission of the Technical Services Territories is to provide technical and procedural support and guidance for Field Examination and Area Management in both SB/SE and LB&I by reviewing a wide range of Examination casework. This includes issuing Statutory Notices of Deficiency (SNOD) and Final Notices of Partnership Administrative Adjustments (FPAA), effecting Criminal Restitution Assessments, and monitoring Bankruptcy, Fraud and other suspense type cases. It also includes performing various other technical and procedural case reviews to improve quality of examinations.

2. To accomplish the mission Technical Services Territories:




| Technical Services Responsibilities |
| --- |
| Define and clarify individual authorities, relationships, duties, and areas of responsibility for supervisory and staff personnel in Technical Services. |
| Serve as an advisor to the Director, Field Examination and to Field Examination Area Directors, on all facets of Examination Technical Services activities, furnishing information concerning policies of the Internal Revenue Service and interpretation of federal laws and regulations. |
| Provide periodic statute reports as needed to the Director, Field Examination, Field Examination Area Directors, and to LB&I Industry Directors. |
| Identify and promote best practices. |
| Coordinate and control Technical Services territory activities to achieve uniform compliance with directives and effective utilization of personnel; ensures a smooth flow of information, directives, and intra-territory communications to provide for preparation and submission of statistical and administrative reports. |
| Maintain and coordinate revisions of IRM 4.8, –Technical Services (Exam) and IRM 25.26.1, Criminal Restitution and Restitution-Based Assessments. |
| Provide and coordinate technical and processing guidance with internal and external stakeholders which include Appeals, Counsel, Criminal Investigation, LB&I, Taxpayer Advocate Service, and Taxpayer Services. |
| Provide coordination assistance in certain technical programs. |
| Review cases from designated programs for accuracy and quality. |
| Maintain suspense files for bankruptcy, fraud, grand jury, Section 1254 cases, etc. |
| Prepare Statutory Notices of Deficiency (90-day letters), FPAAs and BBA Partnership Notices for both SB/SE Examination as well as LB&I, and coordinate approval with Counsel as necessary. |

3. The following Territory Managers report to Area Directors, Field Examination:



   - Technical Services East Territory reports to Field Examination Central Area

   - Technical Services Legacy Territory reports to Field Examination South Atlantic Area

   - Technical Services Midstates Territory reports Field Examination Midwest Area

   - Technical Services West Territory reports to Field Examination Western


**1.1.16.5.2** **(04-07-2025)**

#### Campus Examination and Automated Underreporter (AUR)

1. The mission of Campus Examination/AUR is to be a world class organization that is committed to educating taxpayers about their responsibilities, resolving taxpayers' issues appropriately, investing in our employees' growth, and delivering the IRS's goals and objectives.

2. The Director, Campus Examination/AUR reports to the Director and Deputy Director, Examination.

3. To accomplish the mission the Director, Campus Examination/AUR:



1. Advises the Director, Examination on all issues involving the delivery of Campus Examination strategic plans and programs.

2. Manages, oversees and implements strategies pertaining to Campus Examination programs (e.g. correspondence Examination, automated underreporter, innocent spouse, centralized case processing, combined annual wage reporting, etc.).

3. Reviews and monitors program progress against operational plans and identifies area for improvement.

4. Monitors resource allocations.

5. Collaborates with other Business Function organizations within and outside of SB/SE Examination, including Examination Headquarters , Specialty Examination, Planning & Performance Analysis Examination, SB/SE, Collection, LB&I and Appeals, to ensure program and taxpayer needs are being properly addressed.

6. Maintains constant oversight and engagement with the Campus Directors to support program delivery, plan performance, resource execution, and quality measurement objectives.

7. Provides quality customer service in responding to both internal (field and administrative) and external (taxpayer and Congressional) inquiries.


4. The following directors in the Campus Examination/AUR organization report to the Director, Campus Examination:



   - Director, Brookhaven Campus Exam/AUR

   - Director, Cincinnati Campus Exam/AUR

   - Director, Memphis Campus Exam/AUR

   - Director, Ogden Campus Exam/AUR


**1.1.16.5.2.1** **(06-01-2016)**

##### Campus Examination and Automated Underreporter (AUR) Operations

1. The mission of the Campus Examination/AUR Operations is to educate taxpayers about their responsibilities, resolve taxpayers' issues appropriately, and deliver the IRS's goals and objectives.

2. The Campus Examination/AUR Campus Directors report to the Director, Campus Examination/AUR.

3. To accomplish the mission each Campus Examination/AUR Campus Director:



1. Oversees the day-to-day operations for correspondence Examination and automated underreporter activities as well as any site specific operations for a given campus such as Document Matching, Innocent Spouse, Combined Annual Wage Reporting, Federal Unemployment Tax Act, Informant Claims and Centralized Case Processing, to name a few; as it relates to resource, financial and program management.

2. Formulates short and long-range program execution strategies and objectives to meet business objectives.

3. Coordinates program activities within the campus to encourage a cohesive workforce environment.

4. Maintains awareness of issues impacting their programs with a focus on improving customer satisfaction and business results.

5. Assists in the resolution of complex case issues.

6. Engages employees in process improvement activities to help promote top level service to taxpayers.

7. Develops employees through encouraging and supporting continuing education.

8. Provides quality customer service in responding to both internal (field and administrative) and external (taxpayer and Congressional) inquiries.


**1.1.16.5.3** **(04-07-2025)**

#### Specialty Examination

1. The mission of Specialty Examination is to increase compliance with excise tax, employment tax, estate and gift tax, and Bank Secrecy Act laws by applying the tax laws with integrity and fairness and to provide SB/SE taxpayers top quality post- filing services for Specialty Examination taxes administered by SB/SE, by helping them understand and comply with all applicable tax laws. This includes effectively managing Specialty Examination field programs to ensure timely, accurate case actions on all examination cases.

2. The Director, Specialty Examination reports to the Director and Deputy Director, Examination.

3. To accomplish the mission the Director, Specialty Examination:



1. Advises the Director, Examination on all issues involving the delivery of Specialty Examination strategic plans and programs.

2. Ensures that Specialty Examination’s mission, principles and vision remain current and support the IRS mission.

3. Designs and develops programs to solve complex Specialty Examination issues.

4. Coordinates implementation strategies in the treatment of risk-based compliance with Examination HQ.

5. Manages issues affecting compliance within Specialty Examination and across Business Units (BU) and works with other BUs to develop and implement consistent and fair treatment of all taxpayers.

6. Provides continuous oversight, coordination and supports the Specialty Examination Chiefs by ensuring that appropriate integrated mechanisms are in place to jointly implement and deliver programs and to manage operations within Specialty Examination.

7. Ensures Mission Statement and priorities are delivered by completing operational reviews of each Specialty Examination program by requiring the completion of reviews by all levels of management in Specialty Examination.

8. Provides quality customer service in responding to both internal (field and administrative) and external (taxpayer and Congressional) inquiries.


4. The following program chiefs report to the Director, Specialty Examination:



   - Chief, Estate & Gift/Excise Tax-Examination

   - Chief, Employment Tax-Examination

   - Chief, BSA-Examination


**1.1.16.5.3.1** **(04-07-2025)**

##### Excise Tax Examination

1. The mission of Excise Tax Examination is to increase compliance with excise tax laws by applying the tax laws with integrity and fairness and to provide SB/SE taxpayers top quality post- filing services for excise taxes administered by SB/SE, by helping them understand and comply with all applicable tax laws.

2. The Chief, Estate and Gift/Excise Tax Examination reports to the Director, Specialty Examination.

3. To accomplish the mission the Chief, Estate and Gift/Excise Tax Examination:



01. Advises the Director, Specialty Examination on all issues involving the delivery of Excise Tax Examination strategic plans and programs.

02. Coordinates excise tax examination field compliance and 637 Registration policies and strategies administered by SB/SE across all Operating Divisions.

03. Ensures that Excise Examination, Fuel Inspection, and 637 Registration programs and policies are enforced consistently.

04. Assists Specialty Workload Planning & Analysis, Exam Case Selection and Specialty Policy in developing and monitoring the Excise Tax Examination work plan.

05. Fosters and supports relationships with internal (Excise Tax Policy, Excise Tax Case Selection, SB/SE Research, Counsel, etc.) and external stakeholders and industry experts to meet taxpayer needs and to improve knowledge of industry standards and practices for those excise taxes administered by SB/SE.

06. Actively improves Excise Tax Examination field compliance processes with a keen focus on customer service.

07. Deploys Excise Tax Examination resources in a manner that supports SB/SE strategies and ensures appropriate support for implementing compliance activity.

08. Partners with Excise Tax Policy and Counsel to develop and deliver Excise Tax key messages to internal and external audiences.

09. Ensures Mission Statement and priorities are delivered by completing operational reviews.

10. Provides quality customer service in responding to both internal (field and administrative) and external (taxpayer and Congressional) inquiries.


4. The following managers report to the Chief, Estate & Gift/Excise Tax Examination:



   - Territory Manager, Eastern

   - Territory Manager, Western

   - Territory Manager, Excise Southern and Fuel Compliance


**1.1.16.5.3.1.1** **(04-07-2025)**

###### Excise Tax Examination Territories

1. The mission of the Excise Tax Examination Territories is to increase compliance with excise tax laws by applying the tax laws with integrity and fairness and to provide SB/SE taxpayers top quality post- filing services for excise taxes administered by SB/SE, by helping them understand and comply with all applicable tax laws.

2. The Excise Tax Examination Territory Managers report to the Chief, Estate and Gift/Excise Examination.

3. To accomplish the mission each Territory Manager:



1. Identifies and resolves emerging examination issues at the local level and coordinates with the necessary Business Units and functions to work the issues.

2. Develops and delivers mission-oriented services and strategies to improve customer service, consistency, and efficiency.

3. Works with group managers and employees to develop and share best practices.

4. Delivers Excise Tax Examination strategies in coordination with Communications to integrate education and outreach.

5. Delivers and coordinates strategies to apply appropriate treatment for non-compliance with the tone, treatment and timing of interaction appropriate to the non-compliance risk posed by the taxpayer.

6. Provides technical advice to the Chief, Estate & Gift/Excise Tax Examination in all facets of compliance activities; seeks clear policy and interpretation of federal law and regulations from Specialty Exam Policy and provides it as needed to customers.

7. Coordinates and controls territory examination activities to achieve uniform compliance with directives and effective utilization of personnel and ensures a smooth flow of information, directives, and intra-territory communications to provide for preparation and submission of statistical and administrative reports.


**1.1.16.5.3.2** **(04-07-2025)**

##### Estate and Gift Tax Examination

1. The mission of Estate and Gift Tax Examination is to increase compliance with estate and gift tax laws by applying the tax laws with integrity and fairness and to provide SB/SE taxpayers top quality post-filing services for estate and gift taxes administered by SB/SE, by helping them understand and comply with all applicable tax laws.

2. The Chief, Estate and Gift/Excise Tax Examination reports to the Director, Specialty Examination.

3. To accomplish the mission the Chief, Estate and Gift/Excise Tax Examination:



01. Advises the Director, Specialty Examination on all issues involving the delivery of Estate and Gift Tax Examination strategic plans and programs.

02. Coordinates Estate and Gift Tax Examination field compliance, policies and strategies administered by SB/SE across all operating divisions.

03. Ensures that Estate and Gift Tax Examination strategies, programs and policies are enforced consistently.

04. Assists Specialty Workload Planning & Analysis, Exam Case Selection, and Specialty Policy in developing and monitoring the Estate and Gift Tax Examination work plan.

05. Fosters and supports relationships with internal (Estate and Gift Tax Policy, Estate and Gift Tax Case Selection, SB/SE Research, Counsel, etc.,) and external stakeholders and industry experts to meet taxpayer needs and to improve knowledge of industry standards and practices for those estate and gift taxes administered by SB/SE.

06. Actively improves Estate and Gift Tax Examination field compliance processes with a keen focus on customer service.

07. Deploys Estate and Gift Tax Examination resources in a manner that supports SB/SE strategies and ensures appropriate support for implementing compliance activity.

08. Partners with Estate and Gift Tax Policy and Counsel to develop and deliver Estate and Gift Tax key messages to internal and external audiences.

09. Ensures Mission Statement and priorities are delivered by completing operational reviews.

10. Provides quality customer service in responding to both internal (field and administrative) and external (taxpayer and Congressional) inquiries.


4. The following managers report to the Chief, Estate and Gift/Excise Tax Examination:



1. Territory Manager, Northeast

2. Territory Manager, South

3. Territory Manager, Central West


**1.1.16.5.3.2.1** **(06-01-2016)**

###### Estate and Gift Tax Examination Territories

1. The mission of Estate and Gift Tax Examination Territories is to increase compliance with estate and gift tax laws by applying the tax laws with integrity and fairness and to provide SB/SE taxpayers top quality post-filing services for estate and gift taxes administered by SB/SE, by helping them understand and comply with all applicable tax laws.

2. The Estate and Gift Tax Examination Territory Managers report directly to the Chief, Estate and Gift/Excise Tax Examination.

3. To accomplish the mission each Territory Manager:



1. Identifies and resolves emerging examination issues at the local level and coordinates with the necessary business units and functions to work the issues.

2. Develops and delivers mission-oriented services and strategies to improve customer service, consistency, and efficiency.

3. Works with group managers and employees to develop and share best practices.

4. Delivers Estate and Gift Tax Examination strategies in coordination with Communications to integrate education and outreach.

5. Delivers and coordinates strategies to apply appropriate treatment for non-compliance with the tone, treatment and timing of interaction appropriate to the non-compliance risk posed by the taxpayer.

6. Provides technical advice to the Chief, Estate and Gift Tax Examination in all facets of compliance activities; seeks clear policy and interpretation of federal law and regulations from Specialty Exam Policy and provides it as needed to customers.

7. Coordinates and controls territory examination activities to achieve uniform compliance with directives and effective utilization of personnel and ensures a smooth flow of information, directives, and intra-territory communications to provide for preparation and submission of statistical and administrative reports.


**1.1.16.5.3.3** **(04-07-2025)**

##### Employment Tax Examination

1. The mission of Employment Tax Examination is to increase compliance with employment tax laws by applying the tax laws with integrity and fairness and to provide SB/SE taxpayers top quality post-filing services for employment taxes administered by SB/SE, by helping them understand and comply with all applicable tax laws.

2. The Chief, Employment Tax Examination, reports to the Director, Specialty Examination.

3. To accomplish the mission the Chief, Employment Tax Examination:



01. Advises the Director, Specialty Examination on all issues involving the delivery of Employment Tax Examination strategic plans and programs.

02. Coordinates employment tax examination field compliance, policies and strategies administered by SB/SE across all Operating Divisions.

03. Ensures that Employment Tax Examination strategies, programs and policies are enforced consistently.

04. Assists Specialty Workload Planning & Analysis, Exam Case Selection, and Specialty Policy in developing and monitoring the Employment Tax Examination work plan.

05. Fosters and supports relationships with internal (Employment Tax Policy, Employment Tax Case Selection, SB/SE Research, Counsel, etc.) and external stakeholders and industry experts to meet taxpayer needs and to improve knowledge of industry standards and practices for those employment taxes administered by SB/SE.

06. Actively improves Employment Tax Examination field compliance processes with a keen focus on customer service.

07. Deploys Employment Tax Examination resources in a manner that supports SB/SE strategies and ensures appropriate support for implementing compliance activity.

08. Partners with Employment Tax Policy and Counsel to develop and deliver Employment Tax key messages to internal and external audiences.

09. Ensures Mission Statement and priorities are delivered by completing operational reviews.

10. Provides quality customer service in responding to both internal (field and administrative) and external (taxpayer and Congressional) inquiries.


4. The following managers report to the Chief, Employment Tax Examination:



   - Territory Manager, East

   - Territory Manager, Mid-States

   - Territory Manager, West

   - Territory Manager, Large Case

   - Territory Manager, National Tip Reporting Compliance Program

   - Territory Manager, Training

   - Territory Manager, Mountain


**1.1.16.5.3.3.1** **(06-01-2016)**

###### Employment Tax Territories

1. The mission of Employment Tax Examination Territories is to increase compliance with employment tax laws by applying the tax laws with integrity and fairness and to provide SB/SE taxpayers top quality post- filing services for employment taxes administered by SB/SE, by helping them understand and comply with all applicable tax laws.

2. The Employment Tax Examination Territory Managers report directly to the Chief, Employment Tax Examination.

3. To accomplish the mission each Territory Manager:



1. Identifies and resolves emerging examination issues at the local level and coordinates with the necessary business units and functions to work the issues.

2. Develops and delivers mission-oriented services and strategies to improve customer service, consistency, and efficiency.

3. Works with group managers and employees to develop and share best practices.

4. Delivers Employment Tax Examination strategies in coordination with Communications to integrate education and outreach.

5. Delivers and coordinates strategies to apply appropriate treatment for non-compliance with the tone, treatment and timing of interaction appropriate to the non-compliance risk posed by the taxpayer.

6. Provides technical advice to the Chief, Employment Tax Examination in all facets of compliance activities; seeks clear policy and interpretation of federal law and regulations from Specialty Exam Policy and provides it as needed to customers.

7. Coordinates and controls territory examination activities to achieve uniform compliance with directives and effective utilization of personnel and ensures a smooth flow of information, directives, and intra-territory communications to provide for preparation and submission of statistical and administrative reports.


4. The mission of Employment Tax Tip Reporting Compliance, National Tip Reporting Compliance Program (NTRCP) Territory, is to develop and implement policies and strategies for tip income filing, payment (withholding), and reporting compliance.

5. To accomplish the mission of the NTRCP Territory, in addition to the tasks noted in (3) above, the NTRCP Territory Manager:



1. Works with Examination HQ in the development and implementation of strategies for delivering Voluntary Employer and Employee Compliance Programs; identifying and resolving emerging issues; and developing and delivering mission-oriented services and strategies to improve customer service, consistency, and efficiency.

2. Collaborates with external stakeholders and industry experts to meet taxpayer needs and improve knowledge of industry standards and practices, voluntary programs, and compliance issues.

3. Oversees coordination of SB/SE employment tax field examination programs, personnel, and procedures related to employers who employ individuals that customarily receive tips in the performance of their duties.

4. Conducts assistance visits of groups performing tip compliance activities to ensure policies and procedures are adhered to and to determine trends and patterns for possible program documents and coordinates Servicewide procedural guidelines and policies for employment tax.

5. Informs of and distributes major policy issues and directives developed by Employment Tax Policy with respect to tip reporting.

6. Serves as an advisor to the Chief, Employment Tax Examination in all facets of Tip Compliance Employment and Income Tax activities; seeks clear policy and interpretation of federal law and regulations from Specialty Exam Policy and provides it as needed to customers.


**1.1.16.5.3.4** **(06-01-2016)**

##### Bank Secrecy Act (BSA) Examination

1. The mission of BSA Examination is to provide an effective, efficient, and high-quality service as the regulatory agency of certain financial institutions and industries concerning their compliance with 31 CFR Chapter X of the Bank Secrecy Act and to ensure compliance of financial institutions and industries with section 6050I of the Internal Revenue Code.

2. The Chief, BSA Examination reports to the Director, Specialty Examination.

3. To accomplish the mission the Chief, BSA Examination:



01. Advises the Director, Specialty Examination on all issues involving the delivery of BSA Examination strategic plans and programs.

02. Coordinates BSA Examination field compliance, policies and strategies administered by SB/SE across all operating divisions.

03. Ensures that BSA Examination strategies, programs and policies are enforced consistently.

04. Assists Specialty Workload Planning & Analysis, Exam Case Selection, and Specialty Policy in developing and monitoring the BSA Examination work plan.

05. Fosters and supports relationships with internal (BSA Policy, BSA Case Selection, SB/SE Research, Counsel, etc.) and external stakeholders and industry experts to meet taxpayer needs and to improve knowledge of industry standards and practices for those employment taxes administered by SB/SE.

06. Actively improves BSA Examination field compliance processes with a keen focus on customer service.

07. Deploys BSA Examination resources in a manner that supports SB/SE strategies and ensures appropriate support for implementing compliance activity.

08. Partners with BSA Policy and Counsel to develop and deliver BSA Exam key messages to internal and external audiences.

09. Ensures Mission Statement and priorities are delivered by completing operational reviews.

10. Provides quality customer service in responding to both internal (field and administrative) and external (taxpayer and Congressional) inquiries.


**1.1.16.5.3.4.1** **(06-01-2016)**

###### BSA Examination Territories

1. The mission of BSA Examination Territories is to provide an effective, efficient, and high-quality service as the regulatory agency of certain financial institutions and industries concerning their compliance with 31 CFR Chapter X of the Bank Secrecy Act and to ensure compliance of financial institutions and industries with section 6050I of the Internal Revenue Code.

2. The BSA Examination Territory Managers report directly to the Chief, BSA Examination.

3. To accomplish the mission each Territory Manager:



1. Identifies and resolves emerging examination issues at the local level and coordinates with the necessary business units and functions to work the issues.

2. Develops and delivers mission-oriented services and strategies to improve customer service, consistency, and efficiency.

3. Works with group managers and employees to develop and share best practices.

4. Delivers BSA Examination strategies in coordination with Communications to integrate education and outreach.

5. Delivers and coordinates strategies to apply appropriate treatment for non- compliance with the tone, treatment and timing of interaction appropriate to the non-compliance risk posed by the taxpayer.

6. Provides technical advice to the Chief, BSA Examination in all facets of compliance activities; seeks clear policy and interpretation of federal law and regulations from Specialty Exam Policy and provides it as needed to customers.

7. Coordinates and controls territory examination activities to achieve uniform compliance with directives and effective utilization of personnel and ensures a smooth flow of information, directives, and intra-territory communications to provide for preparation and submission of statistical and administrative reports.


**1.1.16.5.3.4.2** **(06-01-2016)**

###### BSA Currency Transactions Reporting (CTR) Operations

1. CTR Operations is responsible for processing data and providing related support in compliance with 31 CFR Chapter X of the Bank Secrecy Act with section 6050I of the Internal Revenue Code. The data primarily includes input and penalties of Form 8300 (Report of Cash Payments Over $10,000 Received in a Trade or Business) and FBAR (Report of Foreign Bank and Financial Accounts) penalty assessment, taxpayer support and case coordination. CTR also provides closed case processing for BSA field examinations.

2. The CTR Department Manager, reports to the Chief, BSA Examination.

3. To accomplish the mission the CTR Department Manager:



1. Develops and shares best practices to improve operational performance.

2. Identifies and resolves operational issues at the department level and elevates such issues to the Chief, BSA Examination as necessary.

3. Coordinates and controls department work processes to achieve uniform compliance with directives and effective utilization of personnel.

4. Ensures a smooth flow of information, directives, and intra-department communications for preparation and submission of administrative reports.

5. Conducts team level operational and performance reviews.


**1.1.16.5.4** **(04-07-2025)**

#### Performance Planning and Analysis

1. The mission of Performance Planning and Analysis is to develop, distribute and monitor work plans and targets for all SB/SE Examination and controls and answers all requests for SB/SE Examination data. This includes analysis, preparation and submission of all data requests as well as Executive Reporting on all SB/SE Examination data elements. This office is also responsible for coordinating all facets of the SB/SE Examination TIGTA and GAO audits, coordinating and supporting SB/SE Examination information technology needs and coordinating SB/SE Examination Strategic Initiative activities.

2. The Director, Performance Planning and Analysis Examination, reports to the Director and Deputy Director, Examination.

3. To accomplish the mission the Director, Performance Planning and Analysis Examination:



1. Advises the Director and Deputy Director, Examination on issues involving the delivery of all SB/SE Examination programs.

2. Develops, analyzes, and monitors the Field, Campus, and Specialty Examination work plans.

3. Oversees the development of Workload Studies to determine examination resource allocation.

4. Monitors performance results against all SB/SE Examination Program work plans and targets and identifies areas for opportunities for improvement.

5. Provides briefings to all functions within SB/SE Examination to assist in achieving program delivery.

6. Prepares responses to all data and information requests relative to the performance of SB/SE Examination.

7. Coordinates all SB/SE Examination involvement in TIGTA/GAO requests, responses and Planned Corrective Actions (PCA).

8. Supports, coordinates and tracks all SB/SE Examination information technology needs.

9. Coordinates development and tracing of SB/SE Examination Strategic Initiatives.


4. The following managers report to the Director, Performance Planning and Analysis Examination:



   - Program Manager, Field and Specialty Examination, Workload Planning and Analysis (FSWPA)

   - Program Manager, Campus Examination and Document Matching Workload Planning and Analysis (CEDWPA)

   - Program Manager, SB/SE Examination Data Management (EDM)

   - Program Manager, SB/SE Examination GAO/TIGTA and Information Technology Management (GTIT)


**1.1.16.5.4.1** **(04-07-2025)**

##### Field and Specialty Examination Workload Planning and Analysis (FSWPA)

1. The mission of FSWPA is to create and monitor adherence to Field and Specialty Examination work plans and assist with determining and maintaining the optimal mix of work for these programs.

2. The Program Manager, FSWPA, reports to the Director, Performance Planning and Analysis Examination.

3. To accomplish the mission, the Program Manager, FSWPA:



1. Develops and monitors the Field and Specialty Examination work plans and accomplishments.

2. Monitors Field Examination and Specialty Examination resource utilization and ensures funding is appropriately distributed.

3. Develops and applies a yearly workload study for SB/SE Field Examination to assist in the determination of the proper placement of new resources and assists in determining the correct workload placement.

4. Provides monthly reports, analysis and briefings to the directors of Field Examination and Specialty Examination to assist in achieving program delivery.


**1.1.16.5.4.2** **(11-16-2018)**

##### Campus Examination and Document Matching Workload Planning and Analysis (CEDWPA)

1. The mission of CEDWPA is to create and monitor adherence to the Campus Examination and Document Matching work plans and to determine and monitor the optimal distribution of resources and workload for the Campus programs including support functions.

2. The Program Manager, CEDWPA, reports to the Director, Planning and Performance Analysis Examination.

3. To accomplish the mission, the Program Manager, CEDWPA:



1. Develops and monitors all SB/SE Examination Campus work plans.

2. Monitors campus resource utilization and ensures funding is appropriately distributed.

3. Develops and applies workload models to determine the placement of new resources.

4. Assists in monitoring the campus inventory workstream.

5. Provides monthly briefing and ad hoc reports to the Director, Campus Examination/AUR to assist in achieving program delivery.


**1.1.16.5.4.3** **(04-07-2025)**

##### Examination Data Management (EDM)

1. The primary mission of EDM is to maintain central control for all SB/SE Examination data to ensure accurate, consistent and appropriate information is provided to internal and external stakeholders including data needed in response to TIGTA/GAO audit related requests. In addition, this office serves as the business data owner for the Audit Information Management System (AIMS), AIMS Centralized Information System (A-CIS), and Exam Operational Automation Database (EOAD).

2. The Program Manager, EDM, reports to the Director, Performance Planning and Analysis Examination.

3. To accomplish the mission, the Program Manager, EDM:



1. Maintains all Examination data sources, including validation and system monitoring.

2. Prepares or coordinates responses to all data and information requests relative to the performance of SB/SE Examination.

3. Coordinates with stakeholders Servicewide to capture and document business requirements for the AIMS, A-CIS, and EOAD platforms.

4. Prepares and submits annual and adhoc unified work requests to sustain and enhance functionality of the AIMS, A-CIS, and EOAD platforms to Technology Solutions.


**1.1.16.5.4.4** **(04-07-2025)**

##### Examination GAO/TIGTA and Information Technology Management (GTIT)

1. The mission of GTIT is to ensure that SB/SE Examination is responsive to all GAO and TIGTA audits, and coordinates between functional offices and across BODs as needed. This office also supports, coordinates and tracks all SB/SE Examination information technology needs.

2. The Program Manager, GTIT, reports to the Director, Performance Planning and Analysis Examination.

3. To accomplish the mission, the Program Manager, GTIT:



1. Reviews TIGTA/GAO audits received from the Office of Audit Coordination (OAC) to determine appropriate SB/SE Examination involvement and ownership within SB/SE Examination functions.

2. Supports the SB/SE Examination functional audit owners to ensure responses are complete, timely and accurate.

3. Tracks all Examination PCAs, ensuring timely and accurate completion.

4. Supports, coordinates and tracks all SB/SE Examination information technology needs.

5. Coordinates system/application and equipment rollouts.

6. Coordinates various information technology activities/initiatives/needs with SB/SE Operations Support-Technology Solutions.


**1.1.16.5.5** **(04-07-2025)**

#### Examination Headquarters

1. The mission of Examination Headquarters is to formulate program strategies, provide policy, guidance and technical support for compliance activities in Field, Specialty, and Campus Exam Operations, coordinate workload selection and ensure consistent application of policy, procedures and tax law to effect tax administration while protecting taxpayers’ rights.

2. The Director, Examination Headquarters, reports to the Director and Deputy Director, Examination.

3. To accomplish the mission, the Director and Deputy Director, Examination Headquarters:



1. Advises the Director, Examination on all issues involving the delivery of Examination strategic plans and programs.

2. Provides policy, guidance and procedures to Campus, Field and Specialty Examination operations.

3. Provides input to the work plan based on strategic priorities.

4. Coordinates workload selection and inventory delivery processes.

5. Implements strategies to prevent abusive and offshore tax non-compliance.

6. Supports the improvement of Examination quality through the National Quality Review System and provides feedback to operations.

7. Provides technical support to Field Exam, Campus Examination/AUR, and Specialty Exam operations and manages issues affecting compliance across operating divisions to ensure consistent and fair treatment of all taxpayers.

8. Coordinates with stakeholders such as Appeals, Counsel, Taxpayer Advocate Service, Stakeholder Liaison, Disclosure, and the Office of Planning, Programming and Audit Coordination to support the delivery of key strategic priorities and activities to improve program performance and/or service to taxpayers.


4. The following Directors report to the Director, Examination Headquarters:



   - Director, Examination Field and Campus Policy

   - Director, Specialty Examination Policy

   - Director, Examination Case Selection

   - Director, Examination Quality and Technical Support


**1.1.16.5.5.1** **(04-07-2025)**

##### Examination Field and Campus Policy

1. The mission of Examination Field and Campus Policy is to promote fair, consistent and effective administration of income tax examinations, document matching activities and compliance visits by SB/SE revenue agents, tax compliance officers and campus tax examiners; and the implementation of new legislation and additions or changes to forms that impact SB/SE taxpayers.

2. The Director, Examination Field and Campus Policy, reports to the Director, Examination Headquarters and is responsible for leading the design, development, and delivery of policy and guidance that impacts SB/SE taxpayers, SB/SE Campus Examination and Field Examination processes and document matching processes.

3. To accomplish the mission, the Director, Examination Field and Campus Policy:



1. Develops and distributes guidance on processes and procedures impacting Field and Campus Examination operations.

2. Assists examiners and other functions through one-on-one interactions.

3. Coordinates examination processes and procedures with internal and external stakeholders.

4. Partners with IRS communication offices to help educate stakeholders.

5. Monitors and reports progress and results on strategic actions and commitments.

6. Recommends and initiates actions when trends, issues, and business opportunities are identified through program reviews, monitoring and analysis, or by other internal/ external stakeholders.


4. The following program managers report to the Director, Examination Field and Campus Policy:



   - Program Manager, Field Examination General Processes

   - Program Manager, Field Examination Special Processes

   - Program Manager, IMF/AUR Policy

   - Program Manager, BMF Document Matching

   - Program Manager, Campus Exam and Field Support


**1.1.16.5.5.1.1** **(04-07-2025)**

###### Field Examination General Processes

1. The mission of Field Examination General Processes is to provide oversight, policy, and procedural guidance on standard examination processes to SB/SE Field examiners and managers.

2. The Program Manager, Field Examination General Processes, reports to the Director, Examination Field and Campus Policy.

3. To accomplish the mission, the Program Manager, Field Examination General Processes:



1. Develops and distributes technical and procedural guidance on a wide variety of examination processes.

2. Coordinates examination processes and procedures with internal and external stakeholders.

3. Partners with IRS communication offices to help educate taxpayers and practitioners on standard examination processes and taxpayer rights.

4. Recommends and initiates action to redesign Field Examination processes when trends, issues, and business opportunities are identified through program reviews, monitoring and analysis, or by other internal and external stakeholders.

5. Supports users of the Embedded Quality Review System (EQRS).

6. Provides technical review and support in the development and completion of technical training materials.


**1.1.16.5.5.1.2** **(04-07-2025)**

###### Field Examination Special Processes

1. The mission of Field Examination Special Processes is to provide oversight and policy and procedural guidance on specialized examination processes to SB/SE Field examiners and managers.

2. The Program Manager, Field Examination Special Processes, reports to the Director, Examination Field and Campus Policy.

3. To accomplish the mission the Program Manager, Field Examination Special Processes:



1. Develops and distributes technical and procedural guidance on specialized examination processes.

2. Coordinates examination processes and procedures with internal and external stakeholders.

3. Collaborates with other functions that rely on SB/SE to provide and train SB/SE Examination resources in order to implement strategies.

4. Partners with IRS communication offices to help educate taxpayers and practitioners on examination processes.

5. Recommends and initiates action to redesign examination processes when trends, issues and business opportunities are identified through program reviews, monitoring and analysis, or by other internal or external stakeholders.


**1.1.16.5.5.1.3** **(04-07-2025)**

###### IMF/AUR Policy

1. The mission of IMF/Automated Underreporter (AUR) Policy is to provide guidance and support to AUR operations by establishing policy and procedures, updating the IRM and providing training to Campus personnel to ensure delivery of the AUR program.

2. The Program Manager, IMF/AUR Policy, reports to the Director, Examination Field and Campus Policy.

3. To accomplish the mission the Program Manager, IMF/AUR Policy:



1. Sets and communicates policy, procedures, and guidance for AUR operations.

2. Conducts program reviews to ensure that policies are applied consistently across remote sites (compliance campuses).

3. Evaluates impact of legislative changes and customer feedback on processes and procedures and revises policy and procedures, as necessary.

4. Reviews customer satisfaction and quality data to identify improvement opportunities.

5. Updates IRM guidance and oversees the integration of policies and procedures in four IRMs.

6. Determines business requirements necessary for systems, coordinates with campus operations and Information Technology regarding programming and equipment requirements.


**1.1.16.5.5.1.4** **(04-07-2025)**

###### BMF Document Matching

1. The mission of Business Master File (BMF) Document Matching is to provide Servicewide policy guidance on compliance processes related to campus BMF document matching operations.

2. The Program Manager, BMF Document Matching, reports to the Director, Examination Field and Campus Policy.

3. To accomplish this mission, the Program Manager, BMF Document Matching:



1. Sets policy, establishes procedures and guidelines, and provides training and oversight for remote compliance programs including Business Underreporter (BUR), IRS and Social Security Administration (SSA), Combined Annual Wage Reporting (CAWR), Federal Unemployment Tax Act (FUTA), Information Returns Penalty (IRP), and Ministerial Waivers.

2. Develops remote oversight processes and procedures featuring key business performance indicators.

3. Conducts program reviews to ensure that policies are applied consistently and to identify improvement opportunities.

4. Revises policies as required and redesigns processes as necessary resulting from legislative changes, identified best practices and customer feedback.

5. Monitors quality measures along with customer satisfaction for improvement opportunities.

6. Collaborates with various campus locations and other areas that impact work such as the Office of Servicewide Penalties and Information Technology.

7. Collaborates with external stakeholders such as the SSA and other IRS officers to ensure accuracy of information sharing and adherence to legislative mandates.


**1.1.16.5.5.1.5** **(04-07-2025)**

###### Campus Exam and Field Support

1. The mission of Campus Exam and Field Support is to provide Servicewide policy guidance on compliance processes that relate to campus examination operations and support Field and Specialty Examination programs in SB/SE and Large Business & International (LB&I).

2. The Program Manager, Campus Exam and Field Support, reports to the Director, Examination Field and Campus Policy.

3. To accomplish this mission, the Program Manager, Campus Exam and Field Support:



1. Provides oversight and guidance for campus examination programs and coordinates the issuance of new or revised policy directives to all impacted stakeholders.

2. Ensures that policies are applied consistently across operations through program reviews, data analysis and monitoring.

3. Recommends and initiates action to redesign Field Examination processes when trends, issues, and business opportunities are identified through program reviews, monitoring and analysis, or by other internal and external stakeholders.

4. Collaborates with the Campus Examination and Field offices regarding field support processes and coordinates with other Operating Divisions to provide support and guidance as needed.

5. Reviews quality data for paper and phone processes to identify improvement opportunities.

6. Provides input to the SB/SE Operating Division Strategic Plan.


**1.1.16.5.5.2** **(04-07-2025)**

##### Specialty Examination Policy

1. The mission of Specialty Examination Policy is to provide taxpayers top quality service by helping them understand and meet their Specialty Tax and Bank Secrecy Act (BSA) responsibilities, by establishing policies that allow for the effective and fair application of Specialty tax and BSA laws.

2. The Director, Specialty Examination Policy, reports to the Director, Examination Headquarters.

3. To accomplish the mission, the Director, Specialty Examination Policy:



1. Formulates short and long-range program strategies, policies, and objectives for integration into Specialty Tax and BSA policies. Ensures a consistent approach; and designs programs that address and resolve complex policy issues.

2. Coordinates the timely implementation of new legislation in an efficient and comprehensive manner and communicates revised policies and guidance as appropriate.

3. Analyzes progress against strategic plans and ensures adherence to operational procedures and controls and identifies opportunities for improvement and efficiencies.

4. Coordinates Specialty Tax and BSA Program activities across SB/SE Examination Field and Campus operations and other operating divisions, with Counsel to provide Servicewide support, policies, and guidance.

5. Serves as the Agency representative in collaborative discussions with key stakeholders, such as the Financial Crimes Enforcement Network (FinCEN), to ensure initiatives and policies are formulated with appropriate consideration of taxpayer and stakeholder impact.


4. The following managers report to the Director, Specialty Examination Policy:



   - Program Manager, Bank Secrecy Act Policy

   - Program Manager, Employment Tax Policy

   - Program Manager, Estate & Gift Tax Policy

   - Program Manager, Excise Tax Policy;


**1.1.16.5.5.2.1** **(04-07-2025)**

###### Bank Secrecy Act (BSA) Policy

1. The mission of the BSA Policy is to establish effective policies and procedures, to support compliance with the Bank Secrecy Act.

2. The Program Manager, BSA Policy, reports to the Director, Specialty Examination Policy.

3. To accomplish the mission, the Program Manager, BSA Policy:



1. Advises the Director, Specialty Examination Policy, on all facets of BSA activities and furnishes information concerning policies and interpretations of federal laws and regulations.

2. Formulates short and long-range program strategies and policies specific to BSA customers that improve BSA compliance, strengthens enforcement activities and leverages resources through proactive partnerships.

3. Develops and implements Servicewide policies and strategies addressing money laundering.

4. Designs and efficiently executes implementation plans for new or revised statutes and regulations.

5. Provides program support and guidance to segments of the BSA community over which IRS has regulatory oversight.

6. Represents the IRS, along with Criminal Investigation, on the Bank Secrecy Act Advisory Group, the U.S. Treasury’s Anti-Money Laundering Task Force, and contacts with BSA regulatory agencies and industry groups.

7. Provides technical advice and assistance pertaining to audit techniques, emerging issues, and legal interpretations.

8. Partners with internal and external stakeholders, in particular FinCEN, to design, develop, and implement programs that help customers comply with the BSA applicable statutes, regulations, policies and filer obligations.

9. Recommends and initiates action to redesign field examination processes when trends, issues, and business opportunities are identified through program reviews, monitoring and analysis, or by other internal and external stakeholders.


**1.1.16.5.5.2.2** **(04-07-2025)**

###### Employment Tax Policy

1. The mission of the Employment Tax Policy is to establish effective policies and procedures, to support compliance with employment tax laws.

2. The Program Manager, Employment Tax Policy, reports to the Director, Specialty Examination Policy.

3. To accomplish the mission, the Program Manager, Employment Tax Policy:



1. Advises the Director, Specialty Examination Policy on all facets of employment tax activities and furnishes information pertaining to policies and interpretations of federal tax laws and regulations.

2. Formulates short and long-range program strategies to address the employment tax gap and develop policies and objectives specific to employment tax customers to improve employment tax compliance.

3. Delivers Servicewide employment tax procedural guidance and policies; communicates new or revised policies to field examiners and the public.

4. Provides technical advice and assistance pertaining to audit techniques, emerging issues, and legal interpretations.

5. Designs and executes implementation plans for new legislation.

6. Partners with internal stakeholders (i.e., Examination Operations, LB&I, TE/GE, Taxpayer Services, Counsel, etc.) to implement and support Servicewide employment tax initiatives.

7. Partners with Communications to design, develop, and publicize consistent messages to customers and stakeholders that facilitate understanding of applicable statutes, regulations, policies, and filer obligations.

8. Recommends and initiates action to redesign field examination processes when trends, issues, and business opportunities are identified through program reviews, monitoring and analysis, or by other internal and external stakeholders.


**1.1.16.5.5.2.3** **(04-07-2025)**

###### Estate and Gift Tax Policy

1. The mission of the Estate and Gift Tax Policy is to establish effective policies and procedures, to support compliance with estate, gift, and generation-skipping transfer tax laws.

2. The Program Manager, Estate and Gift Tax Policy, reports directly to the Director, Specialty Examination Policy.

3. To accomplish the mission, the Program Manager, Estate and Gift Tax Policy:



1. Advises the Director, Specialty Examination Policy, on all facets of estate, gift, and generation-skipping transfer tax activities, and furnishes information concerning policies and interpretations of federal laws and regulations.

2. Formulates short and long-range program strategies for Specialty Exam Estate and Gift Tax field examiners to address the underreporting gap for estate, gift, and generation skipping transfer tax and designs policies and objectives specific to estate, and gift tax customers to improve estate, gift, and generation-skipping tax compliance.

3. Designs and executes implementation plans for new legislation.

4. Coordinates delivery of Servicewide estate, gift and generation skipping transfer tax policies and procedural guidelines to field examiners and the public.

5. Provides Servicewide estate, gift and generation skipping transfer tax technical advice to field examiners and the public pertaining to audit techniques, emerging issues, and legal interpretations.

6. Partners with internal stakeholders (i.e. Examination Operations, LB&I, TE/GE, Taxpayer Services, Counsel, etc.) to implement and support Servicewide estate and gift and generation skipping transfer tax initiatives.

7. Recommends and initiates action to redesign field examination processes when trends, issues, and business opportunities are identified through program reviews, monitoring and analysis, or by other internal and external stakeholders.

8. Identifies and develops policies and best practices to address emerging examination issues at the national level and coordinates with the necessary business units and functions to work the issues.

9. Develops and delivers Estate and Gift Tax Examination education and outreach guidance in coordination with Communications to address internal and external stakeholder needs.


**1.1.16.5.5.2.4** **(04-07-2025)**

###### Excise Tax Policy

1. The mission of Excise Tax Policy is to establish effective policies and procedures, to support compliance with the excise tax laws.

2. The Program Manager, Excise Tax Policy, reports directly to the Director, Specialty Examination Policy.

3. To accomplish the mission, the Program Manager, Excise Tax Policy:



1. Advises the Director, Specialty Examination Policy, on all facets of excise tax activities, and furnishes information concerning policies and interpretations of federal tax laws and regulations.

2. Formulates short and long-range program strategies and policies to improve excise tax compliance.

3. Documents Servicewide excise tax procedural guidelines and policies; communicates new or revised policies.

4. Provides technical advice and assistance pertaining to audit techniques, emerging issues, and legal interpretations.

5. Designs and executes implementation plans for new legislation.

6. Coordinates delivery of Servicewide excise tax procedural guidelines and policies to field examiners and the public.

7. Recommends and initiates action to redesign field examination processes when trends, issues, and business opportunities are identified through program reviews, monitoring and analysis, or by other internal and external stakeholders.


**1.1.16.5.5.3** **(04-07-2025)**

##### Exam Case Selection

1. The mission of Exam Case Selection is to provide process and procedural guidance to Field, Campus, Bank Secrecy Act, and Specialty Examination on selection of cases and delivery of inventory, provide input on the work plan, and set direct assignment criteria for routing of examination work.

2. The Director, Exam Case Selection, reports to the Director, Examination Headquarters.

3. To accomplish the mission the Director, Exam Case Selection:



1. Provides centralized oversight and program coordination of workload selection and classification for nationwide compliance functions.

2. Develops standardized policy and program direction for ordering, classifying, and delivering returns.

3. Sets direct assignment criteria for routing of examination work to examiners.

4. Provides input to the Examination work plan.

5. Provides input to the SB/SE Strategic Plan.

6. Oversees the development of decision support tools to shift the emphasis to risk-based compliance by partnering with Research, Applied Analytics and Statistics, and SB/SE Research to study compliance patterns and improve examination resource allocation.


4. The following managers report to Director, Exam Case Selection:



   - Program Manager, Field Case Selection

   - Program Manager, Campus Case Selection

   - Program Manager, Document Matching Analysis and Case Selection

   - Program Manager, Bank Secrecy Act Case Selection

   - Program Manager, Employment/Estate & Gift Case Selection

   - Program Manager, Excise Case Selection


**1.1.16.5.5.3.1** **(04-07-2025)**

###### Field Case Selection

1. The mission of Field Case Selection is to provide process and procedural guidance on the selection of cases and delivery of inventory for field examination.

2. The Program Manager, Field Case Selection, reports to the Director, Exam Case Selection.

3. To accomplish the mission the Program Manager, Field Case Selection:



1. Implements policies related to case selection and reviews progress towards delivering against the Examination work plan.

2. Provides centralized oversight and program coordination of workload selection and classification for nationwide field compliance functions including programs coordinated by DIF campus ordering unit.

3. Develops standardized policy and program direction for ordering, classifying, and delivering returns.

4. Provides input to the SB/SE Division Strategic Plan.

5. Provides information to the Area Planning and Special Programs (PSP) managers for workload delivery.

6. Provides input to the Examination work plan.


**1.1.16.5.5.3.2** **(06-01-2016)**

###### Campus Case Selection

1. The mission of Campus Case Selection is to select and deliver returns for potential examination issues to campus correspondence examination.

2. The Program Manager, Campus Case Selection, reports to the Director, Exam Case Selection.

3. To accomplish the mission the Program Manager, Campus Case Selection:



1. Provides support and guidance on any workload selection related issues during the examination process.

2. Oversees workload selection for correspondence examination based on the annual work plan and through program reviews.

3. Coordinates with the Exam Planning and Performance Analysis (PPA) team regarding changes in workload availability and inventory deliveries.

4. Analyzes examination results and modifies selection criteria as needed based on examination closed case results.

5. Provides input to the Examination work plan.

6. Provides input to the SB/SE Strategic Plan.


**1.1.16.5.5.3.3** **(04-07-2025)**

###### Document Matching Analysis and Case Selection

1. The mission of Document Matching Analysis and Case Selection is to identify, select and deliver inventory for the IMF/AUR and BMF/BUR document matching programs within the campuses.

2. The Program Manager, Document Matching Analysis and Case Selection, reports to the Director, Exam Case Selection.

3. To accomplish the mission the Program Manager, Document Matching Analysis and Case Selection:



1. Establishes internal controls relating to each program or process.

2. Ensures instructions are communicated to and carried out by the assigned employees.

3. Sets policy, establishes procedures and guidelines, and ensure they are applied consistently.

4. Revises policies as required and redesigns processes as necessary resulting from legislative changes.

5. Performs managerial reviews of selection decisions during each phase of the selection and delivery process.

6. Reviews and approves the business requirements written for case selection and Uniform Work Request annually.

7. Provides input on the IMF/AUR and BMF work plans.

8. Identifies campus IRDM workload, providing oversight and program coordination.

9. Provides input to the SB/SE Division Strategic Plan.


**1.1.16.5.5.3.4** **(06-01-2016)**

###### Bank Secrecy Act (BSA) Case Selection

1. The mission of BSA Case Selection is to manage the selection, classification, and delivery of inventory for Specialty Examination, BSA Examination.

2. The Program Manager, BSA Case Selection reports directly to the Director, Exam Case Selection.

3. To accomplish the mission the Program Manager, BSA Case Selection :



1. Implements procedures and guidance related to case selection and review progress towards delivering against the BSA Examination work plan.

2. Provides centralized oversight and program coordination of workload selection, classification, and delivery for Specialty Tax, BSA Title 31 examination, and Title 26: Form 8300 information reporting compliance.

3. Collaborates with Director of Specialty Examination, Specialty Examination Policy, and Examination Field offices when warranted.

4. Develops standardized policy and program direction for ordering, classifying, and delivering workload to support plan goals.

5. Monitors Specialty BSA Examination inventory and timely delivers inventory to support program goals, and strategic plan objectives.

6. Supports development of workload initiatives to identify areas of noncompliance.

7. Provides input to the Specialty BSA Examination work plan.

8. Provides input to the SB/SE Division Strategic Plan.

9. Provides input to the Specialty BSA Examination workload studies.


**1.1.16.5.5.3.5** **(04-07-2025)**

###### Employment and Estate & Gift Case Selection

1. The mission of Employment and Estate & Gift Case Selection is to manage the selection, classification, and delivery of inventory for Specialty Examination Employment and Estate & Gift Tax programs.

2. The Program Manager, Employment and Estate & Gift Case Selection, reports to the Director, Exam Case Selection.

3. Employment and Estate & Gift Case Selection is comprised of Employment Workload Selection and Delivery (WSD) and Estate & Gift Workload Selection and Delivery (WSD).


**1.1.16.5.5.3.5.1** **(04-07-2025)**

###### Employment Workload Selection and Delivery

1. The mission of Employment Workload Selection and Delivery (WSD) is to manage the selection, classification and delivery for Specialty Examination, Employment Tax.

2. The Manager, Employment (WSD) reports to the Program Manager, Employment and Estate & Gift Tax Case Selection.

3. To accomplish the mission the Program Manager, Employment WSD:



1. Implements procedures and guidance related to case selection and reviews progress towards delivering against the Employment Tax Examination work plan.

2. Provides centralized oversight and program coordination of workload selection, classification, and delivery for Specialty Employment Tax and information reporting compliance.

3. Collaborates with Director of Specialty Examination and Specialty Examination Policy when warranted.

4. Develops processes and procedures, classifies and delivers workload to support plan goals.

5. Monitors Specialty Employment Tax Examination inventory and timely delivers inventory to support program goals and strategic plan objectives.

6. Supports development and maintenance of workload initiatives to provide the best possible work for field operations.

7. Provides input to the Specialty Employment Tax Examination work plan.

8. Provides input to the SB/SE Division Strategic Plan.

9. Provides input to the Specialty Employment Tax Examination workload studies.


**1.1.16.5.5.3.5.2** **(04-07-2025)**

###### Estate and Gift Workload Selection and Delivery

1. The mission of the Estate and Gift Workload Selection and Delivery (WSD) is to manage the selection, classification, and delivery of inventory for Specialty Examination, Estate and Gift.

2. The Manager, Estate and Gift Tax WSD reports directly to the Program Manager, Employment and Estate & Gift Tax Case Selection.

3. To accomplish the mission the Program Manager, Estate and Gift Tax WSD:



1. Implements procedures and guidance related to case selection and reviews progress towards delivering against the Estate and Gift Examination work plan.

2. Provides centralized oversight and program coordination of workload selection, classification, and delivery for Specialty Estate and Gift Tax, and information reporting compliance.

3. Collaborates with Director of Specialty Examination, Specialty Examination Policy, and Examination Field offices when warranted.

4. Develops procedures and guidance for ordering, classifying, and delivering workload to support plan goals.

5. Monitors Specialty Estate and Gift Tax Examination inventory and timely delivers inventory to support program goals and strategic plan objectives.

6. Supports development and maintenance of workload initiatives to provide the best possible work for field operations.

7. Provides input to the Specialty Estate and Gift Tax Examination work plan.

8. Provides input to the SB/SE Division Strategic Plan.

9. Provides input to the Specialty Estate and Gift Tax Examination workload studies.


**1.1.16.5.5.3.6** **(04-07-2025)**

###### Excise Case Selection

1. The mission of Excise Case Selection is to manage the selection, classification, and delivery of inventory for Specialty Examination Excise Tax program.

2. The Program Manager, Excise Case Selection, reports to the Director, Exam Case Selection.

3. Excise Case Selection is comprised of Excise Workload Selection and Delivery (WSD) and Excise Joint Operations Center (JOC).


**1.1.16.5.5.3.6.1** **(06-01-2016)**

###### Excise Workload Selection and Delivery

1. The mission of Excise Workload Selection and Delivery (WSD) is to manage the selection, classification, and delivery of inventory for Specialty Examination, Excise Tax program.

2. The Manager, Excise (WSD) reports to the Program Manager, Excise Case Selection.

3. To accomplish the mission, the Manager, the Excise WSD:



1. Implements procedures and guidance related to case selection and reviews progress towards delivering against the Excise Tax Examination work plan.

2. Provides centralized oversight and program coordination of workload selection, classification, and delivery for Specialty Excise Tax and information reporting compliance.

3. Collaborates with Director of Specialty Examination and Specialty Examination Policy, when warranted.

4. Develops procedures and guidance for ordering, classifying, and delivering workload to support plan goals based on the Fairness Act (Policy Statement P-1-236).

5. Monitors Specialty Excise Tax Examination inventory and timely delivers inventory to support program goals, and strategic plan objectives.

6. Supports development and maintenance of workload initiatives to provide the best possible leads for WSD classification.

7. Provides input to the Specialty Excise Tax Examination work plan.

8. Provides input to the SB/SE Division Strategic Plan.

9. Provides input to the Specialty Excise Examination workload studies.


**1.1.16.5.5.3.6.2** **(04-07-2025)**

###### Joint Operations Center (JOC)

1. The Excise Joint Operations Center (JOC) is to use data driven approaches to identify areas of potential excise tax non-compliance. The JOC was established as a partnership between federal and state motor fuel taxing authorities. Since inception it has evolved into a technical foundation for a common data repository that supports the innovative use of technology to collect, analyze, and share information in an effort to identify quality tax compliance leads.

2. The Manager, JOC reports to the Program Manager, Excise Case Selection.

3. To accomplish the mission the Manager, JOC:



1. Collaborates with subject matter experts to develop and maintain workload initiatives that address areas of non-compliance and to provide the best possible work for further classification and enforcement efforts.

2. Identifies questionable activities and tax evasion schemes using data-mining technologies, predictive analytics technology, link-analysis tools, and other forensic-type tools and techniques.

3. Fosters state, federal and multi-national cooperation in the strategic analyses of tax compliance trends and patterns.

4. Identifies, acquires, and integrates federal, state, and other third-party data that change to effect tax compliance.

5. Develops baselines for measuring improvement in tax compliance activities.

6. Collects, analyzes, and shares information to facilitate tax compliance activities.


**1.1.16.5.5.4** **(04-07-2025)**

##### Exam Quality and Technical Support

1. The mission of Exam Quality and Technical Support is to provide technical guidance for a variety of technical tax examination topics and issues, implement new and updated tax law provisions and support Field, Campus and Specialty Exam Quality.

2. The Director, Exam Quality and Technical Support, reports to the Director, Examination, Headquarters.

3. To accomplish the mission the Director, Exam Quality and Technical Support:



1. Oversees program coordination for technical tax issues and provides technical tax law support, including developing guidance, responding to inquiries, developing and delivering training, and maintaining written technical materials.

2. Coordinates the implementation of new and updated legislation across IRS and communicates revised policies and guidance as appropriate.

3. Develops and delivers mission-oriented strategies, identifies and addresses emerging issues, and other potential areas of noncompliance.

4. Coordinates with other operating divisions to provide support and guidance for technical tax law provisions with a Servicewide effect.

5. Publishes quarterly editions of the SB/SE Technical Digest.

6. Supports SB/SE’s quality improvement program through National Quality Review System (NQRS) reviews and feedback for Field, Campus, and Specialty Examination.


4. The following program managers report to the Director, Exam Quality and Technical Support:



   - Program Manager,Technical Support Group 1

   - Program Manager, Technical Support Group 2

   - Program Manager, Technical Support Group 3

   - Program Manager, Technical Support Group 4

   - Program Manager, Campus Exam Quality

   - Program Manager, Field and Specialty Exam Quality


**1.1.16.5.5.4.1** **(04-07-2025)**

###### Technical Support Group 1

1. The mission of Technical Support Group 1 is to promote fair, consistent and effective administration of income tax examinations as well as identify trends, emerging issues, develop strategies to address the needs of SB/SE examiners by implementing new tax legislation, supporting communication offices, managing tax forms and publications by educating SB/SE examiners, SB/SE taxpayers and practitioners through a comprehensive approach including education, outreach, and enforcement .

2. The Program Manager, Technical Support Group 1, reports to the Director, Exam Quality and Technical Support.

3. To accomplish the mission the Program Manager, Technical Support Group 1:



1. Provides technical support concerning audit techniques, tax law interpretation, technical training and development, and program monitoring.

2. Provides oversight for programs of select Internal Revenue Code sections requiring co-administration with other federal government and/or state agencies (e.g., Activities Not Engaged in For Profit (IRC 183), Contributions (IRC 170), Depreciation (IRC 167), Limitation on Business Interest (IRC 163(i)), Low Income Housing Credit (IRC 42), Marijuana (IRC 280E), Net Operating Losses (IRC 172), Passive Activity Losses (IRC 469), Qualified Business Income Deduction (IRC 199A), and Rehabilitation Tax Credit (IRC 47).

3. Coordinates the implementation of the following Inflation Reduction Act of 2022 provisions: Residential Clean Energy Credit (IRC 25D), Energy Efficient Home Credit (IRC 45L) and the Energy Efficient Commercial Buildings Deduction (IRC 179D).

4. Develops and coordinates compliance issues, both legislative and procedural, through coordination with both internal and external stakeholders.


**1.1.16.5.5.4.2** **(04-07-2025)**

###### Technical Support Group 2

1. The mission of Technical Support Group 2 is to identify trends, emerging issues, and develop strategies to address the needs of SB/SE examiners and taxpayers through guidance, education, outreach and enforcement efforts related to digital assets, research and experimentation credits, pass-through entities and other technical issues.

2. The Program Manager, of the Technical Support Group 2, reports to the Director, Exam Quality and Technical Support.

3. To accomplish the mission the Program Manager, Technical Support Group 2:



1. Coordinates and collaborates compliance strategies for digital assets, research and experimentation credits, and other technical issues with LB&I, TE/GE, Special Examination, Office of Fraud Enforcement and Counsel.

2. Manages the SB/SE Examination Emerging Issues Program under IRM 4.34.1, SB/SE Emerging Issues Process.

3. Evaluates merging issues through the emerging issue process and implements compliance plans to address significant areas of potential non-compliance.

4. Provides technical tax law support, including the development of audit techniques, development and delivering technical training, program monitoring and responding to inquiries for issues identified through the Emerging Issues Program.

5. Develops and coordinates compliance issues, both legislative and procedural, through coordination with both internal and external stakeholders.


**1.1.16.5.5.4.3** **(04-07-2025)**

###### Technical Support Group 3

1. The mission of the Technical Support Group 3 is to implement new tax law legislation, including Clean Vehicle Credits and Opportunity Zones, and maintain the SB/SE Examination content on the IRS Virtual Library to provide additional technical support and guidance to examiners.

2. The Program Manager, Technical Support Group 3, reports to the Director, Exam Quality and Technical Support.

3. To accomplish the mission the Program Manager, Technical Support Group 3:



1. Oversees implementation of new legislation, including the development of associated compliance plans, development of guidance and/or training for impacted employees and shares information externally to foster taxpayer compliance with tax law changes.

2. Ensures key policy, compliance, and operational challenges of new legislative changes are promptly identified to facilitate timely and detailed implementation planning.

3. Establishes management and program oversight structures that will help guide implementation activities.

4. Collaborates across IRS to address Servicewide needs, including collaboration with Counsel, LB&I, Taxpayer Services, TE/GE, Communications & Liaison, Information Technology, Office of the Chief Financial Officer, and other SB/SE organizations.

5. Collaborates externally with other government agencies, including Department of Treasury, Department of Energy, Bureau of the Fiscal Services, etc.

6. Updates and maintains content in the IRS Virtual Library.


**1.1.16.5.5.4.4** **(04-07-2025)**

###### Technical Support Group 4

1. The mission of Technical Support Group 4 is to implement new tax law legislation, including Clean Vehicle Credits.

2. The Program Manager, Technical Support Group 4, reports to the Director, Exam Quality and Technical Support.

3. To accomplish the mission the Program Manager, Technical Support Group 4:



1. Oversees implementation of new legislation, including the development of associated compliance plans, development of guidance and/or training for impacted employees and shares information externally to foster taxpayer compliance with tax law changes.

2. Ensures key policy, compliance, and operational challenges of new legislative changes are promptly identified to facilitate timely and detailed implementation planning.

3. Establishes management and program oversight structures that will help guide implementation activities.

4. Collaborates across IRS to address Servicewide needs, including collaboration with Counsel, LB&I, Taxpayer Services, TE/GE, Communications & Liaison, Information Technology, Office of the Chief Financial Officer, and other SB/SE organizations.

5. Collaborates externally with other government agencies, including Department of Treasury, Department of Energy, Bureau of the Fiscal Services, etc.


**1.1.16.5.5.4.5** **(04-07-2025)**

###### Campus Exam Quality

1. The mission of Campus Exam Quality is to administer the quality measurement system for Campus Exam by monitoring case work or telephone contacts and maintaining the integrity of the data in the Embedded Quality Review System for diagnostic Campus National Reviews.

2. The Program Manager, Campus Exam Quality, reports directly to the Director, Exam Quality and Technical Support.

3. To accomplish the mission the Program Manager, Campus Exam Quality:



1. Develops and maintains the framework for organizational performance measures.

2. Works in conjunction with Taxpayer Services Accounts Management to maintain database coding consistency.

3. Provides attribute coding direction and guidance to Quality Reviewers based on the Internal Revenue Manual requirements.

4. Monitors the quality program adherence including coding of review and the sampling process.

5. Coordinates with IRM authors to clarify and update procedural requirements.

6. Provides expert support and assistance to organizational performance initiatives.

7. Develops and implements procedures and methodologies for ongoing analysis, assessment, and monitoring of Campus Exam performance.

8. Coordinates with the National Support Staff (NSS) to execute systemic adjustments and updates as systems and procedures change.

9. Coordinates with the Joint Operation Center to ensure that the Contact Recording System is functional and resolves daily issues.


**1.1.16.5.5.4.6** **(04-07-2025)**

###### Field and Specialty Exam Quality

1. The mission of the Field and Specialty Exam Quality is to support SB/SE’s quality initiatives by collecting data, measuring examination quality, and assessing the long-term trends of performance, in keeping with the balanced measures. Field and Specialty Exam Quality evaluates the quality of examination cases based on specific measurement criteria, referred to as quality attributes.

2. The Field and Specialty Exam Quality Program Manager, reports to the Director, Exam Quality and Technical Support.

3. To accomplish the mission the Program Manager, Field and Specialty Exam Quality.



1. Develops the annual sample plans for Field and Specialty Examination quality case reviews, based upon guidance provided by SB/SE Research.

2. Oversees program performance by determining examination quality through applying defined quality attributes to statistically valid samples of closed examinations.

3. Provides analysis of quality data and monitors trends affecting the quality of examination work.

4. Collaborates with the programs to identify quality improvement opportunities, supports improvement actions and shares best practices.

5. Provides recommendations to enhance the National Quality Review System

6. Publishes quarterly editions of the SB/SE Technical Digest.


**1.1.16.5.6** **(04-07-2025)**

#### Examination Customer Coordination and Innovation Office

1. The mission of the Examination Customer Coordination and Innovation Office (ECCIO) is to ensure there is a dedicated focus and concerted effort in moving SB/SE Examination toward the use of modern technology to improve the taxpayer and employee experience through enhanced efficiencies.

2. The ECCIO Program Manager reports to the Director and Deputy Director, Examination.

3. To accomplish the mission, the ECCIO Program Manager:




| ECCIO Responsibilities |
| --- |
| Fosters an atmosphere where innovation is a priority. |
| Connects the right stakeholders to advance priority initiatives. |
| Identifies areas where process improvements and efficiencies will enhance the taxpayer experience. |
| Provides a one-stop customer service for the management of modernization initiatives. |
| Capitalizes on existing technology to determine if it could benefit other Examination functions. |
| Partners with IT, Technology Solutions and SB/SE Collection to deploy new technology to improve processes. |
| Supports the delivery of key strategic priorities and activities to improve program performance and/or service to taxpayers. |
| Provides project management and facilitation for Examination innovation and modernization initiatives. |
| Promotes process improvements to improve employee satisfaction. |
| Identifies the cost benefits of using modern technology for the IRS. |
| Reviews recommendations from TIGTA or GAO audits that involve enhancements to existing technology to determine the feasibility of implementing changes. |

4. The two Front-line Managers report to the ECCIO Manager:



   - Sub Team 1

   - Sub Team 2


**1.1.16.6** **(04-07-2025)**

### Operations Support

1. The mission of Operations Support is to provide centralization of all SB/SE support functions, in a customer centric environment, to ensure SB/SE Collection and Examination are properly equipped with the tools and resources to execute compliance activities.

2. The Director, Operations Support, reports to the Deputy Commissioner, SB/SE.

3. To accomplish this mission, the Director, Operations Support oversees distinct support functions, providing streamlined executive leadership, accountability and responsibility.

4. The following executive positions report to the Director, Operations Support:



   - Director, Technology Solutions

   - Director, Business Support

   - Director, SB/SE Human Capital Office

   - Director, Business Development


**1.1.16.6.1** **(04-07-2025)**

#### Technology Solutions

1. The mission of Technology Solutions is to provide innovative technology solutions and support to facilitate effective and efficient tax administration.

2. The Director, Technology Solutions, reports to the Director, Operations Support.

3. The following managers report to the Director, Technology Solutions:



   - Program Manager, Collection Systems & Projects

   - Program Manager, Capital Planning & Investment Control

   - Program Manager, Business Data Solutions

   - Program Manager, Business Systems Planning

   - Program Manager, Report Generation Software & Correspondence Examination Automation Support

   - Program Manager, Exam Systems & Projects

   - Program Manager, Project Management Office

   - Program Manager, Business Modernization Support


**1.1.16.6.1.1** **(06-01-2016)**

##### Collection Systems & Projects

1. The mission of Collection Systems & Projects is to provide Collection with innovative technology solutions and system support to facilitate effective tax administration.

2. The Manager, Collection Systems & Projects reports to the Director, Technology Solutions.

3. The following managers report to the Manager, Collection Systems & Projects:



   - Manager, Automated Liens-Entity

   - Manager, Collection Systems

   - Manager, Collection Projects


**1.1.16.6.1.2** **(04-07-2025)**

##### Capital Planning & Investment Control

1. The mission of Capital Planning & Investment Control is to facilitate strategic investment decision-making and efficient use of technology.

2. The Manager, Capital Planning & Investment Control, reports to the Director, Technology Solutions.

3. The following managers report to the Manager, Capital Planning & Investment Control:



   - Manager, Communications Intake & Governance

   - Manager, Demand & Investment Support


**1.1.16.6.1.3** **(04-07-2025)**

##### Business Data Solutions

1. The mission of Business Data Solutions is to provide technology solutions and support services for improving business process efficiencies and empowering our customers to effectively utilize available enterprise tools.

2. The Manager, Business Data Solutions, reports to the Director, Technology Solutions.

3. The following managers report to the Manager, Business Data Solutions:



   - Manager, Business Systems Design & Develoopment

   - Manager, SharePoint Solutions & Support


**1.1.16.6.1.4** **(04-07-2025)**

##### Business Systems Planning

1. The mission of the Business Systems Planning (BSP) organization is to be the focal point for addressing SB/SE customers’ Information Technology equipment and software support and security oversight.

2. The Manager, Business Systems Planning, reports to the Director of Technology Solutions.

3. The following managers report to the Manager, Business Systems Planning:



   - Manager, Customer Service Support

   - Manager, Security Service Support


**1.1.16.6.1.5** **(04-07-2025)**

##### Report Generation Software Support & Correspondence Examination Automation Support

1. This mission of Report Generation Software Support & Correspondence Examination Automaton Support (RGS & CEAS) is to provide continued support for RGS and CEAS software products.

2. The Manager, RGS & CEAS reports to the Director, Technology Solutions.

3. The following managers report to the Manager, RGS & CEAS:



   - Manager, Automation Requirements and Testing

   - Manager, Exam Applications Support Team

   - Manager, Customer Service Liaison


**1.1.16.6.1.6** **(04-07-2025)**

##### Examination Systems & Projects

1. The mission of Examination Systems & Projects is to provide all Exam customers with quality system support and timely data delivery to facilitate effective tax administration.

2. The Manager, Examination Systems & Projects reports to the Director, Technology Solutions.

3. The following managers report to the Manager, Examination Systems & Projects:



   - Manager, General Exam Systems Support

   - Manager, System Development & Data Delivery

   - Manager, Specialty Exam Systems Support


**1.1.16.6.1.7** **(04-07-2025)**

##### Project Management Office

1. The mission of the Project Management Office is to provide future state technology solutions through strategic use of project management and business analysis disciplines in collaboration with IRS stakeholders including customers and partners.

2. The Manager, Project Management Office, reports to the Director, Technology Solutions.

3. The following managers report to the Manager, Project Management Office:



   - Manager, Project Support Team 1

   - Manager, Project Support Team 2


**1.1.16.6.1.8** **(04-07-2025)**

##### Business Modernization Support

1. The mission of Business Modernization Support is to provide leadership, support, management and oversight of the enterprise information technology initiatives and online services to IRS compliance functions and business programs focused on improving and modernizing taxpayer tools and business processes that drives strategic direction and enables transformation.

2. The Manager, Business Modernization Support, reports to the Director, Technology Solutions.

3. The following managers report to the Manager, Business Modernization Support:



   - Manager, Business Technology Management

   - Manager, Business Transformation Support


**1.1.16.6.2** **(04-07-2025)**

#### Business Support Office

1. The mission of the Business Support Office is to guide SB/SE’s financial planning and budgeting processes by promoting strategic resource allocation and sound fiscal management. Also, to provide guidance and oversight of programs having Servicewide impact by coordinating and collaborating with customers.

2. The Director, Business Support Office reports to the Director, Operations Support.

3. To accomplish the mission, the Director, Business Support Office:



1. Provides sound financial oversight and management of SB/SE’s resources \[dollars (full-time equivalents)\].

2. Provides relevant, quality and timely data and services to facilitate management decisions.

3. Oversees the process of formulating multiple year budgets consistent with the SB/SE Strategic Plan.

4. Manages the resource distribution process, including the development of a financial plan that supports the program priorities of SB/SE.

5. Conducts financial reviews and develops recommendations to achieve a balanced financial plan.

6. Brings discipline to business processes by creating efficiencies to eliminate burden on stakeholders.

7. Establishes and implements financial policies, procedures, and controls in conjunction with the overall Service's guidelines.

8. Leads execution and delivery of Servicewide programs to provide policy and guidance to ensure consistent and accurate administration of interest and penalty programs.


4. The following managers report to the Director, Business Support:



   - Program Manager, Workforce and Program Analysis

   - Program Manager, Support Resources & Analysis

   - Program Manager, Budget and Contract Oversight

   - Program Manager, Office of Servicewide Penalties

   - Program Manager, Office of Servicewide Interest


**1.1.16.6.2.1** **(04-07-2025)**

##### Workforce and Program Analysis

1. The mission of Workforce and Program Analysis is to provide financial oversight for certain aspects of the SB/SE budget.

2. The Manager, Workforce and Program Analysis, reports to the Director, Business Support Office.

3. To accomplish the mission, the Manager, Workforce and Program Analysis:



1. Provides financial oversight and serves as POC for Enforcement, Labor Analysis, Hiring, Overtime, Private Debt Collection (Retained Earnings), Federal Highway, Awards (policy & budget), Business Performance Review and SB/SE POC – Reimbursables/G-Invoicing.

2. Serves as Disaster Coordinator and SETR POC.


4. The following managers report to the Manager, Workforce and Program Analysis



   - Manager, Labor Analysis Team

   - Manager, Specialized Programs and Enforcement Team


**1.1.16.6.2.2** **(04-07-2025)**

##### Support Resources & Analysis

1. The mission of Support Resources & Analysis is to provide financial oversight for certain aspects of the SB/SE budget.

2. The Manager, Support Resources & Analysis reports to the Director, Business Support Office.

3. To accomplish the mission, the Manager, Support Resources & Analysis:



1. Serves as the SB/SE Budget POC for training, program travel, printing, non-IT equipment, relocation and moving expenses, supply and purchase card programs. Also serves as the SB/SE POC for the Procurement for Public Sector (PPS) system, cost accounting, SROCs, and the Financial Performance Data Scorecard.

2. Coordinates event spending requests/approvals, including the dissemination of policy and guidance.


4. The following managers report to the Manager, Support Resources & Analysis:



   - Manager, Services, Supplies & Support Team

   - Manager, Equipment, Print & Travel Team


**1.1.16.6.2.3** **(04-07-2025)**

##### Budget and Contract Oversight

1. The mission of Budget and Contract Oversight is to provide financial oversight of the SB/SE budget.

2. The Manager, Budget and Contract Oversight, reports to the Director, Business Support Office.

3. To accomplish the mission, Budget and Contract Oversight:



1. Serves as the first POC for SB/SE Operations Directors on financial requests and the primary liaison for CFO-Corporate Budget.

2. Serves as the SB/SE POC for formulation and investments, financial plan development, budget execution, financial reporting, and enterprise unfunded requests, maintaining current and outyear budgets, and workforce planning coordination.

3. Provides SB/SE non-IT contract management oversight, funding, and vendor inquiries.


4. The following managers report to the Manager, Budget and Contract Oversight:



   - Manager, Budget and Workforce Planning

   - Manager, Contract Oversight Team


**1.1.16.6.2.4** **(04-07-2025)**

##### Office of Servicewide Penalties

1. The mission of Office of Servicewide Penalties (OSP) is to promote fair, consistent and accurate application and use of civil penalties in order to encourage voluntary compliance through penalty policy guidance and support.

2. The Manager, Office of Servicewide Penalties, reports to the Director, Business Support Office.

3. To accomplish the mission, the Manager, OSP:



1. Provides Servicewide coordination of policy and procedures concerning the administration of over 200 civil penalties.

2. Performs quality reviews on penalty assessments and abatements.

3. Conducts studies and analysis of the penalty impact on voluntary compliance.


4. The Manager, OSP SME Group reports to the Manager, Office of Servicewide Penalties


**1.1.16.6.2.5** **(04-07-2025)**

##### Office of Servicewide Interest

1. The mission of Office of Servicewide Interest (OSI) is to promote both accuracy and consistency of interest computations across all Business Operating Divisions through coordination of policy and procedures.

2. The Manager, Office of Servicewide Interest, reports to the Director, Business Support Office.

3. To accomplish the mission, the Manager OSI:



   - Provides Servicewide policy and technical guidance, resources and computational tools, training curriculum, measurement of manual interest computations, and outreach and collaboration to promote manual and systemic interest accuracy on taxpayer accounts.

   - Performs interest assessment quality reviews and conducts studies and analysis of interest computation accuracy.


4. The following managers report to the Manager, Office of Servicewide Interest:



   - Manager, Complex Interest Quality Measurement System (CIQMS)

   - Manager, Operational Analysis Servicewide Interest (OASIS)


**1.1.16.6.3** **(04-07-2025)**

#### SB/SE Human Capital Office

1. The mission of the SB/SE Human Capital Office is to use a customer-oriented approach in collaborating with its partners to design, develop, and deliver business strategies and solutions for SB/SE’s human capital needs in support of IRS strategic goals.

2. The Director, SB/SE Human Capital Office, reports to the Director, Operations Support.

3. To accomplish this mission, the Director, SB/SE Human Capital Office:



1. Oversees the development and implementation of human resource policies, guidelines and procedures for the SB/SE Division.

2. Manages the hiring plans and recruiting programs for SB/SE.

3. Collaborates with SB/SE operating units to develop and deliver a division-wide integrated training plan.

4. Oversees the establishment and maintenance of effective relationships with key internal and external stakeholders.

5. Coordinates organizational change policy and information management activities.


4. The SB/SE Human Capital Office Objectives are to:



1. Address operational training needs to ensure a skilled workforce by developing and providing effective and timely training products.

2. Provide customers with access to the tools, services and resources required to effectively deliver human capital and business continuity needs in support of SB/SE operational goals.

3. Partner with the SB/SE operating units to identify, recruit, and hire a qualified, diverse workforce to support the achievement of operational goals.

4. Provide quality customer service and administrative support for SB/SE’s human resource programs.

5. Effectively administer SB/SE’s leadership and employee engagement strategies to ensure leadership continuity and promote workforce engagement.

6. Ensure eligible taxpayers receive the appropriate level of tax relief after a federally declared disaster.


5. The following managers report to the Director, SB/SE Human Capital Office:



   - Chief, Collection Training

   - Chief, Operations Support & Cross-Functional Training

   - Chief, Examination Training

   - Chief, Organizational Support & Continuity of Operations

   - Chief, Workforce Management

   - Chief, Leadership Development & Support Office


**1.1.16.6.3.1** **(04-07-2025)**

##### Collection Training

1. The mission of Collection Training (CT) is to identify, design, develop and deliver an integrated learning program that addresses the strategic, business, and cultural needs of all Collection Functions, their employees, and the IRS.

2. The Chief, Collection Training, reports to the Director, SB/SE Human Capital Office.

3. To accomplish this mission, the Chief, Collection Training:



1. Works with the Collection Operations and Headquarters program owners to design, create and evaluate innovative technical training solutions utilizing a variety of delivery methods.

2. Coordinates with SB/SE leadership and other key constituents to ensure Collection training and learning supports organizational performance.

3. Partners with other SB/SE Human Capital components to ensure Collection learning requirements are part of recruiting, retention, succession planning, and workplace initiatives.

4. Develops a centralized SB/SE Collection Training plan and budget through an annual Needs Assessment Process (NAP) that incorporates training plan development, ITM administration, and overseeing the delivery of all Collection technical training.

5. Implements training efforts to ensure that courses and curriculum provide learning that is targeted to individual expertise and workload and is delivered when and where needed.

6. Develops innovative technology-based approaches to learning for employees and managers in Collection.


4. The following managers report to the Chief, Collection Training:



   - Manager, Collection Training Group 1

   - Manager, Collection Training Group 2

   - Manager, Collection Training Group 3

   - Manager, Collection Training Group 4

   - Manager, Collection Training Group 5


**1.1.16.6.3.2** **(04-07-2025)**

##### Operations Support & Cross-Functional Training

1. The mission of Operations Support & Cross-Functional Training is to identify, develop and deliver an integrated learning-program that addresses the strategic, business, and cultural needs of SB/SE and the IRS. Operations Support & Cross-Functional Training is responsible for the identification, development and delivery of training for all of Operations Support and SB/SE training needs that are not function-specific, and supports all SB/SE OUs in developing online training.

2. The Chief, Operations Support & Cross-Functional Training, reports to the Director, SB/SE Human Capital Office.

3. To accomplish this mission, the Chief Operations Support & Cross-Functional Training:



1. Coordinates with SB/SE leadership and other key constituents to ensure SB/SE training and learning supports organizational performance.

2. Partners with other SB/SE Human Capital components to ensure SB/SE learning requirements are part of recruiting, retention, succession planning, and workplace initiatives.

3. Proposes, develops, and executes a centralized SB/SE training plan and budget.

4. Collaborates with the Human Capital Office and other operating divisions and business units to design and develop integrated training solutions for cross-functional programs.

5. Implements training efforts to ensure that courses and curriculum provide learning that is targeted to individual expertise and workload and is delivered when and where needed.

6. Develops innovative technology-based approaches to learning for employees and managers in SB/SE.


4. The following managers report to the Chief, Operations Support & Cross- Functional Training:



   - Manager, Operations Support & Cross Functional Team

   - Manager, Technology Enabled Learning (TEL)

   - Manager, Cross Functional Training Delivery Team

   - Manager, Recruitment Team 1

   - Manager, Recruitment Team 2

   - Manager, Operations Support REA Training Team


**1.1.16.6.3.3** **(04-07-2025)**

##### Examination Training

1. The mission of Examination Training is to identify, develop and deliver an integrated learning-program that addresses the strategic, business, and cultural needs of SB/SE and the IRS. Examination Training is responsible for the identification, development and delivery of training for all of SB/SE Examination.

2. The Chief, Examination Training, reports to the Director, SB/SE Human Capital Office.

3. To accomplish this mission, the Chief, Examination Training:



1. Coordinates with SB/SE leadership and other key constituents to ensure Examination training and learning supports organizational performance.

2. Partners with other SB/SE Human Capital components to ensure Examination learning requirements are part of recruiting, retention, succession planning, and workplace initiatives.

3. Proposes, develops, and executes a centralized SB/SE Examination training plan and budget.

4. Implements training efforts to ensure that courses and curriculum provide learning that is targeted to individual expertise and workload and is delivered when and where needed.

5. Develops innovative technology-based approaches to learning for employees and managers in Examination.


4. The following managers report directly to the Director, Examination Training:



   - Manager, Examination Training Team 1

   - Manager, Examination Training Team 2

   - Manager, Examination Training Team 3

   - Manager, Examination Training Team 4

   - Manager, Examination Training Team 5


**1.1.16.6.3.4** **(04-07-2025)**

##### Organizational Support & Continuity of Operations

1. The mission of Organizational Support & Continuity of Operations is to ensure all SB/SE Operating Units are in a constant state of readiness to ensure IRS’ mission and essential functions are uninterrupted during major incidents and emergency situations. The office is also responsible for coordinating tax relief to taxpayers affected by federally declared disasters, and serves as the IRS representative to FEMA and other federal and state agencies. This office also oversees organizational support programs such as Internal Management Documents, Records and Risk Management, Employee Suggestions, and E-Trak Controlled Correspondence.

2. The Chief, Organizational Support & Continuity of Operations, reports to the Director, SB/SE Human Capital Office.

3. To accomplish this mission, the Chief, Organizational Support & Continuity of Operations partners with the SB/SE Division Operating Units enabling them to achieve their business goals and objectives within the following programs:



1. Health, Safety, and Security

2. Records Management

3. Internal Management Documents (IRMs, Policy Statements, and Delegation Orders)

4. Publishing Services Assistance -Internal Forms, Letters, Notices, IDRS Correspondence etc.

5. E-Trak

6. UNAX and Mandatory Briefing Certifications

7. Service Level Agreement – SB/SE & TAS

8. Emergency Preparedness and Continuity Planning


4. The following managers report to the Chief, Organizational Support & Continuity of Operations:



   - Manager, Organizational Support

   - Manager, Continuity of Operations

   - Manager, Corporate Shared Support


**1.1.16.6.3.5** **(04-07-2025)**

##### Workforce Management

1. The mission of Workforce Management (WM) is to provide paramount customer service in a timely and quality manner to our SB/SE customers specifically as it relates to staffing, hiring, and HR systems.

2. The Chief, WM reports, to the Director, SB/SE Human Capital Office.

3. To accomplish this mission, the Chief, Workforce Management develops, supports and executes strategies, processes, policies and programs to effectively achieve the hiring, recruitment and onboarding goals for SB/SE mission critical occupations, ad hoc, special programs and re-employed annuitants. HR Management also provides customer service and guidance on all facets of Human Resources to SB/SE, including: employment, pay, information systems, telework, job abolishment and associated mitigating strategies, and other related human resources issues.

4. The following managers report to the Chief of Workforce Management:



   - Manager, Exam Hiring Team

   - Manager, Collection/Operations Support Hiring Team

   - Manager, Collection & Exam Campus Hiring

   - Manager, Hiring Support Team 1

   - Manager, Hiring Support Team 2

   - Manager, Hiring Support Team 3

   - Manager, Hiring Support Team 4


**1.1.16.6.3.6** **(04-07-2025)**

##### Leadership Development & Support Office

1. The mission of the Leadership Development & Support Office is to advocate for and support current managers and aspiring leaders by administering leadership succession strategies and employee engagement in SB/SE as well as to provide advice, guidance and quality customer service to support organizational planning, managerial requirements, position management and labor relations.

2. The Chief of Leadership Development & Support Office, reports to the Director, SB/SE Human Capital Office.

3. To accomplish this mission, the Chief, Leadership Development & Support Office partners with SB/SE Operating Units, Chief Human Capital Office and other Business Units to:




| Leadership Development & Support Office Responsibilities |
| --- |
| Promote, support and administer SB/SE leadership readiness and development programs to prepare current and future leaders. |
| Gather, maintain and report comprehensive SB/SE leadership data and analysis. |
| Proactively identify leadership development needs of the organization to deliver timely cross-functional training for new leaders. |
| Promote the understanding and use of the Leadership Succession Review (LSR) and Career Learning Plan (CLP) processes to implement initiatives to strengthen leadership skill development and support succession planning. |
| Administer the Employee Engagement Program for SB/SE and promote engagement strategies throughout the organization. |
| Provide excellent customer service and program enhancements for the SB/SE MUM Processing, Telework, SETR, and HRConnect programs. |
| Identify and implement operational efficiencies in all Leadership Development & Support Programs. |
| Administer, support and manage the SB/SE Organizational Change process ensuring adherence to current Position Management and Classification guidelines. |
| Process requests for changes to the 180 Day Non-Competitive Temporary Promotion listing. |
| Provide Labor Relations oversight, guidance, support and training on issues with potential Agency impact and issues that impact Bargaining Unit employees in multiple geographic areas. |
| Administer and promote OGE 450, Hardship Program (HP) and Voluntary Relocation Program (VRP) throughout the organization. |
| Research and process Reasonable Accommodation (RA) job search requests. |
| Promote, support and administer Position Management and Classification to ensure jobs are accurately classified in accordance with published Office of Personnel Management position classification standards and IRS classification guidance. |
| Administer Section 1204 Program adherence per the IRS Restructuring and Reform Act of 1998 (RRA 98).This ensures IRS manages statistics to protect taxpayer rights and safeguards against improper use of Records of Tax Enforcement results (ROTERs) to influence the handling of taxpayer cases. |

4. The following managers report to the Chief, Leadership Development & Support Office:



   - Manager, Leadership Support Team

   - Manager, Leadership Development Team

   - Manager, Labor Relations and Corporate Shared Support

   - Manager, LDSO Support Team 1

   - Manager, LDSO Support Team 2


**1.1.16.6.4** **(04-07-2025)**

#### Business Development Office

1. The mission of the Business Development Office is to facilitate business performance improvement for SB/SE stakeholders and customers.

2. The Director, Business Development Office, reports to the Director, Operations Support.

3. To accomplish this mission, the Director, Business Development Office:



1. Aspires to be a valued partner in resource investment and operational change decisions through analytic insights.

2. Partners engage BDO employees for their business knowledge, analytic problem solving skills, integrative thinking, and development of creative solutions to complex problems.


4. The following Functional Chiefs report to the Director, Business Development Office:



   - Functional Chief, SB/SE Strategy

   - Functional Chief, Oversight Liaison

   - Functional Chief, SB/SE Research

   - Functional Chief, Knowledge Management


**1.1.16.6.4.1** **(04-07-2025)**

##### Strategy

1. The mission of Strategy is to deliver a strategic planning process that identifies and communicates the top priorities and opportunities for SB/SE and the IRS.

2. The Functional Chief, Strategy, reports to the Director, Business Development Office.

3. To accomplish this mission, the Functional Chief, Strategy Function:



1. Develops guidance to identify and align strategic initiatives to SB/SE and IRS goals and objectives.

2. Implements a performance management framework that identifies causal relationships between SB/SE initiatives, business performance and IRS strategic goals and measures.

3. Manages the Employee Driven Teams program to improve operational performance and increase employee engagement.

4. Manages the formal Change Management (CM) program using the PROSCI CM methodology to increase the success of project delivery.


4. The following managers report to the Functional Chief, Strategy:



   - Manager, Group 1

   - Manager, Group 2


**1.1.16.6.4.2** **(04-07-2025)**

##### Oversight Liaison (includes TIGTA/GAO)

1. The mission of Oversight Liaison is to foster partnerships with internal and external stakeholders to improve tax administration by:



1. Serving as the operational liaison for GAO and TIGTA audits to ensure compliance with tax laws and oversight directives.

2. Establishing effective programs to facilitate the GAO/TIGTA audit processes for the Commissioner, SB/SE.

3. Integrating internal controls and risk management as a part of fundamental business practices, including managing iReview to conduct internal reviews of SB/SE programs.

4. Serving as the operational liaison for legislative implementation and development of SB/SE legislative proposals and request for published guidance, and the tax product maintenance program.


2. The Functional Chief, Oversight Liaison reports, to the Director, Business Development Office.

3. To accomplish this mission, for TIGTA/GAO the Functional Chief, Oversight Liaison:



01. Provides timely and complete responses to TIGTA and GAO audit requests.

02. Provides timely reports and liaison support for OUs in addressing new and existing GAO high-risk issues and corrective actions.

03. Identifies and includes appropriate stakeholders in audits.

04. Maintains the liaison’s procedures, in accordance with IRS policy, for an efficient, effective, complete, and coordinated audit process within SB/SE.

05. Assists the Operating Units with writing appropriate responses to audit reports including appropriate corrective action responses to the audit recommendations.

06. Maintains currency of audit status and adequate documentation (e.g., update history) in Enterprise Audit Database, SharePoint and E-LATIS to ensure continuity.

07. Ensures responsible executives are aware of the audit status within their organization.

08. Captures and evaluates lessons learned to inform program improvement.

09. Supports the operating units in implementing corrective actions as scheduled.

10. Maintains currency of post audit status and adequate documentation in JAMES (Joint Audit Management Enterprise System) to ensure continuity.


4. To accomplish this mission, for iReview the Functional Chief, Oversight Liaison:



1. Evaluates SB/SE programs to identify risks and gaps in internal controls.

2. Provides SB/SE leadership information to make operational decisions in furtherance of program goals.

3. Facilitates operationalization of risk management through utilizing education and deliverables provided during iReview sessions.

4. Provides development opportunity for aspiring leaders.


5. To accomplish this mission, for the Legislation Program the Functional Chief, Oversight Liaison:



1. Ensures leadership is informed and aware of legislative actions that SB/SE is responsible for implementing.

2. Ensures SB/SE business units complete all necessary actions to implement new legislation.

3. Ensure actions and provisions are closed timely to show necessary actions were taken to complete legislation implementation.

4. Coordinates and reports legislative proposals and guidance requests to SB/SE leadership to improve tax administration.


6. The following manager reports to the Functional Chief Oversight Liaison:



   - Manager, Internal Controls and Risk Office

   - Manager, Audit Liaison


**1.1.16.6.4.3** **(04-07-2025)**

##### Research

1. The mission of Research is to transform information into insights that support IRS decision makers in improving taxpayer experience, voluntary compliance, and operational efficiencies.

2. The Functional Chief, SB/SE Research, reports to the Director, Business Development Office.

3. To accomplish the mission, the Functional Chief, SB/SE Research Office:



1. Brings together data expertise, advanced analytic skills, keen behavioral insights, and knowledge of compliance operations into usable solutions.

2. Applies established, recognized research techniques to provide evidence for decision-makers.

3. Identifies and analyzes emerging trends to support compliance efforts.

4. Develops compliance tools, including dashboards, simulations, process maps, data reference tables, and databases.

5. Designs and optimizes models to support case identification, selection and assignment.

6. Leads human-centered analytics to evaluate and enhance taxpayer and employee interactions.

7. Combines forces with the IRS research community to understand enterprise-level research problems and develop data-driven recommendations.


4. The following managers report to the Functional Chief, SB/SE Research:



   - Chief, Research Group 1

   - Chief, Research Group 2

   - Chief, Research Group 3

   - Chief, Research Group 4

   - Chief, Research Group 5

   - Chief, Research Group 6

   - Chief, Research Group 7

   - Chief, Research Group 8


**1.1.16.6.4.4** **(04-07-2025)**

##### Knowledge Management

1. The mission of Knowledge Management (KM) is to mitigate loss of technical expertise and to provide one stop job resources for employees.

2. The Functional Chief, Knowledge Management, reports to the Director, Business Development Office

3. To accomplish the mission, the Functional Chief, Knowledge Management:



1. Leads the development, refinement, and assessment of the SB/SE KM Strategy.

2. Leads the governance and implementation of the SB/SE KM Program and integrates with the Servicewide KM Strategy.

3. Develops the SB/SE Knowledge Capture initiative.


4. The following managers report to the Functional Chief, Knowledge Management:



1. Manager, Group 1

2. Manager, Group 2


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-001-016#addtoany "Show all")

A2A