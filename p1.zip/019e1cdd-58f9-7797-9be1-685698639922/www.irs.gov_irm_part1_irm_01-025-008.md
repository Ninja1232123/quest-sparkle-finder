---
url: "https://www.irs.gov/irm/part1/irm_01-025-008"
title: "1.25.8 Enrollment of Actuaries | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-025-008#main-content)

- 1.25.8  [Enrollment of Actuaries](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526279791136)
  - 1.25.8.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526306762128)
    - 1.25.8.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526278759520)
    - 1.25.8.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526278743472)
    - 1.25.8.1.3  [Positions and Responsibilities of the IRS Joint Board Staff](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526278704896)
    - 1.25.8.1.4  [Program Controls](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526278700032)
    - 1.25.8.1.5  [Terms](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526278718432)
    - 1.25.8.1.6  [Acronyms](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526278713824)
    - 1.25.8.1.7  [Forms](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526278746896)
    - 1.25.8.1.8  [Related Websites](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526306928512)
  - 1.25.8.2  [Regulatory Framework](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526306921856)
    - 1.25.8.2.1  [Regulations](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526306917136)
    - 1.25.8.2.2  [Joint Board Advisory Committee on Actuarial Examinations](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526279883408)
      - 1.25.8.2.2.1  [Designated Federal Officer (DFO)](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526279878768)
  - 1.25.8.3  [Overview of Enrollment](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526279872176)
  - 1.25.8.4  [Eligibility for Enrollment](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526278662800)
    - 1.25.8.4.1  [Experience](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526278661712)
    - 1.25.8.4.2  [Knowledge](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526278658608)
      - 1.25.8.4.2.1  [Waiver of EA-1 Examination](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526278656752)
  - 1.25.8.5  [Systems](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526279783952)
    - 1.25.8.5.1  [Pay.gov](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526279782304)
    - 1.25.8.5.2  [E-Trak Practitioner Database (e-Trak)](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526279780512)
  - 1.25.8.6  [Application for Enrollment](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526279776080)
    - 1.25.8.6.1  [Initial Review](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526279772512)
      - 1.25.8.6.1.1  [Suitability Concerns](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526278641424)
    - 1.25.8.6.2  [Preparing the Application Package](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526278635856)
    - 1.25.8.6.3  [Joint Board Review](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526278694400)
      - 1.25.8.6.3.1  [Approval](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526278688048)
      - 1.25.8.6.3.2  [Notice of Proposed Denial](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526278685136)
      - 1.25.8.6.3.3  [Denial](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526278608192)
  - 1.25.8.7  [Enrollment Renewal](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526278604128)
    - 1.25.8.7.1  [Processing the Renewal of Enrollment Application](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526278599952)
      - 1.25.8.7.1.1  [Suitability Concerns](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526278908688)
      - 1.25.8.7.1.2  [Failure to Meet CPE Requirements](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526278903504)
    - 1.25.8.7.2  [Moving from Inactive to Active Status](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526278891248)
  - 1.25.8.8  [Continuing Professional Education (CPE)](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526278875904)
    - 1.25.8.8.1  [Required Hours](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526306980320)
      - 1.25.8.8.1.1  [Renewal after Initial Enrollment Cycle](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526306975520)
      - 1.25.8.8.1.2  [Renewal after First Full Enrollment Cycle](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526306964016)
      - 1.25.8.8.1.3  [Renewal from Inactive Status](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526306961232)
    - 1.25.8.8.2  [Timeframe](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526306959040)
    - 1.25.8.8.3  [Method of Completion](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526306956816)
    - 1.25.8.8.4  [Waiver of CPE](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526306954032)
  - 1.25.8.9  [Qualifying Sponsors](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526306951200)
    - 1.25.8.9.1  [New Qualifying Sponsor Requests](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526306946432)
    - 1.25.8.9.2  [Sponsor Renewal Requests](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526306942960)
  - 1.25.8.10  [Enrolled Actuary and Qualifying Sponsor Audits](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526306934208)
    - 1.25.8.10.1  [CPE Audits](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526306931040)
    - 1.25.8.10.2  [Tax Compliance Audits](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526279848480)
    - 1.25.8.10.3  [Qualifying Sponsor Audits](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526279845072)
  - 1.25.8.11  [Disciplinary Actions](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526279842128)
    - 1.25.8.11.1  [Referrals](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526279836000)
    - 1.25.8.11.2  [Screening of Referrals](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526279832304)
    - 1.25.8.11.3  [Determining Violations](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526279816656)
    - 1.25.8.11.4  [Case Development](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526279811632)
    - 1.25.8.11.5  [Disciplinary Process](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526279792848)
  - 1.25.8.12  [Annual Filing Season Program Appeals](https://www.irs.gov/irm/part1/irm_01-025-008#idm140526306909024)

# Part 1. Organization, Finance, and Management

# Chapter 25. Practice Before the Service

# Section 8. Enrollment of Actuaries

* * *

## 1.25.8 Enrollment of Actuaries

#### Manual Transmittal

October 13, 2023

#### Purpose

(1) This transmits new IRM 1.25.8, Practice Before the Service, Enrollment of Actuaries.

#### Material Changes

(1) This is a new section that provides the policies and procedures relating to individuals who are or wish enrolled to perform actuarial services under Employee Retirement Income Security Act of 1974 (ERISA).

#### Effect on Other Documents

None

#### Audience

Employees of the Joint Board for the Enrollment of Actuaries unit in the Return Preparer Office.

#### Effective Date

(10-13-2023)

Kimberly D. Rogers

**1.25.8.1** **(10-13-2023)**

### Program Scope and Objectives

1. **Purpose:** This section describes how to administer the program for individuals who perform actuarial services under the Employee Retirement Income Security Act of 1974 (ERISA). The program involves receiving, evaluating, processing and approving applications for those who wish to perform actuarial services under ERISA, as well as processing renewal of enrollment applications. In addition, the program involves conducting disciplinary proceedings, and approving applications from organizations that wish to offer continuing professional education (CPE) programs to enrolled actuaries.

2. **Audience:** These instructions are directed at employees of the Joint Board for the Enrollment of Actuaries unit (hereafter referred to as “Joint Board staff”) in the Return Preparer Office.

3. **Policy Owner:** The Executive Director and members of the Joint Board for the Enrollment of Actuaries (hereafter “Joint Board”) are responsible for the policies and administration of the enrolled actuary program contained in this section. The Director, Office of Professional Responsibility (OPR), is primarily responsible for administering and enforcing Treasury Department Circular No. 230, _Regulations Governing Practice before the Internal Revenue Service_(Circular 230).

4. **Program Owner:** The Executive Director of the Joint Board for the Enrollment of Actuaries is responsible for overseeing all components of the enrolled actuary program described in this section.

5. **Primary Stakeholders:** To administer the enrolled actuary program, the JBEA staff interact with the following:



   - applicants for enrollment,

   - enrolled actuaries,

   - supervisors of applicants for enrollment,

   - members of the Joint Board,

   - members of the Joint Board Advisory Committee on Actuarial Examinations (JBAC),

   - Society of Actuaries (SOA),

   - American Academy of Actuaries (AAA),

   - Conference of Consulting Actuaries (CCA),

   - American Society of Pension Professionals and Actuaries (ASPPA),

   - Actuarial Board for Counseling and Discipline (ABCD),

   - IRS Tax Exempt & Government Entities division (TEGE),

   - Return Preparer Suitability unit,

   - Office of Professional Responsibility (OPR),

   - Chief Counsel, General Legal Services (GLS),

   - Department of Labor (DOL),

   - Pension Benefit Guaranty Corporation (PBGC).


**1.25.8.1.1** **(10-13-2023)**

#### Background

1. The Joint Board was established in 1974 by the Secretary of the Treasury and the Secretary of Labor pursuant to section 3041 of ERISA. It operates under bylaws issued by the Secretary of the Treasury and the Secretary of Labor.


**1.25.8.1.2** **(10-13-2023)**

#### Authority

1. Section 3042 of ERISA provides that the Joint Board:



   - shall by regulations establish reasonable standards and qualifications for persons performing actuarial services with respect to plans subject to ERISA and enroll such individuals who satisfy such standards and qualifications.

   - may, after notice and an opportunity for a hearing, suspend or terminate the enrollment of an individual if it is found that the individual has failed to discharge his or her duties under ERISA or did not satisfy the requirements for enrollment in effect at the time of his or her enrollment.


2. Pursuant to section 3042 of ERISA, the Joint Board published regulations governing performance of actuarial services under ERISA. These [Joint Board regulations](https://www.govinfo.gov/content/pkg/CFR-2021-title20-vol4/pdf/CFR-2021-title20-vol4-chapVIII.pdf) are set forth at 20 CFR Part 901.

3. Any active enrolled actuary in good standing with the Joint Board and not under suspension or disbarment from practice before the IRS, may practice before the IRS by filing a written declaration stating that he or she is qualified as an enrolled actuary and is authorized to represent the party or parties.

4. Practice as an enrolled actuary is limited to representation with respect to issues related to specific provisions of titles 26 and 29 of the United States Code. These specific provisions are set forth at section 10.3(d)(2) of Circular 230.

5. Enrolled actuaries who practice before the IRS are subject to the provisions of Circular 230 in the same manner as attorneys, certified public accountants, enrolled agents and enrolled retirement plan agents.


**1.25.8.1.3** **(10-13-2023)**

#### Positions and Responsibilities of the IRS Joint Board Staff

1. The Executive Director, an IRS senior manager, is responsible for the administration of the enrolled actuary program and advises and assists the Joint Board in carrying out its duties under ERISA.

2. The attorney-advisor is responsible for certain legal and technical aspects of the enrollment program, as well as for reviewing and investigating complaints, and assisting with proceedings concerning the alleged misconduct of enrolled actuaries. The attorney-advisor also oversees the qualifying sponsor program, and serves as the Designated Federal Officer and Federal Advisory Committee Act subject matter expert for the Joint Board Advisory Committee on Actuarial Examinations.

3. The senior program analyst (hereafter called "senior analyst" ) is responsible for coordinating tax compliance and CPE audits and assisting the Executive Director with ancillary matters.

4. The management and program analyst (hereafter called "analyst" ) is responsible for receiving, evaluating, and processing applications for enrollment and renewal.

5. The staff support assistant is responsible for receiving, evaluating, and processing incoming mail/email, answering telephone calls, coordinating travel arrangements and processing reimbursements for JBAC quarterly meeting attendees.

6. Seasonal employees are temporary hires responsible for assisting the Joint Board staff with reviewing and processing renewal of enrollment applications during peak renewal season.


**1.25.8.1.4** **(10-13-2023)**

#### Program Controls

1. The analyst maintains a spreadsheet to coordinate the assignment of enrollment applications to be reviewed by the Joint Board members. Joint Board application decisions are documented as part of a practitioner record in e-Trak.

2. The JBEA staff conducts annual CPE and tax compliance audits on a randomly selected sample of active enrolled actuaries.

3. The JBEA staff conducts annual audits on a randomly selected sample of qualifying sponsors.

4. Electronic applications are submitted through pay.gov and processed in e-Trak. Paper applications are processed in e-Trak after verification of payment from Beckley Finance Center.

5. An exception report identifies enrollment applications and renewal of enrollment applications submitted on Pay.gov that did not migrate to e-Trak. This mitigates the risk that renewal of enrollment applications will be associated with an incorrect practitioner record and that duplicate records for new applicants will be created.

6. All noteworthy actions are recorded in the individual practitioner record in e-Trak.


**1.25.8.1.5** **(10-13-2023)**

#### Terms

1. Enrolled Actuary - an enrolled actuary is an individual who has satisfied the enrollment qualifications set forth in the [Joint Board regulations](https://www.govinfo.gov/content/pkg/CFR-2021-title20-vol4/pdf/CFR-2021-title20-vol4-chapVIII.pdf) and who has been approved by the Joint Board to perform actuarial services under ERISA.

2. Joint Board - the term used throughout this section to represent the Joint Board for the Enrollment of Actuaries. See _IRM 1.25.8.2_, Regulatory Framework, for a description of the Joint Board.

3. Joint Board staff - the term used throughout this section to represent the IRS staff who administers the enrolled actuary program.

4. Circular 230 - the term used for Treasury Department Circular No. 230, Regulations Governing Practice before the Internal Revenue Service.


**1.25.8.1.6** **(10-13-2023)**

#### Acronyms

01. AAA - American Academy of Actuaries

02. ABCD - Actuarial Board for Counseling and Discipline

03. ASEA - American Society of Enrolled Actuaries

04. CCA – Conference of Consulting Actuaries

05. CPE - Continuing Professional Education

06. DFO – Designated Federal Officer

07. DOL – Department of Labor

08. ERISA - Employee Retirement Income Security Act of 1974

09. JBAC - Joint Board Advisory Committee on Actuarial Examinations

10. OPR – Office of Professional Responsibility

11. PII - Personally Identifiable Information

12. RPO – Return Preparer Office

13. SOA – Society of Actuaries

14. TEGE- Tax Exempt & Government Entities

15. PBGC – Pension Benefit Guaranty Corporation

16. GLS – Office of Associate Chief Counsel – General Legal Services

17. FACA – Federal Advisory Committee Act


**1.25.8.1.7** **(10-13-2023)**

#### Forms

1. Form 5434, Joint Board for the Enrollment of Actuaries Application for Enrollment

2. Form 5434-A, Joint Board for the Enrollment of Actuaries Application for Renewal of Enrollment


**1.25.8.1.8** **(10-13-2023)**

#### Related Websites

1. [Joint Board for the Enrollment of Actuaries on IRS.gov](https://www.irs.gov/tax-professionals/enrolled-actuaries)

2. Joint Board Staff on IRS Source

3. [Regulations Governing the Performance of Actuarial Services Under the Employee Retirement Income Security Act of 1974](https://www.govinfo.gov/content/pkg/CFR-2021-title20-vol4/pdf/CFR-2021-title20-vol4-chapVIII.pdf)

4. Treasury Department Circular No. 230

5. Society of Actuaries

6. Actuarial Board for Counseling and Discipline

7. [U.S. Department of Labor Employee Benefits Security Administration](https://www.dol.gov/agencies/ebsa)

8. Pension Benefit Guaranty Corporation


**1.25.8.2** **(10-13-2023)**

### Regulatory Framework

1. The Joint Board was established in 1974 by the Secretary of the Treasury and the Secretary of Labor pursuant to Section 3041 of ERISA. It is responsible for establishing reasonable standards and qualifications for the enrollment of persons performing actuarial services with respect to certain employee benefit plans covered by ERISA. The Joint Board operates under bylaws issued by the Secretary of the Treasury and the Secretary of Labor.

2. The Joint Board consists of three members appointed by the Secretary of the Treasury and two members appointed by the Secretary of Labor. The length of the appointment for each is three years. The PBGC may designate a non-voting representative to sit with, and participate in, the discussions of the Joint Board. To the extent feasible, two of the members appointed by the Secretary of the Treasury and one of the members appointed by the Secretary of Labor shall be actuaries. All decisions of the Joint Board are made by simple majority vote.

3. The bylaws establish the position of an Executive Director, and delegate to the Executive Director authority for the day-to-day administration of the Joint Board and the conduct of disciplinary proceedings related to enrolled actuaries.



### Note:



The Executive Director is an IRS employee, not a member of the Joint Board, and is appointed by the Secretary of the Treasury.

4. Each year, the Joint Board elects from among its members a Chair and a Secretary to serve a one-year term. The by-laws also provide for the appointment of an alternate to serve in the absence of a board member.

5. The Joint Board meets monthly to review applications for enrollment and to discuss any other pertinent issues.


**1.25.8.2.1** **(10-13-2023)**

#### Regulations

1. Pursuant to section 3042 of ERISA, the Joint Board published regulations governing performance of actuarial services under ERISA. These [Joint Board regulations](https://www.govinfo.gov/content/pkg/CFR-2021-title20-vol4/pdf/CFR-2021-title20-vol4-chapVIII.pdf), set forth at 20 CFR 901, contain five subparts:



1. Subpart A sets forth definitions and eligibility to perform actuarial services.

2. Subpart B sets forth rules governing the enrollment of actuaries.

3. Subpart C sets forth standards of performance to which enrolled actuaries must adhere.

4. Subpart D sets forth rules applicable to suspension and termination of enrollment.

5. Subpart E sets forth general provisions.


**1.25.8.2.2** **(10-13-2023)**

#### Joint Board Advisory Committee on Actuarial Examinations

1. The Advisory Committee on Actuarial Examinations (hereafter "Advisory Committee" ) is a discretionary committee established, via charter, under agency authority in accordance with the provisions of the Federal Advisory Committee Act (FACA), 5 U.S.C. § 10. The Advisory Committee’s duties are to recommend topics for inclusion in the Joint Board’s examinations, develop and review examination questions, recommend proposed examinations, review examination results and recommend passing scores. In addition, the Advisory Committee makes other recommendations, as requested, relative to the Joint Board’s examination program.

2. The Advisory Committee reports to the Chair of the Joint Board.

3. The Advisory Committee consists of not more than nine members. To ensure a balanced membership, the Joint Board seeks to appoint several members from each main practice area, including small single employer plans, large single employer plans, and multi-employer plans. In addition, to ensure diversity of viewpoints, the Joint Board limits the number of members employed by any one firm or affiliated with any one actuarial organization.

4. The Advisory Committee meets four times per year, holding two meetings that are partially open to the public and two closed meetings. The partially open meetings are held in Washington, DC in January and July of each year.


**1.25.8.2.2.1** **(10-13-2023)**

##### Designated Federal Officer (DFO)

1. The Chair of the Joint Board appoints a Designated Federal Officer (DFO), who is a member of the Joint Board staff, to ensure that the Advisory Committee is in compliance with the requirements of FACA and its implementing regulations.

2. Specifically, the DFO has the following responsibilities:



   - Approve or call the meetings of the Advisory Committee.

   - Prepare and approve all meeting agendas.

   - Adjourn any meetings when the DFO determines adjournment to be in the public interest.

   - Chair meetings when directed to do so by the Chair of the Joint Board.

   - Ensure the timely publication of required notices in the Federal Register.

   - Ensure the timely renewal and filing of the Advisory Committee charter.

   - Prepare and update the Membership Balance Plan.

   - File the Annual Comprehensive Report.

   - Coordinate the ethics training for the Advisory Committee.


**1.25.8.3** **(10-13-2023)**

### Overview of Enrollment

1. An enrolled actuary is an individual who has satisfied the qualifications set forth in the [Joint Board regulations](https://www.govinfo.gov/content/pkg/CFR-2021-title20-vol4/pdf/CFR-2021-title20-vol4-chapVIII.pdf) and who has been approved by the Joint Board to perform actuarial services under ERISA.

2. To maintain enrollment an enrolled actuary must adhere to specific ethical standards, satisfy minimum CPE requirements and submit a timely renewal of enrollment application and payment.

3. **Renewal period.** Enrollment must be renewed every three years. All enrolled actuaries are required to renew in the same year. The renewal years for the near future are 2023, 2026, and 2029. Renewal of enrollment is effective April 1 and expires on March 31 three years later.

4. **Enrollment cycle.** The enrollment cycle is distinguished from the renewal period because it applies specifically to CPE and times of inactive enrollment. It is defined in the [Joint Board regulations](https://www.govinfo.gov/content/pkg/CFR-2021-title20-vol4/pdf/CFR-2021-title20-vol4-chapVIII.pdf) as the three-year period from January 1, 2011, to December 31, 2013, and every three-year period thereafter.

5. **Active/Inactive Enrollment status.** To remain on the roster of active enrolled actuaries, an enrolled actuary must submit a timely renewal application and satisfy all requirements for renewal, including completion of the required CPE hours within the appropriate timeframe. The Executive Director will move an enrolled actuary who does not submit a satisfactory renewal of enrollment application to inactive status by April 1 following the March 1 filing due date for the application. See _IRM 1.25.8.7.2_, Moving from Inactive to Active Status, for detailed information about returning from inactive status to active status.



### Exception:



If an enrolled actuary completes the required number of CPE hours after the close of the preceding enrollment cycle, submits a renewal of enrollment application, and is informed by the Executive Director by April 1 that the renewal of enrollment has been renewed, then the enrolled actuary will not be moved to the inactive roster.

6. **Termination.** An individual may remain on the roster of inactive enrolled actuaries for a period up to three enrollment cycles from the date renewal would have been effective. After this period, enrollment will be terminated.


**1.25.8.4** **(10-13-2023)**

### Eligibility for Enrollment

1. To become an enrolled actuary, an applicant must satisfy both experience and knowledge requirements, submit a completed Form 5434, Joint Board for the Enrollment of Actuaries Application for Enrollment, with an enrollment fee, and be approved by the Joint Board.


**1.25.8.4.1** **(10-13-2023)**

#### Experience

1. To satisfy the experience requirement, within the 10-year period immediately preceding the date of application, an applicant must have completed, either:



1. a minimum of 36 months of certified responsible pension actuarial experience, or

2. a minimum of 60 months of certified responsible actuarial experience, including at least 18 months of certified responsible pension actuarial experience


**1.25.8.4.2** **(10-13-2023)**

#### Knowledge

1. To satisfy the knowledge requirement, an individual must pass two Joint Board examinations: the basic EA-1 examination and the pension EA-2 examination. The pension examination is given in two parts: EA-2F and EA-2L. The requirement to take the EA-1 examination may be waived by the Joint Board under certain circumstances.


**1.25.8.4.2.1** **(10-13-2023)**

##### Waiver of EA-1 Examination

1. The Joint Board will grant a waiver of the EA-1 examination to an individual who has successfully completed:



1. from the Society of Actuaries (SOA) Education and Examination Program, any version of Examination FM (Financial Mathematics) and either (1) Examinations FAM (Fundamentals of Actuarial Mathematics) and ALTAM (Advanced Long-Term Actuarial Mathematics); (2) Examination LTAM (Long-Term Actuarial Mathematics); or (3) Examination MLC (Models for Life Contingencies), or

2. an academic program leading to a degree in actuarial science or actuarial mathematics, or

3. coursework satisfying the Joint Board’s educational requirements (equivalent to a degree in actuarial science or actuarial mathematics).


2. Waiver requests must be submitted in writing prior to applying for enrollment and must include:



1. An official copy of the SOA transcript if submitting a request based on SOA examinations.

2. An official copy of the academic transcript if submitting a request based on formal education.


3. The Joint Board reviews every request. If a request is satisfactory, the Joint Board will issue an EA-1 waiver letter. If the request is not satisfactory, the Joint Board will issue a denial letter, which describes the reason(s) for the denial.


**1.25.8.5** **(10-13-2023)**

### Systems

1. The electronic systems described in the following subsections are used during the enrollment and renewal processes.


**1.25.8.5.1** **(10-13-2023)**

#### Pay.gov

1. Pay.gov is an online portal that provides customers of various government agencies with a highly secure means for completing forms and making payments electronically. The system is available for enrolled actuaries to apply for and renew their enrollment.


**1.25.8.5.2** **(10-13-2023)**

#### E-Trak Practitioner Database (e-Trak)

1. The e-Trak Practitioner database (e-Trak) is the system used to capture data from enrollment and renewal applications. A record is created for each individual who applies for enrollment, and then serves as the comprehensive activity log regarding the individual’s enrollment, and also provides a snapshot of the enrollment status at any given time.

2. All enrollment applications are entered into e-Trak electronically through migration from the Pay.gov interface or manually from paper applications received by mail.



### Note:



An exception report is generated when an application is not automatically loaded from Pay.gov into e-Trak, and all exceptions are addressed by the analyst on a daily basis.


**1.25.8.6** **(10-13-2023)**

### Application for Enrollment

1. To apply for enrollment, an individual must:



1. Submit Form 5434, Application for Enrollment, either by mail or electronically at Pay.gov. See _IRM 1.25.8.5_, Systems, for details about how Pay.gov and e-Trak are used to process an application.

2. Satisfy the experience and knowledge requirements. See _IRM 1.25.8.4_, Eligibility for Enrollment, for details about these requirements.

3. Pay the enrollment fee. The amount of the fee for any given cycle is stated on the Form 5434.


**1.25.8.6.1** **(10-13-2023)**

#### Initial Review

1. An application is first reviewed by the staff support assistant, who ensures it has been signed and dated, and that all required fields have been completed.



   - If the application is complete, the staff support assistant prepares and sends the applicant an acknowledgment letter.

   - If the application is incomplete, the staff support assistant contacts the applicant to request the missing information.


2. The staff support assistant notes if the applicant responds "Yes" to any of the following suitability questions on the application. If so, see _IRM 1.25.8.6.1.1_, Suitability Concerns, for the next steps.



   - For any of the three tax years preceding your date of application, have you failed to timely file a required federal tax return or pay a federal tax, or has an authoritative body issued a finding that you have evaded any federal tax or payment?

   - In the last 15 years or since your 18th birthday, if more recent, has an authoritative body issued a finding that you have engaged in conduct described in section 901.12(f)(1)?



     ### Note:



     This refers to Section 901 of the [Joint Board regulations](https://www.govinfo.gov/content/pkg/CFR-2021-title20-vol4/pdf/CFR-2021-title20-vol4-chapVIII.pdf) and is inquiring about certain disreputable conduct.

   - Have you been convicted of, or fined for, any criminal offenses listed in ERISA section 411 or has an authoritative body issued a finding that you have knowingly submitted false or misleading information on an application for enrollment, or in connection therewith, or in any actuarial report to any person?


3. The staff support assistant also reassigns the e-Trak record to the Return Preparer Suitability unit for a personal tax compliance check and a criminal background check. See IRM 25.20.3, Return Preparer Suitability, for information about these suitability checks.

4. The Return Preparer Suitability unit will determine if the applicant passes the suitability checks.



1. If the applicant does not pass, see _IRM 1.25.8.6.1.1_, Suitability Concerns.

2. If the applicant passes, see _IRM 1.25.8.6.2_, Preparing the Application Package.


**1.25.8.6.1.1** **(10-13-2023)**

##### Suitability Concerns

1. If the applicant responded affirmatively to any of the suitability questions on the application or failed either of the suitability checks performed by the Return Preparer Suitability unit, the staff support assistant notifies the analyst and attorney-advisor.

2. The analyst gathers any available information about the concern, via research or other means, and sends it to the attorney-advisor who:.

3. 1. reviews any information relevant to the concern, including tax transcripts, the applicant’s statement(s), and information provided by the Return Preparer Suitability unit.

2. prepares a memorandum that summarizes any derogatory information, mitigating factors, including the applicant’s responses, and concludes with a recommendation for approval, denial, or approval with monitoring.

3. forwards memorandum to Executive Director for review, who reviews, edits and grants final approval of the memorandum.

4. Upon approval, will upload memorandum to e-Trak and notify analyst to include memorandum in package for Joint Board review.


**1.25.8.6.2** **(10-13-2023)**

#### Preparing the Application Package

1. The staff support assistant uploads a complete copy of the application as a PDF file to the applicant’s e-Trak record and alerts the analyst.

2. The analyst then does the following:



1. confirms that the applicant has passed the required examinations or has received a Waiver Letter. See _IRM 1.25.8.4.2.1_, Waiver of EA-1 Examination, for more information about waivers.

2. reviews the application and contacts the applicant via email for any information that is still missing.

3. prepares and emails individual Experience Certification Letter(s) to all supervisors listed on Schedule A of the application to verify the applicant’s experience.

4. documents all actions in the applicant’s e-Trak record.


3. The analyst compiles the application package and sends it to the Joint Board via secure electronic means. The completed application package contains the following:



   - a digital copy of the application,



     ### Caution:



     All Personally Identifying Information (PII) must be redacted.

   - the memorandum prepared by the attorney-advisor (if applicable),

   - all Experience Certification Letters and responses,

   - SOA transcript(s) and the EA-1 Waiver Letter (if applicable), and

   - a blank copy of the Joint Board review sheet, which will be used to document the Joint Board’s notes and decision.



     ### Note:



     This review sheet is not an IRS document; it was created and is used only by the Joint Board.


**1.25.8.6.3** **(10-13-2023)**

#### Joint Board Review

1. Each application package is reviewed by a team of two or three Joint Board members. These reviewers make the determination to approve or deny the application.

2. If the reviewers need additional information, they notify the analyst, who will contact the applicant via email to request the information. When the applicant responds, the analyst shares the information with the reviewers.



### Note:



If the applicant does not respond within 30 days, the analyst will send a reminder email providing an additional 20 days to respond. If the applicant again does not respond, the analyst will will mail a certified letter to the applicant’s address of record and email a copy of that letter to the applicant. The letter provides an additional 30 days after which, if no response is received, the Joint Board will make a decision based on the current contents of the application package.

3. After review, the Joint Board will vote to approve or propose to deny enrollment.



   - If the Joint Board votes to approve the application, see _IRM 1.25.8.6.3.1_, Approval.

   - If the Joint Board proposes to deny enrollment, see _IRM 1.25.8.6.3.2_, Notice of Proposed Denial.


**1.25.8.6.3.1** **(10-13-2023)**

##### Approval

1. If the Joint Board votes to approve the application, a Joint Board member will notify the analyst by email.

2. The analyst updates the e-Trak record, then creates an enrollment letter that contains the applicant's newly assigned enrollment number. The analyst mails the letter to the new enrolled actuary.

3. The analyst creates and prints the Certificate of Enrollment and obtains the signature of the Joint Board Chair and Secretary. Finalized certificates will be mailed in a document mailer to the new enrolled actuary.


**1.25.8.6.3.2** **(10-13-2023)**

##### Notice of Proposed Denial

1. If the Joint Board proposes to deny enrollment, a Joint Board member will draft a Notice of Proposed Denial, which clearly explains the reasons for the Joint Board's proposed denial and emails the draft to the attorney-advisor. The notice allows the applicant an opportunity to request a conference with the Joint Board.

2. The attorney-advisor reviews the notice to ensure it meets all requirements.

3. The Executive Director reviews and signs the notice.

4. The staff support assistant mails the notice to the applicant by certified mail.

5. The applicant is given 30 days to respond.




| If... | and... | then... |
| --- | --- | --- |
| the applicant responds within 30 days, | requests a conference, | the attorney-advisor will schedule a meeting with the applicant and the reviewers at a mutually agreeable time. The parties will discuss the contents of the applicant's written response, and will ask any other questions deemed relevant to the applicant's qualifications for enrollment. The Joint Board reviewers will then decide whether to approve or deny enrollment based on the written response, answers to questions posed during the conference, and the original contents of the application. |
| the applicant responds within 30 days, | does not request a conference, | the reviewers will evaluate the applicant's response, and make a final decision based on the contents of the response and the original information provided in the application. |
| the applicant fails to respond within 30 days, | n/a | enrollment will be denied. No further letters will be issued. |

6. After the decision by the Joint Board reviewers, the appropriate steps will be followed to approve enrollment (see _IRM 1.25.8.6.3.1_, Approval) or to deny enrollment (see _IRM 1.25.8.6.3.3_, Denial).


**1.25.8.6.3.3** **(10-13-2023)**

##### Denial

1. If the Joint Board reviewers decide to deny enrollment, the reason for the denial will be discussed and voted upon at the next Joint Board meeting.

2. An assigned Joint Board member drafts a denial letter, which highlights reasons for the denial, and emails the draft to the attorney-advisor for review.

3. The Executive Director reviews and signs the denial letter.

4. The staff support assistant mails the letter via certified mail to the applicant and uploads the letter to e-Trak.


**1.25.8.7** **(10-13-2023)**

### Enrollment Renewal

1. Enrolled actuaries are required to renew their enrollment every three years. See _IRM 1.25.8.3_ for more information about the renewal period.

2. To renew enrollment, an enrolled actuary must:



1. Submit Form 5434-A, Application for Renewal of Enrollment, either by mail or electronically at Pay.gov.

2. Attest that the required CPE hours were completed. See _IRM 1.25.8.8_, Continuing Professional Education (CPE), for more information about required CPE hours.

3. Pay the application renewal fee. The amount of the fee is stated on the Form 5434-A.


**1.25.8.7.1** **(10-13-2023)**

#### Processing the Renewal of Enrollment Application

1. Responsibility for processing renewal of enrollment applications is shared by the staff support assistant, analyst, and seasonal staff employees. The same employee processes the application from beginning to end, unless noted otherwise.

2. To process a renewal of enrollment application, the assigned staff member does the following:



1. ensures the application has been signed and dated, and that all required fields have been completed.

2. confirms that the fee has been received and processed.

3. updates e-Trak for changes in the applicant’s personal information (name, mailing address, email address, or telephone number).

4. if any of the above elements are incomplete or raise a question, contacts the applicant to clarify or resolve the issue.


3. The assigned staff member then notes if the applicant responded "Yes" to any of the following suitability questions on the application. If so, see _IRM 1.25.8.7.1.1_, Suitability Concerns, for the next steps.



   - Since the issuance or latest renewal of your enrollment, has an authoritative body issued a finding that you have knowingly filed or used false or misleading information or made false or misleading representations on matters relating to employee benefit plans or actuarial services?

   - Since the issuance or latest renewal of your enrollment, have you been convicted of, or fined for, any criminal offenses (including those listed in ERISA section 411) under the laws of the United States, any State or the District of Columbia, or any territory or possession of the United States, which evidence fraud, dishonesty, or breach of trust?

   - Since the issuance or latest renewal of your enrollment, have you failed to timely file a required federal tax return or pay a federal tax, or has an authoritative body issued a finding that you have evaded any federal tax or payment, or that you have engaged in conduct described in section 901.12(f)(1)?



     ### Note:



     This refers to Section 901 of the [Joint Board regulations](https://www.govinfo.gov/content/pkg/CFR-2021-title20-vol4/pdf/CFR-2021-title20-vol4-chapVIII.pdf) and is inquiring about certain disreputable conduct.

   - Since the issuance or latest renewal of your enrollment, has an authoritative body issued a finding that you have failed to discharge your duties under ERISA or that you have willfully violated any of the regulations of the Joint Board for the Enrollment of Actuaries?


4. The assigned staff member then reviews the number of CPE hours listed on the application and determines if they satisfy the requirements for renewal. See _IRM 1.25.8.8_, Continuing Professional Education (CPE), for details about CPE requirements. If the enrolled actuary has not met the CPE requirements, see _IRM 1.25.8.7.1.2_, Failure to Meet CPE Requirements, for the next steps.

5. If the applicant is currently in Inactive Status, see _IRM 1.25.8.7.2_, Moving from Inactive to Active Status.

6. After confirming that all requirements for renewal have been met, the assigned staff member generates a renewal letter to be mailed by the staff support assistant via first class mail.


**1.25.8.7.1.1** **(10-13-2023)**

##### Suitability Concerns

1. If the enrolled actuary responded affirmatively to any of the suitability questions on the renewal application, the assigned staff member reassigns the application to the analyst , who will notify the attorney-advisor. The renewal will still be processed by the analyst, according to the procedures above.

2. The analyst gathers any available information about the concern, via research or other means, and provides it to the attorney-advisor.

3. The attorney-advisor:



1. reviews any information relevant to the concern, as provided by either the applicant or the analyst.

2. contacts the applicant, generally via secure email, to clarify or resolve the concern.

3. initiates a disciplinary case, if the findings warrant such action. For information about disciplinary cases, see _IRM 1.25.8.12_, Disciplinary Actions.


**1.25.8.7.1.2** **(10-13-2023)**

##### Failure to Meet CPE Requirements

1. If the enrolled actuary has not met the CPE requirements, the assigned staff member will forward the renewal application to the analyst, who will:



1. draft a letter to the enrolled actuary explaining that the CPE is insufficient for renewal, providing 60 days to respond,

2. forward the letter to the attorney-advisor for review, and upon approval,

3. mail the letter via certified mail and send a courtesy copy via email.


2. After the letter has been sent:




| If... | and... | then... |
| --- | --- | --- |
| a response is received within 60 days, | the CPE requirements have been met, | renewal will be approved. |
| a response is received within 60 days, | the CPE requirements have not been met. | will be placed in inactive status effective April 1 of the renewal year. |
| a response is not received within 60 | n/a | will be placed in inactive status effective April 1 of the renewal year. |


**1.25.8.7.2** **(10-13-2023)**

#### Moving from Inactive to Active Status

1. An individual in inactive status may apply to return to active enrollment at any time during the period of inactive enrollment. To return to active status, the applicant must potentially satisfy an increased CPE requirement and a pension actuarial experience requirement. See table below for details.

2. The renewal application (Form 5434-A) must be filed by paper if renewing during the second or third inactive cycle; Pay.gov may not be used.

3. The applicant must satisfy the following requirements to return to active status.




| If returning to active status during the... | the applicant must... |
| --- | --- |
| first inactive enrollment cycle, | earn 36 hours of CPE. Any hours earned during the immediately prior enrollment cycle may be applied to satisfy this requirement. |
| second inactive enrollment cycle, | earn 48 hours of CPE, plus 18 months of certified responsible pension actuarial experience since the start of the first inactive enrollment cycle. Any CPE hours earned during the first inactive enrollment cycle may be applied to satisfy this requirement. |
| third inactive enrollment cycle, | earn 60 hours of CPE, plus 18 months of certified responsible pension actuarial experience since the start of the second inactive enrollment cycle. Any CPE hours earned during the second inactive enrollment cycle may be applied to satisfy this requirement. No hours earned during the first inactive enrollment cycle may be applied to satisfy this requirement. |





### Note:



If only completion of CPE hours is required, the application for return to active status may be filed immediately upon such completion. If qualifying experience is also required, the application for return to active enrollment may not be filed until the completion of both the CPE and qualifying experience requirements.





### Note:



CPE hours applied to meet the requirements for returning to active status may not be used to satisfy the requirements of the enrollment cycle in which the individual has been placed back on the active roster.

4. Applicants in their second or third inactive enrollment cycle are required to file a Form 5434-A and Schedule A (from Form 5434), which describes their pension actuarial experience. The analyst prepares and emails the Experience Certification Letter(s) to all supervisors listed on the Schedule A to certify the experience.



### Note:



When applying from either inactive 2 or inactive 3 status, an applicant can only apply by paper.

5. The application, along with copies of the Experience Certification Letter(s) and any responses, is sent to the Joint Board reviewers to approve or deny renewal. See _IRM 1.25.8.6.3_, Joint Board Review, for details about the review process.


**1.25.8.8** **(10-13-2023)**

### Continuing Professional Education (CPE)

1. Enrolled actuaries must complete a minimum amount of CPE hours during each enrollment cycle in order to renew their enrollment. For detailed information about the CPE requirements, see the [Joint Board regulations](https://www.govinfo.gov/content/pkg/CFR-2021-title20-vol4/pdf/CFR-2021-title20-vol4-chapVIII.pdf).


**1.25.8.8.1** **(10-13-2023)**

#### Required Hours

1. An enrolled actuary must complete at least 36 CPE hours per cycle, of which at least 12 hours must be in core subject matter and 2 hours must be in ethics subject matter. In addition, at least 12 of the total hours must be completed in a formal program setting. The following are definitions of each component of CPE.



   - Core subject matter: program content and knowledge that is integral and necessary to the satisfactory performance of pension actuarial services and actuarial certifications under ERISA and the Internal Revenue Code.

   - Non-core subject matter: program content designed to enhance the knowledge of an enrolled actuary in matters related to the performance of pension actuarial services.

   - Ethics: courses covering actuarial codes of conduct and actuarial responsibilities, such as ethical dilemmas and conflicts of interest.

   - Formal program setting: an in-person or virtual setting in which the enrolled actuary has the opportunity to interact with the instructor in real time, and which is attended by at least three individuals engaged in substantive pension services. The attendee may be one of the three individuals engaged in substantive pension services.


**1.25.8.8.1.1** **(10-13-2023)**

##### Renewal after Initial Enrollment Cycle

1. New enrollees are granted enrollment at any time during an enrollment cycle and are subject to a pro-rated CPE requirement when renewing during the upcoming enrollment cycle. The CPE hours required to renew for the next renewal period are as follows:




| If the enrolled actuary is enrolled in the... | then the total number of CPE hours required is... | and... |
| --- | --- | --- |
| first year of an enrollment cycle, | 24 | at least one-half of the hours must include core subject matter, two hours must be related to ethics. Eight hours must be in a formal program setting. |
| second year of an enrollment cycle, | 12 | at least one-half of the hours must include core subject matter, two hours must be related to ethics. Four hours must be in a formal program setting. |
| third year of an enrollment cycle, | 0 | an applicant is still required to file a timely renewal application and fee. |


**1.25.8.8.1.2** **(10-13-2023)**

##### Renewal after First Full Enrollment Cycle

1. Enrolled actuaries in their first full enrollment cycle must take 18 hours of core subject matter to renew their enrollment, as opposed to the general rule of 12 hours for those who previously completed at least one full enrollment cycle.



### Example:



For an enrolled actuary granted enrollment in 2022, the first full enrollment cycle is 2023-2025. To renew enrollment effective April 1, 2026, the enrolled actuary must complete 18 core hours during the 2023-2025 enrollment cycle.


**1.25.8.8.1.3** **(10-13-2023)**

##### Renewal from Inactive Status

1. The requirements for CPE hours when moving from inactive to active status are addressed in _IRM 1.25.8.7.2_, Moving from Inactive to Active Status.


**1.25.8.8.2** **(10-13-2023)**

#### Timeframe

1. The required CPE hours must be completed by December 31 immediately preceding the start of the next renewal period. See _IRM 1.25.8.3_, Overview of Enrollment, for information about the renewal period.


**1.25.8.8.3** **(10-13-2023)**

#### Method of Completion

1. CPE hours may be earned by completing a qualifying program, consisting of core and non-core subject matter, offered by a qualifying sponsor. For information about qualifying sponsors, see _IRM 1.25.8.9_, Qualifying Sponsors. CPE may also be earned in other ways, such as instructing a qualifying program, authoring a peer-reviewed publication, serving on the Joint Board’s advisory committee, or serving as a pre-tester or writer for one of the Joint Board enrollment examinations.


**1.25.8.8.4** **(10-13-2023)**

#### Waiver of CPE

1. A waiver of the CPE requirements for a given period may be granted under extraordinary circumstances. Waiver requests must provide sufficient evidence that every effort was made throughout the enrollment cycle to participate in one or more qualifying programs that would have satisfied the CPE requirements.

2. Waiver requests must be submitted and approved prior to applying for renewal; requests must include appropriate documentation. The Joint Board staff, in collaboration with the Executive Director, will review each request and notify the enrolled actuary of the decision. If the request is granted, a Joint Board staff member will issue a CPE waiver approval letter. If the request is denied, or if the request is not submitted timely, the enrolled actuary must complete the required CPE to be granted renewal of enrollment.


**1.25.8.9** **(10-13-2023)**

### Qualifying Sponsors

1. Qualifying Sponsors are organizations that wish to provide programs to be used by enrolled actuaries to satisfy the CPE requirements for renewal of enrollment. The organizations must first be recognized as a qualifying sponsor by the Joint Board. To be recognized as a qualifying sponsor, an organization must file a sponsor agreement with and receive approval by the Joint Board.

2. In general, recognition as a qualifying sponsor is effective on the date it is approved and terminates at the end of the sponsor enrollment cycle. A sponsor enrollment cycle is a three-year period that begins one year after the enrollment cycle for individual enrolled actuaries. To retain its qualifying status, a sponsor must file a renewal request before the start of a new sponsor enrollment cycle and be approved by the Joint Board.

3. Upon initial recognition or renewal of an organization’s qualifying sponsor status, the Joint Board will issue a letter to the organization indicating that the organization has been recognized or renewed as a qualifying sponsor and specifying the period of recognition. Only those organizations that have received such a letter for the applicable sponsor enrollment cycle are considered qualifying sponsors for that cycle.

4. Qualifying sponsors are responsible for maintaining certain records to show that their programs are qualifying programs. Such records include certificates of completion, certificates of instruction, course outlines and other material. This information must be retained by the qualifying sponsor for a period of six years following the end of the sponsor enrollment cycle in which the program is held.


**1.25.8.9.1** **(10-13-2023)**

#### New Qualifying Sponsor Requests

1. To become a qualifying sponsor, an organization must contact the Joint Board staff at nhqjbea@irs.gov and state that it would like to become a qualifying sponsor. In response, the Joint Board will provide the sponsor with the application procedure.

2. As part of the application process, organizations are asked to provide a sample CPE program, sample certificate of completion, and sample certificate of instruction. In addition, organizations are asked to provide certain representations regarding compliance with the sponsor requirements set forth in the Joint Board regulations, including the content of programs, qualifications of instructors, content of certificates of completion and instruction, and retention of records.

3. The Joint Board reviews each application and, as applicable, provides corrections and recommendations to the sponsor. If approved, a sponsor recognition letter is issued, and the sponsor is added to the roster of qualifying sponsors. If denied, a letter is issued to the organization explaining the reasons for the denial.


**1.25.8.9.2** **(10-13-2023)**

#### Sponsor Renewal Requests

1. Sponsors must renew their enrollment every three years. All sponsors have the same enrollment cycle.

2. A sponsor enrollment cycle begins on January 1 and ends on December 31. The sponsor enrollment cycles for the near future begin in years 2024, 2027, and 2030.



### Example:



The enrollment cycle beginning in 2024 runs from January 1, 2024, to December 31, 2026.

3. Renewal requests must be submitted by December 31st of the year preceding the start of a new sponsor enrollment cycle. Qualifying sponsors who do not request renewal by December 31st are removed from the list of qualifying sponsors, effective the start of the new sponsor enrollment cycle.



### Note:



Late renewals will be accepted and, in general, the effective date will be the date the renewal is approved.

4. To renew its qualifying status, the sponsor must submit a signed letter requesting renewal. The renewal request may be emailed to the Joint Board at nhqjbea@irs.gov, or sent by mail. The mailing address can be found at [How to Contact the Joint Board](https://www.irs.gov/tax-professionals/enrolled-actuaries/how-to-contact-us). To facilitate review, the renewal request should include:



1. the name and address of the sponsor,

2. the name and contact information for the person responsible for the continuing professional education programs,

3. a statement, signed by an individual in a position to speak for the sponsor, that the sponsor would like to renew its qualifying sponsor status for the upcoming sponsor enrollment cycle, and that it understands and will comply with the requirements set forth at section 901.11(f) of the Joint Board regulations.


5. If the request is satisfactory, a renewal confirmation letter is issued and the sponsor is added to the roster of qualifying sponsors for the new sponsor enrollment cycle. If the request is not satisfactory, the request is denied, and a letter is issued to the sponsor explaining the reasons for the denial.


**1.25.8.10** **(10-13-2023)**

### Enrolled Actuary and Qualifying Sponsor Audits

1. The Executive Director or his/her designee may request and review records of enrolled actuaries or qualifying sponsors to ensure compliance with the Joint Board regulations. For enrolled actuaries, audits are performed on CPE and tax compliance; for qualifying sponsors, audits are performed on general program operations.

2. Audits are done annually. Those to be audited are selected using a random number generator applied to the total population subject to audit.

3. Failure to cooperate with an audit may result in the loss of active status for enrolled actuaries and a delayed renewal for qualifying sponsors until such time the audit is completed , and findings are satisfactorily addressed.


**1.25.8.10.1** **(10-13-2023)**

#### CPE Audits

1. Each year, a sample of active enrolled actuaries is randomly selected for a CPE audit. Those selected are notified of the audit by letter and are asked to provide records to support the CPE hours claimed on the most recently filed renewal application.

2. Audits are performed by the Joint Board staff typically between June and August.

3. Those selected are given a reasonable time to provide adequate proof of records. Anyone who is unable to provide adequate records within the allotted timeframe will be moved to inactive status until such time that adequate records are provided, or additional credit is earned.

4. Egregiously deficient results or patterns of conduct that suggest an enrolled actuary was not truthful when submitting a renewal application, may result in disciplinary action.

5. At the conclusion of the audit, enrolled actuaries will receive a closing letter advising them of the findings.


**1.25.8.10.2** **(10-13-2023)**

#### Tax Compliance Audits

1. Each year, a sample of active enrolled actuaries is randomly selected for a review of their Federal tax compliance.

2. Audits are performed by the Joint Board staff between January and May.

3. Any selected enrolled actuary who failed to file an income tax return, failed to timely file a tax return, and/or has an outstanding tax balance, will be notified and asked to provide an explanation regarding the potential tax noncompliance and copies of any records confirming compliance with Federal tax obligations.

4. At the conclusion of the audit, enrolled actuaries will receive a closing letter advising them of the findings.


**1.25.8.10.3** **(10-13-2023)**

#### Qualifying Sponsor Audits

1. Each year, a sample of active qualifying sponsors is randomly selected for review to ensure programs coordinated or conducted by the sponsor are in compliance with the Joint Board regulations.

2. Qualifying sponsors are notified of the audit by letter and are asked to provide samples of content for their core and non-core programs. The Joint Board staff assesses the content and determines if it meets the requirements of the regulations.

3. At the conclusion of each audit, sponsors will receive a closing letter advising them of the findings.


**1.25.8.11** **(10-13-2023)**

### Disciplinary Actions

1. Under section 3042 of ERISA the Joint Board may, after notice and an opportunity for a hearing, suspend or terminate the enrollment of an enrolled actuary if the Joint Board finds that such enrolled actuary.



1. Failed to discharge his/her duties under ERISA; or

2. does not satisfy the requirements for enrollment in effect at the time of his/her enrollment.


2. The attorney-advisor and Executive Director are responsible for reviewing, investigating and resolving alleged violations of any standards of performance of actuarial services under ERISA.

3. Joint Board members serve as the appellate authority of decisions made by an Administrative Law Judge and thus do not participate in any aspect of the review, investigation or resolution of a disciplinary matter.

4. The rules of conduct applicable to enrolled actuaries are set forth in the following sections of the Joint Board regulations:



1. Subpart C, Standards of Performance for Enrolled Actuaries

2. Subpart D, Suspension or Termination of Enrollment


**1.25.8.11.1** **(10-13-2023)**

#### Referrals

1. A referral is a notification, usually by a third party, alleging that an enrolled actuary’s conduct has violated the Joint Board’s regulations.

2. Referrals are sent to the Joint Board headquarters in Washington, DC via mail, email or fax. There is currently no form available for interested parties to initiate referrals to the Joint Board.

3. The Joint Board staff may receive referrals from a variety of sources, both internal and external, such as TEGE, and external sources such as PBGC, actuarial organizations, clients/former clients and other enrolled actuaries.

4. When a referral is received, a Joint Board staff member will acknowledge receipt of a referral by sending a secure e-mail when received internally and by standard letter when received externally.


**1.25.8.11.2** **(10-13-2023)**

#### Screening of Referrals

1. Referrals are initially reviewed to determine whether:



1. The subject of the referral is an enrolled actuary

2. The reason for the referral raises, as a threshold matter, a question of a violation of the Joint Board’s regulations.


2. Upon receipt of a referral, the staff support assistant will consult e-Trak to confirm the existence of a record of the individual named in the referral.



|     |     |
| --- | --- |
| If... | Then... |
| An enrollment record is found | The staff support assistant will create an enforcement record in e-Trak and assign the matter to the attorney-advisor. |
| No enrollment record is found | The staff support assistant will prepare a memo with the date of research indicating the lack of an enrollment record, and forward the memo with the referral to the attorney-advisor who would determine whether appropriate to forward to another office and include that determination in the memo. |

3. If an enrollment record is found, the attorney-advisor



1. Reviews the referral to make a preliminary determination about jurisdiction and the subject matter of the referral and prepares a memorandum,

2. Uploads the memorandum to e-Trak for the Executive Director’s review.


|     |     |
| --- | --- |
| If Executive Director agrees... | Then... |
| There is no jurisdiction | If appropriate, reroute the case using Form 3210 and close the case |
| There is jurisdiction | Attorney-Advisor will further develop case and document significant actions in e-Trak. |

**1.25.8.11.3** **(10-13-2023)**

#### Determining Violations

1. The attorney-advisor will carefully review the referral to determine whether the alleged conduct is regulated or proscribed by the Joint Board’s regulations.



1. When reviewing the referral, the attorney-advisor will make an independent determination regarding the existence or extent of the alleged violations rather than solely relying on the violations specified by the referent,

2. Attorney-advisor should identify all possible violations, based on the conduct described in the referral.


2. A tax compliance review should be performed on all referrals once jurisdiction has been established. The attorney-advisor will work with the Return Preparer Suitability unit to conduct a tax compliance check of the same scale and extensiveness as tax compliance checks reserved for new enrollments and random tax compliance audits.

3. Attorney-advisor should review the enrolled actuary’s most recent enrollment or renewal form and identify whether any of the alleged conduct and/or tax compliance issues, if any, were accurately disclosed on the form.


**1.25.8.11.4** **(10-13-2023)**

#### Case Development

1. Attorney-advisor will determine whether the evidence of the referral, on its face, supports an immediate issuance of an allegation letter, or if additional research is required.



### Note:



In most cases, additional research will be required to confirm the adequacy of the allegations and to make an informed decision. The information needed varies and depends on the facts and circumstances of the referral.

2. If the attorney-advisor identifies that extensive research is needed or if needed information is not readily available, the attorney-advisor will develop an investigative plan identifying:



   - Facts and evidence in support of each alleged violation.

   - Additional information needed to make a determination.

   - Sources of information, such as technical experts needed.


3. If sought-after information is readily available and can be obtained without delay, attorney-advisor should obtain the information immediately.

4. After obtaining available information or developing an investigative plan, attorney-advisor will prepare a memorandum that includes the following information:



   - Name of individual named in referral

   - Enrollment number

   - Summary of pertinent facts of case

   - Joint Board’s regulations section(s) allegedly violated

   - Analysis of case

   - Investigative plan, if applicable

   - Recommendation

   - Signature and date lines for attorney-advisor and Executive Director


5. The Executive Director will review the case memorandum and uploaded file contents in e-Trak and will concur or dissent with the attorney-advisor’s recommendation or refer back to the attorney-advisor with additional comments/recommendations.

6. If it is determined that there is no cause of action, the attorney-advisor will notify the staff support assistant to close the case and document as no cause of action.

7. Once it is determined that any allegations are supported factually and documented appropriately, attorney-advisor will prepare an allegation letter.

8. The allegation letter is the mechanism by which the Executive Director alleges that a violation of one or more of the Joint Board’s regulations has occurred. The contents of the allegation letter must:



   - Describe the facts underlying the alleged violation(s) with sufficient detail so as to put the enrolled actuary on notice of the charges.

   - Cite the section(s) of the Joint Board’s regulations allegedly violated.

   - Provide the enrolled actuary with 30 days to respond.

   - Notify the enrolled actuary of the right to a conference.

   - Notify the enrolled actuary of the right to obtain the services of an authorized representative.

   - Provide the name of and contact information for the attorney-advisor.

   - Be signed by the Executive Director, or the attorney-advisor on behalf of the Executive Director.


9. When preparing an allegation letter, the attorney-advisor must receive Executive Director approval prior to mailing. Attorney-advisor will prepare a supplemental memorandum with the allegation letter attached for Executive Director review.



1. The Executive Director will review both the memorandum and the allegation letter and will approve or return to attorney-advisor with comments and/or requests for additional research or edits.

2. Once approved, the staff support assistant is notified to prepare the letter for signature and mailing.

3. Allegation letters are mailed via both first class and certified mail to the enrolled actuary’s address of record in e-Trak. Allegation letters are not emailed.


**1.25.8.11.5** **(10-13-2023)**

#### Disciplinary Process

1. The enrolled actuary is afforded (30) thirty days to respond to the allegation letter and may request a conference with the attorney-advisor and Executive Director; however, a conference will not be granted in lieu of a substantive response.

2. The enrolled actuary’s response should include a detailed response to the allegations and should include any mitigating evidence, if applicable.

3. When reviewing the response, attorney-advisor may request additional information or documentation in support of any mitigating evidence offered by the enrolled actuary.

4. The attorney-advisor will prepare a memorandum for Executive Director review which highlights the recommendation for any proposed discipline. Any recommendation for discipline should only be made after considerable review and analysis of the allegations, the enrolled actuary’s response and mitigating evidence, conference deliberations and any discussions with pre-authorized technical experts.

5. Possible disciplinary actions that can be proposed for an enrolled actuary are:



1. Reprimand - The Executive Director may unilaterally issue a reprimand to the enrolled actuary. The reprimand is private in nature and is not disclosed to the public.

2. Suspension - A suspension prohibits an enrolled actuary from being able to perform services as an enrolled actuary for a specific period. Periods of suspension typically range from (6) six months to (60) sixty months. Suspensions must be agreed to by both the Executive Director and enrolled actuary via a fully executed settlement agreement.

3. Termination - A termination will indefinitely remove an enrolled actuary from the roster of enrolled actuaries. Terminated enrolled actuaries are not eligible to apply for enrollment for at least (5) five years from the date of termination and must do so by submitting a petition for reinstatement for approval by the Joint Board and Executive Director. Similar to suspensions, terminations must be agreed to by both the Executive Director and enrolled actuary and be fully executed via a settlement agreement.


6. If the parties are unable to come to an agreement on discipline, the Executive Director will contact Chief Counsel, General Legal Services to discuss the initiation of a proceeding before an Administrative Law Judge for suspension or termination.


**1.25.8.12** **(10-13-2023)**

### Annual Filing Season Program Appeals

1. Individuals who request to participate in the Annual Filing Season Program in accordance with Rev. Proc. 2014-42 and are denied by the Return Preparer Suitability Unit, may appeal the decision.

2. The Return Preparer Suitability Unit will notify the Joint Board senior analyst and Executive Director via email that a timely appeal has been received. Included in the email will be a package of all relevant documentation (facts, letters, correspondence, research) needed to consider the applicant’s case for appeal



### Note:



Any late appeal will move forward but lateness will be documented in the appeal summary. The Return Preparer has 30 days after the denial letter to file an appeal

3. A Suitability analyst will contemporaneously create a case in the Tax Professional PTIN System (TPPS) and forward it to the senior analyst. All documentation and records in support of the appeal will be submitted within the TPPS.

4. The Executive Director will review the contents of the appeal package and render a decision to sustain or overturn the original denial based on the requirements of Rev. Proc 2014-42.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-025-008#addtoany "Show all")

A2A