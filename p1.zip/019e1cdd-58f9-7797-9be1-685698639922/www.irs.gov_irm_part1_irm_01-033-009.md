---
url: "https://www.irs.gov/irm/part1/irm_01-033-009"
title: "1.33.9 Cost Estimating Guidelines | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-033-009#main-content)

- 1.33.9  [Cost Estimating Guidelines](https://www.irs.gov/irm/part1/irm_01-033-009#id1)
  - 1.33.9.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-033-009#id2)
    - 1.33.9.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-033-009#id3)
    - 1.33.9.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-033-009#id4)
    - 1.33.9.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-033-009#id5)
      - 1.33.9.1.3.1  [CFO and Deputy CFO](https://www.irs.gov/irm/part1/irm_01-033-009#id7)
      - 1.33.9.1.3.2  [Associate and Deputy Associate CFO for Corporate Budget](https://www.irs.gov/irm/part1/irm_01-033-009#id8)
      - 1.33.9.1.3.3  [Cost and User Fees Office](https://www.irs.gov/irm/part1/irm_01-033-009#id9)
      - 1.33.9.1.3.4  [Budget Execution Office](https://www.irs.gov/irm/part1/irm_01-033-009#id10)
      - 1.33.9.1.3.5  [Budget Formulation Office](https://www.irs.gov/irm/part1/irm_01-033-009#id11)
      - 1.33.9.1.3.6  [Financial Planning and Analysis Office](https://www.irs.gov/irm/part1/irm_01-033-009#id12)
      - 1.33.9.1.3.7  [National Headquarters Budget Office](https://www.irs.gov/irm/part1/irm_01-033-009#id13)
      - 1.33.9.1.3.8  [Strategic Planning Office](https://www.irs.gov/irm/part1/irm_01-033-009#id14)
      - 1.33.9.1.3.9  [Business Units](https://www.irs.gov/irm/part1/irm_01-033-009#id15)
      - 1.33.9.1.3.10  [Associate Chief Information Officer, Strategy and Planning, IT](https://www.irs.gov/irm/part1/irm_01-033-009#id16)
    - 1.33.9.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-033-009#id17)
    - 1.33.9.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-033-009#id18)
    - 1.33.9.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-033-009#id19)
    - 1.33.9.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-033-009#id20)
    - 1.33.9.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-033-009#id21)
  - 1.33.9.2  [Cost Estimating](https://www.irs.gov/irm/part1/irm_01-033-009#id22)
    - 1.33.9.2.1  [Type of Cost Estimates](https://www.irs.gov/irm/part1/irm_01-033-009#id23)
      - 1.33.9.2.1.1  [New Hire Labor and Non-Labor Cost Estimates](https://www.irs.gov/irm/part1/irm_01-033-009#id25)
      - 1.33.9.2.1.2  [Information Technology Cost Estimates](https://www.irs.gov/irm/part1/irm_01-033-009#id26)
      - 1.33.9.2.1.3  [Procurement Cost Estimates](https://www.irs.gov/irm/part1/irm_01-033-009#id27)
      - 1.33.9.2.1.4  [Submissions Processing Cost Estimates](https://www.irs.gov/irm/part1/irm_01-033-009#id28)
  - 1.33.9.3  [Four Main Pillars of Reliable Cost Estimates](https://www.irs.gov/irm/part1/irm_01-033-009#id29)
    - 1.33.9.3.1  [Comprehensive](https://www.irs.gov/irm/part1/irm_01-033-009#id30)
      - 1.33.9.3.1.1  [Purpose](https://www.irs.gov/irm/part1/irm_01-033-009#id32)
      - 1.33.9.3.1.2  [Plan](https://www.irs.gov/irm/part1/irm_01-033-009#id33)
      - 1.33.9.3.1.3  [Relationships](https://www.irs.gov/irm/part1/irm_01-033-009#id34)
      - 1.33.9.3.1.4  [Work Breakdown Structure (WBS)](https://www.irs.gov/irm/part1/irm_01-033-009#id35)
      - 1.33.9.3.1.5  [Ground Rules and Assumptions](https://www.irs.gov/irm/part1/irm_01-033-009#id36)
    - 1.33.9.3.2  [Well-documented](https://www.irs.gov/irm/part1/irm_01-033-009#id37)
    - 1.33.9.3.3  [Accurate](https://www.irs.gov/irm/part1/irm_01-033-009#id38)
      - 1.33.9.3.3.1  [Data](https://www.irs.gov/irm/part1/irm_01-033-009#id40)
      - 1.33.9.3.3.2  [Sensitivity Analysis](https://www.irs.gov/irm/part1/irm_01-033-009#id41)
      - 1.33.9.3.3.3  [Risk and Uncertainty](https://www.irs.gov/irm/part1/irm_01-033-009#id42)
    - 1.33.9.3.4  [Credible](https://www.irs.gov/irm/part1/irm_01-033-009#id43)
      - 1.33.9.3.4.1  [Document](https://www.irs.gov/irm/part1/irm_01-033-009#id45)
      - 1.33.9.3.4.2  [Independent Cost Estimates (ICE)](https://www.irs.gov/irm/part1/irm_01-033-009#id46)
      - 1.33.9.3.4.3  [Managerial Approval](https://www.irs.gov/irm/part1/irm_01-033-009#id47)
      - 1.33.9.3.4.4  [Update the Estimate to Reflect Actual Costs and Changes](https://www.irs.gov/irm/part1/irm_01-033-009#id48)
  - 1.33.9.4  [Imputed Costs](https://www.irs.gov/irm/part1/irm_01-033-009#id49)
  - 1.33.9.5  [Economic Analysis](https://www.irs.gov/irm/part1/irm_01-033-009#id50)
    - 1.33.9.5.1  [Key Elements of an Economic Analysis](https://www.irs.gov/irm/part1/irm_01-033-009#id52)

# Part 1. Organization, Finance, and Management

# Chapter 33. Strategic Planning, Budgeting and Performance Management Process

# Section 9. Cost Estimating Guidelines

* * *

## 1.33.9 Cost Estimating Guidelines

#### Manual Transmittal

August 27, 2025

#### Purpose

(1) This transmits new IRM 1.33.9, Strategic Planning, Budgeting and Performance Management Process, Cost Estimating Guidelines.

#### Material Changes

(1) This IRM is established to codify IRS’s cost estimating policy for non-IT initiatives, that includes the 12 steps and associated best practices found in the United States Government Accountability Office’s (GAO’s) Cost Estimating and Assessment Guide.

#### Effect on Other Documents

This IRM incorporates Interim Guidance Memorandum CFO-01-0924-0001, Interim Guidance for Estimating Costs, dated September 18, 2024.

#### Audience

All business units

#### Effective Date

(08-27-2025)

Anthony S. Chavez

Acting Chief Financial Officer

**1.33.9.1** **(08-27-2025)**

### Program Scope and Objectives

1. Purpose: To provide IRS employees with consistent policies, guidelines and a framework to develop high-quality non-IT cost estimates that are transparent and fully align with best practices for cost estimation.

2. Audience: All business units and offices

3. Policy Owner: CFO

4. Program Owner: Cost and User Fees office

5. Primary Stakeholder: The IRS budget and finance community

6. Program Goals: To ensure internal controls are implemented and assist offices in applying cost estimating policies


**1.33.9.1.1** **(08-27-2025)**

#### Background

1. As a general practice, GAO publicly releases guidance and best practices intended to help agencies in developing sound internal financial policy. Updated [GAO-20-195G, Cost Estimating and Assessment Guide: Best Practices for Developing and Managing Program Costs](https://www.gao.gov/products/GAO-20-195G), released in March 2020, provides a framework for agencies to develop high-quality, reliable cost estimates for reasonable program planning, budgeting and management.

2. GAO-20-195G’s framework provides a 12-step cost estimation process that emphasizes four pillars of reliable cost estimates: accuracy, comprehensiveness, credibility, and documentation. Refer to IRM 1.33.9.3.2 (3), Well-documented, for the 12-step process set forth by GAO as criteria for effective cost estimates. Following these steps ensures high-quality, realistic cost estimates that enable management to make informed decisions.


**1.33.9.1.2** **(08-27-2025)**

#### Authorities

1. The authorities for this IRM include:



1. [GAO-20-195G, Cost Estimating and Assessment Guide](https://www.gao.gov/products/GAO-20-195G)

2. [Supplement to the Office of Management and Budget (OMB) Circular A-11: Planning, Budgeting and Acquisition of Capital Assets](https://www.whitehouse.gov/wp-content/uploads/2018/06/a11.pdf)

3. [Department of the Treasury Acquisition Procedures (Subpart 1007.70)](https://home.treasury.gov/system/files/281/DTAP-FY22.pdf)

4. [Chief Financial Officers Act of 1990, Public Law (PL) 101-576](https://www.congress.gov/bill/101st-congress/house-bill/5687)


**1.33.9.1.3** **(08-27-2025)**

#### Responsibilities

1. This section provides responsibilities for the:



01. CFO and Deputy CFO

02. Associate and Deputy Associate CFO for Corporate Budget

03. Cost and User Fees Office

04. Budget Execution Office

05. Budget Formulation Office

06. Financial Planning and Analysis Office

07. National Headquarters Budget Office

08. Strategic Planning Office

09. Business Units

10. Associate Chief Information Officer, Strategy and Planning, IT


**1.33.9.1.3.1** **(08-27-2025)**

##### CFO and Deputy CFO

1. The CFO and Deputy CFO are responsible for:



1. Providing oversight and accountability for non-IT cost estimating policy.

2. Establishing, overseeing and approving comprehensive policy for non-IT cost estimation.


**1.33.9.1.3.2** **(08-27-2025)**

##### Associate and Deputy Associate CFO for Corporate Budget

1. Associate and Deputy Associate CFO for Corporate Budget are responsible for:



1. Maintaining, interpreting and ensuring use of best practices for non-IT cost estimation as appropriate.

2. Ensuring effective internal controls are in place to maintain the integrity of non-IT cost estimating policies.

3. Assisting business units in customizing GAO’s 12-step cost estimation process to specific cost estimation needs.

4. Leading the development of the non-IT labor, contracts, and non-labor estimates presented in the Strategic Operating Plan and spending plans.


**1.33.9.1.3.3** **(08-27-2025)**

##### Cost and User Fees Office

1. The Cost and User Fees office is responsible for



1. Developing, communicating and updating this IRM.

2. Assisting business units and offices in complying with applicable criteria in the cost estimating process.

3. Assisting business units in adapting non-IT cost estimates policies and procedures, based on GAO’s Cost Estimating and Assessment Guide, to their cost estimating needs.


**1.33.9.1.3.4** **(08-27-2025)**

##### Budget Execution Office

1. The Budget Execution office is responsible for:



1. Monitoring the execution of IRS’s operating plan.

2. Providing guidance and developing execution policies.

3. Establishing controls on appropriated funds.


**1.33.9.1.3.5** **(08-27-2025)**

##### Budget Formulation Office

1. The Budget Formulation office is responsible for developing and submitting IRS budget requests that justify the resources needed to accomplish the IRS’s mission and goals.


**1.33.9.1.3.6** **(08-27-2025)**

##### Financial Planning and Analysis Office

1. The Financial Planning and Analysis office is responsible for:



1. Developing and maintaining the unit cost rate (UCR) calculator and the support hiring model.

2. Providing policies and guidance for the use of the UCR calculator.

3. Determining how output should be compiled, and how the UCR could be adapted for special situations such as size and life cycle of a task, program, or project.

4. Estimating full-time equivalent (FTE) for budget submissions, operating plans and obligation and employment reporting.


**1.33.9.1.3.7** **(08-27-2025)**

##### National Headquarters Budget Office

1. The National Headquarters Budget office is responsible for:



1. Managing and monitoring National Headquarters and CFO financial plans.

2. Performing detailed analyses of resource utilization and coordinating with internal and external stakeholders to ensure funds are obligated effectively.


**1.33.9.1.3.8** **(08-27-2025)**

##### Strategic Planning Office

1. The Strategic Planning office is responsible for:



1. Developing and updating the IRS strategic plan, identifying the goals, objectives, opportunities and future direction of the IRS, per Treasury guidance and in accordance with OMB Circular A-11, Part 6, The Federal Performance Framework for Improving Program and Service Delivery, and tracking and reporting on its implementation.

2. Performing investment analysis to allocate resources to support critical programs and strategic priorities through the Program and Budget Advisory Committee process.

3. Managing the IRS’s performance measurement and reporting processes, including monitoring and maintaining the IRS budget-level and oversight board performance measures and reporting performance results to both internal and external stakeholders.

4. Managing the IRS governance process that supports and promotes transparency and accountability.


**1.33.9.1.3.9** **(08-27-2025)**

##### Business Units

1. The business units are responsible for:



1. Adhering to IRS-wide cost estimating policies.

2. Developing and approving cost estimates that adhere to established cost estimating policy.

3. Identifying required inputs, direct and indirect costs for a defensible and credible cost estimate.

4. Developing their cost estimating reports and internal controls.

5. Implementing periodic reviews of cost estimates for accuracy and reliability.

6. Answering questions from leadership and oversight.


**1.33.9.1.3.10** **(08-27-2025)**

##### Associate Chief Information Officer, Strategy and Planning, IT

1. The Information Technology Strategy and Planning office is responsible for IT cost estimation policies and procedures that adhere to GAO’s 12-step cost estimation process.


**1.33.9.1.4** **(08-27-2025)**

#### Program Management and Review

1. Program Reports: The CFO’s UCR calculator is a spreadsheet with built-in costs and economic information for estimating labor and non-labor and other costs. The calculator supports cost estimating as well as annual budget requests, and it is used to generate the full cost of labor and non-labor estimates for new hires. The calculator includes supports cost such as IT, travel, training and other calculations.

2. Program Effectiveness: The UCR calculator is documented in a user guide and procedures. The calculator and user guide and procedures are tested and updated annually. User guide and procedures are housed on the CFO; Products, Guidance & Services; Corporate Budget; Financial Planning & Analysis SharePoint site.


**1.33.9.1.5** **(08-27-2025)**

#### Program Controls

1. UCRs are the standard position-related costs that are associated with incremental staffing adjustments and are calculated using a consistent cost methodology that uses historical data, standardized calculations and inflation factors, and clear documentation of assumptions.

2. When an organization requests new staff for an investment, program managers in the business units determine the number of staff needed to accomplish the proposed work. Organizations then use the UCR calculator to estimate the cost of investment staff hiring needed and submits the investment proposal to Corporate Budget for review and inclusion in the Budget Request.

3. The UCR Calculator requires the user to enter the number of hires, a code combination (organization, program area, and employee type), and basic assumptions. From these variables, the calculator generates the estimated UCR costs (Direct, Corporate, and Non-Recurring) for the first three years.

4. Organizations can submit requests with justification to Corporate Budget for approval to add additional “Above/Below UCR” amounts to the standard UCR outputs if the particular investment requires a custom rate or if there are non-staffing related costs to be included in the investment proposal, such as a fixed contract for support.


**1.33.9.1.6** **(08-27-2025)**

#### Terms/Definitions

1. The following terms and definitions apply to this program:



01. **Briefing** \- A presentation and/or written documents (e.g., Word, Excel, or PowerPoint) to provide information that is often used to influence decision making.

02. **Capital asset** \- A capital asset has an estimated useful life of two or more years. Example of capital assets include land, buildings, lease improvements, equipment, motor vehicles, intellectual property, information technology (hardware, software, and modifications) developed or purchased for use by the IRS.

03. **Cost driver** \- The basis used to allocate the costs of financial resources. Examples of cost drivers include square footage, FTEs, service calls answered, tax cases closed and labor dollars. Refer to IRM 1.33.5.2.5.1, Selection of a Costing Assignment Technique, for a listing of cost drivers.

04. **Cost-effectiveness analysis** \- A comparative analysis when the benefits of alternatives cannot be quantified in dollars.

05. **Direct costs** \- Expenses that can be directly traced to a program, activity, product or service. Direct costs generally result from the business units executing their budgets. See IRM 1.33.5.2.3.1, Direct Costs.

06. **Economic Analysis** \- A systematic method to assessing costs and benefits to determine the most efficient and cost-effective approach for a specific situation.

07. **Full-time equivalent (FTE)** \- The basic measure of the employment levels used in the budget. It is the total number of regular, straight-time hours (not including overtime or holiday hours) worked by employees each fiscal year. Annual leave, sick leave, compensatory time off and other approved leave categories are considered hours worked for purposes of defining full- time equivalent employment.

08. **Imputed costs** \- Unreimbursed costs provided by other agencies required to be recognized by accounting standards.

09. **Indirect Cost** \- Cost that is not identifiable with a specific product, function or activity (i.e. rent and utilities). See IRM 1.33.5.2.3.2, Indirect Costs.

10. **Life-cycle cost** \- The total estimated cost for a task, project, program or capital asset over the time period corresponding to its full life. It includes direct and indirect costs for planning, procurement (or development) operations, maintenance and disposal.

11. **Materiality** \- For cost estimating purposes, materiality refers to the relative dollar amount and the significant effect on cost for reasonable management decision-making. Relatively large dollar amounts are deemed to be material when compared to business unit’s or IRS’s budgeted resources.

12. **Planning estimates** \- Used for program conceptual planning of fiscal year budgeting study purposes. It’s not considered valid for contract pricing proposals or budget justification.

13. **Work Breakdown Structure (WBS)** \- A breakdown of a project into smaller elements. The WBS is used to structure cost estimates and to track performance on cost and schedule. It helps organize and define the total work scope of the project.


**1.33.9.1.7** **(08-27-2025)**

#### Acronyms

1. The following acronyms apply to this program.




| **Acronym** | **Definition** |
| --- | --- |
| FTE | full-time equivalent |
| GAO | Government Accountability Office |
| UCR | Unit Cost Rate |
| WBS | Work Breakdown Structure |


**1.33.9.1.8** **(08-27-2025)**

#### Related Resources

01. Document 6746, Cost Estimate Reference

02. IRM 1.33.3, Reimbursable Operating Guidelines

03. IRM 1.33.4, Financial Operating Guidelines

04. IRM 1.33.5, Managerial Costing

05. IRM 1.33.7, User Fees

06. IRM 1.33.8, Estimating Trust Fund Costs

07. IRM 3.30.10, Cost Estimate Reference

08. [Bureau of Labor Statistics Consumer Price Index (CPI) Inflation Calculator](https://data.bls.gov/cgi-bin/cpicalc.pl)

09. [GAO-05-734SP, A Glossary of Terms Used in the Federal Budget Process](https://www.gao.gov/products/GAO-05-734SP)

10. [GAO-18-151SP, Assessment Methodology for Economic Analysis](https://www.gao.gov/products/gao-18-151sp)

11. IT Estimation Procedure

12. Independent Government Cost Estimate (IGCE) for a Procurement

13. [International Cost Estimating & Analysis Association](https://www.iceaaonline.com/cebok/)

14. UCR calculator

15. UCR Calculator User Guide


**1.33.9.2** **(08-27-2025)**

### Cost Estimating

1. Cost estimating is the process of collecting and analyzing reliable financial data and applying quantitative models, techniques, tools, and methodologies to estimate the future cost of a task, project, product, program, procurement or capital asset.

2. Developing and maintaining accurate cost estimates throughout the life cycle of a multi-year task, project, program, procurement or capital asset is required by GAO and IRS cost estimating policy. Overlooking vital cost elements could potentially lead to unreliable cost estimates. Maintaining realistic cost estimates is a vital planning tool.

3. High-quality cost estimates help reduce the risk of cost overruns, missed deadlines and performance shortfalls. Reliable cost estimating encourages congressional, public and oversight trust.

4. The level of detail and accuracy of a cost estimate varies depending on dollar amount or cost materiality, available information when preparing the estimate and the time allowed for completion.

5. Cost estimating is different than cost-benefit analysis. Cost estimating is the process of determining future monetary resources needed for a project, program or asset. Cost-benefit analysis is a quantitative process of comparing the projected costs and benefits of an alternative to determine its feasibility. It’s a historical accounting framework that when combined with other financial or non-financial data can help management make informed decisions.

6. Cost estimating is different than cost-effectiveness analysis. Cost-effectiveness analysis is a comparative analysis when the benefits of alternatives cannot be quantified in dollars.

7. Cost estimating is different than a budgetary estimate. Budget estimates are used for fiscal planning purposes or obtaining funding. Cost estimates are completed for programs, projects or assets for which funds have already been appropriated.


**1.33.9.2.1** **(08-27-2025)**

#### Type of Cost Estimates

1. The following are the most common types of cost estimates in the IRS:



1. New hire labor and non-labor

2. Information Technology

3. Procurement

4. Submissions Processing


**1.33.9.2.1.1** **(08-27-2025)**

##### New Hire Labor and Non-Labor Cost Estimates

1. The CFO’s Financial Planning and Analysis office in Corporate Budget supports the IRS hiring model and provides guidelines and procedures for New Hire Labor and Non- Labor Cost Estimates.

2. The UCR Calculator is the tool designed and used to estimate the cost of new hire initiatives.

3. Refer to the available resources when preparing cost estimates for new hire initiatives. Hiring guidance resources are available on the CFO website under Products, Guidance & Services, Corporate Budget, Financial Planning & Analysis


**1.33.9.2.1.2** **(08-27-2025)**

##### Information Technology Cost Estimates

1. The Information Technology Strategy and Planning office provides policies, guidance and resources to prepare, plan, and submit IT cost estimates.

2. Follow IT Estimation Procedure and the latest IT cost estimating policies when preparing IT cost estimates.


**1.33.9.2.1.3** **(08-27-2025)**

##### Procurement Cost Estimates

1. Procurement Acquisition Management and Planning under the Chief Procurement Officer provides guidelines, tools and resources for procurement cost estimates.

2. Follow procurement latest cost estimating policies and cost estimation tools procedures when preparing procurement cost estimates. Available policy and resources are as follows:



   - Independent Government Cost Estimate (IGCE) for a Procurement

   - Procurement Knowledge Base

   - CCOP mailbox: proc.ccop@irs.gov


**1.33.9.2.1.4** **(08-27-2025)**

##### Submissions Processing Cost Estimates

1. Taxpayer Services, Submission Processing, provides policy and procedures for current programs, program changes, new programs, studies or other use.

2. Follow Submission Processing’s policies and procedures when developing cost estimates for submission processing activities. Refer to. IRM 3.30.10, Work Planning & Control, Cost Estimate Reference and Document 6746, Cost Estimate Reference.


**1.33.9.3** **(08-27-2025)**

### Four Main Pillars of Reliable Cost Estimates

1. The following are the four pillars of reliable cost estimates, as described in GAO’s 12-step cost estimation process:



1. Comprehensive

2. Well-documented

3. Accurate

4. Credible


2. When a program or project carries less economic risk, an extensive cost analysis may not be cost-effective. In these cases, the cost estimate should conform to the four pillars: comprehensive, well-documented, accurate, and credible. Contact the Associate CFO for Corporate Budget if you need assistance in customizing GAO’s 12-Step Cost Estimation Model methodology to your specific cost estimation needs.


**1.33.9.3.1** **(08-27-2025)**

#### Comprehensive

1. Cost estimates must be defined and structured with sufficient detail to ensure cost elements are not omitted or double-counted.

2. The following are essential elements for a comprehensive cost estimate:



1. Purpose

2. Plan

3. Relationships

4. Work Breakdown Structure (WBS)

5. Ground Rules and Assumptions


**1.33.9.3.1.1** **(08-27-2025)**

##### Purpose

1. A comprehensive cost estimate objectively defines the purpose and scope of the estimate and requires a comprehensive program description.

2. Understanding the program and documenting the needs, requirements and challenges for the cost estimate is essential.

3. Cost estimates prepared to support comparative analysis of two or more alternatives need to include all cost elements for each alternative and make each alternative’s cost transparent for informed decision making.

4. Comprehensive cost estimates include cost for the project's or capital asset's full life-cycle. Full life-cycle costs are direct and indirect costs from inception to design, development, deployment, operation and maintenance, and retirement of the program or asset. Ensure start-up and program termination costs are included and documented.

5. Omitting or overlooking life-cycle cost might jeopardize meeting the criteria of a high-quality, reliable cost estimate.


**1.33.9.3.1.2** **(08-27-2025)**

##### Plan

1. Consider the following when developing a cost estimation plan:



1. Develop the plan based on the type of cost estimates and cost estimating available procedures.

2. Determine the estimating structure, identify the cost estimating team and subject matter experts, and develop a master schedule and timeline.

3. Identify the team or party responsible for an independent cost estimate based on the materiality of the estimate.


**1.33.9.3.1.3** **(08-27-2025)**

##### Relationships

1. For non-IT cost estimates, define program characteristics, understand the technology implications, systems relationships, security needs and risk.



### Note:






**IT cost estimates are required to follow IT estimating policies.**

2. Identify a variable or driver that can be used to demonstrate a measurable relationship with costs. The cost estimating relationship may be represented mathematically (for example ratio of cost over output i.e. calls, cases, letters, etc.) or may involve a complex calculation or comparison.


**1.33.9.3.1.4** **(08-27-2025)**

##### Work Breakdown Structure (WBS)

1. Consider the following when developing a WBS:



1. Determine the cost estimating structure and document the cost estimation process.

2. Define terms in a data dictionary.

3. Present WBS elements in the cost estimating plan in a logical and sequential manner.

4. Follow GAO best practices for WBS standardization using templates or other formats that help visualize inclusion of all elements.


**1.33.9.3.1.5** **(08-27-2025)**

##### Ground Rules and Assumptions

1. Consider the following when developing the estimate’s ground rules and assumptions:



1. Identify and clearly define what the estimate includes and excludes.

2. Base cost estimates on a thorough analysis of best available data and facts supported by sounded, detailed, unbiased assumptions. Keep the estimate as objective as possible.

3. Document the rationale and historical data supporting ground rules and assumptions.


**1.33.9.3.2** **(08-27-2025)**

#### Well-documented

1. Cost estimates need to identify rationales, assumptions, original source data, and methodologies used for calculations. Documentation should be sufficient that the calculations can easily be repeated or updated by others.

2. The results of the estimating process should be presented neatly in a format that makes it easy to prepare reports and briefings to IRS leadership and oversight stakeholders.

3. The following is the 12-step process set forth by GAO as criteria for high-quality, reliable, well-documented cost estimates:



01. Define the estimate’s purpose.

02. Develop the estimating plan.

03. Define the program and relationship.

04. Determine the estimate WBS.

05. Identify ground rules and assumptions.

06. Collect data.

07. Conduct sensitivity analysis.

08. Conduct risk and uncertainty analysis.

09. Document the estimate.

10. Obtain an Independent Cost Estimate assessment when deemed necessary. Refer to _IRM 1.33.9.3.4.2_, Independent Cost Estimates.

11. Present the estimate to management for approval.

12. Update the estimate to reflect actual costs and changes.


**1.33.9.3.3** **(08-27-2025)**

#### Accurate

1. Cost estimates are accurate when they are developed by using the most appropriate and consistent methodology in data collection, mathematical formulas, databases, inputs and validation checks.

2. The following are essential elements of accurate cost estimates:



1. Data

2. Sensitivity Analysis

3. Risk and Uncertainty


**1.33.9.3.3.1** **(08-27-2025)**

##### Data

1. The following components are essential for reliable data collection and analysis:



1. Collect data from consistent, reliable sources. Analyze and compare historical data for trends, outliers and inflection. Inflection points are more significant than day-to-day progress, and their effects can be far-reaching. Examples of inflection points are changes in legislation, regulations, or available technology.

2. Compare cost data to output data or data metrics.

3. Investigate possible data sources, ranking them by consistency and reliability. When available, use IRS official systems of record to support the cost estimate. For example, the Integrated Financial System is the official system of record for administrative financial management and Master File is the official system of record for taxpayer data.

4. Validate data by using best practices such as cross-checks and error checking.

5. Express cost estimates in constant year dollars, time-phase results, or total costs.

6. Identify metrics for estimating potential future cost when feasible.

7. Store data used for the estimate in a secure location accessible to other users with the appropriate permissions to use the data and need to know.

8. Ensure data cost models and tools are error free.


**1.33.9.3.3.2** **(08-27-2025)**

##### Sensitivity Analysis

1. Sensitivity analysis is a method for modeling risk and understanding how different variables affect the outcome of a project, program or asset. Risk analysis is a process for assessing the likelihood of adverse events that could negatively impact the IRS.

2. For cost estimates to fully align with best practices of cost estimation, sensitivity analysis should be considered and documented. Cost estimate materiality and professional judgment should be considered when assessing the need for sensitivity analysis.

3. When conducting sensitivity analysis, consider the following:



1. Determine which assumptions are key cost drivers and which cost elements are most affected by changes.



      ### Note:



      Refer to IRM 1.33.5.2.5.1(2), Selection of a Costing Assignment Technique, for example of cost drivers.

2. Identify key elements that drive cost using a "what-if" analysis. Elements should be analyzed and adjusted for each potential driver to identify the effect on the overall estimate. This will help determine which activities have the greatest effect on the program cost.


4. Economic Analysis is a type of sensitivity analysis prescribed by [GAO-18-151SP, Assessment Methodology for Economic Analysis](https://www.gao.gov/products/gao-18-151sp). GAO may review economic analyses that are intended to inform decision-makers and stakeholders about the economic effects of a public program or action. GAO regards Economic Analysis as an essential feature of high-quality sensitivity analysis.



### Note:



Refer to _IRM 1.33.9.5_, Economic Analysis.


**1.33.9.3.3.3** **(08-27-2025)**

##### Risk and Uncertainty

1. Risk is the probability of an unpredictable outcome. Uncertainty is a lack of knowledge about the possibility of an outcome. To the extent possible consider the following:



1. Identify and address uncertainties, unpredictability and potential risks associated with the estimate.

2. Use available risk assessment techniques to conduct risk and uncertainty analysis.

3. Consider risk and uncertainties from a financial or reputation perspective.


**1.33.9.3.4** **(08-27-2025)**

#### Credible

1. Credible, unbiased cost estimates discuss and document data analysis limitations, risks, uncertainty, or special circumstances surrounding source data and assumptions. They include a risk and uncertainty analysis that determines the level of confidence associated with the estimate.

2. The following are elements for credibility criteria:



1. Document

2. Independent Cost Estimates

3. Managerial Approval

4. Update the Estimate to Reflect Actual Costs and Changes


**1.33.9.3.4.1** **(08-27-2025)**

##### Document

1. Recording a cost estimate in writing and other forms is crucial to assess the credibility of a cost estimate. Consider the following criteria when documenting cost estimates:



1. Documentation should follow the guidelines for well-documented estimates specified in GAO’s Cost Estimating and Assessment Guide. Refer to _IRM 1.33.9.3.2_, Well-documented.

2. Document the cost estimating process, methodologies, calculations and conclusion in an orderly, comprehensive manner.

3. Document the cost estimate with the best available data and facts known at the time of the preparation of the estimate.

4. Ensure cost estimate documentation includes a clearly written summary using plain language, clearly labeled tables that describe the data used and results and a conclusion that is consistent with the results.


**1.33.9.3.4.2** **(08-27-2025)**

##### Independent Cost Estimates (ICE)

1. An independent cost estimate (ICE) is used to validate a project cost baseline. It is different than an independent government cost estimate, which is generally used to support a procurement. An ICE is a cost estimating best practice recommended by GAO. It is typically performed by a group independent of the group that prepared the baseline estimate or an outside firm. When deemed necessary, obtain an ICE assessment.


**1.33.9.3.4.3** **(08-27-2025)**

##### Managerial Approval

1. The managerial review process ensures a full accounting of all costs required to develop and deliver a program.

2. The following are basic requirements for managerial approval:



1. Develop a cost estimate briefing and present the documented life-cycle cost estimate to management for approval.

2. Ensure that cost estimates are reviewed by the program or project manager, proposed sponsor and other leadership as appropriate.

3. Validate assumptions. The review process is used to validate assumptions, data analysis and facilitate a common understanding of the cost estimating results. It’s also used to obtain management sign-off on the cost estimate.

4. Obtain approval by management for program description, relationships, and program risk.


**1.33.9.3.4.4** **(08-27-2025)**

##### Update the Estimate to Reflect Actual Costs and Changes

1. Consider the following when updating cost estimates:



1. Update the cost estimate to reflect actual costs and changes at milestone decisions.

2. Continuously improve and enhance cost estimates, estimating techniques and adapt data and assumptions to changing circumstances and inflation. Inflation is a general increase in the prices of goods and services. It’s usually measured using the consumer price index. Refer to _IRM 1.33.9.1.8 (8)_,Bureau of Labor Statistics Consumer Price Index (CPI) Inflation Calculator.

3. Compare and analyze cost estimates to actual costs, evaluate relationships and update and document cost estimate accordingly.

4. Determine any cost variances, the difference between the estimated cost of a task, project, product, program, procurement or capital asset and its actual cost. Cost variance analysis helps programs evaluate deviations from the budgeted or standard costs and identify areas where costs are over or under budget.


**1.33.9.4** **(08-27-2025)**

### Imputed Costs

1. When planning a cost estimate, an understanding of the estimate’s intended use will help determine whether imputed costs should or should not be included.

2. In general, imputed costs are not considered in computing the full cost of a program because such costs are not a part of the IRS budget. Imputed costs are usually omitted to prevent overstating the IRS resources required for a particular product or service.

3. If imputed cost is known when preparing the cost estimate, it should be noted in the cost estimate (even when not included in the calculation). Imputed costs should be considered throughout the life cycle of the cost estimate and documented as appropriate.

4. Imputed costs include services provided by:



1. U.S. Department of the Treasury.

2. Office of Personnel Management.

3. Office of Management and Budget.

4. Any other agency IRS is not required to reimburse.


**1.33.9.5** **(08-27-2025)**

### Economic Analysis

1. GAO defines an economic analysis as an analysis that is intended to inform decision-makers and stakeholders about the economic effects of an action or program.

2. Economic effects commonly include costs, benefits, and economic transfers (for example, transfer payments).

3. Action is defined to include a government law, rule, regulation, project, policy, or program. An action may be examined in the context of legislation, regulation, advocacy, agency operations, or in response to certain events such as a natural disaster.

4. A best practice for economic analysis is a transparent methodology including analytical choices and assumptions.

5. An economic analysis may be prospective, examining an action that could be taken, or retrospective, examining the outcome of an action already taken.

6. Examples of economic analyses include:



1. An economic analysis of the costs of a government program, project, or policy.

2. An economic analysis of the benefits and costs of a government rule or regulation.

3. An economic analysis of the impact of a proposed or existing regulation on regulated entities and consumers

4. An economic analysis of an action in response to an event (for example, an analysis of a federal response to a natural disaster).

5. A benefit-cost analysis or cost-effectiveness analysis.


**1.33.9.5.1** **(08-27-2025)**

#### Key Elements of an Economic Analysis

1. GAO identifies five key methodological elements to the baseline structure of an economic analysis. These key elements are:



1. Objective and scope: Define the objective and scope of the analysis.

2. Methodology: Define and describe the methodology used to examine the economic effects.

3. Analysis of effects: Examine the analysis of economic effects.

4. Transparency: Include the transparency of the analysis of economic effects.

5. Documentation: Include documentation in the analysis as applicable.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-033-009#addtoany "Show all")

A2A