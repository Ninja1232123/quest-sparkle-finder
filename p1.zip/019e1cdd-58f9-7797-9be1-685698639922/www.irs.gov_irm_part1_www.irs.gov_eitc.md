---
url: "https://www.irs.gov/irm/part1/www.irs.gov/eitc"
title: "404 | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/www.irs.gov/eitc#main-content)

# Page Not Found.

## Error 404.

Sorry, this page is not available.

Please check the web address or try searching by the keyword below.

Search

Include Historical Content

\- Any -No

Include Historical Content

\- Any -No

Search

A2A