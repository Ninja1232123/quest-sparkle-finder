---
url: "https://www.irs.gov/irm/part1/irm_01-033-004"
title: "1.33.4 Financial Operating Guidelines | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-033-004#main-content)

- 1.33.4  [Financial Operating Guidelines](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388897829888)
  - 1.33.4.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926553472)
    - 1.33.4.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926504336)
    - 1.33.4.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388899516928)
    - 1.33.4.1.3  [Funds Control Responsibilities](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926444576)
      - 1.33.4.1.3.1  [Associate CFO for Corporate Budget](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926440368)
      - 1.33.4.1.3.2  [Division Finance Officer](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926436832)
      - 1.33.4.1.3.3  [Financial Plan Manager](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926434704)
    - 1.33.4.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926431824)
    - 1.33.4.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926562064)
    - 1.33.4.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898954672)
    - 1.33.4.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926544272)
    - 1.33.4.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388899498096)
  - 1.33.4.2  [Policies](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388899490032)
    - 1.33.4.2.1  [Applicable Guidance](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388899488336)
      - 1.33.4.2.1.1  [Overview of Critical Funds Control Concepts](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926497072)
        - 1.33.4.2.1.1.1  [Purpose: the Necessary Expense Doctrine](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926488048)
        - 1.33.4.2.1.1.2  [Time: the Bona Fide Needs Doctrine](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926478560)
        - 1.33.4.2.1.1.3  [Amount](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926454960)
    - 1.33.4.2.2  [Legislative Policies](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926449120)
      - 1.33.4.2.2.1  [Appropriation Transfers](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926447232)
      - 1.33.4.2.2.2  [Reprogramming Guidelines](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926420480)
        - 1.33.4.2.2.2.1  [Budget Activity Limitations](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926418720)
        - 1.33.4.2.2.2.2  [Financial Plan Manager Responsibilities for Reprogramming Limitations](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926414384)
    - 1.33.4.2.3  [Internal Budget Execution Policies](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926410960)
      - 1.33.4.2.3.1  [Managing within Resource Availability](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926406928)
      - 1.33.4.2.3.2  [Financial Reviews](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926403280)
        - 1.33.4.2.3.2.1  [Labor Reviews](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926400544)
        - 1.33.4.2.3.2.2  [Budget Execution Activity Reports Reviews](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926398240)
        - 1.33.4.2.3.2.3  [Midyear/Spend Plan Review](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926396224)
        - 1.33.4.2.3.2.4  [Aging of Unliquidated Commitments and Aging of Unliquidated Obligations Reviews](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926386304)
      - 1.33.4.2.3.3  [Financial Plan Manager Authority](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926383408)
      - 1.33.4.2.3.4  [Separation of Duties](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926378160)
      - 1.33.4.2.3.5  [Managing the Integrated Financial System](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926373824)
        - 1.33.4.2.3.5.1  [Integrated Financial System Version Descriptions](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926372096)
        - 1.33.4.2.3.5.2  [Integrated Financial System Budget Distribution Levels](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926365104)
        - 1.33.4.2.3.5.3  [Elimination of Budget Deficits in Version 0](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926355696)
        - 1.33.4.2.3.5.4  [Correcting Negative Disbursements](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926352816)
        - 1.33.4.2.3.5.5  [Prohibition of "Top Node" Distributions](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926350560)
        - 1.33.4.2.3.5.6  [Keeping Full-Time Equivalents Aligned With Labor](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926348432)
      - 1.33.4.2.3.6  [Financial Codes](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926346240)
      - 1.33.4.2.3.7  [Reorganizations and Other Modifications Affecting Budget](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388926341600)
      - 1.33.4.2.3.8  [Labor Costs Reprogramming](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898164176)
      - 1.33.4.2.3.9  [IT Reprogramming Authority](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898160800)
  - 1.33.4.3  [Operating Procedures](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898157712)
    - 1.33.4.3.1  [CFO Servicewide Procedures](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898156032)
      - 1.33.4.3.1.1  [Corporate Budget Responsibilities](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898155040)
      - 1.33.4.3.1.2  [Communications](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898150192)
      - 1.33.4.3.1.3  [Preparation of a Servicewide Operating Plan](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898145920)
      - 1.33.4.3.1.4  [Apportionments](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898139136)
        - 1.33.4.3.1.4.1  [Apportionments under a Continuing Resolution](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898130448)
      - 1.33.4.3.1.5  [Appropriation Transfer Procedures](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898126976)
      - 1.33.4.3.1.6  [Interagency Transfers](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898123520)
      - 1.33.4.3.1.7  [Realignments between Financial Plans](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898105952)
        - 1.33.4.3.1.7.1  [Arrangements between Financial Plans](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898104208)
        - 1.33.4.3.1.7.2  [Realignments Requiring Assistance from Corporate Budget](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898089888)
      - 1.33.4.3.1.8  [Labor Projections and Charging Labor Cost](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898086992)
        - 1.33.4.3.1.8.1  [Labor Projections](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898085024)
        - 1.33.4.3.1.8.2  [Charging Labor Costs, General](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898081104)
        - 1.33.4.3.1.8.3  [Charging Labor Costs, Details and Temporary Promotions](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898074656)
      - 1.33.4.3.1.9  [FTE Utilization Policies](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898063888)
        - 1.33.4.3.1.9.1  [Changing FTEs in the Integrated Financial System](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898059616)
      - 1.33.4.3.1.10  [Personnel Issues](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898056208)
        - 1.33.4.3.1.10.1  [Hardship Relocations](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898054528)
        - 1.33.4.3.1.10.2  [Hiring](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898051904)
      - 1.33.4.3.1.11  [Staffing Level Reports - Positions and FTEs](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898046656)
      - 1.33.4.3.1.12  [Cash (Monetary) Awards and Time-Off Awards](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898044384)
        - 1.33.4.3.1.12.1  [Cash (Monetary) Awards for Prior Fiscal Year](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898042608)
      - 1.33.4.3.1.13  [Buyouts](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898035536)
        - 1.33.4.3.1.13.1  [Servicewide Buyouts](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898033792)
        - 1.33.4.3.1.13.2  [Business Unit Buyouts](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898030064)
      - 1.33.4.3.1.14  [Travel and Above Standard Level Requests](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898028176)
      - 1.33.4.3.1.15  [Gainsharing Travel Savings Program](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898021360)
      - 1.33.4.3.1.16  [Statistics of Income, Functional Area 4Q](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898017840)
      - 1.33.4.3.1.17  [Treasury Franchise Fund](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898015632)
      - 1.33.4.3.1.18  [Rebates and Refunds](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898011808)
    - 1.33.4.3.2  [Financial Plan Managers’ Procedures](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898004880)
      - 1.33.4.3.2.1  [Funded Programs](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388898003872)
        - 1.33.4.3.2.1.1  [Funded Programs – Information Technology and BSM Programs](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388897999168)
      - 1.33.4.3.2.2  [Tracking Event-Related Spending](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388897995104)
      - 1.33.4.3.2.3  [Training Programs](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388897992256)
      - 1.33.4.3.2.4  [Object Class 42, Insurance Claims and Indemnities Funding](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388897986672)
      - 1.33.4.3.2.5  [Rent Program and Building Delegation](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388897980512)
      - 1.33.4.3.2.6  [Electronic Tax Research Services](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388897974272)
      - 1.33.4.3.2.7  [Direct, Indirect and Centralized Support](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388897971840)
      - 1.33.4.3.2.8  [Jury Fees](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388897930336)
      - 1.33.4.3.2.9  [Food and Refreshments](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388897923248)
    - 1.33.4.3.3  [IT BAC 98 Procedures](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388897920528)
      - 1.33.4.3.3.1  [Policy on Procuring IT Products and Services](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388897918128)
    - 1.33.4.3.4  [Operations Support and BSM Appropriations Reporting Requirements](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388897912048)
    - 1.33.4.3.5  [Federal Highway Administration Trust Fund](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388897908464)
    - 1.33.4.3.6  [Private Collection Agency Expenditure Fund](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388896405952)
  - 1.33.4.4  [Accounting Issues](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388896402576)
    - 1.33.4.4.1  [Interagency Agreements or Reimbursable Agreements](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388896401616)
      - 1.33.4.4.1.1  [Reimbursable Work Authorizations and Security Work Authorizations](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388896395776)
      - 1.33.4.4.1.2  [Intra-governmental Payment and Collection](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388896392304)
      - 1.33.4.4.1.3  [Reimbursable Operating Guidelines](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388896388864)
    - 1.33.4.4.2  [Vendor Payments](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388896386128)
    - 1.33.4.4.3  [Commitments/Obligations](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388896379808)
    - 1.33.4.4.4  [Unliquidated Commitments/Obligations](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388896376656)
    - 1.33.4.4.5  [User Fees](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388896372816)
    - 1.33.4.4.6  [Expired, Closed and No-Year Appropriations](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388896366400)
    - 1.33.4.4.7  [Prior Year Funds Management](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388896353504)
  - Exhibit  1.33.4-1  [Division Finance Officers and Financial Plan Managers](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388896351424)
  - Exhibit  1.33.4-2  [Master Data (Code) Change Request Procedure](https://www.irs.gov/irm/part1/irm_01-033-004#idm140388896307056)

# Part 1. Organization, Finance, and Management

# Chapter 33. Strategic Planning, Budgeting and Performance Management Process

# Section 4. Financial Operating Guidelines

* * *

## 1.33.4 Financial Operating Guidelines

#### Manual Transmittal

April 07, 2025

#### Purpose

(1) This transmits revised IRM 1.33.4, Strategic Planning, Budgeting and Performance Management Process, Financial Operating Guidelines.

#### Material Changes

(1) _IRM 1.33.4.3.2.7_, Direct, Indirect and Centralized Support, _Exhibit 1.33.4-1_, Division Finance Officers and Financial Plan Managers, and a few other references updated reflect organizational changes in senior leadership, CFO and Taxpayer Services (formerly Wage & Investment).

(2) _IRM 1.33.4.4.1_, Interagency Agreements or Reimbursable Agreements, edited to mention G-Invoicing.

(3) _IRM 1.33.4.4.6_, Expired, Closed and No-Year Appropriations, edited to use current fiscal year examples.

(4) Numerous editorial changes and various updates to website references throughout.

#### Effect on Other Documents

This IRM supersedes IRM 1.33.4, Financial Operating Guidelines, dated February 7, 2023.

#### Audience

The IRS budget community in all divisions and functions, especially the division finance officers (DFOs), financial plan managers (FPMs) and their staffs.

#### Effective Date

(04-07-2025)

Teresa R. Hunter

Chief Financial Officer

**1.33.4.1** **(02-07-2023)**

### Program Scope and Objectives

1. Purpose: IRM 1.33.4, the Financial Operating Guidelines (FOG), assists IRS budget and finance professionals in fulfilling their responsibilities to manage budgetary resources effectively.

2. Audience: The IRS budget community in all divisions and functions, especially the division finance officers (DFOs), financial plan managers (FPMs) and their staffs.

3. Policy Owner: The CFO’s Corporate Budget office is responsible for policy decisions reflected in the FOG.

4. Program Owner: The FOG is published by Corporate Budget. Comments and change requests may be submitted to the Corporate Budget’s director, Financial Planning and Analysis Office. Future revisions, including interim guidance, will be posted to the CFO - Home SharePoint site.

5. Primary Stakeholders: All IRS management, especially the IRS budget community in all divisions and functions.

6. Program Goals: To assist FPMs and other budget and finance professionals in fulfilling their responsibilities to manage budgetary resources effectively. The IRM is not specific to a fiscal year (FY) and is in effect until superseded. These guidelines take precedence over any previous financial operating instructions.



### Note:



During a continuing resolution (CR), additional guidance specific to the CR will be posted on the CFO - Home site


**1.33.4.1.1** **(03-14-2019)**

#### Background

1. This IRM provides internal financial guidance for the budget execution phase of the budget cycle and assists FPMs in fulfilling their responsibilities to manage budgetary resources effectively.

2. This guidance provides funds control regulations, as required by [OMB Circular A-11, Preparation, Submission and Execution of the Budget](https://www.whitehouse.gov/omb/information-for-agencies/circulars/#budget), Part 4, Section 150, Administrative control of funds.

3. This guidance focuses on managing, monitoring and controlling the money that Congress appropriates to the IRS, including user fees. To comply with the _Antideficiency Act_ and applicable provisions of appropriations law, the IRS cannot spend or obligate more than the Congress has appropriated and may use funds only for purposes specified in law. The _Antideficiency Act_ also prohibits the IRS from spending or obligating funds in advance of an appropriation, unless specific authority to do so has been provided in law. Each FPM must comply with the _Antideficiency Act_ and appropriations law.

4. This guidance is issued by Corporate Budget.


**1.33.4.1.2** **(02-07-2023)**

#### Authorities

1. The authorities for this IRM include:



1. [Government Accountability Office’s (GAO) Principles of Federal Appropriations Law (the Red Book)](https://www.gao.gov/legal/appropriations-law/red-book)

2. [OMB Circular A-11, Preparation, Submission and Execution of the Budget](https://www.whitehouse.gov/omb/information-for-agencies/circulars/#budget)

3. OMB Circular 025, User Charges

4. Chief Financial Officers Act of 1990, Public Law (PL) 101-576, 104 Stat. 2838

5. [Antideficiency Act, PL 97-258](https://www.congress.gov/bill/97th-congress/house-bill/6128), 96 Stat. 923

6. [Congressional Budget and Impoundment Control Act of 1974, PL 93-344](https://www.congress.gov/bill/93rd-congress/house-bill/7130), 88 Stat. 297

7. Appropriation law in Title 31 of U.S. Code, especially these sections: 31 U.S. Code 1301 (a), the purpose statute; 31 U.S. Code 1501, the recording statute; 31 U.S. Code 1502, (a), the bona fide needs statute; 1 U.S. Code 1535, the Economy Act provisions; 31 U.S. Code 1551-1558, account closing; and 31 U.S. Code 3302, the Miscellaneous Receipts Act provisions.


**1.33.4.1.3** **(02-07-2023)**

#### Funds Control Responsibilities

1. This section provides funds control responsibilities for the Associate CFO for Corporate Budget, DFOs and FPMs.

2. The _Antideficiency Act_ provides administrative and criminal penalties for obligating or expending in excess of available appropriations. See [OMB Circular A-11](https://www.whitehouse.gov/omb/information-for-agencies/circulars/#budget), Part 4, Section 145, _Requirements for Reporting Antideficiency Act Violations_.


**1.33.4.1.3.1** **(03-14-2019)**

##### Associate CFO for Corporate Budget

1. The Associate CFO for Corporate Budget formally bears the legal responsibility to ensure that the IRS does not violate the _Antideficiency Act_ at the bureau level. To meet the IRS’s collective funds management responsibilities, the Associate CFO for Corporate Budget relies on the DFOs for compliance with the law and these guidelines.

2. The Associate CFO for Corporate Budget delegates funds control responsibilities to the division commissioners and chiefs for the funds in their financial plans.


**1.33.4.1.3.2** **(03-14-2019)**

##### Division Finance Officer

1. The DFOs bear the ultimate responsibility for the funds control of their financial plans, as well as managing their plans through all phases of the budget cycle. See _Exhibit 1.33.4-1_, Division Finance Officers and Financial Plan Managers.


**1.33.4.1.3.3** **(03-14-2019)**

##### Financial Plan Manager

1. The FPMs are responsible for day-to-day operations of monitoring and controlling their financial plans' funds in the execution phase of the budget cycle. See _Exhibit 1.33.4-1_, Division Finance Officers and Financial Plan Managers.

2. Funds control and document approval authority may be delegated to individuals within the organization, as needed; for example, the Procurement for Public Sector (PPS) module in the Integrated Financial System (IFS) identifies FPMs as those with delegated authority to approve documents that commit and obligate funds.


**1.33.4.1.4** **(03-14-2019)**

#### Program Management and Review

1. Program reports: Corporate Budget monitors financial plans monthly and through more comprehensive reviews using IFS reports and queries, including the Status of Available Funds report and the Aging Unliquidated Commitments (AUC) report. FPM responsibilities include using IFS to identify surpluses or deficits early, so that the IRS can optimize resource use.

2. Program effectiveness: To monitor and manage IRS resources, business units participate in several Corporate Budget financial reviews throughout the year, including the midyear/spend plan review and other formal reviews described in _IRM 1.33.4.2.3.2_, Financial Reviews.


**1.33.4.1.5** **(03-14-2019)**

#### Program Controls

1. The DFOs and FPMs have funds control responsibility for their financial plans. They must oversee all financial operations affecting the financial plans’ funding availability and requirements in the execution phase of the budget cycle, and monitor spending to ensure it does not exceed the funding allocation. See _IRM 1.33.4.1.3_, Funds Control Responsibilities.



### Note:



Several IFS reports, such as the Status of Available Funds and Status of Availability Control reports, are available for DFOs and FPMs to monitor funds. DFOs and their staffs should be familiar with the features of these reports and run them regularly to monitor the funds for which they are responsible.

2. IFS is the system of record that DFOs and FPMs must use to manage budgetary resources effectively. IFS includes availability controls (AVC) to help prevent the IRS from going deficient for non-labor expenses. IFS will restrict spending for non-labor if there is insufficient budget at the AVC level; however, the system allows labor to post even when there are no funds available. Therefore, the DFOs and FPMs must review overall funds availability before the posting of payroll and must ensure that the plan balance will not go negative when payroll posts.



### Note:



Servicewide AVCs keep the IRS from over-obligating at the fund level. Each business unit also has customized AVCs for its financial plan at a chosen master data element or combination of master data elements, including fund, fund center, functional area, commitment item and funded program.





### Exception:



During a CR, the AVC levels are only maintained at the IFS fund level.

3. The DFOs and FPMs must establish commitment and obligation targets to ensure they will not violate [OMB Circular A-11](https://www.whitehouse.gov/omb/information-for-agencies/circulars/#budget), the Antideficiency Act, or appropriations law; see _IRM 1.33.4.2.3.2.3_, Midyear/Spend Plan Review.


**1.33.4.1.6** **(02-07-2023)**

#### Terms/Definitions

1. The following terms apply to this IRM:



01. **Accrued expense** \- An accounting transaction to record the receipt of goods or services without the issuance of cash, check or electronic funds transfer (EFT) at the end of an accounting period (for example, the amount of unpaid payroll at the end of each month).

02. **Apportionment** \- A funds allocation plan, approved by OMB, to spend resources provided by one of the annual appropriations acts, a supplemental appropriations act, a continuing resolution, or a permanent law (mandatory appropriations). Resources are apportioned by Treasury Appropriation Fund Symbol (TAFS), also known as Treasury Account Symbol (TAS). The apportionment identifies amounts available for obligation and expenditure. It specifies and limits the obligations that may be incurred and expenditures made (or makes other limitations, as appropriate) for specified time periods, programs, activities, projects, objects or any combination thereof. An apportionment may be further subdivided by an agency into allotments, sub-allotments and allocations.

03. **Appropriation** \- A provision of law (not necessarily in an appropriations act) authorizing the obligation and expenditure of funds for a given purpose. Usually, but not always, an appropriations act provides budget authority and funds to operate for the full fiscal year. IRS funding might come in its regular annual appropriation act, an omnibus act, a supplemental appropriation, a CR, or pursuant to a permanent appropriation. In IFS, an appropriation is represented by the "Application of Funds" code and may be a single fund or a combination of many IFS funds (see sub-appropriation).

04. **Appropriation Report Group** \- A major grouping of IFS funds in IFS Business Warehouse (BW) used for reporting purposes. Along with Appropriation Type, this parameter allows BW reports to group sub-appropriations to the legal level of an appropriation. Important groups are: Appropriated Current Year, Carryover, Reimbursables, and User Fees. For example, the current year IFS funds for 0912, 09D2, 09E2, 09Y2 and the 0912Q fund are all in the group ‘Appropriated Current Year’ group and ‘TS’ type, which ties directly to the Taxpayer Services appropriation.

05. **Appropriation Type** \- A secondary grouping of IFS funds in IFS BW used for reporting purposes. Along with Appropriation Report Group, this parameter allows BW reports to group sub-appropriations to the legal level of an appropriation. For example, the current year IFS funds for 0912, 09D2, 09E2, 09Y2 and the 0912Q fund are all in the group ‘Appropriated Current Year’ group and ‘TS’ type, which ties directly to the Taxpayer Services appropriation.

06. **Bona fide needs rule** \- The principle that a fiscal year appropriation may be used only for a legitimate, or bona fide, need arising in, or in some cases arising prior to but continuing to exist in, the fiscal year for which the appropriation was made. Title 31 U.S. Code Section 1502(a) (the bona fide needs statute) provides: "The balance of an appropriation or fund limited for obligation to a definite period is available only for payment of expenses properly incurred during the period of availability or to complete contracts properly made within that period of availability and obligated consistent with section 1501 of this title. However, the appropriation or fund is not available for expenditure for a period beyond the period otherwise authorized by law."

07. **Budget** \- The budget of the U.S. Government, which sets forth the government’s comprehensive financial plan and indicates the government’s priorities for federal spending.

08. **Budget authority** \- The authority provided by law to incur financial obligations that will result in outlays. Specific forms of budget authority include appropriations, borrowing authority, contract authority and spending authority from offsetting receipts and collections.

09. **Closed appropriation** \- An appropriation that, having passed the last expired year, has been canceled and the balances are no longer available for obligation or expenditure for any purpose.

10. **Commitment** \- An administrative reservation of funds prior to obligation of funds. Typically, commitments are created by a purchase requisition.

11. **Commitment item** \- A subdivision of expense used to classify the organization's consumption of resources. The first two digits of the four-digit code represent the higher-level object class.

12. **Continuing resolution (CR)** \- An appropriation act that provides budget authority for federal agencies, specific activities, or both to continue operations, usually for a specific duration when Congress and the President have not completed action on the regular appropriation acts by the beginning of the fiscal year. A CR usually specifies a maximum rate at which the obligations may be incurred based on levels specified in the resolution. When the IRS is under a CR, Corporate Budget publishes special CR operating procedures on the CFO - Home site.

13. **Cost center** \- A data element in IFS that represents a clearly-defined location where costs incur and represents the lowest level in the organizational hierarchy, below the fund center. Cost center captures costs only, not revenue. Cost centers are usually linked to Treasury Integrated Management Information System (TIMIS) codes but can also be established for non-labor areas.

14. **Direct support** \- Support costs that can be reasonably identified and charged to a specific activity.

15. **Disbursement** \- An outlay, including the issuance of cash, a check, or an EFT.

16. **Division finance officer** \- The person who has been delegated by their division commissioner or chief with full responsibility for its financial plan, including overseeing funds control and managing all phases of the budget cycle. See also financial plan manager.

17. **Expenditure** \- The actual spending of money; an outlay. The definition does not mention receipt of goods or services.

18. **Expired appropriation** \- An annual or multiyear appropriation for which the period of availability established by law has passed and for which new obligations may NOT be incurred. Balances are available only for upward and downward adjustments to existing or unrecorded obligations during the five years after the appropriation expires.

19. **Financial plan** \- A subdivision of funds in IFS, which may be further subdivided into fund centers. Typically, there is a one-to-one relationship of financial plan to business unit, but a few business units manage multiple financial plans. See the financial plans table in the Financial Management Codes Handbook, found on the CFO - Home site, specifically Corporate Budget’s Key Budget Tools.

20. **Financial plan manager** \- The person responsible for day-to-day operations of monitoring and controlling a financial plan’s funds in the execution phase of the budget cycle.

21. **Fiscal year** \- The federal government’s accounting period, which begins on October 1 and ends on September 30, and is designated by the calendar year in which it ends.

22. **Full-time equivalent (FTE)** \- The basic measure of the employment levels used in the budget. It is the total number of regular, straight-time hours (that is, not including overtime or holiday hours) worked by employees divided by the number of compensable hours applicable to each fiscal year. Annual leave, sick leave, compensatory time off and other approved leave categories are considered hours worked for purposes of defining full-time equivalent employment.

23. **Functional area** \- A data element in IFS that represents an activity, such as Submission Processing.

24. **Fund** \- A source of financing for federal agencies. Types of funds include revolving funds, custodial funds and direct or reimbursable appropriations. In IFS, the fund field indicates the appropriation; there can be multiple IFS funds in one appropriation.

25. **Fund center** \- A subdivision of a financial plan in IFS representing an organization’s areas of funds management responsibility.

26. **Funded program** \- A project for which we collect and track costs, formerly called internal order. The IFS data element is still referred to as an internal order code or IOC.

27. **Funds commitment** \- Funds that are reserved in the IFS Funds Management module; for example, entering a purchase request creates a commitment; entering a requisition creates an obligation.

28. **Indirect support** \- Support costs that cannot be reasonably identified and charged to a specific activity and will be charged to the predominantly benefiting functional area.

29. **Integrated Financial System (IFS)** \- The administrative accounting system used by the IRS. IFS is composed of four modules: Budget Control System (BCS), Materials Management (MM), Financial Accounting (FIA) and Controlling (CO). Key features of IFS include integrated modules covering many business functions, real-time data entry, online information, drill-down capability, enhanced reporting capability and simplified research.

30. **Interagency agreement (IAA)** \- An interagency arrangement in which the IRS pays another agency for work performed or goods or services provided.

31. **Internal order code (IOC)** \- A data element in IFS that collects expenditure data for funded programs, formerly called internal orders. IOCs are used to monitor costs and, in some instances, revenues of internal jobs and/or tasks.

32. **Master data** \- Key data elements or codes representing the organizational structure and operations (such as business units, offices, appropriations and functional areas). Master data is stored on a long-term basis and can be incorporated into individual transactions, has an organizational aspect, remains the same over long periods of time, and facilitates reporting, retrieval and validation of information.

33. **Material group code (MGC)** \- See product category code.

34. **Object class (OC)** \- Classification of expense according to type as prescribed by [OMB Circular A-11](https://www.whitehouse.gov/omb/information-for-agencies/circulars/#budget); such as personal services, travel and equipment. Historically, this was a two-digit code (for example, OC 11 and OC 25); however, the OMB OC is now a more detailed three-digit code (for example, OCs 11.1, 11.3, 25.1, 25.2). See also, commitment item.

35. **Obligated balance** \- The cumulative amount of budget authority that has been obligated but not yet outlaid. It is also known as unpaid obligations (which are made up of accounts payable and undelivered orders), net of accounts receivable and unfilled customer orders.

36. **Obligation** \- A definite commitment that creates a legal liability of the government for the payment of goods and services ordered or received, or a legal duty on the part of the United States that could mature into a legal liability by virtue of actions on the part of the other party beyond the control of the United States. Budgetary resources must be available before obligations can legally be incurred.

37. **Omnibus appropriation** \- A type of spending bill that packages multiple regular appropriation bills into one single consolidated bill that can be passed with only one vote in each house.

38. **Onrolls** \- The number of employees in pay status at the end of a pay period; permanent onrolls are used for straight-line permanent labor cost projections.

39. **Operational support contracts** \- Contracts supporting IRS operations that are not assigned to a specific project code. Operational support contracts and similar IAAs are tracked by "K contracts." These operational support contracts and IAAs cover a wide spectrum of procurement mechanisms including, but not limited to: simple and large purchases for services and supplies (SS) and equipment; formal contracts for SS and specialized equipment; IAAs between the IRS and other federal/state/local governmental agencies; and other non-labor expenditures.

40. **Outlay**\- A payment to liquidate an obligation (other than the repayment of debt principal).

41. **Procurement for Public Sector (PPS) module** \- The IFS procurement module that replaced the Integrated Procurement System (IPS) in 2017.

42. **Product category code**\- A data element in IFS, formerly known as the material group code, used to group materials and services according to their characteristics. The product category code points to the ‘Federal Supply Code’ and general ledger account.

43. **Reimbursable agreement**\- An IAA where the IRS performs work for or provides good or services to another agency and they reimburse the IRS.

44. **Reimbursable obligation** \- An obligation financed by offsetting collections credited to an expenditure account in payment for goods and services provided by that account.

45. **Reprogram** \- To shift allocated funds within an appropriation or fund account to use them for different purposes than those planned at the time of appropriation (for example, obligating budgetary resources for a different object class from the one originally planned). While a transfer of funds involves shifting funds from one account (appropriation or fund) to another, reprogramming involves shifting funds within an account. .

46. **Rescission** \- A legislative action that permanently cancels new budget authority or the availability of unobligated balances of budget authority prior to the time the authority would otherwise have expired.

47. **Sequestration** \- A fiscal policy procedure, originally provided for in the Balanced Budget and Emergency Deficit Control Act of 1985 (P.L. 99-177, also known as Gramm-Rudman-Hollings). If the appropriation bills passed separately by Congress provide for total government spending in excess of the limits Congress earlier laid down for itself in the annual budget resolution, and if the Congress cannot agree on ways to cut back the total (or does not pass a new, higher budget resolution), then an "automatic" form of spending cutback takes place. This automatic spending cut is called "sequestration."

48. **Sub-appropriation** \- Part of a legal appropriation that is tracked by an IFS fund. Sub-appropriations are used for multiyear provisions in the legislation and for key programs. The Appropriation Report Group ‘Appropriated Current Year’ and Appropriation Type are used to summarize the IFS funds that make up the legal appropriation.

49. **Supplemental appropriation** \- A type of budget authority provided in an appropriations act in addition to regular or continuing appropriations already provided. For example, the FY 2018 omnibus bill had a provision in Section 113 to provide supplemental funds for tax reform implementation.

50. **Top node** – A budget address in IFS at the highest level of a code hierarchy. For example, "IRS Top Node" means a budget address as follows: fund center = IRS, commitment item = ALLOBJ, and functional area = ALFA.

51. **Training** \- As defined by the Government Employees Training Act (GETA), “the process of providing for and making available to an employee, and placing or enrolling the employee in, a planned, prepared, and coordinated program, course, curriculum, subject, system, or routine of instruction or education, in scientific, professional, technical, mechanical, trade, clerical, fiscal, administrative, or other fields which will improve individual and organizational performance and assist in achieving the agency's mission and performance goals.” 5 U.S. Code Section 4101 (4)

52. **Transfer** \- To move budgetary resources from one appropriation account to another.

53. **Treasury Franchise Fund (TFF)** \- An intradepartmental service operations fund operated by the Department of the Treasury. The TFF provides goods and services such as telecommunications, printing and reproduction, and equipment. Treasury bureaus make an advance payment prior to the receipt of goods, services or other assets.

54. **Unliquidated commitment** \- An administrative reservation of funds that has not yet become an obligation or otherwise been decommitted.

55. **Unliquidated obligation** \- An obligation that has not been expended.

56. **Unobligated balance** \- The cumulative amount of budget authority that is not obligated and that remains available for obligation under the law.

57. **User fees** \- Fees charged to users of goods or services provided by the government.

58. **Warrant** \- An official document issued by the Secretary of the Treasury, pursuant to law, that establishes the amount of appropriations approved by the Congress to be withdrawn from the United States Treasury.


**1.33.4.1.7** **(02-07-2023)**

#### Acronyms

1. A select list of acronyms and abbreviations are referenced for budget execution. To search a comprehensive list of IRS acronyms, see Acronym Database.




| **ACRONYMS AND ABBREVIATIONS** |
| :-: |
| 3YRF | 3-Year Rolling Forecast |
| ADA | Antideficiency Act |
| AUC | Aging of Unliquidated Commitments |
| AUO | Aging of Unliquidated Obligations |
| AVC | Availability Control |
| BAC | Budget Activity Code |
| BFC | Beckley Finance Center |
| BSM | Business Systems Modernization |
| BPS | Business Planning and Simulation |
| BU | Bargaining Unit (avoid abbreviating business unit) |
| CR | Continuing Resolution |
| DFO | Division Finance Officer |
| EUR | Enterprise Unfunded Requirement |
| FOG | _IRM 1.33.4_, Financial Operating Guidelines |
| FMSS | Facilities Management and Security Services |
| FPM | Financial Plan Manager |
| FTE | Full-Time Equivalent |
| FY | Fiscal Year |
| GAO | Government Accountability Office |
| GLS | General Legal Services |
| GSA | General Services Administration |
| IAA | Interagency Agreement |
| IOC | Internal order code (see funded program) |
| IFS | Integrated Financial System |
| IPAC | Intragovernmental Payment and Collection |
| OMB | Office of Management and Budget |
| OPM | Office of Personnel Management |
| PPS | Procurement for Public Sector module (replaced Integrated Procurement System, IPS) |
| SF | Standard Form |
| TIMIS | Treasury Integrated Management Information System |
| TFF | Treasury Franchise Fund |
| TS | Taxpayer Services |
| USC | United States Code |


**1.33.4.1.8** **(02-07-2023)**

#### Related Resources

1. Related resources for this IRM include:



1. [OMB Circular A-11](https://www.whitehouse.gov/omb/information-for-agencies/circulars/#budget)

2. OMB Circular 025, User Charges

3. [Government Accountability Office's Principles of Federal Appropriations Law](http://www.gao.gov/legal/redbook/redbook.html) (aka the Red Book)

4. [Office of Personnel Management's Guide to Processing Personnel Actions](http://www.opm.gov/feddata/gppa/gppa.asp)

5. Appropriation language, found on [Congress.gov](https://crsreports.congress.gov/AppropriationsStatusTable)

6. CFO - Home site

7. IRS Financial Management Codes Handbook, found on the CFO - Home site, specifically on Corporate Budget’s Key Budget Tools


**1.33.4.2** **(12-16-2014)**

### Policies

1. FPMs must follow these budgetary policies, which include both internal and external guidance.


**1.33.4.2.1** **(02-07-2023)**

#### Applicable Guidance

1. The budget execution process is governed by 31 U.S. Code Chapters 13, 15, 31 and 33. Among these, the major laws are the _Antideficiency Act_ (codified at 31 U.S. Code Sections 1341, 1342, 1512–1514 & 1517); the _Impoundment Control Act_ (2 U.S. Code Sections 601-688); the _Economy Act_ (31 U.S. Code Section 1535); the purpose statute (31 U.S. Code Section 1301(a)); the bona fide needs statute (31 U.S. Code Section 1502(a); the provisions that govern the closing of accounts (31 U.S. Code Sections 1551-1555); and the _Miscellaneous Receipts Act_ (31 U.S. Code Section 3302).

2. [OMB Circular A-11](https://www.whitehouse.gov/omb/information-for-agencies/circulars/#budget), provides an overview of the budget process; discusses the basic laws regulating the budget process; defines the basic terms and concepts associated with the budget process; provides guidance on how to prepare and submit budget-related materials required for OMB's review; and provides instructions on budget execution, funds control and periodic reporting.

3. [GAO's Principles of Federal Appropriations Law](http://www.gao.gov/legal/redbook/redbook.html) (also known as GAO's " _Red Book_" ), is a comprehensive collection of the body of case law governing the expenditure of federal funds. The _Red Book_ discusses specific legal authorities to illustrate legal principles, their application and exceptions. These references include GAO decisions and opinions, judicial decisions, statutory provisions and other relevant sources.

4. [Congress.gov](http://www.congress.gov/) has a wealth of information, including the [Appropriations Status Table](https://crsreports.congress.gov/AppropriationsStatusTable) with current-year bills and laws for the regular Financial Services appropriation or a continuing appropriation.

5. All FPMs and other budget and finance professionals must refer to and use these key regulations to manage, track and report budgetary activities. They also must have a working knowledge of the contents of [OMB Circular A-11](https://www.whitehouse.gov/omb/information-for-agencies/circulars/#budget), (especially _Part 4, Instructions on Budget Execution_), the appropriations language and this IRM.


**1.33.4.2.1.1** **(02-07-2023)**

##### Overview of Critical Funds Control Concepts

1. FPMs must know appropriations law concepts and be able to research specific details. Appropriations law (including the _Antideficiency Act)_, [OMB Circular A-11](https://www.whitehouse.gov/omb/information-for-agencies/circulars/#budget), the GAO [Red Book](http://www.gao.gov/legal/redbook/redbook.html), and other applicable guidance, provide information on funds control concepts. General Legal Services (GLS) is also available to assist with appropriations law questions. A short overview of the most important concepts follows. The bulk of this section is copied directly from the GAO [Red Book](http://www.gao.gov/legal/redbook/redbook.html), which has a wealth of information about specific purchases and circumstances. GAO's Comptroller General (Comp. Gen.) decisions are referenced in several places to provide fuller explanations of concepts.

2. The Antideficiency Act (ADA) prohibits federal employees from making expenditures or incurring obligations in advance of an appropriation, or in excess of amounts available in appropriation or fund accounts unless specifically authorized by law. It provides for administrative sanctions and both civil and criminal penalties for deficiencies. In addition, under the purpose statute, appropriated funds may be used only for the purposes for which they were appropriated.

3. Three things are required for appropriated funds to be legally available for obligation:



1. The purpose of the obligation or expenditure must be authorized.

2. The obligation must occur within the time limits applicable to the appropriation.

3. The obligation and expenditure must be within the amount the Congress has established.


4. In addition, no amount can be obligated before OMB apportions the appropriated funds. It is an ADA violation to incur an obligation against anticipated budget authority including offsetting collections.


**1.33.4.2.1.1.1** **(02-07-2023)**

###### Purpose: the Necessary Expense Doctrine

1. The necessary expense doctrine is described in the GAO [Red Book](http://www.gao.gov/legal/redbook/redbook.html), Chapter 3.B, "... Where an appropriation is made for a particular object, by implication it confers authority to incur expenses which are necessary or proper or incident to the proper execution of the object unless there is another appropriation which makes more specific provision for such expenditures, or unless they are prohibited by law...."



### Example:



Since IRS has a specific appropriation for Business Systems Modernization, BSM expenses must be charged to that appropriation, not a more general appropriation.

2. An appropriation for a specific object is available for that object to the exclusion of a more general appropriation, which might otherwise be considered available for the same object. The exhaustion of the specific appropriation does not authorize charging any excess payment to the more general appropriation unless there is specific language in the general appropriation to make it available in addition to the specific appropriation.



### Example:



Even if BSM funds are exhausted, IRS cannot charge BSM expenses to another appropriation.

3. Where two appropriations are available for the same purpose but neither can reasonably be called the more specific of the two, the IRS may select which one to charge for the expenditure in question. Once that selection has been made, the IRS must continue to use the same appropriation for that purpose unless the IRS, at the beginning of the following fiscal year, informs the Congress of its intent to change it (informally known as the "pick and stick rule" ).



### Example:



If the IRS has some discretion to charge a new expense for printing taxpayer education materials to either Taxpayer Services or Operations Support, and decides to charge it to Operations Support, then IRS must continue to charge it to Operations Support in future fiscal years, unless the agency informs Congress of its intent to change for the next fiscal year.

4. When applying the necessary expense rule, an expenditure is justified after meeting a three-part test:



1. The expenditure must bear a logical relationship to the appropriation to be charged.

2. The expenditure must not be prohibited by law.

3. The expenditure must not be an item that falls within the scope of some other appropriation or statutory funding scheme.


**1.33.4.2.1.1.2** **(02-07-2023)**

###### Time: the Bona Fide Needs Doctrine

01. The "bona fide needs" rule is set forth in 31 U.S. Code Section 1502(a): "The balance of an appropriation or fund limited for obligation to a definite period is available only for payment of expenses properly incurred during the period of availability or to complete contracts properly made within that period of availability and obligated consistent with section 1501 of this title. However, the appropriation or fund is not available for expenditure for a period beyond the period otherwise authorized by law." In other words, current-year funds are used for current-year needs.

02. The GAO, in its [Glossary of Terms Used in the Federal Budget Process](http://www.gao.gov/products/GAO-05-734SP), defines an obligation as "A definite commitment that creates a legal liability of the government for the payment of goods and services ordered or received.... An agency incurs an obligation, for example, when it places an order, signs a contract, awards a grant, purchases a service, or takes other actions that require the government to make payments to the public or from one government account to another." The standards for the proper reporting of obligations are found in 31 U.S. Code Section 1501(a). See [OMB Circular A-11](https://www.whitehouse.gov/omb/information-for-agencies/circulars/#budget).



    ### Example:



    The petitioner's attorneys made a joint motion to award attorney fees on September 5, 2006 (FY 2006). The tax court awarded over one million dollars in attorney's fees and expenses on October 4, 2006 (FY 2007). Generally, an agency must pay a claim from the appropriation available for the fiscal year in which the amount of the claim was determined and allowed. In this case, the IRS had no obligation to pay the one million dollars until the tax court issued its final determination on October 4, 2006; therefore, the IRS had to use its FY 2007 appropriation.

03. Agencies may not obligate funds to purchase services or merchandise before appropriations are enacted and accounts are apportioned. See _IRM 1.33.4.3.1.4_, Apportionments.

04. Appropriated funds should not be used to purchase anything for which a bona fide need does not exist (for example, solely to use excess funds at fiscal year-end).

05. Year-End: Generally, current fiscal year funds may not be used for training that will occur in the next fiscal year. On an exception basis, current fiscal year funds may be used for training during the next fiscal year only if the following three conditions are met:



    1. The training meets a bona fide need of the current fiscal year;

    2. the training provider requires the agency to register during the expiring fiscal year and the date offered is the only one available; and

    3. the time between procurement and training is not excessive.


See comments related to [GAO’s decision B-321296](https://www.gao.gov/products/b-321296). If a course normally is available from one or more vendors several times a year, it would be difficult to support that the scheduling was beyond the agency's control. For a complete explanation, see [GAO decision B-238940](https://www.gao.gov/products/b-238940).



06. Travel authorizations funded from regular appropriations must not be processed for a period beyond the current fiscal year or CR period. However, if they are funded from appropriations that are not subject to the CR, such as the multiyear Inflation Reduction Act (IRA) funding, the travel authorizations may be processed.



    ### Exception:



    Advance purchase of airline tickets for authorized travel extending beyond fiscal year-end is permitted; this exemption does not apply to a CR.

07. Expired appropriations: No new obligations may be made against expired appropriations, even if there was a need for that item during that period. The expired appropriation remains available for five years only to pay obligations incurred prior to the account's expiration or to adjust obligations that were previously unrecorded or under-recorded. As provided in 31 U.S. Code Section 1553(a): "the account shall retain its fiscal-year identity and remain available for recording, adjusting and liquidating obligations properly chargeable to that account." See _IRM 1.33.4.4.6_, Expired, Closed and No-Year Appropriations.



    ### Example:



    In FY 2008, the IRS ratified payment of rental fees on a post office box where expenses were incurred each year since FY 2003, but not previously obligated. This was an actual, unrecorded obligation to the government. The fees for the five years FY 2003 to FY 2007 had to be charged to each of the five expired appropriations for those years. \[Note: **if** there had been a fee for FY 2002, a closed year for which funds were no longer available in FY 2008, the IRS would have had to charge that expense against FY 2008 available funds; see IRM 1.33.4.4.6.\]





    ### Example:



    Many administrative obligations (such as utilities or travel) are recorded based on estimated costs. When a bill comes in after a fiscal year has ended for more than the estimate, these obligation "adjustments" must be made from expired unobligated balances from the year the estimate was recorded.





    ### Example:



    For a contract with a continuing need, a modification affecting cost within the scope of the contract may be chargeable to an expired appropriation, depending on the specific facts involved, but a modification for an increased quantity must be charged to a new appropriation.

08. Replacement Contracts: Where it becomes necessary to terminate a contract because of the contractor's default or where the contracting agency determines that a contract award was improper, the funds obligated under the original contract are available, beyond their original period of obligational availability, to obtain another contractor to complete the unfinished work. Three conditions must exist to invoke this authority:



    1. A bona fide need must continue to exist.

    2. The replacement contract must not exceed the scope of the original contract.

    3. The replacement contract must be awarded within a "reasonable time" after termination of the original contract.


09. Multiyear Contracts: A multiyear contract is a contract that covers the needs of more than one fiscal year. This is not to be confused with a contract for needs of the current year, even though performance may extend over several years. For example, a contract to construct a ship that will take three years to complete is not a multiyear contract, but a contract to construct one ship a year for three years is. Appropriations law allows agencies to enter multiyear contracts only if it has available no-year funds or multiyear funds covering the entire term of the contract, or if the agency has specific statutory authority to do so.

10. It is impossible to describe in this IRM every circumstance that may occur. Different types of purchases may follow rules that are not necessarily intuitive, and examples can be easily misinterpreted. These examples are offered with a strong caution to research specific cases well. When in doubt, call your Corporate Budget contact, who in turn may ask General Legal Services (GLS) for help interpreting the law on a case-by-case basis.


**1.33.4.2.1.1.3** **(02-07-2023)**

###### Amount

1. The agency’s total obligations cannot exceed the appropriation for the year or the amount apportioned by OMB, whichever is lower. During a CR, the total obligations cannot exceed the amount apportioned to the agency for the CR period.

2. Agencies may not pay bills when there are no available funds.

3. For legal purposes, obligations are defined as the ‘obligations, expenditure and disbursements (OED)’ in IFS.

4. For legal purposes, the appropriation is the amount described by legislation. The legal appropriation is often made up of several sub-appropriations, represented by IFS funds, used to track key programs and multiyear legislative provisions. The IFS fields Appropriation Report Group ‘Appropriated Current Year’ and Appropriation Type are used to summarize the IFS funds that make up the legal appropriations.

5. It is an ADA violation to obligate more than the amount appropriated and apportioned. This applies to expired accounts, too: it is a violation to make adjustments that would cause total obligations to exceed the original amount appropriated and apportioned.


**1.33.4.2.2** **(02-07-2023)**

#### Legislative Policies

1. The IRS appropriated funds are provided by law, including through appropriations acts. The laws may be one of the annual appropriations (for annual or multiyear appropriations), an omnibus appropriation, a supplemental appropriation, a continuing resolution (CR), or permanent law (i.e., mandatory appropriations and revolving funds). These laws often contain specific provisions regarding the execution of IRS and other government programs. All internal policies and procedures must reflect Congress’s direction given in these laws.


**1.33.4.2.2.1** **(02-07-2023)**

##### Appropriation Transfers

1. By law, no agency may transfer resources between appropriations except as authorized by law. Laws authorizing transfers may also contain provisions requiring congressional notification or approval. It is unlawful to obligate or expend more than the appropriated amount (or the apportioned amount if lower). The administrative provisions of IRS’s appropriations language allow the IRS very limited authority to transfer funds between appropriations with prior approval of the Department of the Treasury (Treasury), OMB and the Congress. This authority must be carefully controlled by Corporate Budget. All requests for interappropriation transfers must be justified to and approved in advance by Corporate Budget. See _IRM 1.33.4.3.1.5_, Appropriation Transfer Procedures.

2. When possible, Corporate Budget will broker realignments between accounts through corporate reserves, fund 0290.


**1.33.4.2.2.2** **(03-14-2019)**

##### Reprogramming Guidelines

1. The Congress and the administration restrict reprogramming, or shifting funds within an appropriation, to exert control over the budget.


**1.33.4.2.2.2.1** **(02-07-2023)**

###### Budget Activity Limitations

1. Congress specifically limits the reprogramming of funds that augment or reduce funding of existing programs, projects or activities. Currently (for FY 2023), the general provisions in the appropriation language sets the limit at the lower of**five million dollars or 10%**. The law contains a provision requiring that the House and Senate Committees on Appropriations approve in advance any reprogramming that exceeds the limits included in the appropriation language, which restricts reprogramming at the budget activity code (BAC) level. In addition, prior approval is needed to create a new program or to eliminate an existing one through the reprogramming of funds.

2. Any reprogramming between BACs requires advance approval from Corporate Budget.



> Note: See _IRM 1.33.4.2.3.9_, IT Reprogramming Authority.


**1.33.4.2.2.2.2** **(01-15-2008)**

###### Financial Plan Manager Responsibilities for Reprogramming Limitations

1. FPMs may reprogram between functional areas within an appropriation only to the extent they do not change the BAC levels. See _IRM 1.33.4.2.2.2.1_, Budget Activity Limitations. The relationship between functional areas and BACs is identified in the "BACs" table of the current Financial Management Codes Handbook found on Corporate Budget’s Key Budget Tools.


**1.33.4.2.3** **(03-14-2019)**

#### Internal Budget Execution Policies

1. In addition to adhering to legislative policies, all reprogramming actions must be justified.

2. Key points to consider:



1. Reprogramming actions must support the financial plan's Strategy and Program Plan.

2. Reprogramming justifications must address changes by functional area.

3. Actions taken in the current year – such as hiring or position management decisions – must be consistent with budgeted resources and the objectives of the next fiscal year, as well as long-term strategic objectives.

4. All nondiscretionary costs must be fully funded before additional funds can be expended on discretionary costs.


**1.33.4.2.3.1** **(03-14-2019)**

##### Managing within Resource Availability

1. FPMs need to work within their resource availability to achieve program plans. The Business Performance Review (BPR) process focuses on IRS efforts to deliver programs and manage resources. After activity levels are set, funding changes should be an exception in program management. Any needs above the plan should first be resolved within the financial plan or through efforts to secure available funds from other organizations (with the caveat that realignments must not exceed appropriation or BAC limitations). If no resolution can be found, the FPM should submit a request to Corporate Budget with a full justification. If FPMs identify surplus funding within their financial plans, they should immediately notify Corporate Budget and return those surplus funds.

2. Corporate Budget monitors financial plans monthly and through a more comprehensive midyear review. FPMs are required to identify any surpluses or out-of-cycle requests to Corporate Budget at midyear. Corporate Budget will pull identified surpluses into corporate reserves to support approved corporate unfunded priorities through year-end.

3. Business unit hiring actions are permitted, provided they comply with the current operating guidance available on the CFO - Home site.


**1.33.4.2.3.2** **(03-14-2019)**

##### Financial Reviews

1. Ensuring optimal and efficient use of IRS resources is a high priority. This IRM reinforces the need to minimize the amount of year-end obligations (that is, after August 31), while maximizing obligations in support of business priorities. Business units participate in several financial reviews throughout the year, as needed, _including, but not limited to,_ the following formal reviews to ensure the optimal use of IRS resources.


**1.33.4.2.3.2.1** **(03-14-2019)**

###### Labor Reviews

1. Corporate Budget conducts labor reviews using the IFS Three-Year Rolling Forecast (3YRF). Specific guidance for the fiscal year is included in the current 3YRF Labor Analysis Guidelines, distributed by email and normally found on the CFO - Home site. See _IRM 1.33.4.3.1.8.1_, Labor Projections.


**1.33.4.2.3.2.2** **(12-16-2014)**

###### Budget Execution Activity Reports Reviews

1. Corporate Budget prepares a Servicewide Budget Execution Activity Report monthly for senior management, with individual reports for each financial plan. Execution reports are used to analyze and report Servicewide spending patterns, realignment of resources, potential surpluses and early identification of unfunded needs or resource shortfalls. These reports also support midyear reviews.


**1.33.4.2.3.2.3** **(03-14-2019)**

###### Midyear/Spend Plan Review

1. After the close of the second quarter, Corporate Budget conducts a midyear/spend plan review with each business unit to assess the financial position of the organization for internal and external stakeholders. This review:



1. Evaluates the status of spending to ensure timely obligation of funds, per CFO and Procurement guidance.

2. Identifies potential unfunded needs and surpluses.

3. Identifies potential base shortfalls that can be corrected in the multiyear planning process.

4. Promotes timely posting of reimbursables.

5. Provides necessary information for the Treasury midyear review, conducted within all Treasury bureaus.

6. Finalizes the spend plans.


2. Business units are required to meet commitment and obligation targets established jointly by the CFO and Procurement.

3. In addition, business units should meet the following targets for total obligations (labor and non-labor):



1. 100% of procurement actions committed by July 31.

2. 92% of budget obligated by August 31.

3. 99.9% of budget obligated by September 30. Total obligations mean obligations, expenditures and disbursements (OED). The ratios are calculated as a percentage of the operating budget level (IFS Budget version 0).



      ### Note:



      These targets support the overall goal of using resources wisely. Do not use the targets as a reason to buy anything unnecessarily. See _IRM 1.33.4.2.1.1.2_, Time: the Bona Fide Needs Doctrine. Return excess budget to Corporate Budget to be used toward corporate needs.


4. Specific guidance for the fiscal year is shared by Corporate Budget at the beginning of the midyear review process and is usually posted on the CFO - Home site.


**1.33.4.2.3.2.4** **(03-14-2019)**

###### Aging of Unliquidated Commitments and Aging of Unliquidated Obligations Reviews

1. The quarterly Aging of Unliquidated Commitments (AUC) and Aging of Unliquidated Obligations (AUO) reviews provide critical analyses of the spend plan, facilitate the management of the procurement process and maximize use of funds. See _IRM 1.33.4.4.4_, Unliquidated Commitments/Obligations.

2. The CFO Financial Management organization provides fiscal year-end processing guidance for these reviews. See the CFO - Home site.


**1.33.4.2.3.3** **(05-16-2011)**

##### Financial Plan Manager Authority

1. FPMs have the authority to implement reprogramming only in their assigned financial plans and are accountable for strict adherence to the limitations set forth above in _IRM 1.33.4.2.2_, Legislative Policies.

2. FPMs may limit or delegate their reprogramming authority for offices within their financial plans. In doing so, the FPMs retain responsibility for ensuring that limitations contained in these operating guidelines are not violated and must be able to explain all reprogramming changes made in their financial plans. The individuals designated as FPMs are identified by position title in _Exhibit 1.33.4-1_, Division Finance Officers and Financial Plan Managers.

3. FPMs may delegate to others outside their business unit the authority to make entries to their financial plan, as necessary, to accomplish realignments between financial plans in IFS. All realignments between financial plans must be initiated by the sending FPM. See procedures in _IRM 1.33.4.3.1.7_, Realignments between financial plans.

4. At times, Corporate Budget makes entries to other financial plans. These occasions will be limited and Corporate Budget will notify FPMs when their involvement is necessary.


**1.33.4.2.3.4** **(03-14-2019)**

##### Separation of Duties

1. Separation of duties isolates roles and responsibilities to ensure that an individual cannot process a transaction from initiation through reporting without the involvement of others, thereby reducing the risk of fraud or error. Examples of situations requiring separation of duties:



1. Receiving checks and posting them in a financial system.

2. Making purchases with the purchase card, authorizing purchases and payments, and certifying funding.

3. Entering a requisition, creating the obligation and then processing the invoice and paying the vendor.


2. FPMs should establish, develop and monitor controls via segregation of duties to ensure that conflicting activities are not assigned to the same individual and are appropriately separated.


**1.33.4.2.3.5** **(12-16-2014)**

##### Managing the Integrated Financial System

1. FPMs are required to routinely monitor their IFS budget data and ensure the data is correct.


**1.33.4.2.3.5.1** **(03-14-2019)**

###### Integrated Financial System Version Descriptions

1. Below are the current IFS budget and FTE versions:



1. Budget version 0 – the current budget; sets availability controls. Controls are by fund, fund center, functional area and commitment item. IFS availability control (AVC) levels may vary depending on the business unit. Use IFS transaction FMAVCR02 or FMAVCH01 to view the AVC controls for your business unit.



      ### Note:



      During a CR, the full-year funding level is loaded into version 0, with the available allocations for the CR period in budget type AUTH, and the funds reserved for the rest of the year in budget type 4395. The availability controls are temporarily set at the fund level during the CR period.

2. Budget version 999 – the current plan for FTE staffing resources; associated with budget version 0. This FTE budget has detail by fund, fund center, functional area, commitment item, funded program and activity type.

3. Budget version 20 – a holding place for the full-year budget, which is copied from Business Planning and Simulation, Plan Development, version P0, and held until Corporate Budget moves it to version 0 at the beginning of the new fiscal year. The version is strictly used during the budget load and for travel system authorization validation.

4. Budget version SP – Spend plan version used to create the operating plan submission, after an Enacted budget is passed. The separate version gives the Budget Execution office flexibility to plan and reprogram the full year budget for the operating plan, while maintaining budget control in IFS version 0. Once the approved warrant is received, the Budget Execution office copies version SP into version 0 as the official operating plan.


**1.33.4.2.3.5.2** **(03-14-2019)**

###### Integrated Financial System Budget Distribution Levels

1. Federal budgets must be recorded at every stage of approval. To comply with federal requirements, the IRS has a budget distribution process to reflect the appropriate accounting for external reporting.

2. IFS uses four main "budget types" to reflect the legal stage of the budget distribution process:



   - APPR: Funds are received from the Congress through an **appropriation**. Before they are apportioned, they are not available for obligation.

   - APOR: After OMB approves the **apportionments**, IRS can use the funds.

   - ALLT: Corporate Budget legally distributes **allotments** but may hold restricted funds here temporarily before releasing them to the business units.

   - AUTH: Corporate Budget distributes suballotments to the business units as **authorization** to obligate funds.


3. During a CR, 4395 is an additional budget type used. At the beginning of the fiscal year, the full-year funding level is loaded into version 0, with the portion available for the CR period put in budget type AUTH, and the portion held for the _remainder of the year_ put in budget type 4395.

4. Each level is associated with a general ledger account (in the background) that is reported externally by CFO-FM. Corporate Budget is responsible for distributing the budget down to the lowest level. The business units do not have system access to make the entries at the higher level.


**1.33.4.2.3.5.3** **(03-14-2019)**

###### Elimination of Budget Deficits in Version 0

1. IFS availability controls (AVC) help prevent the IRS from going deficient for non-labor expenses. At a minimum, AVC is established to control budget by fund, fund center (financial plan level), commitment item (object class) and functional area. However, some business units establish controls at lower levels, causing the system to reject the obligation if there is insufficient budget at those levels. Availability controls are not configured to prevent payroll postings in IFS, so unexpectedly high labor expenses can result in a deficient status. This is likely to occur in September in financial plans with significant reimbursable projects where the earnings have not been realized yet. Since a budget can become deficient from posting payroll, FPMs must research their budget deficits bi-weekly and correct them no later than one week after payroll posts. The IFS FMAVCR02 or FMAVCH01 report (Display Overall Values of Control Objects) will quickly identify labor budget deficits. Realignments must be processed to resolve the deficits, using the IFS transaction FMBB. Further, FPMs must do everything possible to post reimbursable earnings timely throughout the year and especially at year-end. See IRM 1.33.3, Reimbursable Operating Guidelines.


**1.33.4.2.3.5.4** **(02-07-2023)**

###### Correcting Negative Disbursements

1. FPMs must correct negative disbursements that result from transferring disbursements exceeding what was disbursed in an accounting string; a negative total would falsely state availability; such credits were probably posted to an incorrect accounting string. However, they do not need to correct negative disbursements that result from credits posting to current-year funds from charges, if they are legitimate credits. Plan managers must correct negative disbursements in active appropriations that extend beyond the current year through multi- or no-year authority, cancelling appropriations and expiring reimbursable appropriations.


**1.33.4.2.3.5.5** **(04-16-2010)**

###### Prohibition of "Top Node" Distributions

1. When establishing new budget authority, Corporate Budget pushes the budget down through the IFS "top node" data elements; that is, commitment item ALLOBJ and functional area ALFA. However, FPMs may not post funds to the top node, because charges in ALLOBJ/ALFA create problems for financial reporting, cost allocations and reprogramming limitations. All funds must possess a valid commitment item and functional area. Any funds remaining at the ALLOBJ/ALFA level should be pushed down accordingly.


**1.33.4.2.3.5.6** **(03-14-2019)**

###### Keeping Full-Time Equivalents Aligned With Labor

1. Budget version 999 must be maintained so that FTEs and labor dollars always stay aligned. See _IRM 1.33.4.3.1.9_, FTE Utilization Policies.


**1.33.4.2.3.6** **(03-14-2019)**

##### Financial Codes

1. The validity and accuracy of IRS financial reports depends on the correct use of financial codes. FPMs, all staff in budget organizations and all parties responsible for assigning financial codes to documents must be familiar with the codes and definitions in the current Financial Management Codes Handbook found on Corporate Budget’s Key Budget Tools.

2. Funded programs, also known as internal order codes (IOCs), are set up to track project-specific information. See _IRM 1.33.4.3.2.1_, Funded Programs. When necessary, the CFO will issue guidance or procedures for using specific IOCs for Servicewide activities or projects that need to be tracked and will post it on Corporate Budget’s Key Budget Tools.

3. Procedures for establishing new financial codes are provided in _Exhibit 1.33.4-2_, Master Data (Code) Change Request Procedure.


**1.33.4.2.3.7** **(12-16-2014)**

##### Reorganizations and Other Modifications Affecting Budget

1. FPMs must notify Corporate Budget of any reorganizations as soon as senior management approves an initial reorganization proposal. Congress directs IRS to include in its annual operating plan the details on any planned reorganizations, job reductions or increases to offices or activities within the agency, and modifications to any service or enforcement activity. Reorganizations include significant planned staffing increases or decreases, establishment of new offices or functions, or elimination of any offices or programs. When notifying Corporate Budget, please include:



   - Budget dollars crossing appropriations, regardless of the amount

   - Transfers of dollars and/or FTEs between business units

   - Staffing reductions of more than 20 FTEs


2. Corporate Budget staff will maintain the appropriate level of confidentiality regarding possible reorganizations if requested by the FPM.

3. To request new or revised financial codes, see _Exhibit 1.33.4-2_, Master Data (Code) Change Request Procedure.

4. For more guidance on reorganizations, see IRM 1.1.4, Organizational Planning.


**1.33.4.2.3.8** **(03-14-2019)**

##### Labor Costs Reprogramming

1. There are no legal restrictions on realigning funds between labor and non-labor; however, to better manage funds, additional internal guidance often requires Corporate Budget approval before realigning labor funds to non-labor. Business units must ensure compliance with current operating guidance available on the CFO - Home site.

2. FPMs must balance labor and support so that FTEs are fully costed and strategic plans are realized. For more information on managing FTEs see _IRM 1.33.4.3.1.9_, FTE Utilization Policies, and on hiring see _IRM 1.33.4.3.1.10_, Personnel Issues.


**1.33.4.2.3.9** **(12-16-2014)**

##### IT Reprogramming Authority

1. All IT resources reside in the IT financial plan. All requests for reprogramming affecting BAC 98 must follow the IT reprogramming policy.

2. For IT budget execution information, see IRM 2.21.1, Introduction to Shopping Cart Processing for IT.


**1.33.4.3** **(08-28-2006)**

### Operating Procedures

1. FPMs must adhere to the following detailed guidance for budget execution.


**1.33.4.3.1** **(02-07-2023)**

#### CFO Servicewide Procedures

1. The CFO develops and implements Servicewide procedures resulting from high-level direction from senior leadership, Treasury, OMB, and other authorities.


**1.33.4.3.1.1** **(03-14-2019)**

##### Corporate Budget Responsibilities

1. Although many budget execution activities are decentralized, Corporate Budget continues to have Servicewide fiduciary responsibility.

2. Corporate Budget monitors business units’ budget execution activities to identify potential issues before they become corporate ones.

3. Corporate Budget reports to the IRS senior leadership regularly on the IRS’s financial status, including compliance with appropriation language restrictions.

4. Corporate Budget periodically reviews reprogramming out of labor to verify the effect on current- or out-year resource levels. Corporate Budget will work with the FPMs to ensure reallocations make sound business sense.

5. Corporate Budget is responsible for the Centralized Payments plan 1111, the Undistributed Funds plan 0290, prior-year funds and IRS appropriation levels.

6. On a regular basis, Corporate Budget estimates labor needs, analyzes hiring/attrition trends and estimates/realigns corporate costs.


**1.33.4.3.1.2** **(03-14-2019)**

##### Communications

1. Corporate Budget has primary responsibility for overseeing budget execution policy.

2. Within Corporate Budget, an assigned execution analyst is the primary point of contact for each business unit for any questions or requests regarding budget execution or this IRM. FPMs should communicate with Corporate Budget through their assigned execution analyst.

3. For financial code change requests, FPMs should send their requests directly to Corporate Budget’s Master Data Team (CFO.Master.Data.Request@irs.gov), with a copy to their assigned execution analyst. Procedures for Master Data changes are provided in _Exhibit 1.33.4-2_, Master Data (Code) Change Request Procedure.

4. For any budget formulation questions or requests, FPMs should go directly to their assigned Corporate Budget formulation analyst.


**1.33.4.3.1.3** **(03-14-2019)**

##### Preparation of a Servicewide Operating Plan

1. The House Appropriations Committee directs the IRS to submit an operating plan within a specified number of days after enactment of the new fiscal year appropriation.

2. Corporate Budget prepares a table that crosswalks the budget request to the enacted level of funding and the current operating plan. The format is like the Congressional Budget Justification’s Explanation of Proposed Fiscal Year Budget Operating Level chart.

3. FPMs must distribute their plan’s funds by OMB object class, functional area and commitment item as they will be executed.

4. FPMs develop narrative to provide program, project and activity information for each appropriation. The narrative must:



1. Describe the major goals to be achieved with the funding provided and how funds for each BAC will be used.

2. Discuss the impact of congressional changes to the President’s Budget Request.

3. Identify anticipated reprogramming actions of enacted funds.

4. Provide information on major procurements and capital investments.


5. Corporate Budget compiles and submits the crosswalk table and narrative referenced above.


**1.33.4.3.1.4** **(03-14-2019)**

##### Apportionments

1. An apportionment is an action by which OMB distributes amounts available for obligation in an appropriation or fund account. It typically limits the obligations that may be incurred for specified time periods, programs, activities, projects, objects or any combination thereof. It may also place limitations on the use of other resources, such as FTEs or property. An apportionment is legally binding, and obligations and expenditures (disbursements) that exceed an apportionment are a violation of and are subject to reporting under, the _Antideficiency Act_. See [OMB Circular A-11](https://www.whitehouse.gov/omb/information-for-agencies/circulars/#budget), Section 120, Apportionment process.

2. Initial apportionment requests usually are due to OMB for a new fiscal year by the third week of August. The initial apportionments include estimates of expected reimbursables, carryover amounts for multiyear authority, prior-year recoveries for multi- and no-year accounts, and anticipated user fee transfers to the no-year accounts.

3. For newly enacted, full-year appropriations, the IRS receives an automatic apportionment, so it can operate for 30 days or until apportionment requests are approved. If a request is not approved by the 30th day after enactment, the IRS receives another 30-day automatic apportionment, in effect until the apportionment request is approved. The rate is the higher of the:



   - pro-rata share (1/365th for each day) of the prior year's enacted appropriations level

   - pro-rata share (1/365th for each day) of the current year's enacted appropriation level

   - historical seasonal obligation level


4. For the yearly appropriations, an amount not to exceed 1% of the total is apportioned to pay legitimate obligations related to canceled appropriations.

5. [OMB Circular A-11](https://www.whitehouse.gov/wp-content/uploads/2018/06/a11.pdf) provides automatic apportionments of prior-year recoveries of $400,000 or 2% of the annual appropriation, whichever is lower; however, OMB requires the IRS to have an apportionment in place before using these funds. IFS does not have a control on prior-year recoveries to stop the usage of these funds; therefore, business units should ensure that no obligations are charged to these funds until the apportionments are received.


**1.33.4.3.1.4.1** **(12-16-2014)**

###### Apportionments under a Continuing Resolution

1. OMB automatically apportions funding levels during a CR. After passage of final appropriations, Corporate Budget prepares and submits revised apportionment requests to Treasury and OMB for approval. Corporate Budget has 10 days from enactment to request an apportionment from OMB even if the period of the CR has not expired. See [OMB Circular A-11](https://www.whitehouse.gov/omb/information-for-agencies/circulars/#budget), Section 120, _Apportionment process under continuing resolutions_.


**1.33.4.3.1.5** **(03-14-2019)**

##### Appropriation Transfer Procedures

1. All proposed interappropriation transfers must be justified to and approved by Corporate Budget. If approved, Corporate Budget will submit the transfer request for approval to Treasury, OMB and the congressional subcommittees. After receiving all approvals, Corporate Budget will submit Treasury Standard Form (SF) 1151, Nonexpenditure Transfer Authorization, to Treasury and will notify the appropriate FPM to enter it in IFS. (See also _IRM 1.33.4.2.2.1_, Appropriation Transfers.)

2. When possible, Corporate Budget will broker realignments between accounts through Corporate Reserves, fund 0290.


**1.33.4.3.1.6** **(12-16-2014)**

##### Interagency Transfers

1. Corporate Budget controls funds transfers from the IRS to other agencies, documented by a SF 1151, Nonexpenditure Transfer Authorization, transfer request. The SF 1151, Nonexpenditure Transfer Authorization, must cite the public law or other authority that authorizes the transfer. When a FPM needs to send or receive funds from another agency, he/she must provide the following information via email to Corporate Budget:




| **Required Information to Support Interagency Transfer** |
| :-: |
| **Transfer (FROM/TO)**\[IRS information\]<br> <br>01. IRS fund code<br>       <br>02. Financial plan and fund center<br>       <br>03. Functional area<br>       <br>04. Commitment item<br>       <br>05. Funded program, if appropriate<br>       <br>06. Amount<br>       <br>07. Justification for request<br>       <br>08. Date needed<br>       <br>09. Finance contact name and phone number<br>       <br>10. Authorizing authority (such as public law, U.S. Code, etc.)<br>       <br>11. Authorized by<br>       <br>**Transfer (TO/FROM)** \[other agency information\]<br> <br>1. Agency<br>      <br>2. Treasury account symbol<br>      <br>3. Accounting information, as available<br>      <br>4. Agency contact name and phone number<br>      <br>5. Backup contact name and phone number |

2. Some interagency transfers will require an apportionment or reapportionment request, which must be approved by Treasury and OMB before the SF 1151, Nonexpenditure Transfer Authorization, may be forwarded. All approvals must be granted before the funds can be put in IFS.


**1.33.4.3.1.7** **(03-14-2019)**

##### Realignments between Financial Plans

1. Realignments between financial plans require coordination between the FPMs in both the receiving and the sending financial plans.


**1.33.4.3.1.7.1** **(01-15-2008)**

###### Arrangements between Financial Plans

1. In IFS, the sending FPM enters realignments using an IFS transaction FMBB. This applies to budget version 0 and/or 999. The sending FPM must ensure the entry does not exceed BAC reprogramming limitations. See _IRM 1.33.4.2.2.2_, Reprogramming Guidelines.

2. The receiving FPM emails the appropriate receiver lines (TO lines) to use for the FMBB transaction including the fund, functional area, fund center and commitment item to the sending FPM.

3. Within a week of receiving the email, the sender must resolve any issues with the receiver and accurately enter the FMBB transaction into IFS. The sender attaches the receiver’s email to the FMBB transaction as a "Long Text" note, and copies the TO lines directly into the FMBB transaction, providing a detailed audit trail.




| **Summary of Responsibilities for Realignments between Financial Plans** |
| :-: |
| **Sending FPM** | **Receiving FPM** |
| :-: | :-: |
| Ensures funds are available and coordinates with receiving FPM to ensure reprogramming limitations are not exceeded. | Coordinates with the sending FPM to ensure that reprogramming limitations are not exceeded. |
| Enters the FMBB (FROM and TO sides) using the receiver’s detailed TO lines. | Provides accurate TO lines for the FMBB transaction. |
| Enters FMBB transactions for FTEs (FROM and TO sides) into budget version 999. If salaries are transferred, ensures new FTE and labor levels in the sending plan are balanced. | Provides accurate TO lines for receiving FTEs. If salaries are transferred, ensures remaining FTEs and labor levels in the receiving plan are balanced. |


**1.33.4.3.1.7.2** **(08-28-2006)**

###### Realignments Requiring Assistance from Corporate Budget

1. FPMs should first try to resolve funding issues by making realignments within their financial plan. Second, they should see if funds are available in other organizations that could be realigned without exceeding BAC limitations. Finally, if no resolution can be found, a FPM may submit a request to Corporate Budget. The request should include a full justification and the [Corporate Budget Funds Transfer template](http://cfo.fin.irs.gov/SPB/Operational_Guidelines/RequestForms/CB_Funds_Xfer_Template.xls), which includes the accounting string necessary to process the reprogramming in IFS.


**1.33.4.3.1.8** **(01-06-2021)**

##### Labor Projections and Charging Labor Cost

1. Labor costs account for approximately 75% of IRS’s regular annual appropriations. FPMs must use labor projections to monitor and plan current fiscal year requirements.


**1.33.4.3.1.8.1** **(03-14-2019)**

###### Labor Projections

1. During budget execution, FPMs must monitor their labor costs regularly using the IFS 3YRF. All FPMs will input their hiring, attrition and any other assumptions specific to their financial plan in the module on a regular basis. Additionally, FPMs must provide their other-than-full-time permanent staff plan data to Corporate Budget as needed.

2. Formal labor reviews are scheduled as part of the financial review process. See _IRM 1.33.4.2.3.2_, Financial Reviews. Corporate Budget will use 3YRF data to report on staffing levels and to make labor projections. Corporate Budget will perform labor analyses to ensure that funds are allocated appropriately. More specifics are included in the current Labor Analysis Guidelines, found on the CFO - Home site.

3. Corporate Budget arranges Labor Projection Methodology and the 3YRF training for the business units. See the Financial Learning Hub or contact Corporate Budget Financial Planning & Analysis office for the latest training information.


**1.33.4.3.1.8.2** **(03-14-2019)**

###### Charging Labor Costs, General

1. Labor costs are generally obligated to functional areas based on the cost center where the employee is currently assigned organizationally. The cost center is based on the Totally Automated Personnel System (TAPS) organizational segment ("org seg" ) code. When employees perform work in a functional area or on funded program other than the one where they are currently assigned organizationally, their time should be charged to the functional area or funded program where the work is performed. However, because adjustments to time charging require significant key entry and are highly susceptible to error, each FPM must choose an approach to time charging that balances timeliness, burden and accuracy.

2. FPMs should generally leave time charged to the home cost center if the data will be reasonably accurate.

3. FPMs should use direct charging (Iine-by-Iine accounting) only for a few defined needs, especially capturing work on funded programs and detail assignments in SETR.

4. FPMs should use indirect charging for limited needs; for example, Counsel's activities, Earned Income Tax Credit (EITC) charging, and customer education and outreach work done by TE/GE revenue agents. Other needs may be allowed. The emphasis should be on the need for reasonably accurate data, making indirect charging of small amounts unnecessary. As with all document entry, ensure proper documentation justifies the IFS entries. Indirect charging is done in IFS by using transaction code FV50, Park G/L Account document, with document type EV (expense voucher), the IFS document type for correcting and transferring expenditures.

5. For required cost tracking of legislative mandates and other activities, FPMs may choose the approach that will minimize the potential for errors but give reasonably accurate data.

6. Gaining and losing organizations are both responsible for using correct accounting codes when there is a delay in the release of employees to a different organization code or where there is a delay in the processing of an [SF 52, Personnel Action Request](http://www.opm.gov/forms/pdf_fill/sf52.pdf), for an employee reassigned to a different organization code.


**1.33.4.3.1.8.3** **(02-07-2023)**

###### Charging Labor Costs, Details and Temporary Promotions

1. A detail or detail assignment is defined, for financial purposes, as a work assignment outside the home cost center and/or functional area for a specified period with a minimum duration of one pay period, when the employee is expected to return to regular duty at the end of the assignment.

2. All details must be charged to the correct functional area, which is generally the functional area where the work is being done. This may be accomplished either by an [SF 52, Personnel Action Request](http://www.opm.gov/forms/pdf_fill/sf52.pdf), which points the charges and the onrolls to the new receiving cost center and functional area, or through timekeeping. If the receiving office is _not_ funding the detail, the employee's manager must coordinate with the servicing budget office to charge the employee's time to the **correct functional area** with their home cost center. If the detail crosses appropriation accounts (for example, an Enforcement employee detailed to a Taxpayer Services funded office), the receiving office **must** pay the costs of the detail. The overriding principle is that FPMs must charge time correctly by functional area to avoid a purpose statute violation. (There may be circumstances where a non-reimbursable detail is legally permissible, but such situations are rare.)

3. When an employee is detailed and no Personnel Action Request is completed (for example, a same-grade detail), either the "D" (detail) code or the "U" (user funded) code can be selected as an override to the generated accounting code so the charges are directed to the function where the work is being performed.



### Note:



At no time should the "S" (SETR generated) code be manually entered in the 13th position of the accounting code. This is strictly a "SETR" or "system" generated code. When entered manually, SETR does not detect that an override is necessary and will use the prior-stored accounting code which is usually the accounting code of the employee’s permanent organization - not the code where the work is being performed.





### Note:



Because details of onrolls do not move when we use the "D" or "U" code in timekeeping, onroll-based labor projections, especially 3YRF projections, should be adjusted to account for details.

4. When a detail involves a temporary promotion, the onroll moves to the organization that is giving the promotion, so it is important to know when the temporary promotion will end, since the 3YRF will continue to assume the person stays in the promoting organization. The Human Resources Reporting Center can be used to determine the ending date of the temporary promotion. See Secured Business Unit Sites, Employee Data Reports, NTE Report-TIMIS and TAPS.

5. Each business unit should establish a control point at a high level within the organization (for example, branch, division, or operation) to keep a log of all detailed employees charged to one of these codes and the expected duration and to ensure that the code is removed when no longer needed.


**1.33.4.3.1.9** **(03-14-2019)**

##### FTE Utilization Policies

1. The IRS maintains FTE allocations in IFS Budget version 999. See _IRM 1.33.4.2.3.5.1_, Integrated Financial System Version Descriptions.

2. FPMs should ensure FTEs are fully funded with labor and non-labor resources. Each financial plan’s labor funding (specifically, commitment items 11SP, 11ST and 12LA in IFS version 0) must support the number of FTEs in the financial plan (version 999) at all times. When funding transfers are made, FTE adjustments must be made to retain the FTE and labor funding balance.

3. FPMs are responsible for their FTE resources. To keep FTE in balance with labor funding, FPMs are permitted to "drown" surplus FTEs (that is, reduce FTE allocations) from the financial plan, to create additional FTEs, and to convert between other than full-time permanent FTEs and full-time permanent FTEs, as necessary. These actions are permitted if sufficient labor and non-labor funds are available to support the FTEs, and they do not adversely affect accomplishment of the Strategy and Program Plan. See the hiring guidance in the next section.


**1.33.4.3.1.9.1** **(03-14-2019)**

###### Changing FTEs in the Integrated Financial System

1. FPMs can adjust FTEs in IFS budget version 999 with the FMBB document. Commitment items begin with ZPM for permanent FTEs and ZTM for other-than-full-time permanent FTEs followed by two digits representing the activity type.

2. FTEs cannot be transferred in IFS from one fund to another. Each fund is adjusted with an increase or decrease.

3. These actions are permitted if sufficient labor and non-labor funds are available to support the FTEs and they do not affect the Strategy and Program Plan adversely. For guidance, see _IRM 1.33.4.3.1.10.2_, Hiring.


**1.33.4.3.1.10** **(03-14-2019)**

##### Personnel Issues

1. Budgetary guidance is warranted for certain personnel issues that are discussed below.


**1.33.4.3.1.10.1** **(03-14-2019)**

###### Hardship Relocations

1. The IRS hardship relocation guidelines are delineated in Article 15 of the National Agreement between the IRS and NTEU. A basic tenet of the IRS hardship relocation policy is that there is work to be performed now and in the future in the geographic area to which an employee has requested a hardship relocation, and there is a vacancy that management intends to fill. There is no transfer of funds or FTEs to support approved hardship relocations. The National Agreement is on HCO’s Labor/Employee Relations & Negotiations site.


**1.33.4.3.1.10.2** **(03-14-2019)**

###### Hiring

1. FPMs can process internal and external hiring actions if they comply with ‘hiring guidance’ or ‘operating guidance’ available on the CFO - Home site. See _IRM 1.33.4.2.3.1_, Managing within Resource Availability.

2. The CFO uses 3-Year Rolling Forecast data to report on staffing levels and to make labor projections. FPMs must use the 3YRF to input their business unit’s planned hiring, attrition and assumptions for the CFO’s labor reviews. See _IRM 1.33.4.2.3.2.1_, Labor reviews.

3. Corporate Budget will work with the FPMs to analyze their maximum year-end staffing capacity and affordability, based on expected budget levels, hiring plans and attrition.

4. Hiring plans are also reported in staffing level reports (See _IRM 1.33.4.3.1.11_, Staffing Level Reports - Positions and FTEs) and in PeopleTrak.


**1.33.4.3.1.11** **(12-16-2014)**

##### Staffing Level Reports - Positions and FTEs

1. FPMs are responsible for developing staffing plans to achieve the IRS’s goals. FPMs update the 3YRF with full-time permanent hiring plans and attrition projections by pay period and employment category. Corporate Budget uses this information and historical trends to develop staffing status reports for senior leadership.


**1.33.4.3.1.12** **(12-16-2014)**

##### Cash (Monetary) Awards and Time-Off Awards

1. The IRS manages awards based on OMB and OPM guidelines. Award pool estimates at the financial plan level are established according to these guidelines.


**1.33.4.3.1.12.1** **(12-16-2014)**

###### Cash (Monetary) Awards for Prior Fiscal Year

1. Cash (monetary) awards are chargeable to the "Appropriations current at the time the awards are made," per [Red Book](http://www.gao.gov/legal/redbook/redbook.html), Volume II, Chapter 7, Section B.7.a. For example, corrections or adjustments to cash (monetary) awards made in FY 2012 are chargeable to FY 2012. However, if an award is delayed and managerial approval is not completed until after September 30 (the next fiscal year), the award is made in and charged to the new fiscal year.

2. In general, awards are regarded as having been made when there is an administrative determination to make them, as evidenced by the effective date on the SF 50, Notification of Personnel Action, for the award (the effective date is not the same as the payment date).

3. Corrections and Adjustments: Corrections of clerical errors are properly chargeable to the fiscal year in which the award was originally made.

4. In circumstances when interest must be paid on a late or partial payment of an award, the interest is chargeable to the fiscal year in which the award should have been made.

5. Awards Claims and Settlements: The date that an awards claim becomes a legal liability determines the fiscal year of the appropriation to be used to pay the claim. Which fiscal year to charge for claim resolution depends on the underlying basis of the dispute and the specific circumstances of the case. GLS can provide advice on settlements on a case-by-case basis.

6. In situations where a settlement is determined in the current year for an award, an adjustment will be made to current-year award funding. Corporate Budget will direct the business unit to reprogram funds into commitment item 1171 to supplement cash (monetary) award funding. The supplemental award funding is in addition to the awards pool for current-year awards.

7. See _IRM 1.33.4.3.1.15_, Gainsharing Travel Savings Program, for information about gainsharing awards for a prior fiscal year.


**1.33.4.3.1.13** **(03-14-2019)**

##### Buyouts

1. The responsibility for buyout costs may depend on who initiates the buyout, as outlined below.


**1.33.4.3.1.13.1** **(12-16-2014)**

###### Servicewide Buyouts

1. When Servicewide buyouts are initiated and an employee accepts a buyout, the related Voluntary Separation Incentive Pay (VSIP) should be funded by the employee’s business unit unless other specific guidance is provided. Terminal leave and other expenses should be funded as they are for all separating employees. Administrative payments to OPM for processing the buyouts will be handled separately. Corporate Budget and the FPM should consult with HCO regarding the process and the remittance of fees to OPM prior to finalizing buyout offers.

2. If a business unit negotiates an arrangement for an employee to accept a buyout in the current year, but he/she retires in the following fiscal year, the expenses are incurred in the following fiscal year when the employee retires, not when the decision is made. In this case, the employee’s business unit will be responsible for funding the buyout-related expenses incurred in the following fiscal year.


**1.33.4.3.1.13.2** **(12-16-2014)**

###### Business Unit Buyouts

1. If a business unit decides to offer buyouts, the business unit will be responsible for buyout expenses, including VSIP, Terminal Leave and possibly OPM costs. The FPM should consult with HCO regarding the process and the remittance of fees to OPM prior to finalizing buyout offers.


**1.33.4.3.1.14** **(02-07-2023)**

##### Travel and Above Standard Level Requests

1. Each business unit receives travel funds to complete its mission and should restrict charging official travel against a financial plan or functional area other than its own. All travelers should charge travel to their own business unit, whether supporting their own direct program or a customer function.

2. Travel directly related to the Federal Highway Administration’s Excise File Information Retrieval System (ExFIRS) may be charged against available multiyear funds as directed.

3. Employees participating in leadership training programs must charge their time and travel costs to their home functional area.

4. IT should pay for the travel of all IT analysts, whether attending functions within their own financial plan or assisting with the implementation of an approved project/program.

5. In general, support functions such as IT, FMSS and HCO have been funded to support their customers’ day-to-day operational needs and should not expect the customer to pay for their usual travel. Some examples and exceptions follow:



1. FMSS will require a business unit requesting above-standard requests to fund the travel costs. Above-standard requests are those beyond the level of service standards mutually agreed to in the Level of Service Agreement between the support organization and its customers. In the case of approved space projects that are centrally funded from the Stewardship financial plan (STWD), necessary FMSS travel and overtime funds already are included in the project authorization amount, and no funds will be requested from the business units; however, business units will be expected to pay travel and overtime expenses related to customer-funded projects.

2. HCO will pay for instructor travel associated with funded Servicewide training programs, through the Centralized Payments plan 1111. This travel will cover the volunteer instructors of the leadership courses offered. However the student travel is funded by the home business unit of the attendees.


**1.33.4.3.1.15** **(03-14-2019)**

##### Gainsharing Travel Savings Program

1. Under the Government Employee’s Incentive Awards Act, IRS employees can earn gainsharing travel savings awards for saving the IRS money while on temporary duty travel. These savings come from the use of less expensive lodging and/or from the use of frequent flyer benefits to purchase airline tickets for official travel. Employee participation is optional. Gainsharing awards are charged as travel expenses. See IRM 1.32.14, Gainsharing Travel Savings Program.

2. All temporary duty travel with lodging expenses, foreign or domestic, are covered under this program. Relocation travel is not covered under this program. See IRM 1.32.1, IRS Local Travel Guide and IRM 1.32.11, IRS City-to-City Travel Guide.

3. An employee accumulates travel savings throughout the fiscal year and documents the savings on Form 13631-A, IRS Travel Savings, to request a gainsharing award. See IRM 1.32.14, Gainsharing Travel Savings Program.


**1.33.4.3.1.16** **(01-15-2008)**

##### Statistics of Income, Functional Area 4Q

1. Surplus funding in Statistics of Income (SOI) functional area 4Q may be reprogrammed within a financial plan as needed to cover functional area 4Q deficits. Surplus SOI funds in any financial plan will first be used to offset SOI deficits in other financial plans or fund centers before being reprogrammed into other functional areas, at the direction of the director, Statistics of Income. The written concurrence of the director, Statistics of Income, is required before reprogramming FTEs or funds out of functional area 4Q.


**1.33.4.3.1.17** **(02-07-2023)**

##### Treasury Franchise Fund

1. The Treasury Franchise Fund is a revolving fund comprised of three services providers: Treasury Shared Services Programs (TSSP), Centralized Treasury Administrative Services (CTAS) and Administrative Resource Center (ARC). These providers offer a host of IT and non-IT services to IRS and other bureaus across the federal government. Services are acquired through an annual interagency agreement (IAA) facilitated by Office of Treasury Franchise Fund Management and Oversight (OTFFMO). The providers administer these centralized services more advantageously and more economically than they could be provided otherwise.

2. The effective management and use of the Treasury Franchise Fund (TFF) is a shared responsibility of the IRS and the Treasury service providers.

3. More information about the TFF is available on the CFO’s Treasury Franchise Fund page.


**1.33.4.3.1.18** **(03-14-2019)**

##### Rebates and Refunds

1. Funds received from sources outside of the IRS are deposited into Treasury’s general fund as miscellaneous receipts, unless the IRS has statutory authority to retain funds for credit (that is, an increase) to its own appropriation.

2. An exception is authorized for receipts that qualify as refunds. Refunds are defined as "repayments for excess payments and are to be credited to the appropriation or fund accounts from which the excess payments were made." Refunds must be directly related to previously recorded expenditures and are reductions of such expenditures. Refunds also have been defined as representing "amounts collected from outside sources for payments made in error, overpayments or adjustments for previous amounts disbursed." [GAO Opinion B-217913 (1986)](https://www.gao.gov/products/129998). Travel credit card rebates are adjustments of previous disbursements and therefore qualify as refunds. Refunds and/or rebates received are applied to the appropriation and fiscal year initially charged.

3. Timing of the original obligations determines the dispensation of the rebate.



   - If the appropriation initially charged is open (current year), apply the rebate/refund to current year funds and it becomes available for obligation.

   - If the appropriation initially charged has expired, but is not closed, apply the rebate/refund to the expired account, even though its use in a prior year fund is limited.

   - If the appropriation initially charged has closed, deposit the refund to the Treasury general fund.


**1.33.4.3.2** **(08-28-2006)**

#### Financial Plan Managers’ Procedures

1. The following procedures were developed and applied primarily by individual FPMs for cross-cutting and/or stewardship issues.


**1.33.4.3.2.1** **(03-14-2019)**

##### Funded Programs

1. Funded programs, formerly known as internal order codes (IOCs), are IFS data elements that collect expenditure data for specific projects. They are used to track costs of training, events and projects. In IFS, funded programs use the term IOC. IOCs are generally five-character alphanumeric codes. For IT projects, the IOC tracks sub-project activities with eight-character codes. Reimbursable projects use ten-character IOCs.

2. The Financial Management Codes Handbook, found on Corporate Budget’s Key Budget Tools, has an explanation of the funded program code structure and lists of IOCs by type.

3. See _IRM 1.33.4.3.2.2_ regarding funded programs to Track Event-Related Spending.

4. For instructions on how to request an IOC, see this IRM’s _Exhibit 1.33.4-2_, Master Data (Code) Change Request Procedure.


**1.33.4.3.2.1.1** **(12-16-2014)**

###### Funded Programs – Information Technology and BSM Programs

1. Funded programs continue to be the official source for project cost information and are required for all costs charged against BAC 98 IT and BSM appropriation resources. Non-labor costs will be captured by an IOC through the normal accounting process (for example, requisitions and travel vouchers). Labor costs will be captured from the payroll system, or by using an EV voucher. Employees funded by IT resources are required to track time by IOC in the payroll system. IOCs are also used as needed to track certain major projects. See _IRM 1.33.4.2.3.6_, Financial Codes.

2. Customers requiring an IT or BSM IOC should contact IT Financial Management Services, Plan Development, which will assist customers and act as a liaison with Corporate Budget for establishing, revising or removing codes.

3. The IOC Structure tab of the Financial Management Codes Handbook, found on Corporate Budget’s Key Budget Tools, describes special identifiers within the IT IOC structure.


**1.33.4.3.2.2** **(02-07-2023)**

##### Tracking Event-Related Spending

1. An event includes a conference, meeting, training, awards ceremony, or other similar gathering that involves expenses of the attendees, such as for travel, meals or refreshments.

2. For all events that cost $20,000 or more, see IRM 1.32.10, Reporting on Event-Related Spending, for direction on funded programs (IOCs) to track costs, reporting requirements and exclusions. See _IRM 1.33.4.3.2.3_ if the event is training.


**1.33.4.3.2.3** **(02-07-2023)**

##### Training Programs

1. The Centralized Payments plan (plan 1111) pays all costs to manage the Servicewide leadership program. Employees participating in Servicewide leadership training programs charge their time and travel costs to their home functional area. The Centralized Payments plan pays contract, material and instructor costs for the Servicewide leadership programs.

2. HCO is responsible for developing curriculum for the education and e-learning programs.

3. HCO manages the Skillsoft program and with IT, funds the Skillsoft contract, including Skillport Learn and Lead 24x7. HCO maintains contract administration responsibilities for the Accounting and Tax Law Training (Thomson Reuters Checkpoint Learning) contract. The business units prepare and fund requisitions based on the number of online training modules or customized tasks being ordered off the Thomson Reuters Checkpoint Learning contract.

4. Expenditures for training commitment items must include an IOC. Training IOCs have been established for mission-critical occupations, management levels, Servicewide programs and training support. This includes training travel, services and supplies.

5. For training events that cost over $20,000, see IRM 1.32.10, Reporting on Event-Related Spending, for direction on funded programs to monitor costs, reporting requirements and exclusions.

6. For training included as part of a contract, the training must be a separate line item on the requisition and coded as training in IFS. Training listed as a separate task in a contract statement of work for the acquisition of goods and services should be submitted for review according to HCO’s policy. See IRM 6.410.1, Learning & Education (L&E) Policy.


**1.33.4.3.2.4** **(03-14-2019)**

##### Object Class 42, Insurance Claims and Indemnities Funding

1. Chief Counsel is responsible for administering funding for object class 42, Insurance Claims and Indemnities. Counsel processes and approves insurance claims and other litigation expenses under general ledger account 6100.4202 for parties that prevail in tax litigation cases against the IRS. Counsel also processes and approves indemnity payments, which include federal tort claims and employee personal property claims. Federal tort claims filed under the Federal Tort Claims Act are paid using general ledger account 6100.4201 for personal injury claims or general ledger account 6100.4209 for property damage claims. Employee personal property claims filed under the Military Personnel and Civilian Employee Compensation Act are also indemnity claims that are paid using general ledger account 6100.4209.

2. These claims are centrally funded through one of two methods:



1. FMSS is responsible for funding Counsel-approved attorney fee and indemnity claims in the Taxpayer Services (0912) and Enforcement (0913) appropriations.

2. IT is responsible for funding Counsel-approved attorney fee and indemnity claims in Operations Support (0919).


3. All non-tax litigation attorney fees or settlement claims are the responsibility of the business unit in which the claim arose. Settlement claims include payments to taxpayers for the expenses incurred due to an erroneous levy (general ledger account 6100.4203) and payments to current and former employees for the final settlement of a complaint (general ledger account 6100.4204). Claims also may include payments of claims and judgments that are taxable and arise from court decisions or abrogation of contracts (general ledger account 6100.4205) and those that are non-taxable and arise from court decisions or abrogation of contracts (general ledger account 6100.4206).

4. Amounts awarded, including settlements to current or former IRS employees or applicants for employment in equal employment opportunity (EEO) cases litigated in District Court, are the responsibility of the business unit in which the EEO complaint arose (general ledger account 6100.4211).


**1.33.4.3.2.5** **(12-16-2014)**

##### Rent Program and Building Delegation

1. Rent resources are centralized in FMSS.

2. The IRS occupies several GSA-delegated buildings and is responsible for all operations and maintenance (O&M). Building Delegation funds in functional area 3D are to be used solely for the GSA Building Delegation Program, as documented in delegation agreements.

3. Each year, GSA estimates the amount of O&M they would have charged if they had operated those buildings under their standard usage policies. In accordance with P.L. 107-217 (codified at 40 U.S. Code Section 121(d)(3)), the IRS is authorized to retain as no-year money the unexpended portion of its appropriated funds up to GSA’s estimated cost of O&M. Therefore, if IRS’s actual O&M costs for GSA-delegated buildings are less than GSA’s estimate for the given year, the difference is eligible for transfer (rollover) at year-end into no-year authority. Corporate Budget controls the transfer process and must obtain approval based on input from FMSS. FMSS is responsible for re-allocating funding to delegated site allotment offices once Corporate Budget has completed the appropriation transfer process.

4. Under no circumstances may rollover no-year funds be used for current-year labor costs. No-year rollover funds may be obligated at the discretion of the delegated site’s financial management officer to meet current-year needs and must be used in accordance with GSA-defined standards.


**1.33.4.3.2.6** **(02-07-2023)**

##### Electronic Tax Research Services

1. The Office of Servicewide Policy Directives and Electronic Resources (SPDER) provides comprehensive electronic tax law and legal research services, including training on these resources, through the ReferenceNet Legal and Tax Research Services, available on the Tax Administration Tools site.

2. For additional information, contact SPDER at \*SPDER@irs.gov.


**1.33.4.3.2.7** **(04-07-2025)**

##### Direct, Indirect and Centralized Support

1. Direct support that can be reasonably identified and charged to a specific functional area must be charged there.

2. Indirect support should be reviewed and charged to the multiple functional areas it supports if a reasonable distribution can be made. If no reasonable distribution is possible, indirect support will be charged to the predominantly benefiting functional area. The IRS policy is to maximize direct support and minimize indirect support to the extent practicable.

3. Support costs funded centrally by certain support organizations include, but are not limited to, the following:




| **CENTRALIZED SUPPORT** |
| :-: |
| **BUSINESS UNIT OWNER** | **PROGRAM** | **FUNDING RESPONSIBILITY** |
| --- | --- | --- |
| C&L | Closed caption services - for SABA events | C&L for SABA events only;<br> individual business unit for all other events (based on Visual Education and Communications Branch estimates) |
| Chief Counsel | Tax litigation attorney fees and indemnity claims | See _IRM 1.33.4.3.2.4_, Object class 42, Insurance Claims and Indemnities Funding |
| FMSS | Building delegation | FMSS |
| Buildings services and maintenance | FMSS |
| Courier (non-mail related) | FMSS |
| Equipment purchases | FMSS;<br> business units for exclusive use |
| Furniture | FMSS primary;<br> business units supplementary |
| Logistics contract | FMSS |
| Mail services at non-campus locations and National FMSS Mailroom Contract | FMSS |
| Mail meter rental and maintenance at non-campus locations | FMSS;<br> business units for exclusive use |
| Motorpool | FMSS manages all motorpool vehicles and is responsible for their associated payment, with the exception of the CI motorpool, which is CI’s responsibility. |
| Rent | FMSS |
| Security (guard services) | FMSS |
| Shred services | FMSS |
| Space and housing – space alterations | FMSS exclusively |
| Uninterrupted Power Source (UPS) | FMSS |
| HCO | Background investigations | HCO |
| Flexible Spending Account fees | HCO |
| Public Transit Subsidy Program | Funds are centralized and paid in plan 1111, but managed by HCO |
| IT | Copiers/Multi-Functional Devices (C/MFDs) contract | IT funds all photocopiers |
| Network printer consumables | For network printers only, IT funds toner and, depending on the printer type, printer drums; see paragraph (4). |
| Portable Electronic Devices (PEDs), such as cell phones, smartphones and hotspots | IT; see paragraph (5). |
| Taxpayer Services (TS) | Bulk printing and postage (such as tax packages and notices) | TS |
| Equipment rentals | Business units for rental of exclusive use;<br> TS for shared |
| Mail meter rental and maintenance at campuses | TS Direct; TS Shared Support |
| Mail services at campuses | TS |
| Post office boxes at campuses and shared PODs | TS Shared Support |
| Small POD supply program | TS Shared Support for participating offices only |
| Standard copy paper and fax toners | TS Shared Support for all DC metro and field offices |

4. IT User and Network Services manages the networked printers. The program includes networked end-user non-production printers (minimum 1-to-10 employee ratio). The networked printer program results in shared devices that cross organizational boundaries. To ensure printer consumable ordering/purchasing is transparent to the business units, User and Network Services administers the program through the Office of Acquisition Strategy. The program covers printer toner, waste toner bottles, oil bottles, photoconductors and, depending on the printer type, printer drums. The program does not cover paper products or consumables for stand-alone, non-qualifying printers. All IRS business units are eligible to participate in the program.

5. IT is responsible for funding all costs of portable electronic devices (PEDs), cell phones, smartphones and hotspots in its inventory. This includes replacement costs. The determination of who has authorized use of PEDs will be based on standard employee profiles and senior executive team direction.


**1.33.4.3.2.8** **(02-07-2023)**

##### Jury Fees

1. Jury fees are treated as a standard collection, not as a reimbursable. The actual collection transaction will be processed against the accounting string supplied by the business unit on the employee’s [Form 3210](http://core.publish.no.irs.gov/forms/internal/pdf/f3210--2010-04-00.pdf), Document Transmittal. All business units will use general ledger account 6100.1111 as the expense code on [Form 3210](http://core.publish.no.irs.gov/forms/internal/pdf/f3210--2010-04-00.pdf). If a business unit fails to supply a valid accounting string to the employee serving on the jury, its financial plan cannot recoup those fees; instead, the funds will default to a standard accounting string controlled by Corporate Budget. Please note that all debit vouchers will be posted to the same accounting string as the original check.

2. If the check is for time only, the employee should endorse the check by writing the words "Payable to Internal Revenue Service" on the back of the check beneath the employee's signature. The accounting string also should be identified on the jury fee check. In cases where the check for jury duty covers both time and travel, employees should cash the court's check and keep only the travel portion. Employees should complete a [Form 3210](http://core.publish.no.irs.gov/forms/internal/pdf/f3210--2010-04-00.pdf) to forward their personal check (payable to the Internal Revenue Service) and a copy of the court statement to the Government Payables & Funds Management Office. [Form 3210](http://core.publish.no.irs.gov/forms/internal/pdf/f3210--2010-04-00.pdf) should contain the employee’s full name as shown in personnel records, social security number, organizational unit, accounting string, office phone number and the dates of court attendance. The employee should mail the check and Form 3210, Document Transmittal, to: Internal Revenue Service; Government Payables & Funds Management Office, PO Box 9002, Beckley, WV 25802-9002 .


**1.33.4.3.2.9** **(02-07-2023)**

##### Food and Refreshments

1. The IRS may not use appropriated funds to provide food for federal employees except as authorized by statute (for example, travel regulations allow reimbursement for food through per diem).

2. See IRM 1.32.20, Using Appropriated Funds to Purchase Meals and Light Refreshments.

3. See IRM 1.32.10, Reporting on Event Related Spending.


**1.33.4.3.3** **(03-14-2019)**

#### IT BAC 98 Procedures

1. The following procedures apply to IT BAC 98 resources. The Chief Information Officer (CIO), has responsibility for all BAC 98 resources and all IT resources reside in the IT financial plan (MITQ). See _IRM 1.33.4.2.3.9_, IT BAC 98 Reprogramming Authority. IT provides additional financial operating guidelines for its own organization on its IT Procedures/Guidelines website.


**1.33.4.3.3.1** **(02-07-2023)**

##### Policy on Procuring IT Products and Services

1. Funds in BAC 98 and the BSM appropriation (fund 0921) are designated for procuring IT goods and services exclusively. BAC 98 provides funding for Servicewide IT operations, maintenance and investments to enhance or develop business applications for the business units. BAC 98 funds telecommunications, hardware and software (including commercial-off-the-shelf), contractual services, and staffing costs to manage, maintain and operate IT. Funds in BAC 98 also provide for critical or limited (except when funded by initiatives) improvements or enhancements to existing business applications. Purchases of IT-related goods and services may only be funded from BAC 98 or BSM funds. All IT-related needs should be routed through the IT organization.



### Exception:



CI’s Investigative Technology earmark is funded in BAC 35.





### Exception:



Telecommunications and other IT costs may be transferred from BAC 98 to the TFF no-year accounts for IRS’s share of the associated TFF expenses.

2. Appropriated funds are only available for the purposes for which they are appropriated, 31 U.S. Code Section 1301(a). If an object is specifically provided for in an appropriation, that appropriation must be used to the exclusion of a more general appropriation that might otherwise have been available for the item. Deliberately charging the wrong appropriation for expediency or administrative convenience, even with the intent to later transfer to the correct appropriation, unless otherwise permitted by law, is a legal violation.

3. The Commissioner delegated authority to the CIO to govern all areas related to IT resources and technology management (Delegation Order IT 2-1-1), including the responsibility to budget and deliver IT products. CIO policies and procedures are included in Delegation Order IT 2-1-1 and IRM 2.21.1, Introduction to Shopping Cart Processing for IT. The Master Service Level Agreement provides additional guidance for obtaining internal IT products and services. The Delegation Order, IRM and Master Service Level Agreement are all available on the IT Procedures/Guidelines website.


**1.33.4.3.4** **(12-16-2014)**

#### Operations Support and BSM Appropriations Reporting Requirements

1. IRS’s annual appropriation acts typically include several reporting requirements related to general IT investments and specific BSM projects.

2. Historically, reports have been due to the House and Senate Committees on Appropriations and the Comptroller General of the United States within 14 days after the end of each fiscal year quarter. Required content typically includes the cost and schedule performance for major IT investments and specific BSM projects, including the purpose and life-cycle stages of the investments, the reasons for cost and schedule variances, investment risks and strategies the IRS is using to mitigate them, and expected developmental milestones to be achieved and costs to be incurred in the next quarter.

3. Reporting requirements and timeframes may change each year, so for specific reporting requirements, business units should refer to the Operations Support and BSM appropriations language in the annual funding laws and consult with their Corporate Budget analysts.


**1.33.4.3.5** **(03-14-2019)**

#### Federal Highway Administration Trust Fund

1. The IRS performs work for the Department of Transportation’s Federal Highway Administration (FHWA) under the authority of the Highway Trust Fund. IT and SB/SE enforce and enhance the collection of highway use taxes through systems modernization. This work is funded through an allocation account. See [OMB Circular A-11](https://www.whitehouse.gov/omb/information-for-agencies/circulars/#budget), Part 1, Section 20, Terms and Concepts.

2. The FHWA, the parent agency, is responsible for recording the contract authority, recording appropriations to liquidate the contract authority, and tracking obligations and disbursements of the fund through use of its own Treasury appropriation fund symbol. FHWA issues budget guidance to the IRS on Form FHWA 370, Advice of Funds Available for Obligation. The dollar amount on Form FHWA 370 represents an allotment of contract authority to the IRS. This form provides both the authority and description of the project or program to be executed. It does not provide the funding authority (dollars) to pay the bills, just the transfer of contract authority. Funds are not transferred until needed for disbursement. When they are needed, FHWA will initiate a Form SF 1151, Nonexpenditure Transfer Authorization, based on IRS’s estimated quarterly disbursements. The CFO’s Financial Management organization reports commitments, obligations, expenditures and disbursements for this fund to FHWA, using both budgetary and proprietary accounts.

3. Trust fund accounting differs from general fund or revolving fund accounting since unused fund authority is returned to the parent agency annually and reallocated.


**1.33.4.3.6** **(03-14-2019)**

#### Private Collection Agency Expenditure Fund

1. Private debt collection (PDC) is allowed under specific criteria specified in P.L. 114-94, Fixing America’s Surface Transportation (FAST) Act.

2. A percentage of the funds that are collected by private collection agencies are transferred into a special no-year fund expenditure account with normal budgetary procedures. SB/SE is the lead organization. OMB requires a spend plan 10 days before they can be used.


**1.33.4.4** **(01-15-2008)**

### Accounting Issues

1. Most accounting policies can be found on the CFO - Home site, especially the CFO IRMs, but key budget execution policies are presented here.


**1.33.4.4.1** **(04-07-2025)**

#### Interagency Agreements or Reimbursable Agreements

1. The IRS can enter into two types of arrangements with other federal agencies: interagency agreements (IAA) or reimbursable agreements (RA). These agreements occur when federal agencies perform work and provide goods or services for other agencies and are reimbursed. Reimbursements between agencies are a form of resource transfer. The organization entering and signing the agreement is responsible for budgeting and arranging funding for the agreements. These transfers are prohibited without statutory authority.

2. The IRS enters into an IAA when it pays another agency to perform work for or provide goods or services to the IRS.

3. The IRS enters into an RA when it is reimbursed for performing the work for or providing goods or services to another agency. See IRM 1.33.3, Reimbursable Operating Guidelines.

4. In the event of a CR, continuing projects via IAAs can perform work and accrue earnings at the same rate that occurred in the prior year.

5. All interagency agreements should be processed in G-Invoicing, Fiscal Services’s online platform. it allows bureaus to electronically originate and maintain their agreement, record the accounting treatment of their reimbursable activity, to exchange that data with one another, and to settle Buy/Sell interagency agreements. General information is available at [G-Invoicing webpage](https://www.fiscal.treasury.gov/g-invoice/) and IRS-specific instructions are available at Procurement’s site, under ‘Inter Agency Agreements.’


**1.33.4.4.1.1** **(02-07-2023)**

##### Reimbursable Work Authorizations and Security Work Authorizations

1. Project managers for GSA reimbursable work authorizations (RWA) must work with GSA to obtain documentation supporting charges for work completed on individual RWAs (GSA Form 2957), including unbilled amounts. At year-end, project managers should send supportable estimates for all work completed on an RWA, but unbilled by GSA, to the Government Payables & Funds Management office’s Intra-governmental Payment and Collections (IPAC) unit. This will allow the IPAC unit to record an accounts payable for work completed but not yet billed.

2. Project managers for security work authorizations (SWA) must work with the Department of Homeland Security (DHS) to obtain documentation supporting charges for work completed on individual SWAs (FPS Form FPS 57), including unbilled amounts. At year-end, project managers should send supportable estimates for all work completed on an SWA, but unbilled by DHS, to the Government Payables & Funds Management office’s IPAC unit. This will allow the IPAC unit to record an accounts payable for work completed but not billed.


**1.33.4.4.1.2** **(02-07-2023)**

##### Intra-governmental Payment and Collection

1. FPMs, with input from project managers as appropriate, are responsible for certifying payment for all amounts billed from other federal agencies through the IPAC process. Certification indicates that the IRS has received all the goods and services being billed, and that those goods and services were acceptable. Certification of receipt and acceptance should be provided to the Government Payables & Funds Management office, specifically to the **\*CFO BFC Electronic IPAC Certification** mailbox, within 10 calendar days of receiving the bill. In cases where amounts billed are in dispute, a reconciliation should be provided to the IPAC unit, identifying the amounts and plans for resolving discrepancies. For more information, see IRM 1.35.3 , Receipt and Acceptance Guidelines.


**1.33.4.4.1.3** **(03-14-2019)**

##### Reimbursable Operating Guidelines

1. Obligations for reimbursable work may not be incurred until there is a binding agreement between the IRS and the requesting agency. Since FPMs cannot exceed their budgets, they must assist their reimbursables coordinators to comply with the long-standing policy: **no agreement, no work**. See IRM 1.33.3, Reimbursable Operating Guidelines, for guidance on the reimbursables program and the Reimbursables and Receivables site, for additional resources.


**1.33.4.4.2** **(02-07-2023)**

#### Vendor Payments

1. To comply with prompt payment regulations, the contracting officer’s representative (COR), alternate COR or end user must enter receipt and/or acceptance electronically in IFS via the PPS portal for procurement acquisitions. These entries will post in real time to IFS financial accounts.

2. The receipt posting establishes an accrual on the IRS financial statements and liquidates the obligation. Receipt can occur without acceptance. The business unit must record receipt for goods and/or services received regardless of whether it is a partial or complete order. If the business unit receives a complete order, it must document that the order is complete in IFS. The receipt function must be annotated in IFS as soon as the goods and/or services have been received, but no later than seven calendar days after a proper vendor invoice has been received by the Accounts Payable Office. See IRM 1.35.3, Receipt and Acceptance Guidelines.

3. The acceptance posting acknowledges that the goods and/or services meet specific conditions and requires the government to pay the vendor. Acceptance cannot occur without receipt. Acceptance of goods and/or services should be annotated as soon as the quality assurance inspection is complete and meets contractual obligation standards. Acceptance must be recorded in IFS no later than seven calendar days after a proper vendor invoice has been received by BFC, unless the award/contract contains language allowing additional time to perform the quality assurance function to determine whether the goods and/or services are acceptable and meet the terms and conditions of the award/contract. If the business unit accepts a complete order, it must document that the order is complete in IFS. See IRM 1.35.3, Receipt and Acceptance Guidelines.

4. The office that physically receives the goods and/or services must maintain documentation that supports recording the receipt and acceptance. Examples of appropriate receipt and acceptance documentation include timesheets, packing slips, delivery notifications, bills of lading, contract deliverables, training certifications and/or class rosters, or a signed quality assurance inspection document. If the COR or alternate COR is recording the receipt and/or acceptance for the end user, the end user must verify in writing with the COR or alternate COR (such as an email) that they have received and/or accepted the goods and/or services. The business unit purchasing the goods and/or services has responsibility to maintain the appropriate documentation supporting receipt and acceptance. See IRM 1.35.3, Receipt and Acceptance Guidelines.

5. The COR, alternate COR or end user must review contracts monthly (or on a cycle appropriate to the contract) to ensure receipt and acceptance activities are current and to make sure obligations are valid.


**1.33.4.4.3** **(12-16-2014)**

#### Commitments/Obligations

1. Commitments and obligations must be posted timely. See IRM 1.35.24, Establishing IRS Commitments and Obligations. Commitments set aside funds for future obligations and are a management tool that draws down availability. Obligations are legally binding agreements created by awards, contracts or purchase orders. Obligations for negotiated agreements must be entered in IFS prior to starting work. Obligations draw down (liquidate) commitments. Expenditures draw down (liquidate) obligations.

2. FPMs should make every effort to post data in IFS to the appropriate accounting string; however, accounting code corrections can be made in IFS. CFO Financial Management's procedures identify thresholds below which the accounting codes for the obligation should not be changed, except in certain cases. In situations where the actual accounting code cannot be corrected, the FPM may need to transfer funds to cover any budget deficit. There are separate rules for purchasing transactions, electronic travel system obligations, manual travel obligations and payroll. For Accounting Code Change guidance, see the work step instructions on IFS-PPS Resources.


**1.33.4.4.4** **(02-07-2023)**

#### Unliquidated Commitments/Obligations

1. Managing commitments and obligations timely enables the IRS to optimize its financial resources. Unliquidated commitments and obligations may be decommitted or deobligated whenever they are deemed no longer valid, at any time throughout the fiscal year. FPMs are responsible for coordinating with Procurement and the Government Payables & Funds Management office’s Inter-governmental & Funds Management (IGFM) section, the timely liquidation of orders or estimated obligations that are no longer valid.

2. Bulk-funded commitments and estimated obligations must be tightly controlled, reviewed and adjusted to actual requirements as quickly as possible. FPMs must review all outstanding unliquidated obligations monthly, regardless of fiscal year and appropriation, to identify unliquidated obligations that should be deobligated. They should contact the appropriate staff to help determine which unliquidated obligations should be deobligated. Aging of Unliquidated Commitments (AUC) and Aging of Unliquidated Obligations (AUO) programs have been established in IFS to assist and facilitate reviews. Periodic reviews are required by the CFO. See _IRM 1.33.4.2.3.2.4_, Aging of Unliquidated Commitments and Aging of Unliquidated Obligations Reviews.


**1.33.4.4.5** **(04-16-2010)**

#### User Fees

1. User fees are collected throughout the fiscal year for the costs of providing specific services and are deposited into a special fund receipt account. User fees may be used to supplement IRS appropriations to fund corporate needs. The IRS must submit user fee spend plans to OMB and receive their approval prior to transferring funds from the receipt account to IRS’s no-year accounts.

2. Once OMB has approved the spend plans, the IRS must request an apportionment to transfer the user fee funds from the receipt account into its user fee no-year accounts.

3. Once funds are transferred to the user fee no-year accounts and are distributed to a financial plan, they become part of that financial plan’s resource availability for the current fiscal year. See _IRM 1.33.4.2.3.1_, Managing within Resource Availability.

4. Balances available at fiscal year-end in the user fee no-year accounts, including recoveries from prior-year obligations, will be transferred back to the receipt account for redistribution the following fiscal year.

5. User fee charges for providing specific services must be reviewed every two years to ensure existing charges are adjusted to reflect changes in costs and to determine whether fees should be assessed for other goods and services. See OMB Circular 025, User Charges. This biennial review is done by the FPMs with assistance from the CFO’s Cost and User Fees office in Corporate Budget. Business units are responsible for collecting fees, maintaining case information, developing a method to track cases and fee information, and maintaining files for audit purposes. See IRM 1.33.7, User Fees.


**1.33.4.4.6** **(04-07-2025)**

#### Expired, Closed and No-Year Appropriations

1. Budget authority life cycles are discussed in [OMB Circular A-11](https://obamawhitehouse.archives.gov/omb/circulars_a11_current_year_a11_toc) and the narrative of the Financial Management Codes Handbook, found on Corporate Budget’s Key Budget Tools. Appropriation language defines the period during which funds are open as meaning available for new obligations. The IRS receives some multiyear and no-year funding, but most appropriations are annual appropriations, meaning they are open for one year. Special rules apply after an annual or multiyear appropriation expires.

2. Expired appropriations: Once the period of availability expires, new obligations may NOT be incurred. Balances are available only for upward and downward adjustments to existing or unrecorded obligations during the five years following expiration of obligation authority for annual and multiyear funds. See _IRM 1.33.4.2.1.1.2_, Time: the Bona Fide Needs Doctrine.



### Example:



During FY 2025, balances from annual appropriations for FY 2020 through FY 2024 are expired.





### Example:



The annual appropriation for FY 2025 (25250912D) will expire at 12:00 a.m. on October 1, 2025, and only be available for adjustments through FY 2030.

3. Travel is an exception and should always be obligated against the fiscal year in which it occurred. If an employee does not file a voucher timely, the travel must still be charged to the year in which the travel took place.

4. Closed appropriations: After the last expired year, the account is closed and the balances are canceled. Any invoices for valid obligations received after the account is closed must be obligated against and disbursed from current-year budget authority that is available for the same general purpose. No more than 1% of any annual appropriation is available to cover closed-year obligations. To monitor compliance with that limit in IFS, the IRS uses separate IFS funds designated by "Q" for these expenditures. The "Q" fund is a legal subset of the current-year appropriation and assigned to the same Treasury symbol. FPMs must use the "Q" fund for valid obligations received after the account is closed.



### Example:



Effective October 1, 2024 (FY 2025), annual appropriations for FY 2019 are closed.





### Example:



An annual appropriation for FY 2025 (for example, 25250912D) will close at 12:00 a.m. on October 1, 2030 (that is, in FY 2031, it is closed).





### Example:



An invoice is received during FY 2025 for a valid obligation that incurred against the FY 2019 annual Taxpayer Services appropriation (19190912D). Since the account was closed and budget authority was canceled effective October 1, 2024, the obligation would have to be made in the current year, FY 2025 against the closed-year Taxpayer Services "Q" fund account 25250912Q.





### Note:



The business unit must promptly move funds from the direct account, for example 25250912D, to the closed-year account, 25250912Q, to cover the expenditure (although it is handled systemically as an interappropriation transfer, this is not an actual interappropriation transfer because the "Q" fund account is legally a subset of the direct account).

5. No-year funds: Occasionally, the language for a specific appropriation of budget authority or the authorization of the appropriation may make all or some portion of the amount available until expended. This is referred to as no-year budget authority. These accounts are designated by an "X" in the account number, such as fund 25XX0913D.


**1.33.4.4.7** **(02-07-2023)**

#### Prior Year Funds Management

1. When a realignment of prior-year funds is needed, the correction must be determined by or approved by the affected business unit, who will request the correction by emailing Corporate Budget. The email request must include a full justification, all accounting strings needed and amounts. Corporate Budget will record approved adjustments in IFS and will respond via email informing the requester of the processed adjustment and the IFS transaction numbers.


**Exhibit 1.33.4-1**

### Division Finance Officers and Financial Plan Managers

The DFOs and FPMs have funds control responsibility for their financial plans. See _IRM 1.33.4.1.3_, Funds Control Responsibilities. This exhibit identifies the DFO and FPM by position title.

| **DIVISION FINANCE OFFICERS AND FINANCIAL PLAN MANAGERS** |
| :-: |
| **Financial Plan (FP code)** | **Division Finance Officers** | **Financial Plan Managers** |
| --- | --- | --- |
| Appeals (APPZ) | Director, Case and Operations Support | Director, Finance |
| Chief Communications & Liaison (CALC) | Director, Finance and Education | Director, Finance and Education |
| Chief Financial Officer (CFOB) | Director, National HQ Budget Office | Director, National HQ Budget Office |
| Counsel (ATTY) | Associate Chief Counsel (Finance and Management) | Director, Financial Management |
| Criminal Investigation (CIDV) | Director, Strategy | Director, Finance |
| Executive Leadership and Direction (NHQM) | Director, National HQ Budget Office | Director, National HQ Budget Office |
| Facilities Management and Security Services (AWSP/STWD) | Associate Director, Financial Management Branch | Associate Director, Financial Management Branch |
| Human Capital Office (HCOH/HCCJ) | Director, Finance | Chief, Financial Management |
| Information Technology (MITQ) | Director, Financial Management Services | Chief, Budget Planning,<br> Chief, Budget Execution<br> Chief, Support Services |
| Large Business and International (LMSB) | Director, Management & Finance | Manager, Finance |
| Privacy, Government Liaison and Disclosure (PLDG) | Director, Program Planning Support | Chief, Financial Planning and Technology |
| Small Business/Self-Employed (SBSE) | Director, Business Support Office | Director, Business Support and Finance Senior Managers |
| Tax Exempt and Government Entities (TEGE) | Director, Finance | Director, Finance |
| Taxpayer Advocate Service (TPAX) | Director, Financial Operations | Director, Financial Operations |
| Taxpayer Services (WAGE/WISK) | Director, Taxpayer Services Operations Support (TSOS) | Chief, Finance |
| Other Corporate Plans (1111/0290) | Associate CFO, Corporate Budget | Director, Budget Execution |

**Exhibit 1.33.4-2**

### Master Data (Code) Change Request Procedure

Financial Management Master Data includes fund centers, cost centers, functional areas, commitment items and funded programs (also called internal order codes or IOCs).

To request master data additions, changes or deactivations, see the Master Data Request Templates on the CFO - Home site, specifically Corporate Budget’s Key Budget Tools. Completed request forms are normally submitted to Corporate Budget at [\*CFO Master Data Request](https://www.irs.gov/irm/part1/CFO.Master.Data.Request@irs.gov), or for funded programs to Financial Management Systems at \*CFO Internal Order MD Request.

For reorganizations, the business unit should contact Corporate Budget as soon as senior management approves the initial reorganization proposal. See _IRM 1.33.4.2.3.7_, Reorganizations and Other Modifications Affecting Budget. Corporate Budget facilitates establishing financial codes associated with reorganizations. The business unit should meet with Corporate Budget to discuss the purpose of the reorganization, to compare the old structure to the proposed structure hierarchy and to determine derivation rules. Once an agreement is made, business units should submit the appropriate request forms and an organizational chart to Corporate Budget at least 60 days prior to the anticipated effective date of the reorganization. Corporate Budget will coordinate with HR Connect representatives to ensure accurate and complete information is available to implement the financial codes in HR Connect.

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-033-004#addtoany "Show all")

A2A