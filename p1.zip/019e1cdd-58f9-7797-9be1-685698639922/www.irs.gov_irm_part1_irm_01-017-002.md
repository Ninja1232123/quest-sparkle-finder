---
url: "https://www.irs.gov/irm/part1/irm_01-017-002"
title: "1.17.2 Publishing Systems and Programs | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-017-002#main-content)

- 1.17.2  [Publishing Systems and Programs](https://www.irs.gov/irm/part1/irm_01-017-002#id1)
  - 1.17.2.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-017-002#id2)
    - 1.17.2.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-017-002#id4)
    - 1.17.2.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-017-002#id5)
    - 1.17.2.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-017-002#id6)
    - 1.17.2.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-017-002#id7)
    - 1.17.2.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-017-002#id8)
    - 1.17.2.1.6  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-017-002#id9)
    - 1.17.2.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-017-002#id10)
  - 1.17.2.2  [Request Publishing Services](https://www.irs.gov/irm/part1/irm_01-017-002#id11)
    - 1.17.2.2.1  [Copying Services](https://www.irs.gov/irm/part1/irm_01-017-002#id13)
  - 1.17.2.3  [Publishing Programs](https://www.irs.gov/irm/part1/irm_01-017-002#id14)
    - 1.17.2.3.1  [Business Card Program](https://www.irs.gov/irm/part1/irm_01-017-002#id16)
    - 1.17.2.3.2  [Employee Recognition for Career Service and Performance Awards](https://www.irs.gov/irm/part1/irm_01-017-002#id17)
    - 1.17.2.3.3  [Envelope Program](https://www.irs.gov/irm/part1/irm_01-017-002#id18)
    - 1.17.2.3.4  [Internal Revenue Bulletin (IRB) Program](https://www.irs.gov/irm/part1/irm_01-017-002#id19)
    - 1.17.2.3.5  [Internal Revenue Manual (IRM) Program](https://www.irs.gov/irm/part1/irm_01-017-002#id20)
    - 1.17.2.3.6  [Letter Program](https://www.irs.gov/irm/part1/irm_01-017-002#id21)
    - 1.17.2.3.7  [Letterhead/Stationery Program](https://www.irs.gov/irm/part1/irm_01-017-002#id22)
    - 1.17.2.3.8  [Training Products Program](https://www.irs.gov/irm/part1/irm_01-017-002#id23)
    - 1.17.2.3.9  [Substitute Forms Program](https://www.irs.gov/irm/part1/irm_01-017-002#id24)
    - 1.17.2.3.10  [Survey Program](https://www.irs.gov/irm/part1/irm_01-017-002#id25)
  - 1.17.2.4  [Program Planning](https://www.irs.gov/irm/part1/irm_01-017-002#id26)
    - 1.17.2.4.1  [Review and Evaluation Conferences](https://www.irs.gov/irm/part1/irm_01-017-002#id28)
  - 1.17.2.5  [Publishing Applications](https://www.irs.gov/irm/part1/irm_01-017-002#id29)
    - 1.17.2.5.1  [Electronic Status Notice (ESN)](https://www.irs.gov/irm/part1/irm_01-017-002#id31)
    - 1.17.2.5.2  [Publishing Services Data (PSD)](https://www.irs.gov/irm/part1/irm_01-017-002#id32)
    - 1.17.2.5.3  [Core Repository of Published Products (CROPP)](https://www.irs.gov/irm/part1/irm_01-017-002#id33)
    - 1.17.2.5.4  [Integrated Composition Program](https://www.irs.gov/irm/part1/irm_01-017-002#id34)

# Part 1. Organization, Finance, and Management

# Chapter 17. Publishing

# Section 2. Publishing Systems and Programs

* * *

## 1.17.2 Publishing Systems and Programs

#### Manual Transmittal

December 05, 2025

#### Purpose

(1) This transmits revised IRM 1.17.2, _Publishing - Publishing Systems and Programs_.

#### Material Changes

(1) IRM 1.17.2.3.1(4), _Business Card Program_ \- Added content to clarify that the business card program does not support the purchase or creation of digital NFC cards.

(2) IRM 1.17.2.3.6(7), _Letter Program_ \- Added content to describe production of systematically generated letters Information Technology creates and Media & Publications Distribution supports.

(3) IRM 1.17.2.3.8(2), _Training Products Program_ \- Removed text that refers to the IMDDS program, which is discontinued. We also updated “ELMS” to “ITM.”

(4) Editorial changes made to update hyperlinks.

#### Effect on Other Documents

This supersedes IRM 1.17.2 dated October 11, 2024.

#### Audience

All IRS employees, contractors, and vendors who design, publish, or distribute printed and/or electronic internal/external material.

#### Effective Date

(12-05-2025)

Tracey K. Quamie

Director, Publishing

Media & Publications Division

**1.17.2.1** **(12-05-2025)**

### Program Scope and Objectives

1. **Purpose:** Publishing’s mission is to plan and produce or procure all IRS print and electronic communications products used by the public to comply with tax filing requirements and obligations and used internally within IRS for tax administration. This section describes established publishing programs administered by the Publishing organization. It includes various electronic systems and applications used to receive, order, control, issue, and support the publication of IRS print and electronic communications products. Updates to changes in services are posted on the Media & Publications (M&P) Publishing and Distribution Intranet website at http://publish.no.irs.gov.

2. **Audience:** The audience for this IRM is IRS employees Servicewide.

3. **Policy Owner:** The Director of Publishing owns the policies contained herein.

4. **Program Owner:** Taxpayer Services (TS), Customer Assistance Relationships and Education (CARE), M&P, Publishing is responsible for the administration, procedures, and updates related to the program.

5. **Primary Stakeholders.** Tax Forms & Publications (TF&P) in M&P, CARE, TS; Chief Financial Officer of the IRS; Distribution in M&P, CARE, TS; IRS organizations servicewide.

6. **Contact Information.** The Director of Publishing in M&P in CARE, TS.


**1.17.2.1.1** **(10-11-2024)**

#### Background

1. Publishing’s mission is to plan and produce or procure all IRS print and electronic communications products used by the public to comply with tax filing requirements and obligations and used internally within the IRS for tax administration. The Publishing function (also known as "Publishing" ) under M&P within TS develops and delivers published products in electronic, paper, and other alternative formats for internal (employees) and external (taxpayers) use.


**1.17.2.1.2** **(10-11-2024)**

#### Authority

1. Publishing’s authority as the official IRS publisher is documented in IRM 1.17.9.7, _Roles and Responsibilities When Publishing a Product_.


**1.17.2.1.3** **(10-11-2024)**

#### Roles and Responsibilities

1. This section explains the responsibilities associated with being a published product originator and the roles and responsibilities of all involved in the published product processes.


**1.17.2.1.4** **(12-05-2025)**

#### Program Management and Review

1. **Program Reports.** Balanced measures for tax and non-tax products.

2. **Program Effectiveness.** The Computer Assisted Publishing System (CAPS) has reporting capabilities that enable management and employees to monitor and track delivery of Publishing products and services.


**1.17.2.1.5** **(12-05-2025)**

#### Program Controls

1. The Computer Assisted Publishing System (CAPS) has reporting capabilities that enable management and employees to monitor and track delivery of Publishing products and services.


**1.17.2.1.6** **(12-05-2025)**

#### Terms and Acronyms

1. This IRM section uses the following terms and acronyms to describe the involved processes and resources.



**Terms**






| Term | Definition |
| --- | --- |
| Form | A document with spaces to store information |
| Product | Something tangible created or produced |
| Publish | Prepare and issue for use and distribution |
| Service | Something done on behalf of others |







**Acronyms**






| Acronym | Definition |
| --- | --- |
| ADP | Automatic Data Processing |
| ATG | Audit Techniques Guides |
| BOD | Business Operating Division |
| C&L | Communications & Liaison |
| CAPS | Computer Assisted Publishing System |
| CARE | Customer Assistance Relationships and Education |
| CER | Centralized Evaluative Review |
| CGI | Common Gateway Interface |
| CMS | Content Management System |
| CPA | Certified Public Accountant |
| CPM | Composition Process Management |
| CROPP | Core Repository of Published Products |
| CSS | Customer Support Services |
| ELITE | Enterprise Logistics Information Technology System |
| EPS | Encapsulated PostScript |
| ERP | Employee Recognition Program |
| ESN | Electronic Status Notice |
| GPO | Government Publishing Office |
| GSA | General Services Administration |
| HTML | Hyper-text mark-up language |
| IMD | Internal Management Document |
| IRB | Internal Revenue Bulletin |
| IRM | Internal Revenue Manual |
| ITM | Integrated Talent Management |
| LPTS | Linguistic Policy, Tools and Services |
| NDC | National Distribution Center |
| OCA | Office of Compliance Analytics |
| OLS | Online Services |
| PDF | Portable Document File |
| PII | Personally Identifiable Information |
| PRA | Paperwork Reduction Act |
| PS | Personnel Security |
| PSD | Publishing Services Data System |
| PSR | Publishing Service Request |
| SBU | Sensitive But Unclassified |
| SGML | Standard Generalized Markup Language |
| TAC | Taxpayer Assistance Center |
| TCS | Taxpayer Correspondence Services |
| TF&P | Tax Forms & Publications |
| TIGTA | Treasury Inspector General for Tax Administration |
| TIN | Taxpayer Identification Number |
| TPDS | Training Products Distribution System |
| TS | Taxpayer Services |
| WCMS | Web Content Management System |


**1.17.2.1.7** **(12-05-2025)**

#### Related Resources

1. Document 12687, _Getting Your Information Published at the IRS_

2. Document 12616, _Design Guidelines for IRS Internal and Non-Tax Public Use Forms_

3. IRM 1.17.7, _Use of the Official IRS Seal, IRS Logo, Program Logos and Internal Logos_

4. IRM 1.17.1, _Publishing, Overview of Publishing Authorities, Roles and Responsibilities, and Organizational Structure_

5. IRM 22.31.1, _Multilingual Initiatives, IRS Language Services_


**1.17.2.2** **(07-20-2020)**

### Request Publishing Services

1. Product originators must request all services from M&P Publishing by submitting a Publishing Services Request (PSR), regardless of the type of media and ultimate production source determination. M&P Publishing assigns the PSR to a publishing specialist to provide service.

2. The PSR automates the process of obtaining business and funding approvals, gathering product information, and initiating contact with Publishing. Product originators can use the PSR to request any type of publishing service that previously required a Form 1767, _Publishing Services Requisition_.

3. The requisition requires signature authority from one of the following before committing any resources:



   - The Commissioner

   - Operating Division Commissioners or Deputy Commissioners or their designees

   - Chief Officers or designees

   - National Taxpayer Advocate

   - Chief Counsel, or

   - Other Executive Heads of Office or designees


4. Each office must provide M&P Publishing with a list of individuals authorized to sign their requisitions. Use Form 13200, _Authorization to Designate Business Approvers for Publishing Services Requests_, to add, delete, or update names, titles, office symbols, or SEIDs. Submit a new Form 13200 when changes occur.

5. Product originators should only use the Form 1767 when the online PSR is not available or cannot meet the customer’s requirements.

6. For additional information on how to fill out a PSR, refer to IRM 1.17.9, _Publishing, User Guide for Requesting Published Products and Services_.


**1.17.2.2.1** **(08-12-2021)**

#### Copying Services

1. Customers needing copy services should consult with a publishing specialist or submit a PSR. You can find the list of publishing specialists on the Publishing website at http://publish.no.irs.gov/publish/psal.html.


**1.17.2.3** **(07-15-2019)**

### Publishing Programs

1. This section describes programs that M&P Publishing provides:



   - Business Card

   - Employee Recognition Program for Career Service and Performance Awards

   - Envelope

   - Internal Revenue Bulletin

   - Internal Revenue Manual

   - Letter

   - Letterhead/Stationery

   - Training Products


2. For a complete and current list of Publishing programs, go to https://publish.no.irs.gov/publish/puborg.html#tab=tab1.


**1.17.2.3.1** **(07-20-2020)**

#### Business Card Program

1. The IRS has the authority to pay for business cards for employees directly involved in promoting Electronic Tax Administration, personnel recruitment, and significant public contact.

2. M&P Publishing manages the production contract for business cards and has developed a system that allows employees and managers to request and order business cards electronically.

3. Find up-to-date information and guidance about the business card program on the M&P Publishing website at https://publish.no.irs.gov/pubsys/bcard/bcards.html#tab=tab1.

4. The business card program is not issuing or accountable for Digital NFC cards. Please see IRM 1.17.7.4.8 about QR codes on cards.


**1.17.2.3.2** **(08-12-2021)**

#### Employee Recognition for Career Service and Performance Awards

1. The IRS designed the Employee Recognition Program (ERP) to recognize IRS employees with various awards and/or certificates. IRS managers are encouraged to recognize employee contributions and accomplishments through the ERP. The manager must decide what type of award or certificate is appropriate for the employee to receive and must include a brief write-up, which will be formatted on the award or certificate.

2. A publishing specialist in the Functional Publishing section manages all aspects of this program, including the ordering, designing, proofing, and distribution of these awards to the recipients.

3. See IRM 6.451.1.15, _IRS Employee Recognition Program_, for more information or visit the Employee Recognition Program website at http://hco.web.irs.gov/erp/index.html.

4. Product originators must use an approved PSR to make all requests for non-career and non-performance awards and must include Form 15055, Employee Recognition Program (ERP) - Order Request Summary, and Form 15055-A, _Employee Recognition Program (ERP) - Certificate Personalization Request_.

5. All awards are personalized and sent directly to the originator or the recipient.

6. See IRM 6.451.1, _Employee Performance and Utilization - Awards and Recognition_, for more information and guidance on how the Internal Revenue Service recognizes employees.


**1.17.2.3.3** **(10-20-2022)**

#### Envelope Program

1. The envelope program provides all IRS offices with the correct size, type, and quantity of printed envelopes required for correspondence and special mailing programs and ensures that all envelopes conform to Postal Service regulations.

2. Envelope Program specialists are responsible for reviewing and processing printing requisitions and/or procurements, administering the envelope contracts, updating and maintaining envelope ordering procedures, and participating on various task forces and groups responsible for the Envelope Program workflow processes and/or implementations.

3. IRM 1.17.8.4.3, _Envelopes_, provides detailed information on the envelope program, including envelope standards, ordering and procurement procedures, specifications review, IRS envelope contracts, and other related information.

4. Additional envelope user information is available on the M&P Publishing and Distribution website at https://publish.no.irs.gov/pubsys/envelope/envprog.html#tab=tab1.

5. Refer to IRM 1.17.10.3, _Item IDs_, regarding identification standards for envelopes.


**1.17.2.3.4** **(08-18-2016)**

#### Internal Revenue Bulletin (IRB) Program

1. The authoritative instrument for the distribution of official IRS tax guidance is the Internal Revenue Bulletin (IRB), a weekly collection of items of general interest to the tax professional community.

2. The IRS publishes a weekly bulletin that contains all substantive rulings necessary to promote a uniform application of the tax laws. The first bulletin of the calendar year is reserved for publication of user fees, technical advice, and procedures for issuing rulings.

3. The weekly bulletin is available on the Internal Revenue Service Bulletin Board on the Intranet at http://core.publish.no.irs.gov/irb/pdf/index.html, and on the Internet at [http://www.irs.gov/irb/](http://www.irs.gov/irb/).


**1.17.2.3.5** **(10-20-2022)**

#### Internal Revenue Manual (IRM) Program

1. The IRM is the primary, official source of IRS instructions to staff relating to the administration and operation of the Service. The IRM contains policy, procedures, and direction employees need to carry out their responsibilities in administering tax laws or other agency obligations.

2. Publishing specialists on the IRM team manage publishing the IRM, including:



   - Reviewing and processing Form 1767, _Publishing Services Requisition_

   - Administering the IRM composition and printing contract

   - Managing the electronic IRM files in the Core Repository of Published Products (CROPP)

   - Distributing the electronic IRM files from the CROPP to other IRS divisions


3. IRM team members also participate on various task forces and groups responsible for IRM process redesign and implementation. To see a current list of IRM team members, visit http://publish.no.irs.gov/pubsys/irm/irm.html#tab=tab1.

4. IRM 1.11.2, _Internal Revenue Manual (IRM) Process_, describes the IRM and its components, including the



   - Author and Internal Management Document (IMD) responsibilities

   - Checklist for preparing IRMs for publishing

   - Format

   - Numbering

   - Sample Manual Transmittals

   - Structure


5. To view the IRM online, go to http://publish.no.irs.gov/pubsys/irm/numind.html.

6. Refer to IRM 1.17.10.3, _Item IDs_, regarding identification standards for IRMs.


**1.17.2.3.6** **(12-05-2025)**

#### Letter Program

1. The letter program team performs publishing and customer analysis, and administrative and operational workflow processes, for the public-use letters used to communicate with the public about tax matters and to provide general tax information. Publishing formats letters based on M&P design standards. A system other than the product catalog page may generate the final letter sent to the taxpayer and may format it differently. However, the textual content must stay the same.

2. If an IRS letter is sent to 10 or more entities, then Publishing must assign an official IRS letter and catalog number, and the Taxpayer Correspondence Services (TCS) must review the letter content. See IRM 1.17.10.3, _Item IDs_, for letter numbering standards and IRM 25.13.1 for TCS.

3. Publishing specialists number, format, design, issue, and post letters to the CROPP.

4. Refer to IRM 1.17.8.5.2, _Letters_, at http://irm.web.irs.gov/link.aspx?link=1.17.8.5.2 for detailed information on the Letter program. Visit the Form Letter Program Intranet page at http://publish.no.irs.gov/pubsys/letterp/lphome.html _http://publish.no.irs.gov/pubsys/letterp/lphome.html_ for the most current information.

5. An attachment to a letter asking the taxpayer to complete and return information is a form and must be identified with form and catalog numbers. A separate Publishing Services Request (PSR) is required to create a new form. See IRM 1.17.8.5.1, _Forms_, for form requirements.

6. Before submitting a request to create a new letter, please go to our Product Catalog Information page at http://publish.no.irs.gov/catlg.html, and perform a search by title to determine if a suitable letter already exists. Additionally, you can view the letter list of all letter numbers, which includes active letters and newly assigned letter numbers. Use the down arrows at the column headings to sort the file by originator name, originator address, long title, etc.

7. We produce letters systemically created in the Correspondex system (CRX-Letters, CP Notices and ACS letters) and published on the Servicewide Notice Information Program (SNIP) in collaboration with Information Technology (IT) with support from Taxpayer Correspondence Services.


**1.17.2.3.7** **(11-19-2012)**

#### Letterhead/Stationery Program

1. IRM 1.10.1, Office of the Commissioner of Internal Revenue, IRS Correspondence Manual, provides guidance and procedures for the preparation of IRS and Treasury correspondence. The consistent use of IRS letterhead will help the IRS present one face to the public while reassuring taxpayers that correspondence they receive from IRS is legitimate and official.

2. To accomplish this, IRS stationery is produced in two ways:



   - Preprinted stationery paper

   - Electronic letterhead (where approved by business unit)


3. For correspondence produced on preprinted stationery, the letterhead is printed using specific green ink on a particular type of paper that carries an eagle watermark.

4. For electronically produced correspondence, it’s acceptable for the letterhead to print in black ink.

5. In both cases, you must use a customized font. We developed this font to make it difficult for external entities to forge IRS stationery.

6. To access the only acceptable stationery formats and their corresponding Word templates, go to http://publish.no.irs.gov/pubsys/letterhead/lttrhead.html.

7. You may order preprinted stationery from the IRS forms hotline at the National Distribution Center (NDC). Call the NDC at 800-829-2765 and provide the operator with the stationery's catalog number and your Internal Management Documents Distribution at http://publish.no.irs.gov/distsys/imdds/opnlkup.html.


**1.17.2.3.8** **(10-20-2022)**

#### Training Products Program

1. Publishing and Distribution team members input and maintain course requirements, printing and distribution of IRS training material. Team members also provide technical support in the areas of quantity requirements, copy preparation, printing schedules, printing contracts, and printing budgets.

2. The training team supports official training courses developed by Learning and Education (L&E). This includes the Training Products Distribution System (TPDS) products and Automated Data Processing (ADP) products used at IRS campuses. The training team also processes one-time publishing requests for pilot materials used to develop subsequent ITM courses. For additional information, refer to Training Products Program at https://publish.no.irs.gov/pubsys/training/training.html.

3. Refer to IRM 1.17.10.3, _Item IDs_, regarding identification standards for training products.


**1.17.2.3.9** **(10-11-2024)**

#### Substitute Forms Program

1. The Substitute Form Program reviews and approves tax forms and schedules reproduced by software developers and form designers, commonly known as substitute forms. The major responsibility of the program is to ensure the integrity of IRS forms is upheld, but to also ensure that the IRS, and other government agencies, will receive quality substitute forms that will have no adverse impact on processing.

2. Analysts provide information to vendors, in publications and through email, on roles, responsibilities, procedures, resources, and any other information not specified in governing publications and or revenue procedures. Although the primary responsibility of the unit is to ensure the quality and integrity of reproduced IRS forms is upheld, analysts are also responsible for responding to correspondence received from internal and external stakeholders and partners, vendors, certified public accountants (CPA), tax practitioners, and taxpayers. In most cases, providing feedback requires extensive research and collaboration to ensure that vendors, practitioners, and taxpayers receive the most accurate information to avoid an adverse impact when reproducing and or filing substitute forms. In addition, analysts are also tasked with providing assistance and information for investigations initiated by the agency (e.g., Treasury Inspector General for Tax Administration (TIGTA) or Office of Compliance Analytics (OCA)).

3. Forms reviewed by the unit and covered in publications and revenue procedures include:



   - Applications for permission to file returns electronically and forms used as required documentation for electronically filed returns

   - Forms and schedules relating to partnerships, exempt organizations, and employee plans

   - IRS tax forms and their related schedules

   - Over-the-counter estimated tax payment vouchers

   - Powers of Attorney

   - Worksheets as they appear in instructions packages


Publications cover eight components of each substitute form. Revenue procedures in the Internal Revenue Bulletin generate these publications:



   - Publication 1141, 07-2023 Catalog No. 47000C— _General Rules and Specifications for Substitute Forms W-2 and W-3_

   - Publication 1167, 10-2023 Catalog No. 47013F— _General Rules and Specifications for Substitute Forms and Schedules_

   - Publication 1179, 10-2023 Catalog No. 47022Q— _General Rules and Specifications for Substitute Forms 1096, 1098, 1099, 5498, and Certain Other Information Returns_

   - Publication 1223, 12-2023 Catalog No. 61278W— _General Rules and Specifications for Substitute Forms W-2c and W-3c_

   - Publication 4436, 3-2024 Catalog No. 39499P— _General Rules and Specifications for Substitute Form 941, Schedule B (Form 941), Schedule D (Form 941), Schedule R (Form 941), and Form 8974_

   - Publication 5223, 11-2023 Catalog No. 67909Y— _General Rules and Specifications for Affordable Care Act Substitute Forms 1095-A, 1094-B, 1095-B, 1094-C, and 1095-C_


**1.17.2.3.10** **(07-20-2020)**

#### Survey Program

1. The survey program team is responsible for working closely IRS-wide with Business Operating Division (BODs) representatives to coordinate the printing and administration of their Customer Experience Research (CER) surveys and Burden surveys. The CER surveys evaluate customer experiences with their interaction with the IRS and help to identify operational improvements. The Burden surveys provide congress and the president with accurate estimates of the time and money taxpayers spend to follow federal tax rules and regulations. Tax administrators and policy managers use this information to reduce and manage taxpayer burden.

2. Survey program specialists are responsible for helping the BOD prepare their correspondence pieces for production and mailing by working closely with the TCS to ensure the content complies with IRS requirements and the Letter Program to ensure that letters are formatted according to IRS standards.

3. The program specialists also work closely with the Human Capital Office (HCO) Personnel Security (PS) Contractor Security Onboarding to ensure that print contractors have the necessary clearances to work with Personally Identifiable Information (PII) and Sensitive but Unclassified Information (SBU). This process involves fingerprinting, background checks, credit checks, selective service enrollment and tax compliancy. Only after they receive clearance can a contractor work on IRS work involving PII and/or SBU.

4. The specialist must ensure that each print contractor is up to date with their annual mandatory briefings and that their training is recorded in the Integrated Talent Management (ITM) system.

5. Specialists must rectify monthly postage from the correspondence for each survey with the Postal One records to verify that the correct postage is being billed to the IRS.


**1.17.2.4** **(11-19-2012)**

### Program Planning

1. Program planning requires assessing the need for products or programs through meetings, discussions, and information exchanges among the publishing specialists and the customer organizations. It focuses on understanding of mutual expectations that will lead to the timely and successful production of program items relevant to the customer’s missions.

2. Program planning focuses on achieving the following:



   - Becoming familiar with customer organizational mission and goals

   - Educating the customer about the Service’s concept of operation and definition of roles

   - Developing mutual activity agenda and expectations that serve as criteria for measuring programs results

   - Reviewing and evaluating program accomplishments to serve as key to improving customer service


**1.17.2.4.1** **(09-28-2015)**

#### Review and Evaluation Conferences

1. Annual review and evaluation conferences assess operation of the previous year’s programs. The goals of the conference are to evaluate past performance, examine problem areas, suggest solutions, and explore alternative methods of program operation.

2. Program Planning Conferences follow review and evaluation conferences. The primary areas discussed during program planning are:



   - New production techniques

   - Changes in requirements

   - Production schedules

   - Product specifications


3. Typically, review and evaluation conferences are conducted for the following programs:



   - IRM

   - Envelopes

   - Annual and Quarterly Mailings

   - Recruitment Publications

   - Specialty Forms

   - Tax Forms

   - Tax Guides

   - Taxpayer Information Publications

   - Taxpayer Education


**1.17.2.5** **(09-28-2015)**

### Publishing Applications

1. The Computer Assisted Publishing System (CAPS) contains various information management applications and hosts the Core Repository of Published Products (CROPP), the Electronic Publishing website, and "Page 1" (M&P Internal) Web page.

2. Publishing mainly uses two applications:



   - Electronic Status Notice (ESN)

   - Publishing Services Data (PSD)


Both applications provide data to support product procurement scheduling and tracking, cost and quantity information, billing and payment information, product revision information, distribution warehousing and order fulfillment activities, balanced measures, and customer-oriented applications (e.g., Electronic Publishing website, milestone reporting, financial reporting, and customer satisfaction survey).



**1.17.2.5.1** **(08-17-2018)**

#### Electronic Status Notice (ESN)

1. The Electronic Status Notice system provides the official record for all forms, letters, notices, publications, envelopes, documents, and training publications. ESN is the database of all published products.

2. The purpose of ESN is to collect, verify, and disseminate information about IRS published products. This information consists of various physical, historical, and program-oriented data. Its data structure is a product attribute file used to identify the use and handling of published products. ESN is the definitive source of all product-related characteristics and must contain all the information required by the other Publishing data systems and applications. (e.g., PSD, ELITE, CROPP, etc.)

3. ESN contains information on published products, including identifying number, title, using and stocking points, related directives, disposition of prior issuances, and other data pertaining to their purpose and use.

4. ESN also contains information on those standard forms most commonly used in Internal Revenue Service offices and those forms and publications of agencies and bureaus, such as Department of the Treasury, the Office of Personnel Management and the Social Security Administration, whose forms and publications are used in the regular course of IRS business.

5. No other published product database will be maintained within the IRS without the expressed written permission of the Director, M&P Publishing.


**1.17.2.5.2** **(08-18-2016)**

#### Publishing Services Data (PSD)

1. The PSD application provides budget execution management, requisition tracking and control, and GPO processing for all requests for publishing services.

2. M&P uses PSD to:



   - Record, report, and verify financial obligations and GPO Intergovernmental Payment and Collections invoices made for procurements of products

   - Maintain the system of record audit financial documentation for GPO procurements

   - Maintain procurement data used to generate various procurement documents such as GPO Form 2511 and Distribution files

   - Provide data for product and procurement analysis

   - Provide accurate production status information to customers and stakeholders

   - Provide data for Publishing's balanced measures results


**1.17.2.5.3** **(10-20-2022)**

#### Core Repository of Published Products (CROPP)

1. M&P Publishing develops and maintains a publishing management system to collect, store, manage, and deliver electronic products for use in electronic publishing applications such as web publishing (intranet and internet), on-demand printing, and CD-ROM and DVD publishing. Publishing specialists are the first point of contact for adding, revising, or obsoleting products in the CROPP. Only Publishing can post published products to the intranet and IRS.gov.

2. The CROPP contains all number-controlled, official published products issued by the Service and must serve as the primary source for all products that meet this criteria. These products are available (for download or print) to IRS employees through the Publishing and Distribution Intranet site at http://publish.no.irs.gov, or may be hyperlinked from other Service Intranet resources using standardized Common Gateway Interface (CGI) programs.

3. The CROPP contains files of all official IRS forms, instructions, documents, publications, manuals, and other Service products in standard, nonproprietary formats. Certain products are available for local printing by the National Distribution Center (NDC).

4. M&P Publishing established the CROPP to manage product attributes and make available appropriate file formats for use in electronic and print applications.

5. At http://publish.no.irs.gov/ephlp.html#tab=tab7, the CROPP contains descriptions of the following types of electronic files:



   - Source-file formats \[Standard Generalized Markup Language (SGML), Extensible Markup Language (XML), Encapsulated PostScript (EPS), and Portable Document Format (PDF)\]

   - Distribution files \[Hypertext Markup Language (HTML) and Portable Document Format (PDF)\]

   - Graphic files and text files (various formats)


6. Electronic files can only post to the CROPP after the product content owner/originator provides an "ok-to-publish."

7. The CROPP can be accessed at http://publish.no.irs.gov/catlg.html.


**1.17.2.5.4** **(10-11-2024)**

#### Integrated Composition Program

1. M&P Publishing develops and maintains a centralized composition system to store, manage, and transform electronic products from a single-source file into output files used for print or viewing electronically. Source files are added to the system via the Composition Process Management (CPM) application. Source files include the following types:



   - Encapsulated PostScript (EPS)

   - Extensible Markup Language (XML)

   - Portable Document Format (PDF)

   - Standard Generalized Markup Language (SGML)


2. Publishing uses XML transformation software to transform the source file(s) into multiple output file types used for print or electronic displays such as Internet Explorer, Adobe Reader, Tablets, or Smart Phones. Output files include the following types:



   - eBook file format (ePub)

   - Extensible Markup Language (XML)

   - Graphic files (various formats)

   - Hypertext Markup Language (HTML)

   - Portable Document Format (PDF)


In addition, Publishing uses a content management service to generate online web forms, which are built from HTML, CSS, and JavaScript.



3. All output files are stored in the CPM application and select file types are also incorporated into the CROPP, where they are accessible via the IRS Intranet.

4. You should send requests for eBook products that need to be produced outside of the Integrated Composition Program to the Publishing Services branch of Publishing using the Publishing Services Request (PSR) application. Publishing will facilitate the creation and distribution of these products.

5. Access to the CPM application is restricted to M&P Publishing employees, who can access it at http://publish.no.irs.gov/publish/pub-elc.html.

6. Access the PSR application at http://caps-as.enterprise.irs.gov/psr/app.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-017-002#addtoany "Show all")

A2A