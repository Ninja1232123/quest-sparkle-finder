---
url: "https://www.irs.gov/irm/part1/irm_01-035-024"
title: "1.35.24 Establishing IRS Commitments and Obligations | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-035-024#main-content)

- 1.35.24  [Establishing IRS Commitments and Obligations](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388926539136)
  - 1.35.24.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388897904208)
    - 1.35.24.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388897896368)
    - 1.35.24.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388897393408)
    - 1.35.24.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388897382784)
      - 1.35.24.1.3.1  [CFO and Deputy CFO](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388897376384)
      - 1.35.24.1.3.2  [Associate CFO for Corporate Budget](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388897697328)
      - 1.35.24.1.3.3  [Senior Associate CFO for Financial Management and Associate CFO for Corporate Accounting](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388897693776)
      - 1.35.24.1.3.4  [Government Payables and Funds Management](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388897690544)
      - 1.35.24.1.3.5  [Financial Reporting and Analysis](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388897686640)
      - 1.35.24.1.3.6  [Financial Management Systems](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388897683104)
      - 1.35.24.1.3.7  [Office of the Chief Procurement Officer](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388897680016)
      - 1.35.24.1.3.8  [Division Finance Officers](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388897676320)
      - 1.35.24.1.3.9  [Financial Plan Managers](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388897363808)
      - 1.35.24.1.3.10  [Business Unit Managers](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388897360256)
    - 1.35.24.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388897357104)
    - 1.35.24.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388897352544)
    - 1.35.24.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388897344752)
    - 1.35.24.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388897885552)
    - 1.35.24.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388897858336)
  - 1.35.24.2  [Congressional Authority](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388897851872)
  - 1.35.24.3  [IRS Budget Authority](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388897848800)
  - 1.35.24.4  [Business Unit Financial Plans](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388897842496)
  - 1.35.24.5  [Commitment Process Overview](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388897838688)
    - 1.35.24.5.1  [Recording Commitments](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388897836928)
  - 1.35.24.6  [Obligation Process Overview](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388897834176)
    - 1.35.24.6.1  [G-Invoicing](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388897832960)
    - 1.35.24.6.2  [Creating the Obligation](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388898426528)
    - 1.35.24.6.3  [Requirements for Recording Contract Obligations](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388898424128)
      - 1.35.24.6.3.1  [Authorized Officials](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388898419664)
      - 1.35.24.6.3.2  [Unauthorized Commitment and Ratification](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388898413680)
      - 1.35.24.6.3.3  [Antideficiency Act](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388898410496)
      - 1.35.24.6.3.4  [Prior Year Obligation Adjustments](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388898404272)
  - 1.35.24.7  [Recording the Obligation - Process Description](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388898396352)
    - 1.35.24.7.1  [Systematic Obligation Real-Time Posting and Interfaces](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388898391776)
      - 1.35.24.7.1.1  [Processing Procurement Obligations in PPS](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388898388032)
      - 1.35.24.7.1.2  [Processing Travel and Relocation Obligations](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388898377392)
      - 1.35.24.7.1.3  [Processing Other Obligations](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388898375072)
    - 1.35.24.7.2  [Manual Obligations](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388898371216)
  - 1.35.24.8  [Open Obligation Management](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388898327440)
  - 1.35.24.9  [Financial Reporting](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388898324208)
  - 1.35.24.10  [Aging Unliquidated Commitments and Aging Unliquidated Obligations](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388898321376)
  - 1.35.24.11  [Adjustment Shopping Cart (Unfunded) Process for New Fiscal Years](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388898318720)
  - 1.35.24.12  [Auditing and Supporting Documentation](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388898311872)
  - 1.35.24.13  [Incremental Funding for IRS Liabilities](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388898305904)
  - 1.35.24.14  [Incremental Funding During Continuing Resolution Authority](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388898301264)
  - 1.35.24.15  [Incremental Funding](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388898294768)
  - 1.35.24.16  [IRS Lapse in Appropriations Contingency Planning](https://www.irs.gov/irm/part1/irm_01-035-024#idm140388898291696)

# Part 1. Organization, Finance, and Management

# Chapter 35. Financial Accounting

# Section 24. Establishing IRS Commitments and Obligations

* * *

## 1.35.24 Establishing IRS Commitments and Obligations

#### Manual Transmittal

April 07, 2025

#### Purpose

(1) This transmits revised IRM 1.35.24, Financial Accounting, Establishing IRS Commitments and Obligations.

#### Material Changes

(1) IRM 1.35.24.1.2, Authorities, updated authorities to cite current publications.

(2) IRM 1.35.24.1.3, Responsibilities, updated titles due to leadership reorganization.

(3) IRM 1.35.24.1.5, Program Controls, reworded for clarification.

(4) IRM 1.35.24.1.6, Terms/Definitions, added Government-Invoicing (G-Invoicing) definition.

(5) IRM 1.35.24.1.7, Acronyms, removed Corporate Budget (CB), Chief Financial Officer (CFO), and Government Wide Acquisition Contract (GWAC).

(6) IRM 1.35.24.1.8, Related Resources, title change to Financial Operating Guidelines.

(7) IRM 1.35.24.6.1, G-Invoicing, added G-Invoicing information.

(8) IRM 1.35.24.6.3.2, Unauthorized Commitment and Ratification, removed Internal Revenue Service Acquisition Procedure (IRSAP) as a source of information.

(9) IRM 1.35.24.7.2, Manual Obligations, added additional forms used. Changed “appropriate Deputy Commissioner” to “Senior ACFO for Financial Management.”

(10) IRM 1.35.24.11, Adjustment Shopping Cart (Unfunded) Process for New Fiscal Years, reworded for clarification.

(11) IRM 1.35.24.14, Incremental Funding During Continuing Resolution Authority, reworded for clarification.

(12) IRM 1.35.24.15, Incremental Funding, added “Senior” to “Associate CFO for Financial Management.”

(13) Editorial changes made throughout the IRM.

#### Effect on Other Documents

IRM 1.35.24, dated January 31, 2023, is superseded.

#### Audience

All business units

#### Effective Date

(04-07-2025)

Teresa R. Hunter

Chief Financial Officer

**1.35.24.1** **(01-31-2023)**

### Program Scope and Objectives

1. Purpose: To provide IRS policy and guidance regarding the establishment of commitments and obligations recorded in the Integrated Financial System (IFS) by:



1. Describing the process of creating and recording an obligation or commitment.

2. Describing the process of adjustments to prior year obligations.

3. Describing financial reporting requirements.

4. Explaining the responsibility of monitoring unliquidated obligations and commitments.


2. Audience: These procedures apply to IRS employees responsible for establishing, recording and monitoring commitments and obligations including but not limited to:



   - Business unit managers

   - Contracting officers

   - Financial management analysts

   - Financial budget analysts

   - Accounting technicians


3. Policy Owner: Government Payables and Funds Management is under the CFO.

4. Program Owner: Government Payables and Funds Management is the program office responsible for establishing IRS commitments of obligations recorded in IFS and to ensure these entries are accurate and timely.

5. Primary Stakeholders: CFO and Office of the Chief Procurement Officer.

6. Program Goals: To ensure that all commitments and obligations are recorded in the IRS IFS system accurately and timely.


**1.35.24.1.1** **(12-09-2019)**

#### Background

1. The IRS receives appropriated funds pursuant to law providing budget authority to execute financial obligations that will result in immediate or future payments for goods and services. This process is also referred to as the purchasing chain.

2. The four stages in the purchasing chain are: a) creating a commitment, b) establishing an obligation, c) validating an expenditure and e) processing a disbursement.

3. This IRM addresses the first two stages of the process. All commitments and obligations must be created and validated by an authorized official, correctly formatted and fully funded.

4. Transactions must be recorded timely and accurately to ensure the IRS is compliant with U.S. fiscal law, including the Antideficiency Act (ADA).


**1.35.24.1.2** **(04-07-2025)**

#### Authorities

1. The authorities for this IRM include:



01. [USC, Title 31, Money and Finance](https://uscode.house.gov/browse/prelim@title31&edition=prelim)

02. [Chief Financial Officers Act of 1990, Pub. L. 101-576](https://www.congress.gov/bill/101st-congress/house-bill/5687)

03. [Federal Managers Financial Integrity Act of 1982, Pub. L. 97-255](https://www.congress.gov/bill/97th-congress/house-bill/1526)

04. [Federal Financial Management Improvement Act of 1996, Pub. L. 104-208](https://www.congress.gov/bill/104th-congress/house-bill/4319)

05. 48 CFR 1, Federal Acquisitions Regulation

06. [FAR 52.232-19, Availability of Funds for the Next Fiscal Year](https://www.acquisition.gov/far/52.232-19?searchTerms=fiscal%20year%20end)

07. [Government Auditing Standards 2018 Revision, GAO-18-568G](https://www.gao.gov/legal/appropriations-law/red-book#:~:text=The%20Red%20Book-,Overview,%2C%20their%20application%2C%20and%20exceptions.)

08. [Statement of Federal Financial Accounting Concepts (SFFAC) No. 1, Objectives of Federal Financial Reporting](https://fasab.gov/accounting-standards/document-by-chapter/)

09. [Statement of Federal Financial Accounting Standards (SFFAS) No. 4, Managerial Cost Accounting Standards and Concepts](https://fasab.gov/accounting-standards/document-by-chapter/)

10. [Statement of Federal Financial Accounting Standards (SFFAS) No. 5, Accounting for Liabilities of the Federal Government](https://fasab.gov/accounting-standards/document-by-chapter/)


**1.35.24.1.3** **(04-07-2025)**

#### Responsibilities

1. This section provides responsibilities for:



01. CFO and Deputy CFO

02. Associate CFO for Corporate Budget

03. Senior Associate CFO for Financial Management and Associate CFO for Corporate Accounting

04. Government Payables and Funds Management

05. Financial Reporting and Analysis Office

06. Financial Management Systems Office

07. Office of the Chief Procurement Officer

08. Division finance officers

09. Business unit managers

10. Financial plan managers


**1.35.24.1.3.1** **(12-09-2019)**

##### CFO and Deputy CFO

1. The CFO and Deputy CFO are responsible for establishing policy and overseeing:



1. IRS financial management responsibilities on behalf of the Commissioner.

2. Efficient execution of federal appropriated funding.


**1.35.24.1.3.2** **(12-09-2019)**

##### Associate CFO for Corporate Budget

1. The Associate CFO for Corporate Budget is responsible for:



1. Managing and distributing the IRS’s budget authority to the appropriate business unit or central program manager.

2. Complying with federal apportionments and allocated funding limitations.

3. Procedures, standards and controls for commitments and obligations.


**1.35.24.1.3.3** **(04-07-2025)**

##### Senior Associate CFO for Financial Management and Associate CFO for Corporate Accounting

1. The Senior Associate CFO for Financial Management and the Associate CFO for Corporate Accounting are responsible for overseeing:



1. Accounting and reporting of administrative financial processes.

2. The IRS’s compliance with financial audit and internal control requirements.


**1.35.24.1.3.4** **(12-09-2019)**

##### Government Payables and Funds Management

1. Government Payables and Funds Management is responsible for:



1. Overseeing the processes of systemic and manual obligations.

2. Providing customer support to business unit finance staff for commitments and obligations.

3. Providing compliance results to business unit managers and CFO leadership.

4. Validating aged commitments and obligations from IRS financial systems.


**1.35.24.1.3.5** **(12-09-2019)**

##### Financial Reporting and Analysis

1. Financial Reporting and Analysis is responsible for:



1. Managing IRS accounting processes to meet regulatory and statutory compliance.

2. Reviewing and recording entries for commitments, obligations, accounts payable, accounts receivable, contingent liabilities, accruals, account adjustments or reclassifications.

3. Preparing financial statements for periodic and annual reporting.


**1.35.24.1.3.6** **(12-09-2019)**

##### Financial Management Systems

1. Financial Management Systems is responsible for:



1. Maintaining the IRS’s IFS system.

2. Overseeing the scheduling, monitoring and staff support of all IFS module interfaces with external systems.


**1.35.24.1.3.7** **(12-09-2019)**

##### Office of the Chief Procurement Officer

1. Office of the Chief Procurement Officer is responsible for:



1. Processing contractual obligations for business unit requisitions that comply with federal statutes and regulations and IRS policy.

2. Administering reviews and monitoring and tracking open awards, including contract closeout or termination.

3. Providing guidance and training for policies and procedures relating to Procurement's role in the commitment and obligation process.


**1.35.24.1.3.8** **(12-09-2019)**

##### Division Finance Officers

1. The Division Finance Officers (DFO) are responsible for:



1. Managing business unit budgets to comply with prudent and lawful IRS financial management practices.

2. Managing commitments and obligations to ensure that available balances are adequate for the goods or services to be received.

3. Establishing and maintaining supporting documentation of business unit commitments and obligations.

4. Establishing internal controls to ensure requisitions are approved by an appropriate manager, have adequate funding and comply with current fiscal laws and regulations.


**1.35.24.1.3.9** **(12-09-2019)**

##### Financial Plan Managers

1. Financial plan managers are responsible for:



1. Certifying that funds are available and used for proper purposes.

2. Ensuring that overspending does not occur within the financial plan(s) under their control.

3. Reviewing commitments and obligations to ensure they are recorded and liquidated accurately and timely.


**1.35.24.1.3.10** **(12-09-2019)**

##### Business Unit Managers

1. Business unit managers are responsible for:



1. Administering IRS policies that support the proper use of funds for purchases used to complete their mission and mitigate fraud, waste and abuse.

2. Reviewing and certifying requisitions to ensure they are fully funded, validated by approving officials and entered into Procurement for Public Sector (PPS).


**1.35.24.1.4** **(12-09-2019)**

#### Program Management and Review

1. Government purchases must meet all requirements of law, executive orders, regulations and all other applicable IRS procedures. Corporate Accounting, Corporate Budget and Procurement use several reports and other control measures to manage commitments and obligations. Aging Unliquidated Commitments (AUC) and Aging Unliquidated Obligations (AUO) reviews are conducted based on a schedule provided by Government Payables and Funds Management to Procurement and the business units the first quarter of each fiscal year to ensure business units are managing obligations timely and accurately. The IRS’s annual goal is to obligate 92% of all expiring, non-labor funds by August 31 and 99.9% of all expiring funds by September 30.

2. Program effectiveness: Program reports are used monthly to evaluate the effectiveness to ensure the 99.9% obligation rate is achieved every fiscal year.



1. The Government Accountability Office (GAO) conducts reviews to verify the accuracy and timeliness of obligations throughout the year.


**1.35.24.1.5** **(04-07-2025)**

#### Program Controls

1. This section provides information on the controls and control methods:



1. The IRS established an administrative system of funds control designed to ensure accuracy of obligations or expenditures.

2. Separation of duties are established for obligations, vendor code coordinators and accounts payable based on IFS role restrictions.

3. Access control: A user account for any system contains a unique ID and password. Group memberships and rights and permissions for accessing an information system and its resources are determined by authorized security coordinators and managers from business units.

4. Obligation threshold: IFS performs edit checks to ensure an obligation will not be posted if the obligation exceeds the IFS commitments/allotments entered into IFS. If a re-obligation is being done for the current year, and the commitment has not been de-committed, the obligation can be re-established, by pulling in the original commitment. However, if the funds have been de-committed, then a new shopping cart will have to be created for the new obligation. IFS also allows new obligations against unexpired appropriations and it allows modified obligations to expired appropriations if the obligation exceeds the reference commitment by less than 10% or $500.

5. Obligation reports disclose the percentages of manual and procurement lines obligated timely.

6. Obligation Error reports which are based on a random sampling of obligations posted in IFS are used to monitor program accuracy.

7. Approval Process: All PPS requisitions must have at least one approver before the financial plan manager who is the final approver.

8. Auditing: GAO performs regular testing of internal controls during the year and performs annual audits of all programs.

9. Per IRM 1.35.6, Property and Equipment Accounting, the Financial Reporting and Analysis office conducts reviews to ensure compliance with applicable federal financial accounting standards. The CFO is responsible for the servicewide accountability to determine if the items purchased are classified correctly as either expenses or assets; and if posted to the appropriate general ledger account classification per the current Financial Management Codes Handbook.


**1.35.24.1.6** **(04-07-2025)**

#### Terms/Definitions

1. The following terms and definitions apply to this program:



01. **Accounts payable** \- A recorded liability once the IRS acknowledges receipt of goods or services. Accounts payable signifies an amount owed by the IRS for goods or services received, ongoing contract performance received and rents due to other entities.

02. **Apportionment** \- The act by which the Office of Management and Budget (OMB) distributes amounts available for obligation, including budgetary reserves established pursuant to law, in an appropriation or fund account. An apportionment divides amounts available for obligation by specific time periods (usually quarters), activities, projects, objects or a combination thereof. The apportioned amounts limit the amount of obligations that may be incurred. The apportioned amounts may be subdivided by the agency.

03. **Appropriation** \- Authority given to federal agencies to incur obligations and make payments from Treasury for specified purposes. The classification is based on availability for new obligations.

04. **Binding agreement** \- A contractual relationship is evidenced by: (1) an offer, (2) acceptance of the offer, (3) valid legal and valuable consideration and (4) made by an authorized official.

05. **Current or unexpired appropriations** \- An appropriation that is available for incurring new obligations.

06. **Expired appropriation** \- An appropriation that is no longer available to incur new obligations, although it may still be available for the recording or payment (liquidation) of obligations properly incurred before the period of availability expired. Annual and multi-year appropriations remain available for an additional five fiscal years beyond expiration, however, only to adjust and make payments to liquidate liabilities arising from obligations made within the fiscal year for which the funds were appropriated. (See Title 31 USC Section 1553 (a), Availability of appropriation accounts to pay obligations).

07. **Canceled appropriation** \- An appropriation that is closed and no longer available for obligation or expenditure for any purpose.

08. **Commitment** \- The reservation of a portion of a business unit's budgeted funds signifying the future intent to purchase goods or services. The commitment process includes the submission of the requirement (requisition), the validation and approval of the requirement (authorization) and the reservation of funds (commitment).

09. **Disbursement** \- The amount paid by a federal agency, by cash or cash equivalent, during the fiscal year to liquidate government obligations.

10. **Economy Act Order** (Title 31 USC Section 1535, Agency agreements) - The general authority for one agency or unit to obtain goods and services from another agency or unit. Payment may be made in advance or upon the provision of the goods and services ordered.

11. **Expenditure** \- The actual spending of money, in other words, an outlay. Outlay is used interchangeably with the term disbursement. This stage of the purchasing chain includes the actual payment and liquidation of the accounts payable amount.

12. **Financial plan** \- A business unit plan for executing approved budget authority in meeting assigned missions and responsibilities.

13. **G-Invoicing**\- G-Invoicing is a solution to address accounting and reporting challenges around buy and sell transactions by providing a common platform for intergovernmental transactions, or IGT.

14. **Incremental funding** -The provision or recording of budgetary resources for a program or project based on obligations estimated to be incurred within a fiscal year when such budgetary resources are provided for only part of the estimated cost of the acquisition.

15. **Interface** \- The transfer of data between two or more data systems.

16. **Liquidation (or liquidated)** \- The payment(s) to vendors for IRS obligations until the obligation is fully received/accepted/paid or eventually closed.

17. **Multiple year appropriations** \- Budget authority available for a fixed period more than one fiscal year. This authority generally takes the form of 2-year, 3-year, etc. Availability may cover periods that don’t coincide with the start or end of a fiscal year.

18. **No-year appropriations** \- An appropriation that is available for obligation for an indefinite period of time. A no-year appropriation is usually identified by appropriation language such as to remain available until expended or without fiscal year limitation.

19. **Obligation** \- As defined by the GAO, a definite commitment that creates a legal liability of the government for the payment of goods and services ordered or received, or a legal duty on the part of the United States that could mature into a legal liability by virtue of actions on the part of the other party beyond the control of the United States. Payment may be made immediately or in the future.

20. **One-year appropriations** \- An appropriation that is available for obligation during a specific fiscal year. Funds not obligated during the fiscal year expire at the end of the year. It is also known as a fiscal year or annual budget authority.

21. **Purchasing chain** \- The four potential accounting stages for IRS purchases: commitment, obligation, accounts payable and expense.

22. **Real-time posting** \- Transactions appear as soon as the item is posted and do not need to be re-processed at night to create the hard post.

23. **Requisition - also referred to as shopping cart** \- A request for goods or services submitted by a business unit.


**1.35.24.1.7** **(04-07-2025)**

#### Acronyms

1. The following acronyms apply to this program:




| **ACRONYM** | **DESCRIPTION** |
| --- | --- |
| ADA | Antideficiency Act |
| ALS | Automated Lien System |
| AUC | Aging Unliquidated Commitments |
| AUO | Aging Unliquidated Obligations |
| CO | Contracting Officer |
| CRA | Continuing Resolution Authority |
| DFO | Division Finance Officer |
| ETS | Electronic Travel System |
| FAR | Federal Acquisition Regulation |
| FR | Federal Reserve IPP Relevant PO |
| GAO | Government Accountability Office |
| GSA | General Services Administration |
| IAA | Interagency Agreement |
| IFS | Integrated Financial System |
| IGT | Intergovernmental Transactions |
| IRSAP | Internal Revenue Service Acquisition Procedure |
| OMB | Office of Management and Budget |
| PC | Purchase Card |
| PM | Procurement Obligation |
| PO | Purchase Order |
| PPS | Procurement for Public Sector |
| PR | Purchase Requisition |
| SF | Standard Form |
| SFFAC | Statement of Federal Financial Accounting Concepts |
| SFFAS | Statement of Federal Financial Accounting Standards |


**1.35.24.1.8** **(04-07-2025)**

#### Related Resources

1. Related resources for this IRM include:



1. [OMB Circular A-123, Management’s Responsibility for Internal Control](https://obamawhitehouse.archives.gov/omb/circulars_a123_rev)

2. [OMB Circular A-134, Financial Accounting Principles and Standards](https://georgewbush-whitehouse.archives.gov/omb/circulars/a134/a134.html)

3. [OMB Circular A-136, Financial Reporting Requirements](https://georgewbush-whitehouse.archives.gov/omb/circulars/a136/a136.html)

4. [IRM 1.35.3, Receipt and Acceptance Guidelines](https://irm.web.irs.gov/Part1/Chapter35/Section3/IRM1.35.3.aspx)

5. [IRM 1.33.4, Financial Operating Guidelines](https://irm.web.irs.gov/Part1/Chapter33/Section4/IRM1.33.4.aspx)


**1.35.24.2** **(12-09-2019)**

### Congressional Authority

1. Congressional authority to enact federal budget authority for federal funds is provided under U.S. Constitution: Article 1, Section 9, clause 7, Taxes and Congressional Spending.

2. The ADA explicitly prohibits federal employees and officers from making contracts or other obligations in advance of, or in excess of an appropriation, unless authorized under law. Additionally, public funds may only be used for the purpose(s) and during the time frame for which Congress appropriated funds.

3. The Department of the Treasury assigns an appropriation warrant for the OMB to apportion. The apportioned funds are then made available for various federal agencies to execute their missions.


**1.35.24.3** **(12-09-2019)**

### IRS Budget Authority

1. The CFO’s Corporate Budget office manages the IRS’s budget authority on behalf of the Commissioner. The IRS receives budget authority from congressional appropriations, negotiated Economy Act orders (with other federal agencies), and user fees for requested services.

2. Corporate Budget establishes business units’ funding levels through the annual plan development process. Financial plan levels are approved by IRS leadership and entered into the IFS as initial funding levels for the business units. Levels are adjusted once an appropriation bill is signed and apportionments are received. Business units budget authority limits must be strictly adhered to during the fiscal year to ensure the IRS remains compliant within OMB apportionments.

3. IFS edit checks are in place that ensure:



1. Apportionments do not exceed appropriated funds.

2. Allotments do not exceed apportionment funds.

3. Sub-allotments do not exceed allotment funds.

4. Commitments do not exceed sub-allotments.

5. Obligations do not exceed commitments.


**1.35.24.4** **(12-09-2019)**

### Business Unit Financial Plans

1. The business unit financial plans are the approved operational strategies that the business unit intends to execute in accomplishing assigned missions and responsibilities. It is critical for financial plan managers to oversee and approve business unit spending throughout the year.

2. Financial plans are representative of a point in time and must be adjusted throughout the year to account for operational requirements or changes. Business units should adhere to the approved budget authority and Economy Act orders.

3. Reimbursable projects are funded according to joint agreements and solely for that particular reimbursable project. Project overruns need to be funded by the participating parties ensuring the IRS’s budget authority is not diverted from direct missions to support other federal agencies. The prompt return of unused budget authority allows other federal agencies to obligate their unused budget towards their agency priorities.


**1.35.24.5** **(12-09-2019)**

### Commitment Process Overview

1. Business units use commitments as an administrative reservation of funds in anticipation of an obligation. Requests are validated and approved in PPS.


**1.35.24.5.1** **(12-09-2019)**

#### Recording Commitments

1. Once a commitment is approved and recorded in IFS, the funding is reserved, and the obligating office must complete the necessary actions to establish and record the obligation. Business unit financial managers should continually review outstanding commitment balances to ensure validity. All commitments must be obligated or de-committed before the end of the fiscal year.


**1.35.24.6** **(12-09-2019)**

### Obligation Process Overview

1. Federal agencies execute assigned missions with appropriated funds through the obligation process. GAO-05-734SP, A Glossary of Terms Used in the Federal Budget Process, states that an obligation is "a definite commitment that creates a legal liability of the government for the payment of goods and services ordered or received, or a legal duty on the part of the United States."


**1.35.24.6.1** **(04-07-2025)**

#### G-Invoicing

1. G-Invoicing



   - Creates and stores interagency agreements.

   - Creates orders.

   - Tracks performance against orders.

   - Transfers funds.


2. G-Invoicing is a means to improve the quality of IGT buy/sell data supporting more accurate financial management by federal trading partners.The G-Invoicing obligation process begins with the creation of a Purchase Order (PO) which is created from the processing of a Purchase Requisition (PR). When creation of the PO is completed, it will be transmitted to the Treasury G-Invoicing Application for Trading Partner approval.

3. The G-Invoicing obligation process is initiated by the systemic generation of an automated email to both the Purchase Requisition (PR) Creator and the Electronic Obligations mailbox indicating that PR has been fully approved and is ready to be processed.

4. When this email is received it is because 1) the initial PO needs created, or 2) a change was approved on the PR that now needs to be reflected on the PO.

5. Another element in the email (manual) sent by the PR Creator to the Electronic Obligations mailbox is the identification of the type of Purchase Order. There are two PO types:



   - Buyer Initiated Order - The requesting agency is beginning the G-Invoicing order process. The G-Invoicing order (7600B) does not exist until the buyer initiated purchase order is successfully transmitted.

   - Seller Facilitated Order - The requesting agency responds to the order created by the servicing agency. The G-Invoicing order (7600B) already exists within the G-Invoicing application. The Treasury order number, line number(s), and schedule number(s) are necessary to create the seller facilitated order purchase order in IFS.


**1.35.24.6.2** **(12-09-2019)**

#### Creating the Obligation

1. Business units determine the need to purchase a good or service and validates that the purchase is a legal use of appropriated funds. The business unit also ensures that it has adequate funding to support the obligation.

2. All business units and their financial plan managers must use appropriate internal controls to ensure that purchased goods or services are protected against fraud, waste and abuse.


**1.35.24.6.3** **(12-09-2019)**

#### Requirements for Recording Contract Obligations

1. A contract obligation must be:



   - Authorized by law.

   - A written binding agreement that tenants an offer, acceptance of offer and a valid consideration.

   - For specific goods, real property, work or services.

   - Executed before the expiration of the period of availability.


2. The Federal Acquisition Regulation (FAR) defines a contract as a mutually binding legal relationship obligating the seller to furnish the supplies or services (including construction) and the buyer to pay for them. It includes all types of commitments that obligate the government to an expenditure of appropriated funds and that, except as otherwise authorized, are in writing. (Title 48 Code of Federal Regulations, Section 2.101 (2005), Definitions).


**1.35.24.6.3.1** **(12-09-2019)**

##### Authorized Officials

1. The FAR, subpart 1.6 - Career Development, Contracting Authority and Responsibilities, states:



1. "Unless specifically prohibited by another provision of law, authority and responsibility to contract for authorized supplies and services are vested in the agency head. The agency head may establish contracting activities and delegate broad authority to manage the agency’s contracting functions to heads of such contracting activities. Contracts may be entered into and signed on behalf of the government only by contracting officers (CO). In some agencies, a relatively small number of high-level officials are designated CO’s solely by virtue of their positions. CO below the level of a head of a contracting activity shall be selected and appointed under FAR 1.603 - Selection, appointment and termination of appointment for contracting officers."

2. "Agency heads may mutually agree to assign contracting functions and responsibilities from one agency to another and create joint or combined offices to exercise acquisition functions and responsibilities."

3. "Agency heads are encouraged to delegate micro-purchase authority to individuals who are employees of an executive agency or members of the Armed Forces of the United States who will be using the supplies or services being purchased (FAR 1.603-3(b))."


2. Only authorized individuals have the authority to legally obligate (or commit) the IRS. Examples of these authorized individuals include: Procurement officials awarding contracts within their warranted limitations, authorized business unit government purchase card (PC) holders completing authorized unit purchases, authorized supervisors and managers approving official travel and authorized supervisors and managers approving employee timesheets. Other examples of delegated obligation authority exist; all individuals must be assigned the responsibility (in writing) and have inherent knowledge and have received adequate training to execute the delegated responsibilities.


**1.35.24.6.3.2** **(04-07-2025)**

##### Unauthorized Commitment and Ratification

1. The FAR, Section 1602-3 - Ratification of unauthorized commitments states:



1. "Unauthorized commitment" means an agreement that is not binding solely because the government representative who made it lacked the authority to enter into that agreement on behalf of the government. Unauthorized commitments cannot be processed.

2. "Ratification" means the act of approving an unauthorized commitment by an official who has the authority to do so.


**1.35.24.6.3.3** **(12-09-2019)**

##### Antideficiency Act

1. The ADA was enacted to restrict agencies from over-obligating, or over-spending appropriations.

2. The ADA states an officer or employee of the United States government or of the District of Columbia government may not:



   - Make or authorize an expenditure or obligation exceeding an amount available in an appropriation or fund for the expenditure or obligation. (Title 31 USC Section 1341 (a)(1)(A), Limitations on expending and obligating amounts).

   - Involve either government in a contract or obligation for the payment of money before an appropriation is made unless authorized by law. (Title 31 USC Section 1341 (a)(1)(B), Limitations on expending and obligating amounts).

   - Make or authorize an expenditure or obligation of funds required to be sequestered under section 252 of the Balanced Budget and Emergency Deficit Control Act of 1985. (Title 31 USC Section 1341 (a)(1)(C), Limitations on expending and obligating amounts).

   - Involve either government in a contract or obligation for the payment of money required to be sequestered under section 252 of the Balanced Budget and Emergency Deficit Control Act of 1985 (Title 31 USC Section 1341 (a)(1)(D), Limitations one expending and obligating amounts).

   - Accept voluntary services for either government or employ personal services exceeding that authorized by law except for emergencies involving the safety of human life or the protection of property. (Title 31 USC Section 1342, Limitation on voluntary services).

   - Make or authorize an expenditure or obligation exceeding an apportionment or the amount permitted by regulations prescribed under section 1514(a) of this title. (Title 31 USC Section 1517(a), Prohibited obligations and expenditures).


**1.35.24.6.3.4** **(12-09-2019)**

##### Prior Year Obligation Adjustments

1. The IRS makes prior year obligation adjustments to:



   - Adjust previously recorded obligations without a change in scope to the nature of the original obligation performance.

   - Record a valid prior year obligation that was erroneously de-obligated through administrative (or system) error.

   - To record a valid prior year obligation that was not recorded (by error) and mandated by legal authority or verified audit authority.


2. The adjusting of prior year obligation balances requires a review process ensuring that the adjustment is a proper use of prior year funds. Business units must provide supporting documentation that the requested obligation adjustment is not a change in scope to the original obligation. The documentation should be adequate to be validated by a third-party review. Business units must ensure they forward requested prior year obligation adjustments timely for thorough review of the upward adjustment, including Chief Counsel and Procurement (when required).

3. An expired appropriation is limited to transactions for expenses or to adjust properly recorded obligations made during the period of availability. New obligations may not be incurred. Balances are available only for upward and downward adjustments to existing or unrecorded obligations during the five years after the appropriation expires.

4. Government Payables and Funds Management validates that all prior year obligation adjustments have supporting documentation and approval and a statement supporting that there is no change in scope to the original obligation before posting the prior year adjustment in IFS.

5. Agencies must maintain separate obligated and unobligated balances for the expired account to ensure compliance with the ADA. The CFO Financial Reporting and Analysis office conducts quarterly reviews of prior year account balances to ensure accuracy and record adjustments if necessary.

6. The IRS ensures that a comprehensive review is conducted for prior year adjustments to validate the necessity of available prior year budget authority. These adjustments are valid obligations that were incorrectly recorded before the end of the period of obligation. Insufficient prior year funding must be avoided to prevent an ADA violation.


**1.35.24.7** **(12-09-2019)**

### Recording the Obligation - Process Description

1. The IRS processes and records obligations into IFS in three ways:



   - Using systematic real-time posting in IFS.


   - Interfaces from Electronic Travel System (ETS) and other systems including the Purchase Card (PC) module and Automated Lien System (ALS).


   - Manually entering obligations directly into IFS.


2. Title 31, USC, section 1501 (a), states: An amount shall be recorded as an obligation of the United States government only when supported by documentary evidence of a binding agreement between an agency and another person (including an agency) that is:



   - Authorized by law.

   - Prepared in writing and executed before the end of the period of availability for obligation of the appropriation or fund used for specific goods to be delivered, real property to be bought or leased, or work or service to be provided.


**1.35.24.7.1** **(12-09-2019)**

#### Systematic Obligation Real-Time Posting and Interfaces

1. The primary process of establishing IFS obligations is through systematic real-time postings. PPS is real-time posting; ETS, PC and ALC modules interface with IFS.

2. Systematic obligation real-time posting or interfaces are described in the following sections:



   - Processing procurement obligations in PPS

   - Processing travel and relocation obligations

   - Processing other obligations


**1.35.24.7.1.1** **(12-09-2019)**

##### Processing Procurement Obligations in PPS

1. There are two types of obligations that can be awarded:



   - Procurement awards with obligation types Procurement obligations (PM) or Federal Reserve IPP Relevant PO (FR).

   - Interagency award: There are two types of Interagency awards: (1) Interagency Acquisitions and (2) Interagency Agreements (IAA).


2. Procurement contracts are legal documents between buyers and sellers in a transaction. During the awarding of the contract if the IPP Relevant indicator is checked within PPS, the obligation will be established with the document type FR. If the IPP Relevant indicator is not checked, the obligation is established with the document type PM.

3. IAAs are written agreements between two or more agencies. The agreement includes terms and conditions that govern the products or services that a servicing agency will provide a requesting agency. An IAA can be used for interagency acquisitions that are commonly conducted through indefinite-delivery contracts, such as task- and delivery-order contracts. There are two types of interagency acquisitions: acquisition assistance IAAs and non-acquisition assistance IAAs.



   - Acquisition assistance IAAs involve products or services provided by contractors as a principal purpose of the IAA. This includes assisted acquisitions and direct acquisitions.

   - Direct acquisitions: In a direct acquisition (an acquisition under the Economy Act (31 U.S.C. 1535)), the requesting agency places an order against the servicing agency’s contract. The servicing agency manages the contract but does not participate in the placement of an order. The requesting agency awards and administers the order therefore, no written agreement with the servicing agency is required. An example of a direct acquisition occurs when the CO places an order against a Federal Supply Schedule, a Government Wide Acquisition Contract, or a Multiple Agency Contract.

   - Assisted acquisitions: An assisted acquisition is a non-Economy Act acquisition completed under other statutory authorities, (i.e. General Services Administration Federal Supply Schedules in subpart 8.4 and government wide acquisition contracts). In an assisted acquisition, the servicing agency and requesting agency enter an IAA where the servicing agency performs acquisition activities on the requesting agency’s behalf. The servicing agency is responsible for awarding and administering a contract, task order, or delivery order. In some cases, more than one servicing agency may be involved in an assisted acquisition.

   - Non-assistance IAAs involve the provision of products or services by the servicing agency where the products or services are provided to the employees of the servicing agency or where contractor support is incidental to the provision of the products or services.



     ### Note:



     These agreements are not processed by Procurement.


4. Awards are recorded in real-time into IFS. The system provides the functionality for creating, routing, approving, tracking, and funding awards in PPS and the receipt and acceptance process.

5. For forms used by Procurement, see FAR part 53 – Forms.


**1.35.24.7.1.2** **(12-09-2019)**

##### Processing Travel and Relocation Obligations

1. Travel authorizations are created and approved within ETS 2 (ETS2 - ConcurGov). Obligations are system generated in IFS.

2. Relocation authorizations require the business unit to forward an approved authorization form to Travel Operations, who updates the data into moveLINQ.


**1.35.24.7.1.3** **(12-09-2019)**

##### Processing Other Obligations

1. There are other systematic obligations where the payment is disbursed upon reconciliation, approval or confirmation of the invoice.

2. PC transactions are not obligated at the time of order. Transactions that are both reconciled and approved create an obligation in IFS per the Purchase Order Creation program. Enterprise Central Component extracts a file of transactions from Citibank’s server to be downloaded into the PC module daily. At the end of the 10th business day after the download date (and each day thereafter) transactions that are reconciled or approved (but not both) create an obligation in IFS per the Purchase Order Creation program.

3. Lien expenses are pulled directly from the accounting string and disbursed without a commitment or obligation. Once confirmation occurs in ALS that the lien request has been mailed, the related payment request for the lien fee is automatically uploaded within five business days.


**1.35.24.7.2** **(04-07-2025)**

#### Manual Obligations

1. Manual obligations do not require action by procurement. They are processed and posted into IFS by technicians in the Obligations Unit of Government Payables and Funds Management upon receipt of the proper obligating documentation from the business unit.

2. Business units must resolve funding issues before the start of service or ordering of goods and submission of documentation to Government Payables and Funds Management.

3. The following is a list of IRS manual obligation programs/processes:




| **Program / Process** | **Obligating Document** | **Obligation Method** | **Business Unit is responsible for:** | **IFS Recording Requirement** |
| :-: | :-: | :-: | :-- | :-- |
| Inter-governmental Personnel Act Agreement, Child Care Subsidy, Federal Government Flexible Spending Account (FSAFEDS) Administrations Fees | Form 2785 | Manual | Forwarding an approved Form 2785 to Government Payables and Funds Management within 10 business days after approval of the invoice. | Obligations must be recorded within 15 business days of the approval of the invoice. |
| Fuel and Maintenance Credit Cards | Reconciliation Worksheet | Manual | Forwarding the Reconciliation Worksheet by the 27th of the month for which the statement cycle ends. | Obligations must be recorded by the first week of the following month for which the statement cycle ends. |
| GSA Rent | Form 2785 | Manual | Forwarding the approved Form 2785 monthly to Government Payables and Funds Management a minimum of five business days before the start of service. | Obligation must be recorded monthly upon creation/approval of Form 2785 and prior to the start of service. |
| Training, Reimbursable Work Authorization, Security Work Authorization | SF 182, Form 2957, Form FPS 57 | Manual | Forwarding the approved form to Government Payables and Funds Management within 10 business days after approval and five business days prior to the start of service or goods received. | Obligations must be recorded within 15 business days of creation/approval of appropriate form and prior to the start of service. |
| Printing (Government and non-government), Witness Fees | Form 2785 | Manual | Forwarding an approved Form 2785 to Government Payables and Funds Management within 10 business days after the start of a new fiscal year. | Obligations must be recorded within 15 business days of the creation/approval of 2785 and prior to the start of service. |
| Internal Revenue Bill of Lading, Commercial Bill of Lading | Form 2785 or Form 12741 with Form 1334 | Manual | Forwarding an approved Form 2785 to Government Payables and Funds Management within 10 business days after the start of the new fiscal year. | Obligations must be recorded within 15 business days of the start of the new fiscal year and after creation/approval of obligating document(s). Funding is added throughout the year as needed. |
| Administrative Summons, Telephones, Consolidated American Payroll Processing System, Foreign Service Accounts, Motorpool, Unemployment Compensations for Federal Employees, Travel Service Virtual Office, Attorney Bar Associations Dues, Miscellaneous Employee Reimbursement. | Form 2785 or Form 1334 | Manual | Forwarding an approved Form 2785 to Government Payables and Funds Management within 10 business days after the start of a new fiscal year. | Obligations must be recorded within 15 business days of the start of the new fiscal year and after creation/approval of the obligating document(s). Funding is added throughout the year as needed. |
| Taxpayer Claims, National Treasury Employees Union Attorney Fees, Settlements, Attorney Fees, Personal Property Claims | Form 2785 Form 1334 | Manual | Forwarding the approved form to Government Payables and Funds Management within 10 business days after issuance of the Authorization Memorandum. | Obligations must be recorded within 15 business days of the issuance of the Authorization Memorandum. |
| Relocation, Basic Plus | Amendment Authorization for Basic Plus Moving Expenses | ETS Interface | Amendment Authorization and an approved Relocation Request Form to Government Payables and Funds Management no later than 10 business days after approval of the Relocation Request Form by the Senior ACFO for Financial Management. | Obligations must be recorded within 15 business days of approval of the Relocation Request Form by the Senior ACFO for Financial Management. |
| Travel and Related Centrally Billed Account (CBA) Activity, if applicable | ETS Trip Authorization | ETS Interface | Submit and approve required official travel in ETS before the beginning of the travel period. | Obligations must be recorded before the beginning of the travel period. |
| Purchase Card/Convenience Checks (PC Module) | Reconciled and/or Approved Transaction | PPS Interface | Ensuring cardholders and approvers reconcile and approve all transactions within 10 business days of the PC Module file creation. | Appropriate transaction should be recorded within 15 business days of the PC Module creation date. |


**1.35.24.8** **(12-09-2019)**

### Open Obligation Management

1. Open obligations pertain to those for which goods and services that have not been completely received, if the contract is not officially closed. The funds for the obligation remain available to liquidate or adjust the obligation through the fifth year of "expired" appropriation status until the identified appropriation is cancelled.

2. All business units must continually monitor the status of open obligations, ensuring goods and services are received and accepted in a timely manner and that associated invoices are paid. Business unit managers must work with Procurement and Government Payables and Funds Management to close obligations.

3. The AUC/AUO discussed in section IRM 1.35.24.10, Aging Unliquidated Commitments and Aging Unliquidated Obligations, is also used to effectively manage open obligations.


**1.35.24.9** **(12-09-2019)**

### Financial Reporting

1. The IRS records commitment and obligation transactions into IFS. Budgetary accounts are used to monitor budget approval and execution. Proprietary accounts are used to monitor assets, liabilities, revenues and expenses.

2. The IRS’s financial reports provide the Treasury, OMB and Congress with the status (obligations and expenditures) of appropriated funds. They are referenced to support decisions in managing assigned programs and controls the cost of operations. Treasury publishes guidance in the Treasury Financial Manual for agencies to follow for the use of funds and the preparation of financial reports on their accounts.


**1.35.24.10** **(12-09-2019)**

### Aging Unliquidated Commitments and Aging Unliquidated Obligations

1. The review of AUCs and AUOs provides an effective management tool for validating aging commitments and obligations for potential recoupment of budgetary resources. Government Payables and Funds Management prepares reports periodically to review open commitments and obligations considered as "aging" and outlined in the AUC/AUO review schedule.

2. Business unit managers are responsible for monitoring and updating the status of their open commitments and obligations. Business units must certify the validity of open commitments and obligations that include substantive supporting documentation.


**1.35.24.11** **(04-07-2025)**

### Adjustment Shopping Cart (Unfunded) Process for New Fiscal Years

1. The CO shall insert language into contracts renewing on October 1 to prevent disruption in critical services, such as: Funds are not presently available for performance under this contract beyond \_\_\_\_\_. The government’s obligation for performance of this contract beyond that date is contingent upon the availability of appropriated funds from which payment for contract purposed can be made. No legal liability on the part of the government for any payment may arise for performance under this contract beyond \_\_\_\_, until funds are made available to the contracting officer for performance and until the contractor receives notice of availability, to be confirmed in writing by the contracting officer. per FAR 52.232-19.



1. Obligations should be funded immediately once appropriations are received and apportionments are approved to allow the contractor to continue services and allow the IRS to expense incurred liabilities.

2. There are additional circumstances that might cause or result in a slight delay in funding the obligation (i.e. system outages, funding approval process).

3. There are other instances when business units will start the pre-award contracting process with Procurement using the unfunded adjustment shopping cart. Additional instances include efforts with other agencies, or IRS business units, in developing joint agreements or Economy Act orders. An obligation cannot be established without documentary evidence of a contract award and a fully funded purchase request.

4. If a business unit must start a manual obligation process for an upcoming fiscal year's services that cannot afford a break in service, an unfunded adjustment shopping cart can also be used. Some providers of Economy Act service agreements mandate obligation documentation in advance of the IRS receiving appropriated funds. The same funding clauses utilized by Procurement must be included in the obligating documentation and the business unit must make sure that no dollar values to be obligated are identified in the fields and approved funded shopping cart must be approved by the business unit once an appropriation is received.

5. In instances when the full obligation requirement is unknown at the time of the award, the IRS must minimally fund the estimated IRS’s liability for the obligation.


**1.35.24.12** **(12-09-2019)**

### Auditing and Supporting Documentation

1. The supporting material required for recording obligations and any other posting as part of the IRS’s financial statements, financial systems and financial reports are governed by Generally Accepted Government Auditing Standards.

2. Supporting or source documentation is the evidence that transactions have occurred, for the proper purpose, and for the posted amounts.

3. Transactions cannot be entered into IFS until proper criteria for recording obligations is met.

4. Principles of Federal Appropriations Law is used as a reference to help determine if appropriated funds are legally available. Among other principles of fiscal law, it provides guidance on the following ADA principles:



   - Purpose of the obligation or expenditure must be authorized.

   - Obligation must occur within the time limits applicable to the appropriation.

   - Obligation and expenditures must be within the funding amounts Congress has established.


5. Government Payables and Funds Management is the central internal inspection office for monitoring IRS compliance and this policy and guidance. Government Payables and Funds Management conducts regular inspections of commitment and obligating documents ensuring legal, accurate and timely recording of all transactions.


**1.35.24.13** **(12-09-2019)**

### Incremental Funding for IRS Liabilities

1. The Federal Accounting Standards Advisory Board states that, a liability is a present obligation of the federal government to provide assets or services to another entity at a determinable date, when a specified event occurs, or on demand. A liability arises when one party acts causing a probable and measurable future outflow of resources resulting from the event. Probability refers to actions that can reasonably be expected or are believed to be more likely than not based on available evidence or logic except for pending or threatening litigation and unasserted claims (SFFAS #5, (33)). These reciprocal or exchange transactions usually occur as a part of the authorized goods and services delivered within the performance work statements of awarded contracts. Once a contractor performs an authorized action, the IRS has incurred a liability. The IRS recognizes and funds these liabilities before the period of performance begins, even when using incremental funding.

2. Liabilities directly affect incrementally funded obligations and include:



1. Authorized goods or services: If the contractor was directed to proceed with services as part of an approved and valid obligation agreement, the IRS must fund and expense the appropriate accrued liabilities.

2. Potential termination costs: The IRS must account for any termination cost for contracts that it chooses not to continue for the convenience of the government (if included as part of the obligated contract).


**1.35.24.14** **(04-07-2025)**

### Incremental Funding During Continuing Resolution Authority

1. Obligations should be fully funded once established to ensure the IRS is compliant with the ADA. Business units must request CFO senior leadership approval before using an incremental approach to fund non-CRA affected obligations. If the business unit must incrementally fund an obligation, Procurement will include the following language from IRSAP Procedures, Guidance and Information (PGI) 1032.790 (c), (d), (e), (f), and (g) in the award:



   - (c) If a Continuing Resolution Authority (CRA) has been enacted on or before October 1, a CO shall adhere to the requirements of FAR subpart 32.702 - Policy and shall obtain written assurance from the funds certifying official that adequate funds are available.

   - (d) Written assurance can take the form of a shopping cart, e-mail, or other document from the funds certifying official.

   - (e) The written assurance must be included within the official contract file to show the availability of funds for the acquisition.

   - (f) Insert the following language in Section B or other appropriate section of the acquisition document if the CR does not fully fund the acquisition: "Funds in the amount of $\_\_ are presently available. The government’s obligation under this contract is contingent upon the availability of appropriated funds from which payment for contract purposes can be made. It is anticipated that once an appropriation is enacted and the budget is received, additional funds in the amount of $\_\_ will be added to the contract to fully fund the period of performance for which the funding is provided." Notice to the contractor is needed before liability goes over that amount and the government’s liability is limited to that amount unless the government takes affirmative action to increase it.

   - (g) A CO in receipt of a shopping cart to provide funds for a contract/task order award that includes the subject to availability clauses shall promptly obligate funds to the contract/task order.


2. Incremental funding due to a CRA is an approved strategy that doesn't require CFO leadership approval before implementation.


**1.35.24.15** **(04-07-2025)**

### Incremental Funding

1. When necessary to incrementally fund an affected obligation, the business unit must forward the request through their DFO to the Senior Associate CFO for Financial Management. The Senior Associate CFO for Financial Management will coordinate and approve in conjunction with the Office of the Chief Procurement Officer and the Associate CFO for Corporate Budget.

2. The approved incremental funding strategy must identify the relevant future funding sources for fully funding the obligation. Incrementally-funded obligations must be monitored to ensure that planned funding sources are realized. If funding sources are not realized, the business unit must immediately notify the IRS’s senior leadership for approval.


**1.35.24.16** **(12-09-2019)**

### IRS Lapse in Appropriations Contingency Planning

1. Federal agencies are required to develop annual contingency plans for implementation when there is a lapse in appropriations as defined by the Antideficiency Act, 31 United States Code 1341 and 1342. This Act severely restricts the conduct of business by agencies and prohibits government officials from incurring obligations in excess of appropriations except in those categories of activities as defined by the Attorney General. This opinion identified three categories of activities that may be continued. They are:



   - Category A: Activities which are authorized by law and funded by multi-year, no-year and revolving funds or advance appropriations and thus would not be affected by an annual appropriations lapse.


   - Category B: Activities necessary for the safety of human life or protection of property.


   - Category C: Activities Necessary for Orderly Agency Shutdown.


2. The measures were created along four performances areas that are essential to enabling the workforce to accomplish the IRS Mission. These four areas, referred to as Human Capital Pillars, are listen, lead, develop and support. They represent the Human Capital projects, initiatives, objectives and strategies that are outlined in the five-year Human Capital Business Plan.

3. This contingency plan becomes effective after official notification is received from the Department of the Treasury that a lapse in appropriations is possible or in effect.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-035-024#addtoany "Show all")

A2A