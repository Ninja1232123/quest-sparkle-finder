---
url: "https://www.irs.gov/irm/part1/irm_01-004-002"
title: "1.4.2 Monitoring and Improving Internal Control | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-004-002#main-content)

- 1.4.2  [Monitoring and Improving Internal Control](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933945354128)
  - 1.4.2.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933914340080)
    - 1.4.2.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933914391680)
    - 1.4.2.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933944415056)
    - 1.4.2.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933944755600)
      - 1.4.2.1.3.1  [Commissioner, Deputy Commissioner, Chief Taxpayer Services, Chief Tax Compliance Officer, Chief Information Officer and Chief Operating Officer](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933949250928)
      - 1.4.2.1.3.2  [CFO and Associate CFO for Internal Controls](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933916618224)
      - 1.4.2.1.3.3  [Division Commissioners, Chiefs, National Taxpayer Advocate and Chief Counsel](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933917213904)
      - 1.4.2.1.3.4  [Managers at All Levels](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933945666208)
      - 1.4.2.1.3.5  [Internal Controls Coordinators](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933917341408)
    - 1.4.2.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933944402832)
    - 1.4.2.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933914081488)
    - 1.4.2.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933914078464)
    - 1.4.2.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933945602416)
    - 1.4.2.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933914258144)
  - 1.4.2.2  [Improving Controls](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933914254160)
    - 1.4.2.2.1  [Steps to Downgrade a Material Weakness and Significant Deficiency](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933914252320)
    - 1.4.2.2.2  [Annual Assurance Review Process](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933914011536)
    - 1.4.2.2.3  [Identification of Quality Assurance Reviews and Initiatives](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933914266688)
    - 1.4.2.2.4  [Internal Control Reviews](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933914264112)
    - 1.4.2.2.5  [Outreach and Reporting](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933914261952)
  - 1.4.2.3  [Internal Controls Process](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933914243552)
    - 1.4.2.3.1  [Responsibility of Management in Risk Assessment](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933914136304)
    - 1.4.2.3.2  [The Role of Enterprise Risk Management](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933914134480)
    - 1.4.2.3.3  [Control Environment](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933914132480)
      - 1.4.2.3.3.1  [The Role of the IRS in the Control Environment](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933914129472)
      - 1.4.2.3.3.2  [Responsibility of Management in the Control Environment](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933914126064)
    - 1.4.2.3.4  [Risk Assessment](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933914301136)
  - 1.4.2.4  [Control Activities](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933914298736)
    - 1.4.2.4.1  [Incorporating the Use of Controls](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933914296304)
  - 1.4.2.5  [Information and Communication](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933913931520)
  - 1.4.2.6  [Monitoring Controls](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933914222640)
    - 1.4.2.6.1  [Role of Management in Monitoring](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933914220928)
    - 1.4.2.6.2  [Testing Design and Effectiveness of Internal Controls](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933944230080)
    - 1.4.2.6.3  [Role of the Government Accountability Office and TIGTA](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933944227760)
    - 1.4.2.6.4  [Management Controls Executive Steering Committee (MC ESC)](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933944223728)
  - 1.4.2.7  [Remediation Plan](https://www.irs.gov/irm/part1/irm_01-004-002#idm139933914124720)

# Part 1. Organization, Finance, and Management

# Chapter 4. Resource Guide for Managers

# Section 2. Monitoring and Improving Internal Control

* * *

## 1.4.2 Monitoring and Improving Internal Control

#### Manual Transmittal

May 14, 2025

#### Purpose

(1) This transmits revised IRM 1.4.2, Resource Guide for Managers, Monitoring and Improving Internal Control.

#### Material Changes

(1) IRM 1.4.2.1(2)(f), Program Scope and Objectives, added additional purpose item.

(2) IRM 1.4.2.1.3, Responsibilities, revised to reflect one Deputy Commissioner and addition of Chief Operating Officer due to April 2024 IRS leadership structure change.

(3) IRM 1.4.2.1.3.1, Commissioner, Deputy Commissioner, Chief Taxpayer Services, Chief Tax Compliance Officer, Chief Information Officer and Chief Operating Officer, revised to reflect April 2024 IRS leadership structure change.

(4) IRM 1.4.2.1.3.2, CFO and Associate CFO for Internal Controls, revised the CFO and Associate CFO for Internal Control responsibilities.

(5) IRM 1.4.2.1.3.4(1)(h)(i), Managers at all Levels, revised to reflect current responsibilities.

(6) IRM 1.4.2.1.6(1)(b), Terms/Definitions, updated Control Deficiency to include “simple” and revised definition.

(7) IRM 1.4.2.1.6(1)(e)(f), Terms/Definitions, recategorized Material Weakness in Internal Control Over Reporting into four types: compliance, external financial reporting, operations and reporting.

(8) IRM 1.4.2.1.7, Acronyms, revised listing.

(9) IRM 1.4.2.1.8, Related Resources, revised to reflect applicable IRM references.

(10) IRM 1.4.2.2.1, Steps to Downgrade a Material Weakness and Significant Deficiency, revised to reflect current process.

(11) IRM 1.4.2.2.2, Annual Assurance Review Process, revised to reflect current process.

(12) IRM 1.4.2.2.5(1)(b), Outreach and Reporting, updated to reflect the new Federal Accounting Standards Advisory Board’s Statement of Federal Financial Accounting Standard 64, Management’s Discussion and Analysis.

(13) IRM 1.4.2.3.2, The Role of Enterprise Risk Management, added additional IRM reference.

(14) IRM 1.4.2.4.1(2), Incorporating the Use of Controls, clarified automated controls.

(15) IRM 1.4.2.6.4, Management Controls Executive Steering Committee, revised to reflect its current structure.

(16) Minor editorial changes have been made throughout the IRM.

#### Effect on Other Documents

IRM 1.4.2, dated June 13, 2023, is superseded.

#### Audience

All business units

#### Effective Date

(05-14-2025)

Teresa R. Hunter

Chief Financial Officer

**1.4.2.1** **(05-14-2025)**

### Program Scope and Objectives

1. This IRM provides guidance to all IRS employees for maintaining an effective internal control program that complies with legislative requirements and related regulations and directives, such as the [Standards for Internal Control in the Federal Government,](https://irsgov.sharepoint.com/sites/CFO/Documents/Forms/AllItems.aspx?id=%2Fsites%2FCFO%2FDocuments%2FThe%20GAO%20Green%20Book%20%28508%20compliant%29%2Epdf&parent=%2Fsites%2FCFO%2FDocuments) commonly known as the "Green Book."

2. Objectives: Internal controls are the programs, policies and procedures established to ensure that:



1. The IRS accomplishes its mission and program objectives efficiently and effectively.

2. Programs and resources are protected from waste, fraud, abuse, mismanagement and misappropriation of funds.

3. Laws and regulations are followed.

4. Financial reporting is reliable.

5. Reliable information is obtained and used for decision making.

6. Assets and data are secured.


3. Audience: Internal controls are everyone’s responsibility. This guidance applies to managers at all levels. Managers are expected to understand the risks associated with their operations and ensure that controls are in place and operating effectively to mitigate known risks. Managers provide candid, reliable and supportable reports on the status of those controls annually.

4. Policy Owner: The CFO, Office of Internal Controls (IC), is responsible for this IRM.

5. Program Owner: Associate CFO for IC.

6. Primary Stakeholders: IRS managers.

7. Program Goals: To accomplish the objectives identified in the Purpose section above.


**1.4.2.1.1** **(06-13-2023)**

#### Background

1. Internal controls are a major part of effectively managing an organization. They consist of the plans, methods and procedures used to meet missions, goals and objectives. Internal controls support performance-based management. Effective systems of internal control provide unmodified assurance that ensures the IRS achieves the following objectives:



1. Effectiveness and efficiency of operations.

2. Reliability of financial reporting.

3. Compliance with applicable laws and regulations.


2. All employees must be committed to implementing effective and efficient internal controls. The Department of the Treasury (Treasury), TIGTA and the Government Accountability Office (GAO) provide oversight to evaluate whether control strategies that mitigate program and administrative operational risks are implemented.

3. Internal controls are the responsibility of every employee. Managers are accountable for and have stewardship of all assigned operations within their organization, including program, administrative and financial, such as:



1. Designing and implementing controls providing unmodified assurance that programs are being accomplished as intended.

2. Conducting assessments to identify risks to programs, compliance with laws and regulations and reporting accuracy on an annual basis or after any significant changes.

3. Implementing remedies to mitigate risk and measuring the results.


4. It is important to identify problem areas and take appropriate corrective actions before external auditors, such as GAO and TIGTA, issue findings or before problems escalate into serious control weaknesses. On the other hand, there must be an appropriate balance of control in programs and operations. For example, an over-controlled process or program may be costly to implement and interfere with program accomplishment. Similarly, an uncontrolled or under-controlled process or program may allow problems to go unnoticed and assets to be wasted or misused.

5. Focus and awareness of internal controls are an integral part of all managers’ and employees’ daily activities. By fostering open, honest communications and promoting problem-solving within an organization, managers create an environment where internal controls are acknowledged as tools to achieve goals.


**1.4.2.1.2** **(06-13-2023)**

#### Authorities

01. The [Budget and Accounting Procedures Act of 1950,](https://budgetcounsel.files.wordpress.com/2017/04/pub-l-81-784-budget-and-accounting-procedures-act-of-1950.pdf) requires the head of each federal department and agency establish and maintain adequate systems of management controls.

02. [Inspector General Act of 1978](https://oig.treasury.gov/Inspectors-General-Act-of-1978), as amended, grants the Office of the Inspector General (OIG) administrative authority.

03. [The Federal Managers’ Financial Integrity Act of 1982](https://obamawhitehouse.archives.gov/sites/default/files/omb/assets/omb/financial/fmfia1982.html)(FMFIA) and [Office of Management and Budget (OMB) Circular A-123, Management’s Responsibility for Enterprise Risk Management and Internal Control,](https://obamawhitehouse.archives.gov/sites/default/files/omb/memoranda/2016/m-16-17.pdf) require federal agencies to improve accountability in federal programs and operations.

04. The [CFO Act of 1990,](https://govinfo.library.unt.edu/npr/library/misc/cfo.html) as amended, requires agencies to provide audited financial statements made available to the public.

05. The [Federal Financial Management Improvement Act of 1996](https://www.congress.gov/bill/104th-congress/house-bill/4319) (FFMIA) and [Appendix D to OMB Circular A-123, Management of Financial Management Systems,](https://www.govinfo.gov/content/pkg/FR-2013-09-27/pdf/2013-23548.pdf) require financial systems reviews.

06. The [Reports Consolidation Act of 2000](https://www.govinfo.gov/content/pkg/PLAW-106publ531/pdf/PLAW-106publ531.pdf), requires the Annual Assurance Statement to include reliable Performance Measures.

07. The [Government Performance and Results Act Modernization Act of 2010 (GPRAMA)](https://www.govinfo.gov/content/pkg/PLAW-111publ352/pdf/PLAW-111publ352.pdf) requires annual performance plans and reports.

08. The [Federal Information Security Modernization Act of 2014](https://www.cbo.gov/sites/default/files/113th-congress-2013-2014/costestimate/s25211.pdf) and [OMB Circular A-130, Managing Information as a Strategic Resource](https://obamawhitehouse.archives.gov/omb/circulars_a130_a130trans4), require annual systems performance and security reviews.

09. The [Standards for Internal Control in the Federal Government](https://www.gao.gov/greenbook) (known as the "Green Book”) provide the overall framework for establishing and maintaining an effective internal control system.

10. [Treasury Directive 40-04,](https://home.treasury.gov/about/general-information/orders-and-directives/td40-04) Treasury Internal Control Program provides guidance on internal control and implementation of internal control statutes, regulations and other requirements.


**1.4.2.1.3** **(05-14-2025)**

#### Responsibilities

1. This section provides responsibilities for:



1. Commissioner, Deputy Commissioner, Chief Taxpayer Services, Chief Tax Compliance Officer, Chief Information Officer and Chief Operating Officer

2. CFO and Associate CFO for Internal Controls

3. Division Commissioners, Chiefs, National Taxpayer Advocate and Chief Counsel

4. Managers at all levels

5. Internal Control Coordinators


**1.4.2.1.3.1** **(05-14-2025)**

##### Commissioner, Deputy Commissioner, Chief Taxpayer Services, Chief Tax Compliance Officer, Chief Information Officer and Chief Operating Officer

1. The Commissioner, Deputy Commissioner, Chief Taxpayer Services (CTS), Chief Tax Compliance Officer (CTCO), Chief Information Officer (CIO) and Chief Operating Officer (COO) are responsible for:



1. Creating a positive governance structure within the IRS to ensure operational efficiency and adherence to all applicable internal control requirements.

2. Establishing priorities in identifying, correcting and reporting internal control material weaknesses, significant deficiencies and accounting noncompliances.

3. Ensuring that adequate funding is requested during the budget process to correct identified deficiencies.

4. Establishing a quality assurance process that allows the Commissioner to provide assurance that the objectives of the FMFIA are being achieved.

5. Ensuring that the performance plans for each Senior Executive Service member or equivalent employee having significant responsibilities for internal control contain appropriate performance requirements and expectations.

6. Ensuring that all other employees are aware of expectations and are subject to appropriate internal controls performance standards.


**1.4.2.1.3.2** **(05-14-2025)**

##### CFO and Associate CFO for Internal Controls

1. The CFO is the IRS’s Internal Control Officer and has operational responsibility for the IRS’s internal control program by:



1. Evaluating all internal control systems periodically and ensuring that audits, internal control reviews, risk assessments and other evaluations are coordinated to complement one another with minimal duplication of effort.

2. Determining annually which programs or administrative functions are subject to a formal review to supplement management judgment as to the adequacy of internal controls and allocating adequate resources to evaluate their systems of internal control.

3. Ensuring that detailed procedures, documentation, training for managers and employees and reporting requirements necessary to review, establish, maintain, test, improve and report on IRS’s financial management systems are appropriately designed and operate effectively.

4. Reporting to the Treasury Deputy CFO (TDCFO) control deficiencies identified in audit reports, internal reviews and other sources that have the potential to rise to the level of a material weakness or significant deficiency.

5. Ensuring timely correction and validation of all identified program, operations and reporting deficiencies whether material or immaterial.

6. Ensuring internal control guidelines issued are implemented and include employee accountability.

7. Maintaining, correcting and/or updating the Joint Audit Management Enterprise System (JAMES) with specific data on IRS FMFIA material weakness, significant deficiencies and Remediation Plans, as well as any financial statement audit recommendations.


2. The Associate CFO for IC is responsible for administering and carrying out the day-to-day activities regarding IRS’s internal control program by:



1. Preparing internal control policies and procedures.

2. Implementing [OMB Circular A-123](https://obamawhitehouse.archives.gov/omb/circulars_a123_rev/) requirements.

3. Providing administrative support to the Management Controls Executive Steering Committee (MC ESC).

4. Developing internal control procedures, training and reporting requirements necessary to establish, review, improve and report on IRS’s systems controls.

5. Managing the annual assurance process and preparing the IRS Assurance Statements.

6. Monitoring the completion of corrective actions addressing material weaknesses and significant deficiencies.

7. Providing advice and assistance to managers and their ICCs, as needed.


**1.4.2.1.3.3** **(07-17-2020)**

##### Division Commissioners, Chiefs, National Taxpayer Advocate and Chief Counsel

1. The Division Commissioners, Chiefs, National Taxpayer Advocate and Chief Counsel are responsible for:



1. Establishing and implementing adequate and effective controls for all operations and activities within their responsible areas.

2. Conducting a self-assessment and reporting annually on the status of internal control to the MC ESC.

3. Assessing the effect of known deficiencies and providing comments to the MC ESC.

4. Providing adequate resources to correct identified material weaknesses and significant deficiencies.

5. Preparing briefing documents for the agenda topics of MC ESC and subgroup meetings.


**1.4.2.1.3.4** **(05-14-2025)**

##### Managers at All Levels

1. Managers at all levels are responsible for:



1. Providing a positive control environment.

2. Identifying potential risk areas.

3. Ensuring that adequate and effective controls are in place.

4. Reporting results of reviews to the next level of management.

5. Ensuring reports are supportable, accurate and complete.

6. Providing adequate resources to correct identified problems.

7. Documenting, implementing and validating corrective actions timely.

8. Considering the potential for fraud when identifying, analyzing and responding to risks.

9. Safeguarding IRS assets to include sensitive data and other information.


**1.4.2.1.3.5** **(06-13-2023)**

##### Internal Controls Coordinators

1. ICCs are responsible for assisting management in developing and maintaining their internal control program and serving as the primary liaison with the IC organization. Each business unit within the IRS is required to have a designated ICC. Their responsibilities include:



1. Managing their organization's annual assurance review process and preparing its assurance certification memorandum.

2. Providing technical assistance to management and review teams in the evaluation of controls.

3. Monitoring the status of corrective actions addressing material weaknesses and significant deficiencies, as well as reporting the status to IC.

4. Participating in the Internal Control Community of Practice (ICCoP) and attending ICCoP meetings.


**1.4.2.1.4** **(06-28-2018)**

#### Program Management and Review

1. Program reports include:



1. MC ESC briefings

2. Annual Assurance Statements

3. Remediation plans

4. IRM 1.4.3, Financial Assurance Control Testing

5. IRM 1.4.31, Quality Assurance Review Program

6. IRM 1.4.32, Internal Control Review Program


2. Program effectiveness is determined by:



1. Mission and program objectives are accomplished efficiently and effectively.

2. Reliable information is obtained and used for decision making.

3. Laws and regulations are followed.

4. Financial reporting is reliable.

5. Program and resources are protected from fraud, waste, abuse, mismanagement and misappropriation of funds.


**1.4.2.1.5** **(06-13-2023)**

#### Program Controls

1. The MC ESC is responsible for:



1. Approving extensions to remediation plans.

2. Providing final internal approval of a material weakness closure or downgrade to a significant deficiency and elimination of a significant deficiency.


**1.4.2.1.6** **(05-14-2025)**

#### Terms/Definitions

1. The following terms and definitions apply to this program:



1. **Annual self-assessment** \- A business unit’s review of the effectiveness of internal controls within their area of responsibility and the involvement of each level of management in certifying the control environment within their area is conducive to identifying risks or deficiencies at all levels.

2. **Control or “simple” deficiency** \- This condition exists when the design, implementation, or operation of a control does not allow management or personnel, in the normal course of performing their assigned functions, to achieve control objectives and address related risks.

3. **Corrective action** \- Action taken to correct identified deficiencies.

4. **Internal controls** \- Processes and procedures implemented by management to help an organization operate efficiently and effectively to achieve its objectives. Internal control is an integral component of an organization’s management that provides unmodified assurance that the internal control objectives are being achieved.

5. **Material weakness** \- This condition exists when the Agency Head determines that the significant deficiency is significant enough to report outside of the Agency as a material weakness. In the context of the Green Book, non-achievement of a relevant principle and related component results in a material weakness. There are four types of material weaknesses:



      > 1) **Material weakness in internal control over compliance** \- This condition exists when management lacks a process that reasonably ensures preventing a violation of law or regulation that has a direct and material effect on financial reporting or significant effect on other reporting or achieving Agency objectives.
      >
      > 2) **Material weakness in internal control over external financial reporting** \- This condition exists when a deficiency, or a combination of deficiencies, in internal control, such that there is a reasonable possibility that a material misstatement of the entity’s financial statements will not be prevented, or detected and corrected, on a timely basis.
      >
      > 3) **Material weakness in internal control over operations** \- This condition might include, but is not limited to, conditions that:
      >
      >       - Impact the operating effectiveness of entity-level controls of needed services.
      >
      >       - Impair fulfillment of essential operations or mission.
      >
      >       - Deprive the public of needed services.
      >
      >       - Significantly weaken established safeguards against fraud, waste, loss, unauthorized use or misappropriation of funds, property, other assets or conflicts of interest.
      >
      >
      >  4) **Material weakness in internal control over reporting** \- This condition exists when a significant deficiency, in which the Agency Head determines significant enough to impact internal or external decision-making and reports outside of the Agency as a material weakness.

6. **Modified assurance** \- Informed judgment by the head of an organization that internal controls may not be adequate to address specific problems identified in the assurance memorandum.

7. **Remediation plan** \- A plan to achieve FFMIA compliance when an agency's annual review determines the financial management systems cannot prepare the required financial statements and reports in accordance with federal accounting standards, provide reliable and timely financial information for managing operations and/or comply with United States Standard General Ledger (USSGL) requirements.

8. **Significant deficiency** \- This condition exists when a deficiency, or a combination of deficiencies, in internal control that is less severe than a material weakness, yet important enough to merit the attention of those charged with governance.

9. **Unmodified assurance**\- Informed judgment by the head of an organization, based upon sufficient information, that the internal controls in place adequately protect the resources, ensure accurate reporting and facilitate mission completion.


**1.4.2.1.7** **(05-14-2025)**

#### Acronyms

1. The following acronyms apply to this program:




| **Acronym** | **Meaning** |
| :-: | :-: |
| CIO | Chief Information Officer |
| COO | Chief Operating Officer |
| CTCO | Chief Tax Compliance Officer |
| CTS | Chief Taxpayer Services |
| ERM | Enterprise Risk Management |
| FFMIA | Federal Financial Management Improvement Act of 1996 |
| GAO | Government Accountability Office |
| IC | Office of Internal Controls |
| ICC | Internal Controls Coordinator |
| ICCoP | Internal Controls Community of Practice |
| ICMA | Internal Controls Managerial Assessment |
| ICR | Internal Control Review |
| JAMES | Joint Audit Management Enterprise System |
| MC ESC | Management Controls Executive Steering Committee |
| MD&A | Management’s Discussion and Analysis |
| OCRO | Office of the Chief Risk Officer |
| OMB | Office of Management and Budget |
| PCA | Planned Corrective Action |
| TDCFO | Treasury Deputy CFO |
| Treasury | Department of the Treasury |
| USSGL | United States Standard General Ledger |


**1.4.2.1.8** **(05-14-2025)**

#### Related Resources

1. The following IRMs are the most significant IRMs that affect the IRS’s internal controls program:



1. IRM 1.4.3, Financial Assurance Control Testing

2. IRM 1.4.31, Quality Assurance Review Program

3. IRM 1.4.32, Internal Control Review Program

4. IRM 1.4.60, Enterprise Risk Management Program


**1.4.2.2** **(06-13-2023)**

### Improving Controls

1. Sound internal controls support the IRS in improving its operations and meeting its compliance objectives. The work begins with each IRS office, and there are a number of Servicewide processes and programs to assess and improve internal controls.


**1.4.2.2.1** **(05-14-2025)**

#### Steps to Downgrade a Material Weakness and Significant Deficiency

1. The steps to downgrade a material weakness and to close a significant deficiency are:



1. Identify/clarify issues that contribute to the material weakness or significant deficiency.

2. Develop appropriate planned corrective actions (PCAs) to address the deficiency.

3. Verify that the PCA will reduce the risk level as expected and informally meet with auditors to discuss the plan of action.

4. Finalize the action plan.

5. Ensure that PCAs are implemented and completed and validate that expected results are achieved.

6. Evaluate the continuous monitoring process to ensure controls are in place and continue to operate effectively to mitigate potential risk(s) and report out to IC for review.

7. Obtain MC ESC approval to downgrade a material weakness or to close a significant deficiency.

8. Report the material weakness or significant deficiency downgrade/closure in the Assurance Statement.

9. While IRS management determines whether a material weakness or significant deficiency has been resolved for Assurance Statement reporting purposes, the financial statement auditors will make an independent assessment of management’s assertion and report that conclusion in their report.


**1.4.2.2.2** **(05-14-2025)**

#### Annual Assurance Review Process

01. The annual assurance review process focuses on the adequacy of internal controls within an organization. Managers assess risks (for example, the probability of a negative, unanticipated occurrence) of operations, determine whether controls adequately mitigate those risks and report whether those controls are effective. If managers identify weaknesses in their internal control procedures, they are required to report them to the responsible officials and business unit leadership so that a corrective action plan can be developed and implemented.

02. Each spring, the CFO issues guidance to the Deputy Commissioner, Division Commissioners, Chiefs, Directors, National Taxpayer Advocate and Chief Counsel on the annual self-assessment of internal controls, known as the Internal Controls Managerial Assessment (ICMA) and on preparing the annual assurance memorandum for their organizations.

03. All business units use the ICMA to conduct an annual self-assessment of their internal controls. Managers review the effectiveness of controls within their own area of responsibility and verify that adequate internal controls are in place and function effectively to accomplish organizational goals and protect IRS resources.

04. Business units must determine if any reported internal control weakness warrants inclusion in their Statement of Assurance memorandum. The MC ESC will determine if the internal control deficiency rises to the level of a significant deficiency or a material weakness. The IRS reports significant deficiencies and material weaknesses to Treasury.

05. Heads of business units review their ICMA results and prepare a Statement of Assurance memorandum indicating the status of their business unit’s internal controls. Heads of business units also consider external auditor reports, internal studies and assessments and other known factors.

06. The Statement of Assurance memorandum is a one or two-page document containing a specific statement regarding the level of assurance of the business unit’s internal controls. There are three types of assurance:



    1. Unmodified assurance is an informed judgment by the head of an organization, based on all available information, that the internal controls in place adequately protect resources and enable mission completion. Unmodified assurance recognizes that the cost of establishing and implementing controls should not exceed the benefits derived from them.

    2. Modified assurance is an informed judgment by the head of an organization, based on all available information, that the internal controls in place may not be adequate to address the problems identified in the Statement of Assurance memorandum. This level of assurance is based on the seriousness of the problems.

    3. Statement of No Assurance indicates that material weaknesses exist and that there is no, or only a limited, system of internal control in this organization. This condition is not typically seen in the federal government.


07. The Statement of Assurance memorandum briefly describes the process used to assess whether adequate internal controls are in place and functioning effectively to accomplish organizational goals and protect IRS resources. Preparers consider the information systems environment operated or used by their organizations and also the issues identified by GAO, TIGTA and IRS management reviews (if applicable) when preparing the Statement of Assurance memorandum.

08. PCAs for newly identified internal control deficiencies should be included with the Statement of Assurance memorandum. Managers execute actions necessary to resolve internal control deficiencies, regardless of whether the MC ESC deems them as significant deficiencies or material weaknesses. Corrective action plans for internal control deficiencies identified in the previous fiscal year(s) will also be updated.

09. Internal control deficiencies that have been corrected will be submitted with a certificate of completion describing the validation process and the results indicator data that verifies that the internal control weakness has been corrected.

10. The MC ESC will review and evaluate these documents and other relevant information to recommend to the Commissioner the level of assurance for submission in the IRS’s Annual Assurance Statement and any newly identified material weaknesses or significant deficiencies (if any).

11. The Commissioner signs and submits an Annual Assurance Statement to Treasury in early November each year.

12. The Commissioner also signs two statements for reporting on internal control over reporting. The IRS Management’s Report on Internal Controls over Financial Reporting concludes on the effectiveness of internal control over financial reporting.


**1.4.2.2.3** **(06-13-2023)**

#### Identification of Quality Assurance Reviews and Initiatives

1. In fiscal year 2012, the IRS expanded its annual assurance process to identify key program evaluations, managerial, operational, security and quality assurance (“reviews”) conducted by the business units to assess the effectiveness of IRS internal controls. These internal control reviews are important to the IRS and can result in greater efficiency, better taxpayer experiences and more effective responses to issues identified by GAO and TIGTA. Refer to IRM 1.4.31, Quality Assurance Review Program, for more information.


**1.4.2.2.4** **(06-13-2023)**

#### Internal Control Reviews

1. IC provides business units with insight into the effectiveness of their implemented corrective actions for audit recommendations issued by GAO and TIGTA and evaluates critical controls over IRS programs identified as high risk, high impact or high visibility. This independent examination is known as an Internal Control Review (ICR) and assists IRS business units when they review and evaluate their internal control processes. Refer to IRM 1.4.32, Internal Control Review Program, for additional information regarding the IC review program.


**1.4.2.2.5** **(05-14-2025)**

#### Outreach and Reporting

1. Outreach and Reporting works with external stakeholders to manage and control oversight processes through the MC ESC and the Subgroup.



1. The Improper Payments Compliance program provides Servicewide oversight for all improper payments reporting and compliance requirements pursuant to the Payment Integrity Information Act of 2019. The primary goal is to reduce improper payments by promoting an effective internal control framework, while also accounting for the statutory implications and inherent limitations of programs within the tax system.

2. The Management’s Discussion and Analysis (MD&A) is prepared each fiscal year as Required Supplemental Information to the IRS Financial Statements and is published annually in the IRS Agency Financial Report. It contains a high-level overview of the IRS’s organizational structure, strategic framework, programmatic and financial performance, as well as management assurances related to IRS internal controls. The MD&A also contains other information required by OMB Circular A-136 and the Federal Accounting Standards Advisory Board’s Statement of Federal Financial Accounting Standard 64, Management’s Discussion and Analysis. IRS offices and business units provide the information for inclusion in the MD&A in accordance with the current fiscal year’s deliverable timelines.


2. The Outreach and Education section promotes internal control across the IRS by coordinating activities with and among staff throughout the IC organization. The Internal Controls Outreach and Education Program assists IRS business units in following through on organizational commitments, policy objectives, applicable laws, regulations and related processes and procedures. The overall goal is to enhance efficient and effective operations by increasing awareness of internal control through outreach, collaboration, communication, education and training.


**1.4.2.3** **(06-13-2023)**

### Internal Controls Process

1. Each business unit, regardless of size, is required to adopt methods to periodically assess risk and develop mitigation strategies and implement, review and update its system of internal control. The methods must be tailored to the specific programs and needs of each business unit.

2. The IRS follows the standards for an effective internal control system for federal agencies set forth in the Green Book.

3. There are five interrelated components in the IRS internal control framework:



1. Control Environment

2. Risk Assessment

3. Control Activities

4. Information and Communication

5. Monitoring


**1.4.2.3.1** **(06-13-2023)**

#### Responsibility of Management in Risk Assessment

1. Managers are responsible for determining what levels of risk they are willing to assume. Conducting risk assessments enables managers to help identify potential risks and their likelihood and impact. This information can be used to prioritize risks and develop plans to respond to them.


**1.4.2.3.2** **(05-14-2025)**

#### The Role of Enterprise Risk Management

1. The Office of the Chief Risk Officer (OCRO) oversees Enterprise Risk Management (ERM). The ERM program provides an agency-wide approach to risk management and helps IRS units incorporate risk management principles into strategies and daily operations. Refer to IRM 1.1.31, Organization and Staffing, Office of the Chief Risk Officer, and IRM 1.4.60, Enterprise Risk Management Program.


**1.4.2.3.3** **(06-13-2023)**

#### Control Environment

1. An effective control environment accomplishes the following:



1. Competent employees understand their responsibilities and the limits of their authority, and they are knowledgeable and committed to performing tasks correctly.

2. Employees follow IRS policies and procedures, as well as the IRS ethical standards.


**1.4.2.3.3.1** **(06-13-2023)**

##### The Role of the IRS in the Control Environment

1. The IRS is tasked with maintaining an effective control environment. To this end, IRS leadership must:



1. Establish and effectively communicate policies, procedures and standards of conduct to its employees.

2. Create a positive tone at the top by conducting itself in an ethical manner.

3. Require the same standard of conduct from all IRS employees.


**1.4.2.3.3.2** **(06-13-2023)**

##### Responsibility of Management in the Control Environment

1. Management must foster an effective control environment by:



1. Maintaining high levels of integrity, professional standards and competence.

2. Establishing a leadership philosophy and style that promotes internal control throughout the IRS.

3. Taking appropriate disciplinary action to correct employee misconduct or delinquency that impairs operational effectiveness, or damages the public image of the IRS, thus affecting the efficiency of the Service when an employee does not comply with IRS policies, procedures or standards of conduct.

4. Maintaining an IC oversight body which is the MC ESC discussed in IRM 1.4.2.6.4, Management Controls Executive Steering Committee.


**1.4.2.3.4** **(06-13-2023)**

#### Risk Assessment

1. Risk assessments allow the IRS to be aware of any internal and external risks that could affect its ability to meet its goals. Through risk assessments, the IRS can manage risks better by establishing appropriate internal controls to mitigate or minimize risks to acceptable levels.

2. Risk assessments are iterative processes and must be reviewed and updated when changes occur or new risks emerge.


**1.4.2.4** **(06-13-2023)**

### Control Activities

1. Control activities are IRS policies and procedures that ensure the risks identified during the risk assessment process are mitigated or minimized to an acceptable level.

2. Managers must document, validate and track PCAs for all control deficiencies arising from the design or operating effectiveness of internal controls. Elements must include PCAs, responsible parties, due dates, validation process and monitoring plans.


**1.4.2.4.1** **(06-13-2023)**

#### Incorporating the Use of Controls

1. Management should establish only those control activities necessary to accomplish the IRS mission and objectives effectively and efficiently.

2. The following chart provides the timing, method and type of controls management can leverage in developing a control.




| **Timing of a Control** | Preventive Controls | Protect the IRS by identifying and addressing problems before they occur. |
| --- | --- | --- |
|  | Detective Controls | Designed to find errors after they have occurred. Properly designed and operating detective controls will also determine if preventive controls are functioning properly. |
| **Method of a Control** | Manual Controls | Rely on human action. |
|  | Automated Controls | Rely on electronic or automatic actions. |
| **Type of a Control** | Key Controls | Defined as one which, if it fails, is highly improbable that other controls could detect the control’s absence. |
|  | Non-key Controls | Can fail without affecting an entire process. |


**1.4.2.5** **(06-13-2023)**

### Information and Communication

1. Communicating relevant information is essential to internal control. Within the IRS, information must be communicated to management and other employees in a form and time frame that helps everyone carry out responsibilities.

2. The following information must be communicated at all levels throughout the IRS:



1. Mission

2. Control Environment

3. Risk

4. Control Activities

5. Performance


3. Communicating efficient and effective information requires IRS employees to evaluate the quality of information.

4. Management obtains or generates and uses relevant and quality information from both internal and external sources to support internal control. These sources include, but are not limited to:



1. Leaders’ Alerts

2. IRS Headlines

3. MC ESC meetings and reports

4. Management reports

5. GAO and TIGTA


**1.4.2.6** **(06-13-2023)**

### Monitoring Controls

1. Monitoring helps the IRS determine whether internal controls are adequate, properly executed over time and effective.


**1.4.2.6.1** **(06-13-2023)**

#### Role of Management in Monitoring

1. Management has a critical role in the internal control system. Managers should focus their monitoring activities on high-risk areas.

2. Management should review tasks or techniques to provide a reasonable level of confidence that controls are functioning as intended.

3. Management is responsible for governance of testing the design and operating effectiveness of internal controls.


**1.4.2.6.2** **(06-13-2023)**

#### Testing Design and Effectiveness of Internal Controls

1. In testing the design of an internal control, management is responsible for validating that the internal controls, if implemented effectively, would address the identified risk.

2. In testing the effectiveness of internal controls, management is responsible for validating whether the control operated effectively and consistently over a period of time.


**1.4.2.6.3** **(06-13-2023)**

#### Role of the Government Accountability Office and TIGTA

1. The GAO and TIGTA audit and investigate IRS operations to:



1. Promote economy and efficiency.

2. Detect and prevent fraud and abuse.

3. Recommend actions for improvement.


2. The timely closure of GAO and TIGTA audit recommendations are a positive indicator on the IRS’s control environment.


**1.4.2.6.4** **(05-14-2025)**

#### Management Controls Executive Steering Committee (MC ESC)

1. The COO is the Chair of the MC ESC. The voting members are the CTS, CTCO, CIO and COO. Advisors to the MC ESC are the TDCFO, the IRS CFO and the Chief Risk Officer.

2. The other participants are the Associate CFO for IC and support staff, decision-making executive representatives of the MC ESC voting members and program managers responsible for the topics/issues being discussed by the MC ESC.

3. The MC ESC oversees management’s design, implementation and operation of the IRS’s internal control system to ensure that internal controls are universally recognized as a shared responsibility and that internal control deficiencies are identified, analyzed and remediated. The MC ESC’s operations are governed by a charter maintained by IC.

4. The MC ESC’s mission is to ensure that all business units and functions identify, address and correct internal control deficiencies and to recognize the importance of their shared responsibility for designing and implementing strong internal controls.

5. The MC ESC’s objectives are to:



   - Build a strong relationship between risk management and internal controls.

   - Ensure existing and new controls address identified risks effectively.

   - Ensure the remediation of existing control weaknesses and prevent new ones from arising.

   - Provide an unmodified Statement of Assurance that IRS has internal controls in place that function effectively.

   - Achieve an unmodified audit opinion on the IRS’s financial statements.


6. The MC ESC oversees Servicewide progress in closing open financial statement audit recommendations.

7. The MC ESC also:



1. Oversees processes to identify, remediate and close material weaknesses, significant deficiencies and other internal control issues.

2. Authorizes final engagement with GAO on the downgrade or closure of an existing material weakness or significant deficiency.

3. Approves reopened actions and revised due dates for these actions. A reopened action is one that the IRS implemented but the financial statement auditor disagrees that the IRS addressed the recommendation.

4. Oversees the work of the Senior Assessment Team and ensures that the IRS meets all control testing requirements including those required by OMB Circular A-123.

5. Ensures that the IRS meets its reporting and certification obligations under the FMFIA, FFMIA, OMB guidelines, Treasury directives and the annual assurance review process.

6. Serves as an alliance between business units and other steering committees to ensure proper engagement and to minimize duplicative efforts in reporting.

7. Approves the closure of “Hold” recommendations as “Unimplemented." Business units may request the MC ESC approve a “Hold” recommendation be closed as “Unimplemented.” The following conditions should be in place before a PCA could be placed in “Hold” status if:


1. The audit finding upon which the recommendation is based is valid.

2. The recommendation is in an area considered mission critical or requires an improvement that management agrees is critical/necessary.

3. There were no resources available at the time the response to the draft report was written.


8. The office of the Associate CFO for IC identifies MC ESC agenda topics for:



1. Issues, concerns or recommendations related to the financial statement audit.

2. Issues driven by ICR; Quality Assurance Reviews; Annual Assurance Statement; financial reporting transactions testing and results and other topics directed by senior IRS leadership.


9. The OCRO identifies MC ESC agenda topics for:



1. Issues related to open or recently closed audits.

2. Active/open PCAs and GAO and TIGTA priority recommendations.

3. Other audits, including high priority audits or areas of significant risk or concern unless there is a known or potential effect on the financial statement audit or a significant deficiency.


**1.4.2.7** **(06-13-2023)**

### Remediation Plan

1. The FFMIA requires agency heads to assess annually whether their financial management systems can prepare required financial statements and reports, provide reliable and timely financial information for managing operations and account for assets, in accordance with federal accounting standards and the USSGL.

2. Agencies that are not in compliance with FFMIA must develop a remediation plan to achieve compliance. The MC ESC outlines the format and information required within a remediation plan.

3. Agencies that are not in substantial compliance with FFMIA must bring their financial management systems into substantial compliance within three years; if this cannot be achieved, Treasury must request a waiver for a longer period from OMB.

4. As a condition of OMB’s waiver to the three-year requirement for completing FFMIA remediations, the IRS is required to provide a remediation plan and a status review of performance for all remedies that were open during the quarter. The CFO has overall responsibility for the IRS remediation plan. The MC ESC monitors the plan, which is tracked in JAMES.

5. The remediation plan owners update the executive summary of the remediation plan with significant accomplishments achieved during the quarter and significant obstacles identified.

6. The MC ESC approves all extensions to the final due date for any recommendation or major project with a remediation plan. Organizations must submit changes upon identification of a risk to completing a recommendation or major project by the due date.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-004-002#addtoany "Show all")

A2A