---
url: "https://www.irs.gov/irm/part1/irm_01-013-003"
title: "1.13.3 Document Management | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-013-003#main-content)

- 1.13.3 [Document Management](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738675290576)
  - 1.13.3.1 [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674999712)
    - 1.13.3.1.1 [Background](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738675020304)
    - 1.13.3.1.2 [Authority](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738675011728)
    - 1.13.3.1.3 [Responsibilities](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738676262112)
    - 1.13.3.1.4 [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738676253616)
    - 1.13.3.1.5 [Program Controls](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738676249184)
    - 1.13.3.1.6 [Terms/Definitions/Acronyms](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674991392)
    - 1.13.3.1.7 [Related Resources](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674963872)
  - 1.13.3.2 [Statistic of Income Workflow Process](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674960496)
    - 1.13.3.2.1 [Controlling Documents Selected for Statistics of Income](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674959552)
    - 1.13.3.2.2 [Statistics of Income Automated Return Tracking System (STARTS)](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674953536)
    - 1.13.3.2.3 [Workflow Process](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674947392)
      - 1.13.3.2.3.1 [Selecting Documents](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674944656)
      - 1.13.3.2.3.2 [Pulling Paper Documents](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674936208)
        - 1.13.3.2.3.2.1 [First Pull Statistics](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674926352)
        - 1.13.3.2.3.2.2 [Non-Master File (NMF) Database](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674922256)
        - 1.13.3.2.3.2.3 [Special Processing of Returns in the Individual/Sole Proprietorship Program](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674917296)
      - 1.13.3.2.3.3 [Fulfilling Requests for Returns in SOI Control](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674915152)
      - 1.13.3.2.3.4 [Scanning Documents Before Editing](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674895584)
      - 1.13.3.2.3.5 [Additional Activities Before Documents Are Ordered](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674870032)
      - 1.13.3.2.3.6 [Documents Ordered by Processing Center Edit Units](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674864864)
        - 1.13.3.2.3.6.1 [Special Processing of Returns in the Individual/Sole Proprietorship Program](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674861328)
      - 1.13.3.2.3.7 [Submission Processing Center Activities After Editing Begins](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674859120)
      - 1.13.3.2.3.8 [Managing Documents in the Processing Center](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674849408)
      - 1.13.3.2.3.9 [Managing Documents in the SOI Edit Unit](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674840864)
      - 1.13.3.2.3.10 [Activities After Editing Documents](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674834096)
  - 1.13.3.3 [Controlling Documents in the SOI Corporation, Partnership and International Branch Programs](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674824928)
    - 1.13.3.3.1 [Controlling the Samples](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674823600)
    - 1.13.3.3.2 [Corporation Income Tax Returns](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674817744)
      - 1.13.3.3.2.1 [Classifying "Giant" Corporation Returns](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674811856)
      - 1.13.3.3.2.2 [Special Instructions for Controlling "Early Fiscal" Returns](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674809344)
      - 1.13.3.3.2.3 [Editing Priorities](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674803056)
      - 1.13.3.3.2.4 [Scanning Documents After Edit and Test Resolution](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674789984)
      - 1.13.3.3.2.5 [Critical Case Returns](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674780336)
        - 1.13.3.3.2.5.1 [Critical Case List](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674779024)
        - 1.13.3.3.2.5.2 [Researching Corporations on the Critical Case List](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674773552)
          - 1.13.3.3.2.5.2.1 [Initiating the Appropriate ECC-MTB Transcript Request](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674769760)
          - 1.13.3.3.2.5.2.2 [Analysis of Transcripts](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674762560)
        - 1.13.3.3.2.5.3 [Reporting on Critical Case Research](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674725184)
      - 1.13.3.3.2.6 [Corporation Advance Data Requests](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674721280)
      - 1.13.3.3.2.7 [Shipping Documents and Magnetic Media](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674719440)
    - 1.13.3.3.3 [Special Projects](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674717024)
      - 1.13.3.3.3.1 [Forms 1118 Study, SOI Years 2016 and 2017](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674714416)
      - 1.13.3.3.3.2 [Forms 5471 Study](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674711952)
      - 1.13.3.3.3.3 [Forms 8865 Study](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674710208)
      - 1.13.3.3.3.4 [Forms 8858 Study](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674708448)
      - 1.13.3.3.3.5 [Forms 8975 Study](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674706704)
    - 1.13.3.3.4 [Partnership Returns of Income](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674705008)
      - 1.13.3.3.4.1 [Special Editing Instructions](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674685632)
      - 1.13.3.3.4.2 [Scanning Documents Before Edit and Test Resolution](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674682144)
      - 1.13.3.3.4.3 [Closeout Procedures](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674676032)
    - 1.13.3.3.5 [Controlling Documents for International Special Studies](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674659264)
  - 1.13.3.4 [Controlling Documents in the SOI Individual and Tax Exempt Branch Programs](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674640192)
    - 1.13.3.4.1 [Selected Documents](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674639168)
    - 1.13.3.4.2 [Individual Income Tax Program](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674632400)
      - 1.13.3.4.2.1 [Special Photocopying Instructions](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674629296)
      - 1.13.3.4.2.2 [Special Closeout Procedures](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674626992)
        - 1.13.3.4.2.2.1 [Tax Year 2016](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674625088)
        - 1.13.3.4.2.2.2 [Tax Year 2017](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674615040)
      - 1.13.3.4.2.3 [Controlling Files and Tapes at the Cincinnati Submission Processing Center](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674604976)
    - 1.13.3.4.3 [Special Studies](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674599952)
      - 1.13.3.4.3.1 [Sales of Capital Assets (SOCA) Study](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674598208)
      - 1.13.3.4.3.2 [National Research Program](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674594416)
    - 1.13.3.4.4 [Controlling Forms 706 and 709](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674590960)
    - 1.13.3.4.5 [Controlling the Form 990 Series and Form 4720](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674565712)
    - 1.13.3.4.6 [Controlling Documents for Domestic Special Studies](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674561472)
  - Exhibit 1.13.3-1 [Enterprise Computing Center - Martinsburg (ECC-MTB) Files](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674558416)
  - Exhibit 1.13.3-2 [Document Status Codes](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674103440)
  - Exhibit 1.13.3-3 [CADE 2 Schedule of First Pull and One Week Follow-up Dates](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738674051776)
  - Exhibit 1.13.3-4 [Research, Applied Analytics, and Statistics Scanning Projects](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738673575328)
  - Exhibit 1.13.3-5 [Alert Page](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738673516128)
  - Exhibit 1.13.3-6 [Shipping Schedule of Statistics of Income (SOI) Projects](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738673452288)
  - Exhibit 1.13.3-7 [SOI Corporation Study Years 2016, 2017, and 2018](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738673348800)
  - Exhibit 1.13.3-8 [Filing Requirement Codes Posted to the Entity Section of the Master File](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738673284448)
  - Exhibit 1.13.3-9 [Individual/Sole Proprietorship Program Schedule, Tax Years 2016 and 2017](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738673229072)
  - Exhibit 1.13.3-10 [Special Closeout Procedures for SOI Individual Programs, Tax Years 2016 and 2017](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738673198384)
  - Exhibit 1.13.3-11 [Submission Processing Center Disposition Schedule: Number of Days After Closeout](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738673171072)
  - Exhibit 1.13.3-12 [Sales of Capital Assets (SOCA) Program Completion Deadlines](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738673150832)
  - Exhibit 1.13.3-13 [Additional Projects Schedule](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738673141232)
  - Exhibit 1.13.3-14 [Form 706, Form 709, and Form 990 Series Processing Schedules](https://www.irs.gov/irm/part1/irm_01-013-003#idm139738673062320)

# Part 1. Organization, Finance, and Management

# Chapter 13. Statistics of Income

# Section 3. Document Management

* * *

## 1.13.3 Document Management

#### Manual Transmittal

September 13, 2018

#### Purpose

(1) This transmits revised IRM 1.13.3, Statistics of Income, Document Management.

#### Material Changes

(1) This section of the Internal Revenue Manual (IRM) describes the Statistics of Income (SOI) workflow process in 2018 and later processing years. The SOI workflow process includes the controlling, scanning, rendering, assigning, editing, and monitoring of documents and electronic records that SOI samples for its studies. SOI collaborates with the Data Management (DM) Division in the Research, Applied Analytics, and Statistics Office on the scanning of paper returns and the rendering of electronically filed returns.

#### Effect on Other Documents

IRM 1.13.3, dated June 6, 2014, is superseded.

#### Audience

Submission Processing Centers across all Operating Divisions.

#### Effective Date

(09-13-2018)

Barry W. Johnson

Director

Statistics of Income Division OS:RAAS:S

**1.13.3.1** **(09-13-2018)**

### Program Scope and Objectives

1. **Purpose**: Section 1.13.3 of the Internal Revenue Manual (IRM) describes the Statistics of Income (SOI) workflow process which includes the controlling, scanning, rendering, assigning, editing, and monitoring of documents and electronic records that SOI samples for its studies. SOI collaborates with the Data Management (DM) Division in the Research, Applied Analytics, and Statistics Office on the scanning of paper returns and the rendering of electronically filed returns

2. **Audience**: The primary users of this IRM section include managers, statistical assistants, tax examiners, and IT computer specialists at the IRS submission processing centers and enterprise computing centers across the country; and, IRS managers, economists, statisticians, and IT computer specialists at the headquarters office of the Statistics of Income Division in Washington, D.C.

3. **Policy Owner**: Director, Statistics of Income Division.

4. **Program Owner**: The Statistics of Income Division, an organization within Research, Applied Analytics, and Statistics, is responsible for the administration, procedures, and updates related to the Statistics of Income (SOI) Program.

5. **Primary Stakeholders**: Areas within the IRS affected by the SOI program include the IRS submission processing centers and enterprise computing centers.

6. **Program Goals**: A division within the office of Research, Applied Analytics, and Statistics (RAAS), the Statistics of Income Division is responsible for formulating and executing the overall statistical policies and programs of the Internal Revenue Service (IRS). Its goals include:



   - formulating and executing the statistical policies, practices, and programs of the Internal Revenue Service;

   - collecting, analyzing, safeguarding, and disseminating information on Federal taxation in support of tax administration, economic policy development, and financial analysis;

   - serving a broad range of users in the IRS, the Federal government, the public, and the nonprofit sectors;

   - providing statistical support within the Service for a broad range of program evaluation and measurement analytics; and

   - leading efforts to modernize Federal statistical programs and practices through engagement with the Federal statistical community.


**1.13.3.1.1** **(09-13-2018)**

#### Background

1. The Statistics of Income (SOI) Division is one of the principal Federal statistical agencies. Economists, statisticians, computer specialists, and communication specialists primarily staff its four branches — Individual and Tax Exempt; Corporation, Partnership, and International; Information Management and Dissemination; and Statistical Services. These Branches are responsible for various SOI projects, producing tax statistics about individuals, estates, businesses, nonprofit organizations, trusts, and foreign investments. SOI uses both the Internet and traditional print publications to provide the public with data on the Federal tax system. It also provides answers to statistical inquiries (See [https://www.irs.gov/statistics/soi-tax-stats-tax-statistics-questions](https://www.irs.gov/statistics/soi-tax-stats-tax-statistics-questions)).

2. SOI provides tax statistics to the public, from individuals looking for tax information to executives engaged in strategic planning and policy makers seeking data to evaluate and change tax laws. It also provides aggregate tax data, statistical services, and other support to the IRS Business Operating Divisions, Legislative Affairs, and Media Relations by responding to data requests, preparing testimony and reports, and conducting research. Other data users include:



   - Office of Tax Analysis

   - Joint Committee on Taxation

   - Bureau of Economic Analysis

   - U.S. Census Bureau

   - Board of Governors of the Federal Reserve

   - State and Local Governments

   - Non-profit research organizations

   - Academics

   - Tax Professionals

   - Citizens seeking to learn more about the tax system


**1.13.3.1.2** **(09-13-2018)**

#### Authority

1. Part III, General Administrative Provisions, Section 21, of the Revenue Act of 1916, which Congress approved September 8, 1916, stated:



> That the preparation and publication of statistics reasonably available with respect to the operation of the income tax law and containing classifications of taxpayers and of income, the amounts allowed as deductions and exemptions, and any other facts deemed pertinent and valuable, shall be made annually by the Commissioner of Internal Revenue with the approval of the Secretary of the Treasury.



In compliance with Section 21, the Office of Commissioner of Internal Revenue published the first report (Document No. 2817), entitled “Statistics of Income,” as compiled from the returns of personal and corporate income filed with the Treasury Department for the year ended December 31, 1916, on June 1, 1918. The summary section, located before the statistical tables at the beginning of the document, contained comparative figures for personal net income beginning with 1913, and corporate net income, beginning with 1909.

2. 26 U.S. Code § 6108 contains the following information about the preparation and publication of Statistical publications and studies:



1. Publication or other disclosure of statistics of income. The Secretary shall prepare and publish not less than annually statistics reasonably available with respect to the operations of the internal revenue laws, including classifications of taxpayers and of income, the amounts claimed or allowed as deductions, exemptions, and credits, and any other facts deemed pertinent and valuable.

2. Special statistical studies. The Secretary may, upon written request by any party or parties, make special statistical studies and compilations involving return information (as defined in section 6103(b)(2)) and furnish to such party or parties transcripts of any such special statistical study or compilation. A reasonable fee may be prescribed for the cost of the work or services performed for such party or parties.

3. Anonymous form. No publication or other disclosure of statistics or other information required or authorized by subsection (a) or special statistical study authorized by subsection (b) shall in any manner permit the statistics, study, or any information so published, furnished, or otherwise disclosed to be associated with, or otherwise identify, directly or indirectly, a particular taxpayer.


3. As one of the principal Federal statistical agencies, the activities of the Statistics of Income Division are largely the collection, compilation, processing, and analysis of federal tax information for statistical purposes. The other principal Federal statistical agencies are the:



   - Bureau of Economic Analysis

   - Bureau of Justice Statistics

   - Bureau of Labor Statistics

   - Bureau of Transportation Statistics

   - Census Bureau

   - Economic Research Service

   - Energy Information Administration

   - National Agricultural Statistics Service

   - National Center for Education Statistics

   - National Center for Health Statistics

   - National Center for Science and Engineering Statistics

   - Office of Research, Evaluation and Statistics (SSA)


Statistical work in the U.S. Government is also carried out by other programs in the Executive Branch that conduct statistical activities in conjunction with a program mission, such as providing services (for example, medical care benefits for the elderly and the poor) or enforcing regulations (for example, with respect to the environment, transportation, or occupational safety).

4. Additionally, there are other Federal agencies whose statistical activities are excluded because they are not part of the Executive Branch. These agencies include the:



   - Congressional Budget Office, which develops and applies projection models for the budgetary impact of current and proposed Federal programs;

   - Joint Committee on Taxation, which assists Congressional tax-writing committees and members of Congress with development and analysis of legislative proposals; prepares official revenue estimates of all tax legislation considered by the Congress; drafts legislative histories for tax-related bills; and investigates various aspects of the Federal tax system;

   - Federal Reserve Board, which compiles the widely used Flow of Funds report and other monetary statistical series and periodically conducts the Survey of Consumer Finances; and

   - U.S. Government Accountability Office, which develops statistical data in evaluations of government programs.


5. The 1995 reauthorization of the Paperwork Reduction Act of 1980 and other legislation give the Office of Management and Budget (OMB) the responsibility of approving agency information collection requests, including those for surveys and other statistical information. The OMB Office of Information and Regulatory Affairs (OIRA) coordinates the decentralized Federal statistical system. The OIRA Statistical and Science Policy (SSP) Office, headed by the U.S. Chief Statistician, coordinates the activities of the Federal statistical system to ensure the efficiency and effectiveness of the system as well as the integrity, objectivity, impartiality, utility, and confidentiality of information collected for statistical purposes. The Chief Statistician also promotes integration across the Federal statistical system by chairing the Interagency Council on Statistical Policy (ICSP), which enables OMB to obtain more direct participation from agencies in planning and coordinating Federal statistical activities. The ICSP is a vehicle for



   - coordinating statistical work, particularly when activities and issues cut across agencies;

   - exchanging information about agency programs and activities; and

   - providing advice and counsel to OMB on statistical matters.


6. Policy Statement 1-3 governs IRS research activities, which include statistics of income. The guidance in this IRM section conforms with Policy Statement 1-3 establishing the foundation for research in the IRS. The collection and analysis of data related to Service operations and strategic goals is essential in sound planning, management and evaluation of Service programs and activities. Studies, tests and research activities are conducted within the headquarter research function, RAAS, and within the operating divisions. See IRM 1.2.10.4.


**1.13.3.1.3** **(09-13-2018)**

#### Responsibilities

1. Research, Applied Analytics, and Statistics (RAAS) has general program oversight of research activities in the IRS. The Chief Research and Analytics Officer is responsible for coordination of research within the IRS and research conducted within the RAAS organization.

2. Responsibilities of the SOI Director, a senior executive who reports to the Chief Research and Analytics Officer, and the Senior Managers of the four SOI Branches (i.e., Individual and Tax Exempt; Corporation, Partnership, and International; Information Management and Dissemination; and Statistical Services) include



   - formulating and executing the statistical policies, practices, and programs of the Internal Revenue Service;

   - collecting, analyzing, safeguarding, and disseminating information on Federal taxation in support of tax administration, economic policy development, and financial analysis;

   - serving a broad range of users in the IRS, the Federal government, the public, and the nonprofit sectors;

   - providing statistical support within the Service for a broad range of program evaluation and measurement analytics; and

   - leading efforts to modernize Federal statistical programs and practices through engagement with the Federal statistical community.


3. Responsibilities of the SOI Senior managers and their Section Chiefs include



   - producing comprehensive statistics from the data collected from the income tax forms and associated schedules filed on individual, tax-exempt organization, tax-exempt bond, gift, and estate tax returns;

   - producing comprehensive statistics on corporation income tax returns, partnership returns, and international taxpayers, including businesses, individuals, and trusts, through a variety of studies;

   - providing IT support for numerous SOI studies and RAAS initiatives, preparing publications for printing and dissemination, and managing the Statistical information Services (SIS) office and the Tax Stats Web site; and

   - providing statistical services to various organizations across the IRS, producing sample designs and weights for the major SOI studies, providing statistical support for numerous IRS quality measures, surveys, and pilot programs throughout the IRS organization, as well as producing projections of tax return volumes for IRS workload planning.


**1.13.3.1.4** **(09-13-2018)**

#### Program Management and Review

1. All IRS research projects are listed on the Research and Analytics (R&A) Project Repository at https://organization.ds.irsnet.gov/sites/ras/raaspmo/SitePages/RAPCHome.aspx. The repository houses an inventory of all active research projects and studies and prior studies since 2016. It is accessible to all research personnel in the IRS and, therefore, provides a communication vehicle for sharing types of projects and programs that the research community is conducting in support of the IRS mission.

2. SOI conducts special statistical studies based on tax returns or performs certain functions related to statistical studies, often on a reimbursable basis. In the latter capacity, it provides data to agencies and individuals authorized by the Internal Revenue Code to receive tax return information for statistical use. Major SOI products include the annual SOI reports compiled from individual and corporation income tax returns, which feature income statement, balance sheet and tax data by industry and form type. SOI also compiles historical data tables for corporations, sole proprietorships, and partnerships. Most SOI studies are summarized for public use in the SOI Bulletin. The Bulletin includes data formerly published in separate reports, summary analyses of previously published tabulations, and results of special studies and analyses. Copies of SOI reports for official use are distributed throughout the IRS, within the Treasury Department, and other Federal Government users, including the Congressional Joint Committee on Taxation (JCT). SOI produces a public-use file of individual income tax returns, which contains separate tax return records, stripped of identifying information and edited to prevent disclosure.


**1.13.3.1.5** **(09-13-2018)**

#### Program Controls

1. IRM 1.13.3 describes the Statistics of Income (SOI) program requirements related to the Statistics of Income (SOI) workflow process. The SOI workflow process includes the controlling, scanning, rendering, assigning, editing, and monitoring of documents and electronic records that SOI samples for its studies. SOI collaborates with the Data Management (DM) Division in the Research, Applied Analytics, and Statistics Office on the scanning of paper returns and the rendering of electronically filed returns.

2. SOI programs and services include:



   - Selecting IRS tax and information returns for its samples.

   - Statistical processing of tax and information returns in its samples.

   - Disseminating micro-level, aggregate, and tabular statistical data based on its samples.

   - Making returns in its samples available to other IRS functions.


3. Implementation of SOI program requirements occurs in the SOI National Headquarters, submission processing centers, and Martinsburg Computing Center. SOI staff furnish technical guidance and direction to the submission processing centers and Martinsburg Computing Center to implement the SOI programs. Such guidance is related to phases of the statistical work, including the identification of problems and the development of solutions, and often requires written procedures, including those necessary for the selection of samples. To assure that program implementation is correct, SOI evaluates the SOI work performed by the submission processing centers through quality assurance programs, internal audit reports, and on-site reviews of the SOI field processing operation.

4. The Submission Processing Center Work Plans include resources for carrying out the SOI programs.


**1.13.3.1.6** **(09-13-2018)**

#### Terms/Definitions/Acronyms

1. Below are words that require interpretation and their definitions.



**Acronyms**






| Acronyms and Abbreviations | Definition |
| --- | --- |
| BEA | Bureau of Economic Analysis (Department of Commerce) |
| BMF | Business Master File |
| ASPC | Austin Submission Processing Center |
| CSPC | Cincinnati Submission Processing Center |
| CY | Calendar Year |
| ECC-MTB | Enterprise Computing Center - Martinsburg |
| DLN | Document Locator Number |
| EIN | Employer Identification Number |
| ELMS | Enterprise Learning Management System |
| EQSP | Embedded Quality for Submission Processing |
| FOIA | Freedom of Information Act |
| FRB | Federal Reserve Board |
| FSPC | Fresno Submission Processing Center |
| JCT | Joint Committee on Taxation (Congress) |
| KSPC | Kansas City Submission Processing Center |
| IDRS | Integrated Document Retrieval System |
| IMF | Individual Master File |
| MEPS | Measured Employees Performance System |
| NAICS | North America Industry Classification System |
| OSPC | Ogden Submission Processing Center |
| OTA | Office of Tax Analysis (Department of Treasury) |
| PCD | Program Completion Date |
| PY | Processing Year |
| RAAS | Research, Applied Analytics, and Statistics |
| SOI | Statistics of Income |
| STARTS | Statistics of Income Automated Return Tracking System |
| TEPS | Total Evaluation Performance System |
| TY | Tax Year |
| W&I | Wage and Investment |


**1.13.3.1.7** **(09-13-2018)**

#### Related Resources

1. SOI makes its reports available to the general public on [https://www.irs.gov/statistics](https://www.irs.gov/statistics). These Web pages include annual reports, historical data, SOI Bulletins, tabulations, and micro-data files for tax-exempt organizations.


**1.13.3.2** **(09-13-2018)**

### Statistic of Income Workflow Process

1. This section of the Internal Revenue Manual (IRM) describes the Statistics of Income (SOI) workflow process.


**1.13.3.2.1** **(09-13-2018)**

#### Controlling Documents Selected for Statistics of Income

1. The workflow process deals with the controlling, scanning, rendering, assigning, and editing of documents (tax returns, forms, schedules, etc.) and the transmitting of electronic records, which SOI selects for its studies. Some of the phases of this process include:



1. sampling both paper documents filed at the submission processing centers and electronic records at the Enterprise Computing Center - Martinsburg (ECC-MTB);

2. storing paper documents in SOI support or edit units at the centers;

3. ordering paper documents and electronic records for error correction and additional editing in SOI edit units;

4. editing paper documents, scanned images of returns, or electronic records;

5. photocopying some paper documents for special projects;

6. scanning paper documents before and after SOI editing;

7. releasing paper documents from the SOI edit units back to Files; and

8. re-filing paper documents in Files.


**1.13.3.2.2** **(09-13-2018)**

#### Statistics of Income Automated Return Tracking System (STARTS)

1. The Statistics of Income Automated Return Tracking System (STARTS) automates some phases of the SOI workflow process. Two SOI database applications, BMF STARTS and IMF STARTS, store information about the SOI samples, statuses of scanning paper documents and rendering of electronic records, and inventories in the SOI edit units at the submission processing centers. These applications give the SOI edit units at the submission processing centers and National Office the capability to control documents (tax returns, forms, etc.) and electronic records (e.g., electronically filed returns or images of scanned documents) from the point of selection at ECC-MTB to the SOI edit units. Both applications produce inventory management reports that provide SOI managers with tools for monitoring every phase in which documents and records change location (e.g., shipment to processing center, receipt at processing center, completion of editing, etc.) and processing status (edited, scanned, rendered, selected for quality review, etc.). With the applications accessible from computer terminals in the submission processing centers and the Statistics of Income (SOI) office in Washington, DC., SOI edit units, statistical assistants, and National Office analysts can monitor different tasks within each phase of the workflow process in real time. For example:



1. SOI edit units can count and monitor the number of selected paper documents and electronic records that are "missing" (i.e., not in SOI control and unavailable for scanning, rendering, editing, or refiling).

2. SOI edit units can create and monitor workgroups of paper documents and workgroups of scanned and rendered images of documents and electronic records for assignment to individual editors.

3. SOI analysts in National Office and statistical assistants at the submission processing centers can review and monitor an SOI edit unit’s progress in meeting a project deadline.


**1.13.3.2.3** **(09-13-2018)**

#### Workflow Process

1. In defining the way selected documents and records move through the Statistics of Income (SOI) infrastructure, this section identifies:



1. tasks in the SOI edit units;

2. procedures for controlling documents and records as they move through the SOI workflow process; and

3. users' roles at the submission processing centers.


**1.13.3.2.3.1** **(09-13-2018)**

##### Selecting Documents

1. SOI sample selections occur at the Enterprise Computing Center - Martinsburg (ECC-MTB) and the Ogden Submission Processing Center (OSPC). These two centers create and transmit data files to the submission processing centers for loading records into SOI databases and the printing of charge-outs to pull paper returns. All the files contain data that SOI selected from the Business Master File (BMF) and the Individual Master File (IMF).



1. Beginning with **Cycle ‘03**, the ECC-MTB produces, stores, and transmits Business Master File (BMF) data to the Ogden campus for storage in SOI databases. Ogden personnel should ensure this occurs regularly and without unnecessary delay. At approximately the same time the SOI Branch at the Ogden Submission Processing Center creates files for the Forms 706, 709, 990 series, and 4720 projects. See _Exhibit 1.13.3-1_ for a description of SOI files. ECC-MTB also produces and transmits charge-out files to the Cincinnati, Kansas City, and Ogden centers.

2. Beginning with **Cycle ‘04**, ECC-MTB transmits daily **Individual Master File (IMF)** records, such as SOI charge-outs, to the centers in Austin, Fresno, Kansas City, and Ogden, and produces and stores other IMF data, which it transmits to the Cincinnati campus for loading into SOI databases. See _Exhibit 1.13.3-1_ for a description of each file. In addition, supplemental samples for the Form 1040 Study are selected at ECC-MTB in cycle 19, with the tape label containing the cycle designation, **20XX19k.**


2. At times problems create a need to request replacement ECC-MTB files, or reprinting of files at the submission processing center. Center staffs can address questions about a rerun or a reprinting to the SOI coordinator at the center, the SOI Edit Unit manager, or the National Office STARTS Team.


**1.13.3.2.3.2** **(09-13-2018)**

##### Pulling Paper Documents

1. The submission processing centers, or the local SOI units, print and deliver two or three sets of the SOI charge-outs to the centers' Files functions, other designated areas at the centers, or the Federal Records Centers (FRC). The SOI edit units at the centers monitor the receipt of these SOI charge-outs. They also insure the timely pulling of the selected paper documents. If either the ECC-MTB or the centers' print rooms deliver the charge-outs late, or SOI units are producing their own sets of charge-outs, the centers can pull the samples by printing either a STARTS Selected Returns Lists or a set of STARTS charge-outs.

2. Centers print the SOI charge-outs in Document Locator Number (DLN) order, or another appropriate order, and batch them for pulling documents according to local procedures. They charge the pulling of the returns to Organization-Function-Program (OFP) code 28000–530–00000. Document 6209, IRS Processing Codes and Information, and IRM 3.5.61, Files Management and Services, state that the expeditious pulling of paper SOI returns first at the centers is a high priority.

3. Pulling paper SOI returns in Files before the pulling of other weekly requests (such as Refund Review, Notice Review, Unpostables, AIMS, and internal notices), will reduce the number of missing SOI returns - i.e., reduce the number of returns SOI does not control and the SOI unit or Files must find. The criteria that Files uses to pull returns is found in IRM 3.5.61.1.7.3, Priority Pull Listing.

4. For each return found, place an SOI charge-out in the Files, Federal Records Center (FRC), block that holds the document to indicate SOI holds the original return. The second copy of the charge-out is the cover sheet for the return.

5. If a document is unavailable during this "First Pull" phase, the SOI edit unit notes and dates on the SOI charge-out and in STARTS the name of the IRS function controlling the return. This information is helpful in follow-up searches for paper returns missing from the SOI inventory at a center. SOI staff should begin the search immediately for documents if Files annotated on the charge-out, "Block Not in File (BNIF)," or "Document Not in File (DNIF)" .

6. Once Files pulls the returns for a cycle, the SOI edit unit sorts and shelves them in either cycle-page-line or DLN order. The order depends on the local center’s preference in meeting the needs of its SOI operations. During this process, the unit compares the taxpayer identification number (TIN) and DLN on the charge-out with those on the return to insure Files pulled the correct document. This review is done at this point because obtaining the correct return later is more difficult and costly.

7. If the unit shelves the returns in cycle-page-line order, folders are prepared for each cycle and page combination. A page can contain between one and twenty returns. The folder should show the cycle and page number in a location that will display the information when the unit shelves the folders. Returns are placed in the appropriate folder in "line number" sequence.

8. If the unit stores the returns in DLN order, the unit can shelve them by DLN within a SOI cycle or by the standards practiced in Files.

9. A copy of the charge-out for a missing paper return is kept in a folder marked "Missing SOI Year 2018 (2019, etc.) BMF (or IMF) Returns." The unit uses the charge-outs in this folder in follow-up searches, and during the collection of "First Pull" and "One Week Follow-up" information.


**1.13.3.2.3.2.1** **(09-13-2018)**

###### First Pull Statistics

1. After the initial pulling of SOI documents, the center enters the "Missing Date" and "Doc Status" into STARTS for each paper return in a cycle the SOI edit unit does not control. See _Exhibit 1.13.3-2_ for valid document status codes, which describe the submission processing center function holding the "missing" return, or the workflow situation associated with the "missing" return.

2. After the center enters the "missing" return information, it updates the "First Pull" and "One Week Follow-up" dates in the STARTS Cycle Screen. It should follow the schedule of dates in _Exhibit 1.13.3-3_ when updating this cycle information. Entering as early as possible the "One Week Follow-up" date, even if all of the returns in the cycle are not controlled, will make returns, which do not have a return status value of "2" , available sooner for SOI units to edit.

3. The center sends "First Pull" statistics to National Office each week.


**1.13.3.2.3.2.2** **(09-13-2018)**

###### Non-Master File (NMF) Database

1. Some [1040](http://publish.no.irs.gov/cat12.cgi?request=CAT2&itemtyp=F&itemb=1040&items=) returns are posted to the Non-Master File (NMF). Because these documents do not post to the Individual Master File (IMF), SOI does not automatically sample them. In the past, SOI has alerted submission processing center personnel to look for such returns. See IRM 3.17.46, Automated Non-Master File Accounting, for more information about the procedure.

2. Since 2002, submission processing centers posted a NMF record to the IMF. But, because the TC 150 is equal to $0 (no other data is present), this process makes the record essentially the same as a Substitute For Return (SFR) record.

3. The new IMF posting procedure does not always ensure the selection of the 1040 return, especially in the case of "no significant tax data" on the Master File. Therefore, the NMF unit at the Cincinnati Submission Processing Center forwards photocopies of NMF returns to the SOI Branch (see IRM 3.17.46.5.4, IMF Accounts Over $1 Billion). Upon receipt of the photocopy, SOI National Office is notified.

4. The SOI unit in Cincinnati adds record information about the NMF returns to the IMF STARTS database, making the NMF returns available for placement in workgroup orders.


**1.13.3.2.3.2.3** **(09-13-2018)**

###### Special Processing of Returns in the Individual/Sole Proprietorship Program

1. "The set of Cross-Sectional" 1040 returns comprises both Non-SOCA and SOCA 1040 returns.

2. Reducing the number of missing paper "Cross-Sectional" 1040 returns is a high priority.


**1.13.3.2.3.3** **(09-13-2018)**

##### Fulfilling Requests for Returns in SOI Control

1. Certain SOI projects and requests from other IRS functions require the SOI units to photocopy documents, scan documents, or retrieve scanned images of documents that SOI controls. The SOI function (i.e., SOI control unit or SOI edit unit), which is controlling the document or has access to the electronic record information and image, can photocopy, scan, or retrieve it for a special SOI project, or another IRS function. In addition, the SOI unit may give the original return or a printout of the scanned images to the IRS requester and either control the photocopy or rely on the scanned images for SOI processing. After editing, the SOI edit unit destroys the photocopy, if no other SOI processing is necessary (e.g., scanning). Another option is giving the IRS requester access to the Distributed Processing System (DPS) Image Network (DIN), which stores the scanned images of many of the returns in SOI samples.

2. For each SOI project that requires photocopying of some documents, the unit generates a list in STARTS. The lists accompany the photocopies. The unit keeps copies of the lists for future reference. After photocopying the documents on the list, the unit:



1. Stamps the message, "Photocopy for SOI," on the first page of each selected document.

2. Sorts the photocopies based on the listings.

3. Places the originals back on the shelves, or in the STARTS workgroups.

4. Checks a sample of photocopies for completeness and legibility.

5. Ships the photocopies to the processing site.

6. Charges the time spent photocopying documents to the appropriate SOI Organization-Function-Program (OFP) code.


3. If another IRS function requests the original document, and the SOI unit elects to make a photocopy for SOI processing, it:



1. Photocopies the document.

2. Stamps the message, "Photocopy for SOI," on the first page of each selected document.

3. Notes in the "Remarks" field of the STARTS Primary Record Screen that the requesting function has the original.

4. Sends the original to the requester.

5. Places the photocopy back on the shelves, or in the STARTS workgroup.

6. Charges the time to the appropriate non-SOI OFP code.


4. If another IRS function requests the original document, and the SOI unit elects to provide it before SOI processing is completed, it:



1. Locates the document.

2. Scans the document through the DIN system.

3. Notes in the "Remarks" field of the STARTS Primary Record Screen that the requesting function has the original.

4. Re-charges the document to the requesting area.

5. Sends the document to the requesting area.

6. Charges the time to the appropriate non-SOI OFP code.


### Note:

The SOI Operation Manager/Designee will obtain authorization for charging the time for this work prior to fulfilling these requests.

5. If another IRS function requests an expedite image of a document, or a portion thereof, the SOI unit:



1. Prints the image(s) from the DIN server.

2. Stamps the image(s) "Copy" on the first page of each selected document.

3. Sends the image(s) to the requesting area.

4. Charges the time to the appropriate non-SOI OFP code after the SOI Operation Manager/Designee obtains authorization for charging the time for this work to the appropriate code.


### Note:

Documents containing in excess of 25 pages may require SOI Operation management approval prior to fulfilling a request. SOI may elect to provide large volume requesters access to the DIN server for viewing document images after applying for access through the on-line 5081 application process.

6. An SOI unit can enter information about these requests in the STARTS "Remarks" dialog box to maintain a record.


**1.13.3.2.3.4** **(09-13-2018)**

##### Scanning Documents Before Editing

1. SOI units at the Cincinnati and Ogden submission processing centers scan documents for a number of studies and programs before the commencement of SOI editing. For example, SOI units scan corporation and partnership forms, schedules, and attachments before SOI editing and for delivery to the Large Business and International (LB&I) division. In addition, SOI scans the Form 8038 series for the SOI Individual and Tax-Exempt Branch and Form 8328, Carryforward Election of Unused Private Activity Bond Volume Cap, for the Tax-Exempt Governmental Entities (TEGE) operating division.

2. SOI maintains scanning systems to produce, store, and supply the images of the documents: DIN (Distributed Processing System (DPS) Image Network), KIN (Schedule K-1 Image Network which stores images from the Service Center Recognition/Image Processing System (SCRIPS)), LIN (LB&I Image Network), and SEIN (SOI Exempt Organization Return Image Network). The complete list of current SOI scanning projects is found in _Exhibit 1.13.3-4_.

3. Criteria for selecting returns to scan differ among the various SOI studies, including the LB&I and TEGE programs. STARTS controls the returns for the DIN, KIN and LIN operations, while BBTS controls the returns, selected before pipeline processing, for the SEIN system (See IRM 3.20.12, Imaging and Perfecting Exempt Organization Returns for Public and Internal Viewing). Either STARTS reports or a specific SOI study identify the returns the centers will scan during the year.



1. The weekly BMF STARTS file load program identifies 1120 and 1065 returns for SOI and LB&I scanning based on the SOI and LB&I selection criteria. This program supplements the record information on the file that ECC-MTB generates each week and SOI loads into BMF STARTS. The centers generate a STARTS report, which identifies the SOI and LB&I selections. With implementation of KIN, which stores SCRIPS images of the paper filings of Schedule K-1, the centers can focus on scanning the "parent" 1120 and 1065 returns. Upon completion of scanning the parent document, these images are merged with those in KIN to produce a "complete" return for LB&I. The centers can use IDRS to request prints of electronically filed 1120 and 1065 returns, which the centers have to scan for LB&I and SOI, if SOI has not rendered images from the XML files.

2. The Ogden submission processing center scans the population of Forms 8038, 8038-G, 8038-T, 8038-CP, 8038-TC, and 8328 before SOI editing. The center generates a STARTS report, which identifies the selections for both TEGE and SOI.

3. Before editing the centers should scan all of the paper returns in the corporation and partnership samples.



      ### Note:



      If a center is preparing a paper return for pre-edit scanning, but an SOI edit unit needs to edit the same return, the return is placed immediately in a STARTS workgroup and shipped to the edit unit. In this case, scanning of the return will occur after the edit unit completes statistical abstracting.

4. The Cincinnati submission processing center scans the samples of Forms 706 and 709 before SOI editing.

5. The Ogden submission processing center scans the population of Forms 990, 990-PF, 990-T, 4720, 8921, and 8922 (via SEIN) after pipeline processing and stores the images on the SOI DIN server.


4. The SOI edit unit or control unit that scans returns before SOI editing should follow the procedures outlined in the Scanner User Guide for the Distributed Processing System (DPS) Image Network (DIN), or the LB&I Image Network (LIN), as well as this document. These procedures emphasize the following actions, that the SOI edit and control units share:



01. Determining if all the documentation associated with a return is available for scanning.



       ### Note:



       A center does not scan a return until it controls all the documentation associated with the return, unless a program completion deadline is approaching. All Forms 1120S are scanned after the Schedules K-1 are located and associated with the parent return. If additional Schedules K-1 are found, the SOI unit re-scans the entire return and supplies information about the return to both SOI and DMD staff, including the SCPL, which is used to replace the original set of images in DIN with the re-scanned set.

02. Preparing an "Alert Page" , if applicable, that identifies all of the documentation obviously missing from the return (e.g., missing boxes, one or more pages in the first set of pages of a return). See _Exhibit 1.13.3-5_ for an example of this insert.

03. Generating a bar-coded SOI Form 4251 (charge-out) in STARTS, if necessary.

04. Confirming the employer identification number (EIN) and tax period on both the return and the Form 4251 charge-out are identical.



       ### Note:



       If there is a mismatch, or "miss pull" , the SOI unit puts the return aside for further research. In rare cases, a correction of record information occurs and subsequently a new Form 4251 is printed and attached to the return before scanning.

05. Calibrating the scanners to ensure the images of the returns are not only legible but also complete - i.e., the images of periods and hyphens, or other minute characters and symbols, on the return are captured during the scanning process.

06. Scanning the SOI **Form 4251**, **which is placed at the beginning of the return**, followed by the first set of pages of a return (for example, first four pages of an 1120 return), the Form 7004, Application for Automatic Extension of Time to File, if applicable, the Alert page, if applicable, and then the rest of the return.

07. Scanning the entire return, including any indexes and tables of content, if applicable, in the same order in which the document was filed, without rearranging attachments.



       ### Note:



       The unit scans all the pages, other than the envelope, placing any adjustment paperwork at the end of the document.

08. Scanning the return in the same order as the boxes which held all of the documentation, if the return was shipped in more than one box.

09. Viewing the return on the computer monitor while scanning the return to make sure that any pages requiring re-scanning (e.g., two pages on top of each other, or a slanted page) are completed at that time.

10. Reviewing the images of each scanned return by examining the entire scanned image of the return and all supporting schedules and attachments during the quality review phase of the DIN/LIN operations to ensure all the images are readable, including the pages oriented in landscape mode.

11. Date stamping the SOI Form 4251 after completion of the scanning process to identify returns that are "pre-edits" .



       ### Note:



       Each center determines the utility of date stamping.

12. Moving the adjustment paperwork back to the front of the document before re-filing.


5. SOI National Office leads a monthly telephone conference call with the Cincinnati and Ogden SOI staffs. The monthly calls include discussions on workload priorities and changes in procedures for implementing goals associated with scanning. The calls also include discussions about the workflow of the various DIN projects. These calls do not preclude the employees at the centers from communicating with each other and analysts in National Office whenever it is necessary. National Office assumes, however, major issues are covered during the telephone conference calls.


**1.13.3.2.3.5** **(09-13-2018)**

##### Additional Activities Before Documents Are Ordered

1. After completion of photocopying, or imaging, the SOI units continue to maintain the returns on the shelves or carts for a period of time to ensure successful scanning.

2. The SOI units search for missing paper returns. When a missing return is found, it updates the record information in STARTS.

3. The SOI units process expeditiously requests from other IRS functions. It updates the "Photocopy" field on the STARTS Primary Record screen with a "Y," if it releases the original return to the other function after making a photocopy. If another function requests a photocopy, the unit does not charge the photocopying to SOI.

4. The units monitor the workflow process, especially checking whether an SOI processing center has ordered documents. Several reports in STARTS provide workflow management information, including the timely loading of the STARTS Control File, the volume of different types of returns selected in each cycle, the status of missing returns, and the number of days documents remain in Files, of an SOI unit, before shipment to an SOI edit unit.

5. Since STARTS pre-prints the submission processing center address on the Form 3210 facsimiles, the center must check the accuracy of the address in STARTS. The units use the STARTS Address Screen to make changes to their own shipping addresses.

6. The SOI units, enter information (dates, codes, etc.) into STARTS that is valid and indicative of an action at a particular point in the SOI workflow process. The goal is the reduction in the length of time SOI controls documents.


**1.13.3.2.3.6** **(09-13-2018)**

##### Documents Ordered by Processing Center Edit Units

1. A processing center SOI edit unit manager and that manager's staff use STARTS to create workgroups of documents or electronic records. Reports and screens in STARTS present information about when and what returns are ready for assignment, or shipment if paper, from another selecting center, the manager's own center, or Files. See _Exhibit 1.13.3-6_ for information about the assignment of returns.

2. STARTS automatically produces a Shipment Control Sheet, Editor Sign-Out Sheet, and a Document Transmittal and updates the database, inventory reports, and screens when the edit unit creates a workgroup.

3. SOI units fulfill orders timely to ensure returns are available to edit.


**1.13.3.2.3.6.1** **(09-13-2018)**

###### Special Processing of Returns in the Individual/Sole Proprietorship Program

1. The set of "Cross-Sectional" returns comprises both Non-SOCA and SOCA 1040 returns.

2. The SOI units edit available "Cross Sectional" returns first.


**1.13.3.2.3.7** **(09-13-2018)**

##### Submission Processing Center Activities After Editing Begins

1. After fulfilling workgroup requests, the SOI units should continue to search for missing paper returns. When a missing return is found, a unit updates the pertinent record information in STARTS. This action makes the document available for ordering.

2. When another function needs a document, SOI personnel follow the procedures below:



1. Request the original return, a photocopy, or a printout of the scanned images after checking STARTS to find its location in the SOI workflow.

2. Make a complete and legible photocopy or printout, if the other function requests the original.

3. Stamp on the copy, "PHOTOCOPY (OR PRINTOUT) FOR SOI," and write the other function’s name on the first page, so that the SOI processing center knows to destroy this document after completely editing it.

4. Send the original return to the requester; or, to the selecting center Files function, if the center is a non-processing center.

5. Update STARTS with information about whether the unit sent a photocopy, printout, or original to the requester, and the requester’s name.

6. Place the photocopy or printout back in the document’s original SOI workgroup.

7. Recharge the requested document to the other function when the unit sends the original to the requester.


3. An alternative to photocopying, or printing copies of the scanned images, is the edit unit’s expeditious editing of the return, and, then, its release in the next STARTS release workgroup. However, SOI recommends photocopying or printing copies of the scanned images for one of the following requirements:



1. An SOI edit unit needs the original return for several days beyond the norm.

2. A return is selected for quality review.

3. The document requires review by a lead editor.


**1.13.3.2.3.8** **(09-13-2018)**

##### Managing Documents in the Processing Center

1. When an SOI unit receives paper returns from another center or Files, it uses the accompanying Form 3210, Document Transmittal, to verify that all of the returns are in the shipment. The unit retains copies of the Forms 3210.

2. The unit promptly resolves any problems with a shipment, such as "Wrong Pulls" (also called "miss pulls" , or non-selected returns) or returns missing from the shipping boxes or carts. If the unit is unable to find a return, or has a non-selected return in its possession, it:



1. Updates the return as missing in STARTS, which then automatically adds the return to the Missing Returns List.

2. Enters a brief description of the problem (e.g., "Wrong Pull attached to charge-out; returned to the Fresno Submission Processing Center on 05/04/2013" ) in the "Remarks" field of the STARTS Return Information Screen.

3. Ships a "Wrong Pull" back to the other center or Files under cover of a manually prepared Form 3210, Document Transmittal.


3. Upon finding the correct return, the other center or Files sends it to the SOI edit unit, which updates STARTS. This action makes the return available for assignment to a new workgroup.

4. If the processing center SOI control unit receives the returns, it returns an acknowledgment copy of a Form 3210 to Files or the other center. It should check for "Wrong Pulls" or missing returns before shipping it to the SOI edit unit.

5. If a submission processing center unit is sending a STARTS workgroup to the SOI edit unit, it prints the Shipment Control Sheet, Editor Sign-Out Sheet and Form 3210. It also updates STARTS. The unit prints a Form 3210, Document Transmittal facsimile, whether it is sending its own documents, or those from a non-processing center.

6. If the center does not move returns between two different locations, as in the Cincinnati Submission Processing Center, the Form 3210 is not necessary. However, the edit unit still needs the Shipment Control Sheets and the Editor Sign-Out Sheets.

7. Each processing center should decide whether to hold returns awaiting editing in either the SOI control unit area or the SOI edit unit area. This decision will likely depend upon available space; however, a center should hold returns in the SOI control unit area until needed by the SOI edit unit to meet requests for returns from other functions.

8. The SOI control unit releases the workgroup to the SOI edit unit either in boxes or on batch carts according to local procedures.


**1.13.3.2.3.9** **(09-13-2018)**

##### Managing Documents in the SOI Edit Unit

1. When the SOI edit unit receives returns from another center, the processing center SOI control unit, or Files, it verifies that all of the returns in the workgroup are present for editing. If it identifies any problems during this check, it contacts the appropriate function. If the edit unit has a selected return that it is not supposed to edit, the unit uses STARTS to transfer the return to the appropriate SOI processing center.

2. Upon completion of this verification, the edit unit acknowledges receipt of the workgroup by updating STARTS.

3. The edit unit manager controls the unit’s inventory of returns with the assistance of STARTS management reports.

4. Upon completion of edit processing, including quality review, scanning, photocopying, and special editing (such as editing for the SOCA Project), the manager releases returns from the unit.



### Note:



Timely releases of returns at the completion of SOI processing ensures timely delivery of these documents to other IRS requesters. If an SOI edit unit manager is unsure about the closing date of a particular SOI study, or the appropriate actions associated with that closing, the manager contacts the National Office senior analyst of the study.

5. If a released paper return is missing from the workgroup, the manager should check with the tax examiner who originally edited the return, the lead editor, and/or the quality reviewer. The editor sign-out sheets associated with returns shipped to the edit unit are useful for this research. If the return is still missing, the unit records this information in the right margin of the "Release Workgroup" Shipment Control Sheet and releases the workgroup to the processing center SOI control unit or Files.

6. The edit unit updates STARTS after releasing the workgroup.

7. The SOI units in the processing center destroy photocopied returns that are not part of a special study (HINT, SOCA, Form 5471, etc.).


**1.13.3.2.3.10** **(09-13-2018)**

##### Activities After Editing Documents

1. At the processing center, either the SOI control unit or Files function receives the release workgroups from the SOI edit unit. An SOI control unit updates STARTS and verifies the presence of each paper return in the release workgroup. If a return is not found, the unit first checks the area, including the edit unit area, before entering it as missing in STARTS. If a regular Files unit does not have access to STARTS, the SOI edit unit assumes the role of checking whether returns are missing and updating STARTS.

2. The SOI unit keeps copies of the control sheets for the release workgroups when it ships paper returns back to Files. The Files function recharges those returns to the next requester or recharges those returns to Files after re-filing and shelving the documents. The SOI unit retains the shipment control sheets until the end of a program. See IRM 1.13.2, Processing Management, for the program completion deadlines of various SOI studies.

3. Before shipping back documents to another center, the SOI unit ensures that any special processing (such as scanning or photocopying) has been completed.



### Note:



Timely releases of returns at the completion of SOI processing ensures timely delivery of these documents to other IRS requesters.

4. The Files function verifies that all of the paper returns listed on the release workgroup shipment control sheets are present. If problems occur with the shipment, such as missing returns, the unit contacts the processing center SOI control unit or edit unit for assistance. It is the responsibility of the processing center SOI unit to resolve expeditiously these problems. When the documents are found, the unit should ship these returns under cover of a manually prepared Form 3210, Document Transmittal.

5. When the other center receives the shipment, it returns an acknowledgment copy of a Form 3210. The entry of this date on the Form 3210 serves as an acknowledgment of the receipt and the SOI unit updates STARTS.

6. The other center releases its center’s original returns back to Files or to another function. It recharges those returns sent to the new requester. The Files function retains the STARTS shipment control sheets until the program completion date.



### Note:



If a Files manager is unsure about the closing date of a particular SOI study, or the appropriate actions associated with that closing, the manager contacts both the STARTS Team and the senior analyst of the study in National Office.


**1.13.3.3** **(09-13-2018)**

### Controlling Documents in the SOI Corporation, Partnership and International Branch Programs

1. This section of the Internal Revenue Manual (IRM) describes the controlling and assignment of documents selected for the Statistics of Income (SOI) Corporation Programs. Each year the selection of the sample for a specific corporation tax year begins in cycle '27 and ends two years later in cycle '26. For example, selection of the sample for the SOI Year 2017 Corporation program began in cycle 201727 and ends in cycle 201926.


**1.13.3.3.1** **(09-13-2018)**

#### Controlling the Samples

1. The selected documents in the Corporation Programs include the following:



   - Form 1120, U.S. Corporation Income Tax Returns

   - Form 1120-F, U.S. Income Tax Returns of Foreign Corporations

   - Forms 1120S, U.S. Income Tax Returns for an S Corporation

   - Forms 1120-L, U.S. Life Insurance Company Income Tax Returns

   - Forms 1120-PC, U.S. Property and Casualty Insurance Company

   - Forms 1120-REIT, U.S. Income Tax Returns for Real Estate Investment Trusts

   - Forms 1120-RIC, U.S. Income Tax Returns for Regulated Investment Company


**1.13.3.3.2** **(09-13-2018)**

#### Corporation Income Tax Returns

1. During 2018, Statistics of Income (SOI) selects documents for the SOI Year 2016, 2017, and 2018 Corporation Studies. _Exhibit 1.13.3-7_ shows the assignment criteria. During the year the following processing occurs:



1. Sampling for the SOI Year 2016 Corporation Study continues through mid-2018 (i.e., through cycle 201826). The final cutoff for editing the sample happens in July 2018, though returns critical to the sample are added in August, 2018. IRM 1.13.2, Processing Management, provides additional instructions.

2. For the SOI Year 2017 Corporation Study, the selection of returns began in Cycle 201727 and will continue through Cycle 201926. Editing of Forms 1120, 1120-F, 1120S, 1120-RIC, and 1120-REIT, begins in June 2018. An SOI edit unit starts processing Forms 1120-L and 1120-PC in September 2018.

3. Beginning with Cycle 201827, the sampling program selects documents for the SOI Year 2018 Corporation Study. Editing of the various forms in this study begins in the middle of 2019.


2. SOI units at the Cincinnati, Kansas City, and Ogden Submission Processing Centers edit corporation returns filed at their centers with National Office adjusting work volumes through STARTS to meet the expected sample volume for each of the three edit sites.

3. The on-line edit processing in the edit units combines editing, consistency testing, and error resolution of data into one function. The edit units key data from the documents that are subject to various consistency tests. They must resolve any error conditions detected before more processing (editing, photocopying, scanning, etc.) can continue.

4. At the completion of the SOI study, analysts in National Office run a series of post-consistency programs against extracts from the database files. This process produces Source Book-related tables, listings, and other outputs, SOI prepares for its customers.


**1.13.3.3.2.1** **(09-13-2018)**

##### Classifying "Giant" Corporation Returns

1. SOI classifies corporation returns by asset size (or another money amount) and sample code during the execution of the sampling program at ECC-MTB. The criteria for "Giant" corporation returns are assets greater than or equal to $250 million, and a sample code that is either 22, 32, 38, 39, 44, 53, 58, 72, 73, 74, 75, 76, 79, 92, 93, 94, 95, 96, 97 or 98.

2. SOI embedded this classification scheme into the SOI corporation edit application to prioritize returns for editing.


**1.13.3.3.2.2** **(09-13-2018)**

##### Special Instructions for Controlling "Early Fiscal" Returns

1. Some SOI units make the "Early Fiscal" returns available to LB&I or SB/SE for classification. Early classification of these documents increases the likelihood that the returns are available to SOI for its processing of them. If the control unit must photocopy a document, because LB&I or SB/SE needs the original, the unit follows the procedures below:



1. Make a complete photocopy.

2. Update STARTS with information about the LB&I or SB/SE request.

3. Stamp the first page of the original return, "UNIT MADE PHOTOCOPY FOR SOI."

4. Release the original return to LB&I or SB/SE.

5. Stamp the photocopy of the return, "THIS PHOTOCOPY FOR SOI."

6. Control the photocopied return for SOI.



      ### Note:



      Ideally, SOI should scan a return before giving the original paper copy to a requester.


**1.13.3.3.2.3** **(09-13-2018)**

##### Editing Priorities

1. SOI creates a priority list each year that the SOI edit units follow. The edit unit manager can make exceptions to this list in consultation with National Office.

2. The editing priorities are identified in the table below.




| Editing Priority by Program Code | Type of 1120 Return |
| :-: | :-: |
| 1 | Critical Case |
| 2 | Returns on a First In, First Out basis |


**1.13.3.3.2.4** **(09-13-2018)**

##### Scanning Documents After Edit and Test Resolution

1. Scanning of all the 1120 returns in the sample occurs before editing.

2. Scanning creates an historical file for SOI customers to use if they have questions about the data. Each processing center is responsible for determining whether the SOI control unit, or edit unit, scans the selected returns. Only IRS personnel can scan returns. See _IRM 1.13.3.2.3.4_ and _IRM 1.13.3.3.2.4 (4)_ below for information about the scanning procedures.

3. The BMF STARTS application places returns selected for scanning, but not yet scanned, in "release" workgroups, which are separate and distinct from other types of release workgroups. The unit updates the workgroup information in STARTS after completing the scanning.

4. Scanning procedures include:



1. Removing the notes, tabs, snapshots and other mark-up that SOI editors added to the return during the editing process.

2. Viewing the return on the computer monitor while scanning the return to make sure that any pages requiring re-scanning (e.g., two pages on top of each other, or a slanted page) are completed at that time.

3. Examining the entire scanned image of the return and all supporting schedules and attachments during the quality review phase to ensure all the images are readable, including the pages oriented in landscape mode.

4. Notifying SOI National Office of any Form 5471, 8858, 8865, or 8975 that the center plans to scan at a later date after it scanned the parent 1120.

5. Reviewing STARTS reports that identify returns available for releasing.


5. The center will review the quality of each scanned image of a return which is selected for the SOI study.

6. Advance Data review of returns in the spring may require the scanning of some critical case returns earlier in the year. SOI will send RAAS Data Management Division (DMD) a priority list of returns to scan.


**1.13.3.3.2.5** **(09-13-2018)**

##### Critical Case Returns

1. Critical case returns are certain large corporation returns SOI samples at the 100 percent rate in which their absence from the Corporation Study would affect the final statistics. It is important to the outcome of the study the submission processing centers control and account for these returns during SOI processing. For those missing from the sample, this section contains instructions for identifying, researching, and initiating follow-up procedures for controlling these documents.


**1.13.3.3.2.5.1** **(09-13-2018)**

###### Critical Case List

1. The SOI Critical Case List identifies both selected and non-selected returns that are critical to the Corporation Study. The selected returns are those documents sampled at ECC-MTB. Each cycle the submission processing centers pull and control them. A major concern associated with this group is the number of missing documents - i.e., the number of these returns in another IRS function’s possession. SOI units focus their attention on finding these returns and obtaining the original or a photocopy.

2. The non-selected returns are returns that the SOI sampling program at the Enterprise Computing Center - Martinsburg (ECC-MTB) has not selected. Reasons for this occurrence include:



1. corporate mergers, dissolution, or changes in consolidated filing status;

2. a return is not filed by the Advance Data cut-off; and

3. a return had problems posting to the Business Master File.


3. Centers receive the Critical Case List from National Office. It is maintained on the STARTS system.


**1.13.3.3.2.5.2** **(09-13-2018)**

###### Researching Corporations on the Critical Case List

1. It is the responsibility of the submission processing centers to research corporations on the Critical Case List. The centers report their findings to National Office via entries in the Corporation Critical Case Screens.

2. The primary research tool in the centers is the Integrated Data Retrieval System (IDRS). Performing IDRS research can resolve most of the outstanding critical case returns. The Business Master File (BMF) should contain entries within nine months after the end of the corporation’s accounting period. Transactions can include the date associated with the filing of the return or actions taken in non-filing situations. The SOI unit should try to find or determine the reason a Critical Case return has not posted to the BMF.

3. The physical search for returns in Files are helpful in the search process.


**1.13.3.3.2.5.2.1** **(09-13-2018)**

###### Initiating the Appropriate ECC-MTB Transcript Request

1. With the proper name, employer identification number (EIN), and tax period, the SOI unit uses command code TXMOD, which will then display a document locator number (DLN) and summary information. If no data are available or more information is needed, the unit requests an ACTRA (Screen display) or a "Specific" MFTRA transcript. A "Specific" MFTRA transcript is a record of a specific type of tax return (i.e., Form 1120) for a specified tax period (e.g., the ending "accounting period" is "200912" or "201012" ).

2. If no information is found, it is possible the EIN or tax period for the corporation is incorrect or different (due to a change). Requesting a "Tax Class" (Type M for 1120 filers) or "Complete" transcript may provide a clue in finding the correct EIN or Fiscal Year-Month (FYM).



1. The term "No Entity" shows that the EIN for which the transcript was requested does not exist on the BMF. First, verify the EIN to identify if the EIN listed on the transcript is the same as that requested. If it is incorrect, submit a new "Specific" transcript request using the correct EIN. Otherwise the probable explanation is that someone has recorded incorrectly the EIN or the corporation’s entity status has changed. Then the unit can use the EINAD command to discover the new EIN. If available, micro-alpha tapes are also helpful.

2. If the "Specific" transcript shows "No Record," this shows that the EIN that the unit requested appears on the BMF; however, transactions were not applicable to the specific tax class and tax period requested. Examining the "Fiscal Month" in which the accounting period ends is useful. If the accounting period, as listed on the transcript, differs from that listed on the Critical Case List, the accounting period on the report may be incorrect. Request a "Complete" or "Tax Class" transcript. It shows the proper accounting period. A corporation may have requested an accounting period change or may be filing a final, part-year return.


3. If they have entered the correct FYM and EIN, and while waiting for a MFTRA, the unit can check STARTS, Unpostables, Rejects, AIMS or any other control database. This can help determine the physical location of a return.

4. Most of the transcripts will show that tax transactions have taken place rather than showing "No Entity" or "No Record." All first time requests for transcripts should be for "Specific" transcripts. The unit should follow all "Specific" transcripts that do not yield a DLN with a request for a "Complete" transcript (except an extension to file).


**1.13.3.3.2.5.2.2** **(09-13-2018)**

###### Analysis of Transcripts

1. Document 6209, IRS Processing Codes and Information, includes a detailed explanation of the use of the various codes for specific applications and processing operations. SOI units (and SOI Coordinators) should confer with Critical Case Returns personnel in National Office to assure an adequate understanding of the codes in this book for critical case return follow-up.

2. For some cases, the transcript will show that the corporation has received or applied for an extended return filing date (i.e., and extension of time for filing). This will show as transaction code 460. The unit continues to request "Specific" transcripts for these cases. They should note this on the critical case list.

3. When a return has posted to the BMF, the DLN will appear along with the TC 150. The unit records this DLN and any re-file DLN. A re-file DLN is present, if the "Control DLN" is different from the "150" DLN.



1. If the corporation filed the return at the researcher’s center (see first two digits of the control DLN), the unit obtains the return (or a copy) and places it under SOI control.

2. If the corporation filed the return at another center, the researcher may update the center on STARTS so it will appear on the appropriate center’s Critical Case List.

3. Once the researcher finds a DLN, he or she orders the return from files or the Federal Records Center (FRC), which may take one to two weeks. While waiting, the unit should recheck IDRS for any control base.

4. If the return is charged out, the unit reorders the return and contacts the area in control of it in an attempt to obtain a photocopy.

5. If charge-out information shows "Block Not In File (BNIF)," or "Document Not in File (DNIF)," the unit requests again the whole block or the return in an attempt to learn the whereabouts of the return.

6. Certain transaction codes also may show the probable location of the return. Some of them include:




      | Transaction Code | Title | Probable Location |
      | :-: | :-: | :-: |
      | 420 (sets "L" freeze) | Examination Indicator | AIMS data will identify submission processing center, or district office, Exam; or Appeals |
      | 424 (sets "L" freeze) | Examination Request Indicator | AIMS data will identify submission processing center, LB&I office, SB/SE office or Appeals |
      | 520 (in combination with "L" freeze) | IRS Litigation Instituted | AIMS data will identify submission processing center, or LB&I or SB/SE offices |
      | 576 (in combination with "L" freeze) | Unallowable Tax Hold | AIMS Data will identify submission processing center, or LB&I or SB/SE offices |
      | 610 (without posted TC 150) | Remittance with Return | Can indicate shelved full-paid return waiting to be processed-not in Returns Files Section |
      | 922 | URP Underreporter | Underreporter |


4. The Audit Information Management System (AIMS) is another source of information about the status of a selected return. If the return information entered is no more than two or three weeks old, the unit contacts the area responsible for associating AIMS requests. They make a request for a photocopy from this function if the return is in its possession. If this return is a "non-select," the SOI unit generates an SCPL through STARTS upon controlling a photocopy.

5. Identification of the filing requirements of a corporation is another method for finding its return. The IRS posts filing requirement codes (FR Codes) to the Entity Section of the Master File to identify the types of returns a taxpayer must file. _Exhibit 1.13.3-8_ lists the codes for Forms 1120 and 1065.



1. The unit examines the name of the corporation as printed near the upper left corner of the transcript. If the name is different from that on the follow-up list, but the accounting period is unchanged, it is possible that the corporation may be operating under a new name. Checking the Old (prior) Name control field on the transcript can verify this.

2. Sometimes the IRS may not require a corporation to file, or the corporation has changed status from an 1120 to another return type (e.g., 990-C). Then, the filing requirement might read "none," or the screen does not list the 1120. The unit annotates this on the Critical Case List.

3. A filing requirement, "14" , or TC 590 with a closing code 14, shows this is a subsidiary corporation. The unit checks for a cross reference number. This may give the name of the parent. Researching the parent in Mergent is also useful.


6. If transaction code (TC) 150 is not present on MFTRA, the unit checks for a TC 59X posting with closing codes. This can tell whether a return has been secured or if it is liable for filing. TC 590 shows that the corporation has no current tax liability, and, therefore, the IRS does not require that it file for that period. It can also mean that the return is in reject status, merged, or is in Adjustments. Collections generally enters TC 591 when the corporation has filed for bankruptcy or filed a final return. TC 599 shows that a taxable return was secured. Closing codes will corroborate this status.

7. The unit continues to request periodically MFTRA transcripts or Screen displays, and researches IDRS for a control base or case update. A case history sheet is also kept that shows dates, type of research, and the results.

8. Establishing a control base on IDRS for all aged returns is also helpful. It allows other areas to contact the SOI unit if they have the return. It also gives immediate access to an adjusted (290, 291) DLN, once the transaction posts to the Master File, without having to order another transcript.


**1.13.3.3.2.5.3** **(09-13-2018)**

###### Reporting on Critical Case Research

1. After researching corporations, the centers must report their findings to Statistics of Income in the remarks field on one of the Corporation Critical Case Screens.

2. The returns on the Corporation Critical Case Screens are those which are possibly missing, filing an extension, filing with another company, or not filing at all (due to bankruptcy or lack of tax liability). It is crucial that centers report as much information as possible about a corporation so the National Office analysts can revise the critical case files. These timely updates at the centers will reduce the number of outstanding critical cases and diminish the effort associated with certain critical cases that go unresolved year after year.

3. The submission processing center assists the National Office analysts in their research since many analysts do not have IDRS access and may have difficulty gaining the information otherwise.

4. The centers should continually monitor the status of the outstanding returns and update the remarks field when appropriate. National Office will notify the centers when they can end the research.


**1.13.3.3.2.6** **(09-13-2018)**

##### Corporation Advance Data Requests

1. For each SOI Year study, the SOI edit units must process large returns, with certain sample codes, by the corresponding Corporation Advance Data cutoff date. National Office will notify the centers of these sample codes.


**1.13.3.3.2.7** **(09-13-2018)**

##### Shipping Documents and Magnetic Media

1. Addresses that the SOI units, as well as National Office, use when shipping documents, magnetic media, and other materials, are listed in _Exhibit 1.13.3-6_, "Shipping Schedule." The units complete Form 3210 (or STARTS facsimiles) and Form 3220 (applicable parts), "Mass Storage Media," to control the documents and magnetic tapes shipped among the processing centers.


**1.13.3.3.3** **(09-13-2018)**

#### Special Projects

1. Special projects require either the photocopying or scanning of specific forms attached to the corporation returns selected for the annual SOI Corporation Study, and the pulling of specific corporation returns for biennial and quadrennial studies.

2. The photocopy instructions stated below for Special Project SOI studies pertain to "paper" filed Form 1120-series returns. Electronically filed (E-Filed) Form 1120-series returns and any associated E-Filed Forms 1118, 5471, 5735, 8858, 8865, and 8975 are already under SOI control in the Ogden database system. Photocopies of these E-Filed documents are not required.


**1.13.3.3.3.1** **(09-13-2018)**

##### Forms 1118 Study, SOI Years 2016 and 2017

1. For the SOI Year 2016 and 2017 studies, SOI will not photocopy documents. SOI edits the "paper-filed" Forms 1118 from scanned images.


**1.13.3.3.3.2** **(09-13-2018)**

##### Forms 5471 Study

1. Beginning with the SOI Year 2006 Corporation Study, SOI will not photocopy Forms 5471. SOI edits "paper-filed" Forms 5471 from scanned images.


**1.13.3.3.3.3** **(09-13-2018)**

##### Forms 8865 Study

1. Beginning with the SOI Year 2008 Corporation and Partnership Studies, SOI will not photocopy Forms 8865. SOI edits "paper-filed" Forms 8865 from scanned images.


**1.13.3.3.3.4** **(09-13-2018)**

##### Forms 8858 Study

1. Beginning with the SOI Year 2006 Corporation Study, SOI will not photocopy Forms 8858. SOI edits "paper-filed" Forms 8858 from scanned images.


**1.13.3.3.3.5** **(09-13-2018)**

##### Forms 8975 Study

1. SOI will not photocopy Forms 8975. SOI edits "paper-filed" Forms 8975 from scanned images.


**1.13.3.3.4** **(09-13-2018)**

#### Partnership Returns of Income

1. This section provides instructions to centers for controlling Forms 1065, Partnership Returns of Income; Forms 1065-B, Electing Large Partnerships; and, related documents, for the Tax Year 2017 and 2018 Programs.

2. In this study the Enterprise Computing Center - Martinsburg (ECC-MTB) extracts and reformats partnership data from the Business Master File (BMF). It also does pre-edit processing on the data. ECC-MTB transmits the reformatted data to the Ogden Submission Processing Center where SOI programmers load it into the SOI Partnership on-line editing application.

3. SOI renders all of these Modern e-File (MeF) returns into images, which the SOI editors view in a split-screen environment when editing. In addition, SOI began extracting and loading data from some of the forms and schedules into the partnership application database.

4. The editing of SOI partnership returns occurs at both the Cincinnati and Ogden Submission Processing Centers.

5. Submission processing center SOI control units hold the selected partnership documents. They are responsible for ensuring that all of the attachments are associated with either a "parent" Form 1065, U.S. Return of Partnership Income, or Form 1065-B, U.S. Return of Income for Electing Large Partnerships. Attachments include the following:



   - Schedule B-1, Information on Partners Owning 50% or More of the Partnership

   - Schedule C (Form 1065), Additional Information for Schedule M-3 Filers

   - Schedule D (Form 1065), Capital Gains and Losses

   - Schedule F (Form 1040), Profit or Loss From Farming

   - Schedule M-3 (Form 1065), Net Income (Loss) Reconciliation for Certain Partnerships

   - Form 1125-A, Cost of Goods Sold

   - Form 3468, Computation of Investment Credit

   - Form 4562, Depreciation and Amortization

   - Form 4797, Sales of Business Property

   - Form 5884, Work Opportunity Credit

   - Form 6765, Credit for Increasing Research Activities

   - Form 8820, Orphan Drug Credit

   - Form 8824, Like-Kind Exchange

   - Form 8825, Rental Real Estate Income and Expenses of a Partnership or an S Corporation

   - Form 8834, Qualified Plug-In Electric and Electric Vehicle Credit

   - Form 8844, Empowerment Zone Employment Credit

   - Form 8845, Indian Employment Credit

   - Form 8846, Credit for Employer Social Security and Medicare Taxes Paid on Certain Employee Tips

   - Form 8864, Biodiesel and Renewable Diesel Fuels Credit

   - Form 8874, New Markets Credit

   - Form 8881, Credit for Small Employer Pension Plan Startup Costs

   - Form 8882, Credit for Employer-Provided Child Care Facilities and Services

   - Form 8896, Low Sulfur Diesel Fuel Production Credit

   - Form 8903, Domestic Production Activities Deduction

   - Form 8910, Alternative Motor Vehicle Credit

   - Form 8911, Alternative Fuel Vehicle Refueling Property Credit

   - Form 8925, Report of Employer-Owned Life Insurance Contracts

   - Form 8936, Qualified Plug-In Electric Drive Motor Vehicle Credit

   - Form 8752, Required Payment or Refund Under Section 7519

   - Form 8941, Credit for Small Employer Health Insurance Premiums


6. National Office will notify Cincinnati and Ogden edit unit managers when to begin processing partnership returns the selecting submission processing centers control. A Partnership Study is completed when analysts from National Office conduct a "closeout" . _IRM 1.13.3.3.4.3_ contains more information about this.


**1.13.3.3.4.1** **(09-13-2018)**

##### Special Editing Instructions

1. Sometimes partnership returns are selected a second time, though with the assignment of a different cycle, page, and line. The SOI edit unit processes these returns according to the instructions in the Statistical Editing of Partnerships document. These returns have certain identification data that the edit unit collects for statistical purposes. The SOI control units treat these duplicates as regular returns, but should note on the Selection Sheets and in STARTS that ECC-MTB has selected a return for a second time.

2. When the Ogden Submission Processing Center computer systems analyst loads a new cycle, the analyst notifies the Cincinnati and Ogden edit unit managers of the new set of cycles of returns now available for editing. This insures that the manager only orders returns corresponding to the database records. The manager requests returns via BMF STARTS.

3. The edit unit uses STARTS to release partnerships returns. Return release lists are produced from STARTS similar to what is done for 1040 returns after the completion of editing and quality review.


**1.13.3.3.4.2** **(09-13-2018)**

##### Scanning Documents Before Edit and Test Resolution

1. Before editing, the centers scan partnership returns.

2. Scanning creates an historical file for later study by both SOI National Office personnel and SOI customers. Each processing center is responsible for determining whether the SOI control unit, or edit unit, scans the selected returns. Only IRS personnel can scan returns.

3. SCRIPS scans Schedules K-1, Partner's Share of Income, Credits, Deductions, etc. These images are merged with the SOI selected partnership images.

4. Scanning procedures include:



1. Viewing the return on the computer monitor while scanning the return to make sure that any pages requiring re-scanning (e.g., two pages on top of each other, or a slanted page) are completed at that time.

2. Examining the entire scanned image of the return and all supporting schedules and attachments **(except Schedules K-1)** during the quality review phase to ensure all the images are readable, including the pages oriented in landscape mode.

3. Reviewing STARTS reports that identify returns available for releasing.


**1.13.3.3.4.3** **(09-13-2018)**

##### Closeout Procedures

1. Each study year there is a preliminary editing cutoff in mid-November. All returns selected through ECC-MTB selection Cycle 40 are edited in time to meet the preliminary data cutoff date. To ensure inclusion of all available returns selected through this cycle, the centers do the following:




| Function | Action |
| :-: | :-: |
| SOI edit units | Using BMF STARTS, order all partnership returns selected through the cutoff cycle in time to edit them prior to the established cutoff date. |
| SOI control units | Provide all returns immediately that the SOI edit unit orders |
| SOI edit units | Complete editing of all available returns up to and including the cutoff cycle **before** editing returns from later cycles |

2. Close to the program completion deadline, National Office will notify the centers of any partnership documents that ECC-MTB did not sample, but that they should pull and process. In addition, the centers will continue looking for the remaining missing selected partnerships. Upon finding these documents, the control units will send them to the edit units. Editing of partnership returns for a specific tax year normally finishes at the end of the following January. For example, editing of Tax Year 2017 partnership returns begins in July 2018 and ends in January 2019.

3. The centers retain documents according to the Records Control Schedule IRM.


**1.13.3.3.5** **(09-13-2018)**

#### Controlling Documents for International Special Studies

1. Forms 1042-S, Foreign Person's U.S. Source Income Subject to Withholding



1. The Ogden Submission Processing Center sends documents showing tax remitted from foreign governments under treaty agreements to SOI National Office. Information about the tax remitted, the date of payment and the name of the country are part of the shipment.

2. See _Exhibit 1.13.3-6_ in this document and IRM 3.30.123, Processing Timeliness: Cycles, Criteria, and Critical Dates, for shipping details.


2. Form 1118, Foreign Tax Credit-Corporations



1. See _IRM 1.13.3.3.3.1_ for an explanation of this project.

2. SOI edits the **paper-filed** Forms 1118 from scanned images.


3. Form 5471, Information Returns of U.S. Persons With Respect To Certain Foreign Corporations



1. See _IRM 1.13.3.3.3.2_ for an explanation of this project.


4. Forms 8805, Foreign Partners Information Statement of Section 1446 Withholding Tax



1. The Ogden Submission Processing Center sends every Form 8805 table and listing to SOI National Office.


5. Form 8832, Entity Classification Election



1. This SOI study is continuous; it involves editing every filed Form 8832. See IRM 1.13.2.5.13 and Exhibits1.13.2-28 and 1.13.2-29 in IRM 1.13.2 for information about the SOI editing schedule.

2. At the Cincinnati Submission Processing Center, the Entity and Entity Unpostables Units process the Forms 8832 and then send the documents directly to Files. The Cincinnati SOI Control Unit requests the Forms 8832 and attachments from Files. Files sends the returns and attachments to the SOI unit for scanning. After scanning, the SOI Control Unit returns the documents to Files.



      ### Note:



      When Forms 8832 are filed double-sided, **it is crucial the Cincinnati SOI unit scans both sides** of the Form 8832. See IRM 3.13.2.26, Form 8832, Entity Classification Election, for instructions on processing this document.

3. The SOI Branch at the Ogden Submission Processing Center requests the original Form 8832 documents, including attachments, from the Ogden Files area for scanning after the Ogden Entity and Entity Unpostables Units process the documents. One SOI unit scans these documents, and another SOI unit edits the information from the scanned images. The Branch returns the documents to Files after scanning.

4. The Ogden SOI Branch edits all the paper-filed Forms 8832 from scanned images, regardless of the original filing location of the documents.



      ### Note:



      When Forms 8832 are filed double-sided, **it is crucial the Ogden SOI unit scans both sides** of the Form 8832 .See IRM 3.13.2.26, Form 8832, Entity Classification Election, for instructions on processing this document.


6. Forms 8865, Returns of U.S. Persons With Respect To Certain Foreign Partnerships



1. See _IRM 1.13.3.3.3.3_ for an explanation of this project.


**1.13.3.4** **(09-13-2018)**

### Controlling Documents in the SOI Individual and Tax Exempt Branch Programs

1. This section of the Internal Revenue Manual (IRM) describes the documents selected for the Statistics of Income (SOI) Individual Programs.


**1.13.3.4.1** **(09-13-2018)**

#### Selected Documents

1. Studies in this program include the annual Individual/Sole Proprietorship Study, quadrennial Individual Foreign Study and annual Sales of Capital Assets (SOCA) Study. Some documents that SOI edits in its individual income tax return samples are:



   - Forms 1040 and 1040A, U.S. Individual Income Tax Returns

   - Form 1040EZ, Income Tax Returns for Single and Joint Filers with No Dependents

   - Schedule A, Itemized Deductions

   - Schedule B, Interest and Dividend Income

   - Schedule C, Profit or Loss From Business

   - Schedule D, Capital Gains and Losses

   - Form 1116, Foreign Tax Credit

   - Form 2555, Foreign Earned Income

   - Form 4562, Depreciation and Amortization


**1.13.3.4.2** **(09-13-2018)**

#### Individual Income Tax Program

1. Sampling begins in Cycle 201804 for the Tax Year (TY) 2017 Individual/Sole Proprietorship Study. SOI edit units process all of the selected documents, beginning with the 201804 pull, between May 2018 and February 2019. _Exhibit 1.13.3-9_ contains information about the editor training and program deadlines.

2. For TY 2017, the edit units at the Austin, Cincinnati, Fresno, Kansas City, and Ogden Submission Processing Centers process the returns that SOI selected for the sample. These centers will also edit many of these returns for the Sales of Capital Assets (SOCA) study between September 2018 and August 2019.

3. When the edit units begin production, the editing system (called PRISM) selects for editing some Forms 1040EZ, 1040A and 1040, which the SOI control units normally do not pull. PRISM transmits this information to STARTS each cycle. The SOI control units generate Forms 1040EZ, 1040A and 1040 charge-outs from STARTS and pull the returns. Upon controlling these documents, the control unit updates STARTS. This action makes them available for ordering.


**1.13.3.4.2.1** **(09-13-2018)**

##### Special Photocopying Instructions

1. SOI units photocopy documents for several projects that are part of the major studies. _Exhibit 1.13.3-6_ provides the photocopying criteria and shipping addresses. Timely photocopying, shipping, and updating of STARTS ensures the documents are available for either ordering or releasing.


**1.13.3.4.2.2** **(09-13-2018)**

##### Special Closeout Procedures

1. During 2018 and 2019, while the SOI control units and edit units at the submission processing centers are controlling and editing returns, the Cincinnati computer programmers are carrying out special closeout procedures for both the Tax Year (TY) 2016 and 2017 programs, respectively.


**1.13.3.4.2.2.1** **(09-13-2018)**

###### Tax Year 2016

1. Editing of returns for the TY 2016 Individual SOI program begins in July 2017. During 2017 and 2018 there are several program completion dates that the submission processing centers have to meet. _Exhibit 1.13.3-9_ and _Exhibit 1.13.3-10_ describe the deadlines.

2. The Individual Programs Development staff meets the TY 2016 Individual Advance Data closeout deadline by:



1. Scheduling the PRISM Advance Data computer run (that SOI National Office will determine at a later date).

2. Creating a file from the computer run, which contains all of the records on PRISM for cycles 201704 through 201738.

3. Assigning, per National Office direction, the "actual processing status" code to the return status indicator (RSI) field for each record.

4. Leaving the return status indicator (RSI) fields "null" for all of the records on the file that the processing centers did not completely process.

5. Setting only the extraction cycle indicator field for complete records.

6. Employing File Transfer Protocol (FTP) to send the file and a count of the file report to SOI National Office. After reviewing the file, SOI National Office will transmit a copy of the file to the Office of Tax Analysis (OTA) in Treasury and to other users.


3. For the TY 2016 Complete Report closeout, the Individual Programs Development staff does the following:



1. Schedules the PRISM Complete Report computer run (that SOI National Office will determine at a later date), which creates a file that contains all of the records on PRISM for cycles 201704 through 201752.

2. Leaves the return status indicator (RSI) fields "null" for all of the records on the file that the edit units did not completely process.

3. Sets the extraction cycle indicator field for each record.

4. Employs File Transfer Protocol (FTP) to send the file and a count of the file report to SOI National Office. After reviewing the file, SOI National Office will transmit a copy of the file to the Office of Tax Analysis (OTA) in Treasury and to other users.


**1.13.3.4.2.2.2** **(09-13-2018)**

###### Tax Year 2017

1. Editing of returns for the TY 2017 Individual SOI program begins in May 2018. During 2018 and 2019 there are several program completion dates that the processing and non-processing centers have to meet. _Exhibit 1.13.3-9_ and _Exhibit 1.13.3-10_ describe the deadlines.

2. The Individual Programs Development staff meets the TY 2017 Individual Advance Data closeout deadline by:



1. Scheduling the PRISM Advance Data computer run (that SOI National Office will determine at a later date).

2. Creating a file from the computer run, which contains all of the records on PRISM for cycles 201804 through 201838.

3. Assigning, per National Office direction, the "actual processing status" code to the return status indicator (RSI) field for each record.

4. Leaving the return status indicator (RSI) fields "null" for all of the records on the file that the processing centers did not completely process.

5. Setting only the extraction cycle indicator field for complete records.

6. Employing File Transfer Protocol (FTP) to send the file and a count of the file report to SOI National Office. After reviewing the file, SOI National Office will transmit a copy of the file to the Office of Tax Analysis (OTA) in Treasury and to other users.


3. For the TY 2017 Complete Report closeout, the Individual Programs Development staff does the following:



1. Schedules the PRISM Complete Report computer run (that SOI National Office will determine at a later date), which creates a file that contains all of the records on PRISM for cycles 201804 through 201854.

2. Leaves the return status indicator (RSI) fields "null" for all of the records on the file that the edit units did not completely process.

3. Sets the extraction cycle indicator field for each record.

4. Employs File Transfer Protocol (FTP) to send the file and a count of the file report to SOI National Office. After reviewing the file, SOI National Office will transmit a copy of the file to the Office of Tax Analysis (OTA) in Treasury and to other users.


**1.13.3.4.2.3** **(09-13-2018)**

##### Controlling Files and Tapes at the Cincinnati Submission Processing Center

1. The Cincinnati Submission Processing Center controls all incoming files from the Enterprise Computing Center - Martinsburg (ECC-MTB), including those for the Project Individual SOI Modernization (PRISM) system and the Statistics of Income Automated Return Tracking System (STARTS), and transmits composite data files to National Office as directed.

2. Cincinnati acknowledges receipt of all the files that the ECC-MTB sends or transmits. If the center cannot read, or correctly process, the files, it immediately contacts the Network Operations Command Center (NOCC) to request replacement tapes.

3. The Mass Media and Control Handbook IRM contains instructions for completing a Form 3220, Mass Storage Media, that the center sends along with the files, if it sent the files on magnetic tapes.

4. _Exhibit 1.13.3-6_ lists the National Office addresses. Cincinnati should follow a procedure that ensures the most expeditious receipt of the data for processing in National Office. The preferred procedure is File Transfer Protocol (FTP).

5. _Exhibit 1.13.3-11_ contains the Disposition Schedule, which insures that the centers maintain reports and tapes for a specific period to meet all program requirements before their disposition.


**1.13.3.4.3** **(09-13-2018)**

#### Special Studies

1. Some returns in the TY 2016 Individual/Sole Proprietorship Study are part of special studies. One is the Sales of Capital Assets (SOCA) study.


**1.13.3.4.3.1** **(09-13-2018)**

##### Sales of Capital Assets (SOCA) Study

1. The SOI sampling program at the Enterprise Computing Center - Martinsburg (ECC-MTB) identifies returns in the Sales of Capital Assets (SOCA) Panel Study. Distinguishing these returns from others at this early stage enables SOI edit units to plan more effectively the completion of this annual program. All these returns are edited first through the Project Individual SOI Modernization (PRISM) on-line editing system.

2. PRISM also identifies returns for the SOCA study. On occasion, the ECC-MTB sampling program does not identify some panel returns because the information is incomplete, inaccurate or unexpected. The SOI edit sites flag these returns during editing (See _Exhibit 1.13.3-12_).

3. Editing of SOCA returns occurs on a first-in, first-out (FIFO) basis. Immediately following complete editing, the centers ship the original returns back to the selecting center through STARTS. They do not return photocopies, but instead destroy them after the program completion date.


**1.13.3.4.3.2** **(09-13-2018)**

##### National Research Program

1. The National Research Program (NRP) selects some of the returns in the SOI 1040 sample each year. The NRP column on the IMF STARTS Release Workgroup Control Sheet identifies returns the SOI edit units send to the NRP unit at the Cincinnati Submission Processing Center. The address of the NRP unit is below:



> Attn.: NRP Unit - Stop 826G
>
> Internal Revenue Service
>
> 201 W. Rivercenter Blvd.
>
> Covington, KY 41019


**1.13.3.4.4** **(09-13-2018)**

#### Controlling Forms 706 and 709

1. Forms 706, United States Estate Tax Returns



1. Estate tax returns are processed at the Cincinnati Submission Processing Center in 2017 and 2018 on a first-in, first-out basis, and released back to the selecting center within six (6) weeks of receipt of the shipment in the edit unit. Priority is given to returns filed for victims of terrorist attacks, and to returns with gross estates of $5.49 million or more. Timely updating of STARTS is important because delays in the SOI processing adversely affect the acquisition of these documents by other IRS functions, such as SB/SE.

2. On occasion, a return may not contain all of the schedules or related documents that require editing. The edit unit manager determines whether the unit enters the available information into the editing system, or holds the information until the missing schedules are found. In some cases, the manager may decide to contact the preparer of the return to obtain missing information.

3. The center scans all estate tax returns, which SOI selected for processing, before editing. After scanning a group of returns, the edit unit verifies the batch by comparing the SSNs with those listed on the Form 706 Image List. It reviews each image for legibility and completeness before releasing the return to the edit unit. The unit re-scans returns if some images are illegible.

4. Both the control units and edit units photocopy only on an exception basis. Situations arise when only a photocopy is available for SOI processing. For example, another function requests the original return, making it unavailable for shipment; or, the edit unit cannot process completely the document within six weeks. In those cases when a unit must photocopy, it needs to make clear and legible photocopies because it may have difficulty obtaining released, or re-filed, returns. Illegible photocopies hinder the unit’s editing task, including meeting its program deadline.

5. The units can use the checklist below when scanning or photocopying Forms 706 and attachments.




      | Information Items | Scanned/Photocopied<br> (Yes/No) |
      | :-: | :-: |
      | All pages, front and back of Forms 706 |  |
      | All attachments and continuation sheets for Schedules A to S |  |
      | Forms 712 |  |
      | Death Certificate |  |
      | Will |  |
      | Trust Instruments |  |
      | All gift tax returns (Forms 709) and attachments |  |
      | Any additional information provided by the filer detailing the assets of the estate (real estate appraisals are not necessary) |  |


2. Forms 709, United States Gift (and Generation-Skipping Transfer) Tax Returns



1. The SOI Control unit at the Cincinnati Submission Processing Center uses STARTS to obtain information about the pulling of taxpayer folders that contain Forms 709.

2. The SOI edit unit at the center uses STARTS to order the selected documents that it will edit.

3. Either the edit unit or control unit at the center scans all of the returns in the study. After scanning a group of returns, it compares the SSNs with those listed on the Form 709 Image List to verify completion of scanning of the returns in a STARTS release workgroup. It also reviews each image for legibility and completeness before releasing each return in the workgroup. The unit re-scans returns if some images are illegible.

4. Both the control unit and edit unit photocopy only on an exception basis. Situations may arise when only a photocopy is available for SOI processing. In those cases where a unit must photocopy, the unit needs to make clear and legible photocopies, because it may have difficulty obtaining the released or re-filed original. Illegible photocopies hinder the editing task. In cases where photocopying of returns is necessary, all gift tax returns present in a taxpayer folder, as well as all attachments, are copied.

5. Upon completion of the editing task, STARTS releases the returns back to the originating center.


**1.13.3.4.5** **(09-13-2018)**

#### Controlling the Form 990 Series and Form 4720

1. This section describes the controlling and shipping of Forms 990, 990-PF, 990-T, and 4720. _Exhibit 1.13.3-13_ and _Exhibit 1.13.3-14_ specify project start-up dates and cutoff dates by cycle for these documents. Each return sampling cycle, the SEIN database is searched for images of selected returns. A code is inserted into STARTS indicating the presence or absence of an image. The SOI control clerk at the Ogden Submission Processing Center (OSPC) will receive return charge-outs for any returns not having a SEIN image and will search for paper copies stored on holding shelves prior to sending returns back to the Files function. Retrieved paper returns are forwarded to the SEIN unit, scanned, and then returned to the SOI control clerk. The control clerk will hold paper copies until fact-of-editing from a SEIN image is verified.

2. For each of the Forms 990 series and 4720 studies, the SOI control clerk periodically reviews reports from STARTS that list all selected returns having no image available. If the paper return was not retrieved from the holding shelves and sent to SEIN for scanning, the SOI control clerk requests the paper return from Files. OSPC must place special emphasis on accounting for all selected returns, especially those critical cases with sample code classifications of 37 and 46 (Form 990); 79 (Form 990-T); 16, 17, and 23 (Form 990-PF).


**1.13.3.4.6** **(09-13-2018)**

#### Controlling Documents for Domestic Special Studies

1. Forms 8038 and 8038-G



1. Taxpayers file these forms at the Ogden Submission Processing Center (OSPC). If the other centers receive these forms, they mail them to Ogden.

2. Both control units and edit units use STARTS to control these forms.


**Exhibit 1.13.3-1**

### Enterprise Computing Center - Martinsburg (ECC-MTB) Files

**Business Master File (BMF)**

| File Name |  | Run<br> Number | Description | Destination |
| :-: | :-: | :-: | :-: | :-: |
| Form 706 |  | 080-71-16 | Data used in editing documents | Downloaded in Ogden |
| Form 709 |  | 080-7H-15 | Data used in editing documents | Downloaded in Ogden |
| Forms 990-PF |  | 080-7H-11 | Data used in editing documents | Downloaded in Ogden |
| Forms 990/990EZ |  | 080-7H-12 | Data used in editing documents | Downloaded in Ogden |
| Forms 990-T |  | 080-7H-13 | Data used in editing documents | Downloaded in Ogden |
| Partnership Tickler |  | 080-70-18 | Set of records for matching routine | Maintained with SOI sampling program |
| Partnership Edit<br> (Forms 1065 and 1065-B) |  | 080-7B-11 | Reformatted data used in editing documents | Downloaded weekly in Ogden |
| Partnership Research |  | 080-7J-11 | Research | Transmitted to Math Stats |
| Partnership Econ Research<br> (1065 and 1065-B returns) |  | 080-7J-12 and<br> 080-7J-13 | Research | Transmitted to Corporation Statistics Branch |
| Corporation Tickler |  | 080-70-17 | Set of records for matching routine | Maintained with SOI sampling program |
| Corporation Level 5 File |  | 080-70-20 | Level 5 records | File number previously used for another SOI project |
| Corporation Edit<br> (Forms 1120) |  | 080-71-18 | Data used in editing documents | Downloaded in Ogden |
| National Selection Summary<br> (Sample) Counts |  | 080-73-11 | Estimation | Downloaded to Math Stats |
| Corporation Research |  | 080-7I-11 | Research | Transmitted to Math Stats |
| 1120 Corporation Econ Research |  | 080-7I-12 | Research | Transmitted to Corporation Statistics Branch |
| 1120S Corporation Econ Research |  | 080-7I-13 | Research | Transmitted to Corporation Statistics Branch |
| 1120-PC Corporation Econ Research |  | 080-7I-14 | Research | Transmitted to Corporation Statistics Branch |
| 1120-RIC/REIT Corporation Econ Research |  | 080-7I-15 | Research | Transmitted to Corporation Statistics Branch |
| 1120-F Corporation Econ Research |  | 080-7I-16 | Research | Transmitted to Corporation Statistics Branch |
| 1120-L Corporation Econ Research |  | 080-7I-17 | Research | Transmitted to Corporation Statistics Branch |
| 1120-C Sample Control File |  | 080-7D-11 | Data used in editing documents | Transmitted to Corporation Statistics Branch |
| 1120-C Research File |  | 080-7D-12 | Research | Transmitted to Corporation Statistics Branch |
| Form 3520<br> (Quarterly) |  | 080-7E-11 | Data used in editing documents | National Office |
| Form 3520-A (Quarterly ) |  | 080-7N-11 | Data used in editing documents | National Office |
| Form 4720 |  | 080-7H-16 | Data used in editing documents | Downloaded in Ogden |
| Form 4720-A |  | 080-7H-19 | Data used in editing documents | Downloaded in Ogden |
| Form 4720-A (one-time run to include all PY 2013 filings) |  | 123-16-11 | Data used in editing documents | Obsolete |
| Forms 8038 |  | 080-71-25 | Data used in editing documents | National Office |
| Forms 8038-G |  | 080-71-26 | Data used in editing documents | National Office |
| Forms 8038-T |  | 080-71-27 | Data used in editing documents | National Office |
| Forms 8038-CP |  | 080-71-29 | Data used in editing documents | National Office |
| Forms 8038-B |  | 080-71-30 | Data used in editing documents | National Office |
| Forms 8038-TC |  | 080-71-31 | Data used in editing documents | Downloaded in Ogden |
| BMF Sample Control |  | 080-72-14 | Data used in controlling documents (STARTS) | Downloaded in Ogden |
| TC 976 Corporation Research |  | 080-7K-11 | Research | Downloaded in Ogden |
| SOI Corporation MeF |  | N/A | Data used in editing electronically filed corporation returns | Downloaded in Ogden |

**Individual Master File (IMF)**

| File Name | Run<br> Number | Description | Destination |
| :-: | :-: | :-: | :-: |
| IMF Selected Returns Control Data | 080-54-16 | Data used in controlling documents (STARTS) | Cincinnati |
| IMF Return Charge-outs | 080-60-11 | Data used in controlling documents | Centers\* |
| IMF SOI Selection Sheets | 080-54-13 | Data used in controlling documents | Centers\* |
| IMF Returns Data File 1 | 080-66-11 | Data used in editing documents | Cincinnati |
| IMF Returns Data File 2 | 080-66-12 | Data used for state level estimates | Cincinnati |
| IMF Population/Sample Data | 080-52-13 | Data used in controlling the population/sample | Cincinnati |
| IMF - SOI Return data | RDB-40 | Data used in controlling sample records | Cincinnati |
| MTRDB Data | 080-54-29 | Input data used in producing the MTRDB file for SOI | MTRDB Office |
| \*The four submission processing centers that accept paper 1040 returns are: Austin, Fresno, Kansas City, and Ogden. SOI editing of 1040 returns occurs at the Austin, Cincinnati, Fresno, Kansas City,and Odgen submission processing centers. |

**Master List of Files In Part V, Appendix, SOI BMF Sampling Program Specifications (Input Files)**

| File ID | Frequency | Sent To | Name | Layout |
| :-: | :-: | :-: | :-: | :-: |
| 160-00-11 | Created Weekly from BMF Posting’s 160-18-18 output | Runs 160-01, 080-7A, and 080-7D | BMF Sorted Return Transactions | 160-12-15-ENTCAR, followed by one of the CRLs in Table I.1, followed by one of the Trans record layouts in Table I.2. |
| 080-70-17 | Created Semi-Annually by SOI | Run 080-70 | BMF SOI Corporate Tickler | 080-70-17 |
| 080-70-18 | Created Annually by SOI | Run 080-70 | BMF SOI Partnership Tickler | 080-70-18 |

**Master List of Files In Part V, Appendix, SOI BMF Sampling Program Specifications (Output Files)**

| File ID | Frequency | Sent To | Name | Layout |
| :-: | :-: | :-: | :-: | :-: |
| 080-70-11 | Weekly | Run 080-71 | Selected Returns File | 080-70-11, followed by one of the CRLs in Table I.1, followed by one of the Trans record layouts in Table I.2. |
| 080-70-12 | Weekly | Run 080-7H | Exempt Returns File | 080-70-12, followed by one of the CRLs in Table I.1, followed by one of the Trans record layouts in Table I.2. |
| 080-70-13 | Weekly | CA-Dispatch | Controls for run 080-70 | N/A |
| 080-70-14 | Weekly | Run 080-73 | Raw Count Records | 080-70-14 |
| 080-70-15 | Weekly | Run 080-7I | Corporation Research File | 080-70-15, followed by a Corporation Trans record |
| 080-70-16 | Weekly | Run 080-7J | Partnership Research File | 080-70-16, followed by a Partnership Trans record |
| 080-70-19 | Weekly | Run 080-7K | TC 976 Corporation Research File | 080-70-15, followed by a Corporation Trans record |
| 080-71-12 | Weekly (temporary disk) | Run 080-72 | Form 4251 Records | 080-71-12 |
| 080-71-13 | Weekly | Saved in Martinsburg for programmer analysis | Error Records | 080-70-11, followed by one of the CRLs in Table I.1, followed by one of the Trans record layouts in Table I.2. |
| 080-71-15 | Weekly | SOI in DC | Form 706NA Edit File | 080-71-15 |
| 080-71-16 | Weekly | SOI in Ogden | Estate Edit File | 080-71-16 |
| 080-71-18 | Weekly | SOI in Ogden | Corporation Edit File | 080-71-18 |
| 080-71-19 | Weekly | Run 080-7B | Partnership Edit File | 080-71-19 |
| 080-71-20 | Weekly | CA-Dispatch | Controls for run 080-71 | N/A |
| 080-71-22 | Weekly | Run 080-7E | Foreign Trusts File | 080-70-11, followed by the 3520 Trans record |
| 080-71-25 | Weekly | SOI in DC | Private Activity Bonds Edit File | 080-71-25 |
| 080-71-26 | Weekly | SOI in DC | Governmental Bonds Edit File | 080-71-26 |
| 080-71-27 | Weekly | SOI in DC | Arbitrage Rebate Edit File | 080-71-27 |
| 080-71-28 | Weekly | Run 080-7N | Form 3520A File | 080-70-11, followed by the 3520A Trans record |
| 080-71-29 | Weekly | SOI in DC | Credit for Qualified Bond Edit File | 080-71-29 |
| 080-71-30 | Weekly | SOI in DC | Build America Bond Edit File | 080-71-30 |
| 080-71-31 | Weekly | SOI in Ogden | Tax Credit Bond Edit File | 080-71-30 |
| 080-72-12 | Weekly | CA-Dispatch | Controls for run 080-72 | N/A |
| 080-72-14 | Weekly | SOI in Ogden | Sample Control File | 080-72-14 |
| 080-73-11 | Weekly | SOI in DC | National Selection Summary Counts | 080-73-11 |
| 080-73-12 | Weekly | SOI in DC | 1120/1120S National Selection Summary Counts | Obsolete |
| 080-7A-11 | Weekly | Run 080-70 | BMF SOI Extracted Returns | 160-12-15-ENTCAR, followed by one of the CRLs in Table I.1, followed by one of the Trans record layouts in Table I.2. |
| 080-7B-11 | Weekly | SOI in Ogden | Sorted Partnership Edit File | 080-71-19 |
| 080-7D-11 | Weekly | SOI in Ogden | 1120C Sample Control File | 080-7D-11 |
| 080-7D-12 | Weekly | SOI IN DC | 1120C Research File | 080-7D-12 |
| 080-7D-13 | Weekly | SOI in Ogden | LB&I Corp & Part. Control File | 080-7D-13 |
| 080-7D-14 | Weekly | SOI in Ogden | F1042 Control File | 080-7D-14 |
| 080-7D-15 | Weekly | SOI in Ogden | F8703 Control File | 080-7D-15 |
| 080-7E-11 | Quarterly | SOI in DC | Merged Foreign Trusts File | 080-70-11, followed by the 3520 Trans record |
| 080-7H-11 | Weekly | SOI in Ogden | Private Foundations Edit File | 080-7H-11 |
| 080-7H-12 | Weekly | SOI in Ogden | Exempt Organizations Edit File | 080-7H-12 |
| 080-7H-13 | Weekly | SOI in Ogden | 990T Edit File | 080-7H-13 |
| 080-7H-14 | Weekly | SOI in Ogden | Split-Interest Trusts Edit File | 080-7H-14 |
| 080-7H-15 | Weekly | SOI in Ogden | Gift Tax Return Edit File | 080-7H-15 |
| 080-7H-16 | Weekly | SOI in Ogden | Charitable Excise Tax Edit file | 080-7H-16 |
| 080-7H-18 | Weekly | SOI in DC | Fiduciary Edit File | 080-7H-18 |
| 080-7H-19 | Weekly | SOI in DC | Form 4720-A Edit File | 080-7H-19 |
| 080-7H-40 | Weekly | CA-Dispatch | Controls for run 080-7H | N/A |
| 080-7I-11 | Weekly | SOI in DC | Basic Corporation Research File | 080-7I-11 |
| 080-7I-12 | Weekly | SOI in DC | 1120 Corp/Econ Research File | 080-7I-11, followed by the 1120 Trans record |
| 080-7I-13 | Weekly | SOI in DC | 1120S Corp/Econ Research File | 080-7I-11, followed by the 1120S Trans record |
| 080-7I-14 | Weekly | SOI in DC | 1120PC Corp/Econ Research File | 080-7I-11, followed by the 1120PC Trans record |
| 080-7I-15 | Weekly | SOI in DC | 1120R Corp/Econ Research File | 080-7I-11, followed by the 1120REIT Trans record |
| 080-7I-16 | Weekly | SOI in DC | 1120F Corp/Econ Research File | 080-7I-11, followed by the 1120F Trans record |
| 080-7I-17 | Weekly | SOI in DC | 1120L Corp/Econ Research File | 080-7I-11, followed by the 1120L Trans record |
| 080-7J-11 | Weekly | SOI in DC | Basic Partnership Research File | 080-7J-11 |
| 080-7J-12 | Weekly | SOI in DC | 1065 Part/Econ Research File | 080-7J-11, followed by the 1065 Trans record |
| 080-7J-13 | Weekly | SOI in DC | 1065B Part/Econ Research File | 080-7J-11, followed by the 1065B Trans record |
| 080-7K-11 | Weekly | SOI in DC | Basic TC976 Corporation Research File | 080-7I-11 |
| 080-7N-11 | Quarterly | SOI in DC | Merged Form 3520A File | 080-70-11, followed by the 3520A Trans record |
| 123-16-11 | One Time | SOI IN DC | F4720A Control File for 2013<br> (080-7H-19) | Obsolete |
| 123-16-12 | One Time | SOI IN DC | F8703 Control File for 2013<br> (080-7D-15) | Obsolete |

**Exhibit 1.13.3-2**

### Document Status Codes

| **If** the function below controls the document | **Then** the code is |
| :-- | :-- |
| Federal Records Center | 01 |
| Submission Processing Center: Block Not in Files | 02 |
| Submission Processing Center: Document Not in Files | 03 |
| Error Correction | 04 |
| Reject Correction | 05 |
| Entity Control | 06 |
| Unpostables | 07 |
| Accounting | 08 |
| Criminal Investigation | 09 |
| Refund Transcript Review | 10 |
| Notice Review (CP Notices to Taxpayer) | 11 |
| Submission Processing Center: Internal CP Notice | 12 |
| Examination: Form 5546 | 13 |
| Examination: Forms 4251, 2275, etc. | 14 |
| Requester or Submission Processing Center Function Unknown | 15 |
| Schedule K-1 Processing | 16 |
| Wrong Pull (BMF STARTS) | 17 |
| Return is not in order workgroup | 21 |
| Return is not in release workgroup | 22 |
| Incomplete or missing documentation | 24 |
| AIMS (IMF STARTS) | 25 |
| Other | 30 |
| No Doc No Original C/O | 35 |
| Missing from Files (formerly IAP) | 36 |
| Wrong Pull (IMF STARTS) | 50 |

**Exhibit 1.13.3-3**

### CADE 2 Schedule of First Pull and One Week Follow-up Dates

| Processing Year | Enterprise Computing<br> Center - Martinsburg<br> (ECC-MTB) Cycle | First Pull<br> Day 5/Thursday<br> Ending Date | One Week<br> Follow-up Date |
| :-: | :-: | :-: | :-: |
| 2018 | 201801 | 04-Jan-2018 | 15-Jan-2018 |
| 2018 | 201802 | 11-Jan-2018 | 22-Jan-2018 |
| 2018 | 201803 | 18-Jan-2018 | 29-Jan-2018 |
| 2018 | 201804 | 25-Jan-2018 | 05-Feb-2018 |
| 2018 | 201805 | 01-Feb-2018 | 12-Feb-2018 |
| 2018 | 201806 | 08-Feb-2018 | 19-Feb-2018 |
| 2018 | 201807 | 15-Feb-2018 | 26-Feb-2018 |
| 2018 | 201808 | 22-Feb-2018 | 05-Mar-2018 |
| 2018 | 201809 | 01-Mar-2018 | 12-Mar-2018 |
| 2018 | 201810 | 08-Mar-2018 | 19-Mar-2018 |
| 2018 | 201811 | 15-Mar-2018 | 26-Mar-2018 |
| 2018 | 201812 | 22-Mar-2018 | 02-Apr-2018 |
| 2018 | 201813 | 29-Mar-2018 | 09-Apr-2018 |
| 2018 | 201814 | 05-Apr-2018 | 16-Apr-2018 |
| 2018 | 201815 | 12-Apr-2018 | 23-Apr-2018 |
| 2018 | 201816 | 19-Apr-2018 | 30-Apr-2018 |
| 2018 | 201817 | 26-Apr-2018 | 07-May-2018 |
| 2018 | 201818 | 03-May-2018 | 14-May-2018 |
| 2018 | 201819 | 10-May-2018 | 21-May-2018 |
| 2018 | 201820 | 17-May-2018 | 28-May-2018 |
| 2018 | 201821 | 24-May-2018 | 04-Jun-2018 |
| 2018 | 201822 | 31-May-2018 | 11-Jun-2018 |
| 2018 | 201823 | 07-Jun-2018 | 18-Jun-2018 |
| 2018 | 201824 | 14-Jun-2018 | 25-Jun-2018 |
| 2018 | 201825 | 21-Jun-2018 | 02-Jul-2018 |
| 2018 | 201826 | 28-Jun-2018 | 09-Jul-2018 |
| 2018 | 201827 | 05-Jul-2018 | 16-Jul-2018 |
| 2018 | 201828 | 12-Jul-2018 | 23-Jul-2018 |
| 2018 | 201829 | 19-Jul-2018 | 30-Jul-2018 |
| 2018 | 201830 | 26-Jul-2018 | 06-Aug-2018 |
| 2018 | 201831 | 02-Aug-2018 | 13-Aug-2018 |
| 2018 | 201832 | 09-Aug-2018 | 20-Aug-2018 |
| 2018 | 201833 | 16-Aug-2018 | 27-Aug-2018 |
| 2018 | 201834 | 23-Aug-2018 | 03-Sep-2018 |
| 2018 | 201835 | 30-Aug-2018 | 10-Sep-2018 |
| 2018 | 201836 | 06-Sep-2018 | 17-Sep-2018 |
| 2018 | 201837 | 13-Sep-2018 | 24-Sep-2018 |
| 2018 | 201838 | 20-Sep-2018 | 01-Oct-2018 |
| 2018 | 201839 | 27-Sep-2018 | 08-Oct-2018 |
| 2018 | 201840 | 04-Oct-2018 | 15-Oct-2018 |
| 2018 | 201841 | 11-Oct-2018 | 22-Oct-2018 |
| 2018 | 201842 | 18-Oct-2018 | 29-Oct-2018 |
| 2018 | 201843 | 25-Oct-2018 | 05-Nov-2018 |
| 2018 | 201844 | 01-Nov-2018 | 12-Nov-2018 |
| 2018 | 201845 | 08-Nov-2018 | 19-Nov-2018 |
| 2018 | 201846 | 15-Nov-2018 | 26-Nov-2018 |
| 2018 | 201847 | 22-Nov-2018 | 03-Dec-2018 |
| 2018 | 201848 | 29-Nov-2018 | 10-Dec-2018 |
| 2018 | 201849 | 06-Dec-2018 | 17-Dec-2018 |
| 2018 | 201850 | 13-Dec-2018 | 24-Dec-2018 |
| 2018 | 201851 | 20-Dec-2018 | 31-Dec-2018 |
| 2018 | 201852 | 27-Dec-2018 | 07-Jan-2019 |
| 2019 | 201901 | 03-Jan-2019 | 14-Jan-2019 |
| 2019 | 201902 | 10-Jan-2019 | 21-Jan-2019 |
| 2019 | 201903 | 17-Jan-2019 | 28-Jan-2019 |
| 2019 | 201904 | 24-Jan-2019 | 04-Feb-2019 |
| 2019 | 201905 | 31-Jan-2019 | 11-Feb-2019 |
| 2019 | 201906 | 07-Feb-2019 | 18-Feb-2019 |
| 2019 | 201907 | 14-Feb-2019 | 25-Feb-2019 |
| 2019 | 201908 | 21-Feb-2019 | 04-Mar-2019 |
| 2019 | 201909 | 28-Feb-2019 | 11-Mar-2019 |
| 2019 | 201910 | 07-Mar-2019 | 18-Mar-2019 |
| 2019 | 201911 | 14-Mar-2019 | 25-Mar-2019 |
| 2019 | 201912 | 21-Mar-2019 | 01-Apr-2019 |
| 2019 | 201913 | 28-Mar-2019 | 08-Apr-2019 |
| 2019 | 201914 | 04-Apr-2019 | 15-Apr-2019 |
| 2019 | 201915 | 11-Apr-2019 | 22-Apr-2019 |
| 2019 | 201916 | 18-Apr-2019 | 29-Apr-2019 |
| 2019 | 201917 | 25-Apr-2019 | 06-May-2019 |
| 2019 | 201918 | 02-May-2019 | 13-May-2019 |
| 2019 | 201919 | 09-May-2019 | 20-May-2019 |
| 2019 | 201920 | 16-May-2019 | 27-May-2019 |
| 2019 | 201921 | 23-May-2019 | 03-Jun-2019 |
| 2019 | 201922 | 30-May-2019 | 10-Jun-2019 |
| 2019 | 201923 | 06-Jun-2019 | 17-Jun-2019 |
| 2019 | 201924 | 13-Jun-2019 | 24-Jun-2019 |
| 2019 | 201925 | 20-Jun-2019 | 01-Jul-2019 |
| 2019 | 201926 | 27-Jun-2019 | 08-Jul-2019 |
| 2019 | 201927 | 04-Jul-2019 | 15-Jul-2019 |
| 2019 | 201928 | 11-Jul-2019 | 22-Jul-2019 |
| 2019 | 201929 | 18-Jul-2019 | 29-Jul-2019 |
| 2019 | 201930 | 25-Jul-2019 | 05-Aug-2019 |
| 2019 | 201931 | 01-Aug-2019 | 12-Aug-2019 |
| 2019 | 201932 | 08-Aug-2019 | 19-Aug-2019 |
| 2019 | 201933 | 15-Aug-2019 | 26-Aug-2019 |
| 2019 | 201934 | 22-Aug-2019 | 02-Sep-2019 |
| 2019 | 201935 | 29-Aug-2019 | 09-Sep-2019 |
| 2019 | 201936 | 05-Sep-2019 | 16-Sep-2019 |
| 2019 | 201937 | 12-Sep-2019 | 23-Sep-2019 |
| 2019 | 201938 | 19-Sep-2019 | 30-Sep-2019 |
| 2019 | 201939 | 26-Sep-2019 | 07-Oct-2019 |
| 2019 | 201940 | 03-Oct-2019 | 14-Oct-2019 |
| 2019 | 201941 | 10-Oct-2019 | 21-Oct-2019 |
| 2019 | 201942 | 17-Oct-2019 | 28-Oct-2019 |
| 2019 | 201943 | 24-Oct-2019 | 04-Nov-2019 |
| 2019 | 201944 | 31-Oct-2019 | 11-Nov-2019 |
| 2019 | 201945 | 07-Nov-2019 | 18-Nov-2019 |
| 2019 | 201946 | 14-Nov-2019 | 25-Nov-2019 |
| 2019 | 201947 | 21-Nov-2019 | 02-Dec-2019 |
| 2019 | 201948 | 28-Nov-2019 | 09-Dec-2019 |
| 2019 | 201949 | 05-Dec-2019 | 16-Dec-2019 |
| 2019 | 201950 | 12-Dec-2019 | 23-Dec-2019 |
| 2019 | 201951 | 19-Dec-2019 | 30-Dec-2019 |
| 2019 | 201952 | 26-Dec-2019 | 06-Jan-2020 |
| 2020 | 202001 | 02-Jan-2020 | 13-Jan-2020 |

**Exhibit 1.13.3-4**

### Research, Applied Analytics, and Statistics Scanning Projects

| Project | Document<br> Scanned | Application1 | Scanning<br> Location | National Office<br> Contact |
| :-: | :-: | :-: | :-: | :-: |
| Corporation Income Tax (including S Corporations) | SOI sample of Forms 1120, 1120-F, 1120-L, 1120-PC, 1120-REIT, 1120-RIC, and 1120S | DIN2 | Cincinnati; Kansas City; Ogden | C. Wescott |
| Estate Tax | SOI sample of Forms 706 | DIN | Cincinnati | A. Barnes |
| Exempt Organizations (Charitable and Other, Except Private Foundations) 6 | Population of Forms 990 | SEIN3 | Ogden | P. Arnsberger |
| Exempt Organizations (Private Foundations)6 | Population of Forms 990-PF and 4720 | SEIN | Ogden | C. Belmonte |
| Exempt Organizations Unrelated Business Income6 | Population of Forms 990-T | SEIN | Ogden | J. Jackson |
| Gift Tax | SOI Sample of Forms 709 | DIN | Cincinnati | J. Holland |
| LB&I4 | SOI sample of Forms 1120, 1120-F, 1120-L, 1120 PC, 1120S and 1065 | LIN5 | Cincinnati; Ogden | R. Blackwell |
| Partnership Returns of Income | SOI sample of Forms 1065 and 1065-B | DIN | Cincinnati; Ogden | C. Wescott |
| Tax-Exempt Bond Issues6 | Population of Forms 8038, 8038-G, 8038-GC, 8038-T, 8038-CP, 8038-TC, and 8328 | DIN | Ogden | K. Dauberman |
| Foreign Trust<br> Forms 3520/3520-A, 2014 | Population of Forms 3520, 3520-A | DIN | Ogden | D. Holik |
| Applicable Insurance Contracts | Population of Forms 8921 and 8922 | SEIN | Ogden | P. Arnsberger |
| Schedule K-17 | SCRIPS records8 | KIN9 | Cincinnati; Ogden | R. Blackwell |
| 1 In addition to the scanners, or scanning systems, the centers use the Statistics of Income Automated Return Tracking System (STARTS) to generate SOI charge-outs and monitor the controlling of the documents.<br>2 The acronym for Distributed Processing System Image Network.<br>3 The acronym for SOI Exempt Organization Return Image Network.<br>4 The acronym for Large Business and International.<br>5 The acronym for LB&I Image Network.<br>6 SOI partners with Tax Exempt and Governmental Entities (TEGE) to produce the images.<br>7 Attached to Forms 1120S and 1065.<br>8 The acronym for Service Center Recognition/Image Processing System. KIN stores the images of the Schedules K-1 that SCRIPS produces.<br>9 The acronym for K-1 Image Network. |

**Exhibit 1.13.3-5**

### Alert Page

(1) Below is a facsimile of the Alert Page that a center inserts at the location of known missing pages in a return before the commencement of scanning.

|     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |  |
| ALERT |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
| Missing Pages or Information<br> from the<br> Taxpayer or Submission Processing |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
| What is Missing? |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  | SOI Special Search was unable to secure the missing pages or information needed. |  |  |
|  |  |  |  |  |  |  |
|  |  | Date: |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  | Approved signature: |  |  |  |  |
|  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |

**Exhibit 1.13.3-6**

### Shipping Schedule of Statistics of Income (SOI) Projects

| Documents, tapes, etc. | Addresses | Instructions |
| :-: | :-: | :-: |
| Tapes (three or less), microfilm, diskettes, documentation, and requests for data, correspondence, acknowledgments, tax returns in envelopes, status reports, envelope mail not otherwise listed above | Internal Revenue Service, OS:RAAS:DMD<br> Attn.: L. Pezdirtz<br> 1111 Constitution Ave., N.W.<br> K-4100/045<br> Washington, D.C. 20224-0002 | Based on project requirements the sender writes on the labels the SOI Study Year, Project and a brief description of the contents (including volume) |
| Tapes (more than three), tape transmittal verifications, computer run tail sheets, tax returns in boxes, letters of confirmation, training information, all bulk materials including anything shipped in boxes | Internal Revenue Service, OS:RAAS:DMD<br> Attn.: L. Pezdirtz<br> 1111 Constitution Ave., N.W.<br> K-4100/045<br> Washington, D.C. 20224-0002 | Based on project requirements the sender writes on the labels the SOI Study Year, Project and a brief description of the contents (including volume) |
| First Pull Statistics | Via email to the Partnership and Special Projects Section, Corporation, Partnership, and International Branch | Weekly |
| Partnership study administrative mail to National Office | Internal Revenue Service, OS:RAAS:S<br> Attn.: N. Shumofsky<br> 1111 Constitution Ave., N.W.<br> K-4100/138<br> Washington, D.C. 20224-0002 | Per project requirements |
| Forms 1065 selected at the Cincinnati Submission Processing Center | Attn.: Partnership Study, Mail Stop 22F<br> Internal Revenue Service<br> 201 W. Rivercenter Blvd.<br> Covington, KY 41019 | Per project requirements |
| Forms 1065 selected at the Ogden Submission Processing Center | Attn.: Partnership Study<br> M/S 6112 SOI Support<br> Internal Revenue Service<br> Ogden Submission Processing Center<br> 1160 W. 1200 S.<br> Ogden, UT 84201<br> (or, if bulk mail:<br> M/S 6112 SOI Support<br> Internal Revenue Service<br> Ogden Submission Processing Center<br> 1973 North Rulon White Blvd.<br> Ogden, UT 84404 (84201 for United States Postal Service)) | Per project requirements |
| Form 5471 Study |  | See _IRM 1.13.3.3.3.2_ for information |
| Form 8858 Study |  | See _IRM 1.13.3.3.3.4_ for information |
| Form 8865 Study |  | See _IRM 1.13.3.3.3.3_ for information |
| Form 8975 |  | See _IRM 1.13.3.3.3.5_ for information about the Forms 8975 study |
| PRISM-identified High Income Non-Taxable (HINT) and Large Returns at the SOI processing centers (Report H) | Attn.: S/B SOI Clerical Team<br> Ogden Submission Processing Center<br> M/S 6112<br> 1160 West 1200 South<br> Ogden, UT 84201 | Monthly shipments from Austin and Fresno of photocopied 1040 returns that PRISM identifies for the HINT Returns Study (Note "HINT Returns for TY 20XX SOI Individual Program" in the Remarks Section of the Form 3210 that accompanies the photocopied returns) |
| Selected Forms 1040 edited at the Austin Submission Processing Center | Attn.: SOI Unit, Stop 6721<br> Austin Submission Processing Center<br> 3651 South I-35<br> Austin, TX 78767 | Edit units control paper returns and order workgroups of either paper or MeF returns in STARTS |
| Selected Forms 1040 edited at the Cincinnati Submission Processing Center | Attn.: SOI Branch, Stop 22F<br> Cincinnati Submission Processing Center<br> 201 W. Rivercenter Blvd.<br> Covington, KY 41019 | Edit units control paper returns and order workgroups of either paper or MeF returns in STARTS |
| Selected Forms 1040 edited at the Fresno Submission Processing Center | Attn.: SOI Unit, Stop 341<br> Fresno Submission Processing Center<br> 5045 E. Butler<br> Fresno, CA 93888 | Edit units control paper returns and order workgroups of either paper or MeF returns in STARTS |
| Selected Forms 1040 edited at the Kansas City Submission Processing Center | Attn.: SOI Edit Unit, Stop 6130<br> Kansas City Submission Processing Center<br> (a) for UPS and truck freight deliveries only:<br> 333 W. Pershing Road<br> Kansas City, MO 64108<br> (b) for other administrative mail:<br> P.O. Box 24551<br> Kansas City, MO 64131 | Edit units control paper returns and order workgroups of either paper or MeF returns in STARTS |
| Selected Forms 1040 edited at the Ogden Submission Processing Center | Attn: SOI Edit Unit, M/S 6111<br> 1160 W. 1200 S.<br> Ogden, UT 84201 | Edit units control paper returns and order workgroups of either paper or MeF returns in STARTS |
| PRISM data on composite tapes | Attn.: Tape Library<br> Cincinnati Submission Processing Center<br> 201 W. Rivercenter Blvd.<br> Covington, KY 41019 | Upon notification from National Office |
| Selected Forms 706 at the Cincinnati Submission Processing Center during the First Pull period | Attn.: SOI Branch, Stop 22F<br> Internal Revenue Service<br> Cincinnati Submission Processing Center<br> 201 W. Rivercenter Blvd.<br> Covington, KY 41019 | STARTS creates shipments each cycle |
| Selected Forms 709 at the Cincinnati Submission Processing Center | Attn.: SOI Branch, Stop 22F<br> Internal Revenue Service<br> Cincinnati Submission Processing Center<br> 201 W. Rivercenter Blvd.<br> Covington, KY 41019 | STARTS creates shipments |
| Special Forms 709 | Internal Revenue Service, OS:RAAS:S<br> Attn.: J. Holland<br> 1111 Constitution Ave., N.W.<br> K-4100/175<br> Washington, D.C. 20224-0002 | Analyst provides information on the selection and shipment of these special forms |
| Selected Forms 990 at the Ogden Submission Processing Center | SOI units in Ogden follow local center procedures because shipments occur within the same building | Edit units use STARTS to order shipments from the Ogden Submission Processing Center SOI Control Unit |
| Special Forms 990 | Requestor’s address, or,<br> Internal Revenue Service, OS:RAAS:S<br> Attn.: P. Arnsberger<br> 1111 Constitution Ave., N.W.<br> K-4100/171<br> Washington, D.C. 20224-0002 | Analysts provide information on the selection and shipment of these special forms |
| Selected Forms 990-PF at the Ogden Submission Processing Center | SOI units in Ogden follow local center procedures because shipments occur within the same building | Edit units use STARTS to order shipments from the Ogden Submission Processing Center |
| Special Forms 990-PF | Requestor’s address, or,<br> Internal Revenue Service, OS:RAAS:S<br> Attn.: C. Belmonte<br> 1111 Constitution Ave., N.W.<br> K-4100/169<br> Washington, D.C. 20224-0002 | Analysts make the requests |
| Selected Forms 990-T at the Ogden Submission Processing Center | SOI units in Ogden follow local center procedures because shipments occur within the same building | Edit units use STARTS to order shipments from the Ogden Submission Processing Center SOI Control Unit |
| Special Requests | Requestor’s address, or,<br> Internal Revenue Service, OS:RAAS:S<br> Attn.: J. Jackson<br> 1111 Constitution Ave., N.W.<br> K-4100/174<br> Washington, D.C. 20224-0002 | Analysts make the request |
| Selected Forms 4720 at the Ogden Submission Processing Center | SOI units in Ogden follow local center procedures because shipments occur within the same building | Edit units use STARTS to order shipments from the Ogden Submission Processing Center |
| Special Forms 4720 | Requestor’s address, or,<br> Internal Revenue Service, OS:RAAS:S<br> Attn.: M. Ludlum<br> 1111 Constitution Ave, N.W.<br> K-4190<br> Washington, D.C. 20224-0002 | Analysts make the requests |
| Selected Forms 1042-S, Foreign Person's U.S. Source Income Subject to Withholding | Internal Revenue Service, OS:RAAS:S<br> Attn.: S. Luttrell<br> 1111 Constitution Ave., N.W.<br> K-4100/002<br> Washington, D.C. 20224-0002 | Documents |
| Selected Forms 1042-S, Foreign Person's U.S. Source Income Subject to Withholding | Internal Revenue Service, OS:RAAS:S<br> Attn.: A. Bell<br> 1111 Constitution Ave., N.W.<br> K-4100/007<br> Washington, D.C. 20224-0002 | When data file is available |
| Selected Forms 8805, Foreign Partner’s Information Statement of Section 1446 Withholding Tax | Internal Revenue Service, OS:RAAS:S<br> Attn.: A. Bell<br> 1111 Constitution Ave., N.W.<br> K-4100/007<br> Washington, D.C. 20224-0002 | When data file is available |
| Selected Forms 8832, Entity Classification Election | Internal Revenue Service, OS:RAAS:S<br> Attn.: V. Mirgorod<br> 1111 Constitution Ave., N.W.<br> K-4100/013<br> Washington, D.C. 20224-0002 | Monthly |
| Selected Forms 8038, Information Return for Tax-Exempt Private Activity Bond Issues (original documents) | Attn.: M/S 6112 SOI Support<br> Internal Revenue Service<br> Ogden Submission Processing Center<br> 1160 W. 1200 S.<br> Ogden, UT 84201<br> (or, if bulk mail:<br> M/S 6112 SOI Support<br> Internal Revenue Service<br> Ogden Submission Processing Center<br> 1973 North Rulon White Blvd.<br> Ogden, UT 84404 (84201 for United States Postal Service)) | The Ogden unit uses STARTS to order shipments from files at the Ogden Submission Processing Center |
| Selected Forms 8038-G, Information Return for Tax-Exempt Governmental Obligations (original documents) | Attn.: M/S 6112 SOI Support<br> Internal Revenue Service<br> Ogden Submission Processing Center<br> 1160 W. 1200 S.<br> Ogden, UT 84201<br> (or, if bulk mail:<br> M/S 6112 SOI Support<br> Internal Revenue Service<br> Ogden Submission Processing Center<br> 1973 North Rulon White Blvd.<br> Ogden, UT 84404 (84201 for United States Postal Service)) | The Ogden unit uses STARTS to order shipments from files at the Ogden Submission Processing Center |

**Exhibit 1.13.3-7**

### SOI Corporation Study Years 2016, 2017, and 2018

| SOI Year | Return Classification | Processing Date | Tax Period | Sample Selection Sheet Heading | ECC-MTB Cycle1 |
| :-: | :-: | :-: | :-: | :-: | :-: |
| 2016 | Late Fiscal2 | January 2018 to<br> June 2018 | Before 201707 | SOI Year 2016 Late | 201803<br> (Ends<br> 201826) |
| 2017 | Early Fiscal3 | June 2017 to<br> December 2017 | After 201706 | SOI Year 2017 Early | 201703 (Begins 201727) |
| 2017 | Regular Fiscal4 | January 2018 to<br> December 2018 | Before 201807 | SOI Year 2017 Regular | 201803 |
| 2017 | Late Fiscal5 | January 2019 to<br> June 2019 | Before 201807 | SOI Year 2017 Late | 201903<br> (Ends<br> 201926) |
| 2018 | Early Fiscal6 | June 2018 to<br> December 2018 | After 201806 | SOI Year 2018 Early | 201803 (Begins 201827) |
| 1 ECC-MTB cycle at the beginning of an IRS processing year and (the beginning or ending selection cycle for a specific SOI Year study). |
| 2 After June 2018, these corporation returns appear in the BMF STARTS database as SOI Year 2017 documents. After Cycle 201826, returns meeting the Critical Case criteria are processed as SOI Year 2016 selections until National Office announces the final cutoff, probably in August 2018. Returns that do not meet the criteria are edited with the SOI Year 2017 Study. Delinquent returns in the sample are not completely included in this breakdown. |
| 3 Documents in the three SOI Year studies are separated throughout the processing year to improve the handling procedures in the SOI edit units at the Submission Processing centers. |
| 4 These returns are selected, pulled, scanned, and rendered beginning in January 2018. Delinquent returns in the sample are not completely included in this breakdown. |
| 5 These returns are selected, pulled, scanned, and rendered beginning in January 2019. Delinquent returns in the sample are not completely included in this breakdown. |
| 6 The SOI units at the campuses hold all of these returns for editing in the SOI 2018 study. |

**Exhibit 1.13.3-8**

### Filing Requirement Codes Posted to the Entity Section of the Master File

**Form 1120**

| Code | Requirement |
| :-: | :-: |
| 00 | IRS does not require filing of return. |
| 01 | IRS requires filing of Form 1120. It requires the filing of Form 1120 in the month in which the corporation fiscal year ends. |
| 02 | Form 1120S required. |
| 03 | Form 1120-L required. |
| 04 | 1120-PC required; 1120-M required |
| 05 | Reserved for programming use. |
| 06 | Form 1120-F required. |
| 07 | IRS requires filing of Form 1120 (6 month extension). |
| 09 | IRS requires filing of Form 1120-POL. It does not require mailing. No FTD mail-out. |
| 10 | 1120-H required. |
| 11 | Form 1120-ND required. |
| 14 | Subsidiary Organization (TC 590 CC 14 posting). IRS requires neither filing nor mailing of return. |
| 16 | 1120-SF required. |
| 17 | 1120-RIC required. |
| 18 | 1120-REIT required. |
| 19 | 1120 Personal Service Corp. required. |
| 88 | Account currently inactive. IRS requires neither filing nor mailing of return. |

**Form 1065**

| Code | Requirement |
| :-: | :-: |
| 0 | IRS requires neither mailing nor filing of return. |
| 1 | IRS requires mailing and filing of return. |
| 5 | Reserved for programming use. |
| 8 | Account currently inactive. IRS requires neither mailing nor filing of return. |

**Exhibit 1.13.3-9**

### Individual/Sole Proprietorship Program Schedule, Tax Years 2016 and 2017

**Tax Year 2016**

| Activity | Cycles and Dates |
| :-: | :-: |
| Sampling and Controlling | - Cycles 201704 – 201738 (Individual Advance Data Closeout)<br>  <br>- Cycles 201739 – 201752 and any unprocessed returns from Cycles 201704 – 201738 (Complete Report Closeout)<br>  <br>- Cycle 201754 only (Final Report Closeout sampling only) |
| Editor Training | - June 26 - 29, 2017<br>  <br>- June 2017 (Austin, Cincinnati, Fresno, and Kansas City Submission Processing Centers) |
| Advance Data | July 2017 – October 27, 2017 (Austin, Cincinnati, Fresno, and Kansas City Submission Processing Centers) |
| Complete Report | October 30, 2017 – February 16, 2018 (Austin, Cincinnati, Fresno, and Kansas City Submission Processing Centers) |

**Tax Year 2017**

| Activity | Cycles and Dates |
| :-: | :-: |
| Sampling and Controlling | - Cycles 201804 – 201838 (Individual Advance Data Closeout)<br>  <br>- Cycles 201839 – 201852 and any unprocessed returns from Cycles 201804 – 201838 (Complete Report Closeout)<br>  <br>- Cycle 201854 only (Final Report Closeout sampling only) |
| Editor Training | - May 2018<br>  <br>- May 2018 (Austin, Cincinnati, Fresno, Kansas City, and Ogden Submission Processing Centers) |
| Advance Data | May 2018 – October 26, 2018 (Austin, Cincinnati, Fresno, Kansas City, and Ogden Submission Processing Centers) |
| Complete Report | October 29, 2018 – February 8, 2019 (Austin, Cincinnati, Fresno, Kansas City, and Ogden Submission Processing Centers) |

**Exhibit 1.13.3-10**

### Special Closeout Procedures for SOI Individual Programs, Tax Years 2016 and 2017

**Tax Year 2016**

| Return Type and Cycles | Deadline | Instructions |
| :-: | :-: | :-: |
| Advance Data: Cross-sectional returns between 201704 and 201738; and, panel returns based on the manager’s assessment of the edit unit’s ability to meet the Complete Report deadline in February 2017. | October 27, 2017 | For returns requested to meet the Advance data deadline, an SOI control unit that sends returns to a different center must send the shipment by Federal Express or other overnight delivery service, beginning October 6, 2017. The processing centers produce all PRISM reports for their own center and any other center that they edit returns for. Report F, for instance, are generated again to determine the edit status of the returns in the database. The number of missing paper returns at each of the four centers through Cycle 201738 should not exceed 60 returns. |
| Complete Report: All returns selected through 201752 | February 16, 2018 | The total volume completely processed must be at least 99.7 percent of the volume selected through Cycle 201752. The number of missing paper returns through Cycle 201752 can not exceed 30 returns at each of the centers.<br> Only discontinue searching for missing returns for Cycles 201704 through 201752 per National Office direction. From January 12, 2018, through February 16, 2018, the edit units produce PRISM Report F to determine the edit status of the returns in the database. Also during this period, the edit units must complete the editing and error resolution of any returns on these reports. SOI control units that ship returns to different centers must send shipments of requested returns by January 12, 2018. |

**Tax Year 2017**

| Return Type and Cycles | Deadline | Instructions |
| :-: | :-: | :-: |
| Advance Data: Cross-sectional returns between 201804 and 201838; and, panel returns based on the manager’s assessment of the edit unit’s ability to meet the Complete Report deadline in February 2019. | October 26, 2018 | For returns requested to meet the Advance data deadline, an SOI control unit that sends returns to a different center must send the shipment by Federal Express or other overnight delivery service, beginning October 8, 2018. The processing centers produce all PRISM reports for their own center and any other center that they edit returns for. Report F, for instance, are generated again to determine the edit status of the returns in the database. The number of missing paper returns at each through Cycle center through 201838 should not exceed 60 returns. |
| Complete Report: All returns selected through 201852 | February 8, 2019 | The total volume completely processed must be at least 99.7 percent of the volume selected through Cycle 201852. The number of missing paper returns through Cycle 201852 can not exceed 30 returns at each of the centers.<br> Only discontinue searching for returns for Cycles 201804 through 201852 per National Office direction. From January 11, 2019, through February 8, 2019, the edit units produce PRISM Report F to determine the edit status of the returns in the database. Also during this period, the edit units must complete the editing and error resolution of any returns on these reports. SOI control units that ship returns to different centers must send shipments of requested returns by January 11, 2019. |

**Exhibit 1.13.3-11**

### Submission Processing Center Disposition Schedule: Number of Days After Closeout

| Tax Year | Advance Data | Complete Report | Database Output Files (Composite Files) | Management and Other Related Documentation | File Output Reports |
| :-: | :-: | :-: | :-- | :-- | :-- |
| 2017 | 10/26/2018 | 02/08/2019 | 180 | 120 | 120 |
| 2016 | 10/27/2017 | 02/16/2018 | 180 | 120 | 120 |

**Exhibit 1.13.3-12**

### Sales of Capital Assets (SOCA) Program Completion Deadlines

| Cycle | Tax Year | Completion Date |
| :-: | :-: | :-: |
| 04 – 52 | 2015 | 09/29/2017 |
| 04 – 52 | 2016 | 08/30/2018 |

**Exhibit 1.13.3-13**

### Additional Projects Schedule

| Study | Tax Year | Processing Year | STARTS Control |
| :-: | :-: | :-: | :-: |
| U.S. Estate Tax Return, Form 706 | 2017 - 2019 | 2017 - 2019 | Yes |
| U.S. Gift (and Generation-Skipping Transfer) Tax Return, Form 709 | 2017 - 2019 | 2017 - 2019 | Yes |
| Return of Organization Exempt from Income Tax, Forms 990 and 990-EZ | 2015 - 2018 | 2017 - 2019 | Yes |
| Return of Private Foundation, Form 990-PF | 2015 - 2018 | 2018 - 2020 | Yes |
| Return of Certain Excise Taxes on Charities and Other Persons Under Chap. 41 and 42 of the IRC, Form 4720 | 2015 - 2018 | 2017 - 2019 | Yes |
| Exempt Organization Business Income Tax Return, Form 990-T | 2015 - 2018 | 2017 - 2019 | Yes |
| Foreign Tax Credit, Form 1118 | 2016 | 2017 - 2018 | No |
| Foreign Tax Credit, Form 1118 | 2017 | 2018 - 2019 | No |
| Exclusion of Income From U.S. Possession, Form 4563 | Upon SOI notice | Upon SOI notice | No |
| Nonresident Alien Income and Tax Withheld | 2017 | 2018 - 2019 | No |
| Controlled Foreign Corporations, Form 5471 | 2016 | 2017 - 2019 | No |
| Information Return for Tax-Exempt Private Activity Bond Issues, Forms 8038; Information Return for Tax-Exempt Governmental Obligations, 8038-G | 2017 - 2019 | 2017 - 2019 | Yes |
| Partnership Withholding, Forms 8805 | 2017 | 2019 | No |
| Entity Classification Election, Form 8832 | N/A | 2018 - 2019 | Yes |
| Information Return of U.S. Persons With Respect To Foreign Disregarded Entities, Form 8858 | 2016 | 2017 - 2019 | No |
| Return of U.S. Persons With Respect to Certain Foreign Partnerships, Form 8865 | 2016 | 2018 - 2019 | No |
| Country by Country Report, Form 8975 | 2016 | 2017-2019 | No |

**Exhibit 1.13.3-14**

### Form 706, Form 709, and Form 990 Series Processing Schedules

| SOI Project | Start-up Cycle | Last Cycle | Shipment Date Before Closeouts |
| :-: | :-: | :-: | :-: |
| 2017 Form 706 | 201703 | 201752 | 01-08-2017 |
| 2018 Form 706 | 201803 | 201852 | 01-07-2018 |
| 2019 Form 706 | 201903 | 201952 | 01-06-2019 |
| 2017 Form 709 | 201703 | 201801 | 01-06-2018 |
| 2018 Form 709 | 201803 | 201901 | 01-05-2019 |
| 2019 Form 709 | 201903 | 202001 | 01-04-2020 |
| 2015 Form 990 | 201603 | 201801 | 01-04-2018 |
| 2016 Form 990 | 201703 | 201901 | 01-05-2019 |
| 2017 Form 990 | 201803 | 202001 | 01-04-2020 |
| 2018 Form 990 | 201903 | 202101 | 01-02-2021 |
| 2015 Form 990-PF | 201603 | 201801 | 01-04-2018 |
| 2016 Form 990-PF | 201703 | 201901 | 01-05-2019 |
| 2017 Form 990-PF | 201803 | 202001 | 01-04-2020 |
| 2018 Form 990-PF | 201903 | 202101 | 01-02-2021 |
| 2014 Form 990-T | 201503 | 201701 | 1-02-2017 |
| 2015 Form 990-T | 201603 | 201801 | 01-04-2018 |
| 2016 Form 990-T | 201703 | 201901 | 01-05-2019 |
| 2017 Form 990-T | 201803 | 202001 | 01-04-2020 |
| 2018 Form 990-T | 201903 | 202101 | 01-02-2021 |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-013-003#addtoany "Show all")

A2A