---
url: "https://www.irs.gov/irm/part1/irm_01-004-003"
title: "1.4.3 Financial Assurance Control Testing | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-004-003#main-content)

- 1.4.3  [Financial Assurance Control Testing](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980953817200)
  - 1.4.3.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980926026400)
    - 1.4.3.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980926022512)
    - 1.4.3.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980926857744)
    - 1.4.3.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980926855248)
      - 1.4.3.1.3.1  [CFO and Deputy CFO](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980926848832)
      - 1.4.3.1.3.2  [Associate CFO for Internal Controls](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980926229008)
      - 1.4.3.1.3.3  [Senior Associate CFO for Financial Management, Associate CFO for Corporate Accounting, Associate CFO for Revenue Financial Accounting and Associate CFO for Corporate Budget](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980926225872)
      - 1.4.3.1.3.4  [Assurance Review & Testing](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980926220224)
      - 1.4.3.1.3.5  [Research Applied Analytics and Statistics of Income Statistical Services](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980925848464)
      - 1.4.3.1.3.6  [Financial Assurance Control Testing Teams](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980925845472)
      - 1.4.3.1.3.7  [FACT Section Chiefs](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980925838016)
      - 1.4.3.1.3.8  [FACT Team Leads](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980926213152)
      - 1.4.3.1.3.9  [Process Owners](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980926205072)
    - 1.4.3.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980926181360)
    - 1.4.3.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980926173248)
    - 1.4.3.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980926168640)
    - 1.4.3.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980953682768)
    - 1.4.3.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980953661056)
  - 1.4.3.2  [Governance](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980925787872)
  - 1.4.3.3  [General Guidance for FACT](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980925781552)
    - 1.4.3.3.1  [FACT Schedule](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980925989520)
    - 1.4.3.3.2  [Planning Phase](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980925984880)
      - 1.4.3.3.2.1  [Assertions](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980925389776)
      - 1.4.3.3.2.2  [Business Process Test Plan Template](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980925382032)
    - 1.4.3.3.3  [Testing Phase](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980925359200)
      - 1.4.3.3.3.1  [Sampling](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980925355392)
      - 1.4.3.3.3.2  [Review of SMRs and QARs](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980925337120)
      - 1.4.3.3.3.3  [Substantive Testing](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980925331568)
      - 1.4.3.3.3.4  [Evaluating Exceptions and Classifying Findings](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980925294256)
    - 1.4.3.3.4  [Reporting Phase](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980925262576)
  - 1.4.3.4  [Continuous Monitoring](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980925253008)
  - 1.4.3.5  [Record Retention](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980925234800)
  - Exhibit  1.4.3-1  [Record of Discussion](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980925232304)
  - Exhibit  1.4.3-2  [Sample Sizes and Acceptable Number of Errors (90% Confidence Level)](https://www.irs.gov/irm/part1/irm_01-004-003#idm139980925153120)

# Part 1. Organization, Finance, and Management

# Chapter 4. Resource Guide for Managers

# Section 3. Financial Assurance Control Testing

* * *

## 1.4.3 Financial Assurance Control Testing

#### Manual Transmittal

April 04, 2025

#### Purpose

(1) This transmits revised IRM 1.4.3, Resource Guide for Managers, Financial Assurance Control Testing.

#### Material Changes

(1) IRM 1.4.3.1.3.3, Senior Associate CFO for Financial Management, Associate CFO for Corporate Accounting, Associate CFO for Revenue Financial Accounting and Associate CFO for Corporate Budget, updated responsibilities.

(2) IRM 1.4.3.1.3.8, FACT Team Leads, updated responsibilities.

(3) IRM 1.4.3.1.4, Program Management and Review, updated reference from Test Results Spreadsheet to Business Process Test Plan and added reference to Interim Progress Report.

(4) IRM 1.4.3.1.5, Program Controls, updated references from test plan to Business Process Test Plan.

(5) IRM 1.4.3.1.6, Terms/Definitions, updated the following:

| **Term** | **Reason** |
| :-: | :-: |
| Business Process Test Plan | This term was added to replace the prior name for our final report, Test Results Spreadsheet. |
| Material Weakness | Revised definition |
| Test Results Spreadsheet (TRS) | Removed from IRM |
| Test Plan | Removed from IRM |

(6) IRM 1.4.3.1.7, Acronyms, added Business Process Test Plan (BPTP).

(7) IRM 1.4.3.3.2(7), Planning Phase, updated Fact Structure chart.

(8) RM 1.4.3.3.2.2, Business Process Test Plan Template, updated to reflect current template sections and process.

(9) IRM 1.4.3.3.4(2), Report Phase, updated final reports.

(10) Editorial changes made throughout this IRM section include:

- Update to authority reference

- Update to CFO organizational titles

- Update for clarity

- Update to references from test plans to Business Process Test Plan.


#### Effect on Other Documents

IRM 1.4.3, dated August 18, 2023, is superseded.

#### Audience

All business units

#### Effective Date

(04-04-2025)

Teresa R. Hunter

Chief Financial Officer

**1.4.3.1** **(04-01-2020)**

### Program Scope and Objectives

1. Purpose - The IRM provides information for implementing Office of Management and Budget (OMB) Circular A-123, Management’s Responsibility for Enterprise Risk Management and Internal Control, Appendix A: Management of Reporting and Data Integrity Risk.

2. Audience - All business units.

3. Policy Owner - The CFO, Associate CFO for Internal Controls unit.

4. Program Owner - Financial Assurance Control Testing (FACT) Team.

5. Primary Stakeholders - All divisions and functions.

6. Program Goals - Ensure the IRS implements and complies with OMB Circular A-123, Management’s Responsibility for Enterprise Risk Management and Internal Control, Appendix A: Management of Reporting and Data Integrity Risk.


**1.4.3.1.1** **(04-01-2020)**

#### Background

1. The passage of the Sarbanes-Oxley Act of 2002 (SOX) served as an impetus for the Federal Government to reevaluate its policies relating to internal control over financial reporting and management’s related responsibilities. SOX requires management of publicly traded companies to strengthen their processes for assessing and reporting on internal control over financial reporting. While SOX created a new requirement for publicly traded companies, federal managers had been subject to similar internal control reporting requirements for many years.

2. A joint committee of representatives from the CFO Council and the Council of Inspectors General on Integrity and Efficiency (CIGIE) was formed in 2008 and tasked with reviewing the SOX requirements for publicly traded companies, determining how these requirements apply to federal agencies, and recommending changes to the existing guidance on internal control. The joint committee recommended significant changes to the OMB Circular A-123, Management's Responsibility for Internal Control, Appendix A: Management of Reporting and Data Integrity Risk, which included a requirement for agencies to document and test internal controls to verify they are in place and working as intended.

3. To emphasize the importance of having appropriate risk management processes, OMB updated Circular A-123, Management's Responsibility for Internal Control to include Enterprise Risk Management (ERM). The Circular was renamed Management’s Responsibility for Enterprise Risk Management and Internal Control, and Appendix A was renamed Management of Reporting and Data Integrity Risk.


**1.4.3.1.2** **(04-01-2020)**

#### Authorities

1. The authorities related to this IRM are:



1. Treasury Directive 40-04 and associated authorities (July 1, 2024)


**1.4.3.1.3** **(08-18-2023)**

#### Responsibilities

1. This section provides responsibilities for:



01. CFO and Deputy CFO

02. Associate CFO for Internal Controls

03. Senior Associate CFO for Financial Management, Associate CFO for Corporate Accounting, Associate CFO for Revenue Financial Accounting and Associate CFO for Corporate Budget

04. Assurance Review & Testing (ART)

05. Statistics of Income (SOI) division

06. FACT teams

07. FACT section chiefs

08. Team leads

09. Transaction leads

10. Process owners


**1.4.3.1.3.1** **(04-01-2020)**

##### CFO and Deputy CFO

1. The CFO and Deputy CFO are responsible for executing OMB Circular A-123, Management’s Responsibility for Enterprise Risk Management and Internal Control, Appendix A: Management of Reporting and Data Integrity Risk requirements to support Treasury’s assurance statement by properly identifying, testing, and evaluating the IRS’s controls over data integrity and financial reporting.


**1.4.3.1.3.2** **(04-01-2020)**

##### Associate CFO for Internal Controls

1. The Associate CFO for Internal Controls is responsible for:



1. Overseeing the FACT process including approving final Business Process Test Plans (BPTPs).

2. Administering the governance process by chairing the FACT Technical Review Board, providing the status and results of FACT activities to the Management Controls Executive Steering Committee (MC ESC) and the FACT Technical Review Board, and documenting key decisions.


**1.4.3.1.3.3** **(04-04-2025)**

##### Senior Associate CFO for Financial Management, Associate CFO for Corporate Accounting, Associate CFO for Revenue Financial Accounting and Associate CFO for Corporate Budget

1. The Senior Associate CFO for Financial Management, Associate CFO for Corporate Accounting, Associate CFO for Revenue Financial Accounting and Associate CFO for Corporate Budget, are responsible for:



1. Approving BPTPs.

2. Designating a FACT Technical Review Board representative and back-up.

3. Providing subject matter experts (SMEs) to points of contact (POCs) to review the control design analysis to verify that the transaction lead identified key controls.

4. Delivering requested internal control documentation stated in the Prepared by Client (PBC) listing timely.

5. Developing and monitoring planned corrective actions (PCAs) for identified weaknesses.

6. Reviewing and signing the BPTP, Combined Issues Report (CIR) and Executive Summary (ES), as applicable.

7. Signing the ES to acknowledge test results.


**1.4.3.1.3.4** **(08-18-2023)**

##### Assurance Review & Testing

1. ART is responsible for:



1. Providing clear and concise communication of FACT assessment objectives throughout the agency.

2. Approving the FACT assessment methodology and guidance.

3. Leading the coordination of testing activities and timelines with process owners, Treasury and Government Accountability Office (GAO).

4. Ensuring the FACT team carries out assessments in a thorough, effective and timely manner.

5. Communicating the results of testing activities to IRS and agency management.

6. Collaborating with SMEs and POCs to assist in the timely development of the control design analysis (CDA) and the BPTP.

7. Communicating and coordinating with external oversight groups.

8. Ensuring FACT documentation meets retention standards.


**1.4.3.1.3.5** **(04-01-2020)**

##### Research Applied Analytics and Statistics of Income Statistical Services

1. SOI is responsible for:



1. Determining an appropriate sampling method and size for each control based on frequency.

2. Using statistical sampling methods to generate samples for testing.


**1.4.3.1.3.6** **(04-01-2020)**

##### Financial Assurance Control Testing Teams

1. FACT teams are comprised of the transaction lead and individuals that assist with the execution of the BPTP.

2. FACT testing teams are responsible for:



1. Obtaining and analyzing applicable IRMs, interim guidance memoranda, standard operating procedures (SOPs), job aids, Servicewide Electronic Research Program (SERP) alerts, IRM Procedural Updates, GAO/Treasury Inspector General for Tax Administration (TIGTA) audit reports and other guidance related to assigned test steps.

2. Completing and reviewing FACT planning, testing, and reporting activities to ensure that all requirements have been satisfied.

3. Conducting substantive testing of supporting documents received from the process owners.

4. Communicating exceptions found within the test plan to relevant internal and external stakeholders.

5. Verifying that all necessary supporting documentation is available for assigned test objectives.

6. Discussing and verifying facts with the appropriate process owner (to include the condition, criteria, cause, effect, and recommendation), when exceptions are identified.

7. Analyzing test results to determine if internal controls are in place and working effectively.

8. Reporting test results to the process owners, management, and other relevant stakeholders.

9. Recommending future business process test plan updates based on the execution of the business process test plan and lessons learned.


**1.4.3.1.3.7** **(08-18-2023)**

##### FACT Section Chiefs

1. The FACT section chiefs are responsible for:



1. Providing guidance and support for planning, testing, and reporting activities in order to determine the effectiveness of internal controls over financial reporting, mitigate risk and ensure the quality of IRS data.

2. Coordinating with internal stakeholders and business units to identify areas of risk related to key internal controls.

3. Directing test procedures to evaluate whether internal controls are effective at managing and mitigating risk and ensuring data integrity for financial reporting.

4. Reporting the results of internal control testing and prompting program managers to develop and implement corrective action plans to remediate any control deficiencies and/or weaknesses that were identified during the course of the review.

5. Directing the entry of resulting findings into the Joint Audit Management Enterprise System (JAMES) system (or the new Government Risk and Compliance -GRC- system as Treasury directs), monitoring of open items and review of supporting documentation until closure can be accomplished.

6. Engaging with external stakeholders, to include the Department of Treasury and GAO, when developing and implementing program guidance, performing assessment activities, determining outcomes and reporting results.

7. Developing/delivering training and Knowledge Capture (KC) t tools to support operationalization of internal controls activities at the program level.


**1.4.3.1.3.8** **(04-04-2025)**

##### FACT Team Leads

1. The FACT team leads are responsible for:



01. Supporting team members throughout the FACT review cycle. Team leads serve as the first level of support for questions.

02. Addressing FACT process-related questions and comments from stakeholders.

03. Assisting in FACT transaction activities.

04. Providing feedback to transaction leads and co-leads throughout the review process. This includes providing guidance, sharing best practices, and identifying opportunities for improvement.

05. Providing JAMES report of open transaction findings to transaction lead and co-leads during planning stage.

06. Staying informed on the status of team milestones, deliverables, and issues.

07. Reviewing and signing-off on transaction steps and work papers in TeamMate.

08. Providing coaching notes to team members.

09. Completing assigned deliverables for Treasury and GAO stakeholders.

10. Providing input on program guidance, staffing, transaction assignments, and relevant timelines and deliverables.

11. Serving as a subject-matter-expert and providing recommendations and guidance to section chiefs, transaction leads, and co-leads.

12. Helping team members resolve issues or escalate issues, as needed.

13. Notifying business units, POCs, SMEs of any changes to the FACT process.


**1.4.3.1.3.9** **(08-18-2023)**

##### Process Owners

1. The process owners are responsible for:



1. Providing POCs and SMEs to identify and describe applicable internal controls, review the CDA and verify that FACT test plans accurately capture key internal controls related to the process.

2. Participating in and coordinating FACT interviews and walkthroughs to describe applicable internal controls and to answer any questions.

3. Communicating existing audit findings or recommendations (noted by GAO or TIGTA), the status of corrective action, and how it relates to processes under review, if applicable.

4. Gathering and delivering internal control documentation that is included in the PBC listing, or has otherwise been requested, by the respective due date.

5. Evaluating existing management review procedures.

6. Reviewing and signing the Test Results Spreadsheet, CIR and ES, as applicable.

7. Developing, executing and monitoring CAPs (for reported issues) to meet projected completion date(s).

8. Providing timely planned corrective action (PCA) responses to reported issues through use of the JAMES system.

9. Communicating changes to relevant processes and internal controls.


**1.4.3.1.4** **(04-04-2025)**

#### Program Management and Review

1. Program Reports issued by FACT are:



1. **CIR** \- Report that describes the current issue(s) identified during testing and the status of prior issue(s), as applicable.

2. **ES** \- Report that describes the purpose and scope of the review along with a summary of the results and other pertinent information.

3. **IPR** – Report that captures interim results with an expectation of final test results after FACT completes fourth quarter testing.

4. **BPTP** \- Report that includes a detailed description of the test steps, actions taken, review dates, and results of transaction testing.


2. Program Effectiveness:



1. Identify internal control deficiencies and/or weaknesses related to financial and non-financial reporting.

2. Make recommendations that improve internal controls or program efficiency.


**1.4.3.1.5** **(04-04-2025)**

#### Program Controls

1. The following controls are in place to ensure compliance and quality:



1. BPTPs are reviewed and approved by the FACT Technical Review Board.

2. BPTP documentation, evidence and results are reviewed by FACT team leads and/or section chiefs and the director, Assurance Review Testing.

3. Final CIRs and BPTPs are reviewed by the business unit stakeholders and the ES is signed by the responsible executive for the process.

4. Final BPTPs, results of testing and reportable issues are provided to the Department of Treasury and GAO.

5. The MC ESC is notified anytime a material weakness or significant deficiency is identified.


**1.4.3.1.6** **(04-04-2025)**

#### Terms/Definitions

1. The following terms and definitions apply to this program:



01. **Business Process Test Plan (BPTP)** – A consolidated report that provides the details of the test steps, dates and results of transactional testing.

02. **Commerce Clearing House (CCH) TeamMate** – A Windows-based Audit Management System used by the FACT team to manage the review and reporting of the annual control testing process. Workpapers are prepared and stored in the application for all the transactions tested.

03. **Combined Issues Report (CIR)** \- A consolidated report of issues identified during testing of a transaction, which includes issues identified during the current testing period as well as existing issues from previous testing periods.

04. **Compensating Control** – A control that limits the severity of risk from a missing control. While a compensating control mitigates the effects of a control deficiency, it does not eliminate a control deficiency.

05. **Control Activities** \- The actions management establishes through policies and procedures to ensure directives are carried out and that necessary steps are taken to address risks.

06. **Control Deficiency (CD)** \- Exists when the design, implementation or operation of a control does not allow management or personnel, in the normal course of performing their assigned functions, to prevent or detect control weakness in a timely manner or aid in addressing risks.

07. **Control Design Analysis (CDA)** \- Documents the risk associated with a process, key controls designed to mitigate the risk and assessment of their effectiveness.

08. **Control Environment** \- The foundation for an internal control system. It provides the discipline and structure to help an entity achieve its objective.

09. **Control Risk** \- The risk that a material misstatement could occur but may not be detected and corrected or prevented by the entity’s internal controls.

10. **Corrective Action** – An action taken by the process owner that corrects identified deficiencies and produces recommended improvements.

11. **Corrective Action Plan (CAP)** \- Documents the strategy and/or detailed steps to be taken to remediate an identified control deficiency or weakness.

12. **Exception** \- A testing attribute that does not conform to the common rule.

13. **Inspection** \- Examination of documents, products or services to evaluate the consistency, efficiency and/or effectiveness of a control.

14. **Internal controls** \- An integral part of any organization's financial and business policies and procedures. Internal controls consist of all the measures taken by the organization for the purpose of (1) protecting its resources against fraud, waste and inefficiency; (2) ensuring accuracy and reliability in accounting and operating data; (3) securing compliance with the policies of the organization; and (4) evaluating the level of performance in all organizational units of the organization.

15. **Job aids** \- May be an IRM exhibit or SERP Alert, a Technical Communications Document (TCD) or a document used as training material.

16. **Joint Audit Management Enterprise System (JAMES)** – A Treasury database used to track the progress and implement PCAs of process owners as a result of an internal control review.

17. **Management Information Only (MIO)** – When an observation is made that doesn’t rise to the level of an audit finding, yet still warrants the attention of internal control process owners, the FACT team has the ability to issue a MIO which serves to notify the process owner of an opportunity to improve the design or operation of an internal control(s). Unlike the findings described above, MIO notifications do not require a response or corrective action plan.

18. **Material Weakness (MW)** \- A reportable condition, or combination of reportable conditions, which results in more than a remote likelihood that a material misstatement of the financial statements, or other significant reports, will not be prevented or detected. Material weaknesses are reportable conditions that warrant the attention of the MC ESC.

19. **Methodology** \- A documented process for applying standards when assessing, documenting and reporting on internal controls over risks related to financial reporting and data integrity.

20. **Misstatement** \- The amount by which a financial statement line item can differ from its true amount.

21. **Monitoring** \- Activities management establishes and operates to assess the quality of performance over time.

22. **National Institute of Standards and Technology (NIST)** – Responsible for developing information security standards and guidelines, including minimum requirements for federal information systems based on its statutory responsibilities under the Federal Information Security Management Act (FISMA), Public Law 107-347.

23. **Observation** \- Seeing a process or procedure being performed by others.

24. **Operating effectiveness** \- A measure of the extent to which controls achieve their stated goals; evaluated by the test of controls to address the how, by whom, and with what level of consistency controls, policies and procedures have been applied.

25. **Planned Corrective Action (PCA)**– A field utilized within the JAMES system that is intended to track the response of process owners regarding open review findings.

26. **Prepared by Client (PBC) Listing** \- Detailed request of information and documents needed from the customer to conduct testing.

27. **Population** \- Universe or list of items for a given period of time from which the sample will be derived.

28. **Process owner** \- Organization, business unit, operating/business division or office responsible for managing and overseeing the objectives and performance of a process.

29. **Quality Assurance Review (QAR)** \- Assessment of an organization’s risk and internal controls to verify adequate management controls are in place and functioning effectively to accomplish organizational goals and protect resources.

30. **Re-performance** \- Independent execution of procedures or controls that were originally performed as part of the entity’s internal control.

31. **Reportable Issue** \- An issue that is identified during testing that indicates controls are weak, nonexistent or bear monitoring. There are three categories of reportable issues: Control Deficiency, Significant Deficiency and Material Weakness.

32. **Risk assessment** – Assess the risks facing the entity as it seeks to achieve its objectives. This assessment provides the basis for developing appropriate risk responses.

33. **Sample** \- Items selected from a population to be tested to reach a conclusion about the population.

34. **Sampling Plan** – An outline detailing the criteria to use to select a sample (size, frequency of control, risk, etc.) from which the transaction lead will select a certain number of items to use to reach a conclusion representative of the whole population.

35. **Scope** \- Description of the physical locations, organizational units, activities and processes and the corresponding time period subjected to examination or review.

36. **SERP Alert** \- The information communicated to employees may provide a reminder or notification to address work stream, programming or system problems.

37. **Significant Deficiency** – A significant deficiency is a deficiency, or a combination of deficiencies, in internal control that is less severe than a material weakness yet important enough to merit attention by those charged with governance.

38. **Statement of Assurance** – A certification included in the annual Agency Financial Report (AFR) that represents the Commissioner’s informed judgment as to overall adequacy and effectiveness of internal controls. The Commissioner provides either an unmodified statement that an effective and efficient system of internal controls exists, a modified statement that an overall sound system of internal control exists but one or more material weaknesses have been identified or a statement of no assurance on the system of internal control.

39. **Structured Management Review (SMR)** – A review of documented continuous monitoring activities including QARs or other independent internal reviews put in place to cover many IRS internal control activities during the normal course of operations.

40. **Supporting Documentation** \- Written information and/or data providing backup to substantiate the conclusion.

41. **Testing** – After planning, the transaction lead performs the procedures listed in the test plan. The transaction lead tests the key internal controls and the accuracy of the transaction. The transaction lead uses various techniques such as sampling.

42. **Test Objectives** – Purposes or intended goals stating what the transaction lead wants to accomplish when implementing the specified test activities.

43. **Test Steps** – Procedures performed to reach established audit objectives and assess the efficiency and effectiveness of control activity.

44. **Transaction**– Represents activities and/or processes impacting and reflected in the Treasury consolidated financial statements.

45. **Walkthrough** – Process by which to assist in understanding design and implementation of controls and may include a combination of interviews, observations, examination of documents and/or tracing a transaction from initiation to completion.

46. **Workpapers** – Documents that support the test results. The workpapers reveal the comprehensive actions the test team performed to test each control during the testing phase. The workpapers connect the entity’s accounting records and financial reporting to the transaction’s assertion.


**1.4.3.1.7** **(04-04-2025)**

#### Acronyms

1. The following acronyms apply to this program.




| **Acronym** | **Meaning** |
| :-: | :-: |
| BPTP | Business Process Test Plan |
| CAP | Corrective Action Plan |
| CDA | Control Design Analysis |
| CIGIE | Council of Inspectors General on Integrity and Efficiency |
| CIR | Combined Issues Report |
| CPR | Combined Procedures Report |
| JAMES | Joint Audit Management Enterprise System |
| MC ESC | Management Controls Executive Steering Committee |
| NIST | National Institute of Standards and Technology |
| OMB | Office of Management and Budget |
| PBC | Prepared by Client |
| PCA | Planned Corrective Action |
| POC | Point of Contact |
| QAR | Quality Assurance Review |
| SERP | Servicewide Electronic Research Program |
| SOP | Standard Operating Procedures |
| SOX | Sarbanes-Oxley Act of 2002 |
| SME | Subject Matter Expert |
| SMR | Structured Management Review |
| SOI | Statistics of Income Division |


**1.4.3.1.8** **(08-18-2023)**

#### Related Resources

01. [GAO CIGIE Financial Audit Manual (FAM)](https://www.gao.gov/financial_audit_manual)

02. [OMB Circular A-123, Management’s Responsibility for Enterprise Risk Management and Internal Control](https://obamawhitehouse.archives.gov/omb/circulars_a123_rev/)

03. [OMB Circular A-123 Appendix A, Management of Reporting and Data Integrity Risk](https://obamawhitehouse.archives.gov/omb/circulars_a123_rev/#appai)

04. [Treasury’s OMB Circular A-123 Appendix A annual implementation guidance](https://www.whitehouse.gov/wp-content/uploads/legacy_drupal_files/omb/circulars/A123/a123_appx_a_implementation_guide.pdf)

05. [Generally Accepted Government Auditing Standards (Yellow Book),GAO -18-568G](https://www.gao.gov/products/gao-21-368g)

06. [Standards for Internal Controls in the Federal Government (Green Book), GAO-14-704G](https://www.gao.gov/greenbook)

07. [Chief Financial Officer’s Council Implementation Guide for OMB Circular A-123, July 2005](https://obamawhitehouse.archives.gov/omb/circulars_a123_rev/)

08. [OMB Circular A-136, Financial Reporting Requirements](https://www.whitehouse.gov/wp-content/uploads/2019/06/OMB-Circular-A-136.pdf)

09. IRM 10.8.1, Information Technology (IT) Security, Policy and Guidance

10. [NIST Special Publication 800-37, Revision 2, Risk Management Framework for Information Systems and Organizations: A System Life Cycle Approach for Security and Privacy.](https://csrc.nist.gov/publications/detail/sp/800-37/rev-2/final)

11. [NIST Special Publication 800-53, Security and Privacy Controls for Federal Information Systems and Organizations, Revision 5](https://csrc.nist.gov/publications/detail/sp/800-53/rev-5/final)

12. IRM 1.4.2, Monitoring and Improving Internal Control

13. IRM 1.4.31, Quality Assurance Review Program

14. [NARA, General Records Schedule - 5.7: Agency Accountability Records (050)](https://www.archives.gov/files/records-mgmt/grs/grs05-7.pdf)


**1.4.3.2** **(04-01-2020)**

### Governance

1. The IRS has adopted a two-tiered governance process to verify it consistently executes [OMB Circular A-123, Management’s Responsibility for Enterprise Risk Management and Internal Control,](https://obamawhitehouse.archives.gov/omb/circulars_a123_rev/) Appendix A: Management of Reporting and Data Integrity Risk requirements, has documentation procedures, provides credible results and issues, identifies and implements corrective actions. The two-tiered governance process consists of the MC ESC and the FACT Technical Review Board.



1. The IRS Chief Operating Officer chairs the MC ESC with voting members consisting of the Chief Taxpayer Services, Chief Tax Compliance Officer, and the Chief Information Officer. The MC ESC provides executive-level oversight to the FACT process by reviewing testing results and approving the interim and final assurance statements. Refer to IRM 1.4.2, Monitoring and Improving Internal Control for additional information related to the MC ESC.

2. The FACT TRB is an advisory working group composed of senior executives. Members represent Internal Controls, Financial Management, Corporate Budget, Office of the Chief Risk Officer and process owners, as applicable. The FACT Technical Review Board has two key responsibilities:


       i) Review BPTPs to verify test objectives are accurately defined and contain all required internal control procedures.


       ii) Review the sampling plan to verify the methodology, type of sample, and sample sizes are appropriate.


**1.4.3.3** **(04-01-2020)**

### General Guidance for FACT

1. A transaction is a discrete financial activity that produces information in Treasury’s AFR. It contains a series of risks and controls that defines the process; each key control must be identified. Testing controls involves verifying the controls are in place, operating as intended and meeting the stated objectives.

2. Internal control is a process for assuring achievement of an organization's objectives in operational effectiveness and efficiency, reliable financial reporting and compliance with laws, regulations and policies. The objectives and related risks can be broadly classified into one or more of the following three categories:



1. **Operations**: Effectiveness and efficiency of operations

2. **Reporting**: Reliability of reporting for internal and external use

3. **Compliance**: Compliance with applicable laws and regulations


3. Each reporting agency in Treasury is required to include a Statement of Assurance in their Federal Managers’ Financial Integrity Act and Federal Financial Management Improvement Act Annual Assurance Statement. Management cannot rely on internal control testing performed by external oversight organizations (for example, GAO and TIGTA) to meet the OMB requirements for providing assurance. The Statement of Assurance must take one of the following forms:



1. Unmodified statement of assurance (no material weaknesses reported);

2. Modified statement of assurance, considering the exceptions explicitly noted (one or more material weaknesses or lack of substantial compliance reported); or

3. Statement of no assurance (no processes in place or pervasive material weaknesses).


4. FACT team members execute the BPTPs and determine the effectiveness of the internal controls. The teams include individuals who are:



1. Adequately trained to execute the BPTP

2. Aware of documentation requirements

3. Properly supervised

4. Independent of those responsible for carrying out or supervising the controls or transactions tested (not directly responsible or not an employee who reports to the manager directly responsible for the internal control being tested)


5. The FACT team follows the GAO Standards for Internal Control in the Federal Government, also known as the Green Book. According to the Green Book, there are five components of internal controls, which are comprised of 17 principles. The components and principles are as follows:




| **Components of Internal Control** | **Principles** |
| --- | --- |
| Control Environment | 1\. Demonstrate Commitment to Integrity and Ethical Oversight Responsibility |
| 2\. Exercise Oversight Responsibility |
| 3\. Establish Structure, Responsibility and Authority |
| 4\. Demonstrate Commitment to Competence |
| 5\. Enforce Accountability |
| Risk Assessment | 6\. Define Objectives and Risk Tolerances |
| 7\. Identify, Analyze and Respond to Risk |
| 8\. Assess Fraud Risk |
| 9\. Identify, Analyze and Respond to Change |
| Control Activities | 10\. Design Control Activities |
| 11\. Design Activities for Information Systems |
| 12\. Implement Control Activities |
| Information and Communication | 13\. Use Quality Information |
| 14\. Communicate Internally |
| 15\. Communicate Externally |
| Monitoring | 16\. Perform Monitoring Activities |
| 17\. Evaluate Issues and Remediate Deficiencies |


**1.4.3.3.1** **(04-01-2020)**

#### FACT Schedule

1. There are two FACT testing cycles: interim and fourth quarter. Generally, fourth quarter testing is a continuation of interim testing; however, because of the nature and timing of the transactions, some are only tested during one of the cycles.

2. The FACT section chiefs develop a detailed FACT timeline for the testing cycles to verify tests are appropriately scheduled and sufficient resources are available. They monitor the schedule and inform the Assurance Review Testing Director and Associate CFO for Internal Controls of any execution delays.

3. There are three phases during each testing cycle:



1. Planning phase

2. Testing phase

3. Reporting phase


**1.4.3.3.2** **(04-04-2025)**

#### Planning Phase

1. The planning phase, which cover both interim and fourth quarter transaction, begins in November and typically ends in April.

2. The FACT team transaction lead first obtains an understanding of the process and related risks. This is accomplished by:



1. Reviewing applicable risk registers.

2. Reviewing the IRS Enterprise Risk Profile.

3. Reviewing related IRMs, Interim Guidance Memoranda, SOPs, Job Aids and SERP Alerts.

4. Interviewing SMEs, observing and walking through processes.

5. Reviewing and following-up on applicable GAO and TIGTA findings and recommendations.

6. Identifying potential sources of data that could be used as evidence.

7. Reviewing relevant SMRs and/or QARs.

8. Reviewing any other miscellaneous documents.


3. The transaction lead documents the process and creates the CDA. The CDA defines the following transaction attributes:



01. Risks

02. Control activities

03. Control objectives

04. The risk level (high, medium or low)

05. Frequency of controls

06. Compensating controls

07. The type of control (preventive or detective)

08. How the control is performed (manual or automated)

09. The business unit SME

10. The financial assertions

11. The test objective where the control will be tested

12. References to policies and procedures

13. The enterprise risk the control mitigates


4. Using the CDA, the transaction lead determines the scope, objectives and methodology for testing.



1. The scope defines the boundaries of the tests and directly relates to the test objectives. For example, the period reviewed, the availability of necessary documentation or records and the locations of testing are included in the scope definition.

2. The test objective describes what testing intends to accomplish.

3. The methodology comprises the steps and techniques involved in gathering and analyzing data to achieve the objectives, such as inspecting sample data or observing controls. Additionally, it includes both the types and extent of test procedures used to achieve the objectives. The test plan documents and provides sufficient, competent and relevant evidence to achieve the test objectives.


5. After the scope, test objectives and methodology have been determined, the transaction lead develops the test plan. The test plan encompasses:



1. The control test objective

2. Population from which the testing sample size will be drawn

3. Sample methodology

4. Parameters that constitute a failed test

5. Specific tests and documents to review


6. Once the BPTP is complete, the transaction lead starts the approval process as follows:



1. The transaction lead sends the BPTP and CDA to the SMEs for review and comment. The transaction lead collaborates with the SMEs to update the BPTP, as necessary.

2. The transaction lead sends the BPTP to the team lead for review and updates the plan, as necessary.

3. The team lead sends the BPTP to the section chief for review and approval.

4. The section chief sends the BPTP to the Technical Review Board. The TRB has five business days to approve the BPTP.


7. **FACT BPTP Approval Process:** The flowchart below shows the process through which the BPTPs will progress. The bottom of the chart shows that the transaction lead develops the internal control BPTPs, then forwards the BPTP to the FACT section chief and/or team lead for internal reviews. Next, the Technical Review Board will review and approve the BPTPs. Finally, the tests plans are sent to Treasury.




| **FACT STRUCTURE FOR BUSINESS PROCESS TEST PLAN APPROVAL** |
| :-: |
|  |
| Department of the Treasury |
| ⇑ |
| FACT Technical Review Board |
| ⇑ |
| FACT Team Lead, FACT Section Chief and Director of Assurance Review and Testing |
| ⇑ |
| FACT Transaction Lead |
|  |


**1.4.3.3.2.1** **(04-01-2020)**

##### Assertions

1. Financial statement assertions are the implicit or explicit assertions that management is making to users of their financial statements. The role of FACT is to test the controls to determine whether management's assertions can be supported. The financial statement assertions are:



1. Completeness

2. Existence and occurrence

3. Accuracy and valuation

4. Rights and obligations

5. Presentation and disclosure


2. Completeness - Addresses whether all transactions and accounts that should be in the financial statements are included. To support the completeness assertion, FACT obtains sufficient, competent evidence that transactions that should be recorded have been recorded.

3. Existence and occurrence - Addresses whether assets or liabilities exist at a given date or recorded transactions have occurred during a given period. To support the existence and occurrence assertion FACT obtains sufficient evidence that the asset or liability existed at the time it was recorded.

4. Accuracy and valuation - Addresses whether assets, liabilities and equity interests included in the financial statements are at appropriate amounts and any corresponding adjustments are appropriately recorded. To support the accuracy and valuation assertion, FACT obtains sufficient evidence that transactions have been recorded accurately.

5. Rights and obligations - Addresses whether the entity holds or controls the rights to assets included on the financial statements and that liabilities are obligations of the entity. To support the rights and obligations assertion, FACT obtains sufficient evidence to confirm the IRS has a legal title or controls the rights to an asset or has an obligation to repay a liability.

6. Presentation and disclosure - Addresses whether components of the financial statements are properly classified, described and disclosed. To support the presentation and disclosure assertion, FACT obtains sufficient evidence to support that the account balance has not only been properly measured but also adequately described and disclosed.


**1.4.3.3.2.2** **(08-06-2024)**

##### Business Process Test Plan Template

1. The BPTP template is created during the planning phase to ensure consistency among all BPTPs. The template is used as the basis for all FACT BPTPs. The template contains the following sections:



1. Test Plan Guidance

2. ES/IPR

3. Table with Results

4. Test Objectives

5. Results of Testing

6. Definitions and Terms



      ### Note:



      Business process test plans that are tested in both interim and fourth quarter testing cycles will have one BPTP that captures both periods (the full year).


2. Test Plan Guidance



1. Test Plan detailed instructions



      ### Note:



      Some information will come directly from the Risk and Control Matrix.


3. ES/IPR



1. Summarize the test objectives.

2. Identify the results of testing.

3. Identify the current year findings and prior FACT findings.

4. Identify the standards and the responsible executive.


4. Table with Results



1. Summarizes the test results provided.

2. Lists all findings related to the transaction.


5. Test Objective



1. In general, internal control test objectives describe an assessment of one or more aspects of an entity’s internal control system and are designed to provide reasonable assurance of achieving effective and efficient operations, reliability of reporting for internal and external use, or compliance with provisions of applicable laws and regulations.


       i.) Test objectives may vary widely (based on the process under review) and are used to verify that internal controls are effective and operating as intended.

2. Delineate the purpose and scope of the test based on the control’s nature, frequency, and timing (Are all processes being tested or a specific subset? What is the frequency of the testing?)

3. Identify other resources needed to perform the control test (Who and what is needed to perform the testing?)

4. Determine of the type of relevant reporting assertion(s) provided by the control(s) (What type of assertion(s) are provided? Rights or Obligations; Completeness or Accuracy, Presentation or Disclosure; Existence or Occurrences; and Valuation or Allocation) Determination of the type of relevant reporting assertion provided by the control (What type of assertion do the controls provide?) Rights or Obligations; Completeness or Accuracy; Presentation or Disclosure; Existence or Occurrence; and Valuation or Allocation.

5. Each objective (in the BPTP) includes a list of steps that describe the methodology that will be used to accomplish the test objective.

6. Each BPTP includes an objective that addresses the design of the internal control system (under review). The purpose of this objective is to determine if the internal controls in place are designed adequately and to communicate any associated vulnerabilities. Steps (methodology) taken to achieve this objective include:


       i.) Reviewing relevant internal control documents (such as operating procedures, manuals, policies, and desk guides);


       ii.) Conducting interviews and/or walkthroughs;


       iii.) Assessing risk; and


       iv.) Reviewing the results of other oversight activity. Relevant sources of information include GAO and TIGTA audit reports GAO Management Report (related to the IRS financial statement audit) GAO audit findings, also called Matters for Further Consideration (MFCs Internal (IRS)) reviews.

7. Identify the method(s) of testing (Inspection of Documents, Observation, Inquiry or Walkthrough, or Reperformance).

8. Determine the sample size and basis (Specify the method used to select the sample and sample size.)

9. In addition, each BPTP also includes an objective that verifies the status of prior FACT findings and recommendations to ensure that corrective action (when appropriate) was taken to remediate the issue observed.


6. Results of Testing



1. Determine whether the controls that were tested are effective, overall.

2. Determine whether the process owner(s) consistently applied the controls.

3. Lists any findings related to the transaction.


7. Definitions and terms



1. Include process symbols, process names, transaction codes, transaction names, results of current, prior year and test objectives explanations.


**1.4.3.3.3** **(04-01-2020)**

#### Testing Phase

1. During the testing phase, the transaction lead executes the approved BPTP by:



1. Coordinating with business unit process owners.

2. Specifying when the testing phase begins/ends for interim and fourth quarter testing.

3. Obtaining a sample for testing from SOI.

4. Reviewing SMRs and QARs to determine if they provide assurance.

5. Performing substantive testing on samples and other supporting documentation.


**1.4.3.3.3.1** **(08-18-2023)**

##### Sampling

1. In defining the population, the transaction lead should identify the entire set of items from which the sample should be drawn. This includes:



1. Verifying the entire population is accounted for when the sample is drawn.

2. Determining the source document or the transaction documents to be tested.

3. Defining the period covered by the test.

4. If applicable, identifying significant subsets within the population, such as high dollar value items, and working with SOI to develop an appropriate sampling plan.


2. The sample items selected for testing purposes must come from the current fiscal year. However, when transactions occur only at the end of the fiscal year, a sample selection from the previous fiscal year may be permissible.

3. Changes to internal controls over financial reporting process and changes to financial systems should be considered when developing a sampling plan.

4. When sampling from multiple locations, the population may include all or several locations if the controls at each location perform the same function and use the same internal controls. Before combining separate locations into one population, management and the transaction lead should consider such factors as:



1. The extent of uniformity of the controls and their applications at each location.

2. Whether the individual locations can make significant changes to the controls or their application of these controls.

3. The amount and nature of centralized oversight or control over local operations.

4. Whether there may be a need to develop separate conclusions for each location. If the testers, transaction lead or manager concluded the locations should be separate populations, then transaction leads must select separate samples at each location, and testers and management will evaluate the results of each sample separately.


5. The transaction lead sends the population to SOI to generate the sample. SOI works with the transaction lead to determines the most appropriate sample method for each test to be performed. Sampling methodologies must be:



1. **Reliable**: Will the sampling approach produce dependable results?

2. **Consistent**: Can the sampling approach be applied uniformly?

3. **Valid**: Does the sampling approach adhere to applicable guidance and best practices? Does the BPTP measure what it is intended to measure?


6. FACT generally applies one of the following two sampling methods.



1. **Non-statistical sample**: A subset of a defined population, selected using judgement, but not valid to make statistical inferences within a defined level of confidence and precision.

2. **Random sample**: A subset of a defined population, selected using a statistically valid methodology in which every member of the population has a known, non-zero probability of being selected. With this method, transaction leads can make inferences about the population with a defined level of confidence and precision. The confidence level is fixed, but the precision level can vary. Usually, estimates have more precision as sample size increases.


7. Additional sampling consideration include:



1. Seasonal fluctuations (such as periods of limited availability), due to the nature of an activity, may necessitate multiple samples that cover several periods throughout the year to ensure a representative sample. The transaction lead should fully disclose seasonal fluctuations and other noteworthy conditions to SOI so that they can make an informed recommendation for an appropriate sample methodology.

2. In some instances, transaction leads may find that one or more of the sample items selected for testing cannot be reviewed (for example, the transaction was reversed and is no longer there). In these circumstances, the transaction lead should work with SOI to identify a replacement sample for testing and clearly document the need for this approach. As a precaution, transaction leads may ask SOI to identify additional sample items which can be used to test a control when a sample item cannot be tested. In this scenario, the transaction lead would test the next sample item identified in the sample selection list.


**1.4.3.3.3.2** **(04-01-2020)**

##### Review of SMRs and QARs

1. Quality reviews and quality assurance processes that are already in place are considered SMRs and may be tested as part of a FACT review. In addition, SMRs can also be leveraged to provide reasonable assurance over internal controls that are covered under a FACT review. If a transaction lead plans to leverage a SMR the review must contain sufficient information to enable an individual with no previous connection with the evaluation to understand what was reviewed, what was found, and to verify the reviewer’s judgments and conclusions. Refer to IRM 1.4.31, Quality Assurance Review Program, for additional details related to Quality Assurance Reviews.

2. To be considered, a SMR should have the following elements:



1. Documented procedures that guide the SMR.

2. Reviews performed at regular intervals.

3. Documented and independent review of results.

4. Documented processes to resolve noted deficiencies.


**1.4.3.3.3.3** **(04-01-2020)**

##### Substantive Testing

1. Substantive testing is performed by following the procedures the transaction lead identified in the BPTP to ensure controls are implemented and working as intended. The transaction lead may delegate substantive testing to supporting team members. The team member testing the samples must appropriately document and record test steps in their workpapers.

2. All aspects of testing activities require a high level of documentation. Documentation provides support for FACT planning, testing, and reporting processes, aids those conducting and leading the testing, and allows for reviews to be conducted. The test team obtains sufficient and appropriate evidence to develop a reasonable basis for an opinion regarding the effectiveness of internal controls tested through inspection, reperformance, observation, inquiries or confirmations. The documentation of evidence supports overall FACT conclusions.

3. Documentation related to planning, testing and reporting on FACT activities should contain sufficient information to enable an individual who has had no previous connection with the testing to understand what was tested, how the test was conducted, the test results and to verify the reviewer’s judgments and conclusions.

4. The FACT team determines the quantity, type and content of documentation, which provides a clear understanding of the internal control test’s purpose, data sources, results and conclusions. The team organizes the documentation logically to provide a clear link to the conclusions and issues. FACT test documentation must contain the following items:



1. Objectives, scope and methodology for each transaction, including the testing period, a description of the sampling methodology, and if the team deviated from the approved sampling methodology, the rationale for such actions.

2. Support for each test conducted, including the copies of documents examined and the rationale for key decisions and any deviations made from approved guidance.

3. Testing results, analysis and conclusions that provide a clear and concise summary of results cross-referenced to supporting documents and resolution of exceptions or other issues.

4. Evidence of transaction lead and/or supporting team member review and sign-off of workpapers and steps (as prepared) prior to supervisory review.

5. Evidence of FACT section chief, team lead or senior team member review of the work performed that supports conclusions about the controls tested.


5. Workpapers document the FACT review and record information obtained and analyzed during the FACT process. CCH TeamMate maintains all workpapers created directly in the system as well as workpapers scanned and uploaded into the system. The FACT team prepares and updates workpapers throughout the planning and testing phase and documents the following in CCH TeamMate:



1. Plans for the review, including the BPTPs.

2. Examination and the evaluation of the adequacy and effectiveness of the systems of internal control.

3. Test procedures followed, the information obtained and the conclusions reached.

4. Management reviews.

5. Audit reports.

6. Issues.


6. The transaction lead is responsible for determining which documents to include in the workpapers; the workpapers must include the following:



1. The business process test plan with detailed information of all test objectives.

2. For one sample, the workpapers must include one complete example that clearly identifies and documents all attributes tested.

3. For samples that contain exceptions, the workpapers must include all supporting documents.

4. Documents that may not be retrievable in their exact form at a later date. For example, if a screen print is necessary to support a number or dollar amount that may change in the future, that screen print should be retained to verify that figure as of the test date.


7. Among the required items above, workpapers may also include:



01. Planning documents and review plans.

02. Control questionnaires, flowcharts, checklists and the results of control evaluations.

03. Documentation of walkthroughs and interviews.

04. Organization charts, policy and procedures statements and job descriptions.

05. Copies of important contracts and agreements.

06. Letters of confirmation and representation.

07. Photographs, diagrams and other graphic displays.

08. Results of analytical review procedures.

09. Audit reports and management replies.

10. Emails, memos and other relevant correspondence.

11. CAPs, if appropriate and available.


8. The documentation within the workpapers must be appropriately organized to provide a clear link to the overall conclusion. Workpapers must be sufficient to show that the transaction lead completed the following:



1. Obtained guidance to understand the internal control, plan the testing and determine the nature, timing and extent of the tests performed.

2. Adequately planned and supervised work.

3. Observed standards of test work.

4. Obtained sufficient and appropriate documentation to support a reasonable conclusion.


9. The transaction lead should use the following techniques for documenting in workpapers:



1. **Annotation:** Highlight or identify the specific attribute in the workpapers that the team member verified, such as a signature indicating managerial approval.

2. **Indexing:** Workpapers will be automatically indexed once loaded into TeamMate to verify test plan results are properly referenced and can be easily traced to supporting documentation. When referring to reports in TeamMate, use the reference number and page number. Based on the associated test objective to the workpapers, TeamMate will automatically assign each workpaper a reference number.

3. **Sources of data:** Clearly identify the source of any information appearing in workpapers. An independent reviewer should be able to retrace the reviewer’s steps, from basic schedules to summaries and comments. Worksheets should be cross-referenced to other related workpapers and to the BPTP. Effective cross-referencing often reduces the need to duplicate data.

4. **Workpaper summary analysis:** The process of summarizing provides an objective overview and puts findings in perspective. The team’s summary should focus on key information and data. Do not include trivial information or editorial comments not supported by testing. Periodically summarizing findings helps verify firm control over the test.

5. **Record Key Meetings and Interviews:**Record all key discussions (meetings and interviews) used as support for key decisions (testing decisions/conclusions) and understanding the subject matter or test evidence and include the notes in the workpapers. Key decisions and conclusions are often a result of meetings and interviews. Without a record, important information will be lost. Use the format below.

6. **Keep the Writing Simple:** Workpapers should be clear and concise to an uninitiated reviewer. Avoid jargon and explain all technical terms and acronyms in a separate part of the workpapers (glossary of terms).

7. **Keep Workpapers Understandable:** Workpapers should be clear, concise and must stand on their own. They should not need any supplementary information. Anyone reading the papers should be able to determine what the team member set out to do, what they did, what they found, and what they concluded.

8. **Safeguard Personally Identifiable Information (PII):** Some workpapers and documentation contain PII (taxpayer, employee, vendor data, etc.) based on the type of review being performed. All PII must be protected according to the guidelines in IRM 1.4.18.12.4, Personally Identifiable Information, PII.

9. **Keep Workpapers Relevant:** Workpapers should be restricted to relevant and material matters; they should directly relate to the review’s objectives. Well-organized BPTP, execution of FACT procedures and workpaper reviews help verify the inclusion of relevant documents only. Do not include editorial comments and observations not supported by testing. It is important that all conclusions are in context and related to specific evidence.


**1.4.3.3.3.4** **(08-18-2023)**

##### Evaluating Exceptions and Classifying Findings

1. Test results support the FACT team’s conclusion on whether the controls (being tested) are adequate and effective. Exceptions found when testing may indicate that there is an issue with the controls. A testing exception is an attribute that does not meet the expected test criteria.



1. When exceptions are noted, the transaction lead should, in consultation with the team lead and section chief, determine the impact of the exception and the likelihood that the entity’s controls will fail to prevent, or detect and correct, misstatements in financial information.

2. When making this determination, the FACT team should consider a number of factors, to include: the frequency of errors, compliance with laws and regulations, materiality, impact to financial reporting, and if compensating controls are in place to reduce or address the impact and likelihood of the exception(s) noted, among other things.


       i) In this context, a compensating control is a technique or other effort(s) designed to mitigate a control design deficiency, or ineffective operation or implementation of a control, or the simple lack of control over a financial process or program.

3. Test exceptions may result in audit findings which could involve deficiencies in internal control; noncompliance with provisions of laws, regulations, contracts, and operating procedures (among other things); or instances of fraud.


       i) If fraud is suspected, the FACT team will pause testing, promptly notify TIGTA, and wait for instructions on how to move forward.


2. If testing exception(s) result in an audit finding additional consideration is needed to classify the finding according to the parameters below (listed from least severe to most severe):



1. **Control Deficiency (CD):** Exists when the design or operation of a control does not allow management or employees, in the normal course of performing their assigned functions, to prevent or detect misstatements on a timely basis.


       i) A simple deficiency is an internal control deficiency that creates minimal exposure for management and is generally an anomaly. Examples could include missing initials indicating a supervisor’s review on 1 of 26 reconciliations sampled, or the slight delay of an internal control activity.

2. **Significant Deficiency (SD):** An SD, or combination of internal control deficiencies, that adversely affects the entity’s ability to initiate, authorize, record, process or report external financial data reliably in accordance with generally accepted accounting principles such that there is more than a remote likelihood that a misstatement of the entity’s financial statements, or other significant financial reports, that is more than inconsequential will not be prevented or detected.


       i) The term “remote” is defined as the chance of the future event, or events, occurring is slight.


       ii) A misstatement is “inconsequential” if a reasonable person would conclude, after considering the possibility of further undetected misstatements, that the misstatement, either individually or when combined with other misstatements, would clearly be immaterial to the financial statements. If a reasonable person could not reach such a conclusion regarding a particular misstatement, that misstatement would be more than inconsequential.


       iii) Significant deficiencies are reportable conditions that warrant the attention of the MC ESC.

3. **Material Weakness (MW):** A reportable condition, or combination of reportable conditions, that results in more than a remote likelihood that a material misstatement of the financial statements, or other significant financial reports, will not be prevented or detected. Material weaknesses are reportable conditions that warrant the attention of the Management Controls Executive Steering Committee.


3. In addition to the categories described above, the FACT team may encounter a situation that doesn’t rise to the level of an audit finding, yet still warrants the attention of internal control process owners. Under these conditions, the FACT team has the ability to issue an MIO, which serves to notify the process owner of the situation observed. Unlike the findings described above, MIO notifications do not require a response or CAP.



### Note:



If the transaction lead determines the exception(s) warrant immediate attention, the transaction lead must contact the FACT section chief and/or team leader. The FACT section chief and/or team leader must notify the Assurance Review Testing Director and/or the Associate CFO for Internal Controls to notify them of the urgent situation. All audit findings and MIOs require formal documentation and notification to the process owner and IRS management. When documenting the issues and situations observed FACT team members must include the following information.





1. **Classification:** The type of issue observed (control deficiency, significant deficiency, material weakness or MIO).

2. **Condition:**A description of the situation in which the exception or issue was observed, along with any other pertinent information.

3. **Criteria:** Criteria may include the laws, regulations, contracts, standard operating procedures, IRMs, standards, measures, expected performance, defined business practices and benchmarks against which performance is compared or evaluated.


       i) Criteria identify the required or desired state or expectation with respect to the program or operation.


       ii) Criteria provide a context for evaluating evidence and a basis for understanding the findings, conclusions and recommendations that are being reported.

4. **Cause:** The cause is the factor or factors responsible for the difference between the condition and the criteria. The cause may also serve as a basis for recommendations for corrective actions.


       i) Common factors include poorly designed policies, procedures, or criteria; inconsistent, incomplete or incorrect implementation; unintentional oversights, or factors beyond the control of program management. Auditors may assess whether the evidence provides a reasonable and convincing argument for why the stated cause is the key factor contributing to the difference between the condition and the criteria.


       ii) The FACT team should follow-up with the process owner to make sure that they have a clear understanding of the root cause.

5. **Effect or potential effect:** The effect or potential effect is the outcome or consequence resulting from the difference between the condition and the criteria. It describes the impact or potential impact associated with the deficiency observed.


       i) Effect or potential effect may be used to demonstrate the need for corrective action in response to identified problems or relevant risks and should consider materiality, impact to financial reporting and compensating controls, among other things.

6. **Recommendation:** A recommendation is the FACT team’s proposed solution to address the deficiency observed and root cause.

7. **Responsible Entity:** The finding should indicate the responsible entity and process owners and/or manager(s).

8. **Owner Response with Corrective Action Plan:** After the information listed above has been prepared the FACT team issues the finding to the process owner and asks for their response. An owner response should describe management’s position on the issue and include a description of the corrective action that is planned to address the issue(s) observed. Corrective action should seek to address the root cause of the issue, correct past deficiencies (if possible) and prevent reoccurrence.


       i) If, for some reason, the process owner disagrees with the FACT team’s finding and recommendation, they should include a description for the basis of their disagreements and planned action when moving forward.


       ii) This also applies to situations where the process owner chooses to accept the risk associated with the deficiency. If the process owner chooses to accept the risk the FACT team will follow-up to request documentation in the form of an executed Risk Acceptance Form and Tool, Form 14675.

9. **Estimated Completion Date for Corrective Action:** The Owner’s Response should include an estimated completion date for the corrective action plan.


**1.4.3.3.4** **(04-04-2025)**

#### Reporting Phase

1. The final stage of the FACT cycle is the reporting phase. During the reporting phase, the transaction lead assesses the results of the testing and presents a conclusion to state whether the controls were found to be effective and adequate, or not.

2. The transaction lead creates four final reports:



1. **BPTP:** The BPTP is an excel spreadsheet that is maintained within TeamMate that provides a detailed account of the purpose of the transaction and the test results of each transaction test step performed. The FACT section chief and/or team leader submits the BPTP to the process owner(s) at the conclusion of testing so they may gain an understanding of the overall test results.

2. **IPR:** The IPR captures interim results with an expectation of final test results after FACT completes fourth quarter testing. An IPR will be issued in July to stakeholders as a midpoint of internal control testing. The IPR does not require an executive signature.

3. **CIR :** The CIR is a TeamMate-generated report that provides a detailed account of the findings identified when testing a transaction. The report is comprised of issues that were identified during the current testing period, any open findings from prior periods and any recently closed findings from prior periods. The CIR includes all elements of each finding that was issued, the process owner’s response (to describe their corrective action plan) and estimated completion date for corrective action.

4. **ES:** The ES is included as a tab within the BPTP and provides a high-level synopsis of the testing purpose, scope, and overall results, among other important information. The ES is issued to the responsible executive(s) for the transaction and is sent with a copy of the CIR and BPTP for their information and consideration. All ES must be signed and returned by the responsible executive(s) to acknowledge the test results. Note: An executive’s signature is viewed as an acknowledgement of the testing results rather than an acceptance of the conclusions made. An executive may disagree with the results but should always be able to demonstrate their acknowledgement via their signature on the ES.


**1.4.3.4** **(08-18-2023)**

### Continuous Monitoring

1. Continuous monitoring is the process and technology used to detect compliance and risk issues associated with an organization’s financial and operational activities. The financial and operational environment consists of the people, processes and systems working to support efficient and effective operations. Controls are put in place to address risks within these components.

2. Continuous monitoring actively identifies, quantifies and reports control failures such as duplicate vendor records, duplicate payments and transactions that fall outside of approved parameters. It highlights opportunities to improve operational processes.

3. Overall responsibility for IRS continuous monitoring includes:



1. **Management (all levels)**: Issues and monitors internal control programs, policies and procedures. Continuously assesses key business controls and transactions, which permits ongoing insight into the effectiveness of the controls and the integrity of transactions.

2. **Information Technology**: Issues security, policy and guidance for the IRS’s information systems (see IRM 10.8.1, Information Technology (IT) Security, Policy and Guidance). Conducts annual assessments of automated internal controls that affect authorizing, processing, transmitting or reporting material financial transactions to determine whether security controls are in place and operating effectively.

3. **CFO Financial Management**: Conducts reconciliations and reviews in preparation of financial statements to verify timely and accurate reporting.

4. **CFO FACT**: Conducts interim and year-end internal control testing to determine the IRS's compliance with laws and regulations. (See IRM 1.4.2, Monitoring and Improving Internal Control).


4. Continuous monitoring is a key function of the FACT team. The statuses of prior findings are tracked and reported within the JAMES system on a continuous basis. If the status is:



1. **Open:** The finding has been reported and corrective action has not been implemented.

2. **Open, Pending****:****** This indicates that the process owner has begun to take corrective actions(s); however, additional action still needs to be taken by the responsible process owner to remediate the finding prior to submitting for review and approval.

3. **Open, Implemented:** This indicates that the responsible process owner has implemented corrective actions and is awaiting verification to determine if their actions were effective in remediating the issue observed.

4. **Closed, Verified:** This indicates that the actions taken to remediate the finding have been verified and were effective in addressing the issue observed.


5. Continuous monitoring can be traced back to its roots in traditional auditing processes. However, it goes further than a traditional audit (which provides a snapshot at a specific point in time) by establishing continuous monitoring activities to inform management of internal control vulnerabilities or issues on a more frequent basis. This is especially applicable in an information systems environment where technology can be leveraged to provide frequent testing and continuous monitoring. (See NIST Special Publication 800-37, Revision 2, Risk Management Framework for Information Systems and Organizations: A System Life Cycle Approach for Security and Privacy.).

6. IT’s continuous monitoring activities supplement the FACT internal control activities (through interim and year-end operational controls testing). Each year, the FACT team tests various IT transactions to ensure compliance with Treasury guidance.

7. Through continuous monitoring, weak or poorly designed controls can be corrected or replaced to improve the IRS risk profile. Multi-disciplinary teams consisting of automated systems specialists, accounting and reporting experts will use the appropriate policies and procedures as a basis for performing periodic and routine examinations of the financial systems that authorize, process, transmit or report material financial transactions.


**1.4.3.5** **(08-18-2023)**

### Record Retention

1. FACT has established a 6-year standard for record retention. Certain FACT records could be considered ancillary records in situations where FACT testing has an influence on the IRS’s Statement of Assurance. This being the case, the records would be captured under General Records Schedule 5.7, item 050. On a yearly basis, FACT management will identify records which fall outside the retention period per the Records Retention and Disposal SOP.


**Exhibit 1.4.3-1**

### Record of Discussion

| **Record of Discussion** |
| :-: |
| **Date:** | **Time:** |
| **Type of Contact:** | **In Person:** | **By Telephone:** |
|  |  |  |
| **Location of Discussion:** |
| Conference Call |
|  |  |  |
| **Person(s) Contacted/Interviewed:** _(Please list all participants)_: |
| Name, Position/Title, Office, Telephone Number |
| Name, Position/Title, Office, Telephone Number |
|  |  |  |
| **Initiator(s)/Interviewer(s):** |  |
| Name, Position/Title, Office, Telephone Number |
|  |  |  |
| **Purpose:** |  |  |
| (Provide a brief description of the meeting objective.) |
|  |  |  |
| **Discussion:** |  |  |
| (Provide notes from the meeting.) |
|  |  |  |
| **Other Matters Discussed:** |
| (Provide detailed notes of other matters discussed outside of the general purpose of the meeting.) |
|  |  |  |
| **Follow-up Actions:** |
| (List follow-up actions from the meeting.) |
|  |  |  |
| **Documents to Obtain:** |
| (List documents to obtain related to the meeting discussion.) |

**Exhibit 1.4.3-2**

### Sample Sizes and Acceptable Number of Errors (90% Confidence Level)

In defining the severity of the exceptions, the transaction lead may use the error rate tables. The transaction lead may use judgment in applying Tables I and II. Tables I and II show various sample sizes and the maximum number of errors that may be detected. The use of each table is encouraged for population sizes over 2,000 items. However, according to the GAO/Council of the Inspectors General on Integrity and Efficiency (CIGIE) Financial Audit Manual, if the population size is smaller, the statistician may be asked to calculate a reduced sample size. The transaction lead will use judgment to evaluate the existence and significance of a deficiency.

> **Sample Sizes and Acceptable Number of Errors (90% Confidence Level)**

| **Table I (Tolerable Rate of 5%)** |
| :-: |
| **Sample Size** | **Acceptable Number of Exceptions** |
| :-: | --- |
| 45 | 0 |
| 78 | 1 |
| 105 | 2 |
| 132 | 3 |
| 158 | 4 |
| 209 | 6 |

### Note:

Table I is used for determining sample sizes in all cases.

| **Table II (Tolerable Rate of 10%)** |
| :-: |
| **Sample Size** | **Acceptable Number of Exceptions** |
| --- | --- |
| 45 | 1 |
| 78 | 4 |
| 105 | 6 |
| 132 | 8 |
| 158 | 10 |
| 209 | 14 |

### Note:

Table II is used for evaluating sample results only if preliminary assessment of financial reporting control risk is low and exceptions exceed Table I.

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-004-003#addtoany "Show all")

A2A