---
url: "https://www.irs.gov/irm/part1/irm_01-011-004"
title: "1.11.4 Servicewide Delegation Order Process | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-011-004#main-content)

- 1.11.4  [Servicewide Delegation Order Process](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737123961216)
  - 1.11.4.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737095275456)
    - 1.11.4.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737095267344)
    - 1.11.4.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737095480112)
    - 1.11.4.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737095475760)
    - 1.11.4.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737095468480)
    - 1.11.4.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737096449168)
    - 1.11.4.1.6  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737096445520)
  - 1.11.4.2  [Types of Delegations of Authority](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737096370880)
  - 1.11.4.3  [Purpose of Delegation Orders](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737096366992)
    - 1.11.4.3.1  [Rules for Acting Supervisory Officials](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737096356112)
    - 1.11.4.3.2  [Effect of Personnel and Organizational Changes on Delegation Orders](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737095457728)
  - 1.11.4.4  [Functional Statements](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737095455216)
  - 1.11.4.5  [Servicewide Delegation Order Standards](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737095448416)
    - 1.11.4.5.1  [Creating, Revising and Rescinding Servicewide Delegation Orders](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737095429296)
    - 1.11.4.5.2  [Servicewide Delegation Order Content](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737095418752)
      - 1.11.4.5.2.1  [Redelegation of Authority](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737096388032)
    - 1.11.4.5.3  [Procedures for Clearing Servicewide Delegation Orders](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737123503552)
      - 1.11.4.5.3.1  [Clearance Package for Internal, External, and Specialized Reviewers](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737123480128)
      - 1.11.4.5.3.2  [No Response to Clearance Request](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737096480208)
      - 1.11.4.5.3.3  [Final Clearance Package for SPDER Review](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737096476480)
    - 1.11.4.5.4  [Issuance and Publishing of Servicewide Delegation Orders](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737123386176)
    - 1.11.4.5.5  [Editorial Changes for Servicewide Delegation Orders](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737123379664)
  - 1.11.4.6  [Business Unit Delegations Order Standards](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737123370816)
    - 1.11.4.6.1  [Creating, Revising and Rescinding Business Unit Delegation Orders](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737123365264)
      - 1.11.4.6.1.1  [Numbering Business Unit Delegation Orders](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737094672528)
    - 1.11.4.6.2  [Business Unit Delegation Order Content](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737094666592)
    - 1.11.4.6.3  [Procedures for Clearing Business Unit Delegation Orders](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737094662368)
    - 1.11.4.6.4  [Issuance and Publishing of Business Unit Delegation Orders](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737094629056)
  - Exhibit  1.11.4-1  [Sample Servicewide Delegation Order](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737094624048)
  - Exhibit  1.11.4-2  [Sample Delegation Order with Multiple Authorities](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737094615936)
  - Exhibit  1.11.4-3  [Sample of Rescinded Delegation Order](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737094594432)
  - Exhibit  1.11.4-4  [Sample Business Unit Delegation Order](https://www.irs.gov/irm/part1/irm_01-011-004#idm139737094590144)

# Part 1. Organization, Finance, and Management

# Chapter 11. Internal Management Documents System

# Section 4. Servicewide Delegation Order Process

* * *

## 1.11.4 Servicewide Delegation Order Process

#### Manual Transmittal

February 04, 2025

#### Purpose

(1) This transmits revised IRM 1.11.4, Internal Management Document System, Servicewide Delegation Order Process.

#### Material Changes

(1) _IRM 1.11.4.1_, Program Scope and Objectives

- Paragraph (1) - Updated purpose of this IRM section.

- Paragraph (2) - Updated to include management.

- Paragraph (3) - Policy owner updated to Director, Strategy and Business Solutions (SBS).

- Paragraph (4) - Updated to include the business unit responsibilities.

- Paragraph (5) - Added “Primary Stakeholders.”


(2) _IRM 1.11.4.1.2_, Authority

- Paragraph (2) - Updated to describe the authorities of the Commissioner of Internal Revenue.


(3) _IRM 1.11.4.1.3_, Roles and Responsibilities

- Paragraph (1) - Business unit IMD/Delegation Orders Coordinator role added to the list.

- Paragraph (3) - Chiefs reporting directly to the Deputy Commissioner of Internal Revenue added to the list.

- Paragraph (4) - The Director, Strategy and Business Solutions (SBS), RAAS role updated.

- Paragraph (5) - Chief Operating Officer (COO) role and responsibilities added to list.


(4) _IRM 1.11.4.1.4_, Program Management and Review

- Paragraph (3) - Updated to provide additional details regarding the annual IMD Certification process.


(5) _IRM 1.11.4.1.5_, Program Controls

- Paragraph (1) - New subsection added.


(6) _IRM 1.11.4.1.6_, Terms and Acronyms

- Paragraph (1) (Table) - New terms and acronyms added. Definitions for Servicewide delegation orders, Business unit delegation orders, and the Freedom of information Act (FOIA) were expanded.


(7) _IRM 1.11.4.2_, Types of Delegations of Authority

- Paragraph (2) - Removed paragraph. Removed language describing a process for deviating from delegation orders.


(8) _IRM 1.11.4.3_, Purpose of Delegation Orders - Subsection title revised.

- Paragraph (2) List revised to include position descriptions and other documents that describe an official's duties.

- Paragraph (4) and (5)- revised to explain the purpose of Servicewide delegation orders and business unit delegation orders.

- Paragraph (7), and (8) - Removed paragraphs.


(9) _IRM 1.11.4.3.1_, Rules for Acting Supervisory Officials - New subsection added that details the requirements for officials serving in an acting capacity and how authorities are delegated in the roles. This formation previously existed under another subsection of IRM 1.11.4.

(10) _IRM 1.11.4.4_, Functional Statements - This subsection previously existed under another subsection of IRM 1.11.4.

- Paragraph (2) - Added to describe the responsibilities of the business units to establish and maintain their functional statements.


(11) _IRM 1.11.4.5_, Servicewide Delegation Order Standards - Title updated to include the term “Standards.” Subsection that describes the standards for Servicewide delegation orders.

- Paragraph (2) - Updated to remove unnecessary language and improve clarity.

- Paragraph (3) - Added the standards for the business unit senior executive.

- Paragraph (4) - Added the standards for the business unit’s senior executive’s to review delegation orders annually.

- Paragraph (5) - Added procedural resources for revising, issuing, and formatting delegation orders.

- Paragraph (7) - Added the general standards for clearing delegation orders.

- Paragraph (8)(a), (b), and (c) - Added standards for redelegating authorities.

- Paragraph (9) - Added the standards for the effective date of the delegation orders.

- Paragraph (10) - Added the standards for rescinding delegation orders.

- Paragraph (11) - Added the standards for having delegation orders reviewed, approved, and posted.


(12) _IRM 1.11.4.5.1_, Creating, Revising and Rescinding Servicewide Delegation Orders - IRM subsection revised to update title and consolidate the list of delegation order actions.

- Paragraph (2)(c) - Added resource for new delegation order research.

- Paragraph (3) - Added more details and resources for revised delegation research.

- Paragraph (4) - Added resources for rescinding existing delegation orders.


(13) _IRM 1.11.4.5.2_, Servicewide Delegation Order Content

- Paragraph (1) - Revised to expand explanation.

- Paragraph (2) - Added requirements to number each delegated authority when multiple authorities included in the delegation order.

- Paragraph (5) - Added requirement to include an electronic link to each listed sources of authority.

- Paragraph (6) - Added sample ratification paragraphs.

- Paragraph (7) - Added the requirements and formatting of the approving officials’ signature line

- Paragraph (8) - Added requirement to include an electronic link to each referenced source of authority, IRM, IRC, etc.

- Paragraph (9) - Added link to the IMD Community site to view sample delegation orders templates

- Paragraph (10) - Added language that explains that delegation orders must not contain Official Use only (OUO), Sensitive But Unclassified (SBU) or Controlled Unclassified Information (CUI) content.


(14) _IRM 1.11.4.5.2.1_, Redelegation of Authority - New subsection added to outline redelegation authorities. This subsection provides the purpose of redelegating authorities, the methods for redelegating authorities, and limitations for redelegatiing authorities.

(15) _IRM 1.11.4.5.3_, Procedures for Clearing Servicewide Delegation Orders

- Paragraph (1) - Added requirement to send draft delegation order to SPDER before formal clearance.

- Paragraph (2) - Added the list of reviewers that are required to view delegation orders during clearance.

- Paragraph (3) - Added resources for identifying affected offices.

- Paragraph (4) - Added link to a SPDER listing of business unit points of contact.

- Paragraph (5) - Added the timeframes allotted for delegation order review.

- Paragraph (6) - Added requirements for expedited reviews.

- Paragraph (7) - Added requirements and order of Chief Counsel review. Added Chief Counsel contact information.

- Paragraph (8) - Added link to IRM 1.11.9.9, Resolving Disagreements

- Paragraph (9) - Updated the order for sending clearance package to author’s manager, the business unit senior executive, and the Chief reporting directly to the Deputy Commissioner Internal Revenue (if applicable) for review. Added timeframes for responses to review requests.

- Paragraph (10) - Updated requirements for forwarding completed clearance packages to SPDER.

- Paragraph (11) - Added requirement to submit package to SPDER within one year of initiating clearance.


(16) _IRM 1.11.4.5.3.1_, Clearance Package Sent to Internal, External, and Specialized Reviewers - New subsection with updated guidance for the clearance packages sent to reviewers. Removed requirement to include Form 14074, Action Routing Sheet. This document is no longer required for SPDER purposes.

- Table (a) - Added the requirement for the Chief reporting directly to the Deputy Commissioner Internal Revenue (if applicable) to review and complete Form 2061.

- Table (b) - Revised language to improve clarity and removed requirement for draft memo to be on Commissioner or Deputy Commissioner’s letterhead.

- Table (c) - Removed requirement for track changes memo to be on Commissioner’s or Deputy Commissioner's letterhead. Added requirement to provide a complete track changes document.


(17) _IRM 1.11.4.5.3.2_, No Response to Clearance Request - New subsection added to provide procedures to follow when no response is received for a clearance review request.

(18) _IRM 1.11.4.5.3.3_, Final Clearance Package Sent to SPDER for Review - New subsection with updated guidance for the clearance packages sent to SPDER for review. Removed requirement to mail a completed paper package to the IRS Historical Research Library.

- Paragraph (2(c) - Added requirement to include a track changes Word file with new delegation order.

- Paragraph (3)(e) - Added reference to the Chief reporting directly to the Deputy Commissioner Internal Revenue.

- Paragraph (4)(a) - Added Chief, IMD Program.

- Paragraph (4)(c) - Added Chief Data and Analytics Officer.

- Paragraph (4)(d) - Added Chief Operations Officer.

- Paragraph (5) - Added the routing process for the final clearance package.


(19) _IRM 1.11.4.5.4_, Issuance and Publishing of Servicewide Delegation Orders - New IRM subsection that describes the SPDER process for issuing and publishing new, revised or rescinded Servicewide delegation orders.

(20) _IRM 1.11.4.5.5_, Editorial Changes for Servicewide Delegation Orders

- Paragraph (2) - Added “Updating delegation order titles.”

- Paragraph (3) Note - Added a note regarding approving officials requirements.


(21) _IRM 1.11.4.6_, Business Unit Delegation Orders Standards - New subsection that describes the standards for business unit delegation orders.

- Paragraph (1) - Added to describe the purpose of a business unit delegation order.

- Paragraph (3) - Added to describe the parameters of the business unit delegation order.

- Paragraph (5) - Added to describe how business unit delegation orders impact permanent and acting officials.

- Paragraph (6) - Added a reference that explains format requirements.

- Paragraph (7) - Added to explain that business unit counsel and SPDER must review new and revised business unit delegation orders.


(22) _IRM 1.11.4.6.1_, Creating, Revising and Rescinding Business Unit Delegation Orders - New subsection that list the required actions for business units when creating, revising, or rescinding a business unit delegation order.

(23) _IRM 1.11.4.6.1.1_, Numbering Business Unit Delegation Orders - New subsection that explains the process and requirements for numbering business unit delegation orders.

(24) _IRM 1.11.4.6.2_, Business unit Delegation Order Content - Updated title.

(25) _IRM 1.11.4.6.3_, Procedures for Clearing Business Unit Delegation Orders - Title updated. Table added to list the documents required for clearance.

- Paragraph (2) - Table - Added table that lists the documents required for clearing business unit delegation orders.

- Paragraph (3) Note - Added list of required reviewers. Added requirement to include SPDER on Form 2061 when clearing business unit delegation order.

- Paragraph (4) - Added link to a SPDER listing of business unit points of contact.

- Paragraph (5) - Added the timeframe allotted for review by affected offices, functions, or areas.

- Paragraph (6) - Added the timeframe allotted for Chief Counsel review and review requirements.

- Paragraph (7) - Added the timeframe allotted to secure management review, IMD Coordinator review, and business unit executive's approval and signature. Requirement to consult with the business unit that owns the Servicewide delegation order being used as the source of authority for the business unit delegation order.


(26) _IRM 1.11.4.6.4_, Issuance and Publishing of Business Unit Delegation Orders - Updated title.

- Paragraph (2) - Updated to clarify the business unit’s responsibilities for issuing and publishing business unit delegation orders. Added link to IRM 1.11.10, Interim Guidance Process.


(27) _Exhibit 1.11.4-1_, Sample Servicewide Delegation Order - Updated title. Fictionalized approving official’s name.

(28) _Exhibit 1.11.4-2_, Sample Delegation Order with Multiple Authorities - Added a new delegation order. Fictionalized approving official’s name.

(29) _Exhibit 1.11.4-3_, Sample of Rescinded Delegation Order - Added a new delegation order. Fictionalized approving official’s name.

(30) _Exhibit 1.11.4-4_, Sample Business Unit Delegation Order - Replaced previous example with a new example. Fictionalized approving official’s name.

(31) The following changes made throughout:

- Editorial changes to language made throughout to improve clarity.

- IRM 1.11.4 subsections reorganized to improve clarity and readability

- IRM 1.11.4 subsection titles updated to improve clarity.

- The terms “division” and/or “function,” as used to describe organizations, have been replaced with the term “business units.”

- Lists converted to table to improve readability.

- Links updated and/or revised throughout the IRM.


#### Effect on Other Documents

This supersedes IRM 1.11.4 dated April 9, 2020.

#### Audience

Senior executives, business unit IMD coordinators, authors, managers, and reviewers who develop, review or approve delegation orders in all business units.

#### Effective Date

(02-04-2025)

Holly A. Donnelly

Director, Strategy & Business Solutions

Research, Applied Analytics and Statistics

**1.11.4.1** **(02-04-2025)**

### Program Scope and Objectives

1. **Purpose:** This IRM section defines delegations of authority, describes the types of delegation authorities, and explains the purpose of delegation orders. This IRM section also provides instructions for preparing, reviewing, approving and issuing Servicewide delegation orders and business unit delegation orders.

2. **Audience:**These procedures apply to management and employees who are responsible for, creating, revising and rescinding IRS delegation orders.

3. **Policy owner:** Director, Strategy and Business Solutions (SBS), Research, Applied Analytics and Statistics (RAAS).

4. **Program owner**: The Office of Servicewide Policy, Directives and Electronic Resources (SPDER) within SBS, RAAS is the program office responsible for overseeing the Internal Management Document (IMD) process and providing guidance. Each business unit is responsible for establishing an internal process for managing their procedures based upon these Servicewide processes. This includes designating an IMD Coordinator and team to oversee the process within their respective business units.

5. **Primary Stakeholders:**All organizations and business units that use, manage, own, or issue delegation orders approved by the Commissioner or Deputy Commissioner of Internal Revenue.

6. **Contact Information**: Email \*SPDER to recommend changes or make any other suggestions for this IRM section.


**1.11.4.1.1** **(04-09-2020)**

#### Background

1. This IRM section enables the IRS to meet certain federal requirements to document, publish and maintain records of policies, authorities, procedures and organizational operations described in IRM 1.11.1.1.2, Authority.

2. The IRS Restructuring and Reform Act of 1998 resulted in a complete restructuring and reformatting of the IRM to align with the IRS business processes. One of the primary goals of the IRS modernization was to restore and maintain the IRM as the single, official compilation of IRS policies, procedures and guidelines.

3. In 1999, the IRS formed the Office of Servicewide Policy, Directives and Electronic Resources (formerly Servicewide Policy, Directives and Electronic Research). SPDER is responsible for designing, implementing, and managing a strategic approach to setting Servicewide policy for internal management directives. See IRM 1.11.1, Internal Management (IMD) Program and Responsibilities, for information about the effect of these changes.


**1.11.4.1.2** **(02-04-2025)**

#### Authority

1. By law, federal agencies are expected to document, publish and maintain records of policies, authorities, procedures and organizational operations. The IRM is the source for the IRS. See IRM 1.11.1.1.2, Authority, for the authorities and legal obligations of IMDs.

2. 26 CFR 301.7701-9 outlines the delegation and redelegation rules which apply to officials described in the Internal Revenue Code (IRC). Per this authority, the Commissioner of the Internal Revenue is a delegate of the Secretary of Treasury. 26 CFR 301.7701-9 authorizes the Commissioner of the Internal Revenue to redelegate authorities, including authorities specified in Treasury regulations or Treasury decisions, to other IRS officials. They are authorized to perform these actions, unless prohibited or restricted by order or directive. Additionally, it authorizes further redelegation of the authority to officers or employees under their supervision and control, unless prohibited or restricted by order or directive.

3. The Freedom of Information Act (FOIA), [5 USC 552(a)(2)(c)](https://www.justice.gov/oip/freedom-information-act-5-usc-552), requires each agency to make available, in an electronic form, administrative guidance affecting a member of the public. The published delegation orders found on IRS.gov or in IRM 1.2.2, Servicewide Delegations of Authority, fulfills this legal responsibility.


**1.11.4.1.3** **(02-04-2025)**

#### Roles and Responsibilities

1. The business unit (BU) IMD/delegation orders coordinators are responsible for overseeing their business unit’s delegation orders program and providing guidance to authors of delegation orders.

2. The business unit senior executives are responsible for all delegation orders assigned to their respective business units. They ensure the accuracy and validity of their Servicewide delegation orders (SDO) and provide the final approval for their business unit delegation orders, when redelegation is authorized.



### Note:



Business unit senior executives report directly to the Commissioner of Internal Revenue, Deputy Commissioner of Internal Revenue, Chief Tax Compliance Officer, or Chief Operating Officer.

3. The Chiefs reporting directly to the Deputy Commissioner of Internal Revenue oversee a single business unit or multiple business units. These executives include the Chief, Taxpayer Services, Chief Tax Compliance Officer, Chief Information Officer, Chief Operating Officer, and Director, Online Services. The Deputy Commissioner’s direct reports serve as the final reviewer for Servicewide delegation orders owned by the business units under their purview.

4. The Director, Strategy and Business Solutions (SBS), RAAS is the program director responsible for IMD program administration. The Director, SBS, designates oversight responsibility for the IMD program, including delegation orders to the Director, Servicewide Policy, Directives and Electronic Resources (SPDER).

5. The Chief Operating Officer (COO) is responsible for providing direction and oversight to the major operational and administrative functions for the IRS.

6. The Commissioner of Internal Revenue or Deputy Commissioner of Internal Revenue review, approve and sign Servicewide delegation orders.


**1.11.4.1.4** **(02-04-2025)**

#### Program Management and Review

1. The business unit senior executives of each IRS organization are responsible for reviewing, maintaining and archiving delegation orders for their respective programs.

2. SPDER conducts an annual review of each business units’ delegation orders using the Annual IMD Certification process. SPDER compiles the data and generates a report for business unit senior executives, managers, IMD coordinators, and staff. This report captures each business unit’s IMD program accomplishments and areas of opportunity. The results of this review are used by the business units to improve IMD program management.


**1.11.4.1.5** **(02-04-2025)**

#### Program Controls

1. Annual Report on the Internal Management Documents (IMD) Program - An annual memorandum issued to the heads of office on the accomplishments and activities of the IMD program. This report provides senior executives with the information and resources necessary to efficiently manage their respective IMD programs.

2. Annual IMD Program Risk Analysis Report - This analysis report provides the status of Servicewide delegation orders and the actions taken by each business units to resolve these issues and mitigate risk. SPDER shares a report with each business unit’s senior executive, IMD coordinator, and staff.

3. IMD Tracking System - This tool allows SPDER to manage the receipt and posting of new, revised, and rescinded delegation order memos. Delegation orders are updated in the IRM biannually, so this tool was is designed to house and immediately make available the delegation orders memos pending updates to IRM 1.2.2, Servicewide Delegations of Authority. The IMD Tracking system is also used to archive delegation orders as they are published to IRM 1.2.2. It allows for the efficient management and retrieval of approved delegation orders.


**1.11.4.1.6** **(02-04-2025)**

#### Terms and Acronyms

1. Common terms and definitions




| **Term** | **Definition** |
| --- | --- |
| Business Unit (BU) Delegation Order (DO) (formerly Division/Function delegation order) | A business unit delegation order is derived from a Servicewide delegation order. This delegation of authority is issued by the individuals granted authority by the Servicewide delegation order, to their subordinate officers or employees where the authority has been granted to the senior executive through a Servicewide delegation order. |
| Business Unit Senior Executive | National Taxpayer Services (NTA); Chief, Independent Office of Appeals; Director, Online Services; Chiefs, Directors, Deputy Commissioners, or officers overseeing business units reporting directly to the Commissioner of Internal Revenue, Deputy Commissioner of Internal Revenue, Chief Tax Compliance Officer, or Chief Operating Officer. |
| CIO | Chief Information Officer |
| COO | Chief Operations Officer |
| CTCO | Chief Tax Compliance Officer |
| CTS | Chief, Taxpayer Services |
| Freedom of Information Act (FOIA) | A federal law (5 USC 552) that requires federal agencies to make available to the public certain documents or information including administrative procedural manuals and instructions to staff, unless the documents are exempt from disclosure. |
| Functional Statement | A high-level description of the activities and functions of a business unit. It includes the mission or goals, reporting structure, responsibilities and activities taken to achieve the mission. Functional statements also document the authority for the executives and the responsible officials to perform the identified activities, including the issuance and signing of official documents. Functional statements are issued through an IRM section under IRM 1.1, Organization and Staffing. |
| Internal Management Documents (IMDs) | Official communications that designate policies, authorities and instructions to IRS officials and employees. |
| Servicewide Delegation Order (SDO) | An official IRS document providing specific delegations of authority issued by the Commissioner of the Internal Revenue, or on their behalf by the Deputy Commissioner. Delegations are made to subordinate officials, with or without restrictions on redelegation. Servicewide delegation orders are issued when it is necessary to describe the delegation of authority for a specific action or activity based on the IRC, statute, Treasury Regulations or Treasury Decisions. A SDO specifies which IRS officials may perform certain functions, actions, or approve an IRS activity on behalf of the IRS. |
| Treasury Decision (TD) | A document that contains the text of a final or temporary regulation published in the Internal Revenue Bulletin (IRB). The Treasury Decision adds new text to or removes or revises text already published in the Code of Federal Regulations (CFR) and includes applicability for the regulation and the effective date. |

2. See IRS Organization Top Officials Chart for a listing of the Department of Treasury Internal Revenue Service Organization and Top Officials.


**1.11.4.2** **(02-04-2025)**

### Types of Delegations of Authority

1. There are two primary types of delegations of authority:



   - Servicewide delegation orders

   - Business unit delegation orders (formerly Division/Function Delegation Orders)



     ### Note:



     See _IRM 1.11.4.1.6_, Terms and Acronyms, for definitions of these two types of delegations of authority.


**1.11.4.3** **(02-04-2025)**

### Purpose of Delegation Orders

1. Delegations of authority are used to:



1. Place authority in the position(s) where actual operational responsibility resides.

2. Free officials from having to consider issues that can be handled at lower levels.

3. Reduce the time and resources a senior executive might spend on a matter that can be addressed by designated officials or employees.


2. Delegations of authority from the Commissioner to subordinate IRS officials are derived from:



   - Statute

   - Treasury Decisions

   - Treasury Directives

   - Treasury Orders

   - Treasury Regulations

   - Functional Statements (as published in IRM 1.1, Organization and Staffing)

   - Memoranda (signed by the Commissioner or Deputy Commissioner)

   - Position Descriptions and other documents that describe an official's duties with particularity are sufficient to provide the official with the authority necessary to carry out such duties


3. Delegations of authority must be in writing and must clearly establish the intent of the authorized delegating official.

4. Servicewide delegation orders are issued when it is necessary to describe the delegation of authority for a specific action or activity based on the IRC, statute, Treasury Regulations or Treasury Decisions. A SDO specifies which IRS officials may perform certain functions, actions, or approve an IRS activity on behalf of the IRS.

5. Business unit delegation orders are generally derived from Servicewide delegation orders and functional statements. If a Servicewide delegation order allows authorities to be redelegated, business units may redelegate those authorities to the appropriate officials as allowed by the Servicewide delegation order.

6. An SDO is **mandatory** when litigation over the activity can reasonably be expected.


**1.11.4.3.1** **(02-04-2025)**

#### Rules for Acting Supervisory Officials

1. If a supervisory official expects to be absent for a full workday or longer, an acting supervisory official must be designated in writing or become acting when the provisions are set in applicable delegations. See IRM 1.2.2.2.2, Delegation Order 1-2 Designation for Acting Supervisory Officials, for more information.



### Note:



The designation of an acting official for a shorter absence is at the discretion of the current supervisory official or a higher level supervisor.

2. An official serving in an acting capacity will exercise the authority of their permanent position and the acting position when no acting official is designated for (or automatically assumes) their permanent position.



### Exception:



Limitations on authorities must be imposed in writing for specific cases or where prohibited by law. Otherwise, an acting official assumes the full authority vested in or delegated to that position.


**1.11.4.3.2** **(05-06-2006)**

#### Effect of Personnel and Organizational Changes on Delegation Orders

1. Delegations of authority issued by a prior official remain valid, unless or until the authority is rescinded or modified. Officials and designated employees currently occupying a position assume all authorities granted to the previous official or employee in that position.

2. When an organizational or personnel change is made that alters a title/designation without causing a substantive change in function or duty, the existing delegation order will remain in effect.


**1.11.4.4** **(02-04-2025)**

### Functional Statements

1. Functional statement IRMs describe the activities and functions performed by each business unit and provide their stated jurisdictions and functions.

2. Each IRS business unit is responsible for publishing a functional statement in IRM 1.1, Organization and Staffing. A business unit’s functional statement IRM provides a high-level description of their operations, organizational structure, and activities the business unit performs to achieve the IRS mission. It also documents the delegated functions and activities of the executive and the responsible officials to perform the identified activities, including the issuance and signing of official documents.

3. A functional statement IRM contains:



1. Business unit’s mission

2. Strategic goals

3. Offices and their primary responsibilities

4. Reporting structure


4. See IRM 1.11.2.2.5, Functional Statement IRM, for additional guidance on functional statement requirements.


**1.11.4.5** **(02-04-2025)**

### Servicewide Delegation Order Standards

01. Servicewide delegation orders (SDO) redelegate authorities granted to the Commissioner by statute, Treasury Regulations or Treasury Decisions. Authorities include administrative, compliance, data processing, submission processing, accounts management and customer service/campus activities.

02. The Commissioner of Internal Revenue or the Deputy Commissioner of Internal Revenue approve and sign all new, revised, and rescinded Servicewide delegation orders.

03. Business unit senior executives are responsible for ensuring delegated authorities within their business units are correctly documented in a **business unit delegation order**.

04. Responsible business unit senior executives must _review their delegation orders annually_ to ensure the content in the delegation is current, applicable and valid.

05. Delegation orders contain specific content and follow a specified format. See IRM 1.11.4.6.2, Revising and Issuing Servicewide Delegation Orders, and IRM 1.11.4.6.3, Delegation Order Content.

06. Servicewide delegation orders are numbered sequentially, according to IRS business process (conforming to the IRM).



    ### Example:



    A SDO relating to the examining process is numbered Delegation Order 4-XX; IRS delegation orders relating to human capital management are numbered Delegation Order 6-XX. Although delegation orders are numbered to correspond to the processes represented by the IRM part numbers, the authorities apply to any and all IRS personnel and activities according to their terms. For a complete listing of IRM part numbers see IRM 1.11.1.5, IMD Numbering by Business Process.





    ### Note:



    New delegation orders and number assignment must be coordinated through the SPDER program office. IMD Coordinators must contact \*SPDER to request a new delegation order number.

07. Delegation orders must be cleared through affected offices, SPDER, Taxpayer Advocate Office (TAS), Chief Counsel, and the originating office’s senior executives, prior to submitting to the Commissioner or Deputy Commissioners for approval and signature. See IRM 1.11.4.6.4, Procedures for Clearing Servicewide Delegation Orders.

08. Authorities must be delegated to the lowest level expected to take final action. Delegating authorities to the lowest level for action means that:



    1. Every supervisory position in the chain of command (intervening line of authority) from the Commissioner to the lowest designated official has the same authority.



       ### Note:



       In some exceptional cases, delegations are assigned to specific individuals, do not follow the chain of command, and bypass certain officials.

    2. Persons who hold the same position (title) as the lowest delegated authority but at a higher grade within the same office/function can exercise the delegated authority. For example, authorities delegated to GS-11 revenue agents (Small Business/Self-Employed) can also be exercised by GS-12, GS-13 or GS-14 revenue agents (Small Business/Self-Employed).



       ### Note:



       Authorities delegated to persons who hold a position (title) within a particular office/function cannot be exercised by persons who hold the same position (title) in a different office/function (e.g., authorities delegated only to GS-11 revenue agents (Small Business/Self-Employed) may not be exercised by revenue agents, regardless of grade, within Large Business & International.

    3. Management positions within the chain of command from the delegated official to the redelegated official (intervening line of management positions) are authorized to supervise and direct their subordinates' work based on the authorities delegated to them.


09. Servicewide delegation orders are reviewed, approved and signed by the Commissioner of Internal Revenue or the Deputy Commissioner of Internal Revenue. Once signed and approved, the delegation order is immediately effective and supersedes any preceding delegation orders.

10. If a delegated authority is to be removed permanently, the delegation order must be rescinded through review, approval and signature following the procedures outlined in this IRM section.

11. Recently approved delegation orders are posted to the Servicewide Delegation Order Listing web page and the FOIA Library’s [Recently approved Commissioner Delegation Orders](http://www.irs.gov/uac/Recently-Approved-Commissioner-Delegation-Orders-1) until published in IRM 1.2.2, Servicewide Delegations of Authority. IRM 1.2.2 is updated on a semi-annual schedule: January and July by the office of SPDER in RAAS.



    ### Note:



    Delegation orders must be reviewed and approved by the Commissioner of Internal Revenue or Deputy Commissioner of Internal Revenue before being published to IRM 1.2.2.

12. A listing of all active delegation orders by business owner and number is accessible at the Servicewide Delegation Order Listing web page.

13. The originating office must identify how the changes affect other documents, processes and programs and alert organization owners of the change. The changes could require an update to all associated IRM sections to keep the overall IRM consistent.


**1.11.4.5.1** **(02-04-2025)**

#### Creating, Revising and Rescinding Servicewide Delegation Orders

1. Authors must contact the BU IMD/Delegation Orders Coordinator for assistance in creating, revising or rescinding delegation orders.

2. For new delegation orders:



1. IMD Coordinators must Contact \*SPDER to obtain a new delegation order number.

2. Follow IRM 1.11.4.5.2, Servicewide Delegation Order Content, and _Exhibit 1.11.4-1_ for format.

3. Follow IRM 1.11.4.5.3, Procedures for Clearing Servicewide Delegation Orders, for mandatory review and approval actions.


3. For revised delegation orders, authors must:



1. Use the existing delegation order as your source document located in IRM 1.2.2, Servicewide Delegations of Authority.

2. Update the revision number (e.g., Rev. 1) in the title.

3. Secure approval from SPDER for any renumbering.

4. Follow IRM 1.11.4.5.2, Servicewide Delegation Order Content, and _Exhibit 1.11.4-1_ for format.

5. Follow IRM 1.11.4.5.3, Procedures for Clearing Servicewide Delegation Orders, for mandatory review and approval actions.


4. For rescinding an existing delegation order, authors must:



1. Follow IRM 1.11.4.5.2, Servicewide Delegation Order Content, and _Exhibit 1.11.4-1_ for format and sample delegation orders.

2. Follow IRM 1.11.4.5.3, Procedures for Clearing Servicewide Delegation Orders, for mandatory review and approval actions


**1.11.4.5.2** **(02-04-2025)**

#### Servicewide Delegation Order Content

1. Servicewide delegation orders (SDO) must be complete and contain all required elements. When requesting a new delegation order, contact SPDER to secure a new delegation order number. When revising existing delegation orders, update the order’s revision number (e.g., Rev. 1) to reflect the change(s). In addition, the following elements of the delegation order memo are required:



01. **Title:** Provide a brief descriptive title to reflect the subject. The title reflects the subject matter covered rather than duplicating the specific authority as stated within the order itself. Do not include any parenthetical information.

02. **Authority:** Provide a clear statement of the authority being delegated. This statement should not contain any unnecessary material or explanation, although short references to important limitations must be included where practical. Authority statements should ****not**** include statements containing procedures. A single delegation order can provide for more than one authority. Delegated authorities must be individually numbered to easily distinguish between each. See _Exhibit 1.11.4-2_, Sample Delegation Order with Multiple Authorities.

03. **Delegated to:** Enter the title of the lowest level employees or positions to whom the authority is delegated. All positions within the chain of command up to and including the Commissioner of Internal Revenue have the same authority. Higher grades of the same position also have the authority.



       ### Example:



       To determine the appropriate level, originators should research field responsibilities which relate to the order being prepared. If it is appropriate for employees at the GS-07 level to exercise this authority and redelegations are routinely made, the SDO should make the delegation to the GS-07 level.





       ### Note:



       If, during a reorganization, position titles change, without substantive change in responsibility, a delegation order is still effective for the new position title until the delegation order is revised. _Under no circumstances should operations cease because a new title is not reflected in an existing delegation order._

04. **Redelegated to:** Servicewide delegation orders must specify if redelegation is allowed, disallowed or restricted; and if so, to what level. If the original delegation is to the lowest appropriate level, no further redelegation is permitted. See IRM 1.11.4.5.2.1, Redelegation of Authority, for requirements on issuing a business unit delegation order when a SDO permits redelegation. If the authority **cannot** be redelegated, the accompanying verbiage will state, “This authority may not be redelegated.”

05. **Source(s) of Authority:** Always cite the proper and most current source(s) of authority. Ensure that the Treasury Order, Code of Federal Regulations (CFR) provision, or other reference cited in a previous version of the delegation order are not obsolete, outdated, or insufficient. Include an electronic link to each listed sources of authority.



       ### Note:



       Where a source of authority is rendered obsolete or out-of-date, the delegation order will continue to be valid to the extent that the delegation is supported by a superseding or successor authority until the delegation order is superseded, rescinded or obsoleted.

06. **Prior History and Ratification Paragraph:** If the delegation order revises or updates a prior delegation order, the delegation order must include a statement to that effect. All new or revised delegation orders must include a ratification statement to protect the IRS if officials, given the new or revised authority, inadvertently exercised the authority before the delegation order was signed. Include the following in a numbered paragraph immediately preceding the signature of the approving official. The delegation order should include one of the following statements:



       ### Example:



       **New delegation order:** “To the extent that authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified.”





       ### Example:



       **Revised delegation order:** “This order supersedes Delegation Order X-XX (Rev. XX), dated Month DD, YYYY. To the extent that authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified.”

07. **Signature and Date Lines:** The final paragraph of the delegation order must contain a signature line, the date of approval, and a signature. Include the literal "Signed" as a place for the electronic signature followed by a line for the electronic signature. Below the line, type the approving official's name and title and the word "Date." The Commissioner of Internal Revenue or Deputy Commissioner of Internal Revenue are the only officials authorized to sign as approving officials for Servicewide delegation orders. The approving official title is determined by the office to which the respective business unit report.

08. When possible, include electronic links to each referenced IRC, IRM, sources of authority, statute, Treasury Regulation, and Treasury Decision.

09. See _Exhibit 1.11.4-1_ through _Exhibit 1.11.4-4_ or the IMD Community site for sample delegation orders and sample templates.

10. Delegation orders must not contain Official Use only (OUO), Sensitive But Unclassified (SBU) or Controlled Unclassified Information (CUI) content.


**1.11.4.5.2.1** **(02-04-2025)**

##### Redelegation of Authority

1. When a SDO permits redelegation **and** the delegated official chooses to redelegate an authority, the delegated official of the business unit will redelegate the authority in writing to the permissible level(s) through a business unit delegation order. Authors must contact SPDER and the business unit IMD coordinator to initiate a Servicewide and/or business unit delegation order.

2. The following are the two acceptable methods for redelegation:



1. Business unit delegation order



      ### Note:



      See IRM 1.11.4.6, Business Unit Delegation Order Standards, for creating and issuing requirements of a business unit delegation order.

2. Memorandum



      ### Note:



      A memorandum is only used to designate acting or temporary authority to officials. See _IRM 1.11.4.3.1_, Rules for Acting Supervisory Officials.


**1.11.4.5.3** **(02-04-2025)**

#### Procedures for Clearing Servicewide Delegation Orders

01. Prior to initiating formal clearance, the author must forward the draft delegation order to \*SPDER with a courtesy copy to the Internal Management Documents (IMD) Coordinator for an informal review.

02. The author must use Form 2061, Document Clearance Record, to document the review and assessment(s) of:



    1. Affected offices

    2. Taxpayer Advocate Services (TAS)

    3. Chief Counsel

    4. Originator’s management official (Form 2061, Part V, 17a. -17c.)

    5. Business unit senior executive (Form 2061, Part V, 18a. - 18d.)

    6. Chief reporting directly to the Deputy Commissioner Internal Revenue (if applicable) (Form 2061, Part V, 19a. -19c.)

    7. Business unit IMD coordinator


03. The author must Identify affected offices in accordance with IRM 1.11.9.3, Identifying Reviewers.

04. To locate program offices outside of the business unit, authors must use the Internal Management Documents (IMD) Contacts List.

05. Authors must allow 30 calendar days for reviewers to complete their review and assessment. Internal and external reviewers will perform reviews **simultaneously** during the 30-day timeframe.

06. In very rare cases, expedited reviews may be necessary. If an expedited review is necessary due to time constraints, authors must consider the following:



    1. The business unit senior executive (or designee) must approve the expedited clearance of the delegation order.

    2. Expedited clearance must be at least three (3) business days.

    3. When creating a clearance request, the author must indicate that the request is expedited on Form 2061, Part 1, Line 7. Also inform reviewers that the clearance is being expedited by including the term “EXPEDITED CLEARANCE” in the subject line of the clearance request email.

    4. Prepare complete clearance package per _IRM 1.11.4.5.3.1_, Clearance Package for Internal, External, and Specialized Reviewers.


07. Chief Counsel will perform their review **sequentially**. After affected offices and specialized reviewers have complete their review, the author must consolidate the responses and make the necessary updates. Next, send the revised delegation order to Chief Counsel for review.



    1. Allow 30 calendar days for Chief Counsel to complete their review and assessment.

    2. Send the clearance package to the Chief Counsel Clearance contact for review and concurrence at: \*CC IRM Clearance - Counsel Review Copy the Chief Counsel delegation order point of contact as listed in the Internal Management Documents (IMD) Contacts List.

    3. Non-editorial content changes received from Chief Counsel, must be resubmitted back to Chief Counsel for subsequent review and approval.

    4. Chief Counsel must “concur” with revisions before the clearance package is sent forward for further review and approval.



       ### Caution:



       **If more than 60 calendar days lapse between the review by Chief Counsel and delivery to SPDER, the delegation order package will be rejected back to the business unit. The business unit will then be required to clear the package through Chief Counsel again.**


08. In situations where a reviewer “does not concur” with the new or revised delegation order, refer to IRM 1.11.9.9, Resolving Disagreements.

09. After addressing and incorporating comments and feedback from identified reviewers including CC, send your new, revised or rescinded SDO to management and BU senior executive for review and approval.



    ### Reminder:



    The suggested timeframes for review are **15 calendar days** for manager review, **15 calendar days**for BU senior executive review, and **15 calendar days**for Chief reporting directly to the Deputy Commissioner Internal Revenue (if applicable) review. Business units must secure signatures from these officials and submit clearance package to SPDER within 60 days of Chief Counsel concurrence.

10. After the delegation order clearance package has been reviewed by the BU senior executive and Chief reporting directly to the Deputy Commissioner Internal Revenue (if applicable), the author will send the complete package to the IMD Coordinator. The IMD Coordinator will perform a final review and forward the package to \*SPDER. See IRM 1.11.4.5.3.3, Final Clearance Package for SPDER Review.

11. Servicewide delegation orders must be cleared through all required reviewers and submitted to SPDER within one year of the date official clearance was initiated. Clearance packages received in SPDER after one year will be returned to the business unit with a request to clear the delegation order again.


**1.11.4.5.3.1** **(02-04-2025)**

##### Clearance Package for Internal, External, and Specialized Reviewers

1. Forward the delegation order clearance documents identified below to internal, external and specialized reviewers (if applicable), management, IMD Coordinator and Chief Counsel for review and concurrence.




|  | Document(s) | Purpose |
| --- | :-: | :-: |
| a. | Form 2061, Document Clearance Record | Documents reviewer feedback and identifies affected offices, special reviewers, BU IMD coordinator, BU senior executive and the Chief reporting directly to the Deputy Commissioner Internal Revenue (if applicable). |
| b. | Draft memo (Microsoft Word file) for the new, revised, or rescinded delegation order with **no track** changes. | Reflects the new or proposed version being submitted for review and approval. See IRM 1.11.4.5.2, Servicewide Delegation Order Content, for format and content requirements. |
| c. | Tracked changes memo (Microsoft Word file) for revised, or rescinded delegation orders.<br> <br>### Note:<br>The tracked changes document must reflect all changes made from the original delegation order to the final draft memo. | Reflects the changes being submitted for review and approval. |
| d. | Form 13839, Note to Reviewer | Explains why a delegation order is being issued (new), revised, or rescinded. Explanation should be clear, concise, and identify all major issues and the significance of the change(s). |
| e. | Source(s) of Authority (Microsoft Word or Adobe Acrobat file) | Documents the source(s) of authority being cited in the delegation order. When possible, source(s) of authority should be linked to a related SharePoint, website, web page, etc. See _IRM 1.11.4.5.2_ (5). |
| f. | All necessary background information | Assists in explaining the new, revised or rescinded/canceled delegation order. |


**1.11.4.5.3.2** **(02-04-2025)**

##### No Response to Clearance Request

1. If an affected office (other than Chief Counsel) does not respond to a request for clearance within the required time frame, there is no requirement to follow-up. The non-response will be treated as a concurrence with all new, revised, or rescinded delegation orders.

2. The author will document a non-response by making an annotation to the Form 2061 as follows:



1. Write the name of the reviewer or reviewing office in the “Name” field.

2. Write “No Response Received” in the “Title” field.


**1.11.4.5.3.3** **(02-04-2025)**

##### Final Clearance Package for SPDER Review

1. After the delegation order has been cleared through all of the required and affected offices, the specialized reviewers (including Chief Counsel), and reviewed by the business unit senior executive and Chief reporting directly to the Deputy Commissioner Internal Revenue (if applicable), the originating business unit submits the cleared delegation order package to SPDER. SPDER will review and submit the package to the Commissioner or Deputy Commissioner of Internal Revenue for approval and signature.

2. Email the following documents to \*SPDER:




|  | Document(s) | Purpose |
| :-: | :-: | :-: |
| a. | **Signed**Form 2061, Document Clearance Record | Documents the comments and concurrence of all reviewers, including Chief Counsel and the originating business unit’s senior executive and the Chief reporting directly to the Deputy Commissioner Internal Revenue (if applicable).<br> <br>### Note:<br>SPDER must receive the package within 60 days of Chief Counsel’s approval date. |
| b. | **Final** memo (Microsoft Word file) for the new, revised, or rescinded delegation order. Review for the following:<br> <br>   - Tracked changes turned off<br>     <br>   - All changes accepted<br>     <br>   - The official letterhead of the Commissioner or Deputy Commissioner.<br>     <br>### Note:<br>Include a signature line for the Commissioner of Internal Revenue or the Deputy Commissioner of Internal Revenue that includes their name, title and “Date.” | Reflects the new or revised version being submitted for approval. Letterhead stationery is available at: Letterhead Stationery Program |
| c. | **Final** tracked changes memo (Microsoft Word file) for the new, revised, or rescinded delegation orders with track changes turned on.<br> <br>### Note:<br>The track changes document must reflect all made changes made from the original delegation order to the final draft memo. | Reflects the changes being submitted for approval. |
| d. | Form 13839, Note to Reviewer | Explains why a delegation order is being issued (new), revised, or rescinded. Explanation should be clear, concise, and identify all major issues and the significance of the change(s).<br> <br>### Note:<br>Any package submitted for approval/signature without Form 13839, Note to Reviewer, will be returned to the initiator, as this is a requirement of the Commissioner's Office and SPDER. |
| e. | Source(s) of Authority (Microsoft Word or Adobe Acrobat file) | Documents the source(s) of authority being cited in the delegation order. When possible, source(s) of authority should be linked to a related SharePoint, website, web page, etc. See _IRM 1.11.4.5.2_ (5). |
| f. | All necessary background information | Assists in explaining the new, revised or rescinded/canceled delegation order. |

3. A SPDER analyst reviews the delegation order for the following items:



1. Correct grammar, punctuations, and spelling

2. Correct delegation order numbering (See _IRM 1.11.4.6.1.1_)

3. Correct ratification statement and date(s)

4. Form 13839, Note to Reviewer, accurately reflects the reason for and summary of the changes

5. Formatting that complies with Servicewide delegation orders standards

6. Chief Counsel review and concurrence

7. Business unit senior executive and Chief reporting directly to the Deputy Commissioner Internal Revenue (if applicable) concurrence



      ### Note:



      Incomplete clearance packages will be returned to the originator for corrections.


4. After completing a preliminary review, the SPDER office prepares a Form 14074 , Action Routing Sheet for Commissioner or Deputy Commissioner approval. The Form 14074 will be routed through the following offices, as appropriate:



1. The Chief, SPDER IMD Policy and Support

2. The Director, Servicewide Policy, Directives and Electronic Resources

3. The Director, Strategy & Business Solutions, RAAS

4. The Chief Data and Analytics Officer

5. The Chief Operations Officer

6. The Assistant Deputy Commissioner (as appropriate)

7. The Deputy Commissioner of Internal Revenue (as appropriate)

8. The Staff Assistant to the Commissioner (as appropriate)

9. The Commissioner of Internal Revenue (as appropriate)


5. After the review and approval by the Chief Data and Analytics Officer, SPDER will convert the final Word file to a PDF and forward the final package (with completed Form 14074) via e-Trak to the Chief Operations Officer (COO). Upon review and approval, the package will be sent to the Commissioner’s Office or The Deputy Commissioner’s Office for final approval and signature.



### Exception:



Clearance packages submitted by business units reporting to the COO are reviewed during initial business unit clearance process. These packages will **not**be sent to the COO for a second time, unless substantive changes are made that require review by the COO.


**1.11.4.5.4** **(02-04-2025)**

#### Issuance and Publishing of Servicewide Delegation Orders

1. After the Commissioner or Deputy Commissioner has approved and signed the delegation order, SPDER will post a PDF of the signed document to the Search Interim Guidance page, the Servicewide Delegation Order List, and request Online Services to post the delegation order to the [IRS FOIA Library - Recently approved Commissioner Delegation Orders](https://www.irs.gov/privacy-disclosure/recently-approved-commissioner-delegation-orders).

2. SPDER will:



1. Review the final memo to confirm the Commissioner’s or Deputy Commissioner’s signature and date.

2. Prepare memo for posting by making the PDF 508 compliant.

3. Save the signed delegation order to the SPDER shared site.

4. Notify the originator and IMD coordinator of the signature and approval.

5. Forward the final package to the IRS Historical Research Library.

6. Incorporate the new/revised delegation order into IRM 1.2.2 on a semi-annual schedule (January/July).


**1.11.4.5.5** **(02-04-2025)**

#### Editorial Changes for Servicewide Delegation Orders

1. In very limited cases, published delegation orders will require editorial updates. Editorial changes do not impact the meaning of the content and will therefore follow a streamlined clearance process.

2. Editorial changes are limited to:



   - Correcting typographical errors, e.g., spelling or grammatical errors

   - Updating delegation order titles

   - Updating organizational terms and titles to current terms or titles


3. For editorial changes, forward the following documents to \*SPDER for consideration:



1. Track Change Word file of the delegation order

2. Final Word file (no track changes)

3. Form 13839, Note to Reviewer indicating the reason for the change

4. Form 2061, Document Clearance Record signed by the business unit senior executive (or designee) approving the change


4. After review and agreement, SPDER will update the delegation order in IRM 1.2.2 based on the semi-annual schedule (January/July) and notate the editorial correction in the IRM’s manual transmittal. The delegation order effective date and revision number will remain the same.

5. SPDER will retain the documents and forward to the IRS Historical Research library for record retention and documentation.


**1.11.4.6** **(02-04-2025)**

### Business Unit Delegations Order Standards

1. Business unit delegation orders redelegate authority to officials and employees within their respective business units.

2. Business unit senior executives will issue business unit delegation orders when the SDO allows for redelegation **and** the senior executive determines that redelegation is necessary for administrative operations within their business unit.

3. Business unit delegation orders must comply with the parameters of Servicewide delegation orders, Treasury Decisions, Treasury Regulations, or other legal documents.

4. Business unit senior executives must not issue orders that permit a lower-level official to redelegate authorities.

5. Similar to Servicewide delegation orders, if the delegated official is vacant or away from the office and is unable to perform their delegated authorities, the authorities delegated to the permanent official can be taken by the person designated in writing to act for this official.

6. Adhere to the number, format and content standards in the _IRM 1.11.4.6.1.1_, Numbering Business Unit Delegation Orders.

7. Business unit counsel and SPDER must review and approve all business unit delegation orders. See IRM 1.11.4.6.3, Business Unit Delegation Order Clearance.


**1.11.4.6.1** **(02-04-2025)**

#### Creating, Revising and Rescinding Business Unit Delegation Orders

1. Business unit senior executives are responsible for ensuring that their respective business unit delegation orders are current. Business units must conduct an annual review of these delegation orders to determine if there is a need to create, revise, or rescind their business unit delegation orders.

2. **Create**business unit delegation orders when the SDO allows for redelegation **and** the business unit’s senior executive determines that redelegation is necessary for administrative operations within their business unit.

3. **Revise** business unit delegation orders when:



   - Revisions to the source SDO requires that the business unit delegation order be revised.

   - The business unit determines that a redelegation is no longer appropriate and must be modified to meet the business unit’s needs. These revisions reflect changes to the official(s) being delegated with authorities to perform a task, responsibility, or action. Revisions to business unit delegation orders must be permissible and must maintain alignment with the source SDO.

   - Editorial changes are necessary.


4. **Rescind**business unit delegation orders when:



   - The source SDO is rescinded or revised and no longer supports or aligns with the needs of the business unit delegation order.

   - The business unit determines that a redelgation order is no longer necessary because the current SDO as written, meets the needs of the business unit.

   - The business unit determines that a delegation order is no longer valid.


5. The author must contact their BU IMD coordinator for assistance in creating, revising or rescinding business unit delegation orders.

6. The author must follow the numbering schema in _IRM 1.11.4.6.1.1_, Numbering Business Unit Delegation Orders.

7. The author must follow the content guidelines in _IRM 1.11.4.6.2_, Business Unit Delegation Order Content.

8. The senior executive of the business unit redelegating the authority is the signing and approving official.


**1.11.4.6.1.1** **(02-04-2025)**

##### Numbering Business Unit Delegation Orders

1. All business unit delegation order must be numbered correctly. See IRM 1.2. for a listing of published business unit delegation orders.

2. The number format identifies the business unit and the related SDO. Each business unit delegation order number will appear as follows:



> Organization acronym **(TEGE)** \- Servicewide delegation order number **(1-23)** \- sequential digit **(1)**





### Example:



See IRM 1.2.68.2.3, Delegation Order TEGE 1-23-1, Authority to Sign Thirty Day Letters. The title indicates that this is the first TEGE redelegation relating to Servicewide Delegation Order 1-23, Authorization to Perform Functions of the Commissioner.


**1.11.4.6.2** **(02-04-2025)**

#### Business Unit Delegation Order Content

1. The format and content of business unit delegation orders follows that of Servicewide delegation orders. See _IRM 1.11.4.5.2_, Servicewide Delegation Order Content.

2. Business unit delegation orders must state the lowest level of authority. Statements allowing additional redelegation in business unit delegation orders are not permitted.

3. List the related SDO in the “Authority” paragraph. The level of authority in the business unit delegation order must be consistent with the level of authority allowed in the SDO.

4. _Exhibit 1.11.4-4_, Sample Business Unit Delegation Order for an example of a Business Unit Delegation Order.


**1.11.4.6.3** **(02-04-2025)**

#### Procedures for Clearing Business Unit Delegation Orders

1. The author must identify affected offices in accordance with IRM 1.11.9.3, Identifying Reviewers.

2. The author must prepare a business unit delegation order clearance package containing the following:




|  | Document(s) | Purpose |
| --- | :-: | :-: |
| a. | Form 2061, Document Clearance Record | Documents reviewer feedback and identifies affected offices, BU IMD coordinator, and BU senior executive. |
| b. | Draft memo (Microsoft Word file) for the new, revised, or rescinded delegation order with track changes turned off, and all changes accepted.<br> <br>### Note:<br>Add the official letterhead stationery prior to forwarding the final memo to the business unit’s senior executive for approval.<br>### Note:<br>Include a signature line for the business unit’s senior executive that includes their name, title and “Date.” | Reflects the new or proposed version being submitted for review and approval. See IRM 1.11.4.5.2, Servicewide Delegation Order Content, for format and content requirements. |
| c. | Track changes memo (Microsoft Word file) for revised, or rescinded delegation orders with track changes turned on.<br> <br>### Note:<br>The track changes document must reflect all changes made from the original delegation order to the final draft memo. | Reflects the changes being submitted for review and approval. |
| d. | Form 13839, Note to Reviewer | Explains why a delegation order is being issued (new), revised, or rescinded. Explanation should be clear, concise, and identify all major issues and the significance of the change(s). |
| e. | Source(s) of Authority (Microsoft Word or Adobe Acrobat file) | Documents the source(s) of authority being cited in the delegation order. When possible, source(s) of authority should be linked to a related SharePoint, website, web page, etc. See _IRM 1.11.4.5.2_ (5). |
| f. | All necessary background information | Assists in explaining the new, revised or rescinded/canceled delegation order. |

3. The author must forward the complete clearance package with a request for review. Send the package to:



1. Affected offices, functions, or areas

2. Taxpayer Advocate Services (TAS)

3. Office of SPDER

4. Chief Counsel

5. Originator’s management official

6. IMD Coordinator

7. Business unit senior executive


### Note:

The author will send all business unit delegation orders to \*SPDER for review. The Office of SPDER will review the numbering, format and will verify the source of authority is based on an existing SDO. Affected offices and SPDER will review packages **simultaneously**. In addition to the SPDER office, authors must consult with the business unit that owns the Servicewide delegation order being used as the source of authority document. Authors should confirm the parameters of the Servicewide delegation order and identify any pending changes that could impact their business unit delegation order. It is highly recommended that the authors clear their business unit delegation order through that office as well.

4. For specific contacts and business unit mailboxes, authors will refer to the Internal Management Documents (IMD) Contacts List.

5. The author must allow 30 calendar days for the affected offices and Office of SPDER to complete their review and assessment. After the reviews have been completed and returned, authors will consolidate the responses and make the necessary updates before preparing the package for Chief Counsel’s review.



### Note:



If an expedited review is necessary to expedite issuance of a business unit delegation order, the author will follow the guidance outlined in _IRM 1.11.4.5.3_ (6).

6. The author must allow 30 calendar days for Chief Counsel to complete their review and assessment.



1. Non-editorial content changes received from Chief Counsel, must be resubmitted back to Chief Counsel for subsequent review and approval.

2. Chief Counsel must “concur” with revisions before the clearance package is sent forward for further review and approval.


7. After review and concurrence from Chief Counsel, the author must request their management official’s review and assessment, the IMD Coordinator’s review and assessment, and the approval and signed memo from the business unit’s senior executive. These reviews and assessments must be **sequential**. The originator will allow **15 calendar days** for their manager’s review, **15 calendar days**for IMD Coordinator review, and **15 calendar days**for the business unit senior executive’s approval and signature.


**1.11.4.6.4** **(02-04-2025)**

#### Issuance and Publishing of Business Unit Delegation Orders

1. Business units are required to publish approved and signed business unit delegation orders in IRM 1.2, Servicewide Policies and Authorities, within their designated business unit delegation order IRM section. If the business unit does not have an assigned business unit IRM section, the IMD Coordinator must contact \*SPDER to obtain a new IRM section number to house the business unit delegation orders.

2. In the interim of incorporating new/revised business unit delegation orders into the IRM, the program owner or business unit is responsible for posting the business unit delegation order(s) to the Search Interim Guidance pageand the FOIA Library on IRS.gov. See IRM 1.11.10, Internal Management Documents System, Interim Guidance Process, for distribution and posting procedures. Once a business unit delegation order has been incorporated into the business unit’s delegation orders IRM section, the business unit will again use the IMD Tracking System to archive the IGM and initiate its removal from IRS.gov.

3. Revised or new business unit delegation orders are available to the public at [Recently approved business unit delegation drders](http://www.irs.gov/uac/Recently-Approved-Division-Function-Delegation-Orders) until published in the appropriate IRM section.


**Exhibit 1.11.4-1**

### Sample Servicewide Delegation Order

**Delegation Order 7-6 (Rev. 1), **Prohibited Transactions Exemptions****

(1) **Prohibited Transactions Exemptions**

(2) **Authority:** To make determinations on individual prohibited transactions exemptions and perform all functions necessary in the administration of IRC 4975(c)(2).

(3) **Delegated to:** Director, Employee Plans.

(4) **Redelegation:** This authority may not be redelegated.

(5) **Source of Authority:** IRC 4975(c)(2) and Treasury Order 150-10.

(6) To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified. This order supersedes Delegation Order 7-6, dated November 8, 2007.

(7) Signed: Charles A. Calcite, Deputy Commissioner of Internal Revenue

**Exhibit 1.11.4-2**

### Sample Delegation Order with Multiple Authorities

**Delegation Order 1-69 (New), Authorization to Approve an Internal Management Document (IMD)**

(1) **Authorization to Approve an Internal Management Document (IMD)**

(2) **Authority 1:** To approve and authorize issuance of a new or revised Internal Revenue Manual (IRM) section, IRM procedural update (IPU), interim guidance memorandum (IGM), or operating level directive with newly designated or changed official use only (OUO) content.

(3) **Delegated to:** An official as designated in Delegation Order 11-1, Administrative Control of Documents and Material, paragraph three (3), with program oversight of the IMD content.

(4) **Redelegation:** This authority may not be redelegated.

(5) **Authority 2:** To approve and authorize issuance of a revised Internal Revenue Manual (IRM) section, IRM procedural update (IPU), interim guidance memorandum (IGM), or operating level directive de-designating OUO content.

(6)**Delegated to:** An official as designated in Delegation Order 11-1, Administrative Control of Documents and Material, paragraph six (6), with program oversight of the IMD content.

(7) **Redelegation:** This authority may not be redelegated.

(8) **Authority 3:** To approve and authorize issuance of a new, revised, or obsolesced Internal Revenue Manual (IRM) section, IRM procedural update (IPU), interim guidance memorandum (IGM), or operating level directive without newly designated or changed OUO content.

(9)**Delegated to:** A member of the Senior Executive Service with program oversight of the IMD content.

(10) **Redelegation:** This authority may be redelegated in writing to a supervisory manager with program oversight of the IMD content.

(11) **Authority 4:** To approve and authorize issuance of a new, revised, or rescinded Servicewide delegation order and Servicewide policy statement.

(12)**Delegated to:** The IRS Commissioner or the responsible IRS deputy commissioner.

(13) **Redelegation:** This authority may not be redelegated.

(14) **Authority 5:** To approve and authorize issuance of a new, revised, or rescinded business unit delegation order.

(15)**Delegated to:** The responsible division commissioner, deputy commissioner, chief and deputy chief, chief officer and deputy chief officer, director, officer and deputy officer, National Taxpayer Advocate, reporting to the IRS Commissioner or a deputy commissioner.

(16) **Redelegation:** This authority may not be redelegated.

(17) **Sources of Authority:** Delegation Order 11-1, Administrative Control of Documents and Material, Treasury Directive 71-10, and Treasury Security Manual – TD P 15-71

(18) To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

(19) Signed: Charles A. Calcite , Deputy Commissioner of Internal Revenue

**Exhibit 1.11.4-3**

### Sample of Rescinded Delegation Order

**Delegation Order 1-56 (Rescinded), Requests for Customer Financial Records from Financial Institutions Pursuant to a Formal Written Request**

**Rescinded: 08-27-2020**

(1) **Requests for Customer Financial Records from Financial Institutions Pursuant to a Formal Written Request**

(2) The authority to request customer financial records from financial institutions is delegated to the Office of Investigations and Technology, Regional Inspectors, and Assistant Regional Inspectors (Internal Security), which is now obsolete. Therefore, Delegation Order 1-56 is rescinded.

(3) Signed: Charles A. Calcite, Deputy Commissioner of Internal Revenue

**Exhibit 1.11.4-4**

### Sample Business Unit Delegation Order

**Delegation Order TEGE 1-7-1, To Authorize Attendance at Meetings at Government Expense**

(1) **To Authorize Attendance at Meetings at Government Expense**

(2) **Authority:** The authority to authorize the attendance of employees at meetings of scientific or professional societies; municipal, state, federal, or international organizations; Congress; and law enforcement or other groups; and to authorize or approve attendance of employees at meetings held by employee groups, organizations, or associations.

(3) **Delegated to:**

- Director, Exempt Organizations and Government Entities;

- Director, Employee Plans;

- Director, Compliance Planning and Classification; and

- Director, Shared Services.


(4) **Redelegation:** This authority may not be redelegated.

(5) **Source of Authority:** Servicewide Delegation Order 1-7, dated April 7, 2003.

(6) To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes TE/GE Divisional Delegation Order 7 (Rev. 1), dated December 5, 1999.

(7) Signed: Mary B. Poodle, Commissioner, Tax Exempt and Government Entities

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-011-004#addtoany "Show all")

A2A