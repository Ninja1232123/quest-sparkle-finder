---
url: "https://www.irs.gov/irm/part1/irm_01-032-010"
title: "1.32.10 Reporting on Event-Related Spending | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-032-010#main-content)

- 1.32.10  [Reporting on Event-Related Spending](https://www.irs.gov/irm/part1/irm_01-032-010#idm140307900943856)
  - 1.32.10.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-032-010#idm140307900929264)
    - 1.32.10.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-032-010#idm140307900669408)
    - 1.32.10.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-032-010#idm140307900666944)
    - 1.32.10.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-032-010#idm140307900663728)
      - 1.32.10.1.3.1  [CFO And Deputy CFO](https://www.irs.gov/irm/part1/irm_01-032-010#idm140307900658656)
      - 1.32.10.1.3.2  [Associate CFO for Corporate Accounting](https://www.irs.gov/irm/part1/irm_01-032-010#idm140307900655536)
      - 1.32.10.1.3.3  [Travel Management](https://www.irs.gov/irm/part1/irm_01-032-010#idm140307900653168)
      - 1.32.10.1.3.4  [Associate CFO for Internal Controls](https://www.irs.gov/irm/part1/irm_01-032-010#idm140307900648880)
      - 1.32.10.1.3.5  [Associate CFO for Corporate Budget](https://www.irs.gov/irm/part1/irm_01-032-010#idm140307900647056)
      - 1.32.10.1.3.6  [HCO](https://www.irs.gov/irm/part1/irm_01-032-010#idm140307900643584)
      - 1.32.10.1.3.7  [Business Units](https://www.irs.gov/irm/part1/irm_01-032-010#idm140307900641632)
    - 1.32.10.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-032-010#idm140307900635744)
    - 1.32.10.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-032-010#idm140307900632592)
    - 1.32.10.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-032-010#idm140307900621760)
    - 1.32.10.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-032-010#idm140307900351248)
    - 1.32.10.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-032-010#idm140307900332832)
  - 1.32.10.2  [Mission-Critical Travel Exemptions](https://www.irs.gov/irm/part1/irm_01-032-010#idm140307900329744)
    - 1.32.10.2.1  [Treasury-wide Exemptions to Treasury Directive 12-70 Requirements](https://www.irs.gov/irm/part1/irm_01-032-010#idm140307900327904)
  - 1.32.10.3  [Reporting Requirements to Treasury](https://www.irs.gov/irm/part1/irm_01-032-010#idm140307900306112)
  - 1.32.10.4  [Internal Order Codes for Events](https://www.irs.gov/irm/part1/irm_01-032-010#idm140307900286608)

# Part 1. Organization, Finance, and Management

# Chapter 32. Servicewide Travel Policies and Procedures

# Section 10. Reporting on Event-Related Spending

* * *

## 1.32.10 Reporting on Event-Related Spending

#### Manual Transmittal

July 08, 2024

#### Purpose

(1) This transmits revised IRM 1.32.10, Servicewide Travel Policies and Procedures, Reporting on Event-Related Spending.

#### Material Changes

(1) IRM 1.32.10.1(4), Program Scope and Objectives, added Corporate Accounting office per CFO reorganization.

(2) IRM 1.32.10.1.3(b), Responsibilities, updated title from Associate CFO for Financial Management to Associate CFO for Corporate Accounting per CFO reorganization.

(3) IRM 1.32.10.1.3.2(1), Associate CFO for Corporate Accounting, updated title from Associate CFO for Financial Management to Associate CFO for Corporate Accounting per CFO reorganization.

(4) IRM 1.32.10.1.3.3(1)(a), Travel Management, updated responsibility from requesting to reviewing event spending reports.

(5) IRM 1.32.10.1.4(2), Program Management and Review, updated section to state that Travel Management uses reports obtained from the business units and Servicewide Training Events Tracking System (STETS) to prepare event spending reports for the Department of the Treasury; removed that reports are obtained from the Integrated Financial System (IFS).

(6) IRM 1.32.10.1.4(3), Program Management and Review, updated section to state that program effectiveness is measured by ensuring accuracy of the information and amounts recorded on the source document and compliance with Department of the Treasury reporting requirements.

(7) IRM 1.32.10.1.5(1), Program Controls, replaced Reconciliation control with Document Validation control and updated the control method to state that business unit records are used for validating transactions for the report. Also, updated Records Retention control method to state that event spending reports are retained in accordance with the General Record Schedule (GRS).

(8) IRM 1.32.10.1.7, Acronyms, updated section to add the acronyms included in the revised IRM.

(9) IRM 1.32.10.2, Mission-Critical Travel Exemptions, updated section title from “Mission-Critical Travel Exclusions” to “Mission-Critical Travel Exemptions” to provide clarity and consistency with the directive language for all events.

(10) IRM 1.32.10.2(1), Mission-Critical Travel Exemptions, updated the term “exclusions” to “exemptions” to provide clarity and consistency with the directive language for all events.

(11) IRM 1.32.10.2.1, Treasury-wide Exemptions to Treasury Directive 12-70 Requirements, updated section title from “Treasury-wide Exclusions to Treasury Directive 12-70 Requirements” to “Treasury-wide Exemptions to Treasury Directive 12-70 Requirements” to provide clarity and consistency with the directive language for all events.

(12) IRM 1.32.10.2.1(1), Treasury-wide Exemptions to Treasury Directive 12-70 Requirements, updated the term “exclusions” to “exemptions” to provide clarity and consistency with the directive language for all events.

(13) IRM 1.32.10.2.1(2), Treasury-wide Exemptions to Treasury Directive 12-70 Requirements, updated the term “exclusions” to “exemptions” to provide clarity and consistency with the directive language for all events.

(14) IRM 1.32.10.2.1(3), Treasury-wide Exemptions to Treasury Directive 12-70 Requirements, updated section to add that in addition to business units submitting to the CFO the detailed information required by Treasury for all events, including the Treasury-wide exemptions listed in IRM 1.32.10.2.1(4), with events costing $20,000 or greater, business units must also continue to input into STETS.

(15) IRM 1.32.10.2.1(4), Treasury-wide Exemptions to Treasury Directive 12-70 Requirements, added that meetings held to conduct reviews must be site specific reviews. Removed travel for site visits by management to assess employee performance and received employee feedback. Also, updated Mandatory Law Enforcement Training to include non-law enforcement training and meetings held at a Federal Law Enforcement Training Center (FLETC).

#### Effect on Other Documents

IRM 1.32.10, dated March 16, 2022, is superseded.

#### Audience

All business units

#### Effective Date

(07-08-2024)

Teresa R. Hunter

Chief Financial Officer

**1.32.10.1** **(07-08-2024)**

### Program Scope and Objectives

1. Purpose: This IRM contains the event spending reporting requirements that Travel Management uses to prepare reports for the Department of the Treasury. This guidance applies to all events hosted or not hosted by the IRS including, but not limited to, conferences, training and meetings. This guidance covers planning, attendance and approval requirements.

2. Audience: All business units

3. Policy Owner: CFO, Financial Management

4. Program Owner: CFO, Financial Management, Corporate Accounting, Travel Management office, develops and maintains this IRM.

5. Primary Stakeholders: All business units

6. Program Goals: Report on events costing $20,000 or more in compliance with Treasury’s reporting requirements.


**1.32.10.1.1** **(05-11-2020)**

#### Background

1. In June 2011, the White House launched a campaign to cut waste across the federal government, which targeted ineffective and wasteful spending. Treasury issued Treasury Directive (TD)12-70, [Policy and Guidance for Conference Approval, Planning and Reporting](https://www.treasury.gov/about/role-of-treasury/orders-directives/Pages/td12-70.aspx), addressing event spending.


**1.32.10.1.2** **(05-11-2020)**

#### Authorities

1. Treasury Directive 12-70, [Policy and Guidance for Conference Approval, Planning, and Reporting](https://www.treasury.gov/about/role-of-treasury/orders-directives/Pages/td12-70.aspx)

2. 5 U.S. Code 5707, [Regulations and Reports](http://www.law.cornell.edu/uscode/text/5/5707)


**1.32.10.1.3** **(07-08-2024)**

#### Responsibilities

1. This section provides responsibilities for:



1. CFO and Deputy CFO

2. Associate CFO for Corporate Accounting

3. Travel Management

4. Associate CFO for Internal Controls

5. Associate CFO for Corporate Budget

6. HCO

7. Business units


**1.32.10.1.3.1** **(05-11-2020)**

##### CFO And Deputy CFO

1. The CFO and Deputy CFO are responsible for:



1. Overseeing the event spending reporting procedures.

2. Serving as a member of the Servicewide Training Advisory Council (STAC) and providing high-level review of all planned training events to ensure training is justified, needed and delivered in the most cost-effective manner.


**1.32.10.1.3.2** **(07-08-2024)**

##### Associate CFO for Corporate Accounting

1. The Associate CFO for Corporate Accounting is responsible for establishing and ensuring compliance with [TD 12-70, Policy and Guidance for Conference Approval, Planning and Reporting](https://www.treasury.gov/about/role-of-treasury/orders-directives/Pages/td12-70.aspx), event spending reporting requirements.


**1.32.10.1.3.3** **(07-08-2024)**

##### Travel Management

1. Travel Management is responsible for:



1. Requesting event spending reports to ensure compliance with [TD 12-70, Policy and Guidance for Conference Approval, Planning and Reporting](https://www.treasury.gov/about/role-of-treasury/orders-directives/Pages/td12-70.aspx).

2. Coordinating with the business units to gather actual costs for events costing $20,000 or more and entering them into the Treasury database.

3. Periodically reviewing event spending-related documentation with the business units.


**1.32.10.1.3.4** **(05-11-2020)**

##### Associate CFO for Internal Controls

1. The Associate CFO for Internal Controls is responsible for periodically reviewing the actual event expenses and documentation to ensure compliance with the Treasury reporting requirements as part of A-123 testing.


**1.32.10.1.3.5** **(05-11-2020)**

##### Associate CFO for Corporate Budget

1. The Associate CFO for Corporate Budget is responsible for:



1. Developing guidance for establishing Internal Order Codes (IOC).

2. Activating unique IOCs created by the business units for events costing $20,000 or more.

3. Preparing IOC reports on events costing $20,000 or more for reporting to the Treasury.


**1.32.10.1.3.6** **(05-11-2020)**

##### HCO

1. HCO is responsible for reviewing and creating approval packages for all events costing $20,000 or more in accordance with guidelines located at Servicewide Training & Event Management (STEM).


**1.32.10.1.3.7** **(05-11-2020)**

##### Business Units

1. Business units are responsible for:



1. Creating IOCs, if required by the business unit, for any event expenditures between $0 and $19,999. These are business unit specific and are not used by other business units. The business unit’s finance or budget staff establishes a standard, specific IOC following Corporate Budget’s guidance.

2. Ensuring unique IOCs are created for any event expenditures expected to be $20,000 or more.

3. Reporting all actual costs for events costing $20,000 or more in accordance with the requirements of [TD 12-70, Policy and Guidance for Conference Approval, Planning and Reporting](https://www.treasury.gov/about/role-of-treasury/orders-directives/Pages/td12-70.aspx), to cfo.event.request@irs.gov.

4. Adhering to the guidelines developed for processing and approving [TD 12-70, Policy and Guidance for Conference Approval, Planning and Reporting](https://www.treasury.gov/about/role-of-treasury/orders-directives/Pages/td12-70.aspx), events in IRM 6.410.1, Learning and Education Policy.


**1.32.10.1.4** **(07-08-2024)**

#### Program Management and Review

1. Internal controls encompass a set of related policies and procedures to provide reasonable assurance that event spending reports are accurate, reliable and comply with applicable laws and regulations.

2. Program reports: Event spending must meet all requirements of law, executive orders, regulations and all other applicable IRS procedures. Travel Management uses reports obtained from the business units and Servicewide Training Events Tracking System (STETS) to prepare event spending reports for the Department of the Treasury.

3. Program effectiveness: Program effectiveness is measured by ensuring accuracy of the information and amounts recorded on the source document, and compliance with Department of the Treasury reporting requirements.


**1.32.10.1.5** **(07-08-2024)**

#### Program Controls

1. Several program controls are in place to ensure compliance with Department of the Treasury requirements. They include, but are not limited to, the controls listed below:




| **Control** | **Control Method** |
| --- | --- |
| Segregation of duties | A clear segregation of duties exists between those who initiate records and those who prepare reports. |
| Source document format | A standard format is used to ensure consistent, proper recording of event spending transactions. |
| Document Validation | Business unit records are used for validating transactions for the report. |
| Management approval | Management review and approval of event spending reports are delegated to the director who has responsibility for overseeing all reports. |
| Records retention | Event spending reports are retained in accordance with the General Record Schedule (GRS). |


**1.32.10.1.6** **(03-16-2022)**

#### Terms/Definitions

01. The following terms and definitions apply to this program:

02. **Conference -** A pre-arranged formal event with at least some of the following characteristics: designated participants and/or registration, a published substantive agenda, and scheduled speakers or discussion panels on a particular topic, and involves IRS expenses (other than the salaries of attendees), such as expenses for refreshments, meals, or travel (including transportation, lodging, or other expenses authorized under the Federal Travel Regulation (FTR)). A conference may include, but is not limited to, a retreat, convention, seminar or symposium. A conference typically is not a:



    - Routine operational meeting

    - Law enforcement activity

    - Mission-critical core function activity

    - Response to an emergency or recovery activity related to a catastrophic event

    - Testing activity (including the planning, scheduling and conducting)

    - Technical assistance/operational review site visit


03. **Convention -** A formal meeting of members or representatives of a profession or industry.

04. **Event -**An all-inclusive term to include a conference, meeting, training occurrence, award ceremony or other similar gathering that, for the purpose of this guidance, involves expenses of the attendees, such as for travel, meals or refreshments.

05. **Government space -**An IRS or other federal, state, or municipal building, room or facility.

06. **Hosted/co-hosted event -** An event arranged either in total or in part by the IRS, Treasury, or another Treasury bureau, held in either a government or commercial facility, that may include both employees and non-employees as attendees. The bureau provides or arranges for resources required to hold the event.

07. **Internal order code (IOC) -**An Integrated Financial System (IFS) data element that collects expenditure data for a specific project; used to track training and event-related costs, and to track planning and expenditure data for projects within IFS.

08. **Light refreshments -** Include, but are not limited to: coffee, tea, milk, juice, soft drinks, ice cream, donuts, bagels, muffins, fruit, vegetable trays, cheese trays, pretzels, cookies and chips.

09. **Meeting -**A gathering of people with a purpose to discuss business matters that involves strategizing, planning and resolving specific issues or areas of concern.

10. **Non-government space -** A building, room or facility owned by a private-sector organization or entity.

11. **Off-Site -**A location not on IRS premises, including other government facilities and privately-owned buildings, such as hotels.

12. **Retreat -**A meeting held off-site or away from the normal duty station or office. The attendees are staff who meet to discuss various aspects of government or departmental activities, or to review progress and challenges of the implementation of government or departmental policies. Retreats usually offer participants an opportunity to interact in an informal manner to a greater extent than they otherwise would in the normal course of work. This interaction is for the purpose of developing stronger and more effective working relationships.

13. **Seminar -** A lecture or presentation delivered to an audience on a topic or set of topics that may be educational in nature.

14. **Symposium -**A gathering of experts in a particular field at which papers are presented by specialists on particular subjects and discussed with a view to making recommendations.

15. **Total cost of an event -**The total cost of an IRS event is a key indicator in determining the level of approval required and includes all direct and indirect expenses such as refreshments, meals, or travel (including transportation, lodging, or other expenses authorized under the FTR), excluding salaries of attendees. For joint events, the sponsoring organization is responsible for coordinating and securing the total cost and maintaining the records for the event.

16. **Training -**A planned, prepared and coordinated program, course, curriculum, subject or program of instruction or education that improves individual and organizational performance and helps achieve the agency’s mission and performance goals.


**1.32.10.1.7** **(07-08-2024)**

#### Acronyms

1. The following table provides acronyms that are used throughout this IRM section:



|     |     |
| --- | --- |
| **Acronyms** | **Description** |
| A/V | Audio-Visual |
| FACA | Federal Advisory Committee Act |
| FATCA | Foreign Account Tax Compliant Act |
| FLETC | Federal Law Enforcement Training Center |
| FTR | Federal Travel Regulation |
| GRS | General Records Schedule |
| IFS | Integrated Financial System |
| IGA | Intergovernmental Agreement |
| IOC | Internal Order Code |
| M&IE | Meals and Incidental Expenses |
| MAP | Mutual Agreement Procedures |
| PPS | Procurement for Public Sector |
| SETR | Single Entry Time Reporting |
| STAC | Servicewide Training Advisory Council |
| STEM | Servicewide Training & Event Management |
| STETS | Servicewide Training and Event Tracking System |
| TD | Treasury Directive |
| TIEA | Tax Information Exchange Agreement |


**1.32.10.1.8** **(05-11-2020)**

#### Related Resources

1. IRM 1.33.4, Financial Operating Guidelines

2. IRM 6.410.1, Learning and Education Policy

3. Frequently Asked Questions About Treasury Directive 12-70 Review and Approval Process

4. Delegation Order 1-58 (Rev. 2), Policy and Guidance for Conference (including: meetings, retreats, seminars, symposiums or training activities) Approval and Planning


**1.32.10.2** **(07-08-2024)**

### Mission-Critical Travel Exemptions

1. Travel and related expenses for certain mission-critical purposes are not required to go through the event spending approval process. Treasury-wide exemptions and IRS-specific exemptions are covered in the following sections.


**1.32.10.2.1** **(07-08-2024)**

#### Treasury-wide Exemptions to Treasury Directive 12-70 Requirements

1. The IRS has determined that the exemptions listed below are exempt from reporting to Treasury all events that have total costs under $20,000.

2. These exemptions are not meant to cover meetings, conferences, or training events held in non-Government space, occurring over multiple days. IRS employees and managers should be mindful of decisions consistent with the current budget environment and also be aware of situations that could be perceived as wasteful or inappropriate in nature.

3. Business units must continue to input into STETS and also submit to the CFO the detailed information required by Treasury for all events (including those listed below) with events costing $20,000 or greater.

4. This information must be submitted at 10 calendar days and 40 calendar days after the event is held to cfo.event.request@irs.gov. See IRM 1.32.10.3, Reporting Requirements to Treasury, for additional information.



|     |     |
| --- | --- |
| **Exemption** | **Description** |
| Federal Advisory Committee Act (FACA) Meetings | Expenses related to participation in FACA meetings |
| Public hearings and associated briefings | Expenses related to participation in public hearings and associated briefings |
| Meetings held to conduct audits, inspections, or investigations | Meeting with taxpayers, their representatives, or third parties to resolve specific tax cases |
| Meetings held to conduct **site specific** reviews, including process reviews or reviews to assess employee performance. \*Does not include organization or operational strategy meetings. | Travel to a specific IRS site by management to:<br> <br>   - Conduct a site operation review<br>     <br>   - Conduct a site process review<br>     <br>   - Assess an employee’s performance |
| International Travel | - Travel related to U.S. international tax administration obligations<br>     <br>   - Senior international tax officials participating in intergovernmental tax groups<br>     <br>   - Travel for foreign government data safeguarding, information exchange infrastructure evaluations, data transmission methods and Foreign Account Tax Compliant Act (FATCA) Intergovernmental Agreement (IGA) matters<br>     <br>   - Travel for tax treaty and Tax Information Exchange Agreement (TIEA) negotiations<br>     <br>   - Travel for negotiations with foreign competent authorities to resolve taxing rights cases via Mutual Agreement Procedures (MAP) and for the exchange of information or agreement matters |
| Mandatory Law Enforcement Training, Non-Law Enforcement Training or Meetings held at a Federal Law Enforcement Training Center (FLETC) | Travel to mandatory law enforcement training, non-law enforcement training, or meetings held at FLETC |
| System Acceptability Testing | Simulating live operations of new or revised systems |
| Tax-related case travel (Domestic travel only) | Meetings with taxpayers, their representatives or third parties in resolving a specific tax case |
| Subpoena-related travel | Expenses related to IRS staff required to travel to testify |
| Emergency response | Travel for agency response/recovery to civil or natural disasters, evacuations, or other catastrophic events |


**1.32.10.3** **(03-16-2022)**

### Reporting Requirements to Treasury

1. Treasury administers a tracking database for events costing $20,000 or more and oversees internal or external requests for event spending data.

2. For all events that have total costs of $20,000 or more, the following details should be submitted by the business units via email to cfo.event.request@irs.gov within 10 calendar days of the event completion date:



   - IOC number

   - Name of event

   - Date

   - Event location (facility name, address, city and state)

   - Number of IRS employees and non-IRS employees attending that the IRS is paying for

   - Point of contact for additional event details


3. Within 40 calendar days of the completion of the event, the following actual event cost information must be submitted by the business units via email to cfo.event.request@irs.gov



   - IOC number

   - Event title

   - Point of contact name

   - Point of contact email address

   - Point of contact phone number

   - Host bureau (IRS)

   - Start date of the event

   - End date of the event

   - Number of attendees

   - Event facility

   - Event location (city and state only)

   - Description of event’s purpose (training, meeting, forum, conference, etc.)

   - Brief explanation of how the event furthered the IRS’s mission

   - Justification for the use of non-government space, if applicable

   - Description of the contracting procedures

   - Total number of room nights

   - Lodging per diem rate

   - All travel-related expenses that include, but are not limited to: lodging, meals and incidental expenses (M&IE), airfare, miscellaneous costs, transportation (rail, rental car, privately owned vehicle), taxis, parking. The travel card may not be used for non-travel expenses.

   - Meeting room rental charges, if applicable

   - Food, beverage charges or light refreshments, if applicable

   - Audio Visual (A/V) equipment charges, including A/V equipment, A/V technician and labor fees and meeting room internet fees, if applicable

   - Non-A/V equipment and room set up charges, if applicable

   - Meeting expenses (non-travel costs) including tuition, registration, cancellation fees

   - Total cost

   - Variance statement (required if event costs are 10% above or below the estimated costs) - detail must be provided as to why the costs were so much less and/or more than the estimated costs


4. CFO will enter information reported by the business units at 40 calendar days post event into the Treasury online tracking database.

5. Prior to November 15, business units are responsible for ensuring actual costs for the preceding fiscal year are finalized and reported.

6. Each November, CFO will provide Treasury with detailed information on events costing more than $100,000 for the preceding year for public reporting.

7. Treasury must publish all events over $100,000 publicly by November 30 each year.

8. Business units are responsible for notifying the CFO at cfo.event.request@irs.gov of any cancellations, postponements or significant changes to events that require Treasury reporting within 10 calendar days after the event end date.


**1.32.10.4** **(05-11-2020)**

### Internal Order Codes for Events

1. For the purpose of event spending tracking, business units should contact their business unit finance office to request establishment of a unique IOC for any event with an estimated cost of $20,000 or more.

2. To ensure that the IRS can capture the full cost of an event, it is critical that the business units use the appropriate accounting codes for all event-related expenses.



   - Travel requests in the electronic travel system must include the appropriate IOC to ensure that the IRS can capture the full actual cost of an event.

   - Event coordinators are responsible for making sure that travelers receive guidance and provide the IOC to use for the event. They should also provide instructions on how to include the IOC on the travel authorizations and vouchers.

   - Managers are responsible for reviewing all travel authorizations and vouchers to ensure that the proper IOC and accounting strings are used.

   - Employee salaries to attend events are not reported. As a result, there will be no effect on time entry in the Single Entry Time Reporting (SETR) system.

   - Requisitions in the Procurement for Public Sector (PPS) to purchase equipment or control services related to events, for which the total cost is $20,000 or more, must include a unique event IOC.


3. A copy of an IOC report detailing the actual cost of an event should be attached to the Treasury reporting spreadsheet that is submitted to cfo.event.request@irs.gov after the event has been held.

4. For additional information on IOC requirements please see IRM 1.33.4, Financial Operating Guidelines, or contact Corporate Budget via email at cfo.master.data.request@irs.gov.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-032-010#addtoany "Show all")

A2A