---
url: "https://www.irs.gov/irm/part1/irm_01-032-001"
title: "1.32.1 IRS Local Travel Guide | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-032-001#main-content)

- 1.32.1  [IRS Local Travel Guide](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638178295328)
  - 1.32.1.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638178406528)
    - 1.32.1.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638178399984)
    - 1.32.1.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638178395568)
    - 1.32.1.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177996816)
      - 1.32.1.1.3.1  [Approving Officials](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177990768)
      - 1.32.1.1.3.2  [Employees](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177978320)
      - 1.32.1.1.3.3  [CFO and Deputy CFO](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177965504)
      - 1.32.1.1.3.4  [Senior Associate CFO Financial Management](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177962384)
      - 1.32.1.1.3.5  [Travel Management Office](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177960512)
      - 1.32.1.1.3.6  [Travel Policy and Review](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177955088)
      - 1.32.1.1.3.7  [Travel Services](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177948224)
      - 1.32.1.1.3.8  [Travel Operations](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177942736)
    - 1.32.1.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177938080)
      - 1.32.1.1.4.1  [Program Reports](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177935616)
      - 1.32.1.1.4.2  [Program Effectiveness](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177933888)
    - 1.32.1.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177909248)
    - 1.32.1.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177886240)
    - 1.32.1.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177838512)
    - 1.32.1.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177810720)
  - 1.32.1.2  [General Rules](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177807488)
  - 1.32.1.3  [Travel Guidance for Year End](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177797776)
  - 1.32.1.4  [Travel During Periods Covered by Continuing Resolution Authority](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177793920)
  - 1.32.1.5  [Training Travel](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177791248)
  - 1.32.1.6  [Invitational Travel](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177787040)
  - 1.32.1.7  [Transportation Expenses](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177749888)
    - 1.32.1.7.1  [Government-Owned Vehicle (GOV)](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177744128)
    - 1.32.1.7.2  [Public Transportation](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177735840)
    - 1.32.1.7.3  [Taxis, TNCs, Innovative Mobility Technology Companies, Shuttle Services or Other Courtesy Transportation](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177734128)
    - 1.32.1.7.4  [Rental Car](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177729216)
    - 1.32.1.7.5  [Privately Owned Vehicle (POV)](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177704688)
      - 1.32.1.7.5.1  [Mileage Reimbursement](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177697888)
      - 1.32.1.7.5.2  [50-mile Offset Rule](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177690656)
      - 1.32.1.7.5.3  [Six Day Rule](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177683632)
    - 1.32.1.7.6  [Parking Fees and Rented Parking Space](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177675840)
    - 1.32.1.7.7  [Limousine and Executive Car Service](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177670256)
  - 1.32.1.8  [Per Diem Expenses for Local Travel](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177667712)
  - 1.32.1.9  [Miscellaneous Expenses](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177655872)
  - 1.32.1.10  [Public Transportation Subsidy Program (PTSP)](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177648560)
  - 1.32.1.11  [Taxable Travel Reimbursement](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177645792)
  - 1.32.1.12  [Local Long-Term Taxable Travel](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177637776)
  - 1.32.1.13  [Filing Authorization for Long-Term Taxable Travel Form](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177620768)
  - 1.32.1.14  [Extended Temporary Duty Travel Tax Reimbursement Allowance](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177615120)
  - 1.32.1.15  [Arranging for Travel Services, Fees, Paying Travel Expenses and Claiming Reimbursements](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177609344)
    - 1.32.1.15.1  [Arranging for Transportation](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177605600)
    - 1.32.1.15.2  [Fees](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177603216)
    - 1.32.1.15.3  [Paying Travel Expenses Using the Government Travel Card](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177598208)
    - 1.32.1.15.4  [Claiming Reimbursement](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177575728)
  - 1.32.1.16  [Death of Employee While in Travel Status](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177529776)
  - 1.32.1.17  [Travel Forms](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177523856)
  - 1.32.1.18  [Delegation Orders (DO)](https://www.irs.gov/irm/part1/irm_01-032-001#idm139638177520960)

# Part 1. Organization, Finance, and Management

# Chapter 32. Servicewide Travel Policies and Procedures

# Section 1. IRS Local Travel Guide

* * *

## 1.32.1 IRS Local Travel Guide

#### Manual Transmittal

March 22, 2023

#### Purpose

(1) This transmits revised IRM 1.32.1, Servicewide Travel Policies and Procedures, IRS Local Travel Guide.

#### Material Changes

(1) 1.32.1.1(5), Program Scope and Objectives - Primary Stakeholders - added employees who perform or approve official local travel.

(2) 1.32.1.1.3.1 (1)(p), Approving Officials - added Ensuring that travelers submit a local travel voucher every 30 days or if an infrequent traveler with minimal expenses that do not require immediate reimbursement, employees may file a quarterly voucher; and ensuring claimed travel expenses are correct.

(3) 1.32.1.1.3.2 (1)(k), Employees - added Ensuring that travelers submit a local travel voucher every 30 days or if an infrequent traveler with minimal expenses that do not require immediate reimbursement, employees may file a quarterly voucher; and ensuring claimed travel expenses are correct.

(4) 1.32.1.1.3.6(f), Travel Policy and Review - changed travelers to employees.

(5) 1.32.1.1.4 2(a), Program Effectiveness - General Review Items - updated based on updated definition of local travel.

(6) 1.32.1.1.4.2(1), Program Effectiveness - Referrals to Labor/Employee Relations and Negotiations (LERN) - added for clarification - Employees’ audit errors with 1) two or more repeated violations of IRS travel policy, or 2) potential fraudulent transactions, will be put into the Alerts system and referred to Labor/Employee Relations and Negotiations for further determination of disciplinary action.

(7) 1.32.1.1.6 (s), Terms/Definitions - local travel - updated based on FTR definition of city-to-city travel - Travel within a 50-mile radius of the employees officially assigned duty station which is completed within one day and does not require any air, rail or lodging expenses.

(8) 1.32.1.1.6 (u), Terms/Definitions - Official Station - updated for clarification with definition from FTR -An area defined by the agency that includes the location where the employee regularly performs his or her duties or an invitational traveler's home or regular place of business (see **§ 301-1.2**). The area may be a mileage radius around a particular point, a geographic boundary, or any other definite domain, provided no part of the area is more than 50 miles from where the employee regularly performs his or her duties or from an invitational traveler's home or regular place of business. If the employee's work involves recurring travel or varies on a recurring basis, the location where the work activities of the employee's position of record are based is considered the regular place of work.

(9) 1.32.11.1.6(2)(v), Terms/Definitions - added definition - Official Assigned Duty Station/Post of Duty (POD) - the specific building address of record the employee is permanently assigned.

(10) 1.32.1.1.6 (z), Terms/Definitions - Residence - reworded for clarification - The home in which an employee lives in the vicinity of the official assigned duty station, and where an employee commutes to and from the official assigned duty station daily or when required to report to the official assigned duty station.

(11) 1.32.1.2 (2), General Rules - updated based on definition of local travel - This IRM covers travel on official business, which is performed within a 50-mile radius of the employee’s official assigned duty station that is performed within one day and does not require any air, rail or lodging expenses.

(12) 1.32.1.2 (3), General Rules - added - The employee must apply the 50-mile offset and six day rule when applicable.

(13) 1.32.1.2 (4), General Rules - added - The employee must use the proper line of accounting to identify local long-term taxable travel.

(14) 1.32.1.7(2), Transportation Expenses - updated for clarification - Employees performing local travel may claim transportation expenses for:

1. Public transportation like buses, streetcar, trolley or other public transportation

2. Taxis, TNCs, shuttle services and other local transit systems

3. Rental cars, plus fuel

4. POV mileage, minus any applicable offset or rule per IRM 1.32.1.7.5, Privately Owned Vehicle (POV)

5. Rented parking spaces

6. Parking

7. Tolls


(15) 1.32.1.7.2, Public Transportation - section added for clarification - Employees should use public transportation such as bus, streetcar or subway when available and practical.

(16) IRM 1.32.1.7.3(5), Taxis, TNCs, Innovative Mobility Technology Companies, Shuttle Services or Other Courtesy Transportation - added - Employees are not authorized the use of luxury or executive type vehicle services offered by Uber or Lyft (e.g., Uber Black, Uber Premier, Lyft Lux, etc.).

(17) 1.32.1.7.4(1), Rental Car - added for official government travel only for clarification.

(18) 1.32.1.7.5(2)(a), Privately Owned Vehicle (POV) - reworded (a) for clarification -Limit reimbursement to the constructive cost of the authorized method of transportation, which is the sum of the reasonable transportation expenses the employee would have incurred when traveling by the authorized method of transportation versus POV mileage

(19) 1.32.1.7.5(2)(b), Privately Owned Vehicle (POV) - removed (b) not needed for one day travel.

(20) 1.32.1.7.5 (3), Privately Owned Vehicle (POV) - removed requirement to deduct normal commute and in excess of normal commute.

(21) 1.32.1.7.5.2, 50-mile Offset Rule - added back in from July 10, 2019, IRM 1.32.1 with more detailed information for clarification.

(22) 1.32.1.7.5.3, Six Day Rule - added back in from July 10, 2019, IRM 1.32.1.7.5.3, Six Day Rule, with more detailed information for clarification.

(23) 1.32.1.7.6 (3), Parking Fees and Rented Parking Space - added Employees must provide a receipt for any parking expenses in excess of $25.

(24) 1.32.1.11 (1), Taxable Travel Reimbursement - added (a) Daily travel between employee’s residence and a non-temporary work location (other than the officially assigned duty station).

(25) 1.32.1.11, Taxable Travel Reimbursement - added (3) & (4).

(26) 1.32.1.12, Local Long-Term Taxable Travel - added section.

(27) 1.32.1.14, Extended Temporary Duty Travel Tax Reimbursement Allowance - added section.

(28) 1.32.1.15.4 ( ), Claiming Reimbursement - added If you are an infrequent traveler and have minimal expenses that do not require immediate reimbursement you may file a voucher on a quarterly basis.

(29) 1.32.1.15.4 (10), Claiming Reimbursement - added Parking receipt in excess of $25.

(30) This revision includes changes throughout the document for the following:

1. Updated the CFO office names and responsibilities

2. Per Executive Order 13988, references to him, her and his were updated

3. Removed references specific to city-to-city travel and not applicable to local travel

4. Added minor editorial changes such as grammatical, spelling and minor changes for clarification purposes

5. Updated links throughout the IRM

6. Corrected references throughout the IRM


#### Effect on Other Documents

IRM 1.32.1, dated October 21, 2021, is superseded. This IRM incorporates Interim Guidance Memorandum CFO-01-1221-0003, Interim Guidance for IRS Travel Policies, dated February 28, 2022.

#### Audience

All business units

#### Effective Date

(03-22-2023)

Teresa R. Hunter

Chief Financial Officer

**1.32.1.1** **(03-22-2023)**

### Program Scope and Objectives

1. **Purpose:** This IRM provides guidance for all IRS employees on official local travel.

2. **Audience:** All business units

3. **Policy Owner:** CFO, Financial Management

4. **Program Owner:** The CFO, Financial Management, Travel Management office develops and maintains this IRM

5. **Primary Stakeholders:** The primary stakeholders are IRS employees who perform or approve official local travel.

6. **Program Goal:** To ensure that IRS employees exercise integrity and comply with the Federal Travel Regulations (FTR) and IRS travel policy.


**1.32.1.1.1** **(07-10-2019)**

#### Background

1. The FTR does not address local travel and instead delegates that responsibility to each federal agency.

2. This IRM authorizes the IRS to reimburse employees for local travel expenses incurred when performing official business.

3. This IRM outlines the IRS’s local policies and procedures including case-related, training, emergency and invitational travel. It also provides procedures for preparing and approving authorizations and claiming reimbursement for local travel expenses.

4. This IRM implements policies to ensure that local travel expenses are authorized in accordance with travel policy. IRS cannot reimburse an employee for expenses that are not consistent with this IRM which may have been a result of inaccurate information.

5. City-to-city and relocation travel policy is not covered in this IRM. City-to-city travel is covered in IRM 1.32.11, IRS City-to-City Travel Guide, and relocation travel is covered in IRM 1.32.12, IRS Relocation Travel Guide.


**1.32.1.1.2** **(07-10-2019)**

#### Authorities

1. 31 U.S. Code Section 901, [Establishment of agency Chief Financial Officers](http://www.law.cornell.edu/uscode/text/31/901)

2. [Revenue Ruling 99-7](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&ved=2ahUKEwjCyfzxwsv5AhW-nGoFHdzhD9oQFnoECBEQAQ&url=https%3A%2F%2Fwww.irs.gov%2Fpub%2Firs-irbs%2Firb99-05.pdf&usg=AOvVaw03btFwlctDO_CcSL5oez2Q)

3. 5 U.S. Code, Chapter 41, [Training](https://uscode.house.gov/view.xhtml?path=/prelim@title5/part3/subpartC/chapter41&edition=prelim)

4. [Travel and Transportation Reform Act of 1998](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&ved=2ahUKEwj-nfLbxMv5AhWMsoQIHU9qAygQFnoECAMQAQ&url=https%3A%2F%2Fwww.congress.gov%2F105%2Fplaws%2Fpubl264%2FPLAW-105publ264.pdf&usg=AOvVaw0wG9hTo3sAptrFOFJpjtba)


**1.32.1.1.3** **(10-21-2021)**

#### Responsibilities

1. This section provides responsibilities for:



1. Approving officials

2. Employees

3. CFO and Deputy CFO

4. Senior Associate CFO Financial Management

5. Travel Management

6. Travel Policy and Review

7. Travel Services

8. Travel Operations


**1.32.1.1.3.1** **(10-21-2021)**

##### Approving Officials

1. Approving officials are responsible for:



01. Completing mandatory travel policy training every two years.

02. Providing employees with access and the opportunity to review the material in this guide and any other travel regulations prior to traveling.

03. Answering questions an employee may have about the content of this guide or related travel matters.

04. Providing employees who are expected to travel with information on how to apply for a government travel card.

05. Planning travel to ensure that employees' time and travel funds are used in the most efficient and economical manner.

06. Directing employees' attention to possible travel savings.

07. Planning travel so employees do not incur personal expenses for properly authorized travel.

08. Reviewing and approving travel authorizations and vouchers to ensure expenses and accounting information are correct.

09. Approving travel authorizations at least four days prior to the actual travel dates.

10. Ensuring travel expenses are authorized under travel policy. IRS cannot reimburse an employee for expenses that are not consistent with this IRM which may have been a result of inaccurate information.

11. Ensuring required receipts and supporting documentation are scanned or faxed into ETS or attached to the manual vouchers.

12. Reconciling receipts and supporting documentation against the expenses claimed on the voucher before approving.

13. Maintaining copies of approved travel authorizations and supporting documentation for manual vouchers in compliance with General Records Schedule (GRS) 1.1, item 010 Financial Transaction Records Related to Procuring Goods and Services, Paying Bills, Collecting Debts, and Accounting.

14. Reviewing advances to ensure that they are appropriate for expected travel requirements.

15. Ensuring that employees who are either transferring or separating have repaid outstanding travel advances.

16. Ensuring that travelers submit a local travel voucher every 30 days or if an infrequent traveler with minimal expenses that do not require immediate reimbursement, employees may file a quarterly voucher; and ensuring claimed travel expenses are correct.

17. Approving or returning a travel voucher within seven calendar days of submission (to ensure payment within 30 calendar days of submission).

18. Ensuring that advances are liquidated on the vouchers.

19. Ensuring reporting instructions are attached if purpose code "T" is used.


2. Delegation Order 1-30, Authorization and Approval of Official Travel within the United States, identifies the appropriate IRS officials with the delegated authority to authorize and approve travel. This authority has been delegated to managers and may be redelegated to a level no lower than management official.


**1.32.1.1.3.2** **(10-21-2021)**

##### Employees

1. Employees are responsible for:



01. Completing mandatory travel policy training every two years.

02. Performing official travel within the guidance of travel policies, regulations and procedures.

03. Requesting clarification on any travel policies, regulations and procedures that are not understood.

04. Planning travel to minimize travel cost to the IRS.

05. Exercising the same prudence and economy when incurring expenses in the performance of official travel that a prudent person would exercise if traveling on personal business.

06. Submitting a travel authorization at least five days before traveling and incurring local travel expenses.

07. Paying all charges and fees associated with the government travel card by the due date on the invoice. Employees are liable for all charges and will not be reimbursed above maximum levels prescribed by law.

08. Using the mode of transportation that results in the greatest overall advantage to the government.

09. Using the government travel card for official travel including transportation expenses (bus, streetcar, transit system), automobile rentals and other major travel-related expenses.

10. Canceling unused travel authorizations.

11. Submitting a local travel voucher every 30 days or if you are an infrequent traveler with minimal expenses that do not require immediate reimbursement, you may file a quarterly voucher; and ensuring claimed travel expenses are correct. IRS cannot reimburse an employee for expenses that are not consistent with this IRM which may have been a result of inaccurate information.

12. Liquidating a travel advance on a voucher or by submitting a check to Travel Operations.

13. Accounting for travel advances received and repaying any advances that are not liquidated by travel expenses. Employees are indebted to the government for advances which may become taxable.

14. Paying additional expenses resulting from scheduling travel for personal convenience and charging excess travel time against leave.

15. Not delaying the performance of official travel for personal reasons.

16. Not claiming personal expenses on travel vouchers.

17. Ensuring required receipts and supporting documentation are scanned, faxed or uploaded into the Electronic Travel System (ETS) or attached to your manual voucher.

18. Ensuring any outstanding advances are repaid if you are separating from the service.

19. Ensuring approval is obtained prior to incurring any expenses that require advance approval. For example: per diem within the commuting area.

20. Acknowledge that they have read and understand the following truth and accuracy statement before signing their voucher: “I certify that this voucher is true and correct to the best of my knowledge and belief, and that payment or credit has not been received by me.”


**1.32.1.1.3.3** **(07-10-2019)**

##### CFO and Deputy CFO

1. The CFO and the Deputy CFO are responsible for:



1. Overseeing policies, procedures, standards and controls for the IRS financial processes and systems.

2. Ensuring that IRS’s financial management activities comply with laws and regulations.


**1.32.1.1.3.4** **(07-10-2019)**

##### Senior Associate CFO Financial Management

1. The Senior Associate CFO Financial Management is responsible for establishing and ensuring compliance with policies and procedures, and for maintaining internal controls on local travel.


**1.32.1.1.3.5** **(10-21-2021)**

##### Travel Management Office

1. The Travel Management office is responsible for:



1. Developing and issuing IRS local and city-to-city travel policy.

2. Approving exemptions to using electronic travel system (ETS).

3. Reviewing financial policies and procedures for compliance with financial laws and regulations.

4. Approving reduced per diem rates.

5. Approving exceptions to the required commute for receiving per diem.

6. Reviewing and submitting premium class travel requests to CFO for denial or approval of requests.

7. Reviewing and/or approving all reimbursements for expenses which require higher level approval.


**1.32.1.1.3.6** **(03-22-2023)**

##### Travel Policy and Review

1. The Travel Policy and Review staff is responsible for:



1. Educating customers on travel policy, Federal Travel Regulations, ETS and travel procedures.

2. Review travel course materials used when Travel Services conducts travel workshops and customer outreach to ensure traveler compliance with regulations and travel policy.

3. Authoring travel IRMs, Interim Guidance, delegation orders and travel forms.

4. Develop, administer and manage mandatory travel policy training in Integrated Talent Management (ITM).

5. Developing travel communications.

6. Performing travel compliance reviews on travel documents and referring employees with two or more repeated violations, within twelve months, of the FTR and/or IRS travel policies or potential fraudulent transactions to Labor/Employee Relations and Negotiations for further determination of disciplinary action.

7. Conducting quarterly analysis on audit findings and creating scorecards for each business unit.

8. Monitoring and conducting quarterly reviews of Local long term taxable travel (LTTT) for all travelers to determine if travel is to a single location. Review to determine if there appears to be excessive travel to a single location and should be reported as LTTT and reviewing all executive travel for potential LTTT.

9. Managing the Travel Management Center (TMC) contract.


**1.32.1.1.3.7** **(10-21-2021)**

##### Travel Services

1. Travel Services is responsible for:



1. Providing help desk services for users and authorizing officials.

2. Administering the ETS, a web-based end-to-end travel system.

3. Interpreting federal travel policies and procedures.

4. Communicating travel related information.

5. Serving as the Federal Agency Travel Administrator (FATA).

6. Performing eTravel post audit reviews of local travel vouchers.

7. Updating training material to conduct quarterly travel workshops to continue travel education.


**1.32.1.1.3.8** **(10-21-2021)**

##### Travel Operations

1. Travel Operations is responsible for:



1. Reviewing and processing manual travel authorizations and vouchers.

2. Processing Extended TDY Tax Reimbursement Allowance (ETTRA) reimbursement.

3. Processing travel reclassifications identified by Travel Policy and Review.

4. Performing eTravel post audit reviews of city-to-city and foreign travel vouchers.

5. Educating travelers on established travel policy, Federal Travel Regulation (FTR) and travel procedures.

6. Providing customer service for vouchers reviews.


**1.32.1.1.4** **(07-10-2019)**

#### Program Management and Review

1. The CFO is required to report all travel and transportation payments of more than $5 million during the fiscal year to Government Services Administration (GSA).

2. The travel reports include a list of data elements and report formats provided by GSA. The data must be submitted to GSA by November 30 and GSA must provide a government-wide report by January 31 to Office of Management and Budget (OMB) and Congress to be available to the public.


**1.32.1.1.4.1** **(07-10-2019)**

##### Program Reports

1. The IRS completes and submits the Travel Reporting Information Profile (Trip) to the Department of the Treasury annually.


**1.32.1.1.4.2** **(03-22-2023)**

##### Program Effectiveness

1. The IRS ensures program effectiveness for travel authorizations and vouchers through these processes:




| Local Travel Post Audit Review-Current Process |
| :-: |
| An ETS post payment review analysis is conducted every quarter. A percentage of vouchers are pulled from a report based a random sampling formula for all vouchers. The percentage is subject to change based on workload, staffing and volume. |
| General Review Items:<br> <br>1. Travel performed within a 50-mile radius of the employee’s official duty station, completed within one day and does not involve an overnight stay or lodging expenses.<br>      <br>2. Correct TDY location was used for determining LTTT.<br>      <br>3. All expenses are within travel period.<br>      <br>4. Government Credit Card (GOVCC) is used for specific expenses.<br>      <br>5. Receipts are provided for all transportation expenses, specific expenses under $75.00 and all other expenses over $75.00.<br>      <br>6. Reporting Instructions are uploaded into ETS for all travel that has a purpose code of "T" for training travel.<br>      <br>7. Reservation fees are claimed, if applicable for rental car.<br>      <br>8. All late authorizations require an email authorizing travel from approving official. |
| Transportation Expenses Claimed for Privately Owned Vehicle (POV) Transportation:<br> <br>1. Check expenses tab in ETS to validate mileage claimed.<br>      <br>2. Verify 50-mile offset and six day rule were applied correctly, when applicable.<br>      <br>3. Verify proper coding if travel is taxable.<br>      <br>4. Verify mileage if expense appears excessive. |
| Rental Car Expenses Claimed:<br> <br>1. GOVCC used for expenses, including fuel.<br>      <br>2. Receipt attached in ETS, including fuel receipt regardless of dollar amount.<br>      <br>3. No expenses were included for collision damage waiver or theft insurance for personal accident (codes on receipts generally reflect CDW, PAI or LDW).<br>      <br>4. Prepaid fuel is not reimbursable.<br>      <br>5. Dates of rental match dates of travel. Limited exceptions for picking up a rental prior to official travel beginning or returning after official travel has been completed should be document and approved by the approving official. |
| Miscellaneous Items Claimed:<br> <br>1. Ensure excessive expenses have a justification.<br>      <br>2. Ensure emergency or unusual miscellaneous expenses are justified and receipt attached.<br>      <br>3. Ensure cash conversion and Automated Teller Machine (ATM) fees are included if applicable. |
| Mandatory Use of the GOVCC:<br> <br>1. Ensure all required travel expenses list GOVCC on the voucher.<br>      <br>2. If the traveler did not use the GOVCC, ensure a waiver was obtained from Travel Management policy office. |
| Referrals to Labor/Employee Relations and Negotiations (LERN):<br> <br>1. Employees’ audit errors with 1) two or more repeated violations of IRS travel policy, or 2) potential fraudulent transactions, will be put into the Alerts system and referred to LERN for further determination of disciplinary action. |

2. Long-Term Taxable Travel Reviews-Current Process



1. Quarterly Potential Long-Term Taxable Travel (LTTT) review for both executives and non-executives to determine if travel is to a single location.

2. In-depth review and analysis for travelers that appear to be traveling excessively to a single location and possibly should be filing their travel as LTTT.

3. Review all executives travel for potential LTTT, when asked by the CFO.


**1.32.1.1.5** **(10-21-2021)**

#### Program Controls

1. The following chart describes the internal controls in place for the local travel program:




| **Area of Concern** | **Control Method** |
| --- | --- |
| Delegation of Authority | Authority to approve critical travel processes is delegated to the appropriate level in the business units and is documented. |
| ETS Access | User profiles for ETS access are appropriate for the job requirements. |
| Separation of Duties | Separate roles are established for preparers, reviewers, approvers and FATA. |
| Approving Official | The IRS travel guide contains a complete description of the responsibilities for approving travel and authorizing payments for reimbursement of travel expenses. |
| ETS Quality Reviews | Travel Services conducts post-payment audits quarterly. |
| ETS Data Security | Sensitive information is protected from unauthorized access. |
| Manual Quality Reviews | Travel Operations audits 100% of all manual vouchers prior to paying. |
| Travel Advances | Advances cannot be issued to cover transportation costs for non-travel card holders. In ETS the controls for advances are:<br> Standard cardholders cannot obtain a travel advance since they have ATM withdrawal access.<br> Restricted cardholders can get an advance for up to 40% of all reimbursable expenses, except transportation and lodging costs.<br> Non-travel card holders can get 100% of all reimbursable expenses advanced. |
| Liquidation of Travel Advances | Advances are liquidated with each travel voucher. If the traveler does not file a voucher timely, the deobligation utility will convert the advance to a debt for the traveler. |
| Rental Car | Receipts are required for rental car, including fuel and/or oil, regardless of amount. |
| Transportation Cost | Receipts are required for amounts over $75. |
| Pre-Audit Flags | Pre-audit flags in ETS have been established for items that exceed the IRS’s standard policy, and the traveler is required to provide a justification to the approving official to explain any unusual request. |
| Actual Expenses | Actual subsistence for lodging and/or M&IE must be authorized in advance by a first level executive. Authorization must be uploaded into the ETS. |
| Travel Vouchers | All vouchers must be signed by the traveler and approved by the traveler’s manager or approving official. |
| Prompt Pay Interest | Email notifications are sent to the approving officials to notify them that a voucher is waiting their approval immediately after the traveler signs the voucher. |
| Travel Reports | Employees can only view documents related to the org code or group for which they have a user role of approver, preparer or reviewer. |
| Separated Employees | Employees are automatically deleted from the system based on a file received from HCO. |
| Non-IRS Employees | Non-IRS employees may not use the IRS travel system. |


**1.32.1.1.6** **(03-22-2023)**

#### Terms/Definitions

1. The following terms and definitions apply to this program:



01. **Accounting label** \-\- Refers to the line of accounting in the IRS electronic travel system.

02. **Alternative worksite** \-\- A place where an employee is temporarily reassigned, most likely to another building/office within the city limits of the official station.

03. **Approving official** \-\- The manager or management official authorized to approve travel authorizations and vouchers in accordance with Servicewide travel-related Delegation Orders. The approving official should be a grade level equal to or higher than those whose documents they are approving.

04. **Attendant** \-\- An individual who provides personal care and travels with an authorized IRS traveler who has a disability or special need.

05. **Automatic teller machine (ATM) travel advance** \-\- Contractor-provided service that allows cash withdrawals from participating ATMs. The cash withdrawal and associated fees are charged to the Standard Travel Card account. Cash from ATMs is only authorized for expenses that cannot be charged to the travel card while in official travel status.

06. **Common carrier**\-\- Private sector supplier of air, rail, bus or mass transit.

07. **Commute -** Transportation an employee normally incurs when traveling to and from their residence to their official assigned duty station.

08. **Commuting area** \-\- For per diem purposes only, is defined as the area within a 50-mile radius of the employee’s residence **and** official station.

09. **Concur Government Edition (CGE) reservation fee** \-\- A vendor fee that will auto-populate in a document when reservations are booked through Concur or by contacting the TMC directly.

10. **Electronic travel system (ETS)** \-\- A government-contracted computer application and database that provides IRS travelers with automated travel planning and reimbursement capabilities. The ETS includes authorization, reservation and vouchering capabilities for domestic and foreign city-to-city and local travel.

11. **Employee** \-\- An individual serving in the IRS in the usually accepted employer-employee relationship. Employees are entitled to reimbursement of travel and transportation expenses while away from their residences or official assigned duty station.

12. **Extended TDY tax reimbursement allowance (ETTRA)** \-\- An allowance designed to reimburse an employee for federal, state and local income taxes incurred because of local long-term travel.

13. **Fiscal Year** \-\- The twelve-month accounting period used in the government. It begins on October 1 and ends September 30 and is designated by the calendar year in which it ends.

14. **Government owned vehicle (GOV)** \-\- An automobile or light truck, including vans and pickup trucks that is:


        1\. Owned by an agency,


        2\. Assigned or dispatched to an agency from the GSA Interagency Fleet Management System, or


        3\. Leased by the government for a period of 60 days or longer from a commercial source.

15. **Government travel card** \-\- A government contractor-issued card used by employees to pay for official travel expenses such as transportation, lodging, meals, baggage fees, and rental cars and associated fuel/oil where the contractor bills the employee.

16. **Head of office** \-\- Any of the following IRS officials and their deputies: Commissioner, Deputy Commissioners, Division Commissioners, Chiefs, Chief Counsel, directors reporting directly to the Commissioner or a Deputy Commissioner, and the National Taxpayer Advocate.

17. **Innovative mobility technology company** \-\- An organization, including a corporation, limited liability company, partnership, sole proprietorship, or any other entity, that applies technology to expand and enhance available transportation choices, better manages demand for transportation services, or provides alternatives to driving alone.

18. **Invitational traveler** \-\- Travel performed by non-Federal Government employees, including contractors, who are acting in a capacity directly related to official activities of the IRS. Reimbursement for travel by non-Federal Government employees is subject to the same regulations as travel by IRS employees.

19. **Local travel** \-\- Travel within a 50-mile radius of the employees officially assigned duty station which is completed within one day and does not require any air, rail or lodging expenses.

20. **Management official** \-\- An employee with duties and responsibilities requiring or authorizing the individual to formulate, determine or influence IRS policy. The employee also must be a non-bargaining employee on performance commitments under Form 12450A, Management Performance Agreement, or 12450B, Management Official Performance Agreement.

21. **Official station** \-\- An area defined by the agency that includes the location where the employee regularly performs his or her duties or an invitational traveler's home or regular place of business (see **§ 301-1.2**). The area may be a mileage radius around a particular point, a geographic boundary, or any other definite domain, provided no part of the area is more than 50 miles from where the employee regularly performs his or her duties or from an invitational traveler's home or regular place of business. If the employee's work involves recurring travel or varies on a recurring basis, the location where the work activities of the employee's position of record are based is considered the regular place of work.

22. **Official Assigned Duty Station/Post of Duty (POD)** \-\- the specific building address of record the employee is permanently assigned.

23. **Per diem allowance** \-\- Also referred to as subsistence allowance, is a daily payment instead of reimbursement for lodging, meals and related incidental expenses. The per diem allowance is separate from transportation expenses and other miscellaneous expenses.

24. **Privately owned vehicle (POV)** \-\- Any vehicle (such as an automobile, motorcycle, aircraft or boat) that is not owned or leased by a government agency and is not commercially leased or rented by an employee under a government rental agreement for use in connection with official government business.

25. **Profile**\-\- A set of user data that administrators (and sometimes business users) can display and modify. It includes attributes such as name, email, address and language.

26. **Residence** \-\- The home in which an employee lives in the vicinity of the official assigned duty station, and where an employee commutes to and from the official assigned duty station daily or when required to report to the official assigned duty station.

27. **Supplemental voucher** \-\- A document used to reimburse an employee for travel expenses omitted from a previously paid travel voucher.

28. **Taxi**\-\- A hired car that transports passengers to a destination for a fare based upon the distance traveled, time spent in the vehicle, other metric, or a flat rate to and from one point to another (for example, a flat rate from downtown to a common carrier terminal).

29. **Temporary duty travel (TDY) location** \-\- A place, away from an employee's official duty station, to which an employee is authorized to travel.

30. **Telework** \-\- An alternative workplace arrangement (AWA) permitting an employee to perform all or a portion of their officially assigned duties at an alternative worksite, including at residence or another pre-approved location (for example, GSA telework center, satellite IRS office) geographically convenient to the employee's residence.

31. **Texting or Text Messaging** \-\- Reading from or entering data into any handheld or other electronic device.

32. **Transportation network company (TNC)**\-\- A corporation, partnership, sole proprietorship, or other entity, that uses a digital network to connect riders to drivers affiliated with the entity in order for the driver to transport the rider using a vehicle owned, leased, or otherwise authorized for use by the driver to a point chosen by the rider; and does not include a shared-expense carpool or vanpool arrangement that is not intended to generate profit for the driver (i.e., Uber or Lyft).

33. **Travel authorization** \-\- An electronic or written document submitted for approval to authorize official travel. The travel authorization obligates funds and must be submitted and approved prior to travel, except in emergency situations.

34. **Travel authorization and voucher (TAV) fee** \-\- A charge or fee assessed for processing a travel voucher in the electronic travel system.

35. **Travel management center (TMC)** \-\- The travel agency operating under GSA contract that provides transportation, lodging and rental car services to the IRS.

36. **Travel status** \-\- The period an employee is traveling on official business. The period begins with departure from home, official station, or another authorized point and ends with return to that point.

37. **Travel voucher** \-\- A written request or electronic submission supported by documentation and receipts, where applicable, for reimbursement of expenses incurred in the performing official travel.


**1.32.1.1.7** **(10-21-2021)**

#### Acronyms

1. The following acronyms apply to this program:




| **Acronym** | **Acronym Title** |
| --- | --- |
| ATM | Automated Teller Machine |
| CGE | Concur Government Edition |
| CONUS | Continental United States |
| CR | Continuing Resolution |
| EFT | Electronic Funds Transfer |
| ERC | Employee Resource Center |
| ETTRA | Extended TDY Tax Reimbursement Allowance |
| ETS | E-Gov Travel Service |
| FATA | Federal Agency Travel Administrator |
| FICA | Federal Insurance Contributions Act |
| FTR | Federal Travel Regulation |
| GLS | General Legal Services |
| GOV | Government Owned Vehicle |
| GOVCC | Government Credit Card |
| GPS | Global Positioning System |
| GRS | General Records Schedule |
| GSA | General Services Administration |
| ITM | Integrated Talent Management |
| LOA | Line of Accounting |
| LTTT | Long-Term Taxable Travel |
| M&IE | Meals and Incidental Expenses |
| OCONUS | Outside the Continental United States |
| POD | Post of Duty |
| POV | Privately Owned Vehicle |
| PTSP | Public Transportation Subsidy Program |
| TDY | Temporary Duty |
| TMC | Travel Management Center |
| TNC | Transportation Network Company |
| TSP | Thrift Savings Plan |
| WTA | Withholding Tax Allowance |


**1.32.1.1.8** **(07-10-2019)**

#### Related Resources

1. IRM 1.32.4, Government Travel Card Program, for information on the travel card program and the centrally billed government travel card program.

2. IRM 1.2.2, Servicewide Delegations of Authority, for a list of travel related delegation orders.

3. IRM 6.800.2, Employee Benefits, IRS Telework Program, for additional information on telework.

4. IRM 1.32.15, Servicewide Travel Policies and Procedures, Public Transportation Subsidy Program (PTSP).


**1.32.1.2** **(03-22-2023)**

### General Rules

01. The preferred transportation method when performing local travel is common carrier transportation available to the public, such as bus, rail or subway. There are times when this transportation method may not be feasible due to location, timing, equipment/materials and or security reasons. Alternatives would be the use of a government vehicle, a contracted rental car or a privately owned vehicle (POV).

02. This IRM covers local travel on official business, which is performed within a 50-mile radius of the employee’s official assigned duty station that is performed within one day and does not require any air, rail or lodging expenses.

03. The employee must apply the 50-mile offset (see IRM 1.32.1.7.5.2) and six day rule (see IRM 1.32.1.7.5.3) when applicable.

04. The employee must use the proper line of accounting to identify local long-term taxable travel.

05. A local travel authorization allows an employee to perform local travel during regularly scheduled work hours. This authorization is primarily intended for case-related travel and other infrequent, local travel. A local travel authorization should be entered at least five working days before travel departure and must be approved before travel begins. Local travel will generally not include lodging, meals and incidental expenses or rental car, unless authorized as outlined in this IRM 1.32.1.7.4, Rental Car and 1.32.1.8, Per Diem Expenses for Local Travel.

06. An approved authorization is necessary to ensure that funds are obligated to support the travel. The approving official must limit the authorization and payment of travel expenses necessary to accomplish the mission in the most economical and effective manner in accordance with the policies stated throughout this IRM. The approving official should always consider less expensive alternatives, including teleconferencing, before authorizing travel.

07. An employee is required to have a local travel authorization that allows travel within a 50-mile radius of the employees officially assigned duty station which is completed within one day and does not require any air, rail or lodging expenses.

08. An employee must use the appropriate accounting label on the authorization. When a travel authorization is funded by another business unit, the accounting label of the other business unit must be entered on the travel authorization and documentation of funding by other business unit attached to the authorization.

09. An employee is required to use the ETS for preparing local travel authorizations and vouchers, unless exempted per IRM 1.32.1.2(12), General Rules.

10. The approving official must approve local travel five days prior to an employee incurring local travel expenses, unless the employee has an approved exemption.

11. The employee and approving official must electronically sign the authorization. If filing a manual authorization, the employee and approving official must sign the authorization in ink or electronically.

12. If an employee requests an exemption from using ETS, the employee’s manager must submit a request in writing or an electronic justification to the Director, Travel Management. Travel Management will notify the manager and employee when the request is approved or denied.


**1.32.1.3** **(07-10-2019)**

### _Travel Guidance for Year End_

1. Travel arrangements that are made the last few days of the fiscal year may be funded by current annual appropriation, providing the travel starts on or before September 30 and the per diem and other miscellaneous expenses are charged to the fiscal year in which the expenses are incurred.



1. In the event funding is not forthcoming and an employee is in a travel status at midnight on September 30, the approving official will advise the employees if it is necessary to return to their official assigned duty station.


2. Business units with multi-year funding may continue to authorize travel as long as there are sufficient funds available.


**1.32.1.4** **(07-10-2019)**

### Travel During Periods Covered by Continuing Resolution Authority

1. Travel arrangements may continue to be made during a continuing resolution (CR) provided that adequate funding is available to cover anticipated travel expenses. Travel that does not begin prior to the expiration date of the CR must not be signed or approved. The Agency is not permitted to obligate funds not yet appropriated.

2. Official travel may not commence unless a CR is in effect, or a regular appropriation has been enacted. Employees already in travel status when a CR expires (and a new CR is not in place) should seek direction from their supervisor on whether it is necessary to return to the official assigned duty station.


**1.32.1.5** **(07-10-2019)**

### Training Travel

1. Training travel occurs when the IRS requires an employee to travel to attend courses or professional meetings that may involve scientific or professional societies, municipal, state, federal or international organizations. Training travel also includes travel to attend:



1. Congressional and law enforcement events,

2. Other groups meetings to give or get information about IRS activities.


2. Employees who travel to attend training classes within the commuting area of their residence or official assigned duty station are considered on official business and may be entitled to reimbursement of transportation expenses. Reimbursement is subject to the review and approval of the employee’s manager.


**1.32.1.6** **(10-21-2021)**

### Invitational Travel

01. Invitational travel occurs when the IRS invites and pays the travel expenses for individuals not employed by the IRS or employed intermittently in the government. This includes:



    1. Persons employed by other federal government agencies.

    2. Persons serving without pay or at $1 a year when acting in a capacity related to or in connection with official IRS activities.

    3. Attendants to employees with disabilities or special needs.

    4. Persons accompanying an employee to a major award ceremony.

    5. Persons invited to interview with the IRS.

    6. Persons detailed to the IRS.

    7. Persons serving as a witness.


02. Reimbursement for invitational travelers is subject to the same regulations as travel by IRS employees.

03. The guest of an award recipient is considered an invitational traveler and travel authorizations and reimbursement expenses are the same as those normally authorized for IRS employees in conjunction with a temporary duty assignment.

04. Employees who receive a major award may be accompanied to the ceremony by one guest as an invitational traveler. Major awards ceremonies include:



    1. A Presidential Award.

    2. An IRS or major organizational component annual ceremony.


The guest’s travel route must be directly between their residence and the ceremony’s site.


05. If award recipients require special assistance attendants, the attendant may receive reimbursement for travel expenses to accompany the award recipient.

06. The IRS funding for non-IRS award ceremonies is limited to registration fees and local travel expenses for the award recipient and their manager or representative. Non-IRS award ceremonies include:



    1. A prestigious honorary award sponsored by a non-governmental organization.

    2. Award ceremonies hosted by organizations that advocate/recognize achievement in public service and or support public service professions (for example, Federal Executive Boards, Association of Government Accountants).


07. The invitational traveler's profile must be established to make travel reservations with the TMC, process electronic authorizations and vouchers, and complete manual travel authorizations and vouchers. The business unit coordinator can provide the traveler with a worksheet to ascertain the traveler's profile. The traveler must provide the completed profile request to the business unit.

08. The business unit coordinator prepares Form 13635, Manual Travel Authorization, provides a copy of the authorization to the invitational traveler, and requests the traveler’s original or electronic signature on the authorization. The invitational traveler must submit an approved Form 13635, Manual Travel Authorization, before travel begins.

09. A request for an exception to the required commute for per diem must be submitted to the Director, Travel Management, for approval. For lodging and rental car reservations, the invitational traveler will need to provide a personal credit card number to hold the reservations. Invitational travelers who do not provide a credit card number will need to arrange their own lodging and rental car. Invitational travelers should be notified of the per diem rates.

10. Invitational travelers cannot receive a travel advance.

11. An approving official may approve invitational travel as provided in Delegation Order 1-30, Authorization and Approval of Official Travel within the United States. The approved authorization must be mailed or efaxed to Travel Operations to process into the Integrated Financial System (IFS). Documentation can also be emailed to \*CFO Travel Authorizations and Accounting Codes.

12. The IRS’s practice is to pay by Electronic Funds Transfer (EFT). The IRS may grant an EFT waiver if no more than one reimbursement is expected to be paid to the same recipient within one-year. Invitational travelers must inform the business unit that they are unable to accept payment by EFT and complete a Request for Waiver of Electronic Funds Transfer (EFT) Payment for Individuals form. A business unit can obtain a copy of the form from the IRS Source, Employee Resources, Travel website: Travel Forms: .


     The traveler must mail the form to:




    | Internal Revenue Service<br> ATTN: Travel Management Vendor Code Coordinator<br> P.O. Box 9002<br> Beckley, WV 25802 |
    | --- |
    | Efax to 855-787-4375 or email to \*CFO Travel Authorizations and Accounting Codes |

13. The business unit coordinator must verify that the invitational travel has been completed. The traveler must complete and submit a signed paper voucher using, Form 15342, Travel Voucher, and all necessary receipts for claims, to the business unit coordinator.

14. When the travel is completed the business unit coordinator will:



    1. Create a manual voucher from the authorization for the trip.

    2. Include all authorized expenses on the manual voucher and attached receipts provided by the traveler.

    3. Provide a copy of the manual voucher to the invitational traveler and request the traveler’s original signature.

    4. Obtain the approving official’s signature on the manual voucher.


15. Invitational travel is reimbursed by submitting an approved Form 15342, Travel Voucher, required receipts and Form SF-1199-A, Direct Deposit Sign-up Form, to Travel Operations. Efax to 855-787-4375, or mail to \*CFO Travel Authorizations and Accounting Codes.




    | Mailing Addresses |
    | :-: |
    | The approved Form 15342 and SF-1199A must be mailed to:<br> Internal Revenue Service<br> ATTN: Travel Operations<br> P.O. Box 9002<br> Beckley, WV 25802 |
    | For overnight service, mail the forms to:<br> Internal Revenue Service<br> ATTN: Travel Operations<br> 110 N. Heber St.<br> Beckley, WV 25801 |


**1.32.1.7** **(03-22-2023)**

### Transportation Expenses

1. Employees may be reimbursed for transportation expenses they incur when conducting official business away from their official assigned duty station or residence.

2. In accordance with the provisions of this IRM, employees performing local travel may claim transportation expenses for:



1. Public transportation like buses, streetcar, trolley or other public transportation

2. Taxis, TNCs, shuttle services and other local transit systems

3. Rental cars, plus fuel

4. POV mileage, employees must apply the 50-mile offset (IRM 1.32.1.7.5.2) and six-day rule (IRM 1.32.1.7.5.3) when applicable.

5. Rented parking spaces

6. Parking

7. Tolls


3. Employees will not be reimbursed for commuting expenses. Commuting expenses are transportation expenses incurred while traveling from the employee's residence to their official assigned duty station and return. These expenses are personal expenses incurred by the employee and are not reimbursable. Employees are responsible for the commuting cost between their residence and their official assigned duty station.


**1.32.1.7.1** **(07-10-2019)**

#### Government-Owned Vehicle (GOV)

1. The approving official can only authorize employees to use a GOV for official purposes for travel:



1. Between places of official business

2. Between an official assigned duty station and alternate worksite(s) (when public transportation is unavailable, or it is impractical)


2. See IRM 1.14.7, Motor Vehicle Fleet Management Program, for additional information on the use of a government-owned vehicle.

3. Treasury Directive (TD P) 74- 01 section 15 Vehicle Parking, states that no government vehicles shall be parked overnight at any public transportation parking facility (i.e. airport, subway, train station), unless the vehicle is occupied or being used as a work area for surveillance. Office building parking facilities are not considered public transportation parking facilities.

4. Employees must report accidents that occur on official business in a government vehicle to their supervisor and the ERC immediately at 866-743-5748. See IRM 1.14.7.2.9, Motor Vehicle Fleet Management Program for additional information. Employees must also, contact IRS Claims Manager at: claims.manager@irscounsel.treas.gov.

5. The employee completes a [Form SF-91,](https://www.gsa.gov/forms-library/motor-vehicle-accident-report) Motor Vehicle Accident Report. Once completed, the employee’s manager must send the original SF-91, including copies of the police report, the [Form SF-94](https://www.gsa.gov/forms-library/motor-vehicle-accident-report), Statement of Witness, for the witnesses, to the Motor Vehicle Fleet Management Program motor vehicle coordinator or appropriate fleet manager and the local safety officer within 48 hours. The safety officer must forward a copy of each SF 91 to the IRS Claims Manager, Office of Chief Counsel, General Legal Services (CC:GLS:CLP), 1111 Constitution Avenue, NW - Room 6404, Washington, DC 20024.

6. In accordance with Executive Order 13513, issued October 1, 2009, IRS employees are prohibited from texting or text messaging while driving a GOV on official travel.


**1.32.1.7.2** **(03-22-2023)**

#### Public Transportation

1. Employees should use public transportation such as bus, streetcar or subway when available and practical.


**1.32.1.7.3** **(03-22-2023)**

#### Taxis, TNCs, Innovative Mobility Technology Companies, Shuttle Services or Other Courtesy Transportation

1. Employees should use taxis or other ride-share companies (Uber/Lyft) only when more economical means of transportation are not available or practical. Employees should first consider the use of local public transportation such as bus, streetcar, or subway. Employees may use taxis or other ride-share companies only when advantageous because of the expeditious transaction of official business, when carrying of necessary baggage or official documents or other compelling circumstances.

2. Taxis or other ride-share companies (Uber/Lyft) may be used when other modes of short-distance transportation are not reasonably available or if safety is a concern (example, a late-night return). Employees are entitled to be reimbursed the standard tipping amount for taxis up to 20% of the fare amount and the tip must be included in the total fare amount claimed on the travel voucher.

3. Courtesy shuttle transportation should be used whenever possible.

4. The use of bus, subway, or streetcar is an allowable expense for local travel and may be claimed to and from a temporary duty location. Reimbursement for official travel by commercial means may be authorized/approved for local public transportation when local transit fare medium such as tokens, tickets, or cash fares are not furnished by the IRS.

5. Employees may be reimbursed for ride-sharing companies like Uber and Lyft for travel on official business when the approving official determines it is advantageous to the government. Employees are not authorized the use of luxury or executive type vehicle services offered by Uber or Lyft (e.g., Uber Black, Uber Premier, Lyft Lux, etc.).


**1.32.1.7.4** **(03-22-2023)**

#### Rental Car

01. If no government-owned vehicle is available, and the approving official has determined that travel must be performed by automobile, then a rental car can be authorized for official government travel only. When traveling within a large metropolitan area, employees should consider using public transportation before requesting approval for using a rental car.

02. Employees may use a rental vehicle when the approving official has determined that the use of a rental vehicle is in the best interest of the government, such as:



    1. There is no government-owned vehicle available.

    2. There is no readily available public transportation at the travel destination, such as subway, bus, taxi or hotel courtesy shuttle.

    3. Additional room is required to accommodate multiple employees authorized to travel together in the same rental vehicle.

    4. When necessary for safety reasons, such as during severe weather or having to travel on rough or difficult terrain.

    5. When required because of the IRS mission.

    6. The cost of other than a compact car is less than or equal to the cost of the least expensive compact car.

    7. The employee must carry a large amount of government material incident to official business, and a compact rental vehicle does not contain sufficient space.


03. Employees who are authorized to use a rental car for local travel must use the least expensive compact car available unless an exception is approved, subject to the same standards as those outlined in FTR 301-10.450. The approving official should approve these exceptions on a limited basis and must indicate on the travel authorization the reason for the exception. Employees are to reserve the most cost-effective rental cars at the government’s expense. In general, compact size rental cars are considered most advantageous to the government. However, the approving official is ultimately responsible for determining and authorizing the appropriate size rental car necessary for the performance of official business under the circumstances.

04. When use of other than a compact car is necessary to accommodate a medical disability or other special need, the approving official may authorize the use of other than a compact car. Certification statements must include at a minimum:



    1. A disability must be certified annually in a written statement by a competent medical authority. However, if the disability is a lifelong condition, a one-time certification statement is required;

    2. A written statement by a competent medical authority stating that special accommodation is necessary;

    3. An approximate duration of the special accommodation;

    4. A special need must be certified annually in writing according to IRS’s procedures. However, if the special need is a lifelong condition, a one-time certification statement is required; and

    5. If employees are authorized under FTR §301-13.3(a) to have an attendant accompany them, the approving official may authorize the use of other than a compact car if deemed necessary.


05. Employees may request approval from the approving official for vehicle upgrades for using a non-compact rental car in the following circumstances:



    1. When two or more government employees will be sharing a vehicle.

    2. When the traveler must transport a large amount of government equipment.

    3. When the traveler has a documented medical condition requiring a larger vehicle.

    4. When a traveler’s physical size warrants a size increase.


06. When authorized to use a rental vehicle, an employee must use a vendor that participates in the Defense Travel Management Office (DTMO) U.S. Government Rental Car Program, unless the travel is outside the continental U.S. (OCONUS) and there is no agreement in place for the alternative worksite location. Reservations must be made through ETS or through the TMC.

07. Employees who are authorized to use a rental car will be reimbursed the cost of the rental car, taxes, tolls, parking, fuel and oil changes. Employees are responsible for any additional costs incurred as the result of an unauthorized use of a rental car.

08. Use of high performance, convertibles or other luxury vehicles is never allowed.

09. Employees are not reimbursed for purchasing pre-paid refueling options for a rental car. Therefore, employees should refuel prior to returning the rental car to the drop-off location. However, if it is not possible to refuel prior to returning the vehicle because of safety issues or the location of the closest fueling station in the area, employees will be reimbursed for rental car company refueling charges.

10. Employees will not be reimbursed for fees associated with rental car loyalty points for the transfer of points charged by car companies.

11. If employees rent a car with a Global Positioning System (GPS) that is permanently attached to the vehicle and the charge for the GPS is included in the daily rate rental car fee, they will be reimbursed the cost of the GPS. GPS devices that are removable or GPS rental are not considered to be standard equipment, but an accessory, and the employee would be liable for any costs if the device is lost or stolen.

12. If the GPS expense is not included in the daily rental cost but billed as a separate expense on the invoice, it is not reimbursable.

13. Employees who travel within CONUS should not purchase collision damage waiver, theft insurance, or personal accident insurance since the government rental car agreement includes full liability, vehicle loss and damage insurance coverage for the traveler and the government.

14. According to the _United States Government Rental Car Agreement Number 4_, an employee will be reimbursed for collision damage waiver or theft insurance when they travel OCONUS when such insurance is necessary due to rental or rental leasing agency requirements, a foreign statute, or because of legal procedures which could cause extreme difficulty for an employee if involved in an accident.

15. Cars rented by government employees under the _United States Government Rental Car Agreement Number 4,_ must be used only for authorized government purposes and should not be used to transport family and friends. Transporting family or friends raises claims, tort liability and employment law issues should an accident occur injuring the passengers.

16. In accordance with Executive Order 13513, issued October 1, 2009, IRS employees are prohibited from texting or text messaging while driving a rental car on official travel.

17. If employees are involved in a rental car accident, they must contact the IRS claims manager at: claims.manager@irscounsel.treas.gov. Employees must report accidents that occur on official business to their supervisor and the ERC immediately. See IRM 1.14.7.2.9, Motor Vehicle Fleet Management Program for additional information.


**1.32.1.7.5** **(03-22-2023)**

#### Privately Owned Vehicle (POV)

1. Employees may use a POV for alternative worksite travel when authorized by an approving official.

2. The approving official cannot prohibit employees from using a POV on official travel. However, if an employee elects to use a POV instead of the mode of transportation that the approving official authorizes, the approving official will:



1. Limit reimbursement to the constructive cost of the authorized method of transportation, which is the sum of the reasonable transportation expenses the employee would have incurred when traveling by the authorized method of transportation versus POV mileage.


3. In addition to the allowance for mileage, employees are reimbursed for the actual cost of parking fees, ferry fees, bridge tolls, road tolls and tunnel fees. An employee may not be reimbursed for car repairs, depreciation, grease, oil, antifreeze, towing fees and similar expenses, fuel, insurance, and state and federal taxes. Other non-reimbursable costs include parking violations, moving violations, locksmith charges and charges for flat tires.

4. If another employee travels as a passenger with the employee on the same trip in the same POV, the passenger cannot claim mileage. No deduction will be made from the mileage allowance if the passenger contributes to defraying the expenses.

5. Employees will not receive reimbursement for parking at the permanently assigned office when it is incurred in connection with direct travel between their residence and official assigned duty station.

6. In accordance with Executive Order 13513, issued October 1, 2009, IRS employees are prohibited from texting or text messaging while driving a rental car on official travel.

7. Employees must report accidents that occur on official business in a POV to their supervisor and the Employee Resource Center (ERC) immediately. See IRM 1.14.7.2.9, Accident Response and Reporting for additional information. Employees must also contact the IRS Claims Manager at: claims.manager@irscounsel.treas.gov.


**1.32.1.7.5.1** **(10-21-2021)**

##### Mileage Reimbursement

1. Employees who use their POV near their official station to conduct official business will be reimbursed on a mileage basis, not to exceed the applicable mileage rates specified in the FTR. Employees should compute mileage reimbursement by multiplying the distance traveled by the applicable mileage rate. The mileage rates are available on the [GSA](https://www.gsa.gov/travel/plan-book/transportation-airfare-rates-pov-rates-etc/privately-owned-vehicle-pov-mileage-reimbursement-rates) website. Select - Privately Owned Vehicle (POV), Mileage Reimbursement Rates. If traveling by POV, distance is determined by:



1. Actual miles driven from odometer readings

2. Road map.

3. An electronic highway mileage guide such as MapQuest or Google maps


2. Employees who frequently travel between their official assigned duty station and another work location by POV will be reimbursed the mileage rate for the distance between the two locations. They will also be reimbursed for any parking costs incurred at the alternate work location.

3. Employees who work at an alternate work site outside of the commuting area of their official assigned duty station because of a building closure will be reimbursed for mileage that exceeds their normal commuting costs. Normal commuting costs are expenses that an employee would incur while commuting from their residence to the closed official assigned duty station and returning to their residence.

4. If an employee reports to his/her official assigned duty station before visiting one or more locations on official business and then returns to their official assigned duty station before going home, the employee may be reimbursed for all mileage except the mileage in either direction between their residence and official assigned duty station.

5. Employees cannot be reimbursed any mileage incurred solely for personal reasons.


**1.32.1.7.5.2** **(03-22-2023)**

##### 50-mile Offset Rule

1. If an employee’s residence is 50 miles or more from their officially assigned duty station, they must apply the 50-mile offset rule when traveling in the direction or vicinity of their official assigned duty station to one or more alternate work locations. Reimbursement is not allowed for travel from the employee’s residence directly to the official assigned duty station or from the official assigned duty station directly to the employee’s residence.

2. When the employee’s first or last alternate work location is en route, in the general direction or vicinity of the official assigned duty station, the mileage entitlement must be reduced by the number of miles greater than 50 that the residence is from the official assigned duty station. Examples:



1. An employee lives 48 miles from the official assigned duty station, travels directly from the residence to an alternate work location, visits the official assigned duty station during the day and travels directly home from another alternate work location. No mileage offset is applicable as employee residence is less than 50 miles from official assigned duty station.

2. An employee lives 55 miles from the official assigned duty station travels directly from the residence to an alternate work location (30 miles from residence) which is en route or in the general vicinity of the official assigned duty station, visits official assigned duty station during the day and travels directly to the residence from another alternate work location (25 miles from residence). A mileage offset of 10 miles is applicable, five miles each way (55-50=5) for an allowable reimbursement of 45 miles (55-10=45) plus any applicable mileage incurred for travel from official assigned duty station to alternate work locations or alternate work location to official assigned duty station.

3. An employee lives 80 miles from the official assigned duty station travels directly from the residence to an alternate work location (which is en route or in the vicinity of the official assigned duty station) 62 miles from residence and returns to residence. The 50-mile offset must be applied. The offset is 60 miles, 30 miles each way (80-50=30). The employee traveled 124 miles round-trip from the residence to the alternate work location and return to residence. Mileage reimbursement would be 64 miles (124-60=64).


3. If travel is in the opposite direction, not in the general vicinity or direction, of the official assigned duty station, the employee is entitled to full mileage reimbursement. No offset applies.


**1.32.1.7.5.3** **(03-22-2023)**

##### Six Day Rule

1. Employees performing official local travel for an extended period to the same alternate work location will be reimbursed as follows:



1. The amount of the reimbursement depends how many consecutive days the employees reports to the alternate work location requiring official travel. If the number is five days or less, they will receive the full mileage rate reimbursed subject to the 50-mile offset rule, if applicable. (See IRM 1.32.1.7.5.2)

2. If the number of consecutive days (not including weekends or holidays) at the alternate work location requiring official travel exceeds five days, they will receive a reimbursement at a reduced mileage rate for the portion exceeding five days. The reimbursement will be the lesser of:


1. Mileage from their residence to the alternate work location;

2. Mileage from the official duty station to the alternate duty location; or

3. If employees choose to drive their POV when they could normally use public transportation, they will receive reimbursement for the first five consecutive workdays at the current mileage rate, limited to the total cost of public transportation (calculate the cost of public transportation from the residence to the alternate duty location versus the cost of POV mileage, whichever is less).


2. Consecutive days continue until there is a break in travel to the alternate work location of more than one week.

3. Approving officials may waive the limitation in IRM 1.32.1.7.5.3 (1)(b)(3) when, in their judgement, the circumstances of the extended alternate work location assignment warrant such action. Approving officials must include economic factors such as the financial impact of the budget and the cost of public transportation when considering waiving this limitation. When waiving the limitation, approving officials must note on the travel voucher “six-day rule waived” along with an appropriate explanation. This only waives the limitation in 1.32.1.7.5.3 (1)(b)(3) above, it does not limit the reimbursement requirement of IRM 1.32.1.7.5.3(1)(b)(1) and (2).


**1.32.1.7.6** **(03-22-2023)**

#### Parking Fees and Rented Parking Space

1. If employees rent a parking space on a regular basis at their official assigned duty station and use the parking space to conduct official business travel away from their official assigned duty station at a weekly or monthly rate, reimbursement will be made on a pro rata basis on the actual number of days the parking space is used for official business travel as illustrated by the following examples:



1. Employee rents a weekly parking space for parking a POV Monday through Friday, at or near the official assigned duty station. One-fifth (1/5) of the weekly rate will be allowed for each day that the employee uses a POV for official business travel.

2. Employee rents a monthly parking space at or near the office with the space available to the employee as provided by the rental agreement for 21 days of the month. The employee uses the space for parking on official business travel seven days during the month. The employee will be reimbursed for one-third (seven divided by 21 days) of the monthly cost. An employee who rents a monthly a parking space and who receives a certificate from the parking facility that the space is available only Monday through Friday shall be entitled to compute pro rata reimbursement based on the number of workdays in the month.


Employees can be reimbursed for other parking fees incurred for local travel on the same day.


2. Employees will not receive reimbursement for parking at their official station when the parking expense is incurred in connection with their normal commute.

3. Employees must provide a receipt for any parking expenses in excess of $25.


**1.32.1.7.7** **(07-10-2019)**

#### Limousine and Executive Car Service

1. The IRS will not reimburse an employee for using limousine and/or executive car services. An executive car or limousine service generally involves the use of a luxury vehicle with a chauffeur who picks up and drops off a traveler. This restriction does not include paid shuttle services or vans.

2. An employee can generally recognize these types of services because they are used in the company name or advertisement. This restriction also applies to premium services offered through Uber Black, Lyft Premier and other luxury sedan services.


**1.32.1.8** **(10-21-2021)**

### Per Diem Expenses for Local Travel

1. Generally employees are not eligible for per diem for local travel as employees are only eligible for per diem when they:



1. Perform official travel away from their official station;

2. Incur per diem expenses while performing official travel; and

3. Are in a travel status for more than 12 hours.


2. The required commute for payment of per diem is that the alternative worksite location must be more than 50 miles from **both** the employee’s official duty station **and** residence, measured by odometer or other readings on the most commonly used route. Any point beyond both these distances is outside the commuting area. This 50-mile rule does not necessarily mean, however, that they are "away from home" for tax purposes, and the per diem will be taxable income. See IRM 1.32.1.11, Taxable Travel Reimbursement.

3. The following circumstances may justify an exception to IRM 1.32.1.8 (1) & (2) when alternative worksite travel performed is less than 50 miles but at least 30 miles from **both** the official duty station **and** residence:



1. Severe conditions (for example, weather or excess travel delays) exist that may endanger the health and safety of an employee.

2. The employee is attending training or a conference.


4. Approval to receive per diem in the local commuting area is required and must be submitted to the Travel Management Director, for approval at: CFO.FM.Travel.Policy.Review@irs.gov, on Form 15299, Travel Approval Request. The approved request only provides authorization to claim the per diem and does not remove the tax liability for the traveler.

5. Employees must be in travel status for more than 12 hours to be eligible for per diem. If they travel for more than 12 hours, but less than 24 hours, they may receive 3/4 per diem for that day. This 12-hour rule does not necessarily mean that they are away from home for tax purposes and the per diem for that day will be taxable income. See IRM 1.32.1.11, Taxable Travel Reimbursement.


**1.32.1.9** **(10-21-2021)**

### Miscellaneous Expenses

1. The IRS may reimburse employees for emergency and non-emergency personal telephone calls while away from the usual place of work, whether or not the calls are within the local area, if approved by the approving official. Employees must furnish a statement of telephone charges, including date, place called, and amount, for all long distance calls for which they request reimbursement. Employees are required to provide receipts, regardless of amount.

2. The following miscellaneous and emergency expenses may be claimed when employee provides a detailed explanation and a receipt is required regardless of the dollar amount:



1. Cash conversation expenses.

2. Digital Subscriber Line (DSL) internet access/Wi-Fi (if required for official work access) should be claimed under correct expense type. GOVCC should be used and receipt is required regardless of dollar amount.

3. Travelers check fees

4. Telephone/Telegraph expenses (if directly related to training travel or an emergency)

5. Personal protective equipment (PPE), not to exceed $20 and/or COVID-19 testing when required for official travel during a period of restricted travel due to a pandemic or other national health crisis. Employees may only claim if PPE is not provided by POD, does not already have readily available and if testing is not covered by health insurance. PPE is limited to a plain cloth face covering (non-medical grade), hand sanitizer and, if available, disinfecting wipes.

6. Other expenses approved by CFO with instructions to claim as an emergency expense.


**NOTE:** Postage, shipping, ink and other supply items may**not** be claimed as an emergency expense on a travel voucher. (See IRM 1.35.3, Receipt and Acceptance Guidelines)



**1.32.1.10** **(07-10-2019)**

### Public Transportation Subsidy Program (PTSP)

1. The purpose of the public transportation subsidy benefit is not to pay for local travel. The PTSP benefit supports employees using public transportation for their commute to and from their residence and the workplace. Employees can use an unlimited transit pass, which is a ticket that allows an IRS employee to take unlimited trips within a fixed period of time. Employees cannot use their unlimited PTSP transit subsidy benefit and file a local voucher. Employees can find more information about PTSP on the IRS Source, Employee Resources, Benefits website.

2. If the employee's building has closed and the employee receives PTSP, they should use the subsidy to cover their transportation costs to the alternate work site. Employees should increase their PTSP to cover any additional costs of commuting to the alternate work location.


**1.32.1.11** **(03-22-2023)**

### Taxable Travel Reimbursement

1. Taxable travel reimbursements for local travel include:



1. Daily travel between employee’s residence and a non-temporary work location (other than the officially assigned duty station).

2. Subsistence for less than 24 hours without a night’s lodging.

3. Overdue travel advances (See IRM 1.32.1.1.3.2, Employees).

4. Per diem expenses (lodging and/or M&IE) incurred within the commuting area.



      ### Note:



      A Form W-2 will be issued for all taxable travel reimbursements.


2. Reimbursement for travel between a residence and an official station for lodging, and meals provided to an employee for temporary travel within a commuting area is normally taxable travel reimbursement because the travel is not overnight and not away from home. Reimbursement for travel between a residence and a temporary work location generally is not taxable, unless the travel is long-term taxable travel, as described in IRM 1.32.1.12, Local Long-Term Taxable Travel. Reimbursement for travel between two work locations is not taxable .

3. Reimbursements for travel between an employee's residence and a non-temporary work location are taxable, even if the residence is the employee's telework location. The tax rules provide that transportation expense reimbursements for trips, between an office in the home and a non-temporary work location are taxable if the home office does not meet the requirements of Section 280A(c)(1)(A) of the Internal Revenue Code (IRC). The "office in the home" must be used regularly and exclusively as the employee's principal place of business for the employer's convenience. The IRS, as the employer, has determined that each employee's post of duty (POD) is the assigned IRS office of the employee and that a telework location is for the convenience of the employee rather than for the employer; therefore, the requirements of Section 280A(c)(1)(A) are not met. Reimbursements for travel between a non-temporary work location and a telework location in an employee's residence will be taxable.

4. If an employee always leaves from his/her official station to go to the non-temporary work location and returns to his/her official station before returning to his/her residence, the reimbursement is not taxable. The travel reimbursement is only taxable if the employee travels to/from his/her residence to the work site. See IRM 1.32.1.12, Local Long-Term Taxable Travel.


**1.32.1.12** **(03-22-2023)**

### Local Long-Term Taxable Travel

01. The work location is the building or street address where the employee will be performing his/her official duties. Travel to the same work location is considered travel to one location, even if the purpose of the travel changes or the type of work performed changes.

02. The authority that requires IRS to tax local long-term travel (LTTT) is Revenue Ruling 99-7.

03. The rules for long-term travel within the commuting area are:



    1. One-Year Rule: If local travel between a residence and a regular work location (other than the employee’s permanent work location) is realistically expected to last for more than one year, it will be considered long-term local travel, not temporary. The realistic expectation is based on the information known to the employee and manager. The travel becomes taxable at the point it expected to exceed one-year. To determine an employee's length of travel expectation (one-year rule), the first date of travel to a particular work location is the beginning date or "start the clock" (i.e., the determination would be whether travel is expected to end within one year from that date). Physical presence at the work location is the determinative factor and not the date assigned to a project or the first time charged to a project.

    2. 35-Workday Rule Exception to the One-Year Rule: For purposes of travel within the commuting area, if the travel is realistically expected to last for more than one year, or if there is no realistic expectation that the travel will last for one year or less, the travel is not long-term if the employee expects to travel to the location on 35 or fewer days in the calendar year. For purposes of this exception, the employee must take into account all travel to the location, even if the travel is for a different purpose and even if the travel is for less than a full day. Daily transportation costs, such as workdays (or partial workdays), are counted in applying the 35 workdays and seven months break in service. The 35 workdays may be continuous or may be spread throughout the entire calendar year.

    3. Seven-Month Rule Exception to the One-Year Rule: In determining whether travel within the commuting area is long-term, an employee may disregard prior travel to a location if the employee has not traveled to that location for a period of seven or more continuous months. For purposes of this exception, the employee must take into account all travel to the location, even if the travel is for a different purpose.


04. Employees who are in LTTT status are subject to social security taxes (where applicable) and medicare taxes under the Federal Insurance Contribution Act (FICA), as well as federal, state and local income tax liabilities, related to their LTTT reimbursements. The appropriate amounts for their additional tax liabilities will be withheld from their travel reimbursements. Because the Travel and Transportation Reform Act of 1998 authorizes federal agencies to reimburse employees for federal, state and local income taxes incurred as a result of LTTT, the employees will be reimbursed substantially for all additional income taxes.

05. The IRS payment system has been configured in accordance with state withholding regulations based upon information received from all states. If the employee’s state does not have a withholding requirement and the long-term taxable travel voucher reflects a state withholding, the employee should complete a ticket via ERC immediately to have the travel voucher corrected for the withholding.

06. Taxes under FICA are computed as a percentage of wages for employment. FICA taxes consist of social security taxes (where applicable) and medicare taxes (including additional medicare tax).

07. The federal income tax is withheld and will be placed back into the employee’s voucher, potentially reducing the refund the employee normally receives. At the time each voucher is paid, the withholding tax allowance (WTA) will be calculated and paid to the employee to replace only the federal tax withholdings on the reimbursement. The WTA reimburses the employee for the federal tax withholdings on the taxable travel reimbursements.

08. Federal employees who have performed continuous federal service since December 31,1983, and who are covered under the Civil Service Retirement System (CSRS), are generally exempt from the social security portion of FICA taxes. However, such employees are subject to the medicare portion of FICA taxes. Federal employees who were hired since December 31,1983, or who have not performed continuous federal service since December 31,1983, are covered under the Federal Employees Retirement System (FERS), and are subject to both the social security and Medicare portions of FICA taxes. Applicable FICA taxes are withheld with respect to LTTT reimbursements because LTTT is a nondeductible employee expense and the payments generally constitute wages subject to FICA taxes.

09. The social security FICA taxes apply only to wages that do not exceed a maximum wage base that is adjusted annually. If social security taxes are withheld from an employee's wages that exceed the maximum wage base for a year, the employee has two options:



    1. Claim the excess FICA withholding electronically when filing their income tax return (most recommended option); or

    2. claim the excess FICA withholding manually through Travel Operations using the FICA memorandum request, OV Form. To request the OV Form or for FICA coordinator assistance, email cfobfctac@irs.gov.


10. Payments are not made to Thrift Savings Plan (TSP) even though LTTT is considered additional wages. The Office of Personnel Management's pay and leave administration function states that 5 CFR 531.202 is the regulatory source for the definition of basic pay. Taxable travel related payments are not considered basic pay for calculating of TSP.

11. If an employee incurs LTTT for monthly parking expenses at a work location, the parking expenses may be considered non-taxable under the qualified parking exclusion. Additional information on qualified parking exclusion is available in Publication 15- B, _Employer’s Tax Guide to Fringe Benefits_.


**1.32.1.13** **(07-10-2019)**

### Filing Authorization for Long-Term Taxable Travel Form

1. Managers who know, or can reasonably expect, that their employees will receive LTTT assignments, must ensure that it is authorized on Form 12654, Authorization for Long-Term Taxable Travel. Managers must issue a Form 12654 each calendar year to each affected employee when it is determined that the employee will receive LTTT assignments. Both the authorizing official and the employee must sign the form. Employees in LTTT situations must attach a copy of Form 12654, Authorization for Long-Term Taxable Travel, to each LTTT voucher. Employees on LTTT must complete their vouchers using ETS and should submit them promptly at the end of each month or every 30 days if on a continuous travel assignment.

2. A Form 12654, Authorization for Long-Term Taxable Travel, must be completed for each work location.

3. Employees on LTTT must use Purpose Code "L" for LTTT expenses associated with temporary duty travel and Purpose Code "W" for LTTT expenses associated with training travel.

4. If an employee is on LTTT but does not have a LTTT travel authorization or proper withholding on their vouchers, the manager and employee should complete and sign the travel authorization as soon as possible to correct potential misclassification of vouchers. All vouchers with expenses that should have been charged under purpose code "L" or "W" for long-term taxable travel expenses will require manual correction by Travel Operations. If employee do not classify their vouchers properly, they should submit a statement to Travel Operations and give an accounting of the long-term taxable travel transaction. They will complete the process by adding the withholding tax allowance, deducting the appropriate tax withholdings, paying the taxing authorities, and disbursing the net payment to the employee or establishing billing documents, if appropriate. If an employee does not classify their long-term taxable travel accurately, it violates established tax reporting requirements.

5. A copy of Form 12654, Authorization for Long-Term Taxable Travel, must be retained along with other required supporting documentation for long-term travel vouchers. The Form 12654, Authorization for Long-Term Taxable Travel, should be faxed or scanned into ETS each time a voucher is filed. Also, if the employee submits a manual voucher using Form 15342, the Form 12654, should be submitted to Travel Operations each time a manual voucher is filed.


**1.32.1.14** **(03-22-2023)**

### Extended Temporary Duty Travel Tax Reimbursement Allowance

1. The Extended TDY Tax Reimbursement Allowance (ETTRA) reimburses employees for their federal, state and local income tax liability incurred as the result of being reimbursed for tax expenses while on LTTT. The ETTRA does not reimburse employees for Medicare or FlCA taxes.

2. The ETTRA is paid in two parts:



1. A Withholding Tax Allowance (WTA) that is calculated and paid when the initial voucher is paid.

2. A final ETTRA paid after the end of the calendar year during which the employee was reimbursed for LTTT expenses.


3. The IRS will pay an ETTRA to employees incurring additional income tax liability resulting from long-term travel reimbursements. A final ETTRA payment is made to the employee in the year following when the travel reimbursements are made. The final ETTRA will adjust for any federal tax liability not considered when the WTA was paid in the previous year and the final ETTRA will also reimburse the employee for the state and local income tax liability incurred on the long-term taxable travel expense reimbursements.

4. Employees are required to file an ETTRA claim if they received taxable reimbursements associated with long-term taxable travel during the previous year and received a WTA. Employees will receive a notice from BFC, Travel Operations, when it is time to file their ETTRA claim. If they fail to file, it will be assumed that the ETTRA amount is zero. Consequently, employees would have to repay the amount of the WTA previously paid to them for the related reimbursements. Employees may request an extension of the filing date; however, for BFC, Travel Operations, to consider the request, employees must show just cause, such as approval of an extension to file their current year federal tax return.


**1.32.1.15** **(07-10-2019)**

### Arranging for Travel Services, Fees, Paying Travel Expenses and Claiming Reimbursements

1. This section provides IRS guidance and instructions for:



1. Arranging for transportation

2. Paying fees

3. Paying travel expenses using the government travel card

4. Claiming reimbursements


**1.32.1.15.1** **(07-10-2019)**

#### Arranging for Transportation

1. A rental car is considered advantageous to the government, when employees do not have a POV, where public or courtesy transportation is not available or when a government vehicle is not available for performing official business. Employees may use a government contract rental car when authorized.

2. Employees seeking a rental car must use ETS or the TMC to book it.


**1.32.1.15.2** **(07-10-2019)**

#### Fees

1. The ETS charges two fees, a CGE reservation fee and a CGE voucher fee, when booking official travel reservations. The CGE reservation fee includes fees for reservations made within ETS or directly with the TMC.

2. The CGE reservation fee automatically populates on an ETS travel authorization when employees complete their ETS authorization.

3. The ETS will automatically remove the CGE reservation fee when all reservations are removed from an adjusted or amended authorization that has not been stamped ticketed. If the ticket has been issued and the trip has been cancelled, the employee will need to file a voucher for the CGE fee.

4. The online CGE reservation fee will change to an agent-assist CGE transaction fee when agent intervention or assistance is needed, for example, when a credit card declines, authorizations are not approved timely or an employee, responds "Yes" to an email regarding unapproved authorization.

5. The CGE voucher fee is charged when using ETS to process a voucher. This fee is paid directly to ETS. The fee auto-populates in the authorization and is charged when the voucher is approved. The fee amount varies based on the type of travel, either local or city-to-city, and cannot be edited.

6. The CGE voucher fee appears automatically on each travel voucher and is paid by the IRS after each travel voucher is processed. Employees should not claim CGE fees as reimbursable expenses on their travel vouchers.


**1.32.1.15.3** **(10-21-2021)**

#### Paying Travel Expenses Using the Government Travel Card

01. Employees should use the government travel card for authorized expenses to the maximum extent possible. Employees must use the government travel card to pay for transportation, lodging and rental cars including rental car fuel/oil.

02. Employees may also use the travel card to purchase fuel one day before travel and one day after travel when using their POV.

03. There are two types of travel cards. For additional information on the government travel card, see IRM 1.32.4, Government Travel Card Program.



    1. **Standard government travel card**\- includes a maximum monthly card limit of $5,000, a merchant category code template for official travel expenses and ATM access.

    2. **Restricted government travel card**\- includes the same benefits as the standard travel card; however, ATM access is not granted.


04. New employees are exempt from the requirement to pay travel expenses using a government travel card until they obtain one. New employees who are expected to travel must apply for a travel card within 60 days after they report for duty.

05. Employees can withdraw cash from an ATM beginning three days before the official travel date of departure through the last day of official travel, to cover anticipated out-of-pocket incidental travel expenses, such as ground transportation, rental car fuel/oil, tolls, parking and other expenses that generally cannot be purchased with the government travel card.

06. Employees should use the government travel card to pay for the following expenses:



    1. Rental car, including rental car fuel/oil (government travel card MUST be used)

    2. Emergency purchases, receipt required regardless of dollar amount

    3. Meals

    4. Parking

    5. Taxi and shuttle services


07. Employees may not use the government travel card for any personal expenses or these unauthorized uses:



    01. Alcohol and alcoholic beverages

    02. Restaurants at the official station

    03. Office supplies (ink cartridges, paper, toners)

    04. Gifts or souvenirs

    05. Personal items and services

    06. Long distance calls (except for calls billed to the hotel room)

    07. Gambling

    08. Fuel for a government-owned car (use the fleet purchase card)

    09. Conference fees

    10. Expenses associated with obtaining meeting space

    11. Postage


08. The IRS exempts the following groups of travelers from the mandatory use of the government travel card:



    1. Employees who have a pending application for the government travel card.

    2. Employees for whom the issuance of a government travel card would adversely affect the mission of the IRS or put the employee at risk.

    3. Employees who are not eligible to receive a government travel card.

    4. Invitational travelers.

    5. Employees with suspended or cancelled government travel cards.


09. Employees seeking an exemption from using the government travel card must prepare a memorandum requesting an exemption and submit it by email for approval to the appropriate office:



    1. The Director, Credit Card Services, has authority to grant exemptions for financial hardship and religious reasons.

    2. The Manager, International Meetings, Travel and Visitors’ Programs, in LB&I has authority to grant exemptions for overseas travel on a case-by-case basis.

    3. The Director, Travel Management, has the authority for all other reasons.


10. Management may take disciplinary action when a government travel card has been used inappropriately. Disciplinary actions range from oral and written reprimands, to suspension without pay, or removal. Managers should contact Labor/Employee Relations and Negotiations for advice and assistance regarding disciplinary action.


**1.32.1.15.4** **(03-22-2023)**

#### Claiming Reimbursement

01. Employees must submit a voucher within five workdays after completing travel or every 30 days for continuous local travel. If you are an infrequent local traveler with minimal expenses that do not require immediate reimbursement, you may file a voucher on a quarterly basis.

02. Employees must sign their voucher within five days of the trip end date. If they don’t sign the voucher within 30 days of the trip end date, ETS will de-obligate the money used to fund the trip and the authorization will be canceled. The system will send email notifications to the employee 5, 25 and 30 days before de-obligating the authorization. Once it’s canceled, employees cannot modify the authorization and if they have expenses associated with the canceled authorization they are required to complete a new authorization.

03. If employees travel on behalf of the IRS, they must account for their expenses in the travel voucher process. They must submit their travel voucher electronically using ETS, or manually, if the travel authorization was manually submitted.

04. The approving official should approve or return the voucher for correction within seven calendar days to ensure payment within 30 calendar days after submission by the employee.

05. If employees file through ETS, the reimbursement will occur through a split disbursement process. If they file a manual Form 15342, Travel Voucher, they will receive reimbursement for all claimed expenses by EFT; and the employee is responsible for paying the travel credit card company for expenses paid for with the travel credit card.

06. Employees are required to use split disbursement. Split disbursement is the ETS default payment method. All travelers have the option to change the method and amount of payment (i.e., meals and incidental expenses not charged on the travel card). However, if the method or amount of payment is changed, employees will be required to explain during the ETS pre-audit process why the default split disbursement payment method was not used.

07. Split disbursement permits direct payment to the government travel card via EFT and the employee. Payment for charges incurred on the travel card are disbursed to the bank and any residual amount to the employee for expenses not charged to the government travel card. All rental cars and non-mileage expenses charged on the government travel card will be credited to the government travel card account after the approved voucher is processed and the payment will go directly to the government travel card issuer. Employees will receive a bill reflecting the charges and the payments processed from ETS. The government travel card issuer will bill the employee for the balance of any unpaid amounts.

08. If employees have travel expenses that should be charged to a different line of accounting (LOA), the office directing the travel is responsible for providing instructions to the traveler containing the correct LOA to use when filing travel vouchers.

09. An employee’s government travel card statements cannot be scanned or faxed as supporting documentation nor as a receipt for rental car expenses. The government travel card statement does not itemize the detailed travel expenses for reimbursement.

10. Employees must provide receipts and supporting documentation when they file their travel voucher for:



    1. Approval for actual expenses

    2. Bus fare (en route to and from the alternative worksite location)

    3. Rail fare (en route to and from the alternative worksite location)

    4. Rental car expenses including fuel/oil regardless of dollar amount

    5. Telephone calls

    6. Digital Subscriber Line (DSL) internet access/Wi-Fi (if required for official work access)

    7. Parking receipts in excess of $25

    8. Individual expenses over $75

    9. Reporting instructions for training classes


11. Employees should do the following with their travel receipts:



    1. When using ETS, employees must scan or fax all receipts required for expenses detailed in IRM 1.32.1.15.4 (10), Claiming Reimbursements, into ETS and all applicable supporting documentation. The approving official must review the receipts in ETS before approving and signing the travel voucher. The ETS retains copies of the receipts for six years, in compliance with General Records Schedule (GRS) 1.1, item 010 Financial Transaction Records Related to Procuring Goods and Services, Paying Bills, Collecting Debts, and Accounting, so they are available for subsequent audits. Employees may want to keep their original receipts for their records for six years.

    2. When filing a manual voucher, employees must attach original receipts and all applicable supporting documents to their manual travel voucher for the approving official to review before signing the voucher. The approving official must retain the attached receipts for six years in compliance with GRS 1.1, item 010 Financial Transaction Records Related to Procuring Goods and Services, Paying Bills, Collecting Debts, and Accounting.


12. When filing a manual travel voucher, employees must provide receipts or explain in writing why they are unable to provide the necessary receipts. The explanation must be acceptable to the approving official. The approving official will return any voucher submitted without a justification statement. Inconvenience is not an acceptable explanation for failure to provide receipts.

13. Employees may claim reimbursement for non-travel costs for the following expenses on their travel voucher when other travel related expenses are being claimed, when not directly related to the performance of travel, but incurred during travel:



    1. Lien fees

    2. Investigative expenses (for additional information see IRM 9.11.1.3, Incidental Investigative Expenditures)

    3. Administrative summons expenses

    4. Right to Financial Privacy Act fees


Investigative expenses regardless of dollar amount should be redacted. If unable to redact, an explanation should be provided. Claims over $300 for a single day must be submitted on a SF1034, Public Voucher for Purchases and Services Other Than Personal. Additional information on Employee Reimbursables is available in IRM 1.35.3.5.2.9.



14. Other non-travel expenses incurred during official travel such as office supplies must be claimed on Form 1034, Public Voucher for Purchases and Services Other Than Personal, and submitted to Travel Operations for processing with the receipt(s).

15. Employees cannot submit claims for confidential expenses on travel vouchers.

16. Training and conference fees must be paid through the procurement process. Employees cannot claim a training or conference fee on a travel voucher. Employees should contact their business unit finance organization for more information.

17. Employees must electronically sign the voucher in ETS and if filing a manual voucher, they must prepare their claim on Form 15342, Travel Voucher, and sign the voucher in ink. Any changes to a manual travel voucher must be initialed.

18. The approving official must authorize and approve travel vouchers per Delegation Order 1-30, Authorization and Approval of Official Travel within the United States.

19. The traveler and approving official are responsible for the validity of the voucher and must ensure all travel expenses are prudent, accurate and necessary.

20. The approving officials must do the following if they disallow an expense claim on a travel voucher:



    1. Provide the reason for the disallowance in ETS and return the document to the traveler.

    2. Issue a Notice of Disallowance and authorize payment of the amount of the travel claim that is not in dispute.


21. Employees who challenge a disallowed claim must submit a request for reconsideration of the disallowed amount by sending the voucher back to the approving official with a full explanation of the circumstances and the reasons for reconsidering the amount of reimbursement. If the approving official denies the request for reconsideration, employees may submit a request for reconsideration of the disallowance to the Travel Management mailbox \*CFO-FM-Travel Policy & Review @irs.gov and must include:



    1. A full explanation of the circumstances and the reasons the requested reimbursement was disallowed.

    2. A full itemization for all disallowed items reclaimed.

    3. Receipts for the disallowed items that require receipt.

    4. A copy of the Notice of Disallowance.

    5. The proper authority for the claim if challenging the IRS application of the law or statute.


22. If an employee request for reconsideration to a disallowed claim is approved by the CFO, Financial Management, Travel Management office, and if the employee submitted a voucher using ETS, they must process a supplemental voucher in ETS using the Amend link. If a manual voucher was submitted, employees need to:



    1. Prepare a new Form 15342, Travel Voucher, to claim the amount disallowed on the original voucher.

    2. Write Supplemental Voucher at the top of the new voucher.

    3. Sign and date the supplemental voucher.

    4. Attach a copy of the approval notice.

    5. Have the approving official sign and date the voucher.

    6. Attached any required receipt (s)

    7. Mail the supplemental voucher to:


        Internal Revenue Service


        ATTN: Travel Operations


        P.O. Box 9002


        Beckley, WV 25802

    8. Email to \*CFO Travel Vouchers, or efax to 855-787-4375.


23. If an employee’s challenge of a disallowed claim request for reconsideration is denied by the Travel Management, the employee may submit the request reconsideration as follows:



    1. Bargaining unit employees should contact their Union representative.

    2. Non-bargaining unit employees whose claims are denied, may file a claim with the GSA Civilian Board of Contract Appeals (CBCA). (The burden is on the claimant to establish the timeliness of the claim and the liability of the claim based on the information submitted by the claimant and the IRS).


24. Employees will receive their reimbursement three to five workdays after the travel voucher is approved in ETS.

25. If a travel expense is omitted from a travel voucher inadvertently, employees may file a supplemental voucher to claim the expense. Employees must have receipts for amounts claimed over $75 on a supplemental voucher, just as required for an original voucher.

26. Employees who need to correct errors on an already paid voucher should do the following:



    1. Omitted expense - file a supplemental voucher to add the omitted expense and sign the voucher. The voucher will be processed, and the added expense will be reimbursed.

    2. Overpayments on the voucher - complete the Debt Collection Repayment Memo, make a check or money order payable to the IRS and submit the overpaid amount to at the following address:


        Internal Revenue Service


        ATTN: Debt Collection Unit


        P.O. Box 9002


        Beckley, WV 25802-9002


27. Employees must provide the following information on their travel voucher:



    1. Dates of arrival to and departure from the local travel location.

    2. Expenses for local transportation fares, mileage and parking meter fees. These amounts may be aggregated; however, any individual expenses over $75 must be listed separately.

    3. Accounting for personal time taken during the local travel.

    4. Accounting label information.


28. The approving official should approve or return the voucher for correction within seven calendar days to ensure payment within 30 calendar days after submission by the employee.


**1.32.1.16** **(07-10-2019)**

### Death of Employee While in Travel Status

1. This section provides the guidance and instructions supplementing FTR Chapter 303, Part 303-70, [Agency Requirements for Payment of Expenses Connected with the Death of Certain Employees](http://www.gsa.gov/portal/ext/public/site/FTR/file/FTR303TOC.html/category/21870/hostUri/portal)

2. Upon the death of the employee, the approving official needs to identify the travel expenses and prepare a manual authorization and travel voucher to claim the travel expenses on behalf of the employee. The approving official annotates "Employee Deceased" on the employee signature line, signs the voucher and forwards for payment to at the following address:




    Internal Revenue Service


    ATTN: Travel Management Section


    P.O. Box 9002


    Beckley, WV 25802-9002


    Efax 855-787-4375, email \*CFO Travel Vouchers






    Receipts must be obtained, where applicable and appropriate and the travel agency contacted for a refund if a round trip flight was involved.


**1.32.1.17** **(10-21-2021)**

### Travel Forms

1. Form 15342, Travel Voucher

2. Form 13635, Manual Travel Authorization

3. Form 8445, Income Tax Allowance Certification

4. Form 12654, Authorization for Long-Term Taxable Travel


**1.32.1.18** **(10-21-2021)**

### Delegation Orders (DO)

1. This section provides delegation orders for travel:




| **Number** | **Title** |
| :-: | :-: |
| 1-5 | Reimbursement for Actual Expenses |
| 1-7 | To Authorize Attendance at Meetings at Government Expense |
| 1-8 | Approval of Foreign Travel |
| 1-10 | Invitational Travel |
| 1-30 | Authorization and Approval of Official Travel within the United States |
| 1-31 | Authorization and Approval of Tour Renewal Agreement Travel |
| 1-34 | Payment of Travel Expenses for Threatened Law Enforcement and Investigative Employees |
| 1-35 | Authority to Approve the Use of Non-Contract Air Carriers |
| 1-40 | Approval of Personal Funds Used to Purchase Common Carrier Transportation Over $100 |
| 1-48 | Approval of Business-Class Travel |
| 1-49 | Exemption to Travel Card Mandatory Use Policy |


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-032-001#addtoany "Show all")

A2A