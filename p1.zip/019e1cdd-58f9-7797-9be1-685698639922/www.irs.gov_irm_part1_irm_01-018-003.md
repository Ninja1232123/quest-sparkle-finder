---
url: "https://www.irs.gov/irm/part1/irm_01-018-003"
title: "1.18.3 Tax Forms Distribution Programs | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-018-003#main-content)

- 1.18.3  [Tax Forms Distribution Programs](https://www.irs.gov/irm/part1/irm_01-018-003#idm140050097132192)
  - 1.18.3.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-018-003#idm140050126392240)
    - 1.18.3.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-018-003#idm140050126123584)
    - 1.18.3.1.2  [Acronyms](https://www.irs.gov/irm/part1/irm_01-018-003#idm140050126164352)
    - 1.18.3.1.3  [Related Resources](https://www.irs.gov/irm/part1/irm_01-018-003#idm140050098706048)
  - 1.18.3.2  [Employer Program](https://www.irs.gov/irm/part1/irm_01-018-003#idm140050126137680)
  - 1.18.3.3  [Taxpayer Assistance Center (TAC)](https://www.irs.gov/irm/part1/irm_01-018-003#idm140050126134416)
  - 1.18.3.4  [Tax Forms Outlets Program (TFOP)](https://www.irs.gov/irm/part1/irm_01-018-003#idm140050126128848)
  - 1.18.3.5  [Volunteer Income Tax Assistance/Tax Counselling for the Elderly (VITA/TCE) Program](https://www.irs.gov/irm/part1/irm_01-018-003#idm140050126381312)
  - 1.18.3.6  [Other Programs and Responsibilities](https://www.irs.gov/irm/part1/irm_01-018-003#idm140050126374112)
    - 1.18.3.6.1  [External Addresses](https://www.irs.gov/irm/part1/irm_01-018-003#idm140050126323504)
    - 1.18.3.6.2  [Enterprise Logistics Information Technology (ELITE) Contractor Planning Application](https://www.irs.gov/irm/part1/irm_01-018-003#idm140050126320544)
    - 1.18.3.6.3  [Internet Ordering Initiative](https://www.irs.gov/irm/part1/irm_01-018-003#idm140050126316448)
    - 1.18.3.6.4  [Non-Program Order Forms](https://www.irs.gov/irm/part1/irm_01-018-003#idm140050126312496)
    - 1.18.3.6.5  [Prior Year Tax Forms Program](https://www.irs.gov/irm/part1/irm_01-018-003#idm140050126308816)
    - 1.18.3.6.6  [Telephone Orders](https://www.irs.gov/irm/part1/irm_01-018-003#idm140050126304544)

# Part 1. Organization, Finance, and Management

# Chapter 18. Distribution

# Section 3. Tax Forms Distribution Programs

* * *

## 1.18.3 Tax Forms Distribution Programs

#### Manual Transmittal

October 18, 2024

#### Purpose

(1) This manual transmits revised IRM 1.18.3, Distribution, Tax Forms Distribution Programs.

#### Material Changes

(1) IRM 1.18.3, revised throughout to update organizational title Wage and Investment to Taxpayer Services.

#### Effect on Other Documents

This supersedes IRM 1.18.3 dated October 25, 2022.

#### Audience

All IRS Employees

#### Effective Date

(10-18-2024)

Maria Cheeks

Director, Distribution

Taxpayer Services

**1.18.3.1** **(01-05-2018)**

### Program Scope and Objectives

1. Purpose: To provide planning and distribution systems for all IRS print and electronic communications products used by the public and used internally within the IRS.

2. Audience: The public (taxpayers), through designated distribution program partners, and all IRS employees.

3. Policy Owner: Director, Distribution, Media and Publications, Customer Assistance, Relationships and Education (CARE), Taxpayer Services (TS).

4. Program Owner: IRS Media and Publications, Distribution.


**1.18.3.1.1** **(10-25-2022)**

#### Background

1. Tax Forms Distribution Programs (TFDP) include distribution outlets for tax forms and products taxpayers use. These outlets are internal and external to the IRS. The TFDP section (TFDPS) partners with the National Distribution Center (NDC) to provide planning and distribution systems for these outlets.

2. Programs include but are not limited to:



   - Employer Program

   - Taxpayer Assistance Center (TAC) Program

   - Small Business Tax Products Distribution (SBTPD) Program

   - Tax Forms Outlets Program (TFOP)

   - Voluntary Income Tax Assistance/Tax Counseling for the Elderly (VITA/TCE) Program

   - Other Programs and Responsibilities


3. The TFDPS also manages the communications related to product status and ordering options.


**1.18.3.1.2** **(10-25-2022)**

#### Acronyms

1. We use the following acronyms throughout this IRM section:




| **Acronym** | **Definition** |
| --- | --- |
| BOH | Balance on Hand |
| CAPS | Computer Assisted Publishing System |
| CARE | Customer Assistance Relationships and Education |
| CAS | Customer Account Services |
| CBOP | Community Based Outlet Program |
| CQRS | Centralized Quality Review Section |
| ELITE | Enterprise Logistics Information Technology |
| M&P | Media and Publications |
| NDC | National Distribution Center |
| NTI | National Telecommuting Institute |
| OPN | Order Point Number |
| OSMS | Order and Subscription Management System |
| SCORE | Service Core of Retired Executives |
| SPEC | Stakeholder Partnerships, Education & Communication |
| SRTC | Stakeholder Relationship Tax Consultants |
| TAC | Taxpayer Assistance Center |
| TS | Taxpayer Services |
| TCE | Tax Counselling for the Elderly |
| TFDP | Tax Forms Distribution Program |
| TFOP | Tax Forms Outlet Program |
| TPOF | Taxpayer Order Form |
| USDA | United States Department of Agriculture |
| VITA | Voluntary Income Tax Assistance |


**1.18.3.1.3** **(01-05-2018)**

#### Related Resources

1. Available resources include:



   - Accessible Forms and Publications, [https://www.irs.gov/forms-pubs/accessible-irs-tax-products](https://www.irs.gov/forms-pubs/accessible-irs-tax-products)

   - Order and Subscription Management System, http://caps-as.enterprise.irs.gov/osms/views/homePage.xhtml

   - IRS.gov, [http://www.irs.gov](http://www.irs.gov/)

   - Forms, Instructions, and Publications, [https://www.irs.gov/forms-instructions](https://www.irs.gov/forms-instructions)


**1.18.3.2** **(01-05-2018)**

### Employer Program

1. The Employer Program helps distribute employer-related products and information returns to the public in support of the IRS Mission.

2. Businesses and employers can order products offered in this Program year-round through the Online Ordering for Information Returns and Employer Returns page at [https://www.irs.gov/businesses/online-ordering-for-information-returns-and-employer-returns](https://www.irs.gov/businesses/online-ordering-for-information-returns-and-employer-returns) or by calling the forms toll-free number, 800-829-3676. The NDC distributes all products in this Program.


**1.18.3.3** **(10-25-2022)**

### Taxpayer Assistance Center (TAC)

1. The TAC program provides taxpayer assistance center locations with tax forms, instructions, and publications for redistribution to the public. We issue the Balance on Hand (BOH) survey to approximately 358 TAC offices and posts of duty (PODs) each year to determine the remaining stock levels and to obtain quantity requirements for the upcoming filing season product shipments.

2. TAC offices complete the BOH survey using a spreadsheet populated by program contacts in each office. The survey is in the Order Management System (OMS) on the intranet. Authorized Field Assistance personnel access and update the survey using their office Order Point Number (OPN) ending in 6699.

3. Media and Publications (M&P) and Field Assistance partner to determine the products TAC offices are authorized to stock each filing season and which authorized products and quantities will be automatically distributed to the TAC offices. TAC offices will place orders in the Order and Subscription Management System (OSMS) for any authorized product not on the automatic distribution list. The authorized list and the products to be automatically distributed are posted at http://publish.no.irs.gov/distsys/pod/pod.html on the Taxpayer Assistance Center Order Management System (TAC OMS) early in the quarter of each fiscal year.

4. TAC offices use the OSMS, an online ordering system for IRS offices, at https://caps-as.enterprise.irs.gov/osms/views/homePage.xhtml to place reorders for authorized tax products.

5. Initial full cartons for most tax products ship from the print contractor directly to the TACs, while initial products in less than full cartons and reorders ship from the NDC.


**1.18.3.4** **(01-21-2021)**

### Tax Forms Outlets Program (TFOP)

1. The TFOP provides outreach to increase availability of major tax products in local communities.

2. The TFOP offers bulk tax products to IRS program partners in areas that have high rate of paper returns and meet specific program criteria. The IRS partners with libraries, post offices, federal, state and local government offices, prisons, and military installations to provide the TFOP. TFOP also offers reproducible tax products (Publication 1132) to a limited number of previous Community Based Outlet Program (CBOP) partners.

3. Annually in August through October, the TFOP emails Form 8635, Orders for Tax Forms Outlet Program (TFOP) Partners to active TFOP partners. TFOP administrators may reactivate closed accounts upon request from former partners and e-mail Form 8635 to the identified contact person. TFOP no longer accepts requests for new accounts. The CAPS programmer applies a suggested order to the Form 8635 to help partners place orders and uses the partner’s previous-year order to calculate the suggested order.

4. The partner completes Form 8635 and e-mails it to a designated CAPS e-mail inbox where the CAPS extracts and loads the data directly into ELITE for order processing. Partners who have difficulty completing or submitting the order form can e-mail their order request to the TFOP administrator inbox and the administrator will complete and submit an order form on their behalf. Former CBOP partners receive an e-mail that asks whether they want to receive the reproducible Publication 1132. If the administrator receives a positive response, then they add the order (1 per branch based on the number of partner branches on file in ELITE) to a spreadsheet they e-mail daily to the ELITE programmer for order entry.

5. When the tax products become available, TFOP partners begin receiving shipments of the ordered tax products. Most bulk orders for major tax products ship directly from a print contractor, while non-bulk orders ship from the NDC.

6. Generally, the TFOP stops accepting orders three weeks before the general filing deadline (April 15).

7. Annually in April, the TFOP emails Form 8635-A, TFOP Balance on Hand (BOH), to partners who placed at least one order for a major tax product during the previous year. The BOH asks partners to indicate the number of copies that remain onsite after the general filing deadline. Partners return the BOH using the same email method used for Form 8635 (order form). The TFOP uses partners’ responses to suggest order quantities for the next order cycle.


**1.18.3.5** **(10-25-2022)**

### Volunteer Income Tax Assistance/Tax Counselling for the Elderly (VITA/TCE) Program

1. The IRS uses volunteers trained by the Service to offer free assistance with tax return preparation and tax counseling.

2. The VITA/TCE Program helps seniors, individuals with low to moderate incomes, persons with disabilities, and those for which English is a second language. The IRS also provides training materials for more than 91,000 volunteers in this program.

3. Stakeholder Partnerships, Education & Communication (SPEC), Stakeholder Relationship Tax Consultants (SRTCs), and their volunteers use an order form that offers a wide variety of tax materials:



   - F2333V, Order for VITA/TCE Program


4. Annually on October 1st or the first Monday in October each year, the TFDPS emails Form 2333V to partners and/or participants that have an email address associated with their account.

5. Program participants send the completed Form 2333V to a mailbox where the data is extracted and loaded into the CAPS e-mailbox for the SRTC to review and edit if necessary, and approve. SRTCs send approved orders to ELITE for fulfilment by a print contractor or the NDC. Participants can also use Form 2333V for reorders.

6. Program participants can send their orders for other material to the SRTC for review and approval. SRTCs will submit approved orders using OSMS at https://caps-as.enterprise.irs.gov/osms/views/homePage.xhtml to submit approved orders.

7. SRTCs can also enter orders for Form 2333V directly into the CAPS system.

8. We send VITA/TCE materials to individuals' homes and/or offices, and in bulk quantities to VITA/TCE sites, IRS offices, and military installations.

9. The VITA/TCE Program offers more than 25 products. Orders are processed and shipped to our partners by our print contractors or by the NDC.


**1.18.3.6** **(01-05-2018)**

### Other Programs and Responsibilities

1. In addition to the above distribution programs, the TFPDS also manages special distribution processes including databases, order forms, and product information-sharing with IRS employees and contracted entities. Some of the primary processes are:



1. External Addresses

2. ELITE Contractor Planning Application

3. Internet Ordering Initiative

4. Non-Program Order Forms

5. Prior Year Tax Forms

6. Telephone Orders


**1.18.3.6.1** **(01-05-2018)**

#### External Addresses

1. We developed the External Addresses system to standardize data entry, search options, and reports for several programs. We maintain the External Address system in the CAPS system. Programs that use the External Addresses system include:



1. TFOP

2. VITA/TCE


**1.18.3.6.2** **(01-05-2018)**

#### Enterprise Logistics Information Technology (ELITE) Contractor Planning Application

1. The contractor planning application is an ELITE function that creates distribution lists for CAPS program orders. The distribution lists contain full carton and less-than-full carton orders for TAC, TFOP, and VITA/TCE programs for products that will ship directly from print contractors.

2. After an initial order load in early October, we send CAPS orders to ELITE daily. ELITE sends a nightly file to CAPS containing the shipping date and quantity for any product on a distribution list or filled by the NDC.

3. An ELITE distribution list for a specific product contains orders from all CAPS programs that will be filled by a print contractor. Distribution lists are Excel spreadsheets that distribution analysts can sort or edit as needed.

4. Customers can generate multiple lists for the same product on a weekly basis or as needed.

5. Customers can round order quantities to full carton quantities using user-defined percentages.


**1.18.3.6.3** **(01-21-2021)**

#### Internet Ordering Initiative

1. The TFDPS continuously explores all avenues for tax product distribution, including the IRS website at [http://www.irs.gov](http://www.irs.gov/). The forms and publications Web pages on this website accept orders for:



   - Forms and Publications by U.S. Mail

   - Online Ordering for Information Returns and Employer Returns (Employer forms and instructions)


2. A TFDPS analyst updates the pages annually and on an as-needed basis throughout the year.


**1.18.3.6.4** **(01-21-2021)**

#### Non-Program Order Forms

1. The TFDPS owns several forms used for ordering commonly requested tax products:



1. Form 4190, Order Form for Tax Forms and Publications, which IRS TACs and call assistors can use to place taxpayer orders for Federal tax products from the NDC.

2. The Taxpayer Order Form (TPOF) lists the most commonly requested taxpayer products and is included in the annual Instructions for Form 1040 and some high-volume taxpayer publications.

3. Call site assistors and/or taxpayers can send the completed Form 4190 order form to the NDC for data transcription and order fulfilment.


**1.18.3.6.5** **(01-05-2018)**

#### Prior Year Tax Forms Program

1. The Prior Year Tax Forms program archives, stores, and manages all tax forms and instructions dating back to 1864.

2. We provide products to customers from in-house stock, print on demand, and online printing from Portable Document Format (PDF) files. The product's originator may determine whether the products and revisions are to be included as a prior year product and added into the Prior Year Tax Forms program.

3. A calendar year product gets revised annually and becomes a prior year product on December 1. A revision date product is revised as needed and becomes a prior year product once a new revision is approved to print. Orders for prior year products are limited to five prior years.

4. The Prior Year Tax Forms Program analyst works with the Publishing function personnel to update the IRS website for prior year forms, instructions, and publications page at [https://www.irs.gov/forms-instructions](https://www.irs.gov/forms-instructions)


**1.18.3.6.6** **(01-21-2021)**

#### Telephone Orders

1. The TFDPS provides support and assistance to the toll-free Forms number 800-829-3676 operation. This process involves working with other IRS and M&P personnel including:



   - Business Requirements System Integration

   - National Distribution Center

   - Distribution Analysts

   - Printing Specialists

   - Tax Law Specialists

   - Customer Account Services (CAS) policy analysts


2. The TFDPS analyst shares tax product information and provides reference or guidance with the ordering processes such as:



01. Provide information on the availability of new, obsolete, and revised products

02. Deliver timeframes to the public

03. Distribute requirements for Distribution programs

04. Address and/or forward customer complaints, inquiries, or concerns

05. Refer systemic problems to the appropriate source

06. Share questions or comments about procedures

07. Review materials and guidelines with the Centralized Quality Review Section (CQRS) to ensure use of up-to-date information when monitoring the service provider National Telecommuting Institute (NTI) order entry clerks

08. Notify CQRS personnel of changes in procedures and practices

09. Attend conference call meetings to perform call calibrations to monitor use of required call attributes

10. Attend pre- and post-season meetings with all stakeholders to improve communication and continuity

11. Monitor computer systems and daily/nightly file transmissions from IRS to NTI and NTI to IRS to ensure there are no problems or issues


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-018-003#addtoany "Show all")

A2A