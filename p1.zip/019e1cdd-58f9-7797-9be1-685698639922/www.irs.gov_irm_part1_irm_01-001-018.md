---
url: "https://www.irs.gov/irm/part1/irm_01-001-018"
title: "1.1.18 Research, Applied Analytics and Statistics Division | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-001-018#main-content)

- 1.1.18  [Research, Applied Analytics and Statistics Division](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236943082032)
  - 1.1.18.1  [Research, Applied Analytics and Statistics Division](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236942655392)
    - 1.1.18.1.1  [Data Exploration and Testing Division](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236971272512)
      - 1.1.18.1.1.1  [Data Exploration Lab](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236971358416)
      - 1.1.18.1.1.2  [Emerging Risks Lab](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236971356496)
      - 1.1.18.1.1.3  [Issue Identification Lab](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236971280256)
      - 1.1.18.1.1.4  [Modeling and Optimization Lab](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236971278304)
    - 1.1.18.1.2  [Data Management Division](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236971276256)
      - 1.1.18.1.2.1  [Data Delivery and Support](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236938597392)
      - 1.1.18.1.2.2  [Enforcement Revenue Data Lab](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236972366512)
      - 1.1.18.1.2.3  [Infrastructure Systems and Services](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236972364832)
      - 1.1.18.1.2.4  [Operations Imaging Lab](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236972363056)
      - 1.1.18.1.2.5  [Technical Lab](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236938706448)
    - 1.1.18.1.3  [Knowledge Development and Application Division](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236938704592)
      - 1.1.18.1.3.1  [Compliance Modeling Lab](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236942757280)
      - 1.1.18.1.3.2  [National Research Program](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236942755344)
      - 1.1.18.1.3.3  [Partnership and Innovation Lab](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236942753408)
      - 1.1.18.1.3.4  [Policy and Program Impact Lab](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236942765632)
      - 1.1.18.1.3.5  [Taxpayer Behavior Lab](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236942763152)
    - 1.1.18.1.4  [Statistics of Income Division](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236942760496)
      - 1.1.18.1.4.1  [Corporations, Partnerships and International](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236942620400)
      - 1.1.18.1.4.2  [Individual and Tax Exempt](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236942618224)
      - 1.1.18.1.4.3  [Information Management and Dissemination](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236942616368)
      - 1.1.18.1.4.4  [Statistical Services](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236938312224)
    - 1.1.18.1.5  [Strategy and Business Solutions Division](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236938310176)
      - 1.1.18.1.5.1  [Business Performance Analytics Lab](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236938899504)
      - 1.1.18.1.5.2  [Project Management Office](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236938897088)
      - 1.1.18.1.5.3  [Servicewide Policy, Directives and Electronic Resources (SPDER)](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236938895488)
      - 1.1.18.1.5.4  [Strategic Innovation and Implementation](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236942683024)
    - 1.1.18.1.6  [Management and Engagement](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236942680288)
  - Exhibit  1.1.18-1  [Terms, Definitions and Acronyms](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236938927504)
  - Exhibit  1.1.18-2  [Research, Applied Analytics and Statistics Organization](https://www.irs.gov/irm/part1/irm_01-001-018#idm140236942670528)

# Part 1. Organization, Finance, and Management

# Chapter 1. Organization and Staffing

# Section 18. Research, Applied Analytics and Statistics Division

* * *

## 1.1.18 Research, Applied Analytics and Statistics Division

#### Manual Transmittal

November 08, 2022

#### Purpose

(1) This transmits revised IRM 1.1.18, _Organization and Staffing, Research, Applied Analytics and Statistics Division._

#### Background

The Office of Research, Applied Analytics and Statistics, or RAAS, is the Service’s centralized research and analytic organization. It is distinct from research operations embedded in the business units in that RAAS’s projects are more likely to have enterprise or cross-organizational impact or reflect the needs and responsibilities of the entire IRS. RAAS partners with embedded research functions to share information and analytic techniques, to collaborate on projects and identify learning and training opportunities. RAAS advocates for the use of data for decision making.

#### Material Changes

(1) This IRM section has been updated to reflect the new Data and Analytics Operating Model, including the Data and Analytics Strategic Integration Board (DASIB) and the Data and Analytics Advisory Group (DAAG). It removes references to the Research Policy and Planning Committee and the Research Directors’ Coordinating Council which were decommissioned. The Research Directors’ Coordinating Council became one of the advisory councils within the DAAG.

(2) Changed Research & Analytics (R&A) to Data and Analytics (D&A) throughout the document as a result of the new D&A governance structure.

(3) IRM 1.1.18.1(4)d. was added to include RAAS’ role in the delivery of statistics.

(4) IRM 1.1.18.1(6) was added to describe processing of requests for RAAS research.

(5) IRM 1.1.18.1.2.3, Operations Imaging, was renumbered as IRM 1.1.18.1.2.4 and IRM 1.1.8.1.2.4, Infrastructure Systems & Services, was renumbered as 1.1.18.1.2.3 so they appear alphabetically in order in this IRM.

(6) IRM 1.1.18.1.3.5(1) was modified to update the function of the Taxpayer Behavior Lab.

(7) IRM 1.1.18.1.5(2)(a) was deleted as the enterprise research plan is no longer delivered.

(8) IRM 1.1.18.1.5.2(1) was modified to update the function of the Business Performance Analytics Lab.

(9) IRM 1.1.18.1.5.1(1) was modified to update the function of the Project Management Office.

(10) IRM 1.1.18.1.5.4(1) was updated with editorial changes to the Strategic Innovation and Implementation Lab.

(11) Exhibit 1.1.19-2 was updated to (a) correct the RAAS name, (b) correct the SPDER name, and (c) reorder the listing of the labs within RAAS.

(12) Changed references to RAAS to reflect it as an Office in the Purpose and IRM 1.1.18.1 and Exhibit 1.1.18-2 for consistency throughout this IRM.

(13) Editorial changes made throughout this IRM.

(14) Editorial changes made, the addition of Management and Engagement, and addition of the duties of the Deputy Chief Data and Analytics Officer.

#### Effect on Other Documents

This supersedes IRM 1.1.18, dated September 28, 2018.

#### Audience

All Divisions and Functions.

#### Effective Date

(11-08-2022)

Chief Data and Analytics Officer

**1.1.18.1** **(11-08-2022)**

### Research, Applied Analytics and Statistics Division

1. The mission of Research, Applied Analytics and Statistics (RAAS) is to lead a data-driven culture through innovative and strategic research, analytics, statistics, and technology services in partnership with internal and external stakeholders.

2. RAAS is headed by the Chief Data and Analytics Officer who reports to the Deputy Commissioner of Operations Support. The Chief Data and Analytics Officer and the Deputy Chief Data Analytics Officer are responsible for oversight and coordination of the activities of the following six divisions:



   - Data Exploration and Testing Division

   - Data Management Division

   - Knowledge Development and Application Division

   - Statistics of Income Division

   - Strategy and Business Solutions Division

   - Management and Engagement


3. RAAS combines advanced analytics, dynamic testing, reporting, and prototyping with appropriate scientific rigor and deep IRS domain expertise to deliver valid and actionable insights using diverse sources of data. RAAS works in partnership with IRS operating units to achieve orders-of-magnitude returns from the application of advanced analytics and with IRS leadership to maximize the strategic application of Research & Analytics resources across the enterprise.

4. To accomplish this mission, RAAS performs the following activities:



1. Conducts strategic research and analysis and research not limited to a single operating unit but critical Servicewide. This includes various types of research such as econometric modeling, forecasting, compliance studies, analysis of proposed legislative initiatives, and strategic program evaluations.

2. Provides IRS-wide leadership in the design, development, and maintenance of research programs.

3. Provides functional leadership, guidance, and support to the IRS Research Community on research and analytics standards and practices to ensure consistency, comparability, and quality.

4. Delivers high quality, timely, relevant, trusted statistics on the tax system and IRS operations.


5. The Chief Data and Analytics Officer:



1. Serves as a member of the commissioner's senior leadership team to ensure coordinated, responsive, and cost-effective services to the Senior Executive Team and operating divisions in strategic planning and performance management.

2. Develops and maintains relationships with key internal and external stakeholders to identify their research and analysis needs, evaluate and provide high quality of research and analysis services, and identify actions which may be required to continuously improve research processes.

3. Plans and directs the efficient, effective use of research and analysis staff resources, including identifying staff training and development needs, overseeing the design, conducting an assessment of research staff training and development programs, and serving as a mentor and coach to staff.

4. Co-Chairs the Data and Analytics Strategic Integration Board (DASIB).


6. The Deputy Chief Data and Analytics Officer - Statistics:



1. Supports the Chief Data and Analytics Officer and leads the RAAS Statistics of Income Division, which is one of 13 principal federal statistical agencies and is responsible for producing statistics on the tax system.

2. Serves as the Statistical Official for the Treasury Department and in this role has statutory responsibility for advising on statistical policy, techniques and procedures, including developing Departmental statistical data quality and confidentiality standards.

3. Participates as a member of the Office of Management and Budget Interagency Council on Statistical Policy, advising the Chief Statistician of the United States on policies and standards that impact the federal statistical system and working with other statistical agencies to implement laws and regulations governing federal data and statistics.


7. Research requests are submitted through a survey link on the RAAS Projects SharePoint site. The RAAS Project Management Office (PMO) (IRM 1.1.18.1.5.2) facilitates the assignment of the request to the appropriate Research Division which works with the requester to determine the extent of the research being requested. Requests may be referred to embedded research teams in the business units. Research must be approved by a quorum of the research directors and approved research must be separately added to the Project Repository. See IRM 1.7.1.2.4 on the D&A Project Repository.


**1.1.18.1.1** **(09-28-2018)**

#### Data Exploration and Testing Division

1. The Mission of the Data Exploration and Testing Division (DET) is to extract value from analytics through exploration, testing, and learning to improve tax compliance and enterprise operations; apply the broadest breadth of analytical tools and techniques available to leverage existing IRS and third-party data and create new value by innovating operational advances.

2. To accomplish its mission, DET pursues the following organizational goals:



1. Exploring existing and emergent data to identify relevant patterns and anomalies.

2. Innovating front-line compliance and operational solutions that enhance accessibility of data.

3. Responding nimbly to and adapting approaches based on the changing needs of the partners of RAAS.

4. Developing and testing hypotheses using experimental data as well as exploratory analysis.


**1.1.18.1.1.1** **(09-28-2018)**

##### Data Exploration Lab

1. The Data Exploration Lab examines all sources of data for opportunities to detect and prevent fraudulent behavior. The lab identifies patterns and trends to develop new approaches to detect emerging schemes. This will improve service and enforcement efforts by preventing refunds from being issued to fraudulent actors.


**1.1.18.1.1.2** **(09-28-2018)**

##### Emerging Risks Lab

1. The Emerging Risks Lab applies new and advanced techniques to detect emerging risks across the Service. The lab mines data and develops advanced tools to understand and create visual representations of the taxpayer environment. This enables the Service to identify emerging compliance risks across larger taxpayer segments and understand relationships among non-compliant actors that are otherwise difficult to detect.


**1.1.18.1.1.3** **(09-25-2020)**

##### Issue Identification Lab

1. The Issue Identification Lab enhances the Service's compliance issue identification and provides analytically-based solutions to compliance issues. The lab analyzes tax data and taxpayer information to develop innovative and forward-thinking approaches to identify, quantify, evaluate, and/or mitigate compliance issues within the Service.


**1.1.18.1.1.4** **(09-28-2018)**

##### Modeling and Optimization Lab

1. The Modeling and Optimization Lab produces predictive models and resource and workload optimizations to increase effectiveness of IRS service and compliance. These include enforcement models and optimizations to test and implement more effective detection, prevention, and treatment of tax compliance issues as well as resource optimization models covering IRS workforce and real estate.


**1.1.18.1.2** **(09-28-2018)**

#### Data Management Division

1. The mission of the Data Management Division (DMD) is to create and expand strategic opportunities to pair data and analytics in ways that can drive innovation and insights by providing highly-valued data, cutting-edge tools and new and emerging technologies. DMD provides information, tools, services and processes to the IRS research community and operational customers to improve the efficiency and effectiveness of IRS programs.

2. To accomplish its mission, DMD pursues the following organizational goals:



1. Rapidly integrate new data to speed adoption of data-driven solutions.

2. Open new opportunities in analytics by expanding access to data in multi-structured and paper-based formats.

3. Invest in advanced computing and emerging technologies to accelerate innovation, drive efficiencies, and unlock greater value from data.

4. Simplify access to data and tools through self-service analytics to enable more collaboration and sharing of data assets.


**1.1.18.1.2.1** **(09-28-2018)**

##### Data Delivery and Support

1. Data Delivery and Support oversees the management and coordination of data products available on the Compliance Data Warehouse (CDW).


**1.1.18.1.2.2** **(09-28-2018)**

##### Enforcement Revenue Data Lab

1. The Enforcement Revenue Data lab produces and delivers data through the Enforcement Revenue Information System (ERIS) on revenue collected from all IRS enforcement actions.


**1.1.18.1.2.3** **(09-25-2020)**

##### Infrastructure Systems and Services

1. Infrastructure Systems and Services provides support for the servers and networks for the Compliance Data Warehouse, RAAS divisions, and the business units.


**1.1.18.1.2.4** **(09-25-2020)**

##### Operations Imaging Lab

1. The Operations Imaging Lab oversees the RAAS scanning and IRS _e-file_ parsing operations in addition to providing server and network support for the RAAS Statistics of Income and Data Management projects.


**1.1.18.1.2.5** **(09-28-2018)**

##### Technical Lab

1. The Technical Lab collaborates with other RAAS IT support staff to provide support for the servers and networks needed for RAAS staff to collect, analyze, and disseminate information on federal taxation.


**1.1.18.1.3** **(09-28-2018)**

#### Knowledge Development and Application Division

1. The mission of the Knowledge Development and Application Division (KDA) is to leverage domain expertise in tax administration, economics, behavioral research, and statistical methodology to advise IRS senior leadership and agency stakeholders in the baseline understanding of foundational challenges in tax administration and in the development, analysis, and implementation of transformational approaches and procedures.

2. To accomplish the mission, KDA innovates in the following areas:



1. Leveraging a perspective on tax administration that focuses on the taxpayer across tax years, beyond the filing event, and their impact on other taxpayers.

2. Applying scientific techniques to establish necessary baselines and controls to validate burdens, opportunities, and impacts associated with tax compliance.

3. Advancing critical communities of practice in the domains described above.


**1.1.18.1.3.1** **(09-28-2018)**

##### Compliance Modeling Lab

1. The Compliance Modeling Lab estimates the nature and extent of noncompliance, including the tax gap and the voluntary filing rate. Responsibilities also include the development of baseline compliance risk models, including Discriminate Function (DIF). The lab also conducts focused compliance studies supporting key IRS initiatives.


**1.1.18.1.3.2** **(09-28-2018)**

##### National Research Program

1. The National Research Program (NRP) gathers detailed data on the taxpaying population to inform IRS, Treasury, and Executive branch decision-making processes. NRP directly addresses specific congressional inquiries and provides actionable data regarding taxpayer compliance. NRP also generates data for IRS workload selection.


**1.1.18.1.3.3** **(09-28-2018)**

##### Partnership and Innovation Lab

1. The Partnership and Innovation Lab orchestrates strategic partnerships with the academic community and key external stakeholders to generate greater understanding on topics pertaining to behavioral insights and IRS research priorities, develop new methodologies and validate insights. The Partnership and Innovation Lab facilitates knowledge sharing and dissemination across research and analytics functions both within and outside of RAAS.


**1.1.18.1.3.4** **(09-28-2018)**

##### Policy and Program Impact Lab

1. The Policy and Program Impact Lab supports planning and evaluation of major legislative implementation programs and tax administration policy changes, including the Affordable Care Act and the Foreign Account Tax Compliance Act. The lab applies forensic economics and related analytical methods to estimate program impacts. The Policy and Program Impact Lab’s efforts focus on planning support and evaluation of major programs for key customers.


**1.1.18.1.3.5** **(09-25-2020)**

##### Taxpayer Behavior Lab

1. The Taxpayer Behavior Lab focuses on understanding and estimating the time and money burden incurred by taxpayers to meet their federal tax reporting responsibilities and researching cost-effective ways to help taxpayers overcome barriers to claiming the tax benefits to which they are entitled and to encourage tax compliance. The lab’s Taxpayer Burden Models are used to inform tax policy, regulatory guidance, and program improvement. Specific focus areas include taxpayer compliance burden and behavioral insight pilots.


**1.1.18.1.4** **(09-28-2018)**

#### Statistics of Income Division

1. The Statistics of Income Division (SOI) formulates and executes the statistical policies, practices and programs of the IRS. SOI collects, analyzes, safeguards, and disseminates information on federal taxation in support of tax administration, economic policy development, and financial analysis. It serves a broad range of users in the IRS, the Federal Government, the public, and the nonprofit sectors. It provides statistical support within the Service for a broad range of program evaluation and measurement analytics. It leads efforts to modernize federal statistical programs and practices through engagement with the federal statistical community.

2. SOI provides data for various customers, including individuals looking for tax information and executives engaged in strategic planning and policy makers seeking data to evaluate and change tax laws. SOI provides aggregate tax data, statistical services, return filing projections, and other support to the IRS Business Operating Divisions, Legislative Affairs, and Media Relations by responding to data requests, preparing reports, and conducting research.

3. Other external customers include the following:



   - Treasury’s Office of Tax Analysis

   - Congressional Joint Committee on Taxation

   - Department of Commerce Bureau of Economic Analysis

   - U.S. Census Bureau

   - Board of Governors of the Federal Reserve

   - State and local Governments

   - Non-profit research organizations

   - Academics

   - Tax professionals

   - Citizens seeking to learn more about the tax system


**1.1.18.1.4.1** **(11-08-2022)**

##### Corporations, Partnerships and International

1. Corporations, Partnerships and International produces comprehensive data on corporation income tax and partnership returns through a variety of studies. The branch also prepares detailed tables, articles, and publications providing statistics on income, deductions, credits, and other taxes as reported by corporations filing Forms 1120 (including 1120-L, 1120-PC, 1120-REIT, 1120-RIC ) and partnerships filing Form 1065. .International studies include those corporation returns that file relevant forms (such as Form 1118, Form 5471, and more).


**1.1.18.1.4.2** **(09-28-2018)**

##### Individual and Tax Exempt

1. Individual and Tax Exempt produces comprehensive statistics from data collected from income tax forms and associated schedules filed to report income and taxes for individuals, tax-exempt organizations, tax-exempt bonds, gifts, and estates.


**1.1.18.1.4.3** **(09-25-2020)**

##### Information Management and Dissemination

1. Information Management and Dissemination provides Information Technology support for numerous SOI studies and RAAS initiatives, prepares publications for printing and dissemination, and manages the Statistical Information Services office which assists the public and other customers with data requests and questions about published statistics and the Tax Stats Web pages.


**1.1.18.1.4.4** **(09-28-2018)**

##### Statistical Services

1. Statistical Services provides statistical services to various organizations across the IRS. These services include producing sample designs and weights for the major SOI studies and providing statistical support for numerous IRS quality measures, surveys, and pilot programs throughout the IRS. Additionally, the Servicewide Support section develops projections of tax return volumes for IRS workload planning and offers ad hoc forecasting services.


**1.1.18.1.5** **(09-25-2020)**

#### Strategy and Business Solutions Division

1. The Strategy and Business Solutions Division (SBS) engages with stakeholders to frame and solve the most pressing challenges facing tax administration and aligns IRS enterprise-wide D&A talent, knowledge, and resources to maximize the value of our collective D&A and RAAS activities and to further IRS enterprise-wide strategic priorities, coordinating governance for the Servicewide D&A community.

2. To accomplish this mission, SBS is responsible for the following:



1. Coordinating governance functions across RAAS and the Servicewide D&A community.

2. Designing and delivering core tax administration and knowledge tools and services that advance the customer service, compliance and enforcement priorities of the IRS.

3. Spearheading opportunities for detailees to lead or participate in large multi-functional initiatives that focus on the Service’s largest and most pressing strategic problems.

4. Managing a rigorous project intake process and maintaining a comprehensive project repository for the D&A Community.

5. Applying data analytics to assist BOD stakeholders in framing problems, identifying opportunities for programmatic improvement, and testing and implementing solutions.


**1.1.18.1.5.1** **(09-25-2020)**

##### Business Performance Analytics Lab

1. The Business Performance Analytics (BPA) Lab focuses on providing data driven analytical support to IRS customers by engaging in a collaborative manner with subject matter experts and leadership stakeholders. The BPA lab utilizes a variety of quantitative analysis, statistical modeling, and machine learning techniques to solve problems in support of more effective and efficient IRS operations.


**1.1.18.1.5.2** **(09-25-2020)**

##### Project Management Office

1. The Project Management Office (PMO) manages coordination of RAAS portfolio meetings, including new requests for the research assets of RAAS. The PMO advises and supports the Data and Analytics Strategic Integration Board (DASIB), Data and Analytics Advisory Group (DAAG), and shares research information across the IRS Research Community through forums such as senior leadership meetings, communities of practice, and maintenance of the IRS Data & Analytics Project Repository.


**1.1.18.1.5.3** **(09-28-2018)**

##### Servicewide Policy, Directives and Electronic Resources (SPDER)

1. SPDER designs, delivers, and manages a set of tax administration and knowledge tools to enable IRS employees to meet their responsibilities for enforcement, compliance, and customer service. These tools include the Internal Revenue Manual, commercial electronic research services, knowledge management, and the IRS historical library.


**1.1.18.1.5.4** **(09-25-2020)**

##### Strategic Innovation and Implementation

1. The Strategic Innovation and Implementation lab leads analytical and research projects in collaboration with stakeholders from IRS Business Divisions to tackle very large strategic problems by asking the right questions, looking at the problem through different perspectives, and sizing and scoping opportunities to develop and deliver innovative solutions. This lab also spreads the data‐driven culture by providing opportunities for detailees from around the IRS to lead large multi‐functional initiatives and employ advanced data usability and analytics.


**1.1.18.1.6** **(11-08-2022)**

#### Management and Engagement

1. The Management and Engagement (M&E) division supports each RAAS division by providing budgeting, human resources support, contracting, external auditing support, and communications.

2. M&E is divided into the following functions:



1. The Human Resources office works closely with the IRS Human Capital Office (HCO). The M&E Human Resources office also partners with RAAS division managers to administer the RAAS budget and to provide personnel support to various human resource objectives including recruitment, staffing, placement, performance management and award guidance, leadership development, training, and onboarding and offboarding employees.

2. The Contracting office works closely with Procurement. The M&E Contracting group also provides RAAS leaders oversight to high-risk and complex contracts and subject matter expertise to RAAS colleagues related to contract and project management. These contracts support the IRS mission and strategic plan.

3. The Auditing function manages RAAS responses to GAO and TIGTA audits. The RAAS audit liaisons both lead and support and other IRS organizations on GAO/TIGTA audits. The timeline of a typical audit is nine to 18 months. For some audits, both GAO and TIGTA may access taxpayer data on the Compliance Data Warehouse (CDW) to conduct their analyses.

4. The Communications and Engagement function addresses internal communications and employee engagement, including Town Halls, and the Federal Employee Viewpoint Survey (FEVS). This office also manages the weekly newsletter and the Public Service Recognition Week.


**Exhibit 1.1.18-1**

### Terms, Definitions and Acronyms

|     |     |
| --- | --- |
| CDW | Compliance Data Warehouse |
| D&A | Data & Analytics |
| DAAG | Data and Analytics Advisory Group |
| DASIB | Data and Analytics Strategic Integration Board |
| DET | Data Exploration and Testing |
| DIF | Discriminate Index Function |
| DMD | Data Management Division |
| ERIS | Enforcement Revenue Information System |
| FEVS | Federal Employee Viewpoint Survey |
| GAO | Government Accountability Office |
| HCO | Human Capital Office |
| IRS | Internal Revenue Service |
| IT | Information Technology |
| KDA | Knowledge Development and Application |
| M&E | Management & Engagement |
| NRP | National Research Program |
| PMO | Project Management Office |
| RAAS | Research, Applied Analytics and Statistics |
| SOI | Statistics of Income |
| SBS | Strategic Business Solutions |
| SPDER | Servicewide Policy, Directives and Electronic Resources |
| TIGTA | Treasury Inspector General for Tax Administration |

**Exhibit 1.1.18-2**

### Research, Applied Analytics and Statistics Organization

![This is an Image: 37583003.gif](https://www.irs.gov/pub/xml_bc/37583003.gif)

> Graphic Description: Pictured is the organization chart for Research, Applied Analytics and Statistics.There are six divisions included in Research, Applied Analytics and Statistics, all of which respond to the Chief Data and Analytics Officer and the Deputy Data and Analytics Officer. The six divisions are:Knowledge Development and ApplicationData Exploration and TestingStrategy and Business SolutionsStatistics of IncomeData Management DivisionManagement and EngagementReporting to Knowledge Development and Application are the following organizations: Compliance Modeling LabNational Research ProgramPartnership and Innovation LabPolicy and Program Impact LabTaxpayer Behavior LabReporting to Data Exploration and Testing are the following organizations:Data Exploration LabEmerging Risk LabIssue Identification LabModeling and Optimization Lab Reporting to Strategy and Business Solutions are the following organizations: Business Performance Analytics LabProject Management OfficeServicewide Policy, Directives and Electronic ResearchStrategic Innovation and Implementation Reporting to Statistics of Income are the following organizations: Corporations, Partnerships and InternationalIndividual and Tax ExemptInformation Management and DisseminationStatistical Services Reporting to Data Management Division are the following organizations: Data Delivery and SupportEnforcement Revenue DataOperations ImagingInfrastructure Systems and ServicesTechnical Management and Engagement has the following functions:ContractingHuman Resources AuditingCommunications and EngagementEnd Graphic Description

[Please click here for the text description of the image.](https://www.irs.gov/media/340211 "")

[More Internal Revenue Manual](https://www.irs.gov/irm)