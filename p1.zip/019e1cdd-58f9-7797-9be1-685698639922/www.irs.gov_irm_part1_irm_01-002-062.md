---
url: "https://www.irs.gov/irm/part1/irm_01-002-062"
title: "1.2.62 Division/Function Delegation of Authorities for Information Technology (IT) | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-002-062#main-content)

- 1.2.62  [Division/Function Delegation of Authorities for Information Technology (IT)](https://www.irs.gov/irm/part1/irm_01-002-062#idm139733897624640)
  - 1.2.62.1  [Overview](https://www.irs.gov/irm/part1/irm_01-002-062#idm139733897573200)
  - 1.2.62.2  [Delegations of Authority for Information Technology (IT)](https://www.irs.gov/irm/part1/irm_01-002-062#idm139733897833168)
    - 1.2.62.2.1  [Delegation Order IT-1-1-1 (Rev. 1), Order of Succession for Information Technology (IT)](https://www.irs.gov/irm/part1/irm_01-002-062#idm139733897830864)
    - 1.2.62.2.2  [Delegation Order IT-1-23-1 (formerly MITS-1-23-1), Authority to Sign Written Materials](https://www.irs.gov/irm/part1/irm_01-002-062#idm139733897823504)
    - 1.2.62.2.3  [Delegation Order IT-1-23-2 (formerly MITS-1-23-2), Authority to Sign Internal Management Documents](https://www.irs.gov/irm/part1/irm_01-002-062#idm139733899072976)
    - 1.2.62.2.4  [Delegation Order IT-1-23-5 (Rev. 1), Superior Qualifications Appointment Authority](https://www.irs.gov/irm/part1/irm_01-002-062#idm139733899065680)
    - 1.2.62.2.5  [Delegation Order IT-1-23-6, Information Technology (IT) Mission Critical Travel within the United States](https://www.irs.gov/irm/part1/irm_01-002-062#idm139733899058624)
    - 1.2.62.2.6  [Delegation Order IT-1-23-7, Information Technology (IT) Employee Misconduct unit Cases (EMU)](https://www.irs.gov/irm/part1/irm_01-002-062#idm139733899051632)
    - 1.2.62.2.7  [Delegation Order IT-1-23-8, Information Technology (IT) Positions Outside of IT](https://www.irs.gov/irm/part1/irm_01-002-062#idm139733899044848)
    - 1.2.62.2.8  [Delegation Order IT-1-23-9, Approval of Information Technology (IT) GS-15](https://www.irs.gov/irm/part1/irm_01-002-062#idm139733899038432)
    - 1.2.62.2.9  [Delegation Order IT-2-1-1 (Rev. 1), Approve Information Technology (IT) Shopping Carts](https://www.irs.gov/irm/part1/irm_01-002-062#idm139733899031952)
    - 1.2.62.2.10  [Delegation Order IT-2-1-1-A, Consent to Approval of JOFOCs, JEFOs and LSJs](https://www.irs.gov/irm/part1/irm_01-002-062#idm139733899015264)
    - 1.2.62.2.11  [Delegation Order IT-2-1-2, Authority to Approve Acquisition Plans (APs)](https://www.irs.gov/irm/part1/irm_01-002-062#idm139733899008672)
    - 1.2.62.2.12  [Delegation Order IT-6-1-1 (formerly MITS-6-1-1, Rev. 1), Authority to Create and Abolish Positions](https://www.irs.gov/irm/part1/irm_01-002-062#idm139733898995776)
    - 1.2.62.2.13  [Delegation Order IT-11-2-4 (formerly MITS-11-2-4), Disclosure of Personnel/Claimant Matters](https://www.irs.gov/irm/part1/irm_01-002-062#idm139733898988480)
    - 1.2.62.2.14  [Delegation Order IT-25-6-1 (formerly MITS-25-6-1), Cost of Complying With a Summons](https://www.irs.gov/irm/part1/irm_01-002-062#idm139733898981424)
  - 1.2.62.3  [Rescinded IT Delegation Orders](https://www.irs.gov/irm/part1/irm_01-002-062#idm139733898974384)
    - 1.2.62.3.1  [Delegation Order IT-6-4-1 (formerly MITS-6-4-1)](https://www.irs.gov/irm/part1/irm_01-002-062#idm139733898972624)
    - 1.2.62.3.2  [Delegation Order IT-6-6-1 (formerly MITS-6-6-1)](https://www.irs.gov/irm/part1/irm_01-002-062#idm139733898969776)
    - 1.2.62.3.3  [Delegation Order IT-6-6-2 (formerly MITS-6-6-2)](https://www.irs.gov/irm/part1/irm_01-002-062#idm139733898966880)
    - 1.2.62.3.4  [Delegation Order IT-6-6-3 (formerly MITS-6-6-3)](https://www.irs.gov/irm/part1/irm_01-002-062#idm139733898963968)
    - 1.2.62.3.5  [Delegation Order IT-6-6-4 (formerly MITS-6-6-4)](https://www.irs.gov/irm/part1/irm_01-002-062#idm139733898960432)
    - 1.2.62.3.6  [Delegation Order IT-6-14-1 (formerly MITS-6-14-1)](https://www.irs.gov/irm/part1/irm_01-002-062#idm139733898956896)

# Part 1. Organization, Finance, and Management

# Chapter 2. Servicewide Policies and Authorities

# Section 62. Division/Function Delegation of Authorities for Information Technology (IT)

* * *

## 1.2.62 Division/Function Delegation of Authorities for Information Technology (IT)

#### Manual Transmittal

May 01, 2025

#### Purpose

(1) This transmits revised IRM 1.2.62, Servicewide Policies and Authorities, Division/Function Delegation of Authorities for Information Technology (IT).

#### Material Changes

(1) _IRM 1.2.62.2.9_ Revised Delegation Order IT-2-1-1 (Rev. 1).

(2) _IRM 1.2.62.2.1_ Added delegation order IT-1-1-1 (rev 1) title to subsection.

(3) _IRM 1.2.62.2.2_ Added delegation order IT-1-23-1 (formerly MITS-1-23-1) title to subsection.

(4) _IRM 1.2.62.2.3_ Added delegation order IT-1-23-2 (formerly MITS-1-23-2) title to subsection.

(5) _IRM 1.2.62.2.4_ Added delegation order IT-1-23-5 (rev 1) title to subsection.

(6) _IRM 1.2.62.2.5_ Added delegation order IT-1-23-6 title to subsection.

(7) _IRM 1.2.62.2.6_ Added delegation order IT-1-23-7 title to subsection.

(8) _IRM 1.2.62.2.7_ Added delegation order IT-1-23-8 title to subsection.

(9) _IRM 1.2.62.2.8_ Added delegation order IT-1-23-9 title to subsection.

(10) _IRM 1.2.62.2.9_ Added delegation order IT-2-1-1 (rev 1) title to subsection.

(11) _IRM 1.2.62.2.10_ Added delegation order IT-2-1-1-A title to subsection.

(12) _IRM 1.2.62.2.11_ Added delegation order IT-2-1-2 title to subsection.

(13) _IRM 1.2.62.2.12_ Added delegation order IT-6-1-1 (formerly MITS-6-1-1, rev. 1) title to subsection.

(14) _IRM 1.2.62.2.13_ Added delegation order IT-11-2-4 (formerly MITS-11-2-4) title to subsection.

(15) _IRM 1.2.62.2.14_ Added delegation order IT-25-6-1 (formerly MITS-25-6-1) title to subsection.

(16) Updated subsections 1.2.62.2.1 through 1.2.62.2.14 to include link to appropriate Source Authority guidance.

#### Effect on Other Documents

IRM 1.2.62 dated June 21, 2024, is superseded.

#### Audience

All IT organizations

#### Effective Date

(05-01-2025)

Kaschit Pandya

Acting Chief Information Officer

**1.2.62.1** **(05-01-2025)**

### Overview

1. This IRM contains the Division/Function delegation orders issued by the Chief Information Officer (CIO) to the Information Technology (IT) organization. The CIO has delegated to the lowest level allowed within the organization. Every intervening line supervisory position has the same authority. Therefore, it is not necessary to do cascading re-delegations to lower the authority.

2. The format and numbering are consistent with guidance from Servicewide Policy, Directives and Electronic Resources (SPDER). For example, delegation order number IT-1-23-1 shows -



   - IT: the organization issuing the redelegation order

   - 1-23: the associated Service-wide delegation order

   - 1: a sequential number to indicate that more than one redelegation can be issued for each Service-wide delegation order.


3. The delegation orders are also available on the IT Internal Management Documents (IT IMD) SharePoint at IT Delegation Orders (sharepoint.com)

4. Questions about current IT delegation orders, including revisions or issuance of new delegation orders should be directed to the \*IT Internal Management Documents mailbox


**1.2.62.2** **(07-31-2018)**

### Delegations of Authority for Information Technology (IT)

1. Current IT Delegation Orders are listed in numerical sequence.

2. New and revised IT Delegation Orders approved after the publication of this IRM can be found on the IT Internal Management Documents (IT IMD) SharePoint at IT Delegation Orders (sharepoint.com).


**1.2.62.2.1** **(05-01-2025)**

#### Delegation Order IT-1-1-1 (Rev. 1), Order of Succession for Information Technology (IT)

1. _Order of Succession for Information Technology (IT)_

2. _Authority:_ To perform the functions of the Chief Information Officer (CIO), in the event of enemy attack on the United States, disaster, disability, or other emergency to ensure the continuity of the function of that office or division.

3. _Delegation to:_ Chief, Technology Officer. In the absence of this official, the authority is delegated to the Deputy CIO, Operations. In the absence of this official, the authority is delegated to Deputy CIO, Strategy/Modernization.

4. _Redelegation:_ This authority may not be redelegated.

5. _Source of Authority:_ Servicewide Delegation Order 1-1.

6. This order supercedes IT Delegation Order IT-1-1-1 dated August 10, 2021. To the extent that authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified.

7. Signed, Rajiv K. Uppal, Chief Information Officer, Information Technology


**1.2.62.2.2** **(05-01-2025)**

#### Delegation Order IT-1-23-1 (formerly MITS-1-23-1), Authority to Sign Written Materials

01. **Authority to Sign Written Materials**

02. **Authority:** To sign **for the Chief Information Officer**all memoranda, correspondence, directives, forms, etc., which do not require the attention of the Chief Information Officer.

03. **Delegated to:** Deputy Chief Information Officers.

04. **Redelegation:** This authority may not be redelegated.

05. **Authority:** To sign their own name, over their own title (if in their opinion the material set forth below does not require the attention of the Chief Information Officer).



    - All forms, letters, memoranda, instructional material (relating to the activities of their own organizations)

    - All memoranda to Treasury and other Government officials (that transmits various recurring reports)


06. **Delegated to:** Directors.

07. **Redelegation:** This authority may not be redelegated.



    ### Exception:



    Those documents excluded from authority to sign are as follows:





    - Documents or correspondence specifically identified by the Chief Information Officer as requiring his or her signature. This may include replies to correspondence addressed to the Chief Information Officer and signed by the Commissioner, Deputy Commissioner, or other Chief Officer.

    - Documents or correspondence concerned with policy, program, or organizational decisions unless governed by specific Delegation Orders.

    - Documents or correspondence concerned with staffing and budget if:


       – It responds to correspondence addressed to the Commissioner, Deputy Commissioner, Chief Information Officer, or other Chief Officer; or


       – It authorizes programs not covered by financial plans, or will have a substantial influence on existing resource allocations.

    - Documents or correspondence which require signature by the Commissioner, Deputy Commissioner, Chief Information Officer, or other Chief Officer, either because of the dignity of the document or because authority has not been redelegated or cannot be redelegated

    - Answers to Congressional correspondence addressed to the Commissioner, Deputy Commissioner, Chief Information Officer, or other Chief Officer. **Unless an exception has been made by the Chief Information Officer.**

    - Correspondence with those members of Congressional committees designated by the Commissioner.

    - Correspondence with the Joint Committee on Taxation, its staff, and foreign officials.

    - Replies to correspondence addressed to the Commissioner, Deputy Commissioner, Chief Information Officer, or other Chief Officer, by individuals who clearly regard themselves as friends or personal acquaintances of such officials.

    - Approval of their own travel voucher.

    - Approval of their own time and attendance data in SETR.


08. **Source of Authority:**Servicewide Delegation Order 1-23.

09. This order supersedes IT Delegation Order MITS-1-23-1. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified

10. Signed, S. Gina Garza, Chief Information Officer, Information Technology


**1.2.62.2.3** **(05-01-2025)**

#### Delegation Order IT-1-23-2 (formerly MITS-1-23-2), Authority to Sign Internal Management Documents

1. **Authority to Sign Internal Management Documents**

2. **Authority:** To sign for the Chief Information Officer all Form 2061, Document Clearance Records, associated with the Internal Management Document Clearance Process, which do not require the attention of the Chief Information Officer.

3. **Delegated to:** Director, Business Planning and Risk Management.

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23.

6. This order supersedes IT Delegation Order MITS-1-23-2. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified.

7. Signed, S. Gina Garza, Chief Information Officer, Information Technology


**1.2.62.2.4** **(05-01-2025)**

#### Delegation Order IT-1-23-5 (Rev. 1), Superior Qualifications Appointment Authority

1. **Superior Qualifications Appointment Authority**

2. **Authority:** To approve all superior qualifications appointments above the minimum rate of grade.

3. **Delegated to:** Associate Chief Information Officers.

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** IRM 6.531.1.1.8, Superior Qualifications and Special Pay-Setting Authority; Servicewide Delegation Order 1-23.

6. This order supersedes IT Delegation Order IT-1-23-5. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified.

7. Signed, S. Gina Garza, Chief Information Officer, Information Technology


**1.2.62.2.5** **(05-01-2025)**

#### Delegation Order IT-1-23-6, Information Technology (IT) Mission Critical Travel within the United States

1. _Information Technology (IT) Mission Critical Travel within the United States_

2. _Authority:_ Signature authority for approval of all IT Mission Critical Travel within the United States.

3. _Delegated to:_ Deputy Chief Information Officer for Operations. To authorize and approve official mission critical travel during a pandemic (including travel authorizations, travel advances, travel vouchers and travel and transportation payments for emergency purposes) for travel within the United States and its territories and possessions in accordance with the Federal Travel Regulation, IRM 1.32.1, IRS Local Travel Guide and IRM 1.32.11, IRS City-to-City Travel Guide.

4. _Redelegation:_ This authority may not be redelegated.

5. _Source of Authority:_ 5 USC 5707 and Servicewide Delegation Order 1-23.

6. Signed, Nancy A. Sieger, Chief Information Officer, Information Technology


**1.2.62.2.6** **(05-01-2025)**

#### Delegation Order IT-1-23-7, Information Technology (IT) Employee Misconduct unit Cases (EMU)

1. _Information Technology (IT) Employee Misconduct Unit Cases (EMU)_

2. _Authority:_ Signature authority for approval of all EMU cases.

3. _Delegated to:_ Deputy Chief Information Officer for Strategy and Modernization. The Deputy Chief Information Officer for Strategy and Modernization may approve all Information Technology Employee Misconduct Unit cases if he/she is not involved in the case.

4. _Redelegation:_ This authority may not be redelegated.

5. _Source of Authority:_ 5 USC 5707 and Servicewide Delegation Order 1-23.

6. Signed, Nancy A. Sieger, Chief Information Officer, Information Technology


**1.2.62.2.7** **(05-01-2025)**

#### Delegation Order IT-1-23-8, Information Technology (IT) Positions Outside of IT

1. _Information Technology (IT) Positions Outside of IT_

2. _Authority:_ Signature authority for approval of all IT Positions Outside the IT organization.

3. _Delegated to:_ Deputy Chief Information Officer for Strategy and Modernization.

4. _Redelegation:_ This authority may not be redelegated.

5. _Source of Authority:_ 5 USC 5707 and Servicewide Delegation Order 1-23.

6. Signed, Nancy A. Sieger, Chief Information Officer, Information Technology


**1.2.62.2.8** **(05-01-2025)**

#### Delegation Order IT-1-23-9, Approval of Information Technology (IT) GS-15

1. _Approval of Information Technology (IT) GS-15_

2. _Authority:_ Signature authority for approval of IT-GS-15.

3. _Delegated to:_ Deputy Chief Information Officer for Strategy and Modernization.

4. _Redelegation:_ This authority may not be redelegated.

5. _Source of Authority:_ 5 USC 5707 and Servicewide Delegation Order 1-23.

6. Signed, Nancy A. Sieger, Chief Information Officer, Information Technology


**1.2.62.2.9** **(05-01-2025)**

#### Delegation Order IT-2-1-1 (Rev. 1), Approve Information Technology (IT) Shopping Carts

01. _Approve Information Technology (IT) Shopping Carts_

02. _Authority 1:_ Unlimited signature authority for approval of shopping carts.

03. _Delegated to:_ Chief Technology Officer, Deputy Chief Information Officers, Associate Chief Information Officers and Deputy Associate Chief Information Officers.

04. _Redelegation:_ This authority may not be redelegated.

05. _Authority 2:_ Signature authority up to $500,000 for approval of shopping carts.

06. _Delegated to:_ Direct Report Executives and Executive Officers of the Associate Chief Information Officers and Deputy Associate Chief Information Officers.

07. _Redelegation:_ This authority may not be redelegated.

08. _Authority 3:_ Signature authority up to $50,000 for approval of shopping carts for non-IT goods or administrative services, and IT operating costs specifically associated with telecommunications recurring billing (i.e., local/long distance phone service).

09. _Delegated to:_ IT Senior and Frontline Managers.

10. _Redelegation:_ This authority may not be redelegated.

11. _Authority 4:_ Signature authority for approval of $0.00 shopping carts for accounting code changes.

12. _Delegated to:_ IT Strategy & Planning, Financial Management Services, Senior and Frontline Managers.

13. _Redelegation:_ This authority may not be redelegated.

14. _Source of Authority:_ Servicewide Delegation Order 2-1 (Rev. 2).

15. To the extent that authority previously exercised consistent with the order may require ratification, it is hereby affirmed and ratified. This order supersedes IT Delegation Order IT-2-1-1, effective October 1, 2028.

16. Signed, Rajiv Uppal, Chief Information Officer, Information Technology


**1.2.62.2.10** **(05-01-2025)**

#### Delegation Order IT-2-1-1-A, Consent to Approval of JOFOCs, JEFOs and LSJs

1. _Consent to Approval of JOFOCs, JEFOs and LSJs_

2. _Authority:_ Review and consent to approval of JOFOCs, JEFOs and LSJs over $5,000,000 and not exceeding $13,500,000 for IT.

3. _Delegated to:_ Deputy Chief Information Officers (DCIOs).

4. _Redelegation:_ This authority may not be redelegated.

5. _Source of Authority:_ Department of Treasury Acquisition Procedure (DTAP) FY18 Edition version 1.0, Subpart 1006.304 and Department of Treasury Acquisition Procedure Update (APU) 18-04.

6. Signed, S. Gina Garza, Chief Information Officer, Information Technology


**1.2.62.2.11** **(05-01-2025)**

#### Delegation Order IT-2-1-2, Authority to Approve Acquisition Plans (APs)

01. _Authority to Approve Acquisition Plans (APs)_

02. _Authority:_ Review and approve IT APs with a Total Contract Value (TCV) greater than or equal to $20M and less than $50M. (Note: Review and approval is needed by only one DCIO.)

03. _Delegated to:_ Deputy Chief Information Officers (DCIOs).

04. _Redelegation:_ This authority may not be redelegated.

05. _Authority:_ Review and approve IT APs with a TCV greater than or equal to $10M and less than $20M.

06. _Delegated to:_ Associate Chief Information Officers (ACIO), Strategy and Planning (S&P).

07. _Redelegation:_ This authority may not be redelegated.

08. _Authority:_ Review and approve IT APs with a TCV less than $10M. (Note: ACIOs \[unlimited\] and Directors \[up to $500K\] approve Shopping Carts and are expected to review associated documentation \[e.g., APs\].).

09. _Delegated to:_ IT Program Managers (PM), and Contracting Officer Representatives (COR).

10. _Redelegation:_ This authority may not be redelegated.

11. _Source of Authority:_ Treasury Department Memorandum for Bureau Chief Information Officers: Treasury Chief Information Officer Review and Approval of Information Technology Acquisitions, March 15, 2019. Servicewide Delegation Order 2-1.

12. Signed, Nancy A. Sieger, Chief Information Officer, Information Technology


**1.2.62.2.12** **(05-01-2025)**

#### Delegation Order IT-6-1-1 (formerly MITS-6-1-1, Rev. 1), Authority to Create and Abolish Positions

1. **Authority to Create and Abolish Positions**

2. **Authority:** To create and abolish positions. The abolishment of a position is defined as the actual termination of the position, with the duties eliminated entirely or combined with the duties of another position or positions.

3. **Delegated to:** Direct reports to the Chief Information Officer.

4. **Redelegation:**This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 6-1.

6. This order supersedes IT Delegation Order MITS-6-1-1 (Rev. 1). To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified.

7. Signed, S. Gina Garza, Chief Information Officer, Information Technology


**1.2.62.2.13** **(05-01-2025)**

#### Delegation Order IT-11-2-4 (formerly MITS-11-2-4), Disclosure of Personnel/Claimant Matters

1. **Disclosure of Personnel/Claimant Matters**

2. **Authority:** Disclosure of return and return information in personnel matters or claimant representative matters.

3. **Delegated to:** Supervisors at least one level above the supervisory level of the underlying matter.

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 11-2, Exhibit 1.2.49-1, see Authority 6103(l)(4).

6. This order supersedes IT Delegation Order MITS-11-2-4. To the extent that authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified.

7. Signed, S. Gina Garza, Chief Information Officer, Information Technology


**1.2.62.2.14** **(05-01-2025)**

#### Delegation Order IT-25-6-1 (formerly MITS-25-6-1), Cost of Complying With a Summons

1. **Cost of Complying With a Summons**

2. **Authority:** To obligate appropriated funds for payment of search costs, reproduction costs and transportation costs on connection with third party summonses.

3. **Delegated to:** Front-line managers.

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 25-6.

6. This order supersedes IT Delegation Order MITS-25-6-1. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified.

7. Signed, S. Gina Garza, Chief Information Officer, Information Technology


**1.2.62.3** **(07-31-2018)**

### Rescinded IT Delegation Orders

1. These are the rescinded IT Delegation Orders listed in numerical sequence. Rescinded delegation orders are cancelled and are no longer in effect.


**1.2.62.3.1** **(06-14-2021)**

#### Delegation Order IT-6-4-1 (formerly MITS-6-4-1)

1. _Authorization to Engage in Outside Employment, Business, and Other Activities_ is superseded by Service Delegation Order 6-4 (Rev. 1), Authorization to Engage in Outside Employment, Business, and Other Activities, grants the necessary authority to the lowest allowed level and does not allow for re-delegation. Therefore, IT Delegation Order IT-6-4-1 (formerly MITS-6-4-1) is cancelled.

2. Signed, Nancy A. Sieger, Chief Information Officer, Information Technology


**1.2.62.3.2** **(06-14-2021)**

#### Delegation Order IT-6-6-1 (formerly MITS-6-6-1)

1. _Adverse, Disciplinary, and Other Actions_ is superseded by Service Delegation Order 6-24, Delegation of Authorities to Initiate and Approve Personnel Actions, grants the necessary authority to the lowest allowed level and does not allow for re-delegation. Therefore, IT Delegation Order IT-6-6-1 (formerly MITS-6-6-1) is cancelled.

2. Signed, Nancy A. Sieger, Chief Information Officer, Information Technology


**1.2.62.3.3** **(06-14-2021)**

#### Delegation Order IT-6-6-2 (formerly MITS-6-6-2)

1. _Requests for Personnel Actions, Standard Forms 52 and 50_ is superseded by Service Delegation Order 6-24, Delegation of Authorities to Initiate and Approve Personnel Actions, grants the necessary authority to the lowest allowed level and does not allow for re-delegation. Therefore, IT Delegation Order IT-6-6-2 (formerly MITS-6-6-2) is cancelled.

2. Signed, Nancy A. Sieger, Chief Information Officer, Information Technology


**1.2.62.3.4** **(06-14-2021)**

#### Delegation Order IT-6-6-3 (formerly MITS-6-6-3)

1. _Performance Evaluation_ is superseded by Service Delegation Order 6-22, Authority to Approve Monetary and Time-Off Performance Awards, Performance Bonuses, Individual and Group Special Act Awards, Managers’ Awards, Bilingual Awards, Honorary Awards, Employee Suggestion Awards, Informal Recognition, and Quality Step Increases, grants the necessary authority to the lowest allowed level and does not allow for re-delegation. Therefore, IT Delegation Order IT-6-6-3 (formerly MITS-6-6-3) is cancelled.

2. Signed, Nancy A. Sieger, Chief Information Officer, Information Technology


**1.2.62.3.5** **(06-14-2021)**

#### Delegation Order IT-6-6-4 (formerly MITS-6-6-4)

1. _Awards_ is superseded by Service Delegation Order 6-22, Authority to Approve Monetary and Time-Off Performance Awards, Performance Bonuses, Individual and Group Special Act Awards, Managers’ Awards, Bilingual Awards, Honorary Awards, Employee Suggestion Awards, Informal Recognition, and Quality Step Increases, grants the necessary authority to the lowest allowed level and does not allow for re-delegation. Therefore, IT Delegation Order IT-6-6-4 (formerly MITS-6-6-4) is cancelled.

2. Signed, Nancy A. Sieger, Chief Information Officer, Information Technology


**1.2.62.3.6** **(06-14-2021)**

#### Delegation Order IT-6-14-1 (formerly MITS-6-14-1)

1. _Overtime_ is superseded by Service Delegation Order 6-23, Delegations of Authority to Accomplish Pay Administration, grants the necessary authority to the lowest allowed level and does not allow for re-delegation. Therefore, IT Delegation Order MITS-6-14-1 (formerly MITS-6-14-1) is cancelled.

2. Signed, Nancy A. Sieger, Chief Information Officer, Information Technology


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-002-062#addtoany "Show all")

A2A