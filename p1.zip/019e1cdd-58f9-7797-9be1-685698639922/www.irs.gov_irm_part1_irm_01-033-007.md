---
url: "https://www.irs.gov/irm/part1/irm_01-033-007"
title: "1.33.7 User Fees | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-033-007#main-content)

- 1.33.7  [User Fees](https://www.irs.gov/irm/part1/irm_01-033-007#id1)
  - 1.33.7.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-033-007#id2)
    - 1.33.7.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-033-007#id3)
    - 1.33.7.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-033-007#id4)
    - 1.33.7.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-033-007#id5)
      - 1.33.7.1.3.1  [CFO and Deputy CFO](https://www.irs.gov/irm/part1/irm_01-033-007#id7)
      - 1.33.7.1.3.2  [Associate and Deputy Associate CFO for Corporate Budget](https://www.irs.gov/irm/part1/irm_01-033-007#id8)
      - 1.33.7.1.3.3  [Cost and User Fees Office](https://www.irs.gov/irm/part1/irm_01-033-007#id9)
      - 1.33.7.1.3.4  [Revenue Accounting Operations Office](https://www.irs.gov/irm/part1/irm_01-033-007#id10)
      - 1.33.7.1.3.5  [Financial Reporting and Analysis Office](https://www.irs.gov/irm/part1/irm_01-033-007#id11)
      - 1.33.7.1.3.6  [Financial Management Systems Office](https://www.irs.gov/irm/part1/irm_01-033-007#id12)
      - 1.33.7.1.3.7  [Government Payables and Funds Management Office](https://www.irs.gov/irm/part1/irm_01-033-007#id13)
      - 1.33.7.1.3.8  [IT Division](https://www.irs.gov/irm/part1/irm_01-033-007#id14)
      - 1.33.7.1.3.9  [Business Units](https://www.irs.gov/irm/part1/irm_01-033-007#id15)
    - 1.33.7.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-033-007#id16)
    - 1.33.7.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-033-007#id17)
    - 1.33.7.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-033-007#id18)
    - 1.33.7.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-033-007#id19)
    - 1.33.7.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-033-007#id20)
  - 1.33.7.2  [Requirements for Deposit of Funds](https://www.irs.gov/irm/part1/irm_01-033-007#id21)
  - 1.33.7.3  [31 USC 9701, Fees and Charges for Government Services and Things of Value](https://www.irs.gov/irm/part1/irm_01-033-007#id22)
    - 1.33.7.3.1  [OMB Circular A-25, User Charges](https://www.irs.gov/irm/part1/irm_01-033-007#id24)
  - 1.33.7.4  [26 USC 7521, Procedures Involving Taxpayer Interviews](https://www.irs.gov/irm/part1/irm_01-033-007#id25)
  - 1.33.7.5  [26 USC 7528, Internal Revenue Service User Fees](https://www.irs.gov/irm/part1/irm_01-033-007#id26)
  - 1.33.7.6  [26 USC 6103, Confidentiality and Disclosure of Returns and Return Information](https://www.irs.gov/irm/part1/irm_01-033-007#id27)
  - 1.33.7.7  [26 USC 6104, Publicity of Information Required from Certain Exempt Organizations and Certain Trusts](https://www.irs.gov/irm/part1/irm_01-033-007#id28)
  - 1.33.7.8  [26 USC 6108, Statistical Publications and Studies](https://www.irs.gov/irm/part1/irm_01-033-007#id29)
  - 1.33.7.9  [26 USC 6110, Public Inspection of Written Determinations](https://www.irs.gov/irm/part1/irm_01-033-007#id30)
  - 1.33.7.10  [The Pension Protection Act of 2006](https://www.irs.gov/irm/part1/irm_01-033-007#id31)
  - 1.33.7.11  [The Freedom of Information Act](https://www.irs.gov/irm/part1/irm_01-033-007#id32)
  - 1.33.7.12  [The Tax Increase Prevention Act of 2014](https://www.irs.gov/irm/part1/irm_01-033-007#id33)
  - 1.33.7.13  [Receipt and Deposit of User Fees](https://www.irs.gov/irm/part1/irm_01-033-007#id34)
  - 1.33.7.14  [Costing User Fees](https://www.irs.gov/irm/part1/irm_01-033-007#id35)
  - 1.33.7.15  [Biennial Review of User Fees](https://www.irs.gov/irm/part1/irm_01-033-007#id36)
  - 1.33.7.16  [Annual Monitoring/Review](https://www.irs.gov/irm/part1/irm_01-033-007#id37)
  - 1.33.7.17  [Types of IRS User Fees](https://www.irs.gov/irm/part1/irm_01-033-007#id38)
    - 1.33.7.17.1  [Installment Agreements](https://www.irs.gov/irm/part1/irm_01-033-007#id40)
    - 1.33.7.17.2  [Offers in Compromise](https://www.irs.gov/irm/part1/irm_01-033-007#id41)
    - 1.33.7.17.3  [Estate Tax Closing Letters](https://www.irs.gov/irm/part1/irm_01-033-007#id42)
    - 1.33.7.17.4  [Interview Recordings and Transcripts](https://www.irs.gov/irm/part1/irm_01-033-007#id43)
    - 1.33.7.17.5  [Enrollments and Enrollment Renewals of Enrolled Actuaries](https://www.irs.gov/irm/part1/irm_01-033-007#id44)
    - 1.33.7.17.6  [Enrollments and Enrollment Renewals of Enrolled Agents](https://www.irs.gov/irm/part1/irm_01-033-007#id45)
    - 1.33.7.17.7  [Special Enrollment Examinations for Enrolled Agents](https://www.irs.gov/irm/part1/irm_01-033-007#id46)
    - 1.33.7.17.8  [Preparer Tax Identification Numbers](https://www.irs.gov/irm/part1/irm_01-033-007#id47)
    - 1.33.7.17.9  [Appeals Advanced Art Valuation Determinations](https://www.irs.gov/irm/part1/irm_01-033-007#id48)
    - 1.33.7.17.10  [Chief Counsel Rulings and Determination Letters](https://www.irs.gov/irm/part1/irm_01-033-007#id49)
    - 1.33.7.17.11  [TE/GE Determination Letters, Information Letters and Other Guidance](https://www.irs.gov/irm/part1/irm_01-033-007#id50)
    - 1.33.7.17.12  [LB&I Determination Letters](https://www.irs.gov/irm/part1/irm_01-033-007#id51)
    - 1.33.7.17.13  [SB/SE Determination Letters](https://www.irs.gov/irm/part1/irm_01-033-007#id52)
    - 1.33.7.17.14  [U.S. Residency Certifications](https://www.irs.gov/irm/part1/irm_01-033-007#id53)
    - 1.33.7.17.15  [Income Verification Express Service](https://www.irs.gov/irm/part1/irm_01-033-007#id54)
    - 1.33.7.17.16  [Reproductions of Individual and Business Tax Returns](https://www.irs.gov/irm/part1/irm_01-033-007#id55)
    - 1.33.7.17.17  [Reproductions of Exempt Organizations Returns](https://www.irs.gov/irm/part1/irm_01-033-007#id56)
    - 1.33.7.17.18  [Public Use Files](https://www.irs.gov/irm/part1/irm_01-033-007#id57)
    - 1.33.7.17.19  [Public Inspections of Written Determination Background File Documents](https://www.irs.gov/irm/part1/irm_01-033-007#id58)
    - 1.33.7.17.20  [Historical Conservation Easements](https://www.irs.gov/irm/part1/irm_01-033-007#id59)
    - 1.33.7.17.21  [Freedom of Information Act Requests](https://www.irs.gov/irm/part1/irm_01-033-007#id60)
    - 1.33.7.17.22  [Certified Professional Employer Organizations](https://www.irs.gov/irm/part1/irm_01-033-007#id61)

# Part 1. Organization, Finance, and Management

# Chapter 33. Strategic Planning, Budgeting and Performance Management Process

# Section 7. User Fees

* * *

## 1.33.7 User Fees

#### Manual Transmittal

August 21, 2025

#### Purpose

(1) This transmits revised IRM 1.33.7, Strategic Planning, Budgeting and Performance Management Process, User Fees.

#### Material Changes

(1) IRM 1.33.7.1.2, Authorities – Deleted reference (formerly ‘q’) to the No Surprises Act, as the IRS is no longer involved with the related user fee.

(2) IRM 1.33.7.1.4, Program Management and Review – Updated to more accurately describe the existing reviews performed by the Cost and User Fee office and the business units.

(3) IRM 1.33.7.1.5(1)f, Program Controls – Added SharePoint folder to share drive reference, as CFO office files are migrating there.

(4) IRM 1.33.7.1.6, Terms/Definitions – Added “legacy system,” definition and removed “sustaining costs,” as the term is no longer in this IRM.

(5) IRM 1.33.7.1.7, Acronyms – Removed ‘IDR’ and ‘RS-PCC,’ as these acronyms are no longer in this IRM.

(6) IRM 1.33.7.1.8, Related Resources – Added reference to new CFO Interim Guidance for Estimating Costs.

(7) Prior IRM 1.33.7.13, The No Surprises Act – Deleted section, as this legislation established services for a user fee with which the IRS is no longer involved. The work and associated fee processing is now completely managed by the Department of Health and Human Services (HHS).

(8) IRM 1.33.7.15(3), Biennial Review of User Fees – Clarified the specific office responsible for preparing the report and presenting the review results.

(9) IRM 1.33.7.17, Types of IRS User Fees - Deleted “Independent Dispute Resolutions” from Types of IRS User Fees.

(10) IRM 1.33.7.17.13, SB/SE Determination Letters – Added section.

(11) IRM 1.33.7.17.14(4), U.S. Residency Certifications - Added reference to checks and money orders payments.

(12) IRM 1.33.7.17.21, Freedom of Information Act Requests – Updated information on how fees are received.

(13) IRM 1.33.7.18.22, Independent Dispute Resolutions – Deleted section. The IRS is no longer involved in processing these user fees. The services are administered by HHS; and HHS also handles all costing, collections, and reporting related to the user fees.

(14) Throughout IRM – Made minor writing edits for clarity and precision.

#### Effect on Other Documents

IRM 1.33.7, dated June 22, 2023, is superseded.

#### Audience

Business unit finance offices and employees responsible for managing user fee activities.

#### Effective Date

(08-21-2025)

Anthony S. Chavez

Acting Chief Financial Officer

**1.33.7.1** **(06-22-2023)**

### Program Scope and Objectives

1. Purpose: The User Fees IRM provides information for implementing user fees and reviewing user fee activities, rates and reports.

2. Audience: Business unit finance offices and employees responsible for managing user fee activities consult this guidance.

3. Policy Owner: The CFO is responsible for this IRM.

4. Program Owner: The CFO’s Cost and User Fees office oversees user fee activities.

5. Primary Stakeholders: Business units that charge user fees implement this program.

6. Program Goals: This helps ensure internal controls for user fee collection are implemented and activity cost calculations are accurate and consistent.


**1.33.7.1.1** **(06-22-2023)**

#### Background

1. The IRS implemented user fees when the Independent Offices Appropriations Act of 1952 was passed. This act, codified by 31 U.S. Code (USC) 9701, [Fees and charges for Government services and things of value,](http://uscode.house.gov/view.xhtml?req=(title:31%20section:9701%20edition:prelim)) authorizes agencies to prescribe regulations that establish charges where the government provides special benefits to a recipient beyond those given to the general public. Regulations implementing user fees are subject to policies prescribed by the president in the Office of Management and Budget (OMB) Circular A-25, _User charges_. When the IRS began implementing user fees under this authority, receipts were deposited to the government’s general fund.

2. Subsequent legislation permitted the IRS to retain and spend a portion of the user fees collected. The Treasury, Postal Service, and General Government Appropriations Act of 1995 authorized the IRS to expend up to $119 million per fiscal year of new or increased user fee receipts based on the cost of providing services. The annual spending cap was eliminated in the Transportation, Treasury, Housing and Urban Development, the Judiciary, the District of Columbia, and the Independent Agencies Appropriations Act of 2006. Public Law (PL) 109-115.

3. The Bipartisan Budget Act of 2018 modified user fee requirements for installment agreements, limiting fees to those in effect at its enactment and waiving fees for low-income taxpayers who enter direct debit installment agreements. It also established reimbursement for low-income taxpayers who completed an installment agreement and were unable to make electronic debit payments.


**1.33.7.1.2** **(08-21-2025)**

#### Authorities

1. The authorities for this IRM include:



01. [Treasury, Postal Service, and General Government Appropriations Act of 1995](https://www.congress.gov/bill/104th-congress/house-bill/3756), PL 103–329

02. [Transportation, Treasury, Housing and Urban Development, the Judiciary, the District of Columbia, and the Independent Agencies Appropriations Act of 2006](https://www.congress.gov/bill/109th-congress/house-bill/3058), PL 109–115

03. [Pension Protection Act of 2006](https://www.congress.gov/bill/109th-congress/house-bill/4), PL 109–280

04. [Tax Increase Prevention Act of 2014,](https://www.taxnotes.com/research/federal/legislative-documents/public-laws-and-legislative-history/tax-increase-prevention-act-of-2014-p.l-113-295/dv3r) PL 113-295

05. [Freedom of Information Act, Vol VIII, No. 1](https://www.justice.gov/archives/oip/blog/foia-update-index-foia-update-volumes-i-viii-1979-1987), PL 114-185

06. 26 USC 482, [Allocation of income and deductions among taxpayers](https://www.law.cornell.edu/cfr/text/26/1.482-1)

07. 26 USC 6103, [Confidentiality and disclosure of returns and return information](https://www.law.cornell.edu/uscode/text/26/6103)

08. 26 USC 6104, [Publicity of information required from certain exempt organizations and certain trusts](https://www.law.cornell.edu/uscode/text/26/6104)

09. 26 USC 6108, [Statistical publications and studies](https://www.law.cornell.edu/uscode/text/26/6108#:~:text=The%20Secretary%20shall%20prepare%20and,any%20other%20facts%20deemed%20pertinent)

10. 26 USC 6110, [Public inspection of written determinations](https://www.govinfo.gov/app/details/USCODE-2011-title26/USCODE-2011-title26-subtitleF-chap61-subchapB-sec6110)

11. 26 USC 7521, [Procedures involving taxpayer interviews](https://www.law.cornell.edu/uscode/text/26/7521)

12. 26 USC 7528, [Internal Revenue Service user fees](https://www.law.cornell.edu/uscode/text/26/7528)

13. 31 USC 3302, [Custodians of money](https://uscode.house.gov/view.xhtml?req=(title:31%20section:3302%20edition:prelim))

14. 26 USC 7809, [Deposit of collections](https://www.law.cornell.edu/uscode/text/26/7809)

15. 31 USC 9701, [Fees and charges for Government services and things of value](https://www.law.cornell.edu/uscode/text/31/9701)

16. [Bipartisan Budget Act of 2018,](https://www.govinfo.gov/app/details/PLAW-115publ123) PL 115-123


**1.33.7.1.3** **(06-22-2023)**

#### Responsibilities

1. This section provides responsibilities for the:



1. CFO and Deputy CFO

2. Associate and Deputy Associate CFO for Corporate Budget

3. Cost and User Fees office

4. Revenue Accounting Operations office

5. Financial Reporting and Analysis office

6. Financial Management Systems office

7. Government Payables and Funds Management office

8. IT division

9. Business units


**1.33.7.1.3.1** **(06-22-2023)**

##### CFO and Deputy CFO

1. The CFO and Deputy CFO oversee the IRS user fee program’s policies and controls that ensure compliance with applicable authorities.


**1.33.7.1.3.2** **(06-22-2023)**

##### Associate and Deputy Associate CFO for Corporate Budget

1. The Associate and Deputy Associate CFO for Corporate Budget are responsible for ensuring policies, procedures, standards and controls for costing, reporting, and spending user fees are in place. This includes:



1. Leading the biennial review process, including obtaining approval for user fee rates and coordinating OMB Circular A-25, _User charges_, full cost requirements.

2. Responding to user fee audits performed by the Government Accountability Office or the Treasury Inspector General for Tax Administration.

3. Overseeing the implementation of new user fees and rate revisions.

4. Determining, with senior IRS leadership, the use of user fee funds and preparing the user fee plan for OMB.

5. Posting anticipated collections in IFS.

6. Completing Standard Forms 1151, Non-Expenditure Transfer Authorizations.

7. Transferring user fees between the parent account and IRS appropriated accounts.

8. Recording apportionments.


**1.33.7.1.3.3** **(06-22-2023)**

##### Cost and User Fees Office

1. The Cost and User Fees office reports to the Deputy Associate CFO for Corporate Budget and is responsible for:



1. Developing policies, leading biennial reviews and providing guidance to the business units for implementing and monitoring user fees.

2. Calculating the annual corporate overhead rate used in the business unit cost calculations.

3. Monitoring transaction volumes and user fee receipt revenue in comparison to projections and researching unexpected variances.

4. Validating and monitoring user fee costing and processes.

5. Developing Unified Work Requests (UWRs) for system updates in support of user fee transactions and reporting.

6. Reconciling user fee deposits and Central Accounting Reporting System (CARS) monthly reports to supporting documentation from the business units, including variance explanations.

7. Preparing user fee collection reports, the President's Budget Receipt Estimates and user fee deliverables to support the Government Accountability Office’s financial statement audit.

8. Working with business units to review and revise user fee collection processes, including the use of Pay.gov and the Over-the-Counter Channel Application (OTCnet) to streamline deposits.

9. Providing the proposed year-end user fee entry to the Financial Reporting and Analysis office for review and posting, as appropriate.


**1.33.7.1.3.4** **(06-22-2023)**

##### Revenue Accounting Operations Office

1. The Revenue Accounting Operations office reports to the Associate CFO for Revenue Financial Accounting and is responsible for:



1. Ensuring CFO RACS units provide monthly reports of installment agreement user fee collections to the Cost and User Fees office.


**1.33.7.1.3.5** **(06-22-2023)**

##### Financial Reporting and Analysis Office

1. The Financial Reporting and Analysis office reports to the Associate CFO for Corporate Accounting and is responsible for:



1. Preparing and posting a non-standard Treasury Form 224 entry into the Integrated Financial System (IFS) monthly and at fiscal year-end to record user fee collections initially recorded in the Redesigned Revenue Accounting and Control System (RRACS).

2. Providing monthly interim RRACS reports to the Cost and User Fees office three business days before the end of each month.

3. Preparing monthly analyses comparing CARS data with IFS user fee activity and reconciling budgetary and proprietary user fee general ledger balances.

4. Providing year-end RRACS reports to the Cost and User Fees office within two business days after the fiscal year-end.


**1.33.7.1.3.6** **(06-22-2023)**

##### Financial Management Systems Office

1. The Financial Management Systems office reports to the Associate CFO for Revenue Financial Accounting and is responsible for:



1. Maintaining the exchange of information between IFS, the Transcript Delivery System and Pay.gov.

2. Supporting systemic changes and UWRs for CFO RACS units' system functionalities.


**1.33.7.1.3.7** **(06-22-2023)**

##### Government Payables and Funds Management Office

1. The Government Payables and Funds Management office reports to the Associate CFO for Corporate Accounting and is responsible for:



1. Depositing and recording checks received for user fees.

2. Notifying business units of any user fee receipts originating outside the business units.


**1.33.7.1.3.8** **(06-22-2023)**

##### IT Division

1. The IT division is responsible for:



1. Posting weekly installment agreement provided through an annual UWR to Control D.

2. Producing monthly installment agreement and offer in compromise reports provided through an annual UWR to the CFO Accounts Receivable Management System.

3. Providing nine- and twelve-month files of installment agreement user fees to the CFO based on UWR requirements.


**1.33.7.1.3.9** **(06-22-2023)**

##### Business Units

1. The business units are responsible for:



01. Collecting and reporting user fees within their program areas.

02. Developing quarterly estimates of projected volumes and revenue, and annual estimates for ten subsequent years for the Cost and User Fees office.

03. Providing the Cost and User Fees office with monthly activity reports and explanations of actual to budget variances within three days of the end of the month.

04. Executing the biennial review of user fee activities, including maintaining documentation to support cost estimates.

05. Maintaining and tracking information on revenue and volumes to support financial audits.

06. Implementing changes to legacy systems used to monitor user fees.

07. Sending the daily deposit tickets that support IFS revenue entries to the Cost and User Fees office within 24 hours.

08. Researching debit vouchers and updating case load systems’ payment information.

09. Submitting refund schedules with original collection dates to the Cost and User Fees office.

10. Reviewing activities annually for potential new user fees or necessary revisions to existing user fee rates or activities.


**1.33.7.1.4** **(08-21-2025)**

#### Program Management and Review

1. The Cost and User Fees office uses the following reports to monitor user fee collections and analyze variances from prior collections and business unit projections:



1. Commissioner’s chart

2. Biennial Review of User Fee Charges report

3. Offer in compromise analysis

4. Installment agreement analysis


2. Business units assess the effectiveness of user fee programs by evaluating participation levels, workload reductions, participant feedback and other relevant factors.


**1.33.7.1.5** **(08-21-2025)**

#### Program Controls

1. The Cost and User Fees office is responsible for:



1. Analyzing monthly volume and revenue information.

2. Reviewing supporting documentation to ensure user fee collections are classified and recorded correctly.

3. Developing the corporate overhead rate and managing the allocation cycles to ensure consistent costing methodologies for business units.

4. Reviewing the business unit costing documents submitted during the biennial review to ensure accuracy and consistency.

5. Ensuring preparers, reviewers and approvers have separate roles and responsibilities.

6. Saving reports and supporting documentation on a shared drive or SharePoint folder with access limited to users with the appropriate job requirements.


2. Business units are responsible for:



1. Reviewing user fee charges every two years to ensure rates are adjusted to reflect changes in costs and to determine if other agency programs should assess fees.

2. Implementing internal controls (e.g., management reviews, system access) applicable to their specific user fee processes.


**1.33.7.1.6** **(08-21-2025)**

#### Terms/Definitions

1. The following terms and definitions apply to this program:



01. **Art** \- Paintings, sculptures, watercolors, prints, drawings, ceramics, antique furniture, decorative arts, textiles, carpets, silver, rare manuscripts and other similar objects.

02. **Costs** \- The monetary value of resources used in performing activities or in acquiring or producing goods and services.

03. **Corporate overhead rate** \- The rate calculated annually by the Cost and User Fees office and applied to total labor and benefit costs to determine the full cost of providing services.

04. **Direct costs** \- The costs incurred directly by programs due to their budget execution. These include salaries, benefits, consulting, materials, supplies, etc.

05. **Full cost** \- All costs used in generating activities, products and services, including direct, indirect and imputed costs.

06. **Imputed costs** \- The unreimbursed costs required to be recognized by accounting standards.

07. **Indirect costs** \- The costs of resources that are jointly or commonly used and cannot be reasonably identified and charged to a specific activity.

08. **Legacy System** \- A system is designated as legacy if it measurably obstructs IRS mission-critical outcomes by limiting functionality essential to key operations or business objectives; increasing operational risk (e.g., security vulnerabilities, system failures); or degrading performance (e.g., causing delays or inefficiencies). Legacy status is determined by impact on the agency’s evolving mission requirements, regardless of system age, programming language, or vendor support status.

09. **Market price** \- Price for goods, resources or services based on a competitive open market that creates neither a shortage nor a surplus of the goods, resources or services.

10. **Overhead** \- Support costs not directly identifiable to a business unit functional area.

11. **Special benefits** \- Privileges, goods or services that give recipients benefits beyond those available to the general public.

12. **Support costs**\- The business unit costs that primarily support other IRS business units.

13. **User fees** \- Charges levied by a federal agency on individuals or entities directly benefiting from a service provided by a government program or activity. User fees are charged for federal activities that provide recipients with benefits greater than those provided to the general public.


**1.33.7.1.7** **(08-21-2025)**

#### Acronyms

1. The following acronyms apply to this program:




| **Acronym** | **Definition** |
| --- | --- |
| FOIA | The Freedom of Information Act |
| HHS | Department of Health and Human Services |
| IA | Installment Agreement |
| IFS | Integrated Financial System |
| IVES | Income Verification Express Service |
| OTCnet | Over-the-Counter Channel Application |
| OIC | Offer in Compromise |
| OMB | Office of Management and Budget |
| PL | Public Law |
| PO | Post Office |
| PTIN | Preparer Tax Identification Number |
| RACS | Revenue Accounting and Control System |
| RRACS | Redesigned Revenue Accounting and Control System |
| USC | United States Code |
| UWR | Unified Work Request |


**1.33.7.1.8** **(08-21-2025)**

#### Related Resources

1. IRM 1.33.5, Managerial Costing

2. CFO-01-0924-0001, [Interim Guidance for Estimating Costs, issued September 18, 2024 (to be included in IRM 1.33.9, Cost Estimating Guidelines)](https://spder.web.irs.gov/imdtrack/IG_Uploads/IRS.gov_No/cfo-01-0924-0001.pdf)

3. Federal User Fees, [A Design Guide (General Accountability Office-08-386SP)](https://www.gao.gov/products/gao-08-386sp)

4. OMB Circular A-25, [User charges](https://obamawhitehouse.archives.gov/omb/circulars_a025/)


**1.33.7.2** **(06-22-2023)**

### Requirements for Deposit of Funds

1. 31 USC 3302, Custodians of money, specifies that agencies must promptly deposit any funds received for government use to the general fund, absent specific statutory authority.

2. Treasury, Postal Service and General Appropriations Act, 1995, PL 103–329, provided the authority for the IRS to retain and spend up to $119 million per fiscal year of new or increased user fee receipts implemented as of September 30, 1994. The 2006 Treasury Appropriation Act, PL 109–115, removed the annual $119 million ceiling.

3. 26 USC 7809, Deposit of collections, authorizes that user fee receipts can reimburse the appropriation that incurred expenses under the following code sections:



1. 26 USC 6103, Confidentiality and disclosure of returns and return information

2. 26 USC 6108, Statistical publications and studies

3. 26 USC 6110, Public inspection of written determinations


4. The 2006 Pension Protection Act, PL 109-280, requires user fees collected for historic conservation easements to be spent on enforcement activities for charitable contribution deductions for historic conservation easements. This public law is codified in 26 USC 170(f)(13), Charitable, etc., contributions and gifts.


**1.33.7.3** **(06-22-2023)**

### 31 USC 9701, Fees and Charges for Government Services and Things of Value

1. 31 USC 9701, Fees and charges for Government services and things of value, provides for the collection of user fees where the government provides special benefits to recipients beyond those given to the general public. The IRS collects fees not covered by other legislation under this authority.

2. The IRS implements user fees under Section 9701 by regulation.

3. In accordance with OMB Circular A-25, the implementation guidance for Section 9701, the IRS charges full cost or obtains a waiver from OMB to charge less than full cost.

4. The IRS collects fees under Section 9701 for the following activities:



1. Installment agreements, _IRM 1.33.7.17.1_

2. Offers in compromise, _IRM 1.33.7.17.2_

3. Estate tax closing letters, _IRM 1.33.7.17.3_

4. Interview recordings and transcripts, _IRM 1.33.7.17.4_

5. Enrollments and enrollment renewals of enrolled actuaries, _IRM 1.33.7.17.5_

6. Enrollments and enrollment renewals of enrolled agents, _IRM 1.33.7.17.6_

7. Special enrollment examinations for enrolled agents, _IRM 1.33.7.17.7_

8. Preparer tax identification numbers, _IRM 1.33.7.17.8_


**1.33.7.3.1** **(06-22-2023)**

#### OMB Circular A-25, User Charges

1. The OMB Circular A-25, [User charges,](https://obamawhitehouse.archives.gov/omb/circulars_a025/) provides guidance to government agencies for establishing and charging user fees for special benefits provided to recipients beyond those given to the general public. The charge imposed recovers full cost to the federal government for providing the special benefit or the market price.

2. Full cost includes all direct and indirect costs to any part of the federal government for providing a good, resource or service.

3. A special benefit enables the beneficiary to obtain more immediate or substantial gains or values than those given to the general public, provides business stability or contributes to public confidence in the business activity or beneficiary, or is performed at the request of or for the convenience of the recipient. It is beyond the services regularly received by other members of the same industry or group or the general public.

4. Market price is the price for the good, resource or service based on competition in open markets and creates neither a shortage nor a surplus of the good. When a substantial competitive demand exists, competitive bidding or reference to prevailing prices in competitive markets for goods, resources or services that are similar to those provided by the government determines the market price.

5. Agency heads or their designees may recommend to OMB exceptions to the general policy when the cost of collecting the fees would represent an unduly large part of the fee for the activity or any other condition exists that, in the opinion of the agency head or his or her designee, justifies an exception. IRS considers the implication of the user fee on low-income taxpayers, tax administration, taxpayer rights and cost of collecting the fees when determining the user fee rate and whether to request a waiver.


**1.33.7.4** **(06-22-2023)**

### 26 USC 7521, Procedures Involving Taxpayer Interviews

1. 26 USC Section 7521, Procedures involving taxpayer interviews, requires the IRS to collect a fee from taxpayers who request a transcript or copy of an audio recording made by an IRS officer or employee in connection with an in-person interview relating to tax determinations or collections.

2. The fees reimburse the IRS for transcription and reproduction costs, which are independently calculated for each request. _IRM 1.33.7.17.4_


**1.33.7.5** **(06-22-2023)**

### 26 USC 7528, Internal Revenue Service User Fees

1. 26 USC Section 7528, Internal Revenue Service user fees, requires the IRS to collect a user fee for ruling letters, opinion letters, determination letters and other similar requests.

2. The IRS fees, including user fees under Section 7528, are implemented through the issuance of published guidance.

3. This legislation authorizes the IRS to charge a reasonable fee; however, it sets a floor based on the historical average cost.

4. The IRS collects the following fees under Section 7528:



1. Appeals advanced art valuation determinations, _IRM 1.33.7.17.9_

2. Chief Counsel rulings and determination letters, _IRM 1.33.7.17.10_

3. TE/GE determination letters, information letters and other guidance, _IRM 1.33.7.17.11_

4. LB&I determination letters, _IRM 1.33.7.17.12_

5. SB/SE determination letters, _IRM 1.33.7.17.13_


**1.33.7.6** **(06-22-2023)**

### 26 USC 6103, Confidentiality and Disclosure of Returns and Return Information

1. 26 USC 6103, Confidentiality and disclosure of returns and return information, authorizes the IRS to charge a reasonable fee for reproducing returns and disclosing return information.

2. The IRS fees, including user fees under Section 6103, are implemented through the issuance of published guidance.

3. The IRS collects the following fees under Section 6103:



1. U.S. residency certifications, _IRM 1.33.7.17.14_

2. Income Verification Express Service, _IRM 1.33.7.17.15_

3. Reproductions of individual and business tax returns, _IRM 1.33.7.17.16_


**1.33.7.7** **(06-22-2023)**

### 26 USC 6104, Publicity of Information Required from Certain Exempt Organizations and Certain Trusts

1. 26 USC 6104, Publicity of information required from certain exempt organizations and certain trusts, authorizes the IRS to charge a reasonable fee for reproducing and mailing costs for annual returns, reports, applications for exemption, and notice status of certain exempt organizations.

2. The IRS implements user fees under Section 6104 through an announcement or revenue procedure.

3. The IRS collects the user fee for reproducing exempt organizations’ returns under this authority. _IRM 1.33.7.17.17_


**1.33.7.8** **(06-22-2023)**

### 26 USC 6108, Statistical Publications and Studies

1. 26 USC 6108, Statistical publications and studies, authorizes the IRS to charge a reasonable fee for providing statistical studies and complications involving return information and to furnish those to taxpayers upon written request.

2. The IRS implements user fees under Section 6108 through an announcement or revenue procedure.

3. The IRS collects a user fee for public use files under this authority (requests for special statistical studies and custom tabulations are processed as reimbursable agreements)._IRM 1.33.7.17.18_


**1.33.7.9** **(06-22-2023)**

### 26 USC 6110, Public Inspection of Written Determinations

1. 26 USC 6110, Public inspection of written determinations, authorizes the IRS to charge a fee for reproducing a written determination or background file document for public inspection.

2. The IRS fees, including user fees under Section 6110, are implemented through the issuance of published guidance.

3. This legislation requires that the user fee be the actual costs; however, the IRS can waive or reduce the fee if appropriate.

4. The IRS collects fees for the public inspection of written determination background file documents. _IRM 1.33.7.17.19_


**1.33.7.10** **(06-22-2023)**

### The Pension Protection Act of 2006

1. The Pension Protection Act of 2006 requires the IRS to collect a $500 user fee from any person claiming a deduction for a historical conservation easement donation. _IRM 1.33.7.17.20_

2. The IRS user fees collected under this authority are used for historical conservation easement donation enforcement activities.


**1.33.7.11** **(06-22-2023)**

### The Freedom of Information Act

1. The Freedom of Information Act (FOIA) allows the IRS to charge a user fee for providing certain information covered under the FOIA to the public. _IRM 1.33.7.17.21_

2. The IRS implements FOIA user fees through an announcement or revenue procedure.

3. The FOIA requires agencies to limit fees to reasonable standard charges for document search, duplication and review.

4. FOIA fees are codified in 5 USC Section 552(a)(4).


**1.33.7.12** **(06-22-2023)**

### The Tax Increase Prevention Act of 2014

1. The Tax Increase Prevention Act of 2014 allows the IRS to charge an annual user fee not to exceed $1,000 per year for a program to certify professional employer organizations. _IRM 1.33.7.17.22_


**1.33.7.13** **(06-22-2023)**

### Receipt and Deposit of User Fees

1. The IRS receives user fee remittances at campuses and through Pay.gov lockbox arrangements, Post Office (PO) Boxes, and a mail room at the CFO offices in Beckley, WV.

2. A lockbox is a PO Box established by a financial institution to receive payments made to the IRS. The financial institution receives, deposits and reports payments on Standard Form 215, Deposit Ticket.

3. The IRS uses the following Bureau of the Fiscal Service applications to convert paper checks to electronic funds transfer:



1. Over-the-Counter Channel Application (OTCnet)

2. Remittance Strategy Paper Check Conversion (RS-PCC)


4. The Government Payables and Funds Management office deposits paper checks using the OTCnet.

5. Pay.gov is a secure government-wide collection portal administered by the Bureau of the Fiscal Service. Customers using Pay.gov may pay by Automated Clearing House debit or credit card.



1. The Bureau of the Fiscal Service absorbs all credit card fees for user fee collections.

2. Credit card transactions on one card cannot exceed $24,999.99 on the same day.


6. The IRS records user fee deposits on one of two general ledgers: IFS or RRACS. The Financial Reporting and Analysis office enters user fees originating in RRACS into IFS through a non-standard Treasury 224 entry.


**1.33.7.14** **(06-22-2023)**

### Costing User Fees

1. Business units are required to consider full costs and apply the IRS corporate overhead rate when developing user fee costing. Full cost for providing the good or service includes direct, indirect and imputed costs. The cost of activities includes:



1. Labor and benefits

2. Service and consulting

3. Rent and building costs

4. Depreciation

5. Travel, training and communication

6. Supplies (including equipment, printing and postage)

7. Enforcement


2. Business units identify labor and benefit costs for the user fee activity. Labor costs include both direct and indirect time.

3. The Cost and User Fees office provides the business units with a corporate overhead rate to account for non-labor costs and all other support and sustaining costs paid by the IRS. Expenses not paid by the IRS are not included in the IRS corporate overhead rate.


**1.33.7.15** **(08-21-2025)**

### Biennial Review of User Fees

1. The IRS performs a review every two years to recalculate existing user fee activity costs and consider other activities for which a user fee should be imposed.

2. Business unit strategy and finance offices provide the cost calculations for user fee activities, recommendations for maintaining or adjusting user fees rates, and proposals for new user fees. The cost analysis also considers the effect on voluntary compliance and the corresponding increase to enforcement cost.

3. The Cost and User Fee office prepares the biennial review report and presents the results and business unit recommendations to the CFO.

4. The CFO submits the biennial review to the IRS Commissioner.

5. The Cost and User Fees office works with the business units and other stakeholders to implement rate adjustments and new fees, and works with the business units, Treasury and OMB when a waiver for a less-than-full-cost user fee is recommended.


**1.33.7.16** **(06-22-2023)**

### Annual Monitoring/Review

1. Business units are required to monitor services and activities to determine the potential effect of the user fee on services and activities during the annual budget cycle. The business units should consider whether evidence exists that newly implemented user fees or changes to existing fees have affected tax administration and make appropriate recommendations.

2. Business units are required to review services and activities for potential new user fees during the annual budget cycle. When performing this review, the business units consider the:



1. Voluntary nature of the user fee activities; the IRS does not charge taxpayers for special services that they do not request.

2. Identifiable benefit to a specific taxpayer.

3. Cost of administering the user fee.

4. Effect of the user fee on low-income taxpayers.

5. Effect of the fee on voluntary compliance, taxpayer burden and taxpayer rights.

6. Expected change in demand for service resulting from the proposed fee.


3. The IRS avoids fees that increase enforcement costs, reduce voluntary compliance or otherwise create difficulties in achieving the IRS’s mission.

4. When potential user fees are identified, the business units submit the following information to the Cost and User Fees office:



1. Description of the activity

2. Estimated or historical volumes of participants, products or services

3. Estimated or historical cost of the activity

4. The proposed rate for the user fee and the potential resulting revenue


**1.33.7.17** **(08-21-2025)**

### Types of IRS User Fees

01. Installment agreements

02. Offers in compromise

03. Estate tax closing letters

04. Interview recordings and transcripts

05. Enrollments and enrollment renewals of enrolled actuaries

06. Enrollments and enrollment renewals of enrolled agents

07. Special enrollment examinations for enrolled agents

08. Preparer tax identification numbers

09. Appeals advanced art valuation determinations

10. Chief Counsel rulings and determination letters

11. TE/GE determination letters, information letters and other guidance

12. LB&I determination letters

13. U.S. residency certifications

14. Income Verification Express Service

15. Reproductions of individual and business tax returns

16. Reproductions of exempt organization returns

17. Public use files

18. Public inspections of written determination background file documents

19. Historical conservation easements

20. Freedom of Information Act requests

21. Certified professional employer organizations


**1.33.7.17.1** **(06-22-2023)**

#### Installment Agreements

01. The IRS charges a fee to recover the cost of activities for creating and managing Installment Agreement (IA) payment plans. These activities include answering phone calls, printing and mailing notices, and processing IA collections. The IRS must set the fees at full cost (not to exceed the amounts in effect at the enactment of the Bipartisan Budget Act of 2018), or obtain a waiver from OMB. _IRM 1.33.7.3_

02. An IA is an agreement between the IRS and the taxpayer that allows the taxpayer to pay an outstanding tax liability in monthly installment payments. The taxpayer agrees to pay a user fee for the cost of establishing a new, revised or reinstated IA. The IRS charges an origination fee to establish a new agreement, revise an existing agreement, or reinstate an agreement after the taxpayer defaults on an agreement or an agreement has been terminated. The SB/SE division administers the IA program.

03. A direct debit installment agreement automatically debits the taxpayer's bank account for a monthly transfer to the IRS on a date pre-selected by the taxpayer. These agreements have a lower user fee compared to non-direct debit agreements and the fee is waived for low-income taxpayers.

04. An online payment agreement is established by the taxpayer at IRS.gov. The fee is lower than the fee charged when a taxpayer applies using other methods (phone, mail or in-person) because online payment agreements do not require employee assistance.

05. A voice balance due agreement is established by the taxpayer through the automated phone service. The fee is lower than the fee charged when a taxpayer applies using other methods (agreements established with live phone assistance, by mail or in-person) because voice balance due agreements do not require employee assistance.

06. Taxpayers with incomes at or below 250% of the Department of Health and Human Services poverty guidelines, which are adjusted and published annually, qualify for a reduced low-income user fee. User fees are waived for low-income taxpayers entering into IAs on or after April 10, 2018, who agree to make electronic payments through a direct debit IA. Low-income taxpayers indicating they are unable to make electronic payments through a debit instrument are reimbursed for the user fee upon completing the IA. The taxpayer is not reimbursed for the user fee if the IA is terminated before completion. Low-income taxpayers are identified systemically using their most recently filed tax return. Taxpayers who are not identified as low-income, but believe they meet the requirements for low-income status, must complete Form 13844, Application for Reduced User Fee for Installment Agreements, within 30 days of receipt of the IA acceptance letter.

07. The IRS receives IA fees with installment tax payments through a lockbox or the Electronic Federal Tax Payment System. The CFO Revenue Accounting and Control System (RACS) units record the payments in RRACS as tax revenue. The IA fees and the tax payments are not separately identifiable, so a separate process reclassifies user fee collections from tax revenue to record the IA user fee revenue.

08. The IRS IT division staff executes a weekly automated utility program, the IA User Fee Sweep Program, to reclassify the Integrated Data Retrieval System IA user fee collections from tax revenue to user fee revenue. The program reviews all tax modules in the taxpayer’s account in IA status and verifies a user fee has been received. If not, the program looks for subsequent tax payments sufficient to pay the user fee. If sufficient payments have been received, the program transfers the user fee amount from the tax module to the user fee module, reversing the tax payment and recording the user fee payment.

09. The IT division staff provides the Cost and User Fees office a weekly report that details the volume of user fees collected from the weekly sweep program and a monthly master file report with detailed revenue data. Accountants in the Cost and User Fees office reconcile the data with the RRACS revenue, compare the volume with the previous year and expected year-to-date volumes, and research unexpected variances.

10. Each October, the Cost and User Fees office estimates the tax revenue received in the prior fiscal year that will be reclassified as user fee revenue in the current fiscal year during the sweep process and records an accrual entry, if necessary.


**1.33.7.17.2** **(06-22-2023)**

#### Offers in Compromise

1. The IRS charges a fee to recover the cost for reviewing and processing an Offer in Compromise (OIC) settlement. The IRS must set the fees at full cost or obtain a waiver from OMB. _IRM 1.33.7.3_

2. An OIC is an agreement between a taxpayer and the IRS that settles a tax liability for less than the full amount owed. The IRS accepts an OIC when there is doubt as to liability or collectability, or where acceptance would promote effective tax administration. The SB/SE division administers the OIC program.

3. Taxpayers submit Form 656, Offer in Compromise, and pay the appropriate application fee (user fee) stated on the form. Taxpayers meeting the IRS low-income guidelines are exempt from the application fee. The application fee is not required with a Doubt as to Liability OIC.

4. The IRS retains the user fee for a processable OIC, except in cases where the taxpayer requests a refund and the offer is accepted under Effective Tax Administration or Doubt as to Collectability with Special Circumstances – Economic Hardship criteria. The IRS returns the taxpayer’s check for the user fee and any deposits if the OIC is not processable.

5. The Brookhaven and Memphis campuses receive OIC user fees, which are initially recorded in master file and RRACS as payments against the taxpayer’s debt. During weekly processing, the IT division runs a program that summarizes the payments and generates a journal entry at the general ledger level, reducing the RRACS general ledger account balance for tax receipts and increasing the OIC user fee account for the fees.

6. The IT division provides a monthly master file detail report of user fee transactions to the Cost and User Fees office to analyze and identify all payments that do not equal the user fee amount. Non-matching payments are sent to SB/SE for correction.


**1.33.7.17.3** **(06-22-2023)**

#### Estate Tax Closing Letters

1. The IRS charges a fee to recover the cost of issuing estate tax closing letters upon request of taxpayers. The IRS must set the fees at full cost or obtain a waiver from OMB. _IRM 1.33.7.3_

2. The IRS receives estate tax closing letter requests and the associated user fees through Pay.gov.

3. An estate tax closing letter is issued only after a successful submission is made through Pay.gov and the estate tax return (Form 706 or Form 706-NA) was accepted as filed or, if the return was selected for examination, the examination has concluded. There is no requirement for an estate to secure this letter. An alternative to obtaining the estate tax closing letter (transcript) is outlined at **www.IRS.gov/etcl**. The SB/SE division administers the estate tax closing letter program.


**1.33.7.17.4** **(06-22-2023)**

#### Interview Recordings and Transcripts

1. The IRS charges a fee for providing taxpayers with requested copies or transcripts from audio recordings initiated by IRS for an in-person interview. The fee must cover the cost of any requested transcription and reproduction. _IRM 1.33.7.4_

2. The Service can initiate an audio recording provided it notifies the taxpayer ten calendar days in advance of the interview using Letter 2156, _Recording Interviews_. IRM 4.10.3.4.7.2(1)

3. Transcription and reproduction costs are calculated for each request; costs vary based on factors such as interview length and vendor rates.

4. The SB/SE division receives the requests with payments and submits the payments to Government Payables and Funds Management for deposit.


**1.33.7.17.5** **(06-22-2023)**

#### Enrollments and Enrollment Renewals of Enrolled Actuaries

1. The IRS charges a fee to recover the cost for managing the enrolled actuary program. The IRS must set the fees at full cost or obtain a waiver from OMB. _IRM 1.33.7.3_

2. Enrolled actuaries have satisfied the qualification requirements established by the Joint Board for the Enrollment of Actuaries, which approves individuals to perform actuarial services before the IRS under the Employee Retirement Income Security Act of 1974. The Return Preparer Office administers the enrollment program.

3. Individuals seeking enrollment must satisfy knowledge and experience requirements.

4. Individuals seeking enrollment are subject to a tax compliance check.

5. Enrolled actuaries renew their enrollment every three years using Form 5434-A, Application for Renewal of Enrollment.

6. The IRS receives applications, renewal forms and fees through Pay.gov, the U.S. Postal Service and other private mail carriers.


**1.33.7.17.6** **(06-22-2023)**

#### Enrollments and Enrollment Renewals of Enrolled Agents

1. The IRS charges a fee to recover the cost for processing new enrolled agent applications and renewals. The IRS must set the fees at full cost or obtain a waiver from OMB. _IRM 1.33.7.3_

2. Enrolled agents are individuals who successfully completed the Special Enrollment Examination process or who qualified based on prior IRS employment and have been approved to practice before the IRS. The Return Preparer Office administers the enrolled agent program and grants permission to practice before the IRS.

3. Individuals seeking enrollment are subject to a tax compliance check.

4. Individuals who pass the Special Enrollment Examination are provided an enrollment card, which must be renewed with the IRS every three years. Enrolled agents must register for a preparer tax identification number, which must be renewed annually.

5. The IRS receives applications and fees through Pay.gov, the U.S. Postal Service and other private mail carriers.


**1.33.7.17.7** **(06-22-2023)**

#### Special Enrollment Examinations for Enrolled Agents

1. The IRS charges a fee to recover the cost for overseeing the administration of the Special Enrollment Examination, including developing and approving examination questions, recording test results and managing the program. The IRS must set the fee at full cost or obtain a waiver from OMB. _IRM 1.33.7.3_

2. Individuals pay a user fee each time they sit for a part of the Special Enrollment Examination.

3. A vendor schedules and administers the Special Enrollment Examinations, collects the user fees (along with the vendor's administrative fee), and submits the user fees to the IRS through Pay.gov.


**1.33.7.17.8** **(06-22-2023)**

#### Preparer Tax Identification Numbers

1. The IRS charges a fee to recover the cost of administering the preparer tax identification number (PTIN) application and renewal program. The IRS must set the fee at full cost or obtain a waiver from OMB. _IRM 1.33.7.3_

2. Anyone who prepares or substantially helps to prepare any federal tax return or claim for refund of compensation must have a valid IRS PTIN, which is renewed annually beginning in October for the next filing season.

3. A third-party contractor collects the user fee and a separate contractor fee, processes the PTIN applications and renewals, and submits the PTIN user fees to the IRS through Pay.gov.


**1.33.7.17.9** **(06-22-2023)**

#### Appeals Advanced Art Valuation Determinations

1. The IRS charges a reasonable fee, which may be less than full cost, to recover the cost for performing an advanced art valuation. _IRM 1.33.7.5_

2. Taxpayers can request art valuations for income, estate or gift tax purposes. The Office of Art Appraisal Services under the chief, Appeals, reviews the fair market value claims on works of art and issues a Statement of Value. Taxpayers can rely on the Statement of Value for completing tax returns if the statements are based on facts.

3. A taxpayer seeking a Statement of Value:



1. Submits a copy of a qualified appraisal of the art item(s);

2. Pays the user fee;

3. Completes and submits an appraisal summary; and

4. Identifies the jurisdiction for examination of the taxpayer's tax return.


4. Advanced art valuation determination fees are collected through Pay.gov.


**1.33.7.17.10** **(06-22-2023)**

#### Chief Counsel Rulings and Determination Letters

1. The IRS charges a reasonable fee, which may be less than full cost, to recover the cost for providing rulings and determination letters. _IRM 1.33.7.5_

2. Chief Counsel provides letter rulings, closing agreements and determination letters to taxpayers upon request.

3. Taxpayers pay the user fee on Pay.gov and submit a copy of the payment voucher with their requests for letter rulings or determinations.


**1.33.7.17.11** **(06-22-2023)**

#### TE/GE Determination Letters, Information Letters and Other Guidance

1. The IRS charges a reasonable fee, which may be less than full cost, to recover the cost for providing employee plans and exempt organizations with determinations letters, information letters and other guidance. _IRM 1.33.7.5_

2. The TE/GE division provides letter rulings, determination letters, information letters and other guidance for employee plans and exempt organizations. The Cost and User Fees office maintains a list of the various fee categories and rates.

3. The TE/GE division receives fees at the Cincinnati Submission Processing Center and through Pay.gov.

4. The Cincinnati Submission Processing Center deposits payments through the deposit function and the CFO RACS unit records user fee deposits in RRACS.


**1.33.7.17.12** **(06-22-2023)**

#### LB&I Determination Letters

1. The IRS charges a reasonable fee, which may be less than full cost, to recover the cost for providing a taxpayer with pre filing agreements, federal excise tax exemptions, tax treaty limitation of benefits interpretations and advanced pricing agreements. _IRM 1.33.7.5_

2. Taxpayers serviced by LB&I can request a pre-filing agreement, which is consideration of an issue before filing a tax return. The LB&I division sends a user fee invoice to the taxpayer if the request is accepted. The taxpayer submits payment for the user fee to Pay.gov or to the Government Payables and Funds Management office, which notifies LB&I of receipt.

3. The LB&I division receives requests from taxpayers for federal excise tax exemptions and tax treaty limitation of benefits interpretations through a PO Box or through Pay.gov.

4. Taxpayers may request an advanced pricing agreement to resolve actual or potential transfer pricing disputes as an alternative to the traditional examination process. The LB&I division receives transfer pricing agreements requests and user fees through a PO Box or Pay.gov.

5. Payments received through a PO Box are mailed to Government Payables and Funds Management for deposit.


**1.33.7.17.13** **(08-21-2025)**

#### SB/SE Determination Letters

1. The IRS charges a reasonable fee, which may be less than full cost, to recover the cost of issuing determination letters requested related to income taxes, estate and gift taxes, employment taxes, or excise taxes. _IRM 1.33.7.5_

2. The SB/SE division receives taxpayer requests for a determination letter through a PO Box or through Pay.gov.

3. Payments received through a PO Box are mailed to Government Payables and Funds Management for deposit.


**1.33.7.17.14** **(08-21-2025)**

#### U.S. Residency Certifications

1. The IRS charges a reasonable fee, which may be less than full cost, to recover the cost for providing taxpayers with a U.S. residency certification. _IRM 1.33.7.6_

2. A U.S. residency certification confirms a person is a U.S. resident who files a U.S. tax return. Some income tax treaties between the U.S. and foreign countries can reduce withholding from certain types of income paid to U.S. residents. Treaty partners sometimes require the IRS to certify residency of the individual claiming treaty benefits.

3. To receive a letter of U.S. residency certification, taxpayers file Form 8802, Application for United States Residency Certification, and submit the appropriate user fee to the IRS.

4. The IRS receives U.S. residency certification user fees through Pay.gov for electronic payments. Checks and money orders are processed through OTC.net.


**1.33.7.17.15** **(06-22-2023)**

#### Income Verification Express Service

1. The IRS charges a reasonable fee, which may be less than full cost, to recover the cost for administering the Income Verification Express Service (IVES) program for approved customers who have signed up for this service. _IRM 1.33.7.6_

2. The IVES program provides taxpayer transcripts to customers within two business days. Users fax Form 4506-C IVES, Request for Transcript of Tax Return, signed by the taxpayer, to the campuses that process the request through the Transcript Delivery System.

3. The IRS records IVES user fees using the accrual basis of accounting. The Transcript Delivery System transmits the transcripts to customers during the month, interfacing with IFS at month-end to generate invoices based on the number of transcripts provided and to record revenue and receivables.

4. Approved customers pay electronically via debit or credit card through Pay.gov. The Financial Management Systems office pulls an IVES report from Pay.gov and uploads the report into IFS daily. This process records customer payments and reverses receivables.


**1.33.7.17.16** **(06-22-2023)**

#### Reproductions of Individual and Business Tax Returns

1. The IRS charges a reasonable fee, which may be less than full cost, to recover the cost for photocopying a taxpayer's individual and/or business tax return. _IRM 1.33.7.6_

2. Taxpayers can obtain copies of their tax returns and attachments for the current year and three prior years by submitting Form 4506, Request for Copy of Tax Return.

3. The campuses receive payments for photocopy user fees and the CFO RACS units record the fees in RRACS as user fee revenue.


**1.33.7.17.17** **(06-22-2023)**

#### Reproductions of Exempt Organizations Returns

1. The IRS charges a reasonable fee, which may be less than full cost, to recover the costs for providing an electronic copy of an exempt organization tax return to a taxpayer. _IRM 1.33.7.7_

2. The Ogden campus receives requests and payments for copies of exempt organization tax returns.


**1.33.7.17.18** **(06-22-2023)**

#### Public Use Files

1. The IRS charges a reasonable fee, which may be less than full cost, to recover the costs for creating and providing taxpayers with public use files upon request. _IRM 1.33.7.8_

2. The public use files are micro-data files produced every two years and statistically modified to prevent the disclosure of individual taxpayer data.

3. Taxpayers submit a written request to the Statistics of Income division to purchase a file. Pricing is for the specific file (i.e., a request for a prior file is charged at that file’s rate), rather than the user fee rate in effect for the current file.

4. The Statistics of Income division receives payments through Pay.gov or a PO Box and sends any paper checks received to the Government Payables and Funds Management office for processing.


**1.33.7.17.19** **(06-22-2023)**

#### Public Inspections of Written Determination Background File Documents

1. The IRS charges a fee, which may be less than full cost, to recover the costs for providing a copy of a written determination to a taxpayer. _IRM 1.33.7.9_

2. The IRS provides taxpayers with copies of written determination background file documents.

3. Taxpayers submit written requests to Chief Counsel, who estimates the cost of providing the service and sends a payment agreement to the taxpayer. Chief Counsel processes the request after the payment has been received.

4. Chief Counsel matches payments received through Pay.gov to the submitted applications.


**1.33.7.17.20** **(06-22-2023)**

#### Historical Conservation Easements

1. The IRS charges a fee set at $500 by legislation for the historical conservation easement charitable deduction. _IRM 1.33.7.10_

2. A taxpayer who claims the historical conservation easement charitable deduction on tax return must pay a user fee and submit Form 8283, Noncash Charitable Contributions, along with the fee.

3. The IRS receives the user fee through the Government Payables and Funds Management office through Pay.gov.

4. The Government Payables and Funds Management office notifies the Ogden Campus to record the transaction on the master file taxpayer's record.


**1.33.7.17.21** **(08-21-2025)**

#### Freedom of Information Act Requests

1. The IRS charges a reasonable fee, which may be less than full cost, to recover the costs for providing taxpayers with information that falls under the FOIA. _IRM 1.33.7.11_

2. The FOIA mandates public access to the records of federal agencies unless the information involved is protected from disclosure by one of FOIA's nine exemptions or three exclusions. The Office of Privacy, Governmental Liaison and Disclosure administers the FOIA program.

3. 5 USC 552, Public information, agency rules, opinions, orders, records, and proceedings, requires federal agencies to impose reasonable standard fees to recover direct costs except when the information disclosed is in the public's interest. Agencies are precluded by law from imposing fees if the cost of collection exceeds the amount collected.

4. The taxpayer agrees to pay FOIA fees in advance if the cost to process a FOIA request is estimated to exceed $250 or if the requester failed to pay prior fees in a timely fashion.

5. Privacy, Government Liaison and Disclosure (PGLD) receives FOIA user fees through the following processes:



1. For non-electronic requests, payments are received at a PO Box and the payments are forwarded to the Government Payables and Funds Management office via overnight mail.

2. For electronic requests received through the FOIA Public Access Portal (PAL), payments are made through a link with pay.gov.


For more information, see IRM 11.3.5, Disclosure of Official Information



**1.33.7.17.22** **(06-22-2023)**

#### Certified Professional Employer Organizations

1. The IRS charges an annual fee not to exceed $1,000 per year for certifying professional employer organizations under PL113-295, section 7705. _IRM 1.33.7.12_

2. Organizations apply for certification, which allows them to be treated as the employer of any individual performing services covered by a contract meeting certain requirements.

3. The SB/SE division receives the certification fees through Pay.gov.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-033-007#addtoany "Show all")

A2A