---
url: "https://www.irs.gov/irm/part1/irm_01-011-002"
title: "1.11.2 Internal Revenue Manual (IRM) Process | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-011-002#main-content)

- 1.11.2  [Internal Revenue Manual (IRM) Process](https://www.irs.gov/irm/part1/irm_01-011-002#id1)
  - 1.11.2.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-011-002#id2)
    - 1.11.2.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-011-002#id4)
    - 1.11.2.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-011-002#id5)
    - 1.11.2.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-011-002#id6)
    - 1.11.2.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-011-002#id7)
    - 1.11.2.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-011-002#id8)
    - 1.11.2.1.6  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-011-002#id9)
    - 1.11.2.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-011-002#id10)
  - 1.11.2.2  [IRM Standards](https://www.irs.gov/irm/part1/irm_01-011-002#id11)
    - 1.11.2.2.1  [Supplemental Guidance](https://www.irs.gov/irm/part1/irm_01-011-002#id12)
      - 1.11.2.2.1.1  [Local Procedures](https://www.irs.gov/irm/part1/irm_01-011-002#id14)
    - 1.11.2.2.2  [Responsibilities for Maintaining the IRM](https://www.irs.gov/irm/part1/irm_01-011-002#id15)
      - 1.11.2.2.2.1  [Risks When the IRM is not Current](https://www.irs.gov/irm/part1/irm_01-011-002#id17)
    - 1.11.2.2.3  [When Procedures Deviate from the IRM](https://www.irs.gov/irm/part1/irm_01-011-002#id18)
    - 1.11.2.2.4  [Address Management and Internal Controls](https://www.irs.gov/irm/part1/irm_01-011-002#id19)
    - 1.11.2.2.5  [Functional Statement IRM](https://www.irs.gov/irm/part1/irm_01-011-002#id20)
  - 1.11.2.3  [IRM Format, Structure and Identifying Information](https://www.irs.gov/irm/part1/irm_01-011-002#id21)
    - 1.11.2.3.1  [IRM Section Elements](https://www.irs.gov/irm/part1/irm_01-011-002#id23)
    - 1.11.2.3.2  [IRM Catalog Number](https://www.irs.gov/irm/part1/irm_01-011-002#id24)
    - 1.11.2.3.3  [Identify the IRM Owner](https://www.irs.gov/irm/part1/irm_01-011-002#id25)
    - 1.11.2.3.4  [Identify the IRM Author](https://www.irs.gov/irm/part1/irm_01-011-002#id26)
  - 1.11.2.4  [Create New or Change Existing IRM Sections](https://www.irs.gov/irm/part1/irm_01-011-002#id27)
    - 1.11.2.4.1  [Request a New IRM Chapter or Section](https://www.irs.gov/irm/part1/irm_01-011-002#id28)
      - 1.11.2.4.1.1  [Receive a Catalog Number](https://www.irs.gov/irm/part1/irm_01-011-002#id30)
    - 1.11.2.4.2  [Create or Change an IRM Title](https://www.irs.gov/irm/part1/irm_01-011-002#id31)
    - 1.11.2.4.3  [Change the IRM Owner](https://www.irs.gov/irm/part1/irm_01-011-002#id32)
    - 1.11.2.4.4  [Change the IRM Author](https://www.irs.gov/irm/part1/irm_01-011-002#id33)
  - 1.11.2.5  [Write the IRM](https://www.irs.gov/irm/part1/irm_01-011-002#id34)
    - 1.11.2.5.1  [Authoring Process - First Steps and Training](https://www.irs.gov/irm/part1/irm_01-011-002#id35)
      - 1.11.2.5.1.1  [Prepare to Write or Revise Content](https://www.irs.gov/irm/part1/irm_01-011-002#id37)
      - 1.11.2.5.1.2  [Writing Rules](https://www.irs.gov/irm/part1/irm_01-011-002#id38)
      - 1.11.2.5.1.3  [Consider Requested IRM Changes](https://www.irs.gov/irm/part1/irm_01-011-002#id39)
      - 1.11.2.5.1.4  [IRM Changes Affecting conditions of Employment of Bargaining Unit Employees](https://www.irs.gov/irm/part1/irm_01-011-002#id40)
      - 1.11.2.5.1.5  [Removing Substantive Content from an Existing IRM Section](https://www.irs.gov/irm/part1/irm_01-011-002#id41)
    - 1.11.2.5.2  [Determine IRM Dates](https://www.irs.gov/irm/part1/irm_01-011-002#id42)
      - 1.11.2.5.2.1  [Determine the Subsection Date](https://www.irs.gov/irm/part1/irm_01-011-002#id44)
    - 1.11.2.5.3  [Designate IRM Content as Official Use Only (OUO)](https://www.irs.gov/irm/part1/irm_01-011-002#id45)
    - 1.11.2.5.4  [Display Content](https://www.irs.gov/irm/part1/irm_01-011-002#id46)
      - 1.11.2.5.4.1  [Tables](https://www.irs.gov/irm/part1/irm_01-011-002#id47)
      - 1.11.2.5.4.2  [Graphics](https://www.irs.gov/irm/part1/irm_01-011-002#id48)
        - 1.11.2.5.4.2.1  [Convert a Graphic to PDF](https://www.irs.gov/irm/part1/irm_01-011-002#id50)
        - 1.11.2.5.4.2.2  [Store IRM Graphic Files](https://www.irs.gov/irm/part1/irm_01-011-002#id51)
        - 1.11.2.5.4.2.3  [Use Alternative Text for Graphics](https://www.irs.gov/irm/part1/irm_01-011-002#id52)
    - 1.11.2.5.5  [Contact Information](https://www.irs.gov/irm/part1/irm_01-011-002#id53)
    - 1.11.2.5.6  [Fictitious Identifying Information](https://www.irs.gov/irm/part1/irm_01-011-002#id54)
      - 1.11.2.5.6.1  [Personally Identifiable Information (PII) or Federal Tax Information (FTI) Breach Actions](https://www.irs.gov/irm/part1/irm_01-011-002#id56)
    - 1.11.2.5.7  [Write in Plain Language](https://www.irs.gov/irm/part1/irm_01-011-002#id57)
    - 1.11.2.5.8  [Standard Citation Rules](https://www.irs.gov/irm/part1/irm_01-011-002#id58)
      - 1.11.2.5.8.1  [Cite the IRM](https://www.irs.gov/irm/part1/irm_01-011-002#id60)
      - 1.11.2.5.8.2  [Cite Legal Sources](https://www.irs.gov/irm/part1/irm_01-011-002#id61)
      - 1.11.2.5.8.3  [Cite Other IRS Published Products](https://www.irs.gov/irm/part1/irm_01-011-002#id62)
      - 1.11.2.5.8.4  [Validate Links](https://www.irs.gov/irm/part1/irm_01-011-002#id63)
      - 1.11.2.5.8.5  [Create Hyperlinks](https://www.irs.gov/irm/part1/irm_01-011-002#id64)
  - 1.11.2.6  [Use and Preparation of the Manual Transmittal (MT)](https://www.irs.gov/irm/part1/irm_01-011-002#id65)
    - 1.11.2.6.1  [Required Elements of the Manual Transmittal](https://www.irs.gov/irm/part1/irm_01-011-002#id66)
      - 1.11.2.6.1.1  [Manual Transmittal (MT) Date](https://www.irs.gov/irm/part1/irm_01-011-002#id68)
      - 1.11.2.6.1.2  [Manual Transmittal Purpose](https://www.irs.gov/irm/part1/irm_01-011-002#id69)
      - 1.11.2.6.1.3  [Manual Transmittal Material Changes](https://www.irs.gov/irm/part1/irm_01-011-002#id70)
      - 1.11.2.6.1.4  [Effect on Other Documents](https://www.irs.gov/irm/part1/irm_01-011-002#id71)
      - 1.11.2.6.1.5  [Audience](https://www.irs.gov/irm/part1/irm_01-011-002#id72)
      - 1.11.2.6.1.6  [Effective Date](https://www.irs.gov/irm/part1/irm_01-011-002#id73)
      - 1.11.2.6.1.7  [Signature of Approving Official](https://www.irs.gov/irm/part1/irm_01-011-002#id74)
    - 1.11.2.6.2  [Manual Transmittal Optional Elements](https://www.irs.gov/irm/part1/irm_01-011-002#id75)
  - 1.11.2.7  [Conduct an Informal Review](https://www.irs.gov/irm/part1/irm_01-011-002#id76)
    - 1.11.2.7.1  [Determine the Need for an Informal Review](https://www.irs.gov/irm/part1/irm_01-011-002#id78)
    - 1.11.2.7.2  [Initiate an Informal Review](https://www.irs.gov/irm/part1/irm_01-011-002#id79)
  - 1.11.2.8  [Editorial Updates](https://www.irs.gov/irm/part1/irm_01-011-002#id80)
    - 1.11.2.8.1  [Editorial Update Process](https://www.irs.gov/irm/part1/irm_01-011-002#id82)
  - 1.11.2.9  [Rules to Obsolete an IRM Section](https://www.irs.gov/irm/part1/irm_01-011-002#id83)
  - 1.11.2.10  [Communicate Information About the IRM](https://www.irs.gov/irm/part1/irm_01-011-002#id84)
    - 1.11.2.10.1  [SPDER Communications](https://www.irs.gov/irm/part1/irm_01-011-002#id86)
  - Exhibit  1.11.2-1  [Definitions of Terms for Determining What Belongs in the IRM](https://www.irs.gov/irm/part1/irm_01-011-002#id87)
  - Exhibit  1.11.2-2  [Most Common Reasons to Review the IRM](https://www.irs.gov/irm/part1/irm_01-011-002#id88)
  - Exhibit  1.11.2-3  [IRM Web Resources](https://www.irs.gov/irm/part1/irm_01-011-002#id89)

# Part 1. Organization, Finance, and Management

# Chapter 11. Internal Management Documents System

# Section 2. Internal Revenue Manual (IRM) Process

* * *

## 1.11.2 Internal Revenue Manual (IRM) Process

#### Manual Transmittal

July 31, 2025

#### Purpose

(1) This transmits revised IRM 1.11.2, Internal Management Documents System, Internal Revenue Manual (IRM) Process.

#### Material Changes

(1) _IRM 1.11.2.1.3_, Responsibilities: Changed subsection title from Responsibilities to Roles and Responsibilities.

- Paragraph (4) - Clarified the role of business unit authors regarding IMDs. Added IRM 1.11.1.6.7, IMD Authors.


(2) _IRM 1.11.2.1.4_, Program Management and Review.

- Paragraph (1) - Updated description of reports issued by SPDER.


(3) _IRM 1.11.2.1.6_, Terms and Acronyms.

- Paragraph (1) - Table - Term, Internal Control. Updated IRM 1.4.2.4.2(2), Determine Existing Controls, for examples to IRM 1.4.2.4.1, Incorporating the Use of Controls.


(4) _IRM 1.11.2.2.2_, Responsibilities for Maintaining the IRM.

- Paragraph (5) - Added _IRM 1.11.2.2_ (8), IRM Standards and clarified that IRM owners are responsible for reviewing the IRM annually.


(5) _IRM 1.11.2.2.4_, Address Management and Internal Controls

- Paragraph (5) - Updated example to show how the numbering is for internal controls.


(6) _IRM 1.11.2.2.5_, Functional Statement IRM.

- Paragraph (4)(b) - Updated procedure to add a graphic of business units organizational chart in exhibit.


(7) _IRM 1.11.2.4.1_, Request a New IRM Chapter or Section.

- Paragraph (1) - Clarified system will auto generate an email to the business unit IMD/IRM coordinator.

- Paragraph (2) - Updated procedures to include IMD/IRM coordinator responsibilities.


(8) _IRM 1.11.2.4.2_, Create or Change an IRM Title.

- Paragraph (3) step 3 - Clarified the approval process for the business unit IMD/IRM coordinator.


(9) _IRM 1.11.2.4.3_, Change the IRM Owner.

- Paragraph (2) - Clarified process to indicate an auto email will be generated to the business unit IMD/IRM coordinator.

- Paragraph (3) - Updated procedures to include IMD/IRM coordinator responsibilities.


(10) _IRM 1.11.2.5.1_, Authoring Process. Changed subsection title from Authoring Process to Authoring Process - First Steps and Training.

- Paragraph (1) - Updated author’s actions and training.

- Paragraph (2) - Added a list of ITM courses and description that is included in the new IRM Authoring Curriculum.

- Paragraph (3) - New paragraph explaining self-registration process for ITM course 15770, IRM Authoring Tool. Incorporated IGM RAAS-01-0824-0002, Self-registration for IRM Authoring Tool Training, into IRM 1.11.2, issued 08-05-2024.

- Updated note to include prerequisite ITM course 59521, Introduction to the IRM for All Employees and ITM Course 80730, IRM Authoring: Organizing and Structuring IRMs.


(11) _IRM 1.11.2.5.1.1_, Prepare to Write or Revise Content.

- Paragraph (2) - Step 3, added delegation authorities to the list of changes requiring consideration.

- Paragraph (2) - Step 4, added Exception statement, If an IPU has been issued since the IRM was last published, use the last tracked change XML file submitted to SERP.


(12) _IRM 1.11.2.5.1.4_, IRM Changes Affecting Conditions of Employment of Bargaining Unit Employees.

- Clarified conditions of employment and updating the LERN mailbox.


(13) _IRM 1.11.2.5.8_, Standard Citation Rules.

- Paragraph (4) - Added do not spell out the link in the IRM, also known as a "naked link" . Rather embed links in the citation tool.


(14) _IRM 1.11.2.5.8.4_, Validate Links.

- Paragraph (6) - Added minor editorial edits to IRM Online can be made in between revisions by sending an email to \*SPDER.


(15) _IRM 1.11.2.5.8.5_, Create Hyperlinks.

- Paragraph (1) - Clarified all URLs must be embedded using the various tags in Arbortext Editor.

- Paragraph (4) - Added content to explain what is considered a naked link. Choose the appropriate emphasis tag "external=no" in Arbortext. Give the link or email address a proper name inside the <a> tag.


(16) _IRM 1.11.2.8_, Editorial Updates.

- Paragraph (3) - Added note, edits can be made to IRM online in between revisions by sending an email to \*SPDER.


(17) _Exhibit 1.11.2-1_, Definitions of Terms for Determining What Belongs in the IRM.

- Table, clarified decision making power for delegation of authority.


(18) _Exhibit 1.11.2-2_, Most Common Reasons to Review the IRM.

- Condition 3, clarified explanation of delegation orders and policy statements.


(19) _Exhibit 1.11.2-3_, IRM Web Resources .Updated table to include links within resource name.

(20) Editorial Changes Throughout:

- Updated organizational titles to reflect the current IRS structure.

- Incorporated plain writing techniques including active voice and present tense.

- Updated web addresses and references.

- Corrected capitalization, typos, grammar, etc.


#### Effect on Other Documents

This IRM supersedes IRM 1.11.2, revision date September 13, 2023. This IRM incorporates interim guidance memorandum RAAS 01-0824-0002, New Registration Requirements for IRM Authoring Tool Training, issued 08-05-2024.

#### Audience

All business unit program directors, IMD/IRM coordinators, authors, managers, and reviewers who develop, review or approve IRM procedural content.

#### Effective Date

(07-31-2025)

Holly A. Donnelly

Director, Strategy and Business Solutions

Research, Applied Analytics and Statistics (RAAS)

**1.11.2.1** **(09-13-2023)**

### Program Scope and Objectives

1. **Purpose:** This IRM section describes the IRM authoring process and the procedures for creating or updating the IRM. Specifically, IRM 1.11.2:



1. Describes the steps in the IRM authoring process.

2. Establishes the standards and procedures for writing the IRM.

3. Provides details on adding applicable management and internal controls to the IRM.

4. Recommends IRM resources, including decision tools, websites and other IRM sections.

5. Suggests ways to minimize duplication and improve the content and readability.


2. **Audience:** These procedures apply to IRS employees responsible for developing, creating and improving the IRM, including:



   - IRM authors

   - IRM reviewers

   - Managers with internal management document (IMD) program responsibilities

   - IMD/IRM coordinators

   - Program directors

   - Contractors who prepare IRM material



     ### Note:



     This IRM section uses the terms "author" and "originator" interchangeably.


3. **Policy Owner:** Director, Strategy and Business Solutions (SBS) - Research, Applied Analytics and Statistics (RAAS).

4. **Program Owner:** The Office of Servicewide Policy, Directives and Electronic Resources (SPDER) within SBS - RAAS is the program office responsible for overseeing the IMD process and providing guidance. Each business unit is responsible for establishing an internal process for managing their procedures based upon these Servicewide processes.

5. **Primary Stakeholders:** Media & Publications controls the IRM publishing process, the IRM publishing contract, and the IRM authoring software (Arbortext Editor) contract. All organizations and business units who manage, own, and issue instructions to employees are stakeholders in the IRM program.

6. **Contact Information:** Email \*SPDER to recommend changes or make suggestions for this IRM section.


**1.11.2.1.1** **(04-22-2020)**

#### Background

1. The IRM enables the IRS to meet certain federal requirements to document, publish and maintain records of policies, authorities, procedures and organizational operations described in IRM 1.11.1.1.2, Authority.

2. The IRS Restructuring and Reform Act of 1998 (RRA98) resulted in a complete restructuring and reformatting of the IRM to align with IRS business processes. One of the primary goals of IRS modernization was to restore and maintain the IRM as the single, official compilation of IRS policies, procedures and guidelines.

3. In 1999, the IRS formed the Office of Servicewide Policy, Directives and Electronic Resources (formerly Servicewide Policy, Directives and Electronic Research). SPDER is responsible for designing, implementing and monitoring a strategic approach to managing and setting Servicewide policy for internal management directives. Refer to IRM 1.11.1, Internal Management Document (IMD) Program and Responsibilities, for information about the effect of these changes.


**1.11.2.1.2** **(04-22-2020)**

#### Authority

1. By law, federal agencies must document, publish and maintain records of policies, authorities, procedures and organizational operations. The IRM is the source for the IRS. Refer to IRM 1.11.1.1.2, Authority, for the authorities and legal obligations of IMDs.

2. The Freedom of Information Act (FOIA), [5 USC 552(a)(2)(C)](https://www.justice.gov/oip/blog/foia-update-freedom-information-act-5-usc-sect-552-amended-public-law-no-104-231-110-stat), requires each agency to maintain and make available for public inspection and copying administrative staff manuals and instructions to staff that affect a member of the public. The redacted IRM posted on IRS.gov fulfills this requirement.

3. The Freedom of Information Act (FOIA), [5 USC 552(a)(2)(E)](https://www.justice.gov/oip/blog/foia-update-freedom-information-act-5-usc-sect-552-amended-public-law-no-104-231-110-stat), requires each agency to maintain and make available for public inspection and copying a current index of records likely to become the subject of multiple FOIA requests for substantially the same records. Document 10988, Internal Revenue Manual Index, is available on IRS.gov and fulfills this requirement.


**1.11.2.1.3** **(07-31-2025)**

#### Roles and Responsibilities

1. The Director, Strategy and Business Solutions (SBS) - RAAS, is responsible for IMD program administration and designates oversight responsibility for the IMD program, including IRMs, to the Director, SPDER.

2. Program directors Servicewide oversee IMD administration under their program responsibility, including approval of new or revised IMDs.

3. Program owners manage and execute the IMD program.

4. Business unit authors who prepare IMDs are responsible for following authoring rules found in IRM 1.11 series, IRM Style Guide, and issued interim guidance. Refer to IRM 1.11.1.6.7, IMD Authors, for author’s responsibilities. IMD authors are responsible for clearing IRMs through all affected offices.

5. The Director, Media and Publications (M&P), is responsible for composition reviews involving numbering, formatting and processing the IRM for publication. M&P is also responsible for planning, developing, coordinating, administering and evaluating the policies, systems, procedures and standards to meet IRS publishing needs. Refer to IRM 1.11.5, Publishing the Internal Revenue Manual (IRM).


**1.11.2.1.4** **(07-31-2025)**

#### Program Management and Review

1. SPDER manages the IMD program through the following reviews and reports:




| Review/Report | Description |
| :-: | :-: |
| Annual Report on the Internal Management Documents (IMD) Program | An annual report issued that details IMD program accomplishments and activities. This report also includes a summary of annual certification results and recommended actions. |
| Annual IMD Program Risk Analysis | An addendum to the above memorandum, this report provides the status Servicewide of the actions taken by each business unit on the identified areas of risk to the IMD program. SPDER shares a report for each business unit with the IMD executive and IMD coordinator and staff. |
| IRM Data Reports | IRM data based on the IRM sections processed through M&P monthly. The reports maintain a list of Servicewide IRMs including new, revised, obsolete and official use only IRMs, categorized by business unit, title and process. |
| IRM Online Index and Statistics | Data statistics and indexes for current IRM sections, found on IRM Online. |


**1.11.2.1.5** **(08-12-2021)**

#### Program Controls

1. IMD Certification: SPDER annually requires business units to indicate the status of their IRMs, Servicewide delegation orders and policy statements, and to certify IRM management and internal controls. SPDER compiles the results into a report for senior executives, managers, IMD coordinators and staff. The report supports and improves IMD program management.


**1.11.2.1.6** **(07-31-2025)**

#### Terms and Acronyms

1. The following table defines terms that appear throughout this IRM section:




| Term | Definition |
| :-: | :-: |
| Audience | The employees responsible for action or who require knowledge about the program, process or activity, identified by job title, role, specific office or business unit. |
| Authorized delegate | The senior manager delegated responsibility for IMD program administration by the member of the Senior Executive Service with program oversight. Refer to IRM 1.2.2.2.53, Delegation Order 1-69 (New), Authorization to Approve an Internal Management Document (IMD). |
| Business unit | The highest-level operating division or office headed by an executive.<br> <br>### Example:<br>IRS business units include Small Business/Self-Employed (SB/SE), Appeals and Human Capital Office (HCO). |
| Filing season IRM | An IRM section that contains tax year-specific information and must be published by a certain date, so employees can be trained to perform their jobs in time for the upcoming tax filing season. |
| Internal control | A tool routinely used by management, or an integral component of a business unit’s management, that assures the following objectives are achieved:<br> <br>   - Effectiveness and efficiency of operations<br>     <br>   - Reliability of reporting for internal and external use<br>     <br>   - Compliance with applicable laws and regulations<br>     <br> Refer to IRM 1.4.2.4.1, Incorporating the Use of Controls. |
| Internal management document | An official communication that designates policies and authorities, and delivers instructions to IRS officials and employees. |
| IRM owner | The program office with primary responsibility for writing and maintaining IRM content whose program director approves the IRM. |
| Manager | The employee’s first-line manager. |
| Policy owner | The program office responsible for the policy/policies published in an IRM section; normally the executive of the operation. |
| Program controls | The reviews and quality assurance activities associated with the program. |
| Program director | The member of the Senior Executive Service, or their authorized delegate, responsible for program administration, including issuance and approval of IMDs. For information on who can be an authorized delegate, refer to IRM 1.2.2.2.53, Delegation Order 1-69 (New), Authorization to Approve an Internal Management Document (IMD). |
| Program goals | The objectives or goals for the specific program and the results from following the processes and procedures of the program. |
| Program owner | The program office that typically reports to the policy owner and is responsible for the administration, procedures and updates related to the program. |
| Program reports | The reports and reporting mechanisms produced under the program. |
| Purpose | A description of the program, process or activity that identifies program objectives, employees responsible for action(s), and the type of work employees perform. |
| Stakeholder | The office or business unit responsible for the program policy or whose processes or procedures are affected. These offices generally include those who are responsible for reviewing and approving the IRM. |

2. The following table provides acronyms that are used throughout this IRM section:




| Acronym | Term |
| :-: | :-: |
| AMC | Alternative Media Center |
| CCDM | Chief Counsel Directives Manual |
| FOIA | Freedom of Information Act |
| IG | Interim guidance |
| IGM | Interim guidance memorandum |
| IMD | Internal management document |
| IPU | IRM procedural update |
| ITM | Integrated Talent Management |
| LERN | Labor/Employee Relations & Negotiations |
| M&P | Media and Publications |
| MT | Manual transmittal |
| OUO | Official use only |
| PDF | Portable document format |
| PII | Personally identifiable information |
| SBU | Sensitive but unclassified |
| SERP | Servicewide Electronic Research Program |
| SME | Subject matter expert |
| SPDER | Servicewide Policy, Directives and Electronic Resources |
| XML | Extensible markup language |


**1.11.2.1.7** **(05-19-2022)**

#### Related Resources

1. The following table lists the primary sources of guidance on the IMD and IRM programs. Together, they form the operating rules and responsibilities for the IMD program.




| IRM Section | Title | Guidance |
| :-: | :-: | :-: |
| IRM 1.11.1 | Internal Management Document (IMD) Program and Responsibilities | Defines the IMD program and explains roles and responsibilities of IRM authors, IMD/IRM coordinators and their managers |
| IRM 1.11.3 | Servicewide Policy Statement Process | Instructs on creating and revising Servicewide policy statements |
| IRM 1.11.4 | Servicewide Delegation Order Process | Instructs on creating and revising Servicewide and business unit delegation orders |
| IRM 1.11.5 | Publishing the Internal Revenue Manual (IRM) | Explains the publishing and distribution processes |
| IRM 1.11.8 | Servicewide Electronic Research Program (SERP) | Instructs on hosting content on SERP and issuing SERP IRM procedural updates (IPUs). Refer to IRM 1.11.8.7.1, Updating IRMs through an IRM Procedural Update (IPU). |
| IRM 1.11.9 | Clearing and Approving the Internal Revenue Manual (IRM) | Instructs on clearing and obtaining approval to publish IRMs |
| IRM 1.11.10 | Interim Guidance Process | Instructs on authoring, issuing and clearing IG and provides the rules for complying with the Freedom of Information Act (FOIA) requirements |
| IRM 10.5.1 | Privacy Policy | Describes the proper handling of sensitive but unclassified (SBU) information and personally identifiable information (PII) |
| IRM 11.3.12 | Designation of Documents | Instructs on processing IMDs and training materials containing official use only (OUO) information |

2. The IRM Decision Tool is an interactive flowchart that helps you determine if new content or instructions to staff found in other sources must be included in the IRM.

3. Document 12835, The IRM Style Guide, is authored by SPDER and provides guidance on format, structure, plain language and writing standards specific to IRMs.

4. The IRS Style Guide, authored by Communications and Liaison (C&L), is a web-based product that provides punctuation, grammar and general writing rules for internal communications.

5. _Exhibit 1.11.2-3_, IRM Web Resources, provides useful IMD related links.


**1.11.2.2** **(09-13-2023)**

### IRM Standards

01. The IRM is the primary, official compilation of instructions to staff that relate to the administration and operation of the IRS. The IRM ensures employees have the approved policy and guidance they need to carry out their responsibilities in administering the tax laws or other agency obligations.

02. Instructions which are the primary source of guidance belong in the IRM. _Primary_, for this purpose, means it is the main source of procedural guidance. This includes information integral to the employee’s job responsibilities or affects their evaluation. The IRM contains information that:



    - Is necessary

    - Presents facts

    - States responsibilities

    - Conveys processes and directions

    - Provides accurate measurements


03. The IRM enables the IRS to meet certain federal requirements to document, publish and maintain records of policies, authorities, procedures and organizational operations described in IRM 1.11.1.1.2, Authority. Refer to _Exhibit 1.11.2-1_, Definitions of Terms for Determining What Belongs in the IRM for the types of IMDs and their description.

04. Instructions remain in effect until changed, superseded or obsoleted by the publication of a subsequent IRM or issued interim guidance (IG).

05. All instructions to employees must be accurate, accessible and easy to follow to ensure employees provide consistent and fair treatment to the public.

06. Authors must ensure their IRM guidance does not contradict with any existing guidance.

07. In certain operational or emergency situations, program owners may issue IG. IG is an official communication conveyed through memoranda or IRM procedural updates (IPUs) used by business units or program offices to immediately issue emergency, pilot, deviation, or temporary changes to operations or IRM procedures for a defined effective period not to exceed two years. Refer to IRM 1.11.10, Interim Guidance Process, for detailed guidance on issuing employee instructions outside of the IRM.

08. To ensure IRM instructions remain consistent, the IRM owner is responsible for reviewing each IRM section annually for procedural, organizational, or operational changes and accurate instruction.

09. Avoid duplicating information contained in another IMD that applies to another office or business unit. Rather, refer to the specific document or IRM number and title where the primary material is located. These practices help employees find the necessary instructions and eliminate the potential for providing conflicting instructions. Refer to _Exhibit 1.11.2-2_, Most Common Reasons to Review the IRM.



    ### Note:



    When addressing an IRS policy in connection with a procedure, don’t restate it verbatim. Refer directly to the policy statement or, paraphrase the content to provide context and include the IRM reference.

10. The IRM Decision Tool helps IRM authors and their management determine the type of information that belongs in the IRM. Through a series of questions, the tool helps to identify whether instructions to staff found in other sources must be included in the IRM.


**1.11.2.2.1** **(09-13-2023)**

#### Supplemental Guidance

1. Program owners may issue supplemental guidance and local procedures to employees **when the primary guidance is in the IRM**. Supplemental guidance contains information on a specific program, project or task. Supplemental guidance must comply with published guidance and reference the applicable IRM section.



### Note:



If there’s a contradiction between the IRM and supplemental guidance, IRM guidance takes precedence.

2. Supplemental guidance:



1. Conveys detailed actions and task-specific instructions within a particular office or geographic location.

2. Provides guidance on performing specific tasks or skills, unique jobs or sub-steps of a larger topic.

3. Lists routing or specific contact information.

4. Provides software or application-specific instructions.

5. Allows teams or subject matter experts to document internal work unit practices.

6. Summarizes processes contained in the IRM.

7. Provides subject-related published documents, reference guides and other governmental publications.


3. Types of supplemental guidance include:



   - Published products, such as Document 12835, IRM Style Guide

   - Job aids, such as desk guides, audit technique guides and user guides

   - Knowledge management materials, such as standard operating procedures (SOP)

   - Check sheets and web-based decision tools

   - Local procedures

   - Training materials



     ### Caution:



     Although training materials are based on the IRM, do not use them in place of the IRM.


### Note:

Definitions for supplemental sources of guidance are in _Exhibit 1.11.2-1_, Definitions of Terms for Determining What Belongs in the IRM.

4. The program office owning the source content and any other affected program office must review supplemental guidance annually for accuracy.

5. Risks associated with placing instructions in a supplemental source of guidance include:



1. Employees following outdated instructions.

2. Decreasing transparency to the public by not disclosing IRS operations.

3. Not clearly documenting changes between revisions.

4. Not subjecting documents to the same formal review and approval process (clearance) as the IRM.

5. Not maintaining archived copies in a searchable or central location.


6. When deciding whether to place content in the IRM or in a supplemental source of guidance, consider the IRM standards for primary guidance provided above in _IRM 1.11.2.2 (2)_, IRM Standards. In addition to those standards, information also belongs in the IRM if any of the following apply:



1. It details actions required by one or more employees as part of their duties.

2. Employees are evaluated on how they follow the instructions it provides.

3. It provides rules for completing required worksheets or forms not published elsewhere.


7. For help in determining if content belongs in the IRM or in a supplemental source of guidance:



1. Use the IRM Decision Tool.

2. Take ITM Course 28309, What Belongs in the IRM.


**1.11.2.2.1.1** **(09-13-2023)**

##### Local Procedures

1. Local procedures are specific instructions for a particular office or campus. They are based on the location, the internal processes of the locality, or specific needs of the taxpayers the location serves. Local procedures cannot set policy or change or contradict national program guidance.



1. These procedures or instructions are formally issued and communicated to employees in a specific office or campus. Refer to _IRM 1.11.2.2.3_, When Procedures Deviate from the IRM, if local procedures need to deviate from the IRM.



      ### Example:






      • Outreach strategies developed by an area office or post of duty to improve taxpayer compliance.


      • Implementation procedures created for a specific group of taxpayers within a post of duty or area/territory advertised locally.





      ### Reminder:



      You must communicate IRS national program guidance on a specific work process through the IRM or interim guidance, for example, centralized work processes that provide Servicewide guidance performed in only one office or campus.


2. Management is responsible for ensuring all employees are aware of and have access to local procedures. To communicate a local procedure to employees:



   - Issue it formally through a memorandum to affected employees.

   - Review it at least annually to ensure consistency with current guidance.

   - Revoke it when the procedure is no longer effective and communicate to employees.


### Note:

Administrative instructions such as emergency evacuation plans, facility-related personnel procedures, etc., are not subject to these requirements.

3. The memorandum used to communicate a local procedure must:



1. Refer to the core process, procedure or applicable IRM section.

2. Document approval by the responsible first-line executive (or their documented designee).

3. Have the affected program office review it for correctness.


4. Local guidance may be subject to FOIA and require disclosure on IRS.gov. For information on the FOIA criteria and requirements, refer to IRM 1.11.1.3.1, Transparency of Instructions to Staff.


**1.11.2.2.2** **(07-31-2025)**

#### Responsibilities for Maintaining the IRM

1. Each program owner is responsible for developing, maintaining and publishing procedures in the IRM to administer their program. Refer to _IRM 1.11.2.1.6_, Terms and Acronyms, for definitions and _IRM 1.11.2.3.3_, Identify the IRM Owner, for more information about the IRM owner.

2. IRM content must be accurate and reliable to ensure consistent administration of the tax laws. To maintain the accuracy of the IRM, the program owner must:



1. Review the IRM at least annually for procedural, operational and editorial changes.

2. Update the IRM when content is no longer accurate and reliable to ensure employees correctly complete their work assignments and for consistent administration of the tax laws.

3. Incorporate all permanent IG content into the next revision of the IRM section prior to the IG’s expiration date.


3. Procedural and operational changes typically originate from the following sources:



   - Legislation

   - Corporate restructuring

   - Interim guidance

   - Chief Counsel guidance

   - Employee recommendations and feedback (refer to _IRM 1.11.2.5.1.3_, Consider Requested IRM Changes)


4. Routine IRM updates are more efficient; addressing changes as they occur eases the burden on authors and reviewers. Infrequent updates usually require extensive changes which increase the time it takes to write, clear and publish the IRM.

5. IRM sections that have not been updated for five or more years are considered "overage" . This is an indicator that the IRM content is most likely not current and must be reviewed and revised if necessary. Per _IRM 1.11.2.2_(8), the IRM owner is responsible for reviewing each IRM section annually.


**1.11.2.2.2.1** **(05-08-2014)**

##### Risks When the IRM is not Current

1. The IRS is required to document its operations, policies and procedures and comply with record keeping laws and disclosure requirements of FOIA. Instructions to staff written in the IRM fulfill these requirements. Refer to IRM 1.11.1, Internal Management Document (IMD) Program and Responsibilities.

2. To ensure reliability, the IRS must maintain a current and complete IRM. When the IRM is not current, IRS employees may:



1. Provide taxpayers outdated and possibly inaccurate information.

2. Follow incorrect procedures.

3. Administer the tax laws inconsistently.

4. Operate according to guidance not transparent to the public.


3. In addition, IRM inconsistencies could adversely affect an employee’s evaluation.


**1.11.2.2.3** **(09-13-2023)**

#### When Procedures Deviate from the IRM

1. At times, national program guidance may not apply to the work in all offices in all areas of the country because of special circumstances or other restrictions. In these cases, you may need to deviate from the official procedures in the IRM. Deviations from national program guidance require approval following Delegation Order 1-69, Authorization to Approve an Internal Management Document (IMD), in IRM 1.2.2.2.53.

2. You must issue guidance that deviates from the IRM (even if temporary) through an interim guidance memorandum (IGM), in accordance with IRM 1.11.10, Interim Guidance Process. It must be:



1. Issued formally through a memorandum to affected employees.

2. Reviewed by affected program offices and specialized reviewers (when applicable).

3. Approved following Delegation Order 1-69.

4. Reviewed annually.


3. When preparing a deviation:



1. Summarize the circumstances that require deviation.

2. Identify the applicable IRM section(s).

3. Describe the reason for the deviation (explain what caused the situation to occur and what is being done to correct it).

4. Specify the timeframe the deviation is effective (not longer than two years).


4. If your IRM is on SERP, you must also issue an IPU referencing the deviation.

5. Procedural guidance which deviates from the IRM is subject to FOIA on IRS.gov. For information on E-FOIA criteria and requirements, refer to IRM 1.11.10, Interim Guidance Process.


**1.11.2.2.4** **(07-31-2025)**

#### Address Management and Internal Controls

1. An IRM section involving a program, policy or process must describe its internal control framework in the first subsection. Title this subsection "Program Scope and Objectives." This subsection describes the program objectives and officials charged with program management and oversight. This informs employees about the importance of, and context for, internal controls. The terms associated with internal controls are below in paragraph (4). Definitions for additional terms associated with the IRM process are in _IRM 1.11.2.1.6_, Terms and Acronyms.



### Note:



The only IRMs that don't require internal controls are functional statement IRMs in the 1.1 series, delegation order and policy statement IRMs in the 1.2 series, and obsolete IRMs.

2. As described in IRM 1.4.2, Monitoring and Improving Internal Control, internal controls are the programs, policies and procedures established to ensure:



1. Clear delineation of mission and program objectives and definition of key terms.

2. Establishment of program goals and measurement of performance to assess efficient and effective mission and objective accomplishment.

3. Protection of programs and resources against waste, fraud, abuse, mismanagement and misappropriation.

4. Conformance of program operations with applicable laws and regulations.

5. Complete, current and accurate financial reporting.

6. Usage of reliable information for decision making and quality assurance.


3. The program director is responsible for ensuring IRM internal control content is complete, accurate, and reviewed at least annually, to promote consistent tax administration. This rule is consistent with the annual IRM review requirement in _IRM 1.11.2.2_ , IRM Standards.

4. The IRM must address internal controls by providing an overview of information relating to the program, process or activity. IRM internal controls include the components listed in the table below, in the same order as below. The IRM may include additional components, if any, after those specified in the table.



### Caution:



Do not include instructions to staff within internal controls.








| IRM Internal Control Component | Description of Component |
| :-: | :-: |
| Program Scope and Objectives | Provide a general overview of the program, policy or process in the first subsection, and include:<br> <br>   - Purpose<br>     <br>   - Audience<br>     <br>   - Policy owner<br>     <br>   - Program owner<br>     <br>   - Primary stakeholders<br>     <br>   - Program office contact information (optional) |
| Background | Provide a brief overview of information pertinent to the program, including informational sources on the program’s existence and content in the IRM. |
| Authority | Provide the underlying source authorities of the program, process, or activity. Reference the sources of authority, for example:<br> <br>   - Public law<br>     <br>   - Internal Revenue Code<br>     <br>   - Regulations<br>     <br>   - Policy statements<br>     <br>   - Delegation of authority |
| Roles and Responsibilities | Provide general information on who is responsible for the activities in the IRM section.<br> <br>   - Specify the executive or official by title responsible for program oversight.<br>     <br>   - Describe the role of each official and their responsibilities.<br>     <br>   - Provide management and employee responsibilities. |
| Program Management and Review | Provide a general description of how the program is managed and how effectiveness and objectives are measured. Identify reports used to accomplish these tasks.<br> <br>   - Program reports - List and describe the types, purpose and frequency to support the program objectives.<br>     <br>   - Identify the data sources, storage location or the primary purpose for compiling the data.<br>     <br>   - Program effectiveness - program, operational or quality reviews<br>     <br>   - Institution of oversight councils or process improvement teams |
| Program Controls | Document the program controls developed to oversee the program, such as:<br> <br>   - Embedded management and validation systems<br>     <br>   - Separation of duties/control of user roles<br>     <br>   - Access limitations (passwords for data systems, reports permissions levels, etc.)<br>     <br>   - Written delegations of authority<br>     <br>   - Mandatory use of systems or automated processes<br>     <br>### Note:<br>In rare instances, a program’s controls may overlap with program management and review information. If your program does not have content that applies to both "Program Management and Review" and "Program Controls" , consult with your business unit IMD coordinator on what to include. |
| Terms and Acronyms | Define the key terms included in the IRM content pertinent to the program, objectives, and goals.<br> <br>   - List frequently used acronyms and their definitions.<br>     <br>   - Be specific when defining requirements. Clarify any terms subject to interpretation (particularly measures used for evaluation purposes), such as timely, fair or reasonable.<br>     <br>     <br>     <br>     ### Example:<br>     <br>     <br>     <br>     "Process the adjustment timely."<br>     <br>     <br>     Instead, specify the time frame and write: "Process the adjustment within two workdays of receipt."<br>     <br>   - Place content in an exhibit if it extends beyond one page.<br>     <br>### Note:<br>Terms and acronyms may have separate subsections. |
| Related Resources | List sources employees use to conduct work, such as:<br> <br>   - Websites<br>     <br>   - Published documents<br>     <br>   - Job aids<br>     <br>   - Decision tools<br>     <br>   - Knowledge bases<br>     <br> Place content in an exhibit if it extends beyond one page. |

5. Place information relating to internal controls within the first subsection of the IRM. The following example illustrates how the numbering displays in the IRM:



   - IRM 1.11.2.1, Program Scope and Objectives

   - IRM 1.11.2.1.1, Background

   - IRM 1.11.2.1.2, Authority

   - IRM 1.11.2.1.3, Roles and Responsibilities

   - IRM 1.11.2.1.4, Program Management and Review

   - IRM 1.11.2.1.5, Program Controls

   - IRM 1.11.2.1.6, Terms and Acronyms

   - IRM 1.11.2.1.7, Related Resources


### Note:

Refer to the Internal Controls Template available on the IMD Community Home site.

**1.11.2.2.5** **(07-31-2025)**

#### Functional Statement IRM

1. Business units must publish their functional statements in an IRM section in IRM 1.1, Organization and Staffing. The functional statement IRM provides a high-level description of the business unit’s operations, organizational structure and activities it performs to achieve the IRS mission. The IRM contains the functional statement of the business unit itself, and the functional statements of all program offices within the business unit.

2. The business unit’s functional statement describes its:



   - Mission and how it supports the IRS mission

   - Strategic goals

   - Offices and their primary responsibilities

   - Reporting structure


3. Each program office’s functional statement describes its:



   - Purpose

   - Management and reporting structure

   - Responsibilities and operations


For more information, refer to IRM 1.11.4.3, Functional Statements.



4. Business units must:



1. Publish a functional statement IRM after forming or standing up the business unit.

2. Include a graphic of the business unit’s organizational chart as an exhibit or figure at the end of the functional statement IRM.

3. Revise the functional statement IRM when there’s a reorganization or change to the business unit’s mission or primary responsibilities.

4. Review the functional statement IRM annually to ensure its accuracy.

5. Obsolete the functional statement IRM when a business unit is no longer operational.


5. New business units should use the information in the documentation establishing the office to prepare a functional statement IRM. There is a job aid available on the IMD Community of Practice site to help you prepare functional statements and functional statement IRM sections, refer to Functional Statements.


**1.11.2.3** **(09-13-2023)**

### IRM Format, Structure and Identifying Information

1. The IRS organizes the IRM by business process. IRM format and structure accommodates changes to IRS operations and program responsibilities. As the IRS changes, the IRM may have material added or removed, independent of organizational structure. Refer to IRM 1.11.1.5, IMD Numbering by Business Process.

2. The IRM structure uses a precise numbering scheme, separated by decimals, to identify the content. The first three numbers, which represent the IRM section number, identify the:



   - **Part**: The IRS business process

   - **Chapter**: A major topic within the business process

   - **Section**: A specific topic within the major topic (chapter)


### Example:

The following is the breakdown for IRM 1.11.2:

| Structural Component | Number | Title |
| :-: | :-: | :-: |
| Part | 1 | Organization, Finance and Management |
| Chapter | 11 | Internal Management Document System |
| Section | 2 | Internal Revenue Manual (IRM) Process |

3. Each IRM section is an individually published product. Whenever making a change, whether extensive or minor, you must publish the entire section.

4. Employees can access indexing tools which display the number, title or topic, and owner information about each IRM section.



   - Visit IRM Online to search IRM Indexes by number, owner, audience, title, etc.

   - View Document 10988, Internal Revenue Manual Index, for a list of IRM sections sorted by IRM number, owner/audience, and alphabetically by chapter and section title. This document also provides IRM history, a list of authors and more.


**1.11.2.3.1** **(09-13-2023)**

#### IRM Section Elements

1. Each IRM section consists of the following:



   - IRM section number and title

   - Catalog number

   - Manual Transmittal

   - Table of Contents

   - Subsections (content)

   - Exhibits and figures (when applicable)


2. The following table describes the elements of an IRM section.




| IRM Section Element | Description |
| :-: | :-: |
| IRM section number | - A three-part number aligned under the IRS business process.<br>     <br>   - Each IRM number has a title that describes the content. |
| Catalog number | - A unique five-digit number and letter assigned by M&P.<br>     <br>   - Identifies the product in publishing archives.<br>     <br> Refer to _IRM 1.11.2.3.2_, IRM Catalog Number. |
| Manual Transmittal | - Provides information about the IRM and any changes since the last published version.<br>     <br> Refer to _IRM 1.11.2.6_, Use and Preparation of the Manual Transmittal. |
| Table of Contents | - A list of every IRM subsection, exhibit and figure.<br>     <br>   - The outline format helps readers to easily find information.<br>     <br>   - Automatically generated by the IRM authoring software. |
| Subsection | - A block of text containing instructions or information.<br>     <br>   - A title describes the content.<br>     <br>   - A date identifies when the content became effective.<br>     <br>   - Assigned a number (may be sub-divided up to five subsection levels).<br>     <br>     <br>     <br>     ### Example:<br>     <br>     <br>     <br>     IRM 1.2.3.4.5.6 is a subsection number at the third subsection level:<br>     <br>     <br>     1= Part<br>     <br>     <br>     2= Chapter<br>     <br>     <br>     3= Section<br>     <br>     <br>     4= Subsection1<br>     <br>     <br>     5= Subsection2<br>     <br>     <br>     6= Subsection3<br>     <br> All subsections must contain information or procedures, and authors must number or label each item. Refer to _IRM 1.11.2.5.4_, Display Content, for more information. |
| Exhibit | - Contains text, tables or graphics.<br>     <br>   - Located at the end of the IRM section.<br>     <br>   - Exhibits are consecutively numbered.<br>     <br>### Example:<br>Exhibit 1.11.2-3 |
| Figure | - Located within an IRM subsection paragraph or exhibit.<br>     <br>   - The IRM authoring software numbers figures consecutively throughout the IRM section.<br>     <br>### Example:<br>Figure 4.19.9-2 |


**1.11.2.3.2** **(09-13-2023)**

#### IRM Catalog Number

1. The IRS publishes the IRM at the section level. Upon SPDER’s approval of a new IRM section request, M&P assigns the IRM section a catalog number. The catalog number is a unique string of five numbers and one letter.



### Example:



The catalog number for this IRM section is 29299R.

2. When M&P assigns a catalog number, it is permanently associated with the IRM section and the primary topic. M&P cannot re-use the IRM number nor catalog number unless it's for the same or a similar topic.



1. If an IRM section is obsoleted, SPDER and M&P archive both the IRM number and catalog number.

2. If later reissuing the same or similar topic, SPDER and M&P restore the IRM number and catalog number.


3. For information on catalog number approval, refer to _IRM 1.11.2.4.1.1_, Receive a Catalog Number.


**1.11.2.3.3** **(09-13-2023)**

#### Identify the IRM Owner

1. The business unit primarily responsible for the program owns and manages the IRM content. As explained in _IRM 1.11.2.2.2_, Responsibilities for Maintaining the IRM, owners are responsible for the accuracy of their IRM content. To identify ownership, refer to the relevant functional statement IRM in IRM 1.1, Organization and Staffing.

2. In some cases, two or more program offices in different business units may contribute to the content of an IRM section; however, only one business unit can be the primary owner.

3. The following indexing tools list the IRM owners. Refer to these tools to determine who to contact when you have a question or concern involving a particular program:



   - IRM Online: Research the currently effective IRM hypertext markup language (HTML) format.

   - IRM Numerical Index : Access the most recently published and historical versions of the IRM in portable document format (PDF). The most current version is also available in extensible markup language (XML) format.


**1.11.2.3.4** **(09-13-2023)**

#### Identify the IRM Author

1. Management assigns analysts or frontline employees as IRM authors. IRM authors are responsible for preparing program procedures and guidelines. Frequently, authoring an IRM section is a collateral responsibility. Authors work closely with their IMD/IRM coordinators. Refer to IRM 1.11.1.6.7, IMD Authors, for roles and responsibilities.

2. M&P updates the author's contact information on the "Product Catalog Results" page for each published product as the "Content POC." M&P obtains the author information from the Form 1767, Publishing Services Requisition.

3. You also may find the author information in the indexing sources listed above in _IRM 1.11.2.3.3_, Identify the IRM Owner.


**1.11.2.4** **(09-13-2023)**

### Create New or Change Existing IRM Sections

1. When the IRS makes changes to the structure or the work of a business unit, this can cause changes to:



   - Numerical placement of an IRM

   - An IRM title

   - An IRM owner


2. Business units may need to request new IRM sections or change the title, number, owner or author of an existing IRM section. To ensure conformity and continuity across the IRM and among all business units and owners, SPDER controls and assigns all IRM numbers and titles. SPDER also approves and records all types of IRM changes.

3. Get your manager’s approval before requesting a new IRM section or change to an existing IRM section.


**1.11.2.4.1** **(07-31-2025)**

#### Request a New IRM Chapter or Section

1. To initiate a new IRM chapter or section, the responsible program office completes the IRM Request Form at IRM Requests and Author Changes, as follows:




| Form Field | Input for a New Section Request | Input for a New Chapter and Section Request |
| :-: | :-: | :-: |
| Requestor’s Information | - Name and role<br>     <br>   - Business unit; select from the drop-down menu | - Name and role<br>     <br>   - Business unit; select from the drop-down menu |
| Request Type | Select "New IRM Section" from the drop-down menu. | Select "IRM Chapter and Section" from the drop-down menu. |
| IRM Information | - Part and chapter numbers; these are lookup fields and the titles will automatically generate<br>     <br>   - Proposed title for new section<br>     <br>     <br>     <br>     ### Note:<br>     <br>     <br>     <br>     Follow guidelines in _IRM 1.11.2.4.2_, Create or Change an IRM Title when proposing a title.<br>     <br>   - Describe the request; for example, the IRM section incorporates content from another IRM section, content is being merged, content is completely new, etc. Specify the effect on any existing documents or IRM sections.<br>     <br>   - Provide the business reason for the request; for example, the stand-up of a new program office or transfer of content ownership. | - Part number; this is a lookup field and the part title will automatically generate<br>     <br>   - Proposed title for new chapter<br>     <br>   - Proposed title for new section<br>     <br>     <br>     <br>     ### Note:<br>     <br>     <br>     <br>     Follow guidelines in _IRM 1.11.2.4.2_, Create or Change an IRM Title when proposing a title.<br>     <br>   - Describe the request; for example, content is being merged, content is completely new, etc. Specify the effect on any existing documents or IRM sections.<br>     <br>   - Provide the business reason for the request; for example, the stand-up of a new program office or transfer of content ownership. |
| Attachments | Upload any files or documentation that explain and support the request; for example, an outline of the new section, a crosswalk table that demonstrates incorporation of content from another IRM section, email documentation of managerial approval, etc. | Upload any files or documentation that explain and support the request; for example, an outline of the new section, a crosswalk table that demonstrates incorporation of content from another IRM section, email documentation of managerial approval, etc. |
| Audience | By business unit, program office or job category, identify the employees expected to follow the procedures or benefit from the information. | By business unit, program office or job category, identify the employees expected to follow the procedures or benefit from the information. |
| Identifying Information | - Author’s name, telephone number and office symbols (if different from the requestor)<br>     <br>   - Program director (search by last name)<br>     <br>   - Business unit IMD coordinator (search by last name | - Author’s name, telephone number and office symbols (if different from the requestor)<br>     <br>   - Program director (search by last name)<br>     <br>   - Business unit IMD coordinator (search by last name |



    Press the Save button when finished. The system will auto generate an email to the business unit IMD/IRM Coordinator.



2. The IMD/IRM coordinator:



1. Reviews the request to ensure it’s accurate and complete.

2. Edits the request, if needed or **Return to requestor** for additional information.

3. Approves the request as appropriate. The system will auto generate an email to the SPDER office.


3. The SPDER office:



1. Reviews the request to determine if the information duplicates existing or historical IRM content.

2. Determines under which business process the content belongs (IRM part and chapter).

3. Assigns a unique IRM chapter or section number and requests a catalog number from M&P.

4. Ensures the title sufficiently describes the content. Refer to _IRM 1.11.2.4.2_, Create or Change an IRM Title, for more information.

5. Returns the request indicating approval.

6. Adds the title to the official IRM Part and Chapter list. Refer to IRM Part and Chapter Titles.


**1.11.2.4.1.1** **(09-13-2023)**

##### Receive a Catalog Number

1. Upon approving a new IRM section request, SPDER contacts M&P to request a catalog number. The table below describes the actions SPDER takes when working new catalog number requests:




| If the IRM is | And | Then SPDER |
| :-: | :-: | :-: |
| New | All the material is new | Requests a new catalog number. |
| New | You move a portion of the material from one IRM section to a new IRM section | Requests a new catalog number. |
| Obsolete | You reinstate a formerly obsolete program, procedure or activity | Provides the original catalog number from the obsolete IRM section having substantially the same subject and title. |

2. When you reinstate an IRM section, you are reissuing a previously published IRM involving the same or substantially similar business process that is currently obsolete. In this case it’s only necessary to contact SPDER at \*SPDER if:



1. The content differs substantially from the prior revision.

2. You revise the IRM title.

3. The owning business unit changes. In this case, refer to _IRM 1.11.2.4.3_, Change the IRM Owner, for guidance.


**1.11.2.4.2** **(07-31-2025)**

#### Create or Change an IRM Title

1. The IRM part title describes the business process. The chapter title describes the primary topic, and the section title describes a specific topic within the primary topic. Titles must describe these topics.

2. When creating a title:



1. Make it short but descriptive enough that the reader can identify the program, process or activity.

2. Use keywords to help the IRM show up in online searches.

3. Avoid using the name of an office, business unit, or organization unless it describes the program or activity.

4. Don’t use punctuation such as a hyphen (-) or slash (/).


### Note:

These rules also apply to IRM elements, including subsections and exhibits.

3. To change a chapter or section title:




| Step | Action |
| :-: | :-: |
| 1 | Consult with your management and/or your IMD/IRM coordinator. |
| 2 | After you receive managerial approval, complete the IRM Request Form at IRM Requests and Author Changes and provide the following information:<br> <br>   - Requestor’s name, role and business unit<br>     <br>   - Request type; select the appropriate Title Change option from the drop-down menu<br>     <br>   - For chapter title change requests: The current part and chapter numbers; current titles will auto-populate<br>     <br>   - For section title change requests: The IRM’s catalog number; the section title will auto-populate<br>     <br>   - Proposed new title<br>     <br>   - Business reason for recommending the title change<br>     <br>   - Applicable attachments<br>     <br>   - Author’s name, telephone number and office symbols (if different from the requestor)<br>     <br>   - Program director (search by last name)<br>     <br>   - Business unit IMD coordinator (search by last name |
| 3 | The business unit IMD/IRM coordinator then reviews the request. Upon approval, an auto generated email is sent to SPDER. |
| 4 | SPDER considers the request and either approves it or requests additional information. |
| 5 | After SPDER approval, revise the IRM XML file to reflect the new title(s) as appropriate. The new title will be displayed when the IRM is next published.<br> <br>### Reminder:<br>When revising the IRM file, address the title change in the material changes of the Manual Transmittal, as the first change. |


**1.11.2.4.3** **(07-31-2025)**

#### Change the IRM Owner

1. A corporate reorganization or change in program responsibilities may change the owner of a business process or activity.

2. When an IRM owner changes at the business unit level, complete the IRM Request Form at IRM Requests and Author Changes, as follows:




| Form Field | Input |
| :-: | :-: |
| Requestor’s Information | - Name and role<br>     <br>   - Business unit; select from the drop-down menu |
| Request Type | Select "IRM Owner Change" from the drop-down menu. |
| IRM Information | - The IRM’s catalog number; the section title will auto-populate<br>     <br>   - New business unit name<br>     <br>   - Effective date of the change<br>     <br>   - Business reason for proposal: explain why the IRM section is being transferred |
| Attachments | Upload any files or documentation that show the ownership transfer is approved, such as emails. |
| Audience | By business unit, program office or job category, identify the employees expected to follow the procedures or benefit from the information. |
| Identifying Information | - Author’s name, telephone number and office symbols (if different from the requestor)<br>     <br>   - Program director (search by last name)<br>     <br>   - Transferring business unit IMD coordinator (search by last name<br>     <br>   - Receiving business unit IMD coordinator (search by last name |



    Press the Save button when finished. The system will generate an auto email to the requestor IMD/IRM coordinator(s).



3. The business unit’s IMD/IRM coordinator(s) reviews the request. Upon approval an auto email is generated to SPDER.

4. SPDER acknowledges the change in ownership. Then, the author must:



1. Make the necessary changes to the IRM XML file (including changing all the metadata fields).

2. Publish the IRM and ensure all data sources (IRM Online, IRM Index, Publishing catalog page, SERP) reflect the ownership change.


**1.11.2.4.4** **(09-13-2023)**

#### Change the IRM Author

1. When reassigning an IRM section, the new author (or IMD/IRM coordinator) takes the following steps to update the information displayed on the Product Catalog Results page:



1. Notify the business unit IMD/IRM coordinator.

2. Complete the Author Change Request form at IRM Requests and Author Changes. Specify the IRM section catalog number, previous author’s name, and new author’s information.


2. Once the request is complete, M&P is automatically notified and they update the Product Catalog Results page.

3. If the IRM is hosted on SERP, also contact the SERP program office to update the author information on the SERP site. Follow the instructions in IRM 1.11.8.3, Authorized Submitter.


**1.11.2.5** **(09-13-2023)**

### Write the IRM

1. To ensure IRS instructions are accurate and complete, create or revise an IRM section to:



1. Incorporate interim guidance

2. Address process improvements and operational and procedural changes

3. Reflect new or revised legislation

4. Revise guidance based on a Chief Counsel opinion

5. Remove outdated and duplicated content

6. Incorporate employee recommendations and feedback, following _IRM 1.11.2.5.1.3_, Consider Requested IRM Changes.

7. Clarify or reorganize content

8. Review the IRM for editorial changes, following _IRM 1.11.2.8_, Editorial Updates.


### Note:

_Exhibit 1.11.2-2_, Most Common Reasons to Review the IRM. Lists the most common reasons to review the IRM.

**1.11.2.5.1** **(07-31-2025)**

#### Authoring Process - First Steps and Training

1. IRM authors are to take the following actions and training when first assigned to write or update an IRM section:



1. Locate your IMD coordinator on the Internal Management Documents Community site under the Who to Contact tab.

2. Obtain manager approval before taking any courses.

3. Contact your business unit IMD coordinator for business unit training and tracking IRM section assignments.

4. If you are a new author, register as a user of the IRM authoring software at Arbortext Editor Registration.

5. Install the Arbortext Editor IRM software by following the instructions at “Arbortext Installation Instructions” on Arbortext Editor Training web page.



      ### Caution:



      Ensure you request and receive the Arbortext Editor version customized for IRMs, **_not Tax Forms and Publications_**.

6. Join the IMD Community TEAM to receive alerts via TEAMS channel and email communications to your inbox.


2. As a new author, complete all SPDER IRM authoring courses listed on the IMD Community of Practice, IRM Authoring Curriculum. The IRM authoring courses can be added to an author's ITM learning plan upon request and approval of the employee’s manager. To have the courses added, send an email to \*SPDER that includes your name and HR connect or employee ID number. Include your manager and IMD Coordinator. Refer to list of ITM courses available:




| ITM | Course | Description |
| :-: | :-: | :-: |
| 59521 | Introduction to the IRM for All Employees | This course introduces students to the Internal Revenue Manual. It defines the IRM, explains its purpose and stresses the importance of using the IRM. The course explains the IRM structure, format and numbering scheme. Students learn about the different IRM platforms, how they are updated and where to find them. They are introduced to various IRM supplemental sources and how they support the IRM.<br> <br>### Note:<br>Pre-requisites to ITM course 15770, IRM Authoring Tool Training (Arbortext Editor - Classroom) |
| 26675 | Overview of the IRM Online | The course covers how to use the IRM Online to conduct tax and procedural research in the IRM.<br> <br>### Note:<br>This is an instructor online led course. |
| 80730 | IRM Authoring: Organizing and Structuring IRMs | This course provides foundational knowledge for IRM authoring: categorization of Servicewide IRM sections, the IRM section numbering scheme, IRM section elements and the basics of IRM subsection structure.<br> <br>### Note:<br>Pre-requisites to ITM course 15770, IRM Authoring Tool Training (Arbortext Editor - Classroom) |
| 15770 | IRM Authoring Tool Training (Arbortext Editor - Classroom) | This course teaches authors and coordinators how to use the IRM authoring tool to create and edit IRM files in the proper IRM format.<br> <br>### Note:<br>This is an instructor led, IN-PERSON course. |
| 28309 | What Belongs in the IRM | This course explains the type of information that should be contained in an IRM and introduces the IRM Decision Tool. |
| 57131 | IRM Authoring: Fundamentals of Writing the IRM | This course teaches authors how to deliver a well-written IRM section. The course discusses placing primary program instruction in the IRM, using IRM structure and titles to organize content, style and formatting rules, plain language, and more. |
| 28317 | IRM PDF Graphics | This course provides general information on graphics and their use in the IRM file. |
| 28319 | Manual Transmittal Essentials | This course covers the fundamentals of the manual transmittal. It discusses the required and optional elements as well as the extensible markup language (XML) used to create or revise the MT section of the IRM. |
| 28327 | Introduction to the Interim Guidance Process | This course describes the types of interim guidance and how to prepare and issue it. |
| 19707 | IRM Authoring: Clearing the IRM | This course describes the internal management documents (IMDs) clearance process and provides procedures that support the process. |
| 28321 | IRM Authoring: Publishing the IRM | This course details how to publish an IRM section. |

3. ITM course 15770, IRM Authoring Tool (Classroom) is an in-person and instructor led training course. You may be required to travel to attend. Ensure the proper offices (business unit finance office, management, etc.) are aware of your need to travel if applicable. Self-registration to attend this course is available through the ITM platform. Go to the Arbortext Editor Training on SPDER SharePoint for steps to self-register.



### Note:



Two prerequisite courses are required for this course, ITM course 59521, Introduction to the IRM for All Employees and ITM Course 80730, IRM Authoring: Organizing and Structuring IRMs.


**1.11.2.5.1.1** **(07-31-2025)**

##### Prepare to Write or Revise Content

1. Take the following actions when preparing to _write a new IRM section_:



1. Identify the IRM’s audience.

2. Organize information by process, in order of importance, and in order of occurrence.

3. Prepare an outline.

4. Request a new IRM section number following _IRM 1.11.2.4.1_, Request a New IRM Chapter or Section.


2. Take the following actions when preparing to _revise an existing IRM section_:




| Step | Action |
| :-: | :-: |
| 1 | Gather all related interim guidance, policies, legislation and issues raised since the last IRM revision. |
| 2 | Examine _all_ content, even existing subsections you do not plan to edit. If any content is outdated or does not reflect current operations, you must revise it. |
| 3 | Discuss your planned IRM changes with your manager, including changes to work practices, procedures, delegated authorities (delegation orders), or policies utilized by or impacting bargaining unit employees. Refer to _IRM 1.11.2.5.1.4_, IRM Changes Affecting Conditions of Employment of Bargaining Unit Employees. |
| 4 | Download the IRM XML file from the official repository of published products:<br> <br>1. Open IRM Numerical Index.<br>      <br>2. Select the part number of your IRM section. Then click on the "Cat. No." hyperlink for your IRM section. This opens the Product Catalog Results page for that IRM section.<br>      <br>3. Scroll down the page to the "Get XML Format" section.<br>      <br>4. Right-click on the current version in "MM-DD-YYYY" format.<br>      <br>5. Select "Save link as" and choose the location where you want to save the file.<br>      <br>### Exception:<br>If an IRM Procedural Update (IPU) has been issued since the IRM was last published, use the last tracked change XML file submitted to SERP. |


**1.11.2.5.1.2** **(09-13-2023)**

##### Writing Rules

1. Draft new or revised content following these rules:



01. Write content using the IRM authoring software. Review Authoring the IRM with Arbortext Editor (Coursebook) for assistance.

02. Include or update the program scope and objectives, audience and other internal control components per _IRM 1.11.2.2.4_, Address Management and Internal Controls. Ensure titles and organizational names are current.

03. Write to the identified audience.

04. Create subsection titles that are concise and clearly describe the content. Refer to _IRM 1.11.2.4.2_, Create or Change an IRM Title.

05. Structure and display content following the guidelines in _IRM 1.11.2.5.4_, Display Content.

06. Write in plain language so your audience can easily find and understand the instructions. Refer to _IRM 1.11.2.5.7_, Write in Plain Language.

07. Avoid duplicating procedures covered in another IRM section or published document; refer to that IRM instead. Refer to _IRM 1.11.2.5.8.1_, Cite the IRM.

08. Check all references and links. Refer to _IRM 1.11.2.5.8.4_, Validate Links.

09. Follow the style rules in Document 12835, The IRM Style Guide.

10. Review existing content for clarity, remove unnecessary content, and add or rearrange content to improve readability.


2. Consult with authors of other IRM sections that contain similar or related material to ensure clear and consistent guidance.



1. Use IRM Online’s keyword search function to identify other IRM sections that have related content and may be impacted by your changes.

2. Identify the owner/author of an impacted section by viewing the IRM’s Catalog page. Catalog pages can be found at IRM Numerical Index or through M&P’s Find a Product search page.


3. Keep track of all edits for inclusion in the Material Changes. Refer to _IRM 1.11.2.6.1.3_, Manual Transmittal Material Changes.

4. Coordinate an informal review with stakeholders. Refer to _IRM 1.11.2.7_, Conduct an Informal Review.

5. Review your draft for accuracy, formatting, functioning links and plain language, and ask others to review it also. Form 15418, IRM Package Check Sheet, can be used to ensure IRMs meet IRM 1.11 standards.


**1.11.2.5.1.3** **(09-13-2023)**

##### Consider Requested IRM Changes

1. Employees or affected program offices may suggest corrections or content changes to the IRM. Refer to IRM 1.11.6.5, Providing Feedback About an IRM Section - Outside of Clearance, for the various methods to give feedback.

2. To ensure the quality and consistency of IRM procedures, IRM authors evaluate all change requests and respond to requests for substantive IRM changes. A change is substantive if it involves a procedural or operational matter.

3. When you (the author) receive a written request that may require an IRM revision:



1. Acknowledge receipt of the recommendation within two weeks. Include an expected response date.

2. Review and consider the recommendation for acceptance.

3. Respond with any actions within _45 days_, including projected time frames.


### Note:

When responding to feedback received through SERP, refer to IRM 1.11.8.10, SERP Feedback - Author/Content Owner Responsibilities, for additional guidance.

4. When you don’t agree to adopt a recommended change that the requestor believes could adversely affect their program, the requesting office may elevate the issue to your manager and/or program director.

5. When you accept the recommendation, make the change by either:



1. Incorporating it in the next IRM revision, not to exceed two years from the date of the request.

2. Issuing IG if the content is substantive and is needed before the IRM can be updated. Refer to IRM 1.11.10, Interim Guidance Process, for instructions on issuing interim guidance.


6. Document the issue and resolution in the IRM document clearance record (DCR) package maintained in the IRS Historical Research Library. Refer to IRM 1.11.9.10.5, Archiving Clearance Documents.



1. If you do revise the IRM based on the recommended change, document the resolution and disposition of the recommendation and email the IRS Historical Research Library at \*IRM Library when the IRM is next published.

2. If you don’t revise the IRM based on the recommendation, send the information documenting the resolution and disposition to the IRS Historical Research Library for association with the IRM DCR package.


7. Include the following in the IRM DCR package:



1. The issue described by the employee or program office requesting the change.

2. The response and decision by the program office.

3. Any documentation or communications with and between management.


**1.11.2.5.1.4** **(07-31-2025)**

##### IRM Changes Affecting conditions of Employment of Bargaining Unit Employees

1. Along with their management, authors **must** evaluate all IRM changes for potential impact to conditions of employment of bargaining unit employees _while authoring and before starting the clearance process_. Conditions of employment means personnel policies, practices and matters affecting working conditions.



### Note:



If there are questions about whether a change impacts the conditions of employment of bargaining unit employees, the author or their manager must elevate them to Labor/Employee Relations & Negotiations (LERN) at Labor/Employee Relations & Negotiations Contacts for evaluation.

2. Follow the instructions below for the appropriate course of action:




| **If** | **Then** |
| :-: | :-: |
| The change is editorial | There is no impact to conditions of employment of bargaining unit employees and it is not necessary to contact LERN prior to clearance. |
| The change has no impact on the conditions of employment of bargaining unit employees | It is not necessary to contact LERN prior to clearance. |
| The change impacts the conditions of employment of bargaining unit employees. Refers to personnel policies, practices, and matters impacting a bargaining unit employee’s daily work life, such as, but not limited to:<br> <br>   - Work processes or assignments<br>     <br>   - Schedules<br>     <br>   - Overtime<br>     <br>   - Equipment<br>     <br>   - Office space/design<br>     <br>   - Parking<br>     <br>   - Type/placement of office furniture relocation of an office and all items addressed per Article 47, Section 5 of Document 11678, National Agreement | The author or their manager completes Form 14036, Notice to National NTEU, and emails the form to LERN at \*HCO LERN Review/Comment. LERN will determine if there is an obligation to provide formal notice and bargaining with NTEU before clearance can begin.<br> <br>### Note:<br>For questions about completing the form, you may contact LERN at Labor/Employee Relations & Negotiations Contacts.<br> Once Form 14036, Notice to National NTEU, is sent to LERN, clearance is on hold until LERN notifies the IRM author or their manager that clearance may begin. Refer to paragraph three below. |

3. LERN reviews Form 14036 and required attachments (briefing and crosswalk) and notifies the IRM author and/or manager with the determination:



1. If the change(s) do(es) **not require** notice and bargaining with NTEU, the IRM author or manager may proceed with the changes and start the review/clearance process. Follow IRM 1.11.9.4.4(3), Labor/Employee Relations & Negotiations.

2. If the change(s) **do(es) require(s)** notice and bargaining with NTEU, clearance remains on hold until LERN advises the author or manager that bargaining obligations have been met and clearance may begin. When the author receives notification to begin clearance, follow IRM 1.11.9.4.4(3), Labor/Employee Relations & Negotiations.


**1.11.2.5.1.5** **(09-13-2023)**

##### Removing Substantive Content from an Existing IRM Section

1. If you plan to delete IRM procedures that are still in use and affect employees’ working conditions or evaluations, coordinate with the program office that is now responsible for the guidance.



### Note:



When determining who owns the IRM content, refer to _IRM 1.11.2.3.3_, Identify the IRM Owner.

2. To protect continuity of operations, the responsible program office must issue the guidance in an IRM or interim guidance either before or at the same time that it’s removed from the current IRM section.

3. Work with your business unit’s IMD coordinator and management, if necessary, to arrange for the transfer of content, develop a clear action plan, and coordinate the timing of revisions. Change the IRM owner following the instructions in _IRM 1.11.2.4.3_, Change the IRM Owner.

4. The material changes of both IRM sections must indicate the relocation of content, including the previous and new locations, following _IRM 1.11.2.6.1.3_, Manual Transmittal Material Changes, and if applicable, _IRM 1.11.2.9_, Rules to Obsolete an IRM Section.


**1.11.2.5.2** **(09-13-2023)**

#### Determine IRM Dates

1. The IRM requires content specify the effective date when making certain decisions or changes for each published revision. The types of IRM dates include:



   - Manual Transmittal (MT) date

   - IRM effective date

   - Subsection date

   - Revision date


2. The table below defines each type of IRM date and the proper date format:




| IRM Date Type | Definition | Date |
| :-: | :-: | :-: |
| MT date | This is the date M&P publishes the IRM section and posts in the Core Repository of Published Products (housed on the Electronic Publishing website). | Month DD, YYYY<br> <br>### Note:<br>M&P inserts the MT date in the IRM XML file. |
| Effective date | This is the date the new or revised IRM section is effective. The IRM effective date can be:<br> <br>1. The same date as the MT date, or<br>      <br>2. A specific _future_ date. | - (MM-DD-YYYY) - wild card date format. The _wild card date_ reflects the MT date.<br>     <br>   - (12-01-2022) - a specific date.<br>     <br>### Reminder:<br>A filing season IRM requires a specific effective date. |
| Subsection date | This is the effective date of the information in the IRM subsection. The subsection date can be:<br> <br>1. The same date as the revision date, or<br>      <br>2. The _effective date._<br>      <br>### Note:<br>When you substantially revise the information in a subsection, change the date. Refer to _IRM 1.11.2.5.2.1_, Determine the Subsection Date. | (MM-DD-YYYY) - wild card date format.<br> Specific Date: (12-01-2022) |
| Revision date | This date reflects the MT date. The revision date only appears in PDF versions of the IRM and Document 10988, IRM Index. | - PDF IRM: (MM-DD-YYYY)<br>     <br>   - IRM Index: MM-YYYY |

3. Follow these rules when the IRM section is effective on a specific date:



1. The IRM effective date must be the same date as, or a later date than, the MT date. To meet the effective date, you must provide M&P with enough time to process the IRM. This is especially critical for IRMs published during filing season, between August through December.

2. All revised subsections must match the effective date. You can’t use a wild card date.


4. When adding or revising information that becomes effective on a specified date, insert the date in both the MT effective date element and the affected subsection date(s).



### Example:



M&P publishes an IRM section on November 15, 2021, but the procedures are not effective until January 1, 2022.






| Date Type | Date and Format |
| :-: | :-: |
| MT date | November 15, 2021 |
| IRM Effective date | 01-01-2022 |
| Subsection dates | 01-01-2022 |
| Revision date | - 11-15-2021 in the PDF IRM<br>     <br>   - 11-2021 in the IRM Index |

5. For additional information on MT dates, refer to _IRM 1.11.2.6.1_, Required Elements of the Manual Transmittal.


**1.11.2.5.2.1** **(09-13-2023)**

##### Determine the Subsection Date

1. When you make a substantive change to an IRM section, change the subsection date to the date it is effective. A change is considered substantive if it involves a procedural or operational matter. Refer to _IRM 1.11.2.6.1.6_, Effective Date for the definition.

2. The table below provides the rules for determining the subsection date:




| If the subsection | Then the subsection date is the |
| :-: | :-: |
| Contains substantive changes | IRM effective date. |
| Changes are editorial but there are substantive changes in other subsections | Existing subsection date. Do not change the subsection date for these editorial changes since they have no effect on the content itself. |
| Changes are editorial and the IRM is being updated **only** for editorial reasons (there are no substantive changes anywhere else in the IRM section) | Date as instructed in _IRM 1.11.2.8.1_, Editorial Update Process. |
| Incorporates content from an issued IPU with _no_ subsequent substantive changes | IPU issue date. |
| Incorporates content from an issued IPU with subsequent substantive changes | IRM effective date. |
| Incorporates content from an interim guidance memorandum (IGM) with _no_ subsequent substantive changes | IGM effective date. |
| Incorporates content from an IGM with subsequent substantive changes | IRM effective date. |


**1.11.2.5.3** **(09-13-2023)**

#### Designate IRM Content as Official Use Only (OUO)

1. An OUO designation prevents automatic distribution to the public of materials exempt from the FOIA where disclosure carries a reasonable expectation of harm to a government interest or to a personal privacy interest. Refer to IRM 11.3.12, Designation of Documents.

2. The IRS considers material OUO when restricted for official purposes by individuals authorized by Delegation Order 11-1, Administrative Control of Documents and Material (as revised) in IRM 1.2.2.12.1. Refer to Delegation Order 1-69, Authorization to Approve an Internal Management Document (IMD), in IRM 1.2.2.2.53, for approval and authorization of IMDs containing OUO content.

3. IRMs containing newly designated OUO information require clearance through Privacy, Governmental Liaison and Disclosure (PGLD) at \*PGLD IMD SPOC. Refer to IRM 1.11.9.4.2, Privacy, Governmental Liaison and Disclosure.

4. The following examples of IRM content may require a designation of OUO:



   - Instructions relating to enforcement strategies, tolerances and criteria where public release would lead to a reasonable expectation of harm to IRS actions or operations.

   - Material where public release would significantly impede or nullify IRS actions in carrying out a responsibility or function.

   - Data processing information that would result in taxpayers altering their filing practices or avoiding payment of taxes.


### Note:

Generally, do not classify employee contact name and phone numbers as OUO. Refer to _IRM 1.11.2.5.5_, Contact Information.

5. Any IRM section can contain OUO content.



### Reminder:



You must follow other privacy and security guidance to protect sensitive information, whether electronic files or in paper. Encrypt documents containing sensitive information when sending out via email or saving to a hard drive. Refer to IRM 10.5.1.6.8, Email and Other Electronic Communications, and IRM 10.8.1, Policy and Guidance.

6. The program office owning the IRM determines if content is OUO. For assistance with a determination of the reasonable harm of a specific OUO determination, send an email with the subject line "Informal Assistance Request" to \*PGLD IMD SPOC.

7. Tag IRM content that is OUO using the IRM authoring software to show it’s restricted content. When published, the public version automatically redacts tagged information. To tag content OUO in the IRM XML file:



1. Modify attribute on "manual tag" to hasouo= "yes."

2. Properly mark OUO material embedded in the text with a "restrict" tag or attribute.

3. When an IRM graphic contains any OUO information, you must insert a restrict tag or attribute to avoid releasing sensitive information. When you insert the restrict tag or attribute, the IRM authoring software restricts the entire graphic.


**1.11.2.5.4** **(09-13-2023)**

#### Display Content

1. Display and place content in manageable pieces so it’s easy to read and the user can quickly find what they’re looking for.




| Use a(n) | To |
| :-: | :-: |
| Paragraph | Display body content.<br> <br>   - All IRM body content must be placed inside a paragraph.<br>     <br>   - The text always starts with a numbered paragraph.<br>     <br>   - Paragraphs can contain lists, tables, notes and figures.<br>     <br>### Caution:<br>Do not create an unnumbered or split paragraph using a break or a table. This is known as a dangling paragraph and is not permitted in the IRM. |
| Additional paragraph | Break up long bodies of text. |
| List | Display information, procedures or actions. List types include:<br> <br>   - Bullet<br>     <br>   - Alphabetical ("alpha" )<br>     <br>   - Numerical ("step" ) |
| Table | 1. Provide data.<br>      <br>2. Present conditional information (If/Then).<br>      <br>3. Present procedures in a specific order (step/action).<br>      <br> Refer to _IRM 1.11.2.5.4.1_, Tables, for more details. |
| List or table | 1. Simplify complex material.<br>      <br>2. Break up long bodies of text.<br>      <br>3. Make it easier to find information. |
| Note (reminder, caution, etc.) | Emphasize a point, remind, or make aware.<br> <br>### Caution:<br>Do not use these tags to convey procedures. |
| Example | Illustrate a concept. |
| Figure | Display a graphic within the text. |
| Exhibit | Display:<br> <br>   - A lengthy table or list<br>     <br>   - Text containing a varied format<br>     <br>   - A completed form, letter or prototype<br>     <br>   - A graphic |
| Break | Place content on a separate line inside a table or an example, _not inside a list or paragraph._ |
| Block paragraph | Display a quote or address. |





### Note:



For more information on using these in your IRM section, review Document 12835, The IRM Style Guide.

2. Do not reserve a subsection for future use. Placeholders are not permitted in the IRM.


**1.11.2.5.4.1** **(09-13-2023)**

##### Tables

1. A table is a useful way to present information clearly and concisely, particularly if it’s complex. Use a table to provide data or present instructions that are conditional or must follow a particular order.



1. For instructions on inserting a table into the XML IRM file, refer to Authoring the IRM with Arbortext Editor (Coursebook), referenced in _Exhibit 1.11.2-3_, IRM Web Resources.

2. For useful tips on using tables, refer to Document 12835, The IRM Style Guide.


2. To comply with Section 508 of the Rehabilitation Act for persons with disabilities, take the following steps when placing a table in the IRM:



1. For a table with a column title, designate the first row as the header row. By taking this action, the header row displays in bold font and repeats on continuation pages of the paper IRM.

2. Precede the table with a sentence or paragraph that introduces or summarizes the contents. Copy the sentence or paragraph and insert it into the summary attribute of the table tag.

3. Don’t merge or span cells, vertically or horizontally. Display the information either by entering information in each row or column or placing the information in a separate table.


**1.11.2.5.4.2** **(09-13-2023)**

##### Graphics

01. A graphic is a picture. The graphic may depict a flowchart, graph, form or logo. A figure or an exhibit may display a graphic. Create a graphic separately from the IRM XML file.

02. Ensure graphics do not contain personally identifiable information (PII) by following the guidelines in _IRM 1.11.2.5.6_, Fictitious Identifying Information. If you discover a breach, follow _IRM 1.11.2.5.6.1_, Personally Identifiable Information (PII) or Federal Tax Information (FTI) Breach Actions.

03. To publish a graphic in the IRM, the graphic must meet the following requirements.



    - _Format:_ Create the graphic in PDF.

    - _Color:_ Use black and white or grayscale.



      ### Exception:



      M&P only allows color to some Part 3 IRMs, based on their approval.

    - _Orientation:_ Display in portrait or landscape. (Only place a landscape-oriented graphic in an exhibit.)

    - _Name:_ Use an eight-digit graphic file name. Refer to paragraph (4) below for an explanation.

    - _File limitations:_ Prepare one graphic page for each PDF. If a graphic is two pages or more, save each graphic page to a separate PDF.



      ### Note:



      M&P does not accept photos or gradients.


04. A graphic is associated with the IRM by a graphic number. The author inserts the graphic number in the IRM XML file. The graphic number is an eight-digit graphic file name comprised of the IRM catalog number (without the alpha character) followed by three unique numbers assigned by the author.



    ### Example:



    IRM 3.11.6’s catalog number is 33455F. The first graphic is named 33455001.

05. A graphic that displays on more than one page requires a graphic filename for each graphic page and an associated PDF for each graphic page. Insert the graphic tag for each of the pages in the IRM XML file.

06. To insert a graphic in the IRM XML file:



    1. Prepare the graphic in PDF.

    2. Review the graphic content for accuracy.

    3. Assign each graphic page a graphic number. Use the IRS Tools − Show Graphic File list (on the Arbortext toolbar) to verify the number hasn’t been used.

    4. Insert the graphic file number in the IRM XML file.

    5. Insert a graphic descriptor for each graphic page in the XML file. If the text surrounding the graphic sufficiently describes the graphic content, the graphic descriptor must reference such paragraph(s).

    6. Send the graphic(s) along with the XML file when forwarding for publishing.

    7. Insert a restrict tag when a graphic contains OUO content.


### Note:

Verify your graphic file numbers by using the "show graphic file list" on the tool bar under IRS Tools. By doing so, you’ll prevent duplicating a graphic file name.

07. When submitting graphics to M&P with your IRM file:



    1. Submit only the new or changed graphic page(s). Refer to IRM 1.11.5.4, Submitting the IRM Publishing Package.

    2. Submit the original source document for the graphic to the IRM Source Graphic link on the IRM Upload page at IRM Processes for future use. Refer to _IRM 1.11.2.5.4.2.2_, Store IRM Graphic Files.


08. Because the graphic is a picture or illustration, electronic media or employees with impaired vision (who use assistive technology such as a Job Access for Windows and Speech (JAWS) reader) cannot read the content. For example, when a user conducts a key word search, the graphic content is not accessible. Refer to _IRM 1.11.2.5.4.2.3_, Use Alternative Text for Graphics.

09. Consider other ways to present the information, as illustrated in the following examples:




    | Example | Options |
    | :-: | :-: |
    | A letter or memo on official stationery | 1. If the primary audience includes employees with web access, insert a web link to the memo or letter.<br>       <br>    2. If employees don’t have web access, type the letter/memo (text) into the IRM authoring software and describe the stationary used (or describe the logo). |
    | Display a table | 1. Insert the information into a table in the IRM authoring software.<br>       <br>    2. Import the table from an Excel file into the IRM authoring software. |

10. Avoid graphics that are simply screenshots of an IRS published product; use links instead.

11. Additional tips for creating a graphic:



    1. When updating your IRM, review the graphic content.

    2. When creating a graphic with a logo and the content is primarily text, insert the text in the XML file using a table. Specify the type of stationary in brackets.

    3. Follow the editorial update process when improving the quality or display of an IRM graphic. Refer to _IRM 1.11.2.8_, Editorial Updates


**1.11.2.5.4.2.1** **(09-13-2023)**

###### Convert a Graphic to PDF

1. To convert a graphic to PDF, take the following actions:




| Step | Action |
| :-: | :-: |
| 1 | Open graphic in the application used to create it. |
| 2 | Go to File − Print. |
| 3 | Set Printer Name to "Adobe PDF." |
| 4 | Click on "Properties" (or "Printer Properties" ). |
| 5 | On the "Adobe PDF Settings" tab, set Default Settings to " _Press Quality_."<br> <br>### Note:<br>Setting _Press Quality_ embeds the fonts. |
| 6 | On the "Paper/Quality" tab, set "Color" to "Black and White." |
| 7 | On the "Layout" tab, set "Orientation" to "Portrait" (or "Landscape," if applicable) and "Pages Per Sheet" to "1." |
| 8 | Click "OK" to exit the Adobe PDF Document Properties window. |
| 9 | Click "OK" to Print to Adobe PDF. |
| 10 | Save the graphic file using:<br> <br>   - Eight-digit filename (five-digit catalog number plus three unique numbers)<br>     <br>   - PDF extension (.pdf) |

2. To improve the quality of the IRM graphic, copy the content and insert it into a Microsoft™ product (Word, Excel, Publisher) before creating the PDF.



### Example:



If your IRM displays a computer screen, copy the screenshot to a Word document before creating the PDF graphic. Then follow the steps in the table above starting from step 2.

3. Check the PDF to ensure the orientation and appearance are correct. Information on graphic files is available on Virtual IMD Learning Library Application (VILLA) SharePoint site and the Authoring the IRM with Arbortext Editor (coursebook) lesson on graphics. Refer to _Exhibit 1.11.2-3_, IRM Web Resources.

4. Ensure you embedded (locked) the fonts so your document displays properly in the PDF. To check whether you embedded the fonts:



1. Open the PDF graphic and select "File" from the tool bar and select "Properties."

2. In the Document Properties box, find the "Fonts" tab. Check that each font displays the words "embedded subset" next to it.


5. If "embedded subset" isn't displayed next to each font, you must embed them by setting the file to _Press Quality_. Refer to step 5 in the table under paragraph (1), above.

6. For questions about creating a graphic, contact an M&P IRM printing specialist at \*M&P IRM or your Learning and Education (L&E) specialist.



### Note:



If an L&E specialist prepared your graphic, submit the graphic for publishing following the IRM uploading rules. Refer to IRM 1.11.5, Publishing the Internal Revenue Manual (IRM), for rules on submitting files for publishing.


**1.11.2.5.4.2.2** **(09-13-2023)**

###### Store IRM Graphic Files

1. M&P stores the original source files so they’re accessible to future users from the Publishing + Distribution Product Catalog Results page. These source files are the original files used to generate the PDF graphic submitted with the IRM publishing package. A "graphic source file" is the original, editable file from which the author created the graphic.



### Note:



You cannot edit a TIFF, JPEG, GIF, BMP, PNG, WPG or other graphic editor file.

2. Include the original source files used to develop the IRM graphics when you upload the IRM XML package to M&P. Refer to IRM 1.11.5.4, Submitting the IRM Publishing Package.



### Example:



You want to insert a screen shot in the IRM. You copy and paste the screen shot into a Microsoft™ Word file. Save the Word file. The Word file is the original source of the graphic. Include the Word file in the IRM XML package when uploading the file to M&P.


**1.11.2.5.4.2.3** **(09-13-2023)**

###### Use Alternative Text for Graphics

1. Section 508 of the Rehabilitation Act of 1973 (revised January 18, 2017) requires federal agencies to make electronic information and communication technologically accessible to people with disabilities. All non-text content presented to the user requires a text alternative that serves the equivalent purpose. IRM authors must create a meaningful description of each graphic. Alternative text used to describe a graphic is referred to as a graphic descriptor.

2. When inserting a graphic into the IRM XML file, insert a descriptor tag.

3. The text inserted within the graphic descriptor tags is accessible only on online IRM formats. Specifically:



1. On web-based media (HTML format), such as IRM Online, SERP, Chief Counsel Directives Manual (CCDM) Online and Servicewide research tools, readers can view the graphic and access the alternative text.

2. The Electronic Publishing website (PDF format) displays the graphic, but the alternative text is not accessible.


4. The Alternative Media Center (AMC) provides training and guidance to employees throughout the IRS on effective methods of making products accessible during the development stage. For more information, visit the "Learn" section on the AMC website.


**1.11.2.5.5** **(09-13-2023)**

#### Contact Information

1. Avoid using employee names, email addresses, and phone numbers in the IRM, unless necessary for a business purpose. Use a program office name instead of an individual, or an organizational mailbox instead of an individual email address.

2. Consider creating a contact listing document that can be stored on an internal site and linked to the IRM.

3. When it’s necessary to display a telephone number in the IRM, follow these rules:



1. Verify the telephone number.

2. Review the number at least annually, especially if it’s an IRS tax assistance (toll-free) number.

3. Verify IRS toll-free numbers at Joint Operations Center and select "Other Links/Helpful Tools – Product Line Overview" . The Product Line Overview Excel file identifies IRS toll-free numbers in the first column titled "CDN." IRM authors may contact \*CTR JOC with questions about information in the Product Line Overview.


### Reminder:

Telephone numbers that appear in the IRM are available to the public.

**1.11.2.5.6** **(04-22-2020)**

#### Fictitious Identifying Information

1. Authors and reviewers **must** always review IRM content for federal tax information (FTI) or other personally identifiable information (PII). If an author believes an exception exists where there is a need for FTI or PII in an IRM, email \*Privacy for guidance.

2. To avoid accidental use of _real_ taxpayer information in IRM text, exhibits or graphics, follow the guidelines in Document 13324, Guidelines and Examples for Fictionalizing Domestic Taxpayer Information, and Document 13311, International Name and Address Construction Job Aid, to properly fictionalize:



   - Names of taxpayers, businesses and streets

   - Names for cities and towns

   - Street or post office (PO) box numbers and zip codes

   - Taxpayer identification numbers

   - Document locator numbers (DLNs)

   - Telephone numbers, fax numbers, email addresses and any other potential PII


**1.11.2.5.6.1** **(04-22-2020)**

##### Personally Identifiable Information (PII) or Federal Tax Information (FTI) Breach Actions

1. If you discover PII or FTI when reviewing or updating the IRM, you must report it **immediately upon discovery**. A prompt report decreases the possibility for use of the information to perpetrate identity theft or other forms of harm.

2. Take the following actions **immediately** in accordance with IRM 10.5.4.3.3(2), Inadvertent Unauthorized Disclosures and Losses or Thefts of IT Assets, BYOD Assets and Hardcopy Records/Documents:



1. Report the breach to your manager and IMD/IRM coordinator.

2. Report it to the Office of Privacy, Governmental Liaison and Disclosure (PGLD) Incident Management Office (IM) using the PII Breach Reporting Form. Refer to PII Breach Reporting Form. Call 267-466-0777 if you have any problems with the online form or any questions about completing the online form.

3. Contact SPDER at \*SPDER.

4. Work with SPDER and your IMD/IRM coordinator to remove content from the IRS electronic sources and revise the IRM.



      ### Note:



      If you are not the IRM author, contact the IRM author, their manager and their business unit IMD coordinator. They will work with SPDER to revise the IRM and remove content from the IRS electronic sources.


3. For more information on PII or FTI unauthorized disclosure reporting, refer to IRM 10.5.4.3, Reporting Losses, Thefts and Disclosures.


**1.11.2.5.7** **(09-13-2023)**

#### Write in Plain Language

1. Write in plain language so that your IRM section is easy to read and understand. The following are some basic plain language techniques:



1. Replace complex words with simpler words; emphasize clarity over formality.

2. Use active voice when possible.

3. Remove unnecessary and duplicative terms.

4. Present information from the positive, and don’t use double negatives.

5. Use parallel structure.

6. Avoid jargon: unnecessarily complicated language used to impress instead of inform.

7. Use descriptive titles. For example, don’t just write "Introduction" .


2. For more on plain language writing, review:



1. Federal plain language guidelines for all agencies.

2. ITM Course 57131, IRM Authoring: Fundamentals of Writing the IRM, for IRM-specific guidance and examples of plain language writing.

3. Form 14481, Plain Language Checklist and Review Sheet.

4. Document 12835, The IRM Style Guide.


**1.11.2.5.8** **(07-31-2025)**

#### Standard Citation Rules

1. Follow a standard format when citing sources in the IRM. Linking to relevant sources ensures readers can easily find information applicable to the subject.

2. Include pertinent web addresses when referencing online sources. For example, link to:



   - Performance support tools

   - Contact listings

   - Official published products

   - Legal publications

   - Supplementary materials


### Caution:

The primary source of guidance must be in the IRM. Refer to discussion at _IRM 1.11.2.2_, IRM Standards.

3. Consult the following resources for information on citation standards and inserting links in the IRM:



1. Document 12835, The IRM Style Guide, for standard citation rules in the IRM.

2. Authoring the IRM with Arbortext Editor, the IRM XML coursebook, on how to insert a link using the IRM authoring software. The coursebook is in the IRS Catalog, at Authoring the IRM with Arbortext Editor (Coursebook).


4. Do not include **naked** when authoring IRM content. Naked links expose the web address of the page or website to which you are directing the reader. Instead, embed all links using the citation tools, as discussed in _IRM 1.11.2.5.8.5_, Create Hyperlinks.


**1.11.2.5.8.1** **(05-08-2014)**

##### Cite the IRM

1. When citing an IRM section or subsection, always use the acronym "IRM" along with the IRM number. Don’t spell out "Internal Revenue Manual" .

2. When citing multiple IRM sections or subsections within the same paragraph, place the acronym "IRM" before each referenced section or subsection. Also, include the complete IRM number when referencing the IRM section.



### Example:










| Correct | Incorrect |
| :-: | :-: |
| IRM 2.3.4.5 and IRM 2.3.4.6 | IRMs 2.3.4.5 and 2.3.4.6 |

3. Include the title when referring to _another_ IRM part, chapter or section. Adding the title helps readers find the information in the event the content was moved.



### Example:






IRM 11.3.4, Congressional Inquiries

4. When referencing a subsection within the IRM you are writing (a see also), insert the entire IRM number down to the lowest level, including the paragraph or list item. It’s optional to include the subsection title.



### Example:






IRM 1.11.2.5.8.2, Cite Legal Sources

5. To verify current IRM information, visit the Electronic Publishing Catalog Information page Find a Product.


**1.11.2.5.8.2** **(09-13-2023)**

##### Cite Legal Sources

1. When citing law, such as the IRC, public laws, Treasury regulations, or other issuances (such as the United States Code and the Code of Federal Regulations as may be necessary for items not under the IRC or in Treasury regulations), provide an accurate citation. Refer to Document 12835, The IRM Style Guide, for a complete listing of citation formats.




| If citing | Then provide | Example |
| :-: | :-: | :-: |
| The Internal Revenue Code (IRC), United States Code (USC), or Code of Federal Regulations (CFR) | The title (numeral) and section number | The IRC 6103(h)<br> 31 USC 321<br> 31 CFR 1022.380 |
| Multiple IRC sections | IRC before each referenced Code section | The IRC 6103, the IRC 6110<br>_Not_<br> IRC sections 6103, 6110 |
| Public law not codified | Either:<br> <br>   - Public law number or<br>     <br>   - Name of the act in which the law appears | Public Law 104-13, Paperwork Reduction Act of 1995 |

2. For instructions on how to insert a citation tag in the IRM XML file, refer to _IRM 1.11.2.5.8.5_, Create Hyperlinks.

3. When referencing agency decisions reflected in published guidance (such as certain regulatory guidance, revenue procedures and revenue rulings) provide an accurate citation. You need a citation to be able to track a change.


**1.11.2.5.8.3** **(05-08-2014)**

##### Cite Other IRS Published Products

1. When citing another IRS published product, reference the document by number (such as a form, publication, letter, etc.) and name.



### Example:










| Correct | Incorrect |
| :-: | :-: |
| Form 1040 and Form 1040-SR | Forms 1040, 1040SR |

2. Link to the published product in the IRS Catalog instead of recreating the document as a graphic. Use the authoring software’s citation feature instead of a link to the website URL; that way, if the product gets updated, the IRM automatically links to the current document.

3. For help with creating a hyperlink in the IRM XML authoring software, follow instructions in _IRM 1.11.2.5.8.5_, Create Hyperlinks.


**1.11.2.5.8.4** **(07-31-2025)**

##### Validate Links

1. Always verify links and cross-references in your IRM file to ensure they work and refer to the most current information.

2. Ensure legal citations are valid and not modified, superseded or overturned. For legal and tax research services, refer to ReferenceNet Legal and Tax Research Services.

3. Verify links to IRS published documents such as IRM sections, letters, notices, forms, instructions, publications, etc., by using the IRM Preview Tool, or by visiting the Electronic Publishing Catalog Information page Find a Product.

4. To verify a website address, use the IRM Preview Tool, or copy and paste the website address from the "href" of the anchor (<a>) tag into your internet browser. To change the web address, follow the linking and citation instructions in the Arbortext Editor FAQs, listed in _Exhibit 1.11.2-3_, IRM Web Resources.

5. Verify IRS toll-free numbers and agency addresses. For IRS buildings, view the listing at IRS Building Addresses.

6. Minor edits can be made to IRM Online in between revisions by sending an email to \*SPDER with corrections to spelling errors, internal websites and telephone numbers.


**1.11.2.5.8.5** **(07-31-2025)**

##### Create Hyperlinks

1. The IRM authoring software uses different types of tags to create links in the published product. All URLs must be embedded using the various tags in Arbortext Editor. For step-by-step instructions to create links, refer to:



   - Virtual IMD Learning Library Application

   - Authoring the IRM with Arbortext Editor (Coursebook)


2. The table below describes these tags and their purpose.




| Use a(n) | To create a link to a(n) |
| :-: | :-: |
| <seealso> tag | Location within the same subsection, such as a(n):<br> <br>   - IRM subsection (subsec)<br>     <br>   - Paragraph<br>     <br>   - Exhibit<br>     <br>   - Figure |
| anchor or <a> tag | - Website address<br>     <br>   - Email address<br>     <br>   - Court case or Treasury regulation<br>     <br>### Note:<br>Do not include server names or IP addresses in website links or addresses. |
| citation or <c> tag | - IRM subsection, figure or exhibit in another IRM<br>     <br>   - IRS published products, such as documents, forms or publications<br>     <br>   - Internal Revenue Bulletin (IRB), Internal Revenue Code (IRC), letters, notices, revenue procedures or revenue rulings |

3. When you insert these tags into the IRM XML file, online versions of the IRM such as IRM Online and SERP automatically create links for them.

4. Published IRMs must not display the URLs or full email addresses. Use meaningful words that are relevant to the linked content. This improves readability and accessibility by providing clear, descriptive context for the link. If possible, avoid using click here or other generic phrases. Give the link or email address a proper name inside the beginning and closing <a> tag.


**1.11.2.6** **(05-08-2014)**

### Use and Preparation of the Manual Transmittal (MT)

1. The manual transmittal (MT) communicates information about the IRM revision. The MT provides a historical record and description of changes to procedures, processes and programs. A properly completed MT is a valuable tool for readers and researchers such as IRS employees, librarians and attorneys.

2. The MT tells the reader:



   - If the IRM section is new, revised or obsolete

   - The important changes to procedures, guidelines and operations

   - The effective date of the procedures

   - The effect of the changes on other IRM sections or documents as to whether superseded or obsolesced

   - The intended audience of the IRM section


3. Complete the required elements for each revision of a new, revised or obsolete IRM section. Refer to _IRM 1.11.2.6.1_ for the details to properly complete the MT.

4. The MT also accommodates additional elements to add optional information. Refer to _IRM 1.11.2.6.2_ for more information.


**1.11.2.6.1** **(05-08-2014)**

#### Required Elements of the Manual Transmittal

1. The IRM authoring software automatically generates an MT template. Authors must complete the MT each time they create, revise or obsolete an IRM section.

2. Below is a list of the required elements arranged in order with a description of each:




| Required Element | Description |
| :-: | :-: |
| MT Date | Identifies the date M&P publishes the IRM section. The M&P IRM printing specialist completes this element. Refer to _IRM 1.11.2.6.1.1_, Manual Transmittal (MT) Date. |
| Purpose | Informs readers the reason for the revision, such as whether the IRM section is new, revised, reissued or obsolete. Refer to _IRM 1.11.2.6.1.2_, Manual Transmittal Purpose for specific language. |
| Material Changes | Documents:<br> <br>   - Substantive changes to the IRM section.<br>     <br>   - Reason(s) for the creation of a new IRM section.<br>     <br>   - Reason(s) the material is obsolete (in whole or in part).<br>     <br> Refer to _IRM 1.11.2.6.1.3_, Manual Transmittal Material Changes. |
| Effect on Other Documents | Lists other IRM section(s), IG or published products affected by this revision. For example:<br> <br>   - To supersede or obsolete the prior IRM revision.<br>     <br>   - To incorporate interim guidance.<br>     <br>   - To incorporate a published document.<br>     <br> Refer to _IRM 1.11.2.6.1.4_, Effect on Other Documents. |
| Audience | Identifies the primary user(s) of the IRM content, whether by business unit, office or job category. Refer to _IRM 1.11.2.6.1.5_, Audience. |
| Effective Date | Identifies the date the information in the IRM section becomes effective. This can be a wild card date (MM-DD-YYYY) or a specified date. Refer to _IRM 1.11.2.6.1.6_, Effective Date. |
| Signature | Identifies the name and title of the approving program director responsible for the program area. Refer to _IRM 1.11.2.6.1.7_, Signature of Approving Official. |

3. For more information on IRM dates, refer to the table in _IRM 1.11.2.5.2_, Determine IRM Dates.


**1.11.2.6.1.1** **(05-19-2022)**

##### Manual Transmittal (MT) Date

1. The MT date is the date M&P publishes the IRM section. This is the date to expect the Electronic Publishing website to post the IRM. M&P is responsible for setting the publishing date and inserting the MT date into the file. (This date is contractually determined). There are no exceptions to this rule.

2. Type "Month DD, YYYY" and not an actual date.

3. Refer to _IRM 1.11.2.6.1.6_, Effective Date for the rules on the effective date and how it differs from the MT date.


**1.11.2.6.1.2** **(05-08-2014)**

##### Manual Transmittal Purpose

1. The MT purpose is a brief statement that identifies the IRM number, chapter and section titles, and describes the reason for the issuance, such as new, revised, obsolete or reissued. This statement is _not_ intended to describe the purpose of the information in the IRM section itself.

2. To prepare the MT, use the following standard language:




| If the IRM section | Then the IRM section is | And the purpose must read |
| :-: | :-: | :-: |
| Is issued for the first time under the IRM number | New | "This transmits new IRM X.X.X, Chapter title, Section title." |
| Is issued under the same IRM number | Revised | "This transmits revised IRM X.X.X, Chapter title, Section title."<br> <br>### Reminder:<br>A change to the chapter or section title with the same IRM number is still a revision. Explain a title change in the material changes. |
| Is no longer effective | Obsolete | "This transmits obsolete IRM X.X.X, Chapter title, Section title."<br> <br>### Reminder:<br>In the material changes, describe the reason the information is no longer in force or effect. |
| Was previously obsolesced and the author republishes with substantially similar information | Reissued<br> <br>### Note:<br>You can reissue the IRM section under the same IRM number if it contains some or all the same information as the previous revision. | "This transmits reissued IRM X.X.X, Chapter title, Section title." |


**1.11.2.6.1.3** **(09-13-2023)**

##### Manual Transmittal Material Changes

1. The MT material changes highlight new, revised or removed procedures and content in the published IRM. This element:



   - Identifies significant changes to program operations

   - Provides authority for the issuance or the reason for the changes

   - Creates an audit trail for IG or other information incorporated into the IRM


2. Follow these guidelines when preparing the material changes. Working from the last published XML file:



1. Delete the content from the material changes (except perhaps for a general statement on applicable editorial changes).



      ### Note:



      This applies to all changes, including any IPU changes made since the last published IRM.

2. Review the updated IRM content and identify all substantive changes, additions or deletions by subsection and paragraph. If superseding a change by a subsequent change, explain why.

3. Start each material change entry with the IRM subsection number, not the IPU or IGM number.



      ### Caution:



      Base the subsection numbering off the accepted changes version of the XML file. Subsection numbering based off the tracked changes file can result in erroneous references when adding, deleting and renaming subsections.

4. List the changes in subsection order.

5. Briefly describe each substantive change to help the reader understand what has changed and why. It is not sufficient to only use statements such as "clarified procedures" or "added a new paragraph." If removing content owned by another office, you must state who the program office is and where to find the information in the IRM. Refer to _IRM 1.11.2.5.1.5_, Removing Substantive Content from an Existing IRM Section.

6. The following table identifies repetitive substantive changes you may summarize. Place each summarized change into its own paragraph or table row, in the beginning of the material changes. Specify the type of change and reason. Update the related subsection date to the new effective date for each occurrence of the changed content following _IRM 1.11.2.5.2.1_, Determine the Subsection Date.




      | Type of Change | Example |
      | :-: | :-: |
      | IDRS code updates (transaction codes, action codes, command codes, etc.) | Replaced code XXX with code XXX throughout the IRM due to \[reason\]. |
      | Tax year | Updated tax year 2021 to tax year 2022 throughout the IRM. |
      | Rates (interest, penalty) | Updated the IRC 6695 (a)-(g) inflationary rates for tax year 2022 throughout the IRM. |
      | Exemption amounts, deductions, credits, income thresholds and other items subject to inflation (amounts generally change every year) | - Updated exemption amount for tax year 2022 throughout the IRM.<br>        <br>      - Updated tax year 2022 credit amount to \[amount\] throughout the IRM.<br>        <br>      - Updated \[topic\] for tax year 2022 income limitations throughout the IRM. |
      | Titles | Updated title of Form XYZ to \[new title\] throughout the IRM. |
      | Forms and form line numbers | - Replaced Form XYZ, \[Title\], with Form ABC, \[Title\], throughout the IRM due to \[reason\].<br>        <br>      - Updated line 5 of Form ABC, \[Title\], due to form revision. |
      | Citations, references, links and telephone numbers | Updated phone number for taxpayers to call \[name of contact\] throughout the IRM. |





      ### Note:



      If changes to titles, citations, references, links and telephone numbers do not impact the taxpayer, they are considered editorial.

7. You may summarize the editorial corrections by specifying the type of change, not each specific change or location. Place this information in the last paragraph in the list of material changes. By identifying the type of editorial change, you are verifying to readers the content is reliable. Refer to _IRM 1.11.2.8_ for the types of changes that are considered editorial.



      ### Example:



      "Reviewed and updated website addresses, legal references and IRM references, as necessary."

8. Insert <restrict> tags around any OUO content. Refer to _IRM 1.11.2.5.3_ for instructions on how to designate OUO content.


3. Write a narrative explaining the substantive changes to the IRM. Then present the content changes in paragraph or table format, using descriptive action verbs to describe each change. For examples, view the Material Changes of this IRM section.



### Example:



Use terms such as: "added" , "deleted" , "revised" , "modified" , etc.

4. When placing changes in a table, prepare a lead sentence or phrase describing the table contents.



### Example:



"The following table provides changes made to IRM X.X.X."






| IRM subsection | Description |
| :-: | :-: |
| \[subsection #\] | Added \[content\] to explain \[issue\]. |
| \[subsection #\] | Deleted this section since procedures are no longer in effect due to \[reason\]. |
| \[subsection #\] | Revised \[content\] for \[reason\]. |
| Throughout | Reviewed and updated website addresses, legal references and IRM references, as necessary. |

5. Follow these standards to describe substantive changes:




| Type of Change | What to Include |
| :-: | :-: |
| Create a new IRM | 1. Describe the primary purpose of the new IRM and the audience.<br>      <br>2. If moving material from other IRM sections, identify those IRMs and the reason for removing the content from the original IRM. |
| Reorganize or restructure an IRM | 1. Describe the reason for reorganizing or restructuring the content.<br>      <br>2. Specify the content removed, revised and added by subsection.<br>      <br>3. Consider using a crosswalk to identify the content’s original and new location. |
| Significantly change a program or process | 1. Summarize the change, describe the reason(s), add relevant dates and/or audience information.<br>      <br>2. Depending on the complexity, insert this information either in the "background" or the first paragraph of the "material changes." |
| Incorporate content from a different IRM section | 1. Identify the specific IRM subsection(s) from which content is being incorporated and the new subsection where it’s being placed.<br>      <br>2. Describe the content and the reason for the relocation of content.<br>      <br>3. If you’re incorporating multiple subsections, consider using a crosswalk table to easily identify the content’s original and new location(s). |
| Incorporate IG into the IRM | 1. Identify the number and issue date of the guidance.<br>      <br>2. For a memorandum, also include the title.<br>      <br>3. Summarize the guidance and specify in which subsection you incorporated the guidance. |
| Obsolete an IRM | Explain the reason the information is no longer in effect. Refer to _IRM 1.11.2.9_ for additional instructions to prepare the MT to obsolete an IRM section. |


**1.11.2.6.1.4** **(05-08-2014)**

##### Effect on Other Documents

1. The effect on other documents provides a record of the revision's specific effect on an existing document. This element provides an audit trail and is especially important for historical research. The effect on other documents identifies the IRM material as one of the following:



   - Amended: Existing material changed

   - Supplemented: Material added

   - Superseded: Material replaced by other materials

   - Obsoleted: Material no longer needed and not replaced by any other material


2. This table suggests language to complete the effect on other documents.




| When | Then | Sample Language |
| :-: | :-: | :-: |
| Revising an IRM section, | Specify the IRM number, title and MT date of the superseded document. | \[IRM number\], dated MM-DD-YYYY, is superseded. |
| Revising an IRM section to insert text from another IRM section, | Specify the IRM number, title and MT date of the superseded document and indicate the IRM from which you moved the text. | \[IRM number\], \[Title\], dated \[MM-DD-YYYY\], is superseded.<br> Text from \[IRM number\], \[Title\], dated \[MM-DD-YYYY\] has been incorporated. |
| Obsoleting an IRM section in its entirety, | Specify the IRM is "obsolete as of the IRM effective date." | \[IRM number\], dated MM-DD-YYYY, is obsolete as of the IRM effective date. |
| Removing portions of an IRM section, | Address actions separately, such as:<br> <br>   - Specify portions are obsolete and<br>     <br>   - Specify where active content moved. | Portions of \[IRM number\], \[Title\], dated MM-DD-YYYY, are obsolete as of the IRM effective date and the remaining portions are incorporated into \[IRM number\], \[Title\], dated MM-DD-YYYY. |
| Issuing a new IRM section with no history, | Insert "None" or "NA" | "None" |
| Incorporating interim guidance into the IRM, | Insert the IGM/IPU number and issue date.<br> For an IG memorandum, also include the title. | This IRM incorporates Interim Guidance Memorandum SBSE-05-0508-XXXX, \[Title of interim guidance\], dated \[MM-DD-YYYY\].<br> This IRM incorporates IRM Procedural Update (IPU) 22UXXXX issued May 29, 2023. |

3. When completing the effect on other documents for an IRM where the previous IRM effective date was different than the MT date, specify both dates, as displayed in this example:



### Example:



"Effect on Other Documents: IRM 21.8.3, dated 08-23-2014 (effective 10-01-2014), is superseded."


**1.11.2.6.1.5** **(04-22-2020)**

##### Audience

1. The audience is the intended group of IRS employees expected to follow or benefit from the IRM section procedures. Identify the audience by the business unit, division, function, office or job category.




| IRM Audience Identified By | Example Language |
| :-: | :-: |
| Business unit | - All business units<br>     <br>   - Small Business/Self-Employed (SB/SE), Large Business & International (LB&I), Tax Exempt and Government Entities (TE/GE) and Taxpayer Services (TS)<br>     <br>   - Appeals<br>     <br>   - Employee Plans |
| Job category or group | - All managers<br>     <br>   - Appeals officers and Appeals settlement officers<br>     <br>   - Employees who conduct examinations (in SB/SE, LB&I, TE/GE)<br>     <br>   - IMD community (IMD/IRM coordinators, IRM authors, reviewers, managers of these employees) |





### Caution:



Although the IRM is available to the public (as provided by the FOIA), the public is not the intended audience. Therefore, the IRM must not be written as taxpayer guidance or information.


**1.11.2.6.1.6** **(09-21-2015)**

##### Effective Date

1. The IRM effective date is the date employees begin following the new procedures. The Manual Transmittal date, the date the IRM is published, matches the IRM effective date, if the effective date is the wild card date of"(MM-DD-YYYY)" .




| Date | Action | Format |
| :-: | :-: | :-: |
| IRM with no specified effective date | Enter the wild card date (MM-DD-YYYY), the date the procedures become effective. | (MM-DD-YYYY) |
| Procedures are effective on a specified date, (filing season, for example) | Enter the specific date the content is effective. | (01-01-20YY) |

2. For filing season IRMs, insert the specific date in the effective date field. Also insert this date for any revised subsection(s) with a change in content. For a discussion of filing season, refer to IRM 1.11.5.4.2, Filing Season Production Schedule.


**1.11.2.6.1.7** **(11-15-2022)**

##### Signature of Approving Official

1. The approving official is the program director or member of the Senior Executive Service (SES) responsible for the program (or their documented designee). The MT identifies the approving official’s name and title. This is normally the same approving official who approves the IRM in the IMD Electronic Clearance System, or signs in block 20c of the Form 2061, Document Clearance Record, approving the IRM content.

2. When instructions or guidelines apply to more than one business unit, the approving official is the primary head of office of the business unit responsible for the program area.

3. For further guidance on signature authority, refer to IRM 1.11.9, Clearing and Approving the Internal Revenue Manual (IRM).


**1.11.2.6.2** **(09-13-2023)**

#### Manual Transmittal Optional Elements

1. The authoring software allows for the manual insertion of several optional elements. Optional elements are rarely necessary since most of the information they provide is covered by the internal controls subsection; however, they may be appropriate in limited situations.

2. The following table describes the four optional elements and when to use them:




| Optional Element | Description of Use |
| :-: | :-: |
| Note | Provide information to the reader to highlight an important issue related to the IRM’s publication. |
| Background | Cite the authority for issuing the document or provide background information on the development of the material, if the IRM section does not require internal controls. |
| Scope | Use when it’s necessary to limit the applicability of the IRM revision. For example, the procedures may only apply:<br> <br>   - During a certain time period.<br>     <br>   - To employees in a particular location (such as an area affected by a natural disaster).<br>     <br>   - To employees in a specific job category. |
| Related Resources | List helpful websites, references or other sources of information on the topic, if the IRM section does not require internal controls. |





### Reminder:



The only IRMs that don't require internal controls are functional statement IRMs in the 1.1 series, delegation order and policy statement IRMs in the 1.2 series, and obsolete IRMs.


**1.11.2.7** **(05-19-2022)**

### Conduct an Informal Review

1. Informal review is an opportunity to receive input from others when developing or revising a procedure, process or program. Obtaining input from affected stakeholders and subject matter experts (SMEs) simplifies the IRM review and clearance process.

2. An IRM reviewer may be a(n):



   - SME in another office or business unit

   - Manager

   - Specialized reviewer (as defined in IRM 1.11.9, Clearing and Approving the Internal Revenue Manual (IRM))

   - Affected stakeholder

   - Employee who follows the instructions


3. An informal review is particularly helpful when the new or revised procedure, process or program addresses:



   - New or significant changes to a workflow or procedure

   - Legal interpretation

   - Taxpayer rights or duties

   - A change in working conditions requiring negotiations between LERN and the union


4. Send your draft IRM to your manager for review prior to formal clearance.

5. An informal review does not take the place of formal clearance. You still must formally clear through affected offices and specialized reviewers. Refer to IRM 1.11.9.3, Identifying Reviewers, for further guidance.


**1.11.2.7.1** **(04-22-2020)**

#### Determine the Need for an Informal Review

1. An informal review helps facilitate the processing of an IRM section by:



   - Providing an opportunity to verify the accuracy of current operations

   - Opening communications with offices affected by the policies or procedures and obtain their buy-in

   - Identifying potential issues or barriers

   - Avoiding unnecessary delays during formal clearance


2. Review these questions when considering whether to seek advice from a SME:



   - Is the material technically or procedurally complex?

   - Do you anticipate a lengthy review period?

   - Do you need the opinion of a SME before sharing the information with others?

   - Will you need the approval from another office or business unit because of the proposed changes?

   - Do the procedures affect how other offices do their work?


3. Request an informal review when:



1. You’re not familiar with the subject matter.

2. You’re required to get a specialized reviewer's input to develop the content (for example, obtaining legal advice, workforce relations). Authors **must** evaluate all new or revised IRMs for potential changes to conditions of employment of bargaining unit employees prior to clearance. Refer to _IRM 1.11.2.5.1.4_, IRM Changes Affecting Conditions of Employment of Bargaining Unit Employees.

3. You have a question or need confirmation from a SME in another office or business unit.


**1.11.2.7.2** **(05-08-2014)**

#### Initiate an Informal Review

1. When you initiate an informal review:



1. Identify the office or business unit responsible for addressing the changes or concerns.

2. Explain the issues in an email or a note to reviewer outlining the changes or concerns.

3. Attach a draft of the revised IRM or pertinent portions.

4. Email the draft and specify a written response and the response date.

5. Set up a meeting to discuss the reviewer’s questions or concerns.


### Note:

Do not use a Form 2061, Document Clearance Record, for this purpose.

2. Documentation accumulated during the informal review process may become part of the clearance package archived in the IRS Historical Research Library. Keep copies of all actions and contacts with the SME. Refer to IRM 1.11.9.10.5, Archiving Clearance Documents.


**1.11.2.8** **(07-31-2025)**

### Editorial Updates

1. To correct minor editorial and typographical changes to the IRM, use the editorial update process. This process promotes a more current and improved IRM.

2. Editorial changes include:



1. Updating organizational terms and titles.

2. Adding or correcting references, websites, telephone numbers and citations.



      ### Exception:



      Updates to telephone numbers, websites/references or any other information that impacts taxpayers are considered substantive changes.

3. Reorganizing content within an IRM subsection without changing, adding or removing any substantive content or its meaning.



      ### Example:



      Renumbering paragraphs within a subsection.

4. Improving the quality of an existing graphic or adding alternative text.

5. Converting a graphic to text.

6. Correcting typographical errors, e.g., spelling or grammatical errors.

7. Changing to plain language without altering the meaning of the content.


### Note:

Correcting non-editorial errors that require immediate attention (PII, etc.) may qualify for expedited clearance. Refer to IRM 1.11.9.5.4.1, Expedited Clearance. For additional steps involving PII, refer to _IRM 1.11.2.5.6.1_, Personally Identifiable Information (PII) or Federal Tax Information (FTI) Breach Actions.

3. It is appropriate to revise the IRM for editorial corrections that improve readability or as part of an annual review. However, consider the cost-benefit of republishing the IRM within a year merely to correct a minor editorial error.



### Note:



Minor edits can be made to IRM Online in between revisions by sending an email to \*SPDER with corrections to spelling errors, internal websites and telephone numbers.


**1.11.2.8.1** **(09-13-2023)**

#### Editorial Update Process

1. Use the following guidance to update the IRM to correct an editorial error:




| Topic | Action |
| :-: | :-: |
| Preparing the Manual Transmittal | Follow the rules for updating the MT described in _IRM 1.11.2.6_, Use and Preparation of the Manual Transmittal (MT).<br> <br>   - In the material changes, specify the type(s) of editorial changes made. Refer to the table in paragraph (2) below for suggested language. |
| Changing Subsection Dates | At least one subsection date in the IRM section must match the IRM effective date. Therefore, if the IRM section is being updated for:<br> <br>   - **A single editorial change only**, change the date of that affected subsection to the effective date.<br>     <br>   - **Multiple editorial changes only**, change the date of the first subsection (IRM X.X.X.1) to the effective date. All other subsections keep their existing subsection dates.<br>     <br>### Note:<br>If the IRM section contains editorial _**and**_ substantive changes, follow the instructions in _IRM 1.11.2.5.2.1 (2)_, Determine the Subsection Date. |
| Making the Editorial Updates | Input the appropriate editorial correction(s) or update(s) to the XML file. Review the rest of the IRM content to ensure it reflects all current operations and correct other inaccuracies and outdated links. Refer to _IRM 1.11.2.5.1_, Authoring Process. |
| Clearing the IRM | Follow the streamlined clearance process per IRM 1.11.9.2.1.1, Clearance of Editorial Updates. The extent of review corresponds to the management level necessary to approve these minor corrections.<br> <br>1. Clear through the author’s manager<br>      <br>2. Clear through the IMD/IRM coordinator<br>      <br>3. Obtain approval from the program director (or documented designee) |
| Publishing the IRM | Work with your business unit’s IMD staff to submit the revised IRM for publishing, following procedures in IRM 1.11.5, Publishing the Internal Revenue Manual (IRM). |

2. When you prepare the MT, describe the type of information that changed in the material changes.




| When you make an editorial change: | Then: | Example Language |
| :-: | :-: | :-: |
| To a single subsection | Identify that subsection. | IRM X.X.X.X: Updated to reflect \[specify the type of editorial change(s)\]. |
| In multiple places throughout the document | Use a summarizing statement. | - Revised IRM X.X.X throughout to update organizational terms and/or titles \[specify the change\].<br>     <br>   - Reviewed and updated IRM X.X.X throughout to correct legal citations, published forms and documents and web addresses.<br>     <br>   - Revised IRM X.X.X throughout to incorporate plain language, active voice, and to clarify content. |


**1.11.2.9** **(09-13-2023)**

### Rules to Obsolete an IRM Section

1. An IRM section is obsolete when the IRM information is no longer in effect due to a law, policy, operational, procedural or administrative change. You may completely eliminate an obsolete IRM section’s information or merge any of its remaining information into another IRM section(s).

2. An obsolete IRM file contains only the MT when published. This document is the only remaining record of this IRM section. The author must explain in the material changes why the content is no longer effective or, if restructuring the content, where to find the current instructions.

3. If portions of the IRM remain effective, including any outstanding interim guidance, summarize the content specifying the current source and the new location of the remaining content. You may list the changes in a paragraph or place them in a table or list, along with the identifying information. Also, submit the active IRM for publishing before or simultaneously with the obsolete IRM to eliminate any conflicting or gap in instructions.

4. Refer to the table below for sample language you may use for the MT material changes:




| If the information is | Then insert |
| :-: | :-: |
| Moved to another IRM section | "The material relating to \[INSERT subject\] previously contained in \[IRM section X.X.X\] is incorporated into new \[IRM X.X.X\], \[IRM section title\]." Describe the reason. |
| No longer effective | "The material in \[IRM section #\] is obsolete because \[insert reason\]." |

5. The table below provides step by step instructions for preparing to obsolete an IRM section.




| Action | Instructions |
| :-: | :-: |
| Prepare the IRM file using either method | **Method 1**<br>1. Open the last published version of the IRM file and save it to your computer.<br>      <br>2. Place the cursor at the end of the manual start tag at the top of the IRM file.<br>      <br>3. Select "modify attributes" to change the status from "active" to "obsolete."<br>      <br>4. Ensure the <hasouo> attribute is set to "no."<br>      <br>5. Update the metadata elements.<br>      <br>6. Delete the IRM content. One subsection title and paragraph must contain text to pass a completeness check. Put "OBSOLETE" in the title and paragraph of the only subsection1 not deleted.<br>      <br>**Method 2**<br>1. Create a new IRM obsolete template by selecting File - New, then IRM (Obsolete) XML 1.0.<br>      <br>2. Place cursor at the end of the manual start tag at the top of the IRM file.<br>      <br>3. Select "modify attributes" to add the catalog number.<br>      <br>4. Ensure the <hasouo> attribute is set to "no."<br>      <br>5. Update the metadata elements for the user, owner and author.<br>      <br>6. Ensure to complete the Manual Transmittal per the row below and complete the audience, effective date, and signature. Select "modify attributes" to complete the IRM part, chapter, and section tags. You must type in the section title. |
| Prepare the Manual Transmittal | 1. Purpose: Insert: "This obsoletes IRM X.X.X, chapter title, section title."<br>      <br>2. Material Changes: Explain why the information is no longer in force or effect.<br>      <br>3. Effect on Other Documents: Insert "IRM \[IRM number\], \[Title\], dated \[MM-DD-YYYY\] is obsolete as of the date of this transmittal (or, if later, the IRM effective date)." |
| Place the revised file into clearance | Following procedures in IRM 1.11.9, Clearing and Approving the Internal Revenue Manual (IRM):<br> <br>1. Prepare a clearance request in IMD Electronic Clearance or Form 2061.<br>      <br>2. Clear the IRM through your manager and IMD/IRM coordinator.<br>      <br>3. Clear the IRM through and obtain agreement from any affected offices or specialized reviewers, as required.<br>      <br>4. Obtain the program director's (or documented designee's) signature. |
| Submit the finalized file for publishing | 1. Prepare Form 1767, Publishing Services Requisition.<br>      <br>2. Follow standard procedures for submitting the file to M&P. Refer to IRM 1.11.5, Publishing the Internal Revenue Manual (IRM). |

6. When a program or process is no longer effective, update the information in other sources as well. Check for information that resides:



   - On IRS Source

   - In IRM sections owned by other business units or offices

   - In other IRS published documents or training materials


### Example:

Search IRM Online using relevant keywords to identify IRM sections that reference an obsolete program or process. Notify the author(s) or content owner(s) that the content requires updating. Refer to IRM 1.11.6.5, Providing Feedback About an IRM Section - Outside of Clearance, for instructions.

**1.11.2.10** **(09-13-2023)**

### Communicate Information About the IRM

1. Inform employees who use the IRM about procedural changes or updates. Consider issuing a communication to highlight significant updates or to remind employees about important rules and work processes.



1. To communicate to employees in your business unit, use your business unit website, newsletter or mailing list.

2. To communicate to employees in all business units, use a Servicewide communication channel.


2. Communications & Liaison provides the following Servicewide communications products/channels:




| Publication | Description | Audience |
| :-: | :-: | :-: |
| Business Unit News (BUN) | News from your business unit with broad interest | IRS employees |
| IRS Source Daily News | Short, timely communications with a broad audience | IRS employees |
| Leader's Alerts | All-manager electronic news articles | IRS executives and managers |
| IRS Headlines | All-employee electronic news articles | IRS employees |





### Note:



Contact C&L’s Office of Communications at \*C&L Office of Communications for submission guidelines.

3. When preparing to issue a communication:



1. Identify your audience.

2. Determine the appropriate vehicle for the communication.

3. Reference the applicable IRM section or other official source when addressing a procedural or operational matter.

4. Follow your business unit’s procedures for issuing communications, including securing managerial approval if required.


**1.11.2.10.1** **(09-13-2023)**

#### SPDER Communications

1. SPDER issues IMD alerts on the Servicewide IMD program and processes to:



   - Announce program changes, enhancements, training opportunities, initiatives, reminders and other news.

   - Highlight the issuance of new interim guidance, a new IRM section, policy statement or delegation order that impacts the IMD community.

   - Reinforce published guidance or instructions.


2. There are two self-subscribing mailing lists for IMD alerts:



   - Manager list: for managers of employees with IRM/IMD responsibilities.

   - Author list: primarily for IRM authors, but also helpful to IRM reviewers, coordinators, managers or others involved in IMDs.


3. Sign up for News and Mailings at the IMD Community page. Join team at IMD Community News. SPDER also posts all issued alerts to this page.


**Exhibit 1.11.2-1**

### Definitions of Terms for Determining What Belongs in the IRM

| Term | Definition | Example |
| :-: | :-: | :-: |
| Delegation of authority | The act of transferring decision-making power or authority from a superior to a subordinate.<br> Specific delegations (delegation orders) are issued by the Commissioner of Internal Revenue or on behalf of the Commissioner, to subordinates, with or without restriction on redelegation. | IRM 1.2.2.2.26, Delegation Order (DO) 1-31 (Rev. 1), Authorization and Approval of Tour Renewal Agreement Travel |
| Check sheet | Form or document used to ensure a process is complete or correct. Check sheets may be considered a type of job aid. | Form 15418, IRM Package Check Sheet |
| Functional statement | A high-level description of the activities and functions of a business unit or program office. It includes the mission or goals, reporting structure, responsibilities and activities taken to achieve the mission. | IRM 1.1.13.4.2, Business Systems Modernization (BSM) |
| Guideline | Direction employees use to determine a course of action, or an explanation that helps employees make judgments based on facts. | Refer to _IRM 1.11.2.2_, IRM Standards |
| Interim guidance (IG) | A memorandum or IPU used to convey immediate, emergency or temporary changes to operations or procedures. | View at IMD Track Alert |
| Job aid or performance support tool | A device or guide that instructs on performing a specific task or skill, such as a desk, technique or user guide.<br> A job aid that summarizes IRM content must include a reference to the applicable IRM. | - Audit technique guides<br>  <br>- Tax Withholding Estimator |
| Knowledge management material | Material that summarizes a specific program, project or task, and supports current IRM procedures. | Standard operating procedures (SOP) or knowledge bases found on the IRSU Knowledge Management and Measures Office |
| Local guidance | Instruction provided for a program within a particular office or geographic location that supplements or supports prescribed IRM procedures. | An office evacuation plan or procedures for conducting specific outreach sessions. Refer to IRM 1.11.2.2.1.1, Local Procedures. |
| Official IRS published product | A published product that resides on the Electronic Publishing website (IRS Catalog) and includes documents, forms, publications, letters and the IRM. | Document 6209, IRS Processing Codes and Information |
| Pilot project | A short-term project or study designed to observe how a specific procedural change may work in practice, evaluate it for adjustments and decide whether to implement it permanently. | For a current example of a pilot or trial project described in an IGM, access the IMD Track Alert and search the term "pilot" in the keyword field. |
| Policy statement | A statement of views concerning an important ideal or value that guides the IRS in administering the internal revenue laws and forms the basis for IRM procedures and instructions. | IRM 1.2.1.2.12, Policy Statement 1-47, Reasonable Accommodations for People with Disabilities |
| Procedure | A process, series of instructions to follow, or a set sequence of steps that establish a standard based on rule or policy. | The step-by-step instructions on how to insert a graphic in the IRM XML file found in _IRM 1.11.2.5.4.2_, Graphics. |
| Software or application-specific instruction | Instruction that describes how to use and operate computer software or application. | BEARS End User Guide |
| Temporary guidance | Procedure, guidance or activity effective for a limited amount of time, up to two years. | Operating instructions based on temporary legislation or a new or emerging issue. Refer to IRM 1.11.10, Interim Guidance Process, for more information. |
| Training document | Course material or other published document used in software / on-the-job / skills training or instructor guides | Training Document 15770-002, Authoring the IRM with Arbortext Editor (Coursebook) |

**Exhibit 1.11.2-2**

### Most Common Reasons to Review the IRM

| Condition | Condition Explained | Review the IRM | Update the IRM |
| :-: | :-: | :-: | :-: |
| 1\. Changes to tax law, programs or processes | There is new legislation or revisions to a program or process. These changes may impact the IRM. | Verify all related IRM content. | Update the IRM to reflect the most current information. |
| 2\. Corporate reorganization or change | IRS reorganization may affect IRMs that reference the business unit, function, program, etc. | Verify:<br> <br>- Terms<br>  <br>- Titles<br>  <br>- Business unit (functional statement)<br>  <br>- Programs<br>  <br>- Procedures | 1. For a new business unit, create a functional statement IRM section (IRM 1.1, Organization and Staffing).<br>   <br>2. When an organizational change occurs, revise the affected offices’ functional statements and the functional statement IRM.<br>   <br>3. Review the IRM for current terminology, titles, programs and procedures. |
| 3\. Newly created, revised, or rescinded delegation orders and policy statements | Changes to delegation orders and policy statements may impact related IRM references and instructions. | A delegation order or policy statement may be:<br> <br>- Newly created<br>  <br>- Revised<br>  <br>- Rescinded | 1. Update references to reflect the revised delegation order or policy statement number and revision date.<br>   <br>2. Clear and approve the related IRM per new or revised delegation authorities.<br>   <br>3. Ensure the related IRM conforms to existing IRS policy. |
| 4\. References to official published products | The IRS can revise, remove, supersede or rename official published products. | Search for:<br> <br>- IRM references to other published products on the Electronic Publishing site.<br>  <br>- Changes to an IRM number or title, an outdated IRM number format or a number in parentheses, (4100, 7(10)00). | Update references to reflect current documents:<br> <br>1. Other IRM sections<br>   <br>2. Forms<br>   <br>3. Letters<br>   <br>4. Publications<br>   <br>5. Documents<br>   <br>6. Notices |
| 5\. Interim guidance (IG) | An IG is issued and the procedural changes may affect a published IRM section. | 1. To determine if IG exists, check the IMD Tracking System.<br>   <br>2. To determine if IG impacts an IRM section, access IRM Online, select the IRM section, and then select the "Interim Guidance" button. | 1. Update the IRM to incorporate the most current guidance.<br>   <br>2. Incorporate procedures by the expiration date. |
| 6\. Reorganize, add or remove IRM material | Authors reorganize, add, move or remove IRM content, which results in numbering or title changes. This affects other documents that reference that content. | Check all IRM references:<br> <br>- IRM numbers and titles<br>  <br>- Exhibits<br>  <br>- Figures | 1. Update IRM references to other IMDs.<br>   <br>2. Verify references to other IRM sections and subsection numbers.<br>   <br>3. Verify IRM titles.<br>   <br>4. Check for obsolete IRM sections and/or content. |
| 7\. IRM material duplicated in another document | Duplicating guidance can lead to inconsistencies in guidance used by employees. Refer to the primary document to reduce the likelihood of conflicting information. | Check for IRM content that duplicates:<br> <br>- Another IRM section.<br>  <br>- A published document, where the content is the primary source. | 1. Rather than duplicate content, reference the original source.<br>   <br>2. Follow the rules for determining what belongs in the IRM. Refer to _IRM 1.11.2.2_, IRM Standards. |
| 8\. Legal and other references | References are subject to change. | Verify these sources annually:<br> <br>- IRC<br>  <br>- Regulations<br>  <br>- Notices<br>  <br>- Revenue Rulings<br>  <br>- Revenue Procedures | 1. Use Servicewide research tools to verify all legal references.<br>   <br>2. When preparing content, insert legal citations rather than restating the Code, regulations, etc. |
| 9\. Software or IT system changes | Technology changes may affect business processes and the IRM procedures dependent on these technologies. | Check for:<br> <br>- Processes and procedures related to new system requirements<br>  <br>- Release of new or upgraded software or computer application | 1. Obtain documentation about the new software or system change.<br>   <br>2. Revise IRM content to reflect new processes or procedures.<br>   <br>3. Request a new IRM section number. |
| 10\. Telephone numbers in the IRM | The IRS provides toll-free numbers so taxpayers and practitioners can contact us. | - Verify IRS toll-free numbers annually.<br>  <br>- Conduct a key word search for "1-888" or the term "toll-free." | Verify all toll-free numbers following _IRM 1.11.2.5.5_, Contact Information.<br> <br>### Note:<br>For an office or other telephone number, review and revise the IRM as necessary. |
| 11\. Website addresses | Website addresses change frequently. | 1. Verify all website addresses.<br>   <br>2. Key-word search for "http" to help locate the links.<br>   <br>3. Use the IRM Preview Tool to test links. | 1. Copy link from the "href" attribute of <a> tag into your internet browser to verify it works.<br>   <br>2. Fix the <a> tag for broken links. |

**Exhibit 1.11.2-3**

### IRM Web Resources

|     |     |
| --- | --- |
| Resource | Description |
| Acronyms Database | Searchable repository of Servicewide acronyms and abbreviations. |
| Alternative Media Center | Contacts to help deliver alternative accessible media to employees with disabilities. |
| Arbortext FAQs | Frequently asked questions and solutions. |
| Arbortext Editor Registration | Links to register and sign-up for email notifications of software updates and get the latest upgrades and fixes. |
| Other Internal Management Documents | List of IMD websites for each business unit. |
| Chief Counsel Clearance Determination Tool | Helps determine if your IRM requires review by the Office of Chief Counsel. |
| [FOIA Library](https://www.irs.gov/privacy-disclosure/foia-library) | The Freedom of Information Act (FOIA) Library provides a comprehensive list of documents and other information available electronically on IRS.gov. |
| IMD Community News | Join the IMD Community Team, to receive news via TEAMS channel and emails that inform the IMD community about IMD updates and news. |
| IMD Electronic Clearance | Online review and approval system for IMDs that streamlines the clearance process by allowing for easy retrieval of proposed changes, comments and approval in a centralized location. |
| Internal Management Documents (IMD) Contacts List | List of IMD contacts searchable by business unit or by their role in the IMD process. |
| Information Resources Accessibility Program (IRAP) | Contact for information on creating documents and files accessible to persons with disabilities. |
| IRM Authoring Software Course Book | Training manual on the XML authoring software. Training 15770-002: Authoring the IRM with Arbortext Editor. |
| IRM Decision Tool | An interactive flowchart that helps you determine if content belongs in the IRM. |
| IRM Online | Searchable database that contains current and prior versions of every published IRM section and links to interim guidance, SERP, the IRS Catalog, the IRS Historical Research Library and more. |
| IRM Preview Tool | See what the IRM will look like (on IRM Online) to test links and ensure proper display of IRM format/tables. |
| IRM Requests and Author Changes Form | Submit requests to:<br> <br>- Request a new IRM section<br>  <br>- Request a new IRM chapter and section<br>  <br>- Change an IRM section title<br>  <br>- Change a chapter title<br>  <br>- Change an IRM owner<br>  <br>- Change an IRM author |
| Document 12835, IRM Style Guide | Guidelines for proper IRM format, structure, plain language and writing standards. |
| IRS Historical Research Library<br> Email: \*IRM Library | Access historical IRS and IRM documentation<br> Contact the library staff for questions and information . |
| IRS Style Guide | Web-based guide administrated by C&L that provides grammar, punctuation capitalization rules and more for non-IRM internal communications . |
| Internal Revenue Manual (IRM) Program<br> Email: \*M&P IRM | M&P IRM Program page, shows M&P's IRM-related resources. |
| IRM Part and Chapter Titles | List of the approved IRM part and chapter titles automatically generated by the IRM authoring software into the XML file. |
| Plain Language website | Information on writing in plain language, as required by the Plain Writing Act of 2010, 5 USC 301. |
| Publishing + Distribution site (IRS Catalog) Find a Product | Access to all current and archived IRS published products. |
| ReferenceNet Legal and Tax Research Services | Portal for tax, legal, asset locator and other corporate research tools. |
| Interim Guidance<br> (The public can search for interim guidance at: [Recent Interim Guidance to Staff](https://www.irs.gov/uac/Interim-Guidance-by-IRS-Business-Process) at irs.gov) | Search for active and archived IG through the IMD search page on IMD Track, which you can filter by business unit.<br> SPDER posts IG subject to FOIA on the FOIA Library page on IRS.gov. |
| Servicewide Electronic Research Program (SERP) | An electronic research source maintained by TS that provides access to current IRMs, IPUs and reference materials. Not all IRMs are on SERP; SERP hosts IRMs by request based on end-user need. |
| IMD Community of Practice | Expansive list of resources for authors, coordinators, managers and reviewers; provides links to training, IMD news, job aids and more. |
| IMD Training information | IRM authoring and IMD training available to the IMD community in self-study, virtual and classroom formats. |
| Virtual IMD Learning Library Application (VILLA) | Compilation of one to ten minute training videos on various IMD and Arbortext topics. |
| XML Help Desk<br> Email: \*TS MPM XMLSGMLHELP | XML Help Desk Knowledge Base contact information, to contact an expert for help with the IRM authoring software. |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-011-002#addtoany "Show all")

A2A