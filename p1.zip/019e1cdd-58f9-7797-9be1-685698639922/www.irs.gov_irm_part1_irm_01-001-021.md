---
url: "https://www.irs.gov/irm/part1/irm_01-001-021"
title: "1.1.21 Chief Financial Officer | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-001-021#main-content)

- 1.1.21  [Chief Financial Officer](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204740224)
  - 1.1.21.1  [Overview](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204621216)
  - 1.1.21.2  [Background, Authorities and Related Resources](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204618896)
  - 1.1.21.3  [Office of the Chief Financial Officer](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204784496)
    - 1.1.21.3.1  [Financial Management](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204769344)
      - 1.1.21.3.1.1  [Administration Office](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204764000)
      - 1.1.21.3.1.2  [Policy and Data Analytics Office](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204759536)
      - 1.1.21.3.1.3  [Corporate Accounting](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204348992)
        - 1.1.21.3.1.3.1  [Accounts Payable Office](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204343984)
        - 1.1.21.3.1.3.2  [Credit Card Services Office](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204337808)
        - 1.1.21.3.1.3.3  [Purchase Card Approver Group](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204333072)
        - 1.1.21.3.1.3.4  [Account Maintenance and Support](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204330176)
        - 1.1.21.3.1.3.5  [Credit Card Administration and Assistance](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204326960)
        - 1.1.21.3.1.3.6  [Procedures Analysis and Review](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204323456)
        - 1.1.21.3.1.3.7  [Purchase Card Payments](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204320288)
        - 1.1.21.3.1.3.8  [Financial Reporting and Analysis Office](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204317248)
        - 1.1.21.3.1.3.9  [General Ledger Review](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204308224)
        - 1.1.21.3.1.3.10  [Revenue Reporting](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204306304)
        - 1.1.21.3.1.3.11  [Review and Reconciliation](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204304448)
        - 1.1.21.3.1.3.12  [Administrative Reporting](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204302592)
        - 1.1.21.3.1.3.13  [Headquarters Accounting](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204300800)
        - 1.1.21.3.1.3.14  [Government Payables and Funds Management Office](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204296144)
        - 1.1.21.3.1.3.15  [Travel Management Office](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204284832)
        - 1.1.21.3.1.3.16  [Travel Services](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204274912)
        - 1.1.21.3.1.3.17  [Travel Review](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204271968)
        - 1.1.21.3.1.3.18  [Travel Operations](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204268896)
        - 1.1.21.3.1.3.19  [Travel Processing](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204265376)
      - 1.1.21.3.1.4  [Revenue Financial Accounting](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204263616)
        - 1.1.21.3.1.4.1  [Unpaid Assessments and Analysis Office](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204255184)
        - 1.1.21.3.1.4.2  [Unpaid Assessments Account Analysis](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204248784)
        - 1.1.21.3.1.4.3  [Custodial Analysis and Reporting](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204244800)
        - 1.1.21.3.1.4.4  [Unpaid Assessments Account Resolution](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204241296)
        - 1.1.21.3.1.4.5  [Revenue Accounting Operations Office](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204237104)
        - 1.1.21.3.1.4.6  [Financial Management Systems Office](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204224736)
        - 1.1.21.3.1.4.7  [Systems Security and Compliance](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204217872)
        - 1.1.21.3.1.4.8  [Systems Operations Support](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204213424)
        - 1.1.21.3.1.4.9  [Revenue Systems](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204210320)
    - 1.1.21.3.2  [Corporate Budget](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204204992)
      - 1.1.21.3.2.1  [Budget Formulation Office](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204195568)
      - 1.1.21.3.2.2  [Financial Planning and Analysis Office](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204189168)
      - 1.1.21.3.2.3  [Budget Execution Office](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204181728)
      - 1.1.21.3.2.4  [National Headquarters Budget Office](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204175504)
      - 1.1.21.3.2.5  [Strategic Planning Office](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204171184)
      - 1.1.21.3.2.6  [Cost and User Fees Office](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204163408)
    - 1.1.21.3.3  [Internal Controls](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204154560)
      - 1.1.21.3.3.1  [Internal Reviews Office](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204148752)
      - 1.1.21.3.3.2  [Assurance Review and Testing Office](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204141264)
      - 1.1.21.3.3.3  [Outreach and Reporting Office](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204135136)
        - 1.1.21.3.3.3.1  [Outreach and Education](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204128048)
  - Exhibit  1.1.21-1  [Terms, Definitions and Acronyms](https://www.irs.gov/irm/part1/irm_01-001-021#idm140343204126240)

# Part 1. Organization, Finance, and Management

# Chapter 1. Organization and Staffing

# Section 21. Chief Financial Officer

* * *

## 1.1.21 Chief Financial Officer

#### Manual Transmittal

October 22, 2024

#### Purpose

(1) This transmits revised IRM 1.1.21, Organization and Staffing, Chief Financial Officer.

#### Material Changes

(1) IRM 1.1.21.3.1.2, Policy and Data Analytics Office, updated to clarify the responsibilities and IRMs maintained by the Policy and Data Analytics office.

(2) IRM 1.1.21.3.1.3.3(1)(a), Purchase Card Approver Group, updated to reflect change in office name from W&I to Taxpayer Services.

(3) IRM 1.1.21.3.1.3.5(1)(b), Credit Card Administration and Assistance, updated to clarify the responsibilities of the Credit Card Administration and Assistance section.

(4) IRM 1.1.213.1.3.8(3), Financial Reporting and Analysis Office, updated IRMs maintained by the Financial Reporting and Analysis office.

(5) IRM 1.1.21.3.1.3.10, Revenue Reporting, updated to clarify the responsibilities of Revenue Reporting.

(6) IRM 1.1.21.3.1.3.13, Headquarters Accounting, updated to clarify the responsibilities of Headquarters Accounting.

(7) IRM 1.1.21.3.1.4, Revenue Financial Accounting, updated to clarify the responsibilities of the Revenue Financial Accounting organization.

(8) IRM 1.1.21.3.1.4.1, Unpaid Assessments and Analysis Office, updated to clarify the responsibilities and sections of the Unpaid Assessments and Analysis office.

(9) IRM 1.1.21.3.1.4.3, Custodial Analysis and Reporting, update to reflect current office name.

(10) IRM 1.1.21.3.1.4.5(2)(a), Revenue Accounting Operations Office, updated to clarify the responsibilities of the Revenue Accounting office.

(11) IRM 1.1.21.3.1.4.7(1)(d), Systems Security and Compliance, updated to clarify the responsibilities of the Systems Security and Compliance office.

(12) IRM 1.1.21.3.2.2(2)(d), Financial Planning and Analysis Office, updated to clarify the responsibilities of the Financial Planning and Analysis office.

(13) IRM 1.1.21.3.2.6, Cost and User Fees Office, updated to clarify the responsibilities and IRMs maintained by the Cost and User Fees Office.

(14) IRM 1.1.21.3.3.1(2)(a), Internal Reviews Office, updated to reflect change in IRM title.

(15) IRM 1.1.21.3.3.2, Assurance Review and Testing Office, updated to clarify the responsibilities of the Assurance Review and Testing Office.

(16) IRM 1.1.21.3.3.3.1, Outreach and Education, added new section to provide Outreach and Education responsibilities.

(17) Minor editorial and formatting changes made throughout the document.

#### Effect on Other Documents

IRM 1.1.21, dated December 18, 2023, is superseded.

#### Audience

All business units

#### Effective Date

(10-22-2024)

Teresa R. Hunter

Chief Financial Officer

**1.1.21.1** **(12-18-2023)**

### Overview

1. This IRM provides the responsibilities of the CFO. The CFO organization manages a portfolio of corporate-wide activities, including budget formulation, budget execution, strategic planning, accounting, financial management, travel services, credit card services and internal controls.

2. The CFO, Financial Management, Policy and Data Analytics office, develops and maintains this IRM.


**1.1.21.2** **(10-22-2024)**

### Background, Authorities and Related Resources

1. The Chief Financial Officers Act of 1990 (CFO Act) is a federal law intended to regulate the accounting, auditing and financial reporting practices of the federal government. In accordance with the CFO Act, each agency or department vests its financial management functions in its CFO.

2. The CFO Act:



   - Brings more effective general and financial management practices to the federal government.

   - Provides for improvement in each federal agency of accounting systems, financial management and internal controls to assure the issuance of reliable financial information and to deter fraud, waste and abuse of government resources.

   - Produces complete, reliable, timely and consistent financial information for use by the executive branch of the federal government and the Congress in the financing, management and evaluation of federal programs.


3. The authorities for this IRM include:



01. [Government Performance and Results Modernization Act of 2010](https://www.congress.gov/bill/111th-congress/house-bill/2142), Pub. L. No. 111-352

02. [Accountability of Tax Dollars Act of 2002](https://www.congress.gov/bill/107th-congress/house-bill/4685/text), Pub. L. No. 107-289

03. [E-Government Act of 2002](https://www.congress.gov/bill/107th-congress/house-bill/2458), Pub. L. No. 107-347

04. [Federal Information Security Management Act of 2002](https://www.congress.gov/bill/107th-congress/house-bill/3844), Pub. L. No. 107-347

05. [IRS Restructuring and Reform Act of 1998](https://www.congress.gov/bill/105th-congress/house-bill/2676), Pub. L. No. 105-206

06. [Federal Financial Management Improvement Act of 1996](https://www.congress.gov/bill/104th-congress/house-bill/4319), Pub. L. No. 104-208

07. [Government Management Reform Act of 1994](https://www.congress.gov/bill/103rd-congress/senate-bill/2170), Pub. L. No. 103-356

08. [Government Performance and Results Act of 1993](https://obamawhitehouse.archives.gov/omb/mgmt-gpra/gplaw2m), Pub. L. No. 103-62

09. [Chief Financial Officers Act of 1990](https://www.congress.gov/bill/101st-congress/house-bill/5687#:~:text=Chief%20Financial%20Officers%20Act%20of%201990%20%2D%20Title%20I%3A%20General%20Provisions,be%20to%20improve%20such%20systems.), Pub. L. No. 101-576, section 902

10. [Federal Managers’ Financial Integrity Act of 1982](https://obamawhitehouse.archives.gov/omb/financial_fmfia1982), Pub. L. No. 97-255

11. Treasury Directive 40-02, [Corresponding with the General Accounting Office (GAO)](https://www.treasury.gov/about/role-of-treasury/orders-directives/Pages/td40-02.aspx)

12. Treasury Directive 40-03, [Treasury Audit Resolution, Follow-Up, and Closure](https://www.treasury.gov/about/role-of-treasury/orders-directives/Pages/td40-03.aspx)

13. Treasury Directive 40-04, [Treasury Internal Control Program](https://www.treasury.gov/about/role-of-treasury/orders-directives/Pages/td40-04.aspx)


4. Related resources for this IRM include:



1. Office of Management and Budget (OMB) Circular A-11, Preparation, Submission, and Execution of the Budget

2. OMB Circular A-25, [User Charges](https://www.whitehouse.gov/omb/information-for-agencies/circulars/)

3. OMB Circular A-123, [Management's Responsibility for Enterprise Risk Management and Internal Control](https://www.whitehouse.gov/omb/information-for-agencies/circulars/)

4. OMB Circular A-136, [Financial Reporting Requirements](https://www.whitehouse.gov/omb/information-for-agencies/circulars/)

5. Financial Management Codes Handbook

6. [Principles of Federal Appropriations Law (Red Book)](http://www.gao.gov/legal/redbook/redbook.html)

7. [Federal Accounting Standards Advisory Board (FASAB) Handbook of Federal Accounting Standards and Other Pronouncements, as Amended](https://fasab.gov/accounting-standards/)


**1.1.21.3** **(12-18-2023)**

### Office of the Chief Financial Officer

1. **Mission**: Leading IRS’s financial management operations with integrity and accountability through expert planning and sound financial advice, ensuring an excellent customer experience.

2. **Strategic Goals**:



1. Promote resilient, agile, and sound financial management operations while embracing innovative practices.

2. Provide strategic advice to assess strategies, mitigate risks, and optimize performance.

3. Foster an inclusive, collaborative and well-equipped workforce.


3. The CFO organization oversees the IRS’s budget and planning, financial management and reporting, internal control practices and provides expert planning and financial advice to IRS leadership. The CFO manages IRS’s financial activities in compliance with the CFO Act.

4. The CFO reports to the Chief Operating Officer.

5. The CFO and the Deputy CFO are responsible for:



1. Serving as the principal IRS authority for the Servicewide activities the CFO organization oversees and providing expert financial advice to IRS leadership.

2. Developing operational and performance goals, prioritizing funding for programs and investments, and developing the IRS’s annual budget request.

3. Administering, monitoring and reporting on the financial resources that support the IRS’s mission and strategic plan.

4. Administering Servicewide internal control and assessment activities.


6. The Financial Modernization and Technology office supports the CFO organization in accomplishing its overall mission and objectives.



1. The Financial Management and Technology office is responsible for:


       • Innovation efforts within the IRS CFO.


       • Data analytics initiatives to deliver insights into performance and financial results.


       • CFO systems and related security.

2. The Director, Financial Modernization and Technology office reports to the Deputy CFO.


7. The CFO and Deputy CFO lead the CFO organization, including its three subordinate areas:



1. Financial Management

2. Corporate Budget

3. Internal Controls


**1.1.21.3.1** **(10-22-2024)**

#### Financial Management

1. The Financial Management organization administers IRS’s financial management and reporting activities and monitors the accounting lifecycle.

2. The Financial Management organization is responsible for:



1. Overseeing the payment processing on accounts receivable and payable.

2. Leading the financial statement audit activities and production of the Annual Financial Report.

3. Developing IRS accounting policy that supports the IRS’s mission and strategic plan.


3. The Senior Associate CFO for Financial Management leads the organization, including the Corporate Accounting and Revenue Financial Accounting organizations and two subordinate offices:



1. Administration

2. Policy and Data Analytics


**1.1.21.3.1.1** **(10-22-2024)**

##### Administration Office

1. The Administration office provides administrative support services to the Financial Management organization, ensuring accountability, effectiveness, and optimal performance.

2. The Administration office is responsible for performing the following activities for the Financial Management organization:



1. Coordinating personnel and training activities.

2. Overseeing and maintaining the budget.

3. Managing webpages and SharePoint sites.


3. The Administration office has one subordinate section, the Technical and Training Support section.


**1.1.21.3.1.2** **(10-22-2024)**

##### Policy and Data Analytics Office

1. The Policy and Data Analytics office is responsible for providing expertise and a Financial Management-wide view, consultation and customer service to effectively evaluate, decide, govern and execute its strategic goals.

2. The Policy and Data Analytics office is responsible for:



1. Promoting efficiency and effectiveness across Financial Management while strengthening the relationship among strategy, performance, revenue and corporate accounting offices.

2. Coordinating the internal management of the financial statement audit and providing oversight, monitoring, and coordination of the IRS’s responses to audits, inspections and reviews, which are primarily conducted by TIGTA and GAO.

3. Leading the CFO Internal Management Document program.

4. Integrating and overseeing policy coordination across Financial Management and facilitating integrated strategic thinking and planning to ensure a common direction.

5. Driving Financial Management forward by building high-impact, real-time decision analysis and business intelligence capabilities.


3. The Policy and Data Analytics office maintains:



1. IRM 1.1.21, Chief Financial Officer

2. IRM 1.2.69, Business Unit Delegations of Authority for Chief Financial Officer

3. IRM 1.32.4, Government Travel Card Program

4. IRM 1.35.4, Purchase Card Program

5. IRM 1.35.14, IRS Annual Financial Statement Audit


4. The Policy and Data Analytics office has two subsections:



1. Audit Coordination and Quality Control

2. Policy and Analytical Support


**1.1.21.3.1.3** **(10-22-2024)**

##### Corporate Accounting

1. The Corporate Accounting organization ensures proper accounting and timely reporting of IRS appropriated funds.

2. The Corporate Accounting organization is responsible for overseeing IRS financial reporting and ensuring compliance with federal financial reporting requirements.

3. The Associate CFO for Corporate Accounting leads the organization, including its five subordinate offices:



1. Accounts Payable Office

2. Credit Card Services Office

3. Financial Reporting and Analysis Office

4. Government Payables and Funds Management Office

5. Travel Management Office


**1.1.21.3.1.3.1** **(10-22-2024)**

###### Accounts Payable Office

1. The Accounts Payable office processes all commercial accounts and miscellaneous programs payables.

2. The Accounts Payable office is responsible for:



1. Timely processing of payables to meet the prompt pay guidelines.

2. Supporting Treasury review and daily payment schedules.


3. The Accounts Payable office maintains IRM 1.35.3, Receipt and Acceptance Guidelines.

4. The Accounts Payable office has one subordinate section, Accounts Payable Processing.

5. The Accounts Payable Processing section has three subordinate units:



1. Accounts Payable Unit 1

2. Accounts Payable Unit 2

3. Miscellaneous Programs


**1.1.21.3.1.3.2** **(10-22-2024)**

###### Credit Card Services Office

1. The Credit Card Services office administers the IRS purchase and travel card programs.

2. The Credit Card Services office is responsible for ensuring accurate and timely payments for the centrally billed purchase card program.

3. The Credit Card Services office has five subordinate sections:



1. Purchase Card Approver Group

2. Account Maintenance and Support

3. Credit Card Administration and Assistance

4. Procedures Analysis and Review

5. Purchase Card Payments


**1.1.21.3.1.3.3** **(10-22-2024)**

###### Purchase Card Approver Group

1. The Purchase Card Approver Group is responsible for:



1. Providing oversight and approval responsibility for purchase card activity of purchase cardholders in CFO, LB&I, SB/SE and Taxpayer Services by authorizing cardholder purchases.

2. Assisting cardholders to help prevent misuse of government credit cards.


**1.1.21.3.1.3.4** **(10-22-2024)**

###### Account Maintenance and Support

1. The Account Maintenance and Support section is responsible for:



1. Providing purchase and travel card customer support.

2. Performing account maintenance and control reviews for purchase and travel card, including managing the clearance program and processing exemption/exception requests.

3. Managing travel card past due and delinquency.


**1.1.21.3.1.3.5** **(10-22-2024)**

###### Credit Card Administration and Assistance

1. The Credit Card Administration and Assistance section is responsible for:



1. Providing outreach, education and assistance to support an efficient credit card program.

2. Serving as the credit card misuse point of contact for referring inappropriate use of the purchase and travel card to management through Labor/Employee Relations and Negotiations.

3. Providing approval and tracking of transportation and fees for the centrally-billed account for travel for employees without a travel card.


**1.1.21.3.1.3.6** **(10-22-2024)**

###### Procedures Analysis and Review

1. The Procedures Analysis and Review section is responsible for:



1. Updating, reviewing and maintaining policies, procedures and web resources for the purchase and travel card programs.

2. Approving Purchase Card Official application processing.

3. Reviewing purchase and travel card compliance.


**1.1.21.3.1.3.7** **(10-22-2024)**

###### Purchase Card Payments

1. The Purchase Card Payments section is responsible for:



1. Processing purchase card transaction payments to the credit card contractor.

2. Auditing vendor invoices and verifying valid obligations.

3. Providing funds management and reports for purchase card transactions.


**1.1.21.3.1.3.8** **(10-22-2024)**

###### Financial Reporting and Analysis Office

1. The Financial Reporting and Analysis office maintains financial data integrity by overseeing IRS’s financial and accounting processes and deliverables.

2. The Financial Reporting and Analysis office is responsible for:



1. Preparing monthly financial reports to Treasury.

2. Producing periodic and year-end financial statements.

3. Ensuring compliance with the Digital Accountability and Transparency Act of 2014.

4. Supporting the financial statement audit.


3. The Financial Reporting and Analysis office maintains:



1. IRM 1.35.6, Property and Equipment Accounting

2. IRM 3.17.41, Excise Reporting

3. IRM 3.17.63, Redesigned Revenue Accounting Control System


4. The Financial Reporting and Analysis office has five subordinate sections:



1. General Ledger Review

2. Revenue Reporting

3. Review and Reconciliation

4. Administrative Reporting

5. Headquarters Accounting


**1.1.21.3.1.3.9** **(10-22-2024)**

###### General Ledger Review

1. The General Ledger Review section is responsible for monitoring, analyzing, reconciling and documenting IRS’s general ledger accounts.


**1.1.21.3.1.3.10** **(10-22-2024)**

###### Revenue Reporting

1. The Revenue Reporting section compiles and prepares monthly Treasury and annual financial reports including the IRS statement of custodial activity, and related footnotes and supplemental information, and custodial accounting-related Data Book sections.


**1.1.21.3.1.3.11** **(10-22-2024)**

###### Review and Reconciliation

1. The Review and Reconciliation section is responsible for monitoring, reconciling and preparing work papers for designated general ledger accounts, Fund Balance with Treasury, Intra-governmental Eliminations and the Treasury Report on Receivables.


**1.1.21.3.1.3.12** **(10-22-2024)**

###### Administrative Reporting

1. The Administrative Reporting section is responsible for submitting financial data to the Treasury Information Executive Repository and preparing the year-end financial statements.


**1.1.21.3.1.3.13** **(10-22-2024)**

###### Headquarters Accounting

1. The Headquarters Accounting section maintains the headquarters general ledger for refundable credit activity, provides procedural guidance for the campus custodial general ledger (RRACS) and conducts end of month and fiscal year closing activities.

2. The Headquarters Accounting section is responsible for:



1. Maintaining the headquarters general ledger for refundable credit activity and general ledger activity output from RRACS.

2. Conducting end of month and fiscal year closing activities.

3. Preparing and reviewing audit sampling.

4. Providing policy oversight and guidance to CFO Revenue Accounting Control System (RACS) units and Treasury scoreboard reporting.


**1.1.21.3.1.3.14** **(10-22-2024)**

###### Government Payables and Funds Management Office

1. The Government Payables and Funds Management office oversees administrative accounts receivable, cash receipts, obligation-related activity and reimbursable billing to other government agencies and government accounts payables.

2. The Government Payables and Funds Management office is responsible for:



1. Validating commercial and government obligations through aging unliquidated obligations and aging unliquidated commitments reviews.

2. Providing prompt pay reports and Form 1099 federal reporting.

3. Processing accounts receivable, obligation and de-obligation requests, cash receipts, user fee deposits and refunds, posting reimbursable earnings and payroll and inter-appropriation expenditure adjustments.

4. Processing IRS government accounts payable.

5. Ensuring the validity of obligations, vendor codes and accounting code changes.


3. The Government Payables and Funds Management office maintains:



1. IRM 1.35.13, Administrative Waiver

2. IRM 1.35.24, Establishing IRS Commitments and Obligations

3. IRM 1.36.4, Administrative (Non-Tax) Debt Management


4. The Government Payables and Funds Management office has two subordinate sections:



1. Intergovernmental and Funds Management

2. Intragovernmental and Funds Processing


5. Intragovernmental and Funds Processing has three subordinate units:



1. Debt Collection Unit

2. IPAC Unit

3. Obligation Unit


**1.1.21.3.1.3.15** **(10-22-2024)**

###### Travel Management Office

1. The Travel Management office administers Servicewide travel programs.

2. The Travel Management office is responsible for:



1. Providing policy and program guidance.

2. Managing and improving travel products and services.


3. The Travel Management office maintains:



1. IRM 1.32.1, IRS Local Travel Guide

2. IRM 1.32.10, Reporting on Event-Related Spending

3. IRM 1.32.11, IRS City-to-City Travel Guide

4. IRM 1.32.12, IRS Relocation Travel Guide

5. IRM 1.32.13, Relocation Services Program

6. IRM 1.32.14, Gainsharing Travel Savings Program

7. IRM 1.32.20, Using Appropriated Funds to Purchase Meals and Light Refreshments


4. The Travel Management office has four subordinate sections:



1. Travel Services

2. Travel Review

3. Travel Operations

4. Travel Processing


**1.1.21.3.1.3.16** **(10-22-2024)**

###### Travel Services

1. The Travel Services section is responsible for:



1. Managing the IRS travel help desk.

2. Providing technical support for the IRS travel management system.


**1.1.21.3.1.3.17** **(10-22-2024)**

###### Travel Review

1. The Travel Review section is responsible for:



1. Developing and administrating travel and relocation policy guidance in accordance with the Federal Travel Regulation.

2. Performing compliance reviews and analyses of travel vouchers.


**1.1.21.3.1.3.18** **(10-22-2024)**

###### Travel Operations

1. The Travel Operations section is responsible for:



1. Managing the travel, relocation and state and federal tax payments including the Federal Form 941, Quarterly Federal Tax Returns.

2. Performing compliance reviews and analyses of travel vouchers.


2. The Travel Operations section has one subordinate unit, Travel Processing.


**1.1.21.3.1.3.19** **(10-22-2024)**

###### Travel Processing

1. The Travel Processing section is responsible for processing manual travel and relocation vouchers and disbursements.


**1.1.21.3.1.4** **(10-22-2024)**

##### Revenue Financial Accounting

1. The Revenue Financial Accounting organization ensures proper accounting and timely reporting of IRS tax-related activities and operational control for all CFO financial management accounting systems.

2. The Revenue Financial Accounting organization is responsible for:



1. Overseeing Federal Information Security Management Act (FISMA) process compliance for CFO financial management systems.

2. Accounting and reporting for all tax assessments, tax revenue receipts, refund activities and unpaid assessments to comply with CFO Act, FASAB and Treasury and OMB guidance.

3. Establishing and maintaining revenue accounting policies and procedures.

4. Serving as the owner of the IRS’s financial management systems and ensuring compliance with accounting standards and internal controls per the CFO Act; FASAB; Treasury; OMB; federal financial system requirements; and other financial requirements.

5. Ensuring that business units inform or share any changes in operational or system processes that may affect revenue financial systems or reporting.

6. Providing financial system modernization development support and ensuring financial system requirements and other financial requirements are addressed.


3. The Associate CFO for Revenue Financial Accounting leads the organization, including its three subordinate offices:



1. Unpaid Assessments and Analysis Office

2. Revenue Accounting Operations Office

3. Financial Management Systems Office


**1.1.21.3.1.4.1** **(10-22-2024)**

###### Unpaid Assessments and Analysis Office

1. The Unpaid Assessments and Analysis office maintains the integrity and accuracy of the data and business rules used to segment the inventory of unpaid assessments for operational and financial reporting purposes and is responsible for analyzing tax data to accurately present it to the Department of the Treasury, Congress and GAO.

2. The Unpaid Assessments and Analysis office is responsible for:



1. Financial reporting and oversight for unpaid assessments.

2. Addressing financial reporting system noncompliance issues.


3. The Unpaid Assessments and Analysis office maintains IRM 1.34.4, Unpaid Assessments.

4. The Unpaid Assessments and Analysis office has three subordinate sections:



1. Unpaid Assessments Account Analysis

2. Custodial Analysis and Reporting

3. Unpaid Assessments Account Resolution


**1.1.21.3.1.4.2** **(10-22-2024)**

###### Unpaid Assessments Account Analysis

1. The Unpaid Assessments Account Analysis section ensures that unpaid assessments are accurately recorded in accordance with the federal accounting standard categorization requirements for financial reporting.

2. The Unpaid Assessments Account Analysis section is responsible for:



1. Performing technical evaluations of unpaid assessment data, including the evaluation of IRS’s compliance with laws related to tax accounts reviewed during the GAO custodial financial statement audit.

2. Communicating audit findings and providing technical guidance and assistance to the business units.


**1.1.21.3.1.4.3** **(10-22-2024)**

###### Custodial Analysis and Reporting

1. The Custodial Analysis and Reporting section analyzes and summarizes unpaid assessments data.

2. The Custodial Analysis and Reporting section is responsible for:



1. Reporting unpaid assessments financial information.

2. Delivering statistical information to report net taxes receivable as an asset.


**1.1.21.3.1.4.4** **(10-22-2024)**

###### Unpaid Assessments Account Resolution

1. The Unpaid Assessments Account Resolution section ensures that non-delinquent Internal Revenue Code (IRC) Section 965(h), Election to Pay Liability in Installments and delinquent unpaid assessments are accurately recorded in accordance with the federal accounting standard categorization requirements for financial reporting.

2. The Unpaid Assessments Account Resolution section is responsible for:



1. Performing technical evaluations of unpaid assessment data, including the evaluation of IRS’s compliance with laws related to tax accounts reviewed during the IRC Section 965(h) testing and unpaid assessment quality reviews.

2. Communicating IRC Section 965(h) and quality review test findings while providing technical guidance and assistance to the business units.


**1.1.21.3.1.4.5** **(10-22-2024)**

###### Revenue Accounting Operations Office

1. The Revenue Accounting Operations office ensures compliance with federal financial management and reporting activities for custodial accounting and is responsible for internal and external reporting requirements and the preparation of the annual revenue and refund audit samples. The Revenue Accounting Operations office consists of two Campus Accounting Departments housing multiple RACS units.

2. The Revenue Accounting Operations RACS departments are responsible for:



1. Recording transactions into RRACS.

2. Ensuring that assessments are recorded properly and signed timely.


3. The Revenue Accounting Operations office maintains:



1. IRM 3.17.15, Accounting Reports Analyst - Responsibilities

2. IRM 3.17.64, Accounting Control General Ledger Policies and Procedures

3. IRM 3.17.244, Manual Assessments


4. The Revenue Accounting Operations office has two subordinate sections:



1. Campus Accounting Department 1

2. Campus Accounting Department 2


5. Campus Accounting Department 1 consists of four RACS units:



1. Austin RACS Unit

2. Cincinnati RACS Unit

3. Kansas City RACS Unit 1

4. Kansas City RACS Unit 2


6. Campus Accounting Department 2 consists of three RACS units:



1. Fresno RACS Unit

2. Ogden RACS Unit 1

3. Ogden RACS Unit 2


**1.1.21.3.1.4.6** **(10-22-2024)**

###### Financial Management Systems Office

1. The Financial Management Systems office oversees IRS’s data integrity and user security controls for Financial Management.

2. The Financial Management Systems office is responsible for:



1. Managing user access and providing users with system user guides, training materials, system outage notifications and helping with executing transactions.

2. Facilitating fiscal year-end/annual close system activities and the annual budget load.

3. Supporting Financial Management reporting and system requirements.


3. The Financial Management Systems office maintains IRM 3.17.50, RRACS Procedures.

4. The Financial Management Systems office has three subordinate sections:



1. Systems Security and Compliance

2. Systems Operations Support

3. Revenue Systems


**1.1.21.3.1.4.7** **(10-22-2024)**

###### Systems Security and Compliance

1. The Systems Security and Compliance section is responsible for:



1. Overseeing the annual FISMA process for integrated financial system (IFS) and mLINQS and other systems.

2. Supporting IFS users and managing IFS roles.

3. Providing support for IRS’s travel and relocation systems.

4. Posting and ensuring the integrity of payroll data.

5. Overseeing the annual FISMA process for IFS and mLINQS.


**1.1.21.3.1.4.8** **(10-22-2024)**

###### Systems Operations Support

1. The Systems Operations Support section is responsible for:



1. Providing testing, functional support and defect resolution for IFS and Business Warehouse system requirements.

2. Conducting master data updates and data quality assurance checks on inbound and outbound interface execution.


**1.1.21.3.1.4.9** **(10-22-2024)**

###### Revenue Systems

1. The Revenue Systems section ensures revenue accounting systems remain compliant with all relevant rules and regulations, along with managing new system requirements requested by business stakeholders.

2. The Revenue Systems section is responsible for:



1. Conducting user acceptance testing for systemic changes implemented for production environments due to new legislation or change requests.

2. Maintaining the annual FISMA assessments for RRACS, Financial Management Information Systems (FMIS)/Custodial Detail Database (CDDB), Automated Manual Assessment, Automated Quarterly Excise Tax Listing and Custodial Audit Support Tracking System.

3. Maintaining the annual maintenance of custodial systems and production user profile table access.

4. Preparing the Federal Financial Management Improvement Act assessment for RRACS and FMIS/CDDB.

5. Conducting external system audit reviews and performing disaster recovery testing for RRACS.


**1.1.21.3.2** **(10-22-2024)**

#### Corporate Budget

1. The Corporate Budget organization leads the Service’s strategic planning, budgeting and execution system that supports the IRS’s vision, mission, goals and objectives, defines its performance measures and targets and supports agency-wide investment decisions. The Corporate Budget office also leads the IRS’s governance maintenance process.

2. The Corporate Budget organization is responsible for:



1. Preparing budget requests, apportionments, operating plans and strategic plans, managing the related hearings and appeals processes and liaising between the IRS, Treasury, OMB, Congress and external stakeholders including GAO and TIGTA on all budget issues.

2. Executing the IRS budget in an integrated and cohesive manner by managing and distributing IRS budget authority (including user fees) and using sound budgetary and investment management principles.

3. Providing budget guidance and analytic expertise to senior IRS leadership and the IRS business units.

4. Chairing the Program and Budget Advisory Committee (PBAC) governance board.

5. Maintaining, interpreting and ensuring compliance with policies and procedures for cost accounting, user fees and trust fund administrative costs.


3. The Associate CFO for Corporate Budget and Deputy Associate CFO for Corporate Budget lead the organization, including its six subordinate offices:



1. Budget Formulation Office

2. Financial Planning and Analysis Office

3. Budget Execution Office

4. National Headquarters Budget Office

5. Strategic Planning Office

6. Cost and User Fees Office


**1.1.21.3.2.1** **(10-22-2024)**

##### Budget Formulation Office

1. The Budget Formulation office develops and submits IRS budget requests that justify the resources that the IRS needs to accomplish its mission and goals.

2. The Budget Formulation office is responsible for:



1. Preparing IRS’s three budget requests - Treasury, OMB and Congressional, in accordance with OMB Circular A-11, _Preparation, Submission and Execution of the Budget_, and written guidance from Treasury and OMB. Each budget cycle includes establishing the current year base budget, computing the additional costs of maintaining current levels, developing program changes with the business units, to include base changes, new resource requests, program decreases (when required), managing budget hearings and facilitating the passback and appeals process with Treasury and OMB.

2. Serving as liaison between the IRS, Treasury and OMB, and coordinating with the IRS business units for all budget formulation issues.

3. Ensuring the completion of the President’s Budget appropriation language and narrative statements, as specified in OMB Circular A-11, Part 2, Section 95, _Budget Appendix and Print Materials_.


**1.1.21.3.2.2** **(10-22-2024)**

##### Financial Planning and Analysis Office

1. The Financial Planning and Analysis office manages the plan development process, supports the budget formulation and execution processes, develops projections to assist leadership in decisions regarding funding allocations and responds to ad hoc inquiries from internal and external customers.

2. The Financial Planning and Analysis office is responsible for:



1. Issuing guidance and managing the plan development and continuing resolution processes and distributing available resources.

2. Preparing and submitting apportionments (initial, newly enacted, user fees) in compliance with OMB Circular A-11, Part 4, _Instructions on Budget Execution_. Apportionments and inter-appropriation transfers are submitted on Standard Form 1151, Nonexpenditure Transfer Authorizations.

3. Developing and maintaining the unit cost rate calculator and the Support Hiring Model used for estimating effects on other support organizations.

4. Providing support to business units using the budget formulation, plan development and Three-Year Rolling Forecast modules.

5. Projecting full-time equivalent (FTE) for budget submissions, operating plans, and obligation and employment reporting.

6. Corporate management and oversight of the Treasury Franchise Fund interagency agreement, in coordination with business units’ points of contact.


3. The Financial Planning and Analysis office maintains IRM 1.33.4, Financial Operating Guidelines.


**1.1.21.3.2.3** **(10-22-2024)**

##### Budget Execution Office

1. The Budget Execution office monitors the execution of IRS’s operating plan, provides guidance, develops execution policies and establishes controls on appropriated funds. This includes prior year accounts until they close, and the remaining resources are returned to the general fund.

2. The Budget Execution office is responsible for:



1. Preparing, managing and executing the IRS operating plan in accordance with 31 United States Code (USC) Chapters 13 and 15 - Anti-deficiency Act (codified at 31 USC Section 1341), Economy Act (31 USC Section 1535) and IRM 1.33.4, Financial Operating Guidelines.

2. Monitoring and controlling IRS spending by conducting periodic reviews, including a mid-year review and uncommitted balance reviews.

3. Preparing and publishing the Financial Management Codes Handbook and maintaining IFS master data management.

4. Coordinating year-end close issues with Financial Management and the Office of Procurement and monitoring year-end spending.

5. Providing budgetary oversight, accountability and overall management of the IRS reimbursable program.


3. The Budget Execution office maintains IRM 1.33.3, Reimbursable Operating Guidelines.


**1.1.21.3.2.4** **(10-22-2024)**

##### National Headquarters Budget Office

1. The National Headquarters Budget office manages and monitors National Headquarters and CFO financial plans. This office performs detailed analyses of resource utilization and coordinates with internal and external stakeholders to ensure funds are obligated effectively.

2. The National Headquarters Budget office is responsible for:



1. Coordinating plan development, continuing resolutions, operating plans and year-end close activities for assigned plans using IRM 1.33.4, Financial Operating Guidelines.

2. Monitoring and controlling spending and producing monthly customer resource reports.

3. Managing the reimbursable operations for assigned plans using IRM 1.33.3, Reimbursable Operating Guidelines.


**1.1.21.3.2.5** **(10-22-2024)**

##### Strategic Planning Office

1. The Strategic Planning office develops and leads agency-wide strategic management processes for strategic and annual planning, investment analysis, performance management and governance.

2. The Strategic Planning office is responsible for:



1. Developing and updating the IRS strategic plan, identifying the goals, objectives, opportunities and future direction of the IRS, per Treasury guidance and in accordance with OMB Circular A-11, Part 6, _The Federal Performance Framework for Improving Program and Service Delivery_, and tracking and reporting on its implementation.

2. Performing investment analysis to allocate resources to support critical programs and strategic priorities through the PBAC process.

3. Managing the IRS’s performance measurement and reporting processes, including monitoring and maintaining the IRS budget-level and oversight board performance measures and reporting performance results to both internal and external stakeholders.

4. Managing the IRS governance process that supports and promotes transparency and accountability.


3. The Strategic Planning office maintains:



1. IRM 1.5.1, The IRS Balanced Performance Measurement System

2. IRM 1.37.1, Servicewide Governance Process (future publication)


**1.1.21.3.2.6** **(10-22-2024)**

##### Cost and User Fees Office

1. The Cost and User Fees office maintains, interprets and ensures compliance with policies and procedures for cost accounting, user fees and trust fund administrative costs.

2. The Cost and User Fees office is responsible for:



1. Developing, communicating and updating cost allocation methodologies, overhead rates and other cost standards.

2. Developing and maintaining cost-based performance measures.

3. Managing the biennial user fee review and facilitating new user fees.

4. Reviewing and maintaining trust fund costs.

5. Running and reconciling the monthly cost allocation cycles to the trial balance.


3. The Cost and User Fees office maintains:



1. IRM 1.33.5, Managerial Costing

2. IRM 1.33.7, User Fees

3. IRM 1.33.8, Estimating Trust Fund Costs

4. IRM 1.33.9, Cost Estimating Guidelines (future publication)


4. The Cost and User Fees office has one subordinate section, Cost.


**1.1.21.3.3** **(10-22-2024)**

#### Internal Controls

1. The Internal Controls organization administers the IRS internal control program and coordinates and executes processes that assess the completeness and effectiveness of internal controls and supports annual assurance activities.

2. The Internal Controls organization is responsible for:



1. Testing and reporting on internal controls for IRS programs and processes, including financial transactions and other business activities.

2. Providing assurance to external stakeholders to communicate the effectiveness of internal controls over the achievement of strategic goals, the effectiveness and efficiency of operations, the reliability of reporting compliance with laws and regulations and to address financial management systems compliance.

3. Educating the IRS on the meaning and importance of effective internal controls.


3. The Associate CFO for Internal Controls leads the organization, including its three subordinate offices:



1. Internal Reviews Office

2. Assurance Review and Testing Office

3. Outreach and Reporting Office


**1.1.21.3.3.1** **(10-22-2024)**

##### Internal Reviews Office

1. The Internal Reviews office is responsible for:



1. Evaluating the effectiveness of internal controls through studies and program assessments.

2. Testing and assessing the efficacy of IRS quality assurance programs.

3. Evaluating the effectiveness of operational controls over IRS programs and the implementation of planned corrective actions for past auditor recommendations.


2. The Internal Reviews office maintains:



1. IRM 1.4.31, Quality Assurance Review Program

2. IRM 1.4.32, Internal Control Review Program


3. The Internal Reviews office has three subordinate sections:



1. Quality Assurance Review

2. Internal Control Review - Operations Support

3. Internal Control Review - Services and Enforcement


**1.1.21.3.3.2** **(10-22-2024)**

##### Assurance Review and Testing Office

1. The Assurance Review and Testing office is responsible for:



1. Leading internal control testing mandated by statute and regulation.

2. Monitoring and testing internal controls over IRS’s corporate and revenue processes in accordance with OMB Circular A-123, Appendix A, Management of Reporting and Data Integrity Risk.

3. Ensuring the IRS complies with federal laws and regulations, the effectiveness and efficiency of operations and the reliability of reporting through evaluation of IRS operations and testing of internal controls.

4. Managing the annual assurance review program, including the Internal Controls Managerial Assessment to report on the adequacy and effectiveness of internal controls in the organization.

5. Conducting evaluations to provide reasonable assurance over internal controls and processes that support overall data quality in IRS reports.


2. The Assurance Review and Testing office maintains IRM 1.4.3, Financial Assurance Control Testing.

3. The Assurance Review and Testing office has two subordinate Financial Assurance Control Testing sections, one for administrative transactions and one for custodial transactions.


**1.1.21.3.3.3** **(10-22-2024)**

##### Outreach and Reporting Office

1. The Outreach and Reporting office is responsible for:



1. Developing corporate control reporting deliverables for the financial statement audit and for Treasury Department publications.

2. Managing control oversight processes through the Management Controls Executive Steering Committee.

3. Coordinating analysis and reporting for the IRS improper payments program, consistent with the requirements of OMB Circular A-123, Appendix C, Requirements for Payment Integrity Improvement.

4. Leading education and outreach efforts for control activities.

5. Coordinating the Management’s Discussion and Analysis and TIGTA Management and Performance Challenges Facing the IRS sections of the IRS Agency Financial Report.


2. The Outreach and Reporting office maintains:



1. IRM 1.4.2, Monitoring and Improving Internal Control

2. IRM 1.4.62, Improper Payments (future publication)


3. The Outreach and Reporting office has one subordinate section, Outreach and Education.


**1.1.21.3.3.3.1** **(10-22-2024)**

###### Outreach and Education

1. The Outreach and Education section is responsible for promoting internal control across the IRS through training, articles, Self-Help online tutorials videos and Reader Polls related to internal control topics.


**Exhibit 1.1.21-1**

### Terms, Definitions and Acronyms

(1) In this IRM, the terms below have the following meanings:

- **Apportionment** \- A funds allocation plan, approved by OMB, to spend resources provided by one of the annual appropriations acts, a supplemental appropriations act, a continuing resolution or a permanent law (mandatory appropriations). Resources are apportioned by Treasury Appropriation Fund Symbol, also known as Treasury Account Symbol. The apportionment identifies amounts available for obligation and expenditure. It specifies and limits the obligations that may be incurred and expenditures made (or makes other limitations, as appropriate) for specified time periods, programs, activities, projects, objects or any combination thereof.

- **Appropriation** \- A provision of law (not necessary in an appropriation act) authorizing the obligation and expenditure of funds for a given purpose. Usually, but not always, an appropriation act provides budget authority and funds to operate for the full fiscal year. IRS funding may come in its regular annual appropriation act, an omnibus act, a supplemental appropriation, a continuing resolution or pursuant to a permanent appropriation.

- **Asset** \- Tangible or intangible items owned by the federal government which would have probable economic benefits that can be obtained or controlled by a federal government entity.

- **Budget** \- The budget of the U.S. government that sets forth the government’s comprehensive financial plan and indicates the government’s spending priorities.

- **Budget authority** \- The legal authority to incur financial obligations that will result in outlays. Specific forms of budget authority include appropriations, borrowing authority, contract authority and spending authority from offsetting collections.

- **Commitment**\- An administrative reservation of funds prior to obligation of funds. Typically, commitments are created by a purchase requisition.

- **Disbursement** \- An outlay, including the issuance of cash, a check or an electronic funds transfer.

- **Expenditure** \- The actual spending of money, an outlay.

- **Financial Plan**\- A subdivision of funds in the Integrated Financial System (IFS), which may be further divided into fund centers. Typically, there is a one-to-one relationship of financial plan to business unit, but a few business units manage multiple financial plans.

- **Financial statements** \- The components of the IRS’s annual financial statement, including the balance sheet, statement of net cost, statement of changes in net position, statement of budgetary resources and statement of custodial activity. In addition to the financial statements, federal agencies prepare note disclosures, required supplementary information and other accompanying information.

- **Fiscal year** \- The federal government's accounting period, which begins on October 1 and ends on September 30, and is designated by the calendar year in which it ends.

- **Full-time equivalent (FTE)** \- The basic measure of employment levels reported in the budget. It is the total number of regular straight-time hours (that is, not including overtime or holiday hours) worked by employees divided by the fiscal year’s compensable hours. Annual leave, sick leave, compensatory time off and other approved leave categories are considered hours worked for purposes of defining FTE employment.

- **Fund** \- A source of financing for federal agencies. Types of funds include revolving funds, custodial funds and direct or reimbursable appropriations. In IFS, the fund field indicates the appropriation.

- **Integrated Financial System (IFS)** \- The IRS’s administrative accounting system.

- **Obligation** \- A definite commitment that creates a legal liability of the government for the payment of goods and services ordered or received, or a legal duty on the part of the United States that could mature into a legal liability by virtue of actions on the part of the other party beyond the control of the United States. Budgetary resources must be available before obligations can legally be incurred.

- **Outlay** \- A payment to liquidate an obligation (other than the repayment of debt principal).

- **Receipt and Acceptance** \- Receipt acknowledges that goods were received and/or services were rendered. Acceptance acknowledges that an authorized IRS official determined that the goods received and/or services rendered conform to the contract requirements.

- **Redesigned Revenue Accounting Control System (RRACS)** \- The IRS automated system used to provide accounting control for all revenue accounting transactions.

- **Three-Year Rolling Forecast (3YRF)** \- An IFS tool for the business units to monitor their financial plans during the fiscal year. It projects full-time employees, permanent and temporary basic salaries, non-basic labor costs, benefits and non-labor requirements. Projections are for the current year, the plan year and the budget year. Budget projections are used to align the financial plan with program objectives, provide advice to management, maintain financial controls and determine reprogramming capabilities and needs.

- **User fees** \- Charges levied by a federal agency on individuals or entities directly benefiting from a service provided by a government program or activity. User fees are charged for federal activities that provide recipients with benefits greater than those provided to the general public.


(2) The following chart contains acronyms that are used throughout this IRM:

| **Acronyms** | **Description** |
| --- | --- |
| CDDB | Custodial Detail Database |
| FASAB | Federal Accounting Standards Advisory Board |
| FISMA | Federal Information Security Management Act |
| FMIS | Financial Management Information Systems |
| FTE | Full-Time Equivalent |
| GAO | Government Accountability Office |
| IFS | Integrated Financial System |
| IRC | Internal Revenue Code |
| OMB | Office of Management and Budget |
| PBAC | Program and Budget Advisory Committee |
| RACS | Revenue Accounting Control System |
| RRACS | Redesigned Revenue Accounting Control System |
| USC | United States Code |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-001-021#addtoany "Show all")

A2A