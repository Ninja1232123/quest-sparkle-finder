---
url: "https://www.irs.gov/irm/part1/irm_01-011-010"
title: "1.11.10 Interim Guidance Process | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-011-010#main-content)

- 1.11.10  [Interim Guidance Process](https://www.irs.gov/irm/part1/irm_01-011-010#id1)
  - 1.11.10.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-011-010#id2)
    - 1.11.10.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-011-010#id4)
    - 1.11.10.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-011-010#id5)
    - 1.11.10.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-011-010#id6)
    - 1.11.10.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-011-010#id7)
    - 1.11.10.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-011-010#id8)
    - 1.11.10.1.6  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-011-010#id9)
    - 1.11.10.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-011-010#id10)
  - 1.11.10.2  [Interim Guidance (IG) Overview and Process](https://www.irs.gov/irm/part1/irm_01-011-010#id11)
  - 1.11.10.3  [Interim Guidance Format](https://www.irs.gov/irm/part1/irm_01-011-010#id12)
    - 1.11.10.3.1  [Interim Guidance Memorandums (IGM)](https://www.irs.gov/irm/part1/irm_01-011-010#id14)
    - 1.11.10.3.2  [SERP IRM Procedural Updates (IPUs)](https://www.irs.gov/irm/part1/irm_01-011-010#id15)
  - 1.11.10.4  [Author Interim Guidance](https://www.irs.gov/irm/part1/irm_01-011-010#id16)
  - 1.11.10.5  [Evaluate Interim Guidance](https://www.irs.gov/irm/part1/irm_01-011-010#id17)
    - 1.11.10.5.1  [Evaluate Interim Guidance for Electronic Freedom of Information Act (E-FOIA) Criteria](https://www.irs.gov/irm/part1/irm_01-011-010#id19)
    - 1.11.10.5.2  [Evaluate Interim Guidance for Potential Changes to Conditions of Employment of Bargaining Unit Employees](https://www.irs.gov/irm/part1/irm_01-011-010#id20)
  - 1.11.10.6  [Clear and Obtain Approval for Interim Guidance](https://www.irs.gov/irm/part1/irm_01-011-010#id21)
    - 1.11.10.6.1  [Non-emergency Clearance and Approval Process for Interim Guidance](https://www.irs.gov/irm/part1/irm_01-011-010#id22)
    - 1.11.10.6.2  [Emergency Clearance and Approval Process for Interim Guidance](https://www.irs.gov/irm/part1/irm_01-011-010#id23)
    - 1.11.10.6.3  [Responding to Reviewers’ Comments](https://www.irs.gov/irm/part1/irm_01-011-010#id24)
      - 1.11.10.6.3.1  [Responding to Reviewers’ Comments (Non - Emergency Guidance)](https://www.irs.gov/irm/part1/irm_01-011-010#id26)
      - 1.11.10.6.3.2  [Responding to Reviewers’ Comments (Emergency Guidance)](https://www.irs.gov/irm/part1/irm_01-011-010#id27)
    - 1.11.10.6.4  [Resolving Disagreements](https://www.irs.gov/irm/part1/irm_01-011-010#id28)
    - 1.11.10.6.5  [Interim Guidance Approving Official](https://www.irs.gov/irm/part1/irm_01-011-010#id29)
  - 1.11.10.7  [Distribute Interim Guidance](https://www.irs.gov/irm/part1/irm_01-011-010#id30)
    - 1.11.10.7.1  [Accessibility Standards for Interim Guidance Documents](https://www.irs.gov/irm/part1/irm_01-011-010#id31)
      - 1.11.10.7.1.1  [Resolving Accessibility Errors](https://www.irs.gov/irm/part1/irm_01-011-010#id33)
  - 1.11.10.8  [Monitor Interim Guidance for Expiration](https://www.irs.gov/irm/part1/irm_01-011-010#id34)
  - 1.11.10.9  [Incorporate into the IRM, Reissue, or Obsolesce Interim Guidance](https://www.irs.gov/irm/part1/irm_01-011-010#id35)
    - 1.11.10.9.1  [Incorporate Interim Guidance into the IRM](https://www.irs.gov/irm/part1/irm_01-011-010#id37)
    - 1.11.10.9.2  [Reissue Interim Guidance](https://www.irs.gov/irm/part1/irm_01-011-010#id38)
    - 1.11.10.9.3  [Obsolesce Interim Guidance Memorandums](https://www.irs.gov/irm/part1/irm_01-011-010#id39)
  - 1.11.10.10  [Archive Interim Guidance](https://www.irs.gov/irm/part1/irm_01-011-010#id40)
  - Exhibit  1.11.10-1  [IMD Tracking System Data Fields for Adding or Archiving Interim Guidance](https://www.irs.gov/irm/part1/irm_01-011-010#id41)

# Part 1. Organization, Finance, and Management

# Chapter 11. Internal Management Documents System

# Section 10. Interim Guidance Process

* * *

## 1.11.10 Interim Guidance Process

#### Manual Transmittal

July 28, 2025

#### Purpose

(1) This transmits revised IRM 1.11.10, Internal Management Documents System, Interim Guidance Process.

#### Material Changes

(1) _IRM 1.11.10.1.2_, Authority, updated to include Section 508 of the Rehabilitation Act.

(2) _IRM 1.11.10.1.6_, Terms and Acronyms:

- Removed IMD Tracking System, IRM Online, Search Interim Guidance and Servicewide Electronic Research Program and moved to _IRM 1.11.10.1.7_, Related Resources.

- Updated definition for Freedom of Information Act (FOIA) and combined with Electronic Freedom of Information Act (E-FOIA).


(3) _IRM 1.11.10.1.7_, Related Resources, updated to include the Electronic Clearance and Electronic Clearance training website.

(4) _IRM 1.11.10.2_, Interim Guidance (IG) Overview and Process, updated to reflect current IRM reference subsection numbers.

(5) _IRM 1.11.10.3.1_, Interim Guidance Memorandums (IGM), updated to include guidance on adding contact information for IGMs that meet E-FOIA criteria.

(6) _IRM 1.11.10.6_, Clear and Obtain Approval for Interim Guidance:

- Removed reference to IRM 1.11.9.3.1, Requesting Employee Feedback, as IRM 1.11.9 has been updated to specify the clearance process for the IRM, not all IMDs.

- Added the Electronic Clearance website as an optional method to clear IGMs.


(7) _IRM 1.11.10.6.1_, Non-emergency Clearance and Approval Process for Interim Guidance:

- Step 2 - added reference to new subsection _IRM 1.11.10.6.3_, Responding to Reviewers’ Comments.

- Step 3 - removed reference to _IRM 1.11.10.6.4_, Resolving Disagreements and added reference to _IRM 1.11.10.6.4_


(8) _IRM 1.11.10.6.2_, Emergency Clearance and Approval Process for Interim Guidance:

- Paragraph (1) - added information to clarify that emergency guidance must still be cleared after issuance.

- Paragraph (2) Step 5 - added guidance to elevate non-concurrence during IG clearance to the applicable program director.

- Paragraph (2) Step 5 - added reference to new subsection _IRM 1.11.10.6.3_, Responding to Reviewers’ Comments.

- Paragraph (2) Step 5 - added guidance to address comments received within 15 calendar days.

- Reorganized content for clarity.


(9) _IRM 1.11.10.6.3_, Responding to Reviewers’ Comments, added new subsection to clarify timeframes for responding to reviewers’ comments.

(10) _IRM 1.11.10.6.3.1_, Responding to Reviewers’ Comments (Non-Emergency Guidance), added new subsection to provide guidance for responding to reviewers’ comments for non-emergency IG.

(11) _IRM 1.11.10.6.3.2_, Responding to Reviewers’ Comments (Emergency Guidance), added new subsection to provide guidance for responding to reviewers’ comments for emergency IG.

(12) _IRM 1.11.10.6.4_, Resolving Disagreements, added new subsection to provide guidance on resolving disagreements during the IG clearance process.

(13) _IRM 1.11.10.7_, Distribute Interim Guidance:

- Paragraph (3) - clarified that IG documents must receive a passing indicator through Adobe Acrobat to be 508 compliant.

- Paragraph (3) - Add reference to IRM 11.3.12.3.2, Procedural Guidance, s this IRM section contains guidance pertaining to designating procedural guidance where all of the content is protected from disclosure.

- Paragraph (4) Step 4 - added requirement for IG documents to meet the requirements in IRM 1.11.10.7, Accessibility Standards for Interim Guidance Documents.

- Paragraph (4) Step 4 - added requirement for internal web links to be deactivated from IG documents meeting E-FOIA criteria.


(14) _IRM 1.11.10.7.1_, Accessibility Standards for Interim Guidance Documents, added new subsection to provide guidance on how to prepare E-FOIA documents for input into the tracking system.

(15) _IRM 1.11.10.7.1.1_, Resolving Accessibility Errors, added new subsection to provide resources to assist with making IG documents 508 compliant.

(16) _IRM 1.11.10.9.1_, Incorporate Interim Guidance into the IRM:

- Paragraph (1) - Added note to refer to IRM 1.11.9.2.1.2, Incorporating Interim Guidance into the IRM if updating the IRM to only incorporate interim guidance.

- Paragraph (4) - clarified requirement to include a zip file with all interim guidance clearance documents in e-Clearance.


,

(17) _IRM 1.11.10.9.2_, Reissue Interim Guidance, provided updated information for reissuing interim guidance:

- Paragraph (8) - added requirement that the Request to Reissue Interim Guidance form must be signed by the applicable program director prior to sending to SPDER.

- Paragraph (10) - added requirement for reissued interim guidance memorandums to include updated program director signature.


(18) _Exhibit 1.11.10-1_, IMD Tracking System Data Fields for Adding or Archiving Interim Guidance:

- Updated to reflect the IMD Tracking system pre-populates the IG expiration date two years from the date of issuance.

- Updated to reflect the OUO question in IMD Tracking systems has been updated to include internal web links.

- Added accessibility standards for IG meeting E-FOIA criteria.


(19) Editorial changes made throughout this IRM section include:

- Changed Wage and Investment (W&I) to Taxpayer Services (TS).

- Corrections to hyperlinks, website addresses, IRM references and typographical errors.

- Updated examples used in IGM element table.

- Updates to terms and titles.


#### Effect on Other Documents

This IRM supersedes IRM 1.11.10, Interim Guidance Process, dated February 7, 2024.

#### Audience

All IRS personnel responsible for issuing interim guidance (IG) - program directors, managers, Internal Management Document (IMD)/IRM coordinators, IG coordinators, authors and reviewers.

#### Effective Date

(07-28-2025)

Holly A. Donnelly

Director, Strategy and Business Solutions

Research, Applied Analytics and Statistics (RAAS)

**1.11.10.1** **(02-07-2024)**

### Program Scope and Objectives

1. **Purpose:** This IRM section provides requirements, information and instructions for preparing and issuing interim guidance (IG). This IRM also addresses disclosure requirements under the Freedom of Information Act (FOIA) relating to administrative staff manuals and instructions to staff issued through IG.

2. **Audience:** The procedures in this IRM section are primarily for:



   - IRM authors

   - Analysts who author IG

   - Program managers, directors, and executives responsible for approving and distributing IG

   - Internal management document (IMD) and IRM coordinators

   - IG coordinators


3. **Policy Owner:** Director, Strategy and Business Solutions (SBS), Research, Applied Analytics and Statistics (RAAS).

4. **Program Owner:** The Office of Servicewide Policy, Directives and Electronic Resources (SPDER) within SBS, RAAS.

5. **Primary Stakeholders:** All business units and functional offices who issue, create, or maintain IRS operating procedures, guidance, or instructions to staff, Privacy, Governmental Liaison and Disclosure (PGLD); Disclosure; and the Servicewide Electronic Research Program (SERP) Communication (SCP) program office, under Taxpayer Services (TS), Customer Account Services (CAS).

6. **Contact Information:** To request information, recommend changes, or make any other suggestions to this IRM section, contact SPDER@irs.gov.


**1.11.10.1.1** **(02-07-2024)**

#### Background

1. The IRM is the official source of IRS policies, authorities, operations and procedures for IRS managers and employees. The IG process allows for quick communication of new or revised instructions to staff before business units can update the affected IRM section(s). The IG process is also used to convey temporary or pilot procedures.


**1.11.10.1.2** **(07-28-2025)**

#### Authority

1. [5 USC 552 (a)(2)(C)](https://www.bloomberglaw.com/ms/product/tax/document/XEGOVE003) [44 USC 3101](https://uscode.house.gov/view.xhtml?req=(title:44%20section:3101%20edition:prelim)), _Records management by agency heads; general duties_, requires federal agencies to make and preserve records documenting organization, functions, policies, decisions, procedures and essential transactions of the agency.

2. The Freedom of Information Act (FOIA), [5 USC 552 (a)(2)(C)](https://www.justice.gov/oip/freedom-information-act-5-usc-552), provides public access to agency administrative staff manuals and instructions to staff affecting a member of the public unless protected from disclosure by an exemption under 5 USC 552(b).

3. 26 CFR § 601.702, _Publication, public inspection, and specific requests for records_, outlines the procedures for publishing information, allowing public inspection of records and handling specific requests for records

4. [Section 508 of the Rehabilitation Act (29 USC 794d)](https://www.section508.gov/manage/laws-and-policies/section-508-law/), requires agencies to make their electronic and information technology accessible to people with disabilities.

5. Delegation Order 11-1, _Administrative Control of Documents and Material_, grants authority to approve IMDs with new, changed, or de-designated official use only content. This authority is delegated to various chiefs, directors and other executives who report to a deputy division commissioner or equivalent chief/director.

6. Delegation Order 1-69 (New), _Authorization to Approve an Internal Management Document_ (IMD), specifies the levels of approvers of IMDs.


**1.11.10.1.3** **(02-07-2024)**

#### Roles and Responsibilities

01. The Director, Strategic Business Solutions (SBS), RAAS, is the program director responsible for IMD program administration. The Director, SBS, designates oversight responsibility for the IMD program to the Director, SPDER.

02. The Director, SPDER oversees the IMD program, to include the IG process.

03. The SPDER program office sets the Servicewide IMD policy, manages and executes the IG program, and provides IMD/IG training and guidance to business units and program offices. SPDER maintains the IMD Tracking System and Search Interim Guidance webpage and coordinates the posting and removal of IG documents meeting electronic FOIA (E-FOIA) to and from the FOIA Library on IRS.gov.

04. Business units establish internal processes for managing their IMD procedures based upon the Servicewide policies and procedures.

05. Program directors and executives oversee IMD administration, including the IG process, under their program responsibility.

06. Program owners manage and execute the IMD program, including the IG process and records retention, within their program area.

07. IG coordinators manage the IG program for their business unit and assist authors and managers in authoring, formatting, issuing, distributing and monitoring IG. A list of business unit IG Coordinators is posted on SPDER’s Internal Management Document Community site.

08. Authors who prepare and write IG follow the rules and processes within this IRM section.

09. PGLD, Disclosure staff provide program guidance on FOIA oversight and disclosure of sensitive content.

10. The SERP program office administers the IRM Procedural Update (IPU) process, which aligns with the procedures in this IRM section.


**1.11.10.1.4** **(02-07-2024)**

#### Program Management and Review

1. SPDER manages the IG program through the following reports and reviews:



   - The Servicewide IMD Program Assessment - An annual report issued that details the IMD program accomplishments and activities. This report also includes a summary of annual certification results and recommended actions. More information can be found on the SPDER Community of Practice webpage.

   - The IMD Tracking System - A database that allows creation of reports to assist in managing the IG program.

   - The Search Interim Guidance - A webpage that houses active IGMs and IPUs, and archived IGMs, allowing business units to monitor and review their IG.


2. SPDER staff periodically reviews IG expiration dates in the IMD Tracking System and notifies the business units of imminent expiration dates.

3. SPDER maintains the IRS Historical Research Library that houses IRM clearance packages, which includes documentation on incorporated IG.

4. SPDER conducts a biennial E-FOIA compliance review to ensure business units comply with FOIA law.


**1.11.10.1.5** **(02-07-2024)**

#### Program Controls

1. Delegation Order 1-69 (New), Authorization to Approve an Internal Management Document (IMD), specifies who can approve the issuance of IG.

2. SPDER requires business units to submit and house their IG on the centralized Search Interim Guidance webpage using the IMD Tracking System.

3. The SPDER office restricts access to the IMD Tracking System to business unit IG coordinators for posting and removing IGMs and IPUs.

4. SPDER staff reviews IG meeting E-FOIA criteria submitted in the IMD Tracking System for compliance with IRM 1.11.10 and Section 508 before initiating upload to the E-FOIA Library on IRS.gov.


**1.11.10.1.6** **(07-28-2025)**

#### Terms and Acronyms

1. The following table lists the definitions and acronyms used throughout this IRM section.




| Term | Definition |
| :-: | :-: |
| Affected Offices | Program offices whose work processes, procedures, official forms, or IMDs require revision due to proposed changes to procedures. |
| Authorized Delegate | A senior manager delegated responsibility for IMD program administration by a member of the Senior Executive Service with program oversight per Delegation Order 1-69 (New), Authorization to Approve an Internal Management Document (IMD). |
| Emergency Interim Guidance | Critical guidance requiring immediate issuance to employees where a delay would result in work stoppage, incorrect processing of account data, or severely impact taxpayer actions. Examples include disaster guidance, critical changes to IRS procedures, or newly enacted legislation. |
| Freedom of Information Act (FOIA) | A federal law requiring each agency to maintain and provide public access to instructions to staff and administrative staff manuals that affect the public, an amendment to the law, **Electronic Freedom of Information Act (E-FOIA)**, requires that these records be made available in an electronic format. |
| Interim Guidance (IG) | Official communication conveyed through memorandums or IRM procedural updates (IPUs) used by business units or program offices to immediately issue emergency, pilot, deviation, or temporary changes to operations or IRM procedures for a defined effective period not to exceed two years. |
| Interim Guidance Memorandum (IGM) | A type of IG conveyed via memorandum to immediately issue emergency, pilot, deviation, or temporary changes to operations or IRM procedures. The procedural change is effective until the expiration date, not to exceed two years. |
| Internal Management Document (IMD) | An official communication that designates policies and authorities, and delivers instructions to IRS officials and employees. |
| IRM Procedural Update (IPU) | A type of IG used to immediately issue an interim procedural change to an IRM hosted on SERP. The procedural change is effective for up to two years. |
| Non-emergency Interim Guidance | Guidance that informs employees of an important procedural change but does not require immediate issuance. |
| Official Use Only (OUO) | Sensitive information requiring protection from the public because it meets a FOIA exemption and there is a reasonable expectation that disclosure would harm tax administration or IRS operations, or when disclosure is specifically prohibited by law. |
| Personally Identifiable Information (PII) | Information that can be used to distinguish or trace an individual’s identity, either alone or when combined with other information that is linked or linkable to a specific individual. See IRM 10.5.1.2.3, Personally Identifiable Information (PII). |
| Program Director | Member of the Senior Executive Service or their authorized delegate responsible for program administration including issuance and approval of IMDs. |
| Program Owner | The program office that typically reports to the policy owner and is responsible for the administration, procedures, and updates related to the program IRM, including IG. |
| Specialized Reviewers | Identified program offices with oversight in a particular area affecting Servicewide IRS operations. See IRM 1.11.9.4, Specialized Reviewers. |
| Temporary Guidance | Non-permanent guidance for a limited time, up to two years. Temporary guidance may or may not be associated with procedures in the IRM. Examples of temporary guidance include pending tax legislation that is subject to change or a pilot program. |


**1.11.10.1.7** **(07-28-2025)**

#### Related Resources

1. The following table lists resources that can be used during the IG authoring and clearance process:




| Resource | Description |
| --- | --- |
| Alternative Media Center | Contacts to help deliver alternative accessible media to employees. |
| E-FOIA Decision Tool | Web-based tool used to determine whether your program office’s interim guidance meets E-FOIA criteria and requires posting to the FOIA Library. |
| IMD Electronic Clearance | Online system used to automate and centralize the review, comment, approval and archival of IRMs and IGMs. |
| IMD Electronic Clearance Training | Website that provides IGM electronic clearance training materials for authors, reviewers, managers, approvers, and coordinators. |
| Integrated Talent Management (ITM) Course 28327, Introduction to the Interim Guidance Process | Course that introduces authors, reviewers and approvers of instructions to staff to the interim guidance (IG) process. |
| Internal Management Documents (IMD) Contacts List | List of business unit IG Coordinators. |
| Internal Management Document (IMD) Tracking System | A restricted database used by business unit IG coordinators to post and remove IGMs and IPUs to and from the Search Interim Guidance page and the FOIA Library on IRS.gov. |
| IRM Online | Electronic version of all the published and effective IRM sections with links to active IG. |
| Recent Interim Guidance to Staff | Page on the IRS.gov’s FOIA Library where IG that meets E-FOIA criteria is posted. |
| Search Interim Guidance | A webpage that contains active IGMs, IPUs, Servicewide delegation orders and policy statements. |
| Servicewide Electronic Research Program (SERP) | An electronic research source maintained by TS designed to provide access to IRMs, updated with IRM procedural updates (IPUs) and reference materials.<br> <br>### Note:<br>Not all IRMs are on SERP. SERP hosts IRMs by request, based on end-user need. |
| SPDER IMD Community of Practice | Website that contains resources related to interim guidance format, authoring and clearance. |


**1.11.10.2** **(07-28-2025)**

### Interim Guidance (IG) Overview and Process

1. Business units use interim guidance (IG) to quickly issue new or revised instructions or operational changes to employees when there is insufficient time to update, clear, and publish the IRM section(s) containing the subject matter content. IG is also used to issue pilot, temporary, and deviation guidance.

2. IG remains effective until the expiration date, not to exceed two years. If there is no stated expiration date, then the guidance is in effect for two years from the date of issuance.

3. Business units must incorporate permanent IG into the next revision of the published IRM section(s) through Media and Publications (M&P) within two years from the issuance date, or sooner if required by the business unit.

4. Business units must post all interim guidance memorandums (IGMs) and only IRM Procedural Updates (IPUs) that meet Electronic Freedom of Information Act (E-FOIA) criteria to the IMD Tracking System. The SPDER office restricts access to the IMD Tracking System to business unit IG coordinators for posting and removing IGMs and IPUs. Email \*SPDER to request access.

5. The following table summarizes the steps involved in the IG process and provides applicable IRM references:




| Step | Action | IRM Reference |
| :-: | :-: | :-: |
| 1. | Author | _IRM 1.11.10.4_, Author Interim Guidance |
| 2. | Evaluate | _IRM 1.11.10.5_, Evaluate Interim Guidance |
| 3. | Clear | _IRM 1.11.10.6_, Clear and Obtain Approval for Interim Guidance |
| 4. | Approve | _IRM 1.11.10.6_, Clear and Obtain Approval for Interim Guidance |
| 5. | Distribute | _IRM 1.11.10.7_, Distribute Interim Guidance |
| 6. | Monitor | _IRM 1.11.10.8_, Monitor Interim Guidance for Expiration |
| 7. | Incorporate IG into the IRM, Reissue, or Obsolesce | _IRM 1.11.10.9_, Incorporate into the IRM, Reissue, or Obsolesce Interim Guidance |
| 8. | Archive | _IRM 1.11.10.10_, Archive Interim Guidance |


**1.11.10.3** **(05-01-2022)**

### Interim Guidance Format

1. Business units may issue IG in one of two formats:



   - Interim guidance memorandum (IGM). See _IRM 1.11.10.3.1_, Interim Guidance Memorandums (IGM).

   - SERP IRM procedural update (IPU). See _IRM 1.11.10.3.2_, SERP IRM Procedural Updates (IPUs).


**1.11.10.3.1** **(07-28-2025)**

#### Interim Guidance Memorandums (IGM)

1. Program owners must use the IGM format when:



   - The guidance impacts an IRM section not hosted on SERP

   - The guidance impacts several IRM sections across business units or program offices, and all of the IRM sections are not hosted on SERP

   - The guidance is temporary or provides deviation procedures described in IRM 1.11.2.2.3, When Procedures Deviate from the IRM

   - The guidance consists of pilot procedures


2. IGMs are typically issued from and through management to affected employees. If the office issuing the guidance also oversees the affected employees, the memo can be sent directly to those employees.

3. All IGMs must contain a unique control number. This must be obtained from the business unit’s IG coordinator.

4. All IGMs must be authored using the business unit’s official letterhead stationery.

5. Include the following elements in an IGM:




| Element | Action/Definition | Example |
| :-: | :-: | :-: |
| Date of Issuance | Enter the date the IGM is issued to employees. | January 25, 2025 |
| Control Number | Enter the sequential tracking number: BU-PN-MMYY-####<br> BU - Business unit symbols<br> PN - IRM part number<br> MM - Month the IG is issued<br> YY - Year the IG is issued<br> #### \- Sequential tracking number<br> <br>### Note:<br>The sequential tracking number always restarts with "0001" at the beginning of each calendar year<br> . | TS-01-0125-0004<br> (TS issued an IGM for IRM Part 1 in January of 2025. It’s the fourth IGM issued by TS for the calendar year.) |
| Expiration Date | Enter the date the IGM expires, not to exceed two years. | January 25, 2027 |
| Affected IRM Number(s) | Enter the primary IRM section number that relates to the IGM first; list all other affected IRMs in numerical order.<br> <br>### Note:<br>If the guidance is temporary or based on new legislation, policy, or procedure where there is no related IRM section, include "proposed" before the IRM section number in the body of the IGM. | IRM 1.22.5<br> or<br> Proposed New IRM X.XX.X |
| MEMORANDUM FOR line | List the chief, director, or head(s) of office responsible for the employees affected by the guidance. If the office issuing the guidance oversees the affected employees receiving the guidance, address the memorandum to those employees. | ALL CHIEFS AND COMMISSIONERS OF IRS OPERATING DIVISIONS AND FUNCTIONS<br> or<br> ALL M&P DISTRIBUTION EMPLOYEES |
| FROM line | List the chief, director, or head(s) of office of the originating office(s) by name and title.<br> <br>### Note:<br>Some IGMs require more than one signatory. See _IRM 1.11.10.3.1_(6) below for examples. | John A. Doe, Director, Distribution, Media and Publications (M&P) |
| Subject | Enter a concise statement of the subject matter. | Additional Actions Needed to Further Reduce Undeliverable Mail |
| Content | Write content using the IRM format and numbering convention, specifying each affected IRM subsection, title, paragraph, and list. Content elements may include purpose, background, source(s) of authority, and procedural change(s). | See: IG Memorandum Template |
| Effect on Other Documents | Enter a sentence stating when permanent guidance will be incorporated into the IRM, identifying the IRM by number and title. Always include a date not to exceed two years from the date of the memo.<br> If guidance is temporary, pilot or deviation instructions, list the affected IRM sections by number and title. | M&P will incorporate this guidance into IRM 1.22.5, _Mail and Transportation Management, Mail Operations_, by January 25, 2027.<br> or<br> This guidance temporarily affects/deviates from IRM section(s) X.XX.XX, until January 25, 2027.<br> or<br> These pilot instructions relate to IRM section(s) X.XX.XX. |
| Effective Date | Insert the date the IG becomes effective. | January 25, 2025 |
| Contact | Include contact information of the originator. | Direct any questions to XXXXX XXXXX, Supply Management Specialist, at phone number XXX-XXX-XXXX<br> <br>### Note:<br>If the guidance meets E-FOIA criteria, use program office contact information instead of employee contact information.<br> See IRM 1.11.2.5.5, Contact Information, for more information |
| IRS.gov Distribution Notation (If IGM meets E-FOIA criteria) | Include a "cc" or "Distribution" notation to indicate posting on the [FOIA Library](https://www.irs.gov/privacy-disclosure/foia-library) on IRS.gov. | cc: FOIA Library on IRS.gov<br> or<br> Distribution: FOIA Library on IRS.gov |





### Note:



An IGM Template is available on the SPDER website. For additional information on memorandum structure and requirements, see IRM 1.10.1.20, _Guidelines for Preparing Memorandums._

6. Procedural guidance is issued to employees from management in their chain-of-command, or from one senior executive to other senior executives for dissemination to affected employees. Originating policy offices may not provide direct instruction to employees in external business units without the agreement and approval of the appropriate chief, director or head of office from the applicable business unit. If the guidance affects employees outside of the originating office’s chain of command, guidance must also be issued from management (chief, director, or head of office) of the affected employees. Add a FROM line for the chief, director, or head of office providing the guidance and add a second FROM line for the equivalent signatory for the other business unit the guidance applies to.



### Example:



Operations Support within the Independent Office of Appeals drafts an IGM that provides new instruction to its employees and those in Accounts Management (AM) within Taxpayer Services (TS). The changes affect IRMs owned by both areas. The IGM must list the applicable signatory from both applicable offices:




MEMORANDUM FOR OPERATIONS SUPPORT EMPLOYEES, APPEALS AND ACCOUNTS MANAGEMENT EMPLOYEES, TS


FROM: Jennifer Pike, Director, Operations Support, Appeals


FROM: Thomas Cypress, Director, Accounts Management, TS

7. In rare situations where the originating office does not own the guidance being issued, the policy owner must also approve the guidance and sign the memorandum. Add a “THRU” line in the memorandum that includes the name and title of the policy owner (chief, director, or head of office). The chief, director, or head of office who is issuing the memorandum on the “FROM” line must be equivalent to the policy owner of the guidance.



### Example:



Field Examination within Small Business Self Employed (SB/SE) drafts an IGM for their employees to temporarily deviate from procedures located in IRM 1.11.9, Clearing and Approving Internal Management Documents (IMDs), owned by SBS within RAAS. The IGM must list the applicable signatory from both applicable offices:




MEMORANDUM FOR FIELD EXAMINATION EMPLOYEES, SB/SE


THRU: David Garter, Director, Strategy and Business Solutions, RAAS


FROM: Barbara Haddock, Director, Field Examination, SB/SE

8. Attachment instructions - When formatting an IGM attachment, use the IRM structure and format. Use redlining to clearly identify the changes from the existing content including subsection title and subsection date.


**1.11.10.3.2** **(02-07-2024)**

#### SERP IRM Procedural Updates (IPUs)

1. Program owners must use the IPU format to issue interim changes for IRMs that are hosted on SERP. See IRM 1.11.8, _Servicewide Electronic Research Program (SERP)_, for more information on SERP.

2. Authors use Arbortext Editor to revise the existing IRM XML file. See IRM 1.11.8.7.1, Updating IRMs Through an IRM Procedural Update (IPU), for guidance on updating the XML IRM file and submitting an IPU.

3. The SERP platform assigns the record a posting number when an IPU is submitted using the Servicewide Electronic Research Program (SERP) Submission Form. See IRM 1.11.8.7.1.1, Issuing an IPU (Interim Guidance).

4. An IPU revises the existing IRM content posted to SERP. The SERP IRM shows new and revised changes highlighted in yellow.



### Note:



An IPU does not update other IRM formats, including IRM Online and the published version available to the public.


**1.11.10.4** **(02-07-2024)**

### Author Interim Guidance

01. The originator of the IG works with the program owner, management, and the IG coordinator to adhere to Servicewide and internal program office processes when authoring the IG.

02. Coordinate the IG content with IRM authors, program offices, and business units who own impacted IRS products, e.g., IRMs, forms, notices and training materials.

03. Ensure content is correct and does not contradict existing instructions, laws, or processes.

04. Specify the procedural change(s) and the employees taking the action.

05. Indicate the reason for the procedural change(s) in the IGM or in the material changes section of the IPU.

06. Write the new or revised procedures using IRM style rules and plain language standards. Plain language is clear, concise, and well-organized writing, appropriate to the subject and intended audience. See Document 12835, _The IRM Style Guide_, for IRM style rules and plain language guidelines.

07. Ensure all of the IG content is free of federal tax information (FTI) or other personally identifiable information (PII). Correctly fictionalize following IRM 1.11.2.5.6, Fictitious Identifying Information.

08. Properly identify and mark sensitive information as official use only (OUO) following IRM 1.11.2.5.3, Designate IRM Content as Official Use Only (OUO).

09. Follow the IRM format and numbering rules described in IRM 1.11.2.3, IRM Format, Structure and Identifying Information. Write the IG content in the IRM format and numbering convention based on the current published IRM section.

10. Follow Section 508 compliance accessibility standards. For guidance on 508 compliance, see:



    - The Section 508 Compliance and Accessibility webpage.

    - The Alternative Media Center.


**1.11.10.5** **(02-07-2024)**

### Evaluate Interim Guidance

1. Prior to clearance, and to ensure proper formatting, clearing and distribution, business units must evaluate IG for E-FOIA criteria and potential changes to conditions of employment of bargaining unit employees.

2. Refer to _IRM 1.11.10.5.1_, Evaluate Interim Guidance for Electronic Freedom of Information Act (E-FOIA) Criteria, for detailed instructions on evaluating IG for E-FOIA criteria.

3. Refer to _IRM 1.11.10.5.2_, Evaluate Interim Guidance for Potential Changes to Conditions of Employment of Bargaining Unit Employees, for detailed instructions on evaluating IG for potential impact to conditions of employment of bargaining unit employees.


**1.11.10.5.1** **(02-07-2024)**

#### Evaluate Interim Guidance for Electronic Freedom of Information Act (E-FOIA) Criteria

1. The [Freedom of Information Act (FOIA), 5 USC 552 (a)(2)(C)](https://www.justice.gov/oip/freedom-information-act-5-usc-552), provides public access to agency administrative manuals and instructions to staff that affect a member of the public, unless protected from disclosure by an exemption under 5 USC 552(b). The FOIA was amended in 1996 to require federal agencies to make these records available to the public in an electronic format, which is referred to as E-FOIA. The IRS complies with this E-FOIA provision by posting content to the [FOIA Library](https://www.irs.gov/privacy-disclosure/foia-library) on IRS.gov.

2. Program owners issuing IGMs or IPUs must follow the FOIA, 5 USC 552 (a)(2)(C) and evaluate the IG for posting to the FOIA Library.

3. Authors must evaluate the IG content to determine if the guidance meets all the FOIA criteria below. If so, the IG requires posting to the FOIA Library.



1. The guidance is procedural and communicates direction, guidelines or standards to employees in the performance of their assigned duties.

2. The guidance affects how a member of the public files, pays and complies with their tax requirements, or interacts with the IRS.

3. The guidance is not exempt from disclosure under 5 USC 552(b). See IRM 1.11.1.3.1.3, Disclosure Exemptions for Instructions to Staff.


4. If the guidance is a restatement of content already posted **in full** on the [FOIA Library](https://www.irs.gov/privacy-disclosure/foia-library), then it is not necessary to post the IG on the FOIA Library. This situation is uncommon, as IG usually provides new instruction to employees.



### Example:



If the procedural change is the exact same language contained in an Internal Revenue Bulletin (IRB) posted on the FOIA Library, then the IG does not require posting since it is already electronically available to the public.

5. Authors can use the E-FOIA Decision Tool for assistance in determining whether guidance meets E-FOIA criteria and requires posting to the FOIA Library. If you are unsure how to answer these questions for your guidance, contact your business unit's interim guidance coordinator or FOIA Advisor.

6. If the IG requires posting to the FOIA Library as explained in IRM 1.11.10.5.1(3) above, take the following actions:




| IGM | IPU |
| :-: | :-: |
| 1. Include a "CC" or distribution notation on the IGM indicating the memo will be posted to the [FOIA Library](https://www.irs.gov/privacy-disclosure/foia-library).<br>      <br>2. **After approval**, forward the IGM to the business unit IG coordinator for uploading to the IMD Tracking System and posting to the FOIA Library. | 1. **After approval,** indicate the IPU change(s) that meet E-FOIA criteria on the SERP Submission Form.<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      If an entire subsection does not meet E-FOIA, specify the corresponding paragraph number(s) that do in the SERP Submission Form.<br>      <br>2. The SERP staff creates a Word document of the changes meeting E-FOIA and forwards the document to the respective business unit IG coordinator for uploading to the IMD Tracking System and posting to the FOIA Library. |


**1.11.10.5.2** **(02-07-2024)**

#### Evaluate Interim Guidance for Potential Changes to Conditions of Employment of Bargaining Unit Employees

1. Before initiating clearance, authors and their management **must** evaluate the IG for potential changes to conditions of employment of bargaining unit employees.

2. For detailed guidelines and instructions for evaluating guidance for potential changes to working conditions of bargaining unit employees and the required actions, refer to IRM 1.11.2.5.1.4, IRM Changes Affecting Conditions of Employment of Bargaining Unit Employees, and IRM 1.11.9.4.4, Labor/Employee Relations & Negotiations.


**1.11.10.6** **(07-28-2025)**

### Clear and Obtain Approval for Interim Guidance

1. Send IG for review and approval to affected program offices and specialized reviewers based on whether the guidance is emergency guidance or non-emergency guidance. Clear the IG through the affected program offices and specialized reviewers as detailed in IRM 1.11.9.3, Identifying Reviewers and IRM 1.11.9.4, Specialized Reviewers.

2. All IG is cleared in an expedited manner, therefore director approval for expedited clearance of interim guidance is not applicable, and signature is not required on Form 2061, Document Clearance Record – Internal Management Document (IMD), box 6 and 7, expedite clearance.

3. Allow at least five business days but no more than 30 calendar days to clear IG.

4. Use Form 2061, _Document Clearance Record_ or the IMD Electronic Clearance (e-Clearance) website to clear and document the review and approval of IGMs. Retain these records for proper archival.



### Note:



See the IMD Electronic Clearance Training page for IGM clearance training resources.

5. Use email or other documentation to capture the review and approval of IPUs. Retain these records for proper archival.



### Reminder:



Form 14074, Action Routing Sheet, should not be used to document the clearance and approval of IG.

6. Clear IG and obtain approval for issuance based on the urgency of issuing the guidance to employees. Use the following table to determine whether your IG requires non-emergency or emergency clearance.




| Type of Clearance | Definition | Follow | Type of Guidance |
| :-: | :-: | :-: | :-: |
| Non-emergency Clearance | The process used to clear guidance that informs employees of an important procedural change but does not require immediate issuance. | _IRM 1.11.10.6.1_, Non-emergency Clearance and Approval Process for Interim Guidance | Temporary, pilot guidance, or non-critical procedural changes |
| Emergency Clearance | The process used to clear critical guidance requiring immediate issuance to employees where a delay would result in a work stoppage, incorrect processing of account data, or severe impact to taxpayer actions. | _IRM 1.11.10.6.2_, Emergency Clearance and Approval Process for Interim Guidance | Disaster guidance, newly enacted legislation, or a critical change to IRS procedures |

7. Reviewers must use the preferred comment method requested by the IG originator when providing comments during IG clearance.


**1.11.10.6.1** **(07-28-2025)**

#### Non-emergency Clearance and Approval Process for Interim Guidance

1. Follow the steps in the table below when issuing non-emergency guidance:




| Step | Actions for both IGM and IPUs |
| :-: | :-: |
| 1 | Email the proposed IGM or IPU changes to affected offices and specialized reviewers for review and concurrence. See IRM 1.11.9.3, Identifying Reviewers, and IRM 1.11.9.4, Specialized Reviewers, for determining affected offices and specialized reviewers.<br> <br>1. Specify the review due date, considering the effective date of the guidance. Allow at least five business days but no more than 30 calendar days. Grant or deny any requests to extend the clearance review due date.<br>      <br>2. For sample email templates, see Clear Your IMDs. |
| 2 | Address received comments and respond promptly to any significant issues. See _IRM 1.11.10.6.3_, Responding to Reviewers' Comments. |
| 3 | Elevate non-concurrences to the program director, who decides to issue the guidance or not. See _IRM 1.11.10.6.4_, Resolving Disagreements. |
| 4 | Obtain approval from the program director or documented designee in accordance with, _IRM 1.11.10.6.5_, Interim Guidance Approving Official. For new or changed OUO content, obtain approval from the program director following Delegation Order 11-1, Administrative Control of Documents and Material. |


**1.11.10.6.2** **(07-28-2025)**

#### Emergency Clearance and Approval Process for Interim Guidance

1. **Emergency interim guidance must go through clearance after it is issued.**

2. Follow the steps in the table below when issuing emergency guidance:




| Step | Actions for IGM | Actions for IPU |
| :-: | :-: | :-: |
| 1 | Obtain approval from the program director or documented designee as detailed in _IRM 1.11.10.6.5_, Interim Guidance Approving Official, and clear through any other stakeholder as determined by the program owner. For new or changed OUO content, obtain approval from the program director following Delegation Order 11-1, Administrative Control of Documents and Material. | Obtain approval from the program director or documented designee as detailed in _IRM 1.11.10.6.5_, Interim Guidance Approving Official, and clear through any other stakeholder as determined by the program owner. For new or changed OUO content, obtain approval from the program director following Delegation Order 11-1, Administrative Control of Documents and Material. |
| 2 | Distribute the IGM based on procedures in _IRM 1.11.10.7_, Distribute Interim Guidance. | Complete the SERP Submission Form on the SERP Author Resources page. Follow IRM 1.11.8.7.1.1, Issuing an IPU (Interim Guidance). |
| 3 | At the same time as step 2, email affected offices and specialized reviewers to clear the IGM. See IRM 1.11.9.3, Identifying Reviewers, and IRM 1.11.9.4, Specialized Reviewers, for determining affected offices and specialized reviewers. Attach the IGM and Form 2061, and state in the email the reason the guidance required immediate issuance. | At the same time as step 2, email affected offices and specialized reviewers to clear the IPU. See IRM 1.11.9.3, Identifying Reviewers, and IRM 1.11.9.4, Specialized Reviewers, for determining affected offices and specialized reviewers. Attach the IPU and state in the email the reason the guidance required immediate issuance. |
| 4 | After issuance of emergency interim guidance, give a clearance due date that is at least five business days, but no more than 30 calendar days. Grant or deny any requests to extend the clearance review due date. | After issuance of emergency interim guidance, give a clearance due date that is at least five business days, but no more than 30 calendar days. Grant or deny any requests to extend the clearance review due date. |
| 5 | Address received comments and respond promptly to any significant issues within 15 calendar days. Elevate non-concurrences to the applicable program director. If necessary, obtain a new control number, revise and issue the corrected guidance indicating it supersedes the previous IGM as soon as practical. See _IRM 1.11.10.6.3_, Responding to Reviewers’ Comments | Address received comments and respond promptly to any significant issues within 15 calendar days. Elevate non-concurrences to the applicable program director. If necessary, revise the XML file and submit the new guidance using the SERP Submission Form as soon as practical. |


**1.11.10.6.3** **(07-28-2025)**

#### Responding to Reviewers’ Comments

1. The author must consider and address reviewers’ comments or concerns on substantive content changes and revise the draft IG as appropriate. Refer to the respective subsection below when responding to reviewers comments for non-emergency and emergency IG.


**1.11.10.6.3.1** **(07-28-2025)**

##### Responding to Reviewers’ Comments (Non - Emergency Guidance)

1. Generally, authors should incorporate accepted changes into the proposed IG for final clearance and management review within 15 calendar days of the clearance due date.

2. If the IG requires substantial changes during the clearance process, forward the revised IG to the offices affected by the changes, identifying the changed content. The additional time frame for review must be at least three business days but not more than 10 business days.

3. In rare situations where the agreed-upon changes require a prolonged time to revise, the program director may approve issuance of the IG immediately without incorporating the changes to avoid further delay. In this situation, the author must notify the reviewer of the delay to incorporate the agreed-upon changes. Once the agreed upon changes are incorporated, the author will clear and issue superseding guidance.


**1.11.10.6.3.2** **(07-28-2025)**

##### Responding to Reviewers’ Comments (Emergency Guidance)

1. Respond to comments within 15 calendar days of the clearance due date.

2. If the IG requires substantial changes after issuance, the author must:



1. Contact your business unit IG coordinator to obtain a new control number.

2. Revise the guidance as necessary.

3. Obtain approval from the program director or documented designee.

4. Issue the corrected guidance indicating it supersedes the previous IG as soon as practical.


**1.11.10.6.4** **(07-28-2025)**

#### Resolving Disagreements

1. In situations where the reviewer does not concur with the changes, the author must contact the reviewer to try and resolve the disagreement.




| If: | Then: |
| --- | --- |
| The author adopts a reviewing office’s proposed changes | The reviewing office provides a new assessment within five business days after the changes are made.<br> <br>### Note:<br>The author must document the communications between the disputing offices and keep as part of the historical file. |
| --- | --- |
| After contact, a reviewer disagrees with the proposed guidance and continues to disagree with the changes | The author initiates a conference call with the reviewer, management and other key personnel from both offices to discuss the differing views before issuing the IG.<br> <br>### Note:<br>The author must notify the program director of any ongoing disagreements. |
| The disputing offices are still unable to resolve the disagreement | Elevate the issue to the respective business unit senior executives for discussion and resolution. |
| The IG is issued without resolving the disagreement | The business units should continue to resolve the issue and the author must address and reconsider the disagreement prior to republishing the affected IRM. |


**1.11.10.6.5** **(02-07-2024)**

#### Interim Guidance Approving Official

1. The approving official for IG is a member of the Senior Executive Service (SES) with program oversight of the IMD content. This person is referred to as the program director.



1. The program director may redelegate their authority to a designee in writing for content without new, changed, or de-designated OUO content. The designee must be a supervisory manager, per Delegation Order 1-69 (New), Authorization to Approve an Internal Management Document (IMD).

2. The program director is responsible for the accuracy of the content, even if the designee signs.


2. IG containing OUO content requires approval by an official with delegated authority under Delegation Order 11-1, Administrative Control of Documents and Material, with IMD program oversight.

3. Content meeting E-FOIA requires program director or documented designee approval for posting to the [FOIA Library](https://www.irs.gov/privacy-disclosure/foia-library) on IRS.gov.

4. See IRM 1.11.1.4, IMD Approval, for more information.


**1.11.10.7** **(07-28-2025)**

### Distribute Interim Guidance

1. The program owner is responsible for distributing IG and notifying affected employees and impacted members of the public.

2. IG must be communicated to employees via email, meetings, or posted to internal websites, etc. In accordance with the [Freedom of Information Act (FOIA), 5 USC 552 (a)(2)(C)](https://www.justice.gov/oip/freedom-information-act-5-usc-552), IG must be communicated to impacted members of the public by posting on the [FOIA Library](https://www.irs.gov/privacy-disclosure/foia-library) on IRS.gov. See _IRM 1.11.10.5.1_, Evaluate Interim Guidance for Electronic Freedom of Information Act (E-FOIA) Criteria, for E-FOIA requirements and additional information.

3. Prior to distributing, the business unit must:



1. Ensure proper OUO markings. See IRM 11.3.12.2.1, Official Use Only and IRM 11.3.12.3.2, Procedural Guidance for designating OUO content.

2. Ensure 508 compliance. Authors must complete an accessibility check through Adobe Acrobat and all sections must receive a passing indicator for the document to be 508 compliant. See the SPDER Section 508 Compliance webpage, or the Alternative Media Center for more 508 guidance.

3. For IGMs, convert to a non-alterable static format such as a portable document format (PDF).


### Note:

Microsoft Word and Adobe have accessibility tools. Check your document for compliance while in Word format and a final check after the document has been converted to pdf.

4. Take the actions in the chart below to distribute the IG based on the format.




| Step | Responsible Party | IGM | IPU |
| :-: | :-: | :-: | :-: |
| 1 | Originating Office | 1. The chief, director, or head of office: Distribute the IGM to the chief, director, or head(s) of office of the affected office(s).<br>      <br>2. Author: Sends the IGM to their business unit’s IG coordinator for posting to the IMD Tracking System. | Originator: Completes the SERP Submission Form on the SERP Authors Resources page; correctly identify any content meeting E-FOIA criteria. Follow IRM 1.11.8.7.1.1, Issuing an IPU (Interim Guidance). |
| 2 | SERP | N/A | Posts the IPU with the changed IRM content to the SERP website. |
| 3 | SERP | N/A | Within seven calendar days of receipt, for IPUs identified as meeting E-FOIA criteria:<br> <br>1. Creates a Word document of the IPU.<br>      <br>2. Fills out a Content Publishing Request (CPR), including a brief summary of changes, the name of the IPU submitter, and the name of the approver.<br>      <br>3. Sends both to the respective IG coordinator via email for posting to the [FOIA Library](https://www.irs.gov/privacy-disclosure/foia-library) and copies the IPU submitter. |
| 4 | Originating Office IG Coordinator | Within seven calendar days of the date the director or designee signs the IGM:<br> <br>1. Ensures the IGM file is in a 508-compliant PDF format.<br>      <br>2. Enters IGM information in the IMD Tracking System. For instructions see _Exhibit 1.11.10-1_, IMD Tracking System Data Fields for Adding or Archiving Interim Guidance.<br>      <br>3. If the IGM meets E-FOIA criteria and contains OUO content, creates a second PDF file and ensure OUO content is properly designated and redacted. The redacted file must also meet the requirements outlined in _IRM 1.11.10.7.1_ , Accessibility Standards for Interim Guidance Documents.<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      If the IGM contains attachments, consolidate into one PDF file.<br>      <br>4. If the IGM meets E-FOIA criteria and contains internal web links, creates a second PDF file and ensures all internal web links are deactivated and formatted as normal text. Use the file name with a "- public" at the end,<br>      <br>5. Uploads the IGM to the IMD Tracking System for immediate availability:<br>      <br>      <br>      <br>      - 508-compliant PDF file<br>        <br>      - Redacted 508 compliant PDF public file if the IGM contains OUO content, or 508- compliant PDF public file with deactivated internal web links. The file must also meet the requirements outlined in _IRM 1.11.10.7.1_, Accessibility Standards for Interim Guidance Documents | Within seven calendar days of receipt of the IPU from SERP staff:<br> <br>1. Creates a 508-compliant PDF of the IPU.<br>      <br>2. Enters IPU information into the correct fields in the IMD Tracking System. For instructions see _Exhibit 1.11.10-1_, IMD Tracking System Data Fields for Adding or Archiving Interim Guidance.<br>      <br>3. If the IPU meets E-FOIA criteria and contains OUO content, creates a second PDF file and ensure OUO content is properly designated and redacted. The redacted file must also meet the requirements outlined in _IRM 1.11.10.7.1_ , Accessibility Standards for Interim Guidance Documents.<br>      <br>4. Uploads the IPU to the IMD Tracking System for immediate availability:<br>      <br>      <br>      <br>      - 508 compliant PDF file<br>        <br>      - Redacted 508- compliant PDF file, if the IPU contains OUO content, or 508 compliant PDF public file with deactivated internal web links. The file must also meet the requirements outlined in _IRM 1.11.10.7.1_, Accessibility Standards for Interim Guidance Documents |
| 5 | Affected Office(s) | Upon receipt of the IGM, the chief, director, or head(s) of office distributes it to affected employees through their management or as determined by their business unit, e.g., email, sharing the new guidance during a meeting, or notification system. | Upon posting of the IPU, the chief, director, or head(s) of office distributes it to affected employees through their management or as determined by their business unit, e.g., email, sharing the new guidance during a meeting, or notification system. |
| 6 | SPDER | Within seven calendar days of receiving an IGM with E-FOIA:<br> <br>1. Submits the IGM for posting to the FOIA Library through the Content Management Request System.<br>      <br>2. After posting, emails the respective IG coordinator confirming the document is on the [FOIA Library - Recent Interim Guidance to Staff](https://www.irs.gov/privacy-disclosure/recent-interim-guidance-to-staff) page. | Within seven calendar days of receiving an IPU with E-FOIA:<br> <br>1. Submits the IPU for posting to the FOIA Library through the Content Management Request System.<br>      <br>2. After posting, emails the respective IG coordinator confirming the document is on the [FOIA Library - Recent Interim Guidance to Staff](https://www.irs.gov/privacy-disclosure/recent-interim-guidance-to-staff) page. |


**1.11.10.7.1** **(07-28-2025)**

#### Accessibility Standards for Interim Guidance Documents

1. Business units must make all interim guidance documents accessible under Section 508 of the Rehabilitation Act (29 USC 794d) and meet Freedom of Information Act (FOIA) standards for applicable documents.

2. The business unit IG coordinator must take the actions in the chart below:




| Step | Actions for both IGM and IPU |
| :-: | :-: |
| 1 | Convert IG documents that meet E-FOIA criteria into a Portable Document Format (PDF) |
| 2 | Ensure IG PDF documents pass all accessibility checks within Adobe Acrobat prior to uploading to the IMD Tracking System. |
| 3 | Remove hyperlinks to all internal websites from documents that will be posted on the FOIA Library. See Deactivate PDF links for assistance.<br> <br>### Note:<br>Internal websites are those that are not accessible to the public. |
| 4 | Save the file using the naming convention of the IG control number. xxxx-01-0525-0001.pdf.<br>**Example:** xxxx-01-0525-0001.pdf, where "xxxx" is the business unit acronym, and the name is lowercase. |
| 5 | Prepare a separate file including the word "public" at the end of file name, if the IG meets E-FOIA criteria and requires modification for public release.<br>**Example:** xxxx-01-0525-0001-public.pdf, where "xxxx" is the business unit acronym, and the name is lowercase. |

3. Documents that don’t meet the requirements outlined in _IRM 1.11.10.7.1_, Accessibility Standards for Interim Guidance Documents, may be returned to the originating office by SPDER.


**1.11.10.7.1.1** **(07-28-2025)**

##### Resolving Accessibility Errors

1. The business unit IG coordinator must complete accessibility checks in Adobe Acrobat for all documents that will be uploaded to the IMD Tracking System. All sections of the document must have passing indicators for it to be 508 compliant.



### Note:



_The Section 508 for Interim Guidance Documents_ process guide is available in various formats on SPDER’s Section 508 Compliance and Accessibility webpage. Use this guide to resolve compliance errors.

2. Authors and coordinators can escalate unresolved errors to \*SPDER or the Alternative Media Center.

3. When requesting assistance with accessibility standards and section 508 compliance from SPDER, submit an email with the document as an attachment, with "Assistance with IG Accessibility" in the subject line.



### Note:



Requests for assistance can take up to 7 business days.


**1.11.10.8** **(02-07-2024)**

### Monitor Interim Guidance for Expiration

1. It is important to monitor IG for expiration. Expired IG places the IRS at risk by misleading employees into following outdated guidance, treating taxpayers inconsistently, or creating administrative or taxpayer burden.

2. The program owner is responsible for ensuring their staff:



1. Monitors the expiration date of IG.

2. Incorporates all permanent IG during the next revision of the affected IRM section(s), reissues the guidance, or obsolesces prior to the IG expiration date.

3. Notifies the IG coordinator to initiate IG archival in the IMD Tracking System and removal from IRS.gov, if applicable.


3. The IMD Tracking System assists with monitoring the age of all IGMs and IPUs that meet E-FOIA criteria. Reports are available to identify IG within 30, 60, 90, or 120 days of expiring.


**1.11.10.9** **(05-01-2022)**

### Incorporate into the IRM, Reissue, or Obsolesce Interim Guidance

1. Refer to the respective subsection below when incorporating IG into the IRM, reissuing or obsolescing.


**1.11.10.9.1** **(07-28-2025)**

#### Incorporate Interim Guidance into the IRM

1. The author/originating office must incorporate all permanent IG into the next published revision of the affected IRM section(s). This must be done before the expiration date of the IG, or sooner if required by the business unit. Interim guidance is considered permanent when the guidance is not temporary, pilot or deviation, and not superseded by subsequent IG. Follow the instructions in IRM 1.11.2, Internal Revenue Manual (IRM) Process, for authoring the IRM.



### Note:



An IRM author may use the streamlined clearance process when updates to the IRM only consist of incorporating an interim guidance memorandum (IGM) or a Servicewide Electronic Research Program (SERP) IRM Procedural Update (IPU).

2. When updating the associated IRM to incorporate IG, the author must include a reference to the IG in both the **material changes** and the **effect on other documents** sections of the manual transmittal.



   - In the material changes, the author must identify what changed, why it changed, and reference the IGM number, issue date, and title (for IGMs) or IPU number and effective date (for IPUs).

   - In the effect on other documents, the author states the IRM incorporates the IG.


### Example:

**Material changes (incorporating IGM):**

IRM 21.1.X.1 - Added content from Interim Guidance Memorandum SBSE-05-0508-XXXX, \[Title of interim guidance\], dated MM-DD-YYYY, to update \[description of the change\].

### Example:

**Material changes (incorporating IPU):**

IRM 21.1.X.1.X - Updated \[description of the change\] - IPU 23U162X issued MM-DD-YYYY.

### Example:

**Effect on other documents (incorporating IGM):**

This IRM incorporates Interim Guidance Memorandum SBSE-05-0508-XXXX, \[Title of interim guidance\], dated Month DD, YYYY.

### Example:

**Effect on other documents (incorporating IPU):**

This IRM incorporates the following IRM Procedural Updates (IPUs): IPU 23U162X and 23U163X issued MM-DD-YYYY through MM-DD-YYYY.

3. If a previously issued IPU is no longer valid guidance for employees to follow and has been superseded by another, a statement to that effect must be referenced in the material changes.

4. The author or originating office must retain a copy of the changed guidance, all signed Forms 2061, approval documentation, clearance documents, and significant reviewers' comments for historical record-keeping purposes. The author must include a zip file of these documents when initiating IRM clearance. See IRM 1.11.9.5.2, Documents Sent for Clearance - Clearance Package.



### Note:



If e-Clearance was used to clear an IGM, include the e-Clearance IGM archived email(s) in the IRM clearance package.

5. Within seven calendar days of when the revised IRM is published incorporating the IG, the author ensures proper archival, per IRM 1.11.9.10.5, Archiving Clearance Documents. The author also notifies the IG coordinator to initiate archival in the IMD Tracking System and removal from IRS.gov.


**1.11.10.9.2** **(07-28-2025)**

#### Reissue Interim Guidance

01. In rare instances and for continuity of operations, business units may reissue IG when the content is unchanged and still valid. Situations requiring reissuance can include:



    - Inability to update the related IRM section within the effective period

    - The IG is temporary in nature and requires an extension


02. The IG content qualifying for reissuance only requires an extension of the effective period. Modified guidance is not considered a reissuance.

03. The program owner must make it a priority to incorporate permanent IG change(s) into the IRM before the expiration date. Reissuing IG is discouraged.

04. Examples warranting reissuance include:



    - Pending legislation, National Treasury Employee Union (NTEU) negotiations, rulings or guidance from Counsel impacting the IRM

    - Delays due to M&P publishing

    - Delays in resolving issues identified during the IRM clearance process

    - Extension of a pilot program

    - Extension of temporary guidance


05. The reissuance of an IGM or IPU requires review to ensure guidance still reflects the current processes and management approval. You must obtain approval from the applicable program director or designee prior to requesting approval for the IG reissuance from SPDER.

06. The Director of SPDER reviews and approves these requests, and may delegate this authority to the SPDER IG coordinator.

07. The business unit IG coordinator assists authors with obtaining approval for reissuance.

08. To obtain approval to reissue IG, the author, business unit IG coordinator, or IMD coordinator takes the following actions:




    | Step | Actions for both IGM and IPU |
    | :-: | :-: |
    | 1 | Completes the form: Request to Reissue Interim Guidance. The requestor must include the target dates for updating the affected IRM(s) and the actions that will be taken to meet the specified timeframes.<br> <br>### Note:<br>The applicable program director must sign the form prior to submitting to SPDER. |
    | 2 | Emails the completed and signed _Request to Reissue Interim Guidance_ form to \*SPDER. The email must also include a copy of the existing IG or a link to it on the IMD Tracking System. |

09. SPDER will provide the status of the request within five business days of receipt and send the _Request to Reissue Interim Guidance_ form back to the originator.

10. If SPDER approves the request, the issuing business unit takes the following actions based on the type of IG:




    | IGM | IPU |
    | :-: | :-: |
    | Requests a new control number from the business unit IG coordinator. | Refers to IRM 1.11.8.7.1.2, Reissuing IPUs (Interim Guidance), for instructions to reissue an IPU. |
    | Issues a new memorandum with a new date, control number and signature.<br> <br>    - Reference the prior issued IGM.<br>      <br>    - Specify in the memorandum the date the business units will incorporate permanent procedures into the affected IRM. | Submits the reissued XML file using the SERP Submission Form to receive a new IPU number. |
    | Removes the original IGM from all intranet sites. | N/A |
    | Within seven calendar days of reissuance, notifies the business unit IG coordinator to initiate archival of the original IGM in the IMD Tracking System and removal from the intranet and IRS.gov. | Within seven calendar days of reissuance, notifies the business unit IG coordinator to initiate archival of the original IPU in the IMD Tracking System and removal from the intranet and IRS.gov. |
    | Retains a PDF copy of the new IGM, previous IGM and clearance documents, significant reviewers' comments, and approval documentation for historical record-keeping purposes. | Retains a PDF copy of the new IPU, previous IPU and clearance documents, significant reviewers' comments, and approval documentation for historical record-keeping purposes. |

11. If the request is not approved, the business unit must schedule a meeting with the Director of SPDER, IG coordinators (SPDER and business unit), and the applicable program director or designee. Although SPDER reviews each request independently, reissuance of IG may not be approved if:



    1. The request is more than 120 days beyond the current expiration date.

    2. The IG has already been reissued.

    3. The business unit did not provide a plan to incorporate permanent guidance with the request.


**1.11.10.9.3** **(05-01-2022)**

#### Obsolesce Interim Guidance Memorandums

1. When business units do not reissue or incorporate an IGM into the IRM and it is no longer valid, e.g., temporary guidance or pilot guidance, the author or business unit must:



1. Within seven calendar days of obsolescence or expiration, notify the IG coordinator to initiate archival in the IMD Tracking System and removal from IRS.gov.

2. Remove the guidance from all intranet sites.

3. Communicate obsolescence to employees following the business unit’s procedures.

4. Retain a PDF copy of the obsolesced guidance, clearance documents, significant reviewers' comments and approval documentation for historical record- keeping purposes, following retention standards found in Document 12829, _General Records Schedules_, and Document 12990, _Records Control Schedules_. Do not send to the IRS Historical Research Library.


**1.11.10.10** **(02-07-2024)**

### Archive Interim Guidance

1. Business units must timely archive IGMs and IPUs when the guidance is:



1. Incorporated into a published IRM.

2. Reissued through another IG.

3. Superseded by another issued IG.

4. Obsolesced and no longer valid, such as temporary or pilot guidance.



      ### Note:



      The IMD webpage systemically marks expired IG as 'Archived' on its expiration date. This systemic status change does not take the place of the requirements below.


2. The originator must ensure the IG is removed from any sites where posted, e.g., the business unit websites and SharePoint sites. For IPUs, the guidance archives when a subsequent IPU issues or the republished IRM becomes effective.

3. Notify your business unit IG coordinator to initiate IG archival in the IMD Tracking System.

4. Within seven calendar days from any of the scenarios described in (1) above, the IG coordinator must use the IMD Tracking System to archive the IG, selecting the correct ‘Remove Action’ for the IG. This documents the removal and, if necessary, notifies the SPDER staff to remove any posted IG from the [FOIA Library](https://www.irs.gov/privacy-disclosure/foia-library) on IRS.gov.

5. When the IG posted to the FOIA Library is incorporated into a published IRM section, SPDER provides a link to that section on the FOIA Library page for 30 days.

6. SPDER forwards a confirmation to the respective business unit IG coordinator to confirm removal of the guidance from the FOIA Library.

7. Program owners must oversee retention standards for their IG documents (hardcopy and electronic) following Document 12829, _General Records Schedules_, for administrative-related records and Document 12990, _Records Control Schedules_, for records accumulated within their program office. Contact your IG coordinator to confirm internal records retention procedures for your business unit.

8. The author of the primary IRM or originator of the IG must retain a PDF copy of the changed guidance, clearance documents, significant reviewers' comments, and approval documentation for historical record-keeping purposes. They must send the IG historical documents to the IRS Historical Research Library, following their business unit’s record retention procedures.


**Exhibit 1.11.10-1**

### IMD Tracking System Data Fields for Adding or Archiving Interim Guidance

The chart below contains the IMD Tracking System data fields and the content and action required when adding or removing IG from the IMD Tracking System and the [FOIA Library](https://www.irs.gov/privacy-disclosure/foia-library) on IRS.gov. Obtain the information from the IG document and the Content Publishing Request submitted with an IPU meeting E-FOIA criteria.

| Field | Content/Action |
| :-: | :-: |
| Was this content approved by the responsible director or designee? | Select "Yes" or "No" to indicate if the director or designee approved the IG. |
| Add Action<br> <br>- New<br>  <br>- Reissue | Select "New" or "Reissue" to identify the IG as a new IG or a reissuance of a previously issued IG memo or IPU. |
| Control Number | Select the IG control number components from the drop-down menus for Business Unit, IRM Part Number, Month, and Year. Enter the Sequence Number. |
| Functional Office | Enter the name of the functional office issuing the IG. |
| Business Unit Name | Select the business unit originating the IG from the drop-down list. |
| Document Type | Select either "Interim Guidance Memo" or "IRM Procedural Update" from the drop-down list. |
| Which IRM(s) does the Interim Guidance relate to? List the primary IRM number first | Enter the primary affected IRM section requiring update due to the issued procedures. Click "Add Row" to enter secondary IRM sections. |
| Title of Interim Guidance | Insert the exact subject line of the IG. The title field is 150 characters or less. The system truncates the title if more than 150 characters. |
| Issue Date | Pre-populated with current date. Use the "Select date" calendar to change the guidance issuance date if necessary. (Use MM/DD/YYYY format). |
| Effective Date | Pre-populated with current date. Use the "Select date" calendar to change the guidance effective date if necessary. If not identified on the IG, this is the guidance issue date. (Use MM/DD/YYYY format). |
| Expiration Date | Pre-populated to two years from the issue date. Use the "Select date" calendar to enter the date the IG expires if the expiration date is earlier than two years. (Use MM/DD/YYYY format). |
| Author of Interim Guidance | Enter the first and last name of the IG author. |
| Approver - Individual who approved the interim guidance (program director or designee) | Enter the first and last name of the individual who approved the IG. |
| Does the guidance meet E-FOIA criteria for posting to IRS.gov? | Select the "Yes" or "No" to indicate if the IG meets E-FOIA criteria.<br> • For IG memos - Look for a notation on the bottom of the IGM of cc: IRS.gov<br> • For IPUs – SERP identifies the IPU as E-FOIA in the subject line of the email forwarded to the IG coordinator |
| Abstract<br> <br>### Note:<br>Required entry if guidance meets E-FOIA criteria and requires posting to IRS.gov. | Enter a two or three-sentence summary (300 characters or less) of the IG content containing:<br> <br>- Business unit and office issuing the IG<br>  <br>- Subject line of the IG<br>  <br>- Effective date of the IG<br>  <br>- IRM section or subsection number associated with the content |
| Does the guidance contain internal web links and/or Official Use Only (OUO)/Sensitive But Unclassified (SBU) information? | Select "Yes" or "No" to indicate if the IG contains internal web links, OUO and/or SBU content. |
| If you answered "Yes" to the previous OUO question – Have you created a redacted version of this guidance for posting to IRS.gov? | Select "Yes" or "No" to indicate if you created a redacted file to post to IRS.gov. |
| I have reviewed this content for IRS.gov posting and all internal web links are deactivated, and it is accurately redacted where appropriate | Check the box to confirm the content was reviewed and accurately redacted for posting to the IRS.gov FOIA Library. |
| Certify the document being uploaded is a PDF and is Section 508 compliant | Check the box to certify the file(s) uploaded is/are in PDF format and meet(s) Section 508 compliance standards. |
| Remove an Interim Guidance: Remove Requested By | Enter first and last name of the individual requesting the removal of the IG. |
| Remove an Interim Guidance: Remove Request Date | Pre-populated field indicating the date of entry for the request. |
| Remove an Interim Guidance: Remove On Date | Use the "Select date" calendar to enter the date the guidance should archive from the IMD Tracking System, IG website and IRS.gov. |
| Remove an Interim Guidance: Remove Action | Select the reason for removal/archival from the drop-down list:<br> • Remove due to incorporation into IRM<br> • Remove due to reissued interim guidance<br> • Remove due to other |
| Removed due to Guidance Incorporated into an IRM | Enter the IRM number the guidance was incorporated into. |
| Removed due to Interim Guidance Reissued | Enter the IG control number of the new reissued IG. |
| Remove Abstract - Removed due to Other | Enter the reason the guidance is no longer valid and requires removal (300 characters or less). |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-011-010#addtoany "Show all")

A2A