---
url: "https://www.irs.gov/irm/part1/irm_01-022-008"
title: "1.22.8 Mailing and Shipping Equipment | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-022-008#main-content)

- 1.22.8  [Mailing and Shipping Equipment](https://www.irs.gov/irm/part1/irm_01-022-008#idm140057027001856)
  - 1.22.8.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-022-008#idm140057022147936)
    - 1.22.8.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-022-008#idm140057027097728)
    - 1.22.8.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-022-008#idm140056994056960)
    - 1.22.8.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-022-008#idm140056994040928)
    - 1.22.8.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-022-008#idm140056993968784)
    - 1.22.8.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-022-008#idm140056994033968)
    - 1.22.8.1.6  [Frequently used Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-022-008#idm140057022007888)
    - 1.22.8.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-022-008#idm140057022152624)
  - 1.22.8.2  [Postage Meters](https://www.irs.gov/irm/part1/irm_01-022-008#idm140057027032608)
    - 1.22.8.2.1  [Postage Meter Providers](https://www.irs.gov/irm/part1/irm_01-022-008#idm140057026980400)
    - 1.22.8.2.2  [Postage Meter Customer Responsibilities](https://www.irs.gov/irm/part1/irm_01-022-008#idm140057027025424)
    - 1.22.8.2.3  [Postage Meter License](https://www.irs.gov/irm/part1/irm_01-022-008#idm140057027037920)
    - 1.22.8.2.4  [Examination of Postage Meters](https://www.irs.gov/irm/part1/irm_01-022-008#idm140057022114224)
    - 1.22.8.2.5  [Change of Postage Meter Location](https://www.irs.gov/irm/part1/irm_01-022-008#idm140056993971584)
    - 1.22.8.2.6  [Defective Postage Meter](https://www.irs.gov/irm/part1/irm_01-022-008#idm140056994046976)
    - 1.22.8.2.7  [Postage Meter Equipment Failure](https://www.irs.gov/irm/part1/irm_01-022-008#idm140057022104608)
    - 1.22.8.2.8  [Transferring and Refunding Postage](https://www.irs.gov/irm/part1/irm_01-022-008#idm140056994058672)
    - 1.22.8.2.9  [Postage Meter Security](https://www.irs.gov/irm/part1/irm_01-022-008#idm140057027020592)
  - 1.22.8.3  [Small Package Carrier (SPC) Technology Options](https://www.irs.gov/irm/part1/irm_01-022-008#idm140056994050704)
    - 1.22.8.3.1  [Small Package Carrier (SPC) Equipment Failure](https://www.irs.gov/irm/part1/irm_01-022-008#idm140057022248352)

# Part 1. Organization, Finance, and Management

# Chapter 22. Mail and Transportation Management

# Section 8. Mailing and Shipping Equipment

* * *

## 1.22.8 Mailing and Shipping Equipment

#### Manual Transmittal

January 08, 2025

#### Purpose

(1) This transmits revised IRM 1.22.8, Mail and Transportation Management, Mailing and Shipping Equipment.

#### Material Changes

(1) IRM 1.22.8 revised throughout to update organizational title Wage and Investment to Taxpayer Services.

#### Effect on Other Documents

IRM 1.22.8, Mailing and Shipping Equipment, dated January 03, 2024 is superseded.

#### Audience

IRS Employees

#### Effective Date

(01-08-2025)

Maria Cheeks

Director, Distribution

Taxpayer Services

**1.22.8.1** **(01-21-2021)**

### Program Scope and Objectives

1. Purpose: This section of the IRM describes the importance of mailing and shipping equipment.

2. Audience: The information in this section is for all IRS employees who make Mail and Transportation Management decisions.

3. Policy Owner: The responsibility of administering the IRS mail and transportation management program falls under the direction of the Commissioner, Taxpayer Services (TS).

4. Program Owner: Technology and Program Support (TPS) is the program office responsible for overseeing and providing guidance for the Mail and Transportation Management.

5. Primary Stakeholders:



1. IRS Business Units

2. Technology and Program Support

3. Postal and Transportation Policy

4. All employees who use mailing and shipping services


6. Program goals: To provide information on the use of postage machines and small parcel technology.


**1.22.8.1.1** **(01-21-2021)**

#### Background

1. Every IRS office, whether operated by a staffed mailroom or self-serviced by individual IRS employees, needs equipment for mailing and shipping. This IRM section contains information about postage meters, Small Package Carrier (SPC) shipping systems and SPC web based shipping. Employees are reminded that it is forbidden to use Government property for conducting personal business or for other unauthorized personal purposes. Government property includes:



   - Office Supplies

   - Telephone and other telecommunications equipment and services

   - Government mail carried by agency personnel, contractors, the U.S. Postal Service and all other carriers

   - Government Mail Services

   - Automated data processing capabilities

   - Printing and reproduction facilities

   - Government records and Government vehicles, per 5 CFR 2635.101 and 107


### Note:

See IRM 10.8.27, Information Technology (IT) Security, Personal Use of Government Furnished Information Technology Equipment and Resources for more information on when an employee can use IRS equipment for personal purposes

**1.22.8.1.2** **(01-21-2021)**

#### Authority

1. 5 CFR 2635, 101&107, Office of Government Ethics, Standard of Ethic Conduct

2. 41 CFR 102-192, Mail Management

3. IRM 10.8.27, Information Technology (IT) Security, Personal Use of Government Furnished Information Technology Equipment and Resources

4. IRM 1.35.3, Financial Accounting, Receipt and Acceptance Guidelines

5. IRM 1.35.5, Administrative Accounting, Advances, Prepaid Expenses and Other Assets


**1.22.8.1.3** **(01-21-2021)**

#### Roles and Responsibilities

1. Taxpayer Services (TS)/Media and Publications (M&P)/Technology and Program Support (TPS) provides guidance and support to the affected stakeholders, including expense verification, adjustments and reconciliation.

2. Postal and Transport (PTP):



1. Develops and evaluates policies, systems, procedures and standards for mail and transportation services

2. Serves as Contracting Officer Representatives (CORs) on Mail and Transportation contacts and Tenders of Service


3. Facilities Management and Security Services (FMSS)/Office of the Deputy Director Facilities Support/Logistics:



1. Oversees the operation of the Mail Management program.

2. Establishes a Territory Point of Contact (TPOC) who provides mail management program guidance for mailroom operations and mail services within their Territory.

3. Coordinates Servicewide field office mailroom operations and mail delivery services

4. Serves as the Contracting Officer’s Representatives (COR) for the National Mailroom Services Contract, and the National Postal Meter Contract

5. Communicates changes in policy to field offices

6. Provides TPOCs with training and education


4. Business Operating Divisions (BOD) assign Local Points of Contact (LPOC) in IRS Field offices that are not serviced by the Primary Mail Contractor. The LPOC serves as the primary contact for the FMSS Mail Program TPOC.


**1.22.8.1.4** **(01-21-2021)**

#### Program Management and Review

1. PTP reconciles postal meter charges and credits from the USPS for the IRS.


**1.22.8.1.5** **(01-21-2021)**

#### Program Controls

1. The following forms and reports are used for control of the program:



   - OMAS report

   - Vendor Meter Reset Report

   - IPAC Billing Document


2. F10580-A, Postage Purchase/Expenditure Report, is used to reconcile postal meter charges and credits from the USPS for the IRS.


**1.22.8.1.6** **(01-21-2021)**

#### Frequently used Terms and Acronyms

1. The following charts contain defined terms and acronyms used throughout this IRM:



**Terms**






| Frequently used Terms and Definitions |
| :-: |
| **Term** | **Definition** |
| --- | --- |
| Electronic Shipping Label | A type of identification label that includes the origin/return address, the destination address, package weight, type of shipment (Ground, 2nd Day Air, etc) and a tracking barcode. |
| Electronic Tracking Number and Shipping Barcode | Tracking number and barcode are automatically generated by the carrier. |
| Postage Meters | Machines or systems approved by the Postal Service that print postage directly onto your mailpiece or on to meter tape, which you affix to your mail. They are available for lease only from authorized providers. |







**Acronyms**






| Frequently used Acronyms |
| :-: |
| **Acronym** | **Definition** |
| --- | --- |
| CMRS | Computerized Meter Resetting Machine |
| DMM | Domestic Mail Manual |
| FMSS | Facilities Management and Security Services |
| LPOC | Local Point of Contact |
| OMAS | Official Mail Accounting System |
| SPC | Small Package Carrier |
| TPS | Technology and Program Support |
| TS | Taxpayer Services |
| TPOC | Territory Point of Contact |
| USPS | United States Postal Service |


**1.22.8.1.7** **(01-21-2021)**

#### Related Resources

1. Related resources include:



   - href=http://publish.no.irs.gov/mailtran/spc.html

   - 5 CFR 2635.101&107, Office of Government Ethics, Standard of Ethic Conduct

   - DMM 604, Postage Meters and PC Postage Products


**1.22.8.2** **(01-21-2021)**

### Postage Meters

1. Postage meters are available only by lease from authorized meter providers. All IRS meters must be penalty postage meters to facilitate payment through the Official Mail Accounting System (OMAS). The United States Postal Service (USPS) holds providers responsible for the control, operation, maintenance and replacement of their meters when necessary. No one other than an authorized provider may possess a postage meter without a valid rental agreement.

2. The Office of Procurement, Southern Region - Midstates Section has negotiated a national meter contract to provide nationwide postage meter equipment and maintenance to IRS offices. The provider is subject to change when the current contract expires. Therefore, it is important to check with the appropriate FMSS Territory Point of Contact (TPOC) for the current provider.

3. All IRS postage meters must use the remote Computerized Meter Resetting System (CMRS), which allows a meter to be reset/refilled using telephone technology. The initial dollar amount of postage set and subsequent refills are paid through the OMAS, which is established with the USPS.

4. The amount of postage to be placed on the meter should be equal to the average amount of postage expended in a month. This applies to the initial fill and subsequent refills.


**1.22.8.2.1** **(08-15-2018)**

#### Postage Meter Providers

1. A list of authorized postage meter providers is contained in Chapter 604 of the USPS Domestic Mail Manual (DMM).


**1.22.8.2.2** **(01-21-2021)**

#### Postage Meter Customer Responsibilities

1. Meter licensee responsibilities include:



1. Securing the meter to prevent any unauthorized use and prevent access to the meter components

2. Keeping the meter in IRS custody until returned to the authorized provider

3. Recording each day's readings of the ascending and descending registers


**1.22.8.2.3** **(08-15-2018)**

#### Postage Meter License

1. USPS requires authorized providers to electronically submit the necessary customer information to the designated Postal Service processing facility in order for the Postal Service to authorize a customer to use a postage meter. There is no application or license fee.

2. USPS authorizes use of the postage meter when the electronic application is accepted. Conditions that apply to this authorization are:



1. Customer must provide updated address information to the provider

2. Postage meter providers must conduct scheduled inspections of meters

3. A defective meter, loss, or theft of a meter must be reported immediately to the provider


**1.22.8.2.4** **(08-15-2018)**

#### Examination of Postage Meters

1. Postage meter inspections are required every three months according to Postal Service regulations. Meters refilled at least once every three months only require annual examination by the USPS.

2. If a postage meter inspection is not performed, USPS will not allow the meter to be refilled.


**1.22.8.2.5** **(08-15-2018)**

#### Change of Postage Meter Location

1. The licensing Post Office and the meter provider must be notified of any change in the name, telephone number, meter location, or any other information contained on the original meter license. The licensing Post Office will issue a modified meter license reflecting the updated information.

2. If an office relocation requires the mail to be processed at a different Post Office and the meter license has not been updated, the Post Office may refuse IRS mail.


**1.22.8.2.6** **(08-15-2018)**

#### Defective Postage Meter

1. Faulty meters must be immediately reported to the meter provider Service Call Center. The meter is repaired on site by the meter provider after a service call is placed. If a meter is inoperable or unable to be repaired, the meter provider will replace it with another meter of the same caliber.


**1.22.8.2.7** **(01-21-2021)**

#### Postage Meter Equipment Failure

1. When equipment fails and it is difficult to place a meter imprint on outgoing mail, the postage meter provider's Service Call Center should be contacted. If mail must be processed before the equipment repairs and/or replacement can be made, the following options are available:



1. Maintain a supply of postage stamps - A small supply of postage stamps stored in the mailroom can be used to process urgent outgoing mail until the meter is repaired or replaced.

2. Arrange for mail to be metered by the nearest IRS office - This option must be coordinated by the TPOC/Local Point of Contact (LPOC).


**1.22.8.2.8** **(08-15-2018)**

#### Transferring and Refunding Postage

1. When a meter is taken out of service, all unused postage loaded on the meter is credited to the IRS OMAS account. Copies of daily ascending and descending meter readings may be required as supporting documentation.


**1.22.8.2.9** **(08-15-2018)**

#### Postage Meter Security

1. The security of the postage meter requires the following:



1. Access to the meter must be controlled. Each meter is equipped with a 4-number PIN to lock and unlock the meter. Refer to the meter providers user guide for this information.

2. At the end of the workday, the meter must be placed in the locked position.

3. Offices with after-hours cleaning must secure the meter in a locked interior room or in a locked cabinet each evening.

4. Offices that do not have an intrusion detection system must secure the meter in a locked interior room or a locked cabinet.


**1.22.8.3** **(01-21-2021)**

### Small Package Carrier (SPC) Technology Options

1. All shipments tendered through a SPC should use an electronic shipping label. Electronic shipping labels allow for faster processing and less handling of a package. There are two methods available for generation of an electronic shipping label:



1. Carrier provided shipping system - This is a standalone computer system that is provided to large office locations. These systems are typically provided to Campus/Submission Processing locations and IRS locations with a contractor staffed mailroom. A Form 9814, Request for Mail/Shipping Service, is required to generate the shipping label

2. Carrier web site - This is primarily used in smaller locations that do not have contract mailrooms. It is an internet-based program from which users can easily generate an electronic shipping label, using their computer, printer and plain printer paper. Users are registered and given access to the program by a Postal and Transport Policy Section employee



      ### Note:



      Employees that ship packages after the mailroom closes should request access to the Carrier web site, so they can generate electronic shipping labels. Manually prepared labels should only be used as a last resort


**1.22.8.3.1** **(08-15-2018)**

#### Small Package Carrier (SPC)   Equipment Failure

1. All electronic equipment and web sites are subject to failures and breakdowns. Rebooting a system and/or stepping away for 5 to 10 minutes may resolve the situation. If not, follow one of the options below:



1. Carrier provided shipping systems - Contact the TPOC/LPOC and advise them of the breakdown. If known, call the local carrier representative and advise them of the situation. Replacement software/hardware and technical support must be provided by the equipment owner

2. Carrier web site - Attempt to open the internet site. If this web site will not load, the problem is internal and not external. Most web site failures are due to an IRS network problem and not related to the SPC web site


2. If unable to resolve, manually prepare 2nd Day Air and/or Next Day Air shipping documents to ensure timely delivery of high priority shipments. Manually prepared labels should only be used as a last resort.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-022-008#addtoany "Show all")

A2A