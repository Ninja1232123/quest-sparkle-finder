---
url: "https://www.irs.gov/irm/part1/irm_01-014-003"
title: "1.14.3 Furniture and Equipment Standards | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-014-003#main-content)

- 1.14.3  [Furniture and Equipment Standards](https://www.irs.gov/irm/part1/irm_01-014-003#idm140686053811904)
  - 1.14.3.1  [Program Scope](https://www.irs.gov/irm/part1/irm_01-014-003#idm140686026174416)
    - 1.14.3.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-014-003#idm140686026055296)
    - 1.14.3.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-014-003#idm140686026045232)
    - 1.14.3.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-014-003#idm140686026090736)
    - 1.14.3.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-014-003#idm140686025317152)
    - 1.14.3.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-014-003#idm140686024792160)
    - 1.14.3.1.6  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-014-003#idm140686053806144)
    - 1.14.3.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-014-003#idm140686024937840)
  - 1.14.3.2  [Directives](https://www.irs.gov/irm/part1/irm_01-014-003#idm140686024935760)
  - 1.14.3.3  [National Workspace Standards (NWS)](https://www.irs.gov/irm/part1/irm_01-014-003#idm140686026010496)
  - 1.14.3.4  [Application of Standards](https://www.irs.gov/irm/part1/irm_01-014-003#idm140686026020624)
    - 1.14.3.4.1  [Office Furniture Standards](https://www.irs.gov/irm/part1/irm_01-014-003#idm140686057406144)
    - 1.14.3.4.2  [Workspace Furniture Selection and Acquisition](https://www.irs.gov/irm/part1/irm_01-014-003#idm140686057397728)
    - 1.14.3.4.3  [Furniture Selection Factors](https://www.irs.gov/irm/part1/irm_01-014-003#idm140686024716512)
    - 1.14.3.4.4  [Use of Furniture Exchange Program (FEP) BPA Contract](https://www.irs.gov/irm/part1/irm_01-014-003#idm140686053794464)
  - 1.14.3.5  [Furniture Finishes and Colors](https://www.irs.gov/irm/part1/irm_01-014-003#idm140686053792416)
  - 1.14.3.6  [Artwork, Accessories and Décor](https://www.irs.gov/irm/part1/irm_01-014-003#idm140686052857776)
  - 1.14.3.7  [Employee Orientation to New Furniture](https://www.irs.gov/irm/part1/irm_01-014-003#idm140686052866944)
  - 1.14.3.8  [Post-Occupancy Evaluation of New Workspace Furniture](https://www.irs.gov/irm/part1/irm_01-014-003#idm140686024926992)
  - 1.14.3.9  [Reasonable Accommodations for Persons with Special Needs](https://www.irs.gov/irm/part1/irm_01-014-003#idm140686053696976)

# Part 1. Organization, Finance, and Management

# Chapter 14. Facilities Management

# Section 3. Furniture and Equipment Standards

* * *

## 1.14.3 Furniture and Equipment Standards

#### Manual Transmittal

June 30, 2025

#### Purpose

(1) This transmits IRM 1.14.3, _Workspace, Furniture and Equipment Standards_.

#### Material Changes

(1) IRM title is changed to Workspace, Furniture, and Equipment Standards to clarify that in addition to furniture and equipment, workspace is one of the primary components previously and currently covered in the guidance.

(2) _IRM 1.14.3.1_The following changes were made throughout this section:

1. (1) Added reference to the Taxpayer Assistance Center (TAC) Design Guide as a supplement to the National Workplace Standards (NWS). Also updated the name of the business unit for which the TAC is assigned because, as of June 4, 2024, the Wage and Investment (W&I) business unit name was changed to Taxpayer Services (TS).

2. (2) - Added acronym for Office Design Handbook, (ODH).

3. (3) - Remove full text of Office Design Handbook and added ODH.

4. (3)(e) - Changed wording: Morale to Wellness.

5. (7) - Stated additional primary stakeholders to include interior architects and included acronym for business units (BU).


(3) _IRM 1.14.3.1.1_ (1)(a) and (b) - Added additional responsibilities for the FMSS Project Management Office.

(4) _IRM 1.14.3.1.2_ (1) - Code of Federal Regulations (CFR) links were added, updated and validated.

(5) _IRM 1.14.3.1.3_ \- Updated title to Roles and Responsibilities. Updated individual role titles as applicable and included clarification of associated responsibilities.

(6) _IRM 1.14.3.1.4_ \- Changed title from Program Objectives to Program Management and Review and added references to resources.

(7) _IRM 1.14.3.1.5_ \- New section added to state Program Controls. Subsequent subsections renumbered.

(8) _IRM 1.14.3.1.6_ \- Acronyms added to table: Automatic Data Processing (ADP), Asset Management Plan (AMP), Business Unit (BU), Internal Revenue Workflow Optimization, Request, and Knowledge System (IRWorks), and Office and Design Handbook (ODH). Acronyms removed: IRS Disability Office (IDO) and Invitation for Bids (IFB).

(9) _IRM 1.14.3.2 (2)_ \- Updated to align cited standards with revised title of IRM and include the word "workspace" .

(10) _IRM 1.14.3.4_ \- Added guidance for the Office Planning and Design (OPAD) service staff.

(11) _IRM 1.14.3.4.1_ (5) - Added additional verbiage for guidance through National Workplace Standards (NWS).

(12) _IRM 1.14.3.4.2_ (2) - Deleted reference to Personal Property Management Handbook and added link to cited regulation reference.

(13) _IRM 1.14.3.4.3_ (4)(d) - Added Sustainability - environmental and economical as additional parameters for furniture selection.

(14) _IRM 1.14.3.4.4_ \- Added guidance for the Furniture Exchange Program (FEP) to clarify how to use the contract and associated procedures.

(15) IRM 1.14.3.4.5 - Deleted section dealing with the reference to a Taxpayer Assistance Center (TAC) Furniture contract because the contract is no longer a requirement.

(16) IRM 1.14.3.4.6 - Removed section on Mandatory Chair Contract because the contract has expired and will not be renewed.

(17) IRM 1.14.3.4.7 - Removed section covering File Cabinet Contract because it is no longer required.

(18) _IRM 1.14.3.5_ \- Clarified furniture finishes and color selection available and which parties are responsible for which roles; and updated the title of one resource.

(19) _IRM 1.14.3.6_ \- Updated the title of the section to Artwork, Accessories and Décor to clarify the guidance covered in the section. Removed reference to artificial plants in title. Content updated to clarify who is involved with determining the aesthetic of a space.

(20) _IRM 1.14.3.8_ \- Updated the name of the platform IRS employees use to submit tickets from the Employee Resource Center (ERC) to ServiceNow IRWorks.

(21) _IRM 1.14.3.9_ \- Removed reference to IRS Disability Office and removed the link. Clarified where the requests for reasonable accommodation originate and the FMSS role in fulfilling these requirements.

(22) Throughout: Made editorial changes to clarify, reorganize and remove duplicate content. Incorporated plain language and updated grammar, titles, website addresses, and references.

#### Effect on Other Documents

This IRM supersedes IRM 1.14.3, dated September 27, 2018.

#### Audience

Facilities Management and Security Services

#### Effective Date

(06-30-2025)

Julia W. Caldwell

Acting Chief

Facilities Management and Security Services

**1.14.3.1** **(06-30-2025)**

### Program Scope

1. The _IRS National Workspace Standards (NWS)_ is a facilities planning and space allocation tool for all individual workspaces and support spaces in new construction, renovation, and relocation projects for the IRS. It is intended for use by IRS FMSS project managers, designers, and other stakeholders. The Taxpayer Assistance Center (TAC) Design Guide is a supplement to the NWS, intended to be used as a detailed space planning and design guide for all Taxpayer Services (TS) TAC sites.

2. **Purpose**: The IRS furniture standards provide policy for selecting furniture and equipment specifically designed for efficiency in a quality work environment as detailed in the _IRS NWS_ and _IRS Office Design Handbook (ODH)_.

3. Compliance with these standards and application of the principles described in _IRS NWS_ and _IRS ODH_:



1. Emphasizes ergonomic flexibility and supports automation.

2. Exhibits design flexibility and effective use of space.

3. Provides privacy for taxpayer interviews.

4. Offers functional, efficient offices.

5. Promotes employee wellness.

6. Demonstrates better property use.

7. Improves accountability.


4. **Audience**: Facilities Management and Security Services (FMSS).

5. **Policy Owner**: Chief, FMSS.

6. **Program Owner**: Associate Director, Project Management.

7. **Primary Stakeholders**: This IRM is intended for use by FMSS Territory Managers (TM), project managers, interior architects and designers, and IRS business units (BU).


**1.14.3.1.1** **(06-30-2025)**

#### Background

1. The FMSS Project Management office establishes policy for workspace planning and design, and provides guidance in acquisition and use of furniture components, furniture systems, and non-Automatic Data Processing (ADP) equipment, all of which meet IRS standards, including:



1. Providing guidance to FMSS project managers to allocate the proper amount and types of space for IRS real estate projects.

2. Providing guidance to FMSS project managers to develop interior space plans using the space design process.

3. Providing guidance to FMSS project managers to develop specifications and select furniture systems that meet agency standards.

4. Establishing procedures for developing new workspace furniture models for the standards.

5. Approving inclusion of new and/or refurbished workspace furniture models in the standards.


**1.14.3.1.2** **(06-30-2025)**

#### Authority

1. These workspace standards comply with:



1. 41 CFR 101-25.302 - _Office Furniture, Furnishings, and Equipment_

2. 41 CFR 101-25.302-2 - _Filing Cabinets_

3. 41 CFR 101-25.104 - _Acquisition of Office Furniture and Office Machines_

4. 41 CFR 101-26.506 - _Interior Planning and Design Services_

5. 41 CFR 102-79 - _Assignment and Utilization of Space_

6. 48 CFR 8 - _Required Sources of Supplies and Services_


**1.14.3.1.3** **(06-30-2025)**

#### Roles and Responsibilities

1. FMSS establishes Servicewide policy, procedures, standards, and guidelines for allocation of workspace procurement and use of furniture and equipment to enable the IRS to perform its function efficiently and economically.

2. Associate Director (AD), Project Management regularly monitors the effectiveness of the NWS, furniture and equipment standards, and the strategic facility and space planning policy.

3. The Chief, Real Property develops the standards for office planning and design, provides guidance in the acquisition and use of furniture components, furniture systems, and non-IT equipment, to comply with IRS standards in all IRS offices as workspace, furniture, and equipment are procured; and develops asset management plans (AMP) for each IRS non-campus office building. The AMP process integrates business requirements, real property information, strategic planning, human capital, and technology to optimize the size and location of each IRS office post of duty (POD). Strategic planning requires evaluating the adequacy of space and the consistent application of IRS NWS.

4. Each AD, FMSS Operations is responsible for overall furniture and equipment activities within their geographical responsibility, assuring appropriate coordination of all matters relating to the workspace, furniture and equipment program, including implementing instructions and guidelines issued by the Chief, FMSS.

5. Each FMSS TM is responsible for administering the workspace, furniture and equipment planning and designing activities in the offices assigned to their geographical territory. FMSS Territories will coordinate with the program staff under Chief, Real Property for strategic facility planning, workspace planning and design, and furniture and equipment acquisition.


**1.14.3.1.4** **(06-30-2025)**

#### Program Management and Review

1. **Program Goals**: The Workspace, Furniture and Equipment Standards provide a foundation for allocating and designing office space for each organization within the IRS in a uniform manner. By following the processes and procedures provided in this IRM, appropriate type and sized workspaces will be built for each IRS BU.

2. **Program Reports**: The NWS is the comprehensive manual developed and maintained by FMSS Project Management which explains, describes, and illustrates workspace and support space furnishings and equipment, workstation models, and how to allocate appropriate amounts of space for each BU function. The NWS is located on the FMSS Project Management SharePoint site. The Project Management tool called _Space, Time and Resources (STAR)_ uses the information in the NWS to allocate space and estimate costs for rent and furnishing workspace and support space. The STAR project management tool can be found on the STAR SharePoint site. The space design process is described in the Desk Guide to Project Management and the Office Planning and Design (OPAD) materials, reviewed annually by the OPAD staff.

3. **Program Effectiveness**: When space is acquired or realigned based on the Workspace, Furniture and Equipment Standards, there will be enough functional space, furnishings and equipment to support the work of the BU housed there.

4. **Annual Review**: The workspace standards are reviewed at least annually for accuracy and continued applicability for each organization.


**1.14.3.1.5** **(06-30-2025)**

#### Program Controls

1. The National Workspace Standards (NWS) describes the recommended workspaces and support spaces required for each BU in the IRS. It is updated as needed and reviewed annually by the Workflow Analysis Office Planning and Design staff.

2. The Project Management tool called STAR uses the information in the NWS to allocate space and estimate costs for rent and furnishing offices and support space. FMSS project managers use the Space Requirements Module (SRM) in STAR to develop the recommended square footage required for space projects.

3. The Furniture Planning and Procurement SharePoint site contains desk guides, requirements, training, best practices, and links to resources for planning and procuring furniture and equipment.

4. The FMSS Desk Guide to Furniture Planning and Acquisition for Projects provides instructions for assessing furniture needs and developing furniture acquisition packages for IRS space projects.

5. The OPAD staff provides oversight of the NWS, Office Planning and Design program, and Furniture Acquisition program.


**1.14.3.1.6** **(06-30-2025)**

#### Terms and Acronyms

1. Acronym table




| **Acronym** | **Definition** |
| :-: | :-: |
| A-i-A | Art in Architecture |
| AD | Associate Director |
| ADP | Automatic Data Processing |
| ANSI | American National Standards Institution |
| AMP | Asset Management Plan |
| BIFMA | Business and Industrial Furniture Manufacturers Association |
| BPA | Blanket Purchase Agreements |
| BU | Business Unit |
| CFR | Code of Federal Regulations |
| ECC | Estimated Construction Costs |
| ERC | Employee Resource Center |
| FAR | Federal Acquisition Regulation |
| FEP | Furniture Exchange Program |
| FMSS | Facilities Management and Security Services |
| GO | General Office |
| GSA | General Services Administration |
| IR | Internal Revenue (Manager) |
| IRWorks | Internal Revenue Workflow Optimization, Request and Knowledge System |
| NWS | National Workspace Standards |
| ODH | Office Design Handbook |
| OPAD | Office Planning and Design |
| RA | Reasonable Accommodations |
| RAC | Reasonable Accommodations Coordinator |
| RFP | Requests for Proposals |
| RFQ | Requests for Quotations |
| SRM | Space Requirement Module |
| TAC | Taxpayer Assistance Center |
| TM | Territory Manager(s) |


**1.14.3.1.7** **(06-30-2025)**

#### Related Resources

1. IRM 1.14.4, _Personal Property Management_


**1.14.3.2** **(06-30-2025)**

### Directives

1. The increased mobility of IRS employees, initiated by the Telework Enhancement Act of 2010, created an opportunity to update the individual workspace standards and support space standards for non-campus IRS space. Furniture and equipment for office-based and mobile workers were updated to support the effects of modernization in terms of electronic communications such as fewer employees requiring assigned seating in the office and the reduction in the need to store paper.

2. The workspace, furniture and equipment standards as detailed in the IRS NWS incorporate space allocation and furniture standards with facility planning guidelines to provide appropriate working environments for IRS employees while using space efficiently and reducing long term facility costs.

3. The two concepts that drive the overall design of an IRS facility are:



1. The corporate model for support spaces.

2. A boundary-less open office plan for general office (GO) employees assigned to workstations and non-assigned (hoteling) employees.


**1.14.3.3** **(09-27-2018)**

### National Workspace Standards (NWS)

1. The IRS NWS planning tool was designed to meet the following objectives:



1. Provide appropriate working environments for IRS Services and Enforcement organizations, Operations Support organizations, and other programs and groups within the IRS.

2. Support changing work patterns and technological advances.

3. Promote efficient use of space and reduce long-term facilities management costs in all IRS facilities.

4. Explain the fundamental space allocation guidelines and planning concepts upon which the IRS’ Space Requirement Module (SRM) inside the STAR project management system tool is based.


**1.14.3.4** **(06-30-2025)**

### Application of Standards

1. Space is allocated to each employee based on a limited number of typical footprints as appropriate to the function. The job series and pay plan are listed in tables that are used to map the employee to one of the typical workspace types. The SRM in the STAR tool employs this process to help the PM allocate space appropriately while planning for space projects.

2. The FMSS Office Planning and Design (OPAD) staff provides subject matter expertise on the NWS, the space design process, and the furniture planning and acquisition program. FMSS Territories will coordinate with the OPAD staff to validate the appropriate amount of space has been allocated for a real estate project based on the NWS and to deliver design services using interior architecture and design principles to modernize IRS workspace.


**1.14.3.4.1** **(06-30-2025)**

#### Office Furniture Standards

1. Workspace furniture standards provide employees with furniture that supports their job operations. These standards emphasize ergonomic flexibility, effective use of space, a quality work environment, and cost efficiency. The standards are to be followed whenever there is a change in facilities which affects workspaces or when any furniture acquisition occurs.

2. For GO employees, there are three default workstation footprints:



1. W.48 - for most General Schedule (GS) office-based employees

2. O.96 - for office-based management

3. O.150 - only for executive or senior level management


3. Exceptions to the three typical footprints are listed in the NWS and in the SRM tool. These exceptions usually occur for specialty groups or for job types that require additional security and/or privacy or have face-to-face contact with the public.

4. The furniture and equipment standards apply to all locations and all IRS groups including:



1. National Headquarters

2. Services and Enforcement

3. Operations Support


5. Furniture guidelines can be found in the NWS, Chapter 2-5 Individual Workspace Standards Furniture Guidelines. This section provides detailed guidance on the specification and construction of the workstations and private offices.


**1.14.3.4.2** **(06-30-2025)**

#### Workspace Furniture Selection and Acquisition

1. Purchase of newly manufactured systems furniture for an entire office can be quite costly. Other, less costly, options should be thoroughly considered prior to acquiring newly manufactured products. Those options include:



1. Cleaning, retrofit of existing product.

2. Excess product shown as available from other IRS projects.

3. Purchase of refurbished products using IRS’ Furniture Exchange Program (FEP) contract or from General Services Administration (GSA) Schedule providers.


2. New furniture acquisition is generally from two sources of supply: government and commercial sources. For additional guidelines on acquisition of personal property refer to Federal Acquisition Regulations (FAR) Part 8, Required Sources of Supplies and Services (48 CFR 8).

3. Government sources include:



1. Sources within IRS, e.g., redistribution of existing or warehoused property.

2. Excessed property from government agencies.

3. Established government sources such as GSA and Federal Prison Industries.


4. Commercial sources include:



1. Directed commercial sources from Federal Supply Schedules.

2. National Industries for the Blind.

3. National Industries for the Severely Handicapped, Inc.

4. Open market procurements, which are made through Invitations for Bids (IFB), Requests for Proposals (RFP), and Requests for Quotations (RFQ).


5. All components of a workspace must meet the American National Standards Institution (ANSI) and Business and Industrial Furniture Manufacturers Association (BIFMA) standards.


**1.14.3.4.3** **(06-30-2025)**

#### Furniture Selection Factors

1. The following factors should be considered in selecting procured furniture:



1. Construction

2. Conformance to specifications

3. Conformance to required standards (ANSI and BIFMA)

4. Sustainability - environmental and economical

5. Maintenance - ease of cleaning and repair

6. Appearance - compatibility and flexibility to fit into the existing office environment

7. Availability - vendor’s ability to meet delivery schedule and provide required components as specified

8. Cost



      ### Note:



      The list of factors is listed in order of importance for most projects but could also be determined on a case-by-case basis.


**1.14.3.4.4** **(06-30-2025)**

#### Use of Furniture Exchange Program (FEP) BPA Contract

1. The IRS often uses Blanket Purchase Agreements (BPA) to obtain quantity discounts for frequently purchased items. The use of the Furniture Exchange Program (FEP) BPA allows for a deeper discount, reduced manufacturing time and reduced procurement lead times. In addition, the FEP program remanufactures exchangeable furniture and prevents furniture components from being disposed of in the landfill. The contracts can be found on the FMSS Furniture Planning and Procurement SharePoint.


**1.14.3.5** **(06-30-2025)**

### Furniture Finishes and Colors

1. Generally, finishes of surfaces are chosen to provide a decreasing reflectance from ceiling to floor. Avoid a highly polished or reflective work surface, especially in the area surrounding the computer screen(s). It is recommended that the work surface be of a medium-value color to minimize eye fatigue.

2. It is advisable to use light-value, neutral colors for file and storage cabinets, a portion of the acoustical partitions, and all other large or tall furniture components because they provide a more spacious appearance as well as allow for long-term layout flexibility.

3. Accent colors may be used in selecting chair upholstery, a portion of the acoustical partitions, paint, and other finishes for walls, and artwork.

4. Furniture finishes are not specified in the IRS NWS and may be selected for each project. Project Managers must follow the guidelines offered in the Desk Guide to Project Management and Office Planning and Design (OPAD) training materials for guidance on selection of finishes and materials, as well as obtaining agreement from end-users on the general color scheme palette.



### Note:



The FMSS Project Manager is responsible for developing the color palette for a project using their expertise, by contacting the IRS OPAD staff for assistance, or by consulting with the design team provided by GSA/Lessor. The Project Team and/or employees should not be asked to develop the project’s color palette.


**1.14.3.6** **(06-30-2025)**

### Artwork, Accessories and Décor

1. Artwork plays an important aesthetic role in office environments and public areas. Tastes vary in artwork, as a result, the OPAD staff and/or project designer is involved in the selection of art. For design continuity, the artwork should be integrated into the overall office design. Various forms of artwork can be used effectively in completing the color scheme and providing a visual break for occupants.

2. The New Deal program Art-in-Architecture (A-i-A) developed "percent for art" programs, a structure for funding public art still utilized today. This program gave one half of one percent of total Estimated Construction Costs (ECC) of all government buildings to purchase contemporary American art for that structure. IRS aligns with this practice to develop a baseline estimate for new construction projects, when budget allows. For smaller budget projects, consider using a standard $0.30 per usable square foot if artwork is appropriate to the scope and when budget allows.

3. Interesting prints are available in many sizes, covering a wide variety of themes. Pictures of local sites may be especially appealing.

4. Textiles in the form of wall-hangings or acoustical tiles on the walls may be effective in some areas; however, choosing fire-retardant, soil-resistant fabrics is important.

5. Other forms of artwork include murals, sculptures, photographs, and large ceramics.

6. Plants add variety and color to the open office. Artificial plants are generally most economical, considering they can be used for longer periods of time. Artificial plants must have a fire-retardant rating and be cleaned regularly. Other uses of plants are:



1. Physically separating two areas.

2. Defining areas in lieu of screens.

3. Visually identifying an area with a landmark.


**1.14.3.7** **(09-27-2018)**

### Employee Orientation to New Furniture

1. Employee orientation is required to achieve maximum, proper utilization of any new furniture workspace or equipment.

2. Orientation should include, but not be limited to:



1. Instruction on the proper positioning of the employee’s head, hands, body, and feet within the workspace for maximum ergonomic comfort.

2. Instruction and demonstration on using all adjustable features of the workspace components.


3. Photographs and actual workspace models can be provided for employees to see before installation when new furniture is to be introduced. Vendors are often amenable to send products without obligation for a trial period. When acquiring furniture for testing or demonstration, each office should follow the guidelines as set forth in IRM 1.14.4, _Personal Property Management_.

4. Demonstration and testing of equipment or other tangible items with a commercial vendor must be prearranged through the Contracting Officer as well as the Property Officer. The Property Officer’s prior approval must be obtained so that any property provided for demonstration or testing is cleared to enter or exit the building.

5. When equipment or tangible item(s) are to be left for demonstration or testing, the Contracting Officer will notify the Property Officer and give the vendor written dates of the demonstration or test dates and when the equipment or tangible item(s) is to be removed.


**1.14.3.8** **(06-30-2025)**

### Post-Occupancy Evaluation of New Workspace Furniture

1. A post-occupancy evaluation must be conducted 90 days after installation of any new workspace furniture.

2. Post-occupancy evaluations are conducted to assure:



1. Proper use of the workspace.

2. All adjustment mechanisms on components, i.e., chairs and sit-to-stand tables, are accessible and work properly.


3. Furniture purchased from a new supply source should be evaluated after installation based on the following criteria:



1. Feedback from employees using the items.

2. Repair and maintenance records (i.e., ServiceNow IRWorks tickets).


**1.14.3.9** **(06-30-2025)**

### Reasonable Accommodations for Persons with Special Needs

1. The role of the FMSS Project Manager requires a greater sensitivity and awareness of requirements for persons with disabilities. To provide an appropriate work environment for those with special needs, it is often necessary to modify existing furniture and equipment, including those areas accessible to taxpayers. Such modifications are referred to as Reasonable Accommodations (RA).

2. An employee who has a special need requiring an accommodation will follow the process outlined in IRWorks under “Reasonable Accommodation Requests”, using Form 13661, Reasonable Accommodations Request Form. A Reasonable Accommodation Coordinator (RAC) is assigned to help facilitate the process. The RAC submits an IRWorks case ticket to FMSS regarding the need and coordinates with FMSS on the timeframe for action.

3. FMSS Project Managers will research alternatives and provide options to the RAC as quickly as possible to ensure the needs are appropriately addressed.

4. A post-occupancy evaluation of any newly designed workspace or installed equipment will be conducted 90 days after installation to ascertain if the solution adequately addressed the need.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-014-003#addtoany "Show all")

A2A