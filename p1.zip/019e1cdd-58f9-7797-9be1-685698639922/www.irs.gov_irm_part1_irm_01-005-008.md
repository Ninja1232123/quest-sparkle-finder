---
url: "https://www.irs.gov/irm/part1/irm_01-005-008"
title: "1.5.8 Section 1204/Regulation 801 Guidance for Taxpayer Advocate Service (TAS) | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-005-008#main-content)

- 1.5.8  [Section 1204/Regulation 801 Guidance for Taxpayer Advocate Service (TAS)](https://www.irs.gov/irm/part1/irm_01-005-008#idm140152754661360)
  - 1.5.8.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-005-008#idm140152754684880)
    - 1.5.8.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-005-008#idm140152754682640)
    - 1.5.8.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-005-008#idm140152754743952)
    - 1.5.8.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-005-008#idm140152754741408)
    - 1.5.8.1.4  [Acronyms](https://www.irs.gov/irm/part1/irm_01-005-008#idm140152754739664)
  - 1.5.8.2  [Section 1204 General Guidelines for TAS](https://www.irs.gov/irm/part1/irm_01-005-008#idm140152754724416)
  - 1.5.8.3  [TAS Section 1204 Quarterly Certification Requirements](https://www.irs.gov/irm/part1/irm_01-005-008#idm140152754246624)

# Part 1. Organization, Finance, and Management

# Chapter 5. Managing Statistics in a Balanced Measurement System

# Section 8. Section 1204/Regulation 801 Guidance for Taxpayer Advocate Service (TAS)

* * *

## 1.5.8 Section 1204/Regulation 801 Guidance for Taxpayer Advocate Service (TAS)

#### Manual Transmittal

February 26, 2025

#### Purpose

(1) This transmits revised IRM 1.5.8, Organization, Finance and Management, Managing Statistics in a Balanced Measurement System Handbook Section 1204/Regulation 801 Guidance for the Taxpayer Advocate Service (TAS).

#### Material Changes

(1) IRM 1.5.8.1.4 The table has been updated to reflect currently used acronyms.

(2) IRM 1.5.8.2(4) The note has been updated to change Wage and Investment to Taxpayer Services.

(3) IRM 1.5.8.3(2) has been updated to correct the reporting structure for manager self-certification of Section 1204 compliance to replace Area Director with Deputy Executive Director Case Advocacy and to add Assistant Executive Director Case Advocacy.

(4) Various grammatical or editorial changes, and corrections to links made throughout.

#### Effect on Other Documents

This transmittal supersedes IRM 1.5.8 dated 11-10-2021.

#### Audience

TAS Employees

#### Effective Date

(02-26-2025)

Erin M. Collins

National Taxpayer Advocate

**1.5.8.1** **(06-07-2018)**

### Program Scope and Objectives

1. The design of IRS Regulations on the use of statistics makes sure that Records of Tax Enforcement Results (ROTERs) are not used to improperly influence the handling of taxpayer cases.

2. Revisions in this text more clearly identify Section 1204 employees, Section 1204 managers, and the Appropriate Supervisor for the Taxpayer Advocate Service.


**1.5.8.1.1** **(11-10-2021)**

#### Background

1. The Taxpayer Advocate Service (TAS) has a unique mission which is, “As an independent organization within the IRS, we help taxpayers resolve problems with the IRS and recommend changes that will prevent the problems”. Given this mission, TAS strives to optimize its effectiveness in resolving tax problems while achieving efficiency in its own operations. TAS, however, as a function within the IRS is subject to Section 1204 and cannot use ROTERs to evaluate employees. This section provides guidance on the use of statistics by TAS when evaluating its employees. Do not use this IRM section as the sole reference for guidance on using statistical data. Use this IRM in conjunction with other IRMs, Section 1204 and Regulation 801.

2. IRM 1.5.1, _The IRS Balanced Performance Measurement System,_ provides an overview of the IRS Balanced Performance Measurement System and outlines how balanced measures are used to measure organizational performance at the IRS.

3. IRM 1.5.2, _Uses of Section 1204 Statistics_:



1. Contains general background information on the use of enforcement statistics.

2. Defines key terms under Section 1204.

3. Provides detailed procedures on the use of ROTERs.

4. Explains the Section 1204 prohibited and permitted use of ROTERs.


4. IRM 1.5.3, _Manager's Self-Certification and the Independent Review Process_, provides guidance and instructions for the Restructuring and Reform Act of 1998 (RRA) Section 1204 self-certification and the Chief Financial Officer (CFO) Independent Review.

5. Regulation 801 as amended is found at 26 CFR Part 801 and is reprinted in IRM 1.5.2.8, _Regulation 801_.


**1.5.8.1.2** **(11-10-2021)**

#### Authorities

1. The IRS Restructuring and Reform Act of 1998 (RRA’98) requires the IRS to change its measures to balance customer service with its overall tax administration responsibilities.

2. 26 CFR 801, Balanced System for Measuring Organizational and Employee Performance, implements the IRS Balanced Performance Measurement System.


**1.5.8.1.3** **(11-10-2021)**

#### Responsibilities

1. Section 1204 managers are required to provide self-certification quarterly to report their findings.


**1.5.8.1.4** **(02-26-2025)**

#### Acronyms

1. |     |     |
| --- | --- |
| **Acronym** | **Meaning** |
| AEDCA | Assistant Executive Director Case Advocacy |
| CFO | Chief Financial Officer |
| Deputy | Deputy Executive Director Case Advocacy |
| DNTA | Deputy National Taxpayer Advocate |
| EDCA | Executive Director Case Advocacy |
| EDSA | Executive Director Systemic Advocacy |
| LTA | Local Taxpayer Advocate |
| NTA | National Taxpayer Advocate |
| ROTER | Records of Tax Enforcement Results |
| TAGM | Taxpayer Advocate Group Manager |
| TAO | Taxpayer Assistance Order |
| TAS | Taxpayer Advocate Service |
| TER | Tax Enforcement Result |


**1.5.8.2** **(02-26-2025)**

### Section 1204 General Guidelines for TAS

01. A Tax Enforcement Result (TER) is the outcome produced by an IRS employee’s exercise of judgment in recommending or determining whether or how the IRS should pursue enforcement of the tax laws. See IRM 1.5.2.10, _Tax Enforcement Results_ (TERs). TERs may be cited to provide guidance on future actions necessary for one or more specific cases. Neither Section 1204 nor Regulation 801 contains restrictions on TER use. A manager may reference an individual case to illustrate whether the employee’s performance met specific performance standards. A manager may make recommendations on enforcement actions in a specific case.

02. However, the IRS determined that managers must not include TER outcomes in a written performance appraisal or employee evaluation.

03. See IRM 1.5.2.10.1, _Permitted Use of TERS_, and IRM 1.5.2.10.2, _Prohibited Use of TERs_, for additional information and examples on using TERs.

04. ROTERs are data, statistics, and compilations of information or other numerical or quantitative recordation of the tax enforcement results reached in one or more cases. Examples of TAS ROTERs may include but are not limited to the number of:



    - Taxpayer Assistance Orders (TAO) issued; and

    - Manual refunds issued;



      ### Note:



      IRM Exhibit 1.5.2-2, _Questions and Answers for Small Business/Self-Employed and Taxpayer Services Operating Divisions_, states that not all actions are TERs, just like not all TAOs are TERs. The determination of whether Section 1204/Regulation 801 applies requires a review of the tasks performed by the employee and a determination whether the employee exercised judgment in regard to recommending or determining whether or how the IRS should pursue enforcement of the tax laws.


    - Percentage of Taxpayer Advocate cases where relief was granted.


05. At all levels, Section 1204 of the Restructuring and Reform Act 1998 prohibits the use of ROTERS with respect to employees or to managers of employees, to evaluate, to impose, or to suggest production quotas or goals. This applies to employees and managers:



    - Who exercise judgment in recommending or determining whether or how the IRS should pursue enforcement of the tax laws; or

    - Whose duties involve providing direction or guidance for field programs involving Section 1204 work activities.


06. See IRM 1.5.2.11.1, _Permitted Use of ROTERS_, and IRM 1.5.2.11.2, _Prohibited Use of ROTERs_, for additional information on using ROTERs.

07. A TAS organizational unit may use any outcome neutral production quantity measure as a diagnostic tool to assess and improve its performance. Outcome-neutral production measures do not contain information regarding the tax enforcement result (TER) reached in any case or cases involving particular taxpayers. The following are examples of outcome neutral production measures:



    - Volume of cases closed;

    - Case cycle time;

    - Closure to receipt ratio;

    - Casework and Systemic Advocacy Quality Results;

    - Customer Satisfaction survey results (internal and external);

    - Employee Satisfaction survey results;

    - Work items completed;

    - Inventory information; and

    - Time per case.


08. Including ROTERs in self-assessments does not violate IRS RRA 98 Section 1204 or Regulation 801; however, to dispel the appearance of impropriety, it is IRS policy that bargaining unit and non-bargaining unit employees do not use ROTERs in self-assessments.

09. If a manager, management official, or confidential management/program analyst submits a self-assessment with ROTERs, it should be returned to the employee for removal of the ROTERs.

10. It is a Section 1204(a) violation if a ranking official or panel uses the information in the ranking process or if a supervisor uses the information when evaluating employees’ performance.

11. See IRM 1.5.2.12.1, _Permitted Use of Quantity Measures_, and IRM 1.5.2.12.2, _Prohibited Use of Quantity Measures_, for additional information on using quantity measures.


**1.5.8.3** **(02-26-2025)**

### TAS Section 1204 Quarterly Certification Requirements

1. Section 1204(c) requires that appropriate supervisors certify, on a quarterly basis, whether or not they used ROTERs in a manner prohibited by Section 1204(a). For quarterly certification, the term, appropriate supervisors, includes Section 1204 appropriate supervisors, directors, managers, supervisors, acting managers, and acting supervisors. The self-certification due dates are found in IRM 1.5.3.4.1, _Due Dates_.

2. The reporting structure for manager self-certification of Section 1204 compliance within TAS rolls up as follows:



   - Taxpayer Advocate Group Manager (TAGM) to;

   - Local Taxpayer Advocate (LTA) and other managers to;

   - Deputy Executive Director Case Advocacy (Deputy) and other appropriate Directors to;

   - Assistant Executive Director Case Advocacy (AEDCA), if applicable, to;

   - Executive Director Case Advocacy (EDCA) or the Executive Director Systemic Advocacy (EDSA), along with other Executives, National Directors and National managers to;

   - Deputy National Taxpayer Advocate (DNTA), who will summarize all TAS units below the NTA Executive level to;

   - National Taxpayer Advocate (NTA).



     ### Note:



     The TAS organization continues to evolve, new managers, directors, and executives are added, moved, or dropped. The above listing, and order is not fixed and not all-inclusive. All Section 1204 managers must follow this section’s guidance and roll up their certifications. Excluding the NTA Executive level, the DNTA will self-certify and summarize all other TAS organizations.


3. **Section 1204 managers** must complete the self-certification to summarize their findings.



1. A Section 1204 Manager is a manager/supervisor at any level who supervises one or more Section 1204 employees.

2. A Section 1204 Employee is an employee who exercises judgment in recommending or determining whether or how the IRS should pursue enforcement of tax laws, or who provides direction and guidance for Section 1204 program activities, including IRM guidance. Section 1204 activity is determined by the tasks performed by an employee, not by the employee’s title or Operating/Functional Division.


4. **Next-level managers and appropriate supervisors**, (those subordinate to the Heads of Operating/Functional Divisions (in TAS, the NTA):



1. Self-certify quarterly for their immediate office (including review of Employee Personnel Files (EPFs) of direct reports).

2. Summarizes their findings and those from the organizational units below them.

3. Certify their findings to the CFO as delegated by the Commissioner.



      ### Note:



      **The Appropriate Supervisor** is the Section 1204 executive in an Operating/Functional Division that directly or indirectly supervises one or more Section 1204 employees. The appropriate supervisor can identify additional appropriate supervisors.


5. **The NTA,** supported by the DNTA;



1. Self-certifies quarterly for their immediate office (including the review of EPFs of direct reports).

2. Summarize their findings and those from the organizational units below them.

3. Certifies their findings to the CFO as delegated by the Commissioner.



      ### Example:



      The NTA self-certifies for their immediate office and sends a Consolidated Office Transmittal Memorandum to the CFO. The Consolidated Office Transmittal Memorandum includes a summary of the findings of the immediate office and other TAS organizational units including the Headquarters Directors and other subordinate appropriate supervisors who self-certify for their individual offices.


6. Refer to IRM 1.5.3, _Manager's Self-Certification and the Independent Review Process_, for procedures on the quarterly self-certification requirements.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-005-008#addtoany "Show all")

A2A