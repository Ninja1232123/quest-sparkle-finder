---
url: "https://www.irs.gov/irm/part1/irm_01-032-011"
title: "1.32.11 IRS City-to-City Travel Guide | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-032-011#main-content)

- 1.32.11  [IRS City-to-City Travel Guide](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508554992624)
  - 1.32.11.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508553944336)
    - 1.32.11.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508553986224)
    - 1.32.11.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508553983536)
    - 1.32.11.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508526879984)
      - 1.32.11.1.3.1  [Approving Officials](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508526872944)
      - 1.32.11.1.3.2  [Employees](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508526269648)
      - 1.32.11.1.3.3  [Commissioner](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508553704016)
      - 1.32.11.1.3.4  [CFO and Deputy CFO](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508553700816)
      - 1.32.11.1.3.5  [Senior Associate CFO Financial Management](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508553696752)
      - 1.32.11.1.3.6  [Associate CFO for Corporate Accounting](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508558828272)
      - 1.32.11.1.3.7  [Travel Management](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508558824672)
      - 1.32.11.1.3.8  [Travel Review](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508558818976)
      - 1.32.11.1.3.9  [Travel Services](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508525919472)
      - 1.32.11.1.3.10  [Travel Operations](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508525914016)
      - 1.32.11.1.3.11  [LB&I, International Travel Office (ITO)](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508525909328)
    - 1.32.11.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508525903136)
      - 1.32.11.1.4.1  [Program Reports](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508525900752)
      - 1.32.11.1.4.2  [Program Effectiveness](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508526317200)
    - 1.32.11.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508525873552)
    - 1.32.11.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508553733872)
    - 1.32.11.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508553791264)
    - 1.32.11.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524972976)
  - 1.32.11.2  [General Rules](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524968736)
  - 1.32.11.3  [Travel Guidance for Year End and/or Beginning of New Fiscal Year](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524937312)
  - 1.32.11.4  [Travel During Periods Covered by Continuing Resolution Authority](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524932032)
  - 1.32.11.5  [Allowable Travel Expenses](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524927424)
    - 1.32.11.5.1  [Transportation Expenses](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524923584)
      - 1.32.11.5.1.1  [Airline Accommodations](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524918064)
        - 1.32.11.5.1.1.1  [Unused ticket(s) or Refund Application](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524875696)
      - 1.32.11.5.1.2  [Train Accommodations](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524871264)
      - 1.32.11.5.1.3  [Government Owned Vehicle (GOV)](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524865456)
      - 1.32.11.5.1.4  [Rental Car](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524857776)
      - 1.32.11.5.1.5  [Privately Owned Vehicle (POV)](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524832704)
      - 1.32.11.5.1.6  [Special Conveyances](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524821408)
        - 1.32.11.5.1.6.1  [Taxis, TNCs, Innovative Mobility Technology Companies, Shuttle Services or Other Courtesy Transportation](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524818816)
        - 1.32.11.5.1.6.2  [Limousine and Executive Car Services](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524812544)
    - 1.32.11.5.2  [Per Diem Expenses](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524808560)
      - 1.32.11.5.2.1  [Reduced Per Diem](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524796576)
      - 1.32.11.5.2.2  [Actual Expenses](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524784896)
      - 1.32.11.5.2.3  [Travel over Weekend and Holidays](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524776720)
        - 1.32.11.5.2.3.1  [Temporary Return to Residence or Official Assigned Duty Station](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524772416)
        - 1.32.11.5.2.3.2  [Travel to Another TDY Location](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524766272)
        - 1.32.11.5.2.3.3  [Temporary Duty Beginning on Monday](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524760352)
        - 1.32.11.5.2.3.4  [Completion of TDY Assignment on Friday](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524756496)
        - 1.32.11.5.2.3.5  [Leave of Absence](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524752128)
    - 1.32.11.5.3  [Miscellaneous Expenses](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524741504)
    - 1.32.11.5.4  [Other Temporary Duty Travel Expenses](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524726368)
      - 1.32.11.5.4.1  [Travel of an Employee with Special Needs](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524721552)
      - 1.32.11.5.4.2  [Travel of a Threatened Law Enforcement/Investigative Employee](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524716448)
      - 1.32.11.5.4.3  [Pre-Employment Interview Travel](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524713472)
      - 1.32.11.5.4.4  [Employees Detailed Beyond Six Months](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524710336)
      - 1.32.11.5.4.5  [Emergency Travel](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524704992)
    - 1.32.11.5.5  [Foreign Travel](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524696544)
    - 1.32.11.5.6  [Invitational Travel](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524686288)
    - 1.32.11.5.7  [Training Travel](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524649504)
    - 1.32.11.5.8  [Official IRS Representation at Funerals](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524645616)
  - 1.32.11.6  [Taxable Travel Reimbursement](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524642128)
    - 1.32.11.6.1  [Long-Term Taxable Travel Away From Home](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524635792)
    - 1.32.11.6.2  [Extended TDY Tax Reimbursement Allowance](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524614448)
  - 1.32.11.7  [Arranging for Travel Services, Paying Travel Expenses, and Claiming Reimbursement](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524607248)
    - 1.32.11.7.1  [Arranging for Travel Services](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524604816)
      - 1.32.11.7.1.1  [Personal and Official Travel Combined](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524565200)
    - 1.32.11.7.2  [Fees](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524554736)
    - 1.32.11.7.3  [Profiles](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524548960)
    - 1.32.11.7.4  [Paying Travel Expenses Using the Government Travel Card](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524545104)
    - 1.32.11.7.5  [Paying for Common Carrier Transportation Expenses](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524526336)
    - 1.32.11.7.6  [Travel Advances](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524518176)
    - 1.32.11.7.7  [Claiming Reimbursements](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524489136)
  - 1.32.11.8  [Using Promotional Materials and Frequent Traveler Programs](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524432800)
  - 1.32.11.9  [Death of Employee While in Travel Status](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524427296)
  - 1.32.11.10  [Travel Payments from Other Federal Agencies](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524420896)
  - 1.32.11.11  [Payment of Travel Expenses from a Non-Federal Source](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524411744)
  - 1.32.11.12  [Travel Forms](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524408624)
  - 1.32.11.13  [Delegation Orders (DO)](https://www.irs.gov/irm/part1/irm_01-032-011#idm140508524399664)

# Part 1. Organization, Finance, and Management

# Chapter 32. Servicewide Travel Policies and Procedures

# Section 11. IRS City-to-City Travel Guide

* * *

## 1.32.11 IRS City-to-City Travel Guide

#### Manual Transmittal

January 21, 2025

#### Purpose

(1) This transmits revised IRM 1.32.11, Servicewide Travel Policies and Procedures, IRS City-to-City Travel Guide.

#### Material Changes

(1) 1.32.11.1.3.3, Responsibilities - added section for Commissioner.

(2) 1.32.11.1.3.5, Responsibilities - added section for Associate Chief Financial Officer (CFO) for Corporate Accounting.

(3) 1.32.11.1.3.7 (g) & (h), Travel Management - added (g) and (h) - Approving use of non-US Flag carriers for foreign travel and approving use of premium economy class travel.

(4) 1.32.11.1.3.11, LB&I International Travel Office (ITO) - section added for clarification.

(5) 1.32.11.1.4.2 (1)(d), Program Effectiveness, General Review Items - added parking.

(6) 1.32.11.1.4.2 (f), Program Effectiveness, General Review Items - added (in box 5) and removed requirement to upload Form 15098, Foreign Travel Documentation Checklist, into Electronic Travel System (ETS).

(7) 1.32.11.1.4.2 (a), Program Effectiveness, Subsistence Allowance Claimed - added and Temporary Duty (TDY) location for clarification.

(8) 1.32.11.1.4.2 (a), Program Effectiveness, Miscellaneous Items Claimed - added (POV mileage plus the parking costs) for clarification, per GSA.

(9) 1.32.11.1.6 (u), Terms/Definitions - added definition for General Vicinity - in the area that is close to (a place); the state of being close by; nearness; proximity. Approving official should make the determination based on factors of location, safety, employee needs, accessibility or other factors that may impact the ability to obtain necessary items while in travel status.

(10) 1.32.11.1.6 (ag), Terms/Definitions - added definition for Online Booking Engine (OBE) - electronic online reservation booking engine used for official government travel.

(11) 1.32.11.1.6 (aj), Terms/Definitions - added definition for Same-Day Travel - travel which is outside of the 50-mile radius of the official assigned post of duty (POD), completed within 12 hours or less, and does not include per diem, lodging or air/rail reservations.

(12) 1.32.11.2 (3), General Rules - updated per Executive Order 14057 and Office Management and Budget (OMB) Memo M-24-05 - The approving official must limit the authorization and payment of travel expenses to those that are necessary to accomplish the mission in the most economical and effective manner, in accordance with the policies stated throughout this document. The approving official and employees should always consider less expensive alternatives, including teleconferencing, virtual attendance at meetings or conferences in compliance with OMB Memorandum M-24-05 “Catalyzing Sustainable Transportation Through Federal Travel (issued December 14, 2023) implementing Executive Order (E.O.) 14057, Catalyzing Clean Energy Industries and Jobs through Federal Sustainability. OMB Memo M-24-05 directs Federal agencies to prioritize sustainable transportation options for official travel and lead by example as an organization working toward net-zero emissions operations by 2050.

(13) 1.32.11.2 (6), General Rules - updated for clarification - A city-to-city travel authorization allows for travel outside the 50-mile radius of the official assigned duty station/POD. It may cover up to one year but should be input in 30-day increments and may only include one round-trip.

(14) 1.32.11.2 (21), General Rules - updated for clarification - Per Executive Order 14057 and OMB Memo M-24-06 - Employees should be familiar with subway/trains and bus routes that are available between meetings, lodging, and other locations at which business is to be conducted. When available, employees should use public buses that use alternative fuels, such as electricity or compressed natural gas, rather than gasoline or diesel to reduce Greenhouse Gas (GHG) emissions.

(15) 1.32.11.2 (23), General Rules - added Employees should not incur prepaid expenses. Non-refundable prepaid expenses incurred due to cancelation of official travel are not reimbursable to the employee. For example, prepaid parking, transit pass, tolls, fuel or charging.

(16) 1.32.11.5.1.1 (17)-(19), Airline Accommodations - added Fly America Act requirements.

(17) IRM 1.32.11.5.1.2 (2), Train Accommodations - updated per Executive Order 14057 and OMB Memo M-24 - Employees are encouraged to use rail, particularly when the train uses electric locomotives rather than diesel, resulting in a lower GHG emissions per passenger mile ratio than other methods of transportation when going shorter distances. Specifically, when traveling in the Northeast and Mid-Atlantic regions of the United States, and in countries where regional or international rail is available and is time and cost effective (e.g., in parts of Europe and Asia). Employees are also encouraged to consider rail options, especially for city pairs less than 250 miles apart.

(18) 1.32.11.5.1.4 (2), Rental Car - added requirement to provide reason rental is authorized to either travel to or at a TDY in ETS.

1. No GOV, public transportation or shuttle available;

2. Cost of a rental car is less than other transportation due to distance to/from hotel to TDY and to length of trip;

3. Multiple TDY locations make public transportation less feasible;

4. For security reasons related to agency mission;

5. Traveling with multiple employees, sharing rental vehicle;

6. Transporting government equipment; or

7. Other, please provide details in comment box provided in ETS.


(19) 1.32.11.5.1.4 (3), Rental Car - added This requirement is waived for “same-day” travel completed within 12 hours or less, does not include per diem, lodging, air or rail reservations, per CFO-01-1023-0004, Interim Guidance for Form 15278, Travel Cost Comparison Worksheet, dated October 10, 2023.

(20) 1.32.11.5.1.4 (4), Rental Car - updated per Executive Order 14057 and OMB Memo M-24-05 - added Employees are authorized to rent a zero-emission vehicle (ZEV) when the daily rental rate is equal to or less than the daily rental rate of the least expensive compact car available. If ZEVs are not available, employees should consider renting a hybrid vehicle if the daily rental rate is less than the rental rate of the least expensive compact car available.

(21) 1.32.11.5.1.4 (7), Rental Car - updated per new U.S. Government Rental Car Agreement #5 - Employees must verify Department of the Treasury appears on the rental agreement to ensure compliance with the U.S. Government Rental Car Program #5.

(22) 1.32.11.5.1.4 (8), Rental Car - updated per Executive Order 14057 and OMB Memo M-24-05 - added Employees are also authorized to have alternative fuel charging expenses reimbursed as “fuel,” which is defined in FTR § 300-3.1 as “the energy source needed to power a vehicle,” and includes “petroleum, hydrogen, propane, and electricity.”

(23) 1.32.11.5.1.4 (10), Rental Car - updated per Executive Order 14057 and OMB Memo M-24-05 - added charging and recharging information.

(24) 1.32.11.5.1.4 (12)(13) & (14), Rental Car - added reference to toll transponders.

(25) 1.32.11.5.1.4 (16), Rental Car - updated US Government Rental Car Agreement #5 which was effective April 1, 2024.

(26) 1.32.11.5.1.5 (3), Privately Owned Vehicle (POV) - added Employees performing same-day travel outside of the 50-mile radius of the assigned POD, completed within 12 hours or less, does not include per diem, lodging, air or rail reservation are waived from completing the Form 15278, Travel Cost Comparison Worksheet. The agency has determined that driving a POV is the most advantageous to the government and does not require a cost comparison.

(27) 1.32.11.5.1.5 (4), Privately Owned Vehicle (POV) - added Employees performing multi-day city-to-city travel in exigent or urgent circumstances (e.g., to protect a statute or any other government interest), will be authorized to travel by POV without completing a cost comparison in advance of travel. However, to remain compliant with FTR 301-10, the employee must complete Form 15278, Travel Cost Comparison Worksheet, upon return, which may or may not limit the employee’s reimbursable travel expenses.

(28) 1.32.11.5.1.5 (7), Privately Owned Vehicle (POV) - reworded for clarification - Per Government Services Administration (GSA) POV mileage must also be considered when paying parking at the airport or train station versus the cost of a taxi, Uber/Lyft, etc.

(29) IRM 1.32.11.5.1.6.1 (1), Taxis, Transportation Network Companies (TNCs), Innovative Mobility Technology Companies, Shuttle Services or Other Courtesy Transportation - updated per Executive Order 14057 and OMB Memo M-24-05 - added Employees traveling in groups at the same TDY location are encouraged to share taxis, TNCs, shuttle or courtesy transportation services.

(30) IRM 1.32.11.5.1.6 1 (1)(c), Taxis, TNCs, Innovative Mobility Technology Companies, Shuttle Services or Other Courtesy Transportation - added You must include a statement or electronic remarks with your travel voucher explaining why such transportation was necessary.

(31) IRM 1.32.5.1.6.1 (2), Taxis, TNCs, Innovative Mobility Technology Companies, Shuttle Services or Other Courtesy Transportation - updated per Executive Order 14057 and OMB Memo M-24-05 - added Employees are encouraged to use “green” options available when the ride cost is equal to or less than the most economical economy/compact options available and are within policy.

(32) 1.32.11.5.1.6.1 (3), Taxis, TNCs, Innovative Mobility Technology Companies, Shuttle Services or Other Courtesy Transportation - added (before any discounts are applied) for clarification.

(33) 1.32.11.5.1.6.1 (4), Taxis, TNCs, Innovative Mobility Technology Companies, Shuttle Services or Other Courtesy Transportation - removed (4) as there are now additional fees incurred when using the reservation feature which should only be used when absolutely necessary or in a remote area outside of large metropolitan areas.

(34) IRM 1.32.11.5.2 (5) & (6), Per Diem Expenses - removed and referred to IRM 1.32.1.8, IRS Local Travel Guide, Per Diem Expenses for Local Travel.

(35) IRM 1.32.11.5.2 (7), Per Diem Expenses - added Early check-in, late check-out, cancelation or “no-show” fees will not be approved for employee convenience or for failure to cancel timely. The employee must verify hotel check-in, check-out times and cancelation policies before making reservations and plan to arrive and depart at those established times. Most hotels will hold luggage at no charge with the hotel concierge. Fees incurred may only be claimed when incurred due to business reasons and approved on Form 15299, Travel Approval Request. Employees must attempt to obtain a refund for cancelation or “no-show” fees and provide documentation of refusal to refund with Form 15299.

(36) 1.32.11.5.2.1 (10), Reduced Per Diem - added Employees attending training or a conference in which the IRS has paid a registration fee and meals are included must reduce M&IE based on the meals provided. If you are unable to consume provided meals due to dietary or religious reasons, the M&IE would not be reduced.

(37) 1.32.11.5.3 (4) Miscellaneous Expenses - updated for clarification - Employees may be reimbursed for the first standard checked bag fees charged by the airline, when authorized. The approving official may authorize additional checked or overweight baggage, if it is determined that additional or overweight baggage is needed for official reasons. Employees must provide a justification in ETS when the baggage expense exceeds $50. Tips at transportation terminals for handling Government property carried by the employee are reimbursable. Tips for personal baggage are not reimbursable.

(38) 1.32.11.5.3 (6) Miscellaneous Expenses - added Outside the Continental United States (OCONUS) for clarification.

(39) 1.32.11.5.4.1 (2), Travel of an Employee with Special Needs - added to include the lactation program, for clarification.

(40) 1.32.11.5.5 (3) - (9), Foreign Travel - updated (3) to read Employees who request approval for foreign travel must follow the procedures in IRM 1.32.5, International Travel Office Procedures and the LB&I International Travel Office sharepoint site and removed (4) - (9).

(41) 1.32.11.5.5 (4), Foreign Travel - added Employees will work with the TMC to make all travel arrangements, including flight, rail, hotel and rental car (if applicable), when booked outside of ETS. See exceptions in IRM 1.32.11.7.1 (4) and (6), Arranging for Travel Services, for clarification.

(42) 1.32.11.5.5 (11), Foreign Travel - added Lodging tax is included in the daily lodging rate and may not be claimed separately for foreign travel, for clarification.

(43) 1.32.11.5.6 (16), Invitational Travel - corrected email address to \*CFO BFC Travel Vouchers (cfo.bfc.travel.vouchers@irs.gov).

(44) 1.32.11.7 (1), Arranging for Travel Services, Paying Travel Expenses, and Claiming Reimbursement - added reference for Federal Travel Regulation (FTR) 301-10.110, Use of Contract City Pair Program Fares.

(45) 1.32.11.7.1 (5)(a-d), Arranging for Travel Services - added (4) (a-d) for clarification, Employees must use a contract City Pair Program fare for scheduled air passenger transportation service when one is available unless one of the limited exceptions exists, see FTR 301-10.110.

(46) 1.32.11.7.1 (9), Arranging for Travel Services - changed 30 days to 30 nights for clarification.

(47) 1.32.11.7.1 (9)(a), Arranging for Travel Services - updated approval level to the Associate CFO for Corporate Accounting and added requirement to use GSA vendors.

(48) 1.32.11.7.1.1, Personal and Official Travel Combined - updated wording per Counsel request to be more consistent with FTR.

(49) 1.32.11.7.1.1 (9), Personal and Official Travel Combined added Employees combining personal with official international travel must also refer to IRM 1.32.5.2 (8), Responsibilities of International Travelers for further restrictions.

(50) This revision includes changes throughout the document for the following:

1. Updated the CFO office names and responsibilities due to 2023 reorganization;

2. Added minor editorial changes to include grammar, spelling and minor changes for clarification purposes;

3. Replaced Duluth Travel Incorporated (DTI), Duluth Travel with Travel Management Center (TMC), and ConcurGov with Electronic Travel System (ETS) throughout IRM;

4. Updated links throughout the IRM; and

5. Corrected references throughout the IRM.


#### Effect on Other Documents

IRM 1.32.11, Official IRS City-to-City Travel Guide, March 28, 2023, is superseded. This IRM incorporates Re-Issued Interim Guidance Memorandum CFO-01-0924-0002, Re-Issued Interim Guidance for Form 15278, Cost Comparison Worksheet Requirements, dated October 6, 2024; Executive Order 14057, Catalyzing Clean Energy Industries and Jobs through Federal Sustainability; OMB Memo M-24-05, Catalyzing Sustainable Transportation Through Federal Travel; and US Government Rental Car Agreement #5.

#### Audience

All business units

#### Effective Date

(01-21-2025)

Teresa R. Hunter

Chief Financial Officer

**1.32.11.1** **(03-28-2023)**

### Program Scope and Objectives

1. **Purpose:** This IRM provides the IRS policies and procedures for city-to-city travel, including domestic, foreign, invitational and emergency travel. It uses the term city-to-city and temporary duty travel (TDY) interchangeably.

2. **Audience:** All business units

3. **Policy Owner:** CFO, Financial Management

4. **Program Owner:** The CFO, Financial Management, Travel Management develops and maintains this IRM.

5. **Primary Stakeholders:** The primary stakeholders are employees who perform or approve city-to-city travel, including domestic, foreign, invitational and emergency travel in the interest of the government for the IRS.

6. **Program Goal:** The goal of this IRM is to ensure that IRS employees comply with the IRS policy for city-to-city travel, including domestic, foreign, invitational and emergency travel.


**1.32.11.1.1** **(07-02-2019)**

#### Background

1. The General Services Administration (GSA) is responsible for establishing governmentwide temporary duty travel (TDY) policies and procedures through the Federal Travel Regulation (FTR). The FTR is the governing document for temporary duty travel and transportation allowances for all IRS employees. This IRM supplements the FTR by providing IRS specific policies and procedures where needed.

2. Local and relocation travel is not covered in this IRM. The IRS policy regarding local travel and relocation are covered in IRM 1.32.1, IRS Local Travel Guide and IRM 1.32.12, IRS Relocation Travel Guide. In 2010, GSA amended the FTR to clarify that it covers only temporary duty travel, not local travel.


**1.32.11.1.2** **(07-02-2019)**

#### Authorities

01. 5 U.S. Code Section 5701-5711, [Regulations and Reports](https://www.govinfo.gov/app/details/USCODE-2011-title5/USCODE-2011-title5-partIII-subpartD-chap57-subchapI-sec5707)

02. 5 U.S. Code Section 5738, [Regulations](https://www.govinfo.gov/app/details/USCODE-2022-title5/USCODE-2022-title5-partIII-subpartD-chap57-subchapII-sec5738)

03. 31 U.S. Code Section 901, [Establishment of agency Chief Financial Officers](https://www.govinfo.gov/app/details/USCODE-2022-title31/USCODE-2022-title31-subtitleI-chap9-sec901)

04. 31 U.S. Code 902, [Authority and Functions of agency Chief Financial Officers](https://www.govinfo.gov/app/details/USCODE-2022-title31/USCODE-2022-title31-subtitleI-chap9-sec902)

05. 31 U.S. Code Section 903, [Establishment of agency Deputy Chief Financial Officers](https://www.govinfo.gov/app/details/USCODE-2022-title31/USCODE-2022-title31-subtitleI-chap9-sec903)

06. 31 U.S. Code Section 3711, [Collection and Compromise](https://www.govinfo.gov/app/details/USCODE-2022-title31/USCODE-2022-title31-subtitleIII-chap37-subchapII-sec3711)

07. 31 U.S. Code Section 3726, [Payment for Transportation](https://www.govinfo.gov/app/details/USCODE-2022-title31/USCODE-2022-title31-subtitleIII-chap37-subchapIII-sec3726)

08. 49 U.S. Code Section 40118, [Government-Financed Air Transportation](https://www.govinfo.gov/app/details/USCODE-2022-title49/USCODE-2022-title49-subtitleVII-partA-subparti-chap401-sec40118)

09. Title 41, CFR Chapters 300-304, [Federal Travel Regulation](https://www.ecfr.gov/current/title-41/subtitle-F)

10. [Department of the Treasury Directives](https://home.treasury.gov/about/general-information/orders-and-directives/numerical-index-of-treasury-directives)

11. [Revenue Ruling 93-86](https://www.taxnotes.com/research/federal/irs-private-rulings/information-letters/irs-addresses-taxation-of-per-diem-reimbursements/29c7s)

12. OMB memo M-24-05, [Catalyzing Sustainable Transportation Through Federal Travel](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&ved=2ahUKEwjG3-mS-_GHAxXBweYEHaQFJQQQFnoECAgQAQ&url=https%3A%2F%2Fwww.whitehouse.gov%2Fwp-content%2Fuploads%2F2023%2F12%2FM-24-05-Catalyzing-Sustainable-Transportation-Through-Federal-Travel.pdf&usg=AOvVaw0VeB2IvNUD8p9rLHg7mVIh&opi=89978449)


**1.32.11.1.3** **(11-04-2021)**

#### Responsibilities

1. This section provides responsibilities for the following:



01. Approving Officials

02. Employees

03. Commissioner

04. CFO and Deputy CFO

05. Senior Associate CFO Financial Management

06. Associate CFO for Corporate Accounting

07. Travel Management

08. Travel Review

09. Travel Services

10. Travel Operations


**1.32.11.1.3.1** **(11-04-2021)**

##### Approving Officials

1. The approving official is responsible for:



01. Completing mandatory travel policy training every two years.

02. Providing employees with access and the opportunity to review the material in this guide and any other travel regulations prior to traveling.

03. Answering questions that an employee may have about the content of this guide or related travel matters.

04. Providing employees who are expected to travel with information on how to apply for a government travel card.

05. Planning travel to ensure that employees' time and travel funds are used in the most efficient and economical manner.

06. Directing employees' attention to possible travel savings.

07. Planning travel so employees do not incur personal expenses for properly authorized travel.

08. Reviewing and approving travel authorizations and vouchers to ensure expenses and accounting information are correct.

09. Verifying the approval of any special travel requirements (such as first-class or business-class travel) before approving an authorization or a voucher.

10. Approving travel authorizations at least four business days prior to the actual travel dates.

11. Ensuring travel expenses are authorized under travel policy. The IRS cannot reimburse an employee for inappropriate expenses incurred from having received incorrect guidance.

12. Ensuring required receipts and supporting documentation are scanned or faxed into the Electronic Travel System (ETS) or attached to the manual vouchers.

13. Reconciling receipts and supporting documentation against the expenses claimed on the voucher before approving.

14. Maintaining copies of approved travel authorizations and supporting documentation for manual vouchers in compliance with General Records Schedule (GRS) 1.1, item 010 Financial Transaction Records Related to Procuring Goods and Services, Paying Bills, Collecting Debts, and Accounting, for records retention authorized disposition.

15. Reviewing advances to ensure that they are appropriate for expected travel requirements.

16. Ensuring that employees who are either transferring or separating have repaid outstanding travel advances.

17. Ensuring that travelers submit travel vouchers within five working days after completing their travel.

18. Approving or returning a travel voucher within seven calendar days of submission (to ensure payment within 30 calendar days of submission).

19. Ensuring that advances are liquidated on the vouchers.

20. Verifying that employees who request use of a non-contract carrier qualify to do so under the FTR.

21. Ensuring that employees do not claim any unauthorized expenses, such as resorts, villas, spas, country clubs and time shares.

22. Ensuring reporting instructions are attached if purpose code "T" is used, when applicable.


2. Delegation Order 1-30, Authorization and Approval of Official Travel within the United States, identifies the appropriate IRS officials with the delegated authority to direct travel. This authority has been delegated to managers and may be redelegated to a level no lower than management official. However, all executives that report directly to the Commissioner must have their travel authorizations and vouchers routed to Executive Services for approval.


**1.32.11.1.3.2** **(11-04-2021)**

##### Employees

1. The employee is responsible for:



01. Completing mandatory travel policy training every two years.

02. Performing official travel within the guidance of travel policies, regulations and procedures.

03. Requesting clarification on any travel policies, regulations and procedures that are not understood.

04. Planning travel to minimize travel cost to the IRS.

05. Exercising the same prudence and economy when incurring expenses in the performance of official travel that a prudent person would exercise if traveling on personal business.

06. Submitting a travel authorization at least five business days before traveling and incurring travel expenses.

07. Paying all charges and fees associated with the government travel card by the due date on the invoice. Employees are liable for all charges and will not be reimbursed above maximum levels prescribed by law.

08. Using the mode of transportation that results in the greatest overall advantage to the government.

09. Using the government travel card for official travel including transportation expenses (bus, streetcar, transit system), automobile rentals and other major travel-related expenses to include fuel for a privately owned vehicle (POV).

10. Canceling unused travel authorizations.

11. Submitting a travel voucher within five working days after completing travel and ensuring claimed travel expenses are correct. The IRS cannot reimburse an employee for inappropriate expenses incurred from having received incorrect guidance.

12. Liquidating a travel advance on a voucher or submitting a check to Travel Operations.

13. Accounting for travel advances received and repaying any advances that are not liquidated by travel expenses. Employees are indebted to the government for advances.

14. Paying additional expenses resulting from scheduling travel for personal convenience and charging excess travel time against leave.

15. Not delaying the performance of official travel for personal reasons.

16. Not claiming personal expenses on travel vouchers.

17. Ensuring required receipts and supporting documentation are scanned, faxed or uploaded into the ETS or attached to the manual voucher.

18. Ensuring any outstanding advances are repaid if the employee is separating from the service.

19. Ensuring approval is obtained prior to incurring any expenses that require advance approval. For example: non-contract carriers, premium-class travel, non-conventional lodging, etc.

20. Not claiming any unauthorized expenses, such as resorts, villas, spas, country clubs or time shares.

21. Acknowledging that they have read and understand the following truth and accuracy statement before signing their voucher: “I certify that this voucher is true and correct to the best of my knowledge and belief, and that payment or credit has not been received by me.”


**1.32.11.1.3.3** **(01-21-2025)**

##### Commissioner

1. The Commissioner is responsible for:



1. Reviewing travel reports during periods of restricted travel due to national emergencies, pandemics, etc.

2. Reviewing, denying and approving first-class travel requests. In the case where the Commissioner needs to obtain approval for first-class accommodations request must be submitted to the Deputy Commissioner or Chief of Staff for review and approval or denial.


**1.32.11.1.3.4** **(07-02-2019)**

##### CFO and Deputy CFO

1. The CFO and Deputy CFO are responsible for:



1. Overseeing policies, procedures, standards, and controls for the IRS financial processes and systems.

2. Ensuring the IRS financial management activities are compliant with laws and regulations.

3. Reviewing, denying and approving business-class travel requests.

4. Reviewing and submitting first-class travel requests to the Commissioner for denial or approval of requests.


**1.32.11.1.3.5** **(07-02-2019)**

##### Senior Associate CFO Financial Management

1. The Senior Associate CFO Financial Management is responsible for:



1. Reviewing, denying and approving premium-economy class seating.

2. Reviewing all requests which require higher level approval.


**1.32.11.1.3.6** **(01-21-2025)**

##### Associate CFO for Corporate Accounting

1. The Associate CFO for Corporate Accounting is responsible for:



1. Establishing, maintaining, and ensuring compliance with temporary duty travel policy and procedures for internal accounting operations and financial reporting.

2. Approving non-conventional lodging requests.

3. Reviewing all requests which require higher level approval.


**1.32.11.1.3.7** **(01-21-2025)**

##### Travel Management

1. Travel Management is responsible for:



1. Developing and issuing IRS temporary duty travel policy.

2. Approving exemptions to using (ETS).

3. Reviewing financial policies and procedures for compliance with financial laws and regulations.

4. Approving reduced per diem rates.

5. Approving exceptions to the required distance traveled for receiving per diem.

6. Reviewing and submitting business/first-class travel requests to CFO for further review and routing to required level for denial or approval of requests.

7. Approving use of non-US Flag carriers for foreign travel.

8. Approving use of preferred seats, which incur an additional fee, in economy class.


**1.32.11.1.3.8** **(01-21-2025)**

##### Travel Review

1. Travel Review is responsible for:



01. Educating customers on travel policy, FTR, ETS and travel procedures.

02. Reviewing travel course materials used when Travel Services conducts travel workshops and customer outreach to ensure traveler compliance with regulations and travel policy.

03. Authoring travel IRMs, delegation orders, travel guidance, and travel forms.

04. Developing, administering and managing mandatory travel training in Integrated Talent Management (ITM).

05. Developing travel communications.

06. Performing travel compliance reviews on travel documents and referring employees with two or more repeated violations, within twelve months, of the FTR and/or IRS travel policies or potential fraudulent transactions to Labor Employee Relations and Negotiation (LERN) for further determination of disciplinary action.

07. Performing 100% review of all vouchers and receipts related to gainsharing awards, F13631-A, IRS Travel Savings, before award processing.

08. Conducting quarterly analysis on audit findings and creating scorecards for each business unit.

09. Performing eTravel post audit reviews of executive travel vouchers.

10. Monitoring and conducting quarterly reviews of travel in excess of 30 days to ensure per diem reduction and long-Term Taxable Travel (LTTT) for all travelers to determine if travel is to a single location. Review to determine if there appears to be excessive travel to a single location and should be reported as LTTT and reviewing executive travel for potential LTTT.

11. Managing the Travel Management Center (TMC) contract.


**1.32.11.1.3.9** **(11-04-2021)**

##### Travel Services

1. Travel Services is responsible for:



1. Providing help desk services for users and authorizing officials.

2. Administering the ETS, a web-based end-to-end travel system.

3. Interpreting federal policies and procedures.

4. Communicating travel related information.

5. Serving as the Federal Agency Travel Administrator (FATA).

6. Updating training material to conduct quarterly travel workshops to continue travel education.

7. Performing eTravel post audit reviews of local travel vouchers.


**1.32.11.1.3.10** **(07-02-2019)**

##### Travel Operations

1. Travel Operations is responsible for:



1. Reviewing and processing manual travel authorizations and vouchers.

2. Processing Extended TDY Tax Reimbursement Allowance (ETTRA) reimbursement.

3. Processing travel reclassifications identified by Travel Review.

4. Performing eTravel post audit reviews of city-to-city and foreign travel vouchers.

5. Educating travelers on established travel policy, Federal Travel Regulations (FTR) and travel procedures.

6. Providing customer service for vouchers reviews.


**1.32.11.1.3.11** **(01-21-2025)**

##### LB&I, International Travel Office (ITO)

1. The International Travel Office (ITO) responsibilities include but are not limited to:



1. Providing completed and approved international travel documents to all IRS international travelers with the exception of Chief Counsel Employees. Chief Counsel employees traveling internationally must follow Chief Counsel guidelines for international travel. See IRM 1.2.2.2.8, Delegation Order 1-8, Approval of Foreign Travel.

2. Obtaining, renewing and tracking official and diplomatic passports.

3. Providing guidance to employees for passports, visas and other international travel related information.

4. Taking passport and visa photos for travelers located in the Washington, DC metro area.

5. Processing visa requests.

6. Coordinating with the courier service for passport and visa delivery to foreign embassies and the Department of State.

7. Obtaining approvals from the Department of State for eCC requests.

8. Updating the Passport Tracker system (see IRM 1.32.5.1.5, Program Controls)


NOTE: See IRM 1.32.5, International Travel Office Procedures and Chief Counsel Directives Manual (CCMD) 30.5.2.5.



**1.32.11.1.4** **(11-04-2021)**

#### Program Management and Review

1. The CFO is required to report all travel and transportation payments of more than $5 million during the fiscal year to GSA.

2. The travel reports include a list of data elements and report formats provided by GSA. The data must be submitted to GSA by November 30 and GSA must issue a government-wide report by January 31 to OMB and Congress to be available to the public.


**1.32.11.1.4.1** **(11-04-2021)**

##### Program Reports

1. The IRS completes the following reports and submits them to the Department of the Treasury annually:



1. Premium-class travel.

2. Travel Reporting Information Profile (TRIP) report.

3. Acceptance of Travel from a Non-Federal Source (submitted every 6 months).

4. Travel by Senior Federal and non-Federal Travelers on Government Aircraft.


**1.32.11.1.4.2** **(01-21-2025)**

##### Program Effectiveness

1. The IRS ensures program effectiveness for travel authorizations and vouchers through this process:




| City-to-City & Foreign Post Audit Review-Current Process |
| :-: |
| An ETS post payment review analysis is conducted every quarter. A percentage of vouchers are pulled from a report based on a random sampling formula for all vouchers. A 100% review is conducted on all foreign and executive travel. The percentage is subject to change based on workload, staffing and volume. |
| General Review Items:<br> <br>1. Travel was performed from Post of Duty (POD) to TDY and return trip is to POD.<br>      <br>2. Correct TDY location was used on voucher to ensure correct per diem was calculated.<br>      <br>3. All expenses are within travel period.<br>      <br>4. Receipts are provided for all transportation expenses (air, rail, rental car (including fuel), baggage and parking (more than $25 cummulative), emergency expenses and all expenses over $75.00.<br>      <br>5. A Travel Cost Comparison worksheet, is provided when applicable, see travel cost comparison section below.<br>      <br>6. Foreign travel has a signed Form 1321 (in box 5) and uploaded into ETS.<br>      <br>7. Reporting instructions are uploaded into ETS for all travel that has a purpose code of "T" for training travel.<br>      <br>8. Reservation fees are claimed and receipt provided.<br>      <br>9. All late authorizations require an email to the approving official and traveler. |
| Subsistence Allowances Claimed:<br> <br>1. Correct amount for meals and incidental expenses (M&IE) according to travel dates and TDY location.<br>      <br>2. Three-fourths (3/4) of M&IE applied on travel days.<br>      <br>3. No M&IE claimed on authorized leave days. |
| Subsistence Allowances Claimed for Lodging:<br> <br>1. Lodging was booked in ETS or with TMC unless an exception to booking in ETS or with TMC is documented.<br>      <br>2. Lodging daily rate claimed does not exceed per diem amount for location.<br>      <br>3. Expenses on voucher match amount on receipts for lodging and lodging taxes.<br>      <br>4. Actual lodging has been authorized by a first-line executive if daily rate claimed is over per diem amount.<br>      <br>5. Approval for any non-conventional (see definition IRM 1.32.11.1.6(ad)) lodging is uploaded into ETS.<br>      <br>6. Receipt from lodging facility and Travel Management Center (TMC) invoice is uploaded into ETS.<br>      <br>7. If actual expenses are not authorized and lodging exceeds per diem amount, then lodging taxes are prorated to equal the same percentage of the per diem amount compared to the actual lodging costs.<br>      <br>8. Government credit card (GOVCC) is used for required expenses. |
| Transportation Expenses Claimed for Airfare/Train Transportation:<br> <br>1. Receipt (TMC invoice) is uploaded into ETS - (Missing, the auditor gets it from the traveler, and adds it to the audit file and uploads it into ETS).<br>      <br>2. Verify amount expensed on voucher matches amount charged on receipt.<br>      <br>3. Review for business-class, first-class or premium economy class flights and ensure proper authorization was obtained.<br>      <br>4. Reservations were made through ETS or TMC or a waiver was approved from the Travel Management to obtain airfare outside of ETS or TMC.<br>      <br>5. GOVCC or CBA is used for all air or train fare expenses.<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      Personal funds, including credit or debit cards, may only be used for round-trip fares equal to or less than $100. If personal funds are used for round-trip fares exceeding $100, Travel Management approval is required to claim expense. |
| Transportation Expenses Claimed for POV Transportation:<br> <br>1. Check expenses tab in ETS to validate mileage claimed.<br>      <br>2. Verify mileage if expense appears high or excessive. |
| Rental Car Expenses Claimed:<br> <br>1. GOVCC is used for expenses, including fuel.<br>      <br>2. Receipt attached in ETS, including fuel receipt regardless of dollar amount.<br>      <br>3. No expenses were included for collision damage waiver, or theft insurance for personal accident. (Codes on receipts generally reflect CDW, PAI or LDW).<br>      <br>4. Dates of rental match dates of travel. Prorate if rental is used for personal use and not official business. |
| Air Baggage Fees Claimed:<br> <br>1. GOVCC used for expenses.<br>      <br>2. Baggage claim expenses included for both departure flights and arrival flights.<br>      <br>3. Justification is provided for excessive baggage (more than 1 bag and/or overweight) claim amounts. Approving official may authorize additional check baggage or overweight claims, if it is determined necessary for official reasons.<br>      <br>4. Receipts are uploaded regardless of dollar amount. |
| Miscellaneous Items Claimed:<br> <br>1. Airport parking (expenses (POV mileage plus the parking costs) do not exceed the cost of round-trip taxi fare).<br>      <br>2. Ensure transportation is not via limousine or luxury transportation services.<br>      <br>3. Laundry expenses are only authorized for TDY four or more consecutive nights lodging and receipt attached or coin-operated facility notated.<br>      <br>4. Laundry expenses for Non-Foreign (Outside Continental United States) OCONUS and territories and all foreign OCONUS travel are not reimbursable.<br>      <br>5. Ensure receipts are provided for parking expenses in excess of $25, to include cumulative parking (example: daily airport parking of $20 per day for 5 days equals $100, a receipt is required).<br>      <br>6. Ensure excessive expenses have a justification.<br>      <br>7. Ensure baggage tips at the airport are not on a voucher.<br>      <br>8. Ensure emergency or unusual miscellaneous expenses are justified and receipt attached.<br>      <br>9. Ensure investigative and/or administrative expenses are justified and receipt attached. Receipts may be redacted if necessary. If unable to redact receipt, a justification must be provided. Claims over $300 for a single day must be submitted on a SF1034, Public Voucher for Purchases and Services Other Than Personal. Additional information on Employee Reimbursables is available in IRM 1.35.3.5.2.9. NOTE: An employee should not give any additional description or explanation of the incidental expenditure on the travel voucher nor should related receipts or memoranda be attached. |
| Mandatory Use of the GOVCC:<br> <br>1. Ensure all required travel expenses were paid with the GOVCC.<br>      <br>2. If the traveler did not use the GOVCC, ensure a waiver was obtained per Delegation Order 1-49, Exemption to Travel Card Mandatory Use Policy. |
| Travel Cost Comparison worksheet (actual and constructive):<br> <br>1. Required if mode of transportation is other than what is normally authorized.<br>      <br>2. Required for voluntary trips home.<br>      <br>3. Required for official travel combined with personal travel.<br>      <br>4. Required for use of POV.<br>      <br>5. Required documentation to be uploaded into ETS includes:<br>      <br>      <br>      <br>      - Backup documentation such as airfare/train travel quotes (ETS screen shots,TMC reservation)<br>        <br>      - Baggage fees (airline website)<br>        <br>      - Taxi fare estimates (http://www.taxifarefinder.com)<br>        <br>      - Airport and/or hotel parking (airport/hotel websites)<br>        <br>      - Rental car quotes (ETS screen shots)<br>        <br>      - Rental car fuel and/or tolls<br>        <br>      - Mileage estimates (Googlemaps or Mapquest) |
| Referrals to Labor/Employee Relations and Negotiations (LERN):<br> <br>1. Employees’ audit errors with 1) two or more repeated violations of the Federal Travel Regulations (FTR) and/or mandatory IRS travel policy, or 2) fraudulent claims (within a 12 month period), will be put into the Alerts system and referred to Labor/Employee Relations and Negotiations for further determination of disciplinary action. |

2. LTTT Reviews-Current Process



1. Quarterly Potential LTTT review for both executives and non-executives to determine if travel is to a single location.

2. In-depth review and analysis for travelers that appear to be traveling excessively to a single location and possibly should be filing their travel as LTTT.

3. Review all executives travel for potential LTTT and 75 nights or more of travel when asked by the CFO.


**1.32.11.1.5** **(03-28-2023)**

#### Program Controls

1. The following chart below describes internal controls in place for the city-to-city travel program:




| **Area of Concern** | **Control Method** |
| --- | --- |
| Delegation of Authority | Authority to approve critical travel processes is delegated to the appropriate level in the business units and is documented. |
| Training | Training is required to obtain and maintain access to ETS, and refresher training is required every 2 years. |
| ETS Access | User Profiles for ETS access are appropriate for the requirements of the job. |
| Separation of Duties | Separate roles are established for preparers, reviewers, approvers and Federal Agency Travel Administrators. |
| Approving Official | This IRM contains a complete description of the travel approving official’s responsibilities when directing travel and authorizing payments for reimbursement of travel expenses. |
| ETS Quality Reviews | Travel Operations conducts post payment audits quarterly. |
| ETS Data Security | Sensitive information is protected from unauthorized access. |
| Foreign Travel | Travel Operations audits 100% of all foreign travel vouchers quarterly. |
| Manual Quality Reviews | Travel Operations audits 100% of all manual vouchers prior to paying. |
| Funding Requirements | Travel obligations must be submitted before travel to cover anticipated travel expenses. |
| Travel Advances | Advances cannot be issued to cover transportation costs. In ETS the controls for advances are as follows:<br> Standard cardholders cannot get travel advances since they have automated teller machine (ATM) withdrawal access.<br> Invitational travelers or interns cannot get travel advances.<br> Restricted cardholders can get up to 40% of all reimbursable expenses, except transportation costs.<br> Only one advance is allowed per authorization.<br> Non-cardholders can get 100% of all advance for reimbursable expenses. |
| Liquidation of Travel Advances | Advances are liquidated with each travel voucher. If the traveler does not file a voucher timely, the deobligation utility will convert the advance to a debt for the traveler. |
| Lodging Cost | Itemized lodging receipts and TMC invoice, regardless of the amount, must be submitted as supporting documentation. |
| Transportation Cost | TMC invoices (not ETS itinerary), regardless of amount, must be submitted as supporting documentation. Documentation must include: (1) traveler’s name, (2) origin and destination along with any stopover points, (3) class of service, (4) fare cost, (5) payment method and (6) fees incurred. |
| Pre-Audit Flags | Pre-audit flags in ETS have been identified for items that exceed the IRS’s standard policy and the traveler is required to provide a justification to the approving official to explain any unusual request. |
| Actual Expenses | Actual subsistence for lodging and/or M&IE must be authorized in advance. |
| Mandatory Use of the Government Travel Card | All employees are required to obtain and use the travel card for required travel expenses unless they qualify for an exemption as outlined in IRM 1.32.4.2.1.1 |
| Use of Personal Funds | Use of cash or personal funds over $100 for round-trip transportation fare, requires approval by Travel Management, which must be attached to the voucher, and there must be a statement on the travel voucher describing the circumstances. |
| Travel Vouchers | All vouchers must be signed by the traveler and approved by the traveler’s manager or approving official. |
| Prompt Pay Interest | Email notifications are sent to the approving officials to notify them that a voucher is waiting their approval immediately after the traveler signs the voucher. |
| Travel Reports | Employees can only view documents related to the org code or group for which they have a user role of approver, preparer or reviewer. |
| Separated Employees | Employees are automatically deleted from the system based on a file received from HCO. |
| Non-IRS Employees | Non-IRS employees may not use the IRS’s travel system. |


**1.32.11.1.6** **(01-21-2025)**

#### Terms/Definitions

1. This section provides the IRS terms to supplement the FTR, Chapter 300, Part 300-3, [Glossary of Terms](https://www.ecfr.gov/current/title-41/subtitle-F/chapter-300/subchapter-A/part-300-3?toc=1)

2. The following terms and definitions apply to this program:



01. **Accounting Label** \-\- The short name for the IRS’s ETS accounting codes.

02. **Approving Official** \-\- The manager or management official authorized to approve travel authorizations and vouchers in accordance with Servicewide travel-related Delegation Orders. The approving official should be a grade level equal to or higher than those whose documents they are approving.

03. **Attendant** \-\- An individual who provides personal care and travels with an authorized IRS traveler who has a disability or special need.

04. **Automatic Teller Machine (ATM) Travel Advance** \-\- Cash from an ATM that is only authorized for expenses while on official IRS travel that cannot be charged to the government travel card.

05. **Centrally Billed Account (CBA)** \-\- A corporate travel card account set up for IRS travelers and invitational travelers who do not have an individually billed travel card to use for official IRS travel expenses (airline and train tickets).

06. **City-to-City** \-\- A form of travel to a place, away from an employee's official assigned duty station (outside the 50 mile radius), to which the employee is authorized to travel, which may involve an overnight stay or lodging expense.

07. **Commuting area** \-\- For per diem purposes only, is defined as the area within a 50 mile radius of the employee’s residence **and** official assigned duty station.

08. **Conditional Routing** \-\- The electronic routing of the IRS's ETS authorizations that require special approval by an appropriate IRS official.

09. **Concur Government Edition Reservation Fee (CGE)** \-\- A vendor fee that will auto-populate in a document when reservations are booked through Concur or by contacting the TMC directly.

10. **Concur Government Edition Voucher Fee (CGE) --** The charge or fee assessed for processing a travel voucher in ETS.

11. **Contract City-Pair Fare** \-\- An airline transportation fare negotiated under contract by GSA. The fare is fully refundable and exchangeable, and reserved for government travel.

12. **Constructive Cost** \-\- The estimated cost of travel by an alternate mode that is compared to the standard or authorized mode of travel to determine the best way for travel to be performed. When a traveler chooses a mode of travel other than the standard or authorized mode, the traveler is reimbursed for the constructive cost of travel or the actual cost, whichever is less.

13. **Digital Signature** \-\- An electronic "signature" used to indicate that an individual has certified or approved the information on the document.

14. **Electronic Travel System (ETS)** \-\- A government-contracted computer application and database that provides IRS travelers with automated travel planning and reimbursement capabilities. The ETS includes authorization, reservation and vouchering capabilities for domestic and foreign city-to-city and local travel.

15. **Employee** \-\- An individual serving in the IRS in the usually accepted employer-employee relationship. Under limited circumstances and authority, employee also refers to individuals employed as experts or consultants paid on a daily when-actually-employed (WAE) basis or serve without pay or are paid $1 a year. Such persons are not considered to have a ‘‘permanent duty station” or “official assigned duty station/POD”: within the general meaning of that term, but they are entitled to travel and transportation expenses while away from their homes or regular places of business.

16. **E-ticket**\-\- An electronic ticket allowing travel without a paper ticket.

17. **Extended TDY Income Tax Reimbursement Allowance (ETTRA)** \-\- An allowance designed to reimburse employees for federal, state, and local income taxes incurred because of an extended temporary duty (TDY) assignment at one location and long-term assignments.

18. **Federal Agency Travel Administrator (FATA)** \-\- The individual responsible for managing ETS at the organization level. A FATA may serve as a systems administrator, a resource manager, or an administrator responsible for loading, updating, and maintaining the ETS tables.

19. **Federal Insurance Contributions Act (FICA) Tax** \-\- A payroll tax or employment tax imposed by the federal government on both employees and employers to fund Social Security and Medicare.

20. **First Level Executive** \-\- The lowest level executive within a business unit or operating division.

21. **General Vicinity** \-\- In the area that is close to (a place); the state of being close by; nearness; proximity. The Approving official should make the determination based on factors of location, safety, employee needs, accessibility or other factors that may impact the ability to obtain necessary items while in travel status.

22. **Government travel card** \-\- A government contractor-issued card used by employees to pay for official travel expenses such as transportation, lodging, meals, baggage fees, rental cars and rental car fuel/oils, for which the contractor bills the employee.

23. **Government Owned Vehicle (GOV)** \-\- An automobile (or light truck, including vans and pickup trucks) that is:


        1\. Owned by an agency,


        2\. Assigned or dispatched to an agency from the GSA Interagency Fleet Management System, or


        3\. Leased by the government for a period of 60 days or longer from a commercial source.

24. **Head of office** \-\- Any of the following IRS officials: Commissioner; Deputy Commissioner; Division Commissioners; Chiefs; Chief Counsel; directors reporting directly to the Commissioner or a Deputy Commissioner; and National Taxpayer Advocate and their deputies.

25. **Innovative mobility technology company** \-\- An organization, including a corporation, limited liability company, partnership, sole proprietorship or any other entity, that applies technology to expand and enhance available transportation choices, better manages demand for transportation services, or provides alternatives to driving alone. Examples: Car2Go, Lime or Bird.

26. **Invitational traveler** \-\- Travel performed by non-Federal Government employees, including contractors, who are acting in a capacity directly related to official activities of the IRS. Reimbursement for travel by non-Federal Government employees is subject to the same regulations as travel by IRS employees.

27. **Line of Accounting (LOA)** \-\- A set of accounting codes that determines the fiscal year, appropriation code, activity, cost center, source code, functional area, fund, purpose, program/project field, and internal order used to finance travel.

28. **Local travel** \-\- Travel within a 50-mile radius of the employee’s officially assigned duty station which is completed within one day and does not require any air, rail or lodging expenses.

29. **Management official** \-\- An IRS employee with duties and responsibilities requiring or authorizing the individual to formulate, determine, or influence IRS policies. In addition, the individual must be a non-bargaining employee and performing commitments under Form 12450A, Manager Performance Agreement, Form 12450B, Management Official Performance Agreement or Form 12450D Management Program Analyst Performance Agreement.

30. **Non-conventional lodging** \-\- Any lodging that is not a traditional hotel/motel type facility which includes but is not limited to home-sharing rentals, Vacation Rental By Owner (VRBO), Airbnb, long-term apartment, condominium, private home or recreational vehicle (RV).

31. **Official Station** \- The location where employees regularly perform their duties or an invitational traveler's home or regular place of business. The geographic limits of the official station are the corporate limits of the city or town where the employee is located, or, if not in an incorporated city or town, the reservation, station or other established area having definite boundaries where the employee is located, not to exceed 50-miles from the building or street where the employee is normally assigned. If the employee’s work involves recurring travel or varies on a recurring basis, the location where the work activities of the employee's position of record are based is considered the regular place of work.

32. **Official assigned duty station/Post of Duty (POD)** \-\- The specific building address of record the employee is permanently assigned, where the employee regularly performs their duties or an invitational traveler's home or regular place of business (see **§ 301-1.1**).

33. **Online Booking Engine (OBE)** \-\- Electronic online reservation booking engine used for official government travel.

34. **Per Diem Allowance** \-\- The per diem allowance (also referred to as subsistence allowance) is a daily payment instead of reimbursement for actual expenses for lodging, meals, and related incidental expenses. The per diem allowance is separate from transportation expenses and other miscellaneous expenses. The per diem allowance covers all charges and services, including any service charges where applicable. Lodging taxes in the United States are excluded from the per diem allowance and are reimbursed as a miscellaneous expense. In foreign locations, lodging taxes are part of the per diem allowance and are not a miscellaneous expense. The per diem allowance covers the following:




        1\. Lodging - Includes expenses, except lodging taxes in the United States, for overnight sleeping facilities, baths, personal use of the room during daytime, telephone access fee, and service charges for fans, air conditioners, heaters and fire extinguishers furnished in the room when such charges are not included in the room rate.






        2\. Meals - Expenses for breakfast, lunch, dinner and related tips and taxes (specifically excluded are alcoholic beverage and entertainment expenses, and any expenses incurred for other persons).






        3\. Incidental expenses - Fees and tips given to porters, baggage carriers, hotel staff, staff on ships and transportation to/from meals.

35. **Pre-trip vouchers** \-\- A pre-trip voucher is used to obtain reimbursement for common carrier fare charges and CGE fees ONLY (when incurred far in advance of a scheduled trip departure).

36. **Privately owned vehicle (POV)** \-\- Any vehicle (such as an automobile, motorcycle, aircraft, or boat) that is not owned or leased by a government agency, and is not commercially leased or rented by an employee under a government rental agreement for use in connection with official government business.

37. **Residence** \-\- The home in which an employee lives in the vicinity of the official assigned duty station/POD to and from which an employee commutes on a daily basis to the official assigned duty station/POD.

38. **Same-Day Travel** \-\- Travel which is outside of the 50-mile radius of the official assigned duty station/POD, completed within 12 hours or less, and does not include per diem, lodging or air/rail reservations.

39. **Supplemental Voucher** \-\- A document used to reimburse employees for travel expenses omitted from a previously paid travel voucher.

40. **Taxi** \-\- A hired car that carries passengers to a destination for a fare based upon the distance traveled, time spent in the vehicle, other metric or a flat rate to and from one point to another (a flat rate from downtown to a common carrier terminal).

41. **Temporary Duty (TDY) Location** \-\- A place, away from an employee's official assigned duty station/POD, to which the employee is authorized to travel.

42. **Texting or text messaging** \-\- Reading from or entering data into any handheld or other electronic device.

43. **Transportation network company (TNC)** \-\- A corporation, partnership, sole proprietorship, or other entity, that uses a digital network to connect riders to drivers affiliated with the entity in order for the driver to transport the rider using a vehicle owned, leased, or otherwise authorized for use by the driver to a point chosen by the rider. Examples: Uber and Lyft.

44. **Travel authorization** \-\- An electronic or written document submitted for approval to authorize official travel. The travel authorization obligates funds and must be submitted and approved before traveling, except in emergency situations.

45. **Travel Cost Comparison worksheet** \-\- The form(s) used to compare the authorized official travel costs to the actual travel costs that the employee incurred by taking a different method of transportation other than the authorized method, when employee voluntarily returns home during a TDY assignment, when an employee travels indirectly to or from a TDY location and when using a POV as the method of transportation.

46. **Travel Management Center (TMC)** \-\- The travel agency operating under the GSA contract that provides transportation, lodging and rental car services to the IRS.

47. **YUP Fares** \-\- In the airline industry, coach fares that offer an immediate upgrade to first or business class, usually at a slight premium to regular coach fares but at a substantial discount from the higher fares.


**1.32.11.1.7** **(11-04-2021)**

#### Acronyms

1. The following acronyms apply to this program:




| Acronyms |
| :-: |
| ATM | Automated Teller Machine |
| CBA | Centrally Billed Account |
| CGE | Concur Government Edition |
| CONUS | Continental United States |
| CR | Continuing Resolution |
| EFT | Electronic Funds Transfer |
| ETTRA | Extended TDY Tax Reimbursement Allowance |
| ETS | Electronic Travel System |
| FATA | Federal Agency Travel Administrator |
| FICA | Federal Insurance Contribution Act |
| FTR | Federal Travel Regulation |
| GOV | Government Owned Vehicle |
| GOVCC | Government Credit Card |
| GPS | Global Positioning System |
| GRS | General Records Schedule |
| GSA | General Services Administration |
| IOC | Internal Order Code |
| ITM | Integrated Talent Management |
| LOA | Line of Accounting |
| LTTT | Long-Term Taxable Travel |
| M&IE | Meals and Incidental Expenses |
| OCONUS | Outside the Continental United States |
| POD | Post of Duty |
| POV | Privately Owned Vehicle |
| PPE | Personal Protective Equipment |
| TDY | Temporary Duty |
| TMC | Travel Management Center |
| TNC | Transportation Network Company |
| TOP | Treasury Offset Program |
| WTA | Withholding Tax Allowance |


**1.32.11.1.8** **(07-02-2019)**

#### Related Resources

1. See IRM 1.32.4, Government Travel Card Program, for information on the travel card program and the centrally billed government travel card program

2. See IRM 6.550.1, Pay Administration (General) for information on compensatory time off for travel when travel outside of regular working hours cannot be avoided and is directed by an employee’s supervisor for the benefit of the government.

3. See GRS 1.1, item 010 Financial Transaction Records Related to Procuring Goods and Services, Paying Bills, Collecting Debts, and Accounting, for information on approving official retaining receipts for six years in compliance with records retention authorized disposition

4. See IRM 1.32.11.13, Delegation Orders, for a list of travel related delegation orders.

5. See United States Rental Car Agreement Number 5, for information on the rental of cars by federal employees when such rental is authorized by the government.


**1.32.11.2** **(01-21-2025)**

### General Rules

01. This section provides the guidance and instructions supplementing FTR, Chapter 301, Subchapter A, Part 301-2, General Rules.

02. Delegation Order 1-30, Authorization and Approval of Official Travel within the United States, identifies the appropriate IRS officials with the delegated authority to direct travel. This delegation order is available in IRM 1.2.2, Servicewide Delegations of Authority.

03. The approving official must limit the authorization and payment of travel expenses to those that are necessary to accomplish the mission in the most economical and effective manner, in accordance with the policies stated throughout this document. The approving official and employees should always consider less expensive alternatives, including teleconferencing, virtual attendance at meetings or conferences in compliance with Office of Management and Budget (OMB) Memorandum M-24-05 “Catalyzing Sustainable Transportation Through Federal Travel (issued December 14, 2023) implementing Executive Order (E.O.) 14057, Catalyzing Clean Energy Industries and Jobs through Federal Sustainability. OMB Memo M-24-05 directs Federal agencies to prioritize sustainable transportation options for official travel and lead by example as an organization working toward net-zero emissions operations by 2050.

04. The preferred transportation method when performing city-to-city travel is common carrier transportation (air or rail). There are times when this transportation method may not be feasible due to location, timing, equipment/materials and or security reasons. Alternatives should be considered in the following order: government vehicle, a contracted rental car or a privately owned vehicle (POV).

05. Employees are required to have an approved travel authorization before departing on travel. An approved authorization ensures that funds are obligated to support the travel and a reservation is ticketed timely.

06. A city-to-city travel authorization allows for travel outside the 50-mile radius of the official assigned duty station/POD. It may cover up to one year but should be input in 30-day increments and may only include one round-trip.

07. Employees may not take multiple round-trips against a single city-to-city ETS authorization; they must submit a separate authorization and separate voucher for each round-trip in ETS.

08. Employees may submit a:



    1. Domestic travel authorization no earlier than 60 days before departure.

    2. Foreign travel authorization no earlier than six months before departure.


09. Employees should enter their travel authorization at least five working days before their travel departure date, as it must be approved before travel begins. Reminder, if a common carrier transportation reservation is required, the approving official must approve it at least four working days before the beginning of travel to ensure reservations are ticketed timely. Reservations not ticketed 72 hours before departure will be automatically canceled by the airline.

10. The employee and the approving official must electronically sign the authorization. If filing a manual authorization, the employee and the approving official must sign the authorization in ink or electronically.

11. Invitational travel and new hire employee travel require manual authorizations and vouchers.

12. Travelers must obtain additional approval, before travel, for the following:



    01. Premium class accommodations include premium economy, business-class and first-class travel (See IRM 1.32.11.5.1.1, Airline Accommodations).

    02. Non-US flag carrier (See IRM 1.32.11.5.5(14), Foreign Travel).

    03. Foreign travel (See IRM 1.32.11.5.5, Foreign Travel).

    04. Using the Centrally Billed Account (CBA) (See IRM 1.32.11.7.4, Paying Travel Expenses Using the Government Travel Card).

    05. Using cash or personal funds to pay for common carrier transportation expenses over $100, (See IRM 1.32.11.7.5 (1)(a) and (b), Paying for Common Carrier Transportation Expenses).

    06. Official IRS representation at funerals (See IRM 1.32.11.5.8, Official IRS Representation at Funerals).

    07. Per diem within local commuting area. (See IRM 1.32.11.5.2(6), Per Diem Expenses).

    08. Lodging that exceeds the GSA nightly per diem rate. (See IRM 1.32.11.5.2.2, Actual Expenses).

    09. Preferred Seating Fee. (See IRM 1.32.11.5.1.1(12), Airline Accommodations).

    10. Transportation and lodging made outside of ETS or TMC. (See IRM 1.32.11.7.1 (2), Arranging for Travel Services).

    11. Use of Non-conventional lodging (i.e., Airbnb, VRBO or other apartment/condo leasing). (See IRM 1.32.11.1.6(ac), Terms/Definitions, and 1.32.11.7.1(6), Arranging for Travel Services).

    12. Reimbursement of a non-refundable reservation and/or change fees. (See IRM 1.32.11.7.1.1(3), Personal and Official Travel Combined).

    13. All other expenses incurred that are a violation of the FTR or agency travel policies.


13. Employees traveling on official travel must use the appropriate line of accounting (LOA) on their travel authorization.

14. When the travel is funded by another business unit, the employee must enter the LOA of the other business unit on the travel authorization.

15. Employees using multiple LOAs must add their lines of accounting and allocate the expenses to the correct accounting code.

16. Employees must use ETS for all TDY travel arrangements, unless they have an approved exception.

17. The Director, Travel Management, may grant individual exceptions from using ETS when such use:



    1. Causes an unreasonable burden on mission accomplishment (for example; for emergency travel or when ETS is not accessible).

    2. Involves invitational travel, new hire travel or accommodations for a disability or special needs in accordance with the FTR.

    3. Compromises a national security interest.

    4. May endanger the life of the traveler (for example, an individual traveling under the Federal Witness Protection Program or threatened law enforcement/investigative personnel traveling in accordance with IRM 1.32.11.5.4.2, Travel of a Threatened Law Enforcement/Investigative Employee).


18. The employee’s request for an approved exception from using ETS must be submitted by the Head of Office in writing or electronically to Travel Management. The Director, Travel Management, notifies the manager and the employee of the decision.

19. City-pair rates are available at the GSA website [City Pairs Program](https://www.gsa.gov/travel/plan-a-trip/transportation-airfare-rates-pov-rates-etc/airfare-rates-city-pair-program). The FTR requires travelers to use city-pair flights when available.

20. To assist employees when choosing government airfare in ETS, the following has been established:



    1. GSA City-Pair w/ Capacity Limits (Discount) -- These fares should always be the employee’s first choice when available and less expensive than the full government contract fare. These fares are typically deeper discounted contract city-pair flights. The carrier has reserved a limited number of tickets at this special price. These fares are also fully refundable and GSA-negotiated. These fares can be found on the subsequent airline search when employees click on Price Flights.

    2. GSA City-Pair (Full Price) --These fares are reserved for government employees traveling on official business. Travel regulations state that this fare should be used to the greatest extent possible when a GSA City-Pair w/ Capacity Limits fare is not available. These fares are fully refundable, changeable and GSA-negotiated.

    3. Government Non-Contract Fares -- These fares are offered to employees traveling on official government business but are not GSA-negotiated. The airlines offer these fares to compete with the contract city-pair carriers and are fully refundable and changeable if seats are available in the category. Fare increases may result if a reservation is not ticketed immediately. Employees may use these fares if they meet one of the exceptions for using non-contract carrier fares in accordance with FTR 301-10.111 and get advance approval, on the travel authorization, as required in FTR 301-112.


21. When traveling within a large metropolitan area, employees should consider using public transportation before requesting approval for using a rental car or POV. Employees should be familiar with subway/trains and bus routes that are available between meetings, lodging, and other locations at which business is to be conducted. When available, employees should use public buses that use alternative fuels, such as electricity or compressed natural gas, rather than gasoline or diesel to reduce Greenhouse Gas (GHG) emissions.

22. Employees should travel within regularly scheduled workhours, whenever possible, and are expected to travel as expeditiously as they would if traveling on personal business. At times, employees may have to travel during non-work hours to meet mission requirements. The IRS Human Capital Officer issues IRS policy governing compensatory time while traveling during non-work hours; see IRM 6.550.2, Pay Administration - Premium Pay Under Title 5 and the Fair Labor Standards Act (FLSA) and Compensatory Time Off for Travel.

23. Employees should not incur prepaid expenses. Non-refundable prepaid expenses incurred due to cancelation of official travel are not reimbursable to the employee. For example, prepaid parking, transit pass (daily, weekly or monthly), tolls, fuel or charging.


**1.32.11.3** **(03-28-2023)**

### Travel Guidance for Year End and/or Beginning of New Fiscal Year

1. Travel arrangements that are made the last few days of the fiscal year may be funded by current annual appropriation, providing the travel starts on or before September 30 and the per diem and other miscellaneous expenses are charged to the fiscal year in which the expenses are incurred. Travel that crosses fiscal years may be entered with a travel end date of September 30 to ensure funds are obligated prior to travel. If funding is approved and signed by the President prior to September 30, the employee may remain in travel status as long as funding is available for the period of anticipated travel. The employee should adjust travel dates on the voucher upon completion of travel.



1. In the event funding is not forthcoming and an employee is in travel status at midnight on September 30, the approving official will advise the employee if it is necessary to return to their official assigned duty station/POD.

2. If funding is approved and signed by the President prior to October 1 and the employee is in travel status at midnight on September 30, the employee may remain in travel status as long as funding is available for the period of anticipated travel. The employee should adjust travel dates on the voucher upon completion of travel.


2. Business units with multi-year funding may continue to authorize travel as long as there are sufficient funds available.

3. Business units without multi-year funding should not arrange or plan travel which will require tickets to be issued on or after October 1 until a continuing resolution or appropriation funding for the new fiscal year has been signed by the President.


**1.32.11.4** **(03-28-2023)**

### Travel During Periods Covered by Continuing Resolution Authority

1. Travel arrangements may continue to be made during a continuing resolution (CR) provided that adequate funding is available to cover anticipated travel expenses. Travel that does not begin prior to the expiration date of the CR must not be signed or approved, creating an obligation of funds not yet appropriated. If travel begins prior to the end of the CR but ends after the CR expiration date, the travel should be entered with CR end date. If funding is approved and signed by the President prior to the CR end date, the employee may remain in travel status as long as funding is available for the period of anticipated travel. The employee should adjust travel dates on the voucher upon completion of travel.

2. Official travel may not commence unless a CR is in effect, or a regular appropriation has been enacted. Employees who are already in travel status when a CR expires (and a new CR is not in place) should seek direction from their supervisor on whether it is necessary to return to the official assigned duty station/POD.

3. Travelers and travel arrangers should only select or purchase contract City-Pair or fully refundable tickets (when a City-Pair is not available) during this period of uncertain funding. This will ensure that a refund will be available in the event a new CR is not signed or travel must be canceled after the ticket has been issued.


**1.32.11.5** **(07-02-2019)**

### Allowable Travel Expenses

1. This section provides the guidance and instructions supplementing FTR Chapter 301, Subchapter B, Allowable Travel Expenses, and covers the following:



1. Transportation expenses

2. Per diem expenses

3. Miscellaneous expenses

4. Other temporary duty travel expenses


**1.32.11.5.1** **(03-28-2023)**

#### Transportation Expenses

1. This section provides the guidance and instructions supplementing FTR, Chapter 301, Subchapter B, Part 301-10, Transportation Expenses.

2. In determining which method of transportation results in the greatest advantage to the government, an approving official should consider the total costs of all transportation methods, including, but not limited to: per diem, overtime, lost work time, total distance to be traveled, salary cost for additional travel time and actual transportation costs.

3. A transportation method must be authorized based on the most advantageous method of transportation by order of precedence:



1. Common carrier - travel by common carrier is presumed to be the most advantageous method of transportation and must be used when reasonably available.

2. Government owned vehicle (GOV) - when your agency determines that your travel must be performed by automobile, a GOV is presumed to be the most advantageous method of transportation.

3. Rental car - if no GOV is available, but your agency has determined that travel must be performed by automobile, then a rental car should be authorized.

4. Privately owned vehicle - POV should be determined to be the most advantageous method of transportation **only** after your agency evaluates the use of a common carrier, a GOV and a rental car.


**1.32.11.5.1.1** **(01-21-2025)**

##### Airline Accommodations

01. This section provides the guidance and instructions supplementing FTR, Chapter 301, Subchapter B, Part 301-10, Subpart B, Airline Accommodations.

02. Employees can use the airport that best meets their needs when a city is served by multiple airports. However, if a contract carrier is not available from that airport, then they must provide justification and be approved on their travel authorization for use of a non-contract carrier.

03. Travel by common carrier is presumed to be the most advantageous method of transportation and must be used when reasonably available.

04. Travelers are required to exercise the same care in making official travel arrangements and incurring travel expenses that a prudent person would exercise if traveling on personal business. The least costly mode of travel must be considered when traveling and every effort should be made to not use first/business class and premium economy. First/business-class or premium economy airfare should only be considered on an exception basis due to mission requirements and meets criteria of the FTR, Treasury Directive 74-13, and IRM 1.32.11.



    1. First-class -- The IRS Commissioner must authorize the use of first-class fares before travel.

    2. Business-class -- The IRS CFO must authorize the use of business-class fares before travel.

    3. Premium economy class -- The IRS Senior Associate CFO Financial Management must authorize the use of premium economy class before travel.


05. If employees purchase a coach fare and it is upgraded to a YUP fare by the airline, employees need to verify that there was no additional cost for the upgrade. If there is an additional cost and employees would like to accept the upgrade, employees must use their personal funds or frequent flyer benefits to pay for the upgraded fares.

06. Employees who request first-class accommodations must complete, sign, and date Treasury Form TD-F 70-02.6, First-Class/Business-Class Travel Request and Authorization, and Form 15095, First-Class/Business-Class Approval Checklist. In addition, employees need to prepare a memorandum requesting approval of first-class travel accommodations and submit it to their Head of Office for signature. Employees must submit all completed forms and supporting documentation to include meeting agendas, trip itinerary schedule and other source data applicable, at least 30 business days in advance of the departure date to the approving official. If approved, the approving official will submit the request electronically to the Travel Review office mailbox at CFO.FM.Travel.Review@irs.gov, for clearance and coordination. The Travel Review office will review the documents submitted and prepare a package that include a memo for the Commissioner’s signature. The CFO submits the package to the Commissioner for approval or disapproval. If approved, all the supporting documents and the final itinerary/invoice must be scanned, uploaded or faxed into ETS, or it must be submitted with a manual authorization. If not approved prior to travel, reimbursement will be limited to the cost of an economy coach fare.

07. Employees who request business-class accommodations must complete, sign, and date Treasury Form TD F 70-02.6, First-Class/Business-Class Travel Request and Authorization, and Form 15095, First-Class/Business Class Travel Approval Checklist. In addition, employees need to prepare a memorandum requesting approval of business class travel accommodations and submit it to their approving official. Employees must submit all completed forms and supporting documentation to include agendas from event/meeting sponsor, trip itinerary schedule and other source data applicable, at least 30 business days in advance of the departure date to the approving official. Once documentation is signed by the approving official of the business unit, all documentation must be submitted electronically to the Travel Review office for clearance and coordination. The documents submitted will be reviewed to determine if the criteria have been met. If acceptable, a package will be prepared to include a memo for the CFO’s signature. If necessary, the Travel Review office will return the package and/or request additional information from the submitting business unit. If not approved prior to travel, reimbursement will be limited to the cost of an economy coach fare.

08. Employees who request premium economy class accommodations must complete, sign and date Form 15299, Travel Approval Request. Employees must submit all completed forms and supporting documentation to include meeting agendas, trip itinerary schedule and other source data applicable, at least 30 business days in advance of the departure date to the approving official. If approved, the approving official will submit the request electronically to the Travel Review office mailbox at CFO.FM.Travel.Review@irs.gov, for clearance and coordination. The Travel Review office will review the documents submitted and prepare a package for the IRS Senior Associate CFO Financial Management signature. If approved, all the supporting documents and the final itinerary/invoice must be scanned, uploaded or faxed into ETS, or it must be submitted with a manual authorization. If not approved prior to travel, reimbursement will be limited to the cost of an economy coach fare.

09. The criteria for using first-class accommodations mirror Treasury Directive 74-13, First-Class and Business-Class Travel, and the FTR 301-10.123 as follows:



    1. When coach-class or business-class accommodations are not reasonably available. Reasonably available means available on an airline that is scheduled to leave within 24 hours of the proposed departure time or scheduled to arrive within 24 hours of the proposed arrival time.

    2. When the use of first-class is necessary to accommodate a disability or other special need. A disability must be documented in writing by a certified medical authority. The certification must state that special accommodation is necessary, the approximate duration of the need for the accommodation, and a recommendation as to the suitable class. If employees are authorized to have an attendant accompany them, they must request the use of first-class accommodations for them separately.

    3. When exceptional security circumstances require first-class accommodations for travel. For example, when the use of other than first-class accommodations would endanger the employee's life or government property; the employee is an agent on protective detail and the employee is accompanying an individual authorized to use first-class accommodations; or, the employee is a courier or control officer accompanying control packages.

    4. When required because of agency mission.

    5. If there are any changes to the trip after approval, the employee must notify the approving official and the CFO office immediately at CFO.FM.Travel.Review@irs.gov to determine if additional approval and/or supporting documentation is required.


10. The criteria for using business-class accommodations mirror Treasury Directive 74-13, First-Class and Business-Class Travel, and the FTR 301-10.123 as follows:



    1. The use of business-class accommodations is necessary to accommodate a disability or other special need. A disability must be documented in writing by a certified competent medical authority. The certification must state that special accommodation is necessary, the approximate duration of the need for the accommodation, and a recommendation as to the suitable class. If employees are authorized to have an attendant accompany them en route, they must separately request the use of business-class accommodations for them.

    2. Coach-class accommodations on an authorized/approved foreign air carrier do not provide adequate sanitation or health standards.

    3. Regularly scheduled flights between origin/destination points (including connecting points) only provide other than coach class (first-class and business-class) accommodations and employees certify that on their voucher.

    4. When exceptional security circumstances require business-class accommodations for travel. For example, when the use of other than business-class accommodations would endanger the employee's life or government property; the employee is an agent on protective detail and the employee is accompanying an individual authorized to use first-class accommodations; or the employee is a courier or control officer accompanying control packages.

    5. Where the origin and/or destination are outside the continental United States (OCONUS), the scheduled flight time (including non-overnight stopovers and change of planes) is in excess of 14 hours and the traveler’s itinerary does not allow for a rest stop en route or a rest period (a rest stop or rest period is defined as full night of sleep of eight hours or more) at the TDY location. Engaging in only routine work (i.e., email, etc.) prior to a rest period is not sufficient to justify premium class.

    6. The use of business-class results in an overall cost savings to the government by avoiding additional subsistence costs, overtime, or lost productive time while awaiting coach-class accommodations.

    7. There is no space available in coach-class accommodations in time to accomplish the mission, which is urgent and cannot be postponed.

    8. When required because of agency mission.

    9. If there are any changes to the trip after approval, the employee must notify the approving official and the CFO office immediately at CFO.FM.Travel.Review@irs.gov to determine if additional approval and/or supporting documentation is required.


11. The criteria for using premium economy class accommodations should be used to accommodate a disability or special need or when the origin and/or destination is OCONUS and scheduled flight time, including stopovers or change of planes is in excess of 8 hours, when available, and before obtaining approval of business/first-class accommodations.



    1. A disability must be documented in writing by a certified competent medical authority or the employee must have a reasonable accommodation on file. The certification must state that special accommodation is necessary, the approximate duration of the need for the accommodation, and a recommendation as to the suitable class. If employees are authorized to have an attendant accompany them en route, they must separately request the use of premium economy class accommodations for them.

    2. Where the origin and/or destination are outside the continental United States (OCONUS), the scheduled flight time (including non-overnight stopovers and change of planes) is in excess of 8 hours. Employees authorized to use premium economy are not eligible for a rest period.

    3. The use of premium class accommodations must be approved by the IRS Senior Associate CFO Financial Management in advance of booking economy plus accommodations. The employee must submit a Form 15299, Travel Approval Request, to the CFO.FM.Travel.Review@irs.gov at least 14 days in advance of travel to review and forward for Senior Associate CFO Financial Management approval.


12. Upgrades to first/business-class or premium economy accommodations may be made at personal expense, including redemption of frequent flyer benefits and does not require approval. Travelers using personal funds or frequent flyer benefits are authorized to travel in first/business class or premium economy.

13. Employees may incur an additional fee for selecting a seat. Some airlines have instituted an additional fee for choosing a seat prior to or at check-in and/or offer a seat selection for "premium" seats (i.e., aisle, front of the cabin, larger seats, more legroom). Agents may even attempt to "up sell" for seat selection. While booking contract fares are guaranteed, if economy class seats are available, choice of a particular seat is not guaranteed. If an employee is prompted to choose a seat prior to or at check-in, it is important to check with the airline carrier's seat policy so that an additional fee is not incurred. The use of "premium" or upgraded/preferred coach seating options is an employee's personal choice and is at the employee’s personal expense. Seat assignments are at the discretion of the carriers. Some airlines do not make seat selection available. Some airlines may allow for a selection at check-in, usually available 24 hours prior to flight departure for domestic flights. For the best seat selection, an employee should check-in as soon as possible.

14. The IRS will not reimburse any fees the airline charges to upgrade boarding or for seat selection to a coach class window or aisle seat. This is a personal expense. However, if the employee has a medical condition documented by a medical professional that requires the additional space, the approving official may authorize reimbursement of the fee for the additional space. In addition, if there are extenuating circumstances, the traveler can request an exception to the policy from the Senior Associate CFO Financial Management. For example, non-premium seats were not available on the flight that is required to meet mission requirements.

15. The FTR provides that when undertaking official business travel, a government employee must use coach-class accommodations unless one of the exceptions permitted elsewhere in the regulation applies. The approving official must be able to determine that, at the time of travel, premium economy or other premium class accommodation is necessary because the employee was so disabled or limited by other special medical needs that other lower-cost economy accommodations (e.g., "bulk-head" seating, or providing two economy seats) cannot be used to meet the employee’s needs.

16. If the approving official can establish that the employee's special needs could be accommodated through another, more economical, arrangement (e.g., the purchase of two coach seats, if that would have been feasible and less expensive, or premium economy class, if it was available), it may, under this policy, limit the travel reimbursement to the lesser amount.

17. All air travel services funded by the federal government are required to use a “U.S. flag” air carrier holding a certificate issued under 49 USC § 41102, [Fly America Act](https://www.gsa.gov/policy-regulations/policy/travel-management-policy-overview/fly-america-act#OSA). The requirement applies to:



    1. Federal government employees and their dependents;

    2. Consultants, contractors and grantees; and

    3. Other travelers whose travel is paid for by the federal government.


18. All exceptions or waivers to the Fly America Act, including an Open Sky Agreement, must be approved by the Director of Travel Management on Form 15402, Justification Certificate for Use of a Foreign-Flag Air Carrier or Vessel, and must include:



    1. A detailed itinerary from the TMC or a screen print from ETS.

    2. Search results performed at the time of booking from the TMC or ETS that document all available flights and the existence of the Fly America exception identified (excess flight time) on the Fly America exception form, if applicable.


19. All requests for approval of Form 15402, Justification Certificate for Use of a Foreign-Flag Air Carrier or Vessel, and all required documentation must be submitted to the CFO.FM.Travel.Review@irs.gov mailbox for review and processing.


**1.32.11.5.1.1.1** **(11-04-2021)**

###### Unused ticket(s) or Refund Application

1. Employees with unused ticket(s) or refund application(s) must do the following:



1. If the CBA was used to purchase transportation tickets and the trip is canceled, employees must promptly notify the TMC and the CBA coordinator at IRS.CCS.CBA@irs.gov.

2. If the government contractor-issued individually billed charge card was used to purchase transportation tickets and the trip is canceled, employees must promptly notify the TMC and request a refund.

3. If the charges appear on the monthly charge card statement, employees must file a written dispute with the government card contractor.

4. If the cancelation results in a voucher rather than a refund, employees must hold onto those vouchers to be used on future official travel. Claiming reimbursement for an unused voucher must be approved by the Director, Travel Management by completing Form 15299, Travel Approval Request and submitting to CFO.FM.Travel.Review@irs.gov prior to claiming.


**1.32.11.5.1.2** **(03-28-2023)**

##### Train Accommodations

1. This section provides the guidance and instructions supplementing FTR, Chapter 301, Subchapter B, Part 301-10, Subpart B, Train Accommodation.

2. Employees may use economy train service instead of a contract airline. Employees are encouraged to use rail, particularly when the train uses electric locomotives rather than diesel, resulting in a lower GHG emissions per passenger mile ratio than other methods of transportation, when going shorter distances. In general, employees should travel by rail where available for city pairs less than 250 miles apart, especially in the Northeast and Mid-Atlantic regions of the United States, and in countries where regional or international rail is available and is time and cost effective (e.g., in parts of Europe and Asia). When traveling between cities, Federal employees should use rail when available and consistent with mission needs.

3. The requirements for requesting premium accommodations including premium economy, business-class and first-class train accommodations are the same as those for airlines. See IRM 1.32.11.5.1.1, Airline Accommodations.

4. Employees may not use the Amtrak Acela or other regional trains that are faster or have fewer stops. Acela is considered an extra-fare train because it operates at an increased fare due to the extra performance of the train (that is, faster speed and/or fewer stops). Therefore, use of the Acela train must be deemed as advantageous to the IRS or required for security purposes, in accordance with FTR § 301-10.103. Exception requests must be submitted to CFO.FM.Travel.Review@irs.gov following the requirements in IRM 1.32.11.5.1.1(4) - (10). The CFO office will review and submit the request for approval to the Deputy Commissioner or, in the case of the Commissioner direct report organizations, the Commissioner. If an exception is approved, the approval must be scanned into ETS with the travel authorization and voucher.

5. Train reservations will be ticketed when the authorization is approved, regardless of the fare type.


**1.32.11.5.1.3** **(07-02-2019)**

##### Government Owned Vehicle (GOV)

1. The approving official can only authorize employees to use a GOV for official purposes for travel:



1. Between places of official business

2. Between an official assigned duty station/POD and places of temporary location (when public transportation is unavailable or it is impractical)


2. See IRM 1.14.7, Motor Vehicle Fleet Management Program, for additional information on the use of a GOV.

3. Employees must report accidents that occur on official business in a GOV to their supervisor and contact ERC immediately at 866-743-5748. The employee completes a [Form SF-91](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwjjpJTa3ZKGAxWm48kDHbRIB4gQFnoECAYQAQ&url=https%3A%2F%2Fwww.gsa.gov%2Fcdnstatic%2FSF91-20.pdf&usg=AOvVaw0l2Dv8WceDIjMnQi_BPKXz&opi=89978449), Motor Vehicle Accident Report. Once completed, the employee’s manager must send the original SF-91, including copies of the police report, the [Form SF-94](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwifjNn13ZKGAxVk5skDHWU8Bt0QFnoECAYQAQ&url=https%3A%2F%2Fwww.gsa.gov%2Fsystem%2Ffiles%2FGeneral_Supplies__Services%2FSF94-17a_1507128924.pdf&usg=AOvVaw3Y5OdNZKyRqihIirvu-Eo2&opi=89978449) from witnesses and a copy of the Form 9154, Report of Occupational Injury, Illness, Accident or Unsafe Condition, to the Facilities Management and Security Services (FMSS) motor vehicle coordinator or appropriate fleet manager and the local safety officer within 48 hours. The safety officer must forward a copy of each SF 91 and any related accident paperwork to the IRS Claims Manager, Office of Chief Counsel, General Legal Services (CC:GLS:CLP), 1111 Constitution Avenue, NW - Room 6404, Washington, DC 20024.

4. In accordance with Executive Order 13513 issued October 1, 2009, IRS employees are prohibited from texting or text messaging while driving a GOV on official travel.


**1.32.11.5.1.4** **(01-21-2025)**

##### Rental Car

01. If no government owned vehicle (GOV) is available and the approving official has determined that travel must be performed by automobile, then a rental car should be authorized for official travel only, as a rental car is considered the most advantageous form of travel when driving.

02. Employees may use a rental car when the approving official has determined that it is in the best interest of the government and must provide the reason the rental car has been authorized to travel to or at the TDY on the authorization for reasons such as:



    1. No GOV, public transportation or shuttle available;

    2. Cost of a rental car is less than other transportation due to distance to/from hotel to TDY and to length of trip;

    3. Multiple TDY locations make public transportation less feasible;

    4. For security reasons related to agency mission;

    5. Traveling with multiple employees, sharing rental vehicle;

    6. Transporting government equipment; or

    7. Other, please provide details in comment box provided in ETS.


03. If the approving official has determined that the use of a rental vehicle is in the best interest of the government, but the traveler prefers to drive their POV, the traveler must complete Form 15278, Travel Cost Comparison Worksheet, to compare the mileage cost for driving their POV versus the cost of renting a vehicle for the same time period. The traveler's reimbursement will be limited to the lesser of the two amounts. Form 15278, Travel Cost Comparison Worksheet, with required documentation must be uploaded into ETS. This requirement is waived for “same-day” travel completed within 12 hours or less, that does not include per diem, lodging, air or rail reservations.

04. Employees who are authorized to use a rental car for TDY must use the least expensive compact car available unless an exception is approved, as outlined in FTR 301-10.450. Employees should select a zero-emission vehicle (ZEV) when the daily rental rate is equal to or less than the daily rental rate of the least expensive compact car available. If ZEVs are not available, employees should consider renting a hybrid vehicle if the daily rental rate is less than the rental rate of the least expensive compact car available. The approving official should approve these exceptions on a limited basis and must indicate on the travel authorization the reason for the exception. In general, compact size rental cars are considered advantageous to the government. However, the approving official is ultimately responsible for determining and authorizing the appropriate size rental car necessary for the performance of official business under the circumstances. (See IRM 1.32.11.5.1.4(5) and (6), Rental Car, for approval authorities).

05. When use of other than a compact car is necessary, the approving official may authorize other rental vehicle options if any of the following apply:



    1. The traveler must transport a large amount of government equipment.

    2. The traveler’s physical size warrants a size increase.

    3. The cost of other than a compact car is less than or equal to the cost of the least expensive compact car.

    4. Additional room is required to accommodate multiple employees authorized to travel together in the same rental car.

    5. When necessary for safety reasons, such as during severe weather or having to travel on rough or difficult terrain.


06. When use of other than a compact car is necessary to accommodate a medical disability or other special need, the approving official may authorize the use of other than a compact car.



    1. For disabilities: A disability must be certified annually in a written statement by a competent medical authority. However, if the disability is a lifelong condition, then a one-time certification statement is required;

    2. For other special needs: The certification statement must be certified annually in a written statement by a competent medical authority stating that special accommodation is necessary and the approximate duration of the special accommodation. However, if the special need is a lifelong condition, then a one-time certification statement is required;

    3. If an employee is authorized under FTR §301-13.3 (a)to have an attendant accompany the employee, the approving official may authorize the use of other than a compact car, if necessary.


07. When authorized to use a rental car, an employee must use a vendor that participates in the Defense Travel Management (DTM) U.S. Government Rental Car Program #5, unless the TDY travel is OCONUS and there is no agreement in place for the TDY location. Reservations must be made through ETS or through the TMC. Employees must verify Department of the Treasury appears on the rental agreement to ensure compliance with the U.S. Government Rental Car Program #5.

08. Employees who are authorized to use a rental car will be reimbursed the cost of the rental car, taxes, tolls, parking, fuel and oil changes. Employees are responsible for any additional costs incurred as the result of an unauthorized use of a rental car. Employees are also authorized to have alternative fuel charging expenses reimbursed as “fuel,” which is defined in FTR § 300-3.1 as “the energy source needed to power a vehicle,” and includes “petroleum, hydrogen, propane, and electricity.”

09. Use of high performance, convertibles or other luxury vehicles is never allowed.

10. Employees will not be reimbursed for purchasing pre-paid refueling or recharging options for a rental car. Employees should refuel or recharge prior to returning the rental car to the drop-off location. However, if it is not possible to refuel or recharge prior to returning the rental car because of safety issues or the location of the closest fueling or recharging station in the area, employees will be reimbursed for rental car company refueling or recharging charges.

11. Employees will not be reimbursed for fees associated with rental car loyalty points for the transfer of points charged by car companies.

12. If employees rent a car with a Global Positioning System (GPS) or a Toll Transponder that is permanently attached to the rental car and the charge for the GPS or toll transponder is included in the daily rate rental car fee, they will be reimbursed the cost of the GPS or toll transponder. GPS or toll transponder devices that are removable or rented separately are considered accessories, not standard equipment, so the employee is liable for any costs if the device is lost or stolen.

13. If the cost of using of the GPS or toll transponder is not included in the daily rental cost but billed as a separate expense on the invoice, it is not reimbursable.

14. If an employee is approved in advance to use a removable or rented GPS navigational feature or toll transponder for reasons of official necessity, the additional expense may be claimed on the travel voucher as part of the rental car cost.

15. Employees who travel within CONUS should not purchase collision damage waiver, theft insurance, or personal accident insurance since the government rental car agreement includes full liability, car loss, and damage insurance coverage for the traveler and the government.

16. Cars rented by government employees under the United State Government Rental Car Agreement #5 must be used only for authorized government purposes and should not be used to transport family and friends, except if relocating. Transporting family or friends raises claims, tort liability and employment law issues should an accident occur injuring the passengers.

17. In accordance with Executive Order 13513, issued October 1, 2009, IRS employees are prohibited from texting or text messaging while driving a rental car on official travel.

18. If employees are involved in a rental car accident, they must contact the IRS Claims Manager at claims.manager@irscounsel.treas.gov for specific information and instructions.


**1.32.11.5.1.5** **(01-21-2025)**

##### Privately Owned Vehicle (POV)

01. This section provides the guidance and instructions supplementing FTR, Chapter 301, Subchapter B, Part 301-10, Subpart D, Privately Owned Vehicle (POV).

02. Employees may use a POV for TDY travel when determined to be the most advantageous to the government.



    1. Employees who use their POV for TDY travel must complete Form 15278, Travel Cost Comparison Worksheet, showing the cost of the presumed most advantageous method of travel (air or rail) and rental car versus POV. Reimbursement will be limited to the lesser cost based on the completed Travel Cost Comparison Worksheet.

    2. Excess travel days will not receive per diem (lodging and M&IE) and must be charged to annual leave for any duty hours that are missed from traveling by POV.

    3. Per diem (lodging & M&IE) is not reimbursable on days annual leave is incurred. See IRM 1.32.11.5.2.3(1)(e), Travel over Weekend and Holidays.


03. Employees performing same-day travel outside of the 50-mile radius of the official assigned duty station/POD, that is completed within 12 hours or less, and that does not include per diem, lodging, air or rail reservations are waived from completing the Form 15278, Travel Cost Comparison Worksheet.The agency has determined that driving a POV is the most advantageous to the government .

04. Employees performing multi-day city-to-city travel in exigent or urgent circumstances (e.g., to protect a statute or any other government interest), will be authorized to travel by POV without completing a cost comparison in advance of travel. However, to remain compliant with FTR 301-10, the employee must complete Form 15278, Travel Cost Comparison Worksheet, upon return, which may limit the employee’s reimbursable travel expenses.

05. The approving official cannot require employees to use a POV for official TDY travel.

06. The approving official cannot prohibit employees from using a POV on official travel; however, reimbursement may be limited based on the completed Travel Cost Comparison worksheet.

07. If employees are performing TDY travel, and they use a POV to drive to the airport or train station near their residence or official assigned duty station/POD, they are entitled to round-trip mileage (from their residence or official assigned duty station/POD to and from the airport or train station) and parking not to exceed the cost of a taxi (including Uber/Lyft) or shuttle to/from the airport or train station.

08. If a family member or friend drives the employee to or from an airport, train station or rental car facility, the employee is entitled to claim round-trip mileage reimbursement, not to exceed the cost of a taxi (including Uber/Lyft) or shuttle from the employee’s residence or official assigned duty station/POD to/from the airport, train station or rental car facility.

09. In accordance with Executive Order 13513 issued October 1, 2009, IRS employees are prohibited from texting or text messaging while driving a POV on official travel.

10. Employees must report accidents that occur on official business in a personally-owned vehicle to their supervisor and the Employee Resource Center (ERC) immediately at 866-743-5748. See IRM 1.14.7.2.9, Motor Vehicle Fleet Management Program, for additional information. Employees must contact IRS Claims Manager at: claims.manager@irscounsel.treas.gov.


**1.32.11.5.1.6** **(07-02-2019)**

##### Special Conveyances

1. This section provides the guidance and instructions supplementing FTR Chapter 301, Subchapter B, Part 301-10, Subpart E, [Special Conveyances](https://www.ecfr.gov/current/title-41/subtitle-F/chapter-301/subchapter-B/part-301-10/subpart-E), including taxis, shuttle services, and other courtesy transportation and rental cars.


**1.32.11.5.1.6.1** **(01-21-2025)**

###### Taxis, TNCs, Innovative Mobility Technology Companies, Shuttle Services or Other Courtesy Transportation

1. When authorized by the approving official, transportation expenses while performing official travel are reimbursable for taxis, shuttle service or other courtesy transportation methods. Employees traveling in groups at the same TDY location are encouraged to share taxis, TNCs, shuttle or courtesy transportation services. These services may be used for:



1. Transportation to and from the airport

2. Transportation from hotel to TDY location

3. Transportation from hotel to obtain meals, groceries, medications or places of worship when not in the general vicinity. You must include a statement or electronic remarks with your travel voucher explaining why such transportation was necessary.


2. Employees may be reimbursed for ride-sharing companies like Uber and Lyft for travel on official business when the approving official determines it is advantageous to the government. Employees should use “green” options available when the ride cost is equal to or less than the most economical compact/economy options available and are within policy. Employees are not authorized the use of luxury or executive type vehicle services offered by Uber or Lyft (e.g., Uber Black, Uber Premier, Lyft Lux, etc.). Employees traveling with other employees may use Uber X, Uber XL or Lyft XL and should document the reason for using the larger accommodations.

3. Employees can be reimbursed for tips when using a taxi, shuttle service, courtesy transportation driver, Transportation Network Companies (TNC), innovative mobility technology companies, or valet parking attendant. NOTE: Valet parking should only be used when no other parking options are available. Employees can be reimbursed the standard tipping amount up to 20% of the fare amount (before any discounts are applied) and must include it in the total fare amount claimed on the travel voucher.


**1.32.11.5.1.6.2** **(07-02-2019)**

###### Limousine and Executive Car Services

1. The IRS will not reimburse an employee for using a limousine and/or executive car service. An executive car or limousine service generally involves the use of a luxury vehicle with a chauffeur who picks up and drops off a traveler. This restriction does not include paid shuttle services or vans.

2. An employee can generally recognize these types of services because they are used in the company name or advertisement. This restriction applies to premium services offered through Uber Black, Lyft Premier and other luxury sedan services.

3. If the employee can certify to the manager in writing that the travel was by van, taxi, or shuttle and that the transportation services provided were not luxury accommodations, then the approving official may approve the cost of transportation.


**1.32.11.5.2** **(01-21-2025)**

#### Per Diem Expenses

1. This section provides the guidance and instructions supplementing FTR Chapter 301, Subchapter B, Part 301-11, Per Diem Expenses, including the following:



1. Lodging-plus per diem

2. Reduced per diem

3. Actual expenses

4. Per diem on non-workdays


The guidance and instructions in this section apply only in determining when the IRS may pay per diem or reimburse expenses. Some of these payments and reimbursements to the employee may be taxable income. See IRM 1.32.11.6, Taxable Travel Reimbursement.


2. Employees must be in travel status more than 12 hours to be eligible for per diem.

3. If employees travel more than 12 hours but less than 24 hours, they may receive 3/4 of the per diem for each calendar day they are in travel status. This 12-hour rule does not necessarily mean that they are away from home for tax purposes, and the per diem may be taxable income. See IRM 1.32.11.6, Taxable Travel Reimbursement.

4. Employees may not receive per diem expenses at their official assigned duty station/POD or the place of residence from which they commute daily to the official assigned duty station/POD. Employees are required to travel a certain distance to receive per diem. The TDY location must be more than 50 miles from both the official assigned duty station/POD and residence, measured by odometer or other readings on the most direct route. Any point beyond both these distances is outside the commuting area. Employees may receive per diem even if the TDY location is within the commuting area, if the criteria under IRM 1.32.1.8, Per Diem for Local Travel, are met. Reimbursement of per diem expenses (lodging and/or M&IE) incurred within the commuting area is considered taxable income. See IRM 1.32.1.8, Per Diem for Local Travel and 1.32.1.11, Taxable Travel Reimbursement.

5. If employees are unable to consume a government-furnished meal, the approving official may allow the employees to claim the full M&IE allowance if their situation meets all the criteria listed below:



1. They are unable to consume the furnished meal(s) because of medical requirements or religious beliefs.

2. They requested specific approval to claim the full M&IE allowance before their travel.

3. They made a reasonable effort to make alternative meal arrangements but were unable to do so.

4. They purchased substitute meals to satisfy their medical requirements or religious beliefs.


6. Employees must use ETS or the TMC to identify suitable facilities that are at or below authorized per diem rates and should consider the perception of luxury accommodations (such as resorts, villas, timeshares, and golf clubs/spas), even if lodging at these facilities is available at the government rate. Fedrooms rates should be used when available.

7. Early check-in, late check-out, cancelation or “no-show” fees will not be approved for employee convenience or for failure to cancel timely. The employee must verify hotel check-in, check-out times and cancelation policies before making reservations and plan to arrive and depart at those established times. Most hotels will hold luggage at no charge with the hotel concierge. Fees incurred may only be claimed when incurred due to business reasons and approved on Form 15299, Travel Approval Request. Employees must attempt to obtain a refund for cancelation or “no-show” fees and provide documentation of refusal to refund with Form 15299.


**1.32.11.5.2.1** **(01-21-2025)**

##### Reduced Per Diem

01. The IRS is authorized to identify a reduced per diem rate lower than the prescribed rate when an employee is on extended travel at a TDY location for more than 30 calendar days. The approving official should make the determination to reduce a per diem rate to less than the prescribed rate for the area if either of the following conditions applies:



    1. The approving official can determine in advance that lodging and/or meal costs will be lower than the per diem rate. The lowest authorized per diem rate must be stated on the employee travel authorization in advance of the travel.

    2. The government provides meals and lodging at no cost to employees.


02. The approving official must submit a memorandum which explains the need for a different per diem rate to Travel Management. If approved, the requesting official must inform the employee of the reduced per diem rate five days before the trip. The travel authorization must contain the lower authorized per diem rate in advance of the travel. A copy of the approval must be faxed or scanned into the travel system with the authorization when reduced per diem is approved.

03. For scheduled travel of more than 30 days, employees must look for opportunities to reduce their lodging and meals per diem. This includes intermittent travel to a single location for 30 days or more, where the employee spends most of their time in travel status. The employee should look at the suitability of extended stay facilities that cost less than the authorized rate for the location. Many extended stay facilities offer discounts for longer stays and generally have facilities that allow meals to be cooked, eliminating the need to obtain meals at restaurants, thereby reducing the employee's meal allowance.

04. Employees on TDY for 30 days or more must submit the Form 15014, Reduced Per Diem City to City, to their managers for approval, stating what actions they took to try to reduce per diem and what rate they were able to obtain. This form should be uploaded into ETS with each travel voucher submitted during the trip. In addition, a copy of the signed form must be submitted to \*CFO-FM-Travel Policy & Review. The business units should evaluate all temporary duty assignments to a single location every 30 days to determine if the employee should return to their official assigned duty station/POD.



    1. If an employee is able to secure lodging at an extended stay facility that provides accommodations to reduce per diem, they must reduce the per diem on the first day of check-in at the facility.


05. When the IRS contracts or arranges with a facility to furnish lodging and/or meals for employees, then employees must stay at the IRS secured facility unless the facility does not have accommodations that are generally comparable to a typical private hotel room (e.g., private bathroom, personal phone, TV, refrigerator, Wi-Fi, etc.).

06. Employees must be notified, in writing, before traveling if they are required to accept the IRS-furnished or contracted meals or lodging. The notification must identify the days affected, explain the need for the use of the facilities, and inform the employees of the reduced per diem rate for those days.

07. If employees stay in the IRS secured lodging, they will only receive reimbursement for meals and incidentals, unless the IRS has also contracted for meals.

08. When IRS-furnished lodging is not furnished for non-workdays, employees are entitled to lodging reimbursement, as well as M&IE, for the weekend or holiday at the applicable rate for the TDY location.

09. Employees participating in training at the Federal Law Enforcement Training Center (FLETC) in Glynco, GA, will receive a special M&IE allowance of five dollars for each day that the IRS provides lodging and meals.

10. Employees attending training or a conference in which the IRS has paid a registration fee and meals are included must reduce M&IE based on the meals provided. If you are unable to consume provided meals due to dietary or religious reasons, the M&IE would not be reduced.


**1.32.11.5.2.2** **(07-02-2019)**

##### Actual Expenses

1. The authority to approve requests for actual expenses is delegated to first level executives in Delegation Order 1-5, Reimbursement for Actual Expenses. This delegation is available in IRM 1.2.2, Servicewide Delegations of Authority.

2. Requests for reimbursement of actual expenses exceeding per diem may occur when:



1. Lodging and/or meals are procured at a prearranged place such as a hotel where a meeting, conference or training session is held.

2. Costs have escalated because of special events (e.g., missile launching periods, sporting events, World’s Fair, conventions, natural or manmade disasters); lodging and meal expenses within prescribed allowances cannot be obtained nearby; and costs to commute to/from the nearby location consume most or all of the savings achieved from occupying less expensive lodging.

3. The TDY location is subject to a Presidentially-Declared Disaster and the IRS has issued a blanket actual expense authorization for the location (see §301-70.201).



      ### Note:



      FTR 301-70.201 May we issue a blanket actual expense authorization for our employees during a Presidentially-Declared Disaster? Yes. A blanket authorization regarding actual expense reimbursement may be issued to your employees assigned to perform TDY travel in an area subject to a Presidentially-Declared Disaster. These authorizations must apply to a specific Declaration and must end on the expiration date of the Declaration, or one year from the date the Declaration is issued, whichever is sooner. A blanket authorization issued under this section must not apply to any travel performed pursuant to Chapter 302 of this title.

4. Mission requirements.

5. No alternative locations or dates are available.


3. Requests for reimbursement of actual expenses exceeding per diem should occur in very rare circumstances. If an employee requests actual travel expenses (i.e., expenses at rates greater than per diem for lodging and meals in the temporary duty city up to a maximum of 300% of per diem) in the ETS system, a justification is required in the pre-audit screen. A copy of the first level executive approval to receive actual expense reimbursement must be scanned or faxed into the travel system.


**1.32.11.5.2.3** **(07-02-2019)**

##### Travel over Weekend and Holidays

1. Employees leaving a temporary duty location over a weekend or holiday must follow the guidance listed below in:



1. Temporary Return to Residence or Official Assigned Duty Station/POD

2. Travel to Another TDY Location

3. Temporary Duty Beginning on Monday

4. Completion of TDY Assignment on Friday

5. Leave of Absence


**1.32.11.5.2.3.1** **(03-28-2023)**

###### Temporary Return to Residence or Official Assigned Duty Station

1. A return trip is only authorized when the employee is on an extended CONUS or non-foreign (Alaska, Hawaii and other US territories) TDY assignment which lasts 30 calendar days or more. If the employee is on extended TDY, the first return trip can take place on the third weekend after the employee begins the TDY and may occur every two weekends thereafter.

2. The approving official determines if it is more cost effective for the employee to remain in a travel status and receive per diem than to permit the employee to return to the official assigned duty station/POD.

3. If employees voluntarily return to their residence or official assigned duty station/POD on non-workdays during the TDY assignment (on days other than those identified in IRM 1.32.11.5.2.3.1(1)), they will be reimbursed based on the following:



1. The maximum reimbursement for round-trip transportation and per diem or actual expense is limited to what would have been allowed had they remained at the TDY location. They must complete Form 15278, Travel Cost Comparison Worksheet, to determine the constructive and actual cost. They must submit the comparison statement with the travel voucher and will be reimbursed for the lesser of the two amounts. Employees should attach a copy of the documentation used to estimate the constructive cost to complete the Travel Cost Comparison Worksheet.

2. When completing Form 15278, Travel Cost Comparison Worksheet, for a voluntary return to the residence, employees must use the lowest non-contract fare that is available to the general public. Employees may use any available resource to determine the non-contract fare such as those found through travel or airline websites. City-pair contract fares cannot be used in the calculation because city-pair contract fares may not be used for a voluntary return, which is considered personal travel. The government travel card cannot be used to obtain the fare. Employees should attach a copy of the documentation used to estimate the constructive cost on the Travel Cost Comparison Worksheet.


4. Authorized return home does not apply to foreign travel assignments.


**1.32.11.5.2.3.2** **(07-02-2019)**

###### Travel to Another TDY Location

1. Employees may not claim transportation expenses for travel to a place other than their residence or official assigned duty station/POD during a temporary absence from a TDY location. The IRS will reimburse the employee the per diem costs incurred at the alternate location up to the maximum amount at the TDY location.

2. Employees have several options when they are completing an assignment at one TDY location on the day before a weekend or holiday and starting an assignment at another TDY location on the day after the non-workday:



1. Stay at the first TDY location for the non-workdays. They will be reimbursed based on the per diem rate for the TDY location.

2. Return to the residence for the non-workdays. They will be reimbursed the cost to return to their residence from one TDY location and the cost to proceed to the next TDY location.

3. Split the non-workdays between the two TDY locations. If employees split the non-workdays between the two TDY locations, employees will receive reimbursement based on per diem rate or authorized actual expense for the time the employee is at each location.

4. Proceed to the new temporary location for all non-workdays. If employees spend non-workdays at the location of the next assignment, employees will receive reimbursement based on the per diem rate or authorized actual expense for that area.


3. If the employee is required to return to the official assigned duty station/POD on a non-workday, the employee will be reimbursed the amount allowable for return travel.


**1.32.11.5.2.3.3** **(07-02-2019)**

###### Temporary Duty Beginning on Monday

1. If the employee’s TDY assignment begins on Monday:



1. If practical, the approving official should schedule the travel within the standard workweek. However, circumstances may require employees to report for duty on Monday at a time too early to permit travel on that day. In this case, employees should travel on Sunday, and they will be reimbursed three-fourths of the M&IE rate for their first day of travel. They may qualify for travel compensatory time in accordance with IRM 6.550.1, Pay Administration (General).

2. Employees may travel during duty hours on the preceding Friday. In this event, subsistence reimbursement is limited to the amount that would have been payable if the employee had departed on Sunday. The employee will not receive reimbursement for expenses incurred on Saturday or Sunday.


**1.32.11.5.2.3.4** **(07-02-2019)**

###### Completion of TDY Assignment on Friday

1. If an employee’s TDY assignment is completed on Friday, the employee may not remain in a travel status over the weekend. The options available to employees are as follows:



1. They return to the home or official assigned duty station/POD on Friday unless arrival would be at an unreasonable hour as determined by the approving official. In that event, employees should return on Saturday. In either case, employees may claim per diem or other authorized subsistence expenses until they arrive at home or the official assigned duty station/POD.

2. When it is advantageous to the government for an employee to travel on Friday, the approving official may still allow the employee, at the employee’s request, to travel later. However, the travel expenses, including subsistence, may not exceed those that the employee would have incurred if the employee had returned immediately.


**1.32.11.5.2.3.5** **(07-02-2019)**

###### Leave of Absence

1. Annual leave must be used while on a TDY assignment when an employee:



1. Is not performing official business during normal work hours at the TDY location.

2. Loses work hours due to travel by a POV when travel by common carrier is authorized.

3. Loses work hours due to Leave of Absence related to indirect travel for personal reasons.


2. If the employee takes leave for an entire day while on TDY, the employee will not be reimbursed for per diem expenses for that day. This applies whether leave is limited to that day alone or is part of a period of leave involving other days or parts of days.

3. If the employee takes leave for an entire day or day(s), the employee is allowed lodging reimbursements for the night preceding the first day's leave or the night preceding the return to duty status. For example, an employee is at the TDY for two weeks and takes 8 hours annual leave on Tuesday of the second week; the employee may claim lodging either on Monday night or Tuesday night but not both nights. Employee would not be entitled to M&IE on Tuesday.

4. An employee’s per diem is affected if they take leave for part of a day:



1. If an employee takes leave for half of the prescribed working hours or less, they will receive reimbursement of either per diem or actual expenses, whichever applies for the entire day.

2. If an employee takes leave for more than half of the prescribed working hours, they will not be reimbursed per diem expenses. For example, if employees are on an eight hour workday schedule and they take more than four hours of leave, they are not entitled to claim lodging costs for that day or M&IE for that day. If employees are on an actual expense basis, they will not be reimbursed for expenses incurred for that day.


5. An employee’s per diem is affected if they take leave before or after non-workdays (weekends or federal holidays) while on a TDY assignment:



1. In general, employees will be reimbursed for non-workdays, if the travel status requires the inclusion of a non-workday. For example, if official travel is through Friday and resumes on Monday, the employee may be allowed reimbursement for Saturday and Sunday.

2. When the employee takes a full week or part of a week of annual leave that falls between two weekends while in travel status, the employee will be reimbursed per diem or actual expenses for a maximum of two non-workdays. For example, if the employee takes annual leave Monday through Friday, the non-workdays will be Saturday and Sunday preceding Monday and Saturday and Sunday following Friday. The employee will receive per diem on the Saturday preceding Monday and on the Sunday following Friday.


**1.32.11.5.3** **(01-21-2025)**

#### Miscellaneous Expenses

1. This section provides the guidance and instructions supplementing FTR Chapter 301, Subchapter B, Part 301-12, [Miscellaneous Expenses.](https://www.ecfr.gov/current/title-41/subtitle-F/chapter-301/subchapter-B/part-301-12)

2. The IRS may reimburse employees for emergency and non-emergency personal telephone calls while away from the usual place of work, whether or not the calls are within the local area, if approved by the approving official. Employees must furnish a statement of telephone charges, including date, place called, and amount, for all long distance calls for which they request reimbursement. Employees are required to provide receipts, regardless of amount.

3. Expenses associated with airport security fast-pass membership fees in registered and/or trusted traveler programs (such as TSA Precheck or Fly Clear) are not reimbursable for the purposes of government travel.

4. Employees may be reimbursed for the first standard checked bag fees charged by the airline, when authorized. The approving official may authorize additional checked or overweight baggage, if it is determined that additional or overweight baggage is needed for official reasons. Employees must provide a justification in ETS when the baggage expense exceeds $50. Tips at transportation terminals for handling government property carried by the employee are reimbursable. Tips for personal baggage are not reimbursable.

5. The IRS may reimburse employees for internet access on a common carrier, while they are on official travel, as a miscellaneous expense, when access is **required** for official business. This expense is not reimbursable if they have a hot spot. Reimbursement will be limited to the internet access fee charged by the airline and must be paid with the GOVCC.

6. The IRS may reimburse expenses incurred for laundry, dry cleaning and pressing of clothing as a miscellaneous travel expense for TDY within CONUS when necessary for official business. However, the employee must incur a minimum of four or more consecutive nights lodging on official travel to qualify for this reimbursement and must attach receipts regardless of the amount. If a coin operated laundry facility is used, employees must notate in comments coin operated laundry facility used. These reimbursements are meant for employees to maintain clean clothing while on an extended assignment. IRS will not reimburse for laundry and dry-cleaning expenses incurred after a TDY assignment ends. Laundry and dry-cleaning expenses have not been removed from foreign per diem rates established by the Department of State, or from non-foreign area per diem rates established by the Department of Defense. Separate claims for laundry and dry-cleaning expenses incurred in foreign areas (OCONUS) and non-foreign areas (OCONUS) are not allowed.

7. Transaction fees plus cash advance fees up to 2.5% for obtaining a cash advance on the travel card.

8. Miscellaneous and emergency expenses may be claimed when an employee provides a detailed explanation. A receipt is required regardless of the dollar amount.



1. Baggage fees (for IRS equipment ONLY - personal baggage fees should be claimed under the expense “baggage fees” IRM 1.32.11).

2. Cash conversion expenses.

3. Internet access/Wi-Fi (if required for official work access), should be claimed under the correct expense type. The GOVCC should be used and a receipt is required regardless of dollar amount.

4. Seat selection (approval by CFO via Form 15299, Travel Approval Request, required due to reasonable accommodation or medical documentation).

5. Travelers check fees.

6. Telephone/Telegraph expenses (if directly related to training travel or an emergency).

7. Personal protective equipment (PPE), not to exceed $20, and/or testing when required for official travel during a period of restricted travel due to a pandemic or other national health crisis. Employees may only claim if PPE is not provided by POD, is not already have readily available and the cost of testing, if testing is not covered by health insurance (cost of an office visit is not reimbursable). PPE is limited to a plain cloth face covering (non-medical grade), hand sanitizer and, if available, disinfecting wipes.

8. Other expenses approved by CFO with instructions to claim as an emergency expense.


**NOTE:** Postage, shipping, ink and other supply items may**not** be claimed as an emergency expense on a travel voucher. (See IRM 1.35.3, Receipt and Acceptance Guidelines)



**1.32.11.5.4** **(07-02-2019)**

#### Other Temporary Duty Travel Expenses

1. This section provides the guidance and instructions supplementing FTR Chapter 301, Subchapter B, Parts 301-13, 301-30, 301-31 and Subchapter D, 301-70 and 301-75, including:



1. Travel of an employee with special needs

2. Travel of a threatened law enforcement/investigative employee

3. Pre-employment interview travel

4. Executive travel over 75 nights

5. Employees detailed beyond six months

6. Emergency travel


**1.32.11.5.4.1** **(01-21-2025)**

##### Travel of an Employee with Special Needs

1. The approving official may authorize additional travel expenses for an employee who has a disability, a special need or a reasonable accommodation on file.



1. If the approving official and/or employee believes that the use of premium accommodations to include premium economy, business-class or first-class is necessary to accommodate the disability or a special need, then the approving official or employee must request such accommodations in accordance with the requirements in IRM 1.32.11.5.1.1, Airline Accommodations.

2. The approving official should authorize those expenses necessary to reasonably accommodate an employee with a disability in accordance with the Rehabilitation Act of 1973, as amended, 29 USC § 701-791, and 5 USC § 3102. An employee with a special need should be treated the same as an employee with a disability, so any additional travel expenses requested or incurred must be necessary to accommodate the employee's needs.


2. The authority to approve additional expense(s) for an employee who has a disability, a special need or a reasonable accommodation, to include the lactation program, is delegated to the approving officials as designated in Delegation Order 1-30, Authorization and Approval of Official Travel within the United States, except for approval for the use of premium accommodations to include premium economy, business-class and first-class travel accommodations per IRM 1.32.11.5.1.1, Airline Accommodations.


**1.32.11.5.4.2** **(07-02-2019)**

##### Travel of a Threatened Law Enforcement/Investigative Employee

1. The IRS pays transportation and subsistence expenses for employees and/or their family, as a threatened law enforcement/investigative employee, when the approving official decides it is appropriate to pay these expenses based on the nature of the threat against the employee’s life and/or the life of immediate family member(s).

2. The approving official must reevaluate the situation for payment of transportation and subsistence expenses as a threatened law enforcement/investigative employee every 30 days, using the same factors that were considered when the expenses were originally authorized.


**1.32.11.5.4.3** **(07-02-2019)**

##### Pre-Employment Interview Travel

1. The approving official in the office conducting the interview may authorize pre-employment interview travel expenses when it is in the best interest of the government.

2. Travel authorizations and reimbursements for interview travel are subject to the same regulations as travel by IRS employees. Pre-employment interview travelers, other than federal government employees, must use the CBA to pay for the purchase of common carrier tickets and must complete a manual authorization and voucher.

3. The pre-employment interviewee must submit a travel claim in accordance with IRS procedures to receive reimbursement for pre-employment interview travel expenses. The office conducting the interview pays the travel expenses.


**1.32.11.5.4.4** **(11-04-2021)**

##### Employees Detailed Beyond Six Months

1. The approval of city-to-city details expected to last for six months or longer must be approved by the Heads of Office for the employees in their business units. In the case of the Heads of Office, the Deputy Commissioner. In the case of direct reports to the Commissioner, the Chief of Staff. See Delegation Order 1-67, Authorization and Approval for Official City-to-City Travel of Six Months or More to a Single Location.

2. Requests for approval should be submitted to the Business Unit Commissioner, Director or Chief on the Form 14795, Request for Approval of City-to-City Travel Extending Beyond Six Months. The request for approval must be submitted as soon as it is determined that the city-to-city travel will extend beyond six months or no later than 30 days prior to the end of a previously approved detail being considered for extension.

3. Once the Business Unit Commissioner/Director/Chief has reviewed and approved the form, it should be forwarded electronically to CFO.FM.Travel.Review@irs.gov for processing.

4. The form is posted on the Traveler’s Toolkit. This form must be completed and approved for any employee on a city-to-city detail that is expected to last more than six months.

5. Employees should allow 30 days from the date they submit the request to obtain approval.

6. If, for any reason, the travel extends beyond the period for which approval was granted, an additional request for approval must be obtained. Once approved, the employee must scan or fax a copy of the signed approval into ETS with each travel voucher.


**1.32.11.5.4.5** **(11-04-2021)**

##### Emergency Travel

1. Emergency travel results from:



1. Employees becoming incapacitated by illness or injury not due to their own misconduct; or

2. The death or serious illness of a member of the employee's family; or

3. A catastrophic occurrence or impending disaster, such as fire, flood, or act of God, which directly affects the home.


2. When an illness or injury occurs on TDY, the approving official may authorize reimbursement for:



1. Per diem at the location where the employee incurred or was treated for incapacitating illness or injury for a reasonable period (generally 14 calendar days).

2. Transportation and per diem expenses for travel to an alternate location to receive medical treatment.

3. Transportation and per diem expenses to return to the employee’s official assigned station/POD.

4. Transportation costs of a medically necessary attendant. Per diem is not allowed.


3. The approving official may authorize per diem if the employee discontinues a TDY assignment because of a personal emergency. Expenses of appropriate transportation and per diem while en route may be allowed, with the approval of the approving official, for return travel from the point of interruption to the official assigned duty station/POD or an alternate location.

4. When employees discontinue a TDY assignment because of a personal emergency and travel to an alternate location and afterwards return to their residence or official assigned duty station/POD, the approving official may reimburse certain excess travel costs provided in this IRM. The excess cost is the difference between the actual cost of travel from the point of interrupted temporary duty to the alternate location and return, and the constructive cost of travel. The actual cost of travel includes the per diem allowance while en route. The constructive cost is the cost of round-trip travel and per diem between the official assigned duty station/POD and the alternate location. Per diem is not allowable for the time spent at the alternate location.


**1.32.11.5.5** **(01-21-2025)**

#### Foreign Travel

01. Foreign travel is official travel outside of the United States and its territories and possessions.

02. Official travel to and from points outside the United States and its territories and possessions must be approved in advance by the Deputy Commissioner LB&I.

03. Employees who request approval for foreign travel must follow the procedures in IRM 1.32.5, International Travel Office Procedures and the LB&I International Travel Office sharepoint site and CCDM 30.5.2.5.

04. Employees will work with the TMC to make all travel arrangements, including flight, rail, hotel and rental car (if applicable), when booked outside of ETS. See exceptions in IRM 1.32.11.7.1 (4) and (6), Arranging for Travel Services.

05. Where the origin and/or destination are OCONUS, and the scheduled flight time, including stopovers and change of planes, exceeds 14 hours, and there is no rest period provided during or after the flight in accordance with FTR 301-10.125, the CFO may authorize use of business-class accommodations in lieu of an authorized rest period. A flight over 14 hours may not necessarily qualify for the use of premium class travel, see IRM 1.32.11.5.1.1(7) (e), Airline Accommodations. Employees must make every effort to schedule their travel so they have a rest period prior to starting work. A rest period (a rest stop or rest period is defined as full night of sleep of eight hours or more) en route or at the temporary duty destination negates the use of business-class travel. Engaging in only routine work (i.e., email, etc.) prior to a rest period is not sufficient to justify premium class. Employees must submit a request to use business-class accommodations in advance of the trip in accordance with the requirements of IRM 1.32.11.5.1.1(4) - (10), Airline Accommodations. Business-class travel can only be authorized when there is no rest stop and the trip is greater than 14 hours (41 CFR 301-10.125 (c)). This request requires completed form TD F 70-02.6 and Form 15095, First-Class/Business-Class Approval Checklist.

06. The approving official can authorize a rest period when the flight time is in excess of 14 hours including stopovers or change of planes. The employee must fly coach if the trip includes a rest period en route or a rest period upon arrival at the duty site in accordance with the FTR. Employees who request approval for a rest period immediately preceding or following periods of annual leave or non-workdays will not be authorized. The request must be made and approved separately for the outbound and the return flights.

07. When the origin and/or destination is OCONUS and scheduled flight time, including stopovers or change of planes is more than 8 hours, premium economy seating may be authorized by the Senior ACFO for Financial Management, no rest period may be authorized if other than coach class is approved.

08. In limited circumstances (e.g., no available flights) a rest period of more than 24 hours may be authorized.

09. Employees whose travel includes a non-US flag carrier transportation on a common carrier that does not meet the Fly America Act (49 U.S.C. 40188) requirements even when there is an Open Skies Agreement, must receive prior approval from the Director of Travel Management before traveling. Employees must complete Form 15402, Justification Certificate for Use of a Foreign-Flag Carrier or Vessel, and submit prior to travel to the \*CFO.FM.Travel.Review@irs.gov mailbox for review and submission for approval, see IRM 1.32.11.5.1.1 (17) - (19), Airline Accommodations.

10. Employees may accept meals from foreign governments or entities without reducing the per diem.

11. Employees must calculate lodging per day based on the conversion rate. Lodging tax is included in the daily lodging rate and may not be claimed separately for foreign travel.

12. Employees with foreign travel that crosses the international date line, if travel is entered correctly, ETS will correctly calculate the authorized per diem entitlements. Employees should not manually try to change per diem entitlements.


**1.32.11.5.6** **(01-21-2025)**

#### Invitational Travel

01. Invitational travel occurs when the IRS invites and pays the travel expenses for individuals not employed by the IRS or employed intermittently by the government. This includes:



    1. Persons employed by other federal government agencies.

    2. Persons serving without pay or at $1 a year when acting in a capacity related to or in connection with official IRS activities.

    3. Attendants to employees with disabilities or special needs.

    4. Persons accompanying an employee to a major award ceremony.

    5. Persons invited to interview with the IRS.

    6. Persons detailed to the IRS.


02. Reimbursement for invitational travelers is subject to the same regulations as travel by IRS employees.

03. The guest of an award recipient is considered to be an invitational traveler and travel authorizations and reimbursement expenses are the same as those normally authorized for IRS employees in conjunction with a temporary duty assignment.

04. Employees who receive a major award may be accompanied to the ceremony by one guest as an invitational traveler. Major awards ceremonies include:



    1. A Presidential Award.

    2. An annual ceremony of the IRS or major organizational component.


The route of travel for a guest must be directly between the guest's residence and the site of the ceremony.


05. If award recipients require special assistance, they may receive reimbursement for an attendant, in addition to the person accompanying the award recipient, as permitted in IRM 1.32.11.5.4.1, Travel of an Employee with Special Needs.

06. The IRS funding for non-IRS award ceremonies is limited to the award recipient and their manager/representative. The IRS will only authorize registration fees and local travel expenses to the award ceremony for the employee and the manager. Non-IRS award ceremonies include:



    1. A prestigious honorary award sponsored by a non-governmental organization.

    2. Award ceremonies hosted by organizations that advocate/recognize achievement in public service, and or support public service professions (e.g., federal executive boards, Association of Government Accountants.)


07. The invitational traveler's profile must be established to make travel reservations and to process manual authorizations and vouchers. The business unit coordinator can provide the traveler with a worksheet to establish the traveler's profile. The traveler can provide the completed profile request to the business unit coordinator.

08. The business unit coordinator prepares Form 13635, Manual Travel Authorization, and provides a copy of the authorization to the invitational traveler and requests the traveler’s original or electronic signature on the authorization. The invitational traveler must submit an approved Form 13635, Manual Travel Authorization, before travel begins.

09. Invitational travelers, other than federal government employees, must use the CBA to pay for the purchase of common carrier tickets through the TMC. Transportation must be arranged by calling the TMC.

10. For lodging and rental car reservations, the invitational traveler must provide a personal credit card number to hold the reservations. Invitational travelers who do not provide a credit card number will need to arrange their own lodging and rental car. Invitational travelers should be notified of the TDY per diem rates, which define their reimbursement limits.

11. Invitational travelers cannot receive a travel advance.

12. An approving official may approve invitational travel as provided in Delegation Order 1-30, Authorization and Approval of Official Travel within the United States. The approved authorization must be mailed or efaxed to Travel Operations to process into IFS. Documentation can also be emailed to \*CFO BFC Travel Authorizations and Accounting Codes.

13. The IRS pays by Electronic Funds Transfer (EFT). The IRS may grant a waiver for direct deposit by EFT if no more than one reimbursement is expected to be paid to the same recipient within a one-year period. Invitational travelers must inform the business unit that they are unable to accept payment by EFT and complete a Request for Waiver of EFT Payment for Individuals form. A business unit can obtain a copy of the form from the IRS Source, Employee Resources, Travel, Travel Policy and Forms.


     The traveler must mail the form along to:




    | Internal Revenue Service<br> Travel Operations<br> ATTN: Travel Management Vendor Code Coordinator<br> P.O. Box 9002<br> Beckley, WV 25802 |
    | --- |
    | Efax to 855-787-4375 or email to \*CFO BFC Travel Authorizations and Accounting Codes |

14. The business unit coordinator must verify that the invitational travel has been completed. The traveler will have to complete and provide a signed paper voucher, Form 15342, Travel Voucher, for their travel, as well as provide all necessary receipts for claims, to the business unit coordinator.

15. The business unit coordinator will do the following when the travel is completed:



    1. Create a manual voucher from the authorization for the trip.

    2. Include all authorized expenses on the manual voucher and attached receipts provided by the traveler.

    3. Provide a copy of the manual voucher to the invitational traveler and request the traveler’s original signature.

    4. Obtain the approving official signature on the manual voucher.


16. Invitational travel is reimbursed by the business unit coordinator submitting the approved Form 15342, Travel Voucher, required receipts, and Form SF1199-A, Direct Deposit Sign-up Form, to Travel Operations. Efax to 855-787-4375, email to \*CFO BFC Travel Vouchers, (cfo.bfc.travel.voucher@irs.gov) or mail to:




    | Mailing Addresses |
    | :-: |
    | Internal Revenue Service<br> Travel Operations<br> ATTN: Travel Section<br> P.O. Box 9002<br> Beckley, WV 25802 |
    | For overnight service, mail the forms to:<br> Internal Revenue Service<br> Travel Operations<br> 110 N. Heber St.<br> Beckley, WV 25801 |


**1.32.11.5.7** **(11-04-2021)**

#### Training Travel

1. Training travel occurs when the IRS requires an employee to travel to attend courses or professional meetings involving, scientific or professional societies, or municipal, state, federal or international organizations. Also, training travel includes travel to attend:



1. Congressional and law enforcement training, or

2. Other group’s meetings to give or get information about IRS’s substantive or administrative activities.


2. In accordance with IRS reporting requirements, all travelers attending an event, conference or training as defined in TD 12-70 must use the correct Internal Order Code (IOC) for tracking and reporting purposes and must attach reporting instructions to their voucher.


**1.32.11.5.8** **(07-02-2019)**

#### Official IRS Representation at Funerals

1. The IRS may authorize travel at the government expense to attend funerals if attendance by an official IRS representative is considered important to the mission of the agency, and the appropriate representative would be unable to attend without the travel being authorized at the government expense. Only one employee can serve as an official IRS representative at a funeral. This type of travel is limited to the United States and its territories and possessions.

2. The business head of office is the authorizing official to approval attendance of IRS representation at a funeral. The authorization must be documented in a memorandum. After the employee receives the approved memorandum to attend the funeral, the employee can process the authorization in ETS. The memo must be uploaded into ETS when the employee submits the voucher. The travel is charged to the applicable business unit’s LOA of the employee designated as the official IRS representative.


**1.32.11.6** **(03-28-2023)**

### Taxable Travel Reimbursement

1. Taxable travel reimbursements may include:



1. All travel expenses with respect to long-term taxable travel.

2. Travel advances outstanding for more than 150 days.

3. Subsistence (M&IE) for trips less than 24 hours without overnight lodging.

4. Per diem expenses (lodging and/or M&IE) incurred within the commuting area.



      ### Note:



      All expenses incurred as part of the lodging receipt to include taxes, fees, parking, etc.

5. Employees incurring LTTT for parking expenses monthly at a work location. There is a certain amount that can be excluded as a qualified parking exclusion. This information is available in Publication 15-B, Employer’s Tax Guide to Fringe Benefits.


2. A Form W-2 will be issued for all taxable reimbursements and overdue travel advances.


**1.32.11.6.1** **(11-04-2021)**

#### Long-Term Taxable Travel Away From Home

01. LTTT is overnight travel (city-to-city) to a work location that cannot be considered temporary. Overnight travel is always long-term, and is not considered temporary, if the travel away from home to a single location is realistically expected to last for more than one year. The realistic expectation is based on the information known to the employee and manager. The travel becomes taxable at the point it is expected to exceed one year.

02. Executives are not to be in travel status for more than 75 nights to a single location in any fiscal year without the appropriate approval.



    1. Form 14580, Request for Approval of Travel Over 75 Nights


Alternatives to in-person meetings should be pursued when appropriate including the use of teleconferences, Teams, Live Meeting and Adobe Connect. Once the request has been signed and approved, it should be submitted to the Division Commissioner/Chief or equivalent for review and signature. The Division Commissioner/Chief or equivalent should then forward the approved form electronically to the CFO.FM.Travel.Review@irs.gov. The executive must scan or fax a copy of the approval into ETS with each travel voucher.



03. In advance of placing an employee on LTTT, business units must complete a business case/cost and benefit analysis, considering a temporary or permanent change of station versus LTTT. Business units considering a request for LTTT should contact the CFO office at CFO.FM.Travel.Review@irs.gov for assistance and further guidance in preparing the business case.

04. A manager who knows, or can reasonably expect, that an employee will receive a LTTT assignment must ensure that it is authorized on Form 12654, Authorization for Long-Term Taxable Travel, and that the Form 12654 is signed by the manager and employee each calendar year of the LTTT assignment. The employee’s first-level executive must approve the LTTT, and the approval and the business case analysis must be uploaded into ETS with each voucher. A copy should also be sent to the CFO at CFO.FM.Travel.Review@irs.gov.

05. In determining if the travel is LTTT, the following criteria is used:



    1. **The One-Year Rule:** Overnight travel away from home is long-term if the travel to a single location is realistically expected to last for more than one year, or if there is no realistic expectation that the travel to a single location will last for one year or less. The realistic expectation for long-term travel is based on the current facts and circumstances known to the employee and the employee's manager.

    2. **Single Location:** A single location is the entire area within which employees would generally commute to work at a particular location. Travel to any other location or locations within that same commuting area is travel that also comes within the single location determination. For example, a period of overnight travel to one work location, followed by a period of overnight travel to a second work location that is within the same commuting area as the first work location, are combined and constitute travel to a single location.

    3. **The One Year Clock Start for Taxability Purposes:** For purposes of determining an employee's length of travel expectation, the first date of travel to a particular work location would be the beginning date or "start of the clock" (i.e., travel is not expected to end within one year from that date). Physical presence at the work location is the determinative factor and not the date assigned to a project or when time first is charged to a project.

    4. **Change in Expectations:** Even if overnight travel is initially temporary, if an employee’s expectations change, the travel may become LTTT. The travel becomes taxable at the point it is expected to exceed one year.


06. Employees who are in a LTTT assignment incur liabilities for the applicable Medicare withholding and Social Security withholding of Federal Insurance Contribution Act (FICA) taxes and applicable federal, state and local income taxes. The IRS withholds the appropriate amounts from their travel reimbursements. Energy Policy Act of 1992, Public Law 102-486, and Revenue Ruling 93-86 require the IRS to tax long-term travel.

07. The IRS will process an Extended TDY Tax Reimbursement Allowance (ETTRA) to those employees incurring an additional income tax liability resulting from long-term travel reimbursements. A final ETTRA payment is made to the employee in the following year after travel reimbursements are made. ETTRA policy does not allow reimbursement of Medicare and FICA.

08. When a travel voucher claiming LTTT expenses is paid to the employee, federal, state, Medicare and Social Security taxes are withheld from the reimbursement. A Withholding Tax Allowance (WTA) is paid to reimburse the employee the federal, state and local tax withholdings on the taxable travel expenses. (The formula for the WTA is a gross-up formula because it also reimburses the employee the federal tax withholdings on the WTA itself, since the WTA is also considered income to the employee.)

09. The LTTT reimbursement is considered wages and taxable for federal, state, Medicare and Social Security tax purposes. The financial system has been configured in accordance with state withholding regulations based upon information received from all states. If the employee’s state does not have a withholding requirement and the voucher reflects a state withholding, the employee should complete an IRS Service Central ticket immediately.

10. If employees reach the maximum Social Security withholding amount of taxable earnings for the year, Travel Operations has a procedure in place to reimburse employees any over-withholding of Social Security taxes on LTTT payments. Each year, Travel Operations sends notices to employees who received LTTT payments during the previous calendar year. This notice informs the employees how to file a claim for the over withholding amount if they believe excess Social Security taxes were withheld on all taxable wages.

11. Employees on domestic LTTT must enter the information in ETS. Employees who are on domestic or foreign LTTT, must use Purpose Code "L" for LTTT expenses associated with TDY travel, and Purpose Code "W" for LTTT expenses associated with training travel.

12. A copy of Form 12654 must be retained, along with other required supporting documentation, for LTTT travel vouchers with the employee personnel file in compliance with GRS 1.1, item 010 Financial Transaction Records Related to Procuring Goods and Services, Paying Bills, Collecting Debts, and Accounting, records retention authorized disposition.

13. The Form 12654 should be faxed or scanned into ETS each time a voucher is filed. Also, if the employee submits a manual voucher using Form 15342, Travel Voucher, then the Form 12654 should be submitted to Travel Operations each time a voucher is filed.

14. Taxable travel-related payments are not considered basic pay for the purpose of the Thrift Saving Plan (TSP).

15. If there was no LTTT travel authorization and withholding on the voucher, the manager and employee should complete and sign the travel authorization as soon as possible to correct a potential incorrectly classified travel vouchers. All vouchers with expenses that should have been charged under purpose code "L" for LTTT expenses will require manual intervention by Travel Operations. If travelers did not classify their vouchers properly, they should submit a statement to CFO.FM.Travel.Review@irs.gov giving an accounting of the LTTT transaction. Travel Review will instruct Travel Operations to reclassify the specific vouchers and amounts to taxable or non-taxable. Long-term travel is considered income under the Internal Revenue Code. Also, not classifying LTTT accurately violates established tax reporting requirements.


**1.32.11.6.2** **(07-02-2019)**

#### Extended TDY Tax Reimbursement Allowance

1. This section provides the guidance and instructions supplementing FTR Chapter 301, Subchapter B, Part 301-11, Subpart F, [Extended TDY Tax Reimbursement Allowance](http://www.gsa.gov/portal/ext/public/site/FTR/file/Chapter301p011.html/category/21868/#wp1089971)(ETTRA).

2. The ETTRA reimburses employees for their federal, state, and local income tax liability incurred as the result of being reimbursed for travel expenses while on LTTT. The Travel and Transportation Reform Act of 1998 authorizes federal agencies to reimburse employees for federal, state, and local income taxes incurred as a result of LTTT. The employees will be reimbursed substantially for the additional federal, state, and local income tax liabilities. The income tax reimbursement will be paid in two parts:



1. A withholding tax allowance (WTA) which is calculated and paid when the voucher is paid; and

2. A final ETTRA paid after the end of the calendar year during which an employee was reimbursed for LTTT expenses.


3. Employees are required to file an ETTRA claim if they received taxable reimbursements associated with LTTT travel during the previous year and received a WTA.

4. Employees must file their ETTRA claim no later than six months (180 days) after receiving notice of the need to file. If employees do not file an ETTRA claim, it will be assumed that their ETTRA amount is zero. Consequently, employees would have to repay the amount of the WTA previously paid to them for the related reimbursements. Employees may request an extension of the filing date; however, for Travel Operations to consider the request, they must show just cause, such as approval of extension to file their current year federal tax return.


**1.32.11.7** **(01-21-2025)**

### Arranging for Travel Services, Paying Travel Expenses, and Claiming Reimbursement

1. This section provides the guidance and instructions supplementing FTR Chapter 301, Subchapter C, Parts 301-10.110, _Use of Contract City Pair Program Fares_, and 301-50, 301-51 and 301-52, [Arranging for Travel Services, Paying Travel Expenses, and Claiming Reimbursement.](https://www.ecfr.gov/current/title-41/subtitle-F/chapter-301/subchapter-C/part-301-50)


**1.32.11.7.1** **(01-21-2025)**

#### Arranging for Travel Services

01. This section provides the guidance and instructions supplementing FTR Section 301-10.110 and FTR Subchapters 301-50 through 301-52. These provisions address the use of contract city pair program fares, arranging for travel services, paying travel expenses, and claiming reimbursement, respectively.

02. Employees must use ETS for transportation (air/rail), car rental and hotel reservations.

03. If an employee fails to use ETS or TMC, the employee will become responsible for any additional costs such as outside vendors’ transaction fees, electronic ticketing fees, delivery fees or cancellation fees. Request to claim any travel expenses incurred by arranging travel outside of the ETS or TMC (including nightly lodging rate), requires approval from the director of Travel Management. Employees must submit Form 15299, Travel Approval Request, to the cfo.fm.travel.review@irs.gov before claiming the expense. In addition, the approving official may take appropriate disciplinary actions as stated in the IRS Guide to Penalty Determinations, Failure to Observe Written Regulations, Orders, Rules or the IRS Procedures. An audit may result in a referral to Labor/Employee Relations and Negotiations for further determination of disciplinary action for failure to comply with official travel policy.

04. TMC services include both online and agent-assisted travel reservations. The TMC will conduct quality checks to ensure the reservation is complete and provide travel reservation support.

05. Employees must use a contract City-Pair Program fare for scheduled air passenger transportation service when one is available unless one of the limited exceptions exists: (Refer to FTR 301-10.110)



    1. There are no accommodations available on any scheduled contract city pair program flight arriving to your destination in time to accomplish the purpose of your travel or use of contract service would require you to incur unnecessary overnight lodging costs which would increase the total cost of the trip;

    2. The contractor’s flight schedule is inconsistent with explicit policies to scheduling during normal working hours;

    3. A non-contract carrier offers a lower fare to the general public that, if used, will result in a lower total trip cost to the government (the combined cost of transportation, lodging, meals and related expenses considered); or

    4. Cost effective rail transportation is available and is consistent with mission requirements.


Note: Personal airline preference or frequent flyer membership is not a justification to book a non-contract airline when one is available.



06. Employees may go directly to the TMC (instead of using ETS) in the following situations:



    1. Booking international reservations with multiple destinations.

    2. Traveling within the next 24 hours.

    3. Changing/modifying existing reservations which have already been ticketed.

    4. Booking hotel only reservations for remote locations (a higher fee is charged at the time of authorization approved or on day of arrival if reservation is not canceled timely).

    5. Accommodating a disability and/or special needs (for example, second seat required, companion travel, service dogs).

    6. Unable to find a hotel at or below per diem in ETS for the specific TDY location.


07. Employees should always check to see if there is a tax exemption form available for the TDY location they are traveling to that would allow an exemption for the lodging taxes. Employees must pay for their lodging with their government travel card to qualify for lodging tax exemption. Employees may need to fill out a lodging tax exemption form and present it at check-in. The lodging tax exemption forms can be found on the Traveler’s Toolkit.

08. The employee may reserve a room by contacting the hotel directly if:



    1. Attending a conference, training or meeting where a block of rooms have been procured or arranged for participants and they have been instructed to call the lodging facility directly to book one of the rooms within the block; or

    2. Booking non-conventional lodging for an extended TDY of 30 days or more (Refer to IRM 1.32.11.7.1(8)(a)); or

    3. OCONUS travel and reservations have been booked by the Department of State or US Consulate for the safety of the employee.



       ### Note:



       The employee must provide documentation of the block of rooms, approval of non-conventional lodging or supporting documentation of booking completed by Department of State or US Consulate.


09. You may be reimbursed the cost of other types of non-conventional lodging when there are no conventional lodging facilities in the area (e.g., World’s Fair or other international sporting event) and the TDY assignment is for 30 nights or more. Such lodging includes college dormitories or similar facilities or rooms not offered commercially but made available to the public by area residents in their homes. Refer to IRM 1.32.11.1.6(ac), Terms/Definitions, for definition of non-conventional lodging.



    1. Employees are required to stay in a fire-safe facility when commercial lodging is not available. Some home-sharing rentals may not meet the fire-safe requirements and cannot be used. For an employee to use a home-sharing rental, an exception must be approved in advance by the Associate CFO for Corporate Accounting and the approval must be uploaded into ETS. Exception requests should be submitted in writing by the business unit head of office no later than 14 days prior to the start date of the travel and should detail the reasons why non-conventional lodging is needed and include evidence that traditional hotels were not available. Employees must use GSA contract vendors when securing non-conventional lodging. They must also include documentation showing that the home-sharing rental meets the Hotel and Motel Fire Safety Act and Federal Emergency Management Agency (FEMA)( https://apps.usfa.fema.gov/hotel/) requirements. The written request and all supporting documentation must be submitted to CFO.FM.Travel.Review@irs.gov. To be eligible for gainsharing, home-sharing rentals must be approved in advance. Non-conventional lodging will not be approved for an employee’s convenience (having family traveling with them).


10. The TMC will email an itinerary confirming the reservation to the email address listed in the employee’s profile. If an employee does not receive an email itinerary within 24 hours after the approving official has approved the authorization, they should contact the TMC.

11. Unless otherwise requested, most refundable reservations will be ticketed two to three days in advance of the travel departure date. Upon ticketing, the TMC will email an invoice to employees, as a confirmation of ticketing. Restricted and penalty fares usually require immediate ticketing. Amtrak tickets may be issued in advance as Amtrak has different ticketing requirements.

12. If an employee needs to cancel their reservation, they should immediately take the following actions to avoid unnecessary fees:



    1. Reservations made through ETS, which have not been ticketed, should be canceled in ETS. Reservations made by contacting the TMC for agent assistance may be canceled through ETS or by calling the TMC directly. If the reservation has not yet been ticketed or invoiced (car/hotel only), no transaction fee will be incurred. Employees also need to cancel the authorization in ETS.

    2. Reservations which have been ticketed cannot be canceled in ETS. Employees must contact the TMC directly to cancel the reservations and they will incur the TMC transaction fee. Employees may be reimbursed for the TMC fee if they submit a voucher and the approving official determines that the cost was unavoidable for official reasons.


13. The ETS allows employees to make as many changes as necessary for air, hotel and/or car reservations after employees have submitted (booked) their reservation for purchase prior to ticketing. Reservations are set up for ticketing 3-4 business days prior to departure or when the manager has approved the authorization in ETS for car/hotel only reservations. However, once the TMC has issued tickets, employees will not be able to make any changes in ETS. If a change in travel plans occurs after the ticket has been issued, they need to call the TMC to make the change. Employees will be charged a full-service Concur Government Edition (CGE) transaction fee for the change, in addition to their previous CGE reservation fee, regardless of whether they made the initial arrangements using ETS. A CGE reservation fee is charged each time a ticket is issued.

14. In the event the trip is canceled or rescheduled by the airlines, and it is within the airline's control, the airline is required to book employees on its next available flight, at no additional cost.

15. If employees miss their flight, they need to call the TMC for assistance.

16. The TMC has a live representative to assist with emergency travel. The emergency phone number is listed on the itinerary. If employees have an after-hours travel emergency or need to resolve an en route problem, employees need to call the TMC directly for assistance.

17. If round-trip Amtrak tickets are equal to or less than $100, employees may purchase tickets directly from Amtrak using the government travel card or personal funds. Employees must still enter their authorization and voucher in ETS. If round-trip Amtrak tickets cost more than $100, employees must use their government travel card and go through the TMC to book the reservations.

18. If employees want to pick up tickets at an Amtrak station kiosk, they should do the following:



    1. Book the reservation by calling the TMC.

    2. Once ticketed, take the e-ticket invoice from the TMC to the Amtrak station.

    3. Retrieve the boarding pass from the Amtrak kiosk.

    4. Pay for the tickets at the Amtrak station using the government travel card.


19. Employees must use ETS to make their reservations for international travel. Employees should contact the TMC directly to book international travel with multiple legs as the TMC is better able to assist them. Employees must get prior approval for foreign travel from LB&I in accordance with IRM 1.32.11.5.5, Foreign Travel, before making their reservations.

20. Travel expenses requiring special approval are handled in ETS by a feature called "conditional routing," which allows for various travel expenses to be routed to the appropriate official for approval. This includes but is not limited to: first-class, business-class, and premium economy airfare, foreign travel and use of the CBA.

21. The ETS defaults to etickets. Paper tickets are issued only when itineraries cannot be eticketed. Please note, travelers will not be reimbursed for fees associated with paper tickets when etickets are available. Employees requesting paper tickets for personal reasons will need to provide a personal form of payment to the TMC at the time of reservation.

22. The list of hotels displayed in ETS are not within the per diem rate for that destination. The list of available hotels that ETS provides to employees does not specifically isolate "per diem" hotels; some rates listed will be over the allowable per diem rate. Employees will need to know the per diem rate for the destination and then find a suitable hotel from the list of hotels. Links to domestic and international per diem tables are available on the hotel ETS request page.

23. If employees choose to drive rather than fly to the TDY and flying is the authorized, they must complete Form 15278, Travel Cost Comparison Worksheet, and attach it to the authorization to compare the constructive official travel transportation related-cost versus the actual travel transportation related-cost. Employees must attach a copy of the documentation used to estimate the constructive cost of common carrier and/or car rental.

24. Once the travel is completed, employees must update and attach Form 15278, Travel Cost Comparison Worksheet, and update the voucher to reflect any changes that may have occurred. Reimbursement is limited to the lesser amount of the official travel or the actual travel costs. Employees must attach a copy of the documentation used to estimate the constructive cost of common carrier and/or car rental.

25. Employees need to follow the instructions available on the IRS Source website for access to ETS.

26. The ETS has an online training course available through ITM. There are also specialty courses available for approving officials, reviewers, preparers and conditional routers.

27. Employees can find more about ETS by going to the Traveler’s Toolkit.


**1.32.11.7.1.1** **(01-21-2025)**

##### Personal and Official Travel Combined

1. Employees who, for personal convenience, travel by an indirect route or interrupt travel by a direct route are personally liable for any additional costs. In the case of indirect or interrupted travel, reimbursement cannot exceed the constructive cost of direct routing or the actual cost of travel, whichever is less. Example: An employee’s official assigned duty station is Dallas, TX and they have been directed to travel to Washington, DC; however, the employee already has a personal trip planned the week before the scheduled trip to DC in Orlando, FL. Employee travels from Orlando, FL to DC rather than Dallas, TX to DC. The employee’s reimbursement will be limited to the cost of travel, if lesser, had the employee traveled from Dallas to DC. The employee is responsible for any additional costs above that limit.

2. Employees are not able to use ETS to make travel reservations that include, for personal convenience, indirect routes or additional stops. The ETS is for official government travel only.

3. Employees who wish to travel by an indirect route for personal convenience must call the designated TMC. The TMC will book a one-way official travel fare (if any) of the proposed itinerary that involves travel between the official station/POD and TDY. This fare must be purchased with the employee's individually billed government travel card account (IBA) or the centrally-billed account (CBA) if the traveler hasn’t received their (IBA). The TMC will also notate the total cost of a round-trip official travel fare on the itinerary/invoice, to be used on the Travel Cost Comparison worksheet described in paragraph (4).

4. The TMC may book the indirect travel route portions of the trip. Such tickets must be a fully refundable fare open to the public; otherwise, if official travel is canceled, the employee will be responsible for the non-refundable fare. Government contract fares may not be used for travel by an indirect route for personal convenience. The employee will be charged a non-reimbursable leisure fee. An additional fee applies for each ticket issued. Both the tickets and associated fees must be charged to a personal credit/debit card; the IBA or CBA may not be used for travel by an indirect route for personal convenience.

5. Employees must complete Form 15278, Travel Cost Comparison Worksheet, and attach both the official travel receipt and the personal travel receipt to the ETS voucher. Employees may only claim the lesser of the actual cost of the airfare or rail expenses by indirect route or the constructive cost of travel by direct routing.

6. The IRS must limit payment of travel costs to those which are necessary to accomplish the mission in the most economical and efficient manner and in accordance with the rules stated throughout FTR 41 CFR 301-2.2. The FTR specifies that an employee performing a TDY assignment must "travel to \[their\] destination by the usually traveled route unless \[the\] IRS authorizes or approves a different route as officially necessary." Under 41 CFR 301-10.7 and 301-10.8, if an employee travels by an indirect route, or interrupts travel for the employee’s personal conveniences, the "employee’s reimbursement will be limited to the cost of travel by a direct route or on an uninterrupted basis." If there are any additional costs resulting from the change in route or interruption in travel, the employee is responsible for those costs. The employee is responsible for excess costs resulting from indirect travel.

7. When employees complete their official travel and remain at or arrive early to the TDY location for personal reasons over the weekend, they can use a city-pair ticket and charge the round-trip airfare to their government travel card. If they decide to change the ticket to extend their stay, they are responsible for any additional fare charges and fees incurred.

8. Employees who elect to drive for personal reasons must follow the guidance in IRM 1.32.11.5.1.5, Privately Owned Vehicle (POV).

9. Employees combining personal with official international travel must also refer to IRM 1.32.5.2 (8), Responsibilities of International Travelers for further restrictions.


**1.32.11.7.2** **(07-02-2019)**

#### Fees

1. The ETS charges two fees, a CGE reservation fee and a CGE voucher fee when booking official travel reservations. The CGE reservation fee combines both ETS and TMC fees for reservations made within ETS or directly with the TMC. The CGE reservation fee is charged when the ticket is issued, when the authorization is approved (car, hotel and some rail fares), or on the day of arrival on car/hotel only reservations that are not canceled timely.

2. The CGE reservation fee automatically populates on an ETS travel authorization when employees complete their authorization in ETS.

3. Employees will be charged an additional CGE transaction reservation fee if another ticket is issued because of a required change to the itinerary.

4. The ETS will automatically remove the CGE reservation fee when all reservations are removed from an adjusted or amended authorization that has not been stamped ticketed. If the ticket has been issued and the trip has been canceled, the employee will need to file a voucher for the CGE fee.

5. The online CGE reservation fee will change to an agent-assist CGE transaction fee when an agent intervention/assistance is necessary (i.e., credit card declines, authorizations not approved timely, responding "Yes" to an email regarding an unapproved authorization).

6. The CGE voucher fee is a charge when using ETS to process a voucher. This fee is paid directly to ETS. The fee auto-populates in the authorization and is charged when the voucher is approved. The fee amount varies based on the type of travel, local or city-to-city, and cannot be edited.

7. The CGE voucher fee appears automatically on each travel voucher and is paid by the IRS after each travel voucher is processed. Employees should not claim CGE fees as reimbursable expenses on their travel vouchers.


**1.32.11.7.3** **(07-02-2019)**

#### Profiles

1. The employee profile provides the TMC and the ETS information needed to make a reservation in accordance with the employee’s preferences. It includes the employee's name, home and office station mailing addresses, office phone number, IRS email address, billing information, preferred airport, frequent flyer numbers, preferred airline seating, and any special accommodations needed. Employees must ensure profile information is correct before booking reservations or creating travel documents.

2. In accordance with the new Transportation Security Administration (TSA) requirements, the name printed on an employee’s ticket must match the name identification (ID) in the ETS profile used at the airport security checkpoint.

3. Frequent flyer membership names must match the ETS profile name exactly to ensure reservations may be booked successfully online in ETS.


**1.32.11.7.4** **(11-04-2021)**

#### Paying Travel Expenses Using the Government Travel Card

1. If an employee is deemed eligible for a government travel card and is expected to travel, the card must be issued within 45 days of reporting for duty. Travel cards should be activated upon receipt.

2. Employees should use the travel card to the maximum extent possible. At a minimum, they must use the government travel card to pay for transportation, lodging, rental cars, rental car fuel/oil and baggage expenses.

3. Employees who are not eligible to receive a government travel card, must use the Centrally Billed Account (CBA) for transportation expenses.

4. The features of the standard and restricted travel cards are as follows:



1. **Standard Government Travel Card** \-\- includes a standard monthly card limit of $5,000, a merchant category code template for official travel expenses, and Automated Teller Machine (ATM) access.

2. **Restricted Government Travel Card** \-\- includes the same benefits of the standard travel card; however, ATM access is not granted. For additional information on the government travel card, refer to IRM 1.32.4, Government Travel Card Program.


5. New employees are exempt until they obtain the government travel card. New employees who will travel are expected to obtain and activate a travel card as soon as it is received.

6. Employees may not use their government travel card for any personal expenses including:



01. Personal items and services

02. Personal airline tickets and companion tickets

03. Restaurants at the official assigned duty station/POD

04. Alcohol and alcoholic beverages, unless consumed with a meal and no separate charge is made

05. Office supplies

06. Gifts/souvenirs

07. Long distance calls (except for calls billed to the hotel room), unless work related or an emergency

08. Fuel for a government-owned vehicle (use the fleet purchase card)

09. Conference fees

10. Expenses associated with obtaining meeting space

11. Gambling


7. The IRS exempts the following groups of employees from the mandatory use of the government travel card:



1. Employees who have an application pending for the government travel card.

2. Employees for whom the issuance of a government travel card, would adversely affect the mission of the IRS or put the employee at risk.

3. Invitational travelers.

4. Employees with suspended or canceled government travel cards.


8. Employees seeking an exemption from use of the government travel card must prepare a memorandum through their manager requesting an exemption and submit it by email for approval to the appropriate office:



1. The Director, Credit Card Services, has the authority to grant exemptions for financial hardship and religious reasons.

2. The Director, Resource Solutions, in LB&I may grant exemptions for international travel on a case-by-case basis.

3. The Director, Travel Management, has the authority for all other reasons.


9. Management may take disciplinary actions when a government travel card has been used inappropriately. Disciplinary actions range from oral and written reprimands, to possible suspension without pay, or removal. Managers should contact Labor/Employee Relations and Negotiations for advice and assistance regarding disciplinary action.


**1.32.11.7.5** **(11-04-2021)**

#### Paying for Common Carrier Transportation Expenses

1. Employees must use one of the following methods for payment of common carrier transportation expenses:



1. For passenger transportation services costing $100 or less round-trip, employees should use a government travel card. If the government travel card is not accepted or the employee has been exempted from mandatory use under IRM 1.32.11.5.4, the employee may use personal funds.

2. For passenger transportation services costing over $100 round-trip, employees must use a government travel card or the CBA. Employees **may not** use cash, personal checks or personal credit cards, for any common carrier expenses that total more than $100 round-trip, without prior approval per Delegation Order 1-49.

3. For baggage charges, employees must use a government travel card. If the government travel card is not accepted or the employee has been exempted from mandatory use under IRM 1.32.11.5.4, the employee may use personal funds.


2. The following payment methods are considered the equivalent of cash:



1. Personal debit/charge cards

2. Cash withdrawals obtained from an ATM using a government travel card

3. Checks, both personal and travelers


3. If employees make unauthorized cash purchases of common carrier transportation outside of ETS or the TMC, the reimbursement will be limited to the cost of such transportation using the authorized booking method. Employees must submit a Travel Approval Request to the CFO.FM.Travel.Review@irs.gov mailbox before claiming this expense.


**1.32.11.7.6** **(11-04-2021)**

#### Travel Advances

01. Employees will use the ATM feature of their government travel card to obtain advances. If an employee has a restricted government travel card or no card at all, then the approving official may authorize the issuance of travel advances through ETS or a manual travel authorization. If approved, employees can only receive one advance per authorization. The approving official should minimize the use of cash travel advances.

02. Employees must use the following method to obtain a travel advance:



    1. **Automated Teller Machine (ATM)** \-\- If employees have a government travel card with a standard cardholder status, they may obtain cash from the ATM for expenses that cannot be charged to the government travel card. A limit of $100 per day, with overall ATM withdrawal limit of $1,000 per month, is allowed for official travel expenses.

    2. **Restricted Government Travel Card (with ETS access)** \-\- If employees have a restricted government travel card with ETS access, they can get a travel advance for up to 40% of all their reimbursable expenses, except transportation costs. The advance is deposited into their account by EFT.

    3. **Restricted Government Travel Card (without ETS access)** \-\- If employees have a restricted government travel card and no ETS access, then they can get a travel advance for up to 40% of all their reimbursable expenses, except transportation costs. Employees need to submit a Form 13635, Manual Travel Authorization, with Section 3, Travel Advance, completed and approved, to Travel Operations. The advance is deposited into their account by EFT.

    4. **No Government Travel Card** \-\- If employees are exempt from using the government travel card under IRM 1.32.11.7.4(7) an (8), Paying Travel Expenses Using the Government Travel Card, they may request an advance up to 100% to cover all expenses excluding common carrier transportation, by submitting a ETS authorization or a Form 13635, Manual Travel Authorization, with Section 3, Travel Advance, completed and approved, to Travel Operations. The advance is deposited into their account by EFT. If they request a manual travel advance, they **must file** a manual travel voucher.


03. If employees obtain an ATM cash advance, they do not account for the cash withdrawal on their voucher because it is accounted for through their travel expenses. When filing the travel voucher, they will enter all their expenses as they normally do.

04. The ATM cash withdrawal service fees and the 2.5% cash advance fee can be claimed as a miscellaneous expense.

05. The ATM cash advance can be used to purchase fuel prior to official travel and taxi expenses that cannot be charged to the individually billed government travel card. See FTR 301-51.200 for other expenses for which an employee may receive a travel advance.

06. There is a limit on the amount of an advance employees can receive on an authorization if they are performing LTTT travel. The travel advances cannot exceed the estimated cost of the trip minus all taxes.

07. If employees are eligible for an advance by EFT, it takes three to five days from the date the approving official approves the advance request for the EFT to process and be deposited in the designated account. If employees wish to receive the advance two to three days prior to the departure, then the approving official needs to approve the advance request at least five working days before the departure date.

08. An employee’s travel advance must be liquidated when:



    1. Their trip is canceled or postponed.

    2. Their travel authorization expires.


09. If the employee’s trip is canceled, postponed, or the travel authorization expires, the employee must submit payment by check or money order within five days made payable to the IRS and mail it to the following address:




     Internal Revenue Service


     ATTN: Debt Collection Unit


     P.O. Box 9002


     Beckley, WV 25802

10. When employees file their travel voucher, ETS will automatically apply the travel reimbursement to any outstanding advance(s). There are no exceptions to liquidating an advance at the time employees file a travel voucher. Employees **must liquidate** the advance when they file their voucher.

11. Employees cannot liquidate their travel advance with a supplemental voucher after the final voucher is filed because the travel advance is no longer available in ETS. Any unliquidated travel advance will be converted to an employee debt when the final voucher is processed. The approving official is responsible for monitoring the travel advance(s) to ensure repayment is made timely.

12. The portion of the travel advance which exceeds the travel expenses claimed on an approved travel voucher becomes a debt upon completion of the trip for which the advance was issued.

13. When the outstanding advance exceeds the travel expenses on the travel voucher, employees must submit a check or money order for the excess amount. The check or money order must be made payable to the IRS and submitted to:


     Internal Revenue Service


     ATTN: Debt Collection Unit


     P.O. Box 9002


     Beckley, WV 25802-9002

14. Employees need to be aware that travel advances can be used to offset delinquent debts they owe to a federal or state agency through the Treasury Offset Program (TOP). If employees owe a delinquent debt to a federal or state agency and that agency refers the debt to Treasury, then Treasury will offset any federal payment due to the employee to enforce collection of the delinquent debt. Federal payments eligible for offset include the employee’s federal salary, travel advances and reimbursements, tax refunds, and federal retirement payments. If the advance is offset by TOP, the employee must pay back the travel advance when filing the voucher.

15. If employees’ travel advances were processed in ETS and intercepted through TOP to pay a delinquent debt they owe to the IRS (for example, an unliquidated prior travel advance) or another debt owed, they cannot request a manual travel advance. Employees cannot receive two advances for the same authorization.

16. If employees do not submit a check or money order for the full amount that exceeds the travel expenses with their approved travel voucher to fully liquidate the travel advance, it is considered a debt and subject to the debt collection procedures provided by applicable legislative and regulatory authority, including the Debt Collection Act of 1982, Public Law 97-365, Debt Collection Improvement Act of 1996, Public Law 104-134, and the Federal Claims Collection Standards. These authorities provide for the assessment of interest, penalties, and administrative charges, and collection by administrative, salary, and tax-refund offset.

17. If employees do not repay their travel advance upon notification that their trip was canceled, postponed, or if they do not file their travel voucher within 30 days of the end of the travel date, and the authorization expires, the entire amount of the travel advance is considered a debt and subject to the debt collection procedures.

18. The travel advance becomes taxable if it remains outstanding for more than 150 days from the date on the first deobligation notification the employee received from the ETS. Additionally, if the advance becomes taxable, the employee must still repay the advance in full.

19. The travel advance will not be reported as taxable income if employees file a travel voucher substantiating the expenses and return any excess amount to Travel Operations within 150 days from the first deobligation notification. Employees should liquidate the advance by submitting a travel voucher within five workdays after completion of travel.

20. If an employee does not repay a travel advance when submitting a manual travel voucher, the approving official should return the voucher to the employee and request that Section 8 on Form 15342, Travel Voucher, be completed.

21. The Family Support Act of 1988, Public Law No. 100-485, requires the IRS to report, as taxable income, any overdue unliquidated travel advance.


**1.32.11.7.7** **(01-21-2025)**

#### Claiming Reimbursements

01. Employees must sign the voucher within five days of the trip end date. If they don’t sign the voucher within 30 days of the trip end date, ETS will de-obligate the money used to fund the trip. The system will email notifications to the employee 5, 25 and 30 days before de-obligating the authorization. The employee will need to create a new authorization. Employees will not be able to modify the authorization once it has been canceled. If they have expenses associated with the cancelled authorization, they are required to process a new travel authorization.

02. If employees travel on behalf of the IRS, they must account for their expenses through the travel voucher process. They must submit their travel voucher in one of two formats: electronically using ETS, or manually, if the travel authorization was manually submitted. Employees must submit the voucher within five workdays after completion of travel or every 30 days for continuous travel.

03. Employees must provide the following information on their travel voucher:



    1. The dates of arrival to and departure from the TDY location and any personal stopovers, if they did not travel directly to or from the TDY location. Do not include stopovers to change planes.

    2. The daily M&IE allowance amount.

    3. All common carrier charges and lodging expenses.

    4. Expenses for telephone calls, local transportation fares, mileage and parking fees.

    5. Personal time taken during the TDY travel.

    6. When the approving official limits the M&IE reimbursement rate to below the maximum M&IE for the locality concerned, employees must state the daily reduced rate.

    7. LOA information.


04. The approving official should, within seven calendar days, approve or return the voucher for correction to ensure payment within 30 calendar days after submission by employees.

05. If employees file through ETS, the reimbursement will occur through a split disbursement process. If they file a manual Form 15342, Travel Voucher, they will receive reimbursement for all claimed expenses by EFT.

06. Employees are required to use split disbursement. Split disbursement is the default payment method for ETS. All employees have the option to change the method and amount of payment (i.e., meals and incidental expenses not charged on the travel card). However, if the method and amount of payment is changed, employees will be required to explain why the default split disbursement payment method was not used, which will be evaluated as part of the ETS pre-audit process.

07. Split disbursement permits direct payment via EFT to the government travel card and employee. Charges incurred on the travel card are disbursed to the bank and any residual amounts to the employee for expenses not charged to the government travel card. All airfare, lodging, rental car, and non-mileage expenses charged on the travel card will be credited to the government travel card account after the approved voucher is processed and the payment will go directly to the government travel card issuer. Employees will receive a bill reflecting the charges and the payments processed from ETS. The government travel card issuer will bill employees for the balance of any unpaid amounts.

08. If employees have travel expenses that should be charged to a different LOA, the office directing the travel is responsible for providing instructions to the traveler containing the correct LOA to use when filing travel vouchers.

09. Employees must provide receipts and supporting documentation when they file their travel voucher for:



    01. Lodging - to include itemized hotel receipt and TMC invoice indicating CGE reservations fees and form of payment

    02. Airfare - DTI invoice indicating airfare, CGE reservation fees and form of payment

    03. Approval for actual expenses - first-level executive (if applicable)

    04. Bus fare (en route to and from the TDY location) - TMC invoice indicating fare, CGE reservation fees and form of payment

    05. Rail fare (en route to and from the TDY location) - TMC invoice indicating fare, CGE reservation fees and form of payment

    06. Rental car expenses including fuel/oil expenses regardless of dollar amount - to include rental car receipt, TMC invoice indicating CGE reservation fees and form of payment; along with any fuel/oil receipts

    07. Parking receipts in excess of $25, to include cumulative parking (example: daily airport parking of $20 per day for 5 days equals $100, a receipt is required

    08. Internet/Wi-Fi regardless of dollar amount

    09. Telephone calls

    10. Baggage regardless of dollar amount

    11. Laundry expenses regardless of dollar amount. If a coin operated laundry facility is used, employees must notate in comments coin operated laundry facility used

    12. Individual expenses over $75

    13. Investigative expenses regardless of dollar amount should be redacted. If unable to redact, an explanation should be provided. Claims over $300 for a single day must be submitted on a SF1034, Public Voucher for Purchases and Services Other Than Personal. Additional information on Employee Reimbursables is available in IRM 1.35.3.5.2.9.

    14. Emergency expenses regardless of dollar amount with detailed description and approval from Travel Management to claim

    15. Reporting instructions for training classes

    16. Form 15278, Travel Cost Comparison Worksheet, with back up documentation (if applicable)

    17. Form 15299, Travel Approval Request (if applicable)

    18. Form TD F 70-02.6, Approval for First-Class and Business-Class Travel (if applicable)

    19. Form 1321, Authorization for Official Travel (if applicable)

    20. Form 15095, First-Class/Business Class Approval Checklist (if applicable)

    21. Form 15098, Foreign Travel Checklist (if appliable)

    22. Documentation of a block of rooms procured or arranged or reservations booked for OCONUS travel by the Department of State or US Consulate

    23. Any waivers or exceptions as stated throughout IRM 1.32.11 (if applicable)


10. An employee’s government travel card statement cannot be scanned or faxed as supporting documentation, nor as a receipt for lodging expenses, airfare or rental car expenses. The government travel card statement does not breakout the detailed travel expenses for reimbursement.

11. Employees should submit travel receipts by:



    1. Uploading all receipts required for expenses detailed in IRM 1.32.11.7.7(9), Claiming Reimbursements, into ETS with all applicable supporting documentation. The approving official must review the receipts in ETS before approving and signing the travel voucher. The ETS retains copies of the receipts for six years in compliance with GRS 1.1, item 010 Financial Transaction Records Related to Procuring Goods and Services, Paying Bills, Collecting Debts, and Accounting, records so they are available for subsequent audits. Employees may want to keep their original receipts for their records for six years.

    2. When filing a manual voucher, employees must attach all required receipts and all applicable supporting documents to their manual travel voucher for the approving official to review before signing the voucher. The approving official must retain the attached receipts for six years in compliance with GRS 1.1, item 010 Financial Transaction Records Related to Procuring Goods and Services, Paying Bills, Collecting Debts, and Accounting, records retention authorized disposition.


12. When filing a manual travel voucher, employees must provide all required receipts, or explain in writing why they are unable to provide the necessary receipts. The explanation must be acceptable to the approving official. If they submit copies of receipts, they must also attach a justification statement explaining the reason(s) why the original receipts cannot be provided. The approving official will return any voucher submitted with copies of receipts without a justification statement. If employees cannot provide a receipt, they must provide an explanation on the travel voucher indicating why the receipt was not provided. Inconvenience is not an acceptable explanation for failure to provide receipts.

13. Employees may claim reimbursement on the travel voucher for non-travel costs not directly related to the performance of travel but incurred during travel. Travelers must provide a detailed description and a receipt for any administrative expense regardless of dollar amount. Claims over $300 for a single day must be submitted on a SF1034, Public Voucher for Purchases. Additional information on Employee Reimbursables is available in IRM 1.35.3.5.2.9. Expenses included are:



    1. Lien fees

    2. Investigative expenses (For additional information see IRM 9.11.1.3.2 Accounting for Incidental Expenditures)

    3. Administrative summons expenses

    4. Right to Financial Privacy Act fees

    5. Third-party records


Investigative expenses, regardless of dollar amount, should be redacted. If unable to redact, an explanation should be provided. Claims over $300 for a single day must be submitted on a SF1034, Public Voucher for Purchases and Services Other Than Personal. Additional information on Employee Reimbursables is available in IRM 1.35.3.5.2.9.


14. Other non-travel expenses incurred during official travel such as office supplies must be claimed on SF1034, Public Voucher for Purchases, and submitted to Travel Operations for processing with the receipt(s).

15. Employees cannot submit claims for confidential expenses on travel vouchers.

16. Training and conference fees must be paid using a small purchase procurement method. Employees cannot claim a training or conference fee on a travel voucher. Employees should contact their business unit finance office for more information.

17. Employees must sign their voucher electronically in ETS and, if filing a manual voucher, must prepare their claim on Form 15342, Travel Voucher, and sign electronically. Any alterations to a manual travel voucher must be initialed.

18. The approving official must authorize and approve travel vouchers as provided in Delegation Order 1-30, Authorization and Approval of Official Travel within the United States.

19. The traveler and approving official are responsible for the validity of the voucher and must ensure all travel expenses are prudent, accurate, and necessary by acknowledging that they have read and understand the truth and accuracy statement before signing or approving the voucher.

20. The approving officials must do the following if they disallow an expense claimed on a travel voucher:



    1. If an employee files a voucher electronically and the approving official disallows an expense, the approving official must provide the reasons for the disallowance in the ETS and will return the document to the traveler.

    2. If an employee files a manual voucher and the approving official disallows an expense claimed on that voucher, then the approving official will issue a "Notice of Disallowance" and authorize payment of the amount of the travel claim which is not in dispute.

    3. Notify the employee of the disallowance.


21. Employees who challenge a disallowed claim must submit a request for reconsideration of the disallowed amount by sending the voucher back to the approving official with a full explanation of the circumstances and the reasons for considering the amount of reimbursement. If the approving official denies the request for reconsideration, employees may submit a request for reconsideration of the disallowance to CFO.FM.Travel.Review@irs.gov mailbox and must include:



    1. A full explanation of the circumstances and the reasons for the requested reimbursement of the disallowed amount.

    2. A full itemization for all disallowed items reclaimed.

    3. Receipts for the disallowed items that require receipts.

    4. A copy of the "Notice of Disallowance."

    5. The proper authority for the claim, if challenging the IRS application of the law or statute.


22. If an employee’s request to challenge a disallowed claim is approved by Travel Management, and if they submitted a voucher using ETS, they must process a supplemental voucher in ETS using the Amend link. If a manual voucher was submitted, employees need to:



    1. Prepare a new Form 15342, Travel Voucher, to claim the amount disallowed on the original voucher.

    2. Write Supplemental Voucher at the top of the new voucher.

    3. Sign and date the supplemental voucher.

    4. Attach a copy of the approval notice.

    5. Have the approving official sign and date the voucher.

    6. Attached any required receipt (s)

    7. Email to \*CFO BFC Travel Vouchers, or efax to 855-787-437 or mail the supplemental voucher to:


        Internal Revenue Service


        ATTN: Travel Operations


        P.O. Box 9002


        Beckley, WV 25802


23. If an employee’s challenge of a disallowed claim request for reconsideration is denied by Travel Management, the employee may submit the request reconsideration as follows:



    1. Bargaining unit employees should contact their Union representative.

    2. Non-bargaining unit employees whose claims are denied, may file a claim with the GSA Civilian Board of Contract Appeals (CBCA). (The burden is on the claimant to establish the timeliness of the claim and the liability of the claim based on the information submitted by the claimant and the IRS).


24. Employees will receive their reimbursement three to five workdays after the travel voucher is approved in ETS.

25. If a travel expense is inadvertently omitted from a travel voucher, employees may file a supplemental voucher to claim the expense. Employees must have receipts for amounts claimed over $75 on a supplemental voucher, just as required for an original voucher.

26. Employees who need to correct errors in an already paid voucher should do the following:



    1. For an omitted expense(s), file a supplemental voucher to add the omitted expense(s) and sign the voucher. The voucher will be processed, and the added expense will be reimbursed.

    2. For overpayments on the voucher, complete the Debt Collection Repayment Memo and make check or money order payable to the IRS. Submit the overpaid amount to Travel Operations at the following address: Debt Collection Repayment Memo, and make check or money order payable to the IRS and submit it to Travel Operations for the overpaid amount to the following address:


        Internal Revenue Service


        ATTN: Debt Collection Unit


        P.O. Box 9002


        Beckley, WV 25802-9002


**1.32.11.8** **(07-02-2019)**

### Using Promotional Materials and Frequent Traveler Programs

1. This section provides the guidance and instructions supplementing FTR Chapter 301, Subchapter C, Part 301-53, [Using Promotional Materials and Frequent Traveler Programs.](https://www.ecfr.gov/current/title-41/subtitle-F/chapter-301/subchapter-C/part-301-53)

2. Employees may join a frequent traveler program; however, the IRS will not reimburse any membership fees for a frequent traveler program.

3. Promotional materials and frequent traveler benefits may be used as follows:



1. Employees may use frequent traveler benefits earned on official travel to obtain travel services for a subsequent official travel assignment(s); however, they may also retain such benefits for their personal use, including upgrading to a higher class of service while on official travel.

2. If employees are offered such benefits resulting from their role as a conference planner or as a planner for other group travel, they may not retain such benefits for personal use. The employee may only accept such benefits on behalf of the federal government. Such accepted benefits may only be used for official government business.


**1.32.11.9** **(07-02-2019)**

### Death of Employee While in Travel Status

1. This section provides the guidance and instructions supplementing FTR Chapter 303, Part 303-70, [Agency Requirements for Payment of Expenses Connected with the Death of Certain Employees](https://www.ecfr.gov/current/title-41/subtitle-F/chapter-303).

2. Upon the death of the employee, the approving official needs to identify the travel expenses and prepare a manual authorization and travel voucher to claim the travel expenses on behalf of the employee. The approving official annotates "Employee Deceased" on the employee signature line, signs the voucher, and forwards for payment to Travel Operations at the following address:




    Internal Revenue Service


    ATTN: Travel Management Section


    Travel Operations


    P.O. Box 9002


    Beckley, WV 25802-9002


    Efax 855-787-4375, email \*CFO BFC Travel Vouchers






    Receipts must be obtained, where applicable and appropriate, and the travel agency contacted for a refund if a round-trip flight was involved.


**1.32.11.10** **(11-04-2021)**

### Travel Payments from Other Federal Agencies

1. The approving official must agree to acceptance of payment from another federal agency for employees to attend meetings, conferences or training.

2. Employees requesting payment from another federal agency must complete an Interagency Agreement - Travel Reimbursement Agency Pays IRS form between the IRS and the other federal agency and submit it to the approving official. This agreement must be completed before the travel begins and attached to the authorization in ETS.

3. There are two methods for the other federal agency to pay travel expenses:



1. Pay-in-kind - the federal agency pays all costs. There are no out-of-pocket expenses paid by the employee.

2. Direct Reimbursement - payment between agencies is handled via the Intra-Governmental Payment and Collection (IPAC) System.


4. When another federal agency is paying for an employee’s travel expenses, employees are required to have an approved travel authorization before travel. After an employee completes the travel, they must claim their expenses on a travel voucher to be reimbursed by the IRS. Employees may not claim travel expenses that were paid in-kind by the federal agency. Once an employee completes their voucher, the business unit submits a request for reimbursement to the paying federal agency. The business unit must contact Travel Operations if further instructions are needed.

5. The approving official determines, in advance of the employee's travel, that payment from a federal agency will cover some, or all, of the employee's allowable travel and subsistence expenses. If a federal agency does not pay the full cost of expenses that an employee incurs during travel, the approving official should state on the employee's travel authorization that the employee will be reimbursed the difference between the full allowances and the in-kind payment from the IRS.

6. If the employee’s request for a federal agency to pay travel expenses is disapproved by the approving official, the employee must graciously decline the travel payment from the federal agency. However, if the business organization determines that the participation is in the interest of the IRS, it may be prudent and appropriate for the IRS to fund the trip.

7. Subsistence allowances are usually limited to the maximum per diem, actual expense, or lodging prescribed in this guide.

8. The maximum subsistence allowance prescribed by the Secretary of State for travel to foreign areas may not be exceeded.

9. Employees may use first-class common carrier accommodations, if the other federal agency authorizes first-class transportation expenses and pays for the use of first-class common carrier accommodations. The employee must still meet the criteria for the use of first-class transportation and obtain prior approval from the IRS Commissioner in accordance with IRM 1.32.11.5.1.1, Airline Accommodations.


**1.32.11.11** **(07-02-2019)**

### Payment of Travel Expenses from a Non-Federal Source

1. This section provides the guidance and instructions supplementing FTR Chapter 304, [Payment of Travel Expenses From a Non-Federal Source](https://www.ecfr.gov/current/title-41/subtitle-F/chapter-304).

2. Employees may not accept payments from a non-federal source, except for Chief Counsel employees who, with appropriate approval, may accept travel payments from non-federal source under 5 USC 4111.


**1.32.11.12** **(03-28-2023)**

### Travel Forms

01. Form 15342, Travel Voucher

02. Form 13635, Manual Travel Authorization

03. Form TD F 70-02.6, First-Class and Business-Class Travel Request and Authorization

04. Form 13631-A, IRS Travel Savings

05. Form 8445, Statement of Income and Tax Filing Status

06. Form 14580, Request for Approval of Executive Travel Over 75 Nights-Operations Support

07. Form 14580-A, Request for Approval of Executive Travel Over 75 Nights-Commissioner Direct Report Organizations

08. Form 14580-B, Request for Approval of Executive Travel Over 75 Nights- Services and Enforcements

09. Form 12654, Authorization for Long-Term Taxable Travel

10. Debt Collection Repayment Memo

11. Form SF-1199-A, Direct Deposit Sign-Up Form

12. Form 15014, Reduced Per Diem City to City

13. Form 15095, First-Class/Business-Class Approval Checklist

14. Form 15098, Foreign Travel Documentation Checklist

15. Form 15278, Travel Cost Comparison Worksheet

16. Form 15299, Travel Approval Request

17. Form 15402, Justification Certificate for Use of a Foreign-Flag Air Carrier or Vessel


**1.32.11.13** **(11-04-2021)**

### Delegation Orders (DO)

1. This section provides delegation orders for travel:




| **Number** | **Title** |
| :-: | :-: |
| 1-5 | Reimbursement for Actual Expenses |
| 1-7 | To Authorize Attendance at Meetings at Government Expense |
| 1-8 | Approval of Foreign Travel |
| 1-10 | Invitational Travel |
| 1-30 | Authorization and Approval of Official Travel within the United States |
| 1-31 | Authorization and Approval of Tour Renewal Agreement Travel |
| 1-34 | Payment of Travel Expenses for Threatened Law Enforcement and Investigative Employees |
| 1-35 | Authority to Approve the Use of Non-Contract Air Carriers |
| 1-40 | Approval of Personal Funds Used to Purchase Common Carrier Transportation Over $100 |
| 1-48 | Approval of Business-Class Travel |
| 1-49 | Exemption to Travel Card Mandatory Use Policy |
| 1-67 | Authorization and Approval for Official City-to-City Travel of Six Months or More to a Single Location |


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-032-011#addtoany "Show all")

A2A