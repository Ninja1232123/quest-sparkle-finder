---
url: "https://www.irs.gov/irm/part1/irm_01-015-007"
title: "1.15.7 Files Management | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-015-007#main-content)

- 1.15.7  [Files Management](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881950218976)
  - 1.15.7.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881950152176)
    - 1.15.7.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881922745744)
    - 1.15.7.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881922185840)
    - 1.15.7.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881922751856)
    - 1.15.7.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881950216224)
    - 1.15.7.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881922181472)
    - 1.15.7.1.6  [Acronyms/Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881922179040)
    - 1.15.7.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881922599776)
  - 1.15.7.2  [Purpose of a Filing System](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881922592352)
  - 1.15.7.3  [Creating and Using a Filing Plan or System](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881949677280)
    - 1.15.7.3.1  [Creating a Files Plan or Filing System](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881949676320)
    - 1.15.7.3.2  [Defining a Files Group](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881949673040)
    - 1.15.7.3.3  [Sorting and Arranging Files](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881949771392)
    - 1.15.7.3.4  [Preparing Records for Filing](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881949766960)
    - 1.15.7.3.5  [Filing Stations and Requirements](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881949757600)
    - 1.15.7.3.6  [Establishing Suspense Files](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881949744912)
    - 1.15.7.3.7  [Establishing Cutoff Periods](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881921157664)
      - 1.15.7.3.7.1  [Cutting Off Subject Files](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881921152784)
      - 1.15.7.3.7.2  [Cutting Off Case Files](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881921150832)
      - 1.15.7.3.7.3  [Cutting Off "Special Event" Files](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881921149120)
    - 1.15.7.3.8  [Controlling Paper Charge-Out and Electronic Check Out Tool](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881921147088)
      - 1.15.7.3.8.1  [Charge-Out Forms](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881921143152)
  - 1.15.7.4  [Case Files](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881921136944)
    - 1.15.7.4.1  [Standardizing Case Files](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881921135904)
      - 1.15.7.4.1.1  [Separating Essential and Non-Essential Documentation](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881921133600)
    - 1.15.7.4.2  [Case Filing and Coding](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881921131216)
  - 1.15.7.5  [Subject Files](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881922668064)
    - 1.15.7.5.1  [Organizing Subject Files](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881922663776)
    - 1.15.7.5.2  [Subject Filing Codes](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881922655216)
      - 1.15.7.5.2.1  [Design of Subject Filing Codes](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881922652448)
  - 1.15.7.6  [Composite Subject Filing and Coding System](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881922647088)
    - 1.15.7.6.1  [Basics of Composite Filing and Coding Systems](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881922644032)
    - 1.15.7.6.2  [Basic Procedures](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881921569200)
  - 1.15.7.7  [Alphabetical Filing](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881921566304)
    - 1.15.7.7.1  [Individual Names](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881921563504)
      - 1.15.7.7.1.1  [Titles](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881921558224)
      - 1.15.7.7.1.2  [Foreign Names](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881921553328)
    - 1.15.7.7.2  [Business Names](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881921550960)
      - 1.15.7.7.2.1  [Firms with Individuals, Names](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881921549232)
      - 1.15.7.7.2.2  [Firm Names with Apostrophes](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881920938848)
      - 1.15.7.7.2.3  [Firm Names Containing Letters and Numbers](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881920933872)
      - 1.15.7.7.2.4  [Firm Names with Conjunctions, Prepositions, Articles](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881920928816)
      - 1.15.7.7.2.5  [Geographic Names and Compass Terms](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881920922992)
      - 1.15.7.7.2.6  [Abbreviations in Business Names](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881920917856)
      - 1.15.7.7.2.7  [Institutions and Organizations](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881920915376)
    - 1.15.7.7.3  [Alphabetic Distribution of Names](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881920911440)
  - 1.15.7.8  [Evaluating Files Operations or Systems](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881920909136)
    - 1.15.7.8.1  [Files Organization](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881920907280)
    - 1.15.7.8.2  [Files Management Administration](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881920904752)
    - 1.15.7.8.3  [Files Audit](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881920898768)
    - 1.15.7.8.4  [Files Surveys/Inventories](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881920890640)
  - Exhibit  1.15.7-1  [Alphabetic Filing Sequences of Individual Names](https://www.irs.gov/irm/part1/irm_01-015-007#idm139881954638448)

# Part 1. Organization, Finance, and Management

# Chapter 15. Records and Information Management

# Section 7. Files Management

* * *

## 1.15.7 Files Management

#### Manual Transmittal

January 14, 2025

#### Purpose

(1) This transmits revised IRM 1.15.7, Records and Information Management, Files Management.

#### Material Changes

(1) IRM references, website links, editorial updates and word revisions, in compliance with the IRS Style Guide, were made throughout this IRM.

#### Effect on Other Documents

IRM 1.15.7, dated March 12, 2024, is superseded.

#### Audience

All IRS divisions and functions.

#### Effective Date

(01-14-2025)

Michael J. Oser

Acting Director, Identity and Records Protection (IRP)

Privacy, Governmental Liaison and Disclosure (PGLD)

**1.15.7.1** **(01-14-2025)**

### Program Scope and Objectives

1. **Overview:** Records, paper and electronic, kept by and for an office play a major part in Internal Revenue Service operations. Organize documents so that complete, and accurate information is readily available when needed. Consistency in classifying, coding, and filing is the prime ingredient in managing files.

2. **Purpose:** This IRM section covers the following:



1. Standard practices and techniques for establishing an efficient filing system,

2. General instructions for controlling and safeguarding records, and

3. An appraisal guide for evaluating files operations.


3. **Audience:** These procedures apply to **all** IRS employees and contractors.

4. **Policy Owner:** Director, Identity and Records Protection - Records and Information Management (RIM).

5. **Program Owner:** The Records and Information Management (RIM) Program office, under Privacy, Governmental Liaison and Disclosure (PGLD) is the program office responsible for oversight of the Servicewide records management policy.

6. **Primary Stakeholders:** The Records and Information Management (RIM) Program office, under PGLD, promotes responsible recordkeeping practices for IRS employees and contractors to follow in accordance with federal laws, regulations, and procedures.


**1.15.7.1.1** **(08-10-2017)**

#### Background

1. In keeping with the Federal Records Act of 1950, as amended, and pursuant to Title 44, United States Code (USC) 3102, the IRS established a records management program - renamed Records and Information Management (RIM) Program - to ensure the economical and efficient management of IRS records. The RIM program provides guidance and ensures IRS records are efficiently and effectively managed until final disposition. The process of identifying and collecting information documents the function, flow, and description of records. It is important to identify exactly what types of records exist in a program or office, the volume of records, the location of the records, and the management of the records. This information is used for preparing files plans or filing systems.


**1.15.7.1.2** **(08-10-2017)**

#### Authority

1. 44 USC 3102 - Establishment of program of management

2. 44 USC 3301 - Definition of Federal Records

3. 36 Code of Federal Regulations (CFR) Chapter XII, Subchapter B - 1220.18 - What definitions apply to the regulations in Subchapter B?

4. 36 CFR Chapter XII, Subchapter B - 1222.34 - How must agencies maintain records?


**1.15.7.1.3** **(08-10-2017)**

#### Responsibilities

1. The **Servicewide Records Officer** is responsible for the various phases of the records management program specified in the Federal Records Act of 1950, as amended, and the Records Disposal Act of 1943. As such, the Servicewide Records Officer is responsible for:



1. All policies and instructions regulating IRS records management,

2. All IRS Official Records Schedules, including submitting updates for scheduling unscheduled records to NARA,

3. Guidance and instruction to Records Specialists and Headquarter Business Unit Information Resource Coordinator (BU/IRCs),

4. Compliance reviews,

5. Transfer of all permanent records to NARA,

6. Records disposition evaluations and appraisals, and

7. Liaison with NARA, Government Accountability Office (GAO), General Services Administration (GSA), Department of the Treasury, and various other federal agencies.


2. **Records Specialists -** assist employees in developing, establishing and evaluating filing operations for assigned BU. They look to the Servicewide IRS Records Officer for direction and guidance in policy matters.

3. **Information Resource Coordinators (IRC) -** monitor local office records filing operations. They consult with management and employees and look to Records Specialists for guidance.

4. This IRM is used by **all** IRS employees and contractors to ensure compliance with paper and electronic records management requirements.


**1.15.7.1.4** **(10-17-2023)**

#### Program Management and Review

1. The RIM Program is evaluated using the following reviews and reports:



   - **Records Management Self-Assessment (RMSA)**: The annual RMSA asks questions that assess compliance with records management statutes and regulations, as well as NARA policies and guidance.

   - **Federal Electronic Records and Email Management Reporting**: This report not only evaluates federal agency email management, it also seeks to assess the current state of all electronic records management at federal agencies (including email and permanent electronic records).

   - **Senior Agency Official for Records Management (SAORM) Annual Report**: This report gathers data on agency progress towards the goals of the Office of Management and Budget (OMB)/NARA Update to Transition to Electronic Records memo (M-23-07) and other important records management initiatives as identified by NARA.

   - **Form 14377, Records and Information Management Virtual Program Review Self Assessment Checklist**: This checklist is utilized as a self-assessment tool to assist the field site offices with records management policies and procedures. In addition, it measures RIM goals to stimulate better fiscal management.

   - **Form 14377-A, IRS Records and Information Management (RIM) Evaluation Checklist**: PGLD requires all business unit information resource coordinator (IRC) contacts to complete this form on a quarterly basis. The purpose of the form is to ensure and document IRS recordkeeping compliance as defined by NARA. Completing the Form 14377-A identifies to PGLD:IRP:RIM potential gaps for training opportunities to assist the business unit with their recordkeeping responsibilities.


**1.15.7.1.5** **(10-17-2023)**

#### Program Controls

1. **Records Management Mandatory Briefing**: Every IRS employee and contractor must protect the information they handle daily to carry out their job responsibilities. They must annually take the Records Management Mandatory Briefing Integrated Talent Management (ITM) course #62965, Records Management Awareness, to ensure IRS records management is efficient, effective, and compliant with all applicable records management laws and regulations.


**1.15.7.1.6** **(10-17-2023)**

#### Acronyms/Terms/Definitions

1. The table lists commonly used acronyms and terms:




| **Acronym** | **Term** |
| --- | --- |
| BU | Business Unit |
| FRC | Federal Records Center |
| GAO | Government Accountability Office |
| GSA | General Services Administration |
| GRS | General Records Schedules, Document 12829 |
| IRC | Information Resource Coordinator |
| NARA | National Archives and Records Administration |
| PGLD | Privacy, Governmental Liaison and Disclosure |
| RCS | Records Control Schedules, Document 12990 |
| RIM | Records and Information Management |
| USC | United States Code |

2. The following definitions apply to paper and electronic records, and filing systems:



01. **Administrative Files or Records -** budget, personnel, supply, and similar housekeeping or other files or records related to the agency's facilitative functions.

02. **Archival -** see Permanent Records.

03. **Case Files -** case (project) files are records, whether paper or electronic, that document the technical and professional work of the service. Case files may include income tax returns, audits, investigations, claims, contracts, or purchase orders.

04. **Centralized Files -** files accumulated by several offices, organizational units, or team members and maintained and supervised in one location.

05. **Charge-out Cards -** long colorful cards for documenting the removal of papers from a folder or the removal of a folder from the file. IRS employees must sign out documents/folders on charge cards to assist with returning files to their proper location, to avoid improper filing, and loss of IRS records.

06. **Closed Files -** a collection of related papers whose action is completed and to which it is unlikely that any additional documents will be added.

07. **Coding -** symbols which represent how a record or file is to be arranged.

08. **Collaborative Site Files -** files, usually in an electronic format, accumulated by several offices, organizations, units, or team members and maintained and supervised in one location, for example SharePoint.

09. **Convenience Files -** non-record copies of correspondence, completed forms, and other documents kept solely for ease of access, and reference, typically near the user's workspace.

10. **Current Records -** documents necessary to conduct the current business of an office and therefore generally maintained in office space and equipment. "Current" refers to the degree of activity, not how recent the dates might be.

11. **Cut-off Dates/Years -** breaking, or ending, files at regular intervals, usually at the close of a fiscal or calendar year, to permit their disposal or transfer in complete blocks or to permit new files to be established.

12. **Decentralized Files -** files maintained at several locations within an office. Decentralized files may be required to conform to various centralized controls.

13. **Electronic Record -** information recorded in a form that is machine-readable (e.g., information that only a computer can process, and which, without a computer, would not be understandable to people).

14. **File Copy -** copy of a document which is marked or recognized as the official or record copy, complete with enclosures, clearances, and/or collateral papers.

15. **File Station -** any location in an organization where records are maintained for current use.

16. **Files Management -** a planned program for filing practices in order to organize and maintain documentary materials properly, ensure their completeness, retrieve them rapidly, and dispose of them more easily.

17. **Files Plan -** a files plan is an office/organization tool for identifying records created/received within the organization, files arrangement, locations, transfer instructions, files retention and disposition instructions, and other specific instructions that provide guidance for effective management of records, including essential (vital) records.

18. **Non-current Records -** records required so seldom to conduct agency business that they must be moved to a holding area or directly to a records center.

19. **Non-record Material -** informational materials excluded from the legal definition of records or not meeting the requirements of that definition. Includes extra copies of documents kept only for convenience of reference, copies of material used only for informational purposes, stocks of publications and processed documents, and library or museum material intended solely for reference or exhibition.

20. **Reading Files -** correspondence arranged chronologically and maintained or circulated for reference.

21. **Records -** papers, maps, photographs, or other documentary material, regardless of physical form or characteristics, made or received by any agency of the United States Government under federal law or in connection with the transaction of public business and preserved, or appropriate for preservation, by the agency or its legitimate successor as evidence of the organization, functions, policies, decisions, procedures, operations, or other activities of the government or because of the information value of data contained.

22. **Records Control Schedule (RCS) -** document providing mandatory instructions for what to do with records (and non-record material) no longer needed for current government business, with provision of authority for the final disposition of recurring or nonrecurring records. The comprehensive IRS RCS comes from two sources; National Archives and Records Administration (NARA)-approved records disposition authorities for IRS program-specific records (published in Document 12990) and NARA's General Records Schedules (GRS) for administrative records series common to most federal agencies (published in Document 12829).

23. **Records Management -** to plan, control, direct, organize, train, promote, and take other action needed to manage an agency's record information in an efficient and economical way, in order to create, maintain, use, and dispose of records needed for the adequate and proper documentation of the policies and transactions of the agency.

24. **Records Management Program -** a planned program designed to provide a coordinated set of policies, procedures and activities needed to manage an agency's recorded information, encompassing creation, maintenance, use and disposition of records, regardless of media. Essential elements include up-to-date directives, training, publicizing the program, and evaluation.

25. **Records Retirement -** the process of moving records from office space to agency storage facilities or Federal Records Center (FRC).

26. **Records Specialist -** a person responsible for carrying out a records management program in cooperation with the Servicewide Records Officer.

27. **Schedule/Scheduling -** the process of developing mandatory instructions for what to do with records and non-record materials.

28. **Servicewide Records Officer -** the person assigned responsibility by the agency head for directing an agency-wide records management program.

29. **Special Records -** types of records maintained separately from textual or paper records because of their physical form or characteristics that require unusual care and/or because they are non-standard sizes.

30. **Suspense File -** records or copies serving as reminders of unfinished transactions that require follow-up action and must be brought to the attention of officials. Also called "tickler files" .


**1.15.7.1.7** **(10-17-2023)**

#### Related Resources

01. Records and Information Management SharePoint

02. Document 12829, General Records Schedules

03. Document 12990, IRS Records Control Schedules

04. Title [36 CFR Chapter XII, Subchapter B](https://www.govinfo.gov/content/pkg/CFR-2011-title36-vol3/pdf/CFR-2011-title36-vol3-chapXII-subchapB.pdf), Records Management codes

05. [44 USC 3102](https://www.archives.gov/about/laws/fed-agencies.html), Establishment of program of management

06. [44 USC 3301](https://www.archives.gov/about/laws/disposal-of-records.html), Definition of a record

07. IRM 1.15.1, The Records and Information Management Program

08. IRM 1.15.4, Retiring and Requesting Records

09. IRM 10.5.1, Privacy Policy

10. IRM 10.8.1, Policy and Guidance


**1.15.7.2** **(10-30-2013)**

### Purpose of a Filing System

1. An efficient filing system simplifies identifying, retrieving, and retaining records. It assists in selecting historical records for permanent retention, retrieving them, and promptly disposing of non-current records.


**1.15.7.3** **(08-10-2017)**

### Creating and Using a Filing Plan or System

1. This portion provides information on creating and using a paper or electronic records files plan or filing system.


**1.15.7.3.1** **(08-10-2017)**

#### Creating a Files Plan or Filing System

1. To create an efficient paper or electronic records files plan, it is necessary to:



1. Identify records that are necessary to do the job,

2. Establish a system for arranging the files, and

3. Determine a location of the files for easy access.


**1.15.7.3.2** **(08-10-2017)**

#### Defining a Files Group

1. Listed below are some basic groups of records and examples of each:



1. **Subject or General Correspondence.** Includes letters, memos, emails, telegrams, reports, etc. Subject files are discussed in further detail in _IRM 1.15.7.5_, Subject Files.

2. **Transitory Correspondence.** (Records routine in nature.) Examples include transmittal forms, correspondence, requests for information, emails, or publications, and announcements of savings bond campaigns, etc.

3. **Case Files.** (Also known as Project Files.) They constitute the largest single group of records in an office, related to investigations, contracts, and projects. The material, whether paper or electronic, always pertains to a specific action, event, person, organization, product, or thing. They are filed by name or number. See _IRM 1.15.7.4_, Case Files.

4. **Working Papers.** Background support material and working papers usually connected with case files. They are filed separately from case files but are retained in the files until the related case is closed.

5. **Technical Reference Material.** These usually include copies of reports, periodicals, manuals, handbooks, and studies. Non-record material usually involves research, statistical reporting, and information gathering. Technical reference material is not stored or filed with official records.

6. **Convenience Files.** Duplicate copies or non-record files, whether paper or electronic, that are used for quick reference. They are also known as chronicle files, reading files, or reference files.

7. **Film, Tape, or Disks.** Audio/visual records that constitute a basic file group because of their physical characteristics. They require separate storage and special care for preservation.

8. **Cartographic Materials and Drawings.** This basic group includes blueprints, maps, charts, aerial photos, engineer's drawings, etc. Their physical characteristics and sizes vary.

9. **Cards.** The variety of card files is almost as great as the variety of case files. Their physical sizes and formats make them a logical file group. Included are 3 x 5 cards, 5 x 8 cards, tab cards, etc.


**1.15.7.3.3** **(10-30-2013)**

#### Sorting and Arranging Files

1. Sort and arrange file groups into smaller feature segments for easier retrieval of documents. For example:



   - Subject

   - Title

   - Date

   - Number

   - Location


2. Set up a cross reference if a document is likely to be requested by more than one filing arrangement.


**1.15.7.3.4** **(03-22-2021)**

#### Preparing Records for Filing

1. The steps outlined below assist in preparing paper or electronic records for filing.

2. Arrange, group and properly identify records, whether paper or electronic, to facilitate disposal when they become eligible for destruction or other disposal, retirement to a (Federal) Records Center, or transfer to NARA.

3. Arrange, group and properly identify records, whether paper or electronic, to facilitate research capabilities within a secured record keeping environment.

4. Arrange, group and properly identify records, whether paper or electronic, to facilitate reference and cross reference purposes.

5. Below is a listing of general paper record sorting and filing procedures:



1. Remove clips, pins, rubber bands before filing papers. If fastening is required, staple papers in upper left corner or in both upper corners.

2. Keep those attachments and enclosures not adaptable to standard file folders separate in suitable materials. Be sure to annotate on the related document the location of the items.

3. Arrange and label file drawers or shelves, guides and folders.

4. Arrange papers in folders by date, the most recent on top.

5. File correspondence with heading to the left for easier checking of dates. When using shelving, place the heading in the upper right corner if the right edge of the file is exposed.

6. Prepare new folders when capacity (3/3) has been reached.

7. Repair torn sheets and replace worn or torn folders.

8. File all administrative and program operating documents with related documents.

9. Prepare a new set of guides and file folders for the current year files when the files have met their predetermined cut-off period.


**1.15.7.3.5** **(03-22-2021)**

#### Filing Stations and Requirements

1. There are three types of file stations (in paper or electronic format):



1. **Centralized** \- maintained at one location,

2. **Decentralized** \- maintained at several locations, and

3. **Partially Decentralized** \- maintained at various locations, with the originals or main set of files preferably nearest the prime user and/or access restricted to authorized users.


2. Thorough consideration and study are required before choosing appropriate storage for paper and electronic records files.



1. **Office Reference Requirements**. Consider the volume of records and frequency of references.

2. **Space Requirements**. Consider the floor space available, expansions capabilities, floor load limitations, light, power, ventilation, etc. for paper records. Consider the bandwidth and available network storage space for electronic records.

3. **Security Requirements**. Choose a restricted or secured area depending upon the paper records housed. See IRM 10.5.1, Privacy Policy, for the types of records that require special protection and contains procedures for providing protection. See IRM 10.8.1, Policy and Guidance, to implement and manage information systems security within the IRS. Ensure only authorized personnel have access to electronic records. There must also be provisions for backup and recovery of electronic records to protect against information loss or corruption.

4. **Safety Requirements**. Make sure that all paper file cabinets and rooms are fire-resistant, clean, and have proper environmental conditions such as temperature, humidity and air circulation. Accumulated trash, eating, smoking, and storage of flammable liquids are prohibited in the files area. Electric lights must be enclosed and a safe distance from records. Do not store records close to heaters or radiators.

5. **Records Requirements**. Consider the type of records being stored to make sure that office space, security, and safety requirements adequately cover the records' needs. Electronic records in large quantities require humidity and temperature controls; blueprints or large vellum drawings may require tube storage or flat drawer cabinets; and photographic or voice recordings require special environmental conditions. Considering these factors permits the records to be available throughout their useful lives.


**1.15.7.3.6** **(03-22-2021)**

#### Establishing Suspense Files

1. A suspense or tickler file, whether a paper or electronic record, calls attention to a pending action. Establish suspense files only after a study is conducted to determine a required need. Ensure approval is gained from responsible authorities.

2. The follow-up document, whether a paper or electronic record, calls attention to specific actions and dates. The offices responsible for the action establishes and controls the dates. Upon receipt of the follow-up document, pull related suspense files to address the pending action.

3. Following are variations of suspense or tickler systems (hard copy or electronic):



1. **Card-Tickler** \- set of month guides (labeled January-December) and a set of day guides 1–31, placed in a card tray. Cards or papers are prepared for the file showing subject, identification, location of the document and pending action. Microsoft Office applications provide tools to create month and day guides for your electronic records.

2. **Sheet Follow-Up** \- set of month guides and day guides in a file drawer. A follow-up form or copy of correspondence is placed behind the appropriate date to indicate when action is required. If the action is not taken, the suspense document is filed for the succeeding day, until the action is completed, or a new follow-up date is assigned. Microsoft Outlook provides tools to set up follow-up systems for electronic messages.

3. **Alphabetic and Date Pending File** \- file containing alphabetic guides A - Z in addition to month and day guides. This system is helpful with a name file when follow-up is required, and the volume is large. Microsoft Office applications provide tools to create month and day guides for your electronic records.

4. **Date Folder** \- set of straight-cut press board folders, legal or letter size, with the month and days printed across the extended edge. A movable indicator or signal is a basic part of the system. The suspense date can be changed without refiling contents in the folder. Microsoft Outlook provides tools to create filing rules for your electronic messages that require storage in electronic date folders.

5. **Color Follow-Up** \- Various colors, each color representing a specific follow-up period. Metal and celluloid colored tab signals, colored paper strips, or colored file labels may be used. Microsoft Outlook provides tools to categorize and follow up by color coding your electronic messages.

6. **Task Minders** \- electronic ticklers such as task reminders or alarms, such as those provided by Microsoft Outlook application.


**1.15.7.3.7** **(08-10-2017)**

#### Establishing Cutoff Periods

1. Establishing cutoff periods provides a means of segregating inactive records from those records which are required in daily operations. Here are factors to consider when establishing cutoff periods:



1. Description of records,

2. Type of records,

3. Volume on hand and estimated growth,

4. Continuity requirements,

5. Rate of reference, and

6. Authorized retention and disposal periods found in Document 12990, IRS Records Control Schedules (RCS) or Document 12829, General Records Schedules (GRS).


**1.15.7.3.7.1** **(03-22-2021)**

##### Cutting Off Subject Files

1. Subject files, whether paper or electronic, are cut off annually or biannually by calendar or fiscal year. Retire eligible subject files to Federal Records Center (FRC). Establish a new file after the cutoff date is met. Store retained subject files based on reference requirements (e.g., less accessible file drawers or archive folders).


**1.15.7.3.7.2** **(10-30-2013)**

##### Cutting Off Case Files

1. Establish an annual cutoff schedule, on a calendar or fiscal year basis, for complete or closed case files.


**1.15.7.3.7.3** **(08-10-2017)**

##### Cutting Off "Special Event" Files

1. Records retentions associated with a "special event" do not lend themselves to a definite cutoff period. The "special event" may pertain to separation of an employee, transfer of equipment, delivery of equipment, or final payment under a contract. These records are treated as separate cases. They are retained as an active case file until the case becomes inactive or the "special event" occurs.


**1.15.7.3.8** **(08-10-2017)**

#### Controlling Paper Charge-Out and Electronic Check Out Tool

1. In large paper files operations, requests for records must be on a prescribed charge-out form.

2. Charge-out cards/forms are used to replace (identify) papers or folders being removed. The charge-out notates the borrowers of a file, their location, and the date. The charge-out cards are placed in the removed records' locations.



### Note:



An effective charge-out control system eliminates the need for individuals to maintain personal copies of documents and reduces the need for file searches. Charge-out cards also help eliminate misfiles.

3. Electronic records stored on SharePoint can be checked out for use and checked in when updated. The check out and check in tool, when configured and used properly, ensures the latest version of a document is stored on SharePoint.


**1.15.7.3.8.1** **(08-10-2017)**

##### Charge-Out Forms

1. There are several optional forms that may be used to charge out paper files. Charge-out cards/forms must contain the following information:



1. File designation code,

2. Subject of document, addressee and date,

3. Date charged out,

4. Name of person who, or office that has the file, and

5. Any transfers to other persons or offices.


2. When the document or folder is returned, it must be checked for completeness before refiling. The charge card is removed from the file, the entry lined out, and the document/folder is placed in the file.

3. Periodic follow-ups must be made on any item that has been charged out for an unreasonably long time.


**1.15.7.4** **(08-10-2017)**

### Case Files

1. Case (project) files are records, whether paper or electronic, that document the technical and professional work of the IRS. Case files may include income tax returns, audits, investigations, claims, contracts, or purchase orders.


**1.15.7.4.1** **(08-10-2017)**

#### Standardizing Case Files

1. Standardizing case files, whether paper or electronic, helps avoid gaps in records and simplifies record keeping.

2. Each Business Unit develops a standard to determine which records are essential to (required for) a case file, both paper or electronic, and how the file must be constituted.


**1.15.7.4.1.1** **(03-22-2021)**

##### Separating Essential and Non-Essential Documentation

1. Whether a paper or electronic record, separate essential from non-essential (supporting) documentation (i.e., those with short-term value). This separation improves ease of reference and conformance with records disposition schedules.

2. File essential documentation with the case file. File non-essential documentation separately from the case file.


**1.15.7.4.2** **(08-10-2017)**

#### Case Filing and Coding

1. Case filing, whether paper or electronic, is the simplest and easiest of all types of filing. Adopt the simplest arrangement of files that is effective for the office.

2. Publicize uniform rules for filing. Uniform rules must be followed to avoid filing inconsistencies, errors, and confusion.

3. Case files are usually filed by name or number, distinguishing them from general correspondence or administrative files, which are usually filed by subject.

4. Use a standard alphabetic arrangement for filing case files by name. _Exhibit 1.15.7-1_, Alphabetic Filing Sequences of Individual Names, shows basic rules for alphabetic filing.

5. The numeric system is used to arrange records identified and referred to by number. Contracts, purchase orders, etc. are usually filed numerically.


**1.15.7.5** **(08-10-2017)**

### Subject Files

1. Subject files, whether paper or electronic, typically are correspondence files, administrative files, or general office files.

2. Subject files include, but are not limited to, records pertaining to:



1. Administration, management and operations,

2. Development and administration of programs,

3. Administration and enforcement of laws, regulations, and statutes affecting IRS' functions and responsibilities, and

4. Administrative functions such as personnel, fiscal, accounting, procurement, transportation, publications control and distribution, forms, records management, etc.


3. Use subject filing when the record will be requested by content and subject correlation is required or desirable.


**1.15.7.5.1** **(03-22-2021)**

#### Organizing Subject Files

1. Organize records, whether paper or electronic, into separate file groups for rapid filing and retrieval. Organize the groups based on characteristics that assist in identification. Grouped records can be further classified into subgroups.



### Example:



Personnel records can be divided into sub-groups by office, organization, and last name.

2. To be effective, classification of files must be:



1. **Complete** \- classify records by an appropriate category,

2. **Responsive** \- describe the records so that users can easily retrieve records they want,

3. **Logical** \- group records in the most predictable order,

4. **Comprehensive** \- title records to completely cover their subjects so that similar titles are not required, and

5. **Exact** \- provide descriptions to records so they are readily identifiable within their groups.


**1.15.7.5.2** **(08-10-2017)**

#### Subject Filing Codes

1. Locating records, whether paper or electronic, efficiently depends on the care used to determine the proper subject file, the logical arrangement of the paper or electronic file folders, and the file codes assigned to them. Filing codes save time.

2. Subject filing codes can be alphabetic, numeric, or a combination alphanumeric.

3. Filing codes are important, but subject category selections that accurately represent record contents are the most important considerations.


**1.15.7.5.2.1** **(03-22-2021)**

##### Design of Subject Filing Codes

1. Never prepare filing codes in anticipation of records that might accumulate. They are prepared only after enough records have accumulated to justify the need for a separate classification.

2. If the volume of records is small, the files should be established using only primary subjects.

3. Numerals are always added consecutively.

4. Codes should be brief, meaningful, segmented (Pers-1 rather than 4127.5), and flexible.

5. Develop a list of codes and their subject matter as a table of contents after a subject filing code has been adopted. Prepare a reverse index (an alphabetic list of subjects with their appropriate codes) if the filing system is complex.

6. Establish an individual file code outline for each office. Provide all users a copy of that outline.

7. Retain a master copy of the outline in a prominent location, accessible to all with a need to know.

8. Size and complexity of the file outline determine whether an index is developed. The index would be an alphabetical list of subject breakdowns with reference to the appropriate file codes.


**1.15.7.6** **(08-10-2017)**

### Composite Subject Filing and Coding System

1. A uniform method for classifying, coding and filing administrative records, whether paper or electronic, promotes the integrity and continuity of records and aids in auditing and researching files. Procedures can be effective regardless of how large or small a filing system may be.

2. Offices develop and use a composite filing and coding system for administrative (subject) files as described in _IRM 1.15.7.6.1_, Basics of Composite Filing and Coding Systems. Files that already use or have an assigned files code, e.g., procurement contract and grant numbers, or personnel records, should use that system.


**1.15.7.6.1** **(10-30-2013)**

#### Basics of Composite Filing and Coding Systems

1. **Major Topics** \- broad headings that encompass major subject areas.

2. **Primary Subjects** \- the first numbered breakdown under a major topic is called a primary subject.

3. **Secondary Subjects** \- the first breakdown under a primary subject is called a secondary subject.



   - Secondary subjects are related to each other and to the primary subject from which they originate.

   - Secondary subject codes are constructed by adding a dash (-) and a numeral to the code.


4. **Tertiary Subjects** \- when further breakdowns are required, secondary subjects are divided into tertiary subjects by adding another dash (-) and another numeral to the secondary subject. Numbers and alphabetic letters are assigned consecutively.

5. **Additional Expansion** \- within the framework of a subject title, there may be other file arrangements which simplify retrieving information, e.g., 1-1750 Records Training; Contractor - External, Internal; Government - Internal, Other Agency.


**1.15.7.6.2** **(08-10-2017)**

#### Basic Procedures

1. Subdivide subjects to meet user needs to achieve flexibility and efficiency.

2. After the composite subject filing system, whether paper or electronic is developed, prepare a file outline and distribute it to users.


**1.15.7.7** **(08-10-2017)**

### Alphabetical Filing

1. Follow basic rules of alphabetizing. Names or words are always arranged by filing unit, according to the sequence of letters in the alphabet.

2. "Nothing before something" is a fundamental filing rule. When first units are the same, consider second units. If first and second units are identical, consider third units. _Exhibit 1.15.7-1_, Alphabetic Filing Sequences of Individual Names, contains an alphabetic file arrangement of individual names and illustrates the "nothing before something" rule.



### Note:



Filing systems for electronic records must adhere to the basic alphabetic filing rules.


**1.15.7.7.1** **(08-10-2017)**

#### Individual Names

1. Names are filed by surname (last name) in strict alphabetical order, letter by letter, to the end of a complete name. When the surname is prefixed or hyphenated, it is still filed as one unit.



### Example:



The surname "De Doe" is filed with DEDOE considered as one unit. "John St. Doe" is filed SAINT DOE (first unit), JOHN (second unit). "John Saint-Doe" is filed SAINT-DOE (first unit), JOHN (second unit).

2. The first name or initial, then the middle name or initial follow the surname in alphabetic sequence.



### Example:



Mary Q. Doe: is filed DOE (first unit), MARY (second unit), Q (third unit). "Q. Mary Doe" is filed DOE (first unit), Q (second unit), MARY (third unit).

3. Abbreviations of first or middle names are filed in alphabetic sequence as though spelled out.



### Example:



"Geo. Pike" is filed PIKE (first unit), GEORGE (second unit).


**1.15.7.7.1.1** **(08-10-2017)**

##### Titles

1. When a title is an integral part of a name, the name is filed as written; the title is the first unit of consideration for filing.



### Example:



QUEEN (first unit), ANN (second unit); SISTER (first unit), MARY (second unit), MARIANNE (third unit).

2. When a title is added to a full name, it is considered as a last unit.



### Example:



"Doctor John Doe" is filed DOE (first unit), JOHN (second unit), DOCTOR (third unit)."Captain Mary Doe" is filed DOE (first unit), MARY (second unit), CAPTAIN (third unit).

3. Designations like Sr., Jr., 2nd, 3rd, are shown in parentheses at the end of the name.



### Example:



"John Doe, Jr." is filed DOE (first unit), JOHN (Jr.) (second unit).


**1.15.7.7.1.2** **(08-10-2017)**

##### Foreign Names

1. If you cannot distinguish the first or last name in a foreign name, file the name as it is written.



### Example:



" Sun Pike Doe" is filed SUN (first unit), PIKE (second unit), DOE (third unit).


**1.15.7.7.2** **(10-30-2013)**

#### Business Names

1. Business names take several forms to be considered for filing. Below are the most common variations and how they are to be filed.


**1.15.7.7.2.1** **(08-10-2017)**

##### Firms with Individuals, Names

1. When a business does not contain the full name of an individual, it is filed as written.

2. When a business name contains an individual's full name, the name is filed by surname, first name or initial, middle name or initial.



### Example:



"Mary Q. Doe Fruit Company" is filed DOE (first unit), MARY (second unit), Q (third unit) FRUIT (fourth unit), COMPANY (fifth unit).

3. When the firm name of an individual is very well-known, and transposing it would cause confusion, it is filed as written.



### Example:



"John Doe Department Store" is filed JOHN (first unit) DOE (second unit), DEPARTMENT (third unit), STORE (fourth unit).

4. Firm names with a title are filed as written.



### Example:



"Dr. Doe’s Shoes" is filed DOCTOR (first unit), DOE’S (second unit), SHOES (third unit).

5. When a business name is formed of two surnames, it is filed as written.



### Example:



"Doe Pike Stores" is filed DOE (first unit) PIKE (second unit), STORES (third unit).

6. When it is not clear whether or not a firm contains a surname and given name of one individual or two surnames, file as though they were two surnames and cross-reference under the second name.

7. A hyphenated word is filed as one name.



### Example:



"Doe-Pike Publishing Company" is filed DOE-PIKE (first unit), PUBLISHING (second unit), COMPANY (third unit).


**1.15.7.7.2.2** **(08-10-2017)**

##### Firm Names with Apostrophes

1. When they show possession, the apostrophe and "s" that follow are disregarded in filing.



### Example:



" John's Body Shop" is filed JOHN (first unit), BODY (second unit), SHOP (third unit).

2. In plural forms, only the apostrophe is disregarded.



### Example:



"Pikes’ Club" is filed PIKES (first unit), CLUB (second unit).

3. The apostrophe in an elision (standing for dropped letters) is not used in filing.



### Example:



"Where It's At Malt Shop" is filed WHERE (first unit), ITS (second unit), AT (third unit), MALT (fourth unit), SHOP (fifth unit).


**1.15.7.7.2.3** **(03-22-2021)**

##### Firm Names Containing Letters and Numbers

1. When letters are used as a name, each letter is considered a separate unit for filing. For radio or television stations, the call letters are the first unit of consideration.



### Note:



Radio Station DOE is filed and indexed under the letters DOE rather than R for Radio.

2. Organizations or agencies containing two or more words and are known by their letter abbreviations, are filed as though spelled out.



### Example:



Though known as "AP Organization" , file under APRICOT (first unit), PEAR (second unit) and Organization (third unit).

3. Numeric names are filed as though spelled out.



### Example:



"1 Main Restaurant" is filed ONE (first unit), MAIN (second unit), RESTAURANT (third unit).


**1.15.7.7.2.4** **(08-10-2017)**

##### Firm Names with Conjunctions, Prepositions, Articles

1. Conjunctions, articles, and prepositions that are part of a name are disregarded.



### Example:



"Avenue of the Anytown Hotel" is filed AVENUE (first unit), ANYTOWN (second unit), HOTEL (third unit). "Doe and Sons Pharmacy" is filed DOE (first unit), SONS (second unit), PHARMACY (third unit).

2. In most cases, articles that begin a commercial name are not considered in filing and are placed in parentheses at the end of the name



### Example:



"The Doe Chef" is filed DOE (first unit) CHEF(the) (second unit).





### Note:



When an article is an intrinsic part of a geographic name, it is considered for filing; THE SITE, VIRGINIA.

3. Prepositions that begin a name are considered.



### Note:



"Over Twenty Club" is filed OVER (first unit), TWENTY (second unit), CLUB (third unit).


**1.15.7.7.2.5** **(08-10-2017)**

##### Geographic Names and Compass Terms

1. In geographic names of more than one word, each word is a separate unit of consideration.



### Example:



"Main Street Shipping Company" is filed MAIN (first unit), STREET (second unit), SHIPPING (third unit), COMPANY (fourth unit).

2. Geographic names with prefixes are considered single units.



### Example:



"Des Does Appliance Store" is filed DES DOES (first unit), APPLIANCE (second unit), STORE (third unit).

3. When compass terms are used in titles, they are filed as written.



### Example:



"Southeast Minnows" and "South West Minnows Bank" are filed SOUTHEAST (first unit) MINNOWS (second unit); SOUTH (first unit), WEST (second unit), MINNOWS (third unit), BANK (fourth unit).


**1.15.7.7.2.6** **(08-10-2017)**

##### Abbreviations in Business Names

1. Abbreviations in company names are filed as though spelled out.



### Example:



"Ft. Doe MFG Co." is filed FORT (first unit), DOE (second unit), MANUFACTURING (third unit), COMPANY (fourth unit).


**1.15.7.7.2.7** **(08-10-2017)**

##### Institutions and Organizations

1. Institutions and organizations are filed under the significant word or location.



### Example:



"University of Doe" is filed DOE (first unit), UNIVERSITY (second unit); "First National Bank of Anytown" is filed ANYTOWN (first unit), FIRST (second unit), NATIONAL (third unit), BANK (fourth unit).

2. When phrases like "association of," union of, "organization of," etc. are beginnings of names or titles, they are considered in filing.



### Example:



"Society for the Minnows" is filed SOCIETY (first unit), MINNOWS (second unit); "Association of Anytown Engineers" is filed ASSOCIATION (first unit), ANYTOWN (second unit), ENGINEERS (third unit).


**1.15.7.7.3** **(10-30-2013)**

#### Alphabetic Distribution of Names

1. A normal alphabetic arrangement of names will have about half the names filed under six letters of the alphabet: S, B, M, H, C, and W. Consider this typical distribution when setting up filing space.

2. Various breakdowns of the alphabet have been developed for easy filing and rapid retrieval.


**1.15.7.8** **(08-10-2017)**

### Evaluating Files Operations or Systems

1. Review filing operations, whether for paper or electronic records, periodically to make sure that the most efficient practices are being followed. Measure the success of the operation by how quickly complete, pertinent information is retrieved.


**1.15.7.8.1** **(08-10-2017)**

#### Files Organization

1. Organize files operations, whether for paper or electronic records, in the way best suited to serve the offices using them. The operation is centralized, decentralized, or partially decentralized - whichever arrangement provides the most efficient service.

2. Staffing is adequate to provide prompt, efficient service to file users, including proper electronic record filing maintenance practices. A "can't find" rate over 3% is unreasonable. Any rate over 1% is excessive; take corrective steps to improve the situation.


**1.15.7.8.2** **(08-10-2017)**

#### Files Management Administration

1. Publicize guidance that:



1. Prohibits filing envelopes (unless it is necessary to meet legal requirements), routine routing slips, copies, or superseded drafts,

2. Requires using charge-out cards for paper records and check out and check in procedures for electronic records,

3. Discourages using duplicate files or attaching the same document for review or reference to multiple emails. Instead, encourage linking to a network-stored document, practice version control, and

4. Maintains an accessible outline of subject files, folder titles, corresponding files codes or structures, and cross-references to associated recordkeeping systems or supporting documentation.


2. Use paper file and electronic storage space to the best advantage. Keep the paper file space neat, clean, uncluttered, and hazard-free, including maintaining an electronic storage space that meets all retention, security, and 508 compliant regulations.

3. Light, space, and ventilation must be adequate for the storage of paper and removable electronic media.

4. Inactive records, whether paper or electronic, must routinely be removed from current files and be retired, destroyed, or moved to alternative/archived storage space.


**1.15.7.8.3** **(08-10-2017)**

#### Files Audit

1. A paper files audit provides a check on the condition of the files and prevents neglect by the file’s operation. Following is a list of what to look for when conducting a paper files audit:



1. **Misfiled Material** \- even 99% accurate filing in a five-drawer cabinet means that 150 documents are misfiled.

2. **Soiled Labels** \- soiled labels are hard to read and increase the chance of misfiles.

3. **Torn or Overloaded Folders** \- make it harder to file and retrieve papers. Papers can be damaged in such folders.

4. **No Inclusive Dates On Closed-Out Folders** \- inclusive (beginning and ending) dates aid in disposing of folders when using approved records disposition schedules.

5. **File 1 of 3, With No Indication On The 3 Files That They Are Connected As One File** \- insufficient information makes it harder to determine file quantity is split.


2. Management ensures that corrective measures are taken immediately if any of the above conditions are found during an audit. Information Resource Coordinators (IRC) are appointed in each organization for this purpose. See IRM 1.15.1.3.5, Responsibilities of the IRC.


**1.15.7.8.4** **(03-22-2021)**

#### Files Surveys/Inventories

1. Files surveys/inventories, whether for paper or electronic records, are conducted to develop records disposition schedules and efficiently manage filing systems.

2. Submit your completed local File surveys/ inventories/ plans to your Records Specialists.


**Exhibit 1.15.7-1**

### Alphabetic Filing Sequences of Individual Names

**Filing Unit Sequence of Names and Titles**

| **Name as Written** | **Unit 1** | **Unit 2** | **Unit 3** | **Unit 4** |
| :-- | :-- | :-- | :-- | :-- |
| Mary Doe | Doe | Mary |  |  |
| Doe | Doe |  |  |  |
| J. Doe | Doe | J. |  |  |
| J. A. Doe | Doe | J. | A. |  |
| J. Alan Doe | Doe | J. | Alan |  |
| John Doe | Doe | John |  |  |
| Mary John Doe | Doe | Mary | John |  |
| Mary John E. Doe | Doe | Mary | John | E. |
| John Q. Public | Public | John | Q. |  |
| John Mary | Mary | John |  |  |
| Mary MacDoe | MacDoe | Mary |  |  |
| John MacDoe, Jr. | MacDoe | John | (Jr.) |  |
| John McDoe | McDoe | John |  |  |
| Mary McDoe | McDoe | Mary |  |  |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-015-007#addtoany "Show all")

A2A