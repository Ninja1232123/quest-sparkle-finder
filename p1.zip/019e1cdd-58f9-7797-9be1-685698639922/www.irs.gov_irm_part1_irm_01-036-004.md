---
url: "https://www.irs.gov/irm/part1/irm_01-036-004"
title: "1.36.4 Administrative (Non-tax) Debt Management | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-036-004#main-content)

- 1.36.4  [Administrative (Non-tax) Debt Management](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925786912)
  - 1.36.4.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925877552)
    - 1.36.4.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925874288)
    - 1.36.4.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925868336)
    - 1.36.4.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925838976)
      - 1.36.4.1.3.1  [CFO and Deputy CFO](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925829968)
      - 1.36.4.1.3.2  [Senior Associate CFO for Financial Management and Associate CFO for Corporate Accounting](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925828192)
      - 1.36.4.1.3.3  [Travel Management](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925824080)
      - 1.36.4.1.3.4  [Travel Operations](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925821120)
      - 1.36.4.1.3.5  [Travel Review](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925818064)
      - 1.36.4.1.3.6  [Government Payables and Funds Management](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925241872)
      - 1.36.4.1.3.7  [Intragovernmental and Funds Processing](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925235760)
      - 1.36.4.1.3.8  [Human Capital Office](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925230416)
      - 1.36.4.1.3.9  [Human Resources Shared Services](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925228752)
      - 1.36.4.1.3.10  [Labor/Employee Relations and Negotiations](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925222096)
      - 1.36.4.1.3.11  [Associate Chief Counsel (Finance and Management)](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925220224)
      - 1.36.4.1.3.12  [Associate Chief Counsel (General Legal Services)](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925218528)
      - 1.36.4.1.3.13  [Human Resources Division, Chief Counsel](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925216832)
      - 1.36.4.1.3.14  [Payroll and Processing Branch, Chief Counsel](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925213840)
      - 1.36.4.1.3.15  [Managers/Supervisors](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925208192)
      - 1.36.4.1.3.16  [IRS Employees and Former IRS Employees](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925203600)
    - 1.36.4.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925199136)
    - 1.36.4.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925191200)
    - 1.36.4.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925179696)
    - 1.36.4.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925137328)
    - 1.36.4.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925122032)
  - 1.36.4.2  [Debts Arising from Pay and Leave Actions](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925111984)
    - 1.36.4.2.1  [Emergency Salary Payments](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925107696)
    - 1.36.4.2.2  [Advanced Leave](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925104288)
    - 1.36.4.2.3  [Salary Overpayments](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925102480)
    - 1.36.4.2.4  [Federal Employees Health Benefits Premiums (FEHB)](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925094992)
    - 1.36.4.2.5  [Student Loan Repayment Program](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925084592)
  - 1.36.4.3  [Debts arising from other various actions](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925081552)
    - 1.36.4.3.1  [Travel Transactions](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925075472)
    - 1.36.4.3.2  [Relocation Transactions](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925071728)
    - 1.36.4.3.3  [Training](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925065712)
    - 1.36.4.3.4  [Restitutions](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925060896)
    - 1.36.4.3.5  [Vendor Transactions](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925054848)
  - 1.36.4.4  [Debt Letter and Due Process Rights](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925047744)
  - 1.36.4.5  [Delinquency](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925039008)
    - 1.36.4.5.1  [Interest](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925036000)
    - 1.36.4.5.2  [Administrative Charges](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925033584)
    - 1.36.4.5.3  [Penalties](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925031840)
    - 1.36.4.5.4  [Waiver of Interest, Administrative Costs and Penalties](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925029024)
  - 1.36.4.6  [Application of Payments](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925024768)
  - 1.36.4.7  [Debts Referred to NFC](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925020912)
  - 1.36.4.8  [Debts Referred to Fiscal Service](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925011328)
    - 1.36.4.8.1  [Cross-Servicing Program](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073925004544)
      - 1.36.4.8.1.1  [Treasury Offset Program](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073924990560)
      - 1.36.4.8.1.2  [Private Collection Agencies](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073924979888)
      - 1.36.4.8.1.3  [Administrative Wage Garnishment](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073924977408)
  - 1.36.4.9  [Bankruptcy](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073924973408)
  - 1.36.4.10  [Retirement and Separation](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073924967712)
  - 1.36.4.11  [Fraud Claims](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073924962240)
  - 1.36.4.12  [Termination of Debts](https://www.irs.gov/irm/part1/irm_01-036-004#idm140073924960464)

# Part 1. Organization, Finance, and Management

# Chapter 36. Administrative Accounting Financial Management Reports

# Section 4. Administrative (Non-tax) Debt Management

* * *

## 1.36.4 Administrative (Non-tax) Debt Management

#### Manual Transmittal

July 31, 2024

#### Purpose

(1) This transmits revised IRM 1.36.4, Administrative Accounting and Financial Management Reports, Administrative (Non-Tax) Debt Management.

#### Material Changes

(1) IRM 1.36.4.1(1), Program Scope and Objectives, added reference that administrative (non-tax) debt is also referred to as non-tax debt throughout the IRM.

(2) IRM 1.36.4.1(5), Program Scope and Objectives, changed the Primary Stakeholders from “Employees, former employees, estates of former employees and entities that have incurred non-tax debts to the IRS” to “CFO and Government Payables and Funds Management office controls the debt management guidelines and policies” to conform to IRM 1.11.2, Internal Management Documents System, Internal Revenue Manual (IRM) Process, which defines a stakeholder as “The office or business unit responsible for the program policy or whose processes or procedures are affected. These offices generally include those who are responsible for reviewing and approving the IRM”.

(3) IRM 1.36.4.1.3(b), Responsibilities, updated titles due to reorganization change.

(4) IRM 1.36.4.1.3.2(1)(c), Senior Associate CFO for Financial Management and Associate CFO for Corporate Accounting, specified that the responsibility as a hearing official is for only those debts submitted to Fiscal Service by the Government Payables and Funds Management office.

(5) IRM 1.36.4.1.3.4, Travel Operations and 1.36.4.1.3.5, Travel Review responsibilities separated to show that operations handles non-Concur debts and review handles all other travel debts.

(6) IRM 1.36.4.1.3.5(g), Government Payables and Funds Management, clarification that GLS should be consulted for former deceased employees instead of employees for suspending or terminating collection activity.

(7) IRM 1.36.4.1.3.8(g), Human Capital Office, added executives to HRSS responsibility for assisting Chief Counsel employees.

(8) IRM 1.36.4.1.4(2)(a), Program Management and Review, added “for enforced collection” to specify the reason for submitting delinquent debts to National Finance Center. Updated the time frame in which delinquent debts are submitted to NFC or Fiscal Service to keep within guidelines of “Managing Government Receivables” guide.

(9) IRM 1.36.4.1.6(1)(b), Terms/Definitions, expanded the definition of Administrative Debt to include examples.

(10) IRM 1.36.4.1.6(1)(v), Terms/Definitions, added definition for “Just Financial obligation” since it is referenced in 1.36.4.1.3.9, Labor/Employee Relations and Negotiations.

(11) IRM 1.36.4.2(1)(e), Debts Arising from Pay and Leave Actions, added Student Loan Repayment Program service agreement breach as an example of Pay and Leave action debt since it is a new program.

(12) IRM 1.36.4.2.5, Student Loan Repayment Program, New. Added Student Loan Repayment Program information under IRM 1.36.4.2, Debts Arising from Pay and Leave Actions since it is a new program.

(13) IRM 1.36.4.8(1), Debts Referred to Fiscal Service, added time frame for Fiscal Service submitted debts to participate in administrative offset to keep within guidelines of “Managing Government Receivables” guide.

(14) IRM 1.36.4.10(5)(b), Retirement and Separation, changed reference from OS GetServices to IRS Service Central (IRWorks) due to name change.

(15) This revision includes changes throughout the document for the following:

1. Added minor editorial changes.

2. Changed wording from Administrative (non-tax) debt to non-tax debt.

3. Changed the wording from salary, leave and health benefits to salary, leave and health or payroll-related benefits to encompass debts such as Student Loan Repayment Program service agreement breaches.


#### Effect on Other Documents

IRM 1.36.4, dated August 04, 2022, is superseded.

#### Audience

All business units

#### Effective Date

(07-31-2024)

Teresa R. Hunter

Chief Financial Officer

**1.36.4.1** **(07-31-2024)**

### Program Scope and Objectives

1. Purpose: This IRM provides policies and guidance for the collection of administrative (non-tax) debt (referred to as non-tax debt throughout this IRM) owed to the IRS by employees, former employees and entities.

2. Audience: All current and former IRS employees and entities (also referred to as debtors) that owe non-tax debts to the IRS.

3. Policy Owner: CFO

4. Program Owners: CFO Government Payables and Funds Management office and HCO Administrative Debt Management Branch.

5. Primary Stakeholders: CFO and HCO controls the debt management guidelines and policies.

6. Program Goals: Ensure non-tax debts owed to the IRS are resolved equitably and timely.


**1.36.4.1.1** **(08-04-2022)**

#### Background

1. The Debt Collection Act of 1982 and the Debt Collection Improvement Act of 1996 were enacted to:



   - Increase efficiency of governmentwide efforts to collect debts owed to the United States.

   - Maximize collections of delinquent debt.

   - Minimize costs and reduce loss arising from debt management.

   - Ensure the public is fully informed of the federal government’s debt collection policies.

   - Ensure debtors have all appropriate due process rights.


2. This IRM contains provisions pertaining to non-tax debts owed to the United States government by individuals and entities such as businesses, trade associations and non-profit organizations. These provisions derive their authority from Chapter 37 of Title 31 United States Code (USC) and from Title 31 Parts 5 and 900-904, of the Code of Federal Regulations (CFR). This IRM also contains provisions specifically pertaining to non-tax debts owed to the United States government by federal civilian employees, former federal civilian employees and the estates of former federal employees. These provisions derive their authority from Title 5 of the USC and from Title 5 of the CFR.

3. 31 USC Section 3711, Collection and compromise, requires a federal agency try to collect claims of or debts owed to the United States government for money or property arising out of the activities of, or referred to, the agency.


**1.36.4.1.2** **(08-04-2022)**

#### Authorities

1. The authorities for this IRM include:



01. [Debt Collection Act of 1982](https://www.congress.gov/bill/97th-congress/house-bill/4613)

02. [Deficit Reduction Act of 1984, Pub L. 09-369](https://www.congress.gov/bill/98th-congress/house-bill/4170#:~:text=Deficit%20Reduction%20Act%20of%201984%20%2D%20Division%20A%20%2D%20Tax%20Reform%20Act,eligible%20for%20the%20investment%20tax)

03. [Debt Collection Improvement Act of 1996](https://www.federalregister.gov/documents/2022/03/02/2022-03584/debt-collection-authorities-under-the-debt-collection-improvement-act-of-1996)

04. [Digital Accountability and Transparency Act of 2014, Pub. L. No.113-101](https://www.congress.gov/113/plaws/publ101/PLAW-113publ101.pdf)

05. [Fair Debt Collection Practices Act, Pub. L. 95-109](https://www.govinfo.gov/link/statute/91/874)

06. [Travel and Transportation Reform Act of 1998, Pub. L. 105-264](https://www.congress.gov/105/plaws/publ264/PLAW-105publ264.pdf)

07. [5 USC Section 4108](https://www.govinfo.gov/app/details/USCODE-2011-title5/USCODE-2011-title5-partIII-subpartC-chap41-sec4108/context), Employee agreements: service after training

08. [5 USC Section 5514](http://uscode.house.gov/view.xhtml?req=5+usc+5514&f=treesort&fq=true&num=5&hl=true&edition=prelim&granuleId=USC-prelim-title5-section5514), Installment deduction for indebtedness to the United States

09. [5 USC Section 5584](http://uscode.house.gov/view.xhtml?req=5+usc+5584&f=treesort&fq=true&num=3&hl=true&edition=prelim&granuleId=USC-prelim-title5-section5584), Claims for overpayment of pay and allowances and of travel, transportation and relocation expenses and allowances

10. [5 USC Section 8906](http://uscode.house.gov/view.xhtml?req=5+usc+8906&f=treesort&fq=true&num=14&hl=true&edition=prelim&granuleId=USC-prelim-title5-section8906), Contributions

11. [11 USC Section 523(a)(8)](http://uscode.house.gov/view.xhtml?req=11+usc+523&f=treesort&fq=true&num=55&hl=true&edition=prelim&granuleId=USC-prelim-title11-section523), Exceptions to discharge

12. [31 USC Section 3701](http://uscode.house.gov/view.xhtml?req=31+usc+3701&f=treesort&fq=true&num=67&hl=true&edition=prelim&granuleId=USC-prelim-title31-section3701), Definitions; 31 USC Section 3711, Collection and compromise (collectively the Federal Claims Collection Act of 1966, as amended)

13. [31 USC Sections 3711 - 3720E](http://uscode.house.gov/view.xhtml?req=31+usc+3711&f=treesort&fq=true&num=32&hl=true&edition=prelim&granuleId=USC-prelim-title31-section3711), Claims of the United States Government

14. [31 USC 3717](http://uscode.house.gov/view.xhtml?req=31+usc+3717&f=treesort&fq=true&num=23&hl=true&edition=prelim&granuleId=USC-prelim-title31-section3717), Interest and penalty on claims

15. 5 CFR 550.1104, Agency regulations (Collection of Debt by Salary Offset)

16. 5 CFR Section 630.209, Refund for Unearned Leave

17. 5 CFR Section 890.502, Withholding, contributions, LWOP, premiums and direct premium payment

18. 31 CFR Part 285, Debt Collection Authorities Under the Debt Collection Improvement Act of 1996

19. 31 CFR Section 5.12, How will Treasury entities offset a Federal employee's salary to collect a Treasury debt?

20. 31 CFR Parts 900-904, Federal Claims Collection Standards

21. 41 CFR Chapter 300, Federal Travel Regulation

22. [Office of Management and Budget Circular A-129](https://www.whitehouse.gov/wp-content/uploads/legacy_drupal_files/omb/circulars/A129/a-129.pdf), Policies for Federal Credit Programs and Non-Tax Receivables

23. [Treasury Directive Publication (TD P 34-01)](https://home.treasury.gov/about/general-information/orders-and-directives/td34-01), Waiving Claims Against Treasury Employees for Erroneous Payments

24. [Treasury Directive Publication (TD P 34-02)](https://home.treasury.gov/about/general-information/orders-and-directives/td34-02), Credit Management and Debt Collection


**1.36.4.1.3** **(07-31-2024)**

#### Responsibilities

1. This section provides responsibilities for:



01. CFO and Deputy CFO

02. Senior Associate CFO for Financial Management and Associate CFO for Corporate Accounting

03. Travel Management

04. Travel Operations

05. Travel Review

06. Government Payables and Funds Management

07. Intragovernmental and Funds Processing

08. Human Capital Office

09. Human Resources Shared Services

10. Labor/Employee Relations and Negotiations (LERN)

11. Associate Chief Counsel (Finance and Management)

12. Associate Chief Counsel (General Legal Services)

13. Human Resources Division, Chief Counsel

14. Payroll and Processing Branch, Chief Counsel

15. Managers/supervisors

16. Employees and former employees


**1.36.4.1.3.1** **(07-31-2024)**

##### CFO and Deputy CFO

1. The CFO and Deputy CFO are responsible for overseeing the IRS non-tax debt collection program except for salary, leave, and health or payroll-related benefits debt collection.


**1.36.4.1.3.2** **(07-31-2024)**

##### Senior Associate CFO for Financial Management and Associate CFO for Corporate Accounting

1. The Senior Associate CFO for Financial Management and the Associate CFO for Corporate Accounting are responsible for:



1. Overseeing the non-tax debt collection process except for salary, leave, and health or payroll-related benefits debt collection.

2. Submitting requests for legal opinions to Chief Counsel concerning whether termination and/or close out of debts is appropriate.

3. Serving as a hearing official for administrative wage garnishment hearing requests from former employees for those debts submitted to Treasury’s Bureau of Fiscal Service (Fiscal Service) by Government Payables and Funds Management.


**1.36.4.1.3.3** **(08-04-2022)**

##### Travel Management

1. Travel Management is responsible for:



1. Overseeing the Travel and Relocation submission of debts.

2. Providing review of or proof of debt when requested by a debtor.


**1.36.4.1.3.4** **(07-31-2024)**

##### Travel Operations

1. Travel Operations is responsible for:



1. Overseeing the non-Concur travel and relocation processes.

2. Ensuring files are retained with supporting documentation for any debts that are established as a result of the non-Concur travel and relocation processes.


**1.36.4.1.3.5** **(07-31-2024)**

##### Travel Review

1. Travel Review is responsible for:



1. Overseeing the Concur travel and relocation post-audit process that identifies debts related to travel.

2. Ensuring files are retained with supporting documentation for all travel and relocation debts.


**1.36.4.1.3.6** **(07-31-2024)**

##### Government Payables and Funds Management

1. Government Payables and Funds Management is responsible for:



1. Overseeing the processing, collection and accounting of all non-tax debts except for those for which HCO is responsible.

2. Reviewing and recommending action for non-tax debts submitted for termination of collection and write-off.

3. Overseeing the negotiation and finalization of inter-agency agreements for obtaining non-Treasury hearing officials for salary offset hearings.

4. Certifying and signing the Annual Certification Agreement for debt collection services under the Fiscal Service Cross-Servicing program and Treasury Offset Program.

5. Referring requests for petition of salary offset hearings to the non-Treasury hearing official and Administrative Wage Garnishment (AWG) hearing requests to the IRS hearing official.

6. Providing data for processing Form 1099-C, Cancellation of Debt.

7. Consulting with Chief Counsel (General Legal Services) before suspending or terminating collection activity for debts of deceased employees and deceased former employees.

8. Consulting with Chief Counsel (General Legal Services) before continuing or terminating collection activities on debtors that have filed bankruptcy.


**1.36.4.1.3.7** **(07-31-2024)**

##### Intragovernmental and Funds Processing

1. Intragovernmental and Funds Processing is responsible for:



1. Managing the processing, collection and accounting for non-tax debts, including posting and applying payments not addressed by HCO.

2. Issuing debt letters and other correspondence for indebtedness except for tax, salary, leave and benefits debts.

3. Referring requests for petition for salary offset hearings to Government Payables and Funds Management.

4. Referring debtor requests for review of debt to appropriate office.

5. Serving as the deciding official on repayment agreements and financial hardship requests.

6. Referring repayment agreements and delinquent non-tax employee debts to the National Finance Center (NFC) for salary offset.

7. Referring delinquent non-tax debts for former employees and entities to Fiscal Service for collection action.


**1.36.4.1.3.8** **(07-31-2024)**

##### Human Capital Office

1. Human Capital Office is responsible for overseeing the salary, leave, and health or payroll-related benefits debt collection program.


**1.36.4.1.3.9** **(07-31-2024)**

##### Human Resources Shared Services

1. Human Resources Shared Services is responsible for:



1. Overseeing and managing the debt collection process for salary, leave, and health or payroll-related benefits.

2. Serving as the deciding official on repayment agreements and financial hardship considerations.

3. Ensuring debt is correctly established in the NFC Administrative Billings and Collection (ABCO) System.

4. Notifying debtors of any salary, leave, and health or payroll-related benefits indebtedness and their rights in accordance with the debt collection laws and regulations.

5. Receiving and reviewing debtor requests for waiver and proof of debt, petition for salary offset hearings and appeals, and corresponding with debtor.

6. Referring requests for petition for salary offset hearing to Government Payables and Funds Management.

7. Assisting the Payroll and Processing Branch in the collection of non-tax debts from Chief Counsel employees and former employees by providing the Payroll and Processing Branch with suitable debt letters to be sent to those employees.

8. Providing information for processing Form 1099-C, Cancellation of Debt for issuance by NFC.

9. Referring employees with delinquent debts to Field Operations, Labor/Employee Relations and Negotiations (LERN).


**1.36.4.1.3.10** **(08-04-2022)**

##### Labor/Employee Relations and Negotiations

1. Field Operations, LERN, is responsible for providing guidance to management related to potential disciplinary action resulting from administrative indebtedness, including failure to satisfy just financial obligations in good faith and failure to manage or honor private financial affairs where IRS operations or reputations are affected.


**1.36.4.1.3.11** **(05-04-2020)**

##### Associate Chief Counsel (Finance and Management)

1. The Associate Chief Counsel (Finance and Management) is responsible for overseeing the debt collection program involving Chief Counsel employees and former employees.


**1.36.4.1.3.12** **(05-04-2020)**

##### Associate Chief Counsel (General Legal Services)

1. The Associate Chief Counsel (General Legal Services) is responsible for providing legal opinions as to whether termination and/or close out of debts is appropriate.


**1.36.4.1.3.13** **(07-31-2024)**

##### Human Resources Division, Chief Counsel

1. Human Resources Division, Chief Counsel, is responsible for:



1. Overseeing the salary, leave, and health or payroll-related benefits debt collection program for Chief Counsel employees and former employees.

2. Serving as the deciding official on repayment agreements and financial hardship considerations requested by Chief Counsel employees and former employees.


**1.36.4.1.3.14** **(07-31-2024)**

##### Payroll and Processing Branch, Chief Counsel

1. Payroll and Processing Branch, Chief Counsel, is responsible for:



1. Managing the collection and processing of and accounting for salary, leave, and health or payroll-related benefits debts for Chief Counsel employees and former employees.

2. Ensuring debt is correctly established in the NFC Administrative Billings and Collection (ABCO) System.

3. Issuing debt letters and other correspondence for indebtedness for salary, leave, and health or payroll-related benefits debts.

4. Receiving debtor requests for salary offset hearings and referring the requests to the Associate Chief Counsel (Finance and Management).

5. Recommending actions for administrative debts submitted for termination of collection and/or write-off.

6. Consulting with Chief Counsel (Finance and Management) before suspending or terminating collection activity for debts of deceased employees and former employees.

7. Referring employees with delinquent debts to the Director, Labor and Employee Relations (LER) division within Chief Counsel for any appropriate disciplinary action.


**1.36.4.1.3.15** **(05-04-2020)**

##### Managers/Supervisors

1. Managers/supervisors are responsible for evaluating financial activity that could potentially lead to an employee debt by:



1. Validating time and attendance records for accuracy.

2. Initiating Time & Attendance (T&A) corrections.

3. Examining and certifying travel vouchers for accuracy.

4. Initiating timely and accurate personnel action requests.

5. Reporting errors immediately to the applicable program office.

6. Reinforcing IRS’s requirements for financial responsibility.


**1.36.4.1.3.16** **(05-04-2020)**

##### IRS Employees and Former IRS Employees

1. Employees and former employees are responsible for paying all non-tax debts owed to the IRS.

2. Employees are responsible for:



1. Ensuring time and attendance is posted accurately.

2. Reviewing earnings and leave statements to ensure their pay is correct.

3. Reviewing their Standard Form 50 (SF-50) to ensure increases in pay are correct.


3. Employees must notify the IRS of errors and are expected to repay salary overpayments.

4. Employees and former IRS employees are responsible for responding timely to debt letters and paying all undisputed administrative debts.


**1.36.4.1.4** **(07-31-2024)**

#### Program Management and Review

1. Program reports are used for collecting and measuring data needed for the program objective:



1. The IRS must execute a certification agreement annually to Treasury that delinquent non-tax debts referred to Treasury for collection purposes were valid and legally enforceable.

2. HCO Austin Payroll Center uses the Payroll and Personnel Systems (PPS) Measures Dashboard Report to determine if the IRS is collecting non-tax debts owed and to identify outreach opportunities that could prevent debt creation.

3. HCO Austin Payroll Center generates reports from the NFC’s ABCO System to monitor employee and former employee non-tax debt information.

4. HCO Debt Management uses the PPS monthly measure report to obtain a summary of IRS non-tax debt that shows current debt information for all active, non-pay status and separated employees.

5. Government Payables and Funds Management uses monthly reports to monitor the status of aging and delinquent debts submitted for collections.

6. The Treasury Report on Receivables is the Treasury’s comprehensive means of collecting data on the status and condition of the federal government’s non-tax debt portfolio.


2. Program Effectiveness:



1. The Government Payables and Funds Management office measures effectiveness of the program by ensuring the referral of employee delinquent non-tax debts for enforced collection to the National Finance Center 30 calendar days after final due process or after 60 calendar days delinquent and former employee or entity delinquent non-tax debts to Fiscal Service before the debt is delinquent 120 calendar days.

2. The HCO measures effectiveness by verifying continued employment for salary offset or the need to refer to Fiscal Service for collection if no longer employed by the Service and delinquent more than 120 calendar days.


**1.36.4.1.5** **(05-04-2020)**

#### Program Controls

1. Program controls for non-tax debts owed to the United States include:



|     |     |
| --- | --- |
| **Control** | **Control Method** |
| Validations | All requests for accounts receivable contain dual levels of approval from the requesting area prior to submission to the Government Payables and Funds Management Debt Collection Unit to ensure validity of the debt. Dual levels of approval are also completed by the Intragovernmental and Funds Processing section before and after establishment to ensure accuracy and completeness. |
| Documentation/Retention | The applicable business unit maintains all supporting documentation. Government Payables and Funds Management ensures the inclusion of the supporting documentation with the account receivable request and maintains both in their files. |
| Reporting | Monthly reports are provided to the Government Payables and Funds Management director and section chiefs on the status of open debt to monitor aging debt and to ensure delinquent debts are submitted to Fiscal Service’s Debt Management Services or NFC timely. |
| Confidential Data | HCO and Government Payables and Funds Management use restricted access sites to store employee debt information. |


**1.36.4.1.6** **(07-31-2024)**

#### Terms/Definitions

1. The following terms and definitions apply to this program:



01. **Account receivable** \- An amount owed to the government by an individual organization or other entity to satisfy a non-tax debt or claim.

02. **Administrative debt** \- A non-tax debt owed to the federal government that occurs because of administrative actions. (e.g., salary and benefit overpayments, unpaid fines and penalties, travel overpayments). Also referred to as administrative non-tax debt or non-tax debt.

03. **Administrative Fee** \- Additional costs incurred in processing and handling a debt because it has become delinquent.

04. **Administrative wage garnishment (AWG)** \- The withholding of a portion of a debtor’s non-federal pay to satisfy a non-tax debt owed to the IRS.

05. **Appeal** \- An administrative proceeding in which the debtor requests a higher management official review of the determination that they owe all or part of the debt.

06. **Automatic stay** \- The statutory court order that prohibits the Department of the Treasury from pursuing further collection action against the debtor while the debtor’s bankruptcy is pending.

07. **Bankruptcy** \- A legal procedure established under Title 11, Chapters 7, 11 and 13 of the United States Code (Bankruptcy Code) whereby the debtor may seek relief from the claims of a creditor.

08. **Compromise** \- Acceptance of less than the full amount of the debt owed from the debtor in satisfaction of the debt.

09. **Contingency fees** \- Administrative costs assessed by Fiscal Service and/or private collection agencies for the successful enforced collection of delinquent debt. Contingency fees are paid from amounts collected from the debtor.

10. **Cross-servicing** \- The process whereby agencies refer delinquent federal non-tax debt to the Fiscal Service for enforced collection.

11. **Debt** \- An amount of money that has been determined by an appropriate federal official to be owed to the United States from a current employee, a former employee or an entity.

12. **Debt collection** \- The recovery, in full or in part, of an administrative (non-tax) debt owed to the IRS through the receipt of money, either in the form of a check, money order or by electronic means.

13. **Default** \- Failure to meet a financial obligation.

14. **Delinquent** \- A debt that is not paid by the due date specified in the debt letter or for which payments are not received in compliance with the terms of an approved repayment agreement.

15. **Disposable pay** \- The amount of an employee's wages that remains after deductions from earnings of any amount required by law to be withheld. These deductions include, but are not limited to, FICA taxes, Medicare taxes and federal, state and local income taxes. They do not include discretionary deductions such as financial allotments and charitable contributions.

16. **Due process** \- The requirement to give the debtor notice of a non-tax debt and the opportunity to dispute the debt and intended collection action.

17. **Enforced salary offset** \- The process of collecting a percentage of an employee's current salary to satisfy a delinquent non-tax debt.

18. **Financial hardship** \- An inability to meet the basic living expenses for goods and services necessary for the survival of the debtor, their spouse and any dependents.

19. **Health insurance receivable** \- A debt established to recover advanced employee salary submitted by the IRS to the insurance carrier to pay an employee’s share of Federal Employee Health Benefit (FEHB) premiums during a period of non-pay or insufficient pay status or due to a correction made to the FEHB.

20. **Hearing Official** \- An Administrative Law Judge or other individual authorized to conduct a hearing and issue a final decision in response to a request for a hearing.

21. **Interest** \- The amount assessed on delinquent debts to compensate the government for the time value of money owed and not paid when due; interest is accrued and assessed from the date of delinquency. Often referred to as additional interest.

22. **Just financial obligation** \- Any financial obligation acknowledged by the employee or reduced to judgment by a court.

23. **Lump sum payment** \- A single non-recurring payment to pay a debt in full.

24. **Overpayment** \- Any amount paid that is more than the amount owed to the employee and to which they are not entitled.

25. **Penalties** \- Punitive charges assessed on delinquent debts. The rate to be assessed is set by law and is assessed on the portion of a debt remaining delinquent more than 90 calendar days.

26. **Principal** \- An amount owed by the debtor, excluding interest, penalties, administrative costs, fees and prepaid charges.

27. **Private collection agency** \- A private-sector entity whose primary business is the collection of delinquent debts.

28. _Proof of Debt_ \- Document(s) of which a creditor submits details of its claim.

29. **Repayment agreement** \- A written contract in which the debtor agrees to pay the debt via periodic installments.

30. **Reschedule** \- A change in the existing terms or conditions to facilitate repayment of a debt.

31. **Restitution** \- Compensation to the United States for a loss, damage or injury.

32. **Salary debt** \- A debt that occurs because of pay and leave actions, including debts resulting from benefits activities.

33. **Salary offset** \- The process of collecting a percentage or set dollar amount of the employees’ current salary to repay a debt.

34. **Treasury Offset Program (TOP)** \- A Fiscal Service program that offsets all eligible federal payments for repayment of delinquent debt.

35. **Wage garnishment** \- The process of withholding amounts for delinquent non-tax debt from the debtor’s disposable non-federal wages and paying those amounts to the government in accordance with a withholding order.

36. **Waiver** \- In accordance with an appropriate statute, the cancellation, remission, forgiveness or non-recovery by the creditor agency of a non-tax debt owed to that agency and generally initiated as a result of the debtor’s request.

37. **Waiver request** \- A petition seeking relief from paying a non-tax debt.


**1.36.4.1.7** **(08-04-2022)**

#### Acronyms

1. The following acronyms apply to this program:



|     |     |
| --- | --- |
| **Acronym** | **Meaning** |
| Fiscal Service | Bureau of the Fiscal Service |
| DOJ | Department of Justice |
| ESP | Emergency Salary Payment |
| FEHB | Federal Employees Health Benefits |
| HRSS | Human Resources Shared Services |
| LERN | Labor/Employee Relations and Negotiations |
| NFC | National Finance Center |
| TIGTA | Treasury Inspector General for Tax Administration |
| TOP | Treasury Offset Program |


**1.36.4.1.8** **(05-04-2020)**

#### Related Resources

1. Related resources for this IRM include:



01. IRM 1.32.1, IRS Local Travel Guide

02. IRM 1.32.4, Government Travel Card Program

03. IRM 1.32.11, IRS City-to-City Travel Guide

04. IRM 1.32.12, IRS Relocation Travel Guide

05. IRM 1.32.13, Relocation Services Program

06. IRM 1.35.13, Administrative Waiver

07. IRM 6.550.1, Pay Administration (General)

08. IRM 6.610, Hours of Duty

09. IRM 6.630, Absence and Leave

10. IRM 1.2.2.2.13, Delegation Order 1-15, Waiving Claims Against Current or Former Employees for Erroneous Payments

11. IRM 1.2.2.2.14, Delegation Order 1-16, Agency Collection Action

12. [Federal Employees Health Benefits (FEHB) Program Handbook](https://www.opm.gov/healthcare-insurance/healthcare/reference-materials/fehb-handbook/)

13. [Federal Employees Group Life Insurance (FEGLI) Program Handbook](https://www.opm.gov/healthcare-insurance/life-insurance/reference-materials/publications-forms/fegli-handbook/)

14. IRS Employee Resource Center website

15. [Managing Federal Receivables, A Guide for Managing Loans and Administrative Debt](https://fiscal.treasury.gov/debt-management/resources/managing-federal-receivables.html)


**1.36.4.2** **(07-31-2024)**

### Debts Arising from Pay and Leave Actions

1. Employees may incur debts that arise as the result of pay and leave actions including but not limited to:



1. Emergency salary payments (ESP)

2. Advanced leave

3. Salary overpayments

4. FEHB Premiums

5. Student Loan Repayment Program service agreement breaches


**1.36.4.2.1** **(05-04-2020)**

#### Emergency Salary Payments

1. An ESP may be issued to replace a salary payment not received by the employee or that NFC did not generate due to an administrative error.



1. An ESP is collected from the employee’s next salary payment.

2. Any ESP not repaid by the end of the year it was received is subject to income tax withholding and is reported on the debtor’s Form W-2, Wage and Tax Statement.


**1.36.4.2.2** **(05-04-2020)**

#### Advanced Leave

1. Advanced leave is subject to repayment. See IRM 6.630.1.6.3 , Payment of Advanced Leave by Separating Employees and IRM 6.630.1.6.4, Payment of Advanced Leave While Currently Employed, for further information.


**1.36.4.2.3** **(08-04-2022)**

#### Salary Overpayments

1. Salary overpayments are erroneous payments that arise from administrative discrepancies from:



1. Time and attendance transactions.

2. Payroll processing.

3. Personnel actions by either the employee or the IRS.


2. Salary overpayments also include errors in processing FEHB payments that are unrelated to employee rights to continue or terminate coverage when the employee goes into a non-pay or insufficient pay status. See IRM 1.36.4.2.4 for FEHB premiums information.

3. Employees have a responsibility to notify the IRS of errors and may be required to repay salary overpayments, including those caused by the IRS.

4. The IRS notifies the employee when it determines that a salary overpayment has occurred and requests repayment. Failure to remit payment or enter into an acceptable repayment agreement by the date specified in the debt letter will result in the debt being considered delinquent.

5. If a salary overpayment is $50 or less, the IRS may automatically collect the full amount from the employee’s next salary payment and a notice will be placed on the Statement of Earnings and Leave for the collection. If the employee is in a non-pay status, normal debt collection procedures will apply and they will be provided with notice of the debt.

6. An employee who receives an erroneous salary overpayment may request a waiver of repayment. See IRM 1.35.13, Administrative Waiver, for more information.

7. Salary overpayments not repaid in the same year as received are considered taxable income and reported on Form W-2, Wage and Tax Statements, as applicable.


**1.36.4.2.4** **(08-04-2022)**

#### Federal Employees Health Benefits Premiums (FEHB)

1. The FEHB program provides health benefits for federal employees. Both the employee and the IRS pay a portion of the premium amount with the employee’s portion of the premium being withheld from their salary each pay period. An employee may incur a debt when they cannot pay their share of the premium because the employee:



1. Entered a non-pay status.

2. Received insufficient pay to cover the FEHB premium amount.

3. Experienced a life event that requires special processing.


2. Federal employees in a non-pay status or who receive salary that is insufficient to pay their share of the FEHB premium may elect to continue their enrollment for a period not to exceed one year during which time the employing agency may approve advanced pay to cover the employee’s share of the FEHB premium per [5 USC Section 8906(e)](http://uscode.house.gov/view.xhtml?req=5+usc+8906&f=treesort&fq=true&num=14&hl=true&edition=prelim&granuleId=USC-prelim-title5-section8906). If advanced pay is necessary to cover the employee’s share of their FEHB premium, the employee or former employee (if the employee does not return to pay status) is obligated to repay the IRS.

3. If the employee elects to continue coverage while in a leave without pay status but not to pay their health insurance premiums on a current basis, the employee is indebted to the IRS for all payments made on their behalf. Collection on the debt is made per 5 CFR Section 890.502, Withholding, contributions, LWOP, premiums and direct premium payment, when the employee returns to pay status.

4. An employee’s request for FEHB premium advances during periods of non-pay or insufficient pay status and payment upon that request does not result in an erroneous payment. The IRS does not have the authority to waive the collection of FEHB debts.

5. For additional information about repaying FEHB premiums, see:



1. "Payroll Debts Owed to the Service" in the Pay chapter of Document 9669, Employee Personnel Resource Guide.

2. Employee Resource Center (ERC).

3. "Leave Without Pay Status and Insufficient Pay" chapter in the FEHB Program Handbook on the Office of Personnel Management (OPM) website.


**1.36.4.2.5** **(07-31-2024)**

#### Student Loan Repayment Program

1. An employee receiving the Student Loan Repayment Program benefit must sign a service agreement that commits the employee to continue employment with the IRS for a period of at least 3 years beginning on the effective date of the service agreement.

2. Benefits received beyond the initial service agreement will automatically extend the service agreement for one year for each annual payment made.

3. An employee must reimburse the IRS for all benefits received if separated either voluntarily or involuntarily (for misconduct, unacceptable performance or a negative suitability determination) prior to the end of the service agreement.


**1.36.4.3** **(08-04-2022)**

### Debts arising from other various actions

1. Frequent actions that establish debt include but are not limited to:



1. Travel transactions

2. Relocation transactions

3. Training

4. Restitutions

5. Vendor transactions


2. When a debtor does not repay the outstanding balance or fails to submit a voucher to account for the travel or relocation expenses, the entire amount of the outstanding balance becomes due and payable and is subject to enforced collection action.

3. When a current employee debt is referred to NFC for salary offset, a deduction of 15% of their disposable pay will occur each pay period until the debt is satisfied unless the employee has entered into an approved repayment agreement.

4. When a former employee or non-employee debt is referred to Fiscal Service, the Treasury Offset Program (TOP) offsets federal payments due to the debtor. Offset may be from federal salary travel advances, travel or relocation voucher reimbursements, tax refunds and federal retirement payments.


**1.36.4.3.1** **(08-04-2022)**

#### Travel Transactions

1. Debts arising from travel transactions include:



1. Travel advances - If a trip is canceled or postponed or the travel authorization has expired, the debtor must repay the outstanding balance of any advance not liquidated in the travel system.

2. Travel overpayments and corrections to original travel vouchers - Post audit reviews are randomly conducted of e-travel vouchers from the electronic travel system to identify discrepancies.

3. See IRM 1.32.1, IRS Local Travel Guide and IRM 1.32.11, IRS City-to-City Travel Guide for additional information.


**1.36.4.3.2** **(08-04-2022)**

#### Relocation Transactions

1. Debts arising from relocation transactions include:



1. Relocation advances -The employee must repay the remaining balance when the employee’s relocation voucher does not liquidate the outstanding balance of each relocation travel segment. If the relocation is canceled, the employee is responsible for repaying the full amount of the outstanding relocation.

2. Service agreements - When an employee violates a service or transportation agreement or fails to affect the transfer or appointment, the employee must reimburse the amount expended by the IRS.

3. Transportation of household goods - When the weight of an employee's household goods exceeds the maximum allowable limit, the employee must reimburse the IRS for the transportation costs and other charges for the excess. Employees must reimburse the IRS for unauthorized services performed by the mover or third-party service provider. See IRM 1.32.12, IRS Relocation Travel Guide and IRM 1.32.13, Relocation Services Program for additional information.

4. Withholding Tax Allowance is calculated and applied to the employee's relocation voucher and third-party payments made on the employee's behalf. When the employee’s taxable income is below the Withholding Tax Allowance, the IRS determines the amount the employee must reimburse the IRS for the overpayment.

5. Relocation overpayments and corrections to original relocation vouchers which are audited upon receipt.


**1.36.4.3.3** **(05-04-2020)**

#### Training

1. An employee may incur a non-tax debt to the IRS resulting from the employee’s breach of agreement for the IRS’s investment in the employee’s training.



1. The IRS may offer to pay for an employee to attend courses that enable employees to meet a career learning plan milestone or competency need. This benefit may be contingent upon the employee agreeing to complete the course satisfactorily by receiving a passing grade of a “C” or higher, certification or other suitable documentation of satisfactory completion. Employees or former employees who do not satisfactorily complete the course may be required to reimburse the IRS for costs incurred.

2. IRM 6.410.1.2.16.2, Learning and Education, SF-182 Process, states “if the employee voluntarily leaves the government before the agreed upon length of service is completed, the IRS has the right to require repayment for the tuition and related fees, travel and other incidental expenses (excluding salary) incurred in connection with the training.”


**1.36.4.3.4** **(08-04-2022)**

#### Restitutions

1. A restitution debt occurs when a debtor is held liable for a loss incurred by the IRS because of negligent, willful, unauthorized or illegal acts by an employee, former employee, individual or entity that include:



1. Theft, misuse or loss of government funds.

2. False claims for services and travel.

3. Illegal, unauthorized obligations and expenditures of government appropriations.

4. Unauthorized use of government-owned or leased equipment, facilities, supplies and services for other than official or approved purposes.

5. Lost, stolen, damaged or destroyed government property or equipment.

6. Improper purchases made with the government purchase card.


2. The debtor is responsible for compensating the IRS for restitution debts.

3. For additional information about improper purchases, see the Employee Resource Center website for the Restricted Purchase List.


**1.36.4.3.5** **(08-04-2022)**

#### Vendor Transactions

1. Debts arising from vendor transactions include but are not limited to:



1. IRS Grant Programs - If a recipient of funds from an IRS grant program does not comply with the federal requirements, terms and conditions of the program, the funds must be paid back to the IRS.

2. User Fee Programs - Participants that receive benefits or services for a fee must pay all invoices in full by the due date. See IRM 1.33.7, User Fees, for additional information.

3. Contracted Goods and Services - Any payment made to a vendor for goods or service to be provided to the IRS must be repaid to the IRS if the terms and conditions of the contract are not fulfilled. See IRM 1.35.3, Receipt and Acceptance Guidelines, for additional information.


2. Delinquent debts are referred to Fiscal Service for collection through their Debt Management Services and are collected through various means such as:



1. Administrative Wage Garnishment.

2. Credit Bureau Reporting.

3. Treasury Offset Program (TOP).

4. Referral to Private Collection Agencies.


3. Delinquent debtors are generally barred from receiving federal loans or loan guarantees until the debt is resolved.


**1.36.4.4** **(05-04-2020)**

### Debt Letter and Due Process Rights

1. Federal debt collection statutes require the IRS to provide employees and entities with debt letters and due process rights under the Debt Collection Act of 1982 and the Debt Collection Improvement Act of 1996.

2. The letter outlines the following information:



01. The type, nature and amount of the debt.

02. The payment due date to avoid the debt becoming delinquent.

03. Payment instructions and the IRS point-of-contact.

04. Repayment options available to the employee.

05. IRS policies for accruing interest, administrative charges and penalties on delinquent debts.

06. Instructions to dispute the amount or the existence of the debt.

07. Instructions to request a review of the debt or inspect and copy IRS records related to the debt.

08. Instructions to petition for a salary offset hearing before a non-Treasury official, if applicable.

09. Instructions for requesting an internal review of the debt (paper hearing), if applicable.

10. The collection actions IRS may take to enforce collection if the debt is not paid by the payment due date including commencement of enforced salary offset for current employees, referral of the debt to Fiscal Service for collection by offset or a private collection agency, reporting of the debt to a credit reporting bureau or referral of the debt to the Department of Justice (DOJ).

11. Instructions for submitting a financial hardship request.

12. Instructions for requesting a waiver of the debt, if applicable. See IRM 1.35.13, Administrative Waiver for additional information regarding the waiver process.


**1.36.4.5** **(05-04-2020)**

### Delinquency

1. A debt is delinquent if it has not been paid by the date specified in the IRS’s debt letter.

2. If an employee enters into an applicable repayment agreement, the debt becomes delinquent when it has not been paid pursuant to the terms of the agreement.

3. If a debtor fails to respond to the debt letter, the debt is considered delinquent as of the date the original notice was mailed. Interest, administrative charges and penalties are added to the unpaid balance and the IRS will begin enforced collection action.


**1.36.4.5.1** **(08-04-2022)**

#### Interest

1. The IRS assesses interest on a debt at the Current Value of Funds Rate in effect at the time the debt becomes delinquent unless the debt is paid in full within the grace period. The Current Value of Funds Rate is based on the Treasury Tax and Loan Rate to the nearest whole percent.

2. Interest is assessed on the principal balance and the rate remains fixed for the duration of the debt without compounding.


**1.36.4.5.2** **(05-04-2020)**

#### Administrative Charges

1. The IRS assesses administrative charges, which represent the additional costs incurred by the IRS for handling and processing a delinquent debt.


**1.36.4.5.3** **(05-04-2020)**

#### Penalties

1. The penalty rate the IRS assesses is set by law, [31 USC Section 3717, Interest and penalty on claims](http://uscode.house.gov/view.xhtml?req=31+usc+3717&f=treesort&fq=true&num=23&hl=true&edition=prelim&granuleId=USC-prelim-title31-section3717). Penalties accrue on all amounts (principal, interest and administrative charges) that remain outstanding for more than 90 calendar days. The penalty accrues from the date of delinquency.


**1.36.4.5.4** **(05-04-2020)**

#### Waiver of Interest, Administrative Costs and Penalties

1. The IRS may waive in whole or in part the interest, administrative charges and penalties in accordance with 31 Section CFR 901.9(g), of the Federal Claims Collection Standards when:



1. The debt is paid within 30 calendar days from the date the debt is established.

2. The debt is waived as part of a compromise.


2. Interest, administrative costs and penalties are not imposed for any period during which collection activity has been suspended pending agency review.

3. The IRS may waive the collection of interest, administrative charges and penalties when it determines that collection would be against equity and good conscience or is not in the best interest of the government.


**1.36.4.6** **(05-04-2020)**

### Application of Payments

1. Pursuant to 31 Section CFR 901.9(f), Federal Claims Collection Standards, the IRS applies delinquent debt payments received against the outstanding balance of a debt in the following order:



1. Penalties.

2. Administrative charges.

3. Interest.

4. Principal.


**1.36.4.7** **(05-04-2020)**

### Debts Referred to NFC

1. A debt owed to the IRS by one of its employees is subject to enforced salary offset when the debt becomes delinquent (5 CFR Section 550,1104, Agency regulations; 31 Section CFR 5.12(c), How will Treasury entities offset a Federal employee’s salary to collect a Treasury debt?).

2. Enforced salary offset may be initiated unless an employee repays the debt in a lump sum by the date provided in the debt letter or establishes a repayment agreement and maintains the terms of the agreement.

3. Each employee’s delinquent debt is subject to a 15% withholding from their disposable pay each pay period unless the employee:



1. Elects to repay the debt in a lump sum.

2. Agrees in writing to a repayment agreement at a percentage greater than 15%.

3. Agrees in writing to a revised repayment schedule based on a financial hardship determination.

4. Requests a salary offset hearing before a non-Treasury hearing official and the hearing official orders that a lesser amount be withheld from the employee’s disposable pay.

5. Requests a waiver or review of the debt.


4. Under enforced salary offset for paying a non-tax debt to the IRS, the amount deducted for any period may not exceed 15% of disposable pay ( [5 USC Section 5514(a)(1),](http://uscode.house.gov/view.xhtml?req=5+usc+5514&f=treesort&fq=true&num=5&hl=true&edition=prelim&granuleId=USC-prelim-title5-section5514) Installment deduction for indebtedness to the United States).

5. The IRS terminates enforced salary offset when the full amount of the debt is collected or the employee separates from the IRS. However, after the employee separates from the IRS (either voluntarily or involuntarily), the IRS imputes a lump sum deduction exceeding 15% of disposable pay from any final salary payments, which might include accrued leave, etc., to satisfy the debt. If the debt is not satisfied with the lump sum payment, the bill must be paid in full by the employee or it will be considered delinquent and referred to Fiscal Service for collection action.


**1.36.4.8** **(07-31-2024)**

### Debts Referred to Fiscal Service

1. The Digital Accountability and Transparency Act of 2014 requires agencies to refer all non-tax debts or claims owed to the government that are delinquent for more than 180 calendar days for cross-servicing to Fiscal Service. Because the IRS relies on Fiscal Service to provide administrative offset on the IRS’s behalf, the IRS must also refer those debts to Fiscal Service before 120 days of delinquency.

2. A non-tax debt is eligible for referral to Fiscal Service if the delinquent debt is legally enforceable and greater than $25 including penalties, administrative fees and interest.

3. When the IRS refers a debt to Fiscal Service for enforced collection, Fiscal Service assesses contingency fees and deducts them from amounts collected from the debtor. The balance of the payment is applied to the delinquent debt using the order described in _IRM 1.36.4.6_, Application of Payments.

4. The IRS does not refer a debt to Fiscal Service if:



1. A waiver request is pending.

2. The debtor has filed for bankruptcy protection or the debt has summarily been discharged by bankruptcy proceeding.

3. The debtor is deceased.


5. Information on the Fiscal Service debt collection program is available on the [Fiscal Service](https://www.fiscal.treasury.gov/index.html) website.


**1.36.4.8.1** **(05-04-2020)**

#### Cross-Servicing Program

1. When a debt is referred to Fiscal Service, the IRS is certifying in writing, under the penalty of perjury, that to the best of their knowledge and belief that:



1. The debt is valid and is not subject to any circumstances that legally preclude collection.

2. There are no pending appeals.

3. The debtor has been given the required notice of due process.


2. Fiscal Service uses several debt collection methods:



1. Mailing letters and following up with phone calls.

2. Negotiating payment agreement options.

3. Reporting debts to credit bureaus.

4. Referring debts to the Treasury Offset Program.

5. Referring debts to the Administrative Wage Garnishment Program.

6. Referring cases to private collection agencies and the DOJ.


3. Fiscal Service maintains debt balance information, collects the funds paid by the debtor and returns the funds to the IRS for proper processing, accounting and application to the debt.

4. Fiscal Service charges contingency fees for its incurred costs related to the Cross-Servicing Program.

5. Additional fees are assessed when the debt is:



1. Collected through the Treasury Offset Program.

2. Referred to private collection agencies.

3. Referred to the DOJ.


6. When Fiscal Service successfully offsets or otherwise collects all or part of a debt, the collected amount is applied in the following order:



1. Contingency fees.

2. Penalties.

3. Administrative costs (other than contingency fees).

4. Interest.

5. Principal.


7. Fiscal Service refers debts to the DOJ for litigation when aggressive collection activity has been attempted and the debt cannot be compromised, suspended or terminated.


**1.36.4.8.1.1** **(08-04-2022)**

##### Treasury Offset Program

1. The Treasury Offset Program (TOP) is a centralized offset program, administered by Fiscal Service, to collect delinquent debts and child support payments owed to federal and state agencies.

2. When a debt is referred to TOP for collection, Fiscal Service is authorized to seize federal payments due to the debtor and apply it to the debt balance.

3. Federal law limits the amount that may be withheld from some types of federal payments that are subject to certain exemptions and limitations. Examples of federal payments eligible for offset include:



1. Federal IRS tax refunds.

2. Retirement payments issued by the OPM.

3. Travel advances and reimbursements.

4. Certain federal benefit payments including Social Security benefits (other than Supplemental Security income), Railroad Retirement benefits (other than tier 2) and Black Lung (part B benefits).

5. Grant payments.

6. Vendor payments.

7. Active military and military retirement payments.

8. Other federal payments that are not exempt by law or by action of the Secretary of the Treasury.


4. Fiscal Service charges a fee to cover its costs for collections through TOP. The fee is collected from each offset.

5. For debtors with multiple debts, Fiscal Service applies the collections to the debtor in the following order:



1. IRS income tax debts.

2. Child support debts.

3. Federal non-tax debts.

4. State income tax debts.


6. When a debtor owes multiple similar debts (for example, income tax debts for multiple years), Fiscal Service applies collections to liquidate the oldest debt first.


**1.36.4.8.1.2** **(05-04-2020)**

##### Private Collection Agencies

1. Fiscal Service may refer delinquent uncollected debts to private collection agencies 30 calendar days after the date Fiscal Service issues a debt letter.

2. A private collection agency remits any collections received to Fiscal Service. Fiscal Service remits the funds to the IRS with supporting detailed debt information. Private collection agencies net fees for collecting debts against the amount collected before remitting the funds to Fiscal Service.


**1.36.4.8.1.3** **(08-04-2022)**

##### Administrative Wage Garnishment

1. Administrative Wage Garnishment (AWG) is a collection tool that Fiscal Service uses to collect delinquent debt from:



1. Federal employees who have private sector part-time jobs.

2. Non-federal employees.


2. Debtors that object to garnishment of their wages can request a hearing from Fiscal Service.

3. Additional information on Administrative Wage Garnishment is available on the Fiscal Service website.


**1.36.4.9** **(05-04-2020)**

### Bankruptcy

1. The IRS is generally prohibited from pursuing further collection action due to an automatic stay when a debtor files for bankruptcy protection effective the date of the filing of bankruptcy.

2. Fiscal Service returns previously referred delinquent debts to the IRS when they determine the debtor has filed for bankruptcy protection.

3. If a debt is discharged by the bankruptcy court, the IRS is precluded from pursuing collection on the debt incurred by the debtor.

4. Generally, under [11 USC Section 523(a)(8), Exceptions to Discharge](http://uscode.house.gov/view.xhtml?req=11+usc+523&f=treesort&fq=true&num=55&hl=true&edition=prelim&granuleId=USC-prelim-title11-section523), Tuition Assistance Program debts are not dischargeable unless a bankruptcy court has found that enforcing the debt would impose an undue hardship on the debtor or their dependents. In certain other circumstances, the debt may be dischargeable in bankruptcy. Consultation with GLS should occur when determining whether a Tuition Assistance Program debt is dischargeable in bankruptcy.

5. If the bankruptcy case is dismissed by the bankruptcy court, the IRS continues enforced collection efforts.

6. The IRS may begin enforced collection on any debt incurred after the bankruptcy petition has been filed and where an automatic stay is not in effect.


**1.36.4.10** **(07-31-2024)**

### Retirement and Separation

1. Employees are responsible for satisfying debts owed to the IRS prior to separation or retirement. The employee must contact HCO or Government Payables and Funds Management prior to leaving the IRS to discuss payment arrangements for any unpaid debt.

2. The IRS uses all available collection tools described in this IRM to collect any unpaid debts owed by a former employee.

3. An employee's final salary payment and lump sum leave payment may be offset if the employee does not satisfy the debt. The final salary payment may be delayed or reduced by the amount owed. The 15% disposable pay limit does not apply. If the entire debt is not satisfied, the IRS will establish a receivable for the remaining balance and begins collection activity.

4. When an employee retires with an existing salary debt, the NFC notifies OPM to garnish retirement benefits.

5. For additional information:



1. See "Schedule of Separation Actions" in the Retirement chapter of Document 9669, Employee Personnel Resource Guide.

2. Contact the Employee Resource Center (ERC) using IRS Service Central (IRWorks).


**1.36.4.11** **(05-04-2020)**

### Fraud Claims

1. If the IRS identifies a debt arising from fraud, false statements or misrepresentations by an employee, the matter will be referred to TIGTA or Chief Counsel for referral to the DOJ.


**1.36.4.12** **(08-04-2022)**

### Termination of Debts

1. When pursuing further debt collection is no longer appropriate, the IRS may terminate debt collection action, write-off and close-out the debt (31 CFR Section 903.3, Termination of collection activity) when:



1. The IRS is unable to collect any substantial amount through its own efforts or through the efforts of others or the debtor is deceased or is not able to be located.

2. The debt cannot be substantiated.

3. Costs of collection are anticipated to exceed the amount recoverable.

4. The debt is legally without merit or enforcement of the debt is prohibited by statute of limitations.

5. The debt has been discharged in bankruptcy.


2. If a debt is terminated and is $600 or more, the amount is reported on Form 1099-C, Cancellation of Debt, except when it is discharged by bankruptcy or the debtor is under the jurisdiction of the court for remedy. If interest is incurred from the cancelled debt, the interest portion is recorded in the financial system and reported separately in box 3 of the 1099-C. Aggregation of debt is allowed, but not required.

3. See 26 CFR Section 1.6050P-1, Information reporting for discharges of indebtedness by certain entities, for more information.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-036-004#addtoany "Show all")

A2A