---
url: "https://www.irs.gov/irm/part1/irm_01-035-004"
title: "1.35.4 Purchase Card Program | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-035-004#main-content)

- 1.35.4  [Purchase Card Program](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030628995536)
  - 1.35.4.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030628831856)
    - 1.35.4.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030628827472)
    - 1.35.4.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030628971168)
    - 1.35.4.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030628825600)
      - 1.35.4.1.3.1  [CFO, Deputy CFO and Senior Associate CFO for Financial Management](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030628820112)
      - 1.35.4.1.3.2  [Chief Procurement Officer and Office of Procurement Policy](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030628818320)
      - 1.35.4.1.3.3  [Credit Card Services Office](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030629132032)
      - 1.35.4.1.3.4  [Purchase Card Approving Officials](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030629127776)
      - 1.35.4.1.3.5  [Purchase Cardholders](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030601510384)
      - 1.35.4.1.3.6  [Convenience Check Program Manager](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030628844128)
      - 1.35.4.1.3.7  [Convenience Check Program Coordinator](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030628841232)
    - 1.35.4.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030628837360)
    - 1.35.4.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030628984464)
    - 1.35.4.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030601975808)
    - 1.35.4.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030628951664)
    - 1.35.4.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030628935808)
    - 1.35.4.1.9  [Purchase Card Criteria](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030628933264)
      - 1.35.4.1.9.1  [Purchase Card Criteria for Purchase Cardholders](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030628931232)
      - 1.35.4.1.9.2  [Purchase Card Criteria for PC Approving Officials](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600398176)
  - 1.35.4.2  [Types of Purchase Card Accounts](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600390720)
    - 1.35.4.2.1  [Micro-Purchase Card](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600389696)
    - 1.35.4.2.2  [Enforcement Purchase Card (SB/SE)](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600387504)
    - 1.35.4.2.3  [Enforcement Purchase Card (CI)](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600385472)
    - 1.35.4.2.4  [Convenience Checks](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600382832)
      - 1.35.4.2.4.1  [Types of Convenience Check Purchase Cardholders](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600381168)
        - 1.35.4.2.4.1.1  [CFO, Credit Card Services Convenience Check Program](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600375904)
        - 1.35.4.2.4.1.2  [SB/SE, Property Appraisal and Liquidation Program](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600372832)
        - 1.35.4.2.4.1.3  [NHQ, Procurement Convenience Check Program](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600370416)
    - 1.35.4.2.5  [Warranted Contracting Officers - Purchases Greater than the Micro-Purchase Thresholds](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600367072)
  - 1.35.4.3  [Purchase Card Program Guidance](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600365024)
    - 1.35.4.3.1  [Authorized Purchase Card Use](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600363344)
    - 1.35.4.3.2  [Unauthorized Purchase Card Use](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600359344)
    - 1.35.4.3.3  [Purchase Card Restrictions](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600352016)
    - 1.35.4.3.4  [Split Purchases](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600350192)
    - 1.35.4.3.5  [Inappropriate Use](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600347104)
    - 1.35.4.3.6  [Separation of Duties and PC Approving Official Span of Control](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600338192)
    - 1.35.4.3.7  [Electronic Purchase Card Guide](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600332640)
    - 1.35.4.3.8  [Restricted Purchase List](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600330224)
    - 1.35.4.3.9  [Required Sources for Micro-Purchases](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600328128)
    - 1.35.4.3.10  [Information and Communication Technology Buys](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600325344)
    - 1.35.4.3.11  [Record Retention for Purchase Card Documentation](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600319472)
  - 1.35.4.4  [Purchase Card Compliance Reviews](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600316320)
  - 1.35.4.5  [Purchase Card Program Training](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600312016)
    - 1.35.4.5.1  [Purchase Card/Convenience Check Training](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600310272)
    - 1.35.4.5.2  [PC Approving Official Training](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600298096)
    - 1.35.4.5.3  [Refresher Training](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600294928)
  - 1.35.4.6  [Activating the Purchase Card](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600292640)
  - 1.35.4.7  [Ordering a Replacement Card](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600290160)
  - 1.35.4.8  [Purchase Card Renewal Process](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600288256)
  - 1.35.4.9  [Documenting Purchase Card Transactions](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600283456)
  - 1.35.4.10  [Purchase Card Module](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600277296)
    - 1.35.4.10.1  [Purchase Card Order Log](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600275408)
    - 1.35.4.10.2  [Processing Time Frames](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600273120)
    - 1.35.4.10.3  [Transaction Reconciliation](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600268720)
  - 1.35.4.11  [Disputed Items](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600265056)
  - 1.35.4.12  [Purchase Card Account Changes](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600259808)
  - 1.35.4.13  [Purchase Card Account Information](https://www.irs.gov/irm/part1/irm_01-035-004#idm140030600255424)

# Part 1. Organization, Finance, and Management

# Chapter 35. Financial Accounting

# Section 4. Purchase Card Program

* * *

## 1.35.4 Purchase Card Program

#### Manual Transmittal

January 10, 2024

#### Purpose

(1) This transmits revised IRM 1.35.4, Financial Accounting, Purchase Card Program.

#### Material Changes

(1) IRM 1.35.4.1.2(1)a), Authorities, updated the title as follows: Office of Management and Budget (OMB)Circular A-123, Appendix B: A Risk Management Framework for Government Charge Card Programs.

(2) IRM 1.35.4.1.3.4(1), Purchase Card Approving Officials, added additional responsibilities and revised several bullets for clarity; removed Completing PC approval official refresher training every two years from bullet list.

(3) IRM 1.35.4.1.5(1), Program Controls, updated the standard monthly limit from $25,000 to $50,000; and the required card usage from four times to two times per year.

(4) IRM 1.35.4.1.9.1(1), Purchase Card Criteria for Purchase Cardholders, changed the purchase cardholder requirement to make an average of four purchases per fiscal year to two; revised several bullets for clarity; and added Complete Purchase Cardholder Refresher training every two years to the bullet list.

(5) IRM 1.35.4.1.9.2(1), Purchase Card Criteria for PC Approving Officials, added Failure to comply with the PC approving official criteria will result in the deactivation of the PC approving official account(s) after the bullet list.

(6) Minor editorial changes made throughout the IRM for clarity and link updates.

#### Effect on Other Documents

IRM 1.35.4, dated November 12, 2021, is superseded.

#### Audience

All business units

#### Effective Date

(01-10-2024)

Teresa R. Hunter

Chief Financial Officer

**1.35.4.1** **(12-13-2019)**

### Program Scope and Objectives

1. Purpose: This IRM provides guidance on the use of a government purchase card (PC).

2. The procedures in the Purchase Card Guide apply Servicewide. Individual business units may supplement the electronic Purchase Card Guide with additional restrictions on use of the PC by their employees. Convenience check guidelines must be followed by those cardholders authorized to use convenience checks. Relevant Federal Acquisition Regulation (FAR) provisions, such as FAR Part 13 Simplified Acquisition procedures, must be followed for purchases of goods over $10,000 ($2,500 for services; $2,000 for construction). Convenience check program participants can make payments to a vendor who does not accept the PC for purchases of $2,500 or less for safety, security and enforcement.

3. Audience: Servicewide

4. Policy Owner: Office of Procurement Policy

5. Program Owner: CFO, Credit Card Services office

6. Primary Stakeholders: All purchase cardholders who are responsible for purchasing goods and/or services for official government use and PC approving officials with oversight responsibility for the activities of purchase cardholders.

7. Program Goals: To deliver efficient card programs that enable IRS employees to obtain needed supplies and services to carry out their tax administration duties.


**1.35.4.1.1** **(12-13-2019)**

#### Background

1. The FAR, Subpart 13.2 states that the purchase card is the preferred method of making and paying for micro purchases.

2. The purchase credit card program is for IRS employees who are authorized to purchase goods and/or services for official government business. It is also for supervisory and administrative personnel who authorize, direct or review the activities of purchase cardholders.


**1.35.4.1.2** **(01-10-2024)**

#### Authorities

1. The authorities for this IRM include:



1. [Office of Management and Budget (OMB) Circular A-123, Appendix B](https://smartpay.gsa.gov/sites/default/files/downloads/Issuance-of-Revised-Appendix-B-to-OMB-Circular-A-123.pdf): A Risk Management Framework for Government Charge Card Programs

2. [FAR Part 13, Simplified Acquisition Procedures](https://www.acquisition.gov/dlad/part-13-%E2%80%93-simplified-acquisition-procedures)

3. [The Government Charge Card Abuse Prevention Act of 2012](https://www.govinfo.gov/content/pkg/PLAW-112publ194/html/PLAW-112publ194.htm)

4. [FAR Part 8, Required Sources of Supplies and Services](https://www.acquisition.gov/dars/part-8-%E2%80%93%E2%80%93-required-sources-supplies-and-services)

5. [Treasury Charge Card Management Plan](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwiYg5nS6deBAxWHMlkFHWHnB74QFnoECBsQAQ&url=https%3A%2F%2Fhome.treasury.gov%2Fsystem%2Ffiles%2F281%2FFY-2022-Charge-Card-Management-Plan.pdf&usg=AOvVaw20LXguiiipoARGbCeYqClE&opi=89978449)

6. [Department of Treasury Acquisition Procedures](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwjo6qe66teBAxXOnGoFHfYzCWsQFnoECA8QAQ&url=https%3A%2F%2Fhome.treasury.gov%2Fsystem%2Ffiles%2F281%2FDTAP_FY22_Edition.pdf&usg=AOvVaw1aMkUKakCoxpKRyg61aNlD&opi=89978449)


**1.35.4.1.3** **(12-13-2019)**

#### Responsibilities

1. This section provides responsibilities for:



1. CFO, Deputy CFO and Senior Associate CFO for Financial Management

2. Chief Procurement Officer and Office of Procurement Policy

3. Credit Card Services Office

4. Purchase card approving officials

5. Purchase cardholders

6. Convenience check program manager

7. Convenience check program coordinator


**1.35.4.1.3.1** **(12-13-2019)**

##### CFO, Deputy CFO and Senior Associate CFO for Financial Management

1. The CFO, Deputy CFO, Senior Associate CFO for Financial Management, and Associate CFO for Corporate Accounting are responsible for the government purchase card program.


**1.35.4.1.3.2** **(11-12-2021)**

##### Chief Procurement Officer and Office of Procurement Policy

1. The Chief Procurement Officer issues and monitors Certificates of Appointment for cardholders with authority over the micro-purchase threshold.

2. The Office of Procurement Policy is responsible for overseeing PC program policy. The Office of Procurement Program policy is also responsible for maintaining the Restricted Purchase List (RPL) and responding to RPL inquiries.


**1.35.4.1.3.3** **(12-13-2019)**

##### Credit Card Services Office

1. The Credit Card Services office, is responsible for:



1. Overseeing the IRS PC program.

2. Issuing program guidance for the PC program.

3. Overseeing periodic program reviews to monitor compliance with established procedures.

4. Issuing and monitoring individual Delegation of Procurement Authority (DPA) for micro-purchase cardholders.

5. Paying all invoices from the government credit card contractor for purchases made using the PC.


**1.35.4.1.3.4** **(01-10-2024)**

##### Purchase Card Approving Officials

1. Purchase card approving officials are responsible for:



1. Adhering to all Purchase Card Approving Official criteria and ensure appropriate card usage by purchase cardholders.

2. Assist purchase cardholder(s) with securing required approvals and uploading documentation to comply with policy regulations.

3. Reviewing the PC order log, transactions and supporting documentation to ensure appropriate approvals, funding and timely processing of transactions.

4. Reviewing purchases to ensure the purchase cardholder is adhering to all PC guidelines.

5. Approving all purchase cardholder posted transactions within 10 days of the transaction download date.

6. Associating and approving all transactions in the Purchase Card Module within 10 days of the posted transaction date in the absence of the purchase cardholder.


**1.35.4.1.3.5** **(11-12-2021)**

##### Purchase Cardholders

1. Purchase cardholders are responsible for:



1. Adhering to all PC criteria, Purchase Cardholder Guidelines and Responsibilities, and appropriate card usage as described in the electronic Purchase Card Guide.

2. Safeguarding the PC and account number at all times to prevent theft or unauthorized use.

3. Ensuring the purchase is allowable by checking the Restricted Purchase List and any business unit restrictions.

4. Obtaining open market vendor certification of compliance with the National Defense Authorization Act (NDAA) Section 889.

5. Obtaining Environmental, Health and Safety (EHS) professional’s purchase approval for certain items.

6. Initiating action to obtain a credit for any disputed item (duplicate, erroneous or over charges).

7. Attaching all required documentation relating to activity on the PC to the Purchase Card Module order log. All documentation for PC buys must be retained for six years from the billing cycle end date.

8. Reporting a lost or stolen PC promptly to the government credit card contractor, the PC approving official, Credit Card Services and TIGTA (if appropriate).

9. Notifying Credit Card Services of any necessary corrections to account information.


**1.35.4.1.3.6** **(12-13-2019)**

##### Convenience Check Program Manager

1. The convenience check program manager is responsible for:



1. Oversight of the convenience check purchase card program Servicewide.

2. Providing program guidance to customers.


**1.35.4.1.3.7** **(11-12-2021)**

##### Convenience Check Program Coordinator

1. The convenience check program coordinator is responsible for:



1. Coordinating the establishment of new convenience check purchase cardholder accounts.

2. Providing training for new users.

3. Providing support for convenience check issues.

4. Coordinating the check ordering process.


**1.35.4.1.4** **(12-13-2019)**

#### Program Management and Review

1. Program reports to Treasury and TIGTA: Credit Card Services prepares reports quarterly and semi-annually. Some of these reports are used to monitor policy compliance with the Government Charge Card Abuse Prevention Act of 2012 requirements.

2. The following chart lists the reports and their reporting frequency:




| **Report** | **Reporting Frequency** |
| --- | --- |
| OMB - Purchase Charge Card Report | Quarterly |
| Purchase Card Violations Report | Semi-annually |

3. Program effectiveness is measured through a series of transaction reviews:



1. Credit Card Services conducts monthly and quarterly transaction reviews to determine cardholder compliance with current guidelines and program effectiveness.

2. TIGTA conducts a semi-annual audit to assess IRS’s implementation and compliance with the Charge Card Abuse Prevention Act of 2012 requirements and provides a final report.


**1.35.4.1.5** **(01-10-2024)**

#### Program Controls

1. Appendix B to OMB Circular A-123, Improving the Management of Government Charge Card Programs, mandates agencies to have internal controls that include standard minimum requirements for the issuance and retention of a PC to reduce the administrative costs associated with the government PC.




| **Controls** | **Control Method** |
| --- | --- |
| Delegation of Procurement Authority (DPA)/Card Limits | Purchase card limit and scope of authority delegated to purchase cardholders: Accounts are established with a single transaction limit of $10,000 and a standard monthly limit of $50,000. |
| Separation of Duties | Separate roles are established for purchase cardholders, PC approving officials and funding officials to avoid situations where one employee or a small group of employees performs more than one step at time. |
| Merchant Category Codes (MCC) Template | A grouping of codes that are assigned to a purchase cardholder’s account based on their anticipated purchasing activity to help reduce the potential of inappropriate use of the PC. |
| Training | Required prior to issuance of card. |
| Refresher Training | Required every two years. |
| Required card usage | Purchase cardholder must use the card two times per year to retain purchase card process skills. |


**1.35.4.1.6** **(11-12-2021)**

#### Terms/Definitions

1. The following terms and definitions apply to this program:



01. **Authorization** \- The process undertaken by a vendor to verify that a purchase is allowable on a particular purchase cardholder account. Vendors sometimes seek authorization if a purchase exceeds certain dollar limits (e.g., $25 or $50). When a vendor seeks authorization for a purchase, the MasterCard authorization system will compare the proposed transaction with the limitations placed on the purchase cardholder’s account.

02. **Billing cycle** \- The period of time commencing on the 4th of each month and ending on the 3rd of the following month. All transactions that post to an account during a billing cycle are summarized on a statement of account.

03. **Bulk (or "block" ) funding** \- A method of setting aside funds for multiple purchases that may be shared by multiple purchase cardholders. Bulk funding eliminates the requirement for a separate requisition for each purchase. Funds for a general type expense, such as basic desktop office supplies, are approved and funded for purchase in advance. Bulk funding does not eliminate the requirement that purchases must be approved prior to using the PC.

04. **Card limit** \- The maximum cumulative amount that can be charged to a PC in any one billing cycle. The PC limits are used to strengthen internal controls by establishing the appropriate amount a purchase cardholder can spend in a billing cycle to accomplish their program responsibilities.

05. **Certificate of Appointment** \- A Standard Form 1402 is used for appointing contracting officers and is required for procurement authority exceeding the micro-purchase threshold.

06. **Convenience check** \- An alternative form of payment associated with a PC account limited to $2,500 for goods/services and $2,000 for construction/alterations. Convenience checks can only be used where the vendor does not accept the PC or other methods of payment cannot be used and the request is for safety, security and/or enforcement.

07. **Delegation of Procurement Authority (DPA)** \- A written DPA is required for micro-purchase authority (e.g., government wide commercial purchase cardholder, convenience check holder). An individual DPA issued to a micro-purchase cardholder through the Integrated Talent Management (ITM) providing their card limits and scope of purchasing authority. Purchase cardholders are required to acknowledge their individual DPA through the ITM system.

08. **Disputed item** \- An erroneous, duplicate or over charge that appears as a transaction on an individually billed government purchase cardholder's statement of account or on the transaction screen in the Purchase Card Module.

09. **Merchant category code (MCC)** \- A standard code assigned to every vendor that accepts a credit card that identifies the category of goods, services or activity they are involved with. The accuracy of the assigned MCC is the function of the vendor and MasterCard.

10. **Merchant category code (MCC) template** \- A grouping of codes that are assigned to each purchase cardholder's account based on their anticipated purchasing activity. An MCC template is an element of the system of internal controls for the credit card program, helping to reduce the potential for inappropriate use of a PC.

11. **Micro-purchase** \- An acquisition of supplies with an aggregate (total cost of purchase determined by total need) purchase amount that does not exceed $10,000 ($2,500 for services; $2,000 for construction).

12. **Purchase Card Module** \- A customized system developed alongside IFS to provide the purchase cardholder the ability to electronically fund, associate, reconcile and monitor purchase card transactions. This system enhances internal controls and ensures timely posting of obligations and payments to the financial system.

13. **Purchase card (PC)** \- The credit card used to purchase goods and services for IRS official government use only.

14. **Purchase card (PC) approving official** \- An individual with oversight and approval responsibility for PC activity of the purchase cardholders under his or her purview.

15. **Purchase card (PC) approving official designee** \- A PC approving official who is designated to approve another PC approving official's cardholders’ transactions in the Purchase Card Module. Designation as an acting manager **does not** confer authority to act as PC approving official. The designee must be from the same business unit as the PC approving official and must be a PC approving official for a group of purchase cardholders.

16. **Purchase Card Electronic Documentation Retention (PCEDR)** \- A SharePoint site that houses purchase card documentation prior to July 2021.

17. **PC reference document** \- The PC reference document is a tool which assists purchase cardholders with determining if a PC may be used to make support-type purchases.

18. **Purchase cardholder** \- An IRS employee who has been given a Delegation of Procurement Authority (DPA) and is authorized to make purchases using the PC. The purchase cardholder is the **only** user of the PC and is responsible for safeguarding the PC and account number to minimize the opportunity for theft or unauthorized use.

19. **Required sources** \- Vendors deemed by FAR Part 8 as prioritized required sources for supplies and services.

20. **Restricted Purchase List** \- Written guidance with a list of goods and services that IRS employees are prohibited from purchasing or items that can only be purchased with the appropriate approvals. The Restricted Purchase List is maintained by the Office of Procurement Policy.

21. **Single transaction limit** \- The PC dollar limit for any one transaction. The maximum allowable micro-purchase single transaction limit is $10,000 ($2,500 for services; $2,000 for construction/alterations). The maximum allowable single transaction limit applies to all purchase cardholders except those with contracting warrants.

22. **Split purchase** \- A series of purchases from the same vendor on the same day in a total amount that exceeds his/her single transaction limit ($10,000 goods, $2,500 for services and $2,000 for construction). A purchase cardholder may not make a split purchase under any circumstances.

23. **Statement of account** \- A summary of transactions (debits and credits) posted to the purchase cardholder's account during the billing cycle.

24. **Tax exemption** \- PC purchases made and paid directly by the federal government are tax exempt where the government is responsible for the payment. Purchase cardholders can access the [tax exemption letter](https://smartpay.gsa.gov/content/state-tax-information) for states and commonwealths prior to conducting official business.

25. **Vendor** \- The source of goods or services purchased. The vendor can be an individual or any type of business entity.


**1.35.4.1.7** **(11-12-2021)**

#### Acronyms

1. The following acronyms apply to this program:




| **Acronym** | **Definition** |
| --- | --- |
| ART | Accessibility Requirements Tool |
| DPA | Delegation of Procurement Authority |
| EHS | Environmental Health & Safety |
| FAR | Federal Acquisition Regulation |
| ICT | Information and Communication Technology |
| MCC | Merchant Category Code |
| NDAA | National Defense Authorization Act |
| NHQ | National Headquarters |
| OMB | Office of Management and Budget |
| PALS | Property Appraisal and Liquidation Specialist |
| PC | Purchase Card |
| RPL | Restricted Purchase List |
| SAM | System for Award Management |


**1.35.4.1.8** **(12-13-2019)**

#### Related Resources

1. Related resources for this IRM include:



1. IRM 1.32.4, Government Travel Card Program


**1.35.4.1.9** **(12-13-2019)**

#### Purchase Card Criteria

1. Criteria have been established to ensure that each PC is issued to responsible IRS employees who have a need and will adhere to all PC policies and procedures. These guidelines also address requirements for PC approving officials who likewise must adhere to established PC policies and procedures and must ensure that their purchase cardholders properly follow all policies and procedures.


**1.35.4.1.9.1** **(01-10-2024)**

##### Purchase Card Criteria for Purchase Cardholders

1. Purchase cardholders must:



1. Have a business need for the PC by making two or more purchases per fiscal year.

2. Create a PC order log in the Purchase Card Module for the items to be purchased and must associate a proper, fully funded requisition prior to placing an order.

3. Associate and reconcile posted transactions in the Purchase Card Module within 10 business days of the transaction download date.

4. Input the receipt date of goods/services for all posted transactions in the Purchase Card Module.

5. Use the Purchase Card Module order log to attach the appropriate documentation to support each purchase.

6. Complete Purchase Cardholder Refresher training every two years.


**1.35.4.1.9.2** **(01-10-2024)**

##### Purchase Card Criteria for PC Approving Officials

1. PC approving officials must:



1. Have a minimum of one assigned purchase cardholder.

2. Not be a purchase cardholder or plan manager.

3. Be in the same business unit as the purchase cardholder unless an agreement for one business unit to perform PC approving official duties of another business unit is established.

4. Be the same or higher grade and not subordinate organizationally to the assigned purchase cardholder(s).

5. Review downloaded transactions in the Purchase Card Module and purchase cardholder documentation to ensure adherence to guidelines and that the appropriate approvals, funding and documentation exist to support each purchase.

6. Review and approve all assigned purchase cardholder(s) posted transactions in the Purchase Card Module within 10 business days of the transaction download date.

7. Complete PC Approving Official Refresher Training every two years.


**Failure to comply with the PC approving official criteria will result in the deactivation of the PC approving official’s account(s).**

**1.35.4.2** **(12-13-2019)**

### Types of Purchase Card Accounts

1. Different types of PC accounts are used to support various functions within the IRS. Detailed information on the types of PC accounts is included in the electronic Purchase Card Guide.


**1.35.4.2.1** **(12-13-2019)**

#### Micro-Purchase Card

1. The micro-purchase card is a MasterCard issued to authorized individuals to purchase goods and services for official IRS government use. Purchases must be less than or equal to the single purchase transaction limit for the purchase cardholder's account. Transaction limits are based on the business needs of the purchase cardholder. The maximum single purchase transaction limit for micro-purchases is $10,000 ($2,500 for services, $2,000 for construction/alterations). All prospective purchase cardholders, regardless of the card type, must complete formal training before a PC is issued.


**1.35.4.2.2** **(12-13-2019)**

#### Enforcement Purchase Card (SB/SE)

1. Revenue officers directly involved with enforcement activity are issued a micro-purchase card that is restricted to enforcement related buys. Enforcement purchase cardholders cannot use their PC to purchase office supplies or routine services. SB/SE collection territory management assistants who have been issued a micro-purchase card for supplies and services may have enforcement purchase authority added to the card.


**1.35.4.2.3** **(12-13-2019)**

#### Enforcement Purchase Card (CI)

1. Criminal investigators directly involved with enforcement activity are issued a PC that is restricted to enforcement related buys. CI enforcement purchase cardholders cannot use their card to purchase routine office supplies and services.


**1.35.4.2.4** **(12-13-2019)**

#### Convenience Checks

1. Convenience checks are an alternative form of payment for specific programs where other methods of payment cannot be used. Convenience checks are associated with a PC account established with the government credit card contractor.

2. Convenience checks should be used as a payment method of last resort only when no reasonable alternative vendor is available who accepts the PC and can only be used when the request is for safety, security or enforcement.


**1.35.4.2.4.1** **(12-13-2019)**

##### Types of Convenience Check Purchase Cardholders

1. The use of convenience checks has been authorized for purchase cardholders in the following organizations:



1. CFO, Credit Card Services

2. SB/SE, property appraisal & liquidation specialists

3. National Headquarters (NHQ), Procurement


2. Convenience check purchase cardholders cannot use their convenience checks to purchase routine office supplies and services outside their authorized program guidelines.

3. Convenience check purchase cardholders are required to satisfy training requirements prior to receiving authorization to issue convenience checks.

4. Program specific approving officials and coordinators responsible for the activities of convenience check purchase cardholders must satisfy the training requirements for PC approving officials as well as program specific training for convenience check purchase cardholders.


**1.35.4.2.4.1.1** **(12-13-2019)**

###### CFO, Credit Card Services Convenience Check Program

1. The CFO convenience check program provides services for micro-purchases of safety, security or enforcement purchases when the vendor will not accept the government PC and no other vendor can provide the goods or services.

2. Convenience checks cannot be used to circumvent restrictions on a PC account. If the total need for the purchase exceeds $2,500 for goods and services or $2,000 for construction, the convenience check program cannot be used. Total purchase cannot be split into smaller parts in an attempt to circumvent the $2,500 limit. See IRM 1.35.4.3.4, Split Purchases.

3. Non-purchase cardholders must route their requests to Procurement.


**1.35.4.2.4.1.2** **(12-13-2019)**

###### SB/SE, Property Appraisal and Liquidation Program

1. SB/SE property appraisal and liquidation specialists (PALS) who use the government PC for enforcement related expenses are authorized to use convenience checks to issue payments to vendors who do not accept the PC.

2. The Director of Collection Policy is responsible for overseeing policies and procedures specific to PALS. Credit Card Services issues procedures for the use of convenience checks.


**1.35.4.2.4.1.3** **(12-13-2019)**

###### NHQ, Procurement Convenience Check Program

1. The convenience check program manager in Credit Card Services is responsible for the Procurement convenience check program and provides guidance and administrative oversight to Procurement convenience check purchase cardholders and PC approving officials.

2. The Office of the Chief Procurement Officer identifies purchase cardholders within Procurement who are authorized to use convenience checks for payments to vendors who do not accept the PC, or purchase order, or no other reasonable alternative vendor is available who accepts the PC.

3. Procurement convenience check purchase cardholders may issue a convenience check for purchases of $2,500 or less as a payment vehicle against a valid government contractual instrument when the vendor will not accept the PC, is exempted from the System for Award Management (SAM) and it is determined that no other SAM vendor can provide the product or service.


**1.35.4.2.5** **(12-13-2019)**

#### Warranted Contracting Officers - Purchases Greater than the Micro-Purchase Thresholds

1. Purchase cardholders procuring supplies or services greater than $10,000 ($2,500 for services; $2,000 for construction) must comply with all procurement laws and regulations, including competition, small business requirements and all instructions contained in the electronic Purchase Card Guide. Purchase cardholders must also comply with the limitations of their Certificate of Appointment.


**1.35.4.3** **(12-13-2019)**

### Purchase Card Program Guidance

1. Purchase card program guidance for the use of the government PC.


**1.35.4.3.1** **(12-13-2019)**

#### Authorized Purchase Card Use

1. The PC can only be used to purchase goods and services for official government use and:



1. Must follow IRS and business unit guidelines.

2. Be approved in advance of the purchase.

3. Be funded and documented in the PC Module order log prior to making the purchase.

4. Are within the purchase cardholder's assigned single transaction and monthly card limits as established in their individual DPA.


**1.35.4.3.2** **(11-12-2021)**

#### Unauthorized Purchase Card Use

1. The PC cannot be used to purchase:



1. Items for personal use

2. Prohibited and/or restricted items

3. Official travel-related expenses

4. Fuel for IRS owned or General Services Administration vehicles

5. Vehicle repairs/maintenance

6. Items without prior funding and approval

7. Items that exceed the micro-purchase threshold unless otherwise granted written delegated authority as evidenced by a Certificate of Appointment

8. Business and personal phone calls

9. NDAA Section 889 certification requirements not met for open market vendors


2. See the Restricted Purchase List and IRM 1.32.4, _Government Travel Card Program_, for additional guidance.


**1.35.4.3.3** **(12-13-2019)**

#### Purchase Card Restrictions

1. PC accounts are restricted by MCC and monthly and single transaction/dollar limits. If the PC is declined by a vendor because of a restriction, contact Credit Card Services through IRS Service Central.


**1.35.4.3.4** **(12-13-2019)**

#### Split Purchases

1. A purchase cardholder may not make a series of purchases from the same vendor on the same day in a total amount that exceeds his/her single transaction limit. This is true even if the purchase cardholder is ordering from the federal supply schedule contract.

2. For most purchase cardholders, the single transaction limit is $10,000 ($2,500 for services, $2,000 for construction/alterations). Purchase requirements exceeding the single transaction limit must be processed by Procurement. The split purchase rules also apply to the maximum allowable of $2,500 for convenience checks.

3. Splitting purchases is considered inappropriate use and is a conduct issue that could result in disciplinary action.


**1.35.4.3.5** **(11-12-2021)**

#### Inappropriate Use

1. Inappropriate use can be summarized in several general categories as follows:



1. Personal use items

2. Prohibited or restricted purchases

3. Using the incorrect card (e.g., using the PC to make an official travel purchase)

4. Purchases made without prior funding or required approvals

5. Altered orders: purchases that do not match the approved request

6. Purchases exceeding the purchase cardholder's single transaction limit

7. Purchases made by someone other than the purchase cardholder

8. Split purchases


2. Inappropriate use of the PC is a conduct issue that could result in disciplinary action. The Inappropriate Use Guide contains specific instances of misuse of the PC and their resolutions. The IRS Manager's Guide to Penalty Determinations provides Labor Relations guidance for penalty determinations for the misuse of the PC.

3. Personal use of the PC may require the IRS “to take steps to recover the cost of any illegal, improper or erroneous purchase” that results in loss to the government made with a PC or convenience check per the [Government Charge Card Abuse Prevention Act of 2012](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwjgppmYka2BAxXamGoFHU0mAhoQFnoECBQQAQ&url=https%3A%2F%2Fwww.govinfo.gov%2Fcontent%2Fpkg%2FPLAW-112publ194%2Fpdf%2FPLAW-112publ194.pdf&usg=AOvVaw3KQNyY48VX_a2fj8h--Gfp&opi=89978449).

4. See the Restricted Purchase List and IRM 1.35.4.3.4, Split Purchases, for additional guidance.


**1.35.4.3.6** **(11-12-2021)**

#### Separation of Duties and PC Approving Official Span of Control

1. IRS acquisition policy requires separation of duties associated with approval, funding, procurement and acceptance to minimize opportunities for unauthorized, fraudulent or otherwise improper acts. Separation of duties of purchase cardholders, PC approving officials and funding officials is necessary to avoid situations where one employee or a small group of employees performs more than one step in the process.

2. Purchase cardholders are allowed to conduct the purchase and receive supplies or services. Separation of duties guidance for participants in the PC program is as follows:



1. A PC approving official cannot be a cardholder.

2. A cardholder cannot be a PC approving official.

3. A cardholder or a PC approving official cannot be a plan manager.

4. A PC approving official cannot be subordinate (organizationally) to a cardholder unless an exception is granted by Credit Card Services.


3. Span of control is required by the OMB Circular A-123, Appendix B: Improving the Management of Government Charge Card Programs for PC approving officials and is based on the number of transactions approved per billing cycle.


**1.35.4.3.7** **(12-13-2019)**

#### Electronic Purchase Card Guide

1. The electronic Purchase Card Guide summarizes IRS policies and procedures relating to use of the PC. The procedures outlined in the guide apply to all IRS business units. The procedures may be supplemented by operating guidelines issued within a business unit. The electronic Purchase Card Guide is maintained as an electronic reference document.

2. See the Purchase Card Guide for additional guidance.


**1.35.4.3.8** **(12-13-2019)**

#### Restricted Purchase List

1. The Office of Procurement Policy provides guidance on restricted goods and services that purchase cardholders are prohibited from buying or that can only be purchased with the appropriate approvals. Purchase cardholders must be familiar with these restrictions and review the Restricted Purchase List before making a purchase. Business units may further limit what can be purchased with the PC. These restrictions can be found in the operating guidelines issued by the business unit.


**1.35.4.3.9** **(11-12-2021)**

#### Required Sources for Micro-Purchases

1. Office supplies must be purchased from mandatory supply schedules. Purchases must be made according to the priority listing chart located in the electronic Purchase Card Guide.

2. For approved purchases other than office supplies, see FAR Part 8, Required Sources of Supplies and Services, for the priority of sources.

3. See the Purchase Card Guide for additional guidance.


**1.35.4.3.10** **(11-12-2021)**

#### Information and Communication Technology Buys

1. All Information and Communication Technology (ICT) purchases made with the government PC must comply with Section 508 of the Rehabilitation Act of 1973.

2. Section 508 requires that when federal agencies develop, procure, maintain or use ICT, they must ensure that:



1. Federal employees with disabilities have access to and use of information and data that is comparable to that of federal employees who are not individuals with disabilities unless an undue burden would be imposed on the agency.

2. Individuals with disabilities, who are members of the public seeking information or services from the agency, have access to use information and data that is comparably provided to the public who are not individuals with disabilities.


3. Requesters or purchase cardholders must perform market research to find a product that conforms to Section 508, if applicable. Proper supporting documentation for the PC transaction is required.

4. For ICT purchases $10,000 or less, Section 508 requires the completion of the Accessibility Requirement Tool (ART) and the report maintained as part of the supporting documentation.

5. For ICT purchases that are $10,000 or greater, Section 508 requires that an ART report be completed and signed by the division director. A copy of a Determination and Findings or Undue Burden Exception Form, along with the approval confirmation, must be printed and maintained as part of the supporting documentation for each PC transaction.


**1.35.4.3.11** **(12-13-2019)**

#### Record Retention for Purchase Card Documentation

1. The required retention period for all PC documentation is six years from the cycle ending date of the purchase. See the [General Records Schedule 1.1](https://www.archives.gov/records-mgmt/grs/grs01-1.pdf) for additional guidance.

2. Purchase cardholders and convenience check cardholders must attach their receipts to the Purchase Card Module order log for PC approving official review and approval immediately after reconciliation.


**1.35.4.4** **(12-13-2019)**

### Purchase Card Compliance Reviews

1. Credit Card Services ensures appropriate use of the purchase card and convenience checks through several reviews:



1. Purchase card charges are selected by a random sample and reviewed to assess compliance with purchase card regulations.

2. All itemized transaction detail reported to the government credit card contractor by certain vendors is reviewed to determine if the charge was allowable per current guidance.

3. Purchase card charges are reviewed to ensure purchase cardholders comply with the split purchase policy and within their delegated procurement authority.

4. Convenience checks issued by convenience check cardholders are reviewed to assess compliance with purchase card regulations.


**1.35.4.5** **(12-13-2019)**

### Purchase Card Program Training

1. All purchase card program participants must complete training relative to their role to support compliance with OMB A-123, Appendix B.


**1.35.4.5.1** **(11-12-2021)**

#### Purchase Card/Convenience Check Training

1. All prospective purchase cardholders must complete the Micro-Purchase Card Training Curriculum and, if necessary, the required training for their assigned program before a PC will be issued. Cardholders with procurement authority over the micro-purchase threshold must complete additional requirements specified in the Treasury Acquisition Certification Management Program Handbook.

2. PC training requirements for specific card types:




| Types of purchasing | User of the card | Required training |
| :-: | :-: | :-: |
| Office supply purchases | Management assistants, clerks and others as determined by the business unit | Purchase card training ITM curriculum XF-15-9 |
| Convenience check purchases | Credit Card Services, PALS and Procurement | Purchase Card Convenience Check Writer Training - ITM Course 57176 - Submit IRS Service Central request for additional training requirements |
| Other than office supplies | As determined by business unit | Submit IRS Service Central request for assistance with proper enrollment |


**1.35.4.5.2** **(12-13-2019)**

#### PC Approving Official Training

1. Each business unit designates employees to be PC approving officials and complete an eligibility form prior to enrollment in the PC Approving Official Training Curriculum.

2. Prospective PC approving officials begin the enrollment process by completing the [purchase card approving official training request form](https://irssource.web.irs.gov/Linked%20Documents%20Library/PC_Appoving_Official_Training_Request_Form.pdf) found on the IRS Source Credit Card Services narratives.


**1.35.4.5.3** **(12-13-2019)**

#### Refresher Training

1. Purchase cardholders and PC approving officials are required to complete refresher training every two years.

2. Purchase cardholders and PC approving officials will be notified by email with detailed instructions when they are required to complete refresher training within 60 days of receipt.


**1.35.4.6** **(12-13-2019)**

### Activating the Purchase Card

1. Purchase cardholders should activate the PC upon receipt. Purchase cardholders should verify the accuracy of the information on the transmittal document that comes with the PC. If there is an error, the purchase cardholder should contact Credit Card Services by submitting a ticket through IRS Service Central.

2. To activate the purchase card, cardholders must follow the instructions on the face of the card. See the electronic Purchase Card Guide for additional information.


**1.35.4.7** **(12-13-2019)**

### Ordering a Replacement Card

1. The purchase cardholder can order a replacement PC if the card becomes worn out, damaged or defective by contacting the government credit card contractor at the telephone number listed on the reverse side of the PC. Accounts for lost or stolen PC will be closed and a new PC will be issued.


**1.35.4.8** **(12-13-2019)**

### Purchase Card Renewal Process

1. When the expiration date listed on the PC draws near, the government credit card contractor will automatically send the purchase cardholder a renewal PC. Generally, this will occur on the 20th of the month prior to the expiration date.

2. The renewal PC will require activation by calling the number on the face of the PC. Activating your renewal PC will automatically cancel the expiring card. Dispose of the expiring PC by cutting it up.

3. If the purchase cardholder does not receive a renewal card by the expiration date, the purchase cardholder should contact Credit Card Services by submitting an IRS Service Central ticket and provide:



1. The problem (such as PC expired, new PC not received)

2. Purchase cardholder's name as it appears on the PC

3. Last six digits of the account number


**1.35.4.9** **(12-13-2019)**

### Documenting Purchase Card Transactions

1. Each transaction made by a purchase cardholder or convenience check cardholder must be documented.

2. At a minimum, purchase cardholders must maintain all electronic or paper documentation substantiating:



1. Approval to place the order. A requisition or other document with detailed item description and approver's signature.

2. A statement, for convenience check transactions, that no reasonable alternative vendor is available who accepts the PC.

3. The item or service ordered matches the approved order. Order confirmation from the vendor with details or other documents reflecting the order placed and, if applicable, interim communications to reflect changes to an original order including returned items or credits.

4. Confirmation of items or services received. Received date entered in the PC order log, and packing slips, cash register receipts or other documents that support the received date entered in the PC order log.

5. Open market vendor certification of compliance with the National Defense Authorization Act (NDAA) Section 889, and Environmental, Health and Safety (EHS) professional’s approval for certain items.


3. See the Purchase Card Guide for additional guidance.


**1.35.4.10** **(12-13-2019)**

### Purchase Card Module

1. The Purchase Card Module enhances internal controls and ensures timely posting of obligations and payments to the financial system. Purchase cardholders have the ability to electronically fund, associate, reconcile and monitor purchase card transactions in the Purchase Card Module.


**1.35.4.10.1** **(12-13-2019)**

#### Purchase Card Order Log

1. Purchase cardholders must create and add a funded requisition to a PC order log prior to making a purchase. The PC order log tracks each step of a purchase and documents transaction details.

2. When goods or services are received, the PC order log item received date field must be updated.


**1.35.4.10.2** **(12-13-2019)**

#### Processing Time Frames

1. Purchase cardholders must associate/reconcile and PC approving officials must approve transactions within 10 business days of the transaction download date in the Purchase Card Module.

2. In the absence of the purchase cardholder, the PC approving official must review, associate and approve transactions. In addition, the PC approving official must indicate when the purchase cardholder is expected to return in the comments area in the Purchase Card Module. When the purchase cardholder returns to the office, they must reconcile all transactions within five business days.

3. In the absence of the PC approving official, the purchase cardholder must have another trained, established PC approving official designee in the same business unit to review and approve transactions. The PC approving official designee should be selected in advance of the projected PC approving official's absence date.

4. An IRS Service Central ticket should be submitted if the purchase cardholder or PC approving official require assistance with the selection of a PC approving official designee.

5. The overall processing time frame is not extended as a result of the absence of a purchase cardholder or PC approving official.


**1.35.4.10.3** **(12-13-2019)**

#### Transaction Reconciliation

1. Purchase cardholders must complete required actions for each purchase:



1. Reconcile and attach their supporting documentation to the Purchase Card Module order log for PC approving official review and approval immediately after reconciliation.

2. Modify the existing requisition to increase the amount of funds or create a new requisition to pay for erroneous charges.

3. Update the PC order log item to reflect full or partial receipt of items.


**1.35.4.11** **(12-13-2019)**

### Disputed Items

1. Disputed transactions fall into one of three categories: duplicate, erroneous and over charges.

2. All charges, including any disputed items, must be paid in full even if the vendor has acknowledged the error and intends to credit the account. Purchase cardholders are responsible for obtaining funds to pay for the disputed item and seek the appropriate credit from the vendor.

3. The purchase cardholder should:



1. Record the disputed purchase in the Purchase Card Module.

2. Contact the government credit card contractor.

3. Close the transaction in the Purchase Card Module when the credit posts to the purchase cardholder's account.


4. If the purchase cardholder thinks the PC has been lost, they must contact the government credit card contractor immediately. If the purchase cardholder thinks the PC has been stolen and/or compromised, they must contact TIGTA.


**1.35.4.12** **(12-13-2019)**

### Purchase Card Account Changes

1. Information and procedures regarding account maintenance changes are available in the electronic Purchase Card Guide and IRS Source employee resource narratives. Account maintenance changes include:



1. MCC changes

2. Address, phone number or name changes

3. Increase monthly purchase limit

4. Closing or reopening a purchase card account

5. Leaving the Service or moving to a new position


**1.35.4.13** **(12-13-2019)**

### Purchase Card Account Information

1. Information and procedures regarding PC accounts are available in the Purchase Card Guide and IRS Source employee resource narratives.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-035-004#addtoany "Show all")

A2A